

# Generated at 2022-06-12 15:28:52.591047
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError(
        text="Unexpected end of input"
    ) == ParseError(
        messages=[Message(text="Unexpected end of input"),]
    )
    assert ParseError(
        text='Expecting "," delimiter',
    ) == ParseError(
        messages=[Message(text='Expecting "," delimiter'),]
    )
    assert ParseError(
        text='Unexpected character "f"',
    ) == ParseError(
        messages=[Message(text='Unexpected character "f"',),]
    )
    assert ParseError(
        text="Must be at least 1 character long",
    ) == ParseError(
        messages=[Message(text="Must be at least 1 character long",),]
    )


# Generated at 2022-06-12 15:28:57.057882
# Unit test for constructor of class ValidationError
def test_ValidationError():
	# Instantiate a ValidationError with a single error message.
	errors = "error"
	message = Message(text=errors)
	assert message.text == errors

	# Instantiate a ValidationError with multiple error messages.
	errors = ["error1", "error2"]
	message = Message(text=errors[0])

	assert message.text == errors[0]

# Generated at 2022-06-12 15:29:01.675670
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=2)
    assert sum(result) == 2

    result = ValidationResult(error=ValidationError("error"))
    assert sum(result) == 1

# Generated at 2022-06-12 15:29:05.423706
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult(value=123)
    assert(list(iter(a)) == [123, None])
    b = ValidationResult(error=ValidationError(text='error'))
    assert(list(iter(b)) == [None, ValidationError(text='error')])


# Generated at 2022-06-12 15:29:07.956637
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="some string", key=1)
    message2 = Message(text="some string", key=1, index=[1])
    assert message1 == message2


# Generated at 2022-06-12 15:29:09.905343
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_one = Message(text="hello")
    message_two = Message(text="hello")

    assert message_one == message_two


# Generated at 2022-06-12 15:29:12.164523
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    ValidationResult(value='value__')


# Generated at 2022-06-12 15:29:19.363237
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text='foo', code='bar', key=1)
    m2 = Message(text='foo', code='bar', key=1)
    m3 = Message(text='foo', code='baz', key=1)
    m4 = Message(text='bar', code='bar', key=1)
    assert m1 == m2
    assert m1 != m3
    assert m1 != m4



# Generated at 2022-06-12 15:29:26.497624
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(error=None)
    result_fields = []
    for val in result:
        result_fields.append(val)
    assert result_fields == [None, None]

    result = ValidationResult(value=None)
    result_fields = []
    for val in result:
        result_fields.append(val)
    assert result_fields == [None, None]



# Generated at 2022-06-12 15:29:38.698749
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    from abc import abstractmethod
    from copy import copy
    
    
    class Position:
        def __init__(self, line_no: int, column_no: int, char_index: int):
            self.line_no = line_no
            self.column_no = column_no
            self.char_index = char_index
    
        def __eq__(self, other: typing.Any) -> bool:
            return (
                isinstance(other, Position)
                and self.line_no == other.line_no
                and self.column_no == other.column_no
                and self.char_index == other.char_index
            )
    
        def __repr__(self) -> str:
            class_name = self.__class__.__name__

# Generated at 2022-06-12 15:29:48.365340
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    from collections import OrderedDict
    from nose.tools import assert_equal, assert_not_equal, assert_dict_equal, raises
    from typesystem.types import String

    # Create a basic String type with a max length of 2, then attempt to validate a string of length 3
    string_type = String(max_length=2)
    data = "abc"
    schema = string_type.validate_or_error(data)
    index = [0]

    class_name = schema.__class__.__name__
    message_text = "Length must be less than or equal to 2"
    position = Position(line_no=1, column_no=2, char_index=2)

    # Create two Message objects with the same message text, code, index and position

# Generated at 2022-06-12 15:29:56.512053
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Empty
    vr = ValidationResult()
    lst = [x for x in vr]
    assert lst == [None, None]
    # value only
    vr = ValidationResult(value=123)
    lst = [x for x in vr]
    assert lst == [123, None]
    # error only
    vr = ValidationResult(error=ValidationError(text='text'))
    lst = [x for x in vr]
    assert isinstance(lst[1], ValidationError)
    assert lst[1]._messages == [Message(text='text', code='custom', key=None, position=None)]


# Generated at 2022-06-12 15:29:57.828839
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert (1, 456) == tuple(ValidationResult(value=(1, 456)))


# Generated at 2022-06-12 15:30:08.672013
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():

    # Unit test for method __iter__ of class ValidationResult
    # with initializer ValidationResult()
    res = ValidationResult()
    value = next(res)
    error = next(res)
    assert (value, error) == (None, None)
    assert not res

    # Unit test for method __iter__ of class ValidationResult
    # with initializer ValidationResult(error=ValidationError())
    res = ValidationResult(error=ValidationError())
    value = next(res)
    error = next(res)
    assert isinstance(error, ValidationError)
    assert (value, error) == (None, ValidationError())
    assert not res

    # Unit test for method __iter__ of class ValidationResult
    # with initializer ValidationResult(value=10)

# Generated at 2022-06-12 15:30:09.462977
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    x = yield
    pass


# Generated at 2022-06-12 15:30:10.662064
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    obj = ValidationResult()
    assert iter(obj)


# Generated at 2022-06-12 15:30:12.671992
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    val = ValidationResult(value=42)
    assert list(val) == [42, None]



# Generated at 2022-06-12 15:30:15.737170
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    instance = ValidationResult(value=2)
    for x in instance:
        print(x)
    return True


# Generated at 2022-06-12 15:30:18.972095
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    Schema = typesystem.Schema({})
    data = dict()
    x = Schema.validate_or_error(data)
    assert len(list(x)) == 2
    assert x[0].error is None
    assert x[1] is None


# Generated at 2022-06-12 15:30:23.283309
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value=True).__iter__()
    assert value is True
    assert error is None
    value, error = ValidationResult(error=ValidationError()).__iter__()
    assert value is None
    assert error is not None


# Generated at 2022-06-12 15:30:36.387616
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    i = iter(ValidationResult(value=None, error=None))
    assert i.__next__() is None
    assert i.__next__() is None
    # now use for loop
    for v in i:
        assert v is None
    # now try another instance
    i2 = iter(ValidationResult(value=3, error=None))
    assert i2.__next__() == 3
    assert i2.__next__() is None
    # now use for loop
    for v in i2:
        assert v is None


# Generated at 2022-06-12 15:30:40.426451
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value=5.5)
    assert len(error) == 0
    assert next(iter(value)) == 5.5
    assert next(iter(error)) is None
    with pytest.raises(StopIteration):
        next(iter(error))
    with pytest.raises(StopIteration):
        next(iter(value))


# Generated at 2022-06-12 15:30:42.561958
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    (value, error) = result
    assert value == 1
    assert error is None


# Generated at 2022-06-12 15:30:46.037563
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert(iter(vr) == iter([1,None]))
    vr = ValidationResult(error="2")
    assert(iter(vr) == iter([None,"2"]))


# Generated at 2022-06-12 15:30:49.407176
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    x = ValidationResult(error=ValidationError("Error message"))
    assert iter(x) == [None, x.error]
    y = ValidationResult(value=1)
    assert iter(y) == [1, None]

# Generated at 2022-06-12 15:30:58.462072
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="May not have more than 100 characters", code="max_length") == Message(text="May not have more than 100 characters", code="max_length")
    assert Message(text="May not have more than 100 characters", code="max_length") == Message(text="May not have more than 100 characters", code="max_length")
    assert Message(text="May not have more than 100 characters", code="max_length") == Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert Message(text="May not have more than 100 characters", code="max_length") == Message(text="May not have more than 100 characters", code="max_length", index=["username"])

# Generated at 2022-06-12 15:31:08.380276
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    x = Message(text="text", code="code", index=["abc", 2, "a"],
                start_position=Position(1, 1, 1), end_position=Position(2, 1, 2))
    y = Message(text="text", code="code", index=["abc", 2, "a"],
                start_position=Position(1, 1, 1), end_position=Position(2, 1, 2))
    z = Message(text="text", code="code", index=["abc", 2, "a"],
                start_position=Position(1, 1, 1), end_position=Position(2, 1, 2))
    assert x == y
    assert x == z
    assert y == z


# Generated at 2022-06-12 15:31:16.449162
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    V = ValidationResult
    i = iter(V(value=1))
    assert next(i) == 1
    try:
        next(i)
    except StopIteration:
        pass
    else:
        assert False

    i = iter(V(error='a'))
    assert next(i) is None
    assert next(i) == 'a'
    try:
        next(i)
    except StopIteration:
        pass
    else:
        assert False

test_ValidationResult___iter__()

# Generated at 2022-06-12 15:31:24.576172
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    x = ValidationResult()
    y = ValidationResult(value = 1)
    z = ValidationResult(error = ValidationError())

    it = iter(x)
    assert next(it) is None
    assert next(it) is None
    try:
        next(it)
    except StopIteration:
        pass
    else:
        raise AssertionError()

    it = iter(y)
    assert next(it) == 1
    assert next(it) is None
    try:
        next(it)
    except StopIteration:
        pass
    else:
        raise AssertionError()

    it = iter(z)
    assert next(it) is None
    assert isinstance(next(it), ValidationError)

# Generated at 2022-06-12 15:31:33.320877
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # arrange
    from typesystem.types import String
    import datetime
    testInstance = String()
    sample = {
        "string" : "test", 
        "date" : datetime.date(2019, 5, 20), 
        "year" : 2019
    }
    tip = 0
    # act
    validated = testInstance.validate(sample["string"])
    for item in validated:
        tip += 1
        continue
    res = tip > 0
    # assert
    assert res == True
    

# Generated at 2022-06-12 15:31:47.670695
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(value=1, error=2)) == [1, 2]
    assert list(ValidationResult(error=2)) == [None, 2]

# Generated at 2022-06-12 15:31:55.274412
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value="value")
    assert isinstance(result, ValidationResult)
    assert iter(result) == iter(ValidationResult.__iter__(result))
    assert "value" in iter(result)
    assert None in iter(result)
    assert list(result) == ["value", None]
    assert "value" in list(result)
    assert None in list(result)
    result = ValidationResult(error="error")
    assert isinstance(result, ValidationResult)
    assert iter(result) == iter(ValidationResult.__iter__(result))
    assert "error" in iter(result)
    assert None in iter(result)
    assert list(result) == [None, "error"]
    assert "error" in list(result)
    assert None in list(result)

# Unit test

# Generated at 2022-06-12 15:31:59.840448
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    values = ("", None)

    for x in values:
        for y in values:
            xy = ValidationResult(value=x, error=y)
            for xy1, xy2 in zip(xy, xy):
                assert xy1 == xy2


# Generated at 2022-06-12 15:32:08.217370
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    _value, _error = ValidationResult(value=42, error=ValidationError(text='Error'))

    # Test
    value, error = ValidationResult(value=42, error=ValidationError(text='Error'))
    assert value == _value
    assert error == _error

    value, error = ValidationResult(value=42, error=ValidationError(text='Error'))
    assert value == _value
    assert error == _error

    value, error = ValidationResult(error=ValidationError(text='Error'))
    assert value == _value
    assert error == _error

    value, error = ValidationResult(error=ValidationError(text='Error'))
    assert value == _value
    assert error == _error



# Generated at 2022-06-12 15:32:18.853251
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    try:
        import hypothesis.strategies as st
        from hypothesis import given, settings, Verbosity
    except ImportError:
        return 
    from . import serialize_schema
    from .schema import Schema
    from .types import Integer, String
    @settings(max_examples = 100, verbosity = Verbosity.verbose)
    @given(input_str = st.text(), output_str = st.text())
    def test(input_str, output_str):
        class MySchema(Schema):
            input = Integer(name = "input")
            output = String(regex = r"^(?:%s)$" % output_str, name = "output")
        validation_result = MySchema.validate_or_error({"input": input_str})

# Generated at 2022-06-12 15:32:24.630447
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result1 = ValidationResult(value = 1)
    result2 = ValidationResult(error = ValidationError(text = "Error text"))
    for result in [result1, result2]:
        assert result.value is not None or result.error is not None, "instance of ValidationResult must have neither value nor error to be None"
        for i in result:
            assert i is not None, "iterating over instance of ValidationResult must not produce None value"


# Generated at 2022-06-12 15:32:26.655424
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result, error = ValidationResult.__iter__(ValidationResult(value='a'))
    assert result == 'a'
    assert error is None


# Generated at 2022-06-12 15:32:33.815483
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(error=object())
    gen = result.__iter__()
    assert isinstance(gen, typing.Iterator)
    assert list(gen) == [None, result.error]
    #
    result = ValidationResult(value=object())
    gen = result.__iter__()
    assert isinstance(gen, typing.Iterator)
    assert list(gen) == [result.value, None]



# Generated at 2022-06-12 15:32:37.811698
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value="hi")
    assert tuple(result) == ("hi", None)

    result = ValidationResult(error=ValidationError(text="hi"))
    assert tuple(result) == (None, ValidationError(text="hi"))


# Generated at 2022-06-12 15:32:42.123463
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(value=42)
    assert tuple(validation_result) == (42, None)

    validation_result = ValidationResult(error=ValidationError(text="hello world"))
    assert tuple(validation_result) == (None, ValidationError(text="hello world"))

# Generated at 2022-06-12 15:33:18.132456
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(line_no=1, column_no=2, char_index=3),
    )
    message_2 = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(line_no=1, column_no=2, char_index=3),
    )
    assert message_1 == message_2


# Generated at 2022-06-12 15:33:26.880724
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    first = Message(text="May not have more than 100 characters")
    second = Message(text="May not have more than 100 characters")
    assert first == second

    first = Message(text="May not have more than 100 characters", code="max_length")
    second = Message(text="May not have more than 100 characters", code="max_length")
    assert first == second

    first = Message(text="May not have more than 100 characters", key="username")
    second = Message(text="May not have more than 100 characters", key="username")
    assert first == second

    first = Message(text="May not have more than 100 characters", index=["username"])
    second = Message(text="May not have more than 100 characters", index=["username"])
    assert first == second


# Generated at 2022-06-12 15:33:30.954217
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    object1 = Message(text="string", code="string", key=100, index=["string"], position=Position(1, 2, 3), start_position=Position(4, 5, 6), end_position=Position(7, 8, 9))
    object2 = Message(text="string", code="string", key=100, index=["string"], position=Position(1, 2, 3), start_position=Position(4, 5, 6), end_position=Position(7, 8, 9))
    assert object1 == object2


# Generated at 2022-06-12 15:33:33.586766
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="may not be empty", code="blank", key="username")
    message2 = Message(text="may not be empty", code="blank", key="username")
    assert(message1 == message2)



# Generated at 2022-06-12 15:33:36.160109
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="hello", code="test", key=1, index=[1]) == Message(text="hello", code="test", key=1, index=[1])


# Generated at 2022-06-12 15:33:43.812244
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Function message is additional argument to __eq__
    
    # Position is additional argument to __eq__
    assert Message(text="this is the text", code="the code", key="the key",
        start_position="the start position", end_position="the end position") != Message(text="this is the text", code="the code", key="the key",
        start_position="the start position", end_position="the end position")
    
    # String is additional argument to __eq__
    assert Message(text="this is the text", code="the code", key="the key",
        index="this is the index") != Message(text="this is the text", code="the code", key="the key",
        index="this is the index")
    

# Generated at 2022-06-12 15:33:53.837234
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='duplicate user', code='already_exists', key='username')
    message2 = Message(text='duplicate user', code='already_exists', key='username')
    assert message1 == message2
    message3 = Message(text='duplicate user', code='already_exists', key='password')
    assert message1 != message3
    message4 = Message(text='duplicate user', code='custom', key='username')
    assert message1 != message4
    message5 = Message(text='duplicate user', code='already_exists', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 != message5

# Generated at 2022-06-12 15:34:03.140538
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    class B:
        pass
    b = B()
    # Case 1
    input = Message(
        text = "May not have more than 100 characters",
        code = 'max_length',
        key = 'username',
        index = ['users', 3, 'username'],
        start_position = Position(line_no = 1, column_no = 1, char_index = 0),
        end_position = Position(line_no = 1, column_no = 1, char_index = 0),
    )

# Generated at 2022-06-12 15:34:10.862499
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='May not have more than 100 characters', code='max_length', key='username') == Message(text='May not have more than 100 characters', code='max_length', key='username')
    assert Message(text='May not have more than 100 characters', code='max_length', key='username') != Message(text='May not have more than 100 characters', code='max_length', key='username123')
    assert Message(text='May not have more than 100 characters', code='max_length', key='username') != Message(text='May not have more than 100 characters', code='max_length', index=['a','b','c'])
    assert Message(text='May not have more than 100 characters', code='max_length', key='username') != Message(text='May not have more than 100 characters', code='novalid')

# Unit test

# Generated at 2022-06-12 15:34:19.127767
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    p = Message('Invalid value')
    assert p == Message('Invalid value')
    assert p != Message('Invalid value', key='')
    assert p != Message('Invalid value', key=0)
    assert p != Message('Invalid value', key=None)
    assert p != Message('Invalid value', key='key')
    assert p != Message('Invalid value', key=1)
    assert p != Message('Invalid value', key=['1'])
    assert p != Message('Invalid value', key=['1', '2'])
    assert p != Message('Invalid value', index=['1'])
    assert p != Message('Invalid value', index=['1', '2'])


# Generated at 2022-06-12 15:35:06.731923
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(
        text="text",
        code="code",
        key="username",
        index=['users', 3, 'username'],
        position=Position(line_no=3, column_no=4, char_index=4),
        start_position=Position(line_no=3, column_no=4, char_index=4),
        end_position=Position(line_no=3, column_no=4, char_index=4),
    )


# Generated at 2022-06-12 15:35:18.126009
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Normal case
    # None
    x = Message(text="May not have more than 100 characters", code=None, key=None, index=None, position=None, start_position=None, end_position=None)
    y = Message(text=None, code="max_length", key=None, index=None, position=None, start_position=None, end_position=None)
    assert x.__eq__(y)

    # Normal case
    # Not None
    x = Message(text="May not have more than 100 characters", code="max_length", key="username", index=["users", 3, "username"], position=Position(1, 3, 5), start_position=None, end_position=None)

# Generated at 2022-06-12 15:35:28.466515
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="May not have more than 100 characters", code="max_length", key="username", start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=10, char_index=10))
    m2 = Message(text="May not have more than 100 characters", code="max_length", key="username", start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=10, char_index=10))

# Generated at 2022-06-12 15:35:35.291455
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message0 = Message(
        text="text", code="code", key="key", position=Position(0, 0, 0)
    )
    message1 = Message(
        text="text", code="code", index=["key"], position=Position(0, 0, 0)
    )
    message2 = Message(
        text="text", code="code", index=["key"], start_position=Position(0, 0, 0)
    )
    message3 = Message(
        text="text1", code="code", index=["key"], start_position=Position(0, 0, 0)
    )
    message4 = Message(
        text="text", code="code", index=["key"], start_position=Position(1, 0, 0)
    )

# Generated at 2022-06-12 15:35:41.814156
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="Foo", code="bar") == Message(text="Foo", code="bar")
    assert Message(text="Foo", code="bar") != Message(text="Bar", code="bar")
    assert Message(text="Foo", code="bar") != Message(text="Foo", code="baz")


# Generated at 2022-06-12 15:35:45.430835
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", index=["index"])
    message2 = Message(text="text", code="code", index=["index"])
    assert message == message2


# Generated at 2022-06-12 15:35:53.964817
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test `equal`
    m1 = Message(text='abc', code='a', key='b', position=Position(1, 2, 3))
    m2 = Message(text='abc', code='a', key='b', position=Position(1, 2, 3))
    assert m1 == m2

    # Test `unequal`
    m1 = Message(text='abc', code='a', key='b', position=Position(1, 2, 3))
    m2 = Message(text='abc', code='a', key='b', position=Position(2, 3, 4))
    assert not (m1 == m2)
    m1 = Message(text='abc', code='a', key='b', position=Position(2, 3, 4))

# Generated at 2022-06-12 15:36:00.612997
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", index=["index"])
    message1 = Message(text="text", code="code", index=["index"])
    assert message == message1
    assert message == Message(text="text", code="code", index=["index"])
    assert message != None
    assert message != 1
    assert message != Message(text="text", code="code", index=["index1"])
    assert message != Message(text="text1", code="code", index=["index"])
    assert message != Message(text="text", code="code1", index=["index"])
    assert message != Message(text="text", code="code", index=["index"], position=None)


# Generated at 2022-06-12 15:36:09.366528
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Create an instance of the type under test
    arg_text = ""
    arg_code = 0
    arg_key = 0
    arg_index = 0
    arg_position = 0
    arg_start_position = 0
    arg_end_position = 0
    obj = Message(
        text = arg_text,
        code = arg_code,
        key = arg_key,
        index = arg_index,
        position = arg_position,
        start_position = arg_start_position,
        end_position = arg_end_position,
    )
    # Get the type(s) under test.
    types_under_test = (obj,)
    # Check that all instances have the same type.
    assert len(set(type(x) for x in types_under_test)) == 1
    # Create a mock

# Generated at 2022-06-12 15:36:13.138602
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    a = Message(text = "text", code = "code", key = 1, index = [1], start_position = None, end_position = None)
    b = Message(text = "text", code = "code", key = 1, index = [1], start_position = None, end_position = None)
    assert a == b
