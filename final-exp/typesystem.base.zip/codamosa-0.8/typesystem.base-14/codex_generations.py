

# Generated at 2022-06-12 15:28:56.532997
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=[1,2,3])
    assert [i for i in vr] == [1,2,3]


# Generated at 2022-06-12 15:28:58.853289
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    pass # TODO


# Generated at 2022-06-12 15:29:03.932914
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    x = 4
    y = 6
    # value, error = x, y
    result = ValidationResult(value=x, error=y)
    # Only error should be present
    assert x in result.__iter__()
    # Only error should be present
    assert y in result.__iter__()

# Generated at 2022-06-12 15:29:09.526480
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    from pprint import pprint
    from .types import Array, Integer

    class User(Array):
        items = Integer()

    value, error = User.validate_or_error([1, 2, 3])
    assert error is None

    value, error = User.validate_or_error([1, "2", 3])
    assert error is not None
    assert len(error) == 1
    assert error.messages()[0].index == [1]
    pprint(error)



# Generated at 2022-06-12 15:29:16.911662
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert len(list(vr)) == 2
    assert len(list(vr)) == 0
    assert list(vr) == [1, None]
    vr = ValidationResult(error='error')
    assert len(list(vr)) == 2
    assert len(list(vr)) == 0
    assert list(vr) == [None, 'error']


# Generated at 2022-06-12 15:29:20.462549
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult(value=True)
    b = ValidationResult(error=True)
    assert next(iter(a)) == True
    assert next(iter(b)) == None


# Generated at 2022-06-12 15:29:27.801258
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="error") == Message(text="error")
    assert Message(text="error") != Message(text="error 2")
    assert Message(text="error", code="custom") != Message(text="error")
    assert Message(text="error", code="custom") != Message(text="error", code="text")
    assert Message(text="error", key="key") != Message(text="error")
    assert Message(text="error", key="key") != Message(text="error", key="key 2")
    assert Message(text="error", index=[1, 2, "3"]) == Message(text="error", index=[1, 2, "3"])
    assert Message(text="error", index=[1, 2, "3"]) != Message(text="error", index=[3, 2, "1"])

# Generated at 2022-06-12 15:29:34.363795
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    Test for method __iter__ of class ValidationResult.
    """
    # object my_result of class ValidationResult
    my_result = typesystem.ValidationResult(value=1)
    print("my_result:", my_result)
    # get all items in my_result
    items = list(iter(my_result))
    print("items:", items)


# Generated at 2022-06-12 15:29:40.211513
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # 1. Arrange
    value = 1
    expected_value = 1
    expected_error = None
    # 2. Act
    validationResult = ValidationResult(value=value)
    # 3. Assert
    actual_value = validationResult.value
    actual_error = validationResult.error
    assert actual_value == expected_value
    assert actual_error == expected_error

# Generated at 2022-06-12 15:29:42.961454
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value = 1)
    it = iter(vr)
    assert next(it) == 1
    assert next(it) == None
    try:
        next(it)
        assert False
    except StopIteration:
        assert True

# Generated at 2022-06-12 15:29:52.869329
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    res1 = ValidationResult(value=None, error=None)
    res2 = ValidationResult(value=None)
    res3 = ValidationResult(error=None)
    assert list(res1) == [None, None]
    assert list(res2) == [None, None]
    assert list(res3) == [None, None]


# Generated at 2022-06-12 15:29:54.815895
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    r = ValidationResult(error=ValidationError(text="error"))
    assert [v for v in r] is not None


# Generated at 2022-06-12 15:29:57.269000
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a=ValidationResult(value=3)
    print(a)
    for b in a:
        print(b)

# It will raise a TypeError, if the class ValidationResult doesn't define __next__

# Generated at 2022-06-12 15:30:00.564834
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1, error=ValidationError())
    assert [1, ValidationError()] == list(result)


# Generated at 2022-06-12 15:30:05.676590
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__(): 
    result, error = MySchema.validate_or_error(data)
    assert isinstance(result, ValidationResult)
    value, error = result
    assert value == expected_value
    assert isinstance(error, ValidationError)
    assert len(error) == 1
    assert error["username"] == "May not have more than 100 characters"


# Generated at 2022-06-12 15:30:09.105262
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Arrange
    validationResult = ValidationResult(error='error')

    # Invoke
    iterator = iter(validationResult)
    next = next(iterator)
    # Act
    assert next == None
    next = next(iterator)
    # Assert
    assert next == 'error'


# Generated at 2022-06-12 15:30:10.896837
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value=10)
    assert list(v) == [10, None]


# Generated at 2022-06-12 15:30:18.221001
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    Test ValidationResult __iter__ method
    """
    val_result = ValidationResult(value = "abc")
    res1 = []
    for val in val_result:
        res1.append(val)
    assert res1 == ["abc", None]

    val_result = ValidationResult(error = "error")
    res2 = []
    for val in val_result:
        res2.append(val)
    assert res2 == [None, "error"]



# Generated at 2022-06-12 15:30:21.211194
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    class_name = "ValidationResult"
    vr = ValidationResult(value = "stuff")
    assert next(iter(vr)) == "stuff"
    assert next(iter(vr)) is None
    try:
        _ = next(iter(vr))
    except StopIteration:
        assert True
    else:
        assert False

# Generated at 2022-06-12 15:30:24.735281
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result_1 = ValidationResult(value='some_value')
    assert list(result_1) == ['some_value', None]
    result_2 = ValidationResult(error='some_error')
    assert list(result_2) == [None, 'some_error']



# Generated at 2022-06-12 15:30:50.901140
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    if '__iter__' not in dir(ValidationResult):
        return 'not implemented'

    v = ValidationResult(value=1)
    lst = []
    for i in v:
        lst.append(i)
    if lst == [1, None]:
        return True
    return False

# Generated at 2022-06-12 15:30:59.661080
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert tuple(ValidationResult(value=10)) == (10, None)
    assert tuple(ValidationResult(error=ValidationError())) == (None, ValidationError())
    try:
        V = ValidationResult(value=10, error=ValidationError())
    except AssertionError:
        pass
    else:
        raise AssertionError("Both value and error specified")
    try:
        V = ValidationResult(value=None, error=None)
    except AssertionError:
        pass
    else:
        raise AssertionError("Both value and error specified")

    # Test that the iterable is single-use.
    V = ValidationResult(value=10)
    assert tuple(V) == (10, None)
    del V

# Generated at 2022-06-12 15:31:01.705583
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    obj = ValidationResult(value="bar")
    arr = list(obj.__iter__())
    assert arr == ["bar", None]


# Generated at 2022-06-12 15:31:05.333920
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=True)) == [True, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]

# Generated at 2022-06-12 15:31:08.118372
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Given
    v = ValidationResult(value = "dummy_value")
    # Then
    assert list(v) == ["dummy_value", None]


# Generated at 2022-06-12 15:31:09.693345
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert [True, None] == list(ValidationResult(value=True))


# Generated at 2022-06-12 15:31:12.056405
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(error=ValidationError())
    for res in vr:
        if res is not None:
            raise ValueError(res)

# Generated at 2022-06-12 15:31:13.732272
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    res = ValidationResult(1, None)
    assert len(res) == 2
    assert next(iter(res)) == 1



# Generated at 2022-06-12 15:31:17.449887
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    t = ValidationResult(value=123)
    res = tuple(t)
    assert res == (123, None)

    t = ValidationResult(error='error message')
    res = tuple(t)
    assert res == (None, 'error message')

# Generated at 2022-06-12 15:31:17.880760
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    pass