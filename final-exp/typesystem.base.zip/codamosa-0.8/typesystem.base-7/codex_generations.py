

# Generated at 2022-06-12 15:29:05.403212
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    print("Starting test_Position___eq__")
    p1 = Position(1, 2, 3)
    p2 = Position(1, 2, 3)
    assert p1 == p2
    p2_2 = Position(1, 2, 4)
    assert p1 != p2_2
    p2_3 = Position(1, 2, 3)
    assert p1 != p2_3
    p3 = Position(1, 2, 3)
    p4 = Position(1, 2, 4)
    assert p3 != p4
    result = True
    print("Finished test_Position___eq__")
    return result



# Generated at 2022-06-12 15:29:07.296762
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p1 = Position(1, 2, 3)
    p2 = Position(1, 2, 3)
    assert p1 == p2


# Generated at 2022-06-12 15:29:18.443780
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Check basic case
    pos1 = Position(1, 2, 3)
    pos2 = Position(1, 2, 3)
    assert pos1 == pos2
    # Check that line_no is considered
    pos1 = Position(1, 2, 3)
    pos2 = Position(2, 2, 3)
    assert not pos1 == pos2
    # Check that column_no is considered
    pos1 = Position(1, 2, 3)
    pos2 = Position(1, 3, 3)
    assert not pos1 == pos2
    # Check that char_index is considered
    pos1 = Position(1, 2, 3)
    pos2 = Position(1, 2, 4)
    assert not pos1 == pos2


# Generated at 2022-06-12 15:29:28.727236
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    class_name = Position(line_no=1, column_no=2, char_index=3)
    assert class_name == class_name
    assert class_name == Position(line_no=1, column_no=2, char_index=3)
    assert not (class_name == Position(line_no=2, column_no=2, char_index=3))
    assert not (class_name == Position(line_no=1, column_no=3, char_index=3))
    assert not (class_name == Position(line_no=1, column_no=2, char_index=4))
    assert not class_name == None
    assert not class_name == 1


# Generated at 2022-06-12 15:29:40.792791
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    """
    Test method `__eq__` of class `Position`
    """
    line_no = 2
    column_no = 3
    char_index = 4
    # Test case 1
    #
    # Test of `__eq__` method of class `Position`
    position1 = Position(line_no=line_no, column_no=column_no, char_index=char_index)
    position2 = Position(line_no=line_no, column_no=column_no, char_index=char_index)
    assert position1 == position2  # expected to be True
    # Test case 2
    #
    # Test of `__eq__` method of class `Position`
    position1 = Position(line_no=line_no, column_no=column_no, char_index=char_index)
   

# Generated at 2022-06-12 15:29:46.050797
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    a = Position(1, 2, 3)
    b = Position(1, 2, 3)
    c = Position(1, 4, 3)
    d = Position(1, 2, 4)
    assert a == a
    assert a == b
    assert b == a
    assert not a == c
    assert not c == a
    assert not a == d
    assert not d == a
    assert not a == 1
    assert not 1 == a
    assert not a == None
    assert not None == a


# Generated at 2022-06-12 15:29:55.198706
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Case 1.
    position = Position(line_no=1, column_no=2, char_index=3)
    other = Position(line_no=1, column_no=2, char_index=3)
    expected = True
    actual = position == other
    assert actual == expected, "actual: {0}, expected: {1}".format(actual, expected)

    # Case 2.
    position = Position(line_no=1, column_no=2, char_index=3)
    other = Position(line_no=4, column_no=5, char_index=6)
    expected = False
    actual = position == other
    assert actual == expected, "actual: {0}, expected: {1}".format(actual, expected)


# Generated at 2022-06-12 15:30:02.150067
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(2, 3, 4)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != 1

    assert Position(1, 2, 3) != Position(1, 2, 4)


# Generated at 2022-06-12 15:30:06.701787
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(0, 2, 3)
    assert Position(1, 2, 3) != Position(1, 0, 3)
    assert Position(1, 2, 3) != Position(1, 2, 0)


# Generated at 2022-06-12 15:30:10.247488
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 1, 0) == Position(1, 1, 0)
    assert Position(1, 1, 0) != Position(1, 0, 0)
    assert Position(1, 1, 0) != Position(0, 1, 0)
    assert Position(1, 1, 0) != Position(0, 0, 0)
