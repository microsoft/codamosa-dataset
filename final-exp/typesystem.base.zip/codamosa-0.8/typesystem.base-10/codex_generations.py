

# Generated at 2022-06-12 15:28:51.060549
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(error=ValidationError(text='test'))) == [None, ValidationError(text='test')]


# Generated at 2022-06-12 15:28:56.426939
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validationResult = ValidationResult(value=42)
    assert next(iter(validationResult), None) == 42
    assert next(iter(validationResult), None) == None

    validationResult = ValidationResult(error=ValidationError(text="Hello, world!"))
    assert next(iter(validationResult), None) == None
    assert next(iter(validationResult), None).text == "Hello, world!"



# Generated at 2022-06-12 15:29:04.814679
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = object()
    result = ValidationResult(value=value)
    res = tuple(result)
    assert len(res) == 2
    assert res[0] == value
    assert res[1] is None

    error = ValidationError()
    result = ValidationResult(error=error)
    res = tuple(result)
    assert len(res) == 2
    assert res[0] is None
    assert res[1] == error



# Generated at 2022-06-12 15:29:07.338170
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=42)
    value, error = result
    assert value == 42
    assert error is None
    value, error = result
    assert value == 42
    assert error is None


# Generated at 2022-06-12 15:29:09.831609
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = ValidationResult(value=1)
    assert value.value == 1
    assert value.error == None
    assert value == (1, None)

    error = ValidationResult(error=ValidationError(text='error'))
    assert error.value == None
    assert error.error.text == 'error'
    assert error == (None, ValidationError(text='error'))



# Generated at 2022-06-12 15:29:12.894410
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    expected_result = None
    result = list(ValidationResult(value=10))
    assert result == expected_result


# Generated at 2022-06-12 15:29:19.827097
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    success_v = ValidationResult(value=1)
    success_v_tuple = tuple(success_v)
    assert success_v_tuple == (1, None)

    err_v = ValidationResult(error='hello error')
    err_v_tuple = tuple(err_v)
    assert err_v_tuple == (None, 'hello error')


# Generated at 2022-06-12 15:29:27.524100
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    class_ = Position
    # Case: spesific
    line_no = 1
    column_no = 2
    char_index = 3
    inst = class_(line_no=line_no, column_no=column_no, char_index=char_index)
    other = class_(line_no=line_no, column_no=column_no, char_index=char_index)
    assert inst.__eq__(other) is True
    # Case: not equal
    inst = class_(line_no=line_no, column_no=column_no, char_index=4)
    assert inst.__eq__(other) is False
    # Case: not isinstance
    inst = class_(line_no=line_no, column_no=column_no, char_index=char_index)
    assert inst.__

# Generated at 2022-06-12 15:29:39.566153
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # >>> vr = ValidationResult(value='good job')
    # >>> next(iter(vr))
    # 'good job'
    # >>> next(iter(vr))
    # >>> next(iter(vr))
    # Traceback (most recent call last):
    #   File "<stdin>", line 1, in <module>
    # StopIteration
    vr = ValidationResult(value="good job")
    assert next(iter(vr)) == "good job"
    assert next(iter(vr)) is None
    with pytest.raises(StopIteration):
        next(iter(vr))
    # >>> vr = ValidationResult(error=ValidationError('bad job'))
    # >>> next(iter(vr))
    # >>> next(iter(vr))
    # ValidationError('bad job')
   

# Generated at 2022-06-12 15:29:42.514264
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(error=ValidationError(text='abc'))
    assert isinstance(validation_result, typing.Iterable)
    result_list = [x for x in validation_result]
    assert len(result_list) == 2

# Generated at 2022-06-12 15:30:00.749621
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position="position1")
    message2 = Message(text="text1", code="code1", key="key1", position="position1")
    message3 = Message(text="text1", code="code1", key="key1", position="position2")
    message4 = Message(text="text1", code="code2", key="key1", position="position1")
    message5 = Message(text="text1", code="code1", key="key2", position="position1")
    message6 = Message(text="text2", code="code1", key="key1", position="position1")
    assert message1 == message2
    assert message1 != message3
    assert message1 != message4
    assert message1 != message5

# Generated at 2022-06-12 15:30:09.909424
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text = "text1", code = "code", index=["index"], start_position = Position(1,1,1),
                      end_position = Position(2,2,2))
    message2 = Message(text="text1", code="code", index=["index"], start_position=Position(1, 1, 1),
                       end_position=Position(2, 2, 2))
    message3 = Message(text="text2", code="code", index=["index"], start_position=Position(1, 1, 1),
                       end_position=Position(2, 2, 2))

    message4 = Message(text="text2", code="code", start_position=Position(1, 1, 1),
                       end_position=Position(2, 2, 2))
    assert message == message2
    assert message2 == message
   

# Generated at 2022-06-12 15:30:19.150259
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    """
    Unit test for method __eq__ of class Message
    """
    text = 'May not have more than 100 characters'
    code = 'max_length'
    key = 'username'
    index = [key]
    line_no = 10
    column_no = 15
    char_index = 40
    position = Position(line_no, column_no, char_index)
    start_position = position
    end_position = position + 5
    message_obj = Message(text=text, code=code, key=key, index=index, position=position, start_position=start_position, end_position=end_position)
    assert message_obj == message_obj
    
    

# Generated at 2022-06-12 15:30:27.399590
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    position_30 = Position(line_no=30, column_no=30, char_index=30)
    position_40 = Position(line_no=40, column_no=40, char_index=40)
    message_1 = Message(
        text="abc", code="abc", key="abc", index=["abc"], position=position_30
    )
    message_2 = Message(
        text="abc", code="abc", key="abc", index=["abc"], position=position_30
    )
    assert message_1 == message_2
    message_2 = Message(
        text="abc", code="abc", key="abc", index=["abc"], position=position_40
    )
    assert message_1 != message_2

# Generated at 2022-06-12 15:30:33.924396
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg = Message(text='May not have more than 100 characters', code='max_length')
    msg1 = Message(text='May not have more than 100 characters', code='max_length')
    msg2 = Message(text='May not have more than 100 characters', code='max_length', index=['a', 'b'])
    print(msg == msg1)
    print(msg1 == msg2)
    print(msg == msg2)


# Generated at 2022-06-12 15:30:41.783135
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='Invalid value',
        code='invalid_value',
        key='username',
        index=["user", 3, "username"],
        position=Position(line_no=1, column_no=2, char_index=10),
        start_position=Position(line_no=1, column_no=2, char_index=10),
        end_position=Position(line_no=5, column_no=6, char_index=100))

# Generated at 2022-06-12 15:30:51.743356
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    print('Testing method __eq__ of class Message')
    test_object = Message(
        text="text",
        code="code",
        key=1,
        index=['a', 'b', 'c'],
        position=None,
        start_position=None,
        end_position=None,
    )
    result = test_object.__eq__(Message(
        text="text",
        code="code",
        key=1,
        index=['a', 'b', 'c'],
        position=None,
        start_position=None,
        end_position=None,
    ))
    assert result  # For making PyCharm inspections happy.
    assert result is True
    assert result == True
    assert result is not False
    assert result != False

# Generated at 2022-06-12 15:31:00.302343
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='test1') == Message(text='test1')
    assert Message(text='test1') != Message(text='test2')
    assert Message(text='test1') == Message(text='test1', code='max_length')
    assert Message(text='test1', index=[3, 4]) == Message(text='test1', index=[3, 4])
    assert Message(text='test1', index=[3, 4]) != Message(text='test1', index=[3, '4'])
    assert Message(text='test1', position=Position(line_no=1, column_no=4, char_index=6)) == Message(text='test1', position=Position(line_no=1, column_no=4, char_index=6))

# Generated at 2022-06-12 15:31:03.818220
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="test1", code="code1")
    message2 = Message(text="test2", code="code2")
    assert message1 != message2


# Generated at 2022-06-12 15:31:09.327848
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="May not have more than 100 characters", code="max_length") == Message(
        text="May not have more than 100 characters", code="max_length"
    )
    assert not (
        Message(text="May not have more than 100 characters", code="max_length")
        == Message(text="May not have more than 101 characters", code="max_length")
    )


# Generated at 2022-06-12 15:31:26.244111
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="May not have more than 100 characters") == Message(text="May not have more than 100 characters")
    assert Message(text="May not have more than 100 characters") == Message(text="May not have more than 100 characters", code=None, key=None, index=None, position=None, start_position=None, end_position=None)
    assert Message(text="May not have more than 100 characters", code="max_length") == Message(text="May not have more than 100 characters", code="max_length")
    assert Message(text="May not have more than 100 characters", code="max_length") == Message(text="May not have more than 100 characters", code="max_length", key=None, index=None, position=None, start_position=None, end_position=None)

# Generated at 2022-06-12 15:31:36.675624
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    position = Position(line_no = 1, column_no = 1, char_index = 0)
    assert Message(text="some_text", code="some_code", key="some_key", index=[1, "a", 2], position=position) == Message(text="some_text", code="some_code", key="some_key", index=[1, "a", 2], position=position)
    assert Message(text="some_text", code="some_code", key="some_key", index=[1, "a", 2], start_position=position, end_position=position) == Message(text="some_text", code="some_code", key="some_key", index=[1, "a", 2], start_position=position, end_position=position)


# Generated at 2022-06-12 15:31:42.273002
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text = "The message text", code = "The message code", key = "The message key", 
                        start_position = Position(1,1,1), end_position = Position(2,2,2) )
    message_2 = Message(text = "The message text", code = "The message code", key = "The message key", 
                        start_position = Position(1,1,1), end_position = Position(2,2,2) )
    assert (message_1 == message_2)

# Generated at 2022-06-12 15:31:50.312117
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert (
        Message(
            text="hello",
            code="custom",
            key=None,
            index=[],
            position=Position(line_no=1, column_no=2, char_index=21),
            start_position=None,
            end_position=None,
        )
        == Message(
            text="hello",
            code="custom",
            key=None,
            index=[],
            position=Position(line_no=1, column_no=2, char_index=21),
            start_position=None,
            end_position=None,
        )
    )


# Generated at 2022-06-12 15:31:54.445495
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message(text = "123", code = "abc")
    msg2 = Message(text = "123", code = "abc")
    assert msg1 == msg2, "__eq__ == 1"

    msg3 = Message(text = "222", code = "abc")
    assert not msg1 == msg3, "__eq__ == 2"

    msg4 = Message(text = "123", code = "abcd")
    assert not msg1 == msg4, "__eq__ == 3"


# Generated at 2022-06-12 15:32:04.827102
# Unit test for method __eq__ of class Message
def test_Message___eq__():

    # Case 1: Message with default code
    message_1 = Message(text='May not have more than 100 characters', code=None, key=None, index=None, position=None, start_position=None, end_position=None)
    message_2 = Message(text='May not have more than 100 characters', code='custom', key=None, index=None, position=None, start_position=None, end_position=None)
    assert message_1 == message_2

    # Case 2: Message with custom code
    message_1 = Message(text='May not have more than 100 characters', code='too_long', key=None, index=None, position=None, start_position=None, end_position=None)

# Generated at 2022-06-12 15:32:10.444680
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text = "4", code = "4", key = "4", index = [4], position = Position(4,4,4), start_position = Position(4,4,4), end_position = Position(4,4,4))
    message2 = Message(text = "4", code = "4", key = "4", index = [4], position = Position(4,4,4), start_position = Position(4,4,4), end_position = Position(4,4,4))
    assert message1 == message2

    message1 = Message(text = "5", code = "4", key = "4", index = [4], position = Position(4,4,4), start_position = Position(4,4,4), end_position = Position(4,4,4))

# Generated at 2022-06-12 15:32:20.613800
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text = 'hello', code = 'alpha', start_position = Position(0,0,0), end_position = Position(0,0,0))
    m2 = Message(text = 'hello', code = 'alpha', start_position = Position(0,0,0), end_position = Position(0,0,0))
    assert m1 == m2

    m1 = Message(text = 'hello', code = 'alpha', start_position = Position(0,0,0), end_position = Position(0,0,0))
    m2 = Message(text = 'hello', code = 'alpha', start_position = Position(0,0,1), end_position = Position(0,0,1))
    assert m1 != m2



# Generated at 2022-06-12 15:32:28.547239
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    """
    method __eq__ of class Message
    """

    message1 = Message(text="error 1")
    message2 = Message(text="error 2")
    message3 = Message(text="error 3")

    assert message1 == message1
    assert message1 != message2
    assert message1 != message3
    assert message2 != message3
    assert message2 == message2
    assert message3 == message3

    message4 = Message(text=message1.text)
    assert message1 == message4
    assert message4 == message1

    message5 = Message(text=message1.text, code=message1.code)
    assert message5 == message1

    message6 = Message(text=message1.text, code=message1.code, key=message1.key)
    assert message6 == message1

    message7 = Message

# Generated at 2022-06-12 15:32:35.765313
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text='text', code='code', key='key')
    message1 = Message(text='text', code='code', index=['key'])
    message2 = Message(text='text', code='code', index=['key'])
    assert not message == None
    assert not message == 10
    assert message == message1
    assert message == message2

if __name__ == "__main__":
    test_Message___eq__()

# Generated at 2022-06-12 15:33:02.774310
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Setup test data
    text1 = "abc"
    code1 = "custom"
    key1 = "a"
    index1 = ['index1']
    position1 = Position(1,2,3)
    start_position1 = Position(11,12,13)
    end_position1 = Position(21,22,23)

    # Creating 2 instances of Message class
    Message1 = Message(
        text=text1,
        code=code1,
        key=key1,
        index=index1,
        position=position1,
        start_position=start_position1,
        end_position=end_position1
    )

# Generated at 2022-06-12 15:33:08.114353
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="wrong key", code="wrong_key", index=["users", 3, "username"])
    m2 = Message(text="wrong key", code="wrong_key", index=["users", 3, "username"])
    assert m1 == m2
    m3 = Message(text="wrong key", code="wrong_key", index=["users", 3, "username"])
    m4 = Message(text="wrong key", code="wrong_key", index=["users", 4, "username"])
    assert m3 != m4
    

# Generated at 2022-06-12 15:33:19.631612
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["c", "d"], position=Position(1,2,3)) == Message(text="a", code="b", key="c", index=["c", "d"], position=Position(1,2,3))
    assert Message(text="a", code="b", key="d", index=["c", "d"], position=Position(1,2,3)) != Message(text="a", code="b", key="c", index=["c", "d"], position=Position(1,2,3))

# Generated at 2022-06-12 15:33:22.133264
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # __eq__ is implemented, so it should return True
    assert Message(text="foo") == Message(text="foo")
    # __eq__ is implemented, so it should return False
    assert not (Message(text="foo") == Message(text="bar"))



# Generated at 2022-06-12 15:33:29.342603
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text1', code='code1', key='key1', index=['index1'], start_position=Position(0, 0, 0), end_position=Position(1, 1, 1))
    message2 = Message(text='text2', code='code2', key='key2', index=['index2'], start_position=Position(2, 2, 2), end_position=Position(3, 3, 3))
    assert message1.__eq__(message2) == False
    message1 = Message(text='text1', code='code1', key='key1', index=['index1'], start_position=Position(0, 0, 0), end_position=Position(1, 1, 1))

# Generated at 2022-06-12 15:33:36.367147
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="some text", code="some code", key="some key")
    m2 = Message(text="some text", code="some code", key="some key")
    assert m1 == m2

    m3 = Message(text="some text", code="some code", index=[1, 2, 3])
    m4 = Message(text="some text", code="some code", index=[1, 2, 3])
    assert m3 == m4
    assert not (m1 == m3)

    m5 = Message(text="some text", code="some code")
    m6 = Message(text="some text", code="some code")
    assert m5 == m6

    m7 = Message(text="some text", code="some code", position=Position(1, 2, 3))

# Generated at 2022-06-12 15:33:42.096425
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    a = Message(text="text", code="code", key=1, index=[0, 1], position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    b = Message(text="text", code="code", key=1, index=[0, 1], position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    assert (a == b) == True


# Generated at 2022-06-12 15:33:51.333865
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text = 'a', code = 'b', key = 'c', index = 'd', position = 'e', start_position = 'f', end_position = 'g')
    message2 = Message(text = 'a', code = 'b', key = 'c', index = 'd', position = 'e', start_position = 'f', end_position = 'g')
    message3 = Message(text = 'D', code = 'C', key = 'B', index = 'A', position = 'G', start_position = 'F', end_position = 'E')
    assert (message1 == message2) == True
    assert (message1 == message3) == False


# Generated at 2022-06-12 15:33:59.669835
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    dummy1 = Message(text="May not have more than 100 characters", code="max_length", key="username", index=["users", 3, "username"], position=Position(line_no=5, column_no=9, char_index=8))
    dummy2 = Message(text="May not have more than 100 characters", code="max_length", key="username", index=["users", 3, "username"], position=Position(line_no=5, column_no=9, char_index=8))
    assert dummy1 == dummy2
    dummy2 = Message(text="May not have more than 100 characters", code="max_length", key="username", index=["users", 3, "username"], position=Position(line_no=5, column_no=9, char_index=9))
    assert dummy1 != dummy2

# Generated at 2022-06-12 15:34:08.857675
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="error message 2", code="errcode1", key="key1", index=[1,2], position=Position(1,2,3))
    message2 = Message(text="error message 2", code="errcode1", key="key1", index=[1,2], position=Position(1,2,3))
    message3 = Message(text="error message 3", code="errcode1", key="key1", index=[1,2], position=Position(1,2,3))
    message4 = Message(text="error message 2", code="errcode2", key="key1", index=[1,2], position=Position(1,2,3))

# Generated at 2022-06-12 15:34:46.286760
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="message1")
    message2 = Message(text="message1")
    message3 = Message(text="message3")
    assert message1==message2
    assert message1!=message3
    print("Test for method __eq__ of class Message passed")

# Generated at 2022-06-12 15:34:49.090985
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    value1 = Message(text='a', code='b', index=['c'])
    value2 = Message(text='a', code='b', index=['c'])
    assert value1 == value2


# Generated at 2022-06-12 15:34:56.729403
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    test_message_1 = Message(text='May not have more than 100 characters', code='max_length', key='username', 
                            index=['users', 3, 'username'], position='position.line_no=123, position.column_no=456, position.char_index=789')
    test_message_2 = Message(text='May not have more than 100 characters', code='max_length', key='username', 
                            index=['users', 3, 'username'], position='position.line_no=123, position.column_no=456, position.char_index=789')
    assert test_message_1 == test_message_2


# Generated at 2022-06-12 15:35:04.394738
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="", code="", key=None, index=None, position=None, start_position=None, end_position=None)
    m2 = Message(text="", code="", key=None, index=None, position=None, start_position=None, end_position=None)
    assert m1 == m2
    m2 = Message(text="", code="", key=None, index=None, position=None, start_position=Position(1, 2, 1), end_position=Position(1, 2, 1))
    assert m1 != m2
    m1 = Message(text="", code="", key=None, index=None, position=Position(1, 2, 1), start_position=None, end_position=None)
    assert m1 == m2

# Generated at 2022-06-12 15:35:07.087801
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    obj = Message(text="A", code="B")
    other = Message(text="A", code="B")
    assert obj == other



# Generated at 2022-06-12 15:35:18.350469
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(
        text="text",
        code="code",
        key=1,
        index=[1, 2, 3],
        position=Position(1, 1, 2),
        start_position=None,
        end_position=None
    )

    message_2 = Message(
        text="text",
        code="code",
        key=1,
        index=[1, 2, 3],
        position=Position(1, 1, 2),
        start_position=None,
        end_position=None
    )

    message_3 = Message(
        text="text",
        code="code",
        key=1,
        index=[1, 4, 3],
        position=Position(1, 1, 2),
        start_position=None,
        end_position=None
    )

   

# Generated at 2022-06-12 15:35:21.975238
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert not (Message(text='May not have more than 100 characters', code='max_length', key='username') ==
                Message(text='May not have more than 50 characters', code='max_length', key='username'))


# Generated at 2022-06-12 15:35:24.018826
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    require(Message(text='text', code='code', key='key') == Message(text='text', code='code', key='key'))



# Generated at 2022-06-12 15:35:24.566746
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    pass

# Generated at 2022-06-12 15:35:33.232285
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    #set up
    message = Message( text="May not have more than 100 characters", code="max_length", key="username", index=['users', 3, 'username'], start_position=Position(line_no=3, column_no=2, char_index=3), end_position=Position(line_no=3, column_no=2, char_index=3))
    assert message.__eq__(message)
    message1 = Message( text="May not have more than 100 characters", code="max_length", key="username", index=['users', 3, 'username'], start_position=Position(line_no=3, column_no=2, char_index=3), end_position=Position(line_no=3, column_no=2, char_index=3))
    assert message.__eq__(message1)
