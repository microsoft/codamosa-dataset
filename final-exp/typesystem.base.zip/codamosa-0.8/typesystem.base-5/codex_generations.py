

# Generated at 2022-06-12 15:28:48.606238
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    pair = ValidationResult(value=5)
    a, b = pair
    assert a == 5
    assert b is None


# Generated at 2022-06-12 15:28:54.780508
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text = "value1", code = "code1", key = "key1") == Message(text = "value1", code = "code1", key = "key1")
    assert Message(text = "value1", code = "code1", key = "key1") != Message(text = "value2", code = "code1", key = "key1")
    assert Message(text = "value1", code = "code1", key = "key1") != Message(text = "value1", code = "code2", key = "key1")
    assert Message(text = "value1", code = "code1", key = "key1") != Message(text = "value1", code = "code1", key = "key2")

# Generated at 2022-06-12 15:28:59.516787
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(value=None, error=ValidationError())
    assert list(validation_result) == [None, ValidationError()]


# Generated at 2022-06-12 15:29:09.404212
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    m2 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    m3 = Message(text='May not have more than 200 characters', code='max_length', key='username')
    m4 = Message(text='May not have more than 100 characters', code='other', key='username')
    m5 = Message(text='May not have more than 100 characters', code='max_length', index=['username'])

    def test_equal(m1, m2):
        if m1 != m2:
            print(f"{m1!r} != {m2!r}")
            exit(1)


# Generated at 2022-06-12 15:29:16.770171
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text = 'text')
    assert message == Message(text = 'text')
    assert not message == Message(text = 'text_')
    assert not message == Message(text = 'text', key = 'key')
    assert not message == Message(text = 'text', code = 'code')
    assert not message == Message(text = 'text', code = 'code', key = 'key')


# Generated at 2022-06-12 15:29:19.202827
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult()
    for value, error in validation_result:
        print(value)
        print(error)



# Generated at 2022-06-12 15:29:25.949317
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value = 1)
    assert v.value == 1
    assert v.error == None
    l = []
    for i in v:
        l.append(i)
    assert l[0] == 1
    assert l[1] == None

    v = ValidationResult(error = 1)
    assert v.value == None
    assert v.error == 1
    l = []
    for i in v:
        l.append(i)
    assert l[0] == None
    assert l[1] == 1
test_ValidationResult___iter__()


# Generated at 2022-06-12 15:29:29.587835
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]

    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]

# Generated at 2022-06-12 15:29:34.769870
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test if the method __eq__ works correctly
    message1 = Message("error", "code", "key")
    message2 = Message("error", "code", "key")
    message3 = Message("error", "code", "key1")
    assert message1 == message2
    assert message1 != message3


# Generated at 2022-06-12 15:29:38.600857
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value={'succ' : 'ssss'})
    if len(list(result)) == 2 :
        print('success')
    else :
        print('failed')



# Generated at 2022-06-12 15:29:43.638669
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    err1 = BaseError(text='test1')
    err2 = BaseError(text='test2')
    err3 = BaseError(text='test1')
    assert err1 == err3
    assert not (err1 == err2)

# Generated at 2022-06-12 15:29:47.621689
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    def method_under_test(data, expected_output):
        val_result = ValidationResult(data)
        assert val_result.value == expected_output
    
    method_under_test(data=[1], expected_output=1)
    

# Generated at 2022-06-12 15:29:56.897450
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    '''
    Test method __eq__ of class Message
    '''
    testPosition = Position(1, 1, 1)
    message1 = Message(text="message1", code="code1", index=None, position=Posi)
    message1_1 = Message(text="message1", code="code1", index=None, position=Position(1, 1, 1))
    message2 = Message(text="message2", code="code2", index=None, position=testPosition)
    message3 = Message(text="message1", code="code1", index=[1,2,3], position=testPosition)
    message4 = Message(text="message1", code="code1", index=None, position=testPosition, start_position=testPosition, end_position=testPosition)

# Generated at 2022-06-12 15:30:07.746133
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message1_1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters")
    message3 = Message(text="May not have more than 100 characters", code="max_length", key="username",
                       index=[32, 'name'])
    message4 = Message(text="May not have more than 100 characters", code="max_length", key="username",
                       start_position=Position(1, 2, 3))

# Generated at 2022-06-12 15:30:14.091524
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test input:
    # message_tuple : Tuple of message arguments.
    # message_args_dict : Dict of single message arguments corresponding to a tuple of message arguments.
    # str_output : Expected string output.
    # error_output : Expected error output.
    # error_index : Index of error in tuple.

    message_tuple = (
        Message(text="My error message"),
        Message(text="My error message", code="custom"),
        Message(text="My error message", code="custom", key="username"),
        Message(text="My error message", key="username"),
    )

# Generated at 2022-06-12 15:30:20.762455
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text', code='code', key=10, position=Position(5,5,5))
    message2 = Message(text='text1', code='code', key=10, position=Position(5,5,5))
    assert message1 == message1
    assert not (message1 == message2)
    assert message1 == Message(text='text', code='code', key=10, position=Position(5,5,5))
    assert message1 == Message(text='text', code='code', key=10, start_position=Position(5,5,5), end_position=Position(5,5,5))


# Generated at 2022-06-12 15:30:24.958208
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    items = [1, 2, 3, 4]
    result = ValidationResult()
    assert list(result) == [None, None]

    result = ValidationResult(value=items)
    assert list(result) == [items, None]

    result = ValidationResult(error=ValidationError())
    assert list(result) == [None, ValidationError()]

# Generated at 2022-06-12 15:30:31.115113
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = {"foo": "bar"}
    validation_result = ValidationResult(value=value)
    assert list(iter(validation_result)) == [value, None]

    error = ValidationError(text="Some error", code="error")
    validation_result = ValidationResult(error=error)
    assert list(iter(validation_result)) == [None, error]


# Generated at 2022-06-12 15:30:39.660107
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test first instantiated with a single message
    be1 = BaseError(text='a', code=None, key='a')
    be2 = BaseError(text='a', code=None, key='a')
    assert be1 == be2
    be3 = BaseError(text='a', code=None, key='a')
    assert be1 == be3
    be4 = BaseError(text='a', code='a', key='a')
    assert be1 == be4
    be5 = BaseError(text='a', code='a', key=0)
    be6 = BaseError(text='a', code=None, key=0)
    assert be5 == be6
    # Test instantiated with a list of error messages

# Generated at 2022-06-12 15:30:42.971565
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(error=ValidationError(text='error'))
    iterator = iter(validation_result)
    assert next(iterator) is None
    assert next(iterator) is validation_result.error

# Generated at 2022-06-12 15:30:56.662809
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    my_schema = String()
    value, error = my_schema.validate_or_error("hello")
    assert value is not None
    assert error is None
    assert value == "hello"

    value, error = my_schema.validate_or_error(123)
    assert error is not None
    assert value is None
    assert error.messages() == [Message(text="is not a valid string", code="type_error")]



# Generated at 2022-06-12 15:30:59.528341
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]

    result = ValidationResult(error=ValidationError(text="Error"))
    assert list(result) == [None, ValidationError(text="Error")]

# Generated at 2022-06-12 15:31:04.496568
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value = 'value of ValidationResult')
    for val in result:
        assert val == 'value of ValidationResult'
    result = ValidationResult(error = 'error of ValidationResult')
    for err in result:
        assert err == 'error of ValidationResult'

# Generated at 2022-06-12 15:31:07.894258
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value="EOF")
    assert next(iter(vr)) == "EOF"
    with pytest.raises(StopIteration):
        next(iter(vr))


# Generated at 2022-06-12 15:31:11.048760
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value=1)
    assert  value is 1 and error is None
    value1, value2, error = ValidationResult(value=1)
    assert value1 is 1 and value2 is None and error is None


# Generated at 2022-06-12 15:31:18.557705
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Instantiate ValidationResult with a value
    a = ValidationResult(value="value")
    # Extract the value and expect to get the value supplied to ValidationResult
    assert next(iter(a)) == "value"
    # Expect to get an exception StopIteration
    assert next(iter(a)) == StopIteration
    # Instantiate ValidationResult with an error
    b = ValidationResult(error="error")
    # Extract the value and expect to get the error supplied to ValidationResult
    assert next(iter(b)) == "error"
    # Expect to get an exception StopIteration
    assert next(iter(b)) == StopIteration


# Generated at 2022-06-12 15:31:20.224908
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value = [1])
    assert result



# Generated at 2022-06-12 15:31:24.970327
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = {
        'name': 'John Doe'
    }
    error = ValidationError(text='error message', code='error_code', key='name')
    vresult = ValidationResult(value=value, error=error)
    v = None
    e = None
    for x, y in vresult:
        v = x
        e = y
    assert v == value
    assert e == error


# Generated at 2022-06-12 15:31:32.030603
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Make an instance of ValidationResult
    # In order to make sure that the sort order of the set is correct,
    # use a sorted copy of the expected set.
    value = 'value'
    error = 'error'
    instance = ValidationResult(value=value, error=error)
    expected = sorted([value, error])
    actual = sorted(instance)
    assert expected == actual


# Generated at 2022-06-12 15:31:35.828646
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validate_result = ValidationResult(value='value')
    expected_return_type = typing.Iterator[typing.Any]
    # assert isinstance(value, expected)
    assert isinstance(iter(validate_result), expected_return_type)


# Generated at 2022-06-12 15:31:42.537911
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value="value")
    assert v.value == "value"
    assert v.error == None


# Generated at 2022-06-12 15:31:47.620703
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    with pytest.raises(AttributeError):
        for _ in ValidationResult---1:
            pass

    for value, error in ValidationResult(error=ValidationError(text="error")):
        assert error == ValidationError(text="error")
        assert value is None

    for value, error in ValidationResult(value=1):
        assert value == 1
        assert error is None

# Generated at 2022-06-12 15:31:51.078730
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    res = ValidationResult(value=(1,2,3,4))
    res_iter = iter(res)
    assert(next(res_iter)==(1,2,3,4))
    assert(next(res_iter)==None)


# Generated at 2022-06-12 15:31:52.530743
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value=1)
    a = 1
    for item in v:
        assert item == a
        a = 2
    assert a == 2



# Generated at 2022-06-12 15:31:56.846940
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from unittest.mock import Mock
    value = Mock(name='value')
    error = Mock(name='error')
    result = ValidationResult(value=value, error=error)
    assert list(result) == [value, error]
    # Unit test for method __bool__ of class ValidationResult

# Generated at 2022-06-12 15:32:00.278331
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = 'value'
    error = 'error'
    v = ValidationResult(value=value, error=error)
    for i, it in enumerate(v):
        if i == 0:
            assert it == value
        if i == 1:
            assert it == error

# Generated at 2022-06-12 15:32:06.986524
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    print("Test ValidationResult.__iter__()")
    vr = ValidationResult()
    assert vr.value is None
    assert vr.error is None

    vr = ValidationResult(value = 42)
    assert vr.value == 42
    assert vr.error is None

    vr = ValidationResult(error = ValidationError())
    assert vr.value is None
    assert vr.error is not None

    vr = ValidationResult(value = 42, error = ValidationError())
    assert vr.value is 42
    assert vr.error is None

# Generated at 2022-06-12 15:32:08.508067
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = 1
    ret = 0
    result = ValidationResult(value=value)
    for value in result:
        ret = ret + value
    assert ret == 1


# Generated at 2022-06-12 15:32:10.530619
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    instance = ValidationResult(value=1)
    assert not isinstance(next(instance), type(None))
    assert next(instance) == None

# Generated at 2022-06-12 15:32:12.761545
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    r = ValidationResult(value=1)
    assert iter(r)


# Generated at 2022-06-12 15:32:23.851617
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = MySchema.validate_or_error(data)
    for actual, expected in (value, error):
        assert actual == expected
        assert actual is expected

# Generated at 2022-06-12 15:32:26.970154
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    error = ValidationError(text="Test error")
    result = ValidationResult(error=error)
    values = list(result)
    assert len(values) == 2
    assert values[0] is None
    assert values[1] is error
    assert values == list(iter(result))

    result = ValidationResult(value="Test value")
    values = list(result)
    assert len(values) == 2
    assert values[0] == "Test value"
    assert values[1] is None
    assert values == list(iter(result))


# Generated at 2022-06-12 15:32:31.727202
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = 2
    b = 3
    res = ValidationResult(value=a)
    assert (a, None) == tuple(res)

    res = ValidationResult(error=b)
    assert (None, b) == tuple(res)

# Generated at 2022-06-12 15:32:38.715382
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    for value in [None, 1, 'test']:
        for error in [None, ValidationError(text='No error'), ValidationError(text='Error')]:
            result = ValidationResult(value=value, error=error)
            if error is None:
                assert len(list(result)) == 2
                assert list(result)[0] == value
                assert list(result)[1] is None
            else:
                assert len(list(result)) == 2
                assert list(result)[0] is None
                assert list(result)[1] == error

# Generated at 2022-06-12 15:32:43.683295
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    print('Test __iter__ of class ValidationResult:')
    my_value = 'my value'
    my_error = "my error"
    valRst = ValidationResult(value=my_value, error=my_error)
    
    for item in valRst:
        print(item)
    print()


# Generated at 2022-06-12 15:32:47.596581
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem import Integer

    schema = Integer(minimum=0)
    result = schema.validate_or_error(1)
    assert (1, None) == tuple(result)

    result = schema.validate_or_error(-1)
    assert (None, ValidationError({'': 'Must be at least 0'})) == tuple(result)


# Generated at 2022-06-12 15:32:52.165895
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult(value=None, error=ValidationError(messages=[Message(text="The error message")]))
    iterator = a.__iter__()
    try:
        assert next(iterator) == None
        assert next(iterator) == ValidationError(messages=[Message(text="The error message")])
    except StopIteration:
        assert False



# Generated at 2022-06-12 15:32:59.410433
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(value = 'test')
    # Check that interable is returned
    assert isinstance(iter(validation_result), typing.Iterator)
    # Check that value and error are yielded
    assert next(iter(validation_result)) == 'test'
    assert next(iter(validation_result)) == None
    # Check that StopIteration is raised once both values are yielded
    with pytest.raises(StopIteration):
        next(iter(validation_result))


# Generated at 2022-06-12 15:33:03.377395
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    s = ValidationResult()
    assert list(iter(s)) == [None, None]
    s = ValidationResult(value=1)
    assert list(iter(s)) == [1, None]
    s = ValidationResult(error='error')
    assert list(iter(s)) == [None, 'error']

# Generated at 2022-06-12 15:33:08.552038
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    def test_iter(self, *args, **kwargs):
        result = ValidationResult(*args, **kwargs)
        assert next(iter(result)) == result.value
        assert next(iter(result)) == result.error

    test_iter(value=True)
    test_iter(error=ValidationError())
