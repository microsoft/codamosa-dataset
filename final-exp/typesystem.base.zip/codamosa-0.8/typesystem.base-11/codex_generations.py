

# Generated at 2022-06-12 15:28:55.933384
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result_1 = ValidationResult(value='a')
    result_2 = ValidationResult(error='b')
    
    expected_result_1 = ['a', None]
    assert [i for i in result_1] == expected_result_1
    
    expected_result_2 = [None, 'b']
    assert [i for i in result_2] == expected_result_2


# Generated at 2022-06-12 15:29:04.451740
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(error= ValidationError(text= "hej"))
    assert len(list(vr)) == 2
    assert list(vr)[0] == None
    assert str(list(vr)[1]) == "hej"
    assert str(vr) == "hej"
    assert bool(vr) == False
    assert repr(vr) == "ValidationResult(error=ValidationError(text='hej'))"

# Generated at 2022-06-12 15:29:05.997561
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    obj = ValidationResult(value=1)
    result = list(obj)
    expected = [1, None]
    assert result == expected


# Generated at 2022-06-12 15:29:07.874351
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert dict(ValidationResult(value=1, error=None)) == {'value': 1, 'error': None}



# Generated at 2022-06-12 15:29:13.054015
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value = "test")
    itr = iter(vr)
    if (itr.__next__() != "test"): raise Exception("test_ValidationResult___iter__ Exception")
    if (itr.__next__() is not None): raise Exception("test_ValidationResult___iter__ Exception")


# Generated at 2022-06-12 15:29:13.718476
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
  pass

# Generated at 2022-06-12 15:29:20.786486
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    Unit test for method __iter__ of class ValidationResult
    """
    vr = ValidationResult(value=0)
    assert next(iter(vr)) == 0
    assert next(iter(vr)) == None

    vr = ValidationResult(error=ValidationError())
    assert next(iter(vr)) == None
    assert next(iter(vr)) != None

# Generated at 2022-06-12 15:29:25.004678
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    test_value, test_error = 'aaa', 'bbb'
    vr = ValidationResult(value=test_value, error=test_error)
    for v, e in vr:
        assert v == test_value
        assert e == test_error
    for v, e in vr:
        assert v == test_value
        assert e == test_error


# Generated at 2022-06-12 15:29:28.248826
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(value=None, error=None)
    assert set(iter(validation_result)) == set([validation_result.value, validation_result.error])



# Generated at 2022-06-12 15:29:32.953219
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # 1
    a = ValidationResult(value = True)
    assert list(iter(a)) == [True, None]
    # 2
    a = ValidationResult(error = 'error')
    assert list(iter(a)) == [None, 'error']


# Generated at 2022-06-12 15:29:44.153222
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    Unit test for method __iter__ of class ValidationResult
    """
    # [ ]
    with pytest.raises(AssertionError):
        ValidationResult()
    # [error]
    error = ValidationError(text="error")
    validation_result = ValidationResult(error=error)
    assert (validation_result.value, validation_result.error) == (None, error)
    # [value]
    value = 33
    validation_result = ValidationResult(value=value)
    assert (validation_result.value, validation_result.error) == (value, None)


# Generated at 2022-06-12 15:29:48.539366
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem import ValidationResult
    vr = ValidationResult(value='ok')
    assert list(vr) == ['ok', None]
    vr = ValidationResult(error='ng')
    assert list(vr) == [None, 'ng']


# Generated at 2022-06-12 15:29:50.704331
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    print('testing method __iter__ of class ValidationResult')
    print('-- tested by __bool__ method')


# Generated at 2022-06-12 15:29:53.521218
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    error = ValidationError(text="foo", code="bar")
    result = ValidationResult(error=error)
    value, error2 = result
    assert value is None
    assert error2 == error


# Generated at 2022-06-12 15:29:59.438466
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_1 = ValidationResult(value=1)
    i_1 = iter(validation_result_1)
    try:
        assert next(i_1) == 1
        assert next(i_1) == None
        assert False
    except StopIteration:
        pass
    validation_result_2 = ValidationResult(error=ValidationError())
    i_2 = iter(validation_result_2)
    try:
        assert next(i_2) == None
        assert next(i_2) != None
        assert False
    except StopIteration:
        pass
test_ValidationResult___iter__()

# Generated at 2022-06-12 15:30:06.110684
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v1 = ValidationResult(value='string')
    v2 = ValidationResult(error=ValidationError(text='error1', code='code1'))

    assert next(iter(v1)) == 'string'
    assert next(iter(v2)) == None

    assert list(iter(v1)) == ['string', None]
    assert list(iter(v2)) == [None, ValidationError(text='error1', code='code1')]


# Generated at 2022-06-12 15:30:08.889973
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result1 = ValidationResult(value='ok')
    result2 = ValidationResult(error='error')
    assert list(result1) == ['ok', None]
    assert list(result2) == [None, 'error']


# Generated at 2022-06-12 15:30:17.304906
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    item = ValidationResult(value=123, error=ValueError('foo'))
    for value, error in item:
        assert value == 123
        assert error == ValueError('foo')
    item.value = 456
    item.error = ValueError('bar')
    for value, error in item:
        assert value == 456
        assert error == ValueError('bar')
    assert iter(ValidationResult(value=123)) == iter((123, None))
    assert iter(ValidationResult(error=ValueError('foo'))) == iter((None, ValueError('foo')))


# Generated at 2022-06-12 15:30:23.279236
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Test the behaviour of the method __iter__ of the class ValidationResult
    # Create a instance of ValidationResult without passing an argument to the constructor
    # Check that the returned value of __iter__ is an Iterator
    try:
        assert isinstance(ValidationResult().__iter__(), Iterator)
    except AssertionError:
        print("AssertionError: assert isinstance(ValidationResult().__iter__(), Iterator)")

    # Create a instance of ValidationResult by passing the arguments value and error to the constructor
    # Check that the returned value of __iter__ is an Iterator

# Generated at 2022-06-12 15:30:27.116826
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Case 1: error not none
    assert list(ValidationResult(error=0)) == [None, 0]
    # Case 2: error= None
    assert list(ValidationResult(value=0)) == [0, None]

# Generated at 2022-06-12 15:30:35.711506
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = "value"
    err = ValidationResult(value = value)
    assert len(list(err)) == 2

# Generated at 2022-06-12 15:30:44.649396
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=None)) == [None, None]
    assert list(ValidationResult(value=True)) == [True, None]
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(value='test')) == ['test', None]
    assert list(ValidationResult(value=[1, 2])) == [[1, 2], None]
    assert list(ValidationResult(value={'name': 'test'})) == [{'name': 'test'}, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]
    assert list(ValidationResult(error=ValidationError(text='error'))) == [None, ValidationError(text='error')]

# Generated at 2022-06-12 15:30:48.888615
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value=True).__iter__()
    assert value == True
    assert error is None
    value, error = ValidationResult(error=ValidationError()).__iter__()
    assert value is None
    assert isinstance(error, ValidationError)


# Generated at 2022-06-12 15:30:50.567707
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    for method in [lambda: (1, 2)]:
        print(method())



# Generated at 2022-06-12 15:30:52.360681
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
   assert iter(ValidationResult(value = 1))     == iter([1, None])


# Generated at 2022-06-12 15:30:56.786844
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    class A:
        pass

    o = ValidationResult(value=A())
    assert next(iter(o)) is o.value
    assert next(iter(o)) is o.error

    o = ValidationResult(error=ValidationError())
    assert next(iter(o)) is o.value
    assert next(iter(o)) is o.error



# Generated at 2022-06-12 15:30:59.511302
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value='value', error='error')
    assert 'value' in result
    assert 'error' in result
    assert 'value' == result[0] and 'error' == result[1]


# Generated at 2022-06-12 15:31:04.495796
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    instance = ValidationResult()
    assert tuple(instance) == (None, None)

    instance = ValidationResult(value=True)
    assert tuple(instance) == (True, None)

    instance = ValidationResult(error='error')
    assert tuple(instance) == (None, 'error')



# Generated at 2022-06-12 15:31:13.557373
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="Message1", code="Code1", index=[1,2,3], position=Position(1,2,3), start_position=Position(1,2,3), end_position=Position(1,2,3))
    message2 = Message(text="Message1", code="Code1", index=[1,2,3], position=Position(1,2,3), start_position=Position(1,2,3), end_position=Position(1,2,3))
    message3 = Message(text="Message2", code="Code1", index=[1,2,3], position=Position(1,2,3), start_position=Position(1,2,3), end_position=Position(1,2,3))

# Generated at 2022-06-12 15:31:17.255789
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = ValidationResult(value="value1")
    for i in value:
        assert i == "value1"
    error = ValidationResult(error="error1")
    for i in error:
        assert i == "error1"


# Generated at 2022-06-12 15:31:35.829247
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    assert list(iter(result)) == [1, None]

    result = ValidationResult(error='error')
    assert list(result) == [None, 'error']
    assert list(iter(result)) == [None, 'error']



# Generated at 2022-06-12 15:31:43.761263
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from hypothesis import given, assume, example
    import hypothesis.strategies as st
    import random
    import typesystem
    @st.composite
    def types(draw,elements=st.none()|st.integers()|st.text()|st.lists(elements=elements,min_size=st.integers(min_value=0,max_value=1),max_size=st.integers(min_value=0,max_value=1))|st.dictionaries(keys=elements,values=elements,min_size=st.integers(min_value=0,max_value=5),max_size=st.integers(min_value=0,max_value=5))):
        return draw(elements)

# Generated at 2022-06-12 15:31:45.955987
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vresult = ValidationResult(value=1)
    (value, error) = vresult
    assert value == 1
    assert error is None

# Generated at 2022-06-12 15:31:49.538552
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    itr = iter(result)
    assert next(itr) == 1
    assert next(itr) is None
    with pytest.raises(StopIteration):
        next(itr)



# Generated at 2022-06-12 15:31:54.223904
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    res,err = ValidationResult(value=2)
    for i in res:
        assert i == 2 or i == None
    assert res.value == 2 or res.value == None
    assert res.error == None
    res,err = ValidationResult(error=ValidationError())
    for i in res:
        assert i == None or i == None
    assert res.value == None or res.value == None
    assert res.error != None
# test_ValidationResult___iter__()

# Generated at 2022-06-12 15:31:55.320853
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    ValidationResult(value=1)


# Generated at 2022-06-12 15:32:01.918103
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    '''
    Test that __iter__ of class ValidationResult returns an iterator
    '''
    vr = ValidationResult(value='i am a value')
    assert vr.__iter__() is iter([vr.value, vr.error])
    vr = ValidationResult(error='i am an error')
    assert vr.__iter__() is iter([vr.value, vr.error])


# Generated at 2022-06-12 15:32:04.547977
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=42)) == [42, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]


# Generated at 2022-06-12 15:32:07.686302
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr1 = ValidationResult(value=1)
    assert next(iter(vr1)) == 1
    
    vr2 = ValidationResult(error=ValidationError(text='error'))
    assert repr(next(iter(vr2))) == repr(ValidationError(text='error'))


# Generated at 2022-06-12 15:32:10.530937
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError(text="hello"))) == [None, ValidationError(text="hello")]
