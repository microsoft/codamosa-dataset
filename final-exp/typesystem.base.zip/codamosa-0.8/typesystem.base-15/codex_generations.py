

# Generated at 2022-06-12 15:28:53.541542
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='Test message', code='test_code', key='test_key') == Message(text='Test message', code='test_code', key='test_key')
    assert Message(text='Test message', code='test_code', key='test_key') != Message(text='Test message', code='test_code', key='test_key2')
    assert Message(text='Test message', code='test_code', key='test_key') != Message(text='Test message2', code='test_code', key='test_key')
    assert Message(text='Test message', code='test_code', key='test_key') != Message(text='Test message', code='test_code2', key='test_key')

# Generated at 2022-06-12 15:28:57.541286
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text="May not have more than 100 characters.")
    message_2 = Message(text="May not have more than 100 characters.")
    message_3 = Message(text="May not have more than 1000 characters.")

    assert message_1 == message_2
    assert not (message_1 == message_3)


# Generated at 2022-06-12 15:29:04.368006
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a, b = ValidationResult(value=1)
    assert type(a) == int
    assert type(b) == type(None)
    assert a == 1
    assert b is None
    a, b = ValidationResult(error=ValidationError())
    assert type(a) == type(None)
    assert type(b) == ValidationError
    assert a is None
    assert b != None


# Generated at 2022-06-12 15:29:05.704809
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(error='blabla')
    for x in vr:
        assert x == 'blabla'

# Generated at 2022-06-12 15:29:07.938314
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    #arrange
    result = ValidationResult(value=1)
    #action
    result_iter = iter(result)
    #assert
    assert result_iter.__next__() == 1
    with pytest.raises(StopIteration):
        result_iter.__next__()


# Generated at 2022-06-12 15:29:13.550971
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    x = ValidationResult(value=1)
    y = ValidationResult(error=ValidationError(text="test"))
    assert x.value is 1
    assert y.error is not None
    assert y.error.text == "test"
    assert list(x)[0] is 1
    assert list(y)[1].text == "test"


# Generated at 2022-06-12 15:29:18.262950
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert tuple(ValidationResult(value=3)) == (3, None)
    assert tuple(ValidationResult(error=ValidationError(text="Boom!"))) == (None, ValidationError(text="Boom!"))


# Generated at 2022-06-12 15:29:23.297104
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="Error message") == Message(text="Error message")
    assert Message(text="Error message", code="code") == Message(text="Error message", code="code")
    assert Message(text="Error message", code="code2") != Message(text="Error message", code="code")
    assert Message(text="Error message") != Message(text="Error message2")


# Generated at 2022-06-12 15:29:28.248905
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult(value=1)
    b = ValidationResult(error=1)
    it = a.__iter__()
    assert a.value == next(it)
    assert a.error == next(it)
    it = b.__iter__()
    assert b.value == next(it)
    assert b.error == next(it)

# Generated at 2022-06-12 15:29:32.775510
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from hypothesis import given
    from hypothesis.strategies import one_of
    from typesystem.types import String
    from typesystem.types import Integer
    from typesystem.types import Array
    string = String()
    integer = Integer()
    array = Array.of(one_of([string, integer]))
    @given(array)
    def test_array(array):
        value, error = array.validate_or_error(["bob", 3, "tom"])
        assert error is None
        assert value == ["bob", 3, "tom"]
        assert list(value) == ["bob", 3, "tom"]
        assert tuple(error) == ()
test_ValidationResult___iter__()

# Generated at 2022-06-12 15:29:43.758681
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from .data_schemas import Any

    for case in [
        ValidationResult(value=2),
        ValidationResult(value=None),
        ValidationResult(value=Any({})),
        ValidationResult(error=ValidationError()),
        ValidationResult(error=ValidationError(text="Test error")),
    ]:
        assert len(list(iter(case))) == 2


# Generated at 2022-06-12 15:29:53.903056
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test compare with exactly same object
    message1 = Message(
        text="test",
        code="test",
        key="test",
        index=[1,2,3],
        position=Position(1,2,3),
        start_position=Position(1,2,3),
        end_position=Position(2,2,3),
    )
    assert message1 == message1

    # Test compare with exactly same object in different value
    message2 = Message(
        text="test",
        code="test",
        key="test",
        index=[1,2,3],
        position=Position(1,2,3),
        start_position=Position(1,2,3),
        end_position=Position(2,2,3),
    )
    assert message2 == message2

    # Test compare with object

# Generated at 2022-06-12 15:29:57.084554
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value='value').__iter__()
    assert error is None
    assert value == 'value'
    value, error = ValidationResult(error='error').__iter__()
    assert value is None
    assert error == 'error'

# Generated at 2022-06-12 15:30:00.266355
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    ValidationResult(value=1)
    ValidationResult(error=ValidationError(text='Error'))



# Generated at 2022-06-12 15:30:03.817964
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(error=ValidationError(text="Error"))) == [None, ValidationError(text="Error")]
    assert list(ValidationResult(value=1)) == [1, None]


# Generated at 2022-06-12 15:30:05.631762
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=3)
    assert list(result) == [3, None]


# Generated at 2022-06-12 15:30:11.264835
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    _result = ValidationResult(value=1, error=None)
    assert [x for x in _result] == [1, None]
    _result = ValidationResult(value=None, error=1)
    assert [x for x in _result] == [None, 1]
    _result = ValidationResult(value=1, error=None)
    assert [x for x in _result] == [1, None]
    _result = ValidationResult(value=None, error=1)
    assert [x for x in _result] == [None, 1]


# Generated at 2022-06-12 15:30:14.603953
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    val_err=ValidationResult(value=5, error=None)
    for i in val_err:
        print(i)


# Generated at 2022-06-12 15:30:16.753534
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value = "data")
    assert list(vr) == ['data', None]


# Generated at 2022-06-12 15:30:20.931166
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result1 = ValidationResult(value='some value')
    result2 = ValidationResult(error=ValidationError(text='some text'))

    value1, error1 = result1
    value2, error2 = result2

    assert 'some value' == value1
    assert None == error1
    assert None == value2
    assert isinstance(error2, ValidationError)
    assert 'some text' == error2.messages()[0].text

# Generated at 2022-06-12 15:30:39.527915
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Test ValidationResult.__iter__
    a = ValidationResult(value=1) # ValidationResult object with value 1
    b = ValidationResult(error=ValidationError(text="err", code="err")) # ValidationResult object with error
    if __name__ == "__main__":
        print(a.value)
        print(b.error)
        for i in a:
            print(i)
        for i in b:
            print(i)
# test_ValidationResult___iter__()



# Generated at 2022-06-12 15:30:44.232930
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # use positional params
    vr = ValidationResult(2,3)
    vr_list = list(vr)
    assert vr_list[0] == 2
    assert vr_list[1] == 3
    # use keyword params
    vr = ValidationResult(error=2,value=3)
    vr_list = list(vr)
    assert vr_list[0] == 2
    assert vr_list[1] == 3
    # use no params
    vr = ValidationResult()
    vr_list = list(vr)
    assert vr_list[0] is None
    assert vr_list[1] is None



# Generated at 2022-06-12 15:30:46.583116
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(error = 10)
    assert next(iter(result)) == None
    assert next(iter(result)) == 10



# Generated at 2022-06-12 15:30:51.405720
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Version: v1.0
    # Authors: BMX
    # Date: 04/04/2019
    # Validated by:
    validation_result = ValidationResult(value=1)
    assert(next(iter(validation_result)) == 1)

    validation_result = ValidationResult(error=2)
    assert(next(iter(validation_result)) == 2)

# Generated at 2022-06-12 15:30:54.266205
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Test for __iter__ of class ValidationResult
    validation_result = ValidationResult(value=11)
    assert [11, None] == list(validation_result)


# Generated at 2022-06-12 15:30:55.996715
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # ValidationResult.__iter__
    assert isinstance(iter(ValidationResult(value=None, error=None)), typing.Iterator)


# Generated at 2022-06-12 15:31:03.006402
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    _0: ValidationResult
    _1: ValidationResult
    _2: ValidationResult
    _3: ValidationResult
    _4: ValidationResult
    _5: ValidationResult
    _6: ValidationResult

    _0 = ValidationResult(value=1)
    assert list(_0) == [1, None]

    _1 = ValidationResult(error=ValidationError(text='error'))
    assert list(_1) == [None, ValidationError(text='error')]

    _2 = ValidationResult(value=1, error=None)
    assert list(_2) == [1, None]

    _3 = ValidationResult(value=1, error=ValidationError(text='error'))
    assert list(_3) == [1, ValidationError(text='error')]

    _4

# Generated at 2022-06-12 15:31:07.963920
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    from json import loads as json_loads
    from yaml import safe_load as yaml_load
    from typesystem.utils import json_dumps
    from typesystem.utils import yaml_dumps
    from typesystem.utils import validate_or_error

    def check(schema_text, json_text, yaml_text):
        schema_cls = validate_or_error(json_loads(schema_text), schema.get_schema())
        values = {"YAML": yaml_load(yaml_text), "JSON": json_loads(json_text)}
        errors = {"YAML": ValidationError(text="yaml_error"), "JSON": ValidationError(text="json_error")}
        for (value_format, value) in values.items():
            error = errors[value_format]


# Generated at 2022-06-12 15:31:13.755174
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    actual = Message(text='foo', code='bar', index=[1], start_position=Position(1,1,1), end_position=Position(2,3,3))
    expected = Message(text='foo', code='bar', index=[1], start_position=Position(1,1,1), end_position=Position(2,3,3))
    assert expected == actual


# Generated at 2022-06-12 15:31:21.708884
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    class_name = Message.__name__
    # Test success
    p1 = Position(line_no=1, column_no=2, char_index=3)
    p2 = Position(line_no=2, column_no=3, char_index=4)
    message1 = Message(text='My Message', code='code', index=[5, 6], start_position=p1, end_position=p2)
    message2 = Message(text='My Message', code='code', index=[5, 6], start_position=p1, end_position=p2)
    assert message1 == message2

    # Test: messages with different indexes are equal
    message2 = Message(text='My Message', code='code', start_position=p1, end_position=p2)
    assert message1 == message2

    # Test failure

# Generated at 2022-06-12 15:31:48.084339
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    ks1 = Message(text='text', code="code", key="key", index=['index'])
    ks2 = Message(text='text', code="code", key="key", index=['index'])
    assert ks1 == ks2



# Generated at 2022-06-12 15:31:54.484792
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="a", code="b")
    assert Message(text="a", code="b") == message
    assert not Message(text="b", code="b") == message
    assert not Message(text="a", code="c") == message
    assert Message(text="a", code="b", key=0) == message
    assert not Message(text="a", code="b", key=1) == message
    assert not Message(text="a", code="b", index=[0]) == message
    assert not Message(text="a", code="b", index=[1]) == Message(text="a", code="b")


# Generated at 2022-06-12 15:31:58.250064
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="username", position=Position(1, 2, 3)) == Message(
        text="text", code="code", key="username", position=Position(1, 2, 3)
    )


# Generated at 2022-06-12 15:32:03.443993
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 3 characters.', code='max_length', key='first_name')
    message2 = Message(text='May not have more than 3 characters.', code='max_length', key='first_name')
    assert message1.__eq__(message2) == True

test_Message___eq__()


# Generated at 2022-06-12 15:32:07.928284
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text='test', code='test', index=[1], start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    m1_1 = Message(text='test', code='test', index=[1], position=Position(1, 1, 1))
    m2 = Message(text='test', code='test', index=[1], start_position=Position(1, 1, 1), end_position=Position(2, 2, 2))
    m3 = Message(text='test', code='test', index=[1], start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))

# Generated at 2022-06-12 15:32:18.427179
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=24, column_no=76, char_index=2345), end_position=Position(line_no=25, column_no=23, char_index=2789)) == Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=24, column_no=76, char_index=2345), end_position=Position(line_no=25, column_no=23, char_index=2789))

# Generated at 2022-06-12 15:32:27.161822
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # case 1
    message_1 = Message(text="text", code="code", index=['key1', 1, 'key2'], position=Position(line_no=1, column_no=1, char_index=1))
    message_2 = Message(text="text", code="code", index=['key1', 1, 'key2'], position=Position(line_no=1, column_no=1, char_index=1))
    test = message_1.__eq__(message_2)
    assert test == True

    # case 2
    message_1 = Message(text="text", code="code", index=['key1', 1, 'key2'], position=Position(line_no=1, column_no=1, char_index=1))

# Generated at 2022-06-12 15:32:34.364026
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", index=["index1", "index2"], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    other = Message(text="text", code="code", index=["index1", "index2"], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert message == other



# Generated at 2022-06-12 15:32:41.938833
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg_1 = Message(text="Something went wrong", code="custom", index=[1, 'key1'], start_position=Position(line_no=3, column_no=2, char_index=12), end_position=Position(line_no=7, column_no=4, char_index=52))
    msg_2 = Message(text="Something went wrong", code="custom", index=[1, 'key1'], start_position=Position(line_no=3, column_no=2, char_index=12), end_position=Position(line_no=7, column_no=4, char_index=52))
    expected = True
    actual = (msg_1 == msg_2)
    assert actual == expected


# Generated at 2022-06-12 15:32:43.920610
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text='some error message')
    m2 = Message(text='some error message')
    assert m1 == m2



# Generated at 2022-06-12 15:33:15.342274
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text = 'test', code='test', index=['test'], start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    message2 = Message(text = 'test', code='test', index=['test'], start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    assert message == message2


# Generated at 2022-06-12 15:33:24.245854
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    text = 'hello'
    code = 'test'
    key = 'key'
    index = [1, 2, 3]
    position = Position(1, 2, 3)
    start_position = Position(1, 2, 3)
    end_position = Position(1, 3, 3)
    message1 = Message(text=text, code=code, key=key, position=position)
    message2 = Message(text=text, code=code, index=index,
                       start_position=start_position, end_position=end_position)
    assert not (message1 == message2)
    message2 = Message(text=text, code=code, key=key, position=position)
    assert message1 == message2

# Generated at 2022-06-12 15:33:25.371704
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='a') == Message(text='a')



# Generated at 2022-06-12 15:33:31.233520
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message("", "", (), None, None, None)
    msg2 = Message("", "", (), None, None, None)
    msg3 = Message("", "", (), Position(1, 2, 3), None, None)
    msg4 = Message("", "", (), Position(1, 2, 3), None, None)
    msg5 = Message("", "", (), Position(1, 2, 3), Position(1, 2, 3), None)
    msg6 = Message("", "", (), Position(1, 2, 3), Position(1, 2, 3), None)
    assert msg1 == msg2
    assert msg3 == msg4
    assert msg5 == msg6
    assert msg1 != msg3
    assert msg3 != msg5


# Generated at 2022-06-12 15:33:36.283551
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    val = Message(text='text', code='code', index=[1, 2], start_position=Position(5, 6, 7), end_position=Position(5, 6, 7))
    other = Message(text='text', code='code', index=[1, 2], start_position=Position(5, 6, 7), end_position=Position(5, 6, 7))
    assert val == other

test_Message___eq__()


# Generated at 2022-06-12 15:33:43.892140
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Arrange
    text_1 = "a"
    code_1 = "b"
    key_1 = 3
    index_1 = [1, "a", 2.3]
    line_1 = 4
    column_1 = 5
    char_index_1 = 6
    position_1 = Position(line_1, column_1, char_index_1)
    start_position_1 = Position(line_1, column_1, char_index_1)
    end_position_1 = Position(line_1, column_1, char_index_1)


# Generated at 2022-06-12 15:33:53.286280
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test when isinstance(other, Message) is False
    other = [1, 2, 3]
    assert Message(text="The data is a list. Expected a dictionary",code="custom", key="family") != other
    # Test when self.text == other.text and self.code == other.code and self.index == other.index and self.start_position == other.start_position and self.end_position == other.end_position is True
    message1=Message(text="The data is a list. Expected a dictionary",code="custom", key="family")
    message2=Message(text="The data is a list. Expected a dictionary",code="custom", key="family")
    assert message1==message2


# Generated at 2022-06-12 15:34:02.548010
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    position = Position(line_no=1, column_no=1, char_index=0)
    message_orig = Message(
        text="msg",
        code="code",
        key="key",
        position=position,
    )
    # test for value
    message_vals = Message(
        text="msg",
        code="code",
        key="key",
        position=position,
    )
    message_vals.__eq__(message_vals)
    # test for type
    message_types = Message(
        text=1,
        code="code",
        key="key",
        position=position,
    )
    message_types.__eq__(message_types)
    # test for length of index

# Generated at 2022-06-12 15:34:10.534509
# Unit test for method __eq__ of class Message

# Generated at 2022-06-12 15:34:12.132314
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    pass
