

# Generated at 2022-06-12 15:29:01.222452
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with both values being None
    try:
        a = BaseError()
        b = BaseError()
        assert a == b
    except AssertionError:
        print('Test #1 of method __eq__ of class BaseError has failed!')
        raise
    else:
        print('Test #1 of method __eq__ of class BaseError has passed!')
    # Test with one value being None
    try:
        a = BaseError()
        b = BaseError(text='Error message', code='code')
        assert a != b
    except AssertionError:
        print('Test #2 of method __eq__ of class BaseError has failed!')
        raise
    else:
        print('Test #2 of method __eq__ of class BaseError has passed!')
    # Test with the other value being None

# Generated at 2022-06-12 15:29:10.099936
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert (
        ValidationError()
        == ValidationError()
        == BaseError(messages=[Message(text="")])
        == BaseError(messages=[Message(index=[], text="")])
    )
    assert (
        ValidationError(text="")
        == ValidationError(text="")
        == BaseError(messages=[Message(text="")])
        == BaseError(messages=[Message(index=[], text="")])
    )
    assert (
        ValidationError(text="", code="")
        == ValidationError(text="", code="")
        == BaseError(messages=[Message(text="", code="")])
        == BaseError(messages=[Message(index=[], text="", code="")])
    )

# Generated at 2022-06-12 15:29:13.552567
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message('no value found')
    message2 = Message('value not found')
    assert message1 == message1 and not message1 == message2


# Generated at 2022-06-12 15:29:18.712642
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error = BaseError(text='text', code='code', key='key', position=Position(1,2,3))
    error2 = BaseError(text='text', code='code', key='key', position=Position(1,2,3))
    assert error == error2

# Generated at 2022-06-12 15:29:28.965740
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message1 = Message(text="The error message.", code="my_code")
    message2 = Message(text="The error message.", code="my_code")
    message3 = Message(text="A different error message.", code="my_code")
    message4 = Message(text="The error message.", code="a_different_code")
    message5 = Message(text="The error message.", code="my_code", key="my_key")
    
    assert message1 == message1
    assert message1 == message2
    assert not (message1 == message3)
    assert not (message1 == message4)
    assert not (message1 == message5)
    
    

# Generated at 2022-06-12 15:29:32.490970
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=42)
    value, error = vr
    assert value == 42
    assert error is None
    assert list(vr) == [42, None]

# Generated at 2022-06-12 15:29:37.685410
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    from typesystem import String

    class MySchema(String):

        max_length = 100

    v, e = MySchema("a" * 101).validate_or_error()

    assert str(e) == '{"max_length": "May not have more than 100 characters"}'



# Generated at 2022-06-12 15:29:40.989508
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="invalid address", code="invalid", key="addresses")
    error2 = BaseError(text="invalid address", key="addresses")
    assert error1 == error2


# Generated at 2022-06-12 15:29:43.758596
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    x = ValidationResult(value = 0)
    l = list(x)
    assert l[0] == 0
    assert l[1] == None
    assert len(l) == 2
    # assert False # TODO: implement your test here



# Generated at 2022-06-12 15:29:53.860402
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text = 'ffff')
    message2 = Message(text = 'ffff')
    assert message1 == message2
    message3 = Message(text = 'ffff', code = 'max_length')
    assert not message1 == message3
    message4 = Message(text = 'ffff', code = 'max_length')
    assert message3 == message4
    message5 = Message(text = 'ffff', code = 'max_length', key = 'username')
    assert not message3 == message5
    message6 = Message(text = 'ffff', code = 'max_length', key = 'username')
    assert message5 == message6
    message7 = Message(text = 'ffff', code = 'max_length', index = ['users', 3, 'username'])
    assert not message5 == message7

# Generated at 2022-06-12 15:30:14.289788
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem import Integer
    from typesystem import String
    from typesystem import Schema

    class MySchema(Schema):
        age = Integer()
        name = String()

    schema = MySchema()
    result = schema.validate_or_error({'age': 'abc', 'name': 111})
    for value in result:
        print(value)



# Generated at 2022-06-12 15:30:19.115370
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    test_obj = ValidationResult(value=4)
    for item in test_obj:
        assert item == 4
    test_obj = ValidationResult(error=ValidationError(text="Test"))
    lst = []
    for item in test_obj:
        lst.append(item)
    assert lst == [None, ValidationError(text="Test")]



# Generated at 2022-06-12 15:30:24.811303
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    iterable = iter(result)
    assert iterable.__next__() == 1
    assert iterable.__next__() == None
    assert True

    result = ValidationResult(error=ValueError("error"))
    iterable = iter(result)
    assert iterable.__next__() == None
    assert iterable.__next__() == ValueError("error")
    assert True

# Generated at 2022-06-12 15:30:35.339823
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():

    # Test for method __iter__ of class ValidationResult
    # Case 1: value, error = validate_or_error(value, error)

    class TestValidationResult:
        def __init__(self):
            self.value = 42
            self.error = 'This is a test error'
        def validate_or_error(value, error):
            return ValidationResult(
                value=TestValidationResult.value,
                error=TestValidationResult.error
            )
    validate_or_error_res = TestValidationResult.validate_or_error(
        TestValidationResult.value, TestValidationResult.error
    )
    validate_or_error_iter_res = tuple(validate_or_error_res)
    # print(validate_or_error_iter_res)
    assert validate_or

# Generated at 2022-06-12 15:30:41.049887
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():

    v = typesystem.ValidationResult(value=88)
    iterv = iter(v)
    assert next(iterv) == 88
    assert next(iterv) == None
    try:
        next(iterv)
    except StopIteration:
        pass
    else:
        assert False

    v = typesystem.ValidationResult(error=88)
    iterv = iter(v)
    assert next(iterv) == None
    assert next(iterv) == 88
    try:
        next(iterv)
    except StopIteration:
        pass
    else:
        assert False

# Generated at 2022-06-12 15:30:43.440810
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value="value1")
    value, error = result
    assert value == "value1"
    assert error is None



# Generated at 2022-06-12 15:30:47.398599
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result, error = ValidationResult(value=1).__iter__()
    assert result == 1 and error is None

    result, error = ValidationResult(error=ValidationError()).__iter__()
    assert result is None and isinstance(error, ValidationError)


# Generated at 2022-06-12 15:30:48.020333
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    pass

# Generated at 2022-06-12 15:30:52.403563
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    try:
        message = Message(text="a message")
        error1 = ValidationError(messages=[message])
        error2 = ValidationError(messages=[message])
        assert error1 == error2
        assert error2 == error1
    except:
        raise AssertionError("testBaseError___eq____failed")



# Generated at 2022-06-12 15:30:58.154510
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # run the test
    error = ParseError(text='Text')
    assert str(error) == 'Text'
    # run the test
    error = ParseError(messages=[Message(text='Text', index=[1])])
    assert str(error) == '{"": "Text"}'
    # run the test
    error = ParseError(messages=[Message(text='Text', index=[1, 2])])
    assert str(error) == '{"": {"": "Text"}}'



# Generated at 2022-06-12 15:31:22.891494
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    val = ValidationResult(value = None, error = None)
    for x in [None,None]:
        i = iter(val)
        assert next(i) == x


# Generated at 2022-06-12 15:31:25.356551
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result1 = ValidationResult(value="value")
    assert list(result1) == ["value", None]
    result2 = ValidationResult(error="error")
    assert list(result2) == [None, "error"]


# Generated at 2022-06-12 15:31:26.343149
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # test the instance's method __eq__
    pass


# Generated at 2022-06-12 15:31:30.877795
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(value=True, error=ValidationError(text='error'))
    assert next(iter(validation_result)) == True
    assert next(iter(validation_result)) == ValidationError(text='error')


# Generated at 2022-06-12 15:31:35.561821
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult(value=1)
    b = ValidationResult(value=2)
    c = ValidationResult(error=3)

    assert list(a) == [1, None]
    assert list(b) == [2, None]
    assert list(c) == [None, 3]



# Generated at 2022-06-12 15:31:37.759615
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error = ValidationError(text='X')
    error2 = ValidationError(text='X')
    assert error == error2


# Generated at 2022-06-12 15:31:45.612092
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text = "Incorrect value", code = "bad_value")
    assert str(error) == "Incorrect value"
    error = BaseError(text = "Incorrect value", code = "bad_value", key = "username")
    assert str(error) == "Incorrect value"
    error = BaseError(text = "Incorrect value", code = "bad_value", key = "username", messages = [Message(text = "Incorrect value", code = "bad_value", key = "username")])
    assert str(error) == "Incorrect value"

# Generated at 2022-06-12 15:31:49.549719
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = 1
    result = ValidationResult(value=value)
    assert list(result) == [value, None]

    error = ValidationError("Unexpected key")
    result = ValidationResult(error=error)
    assert list(result) == [None, error]


# Generated at 2022-06-12 15:31:53.351927
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult()) == [None, None]
    assert list(ValidationResult(value=None)) == [None, None]
    assert list(ValidationResult(error=None)) == [None, None]
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError(text="error1"))) == [None, ValidationError(text="error1")]

# Generated at 2022-06-12 15:31:58.460456
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_validated = ValidationResult(value=9)
    assert list(validation_result_validated) == [9, None]
    validation_result_error = ValidationResult(error=ValidationError(text="test1"))
    assert list(validation_result_error) == [None, ValidationError(text="test1")]


# Generated at 2022-06-12 15:32:47.625438
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=42)) == [42, None]
    assert list(ValidationResult(error="e")) == [None, "e"]



# Generated at 2022-06-12 15:32:51.936117
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    import typesystem

    schema = typesystem.Schema(type="string")
    result = schema.validate_or_error("hello")
    value, error = result
    assert value == "hello"
    assert error == None

    value, error = result

    assert value == "hello"
    assert error == None



# Generated at 2022-06-12 15:32:52.926893
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult()
    assert list(vr) == [None, None]


# Generated at 2022-06-12 15:32:54.028903
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value = 2)
    assert(list(iter(vr)) == [2, None])


# Generated at 2022-06-12 15:32:55.891562
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result_valid = ValidationResult(value=5)
    assert list(result_valid) == [5, None]
    result_invalid = ValidationResult(error=ValidationError())
    assert list(result_invalid) == [None, ValidationError()]


# Generated at 2022-06-12 15:32:58.144009
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value=42).__iter__()
    assert value == 42
    assert error is None

    value, error = ValidationResult(error=ValidationError(key='foo', text='bar')).__iter__()
    assert value is None
    assert error == ValidationError(key='foo', text='bar')


# Generated at 2022-06-12 15:32:59.881979
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    x = True
    try:
        vr = ValidationResult()
        for v, e in vr:
            print(v, e)
    except:
        x = False
    assert x


# Generated at 2022-06-12 15:33:05.693235
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    import typesystem

    bool_schema = typesystem.Boolean(description="True or false?")
    bool_schema.validate(True)

    # Test that __iter__() returns the correct values
    for i in bool_schema:
        assert i is True
    for i in bool_schema.validate_or_error(True):
        assert i is True
    for i in bool_schema.validate_or_error():
        assert isinstance(i, ValidationError)


# Generated at 2022-06-12 15:33:09.685726
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value="value1")
    vr_iter = iter(vr)
    assert next(vr_iter) is vr.value
    with pytest.raises(StopIteration):
        next(vr_iter)



# Generated at 2022-06-12 15:33:13.856025
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    iter_result = []
    for v, e in ValidationResult(value=1):
        iter_result.append(v)
        iter_result.append(e)
    assert iter_result == [1, None]
