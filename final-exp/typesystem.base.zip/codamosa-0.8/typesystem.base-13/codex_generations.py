

# Generated at 2022-06-12 15:28:51.775017
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Test with value
    vr = ValidationResult(value="test")
    k, e = next(vr.__iter__())
    assert k == vr.value
    assert e == vr.error
    try:
        next(vr.__iter__())
    except Exception:
        assert True
    # Test with error
    vr = ValidationResult(error=ValidationError(text="error"))
    k, e = next(vr.__iter__())
    assert k == vr.value
    assert e == vr.error
    try:
        next(vr.__iter__())
    except Exception:
        assert True


# Generated at 2022-06-12 15:28:54.041900
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value = 0)
    v, e = result
    assert v == 0
    assert e == None
    result = ValidationResult(error = ValidationError())
    v, e = result
    assert v == None
    assert type(e) == ValidationError


# Generated at 2022-06-12 15:28:57.356841
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error = ValidationError(messages=[Message(text='my text')])
    assert error == {'': 'my text'}
    assert error != {'': 'my other text'}
    assert error != [Message(text='my text')]


# Generated at 2022-06-12 15:29:03.219741
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value="value1").__iter__()
    assert value == "value1"
    assert error is None

    value, error = ValidationResult(error="error1").__iter__()
    assert value is None
    assert error == "error1"


# Generated at 2022-06-12 15:29:06.127839
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    lst = [i for i in result]
    result = ValidationResult(error=ValidationError())
    lst = [i for i in result]
    pass


# Generated at 2022-06-12 15:29:17.701542
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    err = BaseError(text='Maximum length exceeded')
    assert str(err) == 'Maximum length exceeded'

    err = BaseError(messages=[Message(text='Maximum length exceeded')])
    assert str(err) == "{'': 'Maximum length exceeded'}"

    err = BaseError(messages=[Message(text='Maximum length exceeded', key='length')])
    assert str(err) == '{length: \'Maximum length exceeded\'}'

    err = BaseError(Messages=[Message(text='Maximum length exceeded', index=['user', 'length'])])
    assert str(err) == "{'user': {'length': 'Maximum length exceeded'}}"

    err = ValidationError(text='Maximum length exceeded')
    assert str(err) == 'Maximum length exceeded'


# Generated at 2022-06-12 15:29:21.897920
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text = "error message 1")
    error2 = BaseError(text = "error message 2")
    error3 = BaseError(text = "error message 1")

    assert(error1 == error3)
    assert(error1 != error2)


# Generated at 2022-06-12 15:29:23.789652
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    with pytest.raises(AssertionError):
        ValidationResult(value="foo", error="bar")


# Generated at 2022-06-12 15:29:28.053227
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v_result = ValidationResult(value=None, error=None)
    assert not v_result.value
    assert not v_result.error
    
    v_result = ValidationResult(value=1, error=None)
    assert v_result.value == 1
    assert not v_result.error

# Generated at 2022-06-12 15:29:30.053769
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    def foo(x):
        return x
    assert tuple(ValidationResult(value=foo(1))) == (foo(1), None)
    assert tuple(ValidationResult(error=foo(2))) == (None, foo(2))


# Generated at 2022-06-12 15:29:40.989560
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Case 1: ValidationResult(value={})    
    Case1 = ValidationResult(value = {})
    Case1_iter__ReturnValue1 = next(iter(Case1))
    Case1_iter__ReturnValue2 = next(iter(Case1))
    # Case 2: ValidationResult(error={})    
    Case2 = ValidationResult(error = {})
    Case2_iter__ReturnValue1 = next(iter(Case2))
    Case2_iter__ReturnValue2 = next(iter(Case2))
    return 0

# Generated at 2022-06-12 15:29:44.235996
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = None
    error = ValidationError(text="test")
    # Act
    validationResult = ValidationResult(value=value, error=error)
    iter_value, iter_error = next(iter(validationResult))

    # Assert
    assert iter_value is None
    assert iter_error.text == "test"



# Generated at 2022-06-12 15:29:54.560635
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Setup
    text = 'May not have more than 100 characters'
    code = 'max_length'
    key = 'username'
    index = ['users', 3, 'username']

    # Execution
    message = Message(text=text, code=code, key=key)
    message1 = Message(text=text, code=code, key=key)

    message2 = Message(text=text, code=code, key=key)
    message2.index=['user', 2, 'username']

    message3 = Message(text=text, code=code, index=index)

    # Verification
    assert message == message1
    assert message != message2
    assert not message == message2
    assert message != message3
    assert not message == message3
    assert message3 != message2
    assert not message3 == message2



# Generated at 2022-06-12 15:29:58.097409
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    def test_it():
        input = ValidationResult(
            value={'name': 'Hello'}, error=ValidationError({'name': 'Not valid'},)
        )
        actual = iter(input)
        expected = input.value, input.error
        assert actual == expected
    test_it()



# Generated at 2022-06-12 15:30:08.888649
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="My Book", code="INVALID_COMMAND") == Message(text="My Book", code="INVALID_COMMAND")
    assert Message(text="My Book", code="INVALID_COMMAND") != Message(text="My Book", code="INVALID_COMMAND2")
    assert Message(text="My Book", code="INVALID_COMMAND") != Message(text="My Book2", code="INVALID_COMMAND")
    assert Message(text="My Book", code="INVALID_COMMAND") != Message(text="My Book", code="INVALID_COMMAND", key="username")

# Generated at 2022-06-12 15:30:12.667475
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value=4)
    assert v.value == v.__iter__().__next__()
    assert v.__iter__().__next__() == v.error

    v = ValidationResult(error=ValidationError(text="error", code="code"))
    assert v.__iter__().__next__() == v.value
    assert v.error == v.__iter__().__next__()


# Generated at 2022-06-12 15:30:16.845434
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=15)
    assert list(vr) == [15, None]
    vr = ValidationResult(error=ValidationError())
    assert list(vr) == [None, ValidationError()]


# Generated at 2022-06-12 15:30:19.557901
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(error=ValidationError(text='error!'))
    assert next(iter(vr)) == None
    assert next(iter(vr)) != None
test_ValidationResult___iter__()


# Generated at 2022-06-12 15:30:22.656364
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(error='test')
    it = vr.__iter__()
    assert it.__next__() == None
    assert it.__next__() == 'test'


# Generated at 2022-06-12 15:30:23.073932
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pass

# Generated at 2022-06-12 15:30:36.744233
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    import sys
    import types
    import _io
    # Void: returns type 'NoneType'
    assert type(ValidationResult().__iter__()) is types.NoneType
    # Void: returns type 'NoneType'
    assert type(ValidationResult(error=ValidationError()).__iter__()) is types.NoneType
    # Void: returns type 'NoneType'
    assert type(ValidationResult(value=0).__iter__()) is types.NoneType
    # Void: returns type 'NoneType'
    assert type(ValidationResult(error=ValidationError(), value=0).__iter__()) is types.NoneType
    # Void: returns type 'NoneType'
    assert type(ValidationResult(error=[], value=[]).__iter__()) is types.NoneType



# Generated at 2022-06-12 15:30:46.830491
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text='12', code="custom", key=None, position=None)
    message_2 = Message(text='12', code="custom", key=None, position=None)
    message_3 = Message(text='12', code="custom", key=None, position=None)
    message_4 = Message(text='12', code="custom", key=None, position=None)
    message_5 = Message(text='12', code="custom", key=None, position=None)
    message_6 = Message(text='12', code="custom", key=None, position=None)
    message_7 = Message(text='12', code="custom", key=None, position=None)
    message_8 = Message(text='12', code="custom", key=None, position=None)

# Generated at 2022-06-12 15:30:51.644860
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult(value=1)
    assert next(iter(a)) == 1
    assert next(iter(a)) == None
    b = ValidationResult(error=ValidationError(text="c", key="d"))
    assert next(iter(b)) == None
    assert next(iter(b)) == ValidationError(text="c", key="d")

# Generated at 2022-06-12 15:30:55.831881
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=True)
    print(result)
    print(result.value)
    print(result.error)
    result1 = ValidationResult(error=ValidationError(text="error message"))
    print(result1)
    print(result1.value)
    print(result1.error)


# Generated at 2022-06-12 15:31:05.970129
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error_dict = dict(key1="value1", key2="value2")
    error_messages = [
        Message(text="error1", code="code1", key="key1"),
        Message(text="error2", code="code2", key="key2"),
    ]
    error1 = BaseError(messages=error_messages)
    error2 = BaseError(messages=error_messages)

    assert(error1 == error2)

    error_dict.pop("key1")
    error_messages.pop(0)
    error2 = BaseError(messages=error_messages)

    assert(error1 != error2)

    error_dict = dict(key1="value1", key2="value2", key3=dict())

# Generated at 2022-06-12 15:31:14.350957
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    from sys import platform
    from os import getcwd
    from os.path import join
    from json import load
    from yaml import load as yload
    from arrow import utcnow
    assert Message(text='May not have more than 100 characters', code='max_length', key='username', start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=34, char_index=34)) == Message(text='May not have more than 100 characters', code='max_length', key='username', start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=34, char_index=34))

# Generated at 2022-06-12 15:31:18.089391
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    c = Position(3,1,2)
    c1 = Position(3,1,2)
    assert c == c1
    assert c == c
    assert c1 == c
    assert c1 == c1



# Generated at 2022-06-12 15:31:25.137945
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    theArg = ""
    theArg = theArg.__repr__()
    theArg = dict(theArg)
    theArg = ValidationError(dict(theArg))
    assert theArg.__repr__() == "ValidationError({'text': 'May not have more than 100 characters'})"
    theArg = ""
    theArg = theArg.__repr__()
    theArg = dict(theArg)
    theArg = ValidationError(dict(theArg))
    assert theArg.__repr__() == "ValidationError({'text': 'May not have more than 100 characters'})"


# Generated at 2022-06-12 15:31:29.965050
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    verificationError = ValidationError(messages=[Message(text= "verificationError")])
    result = ValidationResult(value= {}, error=verificationError)
    assert next(iter(result)) ==  {}
    assert next(iter(result)) ==  verificationError


# Generated at 2022-06-12 15:31:34.011670
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text = 'The length of this string is too long')
    message2 = Message(text = 'The length of this string is too long')

    result = message1 == message2
    assert result == True


# Generated at 2022-06-12 15:31:41.019923
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = 1
    error = ValidationError()
    result = ValidationResult(value=value)
    assert list(result) == [value, None]
    result = ValidationResult(error=error)
    assert list(result) == [None, error]
    assert bool(result) == False

# Generated at 2022-06-12 15:31:44.713801
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = 'value'
    error = 'error'
    validation_result = ValidationResult(value=value, error=error)
    assert next(iter(validation_result)) == value
    assert next(iter(validation_result)) == error


# Generated at 2022-06-12 15:31:48.490925
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test that two positions with the same data are equal
    assert Position(1, 2, 3) == Position(1, 2, 3)

    # Test that two positions with different data are not equal
    assert Position(1, 2, 3) != Position(3, 2, 1)


# Generated at 2022-06-12 15:31:53.790046
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Test instance is initialized with the single error message.
    error = BaseError(text="message_1", code="code_1")
    assert repr(error) == 'BaseError(text="message_1", code="code_1")'
    # Test instance is initialized with multiple error messages.
    error = BaseError(messages=[Message(text="message_1", code="code_1")])
    assert repr(error) == "BaseError([Message(text='message_1', code='code_1')])"


# Generated at 2022-06-12 15:32:01.451938
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert (
        repr(
            BaseError(
                text="May not have more than 100 characters",
                code="max_length",
                key="username",
            )
        )
        == "BaseError(text='May not have more than 100 characters', code='max_length')"
    )
    assert (
        repr(BaseError(text="May not have more than 100 characters", code="max_length"))
        == "BaseError(text='May not have more than 100 characters', code='max_length')"
    )



# Generated at 2022-06-12 15:32:06.884196
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    r = ValidationResult(value=None, error=None)
    assert next(iter(r)) is r.value

    r = ValidationResult(value=None, error=ValidationError())
    assert next(iter(r)) is r.value

    r = ValidationResult(value=123, error=None)
    assert next(iter(r)) is r.value

    r = ValidationResult(value=123, error=ValidationError())
    assert next(iter(r)) is r.value


# Generated at 2022-06-12 15:32:09.080132
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value = "value")
    assert (list(vr)==["value", None])
    vr = ValidationResult(error = "error")
    assert (list(vr)==[None, "error"])

# Generated at 2022-06-12 15:32:12.175808
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    text = 'message'
    error1 = BaseError(text=text)
    error2 = BaseError(text=text)
    assert error1 == error2


# Generated at 2022-06-12 15:32:14.412719
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    def _test():
        b = BaseError()
    try:
        _test()
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-12 15:32:21.872875
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(ValidationError(text="x", code="custom")) == "ValidationError(text='x', code='custom')"
    assert (
        repr(
            ValidationError(
                messages=[
                    Message(text="x", code="custom", key="name"),
                    Message(text="y", code="custom", key="age"),
                ]
            )
        )
        == "ValidationError([Message(text='x', code='custom', index=['name']), Message(text='y', code='custom', index=['age'])])"
    )

# Generated at 2022-06-12 15:32:39.297339
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    msg111 = Message(text='text111', code='code111', index=['idx111', 'idx112'] , start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    msg112 = Message(text='text112', code='code112', index=['idx111', 'idx112'] , start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))

    be111 = BaseError(messages=[msg111])
    be112 = BaseError(messages=[msg111])
    be113 = BaseError(messages=[msg112])

    assert be111 == be111
    assert be111 == be112
    assert be111 != be113


# Generated at 2022-06-12 15:32:48.553652
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    e = BaseError(text = 'test')
    assert repr(e) == "BaseError(text='test', code=None)"
    e = BaseError(text='test', code='test_code')
    assert repr(e) == "BaseError(text='test', code='test_code')"
    e = BaseError(text='test', key='test_key')
    assert repr(e) == "BaseError(text='test', code=None, index='test_key')"
    e = BaseError(text='test', key=1)
    assert repr(e) == "BaseError(text='test', code=None, index=1)"
    e = BaseError(text='test', position=Position(1,2,3))

# Generated at 2022-06-12 15:32:57.832572
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    test_ValidationResult = ValidationResult()
    assert iter(test_ValidationResult) != iter(test_ValidationResult)
    test_ValidationResult = ValidationResult(value=123)
    assert iter(test_ValidationResult) != iter(test_ValidationResult)
    test_ValidationResult = ValidationResult(error=ValidationError(text='error'))
    assert iter(test_ValidationResult) != iter(test_ValidationResult)
    test_ValidationResult = ValidationResult(value=123, error=ValidationError(text='error'))
    assert iter(test_ValidationResult) != iter(test_ValidationResult)


# Generated at 2022-06-12 15:33:01.537958
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    f1 = ValidationResult(value=1)
    assert list(f1) == [1, None]
    f2 = ValidationResult(error=ValidationError())
    assert list(f2) == [None, ValidationError()]


# Generated at 2022-06-12 15:33:08.262020
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    v1 = BaseError()
    assert repr(v1) == "<BaseError({})>"
    v2 = BaseError(key='test_key')
    assert repr(v2) == "<BaseError(text=None, code=None, key='test_key')>"
    v3 = BaseError(text='test_text', code='test_code', key='test_key')
    assert repr(v3) == "<BaseError(text='test_text', code='test_code', key='test_key')>"
    v4 = BaseError(messages=['test_text'])
    assert repr(v4) == "<BaseError(text=None, code=None, key=None, messages=['test_text'])>"

# Generated at 2022-06-12 15:33:12.511094
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=42)
    assert list(result) == [42, None]
    result = ValidationResult(error=ValidationError())
    assert list(result) == [None, ValidationError()]


# Generated at 2022-06-12 15:33:19.269561
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value=123)
    assert tuple(v) == (123, None)
    assert next(iter(v)) == 123
    assert next(v) == None
    v = ValidationResult(error=ValidationError(text="foo"))
    assert tuple(v) == (None, ValidationError(text="foo"))
    assert next(iter(v)) == None
    assert next(v) == ValidationError(text="foo")


# Generated at 2022-06-12 15:33:26.675314
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    try:
        # Constructor
        vr = ValidationResult(value = 1, error = None)
        it = vr.__iter__()
        assert (it.__next__() == 1)
        assert (it.__next__() is None)
        raise Exception("impossible")
    except StopIteration:
        pass
    try:
        # Constructor
        vr = ValidationResult(value = None, error = "error")
        it = vr.__iter__()
        assert (it.__next__() is None)
        assert (it.__next__() == "error")
        raise Exception("impossible")
    except StopIteration:
        pass
    return


# Generated at 2022-06-12 15:33:27.459532
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    pass


# Generated at 2022-06-12 15:33:34.536906
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult()
    vr1, vr2 = vr
    assert vr1 is None and vr2 is None
    with pytest.raises(ValueError):
        vr1, vr2, vr3 = vr
    with pytest.raises(ValueError):
        vr1, vr2, vr3, vr4 = vr

    vr = ValidationResult(value=1)
    vr1, vr2 = vr
    assert vr1 == 1 and vr2 is None
    with pytest.raises(ValueError):
        vr1, vr2, vr3 = vr
    with pytest.raises(ValueError):
        vr1, vr2, vr3, vr4 = vr

    vr = Val

# Generated at 2022-06-12 15:33:51.500143
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(1,2)) == [1,2]


# Generated at 2022-06-12 15:33:58.436291
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    import typesystem
    # A string containing JSON data
    json_data = """{
        "foo": "this is a foo",
        "bar": [
            {
                "baz": "this should be an integer"
            },
            {
                "baz": 123
            }
        ]
    }"""

    # Create a schema to validate the data
    class FooSchema(typesystem.Schema):
        foo = typesystem.String()
        bar = typesystem.Array(items={'baz': typesystem.Integer()})

    # Validate the data
    FooSchema.validate(json_data)
    # ValueError is raised in case the data is not valid

# Generated at 2022-06-12 15:34:06.999018
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult(value=1)
    assert 1 == next(iter(a))
    assert None == next(iter(a))
    b = ValidationResult(error=ValidationError(text='Error'))
    assert None == next(iter(b))
    assert ValidationError(text='Error') == next(iter(b))
    c = ValidationResult(value=1, error=ValidationError(text='Error'))
    assert 1 == next(iter(c))
    assert ValidationError(text='Error') == next(iter(c))
    d = ValidationResult(value=1)
    assert 1 == next(iter(d))
    assert None == next(iter(d))



# Generated at 2022-06-12 15:34:10.986611
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=3)
    assert list(iter(vr)) == [3, None]
    vr = ValidationResult(error=ValidationError())
    assert list(iter(vr)) == [None, ValidationError()]
    vr = ValidationResult(value=4, error=ValidationError())
    assert list(iter(vr)) == [4, ValidationError()]
    


# Generated at 2022-06-12 15:34:17.219740
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem import ValidationResult, ValidationError

    res = ValidationResult(value=1)
    assert list(res) == [1, None]
    assert bool(res)
    res = ValidationResult(value=0)
    assert list(res) == [0, None]
    assert bool(res)

    res = ValidationResult(error=ValidationError())
    assert list(res) == [None, ValidationError()]
    assert not bool(res)

# Generated at 2022-06-12 15:34:24.101334
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    def _assert(value, error, *, expect: typing.Sequence[typing.Any], no: int) -> None:
        result = ValidationResult(value=value, error=error)
        actual = tuple(result)
        msg = "Fail test case no " + str(no) + "\n"
        msg += "Expect: " + str(expect) + "\n"
        msg += "Actual: " + str(actual)
        assert actual == expect, msg

    _assert(1, None, expect=(1, None), no=1)
    _assert(None, ValidationError(text="", code="", key=None), expect=(None, ValidationError(text="", code="", key=None)), no=2)

# Generated at 2022-06-12 15:34:26.822281
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value="test").__iter__()
    assert value == "test"
    assert error is None
    value, error = ValidationResult(error=ValidationError()).__iter__()
    assert value is None
    assert isinstance(error, ValidationError)


# Generated at 2022-06-12 15:34:31.607254
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
  """
  Test the iterability of ValidationResult.
  """
  res1 = ValidationResult(error=ValidationError(text="Something went wrong"))

  # Check that we can iterate over the object res1.
  assert [elem for elem in res1] == [None, ValidationError(text="Something went wrong")]

  res2 = ValidationResult(
      value="This value has been validated and it is correct"
  )

  # Check that we can iterate over the object res2.
  assert [elem for elem in res2] == [
      "This value has been validated and it is correct",
      None,
  ]


# Generated at 2022-06-12 15:34:33.703009
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value = {'Defines': 'A '})
    vr_iter = iter(vr)
    assert next(vr_iter) == {'Defines': 'A '}
    assert next(vr_iter) == None
    assert True
    return True


# Generated at 2022-06-12 15:34:36.368477
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert tuple(ValidationResult(value=1)) == (1, None)
    assert tuple(ValidationResult(error=1)) == (None, 1)



# Generated at 2022-06-12 15:35:02.110403
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    val = "abcd"
    vres = ValidationResult(value=val)
    vresIter = iter(vres)
    assert next(vresIter) is val
    assert next(vresIter) is None

    err = ValidationError(text="Error text")
    vres = ValidationResult(error=err)
    vresIter = iter(vres)
    assert next(vresIter) is None
    assert next(vresIter) is err


# Generated at 2022-06-12 15:35:10.940422
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    Method __iter__ for class ValidationResult
    """
    vr = ValidationResult(value=1)
    vr_iter = iter(vr)
    assert next(vr_iter) == 1
    assert next(vr_iter) is None
    with pytest.raises(StopIteration):
        next(vr_iter)

    vr = ValidationResult(error=ValidationError(text="test error"))
    vr_iter = iter(vr)
    assert next(vr_iter) is None
    assert isinstance(next(vr_iter), ValidationError)
    with pytest.raises(StopIteration):
        next(vr_iter)



# Generated at 2022-06-12 15:35:20.283252
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    _bool = False
    _bytes = b"bytes"
    _class_instance = Exception()
    _complex = 1 + 2j
    _dict = {}
    _float = 3.14
    _frozenset = frozenset({1, 2, 3})
    _int = 123
    _list = [1, 2, 3]
    _None = None
    _NotImplemented = NotImplemented
    _range = range(7)
    _set = {3, 2, 1}
    _slice = slice(3, 6, 1)
    _str = "str"
    _tuple = (1, 2, 3)
    _ValidationResult = ValidationResult(error=NotImplemented)
    _ValueError = ValueError()

    obj = _ValidationResult

    # Code to execute if the tests

# Generated at 2022-06-12 15:35:24.125459
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError(text="error"))) == [None, ValidationError(text="error")]


# Generated at 2022-06-12 15:35:28.313991
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result1 = ValidationResult(value=1)
    assert list(result1) == [1, None]
    result2 = ValidationResult(error=ValidationError())
    assert list(result2) == [None, ValidationError()]


# Generated at 2022-06-12 15:35:31.261599
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value=123).__iter__()
    assert value == 123 and error is None

    error, value = ValidationResult(error=ValidationError()).__iter__()
    assert value is None and error is not None


# Generated at 2022-06-12 15:35:32.794967
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1, error=None)
    assert list(result) == [1, None]



# Generated at 2022-06-12 15:35:38.056620
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    d1 = {"key1": 1, "key2": 2}
    d2 = {"key3": 3, "key4": 4}
    v1 = ValidationResult(value=d1)
    v2 = ValidationResult(error=ValidationError(messages=d2))
    # 当v1.error is None，即validate success时，iter才会有效
    isinstance(v1, collections.abc.Iterable)  # True
    isinstance(v2, collections.abc.Iterable)  # True
    for x in v1:
        print(x)  # {'key1': 1, 'key2': 2}
    for y in v2:
        print(y)  # None



# Generated at 2022-06-12 15:35:41.814071
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=10)) == [10, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]


# Generated at 2022-06-12 15:35:43.736458
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = 1
    error = ValidationError(text="error")
    assert sum(ValidationResult(value=value)) == 2
    assert sum(ValidationResult(error=error)) == 0

# Generated at 2022-06-12 15:36:23.165296
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    rtn = list(iter(ValidationResult(value="hello")))
    assert len(rtn) == 2
    assert rtn[0] == "hello"
    assert rtn[1] == None


# Generated at 2022-06-12 15:36:24.310944
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]

# Generated at 2022-06-12 15:36:28.008438
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert ValidationResult() == (None, None)
    assert ValidationResult(value=123) == (123, None)
    assert ValidationResult(error=ValidationError()) == (None, ValidationError())



# Generated at 2022-06-12 15:36:30.077662
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=5)
    assert list(result) == [5, None]
    result = ValidationResult(value=5)
    assert list(result) == [5, None]

# Generated at 2022-06-12 15:36:31.641918
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    ret = ValidationResult(value=2, error=ValidationError())
    ret1 = list(ret)


# Generated at 2022-06-12 15:36:32.241140
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    ValidationResult(value=1)



# Generated at 2022-06-12 15:36:33.768411
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Validate
    ValidationResult(value='value')

    # Invalidate
    with pytest.raises(AssertionError):
        ValidationResult(value='value', error='error')

# Generated at 2022-06-12 15:36:37.620241
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v, e = ValidationResult(value = 'value')
    assert v == 'value'
    assert e == None
    v, e = ValidationResult(value = None, error = 'error')
    assert v == None
    assert e == 'error'

# Generated at 2022-06-12 15:36:41.089377
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error="error")
    assert list(result) == [None, "error"]


# Generated at 2022-06-12 15:36:45.034641
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(value=1)
    assert next(iter(validation_result)) == 1
    assert next(iter(validation_result)) is None
    assert next(iter(validation_result)) is None