

# Generated at 2022-06-12 15:28:53.396883
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert next(iter(result)) == 1
    assert next(iter(result)) == None


# Generated at 2022-06-12 15:29:01.052621
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text='t1', code='c1', key='k1', index=['i1', 'i2'], start_position=Position(1, 2, 3),
                 end_position=Position(4, 5, 6))
    m2 = Message(text='t2', code='c2', key='k2', index=['i3', 'i4'], start_position=Position(2, 3, 4),
                 end_position=Position(5, 6, 7))
    m3 = Message(text='t1', code='c1', key='k1', index=['i1', 'i2'], start_position=Position(1, 2, 3),
                 end_position=Position(4, 5, 6))

# Generated at 2022-06-12 15:29:04.812495
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value = 1)
    vr_result = []
    for v in vr:
        vr_result.append(v)
    assert vr_result == [1, None]

    vr = ValidationResult(error = "error")
    vr_result = []
    for v in vr:
        vr_result.append(v)
    assert vr_result == [None, "error"]


# Unit tests for method __repr__ of class ValidationResult

# Generated at 2022-06-12 15:29:12.556723
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Initializing two Position objects at the same location
    p1 = Position(line_no=3, column_no=4, char_index=5)
    p2 = Position(line_no=3, column_no=4, char_index=5)
    assert(p1 == p2)
    
    # Initializing two Position objects at different locations
    p1 = Position(line_no=3, column_no=4, char_index=5)
    p2 = Position(line_no=1, column_no=2, char_index=3)
    assert(p1 != p2)
    

# Generated at 2022-06-12 15:29:18.441569
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    x1 = "x1"
    x2 = "x2"
    val_res = ValidationResult(value=x1, error=x2)
    x1_2 = tuple(val_res)
    assert x1 == x1_2[0]
    assert x2 == x1_2[1]



# Generated at 2022-06-12 15:29:22.380204
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = "value"
    error = ValidationError()
    result1 = ValidationResult(value=value, error=None)
    result2 = ValidationResult(value=None, error=error)

    assert value in list(result1)
    assert error in list(result2)

# Generated at 2022-06-12 15:29:28.039809
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    code = "custom"
    key = "name"
    text = "some error text"
    start_position = Position(1, 1, 1)
    end_position = Position(1, 1, 1)
    message = Message(text=text, code=code, key=key, start_position=start_position, end_position=end_position)
    error = BaseError(messages=[message])
    message_copy = Message(text=text, code=code, key=key, start_position=start_position, end_position=end_position)
    error_copy = BaseError(messages=[message_copy])
    assert error == error_copy


# Generated at 2022-06-12 15:29:31.420677
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    def __iter__(self) -> typing.Iterator:
        yield self.value
        yield self.error
    """
    testobj = ValidationResult(value=123)
    try:
        first = testobj[0]
    except StopIteration:
        first = None
    assert first == 123
    try:
        second = testobj[1]
    except StopIteration:
        second = None
    assert second == None


# Generated at 2022-06-12 15:29:37.192389
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(messages=[Message(text="1", code="2")]) == BaseError(messages=[Message(text="1", code="2")])
    assert BaseError(messages=[Message(text="1", code="2")]) != BaseError(messages=[Message(text="2", code="2")])


# Generated at 2022-06-12 15:29:44.233447
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    def f(x: typing.Any) -> typing.Iterable:
        v, e = ValidationResult(value=x)
        return (v, e)

    assert f(123) == (123, None)
    assert f('123') == ('123', None)
    assert f([1,2,3]) == ([1,2,3], None)
    assert f(True) == (True, None)
    assert f(False) == (False, None)
    assert f(None) == (None, None)
    assert f(ValidationError()) == (None, ValidationError())



# Generated at 2022-06-12 15:29:50.958211
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_1 = ValidationResult(value=1)
    assert isinstance(iter(validation_result_1), typing.Iterator)
    assert next(iter(validation_result_1)) == 1


# Generated at 2022-06-12 15:29:53.392052
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value={})) == [{}, None]
    assert list(ValidationResult(error={})) == [None, {}]



# Generated at 2022-06-12 15:29:54.297178
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    pass


# Generated at 2022-06-12 15:29:58.613440
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p1 = Position(1, 1, 1)
    p2 = Position(1, 1, 1)
    assert p1 == p2

    p2 = Position(2, 1, 1)
    assert not(p1 == p2)

    p2 = Position(1, 2, 1)
    assert not(p1 == p2)

    p2 = Position(1, 1, 2)
    assert not(p1 == p2)


# Generated at 2022-06-12 15:30:05.631502
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = "value"
    error = ValidationError(text="error")
    #value none
    vr = ValidationResult()
    assert sum(list(map(bool,list(vr))))==0
    vr = ValidationResult(error = error)
    assert sum(list(map(bool,list(vr))))==1
    vr = ValidationResult(value=value)
    assert sum(list(map(bool,list(vr))))==1

# Generated at 2022-06-12 15:30:14.448777
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text = "hello", code = "123", key = "a")
    m2 = Message(text = "hello", code = "123", key = "a")
    assert m1 == m2
    m1.code = "456"
    assert m1 != m2
    m1.code = "123"
    assert m1 == m2
    m1.text = "xyz"
    assert m1 != m2
    m1.text = "hello"
    assert m1 == m2
    m1.key = "b"
    assert m1 != m2
    m1.key = "a"
    assert m1 == m2


# Generated at 2022-06-12 15:30:18.623577
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # When __iter__ of a ValidationResult instance is called, test whether the iterated value is as expected.
    src_ = ValidationResult(value = '1')
    iter_ = src_.__iter__()
    assert iter_.__next__() == '1'
    assert iter_.__next__() is None


# Generated at 2022-06-12 15:30:23.296278
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError() == BaseError()
    assert not BaseError() != BaseError()
    assert not BaseError() == BaseError(text='Text')
    assert not BaseError() == BaseError(code='Code')
    assert not BaseError() == BaseError(key='Key')
    assert not BaseError() == BaseError(messages=[Message()])
    assert BaseError(messages=[Message()]) == BaseError(messages=[Message()])
    assert not BaseError(messages=[Message()]) == BaseError(messages=[Message(text='Text')])
    assert not BaseError(messages=[Message(text='Text')]) == BaseError(messages=[Message(code='Code')])
    assert not BaseError(messages=[Message(code='Code')]) == BaseError(messages=[Message(key='Key')])


# Generated at 2022-06-12 15:30:31.201938
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    def equals(v, e):
        test_result = ValidationResult(value=v, error=e)
        for i, a in enumerate([v, e]):
            b = next(iter(test_result))
            assert a == b
        try:
            next(iter(test_result))
            assert False, 'Iteration finished before expected'
        except StopIteration as e:
            assert str(e) == ''

    equals("value", None)
    equals(None, ValidationError(text="error"))

# Generated at 2022-06-12 15:30:39.729939
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=0)
    value, error = result
    assert value == 0
    assert error is None
    assert list(result) == [0, None]

    result = ValidationResult(error=ValidationError(messages=[Message(text="error")]))
    value, error = result
    assert value is None
    assert error == ValidationError(messages=[Message(text="error")])
    assert list(result) == [None, ValidationError(messages=[Message(text="error")])]

    # Fails because ValidationResult(value).error is None
    try:
        value, error = ValidationResult(value=0)
        assert False
    except TypeError:
        pass

    # Fails because ValidationResult(error).value is None

# Generated at 2022-06-12 15:30:51.256987
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    start_position = Position(line_no=1, column_no=1, char_index=0)
    end_position = Position(line_no=1, column_no=1, char_index=0)
    message = Message(
        text='testValidationError__eq__',
        code='testValidationError__eq__',
        key='testValidationError__eq__',
        start_position=start_position,
        end_position=end_position
    )
    error = ValidationError(messages=[message])
    assert error == error


# Generated at 2022-06-12 15:30:57.801249
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Check iterating over ValidationResult with no error
    validation_result = ValidationResult(value=10)
    value, error = validation_result
    assert value == 10
    assert error is None
    assert next((i for i in validation_result), None) == 10

    # Check iterating over ValidationResult with an error
    validation_result = ValidationResult(error="Error")
    value, error = validation_result
    assert value is None
    assert error == "Error"
    assert next((i for i in validation_result), None) == "Error"



# Generated at 2022-06-12 15:31:00.833728
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult(value='value')
    lst = []
    for i in a:
        lst.append(i)
    if (lst == ['value', None]):
        print("True")
    else:
        print("False")

test_ValidationResult___iter__()

# Generated at 2022-06-12 15:31:02.930828
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    ValidationResult(error=ValidationError()).__iter__()


# Generated at 2022-06-12 15:31:04.704666
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert [v for v in ValidationResult(value=1)] == [1, None]
    assert [v for v in ValidationResult(error=1)] == [None, 1]



# Generated at 2022-06-12 15:31:07.352600
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    res = ValidationResult(value="value")
    value, error = res
    assert value == "value"
    assert error is None


# Generated at 2022-06-12 15:31:10.285288
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Create two different BaseError instances
    error1 = BaseError(text='The value is not a number')
    error2 = BaseError(text='The value is not an integer')
    assert error1 != error2


# Generated at 2022-06-12 15:31:19.485985
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    """
    if isinstance(other, ValidationError):
        return self._messages == other._messages

    if isinstance(other, ParseError):
        return self._messages == other._messages

    return False
    """
    # Define two sample _messages
    a = Message(text="message1", code="code1", key="key1", position=Position(1,2,3))
    b = Message(text="message1", code="code1", key="key1", position=Position(1,2,3))
    c = Message(text="message2", code="code2", key="key2", position=Position(4,5,6))
    d = Message(text="message1", code="code1", key="key1", index=["index1"], position=Position(1,2,3))
   

# Generated at 2022-06-12 15:31:22.112398
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    """
    Error messages are identified by the parent object, index, code and text.
    """
    message = Message(text="User name may not be empty", code="required", index=["name"])
    message2 = Message(text="User name may not be empty", code="required", index=["name"])
    assert message == message2



# Generated at 2022-06-12 15:31:27.700119
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    first = Position(line_no=10, column_no=10, char_index=10)
    second = Position(line_no=10, column_no=10, char_index=10)
    assert first == second


# Generated at 2022-06-12 15:31:36.675294
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test if two instances are the same
    temp = BaseError(text="error", index=[0])
    temp2 = BaseError(text="error", index=[0])
    assert temp == temp2

    # Test if two instances are not the same
    temp3 = BaseError(text="error3", index=[0])
    assert temp != temp3


# Generated at 2022-06-12 15:31:41.372020
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    messages = [Message(text="text0", code="code0", key="key0"), Message(text="text1", code="code1", key="key1")]
    e1 = BaseError(messages=messages)
    e2 = BaseError(messages=messages)
    assert e1 == e2
    messages = [Message(text="text0", code="code0", key="key1"), Message(text="text1", code="code1", key="key0")]
    e3 = BaseError(messages=messages)
    assert not(e1 == e3)
    messages = [Message(text="text0", code="code0", key="key0")]
    e4 = BaseError(messages=messages)
    assert not(e1 == e4)


# Generated at 2022-06-12 15:31:43.411949
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]



# Generated at 2022-06-12 15:31:45.956161
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=42)
    value, error = result
    assert (value == 42)
    assert (error is None)



# Generated at 2022-06-12 15:31:54.316852
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with a ValidationError with a single error message
    error = ValidationError(text=('May not have more than 100 characters',
                                  ), code=('invalid_provider',
                                           ), key=('id',
                                                  ), position=('id', 'name',
                                                               ))
    expected_result = True
    assert (error == error) == expected_result
    assert (error == error) == expected_result
    assert (error == error) == expected_result
    # Test with a ValidationError with multiple error messages

# Generated at 2022-06-12 15:32:04.827409
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    def dict_equal(d):
        assert isinstance(d, dict)
        if not d:
            return 'empty dict'
        else:
            return '{}'.format(', '.join(['{!r}: {!r}'.format(k, dict_equal(v)) for k, v in d.items()]))

    def get_msg(d):
        assert isinstance(d, dict)
        if not d:
            return 'no message'
        else:
            return '{}'.format(', '.join(['{!r}: {}'.format(k, get_msg(v)) for k, v in d.items()]))


    data = {'name': 'bob', 'age': 'unlikely'}

# Generated at 2022-06-12 15:32:08.158818
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    f = ValidationResult(value='test')
    assert next(f.__iter__()) == f.value
    assert next(f.__iter__()) == f.error

    g = ValidationResult(error='test')
    assert next(g.__iter__()) == g.value
    assert next(g.__iter__()) == g.error



# Generated at 2022-06-12 15:32:13.127406
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    Test case for method `__iter__` of class ValidationResult
    """
    ValidationResult_1 = ValidationResult(error = ValidationError(text = "May not have more than 100 characters", code = "max_length"))
    ValidationResult_2 = ValidationResult(error = ValidationError(text = "May not have more than 100 characters", code = "max_length"))
    ValidationResult_3 = ValidationResult(value = "abc", error = None)
    result_1 = list(ValidationResult_1)
    result_2 = list(ValidationResult_2)
    result_3 = list(ValidationResult_3)
    assert result_1 == result_2
    assert result_1 != result_3



# Generated at 2022-06-12 15:32:16.887031
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    data = 3
    result = ValidationResult(value=data)
    assert result == (data, None)

    error = ValidationError(text='Error message')
    result = ValidationResult(error=error)
    assert result == (None, error)

# Generated at 2022-06-12 15:32:26.138830
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError()
    error1 = BaseError(messages = [
        Message(text = 'May not have more than 100 characters', code = 'max_length', key = 'username', position = Position(1, 0, 1), start_position = Position(1, 0, 1), end_position = Position(1, 0, 1)),
        Message(text = 'May not have more than 100 characters', code = 'max_length', key = 'email', position = Position(1, 0, 1), start_position = Position(1, 0, 1), end_position = Position(1, 0, 1)),
    ])
    error2 = BaseError()

# Generated at 2022-06-12 15:32:47.271250
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Test 1: Verify that the __iter__ method of the ValidationResult class returns a 
    #         tuple with two elements representing value and error when __call__ 
    #         method is called on the ValidationResult object

    # Arrange
    validResult = ValidationResult(value="Valid")
    invalidResult = ValidationResult(error="Invalid")

    # Assert
    assert isinstance(iter(validResult), tuple) and len(iter(validResult)) == 2
    assert isinstance(iter(invalidResult), tuple) and len(iter(invalidResult)) == 2


# Generated at 2022-06-12 15:32:52.422743
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    try:
        assert ((1,2).__iter__()  == (1,2))
    except AssertionError as error:
        print(error)
        print("Test 1 __iter__ of class ValidationResult failed")
        print("Reason - 1,2,3 is not the same object as 1,2,3")
        return
    else:
        print("Test 1 __iter__ of class ValidationResult passed")

# Generated at 2022-06-12 15:32:56.195902
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult(value=1)
    b = ValidationResult(error=ValidationError())
    for r in a :
        print(r)
    for r in b :
        print(r)


# Generated at 2022-06-12 15:32:59.063298
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert [1, 2] == list(ValidationResult(value=1))
    assert [None, 2] == list(ValidationResult(error=2))


# Generated at 2022-06-12 15:33:03.065157
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error="no")) == [None, "no"]
    assert list(ValidationResult(error=ValidationError(text="no"))) == [None, ValidationError(text="no")]


# Generated at 2022-06-12 15:33:06.067057
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    it = ValidationResult(value = 1)
    assert next(it) == 1
    it = ValidationResult(error = 1)
    assert next(it) == None
    assert next(it) == 1
    assert next(it) == None

# Generated at 2022-06-12 15:33:14.058844
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():

    vr = ValidationResult(value=1)

    assert next(iter(vr)) == 1
    assert next(iter(vr)) is None
    assert isinstance(next(iter(vr)), StopIteration)

    vr = ValidationResult(error=ValidationError(text="error message"))

    assert next(iter(vr)) is None
    assert isinstance(next(iter(vr)), ValidationError)
    assert next(iter(vr)).text == "error message"
    assert isinstance(next(iter(vr)), StopIteration)


# Generated at 2022-06-12 15:33:21.630737
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from schematics import Schema
    class model_class(Schema):
        pass
    class_instance = model_class()
    class_instance._meta = {}
    def validate(value):
        return value
    class_instance._meta['validate'] = validate
    ValidationResult_instance = ValidationResult(None, ValidationError(text="Text", code="code", key="key"))
    assert hasattr(ValidationResult_instance, '__iter__')
    assert isinstance(ValidationResult_instance.__iter__, collections.abc.Iterator)


# Generated at 2022-06-12 15:33:24.439278
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value = "123")
    assert iter(vr) == iter(["123", None])
    vr = ValidationResult(error = "error")
    assert iter(vr) == iter([None, "error"])

# Generated at 2022-06-12 15:33:26.142963
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    res = ValidationResult(value=1)
    lst = list(res)
    assert lst == [1, None]



# Generated at 2022-06-12 15:33:40.610523
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(iter(ValidationResult(value=8))) == [8, None]
    assert list(iter(ValidationResult(error=ValidationError(text="haha")))) == [None, ValidationError(text="haha")]


# Generated at 2022-06-12 15:33:42.946227
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert len(list(ValidationResult())) == 2
    assert list(ValidationResult(value='a')) == ['a', None]
    assert list(ValidationResult(error='a')) == [None, 'a']



# Generated at 2022-06-12 15:33:47.228729
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]

    result = ValidationResult(error=ValidationError(text='error'))
    assert list(result) == [None, ValidationError(text='error')]


# Generated at 2022-06-12 15:33:48.856526
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value="value")
    vr_iter = iter(vr)
    assert next(vr_iter) == "value"
    assert next(vr_iter) == None

# Generated at 2022-06-12 15:33:51.150037
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=10)
    assert list(result) == [10, None]


# Generated at 2022-06-12 15:33:53.603777
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = ValidationResult(value={'one': 1, 'two': 2}, error=None)
    assert len(list(value)) == 2
    # Unit test for method __bool__ of class ValidationResult

# Generated at 2022-06-12 15:34:01.856174
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value = 1)
    assert next(iter(v)) == 1
    assert next(iter(v)) == None
    assert next(iter(v)) == StopIteration

    v = ValidationResult(error = ValidationError(text = "some error here"))
    assert next(iter(v)) == None
    assert next(iter(v)) == ValidationError
    assert next(iter(v)) == StopIteration

    v = ValidationResult(value = 1, error = ValidationError(text = "some error here"))
    assert next(iter(v)) == 1
    assert next(iter(v)) == ValidationError
    assert next(iter(v)) == StopIteration


# Generated at 2022-06-12 15:34:04.416544
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    vr1 = ValidationResult(error=1)
    print(list(vr), list(vr1))
    return True


# Generated at 2022-06-12 15:34:09.936830
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Given a ValidationResult with value
    result = ValidationResult(value="my_value")
    # When iterating through the ValidationResult
    # Then the iterator should contain value, malformed as well as is_empty
    assert next(result) == "my_value"
    assert next(result) is None

    try:
        next(result)
    except StopIteration:
        success = True

    # Assert
    assert success



# Generated at 2022-06-12 15:34:15.160104
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    val_result = ValidationResult()
    assert next(iter(val_result)) is None

    val_result = ValidationResult(value="value")
    assert next(iter(val_result)) == "value"

    val_result = ValidationResult(error="error")
    assert next(iter(val_result)) is None

