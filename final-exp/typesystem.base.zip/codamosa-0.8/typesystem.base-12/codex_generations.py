

# Generated at 2022-06-12 15:29:01.577594
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    """
    __eq__ is tested for class Position
    """
    assert Position(1, 1, 1) == Position(1, 1, 1)



# Generated at 2022-06-12 15:29:04.693745
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    mes1 = Message(text = "message 1")
    mes2 = Message(text = "message 2")
    mes3 = Message(text = "message 1")
    assert mes1 != mes2
    assert mes1 == mes3


# Generated at 2022-06-12 15:29:07.448436
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    >>> result = ValidationResult(value=100)
    >>> for item in result:
    ...     print(item)
    100
    None

    >>> result = ValidationResult(error=ValidationError(text="test"))
    >>> for item in result:
    ...     print(item)
    None
    ValidationError(text='test')
    """



# Generated at 2022-06-12 15:29:12.164319
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(error='err')
    assert next(iter(result)) is None
    assert next(iter(result)) == 'err'
    result = ValidationResult(value='val')
    assert next(iter(result)) == 'val'
    assert next(iter(result)) is None

# Generated at 2022-06-12 15:29:23.619718
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg0 = Message(
        text="Hello world",
        code="max_length",
        index=[2, "sub_obj", "sub_sub_obj", "sub_key"],
        start_position=Position(line_no=3, column_no=10, char_index=34),
        end_position=Position(line_no=3, column_no=20, char_index=44),
    )

    msg1 = Message(
        text="Hello world",
        code="max_length",
        index=[2, "sub_obj", "sub_sub_obj", "sub_key"],
        start_position=Position(line_no=3, column_no=10, char_index=34),
        end_position=Position(line_no=3, column_no=20, char_index=44),
    )

# Generated at 2022-06-12 15:29:26.975432
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    from operator import things
    from typesystem import Message
    import pytest
    from unittest.mock import mock

    # __eq__ tests
    err_msg1 = Message(text=things, key=mock, index=[2, 'red'])
    err_msg2 = err_msg1
    assert err_msg1 == err_msg2


# Generated at 2022-06-12 15:29:38.750562
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(error=ValidationError())
    assert hasattr(validation_result, '__iter__')
    validation_result_iterator = validation_result.__iter__()
    assert hasattr(validation_result_iterator, '__iter__')
    assert validation_result_iterator.__iter__() is validation_result_iterator
    assert hasattr(validation_result_iterator, '__next__')
    try:
        assert validation_result_iterator.__next__() is None
        assert validation_result_iterator.__next__() is not None
        assert False
    except StopIteration:
        pass
    try:
        assert validation_result_iterator.__next__() is None
        assert False
    except StopIteration:
        pass


# Generated at 2022-06-12 15:29:41.563943
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=5)
    assert sum(vr) == 5
    with pytest.raises(TypeError):
        assert sum(vr) == 5


# Generated at 2022-06-12 15:29:44.546485
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    errors = ValidationError(text='hello', code='world')
    assert len(errors) == 1
    success = ValidationResult(value=123)
    assert len(success) == 1
    for val in success:
        assert val == 123
    for val in errors:
        assert val == 'hello'

# Generated at 2022-06-12 15:29:49.991543
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult()
    assert len(list(result)) == 2
    v, e = result
    assert v is None
    assert e is None

    result = ValidationResult(value=123)
    assert len(list(result)) == 2
    v, e = result
    assert v == 123
    assert e is None

# Generated at 2022-06-12 15:29:59.544755
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code=None, key=None)
    message2 = Message(text="text", code=None, key=None)
    assert message1 == message2



# Generated at 2022-06-12 15:30:02.098711
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = "abc"
    result = ValidationResult(value=value)
    for item in result:
        assert item is value


# Generated at 2022-06-12 15:30:04.014451
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    with pytest.raises(TypeError):
        ValidationResult(value=1, error=2)


# Generated at 2022-06-12 15:30:07.785853
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position1 = Position(
        line_no=1,
        column_no=2,
        char_index=3
    )
    position2 = Position(
        line_no=1,
        column_no=2,
        char_index=3
    )
    assert position1 == position2



# Generated at 2022-06-12 15:30:16.668199
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Success
    v1 = ValidationResult(value = 1)
    v1_iter = iter(v1)
    assert next(v1_iter) == 1
    assert next(v1_iter) == None
    # Failure
    v2 = ValidationResult(error = ValidationError(messages = [Message(text = "test error")]))
    v2_iter = iter(v2)
    assert next(v2_iter) == None
    assert issubclass(type(next(v2_iter)), ValidationError)

# Generated at 2022-06-12 15:30:19.945026
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult(value=1)
    assert list(iter(a)) == [1, None]
    b = ValidationResult(error=ValidationError(text='Error message'))
    assert list(iter(b)) == [None, ValidationError(text='Error message')]


# Generated at 2022-06-12 15:30:23.084718
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():

    vr1 = ValidationResult(value=1)
    assert sum(vr1) == 1

    vr2 = ValidationResult(error=ValidationError())
    assert sum(vr2) == 0
    


# Generated at 2022-06-12 15:30:33.335983
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Test a success condition
    value = {'a': 1,  'b': [2, 3]}
    validation_result = ValidationResult(value=value)

    validation_result_to_iter = iter(validation_result)
    assert next(validation_result_to_iter) == value
    assert next(validation_result_to_iter) is None

    # Test a failure condition
    error = ParseError(text='Failed to parse input data')
    validation_result = ValidationResult(error=error)

    validation_result_to_iter = iter(validation_result)
    assert next(validation_result_to_iter) is None
    assert next(validation_result_to_iter) == error



# Generated at 2022-06-12 15:30:35.355175
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=2, error=None)
    assert list(vr) == [2, None]
    vr = ValidationResult(value=None, error=ValidationError())
    assert list(vr) == [None, ValidationError()]


# Generated at 2022-06-12 15:30:36.449723
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]


# Generated at 2022-06-12 15:30:52.492774
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Call method
    pos1 = Position(2, 3, 4)
    pos2 = Position(2, 3, 4)
    result = pos1.__eq__(pos2)

    # Compare result to expected value
    expected = True
    assert result == expected


# Generated at 2022-06-12 15:30:54.235598
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Sanity check
    my_validation_result = ValidationResult(value = 1)
    assert next(iter(my_validation_result)) == 1
    assert next(iter(my_validation_result)) == None
    # End sanity check

# Generated at 2022-06-12 15:30:57.800799
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value=10)
    assert iter(v) == [10, None]

    v = ValidationResult(error=ValidationError(text="error message", code="code"))
    assert iter(v) == [None, ValidationError(text="error message", code="code")]


# Generated at 2022-06-12 15:31:00.394221
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # 1. No exception is thrown
    result = ValidationResult(value=10)
    assert all([a == b for a, b in zip([10, None], result)])

# Generated at 2022-06-12 15:31:03.920738
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value = 3)) == [3, None]
    assert list(ValidationResult(error = ValidationError())) == [None, ValidationError()]

# Generated at 2022-06-12 15:31:08.584897
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="foo") == BaseError(text="foo")
    assert BaseError(text="foo", code="min_length") == BaseError(text="foo", code="min_length")
    assert BaseError(text="foo", key="a") == BaseError(text="foo", key="a")
    assert BaseError(text="foo", index=["a"]) == BaseError(text="foo", index=["a"])
    assert BaseError(text="foo", index=["a", "b"]) == BaseError(text="foo", index=["a", "b"])
    assert BaseError(text="foo", index=["a"]) != BaseError(text="foo", index=["a", "b"])

# Generated at 2022-06-12 15:31:19.058847
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test: Instantiate and Call With Positional Arguments
    m1 = Message(text="", code="", key="", index=[], position=None, start_position=None,
                 end_position=None)
    m2 = Message(text="", code="", key="", index=[], position=None, start_position=None,
                 end_position=None)
    assert m1 == m2
    # Test: Instantiate and Call With Named Arguments
    m1 = Message(text="", code="", key="", index=[])
    m2 = Message(text="", code="", key="", index=[])
    assert m1 == m2
    # Test: Instantiate and Call With Named Arguments, named arguments with None values are excluded

# Generated at 2022-06-12 15:31:23.545743
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    success = ValidationResult(value = 1)
    error = ValidationResult(error = 'error')
    it = iter(success)
    assert next(it) == 1
    assert next(it) is None
    it = iter(error)
    assert next(it) is None
    assert next(it) == 'error'



# Generated at 2022-06-12 15:31:35.736186
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test when the two BaseErrors have different number of messages.
    error1 = BaseError(text="some error", code="some code", key="some key")
    error2 = BaseError(messages=[Message(text="some error", code="some code", key="some key"), Message(text="some error", code="some code", key="some key")])
    assert error1 != error2
    # Test when the BaseError instance have different number of messages.
    error1 = error1 
    error2 = BaseError(messages=[Message(text="some error", code="some code", key="some key"), Message(text="some error", code="some code", key="some key")])
    assert error1 != error2
    # Test when the two BaseErrors have same number of messages but one of the messages differ.

# Generated at 2022-06-12 15:31:43.697493
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    obj1 = Message(text="foo", code=None, index=None, position=None, start_position=None, end_position=None)
    obj2 = Message(text="bar", code=None, index=None, position=None, start_position=None, end_position=None)
    assert not (obj1 == obj2)
    assert obj1 != obj2

    obj1 = Message(text="foo", code="bar", index=None, position=None, start_position=None, end_position=None)
    obj2 = Message(text="foo", code=None, index=None, position=None, start_position=None, end_position=None)
    assert not (obj1 == obj2)
    assert obj1 != obj2


# Generated at 2022-06-12 15:32:06.736441
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    class_name = ValidationResult.__name__
    # Test (value=None, error=None)
    value = None
    error = None
    input_object = ValidationResult(value=value, error=error)
    expected = (value, error)
    output = tuple(input_object)
    assert output == expected, f"{class_name}.__iter__({input_object!r}) != {expected!r}"
    # Test (value=1, error=None)
    value = 1
    error = None
    input_object = ValidationResult(value=value, error=error)
    expected = (value, error)
    output = tuple(input_object)
    assert output == expected, f"{class_name}.__iter__({input_object!r}) != {expected!r}"
    # Test (value=

# Generated at 2022-06-12 15:32:10.257706
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    __tracebackhide__ = True
    try:
        # Test passing
        assert not BaseError(text="text", code="code", key="key") == BaseError()
        assert BaseError(text="text", code="code", key="key") == BaseError(text="text", code="code", key="key")
    except AssertionError:
        vars = globals().copy()
        vars.update(locals())
        print("\n".join(traceback.format_exception(*sys.exc_info(), **vars)))
        raise


# Generated at 2022-06-12 15:32:16.390997
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    val_result = ValidationResult(value=42)
    value, error = val_result
    assert value == 42
    assert error is None
    val_result = ValidationResult(error=ValidationError(text='Incomprehensible'))
    value, error = val_result
    assert value is None
    assert error.messages() == [Message(text='Incomprehensible')]


# Generated at 2022-06-12 15:32:25.764867
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(
        start_position=Position(
            line_no=15,
            column_no=16,
            char_index=17,
        ),
        end_position=Position(
            line_no=18,
            column_no=19,
            char_index=20
        ),
        index=[1, 'a'],
        code='a',
        text='a',
    )

# Generated at 2022-06-12 15:32:28.822300
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert isinstance(ValidationResult(value=3), typing.Iterable)
    assert isinstance(ValidationResult(error=ValidationError(text="hello")), typing.Iterable)

# Generated at 2022-06-12 15:32:32.888596
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message = Message(text="text")
    error1 = BaseError(messages=[message])
    error2 = BaseError(messages=[message])
    assert error1 == error2


# Generated at 2022-06-12 15:32:37.389688
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    data = 10
    validation_result = ValidationResult(value=data)
    assert list(validation_result) == [data, None]
    validation_result = ValidationResult(error='Something went wrong')
    assert list(validation_result) == [None, 'Something went wrong']


# Generated at 2022-06-12 15:32:39.610798
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Call method __iter__
    value, error = ValidationResult(error=ValidationError(text="test")).__iter__()
    # Verify return value
    assert value == None
    assert error != None


# Generated at 2022-06-12 15:32:43.767443
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=3)) == [3, None]
    assert list(ValidationResult(error=ValidationError(text="error"))) == [None, ValidationError(text='error')]


# Generated at 2022-06-12 15:32:46.496526
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult(value=1)
    b, c = a
    assert b == 1 and c == None
    a = ValidationResult(error='error')
    b, c = a
    assert b == None and c == 'error'