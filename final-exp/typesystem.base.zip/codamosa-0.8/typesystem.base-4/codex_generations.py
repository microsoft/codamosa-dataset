

# Generated at 2022-06-12 15:29:00.989459
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    """
    __eq__(self, other: typing.Any) -> bool
    """

    # Message is a class:
    assert isinstance(Message, type)

    # Constructors:
    m1 = Message(text="text", code="code")
    m2 = Message(text="text", code="code")
    m3 = Message(text="text1", code="code")
    m4 = Message(text="text", code="code1")
    m5 = Message(text="text", code="code", key="key")
    m6 = Message(text="text", code="code", index=["index"])

    # __eq__ is a function:
    assert isinstance(Message.__eq__, type(lambda: None))

    # __eq__(self, other: typing.Any) -> bool
    # Returns whether `self

# Generated at 2022-06-12 15:29:06.718901
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert Message(text='message') == Message(text='message')
    assert Message(text='message') != Message(text='baz')

    assert BaseError() != BaseError(text='message')
    assert BaseError() != BaseError(text='message', code='foo')
    assert BaseError() != BaseError(text='message', code='foo', key='bar')
    assert BaseError() == BaseError()

    assert BaseError(text='message') != BaseError(text='message', code='foo')
    assert BaseError(text='message', code='foo') != BaseError(text='message', code='foo', key='bar')

# Generated at 2022-06-12 15:29:11.699380
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    print('-' * 20, 'test_Message___eq__', '-' * 20)
    msg1 = Message(text='String too long', code='max_length', key='user')
    msg2 = Message(text='String too long', code='max_length', key='user')
    assert msg1 == msg2


# Generated at 2022-06-12 15:29:18.857556
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value="foobar")
    
    assert list(result) == ["foobar", None]
    
    result = ValidationResult(error=ValidationError(
        messages=[Message(text="Foobar", code="foo_bar_code", key="foobarkey")]
    ))
    result = list(result)
    assert result[0] is None
    assert isinstance(result[1], ValidationError)



# Generated at 2022-06-12 15:29:22.068992
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=4, column_no=9, char_index=26) == Position(line_no=4, column_no=9, char_index=26)



# Generated at 2022-06-12 15:29:29.938872
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert Message('some message', code="some code") == \
           Message('some message', code="some code")
    assert not Message('some message', code="some code") == \
           Message('some message', code="other code")
    assert not Message('some message', code="some code") == \
           Message('other message', code="some code")
    assert Message('some message', code="some code") != \
           Message('some message', code="other code")
    assert Message('some message', code="some code") != \
           Message('other message', code="some code")


# Generated at 2022-06-12 15:29:33.541796
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text="You may not have more than 100 characters")
    assert str(error) == "You may not have more than 100 characters"



# Generated at 2022-06-12 15:29:43.619629
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert str(ValidationError(text="foo")) == "foo"
    assert str(ValidationError(messages=[Message(text="foo")])) == '{"": "foo"}'
    assert str(ValidationError(messages=[Message(text="foo", key="bar")])) == '{"bar": "foo"}'
    assert (
        str(ValidationError(messages=[Message(text="foo", index=["0", "bar"])]))
        == '{"0": {"bar": "foo"}}'
    )
    assert (
        str(ValidationError(messages=[Message(text="foo", index=["x", "y", "z"])]))
        == '{"x": {"y": {"z": "foo"}}}'
    )


# Generated at 2022-06-12 15:29:46.829901
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    val, err = ValidationResult(value=1)
    assert tuple(val) == (1, None)
    val, err = ValidationResult(error=ValidationError(text='miss', code='missing'))
    assert tuple(val) == (None, ValidationError(text='miss', code='missing'))

# Generated at 2022-06-12 15:29:56.232527
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1,2,3) == Position(1,2,3)
    assert not (Position(1,2,3) == 5)
    assert not (Position(1,2,3) == Position(1,3,3))
    assert not (Position(1,2,3) == Position(2,2,3))
    assert not (Position(1,2,3) == Position(1,2,4))
    assert Position(1,2,3) != Position(1,3,3)
    assert Position(1,2,3) != Position(2,2,3)
    assert Position(1,2,3) != Position(1,2,4)
    assert not (Position(1,2,3) != Position(1,2,3))

test_Position___eq__()


# Generated at 2022-06-12 15:30:18.624842
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Evaluating the equality of two validations errors
    # Two validation errors are equal if and only if
    # their messages lists are equal

    # Two base errors with equal fields
    e1_fields = {
        'text': 'This is an error',
        'code': 'ERROR_CODE'
    }
    e1_messages = [
        {
            'text': e1_fields['text'],
            'code': e1_fields['code']
        }
    ]
    e1 = BaseError(**e1_fields, messages=e1_messages)
    e2 = BaseError(**e1_fields, messages=e1_messages)

    assert e1 == e2
    assert e1.text == e2.text == e1_fields['text']

# Generated at 2022-06-12 15:30:20.846876
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    messages = [Message(text='hello')]
    baseErr = BaseError(messages = messages)
    baseErr1 = BaseError(messages = messages)
    assert baseErr == baseErr1


# Generated at 2022-06-12 15:30:26.711422
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position1 = Position(
        line_no=1,
        column_no=1,
        char_index=1,
    )
    position2 = Position(
        line_no=1,
        column_no=1,
        char_index=1,
    )
    position3 = Position(
        line_no=1,
        column_no=1,
        char_index=2,
    )
    assert position1 == position1
    assert position1 == position2
    assert position2 == position1
    assert position1 != position3
    assert position3 != position1


# Generated at 2022-06-12 15:30:31.972124
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # test a valid case
    # assert BaseError.BaseError.__eq__(BaseError({'text': 'You need to be signed in to do that.'})) == True
    assert BaseError.BaseError.__eq__(BaseError({'text': 'You need to be signed in to do that.'})) == True
    return


# Generated at 2022-06-12 15:30:33.275694
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text = "foo") == Message(text = "foo")


# Generated at 2022-06-12 15:30:35.949293
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(
        line_no=1, column_no=2, char_index=3
    )


# Generated at 2022-06-12 15:30:39.790682
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    err1 = BaseError(code='max_length', key='name', position=Position(1, 1, 1), text='May not have more than 100 characters')
    err2 = BaseError(code='max_length', key='name', position=Position(1, 2, 3), text='May not have more than 100 characters')
    assert err1 == err2

# Generated at 2022-06-12 15:30:50.212566
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error_1 = ValidationError(text="Hello world")
    error_2 = ValidationError(text="Hello world")
    assert error_1 == error_2
    error_1 = ValidationError(text="Hello world")
    error_2 = ValidationError(text="Hello world!")
    assert error_1 != error_2
    error_1 = ValidationError(text="Hello world")
    error_2 = ValidationError(text="Hello world", code="test")
    assert error_1 != error_2
    error_1 = ValidationError(text="Hello world", code="test")
    error_2 = ValidationError(text="Hello world", code="test2")
    assert error_1 != error_2
    error_1 = ValidationError(text="Hello world")

# Generated at 2022-06-12 15:30:53.917321
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text",code="code",key="key",position="position")
    message2 = Message(text="text",code="code",key="key",position="position")
    assert message1.__eq__(message2) == True


# Generated at 2022-06-12 15:31:01.660651
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert (
        Message(text="May not have more than 100 characters", code="max_length")
        == Message(text="May not have more than 100 characters", code="max_length")
    )
    assert (
        Message(text="May not have more than 100 characters", code="max_length")
        != Message(text="May not have more than 100 characters")
    )
    assert (
        Message(text="Invalid username", key="username")
        == Message(text="Invalid username", key="username")
    )
    assert (
        Message(text="Invalid username") == Message(text="Invalid username")
    )

# Generated at 2022-06-12 15:31:11.492642
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message(text='abc')
    msg2 = Message(text='abc')
    assert msg1 == msg2



# Generated at 2022-06-12 15:31:14.582219
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="1", code="A") == Message(text="1", code="A")
    assert Message(text="1", code="B") != Message(text="1", code="A")
    assert Message(text="2", code="A") != Message(text="1", code="A")



# Generated at 2022-06-12 15:31:22.204753
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text='test', code='test', index=[1,2,3], start_position=Position(1,2,3), end_position=Position(1,2,3))
    m2 = Message(text='test', code='test', index=[1,2,3], start_position=Position(1,2,3), end_position=Position(1,2,3))
    # m1.__eq__(m2)
    # m1 is equal to m2
    assert m1 == m2
    # m1.__eq__(m3)
    # m1 is not equal to m3
    m3 = Message(text='tst', code='test', index=[1,2,3], start_position=Position(1,2,3), end_position=Position(1,2,3))

# Generated at 2022-06-12 15:31:34.485443
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    try:
        assert BaseError(messages=[Message(text="test", code="test", key=["test"])]) == BaseError(messages=[Message(text="test", code="test", key=["test"])])
    except:
        assert False
    try:
        assert BaseError(messages=[Message(text="test", code="test", key=["test"])]) == BaseError(messages=[Message(text="test1", code="test", key=["test"])])
    except:
        assert False
    assert BaseError(messages=[Message(text="test", code="test", key=["test"])]) == BaseError(messages=[Message(text="test", code="test", key=["test"])])

# Generated at 2022-06-12 15:31:35.564992
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    pass


# Generated at 2022-06-12 15:31:40.275056
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    _error_a: ValidationError = ValidationError(text='text-1', code='code-1', key='key-1')
    _error_b: ValidationError = ValidationError(text='text-2', code='code-2', key='key-2')
    assert not _error_a == 1 or _error_a == _error_b


# Generated at 2022-06-12 15:31:45.519555
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message_temp()
    msg2 = Message("Hello World!", "msg_code", None, [1, 2], Position(1, 2, 3), None, None)
    b = msg1 == msg2
    assert b == False
    assert b == True
    assert msg1 == msg2
    assert msg1 != msg2


# Generated at 2022-06-12 15:31:51.161510
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no = 0
    column_no = 0
    char_index = 0
    position = Position(line_no, column_no, char_index)
    Same_Position = Position(line_no, column_no, char_index)
    assert position.__eq__(Same_Position) == True

    Different_Position = Position(line_no, column_no, char_index+1)
    assert position.__eq__(Different_Position) == False


# Generated at 2022-06-12 15:31:52.429446
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    args = []
    pos0 = Position(*args)
    pos1 = Position(*args)
    assert pos0 == pos1

# Generated at 2022-06-12 15:31:57.332492
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="test", code="test", key="test", position="test")
    message2 = Message(text="test", code="test", key="test", position="test")
    assert message1 == message2
    message1 = Message(text="test2", code="test", key="test", position="test")
    assert message1 != message2


# Generated at 2022-06-12 15:32:18.339784
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # type: () -> None
    assert Position(line_no=10, column_no=5, char_index=6) == Position(
        line_no=10, column_no=5, char_index=6
    )

    assert Position(line_no=10, column_no=5, char_index=6) != Position(
        line_no=11, column_no=5, char_index=6
    )
    assert Position(line_no=10, column_no=5, char_index=6) != Position(
        line_no=10, column_no=6, char_index=6
    )
    assert Position(line_no=10, column_no=5, char_index=6) != Position(
        line_no=10, column_no=5, char_index=7
    )

# Generated at 2022-06-12 15:32:26.065457
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    """
    Tests that the __eq__ method of class BaseError
    """
    # Check that different BaseError instances are not equal to each other
    if BaseError(text = "This is a sample error message") == BaseError(text = "This is a sample error message"):
        raise AssertionError
    # Check that BaseError instances with equal fields are equal
    equal_base_errors = [BaseError(text = "This is a sample error message"), BaseError(text = "This is a sample error message")]
    for error in equal_base_errors:
        for equal_error in equal_base_errors:
            if error != equal_error:
                raise AssertionError

# Generated at 2022-06-12 15:32:28.351466
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)



# Generated at 2022-06-12 15:32:34.027339
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 1, 1) == Position(1, 1, 1)
    assert not Position(1, 1, 1) == Position(2, 1, 1)
    assert not Position(1, 1, 1) == Position(1, 2, 1)
    assert not Position(1, 1, 1) == Position(1, 1, 2)


# Generated at 2022-06-12 15:32:41.774893
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    a = Message(text="this is an example", code="custom", key="information", position = Position(
        line_no = 1, column_no = 1, char_index = 1,
    ))
    b = Message(text="this is an example", code="custom", key="information", position = Position(
        line_no = 1, column_no = 1, char_index = 1,
    ))
    assert a == b
    assert hash(a) == hash(b)
    a.key = "name"
    assert a != b
    a.key = "information"
    assert a == b
    assert hash(a) == hash(b)

# Generated at 2022-06-12 15:32:45.998518
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="1", code='2', key=3, index=[4, 5], start_position=Position(6, 7, 8), end_position=Position(6, 7, 8))
    m2 = Message(text="1", code='2', key=3, index=[4, 5], position=Position(6, 7, 8))
    assert m1 == m2

# Generated at 2022-06-12 15:32:54.314705
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message = Message(text="hello world", index=[1])
    error1 = BaseError(messages=[message])
    error2 = BaseError(messages=[message])
    assert error1 == error2
    assert error1 != BaseError(messages=[Message(text="this is the text", code="this is the code", key=1)])
    assert error1 != BaseError(messages=[Message(text="hello world", code="this is the code", key=1)])
    assert error1 != BaseError(messages=[Message(text="hello world", code="the message code", key=1)])
    assert error1 != BaseError(messages=[Message(text="hello world", code="the message code", key=2)])

# Generated at 2022-06-12 15:33:04.758026
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    r'''
    Юнит тест для метода __eq__ класса BaseError
    '''
    # Testing with builtin types
    assert BaseError(text='text1', code='code1', key='key1') == BaseError(text='text1', code='code1', key='key1')
    assert BaseError(text='text2', code='code2', key='key2') != BaseError(text='text2', code='code2', key='key2', position=Position(1, 2, 3))

    # Testing with custom class types
    class CustomClassType1:
        def __init__(self):
            pass
        def __eq__(self, other):
            return True

# Generated at 2022-06-12 15:33:07.561549
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    baseErr1 = BaseError()
    baseErr2 = BaseError()
    assert baseErr1.__eq__(baseErr2)


# Generated at 2022-06-12 15:33:19.089189
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert not BaseError(text='a') == BaseError(text='b')
    assert BaseError(text='a') == BaseError(text='a')
    assert BaseError(text='a', key='b') == BaseError(text='a', key='b')
    assert not BaseError(text='a', key='b') == BaseError(text='a', key='c')
    assert BaseError(messages=[Message(text='a'), Message(text='b')]) == BaseError(
        messages=[Message(text='a'), Message(text='b')]
    )
    assert not BaseError(messages=[Message(text='a', key='b'), Message(text='c')]) == BaseError(
        messages=[Message(text='a', key='c'), Message(text='c')]
    )


# Generated at 2022-06-12 15:33:58.044772
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='Hello World!')
    error2 = BaseError(text='Hello World!')
    assert error1 == error2

    error1 = BaseError(text='Hello', code='custom', key='name')
    error2 = BaseError(text='Hello', code='custom')

    error1 = BaseError(text='Hello', code='custom', key='name')
    error2 = BaseError(text='Hello', code='custom')
    assert error1 == error2
    assert error2 == error1

    error1 = BaseError(code='custom', key='name')
    error2 = BaseError(code='custom')
    assert error1 == error2
    assert error2 == error1

    error1 = BaseError(text='Hello', code='custom', key='name')

# Generated at 2022-06-12 15:34:07.524626
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="May not have more than 100 characters", code="max_length", key="username") == Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert Message(text="May not have more than 100 characters", code="max_length", key="username") != Message(text="May not have more than 200 characters", code="max_length", key="username")
    assert Message(text="May not have more than 100 characters", code="max_length", key="username") != Message(text="May not have more than 100 characters", code="min_length", key="username")
    assert Message(text="May not have more than 100 characters", code="max_length", key="username") != Message(text="May not have more than 100 characters", code="max_length", key="not username")


# Generated at 2022-06-12 15:34:10.232596
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message1 = Message(text="error 1")
    message2 = Message(text="error 2")
    error1 = BaseError(messages=[message1, message2])
    error2 = BaseError(messages=[message1, message2])
    assert error1 == error2


# Generated at 2022-06-12 15:34:17.374296
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="May not be empty", code="empty")

    error2 = BaseError(text="May not be empty", code="empty")
    assert error1 == error2
    assert hash(error1) == hash(error2)

    error2 = BaseError(text="May not be empty", code="empty1")
    assert error1 != error2

    error2 = BaseError(text="May not be empty1", code="empty")
    assert error1 != error2



# Generated at 2022-06-12 15:34:19.163675
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(messages=[Message(text='foo')]) != BaseError(messages=[Message(text='bar')])


# Generated at 2022-06-12 15:34:27.555244
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    for _ in range(10):
        code = random.choice(['', 'price', 'max_length'])
        key = random.choice(['', 'age', 'height'])
        index = []
        if key:
            index = [key]
        elif random.randint(0, 1):
            index = [random.randint(0, 3)]
            while True:
                if random.randint(0, 1):
                    break
                index.append(random.choice(['id', 'name', 'price']))
        start_line_no = random.randrange(0, 100)
        start_col_no = random.randrange(0, 100)
        start_char_index = random.randrange(0, 100)

# Generated at 2022-06-12 15:34:32.995237
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError()==BaseError()
    assert BaseError()!=BaseError(text="a")
    assert BaseError()!=BaseError(text="a",code="b")
    assert BaseError()!=BaseError(text="a",key="b")
    assert BaseError()!=BaseError(text="a",position=Position(1,2,3))
    assert BaseError()!=BaseError(messages=[Message(text="a",code="b")])
    assert BaseError(messages=[Message(text="a",code="b")])==BaseError(messages=[Message(text="a",code="b")])
    assert BaseError(messages=[Message(text="a",code="b")])!=BaseError(messages=[Message(text="a",code="c")])

# Generated at 2022-06-12 15:34:36.171878
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    a = BaseError(code='custom', text='some text', key=1)
    b = BaseError(code='custom', text='some text', key=1)


# Generated at 2022-06-12 15:34:44.872239
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    try:
        raise ValidationError()
    except Exception as error:
        assert error == ValidationError()
    try:
        raise ValidationError(text='', code='', key=None, position=None, messages=None)
    except Exception as error:
        assert error == ValidationError()
    try:
        raise ValidationError(text='', code='', key=None, position=None, messages=[])
    except Exception as error:
        assert error == ValidationError()

# Generated at 2022-06-12 15:34:50.654065
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():

    message1 = Message(text='May not have more than 100 characters', code='max_length')
    message2 = Message(text='No null allowed in the field')

    base_error1 = BaseError(messages=[message1, message2])
    base_error2 = BaseError(text='May not have more than 100 characters', code='max_length')

    assert base_error1 == base_error2


# Generated at 2022-06-12 15:35:54.928512
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    from . import types
    from . import types

    number = types.Number()
    message1 = types.Message(text="invalid",code = "invalid",key = 1,position = Position(1,1,1))
    message2 = types.Message(text="invalid",code = "invalid",key = 1,position = Position(1,1,1))
    error1 = types.BaseError(text="invalid",code = "invalid",key = 1,position = Position(1,1,1))
    error2 = types.BaseError(text="invalid",code = "invalid",key = 1,position = Position(1,1,1))
    assert error1 == error2
    assert error1 != 1

# Generated at 2022-06-12 15:36:01.513412
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message1 = Message(text='text1')
    message2 = Message(text='text2')
    message3 = Message(text='text3')

    error1 = BaseError(messages=[message1, message2])
    error2 = BaseError(messages=[message2, message3])
    error3 = BaseError(messages=[message1, message2, message3])
    error4 = BaseError(messages=[message2])

    assert message1 == message1
    assert message1 != message2
    assert message1 != message3
    assert message1 != error1
    assert message2 == message2
    assert message2 != message1
    assert message2 != message3
    assert message2 != error1
    assert message3 == message3
    assert message3 != message1
    assert message3 != message2
    assert message3 != error1

# Generated at 2022-06-12 15:36:07.833101
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    expected_result = True
    actual_result = BaseError(text = 'A validation error.', code = 'invalid', key = 0, position = 'None') == BaseError(text = 'A validation error.', code = 'invalid', key = 0, position = 'None')
    try:
        assert actual_result == expected_result
        print("Passed TEST 1: BaseError's __eq__ method returns expected result")
    except AssertionError as e:
        print("Failed TEST 1: BaseError's __eq__ method does not return expected result")


# Generated at 2022-06-12 15:36:09.875604
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    e = BaseError(messages=[Message(text="t1", code="c1", key="k1")])
    print(e.__eq__(e))


# Generated at 2022-06-12 15:36:13.061135
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')

    assert error1 == error2


# Generated at 2022-06-12 15:36:14.059762
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    pass


# Generated at 2022-06-12 15:36:15.507198
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(code="invalid") == BaseError(code="invalid")



# Generated at 2022-06-12 15:36:21.905491
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error = BaseError(text="test", code="test1")
    error2 = BaseError(messages=[Message(text="test", code="test1")])
    error3 = BaseError(text="test2", code="test1")
    error4 = BaseError(text="test", code="test2")
    assert error == error2
    assert error2 == error
    assert error != error3
    assert error3 != error
    assert error != error4
    assert error4 != error

# Generated at 2022-06-12 15:36:26.672065
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    self = ValidationError(text='May not have more than 100 characters', code='max_length')
    other = ValidationError(text='May not have more than 100 characters', code='max_length')
    assert self.__eq__(other) == True
    self = ValidationError(text='May not have more than 100 characters', code='max_length', key='key')
    other = ValidationError(text='May not have more than 100 characters', code='max_length', key='key')
    assert self.__eq__(other) == True
    self = ParseError(text='unexpected character after line continuation character')
    other = ParseError(text='unexpected character after line continuation character')
    assert self.__eq__(other) == True


# Generated at 2022-06-12 15:36:31.225622
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    def test_general(obj1, obj2, expected):
        assert (obj1 == obj2) == expected

    BaseError = typesystem.validators.BaseError
    Message = typesystem.validators.Message
    test_general(
        BaseError(
            text="May not have more than 100 characters",
            code="max_length",
            key="username",
        ),
        BaseError(
            text="May not have more than 100 characters",
            code="max_length",
            key="username",
        ),
        True,
    )