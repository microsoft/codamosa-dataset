

# Generated at 2022-06-12 15:28:53.104810
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(value=1)
    one, none = list(validation_result)
    assert one == 1
    assert none is None

# Generated at 2022-06-12 15:28:58.293163
# Unit test for constructor of class BaseError
def test_BaseError():
    msg = "test_msg"
    test_error = BaseError(text=msg)
    assert isinstance(test_error, BaseError)
    assert isinstance(test_error, Mapping)
    assert isinstance(test_error, Exception)
    assert len(test_error) == 1
    assert test_error[""] == msg
    assert list(iter(test_error))[0] == ""
    assert list(test_error.messages())[0].text == msg

# Generated at 2022-06-12 15:29:08.680076
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message(text="Text", code="Code")
    msg2 = Message(text="Text", code="Code")
    assert msg1==msg2
    msg1 = Message(text="Text", code="Code", key="Key")
    msg2 = Message(text="Text", code="Code", key="Key")
    assert msg1==msg2
    msg1 = Message(text="Text", code="Code", index=["Index"])
    msg2 = Message(text="Text", code="Code", index=["Index"])
    assert msg1==msg2
    pos = Position(1,2,3)
    msg1 = Message(text="Text", code="Code", position=pos)
    msg2 = Message(text="Text", code="Code", position=pos)
    assert msg1==msg2


# Generated at 2022-06-12 15:29:13.550854
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text='some error')
    assert len(error) == 0
    assert error.messages() == [
        Message(text='some error', code='custom', key=None, index=[])
    ]
    assert dict(error) == {'': 'some error'}


# Generated at 2022-06-12 15:29:17.700164
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    assert isinstance(iter(result), typing.Iterator)
    assert list(result) == [1, None]



# Generated at 2022-06-12 15:29:25.515091
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # TODO: Add more test cases
    validation_result = ValidationResult(value="example_value")
    assert list(validation_result) == ["example_value", None]
    validation_result = ValidationResult(error=ValidationError(messages=[
        Message(text="example_value", index=[])
    ]))
    assert list(validation_result) == [None, ValidationError(messages=[
        Message(text="example_value", index=[])
    ]) ]


# Generated at 2022-06-12 15:29:37.780850
# Unit test for constructor of class ParseError
def test_ParseError():
    class_name = 'ParseError'
    text = 'may not be blank'
    code = 'blank'
    key = 'input_first_name'
    index = [0, 'input_first_name']
    start_position = 2
    end_position = 12
    Position1 = Position(line_no = 1,column_no = 2,char_index = 3)
    Position2 = Position(line_no = 2,column_no = 3,char_index = 4)
    # Test cases when ParseError is instantiated by multiple messages
    p_error1 = ParseError(messages = [Message(text = text,code = code,key = key,position = Position1),Message(text = text,code = code,key = key,position = Position2)])

# Generated at 2022-06-12 15:29:39.858871
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(value=1)
    for a, b in validation_result:
        assert a == 1
        assert b is None

# Generated at 2022-06-12 15:29:41.280469
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    obj = ValidationResult(value=1, error=None)
    assert list(obj) == [1, None]

# Generated at 2022-06-12 15:29:50.747856
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem import validate_or_error
    from typesystem.schema import Schema
    from datetime import datetime
    from datetime import timedelta

    class DateTimeSchema(Schema):
        @staticmethod
        def str_to_datetime(s: str) -> datetime:
            try:
                return datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
            except ValueError as e:
                raise TypeError(e)

        @staticmethod
        def datetime_to_str(v: datetime) -> str:
            return datetime.strftime(v, "%Y-%m-%d %H:%M:%S")


# Generated at 2022-06-12 15:30:02.344845
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value=1).__iter__()
    assert value == 1
    assert error == None
    value, error = ValidationResult(error=ValidationError()).__iter__()
    assert value == None
    assert isinstance(error, ValidationError)

# Generated at 2022-06-12 15:30:06.869442
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    for value, error in ValidationResult():
        assert value is None
        assert error is None
    for value, error in ValidationResult(value=1):
        assert value == 1
        assert error is None
    for value, error in ValidationResult(error="error"):
        assert value is None
        assert error == "error"


# Generated at 2022-06-12 15:30:09.315861
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr1 = ValidationResult(value="")
    i1 = iter(vr1)
    assert next(i1) == ""
    assert next(i1) is None
    vr2 = ValidationResult(error="")
    i2 = iter(vr2)
    assert next(i2) is None
    assert next(i2) == ""


# Generated at 2022-06-12 15:30:13.131775
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=123)) == [123, None]
    assert list(ValidationResult(error=ValidationError(messages=[Message(text="oops")]))) == [None, ValidationError(messages=[Message(text="oops")])]

# Generated at 2022-06-12 15:30:18.859126
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():

    vr = ValidationResult(value="val")
    assert next(iter(vr)) == "val"
    with pytest.raises(StopIteration):
        next(iter(vr))
    vr = ValidationResult(error="err")
    assert next(iter(vr)) == "err"
    with pytest.raises(StopIteration):
        next(iter(vr))



# Generated at 2022-06-12 15:30:23.823099
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value={"a": 1, "b":2})
    l = list(v)
    assert l == [{"a": 1, "b":2}, None]

    v = ValidationResult(error="error")
    l = list(v)
    assert l == [None, "error"]


# Generated at 2022-06-12 15:30:26.180309
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    v = ValidationResult(value = 1)
    l = list(v)
    print(l)
    v = ValidationResult(error = 1)
    l = list(v)
    print(l)


# Generated at 2022-06-12 15:30:28.354663
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=7)
    value, error = iter(result)

    assert value == 7
    assert error is None

# Generated at 2022-06-12 15:30:32.098859
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    i1, i2, i3 = Message(text='a'), Message(text='b'), Message(text='a')
    assert i1 == i3
    assert i1 != i2


# Generated at 2022-06-12 15:30:35.948852
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # type: () -> None
    # Setup
    result = ValidationResult(value=1)
    # Exercise
    it = result.__iter__()
    value, error = next(it)
    # Verify
    assert value == 1
    assert error is None
    # Cleanup - none necessary



# Generated at 2022-06-12 15:30:47.186778
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert tuple(result) == (1, None)

    result = ValidationResult(error=ValidationError('Error'))
    assert tuple(result) == (None, ValidationError('Error'))



# Generated at 2022-06-12 15:30:55.868570
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    class schema():
        def validate(self,data):
            return data
    s=schema()
    value,error=s.validate(2)
    assert value==2
    assert error==None
    assert bool(value)==True
    v=ValidationResult(value=3,error=None)
    assert v.value==3
    assert v.error==None
    assert bool(v)==True
    e=ValidationResult(value=None,error=ValidationError(text="The data is not True"))
    assert e.value==None
    assert e.error!=None
    assert bool(e)==False
    for i in e:
        assert i==e.error or i==e.value


# Generated at 2022-06-12 15:31:06.077715
# Unit test for method __eq__ of class Message
def test_Message___eq__():
#Input
    python_message = Message(text='hello', code='bla', key = 1, index = [1, 2], position = Position(1, 2, 3), start_position = Position(1, 2, 3), end_position = Position(1, 2, 3))
    python_message2 = Message(text='hello', code='bla', key = 1, index = [1, 2], position = Position(1, 2, 3), start_position = Position(1, 2, 3), end_position = Position(1, 2, 3))
    python_message3 = Message(text='hello', code='bla', key = 1, index = [1, 3], position = Position(1, 2, 3), start_position = Position(1, 2, 3), end_position = Position(1, 2, 3))

# Generated at 2022-06-12 15:31:13.791532
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    myTest = ValidationResult(value="string")
    assert next(iter(myTest)) == "string"
    assert next(iter(myTest)) is None
    myTest2 = ValidationResult(error=ValidationError(text="error"))
    assert next(iter(myTest2)) is None
    assert next(iter(myTest2)) == ValidationError(text="error")


# Generated at 2022-06-12 15:31:17.529503
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Setup
    value, error = None, None

    # Exercise
    validation_result = ValidationResult(value = value, error = error)

    # Verify
    assert(iter(validation_result) == (value, error))


# Generated at 2022-06-12 15:31:24.279828
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem import Schema

    class UserSchema(Schema):
        username = str

    result_1 = UserSchema.validate_or_error({"username": "alex"})
    v_1, e_1 = result_1
    assert v_1 == {
        "username": "alex"
    }
    assert e_1 is None

    result_2 = UserSchema.validate_or_error({})
    v_2, e_2 = result_2
    assert v_2 is None
    assert isinstance(e_2, ValidationError)


# Generated at 2022-06-12 15:31:33.015391
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    print('Testing method Message: __eq__')
    pos = Position(line_no=1, column_no=1, char_index=1)
    msg1 = Message(text='text1', code='code1', key='key1', position=pos)
    msg2 = Message(text='text2', code='code2', key='key2', position=pos)
    msg3 = Message(text='text1', code='code1', key='key1', position=pos)

    assert msg1 != msg2
    assert msg1 == msg3


# Generated at 2022-06-12 15:31:38.694059
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    import hypothesis.strategies as st
    from hypothesis import given
    import hypothesis.extra.pytestplugin

    @given(st.integers(), st.integers())
    def test_function(num1, num2):
        validationresult_instance = ValidationResult(value=num1, error=num2)
        iterator = validationresult_instance.__iter__()
        next(iterator) == num1
        next(iterator) == num2
    test_function()


# Generated at 2022-06-12 15:31:49.116619
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="hello") == Message(text="hello")
    assert not (Message(text="hello") == Message(text="goodbye"))
    assert not (Message(text="hello") == Message(text="hello", index=[1]))
    assert not (Message(text="hello", index=[1]) == Message(text="hello"))
    assert Message(text="hello", index=[1]) == Message(text="hello", index=[1])
    assert Message(text="hello", index=[1, "a"]) == Message(text="hello", index=[1, "a"])
    assert not (Message(text="hello", index=[1, "a"]) == Message(text="hello", index=[1, "b"]))

# Generated at 2022-06-12 15:31:53.423019
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=5)
    value, error = result
    assert (value, error) == (5, None)

    result = ValidationResult(error=ValidationError(text="error"))
    value, error = result
    assert isinstance(error, ValidationError)
    assert error.messages()[0].text == "error"
    assert value is None


# Generated at 2022-06-12 15:32:08.922811
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value=None, error=None)
    assert list(value) == [None, None]



# Generated at 2022-06-12 15:32:13.002458
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Case: Call: Iterate over an instance of class ValidationResult
    # Expected: Return 2 items
    result = ValidationResult(value={}, error={})
    assert next(iter(result)) == {}
    assert next(iter(result)) == {}


# Generated at 2022-06-12 15:32:16.339889
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    r = ValidationResult(value=1)
    assert list(r) == [1, None]

    r = ValidationResult(error=1)
    assert list(r) == [None, 1]


# Generated at 2022-06-12 15:32:19.901226
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    obj = ValidationResult(value=1)
    assert list(iter(obj)) == [1, None]
    obj = ValidationResult(error=ValidationError())
    assert list(iter(obj)) == [None, ValidationError()]


# Generated at 2022-06-12 15:32:23.591887
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    pair = ValidationResult(value='data')
    it = iter(pair)
    assert next(it) == 'data'
    assert next(it) is None
    with pytest.raises(StopIteration):
        next(it)


# Generated at 2022-06-12 15:32:26.332884
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Test method __iter__ of class ValidationResult
    # Input arguments:
    #   value: The validated data.

    # Make instance of class ValidationResult
    result = ValidationResult(value=[1,2,3])
    value, error = result

    # Test: Call method __iter__ of ValidationResult
    # Expected result:
    #   Iterator, that returns list of instances of class ValidationResult
    assert value == [1,2,3]
    assert error == None


# Generated at 2022-06-12 15:32:28.869615
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult()
    value, error = result
    assert value is None
    assert error is None


# Generated at 2022-06-12 15:32:32.548621
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=5)) == [5, None]

    class MyValidationError(ValidationError):
        """A subclass of ValidationError."""


# Generated at 2022-06-12 15:32:38.120371
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    
    # Test for ValidationResult(value = value)
    value, error = ValidationResult(value = 17).__iter__()
    assert value == 17
    assert error is None
    
    # Test for ValidationResult(error = error)
    value, error = ValidationResult(error = "Error!").__iter__()
    assert value is None
    assert error == "Error!"
    

# Generated at 2022-06-12 15:32:47.271684
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg = Message(text='May not have more than 100 characters',
                  code='max_length',
                  key='username',
                  index=['user', 'username'],
                  position=Position(
                    line_no=1,
                    column_no=2,
                    char_index=1
                  ),
                  start_position=None,
                  end_position=None
                  )
    msg2 = Message(text='May not have more than 100 characters',
                   code='max_length',
                   key='username',
                   index=['user', 'username'],
                   position=Position(
                       line_no=1,
                       column_no=2,
                       char_index=1
                   ),
                   start_position=None,
                   end_position=None
                   )