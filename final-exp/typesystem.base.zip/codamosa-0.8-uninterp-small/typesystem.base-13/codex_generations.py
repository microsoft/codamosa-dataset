

# Generated at 2022-06-26 09:59:41.334369
# Unit test for constructor of class BaseError
def test_BaseError():
    base_error_0 = BaseError()
    assert base_error_0.messages() == []
    assert base_error_0.messages(add_prefix=2) == []



# Generated at 2022-06-26 09:59:46.955593
# Unit test for constructor of class ValidationError
def test_ValidationError():
    base_error_0 = BaseError()
    validation_error_0 = ValidationError()
    validation_error_1 = ValidationError(text='')
    validation_error_2 = ValidationError(text='', code='')
    validation_error_3 = ValidationError(text='', code='', key=0)
    validation_error_4 = ValidationError(text='', code='', key=0, position=base_error_0)
    validation_error_5 = ValidationError(text='', code='', key=0, position=base_error_0, messages=[])
    validation_error_6 = ValidationError(messages=[])


# Generated at 2022-06-26 09:59:52.655192
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="m1")
    m2 = Message(text="m2")
    m3 = Message(text="m1")

    assert m1 != m2
    assert m1 == m3


# Generated at 2022-06-26 10:00:00.297467
# Unit test for constructor of class BaseError
def test_BaseError():
    error = BaseError(text="error text", code="error code")
    assert str(error) == "error text"
    assert repr(error) == "BaseError(text='error text', code='error code')"
    error = BaseError(text="error text", code="error code", key="key", position="position")
    assert repr(error) == "BaseError(text='error text', code='error code')"
    error = BaseError(messages=["error text", "error code"])
    assert repr(error) == "BaseError(text='error text', code='error code')"
    error = BaseError(text="error text2", code="error code2", key="key2", position="position2")
    assert repr(error) == "BaseError(text='error text2', code='error code2')"


# Unit

# Generated at 2022-06-26 10:00:03.594543
# Unit test for constructor of class ParseError
def test_ParseError():
    test_case_0()
    base_error_0 = BaseError()
    parse_error_0 = ParseError()


# Generated at 2022-06-26 10:00:11.998386
# Unit test for constructor of class ValidationError
def test_ValidationError():
    r_code_1 = ValidationError(text='text1', code='code_test1')
    r_code_2 = ValidationError(text='text2', code='code_test2')
    r_index_1 = ValidationError(text='text1', code='code_test1', key='key_test1')
    r_index_2 = ValidationError(text='text2', code='code_test2', key='key_test2')
    r_index_3 = ValidationError(text='text3', code='code_test2', key='key_test3')
    r_position_1 = ValidationError(text='text1', code='code_test1', position=10)
    r_position_2 = ValidationError(text='text2', code='code_test2', position=20)
    r

# Generated at 2022-06-26 10:00:16.886577
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_a = Message(text="abc")
    message_b = Message(text="abc")
    message_c = Message(text="abc", code="abc")
    message_d = Message(text="abc", key="abc")

    assert message_a == message_b
    assert message_a != message_c
    assert message_a != message_d


# Generated at 2022-06-26 10:00:26.845173
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test 1
    message_0 = Message()
    message_1 = Message()

    assert message_0 == message_1

    # Test 2
    message_0 = Message(key=1)
    message_1 = Message(index=[1])

    assert message_0 == message_1

    # Test 3
    message_0 = Message(key="")

    assert message_0 == message_0

    # Test 4
    message_0 = Message(key="1")
    message_1 = Message(key="1")

    assert message_0 == message_1

    # Test 5
    message_0 = Message(key=1)
    message_1 = Message(key=1)

    assert message_0 == message_1

    # Test 6
    message_0 = Message(key=1)

# Generated at 2022-06-26 10:00:33.314680
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    arg_value_0 = Message(text="", code="", index=[""], position=None)
    arg_value_1 = Message(text="", code="", index=[""], position=None)

    assert arg_value_0 == arg_value_1


# Generated at 2022-06-26 10:00:46.707263
# Unit test for method __eq__ of class Message

# Generated at 2022-06-26 10:01:03.144527
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m_0_0 = Message(text='t-0-0', code='c-0-0', start_position=Position(0, 0, 0), end_position=Position(1, 1, 1))
    m_0_1 = Message(text='t-0-1', code='c-0-1', start_position=Position(0, 0, 0), end_position=Position(1, 1, 1))
    m_1_0 = Message(text='t-1-0', code='c-1-0', start_position=Position(1, 0, 0), end_position=Position(2, 1, 1))
    m_1_1 = Message(text='t-1-1', code='c-1-1', start_position=Position(1, 0, 0), end_position=Position(2, 1, 1))

# Generated at 2022-06-26 10:01:09.184014
# Unit test for constructor of class BaseError
def test_BaseError():
    try:
        assert BaseError(text="", code="", key=None, position=Position(1, 1, 1), messages=None)
        print("BaseError: constructor test successful")
    except AssertionError:
        print("BaseError: constructor test unsuccessful")



# Generated at 2022-06-26 10:01:15.238393
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message("text", "code", "key", ["index"], "position")
    message_1 = Message("text", "code", "key", ["index"], "position")
    assert message_0 == message_1


# Generated at 2022-06-26 10:01:21.666045
# Unit test for constructor of class ValidationError
def test_ValidationError():
    value = 10
    error = ValidationError(text='May not have more than 100 characters', code='max_length', key='username')
    ValidationResult(value, error)
    value, error = ValidationResult(value, error)
    repr(error)
    repr(value)
    repr(ValidationResult(value, error))
    try:
        ValidationResult()
    except AssertionError:
        pass

# Generated at 2022-06-26 10:01:34.134915
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    """
    Test method Message.__eq__()
    """
    message_0 = Message(text='text')
    message_1 = Message(text='text')
    message_2 = Message(text='text', code='code_0')
    message_3 = Message(text='text', code='code_1')
    message_4 = Message(text='text', key='key_0')
    message_5 = Message(text='text', key='key_1')
    message_6 = Message(text='text', position=Position(0, 1, 2))
    message_7 = Message(text='text', position=Position(0, 1, 2))
    message_8 = Message(text='text', start_position=Position(0, 1, 2))

# Generated at 2022-06-26 10:01:44.758756
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='', code='', index=[0], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))
    message_1 = Message(text='', code='', index=[0], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))
    message_2 = Message(text='', code='', index=[0], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
   

# Generated at 2022-06-26 10:01:45.740756
# Unit test for constructor of class ValidationError
def test_ValidationError():
    assert not ValidationError({})


# Generated at 2022-06-26 10:01:56.650079
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    base_error_0 = BaseError()
    base_error_1 = BaseError(text='', code=None, key=None, position=None, messages=[])
    assert base_error_0 == base_error_1
    # False:
    base_error_2 = BaseError(text='', code=None, key=None, position=None, messages=[])
    base_error_3 = BaseError(text='', code=None, key=None, position=None, messages=[])
    base_error_4 = BaseError(text='', code=None, key=None, position=None, messages=[])
    base_error_5 = BaseError(text='', code=None, key=None, position=None, messages=[])

# Generated at 2022-06-26 10:02:03.509668
# Unit test for constructor of class ParseError
def test_ParseError():
    data = {
        'username': 'aditya',
        'email': 'aditya@mail.com',
        'password': '1234'
    }

    res = ParseError(data)
    assert res.messages() == res.messages()
    assert res.messages(add_prefix='users') == res.messages()
    assert res.messages(add_prefix=1) == res.messages()
    assert res.messages(add_prefix=2) == res.messages()



# Generated at 2022-06-26 10:02:16.449134
# Unit test for constructor of class ValidationError
def test_ValidationError():
    assert ValidationError() != ValidationError()
    assert ValidationError() != ValidationError(text='text')
    assert ValidationError() != ValidationError(code='code')
    assert ValidationError(text='text') != ValidationError(code='code')
    assert ValidationError(text='text') != ValidationError(text='text', code='code')
    assert ValidationError(text='text') != ValidationError(code='code')
    assert ValidationError(text='text') != ValidationError(text='txt', code='code')
    assert ValidationError(code='code') != ValidationError(code='cod')
    assert ValidationError(messages=[Message(text='text')]) != ValidationError(messages=[Message(text='txt')])