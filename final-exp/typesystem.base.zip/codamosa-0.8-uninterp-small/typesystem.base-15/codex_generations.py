

# Generated at 2022-06-26 09:59:35.383005
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -8376
    float_0 = -3980.93833
    str_0 = '#t=B|J!y:_8Fw|'
    dict_0 = {}
    dict_0 = {}
    dict_1 = {}
    dict_1[str_0] = int_0
    dict_0['ZU8W=bI]pR#/eu'] = dict_1
    dict_2 = {}
    dict_2['6i=B.W!1p!R_6e'] = dict_0
    dict_0 = {}
    dict_0 = {}
    dict_0[str_0] = int_0
    dict_2['_e7}L~h#YX9ZHm'] = dict_0
    dict_0 = {}
    dict_0

# Generated at 2022-06-26 09:59:43.805293
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    float_1 = -1825.62947
    validation_error_1 = ValidationError(key=float_1)
    # Call method __eq__ of class BaseError with input parameter validation_error_1
    result = validation_error_0.__eq__(validation_error_1)
    # Expected output bool:True
    assert result


# Generated at 2022-06-26 09:59:49.915978
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=425, column_no=138, char_index=361)
    position_1 = Position(line_no=425, column_no=138, char_index=361)
    assert position_0 == position_1


# Generated at 2022-06-26 09:59:56.366845
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    validation_error_1 = ValidationError(key=float_0)
    int_0 = 2
    validation_error_2 = ValidationError(key=float_0)
    assert not (validation_error_0 == validation_error_1)
    assert validation_error_0 != validation_error_2


# Generated at 2022-06-26 09:59:57.877813
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    pass


# Generated at 2022-06-26 10:00:08.734444
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    from pytest import raises
    from . import ValidationError, ValidationError

    float_0 = -2546.961441213
    float_1 = -2546.961441213
    float_2 = -2546.961441213
    float_3 = -2546.961441213
    float_4 = -2546.961441213
    float_5 = -2546.961441213
    float_6 = -2546.961441213
    float_7 = -2546.961441213
    float_8 = -2546.961441213
    float_9 = -2546.961441213
    float_10 = -2546.961441213
    float_11 = -2546.961441213
    float_12 = -2546.9614412

# Generated at 2022-06-26 10:00:18.027941
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)

    float_1 = -1825.62947
    validation_error_1 = ValidationError(key=float_1)

    float_2 = -1825.62947
    validation_error_2 = ValidationError(key=float_2)

    float_3 = -1825.62947
    validation_error_3 = ValidationError(key=float_3)

    float_2 = -1825.62947
    validation_error_2 = ValidationError(key=float_2)
    assert not validation_error_0 == validation_error_1
    assert not validation_error_2 == validation_error_3


# Generated at 2022-06-26 10:00:29.519670
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    float_0 = -937.418
    str_0 = 'ValidationError(text="Error message", code="custom", key=-937.418)'
    int_0 = 975
    regex_0 = re.compile('-')
    str_1 = '}9\'J1:B:6R)Oh,51GEM1T]?rT}T0F&f<)o=0`0}`Q\'V'
    str_2 = 'ziho'
    dict_0 = {}
    set_0 = set()
    int_1 = -588
    bytes_0 = b'\x1bG\x10\x1f\xf9f4\xc4!\xec\xc3\x8a\x1b-\x0cG\xb2D'
    float_1

# Generated at 2022-06-26 10:00:37.277227
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    method = BaseError.__eq__
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    validation_error_1 = ValidationError(key=float_0)
    # Assert the __eq__ method returns the expected value
    assert method(validation_error_0, validation_error_1)


# Generated at 2022-06-26 10:00:40.276115
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # TODO: Check that the below actually tests something significant.
    assert True



# Generated at 2022-06-26 10:01:02.912099
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Testing BaseError
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    float_1 = -1239.78978
    validation_error_1 = ValidationError(key=float_1)
    # The test
    assert validation_error_0 == validation_error_0
    assert validation_error_1 == validation_error_1
    assert validation_error_0 is not validation_error_1
    assert validation_error_0 != validation_error_1


# Generated at 2022-06-26 10:01:10.216075
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_1 = ValidationError(key=float_0)
    validation_error_2 = ValidationError(key=float_0)
    assert validation_error_1 == validation_error_2
    validation_error_3 = ValidationError(key=float_0, text='text')
    assert validation_error_1 != validation_error_3


# Generated at 2022-06-26 10:01:19.773810
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    float_0 = -962.76623
    str_0 = '`zOt]'
    validation_error_0 = ValidationError(key=float_0)
    message_0 = Message(position=validation_error_0, text=str_0)
    message_1 = Message(position=validation_error_0, text=str_0)
    assert message_0 == message_1


# Generated at 2022-06-26 10:01:21.484290
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)


# Generated at 2022-06-26 10:01:34.071378
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)

    int_0 = -1720015651
    validation_error_1 = ValidationError(key=int_0)
    assert not (validation_error_0 == validation_error_1)

    float_1 = -1507.947817
    validation_error_2 = ValidationError(key=float_1)
    assert not (validation_error_1 == validation_error_2)

    list_0 = ['7', '1', -39, '}', 'z', 'M', '!', '{', '2', '+']
    validation_error_3 = ValidationError(key=list_0)
    assert not (validation_error_2 == validation_error_3)




# Generated at 2022-06-26 10:01:44.732131
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    from io import StringIO
    import json
    import typesystem
    import typesystem.exceptions

    # Test TestCase 0
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    # Test TestCase 1
    source_0 = StringIO('{')
    int_0 = 55
    dict_0 = dict()
    str_0 = '{"some": "thing"}'
    parse_error_0 = ParseError(code=int_0, key=dict_0, text=str_0)
    # Test TestCase 2
    validation_error_1 = ValidationError(dict_0)
    # Test TestCase 3
    code_str = 'e'
    list_0 = list()

# Generated at 2022-06-26 10:01:51.330678
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    str_1 = "3.141592653589793"
    validation_error_1 = ValidationError(key=str_1)
    # assertion message
    msg = "Expected result: True\nActual result: False"
    assert (validation_error_0 == validation_error_1) == True, msg


# Generated at 2022-06-26 10:02:01.796296
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    float_0 = -1825.62947
    str_0 = "C)~l!*b_#n%PQ\\6Ugx6D*}XnC&H"
    str_1 = "&{<;YH8m?0"
    str_2 = "9sLW8(@[Z"
    float_1 = -1825.62947
    float_2 = -1825.62947
    float_3 = -1825.62947
    message_0 = Message(str_0, str_1, float_1, float_0, float_1)
    message_0_copy = message_0
    message_1 = Message(str_2, str_1, float_2, float_2, float_2)
    assert message_0 == message_0_copy

# Generated at 2022-06-26 10:02:12.501620
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    float_0 = 0.73171198583
    int_1 = 165250
    str_2 = '9c5b73cc-22b4-464f-8e1c-2a2a4ec4c7a8'
    str_3 = '4eab6fce-0635-4414-b452-87df049e48e6'
    str_4 = '0d3f3b2e-25a6-442b-87d5-e0d27c988c28'
    validation_error_0 = ValidationError(key=str_0)
    validation_error_1 = ValidationError(index=[float_0, float_0])

# Generated at 2022-06-26 10:02:16.929312
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)



# Generated at 2022-06-26 10:02:41.349941
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    float_0 = -1825.62947
    int_0 = -5
    float_1 = -1825.62947
    position_0 = Position(float_0, float_0, float_0)

    assert position_0.__eq__(position_0) is True
    assert position_0.__eq__(int_0) is False
    assert position_0.__eq__(float_1) is False


# Generated at 2022-06-26 10:02:54.257233
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    float_1 = -1451.2082
    int_2 = 327
    int_3 = -15430
    int_4 = -15755
    position_0 = Position(line_no=int_4, column_no=int_4, char_index=int_4)
    position_1 = Position(int_2, int_2, int_2)
    position_2 = Position(column_no=int_2, line_no=int_2, char_index=int_2)
    position_3 = Position(int_3, int_3, int_3)
    position_4 = Position(int_3, int_3, int_3)
    bool_0 = position_0.__eq__(position_1)
    bool_1 = position_1.__eq__(position_2)
    bool

# Generated at 2022-06-26 10:02:59.521137
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    float_1 = -1825.62947
    validation_error_1 = ValidationError(key=float_1)
    bool_return_value_0 = validation_error_0 == validation_error_1


# Generated at 2022-06-26 10:03:12.523857
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_1 = "string"
    str_2 = "string"
    str_3 = "string"
    str_4 = "string"
    str_5 = "string"
    str_6 = "string"
    str_7 = "string"
    str_8 = "string"
    str_9 = "string"
    str_10 = "string"
    str_11 = "string"
    str_12 = "string"
    str_13 = "string"
    str_14 = "string"
    str_15 = "string"
    str_16 = "string"
    str_17 = "string"
    str_18 = "string"
    str_19 = "string"
    str_20 = "string"
    str_21 = "string"
    str_22 = "string"
   

# Generated at 2022-06-26 10:03:19.795471
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="I could also be found in an assignment", code="custom", index=[])
    message_1 = Message(text="I could also be found in an assignment", code="custom", index=[])
    # check if message_0 and message_1 are equal.
    assert message_0 == message_1


# Generated at 2022-06-26 10:03:23.995878
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    validation_error_1 = ValidationError(key=float_0)
    assert (validation_error_0 == validation_error_1)


# Generated at 2022-06-26 10:03:28.013704
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    assert validation_error_0 == validation_error_0


# Generated at 2022-06-26 10:03:39.280354
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    str_0 = "rzr!F6Q[UqUm{U6]O?6+Ck"
    validation_error_0 = ValidationError(key=float_0)
    validation_error_0.messages()
    boolean_0 = validation_error_0 == None
    print(boolean_0)
    validation_error_1 = ValidationError()
    boolean_1 = validation_error_1 == validation_error_0
    print(boolean_1)
    hash_0 = hash(validation_error_1)
    print(validation_error_1)
    boolean_2 = validation_error_1 == str_0
    print(boolean_2)
    validation_error_2 = ValidationError()
    boolean_3 = validation_

# Generated at 2022-06-26 10:03:44.365233
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_1 = -1825.62947
    validation_error_1 = ValidationError(key=float_1)
    assert not validation_error_0 == validation_error_1


# Generated at 2022-06-26 10:03:49.355009
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    str_0 = 'Ap5f5\'/L\x00P\x9f2\x00<c\x07R\x1a'
    validation_error_1 = ValidationError(key=str_0)
    float_1 = -1825.62947
    validation_error_2 = ValidationError(key=float_1)
    assert (validation_error_2 == validation_error_0) == False
    assert validation_error_0 == validation_error_1


# Generated at 2022-06-26 10:04:17.623761
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    mixed_error_0 = ValidationError(text="\x01\x03\x0e\t\x80\x84\t\"\x0f", code="", key=False)
    mixed_error_1 = ValidationError(text="\x0f\x0c\x05\x06\x0f\x0c3\x05\x0f", code="", key=True)
    mixed_error_2 = ParseError(code="", key=datetime.datetime.now())
    mixed_error_3 = ParseError(code="", key=datetime.datetime.now())

# Generated at 2022-06-26 10:04:18.529880
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    pass


# Generated at 2022-06-26 10:04:22.210204
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    validation_error_1 = ValidationError(key=float_0)
    assert validation_error_0 == validation_error_1


# Generated at 2022-06-26 10:04:26.815463
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    validation_error_1 = ValidationError(key=float_0)
    assert validation_error_0 == validation_error_1



# Generated at 2022-06-26 10:04:29.852409
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    validation_error_1 = validation_error_0
    str_0 = str(validation_error_0)
    assert validation_error_0 == validation_error_1


# Generated at 2022-06-26 10:04:33.220324
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)
    #__tracebackhide__
    #assert False, validation_error_0


# Generated at 2022-06-26 10:04:41.963745
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=1916, column_no=1761, char_index=230)
    position_1 = Position(line_no=1970, column_no=1930, char_index=831)
    position_2 = Position(line_no=1916, column_no=1761, char_index=230)
    position_3 = Position(line_no=1685, column_no=1459, char_index=1404)
    assert position_1 != position_3
    assert position_0 == position_2


# Generated at 2022-06-26 10:04:47.343163
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    float_0 = -1935.9754
    position_0 = Position(line_no=0, column_no=0, char_index=0)
    message_0 = Message(text="", code=None, key=float_0, index=[], position=position_0)
    message_1 = Message(text="", code=None, key=None, index=[], position=position_0)
    assert message_0 != message_1


# Generated at 2022-06-26 10:04:53.202335
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    int_0 = 14
    int_1 = 19
    int_2 = 23
    position_0 = Position(int_0, int_1, int_1)
    position_1 = Position(int_2, int_2, int_2)
    if position_0 == position_1:
        pass
    else:
        raise AssertionError("Expected: True, Actual: False")


# Generated at 2022-06-26 10:05:02.466285
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    string_0 = "P5@Cz~y"
    string_1 = "N*A=NMH"
    string_2 = "jW8`vHV"
    string_3 = "w:CU8j<"
    string_4 = "J{(I+d^"
    string_5 = "TzJ[#:+"
    string_6 = "m-{yxD+"
    string_7 = "`C0=T1T"
    string_8 = "2Z-6S-7"
    string_9 = "V)y3q4)"
    boolean_0 = True
    boolean_1 = True
    boolean_2 = False
    boolean_3 = False
    boolean_4 = True
    boolean_5 = True
    boolean_6 = True
    boolean_7

# Generated at 2022-06-26 10:05:47.081956
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    float_0 = -1825.62947
    location_0 = Position(
        line_no=0, column_no=0, char_index=0
    )  # type: Position
    message_0 = Message(text='', code='', index=[9, 12], position=location_0)
    message_1 = Message(text='', code='', index=[6], position=location_0)
    assert not message_0 == message_1
    assert not message_1 == message_0


# Generated at 2022-06-26 10:05:54.435428
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    float_0 = -16.933
    validation_error_0 = ValidationError(key=float_0)
    message_0 = Message(
        text="This is a text.", code=str(int((float_0 * float_0))), index=[int(float_0)], position=validation_error_0
    )
    message_1 = Message(
        text="This is a text.", code=str(int((float_0 * float_0))), index=[int(float_0)], position=validation_error_0
    )
    assert message_0 == message_1
    assert (not (message_0 != message_1))
    assert message_0.__eq__(message_1)


# Generated at 2022-06-26 10:06:01.121874
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    float_0 = -883.63525
    pos_0 = Position(line_no=float_0, column_no=float_0, char_index=float_0)
    pos_1 = Position(line_no=float_0, column_no=float_0, char_index=float_0)
    pos_2 = (
        Position(line_no=pos_1.line_no, column_no=pos_1.column_no, char_index=pos_1.char_index)
    )
    assert (pos_0 == pos_1) == (
        pos_1 == pos_1
    ) == (pos_2 == pos_0)


# Generated at 2022-06-26 10:06:11.283657
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Local variables:
    validation_error_0 = ValidationError(key=0)
    validation_result_0 = ValidationResult(error=validation_error_0)
    validation_error_0 = ValidationError(key=0)
    validation_result_1 = ValidationResult(error=validation_error_0)
    # Invalid call to method __eq__ of class ValidationResult
    try:
        validation_result_1.__eq__()
    except:
        pass
    validation_error_0 = ValidationError()
    validation_result_0 = ValidationResult(error=validation_error_0)
    validation_error_0 = ValidationError()
    validation_result_1 = ValidationResult(error=validation_error_0)

# Generated at 2022-06-26 10:06:15.025048
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    float_0 = -1825.62947
    position_0 = Position(
        char_index=float_0, column_no=float_0, line_no=float_0
    )
    bool_0 = position_0.__eq__(float_0)
    assert bool_0 == False


# Generated at 2022-06-26 10:06:26.977445
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(char_index=int(50), line_no=int(7), column_no=int(48))
    position_1 = Position(line_no=int(7), column_no=int(48), char_index=int(50))
    assert position_0 == position_1
    position_2 = Position(char_index=int(50), line_no=int(7), column_no=int(48))
    assert position_0 == position_2
    position_3 = Position(column_no=int(48), line_no=int(8), char_index=int(99))
    assert not (position_0 == position_3)
    position_4 = Position(line_no=int(6), column_no=int(47), char_index=int(50))

# Generated at 2022-06-26 10:06:33.114037
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0)

    messages_0 = [Message(text='May not have more than 100 characters', key='username')]
    validation_error_1 = ValidationError(messages=messages_0)
    assert validation_error_0 == validation_error_1


# Generated at 2022-06-26 10:06:37.742418
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    float_0 = -1825.62947
    validation_error_0 = ValidationError(key=float_0, text=float_0, code=float_0)
    float_1 = float_0
    validation_error_1 = ValidationError(key=float_1, text=float_1, code=float_1)
    assert validation_error_0 == validation_error_1



# Generated at 2022-06-26 10:06:49.953022
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Assigning 3 to float_0...
    float_0 = -1825.62947
    # Assigning 6 to float_1...
    float_1 = 7.924
    # Calling ValidationError(text=float_0, code=float_1, key=float_1, position=float_0)...
    validation_error_0 = ValidationError(text=float_0, code=float_1, key=float_1, position=float_0)
    float_2 = float_1
    # Calling ValidationError(text=float_2, code=float_2, key=float_1, position=float_1)...
    validation_error_1 = ValidationError(text=float_2, code=float_2, key=float_1, position=float_1)
    # Calling validation_error_0.__

# Generated at 2022-06-26 10:06:56.546764
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no = 3
    column_no = 2
    char_index = 2
    position = Position(line_no, column_no, char_index)
    line_no = position.line_no
    column_no = position.column_no
    char_index = position.char_index
    result_bool = position == position
    assert isinstance(result_bool, bool)
    assert result_bool


# Generated at 2022-06-26 10:09:01.075212
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    float_0 = -1825.62947
    message_0 = Message(key=str(float_0))
    message_1 = Message(key=str(float_0))
    message_2 = Message(key=str(float_0))
    assert message_0 == message_1
    assert message_1 == message_2


# Generated at 2022-06-26 10:09:06.605079
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg_0 = Message(text='text', code=None)
    result_0 = msg_0.__eq__(None)
    assert result_0 == False
    result_1 = msg_0.__eq__(Message(text='text', code=None))
    assert result_1 == True
    result_2 = msg_0.__eq__(Message(text='text', code=None))
    assert result_2 == True
    result_3 = msg_0.__eq__(Message(text='text', code=None))
    assert result_3 == True
    result_4 = msg_0.__eq__(Message(text='text', code=None))
    assert result_4 == True


# Generated at 2022-06-26 10:09:18.036438
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="text_hello")
    message_1 = Message(text="dummy_value", code="custom", index=["key"])
    message_2 = Message(text="dummy_value", code="dummy code")
    assert message_0 == message_2
    assert message_1 == message_1
    assert message_2 == message_0
    message_3 = Message(text="text_hello", code="dummy code")
    assert not message_3 == message_1
    message_4 = Message(text="text_hello", code="custom", index=["key"])
    message_5 = Message(text="text_hello", code="custom", index=["key"])
    assert not message_4 == message_1
    assert message_4 == message_5