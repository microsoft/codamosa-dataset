

# Generated at 2022-06-26 09:59:34.706625
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with second argument being a ValueError
    message_1 = Message(text='May not have more than 100 characters', code='max_length', key='username', start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=100, char_index=99))
    message_2 = ValueError("Threshold cannot be positive")
    assert message_1.__eq__(message_2) == False

test_case_0()
test_Message___eq__()

# Generated at 2022-06-26 09:59:37.713593
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    iterator_0 = validation_result_0.__iter__()
    try:
        assert iterator_0
        next(iterator_0)
    except StopIteration:
        print("StopIteration")
    try:
        assert iterator_0
        next(iterator_0)
    except StopIteration:
        print("StopIteration")


# Generated at 2022-06-26 09:59:41.431589
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    import pytest
    from typesystem.exceptions import ValidationResult

    validation_result = ValidationResult(value = None, error = None)

    def call_iter_method(validation_result):
        return list(validation_result)

    expected_value = [None, None]
    actual_value = call_iter_method(validation_result)
    assert actual_value == expected_value


# Generated at 2022-06-26 09:59:49.154311
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_error_0 = ValidationError(
        text="Required but not provided", code="required"
    )
    assert validation_error_0.messages() == [
        Message(text="Required but not provided", code="required")
    ]

    expected_result_value_0 = [
        Message(text="Required but not provided", code="required")
    ]
    expected_result_error_0 = None  # type: typing.Optional[ValidationError]

    validation_result_0 = ValidationResult(
        value=expected_result_value_0, error=expected_result_error_0
    )
    result_value_0, result_error_0 = iter(validation_result_0)

    assert result_value_0 == expected_result_value_0
    assert result_error_0 == expected_result_

# Generated at 2022-06-26 09:59:59.102056
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from unittest import TestCase
    from unittest import mock

    import typesystem

    class TestClass:
        def validate_or_error(self, data):
            # here, validate_or_error will be called
            return typesystem.ValidationResult(
                value={
                    "message": data["message"],
                    "user": None if not data["user"] else tuple(data["user"]),
                }
            )

    test_case_0 = TestCase()
    obj = TestClass()
    data = {"message": "", "user": []}
    expected = True


# Generated at 2022-06-26 10:00:03.751998
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_error_0 = ValidationError()
    validation_result_0 = ValidationResult(error=validation_error_0)
    validation_result_0.__iter__()


# Generated at 2022-06-26 10:00:07.772785
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_error_0 = ValidationError()
    validation_result_0 = ValidationResult(error=validation_error_0)
    assert list(iter(validation_result_0)) == [None, validation_error_0]

    validation_result_1 = ValidationResult()
    assert list(iter(validation_result_1)) == [None, None]

# Generated at 2022-06-26 10:00:18.102922
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert ValidationError() == ValidationError()
    assert ValidationError(text="abc") == ValidationError(text="abc")
    assert ValidationError(text="abc") != ValidationError(text="def")
    assert ValidationError(text="abc", code="custom") == ValidationError(
        text="abc", code="custom"
    )
    assert ValidationError(text="abc", code="custom") != ValidationError(
        text="abc", code="bad custom"
    )
    assert ValidationError(text="abc", key=0) == ValidationError(text="abc", key=0)
    assert ValidationError(text="abc", key=0) != ValidationError(text="abc", key=1)

# Generated at 2022-06-26 10:00:27.410046
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Simple test for method __iter__ of class ValidationResult
    validation_result_0 = ValidationResult()
    assert validation_result_0.value is None
    assert validation_result_0.error is None
    validation_result_1 = ValidationResult(error=ValidationError())
    assert validation_result_1.error is not None
    validation_result_2 = ValidationResult(value=10)
    assert validation_result_2.value == 10
    assert validation_result_2.error is None


# Generated at 2022-06-26 10:00:39.523298
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    local_test_Message___eq___1_1 = Message(
        text="A text", index=["0", "a"], position=Position(line_no=1, column_no=2, char_index=3)
    )
    local_test_Message___eq___1_2 = Message(
        text="A text", index=["0", "a"], position=Position(line_no=1, column_no=2, char_index=3)
    )
    local_test_Message___eq___1_3 = Message(
        text="A text", index=["1", "a"], position=Position(line_no=1, column_no=2, char_index=3)
    )

# Generated at 2022-06-26 10:00:49.348112
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # base case
    msg_list = [Message(text="error message", code="code")]
    validation_error_1 = BaseError(messages=msg_list)
    validation_error_2 = BaseError(messages=msg_list)
    __tracebackhide__ = True
    try:
        assert validation_error_1 == validation_error_2
    except: # noqa E722
        pytest.fail("test_BaseError___eq__ failed")
    # list is not the same
    msg_list_different = []
    validation_error_1 = BaseError(messages=msg_list)
    validation_error_2 = BaseError(messages=msg_list_different)
    __tracebackhide__ = True

# Generated at 2022-06-26 10:00:52.673833
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    validation_error_0 = ValidationError(text="Error message!", code="custom")
    validation_error_1 = ValidationError(text="Error message!", code="custom")
    assert (validation_error_0 == validation_error_1)


# Generated at 2022-06-26 10:01:03.119865
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    validation_error_0 = ValidationError()
    other_validation_error_0 = ValidationError(
        messages=[]
    )
    validation_error_1 = ValidationError(
        text="May not have more than 100 characters", code="max_length"
    )
    validation_error_2 = ValidationError(
        text="May not have more than 100 characters", code="max_length"
    )
    validation_error_3 = ValidationError(
        code="max_length", text="May not have more than 100 characters"
    )
    validation_error_4 = ValidationError(
        messages=[
            Message(
                text="May not have more than 100 characters",
                code="max_length",
                key="username",
            )
        ]
    )

# Generated at 2022-06-26 10:01:12.733990
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    from typesystem.exceptions import BaseError

    # Test with empty dict
    test_data_0 = {}
    test_instance_0 = BaseError(text="May not have more than 100 characters", key="username")
    try:
        assert test_instance_0.__str__() == test_data_0
    except AssertionError as e:
        raise(AssertionError(f"Error in '__str__' method of BaseError: {e}"))

    # Test with a dict
    test_data_1 = {"username": "May not have more than 100 characters"}
    test_instance_1 = BaseError(text="May not have more than 100 characters", key="username")
    try:
        assert test_instance_1.__str__() == test_data_1
    except AssertionError as e:
        raise

# Generated at 2022-06-26 10:01:22.427303
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    validation_error = ValidationError(text = 'text', code = 'code', key = 1)
    assert validation_error.__str__() == 'text'
    assert validation_error.__repr__() == "ValidationError(text='text', code='code')"
    validation_error = ValidationError(messages=[Message(text = 'text', code = 'code', index=[1])])
    assert validation_error.__str__() == "{'': 'text'}"
    assert validation_error.__repr__() == "ValidationError([Message(text='text', code='code', index=[1])])"


# Generated at 2022-06-26 10:01:34.471663
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text = 'text', code = 'code', index = [0])
    message_1 = Message(text = 'text', code = 'code', index = [0])
    assert message_0 == message_1

    message_0 = Message(text = 'text', code = 'code', index = [0])
    message_1 = Message(text = 'text', code = 'code', index = [1])
    assert not (message_0 == message_1)

    message_0 = Message(text = 'text', code = 'code', index = [0])
    message_1 = Message(text = 'text', code = 'code', index = [0, 0])
    assert not (message_0 == message_1)

    message_0 = Message(text = 'text', code = 'code', index = [])
   

# Generated at 2022-06-26 10:01:37.163223
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    validation_error_0 = ValidationError()
    assert validation_error_0 == validation_error_0


# Generated at 2022-06-26 10:01:41.742083
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="str")
    message_1 = Message(text="str")
    assert message_0 == message_1, "Expected call to 'test_Message___eq__' to return True"


# Generated at 2022-06-26 10:01:53.155912
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    messages_0_0 = Message(text='hello', code='custom', key=None, index=None, position=None, start_position=None, end_position=None)
    messages_0_1 = Message(text='hello', code='custom', key=None, index=None, position=None, start_position=None, end_position=None)
    messages_1_0 = 'text=\'hello\', code=\'custom\', key=None, index=None, position=None, start_position=None, end_position=None'
    assert messages_0_0 == messages_0_1
    assert not (messages_0_0 == messages_1_0)
    # __hash__ is required to be implemented in Python 3.3+

# Generated at 2022-06-26 10:02:03.292727
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(code="custom", index=[], start_position=Position(0, 1, 1), text="May not have more than 100 characters")
    assert message_0.__eq__(message_0) == True
    message_1 = Message(code="custom", index=[], start_position=Position(0, 1, 1), text="May not have more than 100 characters")
    assert message_0.__eq__(message_1) == True
    message_2 = Message(code="custom", index=[], start_position=Position(0, 1, 1), text="May not have more than 100 characters")
    assert message_1.__eq__(message_2) == True
    message_3 = Message(code="custom", index=[], start_position=Position(0, 1, 1), text="May not have more than 100 characters")


# Generated at 2022-06-26 10:02:10.232163
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # test instance BaseError_0
    validation_error_0 = ValidationError()
    # test output
    assert str(validation_error_0) == "{}"



# Generated at 2022-06-26 10:02:11.722958
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # Test default case
    validation_error_0 = ValidationError()


# Generated at 2022-06-26 10:02:25.449265
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    validation_error_0 = Message(
        text='String does not match the email address format.',
        code='invalid_email',
        index=[],
        position=Position(line_no=0,column_no=0,char_index=0),
    )
    validation_error_1 = Message(
        text='String does not match the email address format.',
        code='invalid_email',
        index=[],
        position=Position(line_no=0,column_no=0,char_index=0),
    )
    validation_error_2 = Message(
        text='String does not match the email address format.',
        code='invalid_email',
        index=[],
        position=Position(line_no=0,column_no=0,char_index=0),
    )
    assert validation_

# Generated at 2022-06-26 10:02:26.471449
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()


# Generated at 2022-06-26 10:02:27.946422
# Unit test for constructor of class BaseError
def test_BaseError():
    validation_error_0 = ValidationError()


# Generated at 2022-06-26 10:02:40.242848
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    validation_error_0 = ValidationError("message_0", code="code_0")
    assert str(validation_error_0) == "message_0"
    validation_error_1 = ValidationError("message_0", code="code_0", key="key_0")
    assert str(validation_error_1) == '{"key_0": "message_0"}'
    validation_error_2 = ValidationError("message_0", code="code_0", key="key_0")
    validation_error_2_key_1 = ValidationError("message_1", code="code_1", key="key_1")
    validation_error_2.add_error(validation_error_2_key_1)

# Generated at 2022-06-26 10:02:47.362276
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    base_error = BaseError()
    str_ = base_error.__str__()
    assert str_ == "{}"
    base_error = BaseError(text="An error occured")
    str_ = base_error.__str__()
    assert str_ == "An error occured"
    base_error = BaseError(messages=[Message(text="An error occured")])
    str_ = base_error.__str__()
    assert str_ == "{'': 'An error occured'}"


# Generated at 2022-06-26 10:02:54.299235
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    arg0 = Position(line_no=None, column_no=None)
    arg1 = Position(line_no=None, column_no=None)
    arg2 = Position(line_no=None, column_no=None)
    arg3 = arg1

    assert(arg0 == arg1 == arg2 == arg3)


# Generated at 2022-06-26 10:03:07.596220
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Message.__eq__(other: typing.Any) -> bool
    message_0 = Message(text='text_0', code='code_0', key='key_0', index=['index_0'], position=Position(line_no=0, column_no=0, char_index=0), start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))
    # message_0 == other: typing.Any
    assert message_0 == message_0

# Generated at 2022-06-26 10:03:13.692332
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # Create instance of class 'BaseError'
    try:
        base_error = BaseError()
    except Exception as e:
        logger.fatal(e, exc_info=True)
        raise

    # Test the method '__str__' of the class 'BaseError'
    try:
        base_error.__str__()
    except Exception as e:
        logger.fatal(e, exc_info=True)
        raise

    return


# Generated at 2022-06-26 10:03:33.938109
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no = 0
    column_no = 0
    char_index = 0
    position_0 = Position(line_no, column_no, char_index)
    line_no2 = 0
    column_no2 = 0
    char_index2 = 0
    position_1 = Position(line_no2, column_no2, char_index2)
    result_ = position_0.__eq__(position_1)
    assert result_ is True


# Generated at 2022-06-26 10:03:45.114642
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=1, column_no=1, char_index=1)
    position_1 = Position(line_no=1, column_no=1, char_index=1)
    position_2 = Position(line_no=2, column_no=2, char_index=2)
    assert position_0 == position_1
    assert not (position_0 == position_2)


# Generated at 2022-06-26 10:03:53.172183
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=0, column_no=0, char_index=0)
    position_1 = Position(line_no=0, column_no=0, char_index=0)
    output = position_0 == position_1
    assert output in [True, False]


# Generated at 2022-06-26 10:03:58.090389
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_a = Position(line_no=27331, column_no=12, char_index=976)
    position_b = Position(line_no=11279, column_no=68, char_index=614)
    assert not position_a == position_b


# Generated at 2022-06-26 10:03:59.729325
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    """
    Test case for method Position.__eq__
    """
    pass



# Generated at 2022-06-26 10:04:08.279128
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_a_0 = Position(line_no=0, column_no=0, char_index=0)
    position_a_1 = Position(line_no=1, column_no=1, char_index=1)
    position_a = Position(line_no=2, column_no=2, char_index=2)
    position_b = Position(line_no=3, column_no=3, char_index=3)
    test_0 = position_a == position_a_0
    test_1 = position_a == position_a_1
    test_2 = position_a != position_a_0
    test_3 = position_a != position_a_1

# Generated at 2022-06-26 10:04:13.523597
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "hi"


# Generated at 2022-06-26 10:04:22.318576
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test __eq__ when other is not a Position.
    assert not Position(line_no=1, column_no=1, char_index=1) == "hello"

    # Test __eq__ when other is a Position, but with different values.
    assert not Position(line_no=1, column_no=1, char_index=1) == Position(line_no=2, column_no=2, char_index=2)

    # Test __eq__ when other is a Position, with the same values.
    assert Position(line_no=1, column_no=1, char_index=1) == Position(line_no=1, column_no=1, char_index=1)


# Generated at 2022-06-26 10:04:28.006853
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position0 = Position(line_no=1, column_no=1, char_index=1)
    position1 = Position(line_no=1, column_no=1, char_index=1)
    position2 = Position(line_no=1, column_no=1, char_index=1)
    assert position0 == position1
    assert position1 == position2


# Generated at 2022-06-26 10:04:31.166922
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    """
    The method __eq__ of class Position returns whether two Positions are equal
    """
    p1 = Position(1, 1, 1)
    p2 = Position(1, 1, 1)
    p3 = Position(1, 1, 0)
    assert (p1 == p2) == True
    assert (p1 == p3) == False
