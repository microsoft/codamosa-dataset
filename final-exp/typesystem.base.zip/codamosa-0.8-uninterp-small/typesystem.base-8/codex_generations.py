

# Generated at 2022-06-26 09:59:27.708510
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    validation_error_0 = ValidationError(messages = [])
    boolean_0 = validation_error_0.__eq__("4j7Z!#e")


# Generated at 2022-06-26 09:59:33.459363
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    msg_0 = Message(text='This is a test message')
    base_error_0 = BaseError(messages=[msg_0])
    base_error_1 = BaseError(messages=[msg_0])
    bool_0 = base_error_0.__eq__(base_error_1)
    assert bool_0 is True


# Generated at 2022-06-26 09:59:42.741638
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    text_0 = 'May not have more than 100 characters'
    code_0 = 'max_length'
    key_0 = 'message'
    position_0 = Position(1, 2, 3)
    message_0 = Message(text=text_0, code=code_0, key=key_0, position=position_0)
    validation_error_0 = ValidationError(messages=[message_0])
    base_error_0 = validation_error_0



# Generated at 2022-06-26 09:59:49.572171
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    text_0 = ""
    code_0 = ""
    key_0 = 0
    index_0 = []
    position_0 = Position(line_no = 0, column_no = 0, char_index = 0)
    start_position_0 = Position(line_no = 0, column_no = 0, char_index = 0)
    end_position_0 = Position(line_no = 0, column_no = 0, char_index = 0)
    message_0 = Message(text = text_0, code = code_0, key = key_0, index = index_0, position = position_0, start_position = start_position_0, end_position = end_position_0)
    # AssertionError: expected: <class 'bool'>, actual: <class 'Message'>
    # print(message_0 ==

# Generated at 2022-06-26 09:59:55.918509
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_arg_0 = Message(text="", code="", index=[], position=None, start_position=None, end_position=None)
    message_arg_1 = Message(text="", code="", index=[], position=None, start_position=None, end_position=None)
    val_0 = message_arg_0.__eq__(message_arg_1)


# Generated at 2022-06-26 10:00:02.924945
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    arg0 = Message(text="", code="", key="", index=[])
    arg1 = Message(text="", code="", key="", index=[])
    bool_0 = arg0.__eq__(arg1)
    bool_1 = arg0.__eq__("")


# Generated at 2022-06-26 10:00:04.953273
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:00:13.504296
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Setup
    message_text_0 = "message_text_0"
    key_0 = "key_0"
    validation_result_0 = ValidationResult()

    # Invoke method
    result = ValidationError(text=message_text_0, key=key_0) == ValidationError(text=message_text_0, key=key_0)

    # Verify
    assert result


# Generated at 2022-06-26 10:00:17.207031
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    schema = typesystem.Schema(type="object", properties={"foo": {"type": "string"}})
    errors = schema.validate_or_error({"foo": 123})
    if errors.error:
        error = {"foo": 123} == errors.error
        error2 = errors.error == {"foo": 123}



# Generated at 2022-06-26 10:00:26.969642
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message_0 = Message(text='test', code='test', key=('test',), index=[0], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    message_1 = Message(text='test', code='test', key=('test',), index=[0], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))

# Generated at 2022-06-26 10:00:33.589893
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    text_0 = "Message.__eq__(...) test error message"
    assert Message(text=text_0) == Message(text=text_0)


# Generated at 2022-06-26 10:00:47.378363
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    text_0 = __rand_int()
    code_0 = __rand_int()
    key_0 = __rand_int()
    start_position_0 = __rand_int()
    end_position_0 = __rand_int()
    message_0 = Message(text=text_0, code=code_0, key=key_0, start_position=start_position_0, end_position=end_position_0)
    text_1 = __rand_int()
    code_1 = __rand_int()
    key_1 = __rand_int()
    start_position_1 = __rand_int()
    end_position_1 = __rand_int()

# Generated at 2022-06-26 10:00:53.175612
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    text_0 = 'Text'
    code_0 = 'Code'
    index_0 = []
    position_0 = Position(1, 2, 3)
    message_0 = Message(text=text_0, code=code_0, position=position_0, index=index_0)
    other_0 = message_0
    bool_0 = message_0.__eq__(other_0)
    assert bool_0


# Generated at 2022-06-26 10:01:00.935673
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    pos_0 = Position(line_no=11, column_no=10, char_index=9)
    pos_1 = Position(line_no=12, column_no=13, char_index=10)
    message_0 = Message(text="message_0", start_position=pos_0, end_position=pos_1)
    message_1 = Message(text="message_1", start_position=pos_0, end_position=pos_1)
    bool_0 = message_0.__eq__(message_1)
    return bool_0


# Generated at 2022-06-26 10:01:08.979417
# Unit test for method __eq__ of class Message
def test_Message___eq__():

    # Ensure message passes equality test when it has the same properties
    message_0 = Message("message text", "message code", "message index")
    message_1 = Message("message text", "message code", "message index")
    is_equal = message_0 == message_1

    # Ensure message passes equality test when it has other properties not concerned with equality
    message_0 = Message("message text", "message code", "message index", start_position=Position(1,1,1))
    message_1 = Message("message text", "message code", "message index", end_position=Position(1,1,1))
    is_equal = message_0 == message_1

    # Ensure message fails equality test when it has different text
    message_0 = Message("message text")
    message_1 = Message("message text 1")
    is_equal = message

# Generated at 2022-06-26 10:01:21.952007
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    test_msg_0 = Message(text="x", code="", key=None, index=None, position=None, start_position=None, end_position=None)
    test_msg_1 = Message(text="y", code="", key=None, index=None, position=None, start_position=None, end_position=None)
    test_msg_2 = Message(text="y", code="", key=None, index=None, position=None, start_position=None, end_position=None)
    msg_bool_0 = test_msg_0.__eq__(test_msg_0)
    msg_bool_1 = test_msg_1.__eq__(test_msg_2)
    assert msg_bool_0 and msg_bool_1


# Generated at 2022-06-26 10:01:34.257519
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(1, 2, 3),
    )
    message_0_copy = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(1, 2, 3),
    )
    message_1 = Message(text="May not have more than 10 characters", code="max_length")
    message_2 = Message(text="Must be longer than 5 characters", code="min_length")
    result_0 = message_0 == message_0_copy
    result_0 = message_0 == message_1
    result_0 = message_0 == message_2


# Generated at 2022-06-26 10:01:35.670747
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    pass



# Generated at 2022-06-26 10:01:41.664393
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    eq_0 = Message(text="1", code="1", key=1) == Message(text="1", code="1", key=1)
    eq_1 = Message(text="2", code="2", key=2) == Message(text="2", code="2", key=3)


# Generated at 2022-06-26 10:01:51.044235
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # A Message object is created
    message_0 = Message()
    message_0.code = "max_length"
    message_0.text = "May not have more than 100 characters"
    message_0.start_position = Position()
    message_0.start_position.column_no = 5
    message_0.start_position.line_no = 10
    message_0.start_position.char_index = 9
    message_0.end_position = Position()
    # __eq__ is called on the Message object
    boolean_0 = message_0.__eq__(message_0)
    assert boolean_0


# Generated at 2022-06-26 10:02:03.292068
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    code_0 = Message().code
    text_0 = Message().text
    index_0 = Message().index
    start_position_0 = Message().start_position
    end_position_0 = Message().end_position
    other_0 = Message()
    other_0 = Message(code=code_0, text=text_0, index=index_0, start_position=start_position_0, end_position=end_position_0)
    dict_0 = Message().__dict__
    dict_0['messages']['code'] = code_0
    dict_0['messages']['text'] = text_0
    dict_0['messages']['index'] = index_0
    dict_0['messages']['start_position'] = start_position_0

# Generated at 2022-06-26 10:02:16.205836
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="") == Message(text="")
    assert Message(code="") == Message(code="")
    assert Message(index=[]) == Message(index=[])
    assert Message() == Message(
        text="", code="", index=[], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0),
    )
    assert Message(text="", code="") == Message(
        text="", code="", index=[], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0),
    )

# Generated at 2022-06-26 10:02:27.788940
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(
        text='The error message. \'May not have more than 100 characters\'',
        code='An optional error code, eg. max_length',
        key=None,
        index=None,
        start_position=Position(line_no=4, column_no=10, char_index=10),
        end_position=Position(line_no=6, column_no=10, char_index=22),
    )

# Generated at 2022-06-26 10:02:40.194478
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    f0 = Message(text='', code='', key=0, index=[], position=Position(0,0,0), start_position=Position(0,0,0), end_position=Position(0,0,0))
    f1 = Message(text='', code='', key=0, index=[], position=Position(0,0,0), start_position=Position(0,0,0), end_position=Position(0,0,0))
    f2 = Message(text='', code='', key=1, index=[], position=Position(0,0,0), start_position=Position(0,0,0), end_position=Position(0,0,0))

# Generated at 2022-06-26 10:02:45.307682
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    val_0 = (message1 == message2)
    assert val_0 == False


# Generated at 2022-06-26 10:02:57.841105
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    code_0 = 'foo'
    text_0 = 'bar'
    key_0 = 'baz'
    start_pos_0 = Position(0, 0, 0)
    message_0 = Message(text = text_0, code = code_0, key = key_0, start_position = start_pos_0, end_position = start_pos_0)
    code_1 = 'foo'
    text_1 = 'bar'
    key_1 = 'baz'
    start_pos_1 = Position(0, 0, 0)
    message_1 = Message(text = text_1, code = code_1, key = key_1, start_position = start_pos_1, end_position = start_pos_1)
    assert(message_0 == message_1)


# Generated at 2022-06-26 10:03:11.572541
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='p', code='o', key='p')
    message_1 = Message(text='a', code='b', key='c')
    message_2 = Message(text='d', code='e', key='f')
    message_3 = Message(text='g', code='h', key='i')
    message_4 = Message(text='p', code='o', key='p')
    message_5 = Message(text='j', code='k', key='l')
    message_6 = Message(text='m', code='n', key='o')
    message_7 = Message(text='p', code='o', key='p')
    message_8 = Message(text='p', code='o', key='p')
    boolean_0 = message_0.__eq__(message_4)
   

# Generated at 2022-06-26 10:03:25.052449
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    line_no_0: int = 0
    column_no_0: int = 0
    char_index_0: int = 0
    position_0 = Position( line_no = line_no_0, column_no = column_no_0, char_index = char_index_0)
    text_0: str = ""
    code_0: str = ""
    key_0: typing.Union[int, str] = 0
    index_0: typing.List[typing.Union[int, str]] = []
    start_position_0: typing.Any = 0
    end_position_0: typing.Any = 0

# Generated at 2022-06-26 10:03:31.078631
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="", code=None, key=None, index=None, start_position=None, end_position=None)
    message_1 = Message(text="", code=None, key=None, index=None, start_position=None, end_position=None)
    bool_0 = message_0 == message_1


# Generated at 2022-06-26 10:03:32.509677
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert True


# Generated at 2022-06-26 10:03:48.033266
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    method_name = Message.__eq__.__name__
    # Test 1
    text = "Message 1"
    code = "assertion_error"
    key = "message_key"
    message_0 = Message(text=text, code=code, key=key)
    message_1 = Message(text=text, code=code, key=key)
    assert message_0.__eq__(message_1) is True
    # Test 2
    text = "Message 1"
    code = "assertion_error"
    key = "message_key"
    message_0 = Message(text=text, code=code, key=key)
    message_1 = Message(text="Message 1", code="assertion_error", key="message_key")
    assert message_0.__eq__(message_1) is True


# Generated at 2022-06-26 10:03:57.464916
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    arg_1 = Message(text="error text", code="custom", key="index item")
    arg_2 = Message(text="error text", code="custom", key="index item")
    message_0 = Message.__eq__(arg_1, arg_2)
    str_0 = message_0.__str__()
    str_1 = message_0.__repr__()



# Generated at 2022-06-26 10:03:59.115935
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    test_Message___eq___0()
    test_Message___eq___1()


# Generated at 2022-06-26 10:04:03.651409
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Message.__eq__()
    input_0 = Message(text="", code="", index=[])
    input_1 = Message(text="", code="", index=[])
    output_0 = input_0.__eq__(input_1)
    assert isinstance(output_0, bool)
    assert output_0 is True


# Generated at 2022-06-26 10:04:08.235689
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test case 0
    message_0 = Message(text="foobar", key="foobar")
    message_1 = Message(text="foobar", key="foobar")
    bool_0 = message_0.__eq__(message_1)
    messages_0 = [message_0, message_1]
    assert len(set(messages_0)) == 1


# Generated at 2022-06-26 10:04:18.252573
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # case 1
    message_1 = Message(text="text_1", code="code_1", key="key_1", position="position_1")
    message_2 = Message(text="text_2", code="code_2", key="key_2", position="position_2")
    bool_result = message_1.__eq__(message_2)
    assert bool_result == False

    # case 2
    message_1 = Message(text="text_1", code="code_1", key="key_1", position="position_1")
    message_2 = Message(text="text_1", code="code_1", key="key_1", position="position_1")
    bool_result = message_1.__eq__(message_2)
    assert bool_result == True


# Generated at 2022-06-26 10:04:28.450329
# Unit test for method __eq__ of class Message
def test_Message___eq__():

    message_0_0 = (
        Message(
            text="f547c71f3faa43cc9d13702eab0bdc2e",
            code="ac77a6f1b6a7465f917a6ae69500768a",
            key="44ce8fddd69548e4b46bfa84e2ca8e4e",
        )
        == Message(
            text="f547c71f3faa43cc9d13702eab0bdc2e",
            code="ac77a6f1b6a7465f917a6ae69500768a",
            key="44ce8fddd69548e4b46bfa84e2ca8e4e",
        )
    )

# Generated at 2022-06-26 10:04:35.625122
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    text_0 = "val"
    code_0 = "val"
    key_0 = "val"
    position_0 = Position(0,0,0)
    message_0 = Message(text=text_0, code=code_0, key=key_0, position=position_0)
    message_1 = Message(text=text_0, code=code_0, key=key_0, position=position_0)
    bool_0 = message_0.__eq__(message_1)
    # Since the above asserts that bool_0 is True, there is no point in a further assertion.


# Generated at 2022-06-26 10:04:42.005278
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg_0 = Message(text="foo", code="baz", index=[2, 3, 1], position=Position(9, 9, 12))
    msg_1 = Message(text="foo", code="baz", index=[2, 3, 1], position=Position(9, 9, 12))
    bool_0 = msg_0.__eq__(msg_1)


# Generated at 2022-06-26 10:04:45.150118
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='', code='')
    message_1 = Message(text='', code='')
    message_0.__eq__(message_1)
