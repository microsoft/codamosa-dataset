

# Generated at 2022-06-26 09:59:31.749473
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    try:
        # Entry point for the test harness
        # Assigns the test method to a local variable to avoid warnings about
        # unassigned attributes
        test_method = BaseError.__eq__
        str_0 = 'text_0'
        str_1 = 'code_0'
        str_2 = 'key_0'
        int_0 = -2334
        position_0 = Position(int_0, int_0, int_0)
        message_0 = Message(str_0, str_1, str_2, position_0)
        list_0 = [message_0]
        # Invoke the test harness method
        result = test_method(list_0)
        # Test successful
        assert result

    except Exception as e:
        # Test failed
        print("Test failed:\n")
        print

# Generated at 2022-06-26 09:59:44.977154
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_1 = -2730
    position_1 = Position(int_1, int_1, int_1)
    str_1 = position_1.__repr__()
    int_2 = -1026
    position_2 = Position(int_2, int_2, int_2)
    str_2 = position_2.__repr__()
    assert True
    dict_0 = dict()
    BaseError.__eq__(dict_0)
    dict_1 = dict()
    ValidationError.__eq__(dict_1)
    ParseError.__eq__(dict_1)
    assert True
    dict_2 = dict()
    Message.__eq__(dict_2)
    assert True
    dict_3 = dict()
    Position.__eq__(dict_3)

# Generated at 2022-06-26 09:59:51.340770
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Create two instances
    message_0 = Message("", "", "")
    message_1 = Message("", "", "")

    # Call the method with two equal instances
    result = message_0.__eq__(message_1)

    assert result is None


# Generated at 2022-06-26 09:59:59.763410
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -2730
    position_0 = Position(int_0, int_0, int_0)
    message_0 = Message(int_0, int_0, int_0, int_0)
    message_0 = Message(int_0, int_0, int_0, int_0)
    message_0 = Message(int_0, int_0, int_0, int_0)
    message_0 = Message(int_0, int_0, int_0, int_0)
    message_0 = Message(int_0, int_0, int_0, int_0)
    message_0 = Message(int_0, int_0, int_0, int_0)
    message_0 = Message(int_0, int_0, int_0, int_0)
    message

# Generated at 2022-06-26 10:00:09.328515
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = 7539
    int_1 = -3750
    str_0 = "A$)>FRz}95"
    str_1 = "."
    emptyset_0 = set()
    tuple_0 = ()
    message_0 = Message(text=str_0, code="", index=[int_0, int_0], position=position_0)
    tuple_1 = (message_0, )
    tuple_2 = (tuple_1, str_0)
    list_0 = [tuple_1, int_0, str_1]
    list_1 = list(list_0)
    tuple_3 = (tuple_1, list_0, str_0, message_0)

# Generated at 2022-06-26 10:00:18.587591
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -2658
    position_0 = Position(int_0, int_0, int_0)
    str_0 = position_0.__repr__()
    position_1 = Position(int_0, int_0, int_0)
    str_1 = position_1.__repr__()
    message_0 = Message(text='', code='custom', position=position_0)
    str_2 = message_0.__repr__()
    str_3 = message_0.__repr__()
    message_1 = Message(text='', code='custom', index=[])
    str_4 = message_1.__repr__()
    str_5 = message_1.__repr__()
    message_list_0 = [message_0, message_1]
    base_error

# Generated at 2022-06-26 10:00:29.703204
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -2730
    int_1 = -2350
    int_2 = -2862
    int_3 = -9596
    int_4 = -5373
    str_0 = '_%'
    str_1 = '_8lE'
    str_2 = ')_`fE'
    str_3 = '_2gD$'
    str_4 = '_'
    str_5 = '_8lE'
    str_6 = ')_`fE'
    position_0 = Position(int_3, int_3, int_2)
    position_1 = Position(int_1, int_0, int_4)

# Generated at 2022-06-26 10:00:40.060877
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    int_0 = -2730
    position_0 = Position(int_0, int_0, int_0)
    int_1 = -9879
    position_1 = Position(int_1, int_1, int_1)
    message_0 = Message(text="text", code="code", key="key", position=position_0)
    message_1 = Message(text="text", code="code", key="key", start_position=position_1, end_position=position_1)
    assert not message_0.__eq__(message_1)



# Generated at 2022-06-26 10:00:49.931437
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    code_0 = 'code_0'
    start_position_0 = Position(70, 33, 6)
    end_position_0 = Position(70, 33, 6)
    key_0 = 'key_0'
    index_0 = ['index_0_0']
    text_0 = 'text_0'
    obj = Message(code = code_0, start_position = start_position_0, end_position = end_position_0, key = key_0, index = index_0, text = text_0)
    obj_other = Message(code = code_0, start_position = start_position_0, end_position = end_position_0, key = key_0, index = index_0, text = text_0)
    eq_(obj == obj_other, True)


# Generated at 2022-06-26 10:00:52.222460
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    int_0 = -2730
    # Get instance of Message
    message = Message()
    # Call __eq__
    message.__eq__(bool)


# Generated at 2022-06-26 10:01:00.750072
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -2730
    position_0 = Position(int_0, int_0, int_0)
    str_0 = position_0.__repr__()
    str_1 = str_0

    error = BaseError(text=str_0, code=str_1, key=int_0, position=position_0)

    if str_0 != str_1 and int_0 != int_0:
        raise Exception('Test failed')



# Generated at 2022-06-26 10:01:09.948750
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    '''
    An error raised when an object failed to validate.
    '''
    int_0 = -2730
    position_0 = Position(int_0, int_0, int_0)
    int_1 = -2730
    position_1 = Position(int_1, int_1, int_1)
    error = BaseError(position=position_0)
    base_error = BaseError(position=position_1)
    str_0 = base_error.__eq__(error)


# Generated at 2022-06-26 10:01:22.757555
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    """
    Tests BaseError.__eq__
    """
    int_0 = -2730
    position_0 = Position(int_0, int_0, int_0)
    str_0 = position_0.__repr__()
    int_1 = -2730
    position_1 = Position(int_1, int_1, int_1)
    str_1 = position_1.__repr__()
    message_0 = Message(str_0, str_0, int_0, position_0, position_0, position_0)
    message_1 = Message(str_1, str_1, int_1, position_1, position_1, position_1)

# Generated at 2022-06-26 10:01:34.585402
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -2730
    position_0 = Position(int_0, int_0, int_0)
    str_0 = position_0.__repr__()
    code = "custom"
    key = "custom"
    index = ["custom"]
    int_1 = -2730
    position_1 = Position(int_1, int_1, int_1)
    str_1 = position_1.__repr__()
    message_0 = Message(text="", code=code, key=key, index=index, position=position_0, start_position=position_1, end_position=position_1)
    message_1 = Message(text="", code=code, key=key, index=index, position=position_0, start_position=position_1, end_position=position_1)


# Generated at 2022-06-26 10:01:44.913530
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    with pytest.raises(Exception):
        int_0 = -2730
        int_1 = -1837
        position_0 = Position(int_0, int_1, int_1)
        position_1 = Position(int_1, int_1, int_0)
        str_0 = position_0.__repr__()
        int_3 = -1326
        position_2 = Position(int_1, int_0, int_0)
        position_3 = Position(int_0, int_0, int_1)
        int_4 = -1828
        message_0 = Message(str_0, str_0, int_3, position_2, position_3)
        message_1 = Message(str_0, str_0, int_3, position_3, position_2)
       

# Generated at 2022-06-26 10:01:46.261263
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # assert __eq__() == True
    assert True is True


# Generated at 2022-06-26 10:01:54.260250
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(
        text="", code="", key="", position=Position(0, 0, 0), messages=[]
    ).__eq__(BaseError(text="", code="", key="", position=Position(0, 0, 0), messages=[]))
    assert not BaseError(
        text="", code="", key="", position=Position(0, 0, 0), messages=[]
    ).__eq__(BaseError(
        text="", code="", key="", position=Position(0, 0, 0), messages=[]
    ))


# Generated at 2022-06-26 10:02:04.887292
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -2730
    str_1 = "test_BaseError___eq__"
    exc_0 = BaseError(text=str_1, code=str_1)
    exc_1 = ValidationError(text=str_1)
    exc_2 = ValidationError(text=str_1, code=str_1)
    exc_3 = exc_2
    exc_4 = BaseError(text=str_1, code=str_1)
    exc_5 = ValidationError(text=str_1, code=str_1)
    exc_6 = BaseError(messages=[Message()])
    exc_7 = BaseError(messages=[Message()])
    exc_8 = ValidationError(messages=[Message()])
    exc_9 = ValidationError(messages=[Message()])
    exc

# Generated at 2022-06-26 10:02:15.669173
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -2730
    position_0 = Position(int_0, int_0, int_0)
    str_0 = position_0.__repr__()
    message_0 = Message(text = str_0, code = str_0, key = str_0, index = [str_0], position = position_0)
    baseerror_0 = BaseError(text = str_0, code = str_0, key = str_0, position = position_0)
    baseerror_1 = BaseError(messages = [message_0])
    int_1 = baseerror_1.__eq__(baseerror_0)
    assert int_1


# Generated at 2022-06-26 10:02:27.395561
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    position_0 = Position(int, int, int)
    arr_0 = [-2501, -2011.5023, -0.9176024129776957, 3.259510665690499]
    str_0 = str(arr_0)
    position_1 = Position(str_0, int, str_0)
    arr_1 = [str_0, int, str_0]
    str_1 = str(arr_1)
    position_2 = Position(str_1, str_1, arr_0)
    arr_2 = [str_1, str_1, arr_0]
    str_2 = str(arr_2)
    position_3 = Position(str_2, arr_0, arr_2)

# Generated at 2022-06-26 10:02:42.556068
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -2730
    int_1 = -2251
    position_0 = Position(int_0, int_0, int_0)
    position_1 = Position(int_1, int_1, int_1)
    str_0 = position_0.__repr__()
    str_1 = position_1.__repr__()
    message_0 = Message(str_0)
    message_1 = Message(str_1)
    error_0 = ValidationError(messages=[message_0, message_1])
    assert error_0 == error_0
    int_2 = -2385
    int_3 = -2617
    position_2 = Position(int_2, int_2, int_2)

# Generated at 2022-06-26 10:02:55.044126
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = 9473
    int_1 = 1296
    int_2 = 1296
    int_3 = 9952
    int_4 = 9952
    str_0 = '__eq__'
    str_1 = '__eq__'
    position_0 = Position(int_3, int_3, int_3)
    position_1 = Position(int_3, int_3, int_3)
    position_2 = Position(int_4, int_4, int_4)
    message_0 = Message(str_0, 'custom', int_0, position_0, position_1)
    message_1 = Message(str_0, 'custom', int_0, position_0, position_2)

# Generated at 2022-06-26 10:03:08.321027
# Unit test for method __eq__ of class BaseError

# Generated at 2022-06-26 10:03:15.412692
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -2730
    position_0 = Position(int_0, int_0, int_0)
    message_0 = Message(str_0="str_0", code="code", index="index", position=position_0)
    message_1 = Message(str_0="str_0", code="code", index="index", position=position_0)
    validationerror = ValidationError(messages=[message_0, message_1])
    validationerror1 = ValidationError(messages=[message_0, message_1])

    assert validationerror == validationerror1


# Generated at 2022-06-26 10:03:28.794433
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -14
    int_1 = -11
    str_0 = str(int_0)
    str_1 = str(int_1)
    position_0 = Position(int_0, int_0, int_0)
    position_1 = Position(int_1, int_1, int_1)
    message_0 = Message(str_0, str_0, str_0, [str_0], position_0)
    message_1 = Message(str_1, str_1, str_1, [str_1], position_1)
    int_2 = -20
    int_3 = -9
    int_4 = -26
    str_2 = str(int_2)
    str_3 = str(int_3)
    str_4 = str(int_4)
   

# Generated at 2022-06-26 10:03:32.645308
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -2730
    position_0 = Position(int_0, int_0, int_0)
    str_0 = position_0.__repr__()
    print(str_0)


# Generated at 2022-06-26 10:03:38.451721
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = -2730
    str_0 = int_0.__repr__()
    str_1 = str_0.__str__()
    str_2 = str_1.__str__()
    message_0 = Message(str_2, str_1)
    assert message_0 == message_0


# Generated at 2022-06-26 10:03:48.531684
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    int_0 = 9261
    int_1 = 2
    int_2 = -2
    int_3 = -9261
    str_0 = str(int_0)
    int_4 = 0
    position_0 = Position(int_1, int_2, int_3)
    position_1 = Position(int_1, int_2, int_3)
    position_2 = Position(int_2, int_3, int_1)
    position_3 = Position(int_3, int_1, int_2)
    position_4 = Position(int_4, int_4, int_4)
    message_0 = Message(str_0, "custom", int_0, [], position_0, position_0)

# Generated at 2022-06-26 10:04:02.483139
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    def __eq___0():
        int_0 = -718
        int_1 = 2201
        int_2 = -4791
        int_3 = int_1 * int_2
        position_0 = Position(int_0, int_0, int_0)
        position_1 = Position(int_1, int_1, int_1)
        str_0 = position_0.__repr__()
        message_0 = Message(text=str_0, code=str_0, index=[int_0, int_0], position=position_0)
        message_1 = Message(text=str_0, code=str_0, index=[int_0, int_0], position=position_0)
        baseerror_0 = BaseError(messages=[message_0])
        baseerror_1 = BaseError

# Generated at 2022-06-26 10:04:12.303791
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    cases = [
    (
        BaseError(),
        BaseError(),
        True,
    ),
    (
        BaseError(),
        BaseError(text=""),
        False,
    ),
    (
        BaseError(),
        BaseError(code=""),
        False,
    ),
    (
        BaseError(),
        BaseError(key=0),
        False,
    ),
    (
        BaseError(),
        BaseError(position=Position(0, 0, 0)),
        False,
    ),
    (
        BaseError(),
        BaseError(messages=[]),
        True,
    ),
    ]
    for case in cases:
        src_0, other_0, expected_0 = case
        expected_exception_0 = False
        expected_exception_type_0 = None
