

# Generated at 2022-06-26 09:59:33.614019
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():

    test_case_0()


# Generated at 2022-06-26 09:59:42.828354
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    validation_result_0_its = iter(validation_result_0)
    validation_result_0_1 = next(validation_result_0_its)
    validation_result_0_2 = next(validation_result_0_its)
    assert validation_result_0_1 is validation_result_0.value
    assert validation_result_0_2 is validation_result_0.error


# Generated at 2022-06-26 09:59:47.470028
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    iter_0 = validation_result_0.__iter__()
    assert next(iter_0) is None
    assert next(iter_0) is None


# Generated at 2022-06-26 09:59:49.605000
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    assert 0 == 1


# Generated at 2022-06-26 09:59:50.917826
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    iter_0 = iter(validation_result_0)
    assert not hasattr(iter_0, '__next__')
    assert not hasattr(iter_0, 'next')


# Generated at 2022-06-26 09:59:55.878844
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    """
    Unit test for method __eq__ of class BaseError
    """
    validation_error_0 = ValidationError()
    validation_error_1 = ValidationError()
    if BaseError.__eq__(validation_error_0, validation_error_1) != True:
        raise RuntimeError("Test #0 failed")


# Generated at 2022-06-26 10:00:08.029487
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    assert tuple(validation_result_0) == (None, None)

    validation_result_0 = ValidationResult(value=None)
    assert tuple(validation_result_0) == (None, None)

    validation_result_0 = ValidationResult(value=None, error=None)
    assert tuple(validation_result_0) == (None, None)

    validation_result_0 = ValidationResult(value=None, error=ValidationError())
    assert tuple(validation_result_0) == (None, ValidationError())

    validation_result_0 = ValidationResult(error=None)
    assert tuple(validation_result_0) == (None, None)

    validation_result_0 = ValidationResult(error=ValidationError())
    assert tuple

# Generated at 2022-06-26 10:00:12.962626
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult(value=123)
    value = validation_result.value

    assert value is None
    assert next(iter(validation_result)) == 123
    assert next(iter(validation_result)) is False

# Generated at 2022-06-26 10:00:14.308991
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert True == True



# Generated at 2022-06-26 10:00:17.512323
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    assert isinstance(validation_result_0.__iter__(), typing.Iterator)


# Generated at 2022-06-26 10:00:27.759599
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message_0 = Message(text="text_0")
    message_1 = Message(text="text_1")
    validation_error_0 = ValidationError(messages=[message_0, message_1])
    validation_error_1 = ValidationError(messages=[message_0, message_1])
    assert validation_error_0 == validation_error_1


# Generated at 2022-06-26 10:00:32.518759
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    validation_result_0 = ValidationResult()
    validation_result_1 = ValidationResult()
    assert validation_result_0 == validation_result_1


# Generated at 2022-06-26 10:00:46.882821
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    #
    # Call actual function being tested.
    #
    msg1 = Message(text='May not have more than 100 characters')
    msg2 = Message(text='May not have more than 100 characters')

    assert msg1 == msg2
    assert msg1 is not msg2

    #
    # Call actual function being tested.
    #
    msg1 = Message(text='May not have more than 100 characters', code='max_length')
    msg2 = Message(text='May not have more than 100 characters', code='max_length')

    assert msg1 == msg2
    assert msg1 is not msg2

    msg1 = Message(text='May not have more than 100 characters', code='max_length')
    msg2 = Message(text='May not have more than 100 characters', code='max_length2')

    assert msg1 != msg2


# Generated at 2022-06-26 10:00:50.885358
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    arg_0 = BaseError()
    arg_1 = BaseError()
    result = arg_0.__eq__(arg_1)
    assert result is False


# Generated at 2022-06-26 10:00:57.666983
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg_0 = Message(text='foo', code='0', key='1')
    msg_1 = Message(text='foo', code='0', key='1')
    assert msg_0 == msg_1, "msg_0 = {}, msg_1 = {}".format(msg_0, msg_1)


# Generated at 2022-06-26 10:01:01.974726
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    with pytest.raises(AssertionError):
        BaseError() == BaseError() == None  # type: ignore


# Generated at 2022-06-26 10:01:09.252899
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    validation_error_0 = ValidationError()
    validation_error_1 = ValidationError()
    base_error_0 = BaseError(text=str())
    base_error_1 = BaseError(text=str())
    base_error_2 = BaseError(text=str())
    base_error_3 = BaseError(text=str())
    base_error_4 = BaseError(text=str())
    assert base_error_0 == base_error_1
    assert base_error_0 == validation_error_0
    assert base_error_0 == base_error_1
    assert base_error_0 == base_error_2
    assert base_error_0 == base_error_3
    assert base_error_0 == base_error_4
    assert base_error_0 == validation_error_1

# Generated at 2022-06-26 10:01:15.936894
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    validation_error_0 = ValidationError(text="text", code="code")
    validation_error_1 = ValidationError(text="text", code="code")
    result = validation_error_0 == validation_error_1
    assert result is True


# Generated at 2022-06-26 10:01:19.995588
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    q = ValidationError(
        text='Expected None found "foo"',
        code='type_error.null',
        key=''
    )
    q == q
    q == None


# Generated at 2022-06-26 10:01:24.737138
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    BaseError(text="test string", code="test code", key="test key") == BaseError(
        text="test string", code="test code", key="test key"
    )


# Generated at 2022-06-26 10:01:33.108346
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="failure", code="max_length")
    message_1 = Message(text="failure", code="max_length")
    message_2 = Message(text="failure", code="max_length")
    assert message_0 == message_1
    assert message_0 == message_2
    assert message_1 == message_2


# Generated at 2022-06-26 10:01:39.327181
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='', code='')
    message_1 = Message(text='', code='')
    message_2 = Message(text='', code='')
    assert message_0 == message_1
    assert not message_0 == message_2


# Generated at 2022-06-26 10:01:45.631299
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # The first Message instantiation here is equivalent to the Message instance in
    # test_Message___init__
    messages_0 = [
        Message(text="test_Message___eq__", code="custom", key=None, index=[])
    ]
    if messages_0 != [Message(text="test_Message___eq__", code="custom", key=None, index=[])]:
        assert False

    messages_1 = [Message(text="test_Message___eq__", code="custom", key=None, index=[])]
    if messages_1 != [Message(text="test_Message___eq__", code="custom", key=None, index=[])]:
        assert False



# Generated at 2022-06-26 10:01:55.260288
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Check __eq__ is reflexive
    t = Message(text="text")
    assert t == t
    assert not (t != t)
    # Check __eq__ is symmetric
    u = Message()
    assert (t == u) == (u == t)
    assert (t != u) == (u != t)
    # Check __eq__ is transitive
    v = Message()
    assert not ((t == u) and (u == v)) or (t == v)
    # Check __eq__ is consistent
    import random
    assert (t == u) == (t == u)
    t.text = "text"
    assert (t == u) == (t == u)


# Generated at 2022-06-26 10:01:59.307298
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text = "May not have more than 100 characters", code = "max_length", key = "username")
    message_1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message_0 == message_1



# Generated at 2022-06-26 10:02:01.432442
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:02:12.137922
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Constructor test for Message
    Message_instance_0 = Message(text="This is a test case.", code="test_case", key="test_key", start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=1, char_index=0), index=["test", "index"])
    Message_instance_1 = Message(text="This is a test case.", code="test_case", key="test_key", start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=1, char_index=0), index=["test", "index"])

# Generated at 2022-06-26 10:02:21.505807
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="", code=None, key=None, index=[], position=Position(line_no=0, column_no=0, char_index=0))
    message_1 = Message(text="", code=None, key=None, index=[], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))


# Generated at 2022-06-26 10:02:25.712031
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="text", code="code", index=[0])
    message_1 = Message(text="text", code="code", index=[0])
    message_1.__eq__(message_0)
    assert message_1 == message_0


# Generated at 2022-06-26 10:02:26.939594
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    pass


# Generated at 2022-06-26 10:02:37.625086
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    from typesystem.types import Message
    from typesystem.types import Position
    tester = Message(text='text', code='code', key='key', index=['index'], position=Position(1, 2, 3), start_position=Position(4, 5, 6), end_position=Position(4, 5, 6))
    other = Message(text='text', code='code', key='key', index=['index'], position=Position(1, 2, 3), start_position=Position(4, 5, 6), end_position=Position(4, 5, 6))
    assert tester==other


# Generated at 2022-06-26 10:02:44.791683
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="", code="", index=[])
    message_1 = Message(text="", code="", index=[])
    assert message_0 == message_1
    message_0 = Message(text="", code="", index=[])
    message_1 = Message(text="", code="", index=[])
    assert message_0 is not message_1
    message_0 = Message(text="", code="", index=[])
    message_1 = Message(text="", code="  ", index=[])
    assert message_0 != message_1
    message_0 = Message(text="", code="", index=[])
    message_1 = Message(text="1", code="", index=[])
    assert message_0 != message_1
    message_0 = Message(text="", code="", index=[])
    message_

# Generated at 2022-06-26 10:02:57.512926
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message(code='custom', text='', index=['_'])
    message_2 = Message(code='custom', text='', index=[0])
    message_3 = Message(code='custom', text='')
    message_4 = Message(index=[0])
    message_5 = Message(index=['_'])
    message_6 = Message(index=[1])
    message_7 = Message(text='')
    message_8 = Message(text='', index=[0])
    message_9 = Message(text='', index=['_'])
    message_10 = Message(text='', index=[1])

# Generated at 2022-06-26 10:03:11.226974
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="test message #0")
    message_1 = Message(text="test message #1")
    message_2 = Message(text="test message #2")
    message_3 = Message(text="test message #3")
    message_4 = Message(text="test message #4")
    message_5 = Message(text="test message #5")
    message_6 = Message(text="test message #6")
    message_7 = Message(text="test message #7")
    message_8 = Message(text="test message #8")
    message_9 = Message(text="test message #9")
    message_10 = Message(text="test message #10")
    message_11 = Message(text="test message #11")
    message_12 = Message(text="test message #12")
    message_13

# Generated at 2022-06-26 10:03:16.439488
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    a = Message(text='a', code='b', key='c', index=['d'], position=Position(1, 2, 3))
    b = Message(text='a', code='b', key='c', index=['d'], position=Position(1, 2, 3))
    assert a == b


# Generated at 2022-06-26 10:03:28.878276
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(
        text="", code="", key=None, start_position=None, end_position=None
    )
    message_1 = Message(
        text="", code="", key=None, start_position=None, end_position=None
    )
    message_2 = Message(
        text="", code="", key="", start_position=None, end_position=None
    )
    message_3 = Message(
        text="", code="", key=None, start_position=None, end_position=None
    )

    assert message_0 == message_1
    assert not message_0 == message_2
    assert message_0 == message_3


# Generated at 2022-06-26 10:03:41.570895
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text = 'a', code = 'b', key = 1, index = [2], position = Position(line_no = 3, column_no = 4, char_index = 5))
    message_1 = Message(text = 'c', code = 'd', key = 6, index = [7], position = Position(line_no = 8, column_no = 9, char_index = 10))
    message_2 = Message(text = 'e', code = 'a', key = 11, index = [12], position = Position(line_no = 13, column_no = 14, char_index = 15))
    message_3 = Message(text = 'f', code = 'b', key = 16, index = [17], position = Position(line_no = 18, column_no = 19, char_index = 20))

# Generated at 2022-06-26 10:03:49.150981
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # None
    message_1 = Message()
    message_2 = Message()
    assert message_1 == message_2
    # Strings
    message_1 = Message(text='Text 1')
    message_2 = Message(text='Text 2')
    assert message_1 != message_2
    # Codes
    message_1 = Message(text='Text 1', code='Code 1')
    message_2 = Message(text='Text 1', code='Code 2')
    assert message_1 != message_2
    # Keys
    message_1 = Message(text='Text 1', key='Key 1')
    message_2 = Message(text='Text 1', key='Key 2')
    assert message_1 != message_2
    # Positions
    message_1 = Message(text='Text 1', position=Position(1, 1, 1))


# Generated at 2022-06-26 10:03:55.808747
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="text", code="code", key=123, index=[1, 2, 3], position=Position(line_no=0, column_no=0, char_index=0), start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))
    message_1 = Message(text="text", code="code", key=123, index=[1, 2, 3], position=Position(line_no=0, column_no=0, char_index=0), start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))

# Generated at 2022-06-26 10:04:04.426679
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='(1, b, True)', code='custom', key='0')
    message_1 = Message(text='(1, b, True)', code='custom', key='x')
    assert not message_0 == message_1
    message_0.code = ''
    assert not message_0 == message_1
    message_0.code = 'custom'
    message_1.text = ''
    assert not message_0 == message_1
    message_1.text = '(1, b, True)'
    message_1.key = '0'
    assert message_0 == message_1
