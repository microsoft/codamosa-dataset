

# Generated at 2022-06-26 09:59:30.817369
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    for value_0, error_0 in validation_result_0:
        pass


# Generated at 2022-06-26 09:59:33.041971
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result = ValidationResult()
    assert [iter(validation_result)] == [iter(None)]


# Generated at 2022-06-26 09:59:35.675812
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Runs method and then checks __iter__ returns expected values
    assert ValidationResult().__iter__() == (None, None)

# Generated at 2022-06-26 09:59:37.692235
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="string", code="string", start_position=Position(1, 1, 1))
    message_1 = Message(text="string", code="string", start_position=Position(1, 1, 1))
    assert message_0 == message_1


# Generated at 2022-06-26 09:59:39.351927
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    validation_result_1 = ValidationResult(value=True, error=ValidationError())
    test_case_0()


# Generated at 2022-06-26 09:59:41.127910
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    list_0 = [x for x in validation_result_0]


# Generated at 2022-06-26 09:59:42.516843
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    test_case_0()



# Generated at 2022-06-26 09:59:47.862205
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    it_0 = validation_result_0.__iter__()

    try:
        next_0 = it_0.__next__()
        assert next_0 == None
    except StopIteration:
        pass



# Generated at 2022-06-26 09:59:54.396911
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no = 1, column_no = 1, char_index = 1)
    position_1 = Position(line_no = 1, column_no = 1, char_index = 1)
    if not position_0 == position_1:
        print(position_0, position_1)
        assert 0


# Generated at 2022-06-26 09:59:58.115985
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    assert list(validation_result_0.__iter__()) == [None, None]


# Generated at 2022-06-26 10:00:10.937865
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    def eq_by_message(got, expected, check_types=True):
        assert (isinstance(got, Message) and isinstance(expected, Message) and
           got.text == expected.text and
           got.code == expected.code and
           got.index == expected.index and
           got.start_position == expected.start_position and
           got.end_position == expected.end_position)
    message_0 = Message(text="Message text")
    message_1 = Message(text="Message text")
    message_2 = Message(text="Message text")
    assert message_0 == message_1
    assert message_1 == message_2
    assert message_0 == message_2
    message_3 = Message(text="Message text", code="Message code")

# Generated at 2022-06-26 10:00:14.510921
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="Hello world")
    message_1 = Message(text="Hello world")
    assert message_0 == message_1


# Generated at 2022-06-26 10:00:27.571260
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=0, column_no=1, char_index=2)
    position_0_0 = Position(line_no=0, column_no=1, char_index=2)
    position_1 = Position(line_no=0, column_no=0, char_index=2)
    position_2 = Position(line_no=1, column_no=1, char_index=2)
    position_3 = Position(line_no=1, column_no=0, char_index=1)
    position_4 = Position(line_no=1, column_no=0, char_index=2)
    position_5 = Position(line_no=1, column_no=0, char_index=3)

    assert position_0 == position_0_0

# Generated at 2022-06-26 10:00:36.768670
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='a', code='a', key='a', index=['a'], position='a', start_position='a', end_position='a')
    message_1 = Message(text='a', code='a', key='a', index=['a'], position='a', start_position='a', end_position='a')
    assert message_0 == message_1


# Generated at 2022-06-26 10:00:44.246439
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="abc", code="abc", key="abc", position="abc")
    message_0 = message_0 == None
    message_0 = message_0 == message_0
    message_0 = message_0 == "abc"


# Generated at 2022-06-26 10:00:50.601337
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Declaration of params
    text_0: str = "Custom error message 1"
    code_0: str = "custom_code"
    key_0: typing.Union[int, str] = "username"
    position_0: Position = Position(1, 4, 0)
    start_position_0: Position = Position(1, 1, 0)
    end_position_0: Position = Position(1, 5, 0)
    other_0: typing.Any = unittester_mock__Message_0()
    # Invoke method
    result: bool = Message(text=text_0, code=code_0, index=[key_0], position=position_0).__eq__(other=other_0)
    # Check the result
    assert result is False


# Generated at 2022-06-26 10:01:02.580830
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(
        line_no=1, column_no=2, char_index=3
    )
    position_1 = Position(
        line_no=1, column_no=2, char_index=3
    )
    position_2 = Position(
        line_no=1, column_no=2, char_index=4
    )
    position_3 = Position(
        line_no=1, column_no=3, char_index=3
    )
    position_4 = Position(
        line_no=2, column_no=2, char_index=3
    )
    assert (
        position_0 == position_1
    ), "Failed assertion: position_0 == position_1"

# Generated at 2022-06-26 10:01:12.572537
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="text", code="text", index=["text"])
    message_1 = Message(
        text="text",
        code="text",
        index=["text"],
        position=Position(
            line_no=1, column_no=1, char_index=1
        ),
    )
    message_2 = Message(
        text="text",
        code="text",
        index=["text"],
        position=Position(
            line_no=1, column_no=1, char_index=1
        ),
    )

# Generated at 2022-06-26 10:01:23.421460
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test in case a is an instance of Message
    # and b is an instance of Message
    # and a.text equals b.text
    # and a.code equals b.code
    # and a.index equals b.index
    # and a.start_position equals b.start_position
    # and a.end_position equals b.end_position
    a = Message(text="a", code="a", index=["a"], start_position=Position(1, 1, 2), end_position=Position(1, 1, 2))
    b = Message(text="a", code="a", index=["a"], start_position=Position(1, 1, 2), end_position=Position(1, 1, 2))
    is_equal_to_b = a == b
    expected_result = True
    assert is_equal_to_

# Generated at 2022-06-26 10:01:30.741323
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='test_text_0', code='test_code_0', key='test_key_0')
    message_1 = Message(text='test_text_1', code='test_code_1', key='test_key_1')
    result = message_0 == message_1
    assert result == False


# Generated at 2022-06-26 10:01:35.535830
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=0, column_no=0, char_index=0)
    position_1 = Position(line_no=0, column_no=0, char_index=0)
    assert position_0 == position_1



# Generated at 2022-06-26 10:01:40.140776
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='', code='custom', key='')
    message_1 = Message(text='', code='custom', key='')
    assert message_0 == message_1


# Generated at 2022-06-26 10:01:45.698138
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='0.3523062602058855', code='custom', position=Position(line_no=2, column_no=8, char_index=10), end_position=Position(line_no=2, column_no=11, char_index=13))
    message_1 = Message(text='0.3523062602058855', code='custom', position=Position(line_no=2, column_no=8, char_index=10), end_position=Position(line_no=2, column_no=11, char_index=13))
    assert message_0 == message_1


# Generated at 2022-06-26 10:01:53.324900
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos_0 = Position(line_no=10, column_no=12, char_index=14)
    pos_1 = Position(line_no=10, column_no=12, char_index=16)
    assert not pos_0.__eq__(pos_1)
    pos_1 = Position(line_no=10, column_no=12, char_index=14)
    assert pos_0.__eq__(pos_1)
    assert pos_1.__eq__(pos_0)


# Generated at 2022-06-26 10:01:56.471211
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='', code='', key='')
    message_1 = Message(text='', code='', key='')
    assert message_1 == message_0


# Generated at 2022-06-26 10:01:58.525521
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    value_0 = message_0 == message_1


# Generated at 2022-06-26 10:02:09.390313
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='text_0', code='code_0', start_position=Position(line_no=0, column_no=0, char_index=0))
    message_1 = Message(text='text_0', code='code_0', start_position=Position(line_no=0, column_no=0, char_index=0))
    message_2 = Message(text='text_0', code='code_0', position=Position(line_no=0, column_no=0, char_index=0))
    message_3 = Message(text='text_0', start_position=Position(line_no=0, column_no=0, char_index=0))

# Generated at 2022-06-26 10:02:22.695989
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert (Message(text="foo") == Message(text="foo", index=[0])) == True
    assert (Message(text="bar") == Message(text="bar", index=[0])) == True
    assert (Message(text="foo") == Message(text="bar", index=[0])) == False
    assert (
        Message(text="foo", index=[0])
        == Message(text="foo", index=[0, 1])
    ) == False
    assert (
        Message(text="foo", index=[1]) == Message(text="foo", index=[0])
    ) == False
    assert (
        Message(text="foo", index=[0]) == Message(text="bar", index=[0])
    ) == False
    assert (
        Message(text="foo") == Message(text="bar")
    ) == False

# Unit

# Generated at 2022-06-26 10:02:27.347516
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=1, column_no=1, char_index=1)
    position_1 = Position(line_no=1, column_no=1, char_index=1)
    r0 = position_0 == position_1
    assert r0 == True


# Generated at 2022-06-26 10:02:39.801494
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(
        text="",
        code="",
        key=None,
        index=None,
        position=Position(
            line_no=0,
            column_no=0,
            char_index=0,
        ),
        start_position=None,
        end_position=None,
    ) == Message(
        text="",
        code="",
        key=None,
        index=None,
        position=Position(
            line_no=0,
            column_no=0,
            char_index=0,
        ),
        start_position=None,
        end_position=None,
    )

# Generated at 2022-06-26 10:02:54.835961
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(
        line_no=0, column_no=0, char_index=0
    )
    position_1 = Position(
        line_no=0, column_no=0, char_index=0
    )
    position_2 = Position(
        line_no=0, column_no=0, char_index=0
    )
    assert position_0 == position_1
    assert position_1 == position_2
    assert position_0 == position_2
    position_3 = Position(
        line_no=1, column_no=0, char_index=0
    )
    assert not position_0 == position_3
    position_4 = Position(
        line_no=0, column_no=1, char_index=0
    )
    assert not position_0 == position

# Generated at 2022-06-26 10:03:07.415912
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="text_0", code="code_0", key="key_0", position=None)
    message_1 = Message(text="text_1", code="code_1", key="key_1", position=None)
    message_2 = Message(text="text_2", code="code_2", key="key_2", position=None)
    message_3 = Message(text="text_3", code="code_3", key="key_3", position=None)
    assert (message_0 == message_0) is True
    assert (message_0 == message_1) is True
    assert (message_0 == message_2) is True
    assert (message_0 == message_3) is True


# Generated at 2022-06-26 10:03:16.208631
# Unit test for method __eq__ of class Message

# Generated at 2022-06-26 10:03:29.647286
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="text_0", code="text_1", key="text_2")
    message_1 = Message(text="text_3", code="text_4", index=["text_5", "text_6"])
    message_2 = Message(text="text_3", code="text_4", index=["text_5", "text_6"])
    assert message_1 == message_2
    
    message_3 = Message(
        text="text_3",
        code="text_4",
        index=["text_5", "text_6"],
        position=Position(line_no=7, column_no=8, char_index=9),
    )
    assert message_1 != message_3
    

# Generated at 2022-06-26 10:03:42.034758
# Unit test for method __eq__ of class Message

# Generated at 2022-06-26 10:03:46.317987
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='code=max_length, key=username', code='max_length', key='username')
    message_1 = Message(text='code=min_length, key=username', code='min_length', key='username')
    assert message_0 == message_0
    assert not message_0 == message_1


# Generated at 2022-06-26 10:03:55.803746
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # 1. Arrange
    message_0 = Message(text="May not have more than 100 characters")
    message_1 = Message(text="May not have more than 100 characters")
    message_2 = Message(text="May not have more than 200 characters")

    # 2. Act
    result = message_0 == message_1
    result_2 = message_0 == message_2

    # 3. Assert
    assert result
    assert not result_2



# Generated at 2022-06-26 10:03:58.343102
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)

# Generated at 2022-06-26 10:04:00.261241
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    a = Position(1, 1, 1)
    b = Position(1, 1, 1)
    assert a == b



# Generated at 2022-06-26 10:04:05.982148
# Unit test for method __eq__ of class Message
def test_Message___eq__():

    # Unit test for Message.__eq__()
    message_0 = Message(text='', code='', key='', index=['', '', ''], position=Position(0, 0, 0))
    message_1 = Message(text='', code='', key='', index=['', '', ''], position=Position(0, 0, 0))
    assert message_0 == message_1


# Generated at 2022-06-26 10:04:15.128845
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    expected = True
    actual = Position(line_no=1, column_no=1, char_index=1) == Position(line_no=1, column_no=1, char_index=1)
    assert expected == actual, __fail_string(expected=expected, actual=actual)


# Generated at 2022-06-26 10:04:25.657012
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    line_no_0 = 1
    column_no_0 = 1
    char_index_0 = 1
    position_0 = Position(line_no_0, column_no_0, char_index_0)
    text_0 = 'text'
    code_0 = 'code'
    key_0 = 1
    index_0 = [1, 1, 1]
    start_position_0 = position_0
    end_position_0 = position_0
    message_0 = Message(text=text_0, code=code_0, key=key_0, index=index_0, position=position_0, start_position=start_position_0, end_position=end_position_0)

# Generated at 2022-06-26 10:04:32.220120
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    class_name = 'Position'
    # The first arg is an instance of Position,
    # and the second arg is an instance of typing.Any
    def test_0(arg_0: Position, arg_1: typing.Any):
        try:
            result = arg_0 == arg_1
        except Exception as e:
            msg = f'An exception was raised during the call to {class_name}.__eq__. Exception message: {str(e)}'
            raise Exception(msg)
        print(f"{class_name}.__eq__(arg_0, arg_1) returned {str(result)}")

# Generated at 2022-06-26 10:04:44.700149
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg_0 = Message(text="aa", code="bb")
    
    msg_1 = Message(text="aa", code="bb")

    assert msg_0 == msg_1
    
    msg_0 = Message(text="aa", code="bb")
    
    msg_1 = Message(text="aa", code="bb")

    assert msg_0 == msg_1
    
    msg_0 = Message(text="aa", code="bb")
    
    msg_1 = Message(text="aa", code="bb")

    assert msg_0 == msg_1
    
    msg_0 = Message(text="aa", code="bb")
    
    msg_1 = Message(text="aa", code="bb")

    assert msg_0 == msg_1
    
    msg_0 = Message(text="aa", code="bb")

# Generated at 2022-06-26 10:04:47.432369
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p0 = Position(line_no=1, column_no=2, char_index=3)
    p1 = Position(line_no=1, column_no=2, char_index=3)
    p0 == p1


# Generated at 2022-06-26 10:04:53.287556
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "not a Position"


# Generated at 2022-06-26 10:04:57.109270
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=1, char_index=0, column_no=0)
    assert position_0 == Position(line_no=1, char_index=0, column_no=0)


# Generated at 2022-06-26 10:05:01.800602
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=1, column_no=2, char_index=3)
    position_1 = Position(line_no=1, column_no=2, char_index=3)
    position_2 = Position(line_no=4, column_no=5, char_index=6)
    assert (position_0 == position_1) == True
    assert (position_0 == position_2) == False


# Generated at 2022-06-26 10:05:04.290018
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="", code=None, index=[])
    message_1 = Message(text="", code=None, index=[])
    assert message_0 == message_1



# Generated at 2022-06-26 10:05:12.406454
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    import sys
    import re
    class_name = "Message"
    func_name = "__eq__"
    class_obj = Message
    args = (r'text="this is a message"', r'code="custom"', r'index=[]')
    func_args = (r'message_1=Message(text="this is a message", code="custom", index=[])',
        r'message_2=Message(text="this is a message", code="custom", index=[])')
    res = "true"
    message_1 = Message(text="this is a message", code="custom", index=[])
    message_2 = Message(text="this is a message", code="custom", index=[])
    res_real = repr(message_1.__eq__(message_2))

# Generated at 2022-06-26 10:05:31.173247
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    from copy import deepcopy
    pos_0 = Position(line_no=1, column_no=2, char_index=3)
    pos_1 = Position(line_no=1, column_no=2, char_index=3)
    pos_2 = deepcopy(pos_1)
    pos_3 = Position(line_no=1, column_no=2, char_index=4)
    pos_4 = Position(line_no=2, column_no=2, char_index=3)
    pos_5 = Position(line_no=1, column_no=3, char_index=3)
    assert pos_0 == pos_1
    assert pos_0 == pos_2
    assert pos_0 != pos_3
    assert pos_0 != pos_4
    assert pos_0 != pos_5

# Generated at 2022-06-26 10:05:35.631569
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    validation_result_0 = Position(1, 2, 3)
    assert validation_result_0 == Position(1, 2, 3)


# Generated at 2022-06-26 10:05:41.661463
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    obj_0 = Position(line_no=5, column_no=5, char_index=5)
    obj_1 = Position(line_no=5, column_no=5, char_index=5)
    obj_2 = Position(line_no=5, column_no=5, char_index=5)
    assert obj_0 == obj_1
    assert obj_1 == obj_2
    assert obj_2 == obj_0
    obj_0 = Position(line_no=5, column_no=5, char_index=5)
    obj_1 = Position(line_no=5, column_no=5, char_index=5)
    obj_2 = Position(line_no=5, column_no=5, char_index=5)
    assert obj_0 == obj_1
    assert obj

# Generated at 2022-06-26 10:05:50.120898
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    t0 = Message(code="custom", index=[], text="some text", position=Position(line_no=1, column_no=2, char_index=3))
    t1 = Message(code="custom", index=[], text="some text", position=Position(line_no=1, column_no=2, char_index=3))
    t2 = Message(code="custom", index=[], text="some text2", position=Position(line_no=1, column_no=2, char_index=3))
    t3 = Message(code="custom", index=[], text="some text", position=Position(line_no=1, column_no=2, char_index=4))

# Generated at 2022-06-26 10:05:57.589336
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    """
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert not Position(1, 2, 3) == Position(1, 2, 4)
    assert not Position(1, 2, 3) == Position(1, 3, 3)
    assert not Position(1, 2, 3) == Position(2, 2, 3)
    assert not Position(1, 2, 3) == Position(1, 2, 3, 4)
    assert not Position(1, 2, 3) == {"1": 1, "2": 2, "3": 3}
    assert not Position(1, 2, 3) == 1
    assert not Position(1, 2, 3) == "abcd"
    """
    pass


# Generated at 2022-06-26 10:05:59.896886
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    first_message = Message(text="Message 0", code="code 0")
    second_message = Message(text="Message 0", code="code 0")
    assert first_message == second_message



# Generated at 2022-06-26 10:06:09.400084
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Case 0
    position_0 = Position(line_no=1, column_no=2, char_index=3)
    position_1 = Position(line_no=1, column_no=2, char_index=3)
    result_0 = position_0.__eq__(position_1)
    assert result_0 == True

    # Case 1
    position_2 = Position(line_no=1, column_no=2, char_index=4)
    result_1 = position_0.__eq__(position_2)
    assert result_1 == False

    # Case 2
    position_3 = 1
    result_2 = position_0.__eq__(position_3)
    assert result_2 == False

    # Case 3

# Generated at 2022-06-26 10:06:14.575193
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="", code=None, key=None, index=None, position=None, start_position=None, end_position=None)
    message_1 = Message(text="", code=None, key=None, index=None, position=None, start_position=None, end_position=None)
    assert message_0 == message_1


# Generated at 2022-06-26 10:06:20.559851
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # inputs
    position_0 = Position(line_no=3, column_no=1, char_index=3)
    other_0 = Position(line_no=3, column_no=2, char_index=3)

    # expected output
    expected_output = False

    # actual output
    actual_output = (position_0 == other_0)

    # compare outputs
    assert actual_output == expected_output, (actual_output, expected_output)


# Generated at 2022-06-26 10:06:28.526336
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='text_0', code='custom', index=[], start_position=None, end_position=None)
    message_1 = Message(text=None, code=None, index=[], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))



# Generated at 2022-06-26 10:06:44.969259
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="hello", code="ok", index=[5, 3], position=Position(1, 1, 2))
    message_1 = Message(text="hello", code="ok", index=[5, 3], position=Position(1, 1, 2))
    message_2 = Message(text="hello", code="ok", index=[5, 3], position=Position(1, 1, 2))
    message_3 = Message(text="hello", code="ok", index=[5, 3], position=Position(1, 1, 2))
    assert message_0 == message_1 == message_2 == message_3

# Generated at 2022-06-26 10:06:57.564460
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message0 = Message()
    message1 = Message()
    #
    # Test for equality when the input parameters are the same.
    #
    assert message0 == message1
    message0.text = "abc"
    message0.code = "abc"
    message0.index = [1, 2, 3]
    message0.start_position = Position(1, 2, 3)
    message0.end_position = Position(1, 2, 3)
    #
    # Test for equality when the input parameters are the same.
    #
    assert message0 == message1
    message1.text = "abc"
    #
    # Test for equality when the input parameters are the same.
    #
    assert message0 == message1
    message1.code = "abc"
    #
    # Test for equality when the input parameters are

# Generated at 2022-06-26 10:07:04.068168
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="Invalid property '@'. Valid properties are ['field1', 'field2']", code='invalid_property', index=['@'], start_position=Position(line_no=11, column_no=5, char_index=5))
    message_1 = Message(text="Invalid property '@'. Valid properties are ['field1', 'field2']", code='invalid_property', index=['@'], start_position=Position(line_no=11, column_no=5, char_index=5))
    assert message_0 == message_1


# Generated at 2022-06-26 10:07:12.508899
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text="hello", code="custom", key=None, index=None, position=Position(line_no=0, column_no=0, char_index=0))
    message_2 = Message(text="hello", code="custom", key=None, index=None, position=Position(line_no=0, column_no=0, char_index=0))
    assert message_1 == message_2


# Generated at 2022-06-26 10:07:14.731282
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg_0 = Message(text="")
    msg_1 = Message(text="")
    assert msg_0 == msg_1


# Generated at 2022-06-26 10:07:22.339349
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Setup for test
    msg_a_0 = Message(text='a', code='a', start_position=Position(1,1,1), end_position=Position(1,1,1))
    msg_a_1 = Message(text='a', code='a', start_position=Position(1,1,1), end_position=Position(1,1,1))
    msg_b_0 = Message(text='b', code='a', start_position=Position(1,1,1), end_position=Position(1,1,1))
    msg_b_1 = Message(text='b', code='a', start_position=Position(1,1,1), end_position=Position(1,1,1))

# Generated at 2022-06-26 10:07:27.836906
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="text", code="code", index=[])
    message_1 = Message(text="text", code="code", index=[])
    eq_0 = message_0 == message_1
    eq_1 = message_0 == message_0

    assert message_0 != message_0
    assert message_1 != message_1
    assert eq_0 == True
    assert eq_1 == True


# Generated at 2022-06-26 10:07:33.021205
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0_0 = Message(text="", code="", index=[])
    message_0_1 = Message(text="", code="", index=[])
    assert message_0_0 == message_0_1
    message_1_0 = Message(text="", code="", index=[])
    message_1_1 = Message(text="", code="", index=[])
    assert message_1_0 == message_1_1
    message_2_0 = Message(text="", code="", index=[])
    message_2_1 = Message(text="", code="", index=[])
    assert message_2_0 == message_2_1
    message_3_0 = Message(text="", code="", index=[])
    message_3_1 = Message(text="", code="", index=[])
    assert message_3

# Generated at 2022-06-26 10:07:38.500746
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Get the expected result
    message_0 = Message()
    message_1 = Message()
    expected_result_0 = message_0 == message_1

    # Get the actual result
    message_0 = Message()
    message_1 = Message()
    actual_result_0 = message_0 == message_1

    # Assert the expected result and actual result are equal
    assert expected_result_0 == actual_result_0


# Generated at 2022-06-26 10:07:46.146427
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message0 = Message(text="Hello")
    message1 = Message(text="Hello")
    message1.code = "custom"
    message2 = Message(text="Hello")
    message2.index.append("key1")
    message3 = Message(text="Hello")
    message3.start_position = Position(line_no=1, column_no=1, char_index=1)
    message3.end_position = Position(line_no=1, column_no=1, char_index=1)
    message4 = Message(text="Hello")
    message4.start_position = Position(line_no=1, column_no=1, char_index=1)
    message4.end_position = Position(line_no=2, column_no=2, char_index=2)
    assert message0 == message

# Generated at 2022-06-26 10:08:06.086624
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="Error", code="CODE", key="BAD_KEY")
    message_1 = Message(text="Error", code="CODE", key="BAD_KEY")
    message_2 = Message(text="Not an error", code="CODE", key="BAD_KEY")
    message_3 = Message(text="Error", code="NOT_CODE", key="BAD_KEY")
    message_4 = Message(text="Error", code="CODE", key="GOOD_KEY")
    message_5 = Message(text="Error", code="CODE", index=["BAD_KEY"])
    message_6 = Message(text="Error", code="CODE", index=["GOOD_KEY"])

# Generated at 2022-06-26 10:08:06.967990
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # TODO: Write this
    pass


# Generated at 2022-06-26 10:08:10.063366
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Initialize Message to test method
    test_method = Message()
    # Get expected value
    expected_value = NotImplemented
    # Invoke method
    result = test_method.__eq__(expected_value)
    # Check result
    assert result == expected_value


# Generated at 2022-06-26 10:08:16.759598
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(code="custom", text="")
    message_1 = Message(code="custom", text="")
    assert message_0 == message_1
    message_0 = Message(code="custom", text="", end_position=Position(1, 0, 1), start_position=Position(1, 0, 1))
    message_1 = Message(code="custom", text="", end_position=Position(1, 0, 1), start_position=Position(1, 0, 1))
    assert message_0 == message_1
    message_0 = Message(code="custom", index=[3], text="", end_position=Position(1, 0, 1), start_position=Position(1, 0, 1))

# Generated at 2022-06-26 10:08:23.551851
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='foo', code='baz', key=0)
    message_1 = Message(text='quux', code='qux', key=1)
    assert message_0 != message_1
    message_2 = Message(text='3.14', code='baz', key=0)
    assert message_0 != message_2
    message_3 = Message(text='foo', code='qux', key=0)
    assert message_0 != message_3
    message_4 = Message(text='foo', code='baz', key=1)
    assert message_0 != message_4
    return None


# Generated at 2022-06-26 10:08:31.564988
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='', code='nt:1', index=[], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))
    message_1 = Message(text='', code='nt:1', index=[], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))

# Generated at 2022-06-26 10:08:32.258078
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    pass


# Generated at 2022-06-26 10:08:40.597848
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    method = Message.__eq__
    instance = Message(text='', code=None, key=None, index=[], start_position=Position(line_no=0, column_no=0, char_index=0))
    other_0 = Message(text='', code=None, key=None, index=[], start_position=Position(line_no=0, column_no=0, char_index=0))
    other_1 = Message(text='0', code='0', key='0', index=['0'], start_position=Position(line_no=0, column_no=0, char_index=0))
    return_value_0 = method(instance, other_0)
    return_value_1 = method(instance, other_1)
    return_value_2 = method(instance, None)
    return_value

# Generated at 2022-06-26 10:08:47.956216
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="text", code="code", index=["index"], position=Position(
        line_no=1, column_no=1, char_index=1))
    assert message_0 == Message(text="text", code="code", index=["index"], position=Position(
        line_no=1, column_no=1, char_index=1))
    assert message_0 == Message(text="text", code="code", index=["index"], position=Position(
        line_no=1, column_no=1, char_index=1))
    assert message_0 == Message(text="text", code="code", index=["index"], position=Position(
        line_no=1, column_no=1, char_index=1))

# Generated at 2022-06-26 10:08:52.376555
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="Some error message")
    actual = message == message
    expected = True
    msg = "Expected: {}, Got: {}".format(expected, actual)
    assert actual == expected, msg
