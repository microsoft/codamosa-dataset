

# Generated at 2022-06-26 09:59:32.160686
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(int, int, int)
    bool_0 = position_0.__eq__(position_0)


# Generated at 2022-06-26 09:59:45.028987
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="Message(text=r, code=r)", code="Message(text=r, code=r)")
    message_1 = Message(text="Message(text=r, code=r)", code="Message(text=r, code=r)")
    bool_0 = message_0.__eq__(message_1)
    message_2 = Message(text="Message(text=r, code=r)", code="Message(text=r, code=r)")
    message_3 = Message(text="Message(text=r, code=r)", code="Message(text=r, code=r)")
    bool_1 = message_2.__eq__(message_3)

# Generated at 2022-06-26 09:59:55.005588
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no_0 = 0
    column_no_0 = 0
    char_index_0 = 0
    position_0 = Position(line_no_0, column_no_0, char_index_0)
    line_no_1 = 0
    column_no_1 = 0
    char_index_1 = 0
    position_1 = Position(line_no_1, column_no_1, char_index_1)
    boolean_0: bool = position_0.__eq__(position_1)


# Generated at 2022-06-26 10:00:03.371349
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="", code="", index=[], position=None, start_position=None, end_position=None)
    message_1 = Message(text="", code="", index=[], position=None, start_position=None, end_position=None)
    bool_0 = message_0.__eq__(message_1)


# Generated at 2022-06-26 10:00:16.290406
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    text_0 = 'Message.__eq__'
    code_0 = 'code_0'
    index_0: typing.List[typing.Union[int, str]] = ['index_0']
    start_position_0 = Position(line_no=10, column_no=10, char_index=10)
    end_position_0 = Position(line_no=20, column_no=20, char_index=20)
    message_0 = Message(text=text_0, code=code_0, index=index_0, start_position=start_position_0, end_position=end_position_0)
    text_1 = 'Message.__eq__'
    code_1 = 'code_1'
    index_1: typing.List[typing.Union[int, str]] = ['index_1']

# Generated at 2022-06-26 10:00:26.078723
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Line 0
    line_no = 0
    # Line 1
    column_no = 0
    # Line 2
    char_index = 0
    # Line 3
    position_0 = Position(line_no, column_no, char_index)
    # Line 4
    bool_0 = position_0.__eq__(position_0)
    # Line 5
    pass #type: typing.Any
    # Line 6
    pass #type: typing.Any


# Generated at 2022-06-26 10:00:38.982268
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text = "uY6g~h%", code = "max_length", index = ["first_name"])
    message_1 = Message(text = "I4k4.4y", code = "max_length", index = ["last_name"])
    message_2 = Message(text = "[1@k}Cd", code = "max_length", key = 4)
    message_3 = Message(text = "Rg&tFy{", code = "max_length", key = "max_length")
    message_4 = Message(text = ",", code = "max_length", index = ["my_dict"])
    message_5 = Message(text = "my_message", code = "max_length", index = ["my_dict"])

# Generated at 2022-06-26 10:00:44.869773
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pos_0 = Position(line_no = 5, column_no = 8, char_index = 4)
    pos_1 = Position(line_no = 1, column_no = 5, char_index = 3)
    boolean_0 = pos_0.__eq__(pos_1)



# Generated at 2022-06-26 10:00:47.665438
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(11, 9, 5)
    position_1 = Position(3, 4, 6)
    is_eq_0 = position_0.__eq__(position_1)


# Generated at 2022-06-26 10:01:00.715096
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    test_Message_0 = Message(
        text="Message (error) text.",
        code="Message code.",
        key=None,
        index=None,
        position=Position(line_no=0, column_no=0, char_index=0),
        start_position=None,
        end_position=None,
    )
    test_Message_1 = Message(
        text="Message (error) text.",
        code="Message code.",
        key=None,
        index=None,
        position=Position(line_no=0, column_no=0, char_index=0),
        start_position=None,
        end_position=None,
    )
    bool_0 = test_Message_0.__eq__(test_Message_1)


# Generated at 2022-06-26 10:01:10.094570
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="", code="", index=[])
    message_1 = Message(text="", code="", index=[])
    bool_0 = message_0.__eq__(message_1)


# Generated at 2022-06-26 10:01:21.516307
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text="", code="", index=[], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))
    message_2 = Message(text="", code="", index=[], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))
    bool_0 = message_1.__eq__(message_2)


# Generated at 2022-06-26 10:01:26.926514
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    message_0.__eq__(message_1)
    message_1.__eq__(message_0)
    message_1.__eq__(message_1)

# Generated at 2022-06-26 10:01:30.472439
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='', code='', key='')
    message_0.__eq__(message_0)


# Generated at 2022-06-26 10:01:35.452226
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = ValidationError()
    message_1 = Message()
    bool_0 = message_0.__eq__(message_1)


# Generated at 2022-06-26 10:01:45.013133
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    text_0 = "dummy"
    code_0 = "dummy"
    key_0 = "dummy"
    index_0 = "dummy"
    position_0 = "dummy"
    start_position_0 = "dummy"
    end_position_0 = "dummy"
    Message_0 = Message(text=text_0, code=code_0, key=key_0, index=index_0, position=position_0)
    Message_1 = Message(text=text_0, code=code_0, key=key_0, index=index_0, start_position=start_position_0, end_position=end_position_0)
    bool_0 = Message_0.__eq__(Message_1)


# Generated at 2022-06-26 10:01:49.867636
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="", code="", index=[], position=Position(0, 0, 0))
    message_1 = Message(text="", code="", index=[], position=Position(0, 0, 0))
    bool_0 = message_0.__eq__(message_0)

# Generated at 2022-06-26 10:01:54.350336
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='0', code='1', index=[2], start_position=3, end_position=4)
    message_1 = Message(text='5', code='1', index=[2], start_position=3, end_position=4)
    result_0 = message_0.__eq__(message_1)


# Generated at 2022-06-26 10:02:04.972805
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(
        text="Ante dapibus in porta ac consectetur ac.",
        code="mollis est non commodo luctus.",
        key=0,
        index=["integer"],
        position=Position(line_no=64, column_no=37, char_index=6437),
        start_position=Position(line_no=64, column_no=37, char_index=6437),
    )

# Generated at 2022-06-26 10:02:10.276921
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Setup and call method to test
    a__index_0 = []
    a_0 = Message(text="", code="custom", index=a__index_0)
    b_0 = Message(text="", code="custom")
    result = a_0.__eq__(b_0)

    # Assert
    assert result == True
