

# Generated at 2022-06-26 09:59:24.188548
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    for target in validation_result_0:
        pass


# Generated at 2022-06-26 09:59:36.024199
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert True
    validation_result_0 = ValidationResult()
    lst_0 = list(validation_result_0)
    assert isinstance(lst_0, list)
    assert len(lst_0) == 2
    assert lst_0[0] is None
    assert lst_0[1] is None
    validation_result_1 = ValidationResult(value=2)
    lst_1 = list(validation_result_1)
    assert isinstance(lst_1, list)
    assert len(lst_1) == 2
    assert lst_1[0] == 2
    assert lst_1[1] is None
    validation_result_2 = ValidationResult(error=ValidationError(text="a"))
    lst_2 = list(validation_result_2)

# Generated at 2022-06-26 09:59:40.542744
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Validating arguments of method __eq__
    # Calling method __eq__
    try:
        BaseError.__eq__(None)
    except:
        print("Exception when calling method __eq__")


# Generated at 2022-06-26 09:59:42.819705
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    for validation_result_1 in validation_result_0:
        pass
    validation_result_0 = ValidationResult(value=None)
    validation_result_0 = ValidationResult(error=ValidationError())


# Generated at 2022-06-26 09:59:47.469786
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult(value=3.14)
    validation_result_1 = ValidationResult(error=ValidationError(text="nope", code="no_way"))


# Generated at 2022-06-26 09:59:52.325053
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_1 = ValidationResult()
    iterator_0 = validation_result_1.__iter__()
    value_of_iter_0 = next(iterator_0)
    

# Generated at 2022-06-26 09:59:54.311760
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    for _ in validation_result_0:
        pass


# Generated at 2022-06-26 09:59:58.048181
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    assert validation_result_0.__iter__() == (None, None)


# Generated at 2022-06-26 10:00:03.072452
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    val_0 = ValidationError(code="custom", text="inline error")
    val_1 = ValidationError(code="custom", text="inline error")
    assert val_0 == val_1


# Generated at 2022-06-26 10:00:06.033793
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    for x in validation_result_0:
        print(x)
        print(float(x))
        print(str(x))


# Generated at 2022-06-26 10:00:15.811793
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=int(), column_no=int(), char_index=int())
    position_1 = Position(line_no=int(), column_no=int(), char_index=int())
    boole_0 = position_0.__eq__(position_1)


# Generated at 2022-06-26 10:00:21.122918
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    p0 = Position(line_no=1, column_no=1, char_index=1)
    p1 = Position(line_no=1, column_no=1, char_index=1)
    eq_0 = p0 == p1


# Generated at 2022-06-26 10:00:30.745036
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Setup
    message_0 = Message(text='message_0', code='code', index=['index'])
    message_1 = Message(text='message_0', code='code', index=['index'])
    message_4 = Message(text='message_4', code='code', index=['index'])
    # Test first case
    base_error_0 = BaseError(messages=[message_0])
    base_error_1 = BaseError(messages=[message_1])
    assert base_error_0 == base_error_1
    # Test second case
    base_error_2 = BaseError(messages=[message_0])
    base_error_3 = BaseError(messages=[message_4])
    assert not base_error_2 == base_error_3
    

# Generated at 2022-06-26 10:00:40.174625
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message_0 = Message(text='foo', code='min_length', key='bar')
    error_0 = ValidationError(messages=[message_0])
    message_1 = Message(text='foo', code='min_length', index=['bar'])
    error_1 = ValidationError(messages=[message_1])
    result_0 = error_0.__eq__(error_1)
    message_2 = Message(text='foo', code='min_length', index=['baz'])
    error_2 = ValidationError(messages=[message_2])
    result_1 = error_1.__eq__(error_2)
    message_3 = Message(text='foo', key='bar')
    error_3 = ValidationError(messages=[message_3])
    result_2 = error_3

# Generated at 2022-06-26 10:00:47.866924
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    local_object_0 = Position(0, 0, 0)
    local_object_1 = Position(0, 0, 0)
    if (local_object_0 == local_object_1):
        pass

    local_object_0 = Position(0, 0, 0)
    local_object_1 = Position(0, 0, 0)
    if (local_object_0 == local_object_1):
        pass


# Generated at 2022-06-26 10:01:00.784452
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    try:
        message_0 = Message(text = '', code = 'custom')
        message_1 = Message()
        assert message_0 == message_1
    except AssertionError:
        assert False

    try:
        message_2 = Message(text = '', code = 'custom')
        message_3 = Message()
        assert message_2 == message_3
    except AssertionError:
        assert False

    try:
        message_4 = Message(code = 'custom')
        message_5 = Message()
        assert message_4 == message_5
    except AssertionError:
        assert False


# Generated at 2022-06-26 10:01:08.979161
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no_0 = int.from_bytes(b"\x03", "big")
    column_no_0 = -1281455850
    char_index_0 = -806789709
    position_0 = Position(line_no_0, column_no_0, char_index_0)
    bool_0 = position_0.__eq__(position_0)
    assert bool_0 is True
    line_no_1 = int.from_bytes(b"\n", "big")
    column_no_1 = 1194033550
    char_index_1 = -1447102143
    position_1 = Position(line_no_1, column_no_1, char_index_1)
    bool_1 = position_0.__eq__(position_1)
    assert bool_1 is True

# Generated at 2022-06-26 10:01:15.007804
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    validation_error = ValidationError()
    validation_error_0 = ValidationError()
    bool_0 = validation_error.__eq__(validation_error_0)
    assert (bool_0 == True)


# Generated at 2022-06-26 10:01:21.934123
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message_0_0 = Message(text="Hello", code="hello", index=[])
    message_0_1 = Message(text="World", code="world", index=[0])
    message_0_2 = Message(text="Goodbye", code="goodbye", index=[0, "name"])
    validation_error_0 = ValidationError(messages=[message_0_0, message_0_1, message_0_2])
    message_1_0 = Message(text="Hello", code="hello", index=[])
    message_1_1 = Message(text="World", code="world", index=[0])
    message_1_2 = Message(text="Goodbye", code="goodbye", index=[0, "name"])

# Generated at 2022-06-26 10:01:31.262257
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    BaseError_0 = BaseError(text='text_0')
    BaseError_1 = BaseError(text='text_1')
    BaseError_2 = BaseError(text='text_0')
    int_0 = BaseError_0.__eq__(BaseError_0)
    int_1 = BaseError_0.__eq__(BaseError_1)
    int_2 = BaseError_0.__eq__(BaseError_2)


# Generated at 2022-06-26 10:01:40.215683
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(1,1,1)
    position_1 = Position(1,1,1)
    bool_0 = position_0.__eq__(position_1)
    assert (bool_0 == True)


# Generated at 2022-06-26 10:01:43.173519
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    arg_0 = Position(2, 3, 4)
    arg_1 = Position(2, 3, 4)
    result = arg_0.__eq__(arg_1)
    assert(result == True)


# Generated at 2022-06-26 10:01:53.198961
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=0, column_no=0, char_index=100)
    bool_0 = position_0.__eq__(position_0)

# Generated at 2022-06-26 10:01:57.415562
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(2,5,5)
    assert not position_0.__eq__(1)
    assert not position_0.__eq__(Position(0,0,0))
    assert position_0.__eq__(Position(2,5,5))


# Generated at 2022-06-26 10:02:02.129890
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    class_0 = Position(
        line_no=2, column_no=3, char_index=4
    )
    class_1 = Position(
        line_no=2, column_no=3, char_index=4
    )
    bool_0 = class_0.__eq__(class_1)


# Generated at 2022-06-26 10:02:03.067370
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    test_case_0()


# Generated at 2022-06-26 10:02:04.533583
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pass



# Generated at 2022-06-26 10:02:08.986733
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=0, column_no=0, char_index=0)
    position_1 = Position(line_no=0, column_no=0, char_index=0)
    boolean_0 = position_0.__eq__(position_1)


# Generated at 2022-06-26 10:02:20.411554
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no_0 = 0
    column_no_0 = 0
    char_index_0 = 0
    position_0 = Position(line_no=line_no_0, column_no=column_no_0, char_index=char_index_0)
    line_no_1 = 0
    column_no_1 = 0
    char_index_1 = 0
    position_1 = Position(line_no=line_no_1, column_no=column_no_1, char_index=char_index_1)
    bool_0 = position_0.__eq__(position_1)


# Generated at 2022-06-26 10:02:29.640776
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test for method __eq__ of class Position
    # Assert expected: True
    assert True
    str_0 = "a"
    str_1 = str_0
    str_2 = "b"
    str_2 = "c"
    str_2 = str_0
    bool_0 = str_0 == str_1
    # Assert expected: True
    assert bool_0
    bool_1 = str_2 == str_1
    # Assert expected: True
    assert bool_1
    # Assert expected: True
    assert bool_0 == bool_1
    bool_2 = bool_0 == bool_1
    # Assert expected: True
    assert bool_2
    bool_3 = bool_2 == bool_0
    # Assert expected: True
    assert bool_3
    bool_4

# Generated at 2022-06-26 10:02:41.081835
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no_0 = 539
    column_no_0 = 913
    char_index_0 = 18
    position_0 = Position(line_no_0, column_no_0, char_index_0)
    line_no_1 = 681
    column_no_1 = 512
    char_index_1 = 913
    position_1 = Position(line_no_1, column_no_1, char_index_1)
    bool_0 = position_0.__eq__(position_1)


# Generated at 2022-06-26 10:02:43.477466
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(1, 2, 3)
    print(position_0 != None)
    print(position_0 == None)


# Generated at 2022-06-26 10:02:53.512975
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no_0 = int()
    column_no_0 = int()
    char_index_0 = int()
    position_0 = Position(line_no_0, column_no_0, char_index_0)
    line_no_1 = int()
    column_no_1 = int()
    char_index_1 = int()
    position_1 = Position(line_no_1, column_no_1, char_index_1)
    bool_0 = position_0.__eq__(position_1)
    assert bool_0


# Generated at 2022-06-26 10:03:06.809636
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    arg_0 = Position(0, 0, 0)
    arg_1 = None
    with pytest.raises(TypeError):
        Position(0, 0, 0).__eq__(arg_1)
    line_no_0 = 0
    column_no_0 = 0
    char_index_0 = 0
    arg_2 = Position(line_no_0, column_no_0, char_index_0)
    ret_0 = Position(0, 0, 0).__eq__(arg_2)
    line_no_1 = 0
    column_no_1 = 0
    char_index_1 = 0
    arg_3 = Position(line_no_1, column_no_1, char_index_1)

# Generated at 2022-06-26 10:03:09.821434
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    v = Position(0, 0, 0)
    v_1 = Position(1, 1, 1)
    r = v == v_1


# Generated at 2022-06-26 10:03:15.512752
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no_1 = 817
    column_no_1 = 532
    char_index_1 = -201
    pos_0 = Position(line_no_1, column_no_1, char_index_1)
    line_no_2 = 602
    column_no_2 = 206
    char_index_2 = -869
    pos_1 = Position(line_no_2, column_no_2, char_index_2)
    condition_0 = pos_0 == pos_1


# Generated at 2022-06-26 10:03:22.158537
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Construct two equal objects
    position_0 = Position(line_no=0, column_no=17, char_index=9)
    position_1 = Position(line_no=0, column_no=17, char_index=9)

    # Assert the two are equal
    assert position_0 == position_1


# Generated at 2022-06-26 10:03:24.317097
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    expected = bool
    actual = Position(None, None, None).__eq__()
    assert expected == actual


# Generated at 2022-06-26 10:03:32.646132
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no = 0
    column_no = 0
    char_index = 0
    position_0 = Position(line_no=line_no, column_no=column_no, char_index=char_index)
    line_no = 0
    column_no = 0
    char_index = 0
    position_1 = Position(line_no=line_no, column_no=column_no, char_index=char_index)
    bool_0 = position_0.__eq__(position_1)


# Generated at 2022-06-26 10:03:43.206244
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0_0 = Position(1, 1, 1)
    position_0_1 = Position(1, 1, 1)
    position_0_2 = Position(2, 2, 2)
    position_0_3 = Position(1, 2, 1)
    position_0_4 = Position(1, 1, 2)
    position_0_5 = Position(1, 1, 1)
    position_0_6 = Position(2, 2, 2)
    position_1_0 = Position(1, 1, 1)
    position_1_1 = Position(1, 1, 1)
    position_1_2 = Position(2, 2, 2)
    position_1_3 = Position(1, 2, 1)
    position_1_4 = Position(1, 1, 2)