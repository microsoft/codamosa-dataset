

# Generated at 2022-06-26 09:59:25.806128
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert ParseError() == ParseError()


# Generated at 2022-06-26 09:59:35.456496
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(code='0', index=['index'], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=1, column_no=1, char_index=2), text='text')
    message_1 = Message(code='1', index=['index'], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1), text='text')
    assert message_0 != message_1



# Generated at 2022-06-26 09:59:41.781057
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    my_val_error = ValidationError()
    results = ValidationResult(error=my_val_error)
    results_iter = iter(results)
    assert results_iter.__next__() == None
    assert results_iter.__next__() == my_val_error


# Generated at 2022-06-26 09:59:46.564843
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Initialization of variables
    value = {'name': 'Testers', 'interests': ['testing', 'testing']}
    error = error = ValidationError([Message(text="Value is invalid", code='invalid')])
    ValidationResult_instance = ValidationResult(value=value, error=error)

# Generated at 2022-06-26 09:59:58.115204
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m = Message(text = 'text_0', code = 'code_0', key = 'key_0', index = ['index_0_0', 'index_0_1'], position = Position(line_no = 0, column_no = 0, char_index = 0))
    m_eq = Message(text = 'text_1', code = 'code_1', key = 'key_1', index = ['index_1_0', 'index_1_1'], position = Position(line_no = 1, column_no = 1, char_index = 1))

# Generated at 2022-06-26 10:00:00.470952
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    Case:
        __iter__
    """
    v = ValidationResult(value=1)
    assert list(v) == [1]
    v = ValidationResult(error=ValidationError())
    assert list(v) == []


# Generated at 2022-06-26 10:00:02.181597
# Unit test for constructor of class BaseError
def test_BaseError():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-26 10:00:11.495312
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    parse_error_1 = ParseError(
        text='The input is not valid JSON.',
        code="invalid_json",
        position=Position(line_no=1, column_no=1, char_index=0)
    )
    parse_error_2 = ParseError(
        text='The input is not valid JSON.',
        code="invalid_json",
        position=Position(line_no=1, column_no=1, char_index=0)
    )
    parse_error_3 = ValidationError(
        text='The input is not valid JSON.',
        code="invalid_json",
        position=Position(line_no=1, column_no=1, char_index=0)
    )
    assert not parse_error_

# Generated at 2022-06-26 10:00:13.434278
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError().__eq__(BaseError()) == True


# Generated at 2022-06-26 10:00:19.555368
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    text = 'SomeError'
    code = 'aCode'
    key = 'aKey'
    msg = Message(text=text, code=code, key=key)
    msg_dict = {msg.key: msg.text}
    base_object = BaseError(messages=[msg])
    assert msg in base_object.messages()
    assert msg_dict == base_object._message_dict
    assert base_object.text == text
    assert base_object.code == code
    assert base_object.index == msg.index
    assert base_object.key == msg.key
    assert base_object.text == text
    assert base_object.code == code
    assert msg_dict == base_object._message_dict
    assert msg == base_object.message


# Generated at 2022-06-26 10:00:29.721697
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1

    message_2 = Message(text="foo")
    assert not message_0 == message_2

    message_3 = Message(text="foo", code="bar")
    assert not message_2 == message_3

    message_4 = Message(text="foo", key="bar")
    assert not message_2 == message_4

    message_5 = Message(text="foo", index=["a"])
    assert not message_2 == message_5

    message_6 = Message(text="foo", position=Position(0, 0, 0))
    assert not message_2 == message_6

    message_7 = Message(text="foo", start_position=Position(0, 0, 0))
    assert not message_2 == message_7

# Generated at 2022-06-26 10:00:31.050782
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    parse_error_0 = ParseError()
    assert parse_error_0.__repr__() == "ParseError(text='', code='custom')"


# Generated at 2022-06-26 10:00:46.298361
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    u"""BaseError.__eq__()"""
    # AssertionError: ParseError not equal to ValidationError: <ParseError()> != <ValidationError()>
    parse_error_0 = ParseError()
    validation_error_0 = ValidationError()
    try:
        assert parse_error_0 == validation_error_0
    except AssertionError as exc:
        print(
            f"AssertionError: {type(parse_error_0).__name__} not equal to {type(validation_error_0).__name__}: {parse_error_0!r} != {validation_error_0!r}"
        )
    # AssertionError: ValidationError not equal to ParseError: <ValidationError()> != <ParseError()>

# Generated at 2022-06-26 10:00:51.875784
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError(text="", code=None, key=None, position=None, messages=None)
    parse_error_1 = ParseError(text="", code=None, key=None, position=None, messages=None)
    assert parse_error_0 == parse_error_1



# Generated at 2022-06-26 10:00:57.712267
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # msg is of class Message.
    msg = Message(text="This is an error message")
    # error is of class ValidationError
    error = ValidationError(messages=[msg])
    assert str(error) == "This is an error message"



# Generated at 2022-06-26 10:01:01.972942
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error_0 = BaseError()

    # Test case: str(error)
    assert str(error_0) == "{}"


# Generated at 2022-06-26 10:01:11.212875
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    class_name = "BaseError"
    messages = [Message(text="year_birth")]
    BaseError.__init__(BaseError(), text="year_birth", code=None, key=None)
    assert_equal(BaseError.__str__(BaseError()), "year_birth")
    BaseError.__init__(BaseError(), text=None, code=None, key=None, messages=messages)
    assert_equal(BaseError.__str__(BaseError()), "{'year_birth': 'year_birth'}")

test_case_0()
test_BaseError___str__()

# Generated at 2022-06-26 10:01:16.901828
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    a0 = ParseError()
    assert a0.__repr__() == "ParseError([])"
    a1 = ValidationError()
    assert a1.__repr__() == "ValidationError([])"



# Generated at 2022-06-26 10:01:19.513119
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:01:21.783929
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(0, 0, 0) == Position(0, 0, 0)



# Generated at 2022-06-26 10:01:34.836514
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg_0 = Message(text='foo', code='bar', index=[1,2,3])
    msg_1 = Message(text='foo', code='bar', index=[1,2,3])
    msg_2 = Message(text='foo', code='bar', index=[3,2,1])
    msg_3 = Message(text='foo', code='baz', index=[1,2,3])
    msg_4 = Message(text='baz', code='bar', index=[1,2,3])
    assert (msg_0 == msg_1)
    assert not (msg_0 == msg_2)
    assert not (msg_0 == msg_3)
    assert not (msg_0 == msg_4)
  

# Generated at 2022-06-26 10:01:38.200482
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg = Message(text = "test")
    msg2 = Message(text = "test")
    assert msg == msg2


# Generated at 2022-06-26 10:01:43.555505
# Unit test for method __eq__ of class Message
def test_Message___eq__():
   assert Message(text="A", code="B") == Message(text="A", code="B")
   assert Message(text="A", code="B") != Message(text="C", code="D")
   assert Message(text="A", code="B") != Message(text="A", code="C")
   assert Message(text="A", code="B") != Message(text="C", code="B")


# Generated at 2022-06-26 10:01:54.437258
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=5339, column_no=7822, char_index=5339)
    other_0 = position_0
    bool_0 = position_0.__eq__(other_0)
    assert bool_0 is True

    position_1 = Position(line_no=7915, column_no=609, char_index=609)
    other_1 = position_1
    bool_1 = position_1.__eq__(other_1)
    assert bool_1 is True

    position_2 = Position(line_no=3844, column_no=9558, char_index=9558)
    other_2 = position_2
    bool_2 = position_2.__eq__(other_2)
    assert bool_2 is True


# Generated at 2022-06-26 10:02:04.973436
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    parse_error_0 = ParseError()
    assert repr(parse_error_0) == "ParseError()"
    parse_error_1 = ParseError(text="This is error text", code="error_code")
    assert repr(parse_error_1) == "ParseError(text=\'This is error text\', code=\'error_code\')"
    parse_error_2 = ParseError(messages=[Message(text="Message text 1", code="code_1", key="key_1"), Message(text="Message text 2", code="code_2", key="key_2")])

# Generated at 2022-06-26 10:02:10.791926
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    parse_error_1 = ParseError()
    parse_error_2 = ParseError()
    assert parse_error_0 == parse_error_1
    assert parse_error_1 == parse_error_0
    assert parse_error_0 != parse_error_2
    assert parse_error_2 != parse_error_0


# Generated at 2022-06-26 10:02:12.856528
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    BaseError.__eq__(parse_error_0, None)


# Generated at 2022-06-26 10:02:18.862201
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    class_name = "BaseError"
    messages = '([], "m")'
    error = BaseError(messages=messages)
    assert error.__repr__() == f"{class_name}({messages})"



# Generated at 2022-06-26 10:02:29.212274
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    parse_error_0 = ParseError()
    parse_error_0_text = parse_error_0.messages()[0].text
    parse_error_0_code = parse_error_0.messages()[0].code
    parse_error_1 = ParseError()
    parse_error_2 = ParseError()
    message = Message(text=parse_error_0_text, code=parse_error_0_code, key='key')
    assert message == Message(text=parse_error_0_text, code=parse_error_0_code, key='key')
    assert message != Message(text=parse_error_0_text, code=parse_error_0_code, key='key1')

# Generated at 2022-06-26 10:02:40.878801
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0_0 = Message(text="message_0_text", code="message_0_code", key="message_0_key", index=["message_0_index"], position="message_0_position", start_position="message_0_start_position", end_position="message_0_end_position")
    message_0_1 = Message(text="message_0_text", code="message_0_code", key="message_0_key", index=["message_0_index"], position="message_0_position", start_position="message_0_start_position", end_position="message_0_end_position")

# Generated at 2022-06-26 10:02:47.844397
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:03:01.074400
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='a', code='b', key='c', index=['d'], position=Position(line_no=0, column_no=1, char_index=2), start_position=3, end_position=4)
    message_1 = Message(text='a', code='b', key='c', index=['d'], position=Position(line_no=0, column_no=1, char_index=2), start_position=3, end_position=4)
    message_2 = Message(text='a', code='b', key='c', index=['d'], position=Position(line_no=0, column_no=1, char_index=2), start_position=3, end_position=4)

# Generated at 2022-06-26 10:03:13.652459
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test for message 1
    msg1 = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        index=["users", 3, "username"],
        position=Position(line_no=12, column_no=0, char_index=26),
    )
    msg2 = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        index=["users", 3, "username"],
        position=Position(line_no=12, column_no=0, char_index=26),
    )
    assert (msg1 == msg2)

    # Test for message 2

# Generated at 2022-06-26 10:03:26.913372
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    class_name = "BaseError"
    method_name = "__eq__"

    a = ValidationError(text='May not be blank')
    b = ValidationError(text='May not be blank')
    assert(a == b)
    c = ValidationError(text='May not be blank', code='blank')
    assert(c != b)
    d = ValidationError(text='May not be blank', code='blank', key='field')
    assert(c == d)
    e = ValidationError(text='May not be blank', code='blank', key='field2')
    assert(e != d)
    f = ValidationError(messages=[Message(text='May be blank')])
    assert(a != f)
    a.messages().append(Message(text='May be blank'))

# Generated at 2022-06-26 10:03:31.639616
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message_0 = Message()
    message_1 = Message()
    error_0 = ValidationError(messages=[message_0])
    error_1 = ValidationError(messages=[message_1])
    assert error_0 == error_1, "Unit test for BaseError.__eq__() has failed!"


# Generated at 2022-06-26 10:03:37.381986
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m0 = Message(text="May not have more than 100 characters", code="max_length", key="key")
    m1 = Message(text="May not have more than 100 characters", code="max_length", key="key")
    assert m0 == m1

# Generated at 2022-06-26 10:03:42.957960
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="hello")
    assert message == Message(text="hello"), "Message equality works"
    assert not (message == Message(text="world")), "Message equality works"


# Generated at 2022-06-26 10:03:46.802941
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    test_Position___eq___0 = Position(line_no=0, column_no=0, char_index=0)
    test_Position___eq___1 = Position(line_no=0, column_no=0, char_index=0)
    assert test_Position___eq___0 == test_Position___eq___1


# Generated at 2022-06-26 10:03:59.245475
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    parse_error_1 = ParseError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(line_no=1, column_no=5, char_index=5),
    )
    parse_error_2 = ParseError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(line_no=1, column_no=5, char_index=5),
    )
    assert parse_error_1 == parse_error_2


# Generated at 2022-06-26 10:04:04.468812
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_1 = ParseError(text="abc")
    parse_error_2 = ParseError(text="abc")
    parse_error_3 = ParseError(text="abcd")
    assert parse_error_1 == parse_error_1
    assert parse_error_1 == parse_error_2
    assert parse_error_1 != parse_error_3


# Generated at 2022-06-26 10:04:15.289977
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert ParseError().__str__() == ""
    assert ParseError(text="text").__str__() == "text"


# Generated at 2022-06-26 10:04:20.485674
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != None


# Generated at 2022-06-26 10:04:24.376613
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    data = {"foo": "bar"}
    error = BaseError(key="foo", text="May not be a string")
    dump = yaml.dump(error)
    assert error.__str__() == "{foo: May not be a string}"
    assert error.__str__() == dump

# Generated at 2022-06-26 10:04:30.783176
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no = 0
    column_no = 0
    char_index = 0
    position_0 = Position(line_no, column_no, char_index)
    assert isinstance(position_0, Position)

    line_no_1 = 1
    column_no_1 = 1
    char_index_1 = 1
    position_1 = Position(line_no_1, column_no_1, char_index_1)
    assert isinstance(position_1, Position)
    assert position_0 == position_0
    assert position_1 == position_1
    assert position_0 != position_1


# Generated at 2022-06-26 10:04:33.945522
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    parse_error = ParseError()
    assert str(parse_error) == "{}"



# Generated at 2022-06-26 10:04:35.661434
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    _ = ParseError() == ParseError()
    _ = ValidationError() == ValidationError()



# Generated at 2022-06-26 10:04:39.176175
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    parse_error_1 = ParseError()
    assert parse_error_0 == parse_error_1


# Generated at 2022-06-26 10:04:45.762159
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no = 1234567
    column_no = 1234567
    char_index = 1234567
    position_0 = Position(
        line_no=line_no, column_no=column_no, char_index=char_index)
    position_1 = Position(
        line_no=line_no, column_no=column_no, char_index=char_index)
    assert position_0 == position_1


# Generated at 2022-06-26 10:04:47.544814
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    parse_error_1 = ParseError()
    assert (parse_error_0 == parse_error_1) == True


# Generated at 2022-06-26 10:04:58.359398
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    value_0 = BaseError(
        text='value_0',
        code='value_1',
        key='value_2',
        position=Position(
            line_no=int(5),
            column_no=int(5),
            char_index=int(5),
        ),
        messages=['value_4', 'value_5', 'value_6'],
    )
    value_1 = BaseError(
        text='value_0',
        code='value_1',
        key='value_2',
        position=Position(
            line_no=int(5),
            column_no=int(5),
            char_index=int(5),
        ),
        messages=['value_4', 'value_5', 'value_6'],
    )
    value_1 = BaseError.mess

# Generated at 2022-06-26 10:05:27.596526
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(
    text="This is text",
    code="custom",
    key=None,
    index=None,
    position=Position(line_no=1, column_no=1, char_index=0),
    start_position=None,
    end_position=None,
    )

    message_1 = Message(
    text="This is text",
    code="custom",
    key=None,
    index=None,
    position=Position(line_no=1, column_no=1, char_index=0),
    start_position=None,
    end_position=None,
    )

    print(message_0 == message_1)


# Generated at 2022-06-26 10:05:28.884986
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)


# Generated at 2022-06-26 10:05:39.091108
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    # AssertRaises is not supported by mypy.
    # assertRaises(
    #     parse_error_0.__eq__(Exception()) == False,
    #     "Expected parse_error_0.__eq__(Exception()) to raise Exception, instead returned False"
    # )
    # assertRaises(
    #     parse_error_0.__eq__(Exception()) != False,
    #     "Expected parse_error_0.__eq__(Exception()) to raise Exception, instead returned True"
    # )
    # assertRaises(
    #     parse_error_0.__eq__(RuntimeError()) == False,
    #     "Expected parse_error_0.__eq__(RuntimeError()) to raise Exception, instead returned False"
    # )


# Generated at 2022-06-26 10:05:48.368964
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    ex_cls = ValidationError
    eq_ = ValidationError().__eq__
    assert eq_(ex_cls())
    assert not eq_(ex_cls(text="a"))
    assert not eq_(ex_cls(text="a", code="b"))
    assert eq_(ex_cls(text="a", code="b", key="c"))
    assert not eq_(ex_cls(text="a", code="b", index=["c"]))
    assert not eq_(ex_cls(text="a", code="b", key="c", position=Position(4, 4, 4)))
    assert not eq_(ex_cls(text="a", code="b", key="c", position=Position(4, 4, 4)))

# Generated at 2022-06-26 10:05:56.479716
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    parse_error_1 = ParseError(text='text1')
    parse_error_2 = ParseError(text='text2')
    parse_error_3 = ParseError(text='text1', code='code1')
    parse_error_4 = ParseError(text='text1', code='code2')
    parse_error_5 = ParseError(text='text1', code='code1', key=1)
    parse_error_6 = ParseError(text='text1', code='code1', key=2)
    parse_error_7 = ParseError(text='text1', code='code1', key=1, position='position1')

# Generated at 2022-06-26 10:05:58.494906
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError()
    base_error_1 = BaseError()
    assert base_error_0 == base_error_1


# Generated at 2022-06-26 10:06:07.696271
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    parse_error_1 = ParseError(messages=[Message(text='1', code='custom', key='')])
    parse_error_2 = ParseError(messages=[Message(text='2', code='custom', key='')])
    assert parse_error_0 == parse_error_0
    assert (parse_error_1 == ParseError(messages=[Message(text='1', code='custom', key='')]))
    assert (parse_error_1 == ParseError(messages=[Message(text='1', code='custom', index=[''])]))
    assert (parse_error_1 == ParseError(messages=[Message(text='1', code='custom', key='')]))

# Generated at 2022-06-26 10:06:14.178659
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no_arg = 1
    column_no_arg = 1
    char_index_arg = 1
    ins_a = Position(line_no=line_no_arg, column_no=column_no_arg, char_index=char_index_arg)
    ins_b = Position(line_no=line_no_arg, column_no=column_no_arg, char_index=char_index_arg)
    assert ins_a == ins_b


# Generated at 2022-06-26 10:06:15.701240
# Unit test for method __eq__ of class BaseError

# Generated at 2022-06-26 10:06:16.580603
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    pass



# Generated at 2022-06-26 10:06:57.027040
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    test_Message___eq___0()



# Generated at 2022-06-26 10:07:05.363606
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_1 = ParseError(
        messages=[
            Message(text="Parse error 0", code="parse_error", index=[]),
            Message(text="Parse error 1", code="parse_error", index=[0]),
        ]
    )
    parse_error_2 = ParseError(
        messages=[
            Message(text="Parse error 0", code="parse_error", index=[]),
            Message(text="Parse error 1", code="parse_error", index=[0]),
        ]
    )
    parse_error_3 = ParseError(
        messages=[
            Message(text="Parse error 3", code="parse_error", index=[]),
            Message(text="Parse error 1", code="parse_error", index=[0]),
        ]
    )

# Generated at 2022-06-26 10:07:16.387311
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message('value', 'value', [1, 2], 'value', 'value', 'value')
    message_1 = Message('value', 'value', [1, 2], 'value', 'value', 'value')
    message_3 = Message('value', 'value', 'value', 'value', 'value', 'value')
    message_4 = Message('value', 'value', [1, 2], 'value', 'value', 'value')
    assert message_0 == message_1
    assert message_3 != message_1
    assert message_4 == message_1



# Generated at 2022-06-26 10:07:23.609738
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_1 = ValidationError()
    parse_error_2 = ValidationError()
    parse_error_3 = ValidationError(text="")
    parse_error_4 = ValidationError(text="", code="")
    parse_error_5 = ValidationError(text="", code="", key="")
    parse_error_6 = ParseError()
    parse_error_7 = ParseError()
    parse_error_8 = ParseError(text="")
    parse_error_9 = ParseError(text="", code="")
    parse_error_10 = ParseError(text="", code="", key="")
    parse_error_11 = ParseError(text="", code="", key="", position=Position(0, 0, 0))

# Generated at 2022-06-26 10:07:27.088039
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    Message(text="error 1", code="max_length", index=[1, "test"]) == Message(text="error 1", code="max_length", index=[1, "test"])



# Generated at 2022-06-26 10:07:32.506160
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error_0 = ValidationError(messages=[
        Message(
            text='may not have more than 100 characters',
            code='max_length',
            key='foo',
        ),
        Message(
            text='may not be less than 10 characters',
            code='min_length',
            key='foo',
        ),
    ])

# Generated at 2022-06-26 10:07:33.819069
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    parse_error_1 = ParseError()
    assert parse_error_0 == parse_error_1

# Generated at 2022-06-26 10:07:37.374004
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    messages = [Message(text="message 1", code="code 1")]
    parse_error_0 = BaseError(messages=messages)
    parse_error_1 = BaseError(messages=messages)
    
    assert parse_error_0 == parse_error_1


# Generated at 2022-06-26 10:07:39.715279
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Define variables
    Expected = True
    Actual = True

    # Perform test
    assert Expected == Actual, 'Test Failed'


# Generated at 2022-06-26 10:07:46.623754
# Unit test for method __eq__ of class BaseError

# Generated at 2022-06-26 10:08:24.537928
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    parse_error_1 = ParseError()
    assert parse_error_0 == parse_error_1


# Generated at 2022-06-26 10:08:32.259263
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    parse_error_1 = ParseError(code = 'root')
    parse_error_2 = ParseError(text = 'root')
    parse_error_3 = ParseError(key = 'root')
    parse_error_4 = ParseError(position = 'root')
    parse_error_5 = ParseError(messages = ['root'])
    assert parse_error_0 == ParseError()
    assert parse_error_1 == ParseError(code = 'root')
    assert parse_error_2 == ParseError(text = 'root')
    assert parse_error_3 == ParseError(key = 'root')
    assert parse_error_4 == ParseError(position = 'root')

# Generated at 2022-06-26 10:08:40.598709
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message_0 = Message(text="Invalid ' = \" = v = v = \" = ' = \" = ' = ' =", code="type", index=["c = \" = ' = ' = \" = \" = \"", "invalid = ' = \" = v = v = \" = ' = \" = ' = ' ="], position=Position(line_no=3, column_no=16, char_index=37))
    message_1 = Message(text="Unexpected ' = \" = v = v = \" = ' = \" = ' = ' =", code="type", index=["c = \" = ' = ' = \" = \" = \"", "unexpected = ' = \" = v = v = \" = ' = \" = ' = ' ="], position=Position(line_no=15, column_no=19, char_index=85))
    parse_error_0

# Generated at 2022-06-26 10:08:41.973461
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error_a = ParseError()
    error_b = ParseError()
    assert error_a == error_b


# Generated at 2022-06-26 10:08:45.195436
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
        # Check if the `BaseError.__eq__` method raises no error when calling
    # with two BaseErrors with the same content.

    _error_0 = ValidationError(text="Some error text")
    _error_1 = ValidationError(text="Some error text")
    assert(_error_0 == _error_1)


# Generated at 2022-06-26 10:08:56.682728
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    messages_0 = [Message(text="", code="", position=None, start_position=None)]
    assert BaseError(messages=messages_0) == BaseError(messages=messages_0)

    messages_1 = [Message(text="", code="", position=None, start_position=None)]
    assert BaseError(messages=messages_1) == BaseError(messages=messages_1)

    messages_2 = [Message(text="", code="", position=None, start_position=None)]
    messages_3 = [Message(text="", code="", position=None, start_position=None)]
    assert BaseError(messages=messages_2) == BaseError(messages=messages_3)

    assert BaseError(messages=[]) != []
    assert BaseError() != {}
   

# Generated at 2022-06-26 10:09:02.727492
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError(
        text="Expected one of '{', '[', or 'true', 'false', 'null', a number, '\"'.",
        position=Position(line_no=1, column_no=1, char_index=0),
    )
    parse_error_1 = ParseError(
        text="Expected one of '{', '[', or 'true', 'false', 'null', a number, '\"'.",
        position=Position(line_no=1, column_no=1, char_index=0),
    )

# Generated at 2022-06-26 10:09:13.083104
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    val_0 = ParseError()
    val_1 = ParseError(text='hello', code='yes', key='no', position='yes')
    val_2 = ParseError(messages=[Message(text='hello', code='yes', key='no', position='yes')])
    val_3 = ValidationError()
    val_4 = ValidationError(text='hello', code='yes', key='no', position='yes')
    val_5 = ValidationError(messages=[Message(text='hello', code='yes', key='no', position='yes')])
    val_6 = ValidationResult()
    val_7 = ValidationResult(value=1, error=ValidationError())
    val_8 = ValidationResult(value=1)


# Generated at 2022-06-26 10:09:14.705536
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    parse_error_1 = ParseError()


# Generated at 2022-06-26 10:09:15.923598
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    parse_error_0 = ParseError()
    assert parse_error_0 == ParseError()
