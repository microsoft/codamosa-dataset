

# Generated at 2022-06-26 09:59:37.023082
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # method called with arguments: (self, other:typing.Any) -> bool
    # tests if __eq__ method works fine
    str_0 = 'BN"8Y4xi0PrRJ\rg'
    message_0 = Message(text=str_0, code=str_0, key=str_0)
    message_1 = Message(text=str_0, code=str_0, key=str_0)
    assert message_0 == message_1
    # method called with arguments: (self, other:typing.Any) -> bool
    # tests if __eq__ method works fine
    str_2 = 'BN"8Y4xi0PrRJ\rg'
    message_3 = Message(text=str_2, code=str_2, key=str_2)

# Generated at 2022-06-26 09:59:39.668982
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = "J"
    str_1 = "y(:"
    str_2 = "!"
    message_0 = Message(text=str_0, code=str_1, key=str_2)
    str_3 = "value"
    ValidationResult(value=message_0)


# Generated at 2022-06-26 09:59:51.419879
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = 'R(:"'
    str_1 = ')'
    str_2 = 'i'
    str_3 = '"'
    str_4 = 'i'
    str_5 = "'&Nx"
    str_6 = 'D'
    str_7 = 'T'
    val_0 = ValidationResult(value=str_0, error=None)
    val_1 = ValidationResult(value=str_1, error=None)
    val_2 = ValidationResult(value=str_2, error=None)
    val_3 = ValidationResult(value=str_3, error=None)
    val_4 = ValidationResult(value=str_4, error=None)
    val_5 = ValidationResult(value=str_5, error=None)

# Generated at 2022-06-26 09:59:59.786384
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = 'zqH'
    position_0 = Position(start_position=position_0, end_position=position_0)
    messages_0 = [Message(text=str_0, code=str_0, index=[], position=position_0)]
    error_0 = ValidationError(text=str_0, messages=messages_0)
    str_1 = '4'
    value_0 = '4'
    validation_result = ValidationResult(value=value_0)
    assert validation_result.error is None
    assert validation_result.value == value_0
    validation_result = ValidationResult(error=error_0)
    assert validation_result.error is error_0
    assert validation_result.value is None

    iterator_0 = validation_result.__iter__()

# Generated at 2022-06-26 10:00:03.360032
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    message_0 = Message(text='', code='', key='')
    validation_result_0 = ValidationResult(value=message_0, error=None)
    for __exception in range(100):
        try:
            assert_equals(list(validation_result_0), [message_0, None])
            break
        except AssertionError:
            pass
    else:
        raise AssertionError('Failed to assert equals')


# Generated at 2022-06-26 10:00:06.452122
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '!p"L"|o\x1a'
    test_ValidationResult___iter___0 = ValidationResult(value=str_0, error=ValidationError(text=str_0))


# Generated at 2022-06-26 10:00:12.189927
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    str_0 = 'BThi5:5G$Kj+'
    error_0 = ValidationError(text=str_0, code=str_0, key=str_0)
    assert str(error_0) == str_0


# Generated at 2022-06-26 10:00:18.674668
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = 'xip4!z&K'
    message_0 = Message(text=str_0, code=str_0, key=str_0)
    validation_result_0 = ValidationResult(error=message_0)
    def test_func():
        for item in validation_result_0:
            print(item)
    test_func()

if __name__ == '__main__':
    test_case_0()
    test_ValidationResult___iter__()

# Generated at 2022-06-26 10:00:24.087283
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '7vpWjx8T'
    message_0 = Message(text=str_0, code=str_0, key=str_0)


# Generated at 2022-06-26 10:00:26.877401
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = 'BN"8Y4xi0PrRJ\rg'
    message_0 = Message(text=str_0, code=str_0, key=str_0)


# Generated at 2022-06-26 10:00:41.290657
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError()
    base_error_0.messages()
    base_error_0.__bool__()
    base_error_1 = BaseError()
    assert base_error_0 == base_error_1
    base_error_1 = ValidationError()
    assert base_error_0 != base_error_1


# Generated at 2022-06-26 10:00:50.331468
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(index=[0, 1], text="{#}", code="invalid_type", start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=2, char_index=2))
    message_1 = Message(index=[0, 1], text="{#}", code="invalid_type", start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=2, char_index=2))

# Generated at 2022-06-26 10:00:59.003880
# Unit test for method __eq__ of class Message
def test_Message___eq__():
  message_0 = Message(text="message.text", code="message.code", key="message.key", position=Position(line_no=0, column_no=0, char_index=0))
  message_1 = Message(text="message.text", code="message.code", key="message.key", position=Position(line_no=0, column_no=0, char_index=0))
  if (not (message_0 == message_1)):
    raise RuntimeError


# Generated at 2022-06-26 10:01:09.812580
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    text_0 = "gf<p[dwsl|"
    message_0 = Message(
        text=text_0,
        code=None,
        key=None,
        index=None,
        position=None,
        start_position=None,
        end_position=None,
    )
    base_error_0 = BaseError(
        messages=[message_0]
    )
    assert base_error_0.__repr__() == "BaseError([Message(text='gf<p[dwsl|', code='custom')])"


# Generated at 2022-06-26 10:01:14.698169
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    """
    Assert that the operator == works for Position.
    """
    assert Position(1,1,1) == Position(1,1,1)


# Generated at 2022-06-26 10:01:21.863981
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # type: () -> None
    validation_error_0 = ValidationError(messages=[Message(text='', code='', key='', position=Position(line_no=1, column_no=2, char_index=3), start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=1, column_no=2, char_index=3))])

# Generated at 2022-06-26 10:01:32.188086
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="user",
        position=Position(line_no=1, column_no=1, char_index=1),
    )
    message_1 = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="user",
        position=Position(line_no=1, column_no=1, char_index=1),
    )
    assert message_0 == message_1


# Generated at 2022-06-26 10:01:37.012292
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    obj_0 = Position(1, 1, 1)
    obj_1 = Position(1, 1, 1)
    assert obj_0 == obj_1


# Generated at 2022-06-26 10:01:39.178435
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError().__eq__(None) is NotImplemented


# Generated at 2022-06-26 10:01:41.546149
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # Test if the output is correct
    assert BaseError().__str__() == "{}"


# Generated at 2022-06-26 10:01:50.005542
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    arg_0 = Position(line_no=1, column_no=2, char_index=3)
    arg_1 = Position(line_no=1, column_no=2, char_index=3)
    expected_return = True
    returned_value = arg_0.__eq__(arg_1)
    assert returned_value == expected_return


# Generated at 2022-06-26 10:01:57.741213
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    validation_result_0 = ValidationResult(error=ParseError(text='text_0', code='code_0', key='key_0', position=Position(line_no=0, column_no=0, char_index=0)))
    validation_result_1 = ValidationResult(error=ValidationError(text='text_1', code='code_1', key='key_1', position=Position(line_no=1, column_no=1, char_index=1)))


if __name__ == "__main__":
    test_case_0()
    test_BaseError___repr__()

# Generated at 2022-06-26 10:02:08.623509
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # test no message
    error = ValidationError()
    assert str(error) == "{}"

    # test one message
    error = ValidationError(text="hello!")
    assert str(error) == "hello!"

    # test several messages
    error = ValidationError(
        messages=[Message(text="hello!"), Message(text="goodbye!")]
    )
    assert str(error) == "{'': 'hello!', '': 'goodbye!'}"

    # test nested message
    error = ValidationError(messages=[Message(text="hello!", key="foo")])
    assert str(error) == "{'foo': 'hello!'}"

    # test nested messages
    error = ValidationError(
        messages=[Message(text="hello!", key="foo"), Message(text="goodbye!", key="bar")]
    )


# Generated at 2022-06-26 10:02:17.443973
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(
        text="",
        code="",
        index=[],
        start_position=Position(line_no=0, column_no=0, char_index=0),
        end_position=Position(line_no=0, column_no=0, char_index=0),
    )
    other_0 = object()
    value_0 = (message_0,) != (other_0,)
    value_1 = value_0 == False

    assert value_1 is True


# Generated at 2022-06-26 10:02:22.516551
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test arguments
    value = 1
    other = 1
    base_error = BaseError(text="", code="", key=1, position=None, messages=[])
    # Test function
    response = base_error.__eq__(other=other)
    assert response == value


# Generated at 2022-06-26 10:02:25.577157
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError()
    base_error_1 = BaseError()
    assert base_error_0 == base_error_1


# Generated at 2022-06-26 10:02:30.900160
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Test function content
    assert ValidationError(text="hello").__repr__() == "ValidationError(\"hello\")"
    assert ValidationError(messages=[Message(text="hello")]).__repr__() == "ValidationError([Message(text=\"hello\")])"
    test_case_0()



# Generated at 2022-06-26 10:02:42.072338
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    data = {
        "employees": [
            {
                "first_name": "Bob",
                "last_name": "Smith",
                "age": 55
            },
            {
                "first_name": "Sue",
                "last_name": "Smith",
                "age": 72
            },
            {
                "first_name": "John",
                "last_name": "Doe",
                "age": 27
            }
        ]
    }

    # Create validation error

# Generated at 2022-06-26 10:02:45.670055
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message = Message(text = "May not have more than 100 characters", key = "username")
    b1 = BaseError(messages = [message])
    b2 = BaseError(messages = [message])
    assert b1 == b2


# Generated at 2022-06-26 10:02:48.457075
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    val = ParseError([Message(text='message', code='code', key='key')])
    assert str(val) == "ParseError([Message(text='message', code='code', index=['key'])])"

# Generated at 2022-06-26 10:03:10.551165
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    _message = Message(text='Validation error', code='max_length', index=["username"], start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=1, column_no=2, char_index=3))
    _message1 = Message(text='Validation error', code='max_length', index=["username"], start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=1, column_no=2, char_index=3))
    if(_message == _message1):
        print('ASSERTION SUCCESSFUL: Message.__eq__')
    else:
        print('ASSERTION FAILED: Message.__eq__')


# Generated at 2022-06-26 10:03:12.616676
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    BaseError_0 = BaseError()
    assert isinstance(BaseError_0.__repr__(), str)


# Generated at 2022-06-26 10:03:25.821092
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Testing if an instance of Message is equal to an instance of Message having same fields.
    message_0 = Message(text='hello', code='max_length', key='username', index=None, position=None, start_position=None, end_position=None)
    message_1 = Message(text='hello', code='max_length', key='username', index=None, position=None, start_position=None, end_position=None)
    assert message_0 == message_1
    # Testing if an instance of Message is not equal to an instance of Message having different fields.
    message_0 = Message(text='hello', code='max_length', key='username', index=None, position=None, start_position=None, end_position=None)

# Generated at 2022-06-26 10:03:31.292867
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(
        text="May not have more than 100 characters", code="max_length", key="username"
    )
    message_1 = Message(
        text="May not have more than 100 characters", code="max_length", key="username"
    )
    assert message_0 == message_1


# Generated at 2022-06-26 10:03:42.797743
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    arg_0 = Message(text='value-0', code='value-1', key='value-2', index='value-3', position='value-4', start_position='value-5', end_position='value-6')
    arg_1 = Message(text='value-7', code='value-8', index='value-9', start_position='value-10', end_position='value-11')
    arg_2 = Message(text='value-12', code='value-13')
    arg_3 = Message(text='value-14', code='value-15')
    arg_4 = Message(text='value-16', code='value-17')
    arg_5 = Message(text='value-18', code='value-19')
    assert arg_0.__eq__(arg_1) == 'Value'
    assert arg_

# Generated at 2022-06-26 10:03:47.178406
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test 1
    position_0 = Position(1, 2, 3)
    position_1 = Position(1, 2, 3)
    position_2 = Position(1, 2, 4)
    position_3 = Position(1, 3, 3)
    assert position_0 == position_1
    assert position_0 != position_2
    assert position_0 != position_3


# Generated at 2022-06-26 10:03:48.136072
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    validation_result_0 = ValidationResult()


# Generated at 2022-06-26 10:04:02.086744
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    test_case_1 = Position(line_no=1, column_no=2, char_index=3)
    test_case_2 = Position(line_no=1, column_no=2, char_index=3)
    test_case_3 = Position(line_no=1, column_no=2, char_index=4)
    assert test_case_1 == test_case_2
    assert test_case_2 == test_case_1
    assert test_case_1 != test_case_3
    assert test_case_3 != test_case_1
    test_case_4 = Position(line_no=1, column_no=3, char_index=3)
    assert test_case_1 != test_case_4
    assert test_case_4 != test_case_1
    test_

# Generated at 2022-06-26 10:04:04.592949
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="", code="", key=None, index=[], position=None, start_position=None, end_position=None)


# Generated at 2022-06-26 10:04:14.886142
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message(text="", code="")
    message_2 = Message(text="", code="", position=None)
    message_3 = Message(text="", code="", position=Position(line_no=0, column_no=0, char_index=0))
    message_4 = Message(text="", code="", start_position=None, end_position=None)
    message_5 = Message(text="", code="", start_position=Position(line_no=0, column_no=0, char_index=0), end_position=None)
    message_6 = Message(text="", code="", start_position=None, end_position=Position(line_no=0, column_no=0, char_index=0))