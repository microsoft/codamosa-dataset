

# Generated at 2022-06-26 09:59:36.047659
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    assert list(validation_result_0) == [None, None]


# Generated at 2022-06-26 09:59:38.123195
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    try:
        for _ in validation_result_0:
            raise AssertionError()
    except TypeError:
        pass


# Generated at 2022-06-26 09:59:41.853811
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    iter_retval_0 = validation_result_0.__iter__()
    assert False


# Generated at 2022-06-26 09:59:43.741064
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    for index_0 in validation_result_0:
        pass



# Generated at 2022-06-26 09:59:47.941390
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    expected = (None, None)
    actual = tuple(iter(validation_result_0))
    assert expected == actual



# Generated at 2022-06-26 09:59:54.097616
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    validation_result_iter_0 = iter(validation_result_0)
    assert next(validation_result_iter_0) == validation_result_0.value
    assert next(validation_result_iter_0) == validation_result_0.error



# Generated at 2022-06-26 10:00:07.319527
# Unit test for constructor of class BaseError
def test_BaseError():
    message_0 = Message(text="Message #0")
    message_1 = Message(text="Message #1", code="custom", key="key_0")
    message_2 = Message(text="Message #2", code="custom", index=["index_0"])
    message_3 = Message(text="Message #3", code="custom", index=["index_1", "index_2"])
    message_4 = Message(text="Message #4", code="custom", key="key_1", index=["index_3"])
    message_5 = Message(text="Message #5", code="custom", key="key_2", index=["index_4", "index_5"])
    validation_error_0 = ValidationError(messages=[message_0])

# Generated at 2022-06-26 10:00:12.963971
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="message text", code= "message code", index=["message index"])
    message_1 = Message(text="message text", code= "message code", index=["message index"])
    assert message_0 == message_1


# Generated at 2022-06-26 10:00:19.866397
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():

    validation_result_0 = ValidationResult()

    # Call function
    result = list(validation_result_0)
    assert result == [None, None]

    validation_result_1 = ValidationResult(value="")

    # Call function
    result = list(validation_result_1)
    assert result == ["", None]

    validation_result_2 = ValidationResult(error=ValidationError())

    # Call function
    result = list(validation_result_2)
    assert result == [None, ValidationError()]


# Generated at 2022-06-26 10:00:30.138627
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    line_no_0 = 115
    column_no_0 = -142
    char_index_0 = -113
    start_position_0 = Position(line_no_0, column_no_0, char_index_0)
    line_no_1 = -130
    column_no_1 = -101
    char_index_1 = -43
    end_position_0 = Position(line_no_1, column_no_1, char_index_1)
    text_0 = '"+{$(2;R_h;e,GxD?=ZW]dR{Y?-y&<J$)5%W#9yeq3l\'Z>6`?Uz~W-1_4w4F]+{p?}n'

# Generated at 2022-06-26 10:00:47.381263
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='text_0', code='code_0', index=['index_0'], position=Position(line_no=0, column_no=0, char_index=0))
    message_1 = Message(text='text_1', code='code_1', index=['index_1'], position=Position(line_no=1, column_no=1, char_index=1))
    message_2 = Message(text='text_0', code='code_0', index=['index_0'], position=Position(line_no=0, column_no=0, char_index=0))
    assert message_0 == message_2, 'Expected message_0 == message_2, but got <' + str(message_0) + '> == <' + str(message_2) + '>'

# Generated at 2022-06-26 10:00:51.839197
# Unit test for constructor of class ValidationError
def test_ValidationError(): #TODO
    error = ValidationError(text="")
    assert error.text == ""
    assert not error.messages()
    assert not error
    assert error == error
    assert hash(error) == hash(error)



# Generated at 2022-06-26 10:01:02.911009
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert (
        Message(text="May not have more than 100 characters")
        == Message(text="May not have more than 100 characters")
    )
    assert (
        Message(text="May not have more than 100 characters", code="max_length")
        == Message(text="May not have more than 100 characters", code="max_length")
    )
    assert (
        Message(text="May not have more than 100 characters", key="username")
        == Message(text="May not have more than 100 characters", key="username")
    )
    assert (
        Message(text="May not have more than 100 characters", index=["username"])
        == Message(text="May not have more than 100 characters", index=["username"])
    )

# Generated at 2022-06-26 10:01:08.168875
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='text_0')
    message_1 = Message(text='text_1')
    assert message_0 == message_0
    assert message_0 != message_1


# Generated at 2022-06-26 10:01:09.487973
# Unit test for constructor of class ValidationError
def test_ValidationError():
    # Case 0: Zero-arg constructor:
    assert ValidationError()


# Generated at 2022-06-26 10:01:22.595701
# Unit test for constructor of class ValidationError
def test_ValidationError():
    try:
        validation_error_0 = ValidationError()
    except Exception as e:
        assert False, "failed to instantiante ValidationError"
    assert validation_error_0 is not None
    try:
        validation_error_1 = ValidationError(text="text_1")
    except Exception as e:
        assert False, "failed to instantiante ValidationError"
    assert validation_error_1 is not None
    try:
        validation_error_2 = ValidationError(text="text_2", code="code_2")
    except Exception as e:
        assert False, "failed to instantiante ValidationError"
    assert validation_error_2 is not None

# Generated at 2022-06-26 10:01:34.529836
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0_0 = Message(text='This is an error message with the code "required"', code='required')
    message_0_1 = Message(text='This is an error message with the code "required"', code='required')
    message_0_2 = Message(text='This is an error message with the code "required"', code='required')
    message_0_3 = Message(text='This is an error message with the code "required"', code='required')
    assert message_0_0 == message_0_1
    assert message_0_1 == message_0_2
    assert message_0_2 == message_0_3
    message_1_0 = Message(text='This is an error message with the code "required"', code='required')

# Generated at 2022-06-26 10:01:37.239749
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1



# Generated at 2022-06-26 10:01:43.669702
# Unit test for constructor of class ValidationError
def test_ValidationError():
    my_e = ValidationError(text='May not have more than 100 characters', code='max_length', key='username')
    my_e_1 = ValidationError(text='May not have more than 100 characters', code='max_length', key='username')
    my_e_2 = ValidationError(text='May not have more than 100 characters', code='max_length', key='username')
    assert my_e == my_e_1
    assert my_e != my_e_2

# Generated at 2022-06-26 10:01:54.689575
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert (
        Message(text="text_1", code="code_1", index=[], position=Position(1, 1, 1))
        == Message(text="text_1", code="code_1", index=[], position=Position(1, 1, 1))
    )
    assert (
        Message(text="text_2", code="code_2", index=[], position=Position(2, 2, 12))
        == Message(text="text_2", code="code_2", index=[], position=Position(2, 2, 12))
    )
    assert (
        Message(text="text_1", code="code_1", index=[], position=Position(1, 1, 1))
        != Message(text="text_2", code="code_2", index=[], position=Position(2, 2, 12))
    )
   

# Generated at 2022-06-26 10:02:08.623864
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(
        text="Min length is {min_length}, got {length}",
        index=[],
        code="min_length",
        start_position=Position(line_no=15, column_no=3, char_index=0),
        end_position=Position(line_no=15, column_no=118, char_index=113),
    )
    message_1 = Message(
        text="Min length is {min_length}, got {length}",
        index=[],
        code="min_length",
        start_position=Position(line_no=15, column_no=3, char_index=0),
        end_position=Position(line_no=15, column_no=118, char_index=113),
    )
    assert message_0 == message_1

# Unit

# Generated at 2022-06-26 10:02:21.904393
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error_0 = ParseError()
    assert type(parse_error_0) is ParseError
    assert parse_error_0 == ParseError()
    assert type(parse_error_0) is ParseError
    parse_error_1 = ParseError(text="string", position=Position(line_no=10, column_no=11, char_index=12))
    parse_error_2 = ParseError(text="string", position=Position(line_no=10, column_no=11, char_index=12))
    assert parse_error_1 == parse_error_2
    assert type(parse_error_0) is ParseError
    validation_result_0 = ValidationResult(error=parse_error_0)
    validation_result_1 = ValidationResult(error=parse_error_1)

# Generated at 2022-06-26 10:02:23.908614
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:02:28.843448
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(code="max_length", text="May not have more than 100 characters")
    message_1 = Message(code="max_length", text="Must be shorter than 100 characters")
    message_2 = Message(code="max_length", text="May not have more than 100 characters")
    assert message_0 == message_2
    assert message_0 != message_1


# Generated at 2022-06-26 10:02:37.712262
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="text_0", code="code_0", index=["index_0"], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=10, column_no=20, char_index=100))
    assert message_0 == Message(text="text_0", code="code_0", index=["index_0"], start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=10, column_no=20, char_index=100))


# Generated at 2022-06-26 10:02:40.820652
# Unit test for constructor of class ParseError
def test_ParseError():
    value, error = 'a', 'b'

# Generated at 2022-06-26 10:02:53.754295
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    code_0 = 'code'
    index_0 = ['index']
    text_0 = 'text'
    end_position_0 = 'end_position'
    start_position_0 = 'start_position'
    message_0 = Message(code=code_0, index=index_0, text=text_0, end_position=end_position_0, start_position=start_position_0)
    
    code_1 = 'code'
    index_1 = ['index']
    text_1 = 'text'
    end_position_1 = 'end_position'
    start_position_1 = 'start_position'
    message_1 = Message(code=code_1, index=index_1, text=text_1, end_position=end_position_1, start_position=start_position_1)

# Generated at 2022-06-26 10:03:07.057710
# Unit test for constructor of class BaseError
def test_BaseError():
    assert BaseError.__doc__ == '\n    A validation or parse error, containing one or more error messages.\n    Error information is accessible either by accessing as a dict-like object,\n    eg. `dict(error)` or by returning the list of messages with `error.messages()`.\n\n    ValidationError is either raised, in the `validate()` usage:\n\n    value = MySchema.validate(data)\n\n    Or returned in the `validate_or_error()` usage:\n\n    value, error = MySchema.validate_or_error(data)\n    ',\
           f'expected: \'{BaseError.__doc__}\', actual: {BaseError.__doc__}'

# Generated at 2022-06-26 10:03:16.002790
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text: message text")
    assert message == message
    assert message == Message(text="text: message text")
    assert message == Message(text="text: message text", code="custom")
    assert message == Message(text="text: message text", index=["key"])
    assert message == Message(
        text="text: message text",
        index=["key"],
        position=Position(line_no=1, column_no=2, char_index=3),
    )
    assert message == Message(
        text="text: message text",
        index=["key"],
        position=Position(line_no=1, column_no=2, char_index=3),
        start_position=Position(line_no=1, column_no=2, char_index=3),
    )

# Generated at 2022-06-26 10:03:20.348858
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text = 'foo')
    other = Message(text = 'bar')
    assert not message.__eq__(other)


# Generated at 2022-06-26 10:03:27.414134
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    base_error_0 = BaseError()
    base_error_0.__eq__(1)
    base_error_1 = BaseError()
    base_error_1.__eq__(1)


# Generated at 2022-06-26 10:03:31.592710
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    first_message = Message(text="May not have more than 100 characters")
    second_message = Message(text="May not have more than 100 characters")
    assert first_message.__eq__(first_message) == True
    assert first_message.__eq__(second_message) == True


# Generated at 2022-06-26 10:03:42.934575
# Unit test for constructor of class ValidationError
def test_ValidationError():
    text = "Error!"
    code = "code_123"
    key = "key123"
    position = Position(5,5,5)
    messages = [Message(text="Error!",code="code_123",key="key123",position=Position(5,5,5))]
    v1 = ValidationError(text=text,code=code,key=key,position=position)
    v2 = ValidationError(messages=messages)

    assert v1._messages[0].text == "Error!"
    assert v1._messages[0].index == ["key123"]
    assert v1._message_dict["key123"] == "Error!"

    assert v2._messages[0].text == "Error!"
    assert v2._messages[0].index == ["key123"]
    assert v2._message_

# Generated at 2022-06-26 10:03:48.977190
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Create class (instance 0)
    temp_0 = Message('a_0', 'b_0', 'c_0', [0, 1, 2], Position(3, 3, 3), Position(4, 4, 4), Position(5, 5, 5))
    # Create class (instance 1)
    temp_1 = Message('a_1', 'b_1', 'c_1', [1, 2, 3], Position(4, 4, 4), Position(5, 5, 5), Position(6, 6, 6))
    # Compare
    assert temp_0 == temp_0
    assert temp_0 != temp_1
    assert temp_1 == temp_1


# Generated at 2022-06-26 10:04:02.728863
# Unit test for constructor of class ValidationError
def test_ValidationError():
    import typesystem
    schema = typesystem.Schema(typesystem.String())
    error = ValidationError(text="invalid", code="invalid", key="name", position=Position(line_no=1, column_no=1, char_index=1))
    assert error.messages()[0] == Message(text="invalid", code="invalid", key="name", position=Position(line_no=1, column_no=1, char_index=1))
    assert error.messages()[0].text == "invalid"
    assert error.messages()[0].code == "invalid"
    assert error.messages()[0].index == ["name"]
    assert error.messages()[0].start_position == Position(line_no=1, column_no=1, char_index=1)


# Generated at 2022-06-26 10:04:12.505091
# Unit test for constructor of class BaseError
def test_BaseError():

    # Pass: Instantiated as a ValidationError with multiple error messages.
    line = 1
    column = 1
    index = []
    text = "Invalid date '20-02-2020'"
    code = "invalid_date"
    data = {
        "text": text,
        "code": code,
        "index": index,
        "start_position": Position(line, column, 2),
        "end_position": Position(line, column, 17),
    }
    messages = [Message(**data)]
    error = BaseError(messages=messages)

    assert error._messages[0].text == text
    assert error._messages[0].index == index
    assert error._messages[0].code == code
    assert error._messages[0].start_position.line_no == line
    assert error

# Generated at 2022-06-26 10:04:19.202858
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0_0 = Message(text='', code='', key='')
    message_0_1 = Message(text='', code='', key='')
    assert message_0_0 == message_0_1

    message_1_0 = Message(text='', code='', key='', start_position=Position(0, 0, 0))
    message_1_1 = Message(text='', code='', key='')
    assert message_1_0 != message_1_1


# Generated at 2022-06-26 10:04:28.882871
# Unit test for method __eq__ of class Message
def test_Message___eq__():
   message_0 = Message(text = "0", code = "0", index = [])
   message_1 = Message(text = "1", code = "1", index = ["1"])
   message_2 = Message(text = "2", code = "2", index = ["2", "2"])
   message_3 = Message(text = "3", code = "3", index = ["3", "3", "3"])
   message_4 = Message(text = "4", code = "4", index = ["4", "4", "4", "4"])
   message_5 = Message(text = "5", code = "5", index = ["5", "5", "5", "5", "5"])
   # Use assertTrue and assertFalse
   assert message_0 == message_0
   assert message_1 == message_

# Generated at 2022-06-26 10:04:30.676629
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m = Message(code="test_code", text="test_text")
    m1 = Message(code="test_code", text="test_text")
    assert m.__eq__(m1)


# Generated at 2022-06-26 10:04:34.125916
# Unit test for constructor of class ValidationError
def test_ValidationError():
    validation_error_0 = ValidationError()
    assert validation_error_0.__str__() == "__str__ return value:"


# Generated at 2022-06-26 10:04:55.900412
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    base_error_0 = BaseError()
    message_0 = Message(text='', code='custom', position=None)
    bool_0 = message_0.__eq__(message_0)
    print(bool_0)

    message_1 = Message(text='', code='custom', position=None)
    bool_1 = message_0.__eq__(message_1)
    print(bool_1)


# Generated at 2022-06-26 10:04:59.845138
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    position = Position(1,2,3)
    message = Message(text = "Hello!", code = "test_code", key = "test_key", position = position)
    assert message == Message(text = "Hello!", code = "test_code", key = "test_key", position = position)


# Generated at 2022-06-26 10:05:07.126487
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    instance_0 = Message(text='', code='', index=list(), start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))
    assert instance_0 == instance_0
    assert instance_0 != 1
    assert not (instance_0 != instance_0)
    assert instance_0 != Message(text='', code='', index=list(), start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))

# Generated at 2022-06-26 10:05:16.331899
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(index=[], code='"{\\n  \\"id\\" : 1,\\n  \\"name\\" : \\"A green door\\",\\n  \\"price\\" : 12.5,\\n  \\"tags\\" : [\\"home\\", \\"green\\"]\\n}\\n"', text='Value is not valid JSON or YAML.', position=Position(line_no=11, column_no=1, char_index=1), start_position=Position(line_no=11, column_no=1, char_index=1), end_position=Position(line_no=11, column_no=1, char_index=1))

# Generated at 2022-06-26 10:05:27.760990
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg0_0 = Message(text="")
    assert msg0_0.__eq__(msg0_0) == True
    assert msg0_0.__eq__(None) == False
    assert msg0_0.__eq__(Message(text="")) == True
    assert msg0_0.__eq__(Message(text="msg0_0")) == False
    assert msg0_0.__eq__(Message(text="", code="msg0_0")) == False
    assert msg0_0.__eq__(Message(text="", index=["msg0_0"])) == False
    assert msg0_0.__eq__(Message(text="", position=Position(1, 2, 3))) == False

# Generated at 2022-06-26 10:05:29.039871
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    message_0 == message_1


# Generated at 2022-06-26 10:05:32.057083
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='', code='', key='')
    message_1 = Message(text='', code='', key='')
    assert message_0 == message_1


# Generated at 2022-06-26 10:05:36.178399
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:05:40.385222
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text', code='code', index=[1, 2, 3], position=Position(1,2,3), start_position=Position(1,2,3), end_position=Position(1,2,3))
    message2 = Message(text='text', code='code', index=[1, 2, 3], position=Position(1,2,3), start_position=Position(1,2,3), end_position=Position(1,2,3))
    assert message1 == message2
    
    

# Generated at 2022-06-26 10:05:49.586195
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="foo", code="code", key=None, position=Position(1, 1, 1))
    m2 = Message(text="foo", code="code", key=None, position=Position(1, 1, 1))
    assert m1 == m2
    m1 = Message(text="foo", code="code", key=None, position=Position(1, 1, 1))
    m2 = Message(text="foo", code="code", key=None, position=Position(1, 2, 1))
    assert not m1 == m2
    m1 = Message(text="foo", code="code", key=None, position=Position(1, 1, 1))
    m2 = Message(text="foo", code="code", key=None, position=Position(2, 1, 1))
    assert not m1 == m2