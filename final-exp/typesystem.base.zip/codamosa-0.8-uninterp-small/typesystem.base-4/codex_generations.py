

# Generated at 2022-06-26 09:59:30.280842
# Unit test for method __iter__ of class ValidationResult

# Generated at 2022-06-26 09:59:33.533279
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Test case with no params
    base_error_1 = BaseError()
    validation_result_0 = ValidationResult()
    int_2 = validation_result_0.__iter__()


# Generated at 2022-06-26 09:59:44.500225
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text = "a", code = "a", index = [0], start_position = Position(line_no = 1, column_no = 1, char_index = 1), end_position = Position(line_no = 1, column_no = 1, char_index = 1))
    message_1 = Message(text = "a", code = "a", index = [0], start_position = Position(line_no = 1, column_no = 1, char_index = 1), end_position = Position(line_no = 1, column_no = 1, char_index = 1))
    bool_0 = message_0.__eq__(message_1)


# Generated at 2022-06-26 09:59:49.369479
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert not isinstance(ValidationResult(value=1, error=2), typing.Iterable)
    assert not isinstance(ValidationResult(value=1, error=2), typing.Sized)


# Generated at 2022-06-26 09:59:51.018366
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    test_case_0()


# Generated at 2022-06-26 09:59:53.614612
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    base_error_0 = BaseError()
    int_0 = base_error_0.__hash__()

# Generated at 2022-06-26 10:00:04.865088
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError(code="custom", text='""')
    base_error_1 = BaseError(code="custom", text='""')
    int_0 = base_error_0.__eq__(base_error_1)
    int_0 = base_error_1.__eq__(base_error_1)
    int_0 = base_error_0.__eq__(base_error_0)
    int_0 = base_error_1.__eq__(base_error_0)
    base_error_1 = BaseError()


# Generated at 2022-06-26 10:00:08.852796
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    int_0 = validation_result_0.__iter__()


# Generated at 2022-06-26 10:00:10.434383
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError() == BaseError()


# Generated at 2022-06-26 10:00:14.961921
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = []
    error = ValidationError()
    test_obj = ValidationResult(value=value, error=error)
    result = test_obj.__iter__()
    assert isinstance(result, typing.Iterator)


# Generated at 2022-06-26 10:00:29.912659
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    base_error_0 = BaseError()
    validation_result_0 = ValidationResult(value=True)

    x = [
        True,
        'Ipsum eveniet et quaerat ut odit.',
        [1, 2, 3],
        'You received a valid ValidationResult'
    ]
    y = [
        'Ipsum eveniet et quaerat ut odit.',
        [1, 2, 3],
        'You received a valid ValidationResult'
    ]
    z = [
        [1, 2, 3],
        'You received a valid ValidationResult'
    ]
    tempResult = True
    count = 0
    for e in validation_result_0:
        if e != x[count]:
            tempResult = False
        count += 1


# Generated at 2022-06-26 10:00:37.006446
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Initialize class
    base_error_0 = BaseError()
    base_error_1 = BaseError()
    base_error_2 = BaseError()
    # Test if the objects are equal
    assert base_error_0 != base_error_1
    assert base_error_0 == base_error_2


# Generated at 2022-06-26 10:00:46.812031
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # BaseError has-a __iter__, but it is not an implementation of Mapping.
    # This means the base_error_0 will be mapped to a dict, which is not empty,
    # meaning the loop in __iter__ will be called at least once.

    base_error_0 = BaseError()

    instance_0 = ValidationResult(error=base_error_0)

    str_0 = ''.join(instance_0)



# Generated at 2022-06-26 10:00:51.231261
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    base_error_0 = BaseError()
    validation_result_0 = ValidationResult()
    for i, j in validation_result_0:
        pass  # code for the body of the for loop


# Generated at 2022-06-26 10:00:55.786873
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError()
    base_error_1 = BaseError()

    assert base_error_0 == base_error_1


# Generated at 2022-06-26 10:01:03.941912
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='', code='custom', key='', index=[], position=Position(line_no=0, column_no=0, char_index=0), start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))
    message_1 = Message(text='', code='custom', key='', index=[], position=Position(line_no=0, column_no=0, char_index=0), start_position=Position(line_no=0, column_no=0, char_index=0), end_position=Position(line_no=0, column_no=0, char_index=0))
    assert message_0 == message_1


# Generated at 2022-06-26 10:01:08.635716
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    base_error_0 = BaseError()
    validation_result_0 = ValidationResult()
    for _ in validation_result_0:
        pass


# Generated at 2022-06-26 10:01:15.859138
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    base_error_0 = BaseError()
    validation_result_0 = ValidationResult(error=base_error_0)
    list_0 = [base_error_0, None]
    list_1 = list(validation_result_0)
    assert list_0 == list_1


# Generated at 2022-06-26 10:01:20.530076
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    base_error_1 = BaseError()
    validation_result_0 = ValidationResult(error=base_error_1)
    assert not validation_result_0.__iter__().__equal__(iter([None, base_error_1]))


# Generated at 2022-06-26 10:01:24.649173
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert ValidationResult().__iter__ == ValidationResult().__iter__
    assert ValidationResult().__iter__ == ValidationResult().__iter__


# Generated at 2022-06-26 10:01:39.038758
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()


# Generated at 2022-06-26 10:01:46.205419
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    print("test_case_0")
    vr_0 = ValidationResult()
    assert list(vr_0) == [None, None]
    vr_1 = ValidationResult(value=1, error=None)
    assert list(vr_1) == [1, None]
    vr_2 = ValidationResult(value=None, error=ValidationError())
    assert list(vr_2) == [None, ValidationError()]
    vr_3 = ValidationResult(value=1, error=ValidationError())
    assert list(vr_3) == [1, ValidationError()]
    print("test_case_1")
    vr_4 = ValidationResult()
    assert tuple(vr_4) == (None, None)

# Generated at 2022-06-26 10:01:53.112735
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    base_error_0 = BaseError()
    result_0 = ValidationResult(error=base_error_0)
    iterator_0 = iter(result_0)
    result_str_0 = next(iterator_0)
    result_str_1 = next(iterator_0)
    assert result_str_0 is None
    assert isinstance(result_str_1, BaseError)
    assert result_str_1.__class__ == BaseError


# Generated at 2022-06-26 10:01:54.979087
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    test_case_0()


if __name__ == "__main__":
    test_Message___eq__()

# Generated at 2022-06-26 10:02:05.405221
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='test_text', code='test_code', index=[1, '2'], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    message2 = Message(text='test_text', code='test_code', index=[1, '2'], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    assert message1 == message2

# Generated at 2022-06-26 10:02:09.647938
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    base_error_0 = BaseError()
    validation_result = ValidationResult(error=base_error_0)
    if validation_result is None:
        return ValueError('Parameter validation_result is None.')
    assert validation_result.__iter__() is not None


# Generated at 2022-06-26 10:02:15.767572
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr_0 = ValidationResult(error=ValidationError())
    vr_1 = ValidationResult(error=ValidationError(), value=3)
    vr_2 = ValidationResult(value=2)
    vr_3 = ValidationResult(value=2, error=ValidationError())



# Generated at 2022-06-26 10:02:21.192697
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError()
    base_error_1 = BaseError()
    assert base_error_0 == base_error_1

    print(repr(base_error_0))
    print(base_error_0)
    print(base_error_0.messages())



# Generated at 2022-06-26 10:02:23.908945
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Tests that the method __iter__ of class ValidationResult returns a generator
    vr = ValidationResult()
    assert isinstance(vr.__iter__(),types.GeneratorType)

# Generated at 2022-06-26 10:02:26.270896
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    instance_0 = BaseError()
    instance_1 = BaseError()
    assert (instance_0 == instance_1) is True


# Generated at 2022-06-26 10:02:42.125194
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError()
    assert base_error_0.__eq__(base_error_0) is True
    base_error_1 = BaseError(messages=[Message(index=[], text='', code='')])
    assert base_error_1.__eq__(base_error_0) is False
    base_error_2 = BaseError(text='', code='')
    assert base_error_2.__eq__(base_error_0) is False
    base_error_3 = BaseError()
    assert base_error_3.__eq__(base_error_0) is True


# Generated at 2022-06-26 10:02:44.372157
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError()
    assert not base_error_0 == Exception()
    assert base_error_0 == BaseError()


# Generated at 2022-06-26 10:02:48.166734
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError(text='Nu8')
    base_error_1 = BaseError(index=['cYv'], text='Nu8')
    assert base_error_0 == base_error_1



# Generated at 2022-06-26 10:02:59.477838
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(line_no=1, column_no=3, char_index=1),
    )
    message_1 = Message(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(line_no=1, column_no=3, char_index=1),
    )
    # Equality operator should be defined on Message
    assert message_0 == message_1
    assert message_1 == message_0



# Generated at 2022-06-26 10:03:05.710573
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError()
    base_error_1 = BaseError()

    # __eq__ returns NotImplemented
    assert base_error_0 != base_error_1
    assert not (base_error_0 == base_error_1)


# Generated at 2022-06-26 10:03:07.898184
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert (message_0 == message_1)


# Generated at 2022-06-26 10:03:11.074414
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # instantiation of class Message
    message_0 = Message(text="message_text_0")

    assert (message_0 == message_0) == True


# Generated at 2022-06-26 10:03:24.729557
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    test_cases = [
        base_error_0 == BaseError(),
        base_error_1 == BaseError(text='test_string_0'),
        base_error_2 == BaseError(text='test_string_1', code='test_string_0'),
        base_error_3 == BaseError(text='test_string_1', key='/tmp/appscale/test_file_0',
                                  position=Position(2, 3, 4)),
        base_error_5 == BaseError(messages=[Message(text='test_string_0'), Message(text='test_string_1')]),
        base_error_6 == BaseError(messages=[Message(text='test_string_1')])]

# Generated at 2022-06-26 10:03:26.540972
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='May not have more than 100 characters', code='max_length')
    message_1 = Message(text='May not have more than 100 characters', code='max_length')

    assert message_0 == message_1


# Generated at 2022-06-26 10:03:38.664641
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='', code='', key=None, index=None, position=None, start_position=None, end_position=None)
    message_1 = Message(text='', code='', key=None, index=None, position=None, start_position=None, end_position=None)
    assert message_0 == message_1
    message_2 = Message(text='', code='', key=None, index=None, position=None, start_position=None, end_position=None)
    assert message_0 == message_2
    message_3 = Message(text='', code='', key=None, index=None, position=None, start_position=None, end_position=None)
    assert message_0 == message_3

# Generated at 2022-06-26 10:03:56.992173
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_1 = BaseError()
    base_error_2 = BaseError()
    assert base_error_1 == base_error_2
    

# Generated at 2022-06-26 10:04:01.746306
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    #
    # A test for method __eq__ of class Message
    #

    msg = Message(text="Test message", code="custom", index=[1, 2, 3])
    assert msg == Message(text="Test message", code="custom", index=[1, 2, 3])
    assert msg != Message(text="Test message", code="custom", index=[1, 2, 4])



# Generated at 2022-06-26 10:04:11.660189
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError(text='test_string')

    assert base_error_0 == base_error_0
    assert base_error_0 == BaseError(text='test_string')
    assert base_error_0 == BaseError(key=0)
    assert base_error_0 == BaseError(key=0, code='custom')
    assert base_error_0 == BaseError(key=0, code='custom', text='test_string')

    assert not base_error_0 == BaseError(text='test_string', code='custom')
    assert not base_error_0 == BaseError(key=0, code='custom', text='test_string_1')
    assert not base_error_0 == BaseError(key=1, code='custom', text='test_string')

# Generated at 2022-06-26 10:04:13.916771
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError()
    base_error_1 = BaseError()
    assert base_error_0 == base_error_1


# Generated at 2022-06-26 10:04:17.508196
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    print(message_0 == message_1)

    message_2 = Message()
    message_3 = Message()
    print(message_2 == message_3)


# Generated at 2022-06-26 10:04:19.068670
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    value = BaseError()
    res = value == None

# Generated at 2022-06-26 10:04:21.838105
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test method arguments
    expected_0 = None

    # Invocation
    result = BaseError.__eq__(expected_0)

    # Test return type
    assert isinstance(result, bool)


# Generated at 2022-06-26 10:04:26.437153
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='', code='', index=[], position=Position(0, 0, 0))
    message_1 = Message(text='', code='', index=[], position=Position(0, 0, 0))
    assert message_0 == message_1


# Generated at 2022-06-26 10:04:30.059099
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message('text_test_0', 'code_test_0', 'key_test_0', ['index_test_0', 'index_test_1'])
    m2 = Message('text_test_0', 'code_test_0', 'key_test_0', ['index_test_0', 'index_test_1'])
    assert m1 == m2


# Generated at 2022-06-26 10:04:35.403262
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError()
    base_error_1 = BaseError()
    assert base_error_0 == base_error_1
    base_error_2 = BaseError(text='message')
    assert not base_error_1 == base_error_2
    assert not base_error_0 == base_error_2


# Generated at 2022-06-26 10:05:11.056485
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    this = Message(text="text", code="code", index=["index"], start_position="start_position", end_position="end_position")
    other = Message(text="text", code="code", index=["index"], start_position="start_position", end_position="end_position")
    assert this == other


# Generated at 2022-06-26 10:05:14.631708
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m = Message(text="error", code="custom", key=1)
    m1 = Message(text="error1", code="custom", key=1)
    assert m == m
    assert not m == m1
    assert not m == "error"


# Generated at 2022-06-26 10:05:22.975144
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    t_Message___eq__ = Message(text = 'text_0', code='code_0', key=0, position=Position(line_no=0, column_no=0, char_index=0))
    s_Message___eq__ = Message(text = 'text_0', code='code_0', key=0, position=Position(line_no=0, column_no=0, char_index=0))
    if (t_Message___eq__ == s_Message___eq__) == True:
        pass
    else:
        raise RuntimeError("Error: Failed to test __eq__ of class Message.")


# Generated at 2022-06-26 10:05:32.177045
# Unit test for method __eq__ of class Message
def test_Message___eq__():

    message_0 = Message(
        text='a', code='custom', key=1, start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=4, column_no=5, char_index=6)
    )
    message_1 = Message(
        text='a', code='custom', index=[1], start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=4, column_no=5, char_index=6)
    )

    if (message_0 == message_1):
        pass
    else:
        raise Exception('AssertionError')


# Generated at 2022-06-26 10:05:36.837971
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = ValidationError()
    base_error_1 = ValidationError()
    assert base_error_0 == base_error_1


# Generated at 2022-06-26 10:05:44.425202
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(code="", index=[], start_position=Position(0, 0, 0), text="", end_position=Position(0, 0, 0))
    message_1 = Message(code="", index=[], start_position=Position(0, 0, 0), text="", end_position=Position(0, 0, 0))
    assert message_0 == message_1


# Generated at 2022-06-26 10:05:46.486829
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError()
    base_error_1 = BaseError()
    assert base_error_0 == base_error_1


# Generated at 2022-06-26 10:05:48.405883
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    a_0 = BaseError()
    a_1 = BaseError()
    assert a_0 == a_1


# Generated at 2022-06-26 10:05:50.425125
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    base_error_0 = BaseError()
    base_error_1 = BaseError()
    assert base_error_0 == base_error_1


# Generated at 2022-06-26 10:05:51.791182
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    x = BaseError()
    y = BaseError()
    assert x == y
