

# Generated at 2022-06-26 09:59:36.189680
# Unit test for method __eq__ of class Position

# Generated at 2022-06-26 09:59:41.036465
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = 'Bb35#!q3'
    base_error_1 = BaseError()
    base_error_1.messages = mock.MagicMock()
    base_error_1.messages.__iter__.return_value = str_0
    validation_result_0 = ValidationResult()
    validation_result_0.error = base_error_1
    list_0 = list(validation_result_0.__iter__())
    assert list_0 == [None, str_0]



# Generated at 2022-06-26 09:59:45.229431
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '~2zHY4\r!0[@)@,P'
    validation_result_0 = ValidationResult(error=str_0)
    validation_result_0_iter = validation_result_0.__iter__()
    assert bool(validation_result_0_iter) == bool(iter(validation_result_0_iter))


# Generated at 2022-06-26 09:59:57.377120
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    str_0 = 'p@!B'
    str_1 = '~$q3'
    int_0 = -619146237
    int_1 = 83919
    int_2 = -3005
    position_0 = Position(int_0, int_1, int_2)
    position_1 = Position(int_1, int_2, int_0)
    position_2 = Position(int_0, int_1, int_2)
    position_3 = Position(int_1, int_2, int_0)
    str_2 = 'vz#W'
    int_3 = 1616478580
    int_4 = -705894100
    int_5 = -1634135413
    position_4 = Position(int_2, int_0, int_1)


# Generated at 2022-06-26 10:00:00.306592
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '`8W`5TN$v'
    base_error_0 = BaseError(text=str_0)
    validation_result_0 = ValidationResult(value=None, error=base_error_0)

    for element in validation_result_0:
        print(element)


# Generated at 2022-06-26 10:00:00.941566
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert True == True


# Generated at 2022-06-26 10:00:11.007959
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = 'v7\x00W8M\x0f\x11\x1d\\F\x1fL*\x00'
    val_result_0 = ValidationResult(error=ValidationError(text=str_0))
    str_1 = '~2zHY4\r!0[@)@,P'
    val_result_1 = ValidationResult(error=ValidationError(text=str_1))
    list_0 = [val_result_1, val_result_1, val_result_1, val_result_0]
    str_2 = 'b\x14\t!\x1c\x1aF\r\r\t'
    val_result_2 = ValidationResult(error=ValidationError(text=str_2))

# Generated at 2022-06-26 10:00:15.018041
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = ';L'
    message_0 = Message(text=str_0)
    end_position = None
    position = Position(column_no=0, char_index=0, line_no=0)
    message_1 = Message(text=str_0, position=position, end_position=end_position)
    assert message_0 == message_1


# Generated at 2022-06-26 10:00:25.808656
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    str_0 = '~2zHY4\r!0[@)@,P'
    base_error_0 = BaseError(text=str_0)
    str_1 = '9=U1h#U?~v7V25Q'
    base_error_1 = BaseError(text=str_1)
    base_error_2 = BaseError(text=str_1)
    base_error_3 = BaseError(text=base_error_2)
    base_error_4 = BaseError(text=base_error_2)
    # Check the BaseError is equal to itself.
    assert base_error_0 == base_error_0
    # Check the BaseError is not equal to another object with a different identity.
    assert base_error_0 != base_error_1
    # Check the BaseError is

# Generated at 2022-06-26 10:00:37.315612
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = 'btwJH'
    str_1 = '6YpJ'
    position_0 = Position(char_index=0, line_no=0, column_no=0)
    message_0 = Message(position=position_0, code=str_1, text=str_0)
    message_1 = Message(position=position_0, code=str_1, text=str_0)
    bool_0 = message_0 == message_1
    bool_1 = message_0 == message_0
    assert bool_0 == bool_1


# Generated at 2022-06-26 10:00:47.553160
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '~2zHY4\r!0[@)@,P'
    base_error_0 = BaseError(text=str_0)
    validation_result_0 = ValidationResult(error=base_error_0)
    assert validation_result_0.__iter__() is not None


# Generated at 2022-06-26 10:00:52.459609
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '~2zHY4\r!0[@)@,P'
    base_error_0 = BaseError(text=str_0)
    validation_result_0 = ValidationResult(error=base_error_0)
    validation_result_0.__iter__()


# Generated at 2022-06-26 10:00:59.271033
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '~2zHY4\r!0[@)@,P'
    base_error_0 = BaseError(text=str_0)
    validation_result_0 = ValidationResult(error=base_error_0)
    if validation_result_0 is not None:
        print(next(iter(validation_result_0)))
    else:
        print(None)


# Generated at 2022-06-26 10:01:08.910565
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '\t'
    str_1 = '\n'
    str_2 = '\x0c'
    base_error_0 = BaseError(text=str_0)
    base_error_1 = BaseError(text=str_1)
    validation_result_0 = ValidationResult(value=str_2, error=base_error_0)
    validation_result_1 = ValidationResult(value=str_1, error=base_error_1)
    lst_0 = list(validation_result_1)
    lst_1 = list(validation_result_0)
    lst_0 = list(validation_result_1)
    lst_1 = list(validation_result_0)
    lst_2 = lst_0 + lst_1
   

# Generated at 2022-06-26 10:01:19.244017
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = 'fy3\x1f[K)c%'
    base_error_0 = BaseError(text=str_0)
    str_1 = 'J\x0eK6U\x1f\\'
    validation_result_0 = ValidationResult(value=str_1, error=base_error_0)
    tuple_1 = validation_result_0.__iter__()
    for value_0 in tuple_1:
        pass


# Generated at 2022-06-26 10:01:24.578033
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = 'Cd2[@\'%4C'
    validation_result_0 = ValidationResult(error=BaseError(text=str_0))
    validation_result_1 = ValidationResult(value=validation_result_0)
    iter0 = validation_result_1.__iter__()
    assert iter0.__next__() == validation_result_0
    assert iter0.__next__() is None
    validation_result_2 = ValidationResult(value=True)
    iter1 = validation_result_2.__iter__()
    assert iter1.__next__() is True
    assert iter1.__next__() is None


# Generated at 2022-06-26 10:01:35.130385
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '#X'
    int_0 = 200
    str_1 = '<xkDIX'
    base_error_0 = BaseError(text=str_0)
    validation_result_0 = ValidationResult(value=int_0, error=base_error_0)
    str_2 = '~&w{[wuhe$'
    int_1 = 600
    validation_result_1 = ValidationResult(value=int_1, error=validation_result_0)
    list_0 = []
    for index_0 in range(3):
        list_0.append(validation_result_1)
    validation_result_2 = ValidationResult(value=list_0, error=validation_result_1)
    base_error_1 = BaseError(text=str_1)

# Generated at 2022-06-26 10:01:42.827857
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = '~2zHY4\r!0[@)@,P'
    message_0 = Message(text=str_0)
    message_1 = Message(text=str_0, code='custom', index=[])
    message_2 = Message(text=str_0, index=[])
    message_3 = Message(text=str_0, code='custom')
    assert message_1 == message_2
    assert not message_2 == message_3


# Generated at 2022-06-26 10:01:45.087275
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert __name__ == '__main__'
    pytest.skip('No tests for abstract method')


# Generated at 2022-06-26 10:01:55.857920
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = 'eIj{'
    val_0 = ValidationResult(value=str_0)
    str_1 = '5W_;8\n'
    val_1 = ValidationResult(error=str_1)
    str_2 = '.\x1a\x05'
    val_2 = ValidationResult(value=str_2)
    str_3 = 'u`d(|'
    val_3 = ValidationResult(value=str_3)
    str_4 = ':'
    val_4 = ValidationResult(error=str_4)
    str_5 = 'g'
    val_5 = ValidationResult(error=str_5)
    str_6 = 'M'
    val_6 = ValidationResult(error=str_6)

# Generated at 2022-06-26 10:01:59.581751
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    messages = Message(text='foo')
    assert messages != Message(text='baz')



# Generated at 2022-06-26 10:02:05.362084
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = '~2zHY4\r!0[@)@,P'
    message_0 = Message(text=str_0)
    str_1 = 'V\x1b/p\x7f\x11\x1c\x12;|k'
    message_1 = Message(text=str_1)
    message_0 == message_1


# Generated at 2022-06-26 10:02:16.869003
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = 'c%RjJT`d\r}O\'Q\x0cR'
    str_1 = '\x0b[3m,U6f%c'
    message_0 = Message(text=str_0, code=str_1, index=['N1', True, False, '<'], position=Position(line_no=0, column_no=0, char_index=0))
    message_1 = Message(text=str_0, code=str_1, index=['N1', True, False, '<'], position=Position(line_no=0, column_no=0, char_index=0))
    assert message_0 == message_1


# Generated at 2022-06-26 10:02:21.638748
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    int_0 = 0
    # Test default argument
    result = ValidationResult()
    assert result.value is None
    assert result.error is None
    for item in result:
        int_0 += 1
    assert int_0 == 2


# Generated at 2022-06-26 10:02:30.318775
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '~2zHY4\r!0[@)@,P'
    base_error_0 = BaseError(text=str_0)
    validation_result_0 = ValidationResult(error=base_error_0)
    validation_result_1 = ValidationResult(error=base_error_0)
    validation_result_2 = ValidationResult(error=base_error_0)
    validation_result_3 = ValidationResult(error=base_error_0)
    validation_result_4 = ValidationResult(error=base_error_0)
    validation_result_5 = ValidationResult(error=base_error_0)
    validation_result_6 = ValidationResult(error=base_error_0)
    validation_result_7 = ValidationResult(error=base_error_0)

# Generated at 2022-06-26 10:02:41.691434
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = '7'
    str_1 = '>'
    str_2 = 's8J'
    str_3 = '~2zHY4\r!0[@)@,P'
    str_4 = '~2zHY4\r!0[@)@,P'
    str_5 = '~2zHY4\r!0[@)@,P'
    str_6 = '~2zHY4\r!0[@)@,P'
    str_7 = '~2zHY4\r!0[@)@,P'
    str_8 = '~2zHY4\r!0[@)@,P'
    str_9 = '~2zHY4\r!0[@)@,P'

# Generated at 2022-06-26 10:02:44.001257
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='a', code='b')
    boolean_result_0 = message_0 == message_0


# Generated at 2022-06-26 10:02:52.554728
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '75'
    int_0 = 8
    base_error_0 = BaseError(text=str_0)
    validation_result_0 = ValidationResult(value=int_0, error=base_error_0)
    iter_0 = validation_result_0.__iter__()
    assert type(iter_0) is typing.Iterator
    int_0
    base_error_0
    assert type(iter_0) is typing.Iterator


# Generated at 2022-06-26 10:03:00.622870
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Initialization
    # Local variables
    value_0 = None
    error_0 = None
    validation_result_0 = ValidationResult(value=value_0, error=error_0)
    # Testing
    validation_result_0_iterator = validation_result_0.__iter__()
    # Checking against expected results
    assert validation_result_0_iterator.__next__() == None
    assert validation_result_0_iterator.__next__() == None
    # Cleanup - None
    return 


# Generated at 2022-06-26 10:03:13.287234
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = '4<6:s8s{2g|9X'
    str_1 = '8o$=w29&+p"`'
    str_2 = '7Mj9*nv{,7;]z'
    pos_0 = Position(line_no=5, column_no=56, char_index=48)
    pos_1 = Position(line_no=51, column_no=19, char_index=23)
    pos_2 = Position(line_no=97, column_no=85, char_index=45)
    pos_3 = Position(line_no=12, column_no=96, char_index=1)
    mes_0 = Message(text=str_0, code=str_1, key=str_2, position=pos_0)
    mes_

# Generated at 2022-06-26 10:03:23.995410
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '~2zHY4\r!0[@)@,P'
    base_error_0 = BaseError(text=str_0)
    validation_result_0 = ValidationResult(error=base_error_0)
    assert isinstance(validation_result_0, ValidationResult)
    assert isinstance(validation_result_0.__iter__(), typing.Iterator)
    assert isinstance(validation_result_0.__iter__().__next__(), typing.Any)


# Generated at 2022-06-26 10:03:37.077302
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    int_0 = 2
    int_1 = 2
    int_2 = 3
    int_3 = 3
    str_0 = ';F)7~|4E'
    str_1 = 'R9Mk)>rTm'
    str_2 = ':3g![\r^'
    str_3 = '9o\ra_Ua>'
    str_4 = 'lw\n0/0P'
    str_5 = 'f?ee&~r'
    str_6 = 'QsKsHqc'
    position_0 = Position(line_no=511, column_no=146, char_index=571)
    position_1 = Position(line_no=35, column_no=81, char_index=208)

# Generated at 2022-06-26 10:03:44.243573
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '}N6~$?6L[1<]=_H/|'
    base_error_0 = BaseError(text=str_0)
    validation_result_0 = ValidationResult(error=base_error_0)
    yield from validation_result_0


# Generated at 2022-06-26 10:03:46.769434
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    str_0 = 'N6UW[7\00IG:G'
    position_0 = Position(line_no=0, column_no=0, char_index=0)
    position_1 = Position(line_no=1, column_no=1, char_index=1)
    base_error_0 = BaseError(text=str_0)
    assert not position_0 == position_1


# Generated at 2022-06-26 10:03:55.011093
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = 'a8I$D'
    base_error_0 = BaseError(text=str_0)
    validation_result_0 = ValidationResult(error=base_error_0)
    it = validation_result_0.__iter__()
    assert next(it) is None
    assert next(it) == base_error_0


# Generated at 2022-06-26 10:03:59.467689
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Initialize a ValidationResult with (value, error) pair
    validation_result_0 = ValidationResult(value=float('nan'), error=())
    result = validation_result_0.__iter__()
    assert isinstance(result, typing.Iterator)


# Generated at 2022-06-26 10:04:09.480587
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    str_0 = '~2zHY4\r!0[@)@,P'
    base_error_0 = BaseError(text=str_0)
    validation_result_0 = ValidationResult(error=base_error_0)
    str_1 = ''
    str_2 = 'Y2U6Q['
    base_error_1 = BaseError(text=str_1, key=str_2)
    validation_result_1 = ValidationResult(error=base_error_1)
    float_0 = float() #float()
    validation_result_2 = ValidationResult(value=float_0)
    int_0 = int() #int()
    validation_result_3 = ValidationResult(value=int_0)

# Generated at 2022-06-26 10:04:15.411394
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    int_0 = 8
    int_1 = 1
    int_2 = 1
    position_0 = Position(int_0, int_1, int_2)
    position_1 = Position(int_0, int_1, int_2)
    # AssertionError: False is not true : Position(line_no=8, column_no=1, char_index=1)
    assert position_0 == position_1



# Generated at 2022-06-26 10:04:25.946482
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(26, -99, 52)
    position_1 = Position(49, 52, -98)
    position_2 = Position(62, 99, 71)
    position_3 = Position(86, -61, -55)
    position_4 = Position(36, -92, 52)
    position_5 = Position(81, 52, -39)
    position_6 = Position(99, 71, 62)
    position_7 = Position(56, -55, 86)
    position_8 = Position(58, -56, 85)
    position_9 = Position(77, 70, 59)
    position_10 = Position(37, -91, 52)
    position_11 = Position(82, 52, -38)
    position_12 = Position(100, 71, 62)

# Generated at 2022-06-26 10:04:32.382686
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = '()*$!)h'
    int_0 = 5
    message_0 = Message(text=str_0, key=int_0)
    message_1 = Message(text=str_0, key=int_0)
    message_2 = Message(text=str_0, key=int_0)
    message_3 = Message(text=str_0, key=int_0)
    assert message_0 == message_1
    message_0.text = '!'
    assert message_0 != message_1
    message_0.text = str_0
    message_0.code = '~'
    assert message_0 != message_1
    message_0.code = message_1.code
    message_0.index.append('~')
    assert message_0 != message_1
    message

# Generated at 2022-06-26 10:04:46.177110
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = '1'
    int_0 = -836048355
    str_1 = '2'
    int_1 = -8350082
    int_2 = -853975297
    str_2 = '3'
    str_3 = '4'
    position_0 = Position(line_no=str_0, column_no=int_0, char_index=str_1)
    position_1 = Position(line_no=str_2, column_no=int_1, char_index=int_2)
    position_2 = Position(line_no=str_3, column_no=int_1, char_index=int_2)

# Generated at 2022-06-26 10:04:57.109787
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = 'GATCcaTGt\x7f8%v]@[n'
    str_1 = 'f?|n-9qa#~H\u000cw\x18Nqq'
    list_0 = []
    position_0 = Position(line_no=3, column_no=0, char_index=3)
    message_0 = Message(text=str_0, code=str_1, index=list_0, position=None, start_position=position_0, end_position=position_0)
    str_2 = 'GATCcaTGt\x7f8%v]@[n'
    str_3 = 'f?|n-9qa#~H\u000cw\x18Nqq'
    list_1 = []

# Generated at 2022-06-26 10:05:03.571328
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = '~2zHY4\r!0[@)@,P'
    message_0 = Message(text=str_0)
    str_1 = 'N}lN[P]Xy*a k'
    message_1 = Message(text=str_1)
    message_2 = Message(text=str_1)
    str_2 = ''
    message_3 = Message(text=str_2)
    assert not (message_1 == message_0)
    assert message_1 == message_2
    assert not (message_1 == message_3)



# Generated at 2022-06-26 10:05:05.563275
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = 'T+v;e^(H}d\x7f&n:gv'
    base_error_0 = BaseError(text=str_0)


# Generated at 2022-06-26 10:05:10.589527
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test Cases
    str_0 = '~2zHY4\r!0[@)@,P'
    int_0 = -65
    base_error_0 = BaseError(text=str_0)
    pos_0 = Position(line_no=int_0, column_no=int_0, char_index=int_0)
    int_1 = -65
    position_0 = Position(line_no=int_1, column_no=int_1, char_index=int_1)
    position_1 = Position(line_no=int_0, column_no=int_0, char_index=int_0)
    # Assertions

    assert not pos_0.__eq__(base_error_0)
    assert pos_0 == position_0
    assert not pos_0 == position

# Generated at 2022-06-26 10:05:21.018964
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = 'T<dHm\t@fVzgZ6-\x7f'
    code_0 = 'max_length'
    position_0 = Position(column_no=54, char_index=2, line_no=0)
    start_position_0 = Position(column_no=60, char_index=8, line_no=0)
    end_position_0 = Position(column_no=55, char_index=3, line_no=0)
    message_0 = Message(text=str_0, code=code_0, position=position_0, start_position=start_position_0, end_position=end_position_0)
    code_1 = 'min_length'

# Generated at 2022-06-26 10:05:30.514872
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Init a Message object
    str_0 = '1#9\n}'
    str_1 = 'Y(7i?\tj'
    str_2 = 't&9Q>'
    str_3 = 'Y(7i?\tj'
    list_0 = [str_3]
    message_0 = Message(text=str_0, code=str_1, key=str_2, index=list_0)

    # Init another Message object
    str_4 = 'Y(7i?\tj'
    list_1 = [str_4]
    str_5 = '1#9\n}'
    str_6 = 't&9Q>'
    str_7 = 'Y(7i?\tj'

# Generated at 2022-06-26 10:05:39.608714
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    int_0 = 78843
    str_0 = 'The error message. \'May not have more than 100 characters\''
    str_1 = 'An optional error code, eg. \'max_length\''
    str_2 = 'An optional key of the message within a single parent. eg. \'username\''
    position_0 = Position(line_no=int_0, column_no=int_0, char_index=int_0)
    message_0 = Message(text=str_0, code=str_1, key=str_2, position=position_0)
    position_1 = Position(line_no=int_0, column_no=int_0, char_index=int_0)

# Generated at 2022-06-26 10:05:48.404763
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = 'L8DR\x0f'
    str_1 = '\\\\l"\t'
    str_2 = 'd;v'
    str_3 = 'tT?Tt'
    int_0 = 3147779
    int_1 = -37690829
    int_2 = 962137682
    position_0 = Position(int_0, int_1, int_2)
    code_0 = '{&b\x19'
    message_0 = Message(code=code_0, position=position_0, text=str_0)
    message_1 = Message(index=[int_0, int_1, int_2], text=str_1)
    assert message_0 == message_1


# Generated at 2022-06-26 10:05:52.447098
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(column_no=313129927, line_no=1069777854, char_index=1701523123)
    position_1 = Position(line_no=893301931, char_index=1179520018, column_no=687133377)
    assert not (position_0 == position_1)
    assert not (position_0 == position_0)



# Generated at 2022-06-26 10:06:04.034315
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = 'Sfx1\t+dTkKP&@T}4$'
    str_0 = str_0
    str_1 = "gnmf@BnGs,B+9'v=E"
    str_1 = str_1
    str_2 = '7*U6R>8VH,M6|D52G\x0a'
    str_2 = str_2
    str_3 = 'Bnf^k#}K+Rl:|lIb\t'
    str_3 = str_3
    int_0 = 816945651
    str_4 = '\x0f|J.~8>Nkf\r(rGB'

# Generated at 2022-06-26 10:06:14.292049
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = 'eV9'
    str_1 = 'f{Qb'
    str_2 = 'Pc'
    list_0 = []
    list_1 = []
    position_0 = Position(0, 0, 0)
    position_1 = Position(0, 0, 0)
    message_0 = Message(text=str_0, code=str_1, index=list_0, position=position_0, end_position=position_1)
    message_1 = Message(text=str_2, code=str_2, index=list_1, position=position_0, end_position=position_1)
    bool_0 = message_0 == message_1
    bool_1 = not bool_0
    assert bool_1


# Generated at 2022-06-26 10:06:26.444261
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = '`g\x1d\tX\x1dl\x1a\x1e'
    str_1 = '~2zHY4\r!0[@)@,P'
    message_0 = Message(text=str_0, code=str_1, key=None, index=None, position=None, start_position=None, end_position=None)
    str_2 = '`g\x1d\tX\x1dl\x1a\x1e'
    str_3 = '~2zHY4\r!0[@)@,P'
    message_1 = Message(text=str_2, code=str_3, key=None, index=None, position=None, start_position=None, end_position=None)


# Generated at 2022-06-26 10:06:37.076085
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = '%T[f,s^M!\x0fYv\x1c'
    int_0 = -1212215938
    str_1 = '|@:mq^\x1c`j\x1f-p'
    int_1 = 975124471
    message_0 = Message(text=str_0, code=str_1, key=int_0)
    message_1 = Message(text=str_0, code=str_1, index=[int_0])
    message_2 = Message(text=str_0, index=[int_0])

# Generated at 2022-06-26 10:06:45.029567
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    int_0 = 1
    str_0 = 'v<7[YBHs#K8'
    base_error_0 = BaseError(messages=[Message(text=str_0, code=None, key=int_0)])
    base_error_1 = BaseError(messages=[Message(text=str_0, code='data_required')])
    base_error_2 = BaseError(messages=[Message(text=str_0, code='data_required')])
    assert base_error_1 == base_error_2
    assert base_error_1 != base_error_0


# Generated at 2022-06-26 10:06:50.499821
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    int_0 = 14
    int_1 = 12
    int_2 = 4
    position_0 = Position(int_0, int_1, int_2)
    assert position_0.__eq__(position_0) == True


# Generated at 2022-06-26 10:07:01.202283
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    str_0 = '~2zHY4\r!0[@)@,P'
    base_error_0 = BaseError(text=str_0)
    str_1 = '_N/ http(g'
    base_error_1 = BaseError(text=str_1)
    str_2 = '6:kB?D(\x06\nx+'
    base_error_2 = BaseError(text=str_2)
    str_3 = '{c_Z,(xI'
    base_error_3 = BaseError(text=str_3)
    str_4 = '#c,R#;'
    base_error_4 = BaseError(text=str_4)
    base_error_5 = BaseError()
    str_5 = 'z5'
    base_error_6

# Generated at 2022-06-26 10:07:12.992246
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = ':kz'
    int_0 = -28369
    int_1 = -11254
    str_1 = 'pjK'
    int_2 = 70315
    str_2 = 'X6'
    int_3 = -17
    str_3 = 'w4'
    message_0 = Message(text=str_0, code=str_1, key=str_2, index=[int_0, int_1])
    message_1 = Message(text=str_2, code=str_3, key=str_3, index=[int_2, int_3])
    assert not (message_0 == message_1)
    message_2 = Message(text=str_2, code=str_1, key=str_2, index=[int_0, int_1])
   

# Generated at 2022-06-26 10:07:19.421174
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # case 1
    str_0 = 'Xm}#\rB^m\rz'
    line_no_0 = 93
    column_no_0 = 83
    char_index_0 = 67
    position_0 = Position(line_no_0, column_no_0, char_index_0)
    line_no_1 = 44
    column_no_1 = 44
    char_index_1 = 78
    position_1 = Position(line_no_1, column_no_1, char_index_1)
    assert position_0 == position_1


# Generated at 2022-06-26 10:07:28.016566
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = '1:9l'
    code_0 = '1:9l'
    float_0 = 89.1649171437
    str_1 = '1:9l'
    position_0 = Position(line_no=float_0, column_no=float_0, char_index=float_0)
    message_0 = Message(text=str_0, code=code_0, index=[float_0], position=position_0)
    message_1 = Message(text=str_1, code=code_0, index=[float_0], position=position_0)
    int_0 = 0
    str_2 = '1:9l'
    message_2 = Message(text=str_2, code=code_0, index=[float_0], position=position_0)
    str_

# Generated at 2022-06-26 10:07:44.764651
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = 'EJ-5}H;S+XplaS_'
    position_0 = Position(char_index=4, column_no=10, line_no=3)
    str_1 = 'BZ=7b#e$G'
    code_0 = 'dummy_code'
    ending_index = 3
    str_2 = 'l\tJj'
    str_3 = 'aA_b'
    str_4 = 'O+(H'
    position_1 = Position(char_index=7, column_no=1, line_no=9)
    message_0 = Message(text=str_0, code=code_0, index=[0], position=position_0)

# Generated at 2022-06-26 10:07:51.970390
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='', code='').__eq__(Message(text='', code='')) == True
    assert Message(text='', code='').__eq__(Message(text='', code='a')) == False
    assert Message(text='a', code='').__eq__(Message(text='a', code='')) == True
    assert Message(text='a', code='').__eq__(Message(text='a', code='a')) == False
    assert Message(text='a', code='').__eq__(Message(text='', code='')) == False
    assert Message(text='', code='').__eq__(Message(text='a', code='')) == False
    assert Message(text='', code='a').__eq__(Message(text='', code='a')) == True
   

# Generated at 2022-06-26 10:08:01.348751
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = 'L^O\\d,H@{T\\3g2'
    str_1 = '"\x1c'
    message_0 = Message(text=str_0, key=str_0, start_position=str_1)
    message_1 = Message(text=str_0, key=str_0, start_position=str_1)
    bool_0 = message_0.__eq__(message_1)
    str_2 = 'O<J+Cmf)m\x0e6\x1e'
    message_2 = Message(text=str_0, key=str_0, start_position=str_2)
    bool_1 = message_0.__eq__(message_2)
    str_3 = 'B`'

# Generated at 2022-06-26 10:08:03.753940
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position_0 = Position(line_no=-1, column_no=-1, char_index=-1)
    position_1 = Position(line_no=0, column_no=0, char_index=0)
    assert position_0 == position_1


# Generated at 2022-06-26 10:08:08.597452
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='May not have more than 100 characters', code='max_length')
    message_1 = Message(text='May not have more than 100 characters', code='max_length')
    message_2 = Message(text='May not have more than 100 characters', code='max_length')
    assert message_0 != message_1
    assert message_0 == message_1
    assert message_0 != message_2
    assert message_0 == message_2
    assert message_1 != message_2
    assert message_1 == message_2


# Generated at 2022-06-26 10:08:11.686636
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    import pytest
    # Preparation
    text = 'hello world'
    code = 'my_code_name'
    index = [1, 2, 3]
    position = Position(1, 2, 3)
    start_position = Position(3, 4, 5)
    end_position = Position(6, 7, 8)
    message_0 = Message(text=text, code=code, index=index, position=position)
    message_1 = Message(text=text, code=code, index=index, position=position)

# Generated at 2022-06-26 10:08:19.471966
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    try:
        str_0 = '5(0:M)'
        base_error_0 = BaseError(text=str_0)
    except Exception as e:
        raise

    try:
        bool_0 = bool()
    except Exception as e:
        raise

    try:
        str_0 = '4D'
        base_error_0 = BaseError(text=str_0)
    except Exception as e:
        raise

    try:
        str_0 = '=>M3'
        base_error_0 = BaseError(text=str_0)
    except Exception as e:
        raise

    try:
        str_0 = 'J>e'
        base_error_0 = BaseError(text=str_0)
    except Exception as e:
        raise


# Generated at 2022-06-26 10:08:23.091536
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text='', code='', start_position=Position(line_no=0, column_no=0, char_index=0))
    message_1 = Message(text='', code='', start_position=Position(line_no=0, column_no=0, char_index=0))
    int_2 = message_0 == message_1


# Generated at 2022-06-26 10:08:26.697658
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    str_0 = '<JnM'
    base_error_0 = BaseError(text=str_0)
    int_0 = 9
    position_0 = Position(int_0, 0, 0)
    position_1 = Position(int_0, 0, 0)
    assert position_1 == position_0


# Generated at 2022-06-26 10:08:35.742697
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    str_0 = '%BdV7y\x0f\x7f\x1b`V^'
    str_1 = '\x08\x00\x12\x00\x13\x00'
    str_2 = ';5^(7\x0b'
    str_3 = 'LlXVE\x17\x18\x19\x1a\x1b'
    position_0 = Position(char_index=1, column_no=-72, line_no=0)
    message_0 = Message(code=str_0, index=[0, 0, -1], position=position_0, text=str_1)
    message_1 = Message(code=str_2, key=0, text=str_3)

# Generated at 2022-06-26 10:08:52.966922
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    num_0 = ~7
    num_1 = -56
    position_0 = Position(num_0, num_0, num_1)
    position_1 = Position(num_0, num_1, num_0)
    position_2 = Position(num_0, num_1, num_0)
    position_3 = Position(num_1, num_0, num_1)
    position_4 = Position(num_1, num_0, num_1)
    position_5 = Position(num_1, num_1, num_1)
    position_6 = Position(num_1, num_1, num_1)
    position_7 = Position(num_1, num_0, num_0)
    position_8 = Position(num_1, num_0, num_0)

# Generated at 2022-06-26 10:09:01.232438
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # ---
    str_0 = 'Qoz#7V.'
    str_1 = 'Mg& '

# Generated at 2022-06-26 10:09:06.381454
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    int_0 = random.randint(0, 9)
    str_0 = '~2zHY4\r!0[@)@,P'
    int_1 = random.randint(0, 9)
    int_2 = random.randint(0, 9)
    int_3 = random.randint(0, 9)
    int_4 = random.randint(0, 9)
    position_0 = Position(int_0, int_1, int_2)
    position_1 = Position(int_3, int_4, int_2)
    assert position_0 == position_1


# Generated at 2022-06-26 10:09:14.589881
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    int_0 = 6
    str_0 = 'TGSNq'
    int_1 = -13
    base_error_0 = BaseError(text=str_0, key=int_1)
    position_0 = Position(int_0, base_error_0, 0)
    int_2 = 10
    int_3 = 10
    position_1 = Position(int_2, int_3, 0)
    Position.__eq__(position_0, position_1)
