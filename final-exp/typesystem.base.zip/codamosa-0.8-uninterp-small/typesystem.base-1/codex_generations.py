

# Generated at 2022-06-26 09:59:20.290824
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    a = ValidationResult()
    assert isinstance(a.__iter__(), types.GeneratorType)


# Generated at 2022-06-26 09:59:25.369091
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_1 = ValidationResult()
    value_1 = validation_result_1.__iter__()



# Generated at 2022-06-26 09:59:32.963891
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    for step_0 in [0, 1]:
        if step_0:
            assert validation_result_0.__iter__() == iterator_0
        else:
            iterator_0 = validation_result_0.__iter__()
            assert iterator_0.__iter__() == iterator_0


# Generated at 2022-06-26 09:59:39.891500
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    try:
        import typesystem
        validation_result_0 = typesystem.ValidationResult()
        assert validation_result_0.__iter__() is not None
    except:
        import traceback
        exception = traceback.format_exc()
        print(exception, file=sys.stderr)
        raise


# Generated at 2022-06-26 09:59:49.368563
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    eq_test_case_0 = Message(
        text="test_0",
        code=None,
        key=None,
        index=None,
        position=None,
        start_position=None,
        end_position=None,
    )
    eq_test_case_1 = Message(
        text="test_0",
        code=None,
        key=None,
        index=None,
        position=None,
        start_position=None,
        end_position=None,
    )
    eq_test_result_0 = eq_test_case_0.__eq__(eq_test_case_1)


# Generated at 2022-06-26 09:59:55.798781
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    iterator_0 = validation_result_0.__iter__()
    assert validation_result_0.__bool__() is False
    assert validation_result_0.__repr__() == "ValidationResult(error=None)"
    assert iterator_0.__next__() is None
    assert validation_result_0.__bool__() is False



# Generated at 2022-06-26 10:00:01.564149
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    iterator_0 = validation_result_0.__iter__()
    value_0 = next(iterator_0)
    value_1 = next(iterator_0)


# Generated at 2022-06-26 10:00:06.154404
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    iterator_0 = validation_result_0.__iter__()
    assert isinstance(iterator_0, typing.Iterator) is True
    value_0, error_0 = iterator_0
    error_1 = validation_result_0.__iter__()


# Generated at 2022-06-26 10:00:17.579321
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():

    #
    # Test 0
    #
    
    validation_result_0 = ValidationResult()
    iterator_0 = validation_result_0.__iter__()

    has_next_0 = iterator_0.__has_next__()
    assert has_next_0

    value_0 = iterator_0.__next__()
    assert value_0 is None

    has_next_1 = iterator_0.__has_next__()
    assert has_next_1

    value_1 = iterator_0.__next__()
    assert value_1 is None

    has_next_2 = iterator_0.__has_next__()
    assert not has_next_2

    #
    # Test 1
    #
    
    validation_result_1 = ValidationResult(
        value="Dummy",
    )


# Generated at 2022-06-26 10:00:27.663223
# Unit test for constructor of class ParseError
def test_ParseError():

    # from event_bus import EventBus
    # from type_definitions import EventBusType

    text = "test"
    code = "custom"
    key = "test"
    position = Position(line_no=1, column_no=1, char_index=0)
    messages = [Message(text=text, code=code, key=key, position=position)]
    parse_error = ParseError(text=text, code=code, key=key, position=position)
    parse_error = ParseError(messages=messages)

