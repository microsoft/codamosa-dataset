

# Generated at 2022-06-26 09:59:24.012536
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    base_error_0 = BaseError()
    message_0 = base_error_0.__str__()
    assert message_0.__class__ == str
    assert message_0 == "{}"

    base_error_1 = BaseError(text="abc")
    message_1 = base_error_1.__str__()
    assert message_1.__class__ == str
    assert message_1 == "abc"

    base_error_2 = BaseError(messages=[Message(text="abc")])
    message_2 = base_error_2.__str__()
    assert message_2.__class__ == str
    assert message_2 == "{'': 'abc'}"


# Generated at 2022-06-26 09:59:26.782143
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 09:59:33.260304
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message({
        'text': 'May not have more than 100 characters',
        'maxLength': 100
    })
    message_1 = Message({
        'text': 'May not have more than 100 characters',
        'maxLength': 100
    })
    var_0 = message_0.__eq__(message_1)


# Generated at 2022-06-26 09:59:40.771784
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    """
    Method __iter__ of class ValidationResult
    """
    validation_result_0 = ValidationResult()
    iterator_0 = validation_result_0.__iter__()
    class_name = validation_result_0.__class__.__name__
    class_name_1 = ValidationResult.__name__
# TESTS


# Generated at 2022-06-26 09:59:44.050053
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validation_result_0 = ValidationResult()
    iterator_0 = validation_result_0.__iter__()
    for var_0 in iterator_0:
        print(var_0)


# Generated at 2022-06-26 09:59:47.627098
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    base_error_0 = BaseError(text="test_text")
    assert base_error_0.__str__() == "test_text"


# Generated at 2022-06-26 09:59:53.252303
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Instance of class ValidationResult
    # Object of class ValidationResult
    validation_result_0 = ValidationResult()
    # Iterator of class ValidationResult
    iterator_0 = validation_result_0.__iter__()


# Generated at 2022-06-26 09:59:59.369759
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # Test the empty error object.
    test_0_obj_0 = BaseError()
    test_0_string_0 = test_0_obj_0.__str__()
    # Test the empty error object with a single message.
    test_1_obj_0 = BaseError(text="test_1")
    test_1_string_0 = test_1_obj_0.__str__()
    # Test the empty error object with multiple messages.
    test_2_obj_0 = BaseError(messages=["test_2", "test_2"])
    test_2_string_0 = test_2_obj_0.__str__()

# Generated at 2022-06-26 10:00:03.445838
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    base_error_0 = BaseError()
    iterator_0 = base_error_0.__iter__()
    assert iterator_0 is not None



# Generated at 2022-06-26 10:00:11.972131
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # The function call
    #     ValidationResult()
    # creates an instance of class ValidationResult with the following attributes:
    #
    #     value = None
    #     error = None
    validation_result_0 = ValidationResult()
    # The function call
    #     validation_result_0.__iter__()
    # returns an object of type Iterator.
    iterator_0 = validation_result_0.__iter__()
    # The function call
    #     iterator_0.__iter__()
    # gets an object of type Iterator for
    #     validation_result_0
    iterator_1 = iterator_0.__iter__()
    # The function call
    #     iterator_1.__next__()
    # returns the object
    #     None
    var_0 = iterator_1.__next__

# Generated at 2022-06-26 10:00:18.881942
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = __create_message_1()
    message_2 = __create_message_2()

    assert message_1 == message_1


# Generated at 2022-06-26 10:00:23.033513
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    validationResult = ValidationResult()
    assert (iter(validationResult) == validationResult)


# Generated at 2022-06-26 10:00:24.644012
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert True



# Generated at 2022-06-26 10:00:25.710129
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert BaseError.__str__(BaseError()) is None

# Generated at 2022-06-26 10:00:28.083751
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    message_0 = ValidationResult()
    assert iter(message_0) is not None


# Generated at 2022-06-26 10:00:31.668145
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=None, error=None)) == [None, None]


# Generated at 2022-06-26 10:00:32.893873
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert 0


# Generated at 2022-06-26 10:00:47.050968
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result_0 = ValidationResult()
    for x in result_0:
        # State 0
        assert True
    # State 1
    result_1 = ValidationResult()
    for x in result_1:
        # State 2
        assert True
    # State 3
    result_2 = ValidationResult()
    for x in result_2:
        # State 4
        assert True
    # State 5
    result_3 = ValidationResult()
    for x in result_3:
        # State 6
        assert True
    # State 7
    result_4 = ValidationResult()
    for x in result_4:
        # State 8
        assert True
    # State 9
    result_5 = ValidationResult()
    for x in result_5:
        # State 10
        assert True
    # State 11
   

# Generated at 2022-06-26 10:00:51.019801
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult()
    iterator = result.__iter__()
    assert next(iterator) == None
    assert next(iterator) == None


# Generated at 2022-06-26 10:00:54.160051
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:01:01.705825
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    assert BaseError().__str__() == "{}"

# Generated at 2022-06-26 10:01:04.879000
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    message_0 = Position()
    message_1 = Position()
    assert (message_0 == message_1)


# Generated at 2022-06-26 10:01:08.810116
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    message = Message(text="May not be empty")
    error = ValidationError(messages=[message])
    print(error)


# Generated at 2022-06-26 10:01:11.324466
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = ValidationError()
    assert str(error) == ""


# Generated at 2022-06-26 10:01:13.644469
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    message_0 = Message()
    BaseError = ValidationError()


# Generated at 2022-06-26 10:01:15.393194
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message() == Message()


# Generated at 2022-06-26 10:01:18.114493
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    message_0 == message_1


# Generated at 2022-06-26 10:01:24.263439
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    line_no = 0
    column_no = 0
    char_index = 0
    assert Position(line_no, column_no, char_index) == Position(line_no, column_no, char_index)
    assert Position(line_no, column_no, char_index) != Position(line_no, column_no, char_index + 1)
    assert Position(line_no, column_no, char_index) != Position(line_no, column_no + 1, char_index)
    assert Position(line_no, column_no, char_index) != Position(line_no + 1, column_no, char_index)


# Generated at 2022-06-26 10:01:31.471114
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # Input and expected result
    message_0 = Message(text='Only letters and numbers allowed')
    input_0 = ValidationError(messages=[message_0])
    expected_result = 'Only letters and numbers allowed'
    # Perform the test
    result = str(input_0)
    # Check the result
    assert result == expected_result


# Generated at 2022-06-26 10:01:34.081569
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    test_case_0()



# Generated at 2022-06-26 10:01:45.040342
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    message_0 = Message()
    error = ValidationError(messages=[message_0])
    # error = ValidationError(messages=[message_0])
    str(error)

# Generated at 2022-06-26 10:01:48.411304
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    r = Message(text='', code='custom', key='')
    assert r == Message(text='', code='custom', key='')


# Generated at 2022-06-26 10:01:50.788505
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    message_0 = Message(text='text')
    error_0 = BaseError(messages=[message_0])
    assert 'text' == str(error_0)


# Generated at 2022-06-26 10:01:55.486290
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text = "hi", code = "mean")
    message_1 = Message(text = "hi", code = "mean")
    assert message_0 == message_1
    message_2 = Message(text = "hi", code = "mean", index = ["0"])
    assert message_0 != message_2


# Generated at 2022-06-26 10:02:02.889821
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    instance_0 = Position(0, 0, 0)
    assert instance_0 == instance_0
    instance_1 = Position(0, 0, 0)
    assert instance_1 == instance_1
    assert instance_0 == instance_1
    instance_1 = Position(0, 1, 0)
    assert not instance_0 == instance_1
    instance_1 = Position(0, 0, 1)
    assert not instance_0 == instance_1
    instance_1 = Position(1, 0, 0)
    assert not instance_0 == instance_1


# Generated at 2022-06-26 10:02:07.216953
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    messages_0 = [Message(text='', code='', key=None, index=[], position=None, start_position=None, end_position=None)]
    error_0 = BaseError(messages=messages_0)
    v = error_0.__str__()
    assert v == {}


# Generated at 2022-06-26 10:02:21.061213
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    exception_lower_boundary = ValueError
    assert issubclass(BaseError, exception_lower_boundary) is True
    baseError = BaseError()
    assert baseError.__str__() == "{}"
    baseError = BaseError(text="password may not contain the word 'password'",
                          code="max_length", key="username")
    assert baseError.__str__() == "password may not contain the word 'password'"
    baseError = BaseError(messages=[Message(text="password may not contain the word 'password'",
                                            code="max_length", key="username"),
                                   Message(text="This is a second message",
                                            code="max_length", key="username")])
    assert baseError.__str__() == "{'username': 'This is a second message'}"

# Generated at 2022-06-26 10:02:22.419093
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    message_0 = Message()
    BaseError.__str__()


# Generated at 2022-06-26 10:02:30.506612
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # Scenario 1:
    message_0 = Message(text='Some error text', code='some_code', key=0)
    error_0 = BaseError(messages=[message_0])
    assert str(error_0) == 'Some error text'

    # Scenario 2:
    message_1 = Message(text='Some message text', code='some_code', index=[0, 'username'])
    message_2 = Message(text='Other message text', code='some_code', index=[1, 'username'])
    error_1 = BaseError(messages=[message_1, message_2])
    assert str(error_1) == "{0: {'username': 'Some message text'}, 1: {'username': 'Other message text'}}"


# Generated at 2022-06-26 10:02:41.801538
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message()
    message_2 = Message()
    assert message_1 == message_2
    message_1 = Message(text="1", code="2", key=3, start_position=Position(1,3,3), end_position=Position(2,3,3))
    message_2 = Message(text="1", code="2", key=3, start_position=Position(1,3,3), end_position=Position(2,3,3))
    assert message_1 == message_2
    message_1 = Message(text="1", code="2", key=3, start_position=Position(1,3,3), end_position=Position(2,3,3))

# Generated at 2022-06-26 10:02:52.694845
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    try:
        Position.__eq__(Position(0, 0, 0), Position(0, 0, 0))
    except TypeError as error:
        assert str(error) == "'typing.Any' object is not subscriptable"


# Generated at 2022-06-26 10:02:55.983975
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="text",code="code",key=0)
    message_1 = Message(text="text",code="code",key=0)
    assert message_0 == message_1


# Generated at 2022-06-26 10:02:59.433994
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    obj = Position(0, 0, 0)
    param = Position(0, 0, 0)
    out = obj == param
    assert out is False


# Generated at 2022-06-26 10:03:00.502295
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    pass



# Generated at 2022-06-26 10:03:13.192996
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    import pytest
    from typesystem.error import Position
    # Test case:
    # 1. Test instance is created with the following args:
    # line_no=1, column_no=2, char_index=3
    inst_0 = Position(line_no=1, column_no=2, char_index=3)
    # 2. other is created as a Position instance with the following args:
    # line_no=1, column_no=2, char_index=3
    other_0 = Position(line_no=1, column_no=2, char_index=3)
    # 3. Expected result: __eq__ should return True
    assert inst_0.__eq__(other_0) == True
    # Test case:
    # 1. Test instance is created with the following args:
    # line_

# Generated at 2022-06-26 10:03:20.292875
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="hi", code="hi", key="hi")
    m2 = Message(text="hi", code="hi", key="hi")
    assert m1 == m2
    m2 = Message(text="hi", code="hi", key="hi", index=["hi"])
    assert m1 != m2


# Generated at 2022-06-26 10:03:27.778470
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    message_0 = Position(1, 1, 1)
    message_1 = Position(1, 1, 123)
    message_2 = Position(1, 123, 1)
    message_3 = Position(123, 1, 1)
    message_4 = Position(1, 1, 1)
    assert not message_0 == message_1
    assert not message_0 == message_2
    assert not message_0 == message_3
    assert message_0 == message_4


# Generated at 2022-06-26 10:03:31.485017
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Parameters
    line_no: int = None
    column_no: int = None
    char_index: int = None
    other: typing.Any = None
    # NotImplementedError - Position.__eq__
    # not implemented
    pass


# Generated at 2022-06-26 10:03:38.487760
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text='string', code='string', key='string', index=['string'], position=None, start_position=None, end_position=None)
    message_2 = Message(text='string', code='string', key='string', index=['string'], position=None, start_position=None, end_position=None)
    assert message_1 == message_2



# Generated at 2022-06-26 10:03:48.531777
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="foo", code="test", key="test")
    m2 = Message(text="foo", code="test", key="test")
    assert m1 == m2

    m1 = Message(text="foo", code="test", key="test", index=["bar"])
    m2 = Message(text="foo", code="test", index=["bar"])
    assert m1 == m2

    m1 = Message(text="foo", code="test", key="test", position=Position(1,1,1))
    m2 = Message(text="foo", code="test", position=Position(1,1,1))
    assert m1 == m2

    m1 = Message(text="foo", code="test", key="test", start_position=Position(1,1,1))

# Generated at 2022-06-26 10:04:06.439119
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:04:16.170756
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text="May not have more than 100 characters", code="max_length")
    message_1 = Message(text="May not have more than 100 characters", code="max_length")
    assert message_0 == message_1

    message_0 = Message(text="May not have more than 100 characters", code="max_length")
    message_1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message_0 != message_1

    message_0 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message_1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message_0 == message_1


# Generated at 2022-06-26 10:04:18.529499
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    """
    This method is needed to compare two instances of this class.
    Put the following code in method test_case_0:
    """
    assert True


# Generated at 2022-06-26 10:04:19.730581
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    test_case_0()


# Generated at 2022-06-26 10:04:21.503589
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:04:23.854677
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:04:24.671319
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message() == Message()


# Generated at 2022-06-26 10:04:26.851459
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:04:29.266810
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(text=1)
    message_1 = Message(text=1)
    assert message_0 == message_0
    assert message_1 == message_0
    assert message_0 == message_1



# Generated at 2022-06-26 10:04:30.419833
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:05:40.564105
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:05:49.769864
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    print("Testing method __eq__ of class Message")
    
    # Set up :
    text_0 = ''
    code_0 = 'custom'
    key_0 = ''
    index_0 = []
    position_0 = Position()
    start_position_0 = Position()
    end_position_0 = Position()

    # Initialising local variables for tests
    test_0 = Message(text = '', code = 'custom')
    test_1 = Message(text = '', code = 'custom')
    test_2 = Message(text='Lorem ipsum dolor sit amet, consectetur adipiscing elit.')

    # Test against expected value
    assert test_0.__eq__(test_1) == True
    assert test_0.__eq__(test_2) == False
    assert test_

# Generated at 2022-06-26 10:05:51.755584
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # TODO: This test will fail for now
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:05:53.387285
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:05:55.781630
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    b = (message_0 == message_1)
    print(b)
    assert isinstance(b, bool)


# Generated at 2022-06-26 10:06:03.993071
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert (Message() == Message()) == True
    assert (Message() == Message(text="hello")) == False
    assert (Message(text="hello") == Message(text="hello")) == True
    assert (Message(text="hello") == Message(text="world")) == False
    assert (Message(text="hello", code="max_length") == Message(text="hello")) == False
    assert (Message(text="hello", code="max_length") == Message(text="hello", code="max_length")) == True
    assert (Message(text="hello", code="max_length") == Message(text="hello", code="min_length")) == False
    assert (Message(text="hello", code="max_length", key="name") == Message(text="hello", code="max_length")) == False

# Generated at 2022-06-26 10:06:05.553516
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:06:08.771047
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    assert message_0 is not message_1
    assert message_0 == message_1


# Generated at 2022-06-26 10:06:12.687013
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message(key=3, text="f{F(61)R", code="X", index=[0])
    message_1 = Message()
    assert message_0 == message_1


# Generated at 2022-06-26 10:06:16.185077
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_0 = Message()
    message_1 = Message()
    summed = message_0 == message_1
    assert summed

