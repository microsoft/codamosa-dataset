

# Generated at 2022-06-18 12:02:50.306402
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    # Test with value
    result = ValidationResult(value=1)
    assert list(result) == [1, None]

    # Test with error
    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:54.138379
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert error1 != error2
    assert error1 != "error1"


# Generated at 2022-06-18 12:03:00.772362
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="test", code="test", key="test", position=Position(1, 2, 3))
    error2 = BaseError(text="test", code="test", key="test", position=Position(1, 2, 3))
    assert error1 == error2
    error3 = BaseError(text="test", code="test", key="test", position=Position(1, 2, 3))
    error4 = BaseError(text="test", code="test", key="test", position=Position(1, 2, 4))
    assert error3 != error4


# Generated at 2022-06-18 12:03:09.986570
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k", code="c") == BaseError(text="a", key="k", code="c")

# Generated at 2022-06-18 12:03:13.708653
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:17.095520
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:26.151037
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index1"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key1", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code1", key="key", index=["index"])

# Generated at 2022-06-18 12:03:36.268783
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that two BaseError objects with the same text, code, key, position, messages are equal
    assert BaseError(text="text", code="code", key="key", position=Position(1, 1, 1), messages=[Message(text="text", code="code", key="key", position=Position(1, 1, 1))]) == BaseError(text="text", code="code", key="key", position=Position(1, 1, 1), messages=[Message(text="text", code="code", key="key", position=Position(1, 1, 1))])
    # Test that two BaseError objects with different text, code, key, position, messages are not equal

# Generated at 2022-06-18 12:03:43.040275
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    assert message1 == message2


# Generated at 2022-06-18 12:03:49.240344
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    assert repr(BaseError(text='May not have more than 100 characters', code='max_length', key='username')) == "BaseError(text='May not have more than 100 characters', code='max_length')"
    assert repr(BaseError(messages=[Message(text='May not have more than 100 characters', code='max_length', key='username')])) == "BaseError([Message(text='May not have more than 100 characters', code='max_length', index=['username'])])"


# Generated at 2022-06-18 12:04:02.124090
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    msg2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert msg1 == msg2


# Generated at 2022-06-18 12:04:12.636753
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert message == Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert message != Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 7))
    assert message != Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 6, 6))

# Generated at 2022-06-18 12:04:17.846168
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Test with a single message
    error = BaseError(text="May not have more than 100 characters", code="max_length")
    assert repr(error) == "BaseError(text='May not have more than 100 characters', code='max_length')"

    # Test with multiple messages
    error = BaseError(messages=[
        Message(text="May not have more than 100 characters", code="max_length"),
        Message(text="May not have less than 10 characters", code="min_length"),
    ])
    assert repr(error) == "BaseError([Message(text='May not have more than 100 characters', code='max_length'), Message(text='May not have less than 10 characters', code='min_length')])"


# Generated at 2022-06-18 12:04:24.945189
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    assert message1 == message2
    message3 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 4))
    assert message1 != message3


# Generated at 2022-06-18 12:04:33.267467
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two ValidationError objects with same messages
    messages = [Message(text="May not have more than 100 characters", code="max_length")]
    error1 = ValidationError(messages=messages)
    error2 = ValidationError(messages=messages)
    assert error1 == error2

    # Test with two ValidationError objects with different messages
    messages1 = [Message(text="May not have more than 100 characters", code="max_length")]
    messages2 = [Message(text="May not have more than 100 characters", code="max_length"), Message(text="May not have more than 100 characters", code="max_length")]
    error1 = ValidationError(messages=messages1)
    error2 = ValidationError(messages=messages2)
    assert error1 != error2

    # Test

# Generated at 2022-06-18 12:04:36.554959
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:04:46.416012
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two ValidationError objects with different messages
    error1 = ValidationError(text="Error 1", code="code1")
    error2 = ValidationError(text="Error 2", code="code2")
    assert error1 != error2

    # Test with two ValidationError objects with same messages
    error1 = ValidationError(text="Error 1", code="code1")
    error2 = ValidationError(text="Error 1", code="code1")
    assert error1 == error2

    # Test with two ValidationError objects with different indexes
    error1 = ValidationError(text="Error 1", code="code1", key="key1")
    error2 = ValidationError(text="Error 1", code="code1", key="key2")
    assert error1 != error2

    # Test with two ValidationError objects with same indexes

# Generated at 2022-06-18 12:04:55.560366
# Unit test for method __repr__ of class BaseError
def test_BaseError___repr__():
    # Test with a single error message
    error = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    assert repr(error) == "BaseError(text='May not have more than 100 characters', code='max_length')"
    # Test with multiple error messages
    error = BaseError(messages=[
        Message(text='May not have more than 100 characters', code='max_length', key='username'),
        Message(text='May not have less than 10 characters', code='min_length', key='username'),
    ])
    assert repr(error) == "BaseError([Message(text='May not have more than 100 characters', code='max_length', index=['username']), Message(text='May not have less than 10 characters', code='min_length', index=['username'])])"

# Unit

# Generated at 2022-06-18 12:05:05.497183
# Unit test for method __repr__ of class BaseError

# Generated at 2022-06-18 12:05:15.731000
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", index=[1, 2, 3])
    assert message == Message(text="text", code="code", index=[1, 2, 3])
    assert message != Message(text="text", code="code", index=[1, 2, 3, 4])
    assert message != Message(text="text", code="code", index=[1, 2])
    assert message != Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    assert message != Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3))
    assert message != Message(text="text", code="code", index=[1, 2, 3], end_position=Position(1, 2, 3))
    assert message != Message

# Generated at 2022-06-18 12:05:32.595030
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index2"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key2", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code2", key="key", index=["index"])

# Generated at 2022-06-18 12:05:39.155691
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username", index=["users", 3, "username"], position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username", index=["users", 3, "username"], position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 == message2


# Generated at 2022-06-18 12:05:51.160409
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that BaseError.__eq__() returns True when the two BaseError objects are equal.
    assert BaseError(text="test") == BaseError(text="test")
    assert BaseError(text="test", code="test") == BaseError(text="test", code="test")
    assert BaseError(text="test", code="test", key="test") == BaseError(text="test", code="test", key="test")
    assert BaseError(text="test", code="test", key="test", position=Position(1, 2, 3)) == BaseError(text="test", code="test", key="test", position=Position(1, 2, 3))

# Generated at 2022-06-18 12:06:02.219802
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test that two messages are equal if they have the same text, code, index, start_position and end_position
    message1 = Message(text="text1", code="code1", index=["index1"], start_position=Position(1, 1, 1), end_position=Position(2, 2, 2))
    message2 = Message(text="text1", code="code1", index=["index1"], start_position=Position(1, 1, 1), end_position=Position(2, 2, 2))
    assert message1 == message2
    # Test that two messages are not equal if they have different text
    message1 = Message(text="text1", code="code1", index=["index1"], start_position=Position(1, 1, 1), end_position=Position(2, 2, 2))

# Generated at 2022-06-18 12:06:09.488205
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=2, char_index=3)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    assert error1 == error2
    assert error1 == error1
    assert error2 == error2
    assert error1 != "foo"
    assert error1 != BaseError(messages=[Message(text="foo")])
    assert error1 != BaseError(messages=[Message(text=text, code=code, key=key)])

# Generated at 2022-06-18 12:06:12.354651
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:06:18.036455
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    m2 = Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert m1 == m2


# Generated at 2022-06-18 12:06:27.387215
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text="test", code="test", key="test")
    error2 = BaseError(text="test", code="test", key="test")
    assert error1 == error2

    # Test 2
    error1 = BaseError(text="test", code="test", key="test")
    error2 = BaseError(text="test", code="test", key="test2")
    assert error1 != error2

    # Test 3
    error1 = BaseError(text="test", code="test", key="test")
    error2 = BaseError(text="test", code="test2", key="test")
    assert error1 != error2

    # Test 4
    error1 = BaseError(text="test", code="test", key="test")

# Generated at 2022-06-18 12:06:36.601276
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two ValidationError instances that have the same error messages
    error1 = ValidationError(text="Error message 1", code="code1", key="key1")
    error2 = ValidationError(text="Error message 1", code="code1", key="key1")
    assert error1 == error2

    # Test with two ValidationError instances that have different error messages
    error1 = ValidationError(text="Error message 1", code="code1", key="key1")
    error2 = ValidationError(text="Error message 2", code="code2", key="key2")
    assert error1 != error2

    # Test with two ValidationError instances that have the same error messages
    # but different error codes
    error1 = ValidationError(text="Error message 1", code="code1", key="key1")

# Generated at 2022-06-18 12:06:39.992295
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:07:02.710259
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two ValidationError objects that have the same messages
    # and therefore should be equal
    error1 = ValidationError(text="Error message 1", code="code1", key="key1")
    error2 = ValidationError(text="Error message 1", code="code1", key="key1")
    assert error1 == error2

    # Test with two ValidationError objects that have different messages
    # and therefore should not be equal
    error1 = ValidationError(text="Error message 1", code="code1", key="key1")
    error2 = ValidationError(text="Error message 2", code="code2", key="key2")
    assert error1 != error2

    # Test with two ValidationError objects that have the same messages
    # but different indexes and therefore should not be equal

# Generated at 2022-06-18 12:07:12.572726
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="c", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="b", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", index=["d"])

# Generated at 2022-06-18 12:07:20.744852
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text1', code='code1', key='key1', index=['index1'], position=Position(1, 2, 3), start_position=Position(4, 5, 6), end_position=Position(7, 8, 9))
    message2 = Message(text='text1', code='code1', key='key1', index=['index1'], position=Position(1, 2, 3), start_position=Position(4, 5, 6), end_position=Position(7, 8, 9))
    assert message1 == message2


# Generated at 2022-06-18 12:07:24.718421
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:07:36.030776
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", start_position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", end_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:07:43.788172
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError() == BaseError()
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a", code="b") == BaseError(text="a", code="b")
    assert BaseError(text="a", code="b", key="c") == BaseError(text="a", code="b", key="c")
    assert BaseError(messages=[Message(text="a")]) == BaseError(messages=[Message(text="a")])
    assert BaseError(messages=[Message(text="a", code="b")]) == BaseError(messages=[Message(text="a", code="b")])

# Generated at 2022-06-18 12:07:52.439559
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text', code='code', key='key', index=['index'], position=Position(line_no=1, column_no=1, char_index=1), start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    message2 = Message(text='text', code='code', key='key', index=['index'], position=Position(line_no=1, column_no=1, char_index=1), start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    assert message1 == message2



# Generated at 2022-06-18 12:07:55.271344
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:08:06.051726
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    message1 = Message(text="text1", code="code1", key="key1")
    message2 = Message(text="text2", code="code2", key="key2")
    message3 = Message(text="text3", code="code3", key="key3")
    message4 = Message(text="text4", code="code4", key="key4")
    message5 = Message(text="text5", code="code5", key="key5")
    message6 = Message(text="text6", code="code6", key="key6")
    message7 = Message(text="text7", code="code7", key="key7")
    message8 = Message(text="text8", code="code8", key="key8")

# Generated at 2022-06-18 12:08:15.687898
# Unit test for method __eq__ of class BaseError

# Generated at 2022-06-18 12:08:37.372007
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two ValidationError objects with the same messages
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='password')
    error1 = ValidationError(messages=[message1, message2])
    error2 = ValidationError(messages=[message1, message2])
    assert error1 == error2
    # Test with two ValidationError objects with different messages
    message3 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    message4 = Message(text='May not have more than 100 characters', code='max_length', key='password')
    error3 = ValidationError(messages=[message3])
    error4 = Val

# Generated at 2022-06-18 12:08:40.704268
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:08:49.577379
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that two ValidationErrors with the same messages are equal.
    error1 = ValidationError(messages=[Message(text="foo")])
    error2 = ValidationError(messages=[Message(text="foo")])
    assert error1 == error2

    # Test that two ValidationErrors with different messages are not equal.
    error1 = ValidationError(messages=[Message(text="foo")])
    error2 = ValidationError(messages=[Message(text="bar")])
    assert error1 != error2

    # Test that two ValidationErrors with the same messages but different indexes are equal.
    error1 = ValidationError(messages=[Message(text="foo", index=[1])])
    error2 = ValidationError(messages=[Message(text="foo", index=[2])])
    assert error1 == error2

# Generated at 2022-06-18 12:08:59.172439
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='a') == BaseError(text='a')
    assert BaseError(text='a') != BaseError(text='b')
    assert BaseError(text='a') != BaseError(text='a', code='b')
    assert BaseError(text='a') != BaseError(text='a', key='b')
    assert BaseError(text='a') != BaseError(text='a', position=Position(1, 2, 3))
    assert BaseError(text='a') != BaseError(text='a', messages=[Message(text='a')])
    assert BaseError(messages=[Message(text='a')]) == BaseError(messages=[Message(text='a')])
    assert BaseError(messages=[Message(text='a')]) != BaseError(messages=[Message(text='b')])
    assert BaseError

# Generated at 2022-06-18 12:09:04.754570
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message3 = Message(text="text2", code="code2", key="key2", position=Position(2, 2, 2))
    assert message1 == message2
    assert message1 != message3


# Generated at 2022-06-18 12:09:09.967518
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=1, char_index=0)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    # Test
    assert error1 == error2
    # Teardown



# Generated at 2022-06-18 12:09:20.129223
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='a') == BaseError(text='a')
    assert BaseError(text='a') != BaseError(text='b')
    assert BaseError(text='a', code='c') == BaseError(text='a', code='c')
    assert BaseError(text='a', code='c') != BaseError(text='a', code='d')
    assert BaseError(text='a', key=1) == BaseError(text='a', key=1)
    assert BaseError(text='a', key=1) != BaseError(text='a', key=2)
    assert BaseError(text='a', position=Position(1, 2, 3)) == BaseError(text='a', position=Position(1, 2, 3))
    assert BaseError(text='a', position=Position(1, 2, 3)) != Base

# Generated at 2022-06-18 12:09:25.354474
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that two BaseError instances are equal if they have the same messages
    # and that they are not equal if they have different messages
    messages = [
        Message(text="message 1"),
        Message(text="message 2"),
    ]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    assert error1 == error2
    error3 = BaseError(messages=[Message(text="message 1")])
    assert error1 != error3


# Generated at 2022-06-18 12:09:33.009430
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="c", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="b", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", index=[1])

# Generated at 2022-06-18 12:09:40.928417
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error1", code="code1", key="key1")
    assert error1 == error2

    # Test 2
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error2", code="code1", key="key1")
    assert error1 != error2

    # Test 3
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error1", code="code2", key="key1")
    assert error1 != error2

    # Test 4

# Generated at 2022-06-18 12:10:11.307083
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    error1 = BaseError(text='error1', code='code1', key='key1')
    error2 = BaseError(text='error2', code='code2', key='key2')
    error3 = BaseError(text='error1', code='code1', key='key1')
    # Exercise
    # Verify
    assert error1 == error3
    assert error1 != error2
    assert error1 != 'error1'


# Generated at 2022-06-18 12:10:15.013305
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    error3 = BaseError(text="error3")
    assert error1 == error2
    assert error1 != error3
    assert error2 != error3


# Generated at 2022-06-18 12:10:17.589478
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    error3 = BaseError(text="error3")
    assert error1 == error2
    assert error1 != error3


# Generated at 2022-06-18 12:10:22.240300
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 2, 3))
    message2 = Message(text="text1", code="code1", key="key1", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:10:30.437506
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='a') == BaseError(text='a')
    assert BaseError(text='a') != BaseError(text='b')
    assert BaseError(text='a') != BaseError(text='a', code='b')
    assert BaseError(text='a') != BaseError(text='a', key='b')
    assert BaseError(text='a') != BaseError(text='a', position=Position(1, 1, 1))
    assert BaseError(text='a') != BaseError(text='a', messages=[Message(text='b')])
    assert BaseError(text='a') != BaseError(messages=[Message(text='a')])
    assert BaseError(messages=[Message(text='a')]) == BaseError(messages=[Message(text='a')])

# Generated at 2022-06-18 12:10:33.783527
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error1", code="code1", key="key1")
    assert error1 == error2


# Generated at 2022-06-18 12:10:41.844167
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index1"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key1", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code1", key="key", index=["index"])

# Generated at 2022-06-18 12:10:50.320159
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    assert error1 == error2

    # Test 2
    error1 = BaseError(text="error1", code="code1")
    error2 = BaseError(text="error1", code="code1")
    assert error1 == error2

    # Test 3
    error1 = BaseError(text="error1", key="key1")
    error2 = BaseError(text="error1", key="key1")
    assert error1 == error2

    # Test 4
    error1 = BaseError(text="error1", position=Position(1, 1, 1))
    error2 = BaseError(text="error1", position=Position(1, 1, 1))
    assert error1 == error2

    # Test

# Generated at 2022-06-18 12:10:53.973701
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:11:03.628131
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k", code="c") == BaseError(text="a", key="k", code="c")

# Generated at 2022-06-18 12:11:57.041683
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with one message
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error1", code="code1", key="key1")
    assert error1 == error2
    error3 = BaseError(text="error1", code="code1", key="key2")
    assert error1 != error3
    error4 = BaseError(text="error1", code="code2", key="key1")
    assert error1 != error4
    error5 = BaseError(text="error2", code="code1", key="key1")
    assert error1 != error5
    # Test with multiple messages
    error6 = BaseError(messages=[Message(text="error1", code="code1", key="key1")])

# Generated at 2022-06-18 12:12:05.717463
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two empty errors
    error1 = BaseError()
    error2 = BaseError()
    assert error1 == error2

    # Test with two errors with the same message
    error1 = BaseError(text="error message")
    error2 = BaseError(text="error message")
    assert error1 == error2

    # Test with two errors with different messages
    error1 = BaseError(text="error message 1")
    error2 = BaseError(text="error message 2")
    assert error1 != error2

    # Test with two errors with the same message and code
    error1 = BaseError(text="error message", code="error code")
    error2 = BaseError(text="error message", code="error code")
    assert error1 == error2

    # Test with two errors with different messages and codes

# Generated at 2022-06-18 12:12:15.760188
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a") != BaseError(text="a", code="b")
    assert BaseError(text="a") != BaseError(text="a", key="b")
    assert BaseError(text="a") != BaseError(text="a", position=Position(1, 2, 3))
    assert BaseError(text="a") != BaseError(text="a", messages=[Message(text="a")])
    assert BaseError(text="a") != BaseError(messages=[Message(text="a")])
    assert BaseError(messages=[Message(text="a")]) == BaseError(messages=[Message(text="a")])

# Generated at 2022-06-18 12:12:22.838443
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text='error1', code='code1', key='key1', position=Position(1, 1, 1))
    error2 = BaseError(text='error1', code='code1', key='key1', position=Position(1, 1, 1))
    assert error1 == error2

    # Test 2
    error1 = BaseError(text='error1', code='code1', key='key1', position=Position(1, 1, 1))
    error2 = BaseError(text='error2', code='code2', key='key2', position=Position(2, 2, 2))
    assert error1 != error2


# Generated at 2022-06-18 12:12:28.972082
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=1, char_index=0)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    # Exercise
    result = error1 == error2
    # Verify
    assert result
