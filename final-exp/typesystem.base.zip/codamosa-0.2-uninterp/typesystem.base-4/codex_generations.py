

# Generated at 2022-06-18 12:02:40.829635
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=1)) == "ValidationResult(value=1)"
    assert repr(ValidationResult(error=ValidationError())) == "ValidationResult(error=ValidationError())"

# Generated at 2022-06-18 12:02:45.401240
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=1, char_index=0))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=1, char_index=0))
    assert message1 == message2


# Generated at 2022-06-18 12:02:48.995975
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 2, 3))
    message2 = Message(text="text1", code="code1", key="key1", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:02:52.059042
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=1)) == "ValidationResult(value=1)"
    assert repr(ValidationResult(error=ValidationError())) == "ValidationResult(error=ValidationError())"


# Generated at 2022-06-18 12:03:01.561681
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1, 2])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1, 2, 3])

# Generated at 2022-06-18 12:03:10.575828
# Unit test for method __iter__ of class ValidationResult

# Generated at 2022-06-18 12:03:13.963944
# Unit test for method __repr__ of class ValidationResult
def test_ValidationResult___repr__():
    assert repr(ValidationResult(value=1)) == 'ValidationResult(value=1)'
    assert repr(ValidationResult(error=ValidationError())) == 'ValidationResult(error=ValidationError({}))'


# Generated at 2022-06-18 12:03:16.628937
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]


# Generated at 2022-06-18 12:03:20.104214
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:23.562520
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='error1')
    error2 = BaseError(text='error2')
    error3 = BaseError(text='error1')
    assert error1 == error3
    assert error1 != error2
    assert error1 != 'error1'


# Generated at 2022-06-18 12:03:38.387113
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that two BaseError instances are equal if they have the same messages
    error1 = BaseError(messages=[Message(text="error1")])
    error2 = BaseError(messages=[Message(text="error1")])
    assert error1 == error2
    # Test that two BaseError instances are not equal if they have different messages
    error1 = BaseError(messages=[Message(text="error1")])
    error2 = BaseError(messages=[Message(text="error2")])
    assert error1 != error2
    # Test that two BaseError instances are not equal if they have different numbers of messages
    error1 = BaseError(messages=[Message(text="error1")])
    error2 = BaseError(messages=[Message(text="error1"), Message(text="error2")])
    assert error1 != error2
   

# Generated at 2022-06-18 12:03:43.757529
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text2", code="code2", key="key2", index=["index2"])
    assert message1 != message2
    message3 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message3


# Generated at 2022-06-18 12:03:48.499621
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    error3 = BaseError(text="error3")
    assert error1 == error2
    assert error1 != error3
    assert error2 == error1
    assert error2 != error3
    assert error3 != error1
    assert error3 != error2


# Generated at 2022-06-18 12:03:51.861060
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:04:04.215279
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text2", code="code2", key="key2", index=["index2"])
    message3 = Message(text="text3", code="code3", key="key3", index=["index3"])
    message4 = Message(text="text4", code="code4", key="key4", index=["index4"])
    message5 = Message(text="text5", code="code5", key="key5", index=["index5"])
    message6 = Message(text="text6", code="code6", key="key6", index=["index6"])

# Generated at 2022-06-18 12:04:13.952465
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    assert error1 == error2
    # Test 2
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2 = BaseError(text='May not have more than 100 characters', code='max_length', key='username', messages=[Message(text='May not have more than 100 characters', code='max_length', key='username')])
    assert error1 == error2
    # Test 3
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2

# Generated at 2022-06-18 12:04:22.009798
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text1', code='code1', key='key1', index=['index1'], position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    message2 = Message(text='text2', code='code2', key='key2', index=['index2'], position=Position(2, 2, 2), start_position=Position(2, 2, 2), end_position=Position(2, 2, 2))
    assert message1 == message1
    assert not message1 == message2


# Generated at 2022-06-18 12:04:26.360140
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:04:34.041334
# Unit test for method __eq__ of class BaseError

# Generated at 2022-06-18 12:04:43.817711
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that BaseError.__eq__() returns True when the two BaseError objects have the same messages
    # and False otherwise.
    message1 = Message(text="message1", code="code1", key="key1")
    message2 = Message(text="message2", code="code2", key="key2")
    message3 = Message(text="message3", code="code3", key="key3")
    message4 = Message(text="message4", code="code4", key="key4")
    message5 = Message(text="message5", code="code5", key="key5")
    message6 = Message(text="message6", code="code6", key="key6")
    message7 = Message(text="message7", code="code7", key="key7")

# Generated at 2022-06-18 12:05:00.020032
# Unit test for method __eq__ of class BaseError

# Generated at 2022-06-18 12:05:10.446257
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a") != BaseError(text="a", code="a")
    assert BaseError(text="a") != BaseError(text="a", key="a")
    assert BaseError(text="a") != BaseError(text="a", position=Position(1, 1, 1))
    assert BaseError(text="a") != BaseError(text="a", messages=[Message(text="a")])
    assert BaseError(text="a") != BaseError(messages=[Message(text="a")])
    assert BaseError(messages=[Message(text="a")]) == BaseError(messages=[Message(text="a")])

# Generated at 2022-06-18 12:05:14.323040
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:05:24.368650
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that BaseError.__eq__() returns True when the two BaseError objects have the same messages
    # and returns False when the two BaseError objects have different messages
    # Create a BaseError object with a single message
    error1 = BaseError(text="message1", code="code1", key="key1")
    # Create a BaseError object with a single message
    error2 = BaseError(text="message1", code="code1", key="key1")
    # Test that the two BaseError objects are equal
    assert error1 == error2
    # Create a BaseError object with a single message
    error3 = BaseError(text="message2", code="code2", key="key2")
    # Test that the two BaseError objects are not equal
    assert error1 != error3
    # Create a BaseError object with multiple messages
    error4

# Generated at 2022-06-18 12:05:27.895244
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="message1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="message1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:05:31.597535
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:05:41.743241
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text2", code="code2", key="key2", position=Position(2, 2, 2))
    message3 = Message(text="text3", code="code3", key="key3", position=Position(3, 3, 3))
    message4 = Message(text="text4", code="code4", key="key4", position=Position(4, 4, 4))
    message5 = Message(text="text5", code="code5", key="key5", position=Position(5, 5, 5))

# Generated at 2022-06-18 12:05:53.330258
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k") != BaseError(text="a", index=["k"])
    assert BaseError(text="a", index=["k"]) == BaseError(text="a", index=["k"])
   

# Generated at 2022-06-18 12:05:58.185173
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:06:01.829103
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error1", code="code1", key="key1")
    assert error1 == error2


# Generated at 2022-06-18 12:06:24.510442
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='a', code='b', key='c', index=['d'], position=Position(1, 2, 3)) == Message(text='a', code='b', key='c', index=['d'], position=Position(1, 2, 3))
    assert Message(text='a', code='b', key='c', index=['d'], position=Position(1, 2, 3)) != Message(text='a', code='b', key='c', index=['d'], position=Position(1, 2, 4))
    assert Message(text='a', code='b', key='c', index=['d'], position=Position(1, 2, 3)) != Message(text='a', code='b', key='c', index=['d'], position=Position(1, 3, 3))

# Generated at 2022-06-18 12:06:34.045934
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) == Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) != Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 4))

# Generated at 2022-06-18 12:06:42.688716
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="a") == BaseError(text="a", code="a")
    assert BaseError(text="a", code="a") != BaseError(text="a", code="b")
    assert BaseError(text="a", key="a") == BaseError(text="a", key="a")
    assert BaseError(text="a", key="a") != BaseError(text="a", key="b")
    assert BaseError(text="a", key="a", position=Position(1, 1, 1)) == BaseError(text="a", key="a", position=Position(1, 1, 1))

# Generated at 2022-06-18 12:06:46.375040
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert not error1 == error2
    assert not error1 == "error1"


# Generated at 2022-06-18 12:06:55.385904
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that two BaseError objects with the same text, code, key, position, messages are equal
    error1 = BaseError(text="text", code="code", key="key", position=Position(1, 2, 3), messages=[Message(text="text", code="code", key="key", position=Position(1, 2, 3))])
    error2 = BaseError(text="text", code="code", key="key", position=Position(1, 2, 3), messages=[Message(text="text", code="code", key="key", position=Position(1, 2, 3))])
    assert error1 == error2
    # Test that two BaseError objects with different text, code, key, position, messages are not equal

# Generated at 2022-06-18 12:07:04.812687
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    message_2 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    assert message_1 == message_2

# Generated at 2022-06-18 12:07:09.198185
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:07:19.948220
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="c", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="b", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", index=["d"])

# Generated at 2022-06-18 12:07:30.978846
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="text") == BaseError(text="text")
    assert BaseError(text="text") != BaseError(text="text2")
    assert BaseError(text="text") != BaseError(text="text", code="code")
    assert BaseError(text="text") != BaseError(text="text", key="key")
    assert BaseError(text="text") != BaseError(text="text", position=Position(1, 1, 1))
    assert BaseError(text="text") != BaseError(text="text", messages=[Message(text="text")])
    assert BaseError(text="text", code="code") == BaseError(text="text", code="code")
    assert BaseError(text="text", code="code") != BaseError(text="text", code="code2")

# Generated at 2022-06-18 12:07:38.501616
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that two BaseError objects are equal
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error1", code="code1", key="key1")
    assert error1 == error2
    # Test that two BaseError objects are not equal
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error2", code="code2", key="key2")
    assert error1 != error2


# Generated at 2022-06-18 12:08:30.545184
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:08:33.676053
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:08:40.258699
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    message3 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2
    assert message2 == message1
    assert message1 == message3
    assert message3 == message1
    assert message2 == message3
    assert message3 == message2


# Generated at 2022-06-18 12:08:43.852098
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text2", code="code2", key="key2", index=["index2"])
    message3 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 != message2
    assert message1 == message3


# Generated at 2022-06-18 12:08:53.659095
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key=1)
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=["c"])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[])

# Generated at 2022-06-18 12:08:56.743192
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:09:02.154041
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 == message2


# Generated at 2022-06-18 12:09:09.419855
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", index=["c"]) == Message(text="a", code="b", index=["c"])
    assert Message(text="a", code="b", index=["c"]) != Message(text="a", code="b", index=["d"])
    assert Message(text="a", code="b", index=["c"]) != Message(text="a", code="b")
    assert Message(text="a", code="b", index=["c"]) != Message(text="a", index=["c"])
    assert Message(text="a", code="b", index=["c"]) != Message(text="a", code="b", index=["c"], position=Position(1, 2, 3))

# Generated at 2022-06-18 12:09:12.635046
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    assert message1 == message2


# Generated at 2022-06-18 12:09:14.337697
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:10:11.447807
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    msg2 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    assert msg1 == msg2


# Generated at 2022-06-18 12:10:16.480749
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message(text="text", code="code", index=[1, 2], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    msg2 = Message(text="text", code="code", index=[1, 2], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert msg1 == msg2


# Generated at 2022-06-18 12:10:20.255053
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:10:23.308305
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:10:28.187038
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text2", code="code2", key="key2", index=["index2"])
    message3 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message3
    assert message1 != message2


# Generated at 2022-06-18 12:10:36.222942
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with two equal messages
    message1 = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 3))
    assert message1 == message2
    # Test with two unequal messages
    message1 = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 4))
    assert not message1 == message2


# Generated at 2022-06-18 12:10:43.611447
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) == Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) != Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 4))

# Generated at 2022-06-18 12:10:49.015821
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username", position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username", position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 == message2


# Generated at 2022-06-18 12:10:52.882209
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:10:58.692476
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username", position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username", position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 == message2
