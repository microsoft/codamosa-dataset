

# Generated at 2022-06-18 12:03:10.571747
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1,1,1))
    message2 = Message(text="text2", code="code2", key="key2", position=Position(2,2,2))
    message3 = Message(text="text3", code="code3", key="key3", position=Position(3,3,3))
    message4 = Message(text="text4", code="code4", key="key4", position=Position(4,4,4))
    message5 = Message(text="text5", code="code5", key="key5", position=Position(5,5,5))
    message6 = Message(text="text6", code="code6", key="key6", position=Position(6,6,6))
    message

# Generated at 2022-06-18 12:03:14.339827
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:17.844862
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:20.805097
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError())
    assert list(vr) == [None, ValidationError()]


# Generated at 2022-06-18 12:03:24.210576
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:29.625706
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text2", code="code2", key="key2", index=["index2"])
    message3 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message3
    assert message1 != message2


# Generated at 2022-06-18 12:03:33.578434
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]

    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:43.040164
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d", "e"]) == Message(text="a", code="b", key="c", index=["d", "e"])
    assert Message(text="a", code="b", key="c", index=["d", "e"]) != Message(text="a", code="b", key="c", index=["d", "e", "f"])
    assert Message(text="a", code="b", key="c", index=["d", "e"]) != Message(text="a", code="b", key="c", index=["d", "e", "f"])

# Generated at 2022-06-18 12:03:50.036437
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=2, char_index=3)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    # Test
    assert error1 == error2


# Generated at 2022-06-18 12:03:54.340946
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:04:09.214476
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two ValidationError instances with different messages
    error1 = ValidationError(text="Error 1", code="code1", key="key1")
    error2 = ValidationError(text="Error 2", code="code2", key="key2")
    assert error1 != error2

    # Test with two ValidationError instances with same messages
    error1 = ValidationError(text="Error 1", code="code1", key="key1")
    error2 = ValidationError(text="Error 1", code="code1", key="key1")
    assert error1 == error2

    # Test with two ParseError instances with different messages
    error1 = ParseError(text="Error 1", code="code1", key="key1")
    error2 = ParseError(text="Error 2", code="code2", key="key2")


# Generated at 2022-06-18 12:04:12.748911
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:04:18.349038
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k") != BaseError(text="a", index=["k"])
    assert BaseError(text="a", index=["k"]) == BaseError(text="a", index=["k"])
   

# Generated at 2022-06-18 12:04:28.710308
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="c", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="b", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", index=[1])

# Generated at 2022-06-18 12:04:37.019830
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="error1") == BaseError(text="error1")
    assert BaseError(text="error1") != BaseError(text="error2")
    assert BaseError(text="error1") != BaseError(text="error1", code="code1")
    assert BaseError(text="error1", code="code1") == BaseError(text="error1", code="code1")
    assert BaseError(text="error1", code="code1") != BaseError(text="error1", code="code2")
    assert BaseError(text="error1", code="code1") != BaseError(text="error1", key="key1")
    assert BaseError(text="error1", key="key1") == BaseError(text="error1", key="key1")

# Generated at 2022-06-18 12:04:39.993057
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:04:49.977139
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that two BaseError objects are equal if they have the same messages
    messages = [Message(text="message1", code="code1"), Message(text="message2", code="code2")]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    assert error1 == error2

    # Test that two BaseError objects are not equal if they have different messages
    messages = [Message(text="message1", code="code1"), Message(text="message2", code="code2")]
    error1 = BaseError(messages=messages)
    messages = [Message(text="message1", code="code1"), Message(text="message3", code="code3")]
    error2 = BaseError(messages=messages)
    assert error1 != error2

    # Test

# Generated at 2022-06-18 12:04:59.306566
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    message1 = Message(text='text1', code='code1', key='key1', position=Position(1, 1, 1))
    message2 = Message(text='text2', code='code2', key='key2', position=Position(2, 2, 2))
    message3 = Message(text='text3', code='code3', key='key3', position=Position(3, 3, 3))
    message4 = Message(text='text4', code='code4', key='key4', position=Position(4, 4, 4))
    message5 = Message(text='text5', code='code5', key='key5', position=Position(5, 5, 5))
    message6 = Message(text='text6', code='code6', key='key6', position=Position(6, 6, 6))
    message

# Generated at 2022-06-18 12:05:09.621971
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text2", code="code2", key="key2", position=Position(2, 2, 2))
    message3 = Message(text="text3", code="code3", key="key3", position=Position(3, 3, 3))
    message4 = Message(text="text4", code="code4", key="key4", position=Position(4, 4, 4))
    message5 = Message(text="text5", code="code5", key="key5", position=Position(5, 5, 5))
    message6 = Message(text="text6", code="code6", key="key6", position=Position(6, 6, 6))
    message

# Generated at 2022-06-18 12:05:14.276547
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='text1', code='code1', key='key1', position='position1', messages='messages1')
    error2 = BaseError(text='text2', code='code2', key='key2', position='position2', messages='messages2')
    assert error1 == error2


# Generated at 2022-06-18 12:05:34.498087
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d", "e"]) == Message(text="a", code="b", key="c", index=["d", "e"])
    assert Message(text="a", code="b", key="c", index=["d", "e"]) != Message(text="a", code="b", key="c", index=["d", "e", "f"])
    assert Message(text="a", code="b", key="c", index=["d", "e"]) != Message(text="a", code="b", key="c", index=["d", "f"])
    assert Message(text="a", code="b", key="c", index=["d", "e"]) != Message(text="a", code="b", key="c", index=["d"])

# Generated at 2022-06-18 12:05:41.886617
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=1, char_index=0)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    # Test
    assert error == error2


# Generated at 2022-06-18 12:05:53.430463
# Unit test for method __eq__ of class BaseError

# Generated at 2022-06-18 12:05:58.293617
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    assert message1 == message2


# Generated at 2022-06-18 12:06:07.515956
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="test", code="test", key="test", index=["test"], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3)) == Message(text="test", code="test", key="test", index=["test"], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:06:12.332988
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with a single message
    error1 = BaseError(text='text1', code='code1', key='key1')
    error2 = BaseError(text='text1', code='code1', key='key1')
    assert error1 == error2
    assert error1.messages() == error2.messages()
    # Test with multiple messages
    error1 = BaseError(messages=[Message(text='text1', code='code1', key='key1'), Message(text='text2', code='code2', key='key2')])
    error2 = BaseError(messages=[Message(text='text1', code='code1', key='key1'), Message(text='text2', code='code2', key='key2')])
    assert error1 == error2
    assert error1.messages() == error2.messages

# Generated at 2022-06-18 12:06:21.993765
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    message3 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=4))
    message4 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=3, char_index=3))
    message5

# Generated at 2022-06-18 12:06:30.598754
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test when self._messages is empty
    error1 = BaseError()
    error2 = BaseError()
    assert error1 == error2
    # Test when self._messages is not empty
    error1 = BaseError(messages=[Message(text="error1", code="code1", index=[1])])
    error2 = BaseError(messages=[Message(text="error1", code="code1", index=[1])])
    assert error1 == error2
    error1 = BaseError(messages=[Message(text="error1", code="code1", index=[1])])
    error2 = BaseError(messages=[Message(text="error2", code="code2", index=[2])])
    assert error1 != error2


# Generated at 2022-06-18 12:06:35.051657
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")

    # Exercise
    # Verify
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:06:40.032143
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text2", code="code2", key="key2", index=["index2"])
    message3 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message3
    assert message1 != message2


# Generated at 2022-06-18 12:07:09.836906
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k", code="c") == BaseError(text="a", key="k", code="c")

# Generated at 2022-06-18 12:07:13.040629
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:07:20.077579
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text2", code="code2", key="key2", position=Position(2, 2, 2))
    message3 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    assert message1 == message3
    assert message1 != message2


# Generated at 2022-06-18 12:07:27.973731
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with same values
    error1 = BaseError(text="error1", code="code1", key="key1", position="position1")
    error2 = BaseError(text="error1", code="code1", key="key1", position="position1")
    assert error1 == error2

    # Test with different values
    error1 = BaseError(text="error1", code="code1", key="key1", position="position1")
    error2 = BaseError(text="error2", code="code2", key="key2", position="position2")
    assert error1 != error2


# Generated at 2022-06-18 12:07:32.881110
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", index=["index1", "index2"])
    message2 = Message(text="text", code="code", index=["index1", "index2"])
    assert message1 == message2


# Generated at 2022-06-18 12:07:40.017781
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=1, char_index=0)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    # Exercise
    result = error1 == error2
    # Verify
    assert result


# Generated at 2022-06-18 12:07:45.277238
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:07:53.348637
# Unit test for method __eq__ of class BaseError

# Generated at 2022-06-18 12:07:57.667615
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Create a Message object
    message = Message(text="May not have more than 100 characters", code="max_length", key="username")
    # Create another Message object
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    # Check if the two objects are equal
    assert message == message2


# Generated at 2022-06-18 12:08:09.000760
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d"]) == Message(text="a", code="b", key="c", index=["d"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["d", "e"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["e"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="d", index=["d"])

# Generated at 2022-06-18 12:08:44.652745
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text2", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code2", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key2", index=["index"])

# Generated at 2022-06-18 12:08:54.496830
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text="text_1", code="code_1", key="key_1", index=["index_1"], position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    message_2 = Message(text="text_2", code="code_2", key="key_2", index=["index_2"], position=Position(2, 2, 2), start_position=Position(2, 2, 2), end_position=Position(2, 2, 2))

# Generated at 2022-06-18 12:09:03.687135
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text='text', code='code', index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert message == Message(text='text', code='code', index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert message != Message(text='text', code='code', index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 7))
    assert message != Message(text='text', code='code', index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 6, 6))

# Generated at 2022-06-18 12:09:06.283741
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:09:09.406101
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:09:11.818189
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", index=["index"])
    message2 = Message(text="text", code="code", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:09:15.642586
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:09:22.659796
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text', code='code', key='key', index=['index'], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    message2 = Message(text='text', code='code', key='key', index=['index'], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:09:30.592320
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index1"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key1", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code1", key="key", index=["index"])

# Generated at 2022-06-18 12:09:34.807727
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    message2 = Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert message1 == message2


# Generated at 2022-06-18 12:10:56.512437
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3))
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3))
    assert message1 == message2
    message3 = Message(text="text2", code="code2", key="key2", index=["index2"], position=Position(4, 5, 6))
    assert message1 != message3


# Generated at 2022-06-18 12:11:00.887087
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    assert message1 == message2


# Generated at 2022-06-18 12:11:03.994272
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:11:08.130867
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text1', code='code1', key='key1', position=Position(1, 1, 1))
    message2 = Message(text='text1', code='code1', key='key1', position=Position(1, 1, 1))
    assert message1 == message2


# Generated at 2022-06-18 12:11:11.001900
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 2, 3))
    message2 = Message(text="text1", code="code1", key="key1", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:11:13.897301
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    msg2 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    assert msg1 == msg2


# Generated at 2022-06-18 12:11:18.093934
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:11:22.099730
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:11:27.118544
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=1, char_index=0))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=1, char_index=0))
    assert message1 == message2


# Generated at 2022-06-18 12:11:34.511097
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) == Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) != Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 4))