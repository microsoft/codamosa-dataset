

# Generated at 2022-06-18 12:03:38.371840
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="text") == BaseError(text="text")
    assert BaseError(text="text", code="code") == BaseError(text="text", code="code")
    assert BaseError(text="text", key="key") == BaseError(text="text", key="key")
    assert BaseError(text="text", position=Position(1, 2, 3)) == BaseError(text="text", position=Position(1, 2, 3))
    assert BaseError(messages=[Message(text="text")]) == BaseError(messages=[Message(text="text")])
    assert BaseError(messages=[Message(text="text", code="code")]) == BaseError(messages=[Message(text="text", code="code")])

# Generated at 2022-06-18 12:03:41.842667
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:45.483401
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:49.021411
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:52.865768
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]

    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:04:05.072370
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with no messages
    error = BaseError()
    assert error == BaseError()

    # Test with one message
    error = BaseError(text="foo")
    assert error == BaseError(text="foo")
    assert error != BaseError(text="bar")
    assert error != BaseError(text="foo", code="bar")
    assert error != BaseError(text="foo", key="bar")
    assert error != BaseError(text="foo", position=Position(1, 2, 3))
    assert error != BaseError(text="foo", messages=[Message(text="foo")])

    # Test with multiple messages
    error = BaseError(messages=[Message(text="foo")])
    assert error == BaseError(messages=[Message(text="foo")])
    assert error != BaseError(messages=[Message(text="bar")])


# Generated at 2022-06-18 12:04:10.292903
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test with two equal Position objects
    position1 = Position(1, 2, 3)
    position2 = Position(1, 2, 3)
    assert position1 == position2

    # Test with two unequal Position objects
    position1 = Position(1, 2, 3)
    position2 = Position(4, 5, 6)
    assert position1 != position2


# Generated at 2022-06-18 12:04:13.624783
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:04:17.420659
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError())
    assert list(vr) == [None, ValidationError()]


# Generated at 2022-06-18 12:04:22.144336
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that BaseError.__eq__() works as expected
    error1 = ValidationError(text='error1')
    error2 = ValidationError(text='error2')
    error3 = ValidationError(text='error1')
    assert error1 == error3
    assert error1 != error2
    assert error2 != error3


# Generated at 2022-06-18 12:05:02.108146
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:05:07.836097
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "foo"


# Generated at 2022-06-18 12:05:13.233147
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for the case when the two objects are equal
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    assert error1 == error2
    # Test for the case when the two objects are not equal
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    assert error1 != error2


# Generated at 2022-06-18 12:05:17.456352
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1", code="code1", key="key1", position=Position(1, 1, 1))
    error2 = BaseError(text="error1", code="code1", key="key1", position=Position(1, 1, 1))
    assert error1 == error2


# Generated at 2022-06-18 12:05:27.196012
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with different text
    message1 = Message(text="text1")
    message2 = Message(text="text2")
    error1 = BaseError(messages=[message1])
    error2 = BaseError(messages=[message2])
    assert error1 != error2
    # Test with different code
    message1 = Message(text="text", code="code1")
    message2 = Message(text="text", code="code2")
    error1 = BaseError(messages=[message1])
    error2 = BaseError(messages=[message2])
    assert error1 != error2
    # Test with different index
    message1 = Message(text="text", index=[1])
    message2 = Message(text="text", index=[2])
    error1 = BaseError(messages=[message1])
    error2 = BaseError

# Generated at 2022-06-18 12:05:31.134666
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:05:41.284778
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with a single message
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error1", code="code1", key="key1")
    assert error1 == error2
    error3 = BaseError(text="error1", code="code1", key="key2")
    assert error1 != error3
    error4 = BaseError(text="error1", code="code2", key="key1")
    assert error1 != error4
    error5 = BaseError(text="error2", code="code1", key="key1")
    assert error1 != error5
    error6 = BaseError(text="error1", code="code1", key="key1", position=Position(1, 2, 3))
    assert error1 != error6
    error7

# Generated at 2022-06-18 12:05:53.030998
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=2, char_index=4)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=2, column_no=2, char_index=3)

# Generated at 2022-06-18 12:06:03.931080
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index1"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key1", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code1", key="key", index=["index"])

# Generated at 2022-06-18 12:06:11.719754
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='a') == BaseError(text='a')
    assert BaseError(text='a') != BaseError(text='b')
    assert BaseError(text='a', code='c') == BaseError(text='a', code='c')
    assert BaseError(text='a', code='c') != BaseError(text='a', code='d')
    assert BaseError(text='a', key='k') == BaseError(text='a', key='k')
    assert BaseError(text='a', key='k') != BaseError(text='a', key='l')
    assert BaseError(text='a', position=Position(1, 2, 3)) == BaseError(text='a', position=Position(1, 2, 3))
    assert BaseError(text='a', position=Position(1, 2, 3)) != Base

# Generated at 2022-06-18 12:06:58.659586
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text="text1", code="code1", key="key1", position="position1")
    error2 = BaseError(text="text1", code="code1", key="key1", position="position1")
    assert error1 == error2
    # Test 2
    error1 = BaseError(text="text1", code="code1", key="key1", position="position1")
    error2 = BaseError(text="text2", code="code1", key="key1", position="position1")
    assert error1 != error2
    # Test 3
    error1 = BaseError(text="text1", code="code1", key="key1", position="position1")
    error2 = BaseError(text="text1", code="code2", key="key1", position="position1")


# Generated at 2022-06-18 12:07:03.637224
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Creation of two instances of class BaseError
    error1 = BaseError(text="May not have more than 100 characters", code="max_length", key="username")
    error2 = BaseError(text="May not have more than 100 characters", code="max_length", key="username")
    # Test if two instances of class BaseError are equal
    assert error1 == error2


# Generated at 2022-06-18 12:07:11.157752
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=1, char_index=0)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    # Exercise
    result = error1 == error2
    # Verify
    assert result is True


# Generated at 2022-06-18 12:07:17.403519
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != None


# Generated at 2022-06-18 12:07:27.576175
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that two BaseError instances are equal if they have the same messages
    error1 = BaseError(messages=[Message(text="error1", code="code1", key="key1")])
    error2 = BaseError(messages=[Message(text="error1", code="code1", key="key1")])
    assert error1 == error2
    # Test that two BaseError instances are not equal if they have different messages
    error1 = BaseError(messages=[Message(text="error1", code="code1", key="key1")])
    error2 = BaseError(messages=[Message(text="error2", code="code2", key="key2")])
    assert error1 != error2
    # Test that two BaseError instances are not equal if one is None

# Generated at 2022-06-18 12:07:38.633194
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message == Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message != Message(text="text", code="code", key="key", position=Position(1, 2, 4))
    assert message != Message(text="text", code="code", key="key", position=Position(1, 3, 3))
    assert message != Message(text="text", code="code", key="key", position=Position(2, 2, 3))
    assert message != Message(text="text", code="code", key="key", position=Position(1, 2, 3), start_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:07:45.442337
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text1", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code1", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key1", index=["index"])

# Generated at 2022-06-18 12:07:53.446470
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", position=Position(1, 2, 3)) == BaseError(
        text="a", position=Position(1, 2, 3)
    )

# Generated at 2022-06-18 12:07:58.144281
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != 1


# Generated at 2022-06-18 12:08:09.558681
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Setup
    message1 = Message(text="text1", code="code1", key="key1")
    message2 = Message(text="text2", code="code2", key="key2")
    message3 = Message(text="text3", code="code3", key="key3")
    message4 = Message(text="text4", code="code4", key="key4")
    message5 = Message(text="text5", code="code5", key="key5")
    message6 = Message(text="text6", code="code6", key="key6")
    message7 = Message(text="text7", code="code7", key="key7")
    message8 = Message(text="text8", code="code8", key="key8")

# Generated at 2022-06-18 12:09:17.813795
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test 1
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2
    # Test 2
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username", index=["username"])
    assert message1 == message2
    # Test 3
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")

# Generated at 2022-06-18 12:09:24.055153
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "foo"
    assert Position(1, 2, 3) != None


# Generated at 2022-06-18 12:09:32.360255
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that BaseError.__eq__() returns True when the two BaseError objects have the same messages
    # and False when they have different messages
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")

# Generated at 2022-06-18 12:09:36.386553
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "foo"


# Generated at 2022-06-18 12:09:40.629610
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "foo"


# Generated at 2022-06-18 12:09:48.501912
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='a') == BaseError(text='a')
    assert BaseError(text='a') != BaseError(text='b')
    assert BaseError(text='a', code='c') == BaseError(text='a', code='c')
    assert BaseError(text='a', code='c') != BaseError(text='a', code='d')
    assert BaseError(text='a', key='k') == BaseError(text='a', key='k')
    assert BaseError(text='a', key='k') != BaseError(text='a', key='l')
    assert BaseError(text='a', position=Position(1, 2, 3)) == BaseError(text='a', position=Position(1, 2, 3))
    assert BaseError(text='a', position=Position(1, 2, 3)) != Base

# Generated at 2022-06-18 12:09:56.988942
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="error") == BaseError(text="error")
    assert BaseError(text="error") != BaseError(text="error2")
    assert BaseError(text="error") != BaseError(text="error", code="code")
    assert BaseError(text="error", code="code") != BaseError(text="error", code="code2")
    assert BaseError(text="error", key="key") != BaseError(text="error", key="key2")
    assert BaseError(text="error", key="key") != BaseError(text="error", index=["key"])
    assert BaseError(text="error", index=["key"]) != BaseError(text="error", index=["key2"])

# Generated at 2022-06-18 12:10:01.203387
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "foo"


# Generated at 2022-06-18 12:10:08.647429
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=2, char_index=4)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=2, column_no=2, char_index=3)

# Generated at 2022-06-18 12:10:14.334588
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "foo"
