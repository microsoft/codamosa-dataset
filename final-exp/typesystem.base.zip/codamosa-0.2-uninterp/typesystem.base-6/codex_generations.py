

# Generated at 2022-06-18 12:02:39.553349
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError())
    assert list(result) == [None, ValidationError()]


# Generated at 2022-06-18 12:02:42.723534
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]

    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:45.622893
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text='error'))
    assert list(vr) == [None, ValidationError(text='error')]


# Generated at 2022-06-18 12:02:48.955202
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:52.629870
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:56.082751
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:58.953440
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]


# Generated at 2022-06-18 12:03:02.367031
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:05.269307
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError())
    assert list(vr) == [None, ValidationError()]


# Generated at 2022-06-18 12:03:08.885787
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:15.329342
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", index=["index"])
    message2 = Message(text="text", code="code", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:03:24.400161
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], position=Position(line_no=1, column_no=2, char_index=3), start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=1, column_no=2, char_index=3))

# Generated at 2022-06-18 12:03:34.444498
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) == Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) != Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 4))

# Generated at 2022-06-18 12:03:43.855418
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    message_2 = Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    message_3 = Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 7))
    message_4 = Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))

# Generated at 2022-06-18 12:03:47.484529
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:03:51.239553
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:03:55.471366
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message(text="text", code="code", key="key", index=["index"])
    msg2 = Message(text="text", code="code", key="key", index=["index"])
    assert msg1 == msg2


# Generated at 2022-06-18 12:04:06.990375
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message_2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message_3 = Message(text="text", code="code", key="key", position=Position(4, 5, 6))
    message_4 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message_4.index = ["index"]
    message_5 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message_5.index = ["index"]

# Generated at 2022-06-18 12:04:15.650468
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", position=Position(1, 2, 3)) == Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert Message(text="text", code="code", key="key", position=Position(1, 2, 3)) != Message(text="text", code="code", key="key", position=Position(1, 2, 4))
    assert Message(text="text", code="code", key="key", position=Position(1, 2, 3)) != Message(text="text", code="code", key="key", position=Position(1, 3, 3))

# Generated at 2022-06-18 12:04:19.500906
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:04:30.323513
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text2", code="code2", key="key2", position=Position(2, 2, 2))
    message3 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    assert message1 == message3
    assert message1 != message2
    assert message2 != message3


# Generated at 2022-06-18 12:04:39.209789
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with two equal objects
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2

    # Test with two unequal objects
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index2"])
    assert not message1 == message2

    # Test with two unequal objects
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key2", index=["index"])

# Generated at 2022-06-18 12:04:43.218347
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:04:52.610990
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", index=["d"])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", index=["d", "e"])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", index=["d", "e", "f"])

# Generated at 2022-06-18 12:04:55.693524
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:05:05.644725
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message == Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message != Message(text="text", code="code", key="key", position=Position(1, 2, 4))
    assert message != Message(text="text", code="code", key="key", position=Position(1, 3, 3))
    assert message != Message(text="text", code="code", key="key", position=Position(2, 2, 3))
    assert message != Message(text="text", code="code", key="key", start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:05:15.912166
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='May not have more than 100 characters', code='max_length', key='username', index=None, position=Position(line_no=1, column_no=2, char_index=3), start_position=None, end_position=None) == Message(text='May not have more than 100 characters', code='max_length', key='username', index=None, position=Position(line_no=1, column_no=2, char_index=3), start_position=None, end_position=None)

# Generated at 2022-06-18 12:05:26.013385
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1,2,3))
    message2 = Message(text="text", code="code", key="key", position=Position(1,2,3))
    assert message1 == message2
    message3 = Message(text="text", code="code", key="key", position=Position(1,2,4))
    assert message1 != message3
    message4 = Message(text="text", code="code", key="key", position=Position(1,2,3))
    message4.index = [1,2,3]
    assert message1 != message4
    message5 = Message(text="text", code="code", key="key", position=Position(1,2,3))
    message5.index = [1,2,3]
    message

# Generated at 2022-06-18 12:05:29.598864
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    assert message1 == message2


# Generated at 2022-06-18 12:05:35.688939
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text2", code="code2", key="key2", index=["index2"])
    assert message1 != message2
    message3 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message3


# Generated at 2022-06-18 12:06:07.826563
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text1", code="code1", key="key1", index=["index1"]) == Message(text="text1", code="code1", key="key1", index=["index1"])
    assert Message(text="text2", code="code2", key="key2", index=["index2"]) == Message(text="text2", code="code2", key="key2", index=["index2"])
    assert Message(text="text3", code="code3", key="key3", index=["index3"]) == Message(text="text3", code="code3", key="key3", index=["index3"])

# Generated at 2022-06-18 12:06:12.513188
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text2", code="code2", key="key2", index=["index2"])
    message3 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message3
    assert message1 != message2


# Generated at 2022-06-18 12:06:22.097382
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], position=Position(line_no=1, column_no=1, char_index=1), start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))

# Generated at 2022-06-18 12:06:25.726614
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:06:30.897039
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message3 = Message(text="text2", code="code2", key="key2", index=["index2"])
    assert message1 == message2
    assert message1 != message3


# Generated at 2022-06-18 12:06:34.690374
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:06:38.407394
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 2, 3))
    message2 = Message(text="text1", code="code1", key="key1", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:06:43.174806
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 == message2


# Generated at 2022-06-18 12:06:48.000544
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text2", code="code2", key="key2", index=["index2"])
    message3 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message3
    assert message1 != message2


# Generated at 2022-06-18 12:06:51.343817
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text', code='code', key='key', position=Position(1, 2, 3))
    message2 = Message(text='text', code='code', key='key', position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:07:31.136829
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="abc") == Message(text="abc")
    assert Message(text="abc") != Message(text="def")
    assert Message(text="abc", code="custom") == Message(text="abc", code="custom")
    assert Message(text="abc", code="custom") != Message(text="abc", code="max_length")
    assert Message(text="abc", key="username") == Message(text="abc", key="username")
    assert Message(text="abc", key="username") != Message(text="abc", key="password")
    assert Message(text="abc", index=["users", 3, "username"]) == Message(
        text="abc", index=["users", 3, "username"]
    )

# Generated at 2022-06-18 12:07:40.774823
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d"]) == Message(text="a", code="b", key="c", index=["d"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["e"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["d", "e"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["d", "e"], start_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:07:50.727558
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index1"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key1", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code1", key="key", index=["index"])

# Generated at 2022-06-18 12:07:53.864289
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:07:59.117706
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=1, char_index=0))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=1, char_index=0))
    assert message1 == message2


# Generated at 2022-06-18 12:08:10.514186
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], position=Position(line_no=1, column_no=1, char_index=1), start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))

# Generated at 2022-06-18 12:08:13.950754
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    msg2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert msg1 == msg2


# Generated at 2022-06-18 12:08:20.235600
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text', code='code', key='key', index=['index'], position=Position(1,2,3), start_position=Position(1,2,3), end_position=Position(1,2,3))
    message2 = Message(text='text', code='code', key='key', index=['index'], position=Position(1,2,3), start_position=Position(1,2,3), end_position=Position(1,2,3))
    assert message1 == message2


# Generated at 2022-06-18 12:08:30.211109
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=1, char_index=0)) == Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=1, char_index=0))

# Generated at 2022-06-18 12:08:33.349423
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:09:46.624241
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=["c"])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=["d"])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=["c", "d"])

# Generated at 2022-06-18 12:09:55.024041
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", position=Position(1, 2, 3)) == Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert Message(text="text", code="code", key="key", position=Position(1, 2, 3)) != Message(text="text", code="code", key="key", position=Position(1, 2, 4))
    assert Message(text="text", code="code", key="key", position=Position(1, 2, 3)) != Message(text="text", code="code", key="key", position=Position(1, 2, 3), start_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:09:59.565189
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text2", code="code2", key="key2", index=["index2"])
    message3 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message3
    assert message1 != message2


# Generated at 2022-06-18 12:10:07.016291
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    assert message1 == message2
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text2", code="code1", key="key1", position=Position(1, 1, 1))
    assert not message1 == message2
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))

# Generated at 2022-06-18 12:10:10.900691
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1,2,3))
    message2 = Message(text="text", code="code", key="key", position=Position(1,2,3))
    assert message1 == message2


# Generated at 2022-06-18 12:10:14.431990
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:10:19.875159
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text', code='code', index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    message2 = Message(text='text', code='code', index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert message1 == message2


# Generated at 2022-06-18 12:10:28.606670
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d"]) == Message(text="a", code="b", key="c", index=["d"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["e"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="d", index=["c"])

# Generated at 2022-06-18 12:10:31.748359
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:10:35.773476
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2
