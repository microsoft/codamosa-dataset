

# Generated at 2022-06-18 12:02:53.213922
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test for method __eq__ of class Message
    # Setup
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1,1,1))
    message2 = Message(text="text2", code="code2", key="key2", position=Position(2,2,2))
    message3 = Message(text="text1", code="code1", key="key1", position=Position(1,1,1))
    message4 = Message(text="text1", code="code1", key="key1", position=Position(1,1,1))
    message5 = Message(text="text1", code="code1", key="key1", position=Position(1,1,1))

# Generated at 2022-06-18 12:03:02.454801
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key")
    message2 = Message(text="text", code="code", key="key")
    assert message1 == message2
    message3 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 != message3
    message4 = Message(text="text", code="code", key="key", index=["index"])
    assert message3 == message4
    message5 = Message(text="text", code="code", key="key", index=["index"])
    assert message4 == message5
    message6 = Message(text="text", code="code", key="key", index=["index"])
    assert message5 == message6

# Generated at 2022-06-18 12:03:05.718068
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:08.976194
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError())
    assert list(result) == [None, ValidationError()]


# Generated at 2022-06-18 12:03:12.679970
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text='error'))
    assert list(vr) == [None, ValidationError(text='error')]


# Generated at 2022-06-18 12:03:15.972594
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:19.549097
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:23.041809
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:32.912738
# Unit test for method __iter__ of class ValidationResult

# Generated at 2022-06-18 12:03:36.559302
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:48.019068
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1, 2])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1, 2, 3])

# Generated at 2022-06-18 12:03:51.413169
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:04:03.688193
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", index=["index"]) == Message(text="text", code="code", index=["index"])
    assert Message(text="text", code="code", index=["index"]) != Message(text="text", code="code", index=["index1"])
    assert Message(text="text", code="code", index=["index"]) != Message(text="text1", code="code", index=["index"])
    assert Message(text="text", code="code", index=["index"]) != Message(text="text", code="code1", index=["index"])
    assert Message(text="text", code="code", index=["index"]) != Message(text="text", code="code", index=["index"], position=Position(1, 2, 3))

# Generated at 2022-06-18 12:04:09.710554
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 == message2


# Generated at 2022-06-18 12:04:12.789658
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:04:16.634267
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text='text', code='code', index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    message_2 = Message(text='text', code='code', index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert message_1 == message_2
    message_3 = Message(text='text', code='code', index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 7))
    assert message_1 != message_3


# Generated at 2022-06-18 12:04:20.653960
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:04:24.895701
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:04:33.201706
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username", position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username", position=Position(line_no=1, column_no=2, char_index=3))
    message3 = Message(text="May not have more than 100 characters", code="max_length", key="username", position=Position(line_no=1, column_no=2, char_index=4))
    message4 = Message(text="May not have more than 100 characters", code="max_length", key="username", position=Position(line_no=1, column_no=3, char_index=3))
    message5

# Generated at 2022-06-18 12:04:43.050637
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", position=Position(1, 2, 3)) == Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert Message(text="text", code="code", key="key", position=Position(1, 2, 3)) != Message(text="text", code="code", key="key", position=Position(1, 2, 4))
    assert Message(text="text", code="code", key="key", position=Position(1, 2, 3)) != Message(text="text", code="code", key="key", position=Position(1, 3, 3))

# Generated at 2022-06-18 12:04:49.937952
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 1, 1))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 1, 1))
    assert message1 == message2


# Generated at 2022-06-18 12:04:55.123219
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 == message2


# Generated at 2022-06-18 12:05:01.692748
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with equal values
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2
    # Test with different values
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 != message2


# Generated at 2022-06-18 12:05:12.275898
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", position=Position(1, 2, 3)) == Message(text="a", code="b", key="c", position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c", position=Position(1, 2, 3)) != Message(text="a", code="b", key="c", position=Position(1, 2, 4))
    assert Message(text="a", code="b", key="c", position=Position(1, 2, 3)) != Message(text="a", code="b", key="c", position=Position(1, 3, 3))

# Generated at 2022-06-18 12:05:22.379708
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='text', code='code', key='key', index=['index'], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3)) == Message(text='text', code='code', key='key', index=['index'], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:05:32.095757
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=1, char_index=0))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=1, char_index=0))
    assert message1 == message2


# Generated at 2022-06-18 12:05:42.327433
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="", code="", key=None, index=None, position=None, start_position=None, end_position=None) == Message(text="", code="", key=None, index=None, position=None, start_position=None, end_position=None)
    assert Message(text="", code="", key=None, index=None, position=None, start_position=None, end_position=None) != Message(text="", code="", key=None, index=None, position=None, start_position=None, end_position=Position(line_no=0, column_no=0, char_index=0))

# Generated at 2022-06-18 12:05:49.677723
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1,2,3))
    message2 = Message(text="text", code="code", key="key", position=Position(1,2,3))
    message3 = Message(text="text", code="code", key="key", position=Position(1,2,3))
    assert message1 == message2
    assert message1 == message3
    assert message2 == message3


# Generated at 2022-06-18 12:06:00.779738
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", index=["index"])
    assert message == Message(text="text", code="code", index=["index"])
    assert message != Message(text="text", code="code", index=["index", "index"])
    assert message != Message(text="text", code="code", index=["index", "index"])
    assert message != Message(text="text", code="code", index=["index", "index"])
    assert message != Message(text="text", code="code", index=["index", "index"])
    assert message != Message(text="text", code="code", index=["index", "index"])
    assert message != Message(text="text", code="code", index=["index", "index"])

# Generated at 2022-06-18 12:06:07.145750
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    assert message1 == message2
    message3 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    message4 = Message

# Generated at 2022-06-18 12:06:18.817040
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", index=[1, 2, 3])
    message2 = Message(text="text2", code="code2", index=[1, 2, 3])
    message3 = Message(text="text1", code="code1", index=[1, 2, 3])
    assert message1 == message3
    assert message1 != message2


# Generated at 2022-06-18 12:06:26.035585
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with two equal Message objects
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2

    # Test with two unequal Message objects
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text2", code="code2", key="key2", index=["index2"])
    assert message1 != message2


# Generated at 2022-06-18 12:06:35.417371
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="foo") == Message(text="foo")
    assert Message(text="foo", code="bar") == Message(text="foo", code="bar")
    assert Message(text="foo", key="bar") == Message(text="foo", key="bar")
    assert Message(text="foo", index=["bar"]) == Message(text="foo", index=["bar"])
    assert Message(text="foo", position=Position(1, 2, 3)) == Message(
        text="foo", position=Position(1, 2, 3)
    )
    assert Message(text="foo", start_position=Position(1, 2, 3)) == Message(
        text="foo", start_position=Position(1, 2, 3)
    )

# Generated at 2022-06-18 12:06:38.836692
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:06:42.027618
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:06:50.550391
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index", "index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index"], position=Position(1, 1, 1))
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index"], start_position=Position(1, 1, 1))


# Generated at 2022-06-18 12:07:00.376331
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index", "index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index2"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key2", index=["index"])

# Generated at 2022-06-18 12:07:09.959242
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="foo") == Message(text="foo")
    assert Message(text="foo") != Message(text="bar")
    assert Message(text="foo", code="foo") == Message(text="foo", code="foo")
    assert Message(text="foo", code="foo") != Message(text="foo", code="bar")
    assert Message(text="foo", key="foo") == Message(text="foo", key="foo")
    assert Message(text="foo", key="foo") != Message(text="foo", key="bar")
    assert Message(text="foo", index=["foo"]) == Message(text="foo", index=["foo"])
    assert Message(text="foo", index=["foo"]) != Message(text="foo", index=["bar"])

# Generated at 2022-06-18 12:07:14.343790
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:07:24.674284
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test for method __eq__ of class Message
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    index = ["users", 3, "username"]
    position = Position(line_no=1, column_no=2, char_index=3)
    start_position = Position(line_no=1, column_no=2, char_index=3)
    end_position = Position(line_no=1, column_no=2, char_index=3)

    # Test
    message1 = Message(text=text, code=code, key=key, position=position)
    message2 = Message(text=text, code=code, key=key, position=position)
    assert message1 == message2
