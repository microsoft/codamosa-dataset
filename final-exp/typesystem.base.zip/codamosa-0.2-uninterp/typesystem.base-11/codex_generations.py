

# Generated at 2022-06-18 12:02:50.643896
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:54.467287
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:58.747844
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    from typesystem import ValidationResult
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text='error'))
    assert list(vr) == [None, ValidationError(text='error')]


# Generated at 2022-06-18 12:03:01.475147
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = 'value'
    error = 'error'
    result = ValidationResult(value=value, error=error)
    assert list(result) == [value, error]


# Generated at 2022-06-18 12:03:04.702403
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:08.077207
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:11.678482
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:15.129068
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:18.677188
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text='error'))
    assert list(vr) == [None, ValidationError(text='error')]


# Generated at 2022-06-18 12:03:22.324610
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value=1)
    assert list(value) == [1, None]
    value, error = ValidationResult(error=ValidationError(text="error"))
    assert list(value) == [None, ValidationError(text="error")]
