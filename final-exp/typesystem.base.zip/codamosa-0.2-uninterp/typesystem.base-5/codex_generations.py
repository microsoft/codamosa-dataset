

# Generated at 2022-06-18 12:02:48.139861
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != 1


# Generated at 2022-06-18 12:02:54.303028
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert not Position(1, 2, 3) == Position(1, 2, 4)
    assert not Position(1, 2, 3) == Position(1, 3, 3)
    assert not Position(1, 2, 3) == Position(2, 2, 3)
    assert not Position(1, 2, 3) == Position(1, 2, 3, 4)
    assert not Position(1, 2, 3) == 1


# Generated at 2022-06-18 12:03:03.453051
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with a single message
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error1", code="code1", key="key1")
    assert error1 == error2
    error2 = BaseError(text="error2", code="code1", key="key1")
    assert error1 != error2
    error2 = BaseError(text="error1", code="code2", key="key1")
    assert error1 != error2
    error2 = BaseError(text="error1", code="code1", key="key2")
    assert error1 != error2

    # Test with multiple messages

# Generated at 2022-06-18 12:03:12.938732
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with a single message
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error1", code="code1", key="key1")
    error3 = BaseError(text="error2", code="code1", key="key1")
    error4 = BaseError(text="error1", code="code2", key="key1")
    error5 = BaseError(text="error1", code="code1", key="key2")
    assert error1 == error2
    assert error1 != error3
    assert error1 != error4
    assert error1 != error5
    # Test with multiple messages
    error1 = BaseError(messages=[Message(text="error1", code="code1", key="key1")])

# Generated at 2022-06-18 12:03:21.968959
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='a') == BaseError(text='a')
    assert BaseError(text='a') != BaseError(text='b')
    assert BaseError(text='a', code='c') == BaseError(text='a', code='c')
    assert BaseError(text='a', code='c') != BaseError(text='a', code='d')
    assert BaseError(text='a', key='k') == BaseError(text='a', key='k')
    assert BaseError(text='a', key='k') != BaseError(text='a', key='l')
    assert BaseError(text='a', position=Position(1, 2, 3)) == BaseError(text='a', position=Position(1, 2, 3))
    assert BaseError(text='a', position=Position(1, 2, 3)) != Base

# Generated at 2022-06-18 12:03:31.797992
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='a') == BaseError(text='a')
    assert BaseError(text='a') != BaseError(text='b')
    assert BaseError(text='a', code='a') == BaseError(text='a', code='a')
    assert BaseError(text='a', code='a') != BaseError(text='a', code='b')
    assert BaseError(text='a', key='a') == BaseError(text='a', key='a')
    assert BaseError(text='a', key='a') != BaseError(text='a', key='b')
    assert BaseError(text='a', position=Position(1, 2, 3)) == BaseError(text='a', position=Position(1, 2, 3))
    assert BaseError(text='a', position=Position(1, 2, 3)) != Base

# Generated at 2022-06-18 12:03:41.293951
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k", code="c") == BaseError(text="a", key="k", code="c")

# Generated at 2022-06-18 12:03:51.068395
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=2, char_index=4)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=2, column_no=2, char_index=3)

# Generated at 2022-06-18 12:04:03.272334
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with a single error message
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    assert error1 == error2
    assert error1 != "error1"
    # Test with multiple error messages
    error3 = BaseError(messages=[Message(text="error1"), Message(text="error2")])
    error4 = BaseError(messages=[Message(text="error1"), Message(text="error2")])
    assert error3 == error4
    assert error3 != "error1"
    # Test with different error messages
    error5 = BaseError(messages=[Message(text="error1"), Message(text="error2")])
    error6 = BaseError(messages=[Message(text="error1"), Message(text="error3")])
    assert error5 != error6


# Generated at 2022-06-18 12:04:13.316857
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a", code="b", key="c") == BaseError(text="a", code="b", key="c")
    assert BaseError(text="a", code="b", key="c") != BaseError(text="a", code="b", key="d")
    assert BaseError(text="a", code="b", key="c") != BaseError(text="a", code="b", key="c", messages=[Message(text="a", code="b", key="c")])
    assert BaseError(text="a", code="b", key="c") != BaseError(text="a", code="b", key="c", messages=[Message(text="a", code="b", key="c"), Message(text="a", code="b", key="c")])

# Generated at 2022-06-18 12:04:28.303559
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text='error1', code='code1', key='key1')
    error2 = BaseError(text='error1', code='code1', key='key1')
    assert error1 == error2

    # Test 2
    error1 = BaseError(text='error1', code='code1', key='key1')
    error2 = BaseError(text='error2', code='code1', key='key1')
    assert error1 != error2

    # Test 3
    error1 = BaseError(text='error1', code='code1', key='key1')
    error2 = BaseError(text='error1', code='code2', key='key1')
    assert error1 != error2

    # Test 4

# Generated at 2022-06-18 12:04:36.424682
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that BaseError.__eq__() works correctly
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert error1 != error2
    assert error1 != "error1"
    assert error1 != None
    assert error1 != 1
    assert error1 != 1.0
    assert error1 != []
    assert error1 != {}
    assert error1 != (1, 2, 3)
    assert error1 != BaseError(text="error1")
    assert error1 != BaseError(text="error1", code="code1")
    assert error1 != BaseError(text="error1", key="key1")

# Generated at 2022-06-18 12:04:46.293080
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    message1 = Message(text='text1', code='code1', key='key1', position=Position(1, 1, 1))
    message2 = Message(text='text2', code='code2', key='key2', position=Position(2, 2, 2))
    message3 = Message(text='text3', code='code3', key='key3', position=Position(3, 3, 3))
    message4 = Message(text='text4', code='code4', key='key4', position=Position(4, 4, 4))
    message5 = Message(text='text5', code='code5', key='key5', position=Position(5, 5, 5))

# Generated at 2022-06-18 12:04:55.417888
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="error1") == BaseError(text="error1")
    assert BaseError(text="error1") != BaseError(text="error2")
    assert BaseError(text="error1", code="code1") == BaseError(text="error1", code="code1")
    assert BaseError(text="error1", code="code1") != BaseError(text="error1", code="code2")
    assert BaseError(text="error1", key="key1") == BaseError(text="error1", key="key1")
    assert BaseError(text="error1", key="key1") != BaseError(text="error1", key="key2")
    assert BaseError(messages=[Message(text="error1")]) == BaseError(messages=[Message(text="error1")])

# Generated at 2022-06-18 12:04:59.021843
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:05:09.330877
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(text="test", code="test", key="test", position=Position(1, 2, 3))
    assert error.messages() == [Message(text="test", code="test", key="test", position=Position(1, 2, 3))]
    assert error.messages(add_prefix="test") == [Message(text="test", code="test", index=["test"])]
    assert error.messages(add_prefix=1) == [Message(text="test", code="test", index=[1])]
    assert error.messages(add_prefix=1.0) == [Message(text="test", code="test", index=[1.0])]
    assert error.messages(add_prefix=True) == [Message(text="test", code="test", index=[True])]
    assert error.mess

# Generated at 2022-06-18 12:05:12.846061
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:05:15.730493
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='text', code='code', key='key')
    error2 = BaseError(text='text', code='code', key='key')
    assert error1 == error2


# Generated at 2022-06-18 12:05:25.803056
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="abc") == BaseError(text="abc")
    assert BaseError(text="abc") != BaseError(text="def")
    assert BaseError(text="abc", code="def") == BaseError(text="abc", code="def")
    assert BaseError(text="abc", code="def") != BaseError(text="abc", code="ghi")
    assert BaseError(text="abc", key="def") == BaseError(text="abc", key="def")
    assert BaseError(text="abc", key="def") != BaseError(text="abc", key="ghi")
    assert BaseError(text="abc", key="def", position=Position(1, 2, 3)) == BaseError(text="abc", key="def", position=Position(1, 2, 3))

# Generated at 2022-06-18 12:05:36.002667
# Unit test for constructor of class ValidationError
def test_ValidationError():
    error = ValidationError(text="error message")
    assert error.messages() == [Message(text="error message", code="custom")]
    assert dict(error) == {"": "error message"}
    assert str(error) == "error message"
    assert repr(error) == "ValidationError(text='error message', code='custom')"

    error = ValidationError(messages=[Message(text="error message", code="custom")])
    assert error.messages() == [Message(text="error message", code="custom")]
    assert dict(error) == {"": "error message"}
    assert str(error) == "error message"
    assert repr(error) == "ValidationError([Message(text='error message', code='custom')])"
