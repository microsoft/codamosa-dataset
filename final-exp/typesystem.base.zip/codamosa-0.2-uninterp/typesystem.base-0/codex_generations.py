

# Generated at 2022-06-18 12:02:51.378763
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError())
    assert list(result) == [None, ValidationError()]


# Generated at 2022-06-18 12:02:55.146192
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:58.375967
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError())
    assert list(vr) == [None, ValidationError()]


# Generated at 2022-06-18 12:03:01.429441
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError())
    assert list(result) == [None, ValidationError()]


# Generated at 2022-06-18 12:03:04.662446
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:14.175252
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError() == BaseError()
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", position=Position(1, 2, 3)) == BaseError(
        text="a", position=Position(1, 2, 3)
    )

# Generated at 2022-06-18 12:03:17.646483
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:03:26.656637
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=1, char_index=1))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=1, char_index=1))
    message3 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=2, column_no=2, char_index=2))
    message4 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=1, char_index=1))
    message5

# Generated at 2022-06-18 12:03:36.750430
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    # Test for method __str__ of class BaseError
    error = BaseError(text="Error message")
    assert str(error) == "Error message"
    error = BaseError(messages=[Message(text="Error message")])
    assert str(error) == "{'': 'Error message'}"
    error = BaseError(messages=[Message(text="Error message", key="key")])
    assert str(error) == "{'key': 'Error message'}"
    error = BaseError(messages=[Message(text="Error message", index=["key"])])
    assert str(error) == "{'key': 'Error message'}"
    error = BaseError(messages=[Message(text="Error message", index=["key", "key"])])
    assert str(error) == "{'key': {'key': 'Error message'}}"

# Generated at 2022-06-18 12:03:39.956868
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1")
    message2 = Message(text="text1", code="code1", key="key1")
    assert message1 == message2


# Generated at 2022-06-18 12:03:55.697164
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text="May not have more than 100 characters")
    assert str(error) == "May not have more than 100 characters"

    error = BaseError(messages=[Message(text="May not have more than 100 characters")])
    assert str(error) == "{'': 'May not have more than 100 characters'}"

    error = BaseError(
        messages=[
            Message(text="May not have more than 100 characters", key="username"),
            Message(text="May not have more than 100 characters", key="password"),
        ]
    )
    assert str(error) == "{'username': 'May not have more than 100 characters', 'password': 'May not have more than 100 characters'}"


# Generated at 2022-06-18 12:04:01.861802
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    messages = [
        Message(text="May not have more than 100 characters", code="max_length", key="username"),
        Message(text="May not have more than 100 characters", code="max_length", key="password"),
    ]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    assert error1 == error2


# Generated at 2022-06-18 12:04:12.460760
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a") != BaseError(text="a", code="a")
    assert BaseError(text="a") != BaseError(text="a", key="a")
    assert BaseError(text="a") != BaseError(text="a", position=Position(1, 1, 1))
    assert BaseError(text="a") != BaseError(text="a", messages=[Message(text="a")])
    assert BaseError(text="a") != BaseError(messages=[Message(text="a")])
    assert BaseError(messages=[Message(text="a")]) == BaseError(messages=[Message(text="a")])

# Generated at 2022-06-18 12:04:16.772149
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a") != BaseError(text="a", code="a")
    assert BaseError(text="a") != BaseError(text="a", key="a")
    assert BaseError(text="a") != BaseError(text="a", position=Position(1, 1, 1))
    assert BaseError(text="a") != BaseError(messages=[Message(text="a")])
    assert BaseError(messages=[Message(text="a")]) == BaseError(messages=[Message(text="a")])
    assert BaseError(messages=[Message(text="a")]) != BaseError(messages=[Message(text="b")])

# Generated at 2022-06-18 12:04:27.557721
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    assert error1 == error2

    # Test 2
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2 = BaseError(text='May not have more than 100 characters', code='max_length', key='password')
    assert error1 != error2

    # Test 3
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2 = BaseError(text='May not have more than 100 characters', code='min_length', key='username')


# Generated at 2022-06-18 12:04:35.319984
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    assert message1 == message2
    message3 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 2))
    assert message1 != message3
    message4 = Message(text="text1", code="code1", key="key1", position=Position(1, 2, 1))
    assert message1 != message4
    message5 = Message(text="text1", code="code1", key="key1", position=Position(2, 1, 1))
    assert message1 != message5

# Generated at 2022-06-18 12:04:42.590837
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=1, char_index=0)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    # Verify
    assert error1 == error2


# Generated at 2022-06-18 12:04:45.563995
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    assert error1 == error1
    assert error2 == error2
    assert error1 != error2


# Generated at 2022-06-18 12:04:47.179749
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text="error message")
    assert str(error) == "error message"


# Generated at 2022-06-18 12:04:56.470334
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text="error message")
    assert str(error) == "error message"
    error = BaseError(messages=[Message(text="error message")])
    assert str(error) == "error message"
    error = BaseError(messages=[Message(text="error message", key="key")])
    assert str(error) == "{'key': 'error message'}"
    error = BaseError(messages=[Message(text="error message", index=["key"])])
    assert str(error) == "{'key': 'error message'}"
    error = BaseError(messages=[Message(text="error message", index=["key", "key"])])
    assert str(error) == "{'key': {'key': 'error message'}}"

# Generated at 2022-06-18 12:05:09.438522
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=2, char_index=3)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error = BaseError(messages=messages)
    other = BaseError(messages=messages)
    # Test
    assert error == other
    # Teardown



# Generated at 2022-06-18 12:05:19.748599
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two empty ValidationError objects
    error1 = ValidationError()
    error2 = ValidationError()
    assert error1 == error2
    # Test with two ValidationError objects with same error message
    error1 = ValidationError(text="Error message")
    error2 = ValidationError(text="Error message")
    assert error1 == error2
    # Test with two ValidationError objects with different error message
    error1 = ValidationError(text="Error message 1")
    error2 = ValidationError(text="Error message 2")
    assert error1 != error2
    # Test with two ValidationError objects with same error message and code
    error1 = ValidationError(text="Error message", code="error_code")
    error2 = ValidationError(text="Error message", code="error_code")
    assert error1

# Generated at 2022-06-18 12:05:22.994724
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:05:33.190037
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    assert error1 == error2
    # Test 2
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    assert error1 != error2
    # Test 3
    error1 = BaseError(text="error1", code="code1")
    error2 = BaseError(text="error1", code="code1")
    assert error1 == error2
    # Test 4
    error1 = BaseError(text="error1", code="code1")
    error2 = BaseError(text="error1", code="code2")
    assert error1 != error2
    # Test 5
    error1 = BaseError(text="error1", key="key1")


# Generated at 2022-06-18 12:05:43.786253
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='a') == BaseError(text='a')
    assert BaseError(text='a') != BaseError(text='b')
    assert BaseError(text='a', code='a') == BaseError(text='a', code='a')
    assert BaseError(text='a', code='a') != BaseError(text='a', code='b')
    assert BaseError(text='a', key='a') == BaseError(text='a', key='a')
    assert BaseError(text='a', key='a') != BaseError(text='a', key='b')
    assert BaseError(text='a', key='a', position=Position(1, 1, 1)) == BaseError(text='a', key='a', position=Position(1, 1, 1))

# Generated at 2022-06-18 12:05:54.994312
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with a single message
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error1", code="code1", key="key1")
    assert error1 == error2
    error3 = BaseError(text="error1", code="code1", key="key2")
    assert error1 != error3
    error4 = BaseError(text="error1", code="code2", key="key1")
    assert error1 != error4
    error5 = BaseError(text="error2", code="code1", key="key1")
    assert error1 != error5
    # Test with multiple messages
    error6 = BaseError(messages=[Message(text="error1", code="code1", key="key1")])
    assert error1 == error6


# Generated at 2022-06-18 12:06:05.521621
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k") != BaseError(text="a", index=["k"])
    assert BaseError(text="a", index=["k"]) == BaseError(text="a", index=["k"])
   

# Generated at 2022-06-18 12:06:13.891816
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="text1", code="code1", key="key1")
    error2 = BaseError(text="text1", code="code1", key="key1")
    assert error1 == error2
    error3 = BaseError(text="text1", code="code1", key="key2")
    assert error1 != error3
    error4 = BaseError(text="text1", code="code2", key="key1")
    assert error1 != error4
    error5 = BaseError(text="text2", code="code1", key="key1")
    assert error1 != error5
    error6 = BaseError(text="text1", code="code1", key="key1", position=Position(1, 2, 3))
    assert error1 != error6

# Generated at 2022-06-18 12:06:19.434082
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 == message2


# Generated at 2022-06-18 12:06:28.698809
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that ValidationError is equal to itself
    error = ValidationError(text="hello")
    assert error == error
    # Test that ValidationError is equal to another ValidationError with the same messages
    error2 = ValidationError(text="hello")
    assert error == error2
    # Test that ValidationError is not equal to another ValidationError with different messages
    error3 = ValidationError(text="hello", code="custom")
    assert error != error3
    # Test that ValidationError is not equal to another ValidationError with different messages
    error4 = ValidationError(text="hello", key="key")
    assert error != error4
    # Test that ValidationError is not equal to another ValidationError with different messages
    error5 = ValidationError(text="hello", position=Position(1, 2, 3))

# Generated at 2022-06-18 12:06:47.098884
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d", "e"]) == Message(text="a", code="b", key="c", index=["d", "e"])
    assert Message(text="a", code="b", key="c", index=["d", "e"]) != Message(text="a", code="b", key="c", index=["d", "e", "f"])
    assert Message(text="a", code="b", key="c", index=["d", "e"]) != Message(text="a", code="b", key="c", index=["d", "f"])
    assert Message(text="a", code="b", key="c", index=["d", "e"]) != Message(text="a", code="b", key="c", index=["d"])

# Generated at 2022-06-18 12:06:56.277518
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k") != BaseError(text="a", index=["k"])
    assert BaseError(text="a", index=["k"]) == BaseError(text="a", index=["k"])
   

# Generated at 2022-06-18 12:07:05.694939
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two empty ValidationError objects
    error1 = ValidationError()
    error2 = ValidationError()
    assert error1 == error2

    # Test with two ValidationError objects with same message
    error1 = ValidationError(text="Error message")
    error2 = ValidationError(text="Error message")
    assert error1 == error2

    # Test with two ValidationError objects with different messages
    error1 = ValidationError(text="Error message 1")
    error2 = ValidationError(text="Error message 2")
    assert error1 != error2

    # Test with two ValidationError objects with same message and code
    error1 = ValidationError(text="Error message", code="error_code")
    error2 = ValidationError(text="Error message", code="error_code")
    assert error1 == error2

# Generated at 2022-06-18 12:07:12.366348
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key=1, index=[1], position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    message2 = Message(text="text", code="code", key=1, index=[1], position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    assert message1 == message2


# Generated at 2022-06-18 12:07:20.881200
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = 'May not have more than 100 characters'
    code = 'max_length'
    key = 'username'
    position = Position(line_no=1, column_no=1, char_index=0)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    # Test
    assert error == error2
    # Teardown
    pass


# Generated at 2022-06-18 12:07:25.686950
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    error1 = BaseError(text='error1')
    error2 = BaseError(text='error2')
    error3 = BaseError(text='error1')
    # Exercise
    # Verify
    assert error1 != error2
    assert error1 == error3


# Generated at 2022-06-18 12:07:30.144582
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='test_text', code='test_code', key='test_key')
    error2 = BaseError(text='test_text', code='test_code', key='test_key')
    assert error1 == error2


# Generated at 2022-06-18 12:07:34.479172
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    assert message1 == message2


# Generated at 2022-06-18 12:07:37.620326
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    assert error1 == error1
    assert error2 == error2
    assert error1 != error2
    assert error2 != error1


# Generated at 2022-06-18 12:07:42.676175
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that BaseError.__eq__() works as expected
    # Create a BaseError object
    error1 = BaseError(text="error1")
    # Create another BaseError object
    error2 = BaseError(text="error2")
    # Check that the two objects are not equal
    assert error1 != error2
    # Create another BaseError object
    error3 = BaseError(text="error1")
    # Check that the two objects are equal
    assert error1 == error3


# Generated at 2022-06-18 12:08:16.816514
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=2, char_index=3)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error = BaseError(messages=messages)
    other = BaseError(messages=messages)
    # Test
    assert error == other
    # Teardown


# Generated at 2022-06-18 12:08:26.561640
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with two equal Message objects
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username", index=["users", 3, "username"], start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username", index=["users", 3, "username"], start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 == message2

    # Test with two unequal Message objects
    message1

# Generated at 2022-06-18 12:08:35.454797
# Unit test for method __eq__ of class BaseError

# Generated at 2022-06-18 12:08:43.507371
# Unit test for method __eq__ of class BaseError

# Generated at 2022-06-18 12:08:53.240169
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    message1 = Message(text="text1", code="code1", key="key1")
    message2 = Message(text="text2", code="code2", key="key2")
    error1 = BaseError(messages=[message1, message2])
    error2 = BaseError(messages=[message1, message2])
    assert error1 == error2
    # Test 2
    message1 = Message(text="text1", code="code1", key="key1")
    message2 = Message(text="text2", code="code2", key="key2")
    error1 = BaseError(messages=[message1, message2])
    error2 = BaseError(messages=[message2, message1])
    assert error1 != error2
    # Test 3

# Generated at 2022-06-18 12:08:56.700981
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:09:05.468920
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text = "May not have more than 100 characters", code = "max_length", key = "username")
    error2 = BaseError(text = "May not have more than 100 characters", code = "max_length", key = "username")
    assert error1 == error2
    # Test 2
    error1 = BaseError(text = "May not have more than 100 characters", code = "max_length", key = "username")
    error2 = BaseError(text = "May not have more than 100 characters", code = "max_length", key = "password")
    assert error1 != error2
    # Test 3
    error1 = BaseError(text = "May not have more than 100 characters", code = "max_length", key = "username")

# Generated at 2022-06-18 12:09:14.204723
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    # Test
    # Verify
    assert BaseError(text='test') == BaseError(text='test')
    assert BaseError(text='test') != BaseError(text='test1')
    assert BaseError(text='test', code='test') == BaseError(text='test', code='test')
    assert BaseError(text='test', code='test') != BaseError(text='test', code='test1')
    assert BaseError(text='test', key='test') == BaseError(text='test', key='test')
    assert BaseError(text='test', key='test') != BaseError(text='test', key='test1')

# Generated at 2022-06-18 12:09:23.951801
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="a") == BaseError(text="a", code="a")
    assert BaseError(text="a", code="a") != BaseError(text="a", code="b")
    assert BaseError(text="a", key="a") == BaseError(text="a", key="a")
    assert BaseError(text="a", key="a") != BaseError(text="a", key="b")
    assert BaseError(text="a", key="a", code="a") == BaseError(text="a", key="a", code="a")

# Generated at 2022-06-18 12:09:28.121831
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="text1", code="code1", key="key1", position="position1")
    error2 = BaseError(text="text2", code="code2", key="key2", position="position2")
    assert error1 == error1
    assert error2 == error2
    assert error1 != error2
