

# Generated at 2022-06-18 12:02:42.584452
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError(text="error"))) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:49.201480
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    assert message == Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    assert message != Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 4))
    assert message != Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3), start_position=Position(1, 2, 3))
    assert message != Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3), end_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:02:52.923703
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text='error'))
    assert list(vr) == [None, ValidationError(text='error')]


# Generated at 2022-06-18 12:02:56.337604
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:01.189098
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    position1 = Position(line_no=1, column_no=2, char_index=3)
    position2 = Position(line_no=1, column_no=2, char_index=3)
    position3 = Position(line_no=1, column_no=2, char_index=4)
    assert position1 == position2
    assert position1 != position3


# Generated at 2022-06-18 12:03:04.505850
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:07.847058
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:11.402438
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:14.996086
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:18.519762
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:34.444347
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    message1 = Message(text="message1")
    message2 = Message(text="message2")
    message3 = Message(text="message3")
    message4 = Message(text="message4")
    message5 = Message(text="message5")
    message6 = Message(text="message6")
    message7 = Message(text="message7")
    message8 = Message(text="message8")
    message9 = Message(text="message9")
    message10 = Message(text="message10")
    message11 = Message(text="message11")
    message12 = Message(text="message12")
    message13 = Message(text="message13")
    message14 = Message(text="message14")
    message15 = Message(text="message15")
    message

# Generated at 2022-06-18 12:03:43.856947
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", position=Position(1, 2, 3)) == BaseError(
        text="a", position=Position(1, 2, 3)
    )

# Generated at 2022-06-18 12:03:54.167624
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with a Message object with a key
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2
    # Test with a Message object with an index
    message1 = Message(text="May not have more than 100 characters", code="max_length", index=["users", 3, "username"])
    message2 = Message(text="May not have more than 100 characters", code="max_length", index=["users", 3, "username"])
    assert message1 == message2
    # Test with a Message object with a position

# Generated at 2022-06-18 12:04:00.215299
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 1, 1))
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 1, 1))
    assert message1 == message2


# Generated at 2022-06-18 12:04:11.186120
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with no messages
    error1 = BaseError()
    error2 = BaseError()
    assert error1 == error2
    assert error2 == error1

    # Test with one message
    error1 = BaseError(text="test")
    error2 = BaseError(text="test")
    assert error1 == error2
    assert error2 == error1

    # Test with two messages
    error1 = BaseError(messages=[Message(text="test1"), Message(text="test2")])
    error2 = BaseError(messages=[Message(text="test1"), Message(text="test2")])
    assert error1 == error2
    assert error2 == error1

    # Test with different messages
    error1 = BaseError(messages=[Message(text="test1"), Message(text="test2")])
    error2 = Base

# Generated at 2022-06-18 12:04:15.398540
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test case 1
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    assert error1 == error2
    # Test case 2
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2 = BaseError(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    assert error1 != error2
    # Test case 3
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2

# Generated at 2022-06-18 12:04:22.288189
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(text="Error")
    assert error.messages() == [Message(text="Error", code="custom")]
    assert error.messages(add_prefix="foo") == [
        Message(text="Error", code="custom", index=["foo"])
    ]
    assert dict(error) == {"": "Error"}
    assert str(error) == "Error"
    assert repr(error) == "ParseError(text='Error', code='custom')"


# Generated at 2022-06-18 12:04:31.677097
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test 1
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2
    # Test 2
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index2"])
    assert message1 != message2
    # Test 3
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key2", index=["index"])
    assert message1 != message2
    # Test 4
    message1

# Generated at 2022-06-18 12:04:35.894744
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    error1 = BaseError(text='error1')
    error2 = BaseError(text='error2')
    error3 = BaseError(text='error1')
    # Verify
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:04:39.904367
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='text1', code='code1', key='key1', position='position1', messages='messages1')
    error2 = BaseError(text='text2', code='code2', key='key2', position='position2', messages='messages2')
    assert error1 == error2


# Generated at 2022-06-18 12:05:01.238216
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test that two messages with the same text, code, index, start_position, and end_position are equal
    message1 = Message(text="text", code="code", index=[1, 2], start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    message2 = Message(text="text", code="code", index=[1, 2], start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    assert message1 == message2
    # Test that two messages with different text are not equal
    message1 = Message(text="text1", code="code", index=[1, 2], start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))

# Generated at 2022-06-18 12:05:11.418532
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 == message2


# Generated at 2022-06-18 12:05:21.588118
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2
    message3 = Message(text="text2", code="code1", key="key1", index=["index1"])
    assert message1 != message3
    message4 = Message(text="text1", code="code2", key="key1", index=["index1"])
    assert message1 != message4
    message5 = Message(text="text1", code="code1", key="key2", index=["index1"])
    assert message1 != message5

# Generated at 2022-06-18 12:05:26.595567
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != None


# Generated at 2022-06-18 12:05:36.868249
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", key="key", index=["index"])
    assert message == Message(text="text", code="code", key="key", index=["index"])
    assert not message == Message(text="text", code="code", key="key", index=["index", "index"])
    assert not message == Message(text="text", code="code", key="key", index=["index", "index", "index"])
    assert not message == Message(text="text", code="code", key="key", index=["index", "index", "index", "index"])
    assert not message == Message(text="text", code="code", key="key", index=["index", "index", "index", "index", "index"])

# Generated at 2022-06-18 12:05:44.036424
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)
    assert Position(1, 2, 3) != 1


# Generated at 2022-06-18 12:05:47.750472
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:05:58.818848
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)
    assert Position(1, 2, 3) != Position(1, 2)
    assert Position(1, 2, 3) != Position(1)
    assert Position(1, 2, 3) != Position()
    assert Position(1, 2, 3) != object()
    assert Position(1, 2, 3) != None


# Generated at 2022-06-18 12:06:01.735654
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)


# Generated at 2022-06-18 12:06:08.833011
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)
    assert Position(1, 2, 3) != Position(1, 2)
    assert Position(1, 2, 3) != Position(1)
    assert Position(1, 2, 3) != Position()
    assert Position(1, 2, 3) != 1
    assert Position(1, 2, 3) != object()


# Generated at 2022-06-18 12:06:34.003061
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:06:39.042272
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text', code='code', index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    message2 = Message(text='text', code='code', index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert message1 == message2


# Generated at 2022-06-18 12:06:47.210706
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    assert message1 == message2


# Generated at 2022-06-18 12:06:50.512932
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:07:00.333955
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index1"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key1", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code1", key="key", index=["index"])

# Generated at 2022-06-18 12:07:09.920438
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=2, char_index=3), end_position=Position(line_no=1, column_no=2, char_index=3))

# Generated at 2022-06-18 12:07:13.895709
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:07:24.630630
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="May not have more than 100 characters", code="max_length", key="username") == Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert Message(text="May not have more than 100 characters", code="max_length", key="username") != Message(text="May not have more than 100 characters", code="max_length", key="username2")
    assert Message(text="May not have more than 100 characters", code="max_length", key="username") != Message(text="May not have more than 100 characters", code="max_length2", key="username")
    assert Message(text="May not have more than 100 characters", code="max_length", key="username") != Message(text="May not have more than 100 characters2", code="max_length", key="username")

# Generated at 2022-06-18 12:07:31.701944
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="May not have more than 100 characters", code="max_length", key="username", index=["users", 3, "username"], position=Position(line_no=1, column_no=1, char_index=1), start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    assert message == message


# Generated at 2022-06-18 12:07:41.096104
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d"]) == Message(text="a", code="b", key="c", index=["d"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["e"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["d", "e"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["d", "e", "f"])