

# Generated at 2022-06-18 12:02:37.891987
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError())
    assert list(vr) == [None, ValidationError()]


# Generated at 2022-06-18 12:02:42.605143
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != 1


# Generated at 2022-06-18 12:02:44.933189
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value = "value"
    error = ValidationError(text="error")
    result = ValidationResult(value=value, error=error)
    assert list(result) == [value, error]


# Generated at 2022-06-18 12:02:54.096758
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    # Test
    # Verify
    assert BaseError() == BaseError()
    assert BaseError(text="text") == BaseError(text="text")
    assert BaseError(text="text", code="code") == BaseError(text="text", code="code")
    assert BaseError(text="text", key="key") == BaseError(text="text", key="key")
    assert BaseError(text="text", position=Position(1, 2, 3)) == BaseError(
        text="text", position=Position(1, 2, 3)
    )
    assert BaseError(messages=[Message(text="text")]) == BaseError(
        messages=[Message(text="text")]
    )

# Generated at 2022-06-18 12:02:57.689642
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:00.939389
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:04.675519
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert next(iter(vr)) == 1
    assert next(iter(vr)) is None
    vr = ValidationResult(error=ValidationError())
    assert next(iter(vr)) is None
    assert next(iter(vr)) is not None


# Generated at 2022-06-18 12:03:14.228264
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    # Exercise
    # Verify
    assert BaseError(text='test') == BaseError(text='test')
    assert BaseError(text='test') != BaseError(text='test1')
    assert BaseError(text='test', code='test') == BaseError(text='test', code='test')
    assert BaseError(text='test', code='test') != BaseError(text='test', code='test1')
    assert BaseError(text='test', key='test') == BaseError(text='test', key='test')
    assert BaseError(text='test', key='test') != BaseError(text='test', key='test1')

# Generated at 2022-06-18 12:03:17.746236
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:21.052559
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:33.577837
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that the method __eq__ of class BaseError returns True when the
    # two objects are equal and False otherwise
    # Create an object of class BaseError
    base_error = BaseError(text="text", code="code", key="key", position="position")
    # Create an object of class BaseError with the same attributes
    base_error_2 = BaseError(text="text", code="code", key="key", position="position")
    # Test that the method __eq__ returns True when the two objects are equal
    assert base_error == base_error_2
    # Create an object of class BaseError with different attributes
    base_error_3 = BaseError(text="text", code="code", key="key", position="position")
    # Test that the method __eq__ returns False when the two objects are not equal

# Generated at 2022-06-18 12:03:38.671458
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "foo"


# Generated at 2022-06-18 12:03:43.665864
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "foo"


# Generated at 2022-06-18 12:03:53.937381
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="text") == BaseError(text="text")
    assert BaseError(text="text") != BaseError(text="text2")
    assert BaseError(text="text") != BaseError(text="text", code="code")
    assert BaseError(text="text") != BaseError(text="text", key="key")
    assert BaseError(text="text") != BaseError(text="text", position=Position(1, 2, 3))
    assert BaseError(text="text") != BaseError(text="text", messages=[Message(text="text")])
    assert BaseError(text="text") != BaseError(text="text", messages=[Message(text="text2")])
    assert BaseError(text="text") != BaseError(text="text", messages=[Message(text="text", code="code")])
    assert BaseError

# Generated at 2022-06-18 12:04:05.846221
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3))
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3))
    assert message1 == message2
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3))
    message2 = Message(text="text2", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3))
    assert message1 != message2

# Generated at 2022-06-18 12:04:15.053112
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    assert error1 == error2

    # Test 2
    error1 = BaseError(text="error1", code="code1")
    error2 = BaseError(text="error1", code="code1")
    assert error1 == error2

    # Test 3
    error1 = BaseError(text="error1", key="key1")
    error2 = BaseError(text="error1", key="key1")
    assert error1 == error2

    # Test 4
    error1 = BaseError(text="error1", position=Position(1, 1, 1))
    error2 = BaseError(text="error1", position=Position(1, 1, 1))
    assert error1 == error2

    # Test

# Generated at 2022-06-18 12:04:26.064419
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    assert error1 == error2
    # Test 2
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    assert error1 != error2
    # Test 3
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1", code="code1")
    assert error1 != error2
    # Test 4
    error1 = BaseError(text="error1", code="code1")
    error2 = BaseError(text="error1", code="code2")
    assert error1 != error2
    # Test 5
    error1 = BaseError(text="error1", code="code1")
    error2 = Base

# Generated at 2022-06-18 12:04:33.870620
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) == Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) != Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 4))

# Generated at 2022-06-18 12:04:43.648605
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error_1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error_2 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    assert error_1 == error_2

    # Test 2
    error_1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error_2 = BaseError(text='May not have more than 100 characters', code='max_length', key='password')
    assert error_1 != error_2

    # Test 3
    error_1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')

# Generated at 2022-06-18 12:04:53.040913
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two BaseError instances with the same values
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    assert error1 == error2
    # Test with two BaseError instances with different values
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2 = BaseError(text='May not have more than 100 characters', code='max_length', key='password')
    assert error1 != error2
    # Test with two BaseError instances with different values
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2 = BaseError

# Generated at 2022-06-18 12:05:22.207327
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with two equal messages
    message1 = Message(text="test", code="test", key="test", position=Position(1, 1, 1))
    message2 = Message(text="test", code="test", key="test", position=Position(1, 1, 1))
    assert message1 == message2

    # Test with two different messages
    message1 = Message(text="test", code="test", key="test", position=Position(1, 1, 1))
    message2 = Message(text="test", code="test", key="test", position=Position(2, 2, 2))
    assert not message1 == message2

    # Test with two different messages
    message1 = Message(text="test", code="test", key="test", position=Position(1, 1, 1))

# Generated at 2022-06-18 12:05:25.802854
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:05:36.003385
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index1"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key1", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code1", key="key", index=["index"])

# Generated at 2022-06-18 12:05:46.646259
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index1"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key1", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code1", key="key", index=["index"])

# Generated at 2022-06-18 12:05:58.509230
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test for method __eq__ of class Message
    # Setup
    message1 = Message(text="text", code="code", key="key", index=[1, 2, 3])
    message2 = Message(text="text", code="code", key="key", index=[1, 2, 3])
    message3 = Message(text="text", code="code", key="key", index=[1, 2, 4])
    message4 = Message(text="text", code="code", key="key", index=[1, 2, 3, 4])
    message5 = Message(text="text", code="code", key="key", index=[1, 2, 3, 4])
    message6 = Message(text="text", code="code", key="key", index=[1, 2, 3, 5])

# Generated at 2022-06-18 12:06:02.538346
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:06:04.934625
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:06:12.923581
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(1, 2, 3)) == Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    assert Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(1, 2, 3)) != Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(1, 2, 4))

# Generated at 2022-06-18 12:06:22.489691
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text', code='code', key='key', index=['index'], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    message2 = Message(text='text', code='code', key='key', index=['index'], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    assert message1 == message2
    message3 = Message(text='text', code='code', key='key', index=['index'], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:06:26.171842
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:06:56.396005
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="foo", code="bar", key="baz") == Message(text="foo", code="bar", key="baz")
    assert Message(text="foo", code="bar", key="baz") != Message(text="foo", code="bar", key="qux")
    assert Message(text="foo", code="bar", key="baz") != Message(text="foo", code="qux", key="baz")
    assert Message(text="foo", code="bar", key="baz") != Message(text="qux", code="bar", key="baz")
    assert Message(text="foo", code="bar", key="baz") != Message(text="foo", code="bar", key="baz", index=["qux"])

# Generated at 2022-06-18 12:07:05.881368
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index", "index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index"], position=Position(line_no=1, column_no=1, char_index=1))

# Generated at 2022-06-18 12:07:09.919493
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:07:16.895531
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    assert message1 == message2
    message3 = Message(text="text2", code="code2", key="key2", position=Position(2, 2, 2))
    assert message1 != message3


# Generated at 2022-06-18 12:07:21.974808
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3))
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:07:33.254003
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", index=[1, 2]) == Message(text="text", code="code", index=[1, 2])
    assert Message(text="text", code="code", index=[1, 2]) != Message(text="text", code="code", index=[1, 3])
    assert Message(text="text", code="code", index=[1, 2]) != Message(text="text", code="code", index=[1])
    assert Message(text="text", code="code", index=[1, 2]) != Message(text="text", code="code", index=[])
    assert Message(text="text", code="code", index=[1, 2]) != Message(text="text", code="code")

# Generated at 2022-06-18 12:07:34.674031
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:07:42.901785
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key=None)
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=["c"])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=["c", "d"])

# Generated at 2022-06-18 12:07:46.514087
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:07:49.690379
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2
