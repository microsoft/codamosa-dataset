

# Generated at 2022-06-18 12:02:38.704862
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])


# Generated at 2022-06-18 12:02:46.012365
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k", code="c") == BaseError(text="a", key="k", code="c")

# Generated at 2022-06-18 12:02:51.914744
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)
    assert Position(1, 2, 3) != object()


# Generated at 2022-06-18 12:02:55.297798
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='error1')
    error2 = BaseError(text='error2')
    error3 = BaseError(text='error1')
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:02:57.517510
# Unit test for method __str__ of class BaseError
def test_BaseError___str__():
    error = BaseError(text='May not have more than 100 characters')
    assert str(error) == 'May not have more than 100 characters'


# Generated at 2022-06-18 12:03:02.614016
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)


# Generated at 2022-06-18 12:03:12.081498
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1, 2])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1, 2, 3])

# Generated at 2022-06-18 12:03:21.051892
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="test", code="test", key="test", index=["test"], position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1)) == Message(text="test", code="test", key="test", index=["test"], position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))

# Generated at 2022-06-18 12:03:24.443624
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='text1', code='code1', key='key1', position='position1')
    error2 = BaseError(text='text2', code='code2', key='key2', position='position2')
    assert error1 == error2


# Generated at 2022-06-18 12:03:34.536699
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(messages=[Message(text="a", code="b", key="c")]) == BaseError(messages=[Message(text="a", code="b", key="c")])
    assert BaseError(messages=[Message(text="a", code="b", key="c")]) != BaseError(messages=[Message(text="a", code="b", key="d")])
    assert BaseError(messages=[Message(text="a", code="b", key="c")]) != BaseError(messages=[Message(text="a", code="b", key="c"), Message(text="a", code="b", key="c")])

# Generated at 2022-06-18 12:03:47.752510
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:03:59.382790
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d", "e"]) == Message(text="a", code="b", key="c", index=["d", "e"])
    assert Message(text="a", code="b", key="c", index=["d", "e"]) != Message(text="a", code="b", key="c", index=["d", "e", "f"])
    assert Message(text="a", code="b", key="c", index=["d", "e"]) != Message(text="a", code="b", key="c", index=["d", "e", "f"])

# Generated at 2022-06-18 12:04:07.605139
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with two equal objects
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2

    # Test with two unequal objects
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index2"])
    assert not message1 == message2


# Generated at 2022-06-18 12:04:15.914589
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with two equal messages
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username", index=["users", 3, "username"], position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username", index=["users", 3, "username"], position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 == message2
    # Test with two unequal messages

# Generated at 2022-06-18 12:04:26.769802
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], position=Position(line_no=1, column_no=1, char_index=0)) == Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], position=Position(line_no=1, column_no=1, char_index=0))

# Generated at 2022-06-18 12:04:33.839511
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 3))
    assert message1 == message2
    message3 = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 4))
    assert message1 != message3
    message4 = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 3))
    assert message1 == message4
    message5 = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 3))

# Generated at 2022-06-18 12:04:37.102455
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:04:40.074397
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:04:44.595389
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    assert message1 == message2


# Generated at 2022-06-18 12:04:53.777835
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    message3 = Message(text="text2", code="code2", key="key2", index=["index2"], position=Position(2, 3, 4), start_position=Position(2, 3, 4), end_position=Position(2, 3, 4))
    assert message1 == message2

# Generated at 2022-06-18 12:05:11.594155
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", index=[1])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", start_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:05:15.256041
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:05:25.250579
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", index=[1, 2, 3])
    assert message == Message(text="text", code="code", index=[1, 2, 3])
    assert message != Message(text="text", code="code", index=[1, 2, 3, 4])
    assert message != Message(text="text", code="code", index=[1, 2])
    assert message != Message(text="text", code="code", index=[1, 2, 3], key=4)
    assert message != Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    assert message != Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:05:33.190128
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with two Message objects with the same values
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2
    # Test with two Message objects with different values
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 != message2


# Generated at 2022-06-18 12:05:36.867784
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:05:40.256705
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:05:46.907463
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    message2 = Message(text="text", code="code", index=[1, 2, 3], start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))
    assert message1 == message2


# Generated at 2022-06-18 12:05:53.775062
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    assert message1 == message2


# Generated at 2022-06-18 12:06:04.579545
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", index=["index"]) == Message(text="text", code="code", index=["index"])
    assert Message(text="text", code="code", index=["index"]) != Message(text="text", code="code", index=["index2"])
    assert Message(text="text", code="code", index=["index"]) != Message(text="text", code="code2", index=["index"])
    assert Message(text="text", code="code", index=["index"]) != Message(text="text2", code="code", index=["index"])
    assert Message(text="text", code="code", index=["index"]) != Message(text="text", code="code", index=["index"], position=Position(1, 2, 3))

# Generated at 2022-06-18 12:06:07.331577
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2
