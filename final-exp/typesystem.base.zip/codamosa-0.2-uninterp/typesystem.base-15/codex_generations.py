

# Generated at 2022-06-18 12:02:40.291863
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]

    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:42.772246
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:48.138978
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)
    assert Position(1, 2, 3) != object()


# Generated at 2022-06-18 12:02:55.749464
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with equal objects
    message_1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message_2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message_1 == message_2

    # Test with unequal objects
    message_1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message_2 = Message(text="text", code="code", key="key", position=Position(1, 2, 4))
    assert message_1 != message_2


# Generated at 2022-06-18 12:03:01.813775
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)
    assert Position(1, 2, 3) != None


# Generated at 2022-06-18 12:03:10.823548
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that two BaseError objects are equal if they have the same messages
    error1 = BaseError(messages=[Message(text='message1'), Message(text='message2')])
    error2 = BaseError(messages=[Message(text='message1'), Message(text='message2')])
    assert error1 == error2

    # Test that two BaseError objects are not equal if they have different messages
    error1 = BaseError(messages=[Message(text='message1'), Message(text='message2')])
    error2 = BaseError(messages=[Message(text='message1'), Message(text='message3')])
    assert error1 != error2

    # Test that two BaseError objects are not equal if they have different numbers of messages
    error1 = BaseError(messages=[Message(text='message1'), Message(text='message2')])


# Generated at 2022-06-18 12:03:14.562049
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]

    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:18.059318
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    assert message1 == message2


# Generated at 2022-06-18 12:03:27.045154
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1, 2])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", index=[1, 2, 3])

# Generated at 2022-06-18 12:03:31.313675
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    value, error = ValidationResult(value=1).__iter__()
    assert value == 1
    assert error is None

    value, error = ValidationResult(error=ValidationError()).__iter__()
    assert value is None
    assert isinstance(error, ValidationError)


# Generated at 2022-06-18 12:03:43.804603
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 1, 1), start_position=Position(1, 1, 1), end_position=Position(1, 1, 1))
    assert message1 == message2


# Generated at 2022-06-18 12:03:54.109884
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text2", code="code2", key="key2", position=Position(2, 2, 2))
    message3 = Message(text="text3", code="code3", key="key3", position=Position(3, 3, 3))
    message4 = Message(text="text4", code="code4", key="key4", position=Position(4, 4, 4))
    message5 = Message(text="text5", code="code5", key="key5", position=Position(5, 5, 5))
    message6 = Message(text="text6", code="code6", key="key6", position=Position(6, 6, 6))

# Generated at 2022-06-18 12:04:06
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text='error1', code='code1', key='key1')
    error2 = BaseError(text='error1', code='code1', key='key1')
    assert error1 == error2

    # Test 2
    error1 = BaseError(text='error1', code='code1', key='key1')
    error2 = BaseError(text='error2', code='code1', key='key1')
    assert error1 != error2

    # Test 3
    error1 = BaseError(text='error1', code='code1', key='key1')
    error2 = BaseError(text='error1', code='code2', key='key1')
    assert error1 != error2

    # Test 4

# Generated at 2022-06-18 12:04:09.613161
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:04:16.918224
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a") != BaseError(text="a", code="a")
    assert BaseError(text="a", code="a") != BaseError(text="a", code="b")
    assert BaseError(text="a", code="a") != BaseError(text="a", key="a")
    assert BaseError(text="a", key="a") != BaseError(text="a", key="b")
    assert BaseError(text="a", key="a") != BaseError(text="a", key="a", code="a")
    assert BaseError(text="a", key="a", code="a") != BaseError(text="a", key="a", code="b")

# Generated at 2022-06-18 12:04:27.557546
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="text", code="code", key="key", position=Position(1, 2, 3)) == BaseError(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert BaseError(text="text", code="code", key="key", position=Position(1, 2, 3)) != BaseError(text="text", code="code", key="key", position=Position(1, 2, 4))
    assert BaseError(text="text", code="code", key="key", position=Position(1, 2, 3)) != BaseError(text="text", code="code", key="key", position=Position(1, 2, 4))

# Generated at 2022-06-18 12:04:29.818511
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:04:38.625512
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", index=["index"])
    assert message == Message(text="text", code="code", index=["index"])
    assert message != Message(text="text", code="code", index=["index", "index"])
    assert message != Message(text="text", code="code", index=["index", 0])
    assert message != Message(text="text", code="code", index=[0, "index"])
    assert message != Message(text="text", code="code", index=[0])
    assert message != Message(text="text", code="code", index=[])
    assert message != Message(text="text", code="code")
    assert message != Message(text="text", index=["index"])
    assert message != Message(text="text")

# Generated at 2022-06-18 12:04:46.118578
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=[1, 2, 3], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    message2 = Message(text="text1", code="code1", key="key1", index=[1, 2, 3], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:04:55.223336
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(messages=[Message(text="text1", code="code1", index=[1, 2, 3])])
    error2 = BaseError(messages=[Message(text="text1", code="code1", index=[1, 2, 3])])
    assert error1 == error2
    error3 = BaseError(messages=[Message(text="text1", code="code1", index=[1, 2, 3])])
    error4 = BaseError(messages=[Message(text="text1", code="code1", index=[1, 2, 3])])
    assert error3 == error4
    error5 = BaseError(messages=[Message(text="text1", code="code1", index=[1, 2, 3])])

# Generated at 2022-06-18 12:05:11.684502
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="text", code="code", key="key", position=Position(1, 2, 3)) == BaseError(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert BaseError(text="text", code="code", key="key", position=Position(1, 2, 3)) != BaseError(text="text", code="code", key="key", position=Position(1, 2, 4))
    assert BaseError(text="text", code="code", key="key", position=Position(1, 2, 3)) != BaseError(text="text", code="code", key="key", position=Position(1, 2, 3), messages=[Message(text="text", code="code", key="key", position=Position(1, 2, 3))])

# Generated at 2022-06-18 12:05:21.856052
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    assert error1 == error2

    # Test 2
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    assert error1 != error2

    # Test 3
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1", code="code1")
    assert error1 != error2

    # Test 4
    error1 = BaseError(text="error1", code="code1")
    error2 = BaseError(text="error1", code="code2")
    assert error1 != error2

    # Test 5
    error1 = BaseError(text="error1", code="code1")
    error2 = Base

# Generated at 2022-06-18 12:05:31.963576
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that two BaseErrors with the same messages are equal
    message1 = Message(text="message1", code="code1", key="key1")
    message2 = Message(text="message2", code="code2", key="key2")
    message3 = Message(text="message3", code="code3", key="key3")
    message4 = Message(text="message4", code="code4", key="key4")
    message5 = Message(text="message5", code="code5", key="key5")
    message6 = Message(text="message6", code="code6", key="key6")
    message7 = Message(text="message7", code="code7", key="key7")
    message8 = Message(text="message8", code="code8", key="key8")

# Generated at 2022-06-18 12:05:38.251609
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)
    assert Position(1, 2, 3) != 1


# Generated at 2022-06-18 12:05:50.156310
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="foo") == Message(text="foo")
    assert Message(text="foo") != Message(text="bar")
    assert Message(text="foo", code="foo") == Message(text="foo", code="foo")
    assert Message(text="foo", code="foo") != Message(text="foo", code="bar")
    assert Message(text="foo", key="foo") == Message(text="foo", key="foo")
    assert Message(text="foo", key="foo") != Message(text="foo", key="bar")
    assert Message(text="foo", index=["foo"]) == Message(text="foo", index=["foo"])
    assert Message(text="foo", index=["foo"]) != Message(text="foo", index=["bar"])

# Generated at 2022-06-18 12:05:54.837706
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)


# Generated at 2022-06-18 12:06:05.404355
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    message1 = Message(text='text1', code='code1', key='key1')
    message2 = Message(text='text2', code='code2', key='key2')
    message3 = Message(text='text3', code='code3', key='key3')
    message4 = Message(text='text4', code='code4', key='key4')
    message5 = Message(text='text5', code='code5', key='key5')
    message6 = Message(text='text6', code='code6', key='key6')
    message7 = Message(text='text7', code='code7', key='key7')
    message8 = Message(text='text8', code='code8', key='key8')
    message9 = Message(text='text9', code='code9', key='key9')
   

# Generated at 2022-06-18 12:06:10.970380
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that BaseError.__eq__() returns True when the two BaseError objects have the same messages
    error1 = BaseError(messages=[Message(text="error1", code="error1", key="error1")])
    error2 = BaseError(messages=[Message(text="error1", code="error1", key="error1")])
    assert error1 == error2
    # Test that BaseError.__eq__() returns False when the two BaseError objects have different messages
    error1 = BaseError(messages=[Message(text="error1", code="error1", key="error1")])
    error2 = BaseError(messages=[Message(text="error2", code="error2", key="error2")])
    assert not error1 == error2


# Generated at 2022-06-18 12:06:17.782951
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:06:20.922628
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:06:38.329981
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that two ValidationErrors with the same messages are equal.
    messages = [
        Message(text="May not have more than 100 characters", code="max_length"),
        Message(text="May not be empty", code="required"),
    ]
    error1 = ValidationError(messages=messages)
    error2 = ValidationError(messages=messages)
    assert error1 == error2
    assert error1 is not error2


# Generated at 2022-06-18 12:06:46.851426
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="hello", code="custom", key="username", position=Position(1, 2, 3)) == Message(text="hello", code="custom", key="username", position=Position(1, 2, 3))
    assert Message(text="hello", code="custom", key="username", position=Position(1, 2, 3)) != Message(text="hello", code="custom", key="username", position=Position(1, 2, 4))
    assert Message(text="hello", code="custom", key="username", position=Position(1, 2, 3)) != Message(text="hello", code="custom", key="username", position=Position(1, 3, 3))

# Generated at 2022-06-18 12:06:55.984208
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="test") == BaseError(text="test")
    assert BaseError(text="test") != BaseError(text="test2")
    assert BaseError(text="test", code="test") == BaseError(text="test", code="test")
    assert BaseError(text="test", code="test") != BaseError(text="test", code="test2")
    assert BaseError(text="test", key="test") == BaseError(text="test", key="test")
    assert BaseError(text="test", key="test") != BaseError(text="test", key="test2")
    assert BaseError(text="test", position=Position(1, 1, 1)) == BaseError(text="test", position=Position(1, 1, 1))

# Generated at 2022-06-18 12:07:01.586981
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message3 = Message(text="text2", code="code2", key="key2", index=["index2"])
    assert message1 == message2
    assert message1 != message3


# Generated at 2022-06-18 12:07:08.339871
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 1, 1))
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 1, 1))
    message3 = Message(text="text2", code="code2", key="key2", index=["index2"], position=Position(2, 2, 2))
    assert message1 == message2
    assert message1 != message3


# Generated at 2022-06-18 12:07:19.040624
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d"]) == Message(text="a", code="b", key="c", index=["d"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["e"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["d", "e"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["d", "e", "f"])

# Generated at 2022-06-18 12:07:29.980787
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test with two equal objects
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2
    # Test with two unequal objects
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index2"])
    assert not message1 == message2
    # Test with two unequal objects
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key2", index=["index"])

# Generated at 2022-06-18 12:07:39.980326
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="foo") == Message(text="foo")
    assert Message(text="foo", code="bar") == Message(text="foo", code="bar")
    assert Message(text="foo", key="bar") == Message(text="foo", key="bar")
    assert Message(text="foo", index=["bar"]) == Message(text="foo", index=["bar"])
    assert Message(text="foo", position=Position(1, 2, 3)) == Message(text="foo", position=Position(1, 2, 3))
    assert Message(text="foo", start_position=Position(1, 2, 3), end_position=Position(4, 5, 6)) == Message(text="foo", start_position=Position(1, 2, 3), end_position=Position(4, 5, 6))

# Generated at 2022-06-18 12:07:50.628884
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that BaseError.__eq__() returns True for equal objects
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a", code="b") == BaseError(text="a", code="b")
    assert BaseError(text="a", key="b") == BaseError(text="a", key="b")
    assert BaseError(text="a", position=Position(1, 2, 3)) == BaseError(
        text="a", position=Position(1, 2, 3)
    )
    assert BaseError(messages=[Message(text="a")]) == BaseError(
        messages=[Message(text="a")]
    )

# Generated at 2022-06-18 12:07:55.535576
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)


# Generated at 2022-06-18 12:08:30.870792
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text="Error 1", code="code1", key="key1")
    error2 = BaseError(text="Error 1", code="code1", key="key1")
    assert error1 == error2
    # Test 2
    error1 = BaseError(text="Error 1", code="code1", key="key1")
    error2 = BaseError(text="Error 2", code="code1", key="key1")
    assert error1 != error2
    # Test 3
    error1 = BaseError(text="Error 1", code="code1", key="key1")
    error2 = BaseError(text="Error 1", code="code2", key="key1")
    assert error1 != error2
    # Test 4

# Generated at 2022-06-18 12:08:40.050262
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="text") == BaseError(text="text")
    assert BaseError(text="text") != BaseError(text="text2")
    assert BaseError(text="text", code="code") == BaseError(text="text", code="code")
    assert BaseError(text="text", code="code") != BaseError(text="text", code="code2")
    assert BaseError(text="text", key="key") == BaseError(text="text", key="key")
    assert BaseError(text="text", key="key") != BaseError(text="text", key="key2")
    assert BaseError(text="text", key="key") != BaseError(text="text", key=1)
    assert BaseError(text="text", key=1) == BaseError(text="text", key=1)
    assert BaseError

# Generated at 2022-06-18 12:08:43.521770
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "foo"


# Generated at 2022-06-18 12:08:46.429968
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:08:50.102279
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text="text", code="code", key="key", index=["index"])
    message_2 = Message(text="text", code="code", key="key", index=["index"])
    assert message_1 == message_2


# Generated at 2022-06-18 12:08:55.440890
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != None


# Generated at 2022-06-18 12:09:00.089247
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != "foo"


# Generated at 2022-06-18 12:09:04.074938
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="text", code="code", key="key", position=Position(1,2,3))
    error2 = BaseError(text="text", code="code", key="key", position=Position(1,2,3))
    assert error1 == error2


# Generated at 2022-06-18 12:09:11.658940
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with a single message
    error1 = BaseError(text='Error message', code='error_code', key='key')
    error2 = BaseError(text='Error message', code='error_code', key='key')
    assert error1 == error2
    error3 = BaseError(text='Error message', code='error_code', key='key2')
    assert error1 != error3
    error4 = BaseError(text='Error message', code='error_code2', key='key')
    assert error1 != error4
    error5 = BaseError(text='Error message2', code='error_code', key='key')
    assert error1 != error5
    # Test with multiple messages
    error6 = BaseError(messages=[Message(text='Error message', code='error_code', key='key')])

# Generated at 2022-06-18 12:09:21.952640
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", index=["d"])
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", start_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:10:42.728127
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    error = BaseError(text='test', code='test', key='test', position='test', messages='test')
    other = BaseError(text='test', code='test', key='test', position='test', messages='test')
    # Assert
    assert error == other


# Generated at 2022-06-18 12:10:51.949149
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='a') == BaseError(text='a')
    assert BaseError(text='a') != BaseError(text='b')
    assert BaseError(text='a', code='c') == BaseError(text='a', code='c')
    assert BaseError(text='a', code='c') != BaseError(text='a', code='d')
    assert BaseError(text='a', key='k') == BaseError(text='a', key='k')
    assert BaseError(text='a', key='k') != BaseError(text='a', key='l')
    assert BaseError(text='a', key='k', position=Position(1, 2, 3)) == BaseError(text='a', key='k', position=Position(1, 2, 3))

# Generated at 2022-06-18 12:10:57.182973
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != 1


# Generated at 2022-06-18 12:11:02.569596
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    # Exercise
    result1 = error1 == error2
    result2 = error1 == error3
    # Verify
    assert result1 == False
    assert result2 == True


# Generated at 2022-06-18 12:11:07.987936
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text2", code="code2", key="key2", index=["index2"])
    message3 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message3
    assert message1 != message2


# Generated at 2022-06-18 12:11:14.710648
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=2, char_index=4)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=2, column_no=2, char_index=3)


# Generated at 2022-06-18 12:11:24.164364
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    assert message1 == message2


# Generated at 2022-06-18 12:11:32.336353
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=2, char_index=4)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=2, column_no=2, char_index=3)

# Generated at 2022-06-18 12:11:38.183602
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=1, char_index=0)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    # Test
    assert error1 == error2
    # Teardown - none necessary


# Generated at 2022-06-18 12:11:46.381916
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=2, char_index=4)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=2, column_no=2, char_index=3)