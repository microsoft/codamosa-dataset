

# Generated at 2022-06-18 12:02:38.313472
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    msg1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    msg2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert msg1 == msg2


# Generated at 2022-06-18 12:02:46.463794
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(line_no=1, column_no=1, char_index=0),
    )
    error2 = BaseError(
        text="May not have more than 100 characters",
        code="max_length",
        key="username",
        position=Position(line_no=1, column_no=1, char_index=0),
    )
    assert error1 == error2

    # Test 2

# Generated at 2022-06-18 12:02:49.118110
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]


# Generated at 2022-06-18 12:02:58.708560
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test with two equal instances of Position
    position1 = Position(line_no=1, column_no=2, char_index=3)
    position2 = Position(line_no=1, column_no=2, char_index=3)
    assert position1 == position2
    # Test with two unequal instances of Position
    position1 = Position(line_no=1, column_no=2, char_index=3)
    position2 = Position(line_no=4, column_no=5, char_index=6)
    assert not (position1 == position2)
    # Test with an instance of Position and an instance of a different class
    position1 = Position(line_no=1, column_no=2, char_index=3)

# Generated at 2022-06-18 12:03:02.117773
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:05.361069
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:09.648736
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that BaseError.__eq__() works correctly
    error1 = BaseError(text="Error 1")
    error2 = BaseError(text="Error 2")
    error3 = BaseError(text="Error 1")
    assert error1 == error3
    assert error1 != error2
    assert error2 != error3


# Generated at 2022-06-18 12:03:12.680526
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]


# Generated at 2022-06-18 12:03:21.703301
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)
    assert Position(1, 2, 3) != Position(1, 2)
    assert Position(1, 2, 3) != Position(1)
    assert Position(1, 2, 3) != Position()
    assert Position(1, 2, 3) != 1
    assert Position(1, 2, 3) != "1"
    assert Position(1, 2, 3) != object()


# Generated at 2022-06-18 12:03:24.360983
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]


# Generated at 2022-06-18 12:03:40.151192
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two ValidationError instances with the same messages
    error1 = ValidationError(messages=[Message(text="error1", code="code1")])
    error2 = ValidationError(messages=[Message(text="error1", code="code1")])
    assert error1 == error2
    # Test with two ValidationError instances with different messages
    error1 = ValidationError(messages=[Message(text="error1", code="code1")])
    error2 = ValidationError(messages=[Message(text="error2", code="code2")])
    assert error1 != error2
    # Test with two ValidationError instances with the same messages but different order
    error1 = ValidationError(messages=[Message(text="error1", code="code1")])

# Generated at 2022-06-18 12:03:49.649302
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="a") == BaseError(text="a", code="a")
    assert BaseError(text="a", code="a") != BaseError(text="a", code="b")
    assert BaseError(text="a", key="a") == BaseError(text="a", key="a")
    assert BaseError(text="a", key="a") != BaseError(text="a", key="b")
    assert BaseError(text="a", key="a") != BaseError(text="a", index=["a"])
    assert BaseError(text="a", index=["a"]) == BaseError(text="a", index=["a"])
   

# Generated at 2022-06-18 12:04:01.381100
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="abc") == BaseError(text="abc")
    assert BaseError(text="abc") != BaseError(text="def")
    assert BaseError(text="abc") != BaseError(text="abc", code="def")
    assert BaseError(text="abc") != BaseError(text="abc", key="def")
    assert BaseError(text="abc") != BaseError(text="abc", position=Position(1, 2, 3))
    assert BaseError(text="abc") != BaseError(text="abc", messages=[Message(text="def")])
    assert BaseError(text="abc") != BaseError(messages=[Message(text="abc")])
    assert BaseError(text="abc") != BaseError(messages=[Message(text="abc"), Message(text="def")])

# Generated at 2022-06-18 12:04:05.372263
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:04:14.759882
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    # Test with two equal objects
    position1 = Position(1, 2, 3)
    position2 = Position(1, 2, 3)
    assert position1 == position2
    # Test with two unequal objects
    position1 = Position(1, 2, 3)
    position2 = Position(1, 2, 4)
    assert position1 != position2
    # Test with two unequal objects
    position1 = Position(1, 2, 3)
    position2 = Position(1, 3, 3)
    assert position1 != position2
    # Test with two unequal objects
    position1 = Position(1, 2, 3)
    position2 = Position(2, 2, 3)
    assert position1 != position2
    # Test with two unequal objects
    position1 = Position(1, 2, 3)

# Generated at 2022-06-18 12:04:25.539842
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k") != BaseError(text="a", index=["k"])
    assert BaseError(text="a", index=["k"]) == BaseError(text="a", index=["k"])
   

# Generated at 2022-06-18 12:04:33.573644
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k") != BaseError(text="a")
    assert BaseError(text="a", key="k") != BaseError(text="a", code="c")

# Generated at 2022-06-18 12:04:36.850498
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:04:41.783557
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="text1", code="code1", key="key1", position="position1")
    error2 = BaseError(text="text2", code="code2", key="key2", position="position2")
    assert error1 == error1
    assert error2 == error2
    assert error1 != error2
    assert error2 != error1


# Generated at 2022-06-18 12:04:46.927620
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != None


# Generated at 2022-06-18 12:05:16.363285
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with a single message
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    assert error1 == error2
    error3 = BaseError(text="error3")
    assert error1 != error3
    # Test with multiple messages
    error4 = BaseError(messages=[Message(text="error1"), Message(text="error2")])
    error5 = BaseError(messages=[Message(text="error1"), Message(text="error2")])
    assert error4 == error5
    error6 = BaseError(messages=[Message(text="error1"), Message(text="error3")])
    assert error4 != error6


# Generated at 2022-06-18 12:05:26.469209
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="a") == BaseError(text="a", code="a")
    assert BaseError(text="a", code="a") != BaseError(text="a", code="b")
    assert BaseError(text="a", key="a") == BaseError(text="a", key="a")
    assert BaseError(text="a", key="a") != BaseError(text="a", key="b")
    assert BaseError(text="a", key="a") != BaseError(text="a", index=["a"])
    assert BaseError(text="a", index=["a"]) == BaseError(text="a", index=["a"])
   

# Generated at 2022-06-18 12:05:30.595696
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='error1', code='code1')
    error2 = BaseError(text='error2', code='code2')
    error3 = BaseError(text='error1', code='code1')
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:05:40.502657
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    assert error1 == error2
    # Test 2
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    assert not (error1 == error2)
    # Test 3
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1", code="code1")
    assert not (error1 == error2)
    # Test 4
    error1 = BaseError(text="error1", code="code1")
    error2 = BaseError(text="error1", code="code1")
    assert error1 == error2
    # Test 5
    error1 = BaseError(text="error1", code="code1")

# Generated at 2022-06-18 12:05:52.514713
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="test") == BaseError(text="test")
    assert BaseError(text="test") != BaseError(text="test2")
    assert BaseError(text="test") != BaseError(text="test", code="test")
    assert BaseError(text="test") != BaseError(text="test", key="test")
    assert BaseError(text="test") != BaseError(text="test", position=Position(1, 1, 1))
    assert BaseError(text="test") != BaseError(messages=[Message(text="test")])
    assert BaseError(messages=[Message(text="test")]) == BaseError(messages=[Message(text="test")])
    assert BaseError(messages=[Message(text="test")]) != BaseError(messages=[Message(text="test2")])

# Generated at 2022-06-18 12:05:59.944145
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that two BaseError objects are equal if they have the same messages
    assert BaseError(messages=[Message(text="test")]) == BaseError(messages=[Message(text="test")])
    assert BaseError(messages=[Message(text="test")]) != BaseError(messages=[Message(text="test2")])
    assert BaseError(messages=[Message(text="test")]) != BaseError(messages=[Message(text="test"), Message(text="test2")])


# Generated at 2022-06-18 12:06:08.339594
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message2 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 1))
    message3 = Message(text="text1", code="code1", key="key1", position=Position(1, 1, 2))
    message4 = Message(text="text1", code="code1", key="key1", position=Position(1, 2, 1))
    message5 = Message(text="text1", code="code1", key="key1", position=Position(2, 1, 1))
    message6 = Message(text="text1", code="code2", key="key1", position=Position(1, 1, 1))

# Generated at 2022-06-18 12:06:17.565426
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a") != BaseError(text="a", code="a")
    assert BaseError(text="a", code="a") != BaseError(text="a", code="b")
    assert BaseError(text="a", key="a") != BaseError(text="a", key="b")
    assert BaseError(text="a", key="a") != BaseError(text="a", index=["a"])
    assert BaseError(text="a", index=["a"]) != BaseError(text="a", index=["b"])

# Generated at 2022-06-18 12:06:21.047204
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:06:30.267678
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="test") == BaseError(text="test")
    assert BaseError(text="test") != BaseError(text="test2")
    assert BaseError(text="test", code="test") == BaseError(text="test", code="test")
    assert BaseError(text="test", code="test") != BaseError(text="test", code="test2")
    assert BaseError(text="test", key="test") == BaseError(text="test", key="test")
    assert BaseError(text="test", key="test") != BaseError(text="test", key="test2")
    assert BaseError(text="test", position=Position(1, 1, 1)) == BaseError(text="test", position=Position(1, 1, 1))

# Generated at 2022-06-18 12:06:56.203029
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position="position")
    message2 = Message(text="text", code="code", key="key", position="position")
    assert message1 == message2


# Generated at 2022-06-18 12:07:05.575011
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k") != BaseError(text="a")
    assert BaseError(text="a", key="k") != BaseError(text="a", code="c")

# Generated at 2022-06-18 12:07:09.620509
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="error1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="error1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:07:20.407297
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    message3 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 4))
    message4 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    message4.index = [1, 2, 4]
    message5 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    message5.text = "text2"

# Generated at 2022-06-18 12:07:31.590587
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='a') == BaseError(text='a')
    assert BaseError(text='a') != BaseError(text='b')
    assert BaseError(text='a') != BaseError(text='a', code='b')
    assert BaseError(text='a') != BaseError(text='a', key='b')
    assert BaseError(text='a') != BaseError(text='a', position=Position(1, 2, 3))
    assert BaseError(text='a') != BaseError(text='a', messages=[Message(text='b')])
    assert BaseError(text='a') != BaseError(messages=[Message(text='a')])
    assert BaseError(messages=[Message(text='a')]) == BaseError(messages=[Message(text='a')])

# Generated at 2022-06-18 12:07:41.016243
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="text", code="code", key="key", position=Position(1, 2, 3)) == BaseError(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert BaseError(text="text", code="code", key="key", position=Position(1, 2, 3)) != BaseError(text="text", code="code", key="key", position=Position(1, 2, 4))
    assert BaseError(text="text", code="code", key="key", position=Position(1, 2, 3)) != BaseError(text="text", code="code", key="key", position=Position(1, 2, 4))

# Generated at 2022-06-18 12:07:43.598441
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:07:52.272508
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a") != BaseError(text="a", code="a")
    assert BaseError(text="a", code="a") == BaseError(text="a", code="a")
    assert BaseError(text="a", code="a") != BaseError(text="a", code="b")
    assert BaseError(text="a", key="a") == BaseError(text="a", key="a")
    assert BaseError(text="a", key="a") != BaseError(text="a", key="b")
    assert BaseError(text="a", key="a") != BaseError(text="a", index=["a"])

# Generated at 2022-06-18 12:08:02.206030
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text='May not have more than 100 characters', code='max_length', key='username') == BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    assert BaseError(text='May not have more than 100 characters', code='max_length', key='username') != BaseError(text='May not have more than 100 characters', code='max_length', key='username1')
    assert BaseError(text='May not have more than 100 characters', code='max_length', key='username') != BaseError(text='May not have more than 100 characters', code='max_length1', key='username')

# Generated at 2022-06-18 12:08:03.933724
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", index=[1, 2, 3], position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:08:59.287335
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index1"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key1", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code1", key="key", index=["index"])

# Generated at 2022-06-18 12:09:07.614156
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two empty BaseError objects
    error1 = BaseError()
    error2 = BaseError()
    assert error1 == error2
    # Test with two BaseError objects with the same message
    error1 = BaseError(text="Error message")
    error2 = BaseError(text="Error message")
    assert error1 == error2
    # Test with two BaseError objects with different messages
    error1 = BaseError(text="Error message 1")
    error2 = BaseError(text="Error message 2")
    assert error1 != error2
    # Test with two BaseError objects with the same message and code
    error1 = BaseError(text="Error message", code="Error code")
    error2 = BaseError(text="Error message", code="Error code")
    assert error1 == error2
    # Test with two BaseError objects with different messages

# Generated at 2022-06-18 12:09:10.694611
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:09:13.690292
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error = BaseError(text="text", code="code", key="key")
    error2 = BaseError(text="text", code="code", key="key")
    assert error == error2


# Generated at 2022-06-18 12:09:23.539664
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with a single message
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error1")
    assert error1 == error2
    assert error1 != "error1"
    assert error1 != BaseError(text="error2")
    assert error1 != BaseError(text="error1", code="code1")
    assert error1 != BaseError(text="error1", key="key1")
    assert error1 != BaseError(text="error1", position=Position(1, 1, 1))
    assert error1 != BaseError(text="error1", messages=[Message(text="error1")])
    assert error1 != BaseError(text="error1", messages=[Message(text="error2")])

    # Test with multiple messages

# Generated at 2022-06-18 12:09:31.789336
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with a single error message
    error1 = BaseError(text="error1", code="code1", key="key1")
    error2 = BaseError(text="error1", code="code1", key="key1")
    assert error1 == error2
    error3 = BaseError(text="error1", code="code1", key="key2")
    assert error1 != error3
    error4 = BaseError(text="error1", code="code2", key="key1")
    assert error1 != error4
    error5 = BaseError(text="error2", code="code1", key="key1")
    assert error1 != error5
    # Test with multiple error messages
    error6 = BaseError(messages=[Message(text="error1", code="code1", key="key1")])
    assert error1 == error

# Generated at 2022-06-18 12:09:39.488690
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test for method __eq__ of class Message
    # Setup
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message3 = Message(text="text1", code="code1", key="key1", index=["index2"])
    message4 = Message(text="text1", code="code1", key="key2", index=["index1"])
    message5 = Message(text="text1", code="code2", key="key1", index=["index1"])
    message6 = Message(text="text2", code="code1", key="key1", index=["index1"])

# Generated at 2022-06-18 12:09:47.293059
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k", code="c") == BaseError(text="a", key="k", code="c")

# Generated at 2022-06-18 12:09:54.026612
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=2, char_index=3)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)

    # Exercise
    result = error1 == error2

    # Verify
    assert result == True


# Generated at 2022-06-18 12:10:01.750735
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k", code="c") == BaseError(text="a", key="k", code="c")

# Generated at 2022-06-18 12:12:09.084999
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message = Message(text="text", code="code", key="key", index=["index"])
    assert message == Message(text="text", code="code", key="key", index=["index"])
    assert message != Message(text="text", code="code", key="key", index=["index1"])
    assert message != Message(text="text", code="code", key="key1", index=["index"])
    assert message != Message(text="text", code="code1", key="key", index=["index"])
    assert message != Message(text="text1", code="code", key="key", index=["index"])
    assert message != Message(text="text", code="code", key="key", index=["index"], position=Position(1, 2, 3))

# Generated at 2022-06-18 12:12:12.760031
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    message2 = Message(text="May not have more than 100 characters", code="max_length", key="username")
    assert message1 == message2


# Generated at 2022-06-18 12:12:20.722911
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3)) == Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3))
    assert Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=3)) != Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=2, char_index=4))