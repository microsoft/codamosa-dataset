

# Generated at 2022-06-18 12:02:50.347938
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)
    assert Position(1, 2, 3) != 1


# Generated at 2022-06-18 12:02:53.832598
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError())
    assert list(vr) == [None, ValidationError()]


# Generated at 2022-06-18 12:02:59.123044
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=1, char_index=0))
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username', position=Position(line_no=1, column_no=1, char_index=0))
    assert message1 == message2


# Generated at 2022-06-18 12:03:02.531401
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:05.449417
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError(text="error"))) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:09.064006
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:12.763219
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]

    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:16.042316
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]
    result = ValidationResult(error=ValidationError(text="Error"))
    assert list(result) == [None, ValidationError(text="Error")]


# Generated at 2022-06-18 12:03:19.629677
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    result = ValidationResult(value=1)
    assert list(result) == [1, None]

    result = ValidationResult(error=ValidationError(text="error"))
    assert list(result) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:03:24.726343
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)


# Generated at 2022-06-18 12:03:32.185038
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != None


# Generated at 2022-06-18 12:03:41.630783
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=2, char_index=4)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=2, column_no=2, char_index=3)

# Generated at 2022-06-18 12:03:46.739440
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != None


# Generated at 2022-06-18 12:03:53.481415
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)
    assert Position(1, 2, 3) != 1


# Generated at 2022-06-18 12:04:05.468584
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3))
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3))
    assert message1 == message2
    message3 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 3))
    message4 = Message(text="text1", code="code1", key="key1", index=["index1"], position=Position(1, 2, 4))
    assert message3 != message4

# Generated at 2022-06-18 12:04:11.056915
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != None


# Generated at 2022-06-18 12:04:17.599898
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(line_no=1, column_no=2, char_index=3) == Position(line_no=1, column_no=2, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=2, char_index=4)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=1, column_no=3, char_index=3)
    assert Position(line_no=1, column_no=2, char_index=3) != Position(line_no=2, column_no=2, char_index=3)

# Generated at 2022-06-18 12:04:23.056605
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 1, 1) == Position(1, 1, 1)
    assert Position(1, 1, 1) != Position(1, 1, 2)
    assert Position(1, 1, 1) != Position(1, 2, 1)
    assert Position(1, 1, 1) != Position(2, 1, 1)
    assert Position(1, 1, 1) != 1


# Generated at 2022-06-18 12:04:27.381039
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    message2 = Message(text='May not have more than 100 characters', code='max_length', key='username')
    assert message1 == message2


# Generated at 2022-06-18 12:04:31.952563
# Unit test for method __eq__ of class Position
def test_Position___eq__():
    assert Position(1, 2, 3) == Position(1, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 4)
    assert Position(1, 2, 3) != Position(1, 3, 3)
    assert Position(1, 2, 3) != Position(2, 2, 3)
    assert Position(1, 2, 3) != Position(1, 2, 3, 4)
    assert Position(1, 2, 3) != "foo"


# Generated at 2022-06-18 12:04:46.292289
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) == Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) != Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 4))

# Generated at 2022-06-18 12:04:55.417429
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c") == Message(text="a", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="d")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="c", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="b", code="b", key="c")
    assert Message(text="a", code="b", key="c") != Message(text="a", code="b", key="c", index=["d"])

# Generated at 2022-06-18 12:05:05.351378
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text='text', code='code', key='key', index=['index'], position=Position(line_no=1, column_no=1, char_index=1), start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    message2 = Message(text='text', code='code', key='key', index=['index'], position=Position(line_no=1, column_no=1, char_index=1), start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    assert message1 == message2



# Generated at 2022-06-18 12:05:15.641296
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", index=["index1"])
    message2 = Message(text="text1", code="code1", index=["index1"])
    assert message1 == message2
    message3 = Message(text="text2", code="code1", index=["index1"])
    assert message1 != message3
    message4 = Message(text="text1", code="code2", index=["index1"])
    assert message1 != message4
    message5 = Message(text="text1", code="code1", index=["index2"])
    assert message1 != message5
    message6 = Message(text="text1", code="code1", index=["index1", "index2"])
    assert message1 != message6

# Generated at 2022-06-18 12:05:25.725783
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", index=["index"]) == Message(text="text", code="code", index=["index"])
    assert Message(text="text", code="code", index=["index"]) != Message(text="text", code="code", index=["index1"])
    assert Message(text="text", code="code", index=["index"]) != Message(text="text", code="code1", index=["index"])
    assert Message(text="text", code="code", index=["index"]) != Message(text="text1", code="code", index=["index"])
    assert Message(text="text", code="code", index=["index"]) != Message(text="text", code="code", index=["index"], position=Position(1, 2, 3))

# Generated at 2022-06-18 12:05:35.552945
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    m1 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=1, char_index=0))
    m2 = Message(text='May not have more than 100 characters', code='max_length', key='username', index=['users', 3, 'username'], start_position=Position(line_no=1, column_no=1, char_index=0), end_position=Position(line_no=1, column_no=1, char_index=0))
    assert m1 == m2


# Generated at 2022-06-18 12:05:39.025296
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:05:43.284013
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:05:46.602707
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", index=["index1"])
    message2 = Message(text="text1", code="code1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:05:58.458005
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) == Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3)) != Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 4))

# Generated at 2022-06-18 12:06:13.979284
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:06:23.342741
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="text", code="code", key="key", index=["index"]) == Message(text="text", code="code", key="key", index=["index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index", "index"])
    assert Message(text="text", code="code", key="key", index=["index"]) != Message(text="text", code="code", key="key", index=["index"], start_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:06:27.123942
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text1", code="code1", key="key1", index=["index1"])
    message2 = Message(text="text1", code="code1", key="key1", index=["index1"])
    assert message1 == message2


# Generated at 2022-06-18 12:06:30.145125
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", index=["index"])
    message2 = Message(text="text", code="code", key="key", index=["index"])
    assert message1 == message2


# Generated at 2022-06-18 12:06:33.959566
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:06:37.066522
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message_1 = Message(text="text", code="code", key="key", index=["index"])
    message_2 = Message(text="text", code="code", key="key", index=["index"])
    assert message_1 == message_2


# Generated at 2022-06-18 12:06:40.497556
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:06:46.487230
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key=1, index=[1, 2], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    message2 = Message(text="text", code="code", key=1, index=[1, 2], position=Position(1, 2, 3), start_position=Position(1, 2, 3), end_position=Position(1, 2, 3))
    assert message1 == message2


# Generated at 2022-06-18 12:06:55.552807
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    # Test 1
    message1 = Message(text='text', code='code', key='key', index=['index'], position=Position(line_no=1, column_no=1, char_index=1), start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    message2 = Message(text='text', code='code', key='key', index=['index'], position=Position(line_no=1, column_no=1, char_index=1), start_position=Position(line_no=1, column_no=1, char_index=1), end_position=Position(line_no=1, column_no=1, char_index=1))
    assert message1

# Generated at 2022-06-18 12:07:04.977690
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d"]) == Message(text="a", code="b", key="c", index=["d"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["e"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["d", "e"])
    assert Message(text="a", code="b", key="c", index=["d"]) != Message(text="a", code="b", key="c", index=["d", "e", "f"])