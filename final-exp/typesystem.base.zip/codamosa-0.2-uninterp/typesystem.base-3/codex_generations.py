

# Generated at 2022-06-18 12:02:32.813235
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert next(iter(vr)) == 1
    assert next(iter(vr)) is None
    vr = ValidationResult(error=ValidationError(text="error"))
    assert next(iter(vr)) is None
    assert next(iter(vr)) == ValidationError(text="error")


# Generated at 2022-06-18 12:02:35.376387
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]


# Generated at 2022-06-18 12:02:39.110142
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]

    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:46.082210
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test 1
    error1 = BaseError(text='error1')
    error2 = BaseError(text='error1')
    assert error1 == error2

    # Test 2
    error1 = BaseError(text='error1')
    error2 = BaseError(text='error2')
    assert error1 != error2

    # Test 3
    error1 = BaseError(text='error1')
    error2 = BaseError(text='error1', code='code1')
    assert error1 != error2

    # Test 4
    error1 = BaseError(text='error1', code='code1')
    error2 = BaseError(text='error1', code='code2')
    assert error1 != error2

    # Test 5
    error1 = BaseError(text='error1', key='key1')
    error2 = Base

# Generated at 2022-06-18 12:02:49.504063
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    vr = ValidationResult(value=1)
    assert list(vr) == [1, None]
    vr = ValidationResult(error=ValidationError(text="error"))
    assert list(vr) == [None, ValidationError(text="error")]


# Generated at 2022-06-18 12:02:52.483691
# Unit test for method __iter__ of class ValidationResult
def test_ValidationResult___iter__():
    assert list(ValidationResult(value=1)) == [1, None]
    assert list(ValidationResult(error=ValidationError())) == [None, ValidationError()]


# Generated at 2022-06-18 12:03:01.814939
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='error1')
    error2 = BaseError(text='error2')
    assert error1 != error2

    error1 = BaseError(text='error1')
    error2 = BaseError(text='error1')
    assert error1 == error2

    error1 = BaseError(text='error1', code='code1')
    error2 = BaseError(text='error1', code='code2')
    assert error1 != error2

    error1 = BaseError(text='error1', code='code1')
    error2 = BaseError(text='error1', code='code1')
    assert error1 == error2

    error1 = BaseError(text='error1', key='key1')
    error2 = BaseError(text='error1', key='key2')
    assert error1 != error2

# Generated at 2022-06-18 12:03:05.064668
# Unit test for constructor of class BaseError
def test_BaseError():
    assert BaseError(text="test", code="test", key="test", position=Position(1, 1, 1))
    assert BaseError(messages=[Message(text="test", code="test", key="test", position=Position(1, 1, 1))])


# Generated at 2022-06-18 12:03:14.560466
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(text="Invalid JSON")
    assert error.messages() == [Message(text="Invalid JSON")]
    assert error.messages(add_prefix="foo") == [Message(text="Invalid JSON", index=["foo"])]
    assert error == ParseError(text="Invalid JSON")
    assert error != ParseError(text="Invalid JSON", code="invalid_json")
    assert error != ParseError(text="Invalid JSON", key="foo")
    assert error != ParseError(text="Invalid JSON", position=Position(1, 2, 3))
    assert error != ParseError(text="Invalid JSON", start_position=Position(1, 2, 3))
    assert error != ParseError(text="Invalid JSON", end_position=Position(1, 2, 3))

# Generated at 2022-06-18 12:03:23.678584
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", position=Position(1, 2, 3)) == Message(text="a", code="b", key="c", position=Position(1, 2, 3))
    assert Message(text="a", code="b", key="c", position=Position(1, 2, 3)) != Message(text="a", code="b", key="c", position=Position(1, 2, 4))
    assert Message(text="a", code="b", key="c", position=Position(1, 2, 3)) != Message(text="a", code="b", key="c", position=Position(1, 3, 3))

# Generated at 2022-06-18 12:03:37.740202
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    assert error1 == error1
    assert error2 == error2
    assert error1 != error2
    assert error2 != error1


# Generated at 2022-06-18 12:03:42.296166
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='error1', code='code1', key='key1')
    error2 = BaseError(text='error1', code='code1', key='key1')
    assert error1 == error2
    error3 = BaseError(text='error3', code='code3', key='key3')
    assert error1 != error3


# Generated at 2022-06-18 12:03:45.934520
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    message1 = Message(text="text", code="code", key="key", position=Position(1, 1, 1))
    message2 = Message(text="text", code="code", key="key", position=Position(1, 1, 1))
    assert message1 == message2


# Generated at 2022-06-18 12:03:56.923379
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="test") == BaseError(text="test")
    assert BaseError(text="test") != BaseError(text="test2")
    assert BaseError(text="test") != BaseError(text="test", code="test")
    assert BaseError(text="test") != BaseError(text="test", key="test")
    assert BaseError(text="test") != BaseError(text="test", position=Position(1, 1, 1))
    assert BaseError(text="test") != BaseError(text="test", messages=[Message(text="test")])
    assert BaseError(text="test") != BaseError(text="test", messages=[Message(text="test2")])
    assert BaseError(text="test") != BaseError(text="test", messages=[Message(text="test", code="test")])
    assert BaseError

# Generated at 2022-06-18 12:04:08.494618
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a") != BaseError(text="b")
    assert BaseError(text="a", code="c") == BaseError(text="a", code="c")
    assert BaseError(text="a", code="c") != BaseError(text="a", code="d")
    assert BaseError(text="a", key="k") == BaseError(text="a", key="k")
    assert BaseError(text="a", key="k") != BaseError(text="a", key="l")
    assert BaseError(text="a", key="k") != BaseError(text="a")
    assert BaseError(text="a", key="k") != BaseError(text="a", code="c")

# Generated at 2022-06-18 12:04:12.460930
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:04:14.992533
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:04:25.926596
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="error message") == BaseError(text="error message")
    assert BaseError(text="error message") != BaseError(text="error message 2")
    assert BaseError(text="error message", code="code") == BaseError(text="error message", code="code")
    assert BaseError(text="error message", code="code") != BaseError(text="error message", code="code2")
    assert BaseError(text="error message", key="key") == BaseError(text="error message", key="key")
    assert BaseError(text="error message", key="key") != BaseError(text="error message", key="key2")
    assert BaseError(text="error message", position=Position(1, 2, 3)) == BaseError(text="error message", position=Position(1, 2, 3))
    assert BaseError

# Generated at 2022-06-18 12:04:33.783740
# Unit test for method __eq__ of class Message
def test_Message___eq__():
    assert Message(text="a", code="b", key="c", index=["d", "e"]) == Message(text="a", code="b", key="c", index=["d", "e"])
    assert Message(text="a", code="b", key="c", index=["d", "e"]) != Message(text="a", code="b", key="c", index=["d", "e", "f"])
    assert Message(text="a", code="b", key="c", index=["d", "e"]) != Message(text="a", code="b", key="c", index=["d", "e"], position=Position(1, 2, 3))

# Generated at 2022-06-18 12:04:43.634852
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test with two ValidationErrors with the same messages
    messages = [Message(text="message1"), Message(text="message2")]
    error1 = ValidationError(messages=messages)
    error2 = ValidationError(messages=messages)
    assert error1 == error2

    # Test with two ValidationErrors with different messages
    messages1 = [Message(text="message1"), Message(text="message2")]
    messages2 = [Message(text="message1"), Message(text="message3")]
    error1 = ValidationError(messages=messages1)
    error2 = ValidationError(messages=messages2)
    assert error1 != error2

    # Test with two ValidationErrors with different messages

# Generated at 2022-06-18 12:05:01.575997
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="a") == BaseError(text="a")
    assert BaseError(text="a", code="b") == BaseError(text="a", code="b")
    assert BaseError(text="a", code="b") != BaseError(text="a", code="c")
    assert BaseError(text="a", code="b") != BaseError(text="a")
    assert BaseError(text="a", code="b") != BaseError(text="a", key="c")
    assert BaseError(text="a", code="b") != BaseError(text="a", key="c", code="b")
    assert BaseError(text="a", code="b") != BaseError(text="a", key="c", code="d")

# Generated at 2022-06-18 12:05:12.154014
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="error") == BaseError(text="error")
    assert BaseError(text="error") != BaseError(text="error2")
    assert BaseError(text="error") != BaseError(text="error", code="code")
    assert BaseError(text="error", code="code") != BaseError(text="error", code="code2")
    assert BaseError(text="error", key="key") != BaseError(text="error", key="key2")
    assert BaseError(text="error", key="key") != BaseError(text="error", index=["key"])
    assert BaseError(text="error", index=["key"]) != BaseError(text="error", index=["key2"])

# Generated at 2022-06-18 12:05:15.403674
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:05:25.510038
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="text") == BaseError(text="text")
    assert BaseError(text="text1") != BaseError(text="text2")
    assert BaseError(text="text1", code="code1") == BaseError(text="text1", code="code1")
    assert BaseError(text="text1", code="code1") != BaseError(text="text1", code="code2")
    assert BaseError(text="text1", key="key1") == BaseError(text="text1", key="key1")
    assert BaseError(text="text1", key="key1") != BaseError(text="text1", key="key2")
    assert BaseError(text="text1", position=Position(1, 2, 3)) == BaseError(text="text1", position=Position(1, 2, 3))
   

# Generated at 2022-06-18 12:05:35.689198
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test that the method __eq__ of class BaseError returns True when the two objects are equal
    assert BaseError(text="a", code="b", key="c") == BaseError(text="a", code="b", key="c")
    assert BaseError(messages=[Message(text="a", code="b", key="c")]) == BaseError(messages=[Message(text="a", code="b", key="c")])
    assert BaseError(messages=[Message(text="a", code="b", key="c")]) == BaseError(messages=[Message(text="a", code="b", key="c"), Message(text="a", code="b", key="c")])
    assert BaseError(messages=[Message(text="a", code="b", key="c"), Message(text="a", code="b", key="c")])

# Generated at 2022-06-18 12:05:39.155266
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    error2 = BaseError(text='May not have more than 100 characters', code='max_length', key='username')
    assert error1 == error2


# Generated at 2022-06-18 12:05:51.207841
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    assert BaseError(text="text", code="code", key="key", position=Position(1, 2, 3)) == BaseError(text="text", code="code", key="key", position=Position(1, 2, 3))
    assert BaseError(text="text", code="code", key="key", position=Position(1, 2, 3)) != BaseError(text="text", code="code", key="key", position=Position(1, 2, 4))
    assert BaseError(text="text", code="code", key="key", position=Position(1, 2, 3)) != BaseError(text="text", code="code", key="key", position=Position(1, 2, 3), messages=[Message(text="text", code="code", key="key", position=Position(1, 2, 3))])

# Generated at 2022-06-18 12:05:52.661369
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    error3 = BaseError(text="error1")
    assert error1 == error3
    assert error1 != error2


# Generated at 2022-06-18 12:06:01.346695
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    # Test for method __eq__ of class BaseError
    # Setup
    text = "May not have more than 100 characters"
    code = "max_length"
    key = "username"
    position = Position(line_no=1, column_no=1, char_index=0)
    messages = [Message(text=text, code=code, key=key, position=position)]
    error1 = BaseError(messages=messages)
    error2 = BaseError(messages=messages)
    # Test
    assert error1 == error2
    # Teardown - none necessary


# Generated at 2022-06-18 12:06:04.201744
# Unit test for method __eq__ of class BaseError
def test_BaseError___eq__():
    error1 = BaseError(text="error1")
    error2 = BaseError(text="error2")
    assert error1 == error1
    assert error2 == error2
    assert error1 != error2
