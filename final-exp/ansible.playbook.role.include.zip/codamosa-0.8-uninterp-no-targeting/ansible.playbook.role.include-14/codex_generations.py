

# Generated at 2022-06-21 01:03:41.976960
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    data = {}
    loader = None
    collection_list = None

    ri = RoleInclude.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri.load_data(data=data, variable_manager=variable_manager, loader=loader) is None

# Generated at 2022-06-21 01:03:52.210585
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.role.include
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement

    ri = ansible.playbook.role.include.RoleInclude()

    assert isinstance(RoleInclude.load({}, play=None), RoleInclude)


# Generated at 2022-06-21 01:03:59.662573
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {'name': 'test'}
    ri = RoleInclude.load(data=data, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert ri['name'] == 'test'

# Generated at 2022-06-21 01:04:04.201756
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = dict(name='test', foo=42, bar='something')
    value = RoleInclude.load(data, play, collection_list)
    assert value.name == 'test'
    assert value.foo == 42
    assert value.bar == 'something'


# Generated at 2022-06-21 01:04:05.246543
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:04:16.791502
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import callback_loader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()
    callback_plugin = callback_loader.get('default')
    inventory = InventoryManager(loader, variable_manager, C.DEFAULT_HOST_LIST)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user = 'admin'
    play_context.remote_addr = '172.28.128.4'
    play_context.remote_user

# Generated at 2022-06-21 01:04:18.820740
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class my_play(object):
        pass
    role_include=RoleInclude(my_play)
    assert role_include.__class__.__name__ == "RoleInclude"

# Generated at 2022-06-21 01:04:19.850571
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert role._role_path is None

# Generated at 2022-06-21 01:04:21.309008
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #TODO: implement it
    pass


# Generated at 2022-06-21 01:04:28.479772
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # arrange
    import json
    import unittest

    import ansible.playbook.role.include
    from units.mock.loader import DictDataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass


# Generated at 2022-06-21 01:04:40.915085
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # create a play class only for the use of getting the variable_manager class
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.reserved import Reserved
    play = PlayContext()
    reserved = Reserved()
    # create a variable_manager object for use with the RoleInclude class
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # create a RoleInclude class

# Generated at 2022-06-21 01:04:42.589268
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-21 01:04:55.018968
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ansible_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    old_style_requirement = '- { role: apache, other=foo }'
    AnsiblePlaybook.module_utils.module_runner = ansible_module
    AnsiblePlaybook.playbook.play_context = AnsiblePlaybook.playbook.PlayContext()

    ri = None
    try:
        ri = RoleInclude.load(old_style_requirement)
    except AnsibleError as e:
        print("RoleInclude test case passed")
    assert (ri == None)


    play = AnsiblePlaybook.Play()
    play.name = 'test-play'
    play.hosts = 'test-host'
    playbook = AnsiblePlaybook.Playbook

# Generated at 2022-06-21 01:05:08.183803
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()
    play = None
    current_role_path = None
    parent_role = None
    collection_list = None
    data = dict(name="ansible-role-apache", version="1.0.0")
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ri._role_name == "ansible-role-apache"

# Generated at 2022-06-21 01:05:19.298712
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-21 01:05:25.938557
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import ansible.playbook
    import ansible.parsing.yaml.objects
    import ansible.template
    import ansible.vars.manager

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    # Test with data as string
    data = '../../tests/units/playbook/data/role_include/RoleIncludeLoadString'
    play = Play()
    play.vars = ansible.vars.manager.VariableManager()
    current_role_path = './N/A'
    parent_role = 'N/A'
    variable_manager = ansible.vars.manager.VariableManager()
    loader = DataLoader()
    collection_list = []

# Generated at 2022-06-21 01:05:31.085252
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    """
    Unit testing of constructor of class RoleInclude
    """
    ri = RoleInclude()

    assert ri._delegate_to == None
    assert ri._delegate_facts == False


# Generated at 2022-06-21 01:05:41.777203
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    play = Play().load({
        'name': 'Test Play',
        'connection': 'local',
        'hosts': '127.0.0.1',
        'tasks': [],
    }, variable_manager=VariableManager(), loader=C.DEFAULT_LOADER)

    kwargs = {
        'play': play,
        'role_basedir': 'playbooks/roles',
        'variable_manager': VariableManager(),
        'loader': C.DEFAULT_LOADER,
    }


# Generated at 2022-06-21 01:05:47.687240
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class Mock_Attribute(object):
        def __init__(self):
            self.name = 'some_name'

    attr = Mock_Attribute()
    role = RoleInclude()
    role.attributes_to_copy.append(attr)
    assert role.attributes_to_copy[0].name == 'some_name'

# Generated at 2022-06-21 01:05:58.851576
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    try:
        RoleInclude.load(None, None, None, None, None)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('should have raised AnsibleParserError')

    data = 'role1,role2'

    try:
        RoleInclude.load(data, None, None, None, None)
    except AnsibleError:
        pass
    else:
        raise AssertionError('should have raised AnsibleError')

    ri = RoleInclude.load('role1', None, None, None, None)

    assert ri.get_name() == 'role1'

# Generated at 2022-06-21 01:06:05.771399
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-21 01:06:06.749827
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude("test", "test")

# Generated at 2022-06-21 01:06:16.493821
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ########################################################
    #### Load the test data
    ########################################################
    test_data = {}
    this_dir = os.path.dirname(__file__)
    test_data_path = os.path.join(this_dir, 'test_data/role_definition.json')
    with open(test_data_path, 'r') as f:
        test_data = json.load(f)


    ########################################################
    #### Define test data for constructor
    ########################################################
    # test_data for constructor
    # test_case 'role_definition_01'
    play = {}
    current_role_path = ''
    # test_case 'role_definition_02'
    # test_case 'role_definition_03'
    # test_case 'role_definition

# Generated at 2022-06-21 01:06:18.642775
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Constructor of class RoleInclude
    """
    
    role_def = RoleInclude()
    assert isinstance(role_def, RoleInclude)


# Generated at 2022-06-21 01:06:26.538248
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from units.mock.loader import DictDataLoader
    from ansible.parsing.dataloader import DataLoader
    from units.mock.path import mock_unfrackpath_noop

    ds = dict(
        become='yes',
        become_method='sudo',
        become_user='root',
        connection='local',
        gather_facts='yes',
        name='test',
        roles='testrole',
        tasks=[]
        )
    ri = RoleInclude()
    ri.load_data(ds, loader=DictDataLoader({}))

# Generated at 2022-06-21 01:06:27.385448
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:06:38.320809
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    variable_manager.set_nonpersistent_facts(dict(bar='baz'))
    variable_manager.set_nonpersistent_facts(dict(baz='biz'))
    variable_manager.set_nonpersistent_facts(dict(biz='fiz'))
    variable_manager.set_nonpersistent_facts(dict(fiz='foz'))
    templar = Templar(loader=None, variables=variable_manager)


# Generated at 2022-06-21 01:06:47.392007
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-21 01:06:48.134127
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:06:59.380936
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    This is a simple test case to construct RoleInclude
    """
    from ansible.playbook.play import Play
    from ansible.playbook.role import ROLE_CACHE
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader
    from ansible.vars import VariableManager

    # This step is required to Cleanup cache before start of testing
    role_loader._clear_caches()

    ROLE_CACHE['/tmp/test_1'] = {}

# Generated at 2022-06-21 01:07:09.750159
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    assert False

# Generated at 2022-06-21 01:07:11.490672
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri
    del ri

# Generated at 2022-06-21 01:07:11.811928
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:07:22.629433
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    data = {}
    play = Play().load(data, variable_manager=VariableManager(), loader=DataLoader())
    role_req = RoleRequirement()
    role_req.role = 'liao'
    role_req.tasks_from = 'main'
    role_req.name = 'role_req'
    parent_role = RoleInclude(play=play)
    parent_role.role = 'parent'
    parent_role.name = 'parent'

# Generated at 2022-06-21 01:07:30.004875
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved
    from ansible.plugins.loader import find_plugin_file

    class FakePluginLoader:
        def _get_paths_of_possible_plugin_to_load(self, name, subdir):
            raise Exception

    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_dir = os.path.join(current_dir, "..", "..", "test_data")
    test_data_dir = os.path.normpath(test_data_dir)

# Generated at 2022-06-21 01:07:32.762476
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude(play='test', role_basedir=__file__, variable_manager='test', loader='test', collection_list='test')

# Generated at 2022-06-21 01:07:42.826660
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play_dict = dict(
        name="test_play",
        hosts="localhost",
        roles=["role1",
               dict(role="role2"),
               dict(role="role3", some_variable=100),
               dict(role="role4",
                    some_complex_variable=[dict(a=1, b=2, c=3), dict(a=4, b=5, c=6)])]
    )


# Generated at 2022-06-21 01:07:49.457693
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    in_data = dict(
        role = 'common' ,
        become = True,
        become_user = 'root',
        become_method = 'sudo',
        vars = dict(
            my_var = 'foo'
        ),
        tasks = [
            dict(
                block = [
                    dict( action = dict(module = 'debug', args = dict(msg = 'Hello world'))),
                    dict( action = dict(module = 'debug', args = dict(msg = 'Goodbye world'))),
                ]
            )
        ]
    )

    play_obj = Play().load(in_data, variable_manager=None, loader=None)

    role_

# Generated at 2022-06-21 01:07:51.628553
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
    # TODO: add unit test for method load of class RoleInclude

# Generated at 2022-06-21 01:08:02.209543
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    c_loader = DataLoader()
    c_play = Play().load({}, loader=c_loader, variable_manager=VariableManager())

    path = os.path.realpath(os.path.dirname(__file__))
    role_list = os.listdir(path + "/asserts/RoleInclude")
    for role_name in role_list:
        if not os.path.isdir(path + "/asserts/RoleInclude/" + role_name):
            continue
        file_list = os.listdir(path + "/asserts/RoleInclude/" + role_name)

# Generated at 2022-06-21 01:08:28.395107
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    
    ROLES_PATH = []
    loader = None
    variable_manager = None
    collection_list = None
    RI = RoleInclude(play=None, role_basedir=ROLES_PATH, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    print("Test completed")
# Unit test End

if __name__ == '__main__':
    
    test_RoleInclude()

# Generated at 2022-06-21 01:08:35.245538
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager(loader=None)
    roleInclude = RoleInclude(play=play_context, variable_manager=variable_manager, loader=None)
    assert roleInclude.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-21 01:08:36.390939
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_role_include = RoleInclude()

# Generated at 2022-06-21 01:08:37.735406
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert 0

# Generated at 2022-06-21 01:08:47.455765
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_name = "ansible-role-example"
    role_path = "/etc/ansible/roles"
    role_basedir = "."
    variable_manager = "test"
    loader = "load"
    collection_list = "test"

    test_role_include = RoleInclude(role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert test_role_include.get_role_basedir() == role_basedir
    assert test_role_include.get_loader() == loader
    assert test_role_include.get_variable_manager() == variable_manager


# Generated at 2022-06-21 01:08:56.004793
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    data = 'my_role_name'
    # create a "play object"
    play = dict(
        hosts='localhost',
        roles=['my_role_name']
    )
    role_basedir = '.'
    vm = VariableManager()
    im = InventoryManager()
    loader = None
    ri = RoleInclude.load(data, play, role_basedir, variable_manager=vm, loader=loader)

    if not isinstance(ri, RoleInclude):
        raise AssertionError("load method of class RoleInclude failed")


# Generated at 2022-06-21 01:09:06.805357
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test data
    yaml_obj={'include_role': [
              {'name': 'name1'},
              {'name': 'name2',
               'tasks_from': 'tasks_from2'}]}
    variable_manager='variable_manager'
    loader='loader'
    collection_list='collection_list'

    role_include = RoleInclude()
    role_include.load(yaml_obj, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    assert role_include._role_name == 'name1'
    assert role_include._role_path is None
    assert role_include._role_collection is None
    assert role_include._role_collections_paths_cache is None
    assert role_include._role_name == 'name2'

# Generated at 2022-06-21 01:09:11.822275
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test initialization
    r = RoleInclude()
    assert r.name is None
    assert r.play is None
    assert r.role_basedir is None
    assert r.get_vars() == {}
    assert r.get_default_vars() == {}
    assert r.get_include_params() == {}



# Generated at 2022-06-21 01:09:13.124832
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:09:20.252355
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class Play:
        pass
    # Case1: role_name is of type string
    data = 'common'
    play = Play()
    current_role_path = 'test/role/test'
    variable_manager = True
    loader = True
    collection_list = True
    try:
        ri = RoleInclude.load(data, play, current_role_path, variable_manager, loader, collection_list)
    except (AnsibleError, AnsibleParserError):
        assert False
    assert isinstance(ri, RoleInclude)
    # Case2: role_name is of type dict
    data = {'role': 'common'}
    play = Play()
    current_role_path = 'test/role/test'

# Generated at 2022-06-21 01:10:08.874640
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    (unit test) test method load of class RoleInclude
    """
    test_data_type = 'test_data_type'

    import ansible.playbook
    def _load(self, data, play, current_role_path, parent_role, variable_manager, loader):
        return test_data_type

    ansible.playbook.RoleInclude._load = _load
    role_include = ansible.playbook.RoleInclude.load(None, None, None, None, None, None)
    assert (role_include == test_data_type)

# Generated at 2022-06-21 01:10:16.785952
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class MockRole:
        role_path = None
        name = 'role_name'
    class MockPlay:
        dependency_tree = []
        ignore_dependencies = False
        def __init__(self):
            self.role_path = []
    class MockVariableManager:
        def __init__(self):
            self.vars = []
    class MockLoader:
        pass

    #  Test requirement with list of dependencies
    requirement_list = RoleInclude.load(
        'role_name',
        MockPlay(),
        MockRole(),
        MockVariableManager(),
        MockLoader()
    )
    assert isinstance(requirement_list, list)
    assert isinstance(requirement_list[0], RoleRequirement)
    assert requirement_list[0].role_name == 'role_name'
    assert requirement_

# Generated at 2022-06-21 01:10:18.246992
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-21 01:10:29.918699
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = None
    variable_manager = None
    play_context = PlayContext()
    play = RoleRequirement()
    role_include = RoleInclude(play=play, role_basedir=None, variable_manager=variable_manager, loader=loader)
    assert role_include
    assert isinstance(role_include.tags, Attribute)
    assert isinstance(role_include.when, Attribute)
    assert isinstance(role_include.name, Attribute)
    assert isinstance(role_include.vars, Attribute)
    assert isinstance(role_include.include_role, Attribute)
    assert isinstance(role_include.pre_tasks, Attribute)

# Generated at 2022-06-21 01:10:37.973666
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    correctly implement RoleInclude.load()
    """
    # TEST CASE: bad data type is given
    # EXPECTED RESULT: raising of AnsibleParserError
    import pytest
    from ansible.parsing.yaml.objects import AnsibleMapping
    with pytest.raises(AnsibleParserError) as pytest_wrapped_e:
        RoleInclude.load(AnsibleMapping(), play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert 'Invalid role definition' in str(pytest_wrapped_e.value)

    # TEST CASE: old style role requirement are given
    # EXPECTED RESULT: raising of AnsibleError

# Generated at 2022-06-21 01:10:38.531636
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert(True)

# Generated at 2022-06-21 01:10:41.916271
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri._play is None
    assert ri._role_basedir is None
    assert ri._variable_manager is None
    assert ri._loader is None
    assert ri._collection_list is None

# Generated at 2022-06-21 01:10:52.889348
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import ROLE_CACHE_MAX_SIZE
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-21 01:10:59.134596
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri._role_name == None
    assert ri._role_path == None
    assert ri._role_expect_wo_block == False
    assert ri._role_vars == None
    assert ri._role_default_vars == None
    assert ri._role_tasks == None
    assert ri._role_handlers == None
    assert ri._role_meta == None
    assert ri._role_dependencies == None
    assert ri._role_has_tasks == False
    assert ri._role_tasks_from == None
    assert ri._role_has_handlers == False
    assert ri._role_handlers_from == None
    assert ri._role_has_default_vars == False
    assert ri._role_

# Generated at 2022-06-21 01:11:08.315679
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    from units.mock.loader import DictDataLoader

    data = {'role': {'name': 'new_role'}}
    play = PlayContext()
    current_role_path = os.path.dirname(os.path.realpath(__file__))
    variable_manager = VariableManager()
    loader = DictDataLoader({})
    collection_list = None
    current_role_path = [current_role_path, os.path.dirname(current_role_path)]


# Generated at 2022-06-21 01:12:35.802174
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri1 = RoleInclude()
    assert ri1.__class__ == RoleInclude

# Generated at 2022-06-21 01:12:36.455434
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:12:43.643400
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    try:
        ri.load('name7')
    except AnsibleError as err:
        assert (str(err).startswith(
            'Invalid old style role requirement: name7'))
    try:
        ri.load('name7,name8')
    except AnsibleError as err:
        assert (str(err).startswith(
            'Invalid old style role requirement: name7,name8'))
    try:
        ri.load(['name1'])
    except AnsibleParserError as err:
        assert (str(err).startswith(
            'Invalid role definition: [\'name1\']'))

# Generated at 2022-06-21 01:12:54.077752
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.pipelining import PipelineModule

    variable_manager = VariableManager()
    loader = DataLoader()
    # inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/inventory')
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

# Generated at 2022-06-21 01:12:54.612239
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:12:55.700842
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    aRoleInclude = RoleInclude()
    assert aRoleInclude

# Generated at 2022-06-21 01:12:56.197297
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()

# Generated at 2022-06-21 01:12:57.211180
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # TODO: Unit test for method load of class RoleInclude
    pass

# Generated at 2022-06-21 01:13:01.814140
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    
    p = Play().load({
        'name': 'test',
        'hosts': 'localhost'
    }, variable_manager=None, loader=None)

    r = RoleInclude(play=p, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    
    r._load_role_data({
        'name': 'test'
    }, variable_manager=None, loader=None)

    

# Generated at 2022-06-21 01:13:04.071919
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert role.__class__.__name__ == 'RoleInclude', \
        'class RoleInclude did not inherit from RoleDefinition'
