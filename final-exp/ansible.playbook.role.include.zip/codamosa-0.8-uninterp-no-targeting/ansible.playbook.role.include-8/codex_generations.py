

# Generated at 2022-06-21 01:03:31.428644
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host

    ri = RoleInclude()
    assert ri is not None


# Generated at 2022-06-21 01:03:43.409928
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # init the object
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_context = PlayContext()
    play_source =  dict(
            name = "Ansible Play ",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )
    play = Play().load(play_source, variable_manager=None, loader=None)
    ri = RoleInclude(play=play, role_basedir=None)

    # test string_types
    role_source = "../"


# Generated at 2022-06-21 01:03:54.942578
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    add_all_plugin_dirs()
    variable_manager = VariableManager()
    loader = DataLoader()
    roles_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'unit', 'test_roles')
    # initialize needed objects
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    print(roles_path)
   

# Generated at 2022-06-21 01:03:56.769465
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Construct and run the test cases described below
    """
    print("Constructing RoleInclude object")
    ri = RoleInclude()

    # TODO: Add test cases

# Generated at 2022-06-21 01:04:07.943922
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play import Play
    from ansible.plugins import action_loader

    loader = TestLoader()
    variable_manager = TestVariableManager()

# Generated at 2022-06-21 01:04:08.494368
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:04:11.596981
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude.__name__ == "RoleInclude"


RoleInclude.register_attribute(delegate_to=Attribute(field=True))
RoleInclude.register_attribute(delegate_facts=Attribute(field=True, default=False))

# Generated at 2022-06-21 01:04:12.540382
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    with pytest.raises(AnsibleError):
        Requirements("")

# Generated at 2022-06-21 01:04:13.105565
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:04:17.767704
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    for req in ('role_basedir', 'variable_manager', 'loader'):
        assert getattr(ri, req) is None

# Generated at 2022-06-21 01:04:27.526380
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    (output, err) = capsys.readouterr()
    res = ()

    # Setup
    data = ""
    play = ""
    current_role_path = ""
    parent_role = ""
    variable_manager = ""
    loader = ""
    collection_list = ""

    # Check exception with incorrect input data
    with pytest.raises(AnsibleParserError) as excinfo:
        res = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert "Invalid role definition" in str(excinfo.value)

    # Check exception with incorrect old style requirement
    data = "toto,titi"

# Generated at 2022-06-21 01:04:30.849212
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    variables = []
    loader = []
    role = ""

    result = RoleInclude.load(role, variables, loader)
    assert not result

# Generated at 2022-06-21 01:04:40.875897
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import json

    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager

    yaml_str = "---\n- name: test_role\n  tasks:\n  - name: test_task\n    debug:\n      msg: hello\n"
    try:
        from yaml import CSafeDumper as Dumper
    except ImportError:
        from yaml import SafeDumper as Dumper


# Generated at 2022-06-21 01:04:42.992005
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include is not None

# Generated at 2022-06-21 01:04:48.389569
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    play = Play().load({
        'name': 'test',
        'hosts': 'dummy'
    }, variable_manager={}, loader={})
    result = RoleInclude.load('role', play)
    assert "role" == result.name
    assert "role" == result.role_name


# Generated at 2022-06-21 01:04:49.984714
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_instance = RoleInclude()
    assert isinstance(test_instance, RoleInclude)

# Generated at 2022-06-21 01:04:50.834876
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:04:56.879604
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Set of valid input parameters for constructor of class RoleInclude
    params_1 = {
        "play": True,
        "role_basedir": True,
        "variable_manager": True,
        "loader": True,
        "collection_list": True
        }
    # Check if object of class RoleInclude is created
    assert RoleInclude(params_1)

# Generated at 2022-06-21 01:05:03.751223
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test case 1
    play = {}
    role_basedir = None
    data = {}
    current_role_path = None
    parent_role = None
    variable_manager = {}
    loader = {}
    collection_list = {}
    ri_instance = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader,
                              collection_list=collection_list)
    assert isinstance(ri_instance.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list), RoleInclude)



# Generated at 2022-06-21 01:05:11.700778
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class MockRoleInclude(RoleInclude):
        def load_data(): pass
    ri = MockRoleInclude()
    try:
        ri.load([])
    except AnsibleParserError:
        pass
    else:
        raise Exception("load() should throw exception with invalid data")
    try:
        ri.load("some,name")
    except AnsibleError:
        pass
    else:
        raise Exception("load() should throw exception with invalid old style role requirement")

# Generated at 2022-06-21 01:05:29.476224
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    import os
    C.HOST_KEY_CHECKING = False

    my_play = Play()
    my_play.load(dict(
        hosts=['all'],
        gather_facts='no',
        roles=['geerlingguy.apache']
    ))

    my_inventory = ansible.inventory.Inventory("localhost", "127.0.0.1")
    my_variable_manager = ansible.vars.VariableManager()
    my_loader = ansible.parsing.dataloader.DataLoader()


# Generated at 2022-06-21 01:05:34.049494
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)



# Generated at 2022-06-21 01:05:43.005549
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    yaml_data = ("""
- hosts: all
  roles:
    - role1
    - role2
""")
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    play_ds = Play().load(yaml_data, variable_manager=None, loader=DataLoader())
    serialized_data = play_ds.serialize()
    assert serialized_data['roles'][0]['role_name'] == 'role1', serialized_data
    assert serialized_data['roles'][0]['role_path'] == 'role1', serialized_data
    assert serialized_data['roles'][0]['default_vars'] == {}, serialized_data
   

# Generated at 2022-06-21 01:05:52.641233
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    class MockPlaybookExecutor(PlaybookExecutor):
        def __init__(self):
            pass

    host = MockPlaybookExecutor()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 01:05:55.178811
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test RoleInclude constructor
    ri = RoleInclude()
    assert ri is not None


# Generated at 2022-06-21 01:06:03.688782
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_path = "roles/webserver"
    role_name = "webserver"
    role = RoleInclude(role_basedir=role_path,
                       role_name=role_name,
                       become=True,
                       become_user="root",
                       become_method="sudo",
                       become_flags="-H",
                       tags=["example", "test"],
                       tasks_from="deploy.yml",
                       handlers_from="handlers/main.yml",
                       variable_manager="",
                       loader="",
                       collection_list="")
    assert role.get_name() == role_name
    assert role.get_path() == role_path
    assert role.become is True
    assert role.become_user == "root"
    assert role.become_method == "sudo"


# Generated at 2022-06-21 01:06:12.797943
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os.path
    play_path = os.path.join(os.path.dirname(__file__), 'test_role_include_load.yml')
    play_data = None
    with open(play_path, 'r') as play_fd:
        play_data = play_fd.read()
    inventory = InventoryManager(loader=DataLoader(), sources=None)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play = Play.load(play_data, variable_manager=variable_manager, loader=DataLoader())
    include = play.get_roles

# Generated at 2022-06-21 01:06:14.552081
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    requirement = RoleRequirement.load(data='role1,role2')
    assert requirement.role_name == 'role1,role2'

# Generated at 2022-06-21 01:06:18.530616
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    loader = DictDataLoader({})
    ri = RoleInclude.load(dict(name='apache', tasks_from='main.yml'), None, None, None, None, loader)
    assert isinstance(ri, RoleInclude)
    assert ri.get_name() == 'apache'
    assert ri.get_role_path() == 'main.yml'

# Generated at 2022-06-21 01:06:19.023254
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:06:40.293992
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import tempfile
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition

    cur_dir = os.path.dirname(os.path.realpath(__file__))

    tmp_dir = tempfile.mkdtemp()
    tmp_playbook_path = tmp_dir + "/role_include.yml"
    tmp_playbook_content = "---\n- hosts: localhost\ntasks:\n- include_role: name=test_role1\n"
    tmp_playbook_handle = open(tmp_playbook_path, "w")
    tmp_playbook_handle.write(tmp_playbook_content)
    tmp_

# Generated at 2022-06-21 01:06:49.535605
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    data = {}
    variables = {}
    os.environ["ANSIBLE_ROLES_PATH"] = "/etc/ansible/roles"

    ri = RoleInclude(None, None, None)
    new_ri = ri.load(data, None, None, None, variables, None)

    assert(new_ri._role_path == None)
    assert(new_ri._name == None)
    assert(new_ri._vars == [])
    assert(new_ri._default_vars == [])
    assert(new_ri._task_vars == None)
    assert(new_ri._role_params == None)
    assert(new_ri._metadata == {})

# Generated at 2022-06-21 01:06:51.240441
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # not implemented
    pass

# Generated at 2022-06-21 01:07:01.005387
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.errors import AnsibleError
    from ansible.variables import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import ansible.constants as C
    #Constructor with no arguments
    try:
        RoleInclude()
    except AnsibleError:
        pass
    #Constructor with args
    C.BASEDIR = "tests/integration/"
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager._extra_vars = {'env': 'test'}
    variable_manager.options_vars['roles_path'] = "../../../../../../roles"

# Generated at 2022-06-21 01:07:12.288273
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    role_include = RoleInclude()
    role_include.variable_manager = VariableManager()
    role_include.variable_manager.extra_vars = dict(foo='bar')

    context = {}
    role_include._load_context(context, ds=dict(foo='bar'))
    assert context['foo'] == 'bar'
    assert context['ansible_play_hosts'] == []

    # test a basic string so we know its working
    data = "foobar"
    # this is the expected data structure...

# Generated at 2022-06-21 01:07:18.738805
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play="testPlay",role_basedir="testPath",variable_manager="testVar",loader="testLoader",collection_list="testCollection")
    assert ri.play=="testPlay"
    assert ri.role_basedir=="testPath"
    assert ri.variable_manager=="testVar"
    assert ri.loader=="testLoader"
    assert ri.collection_list=="testCollection"


# Generated at 2022-06-21 01:07:28.018728
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.config.manager import ConfigManager
    from ansible.playbook.play import Play
    from ansible.plugins import plugin_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor import task_queue_manager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import find_plugin


# Generated at 2022-06-21 01:07:39.312689
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext

    ri = RoleInclude()
    assert ri._play is None
    assert ri._role_basedir is None
    assert ri._variable_manager is None
    assert ri._context is None
    assert ri._tasks is None
    assert ri._handlers is None
    assert ri._default_vars is None
    assert ri._metadata is None
    assert ri._dependencies is None
    assert ri._post_tasks is None
    assert ri._pre_tasks is None
    assert ri._role_path is None
    assert ri._name is None
    assert ri._collections is None
    assert ri._collection_list is None


# Generated at 2022-06-21 01:07:47.694020
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import RoleRequirement
    import ansible.playbook.role.requireme as role_requirement
    from ansible.vars.manager import VariableManager
    import json

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    loader = DataLoader()

    play_data = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [
            dict(role="common")
        ]
    )
    play = Play().load(play_data, variable_manager=variable_manager, loader=loader)
    print (json.dumps({'play': play.get_vars()}, indent=4))

# Generated at 2022-06-21 01:07:58.561557
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {
        'name': 'test',
        'description': 'description',
        'some.var': 'overridden',
        'defaults': {'some.var': 'defaultval', 'another.var': 2},
        'vars': {'some.var': 'varsval'},
        'tasks': [{'name': 'task1'}],
        'handlers': [{'name': 'handler1'}],
    }
    role_basedir='/home/user/ansible'
    current_role_path='/home/user/ansible/roles'
    play = None
    #variable_manager= ...
    #loader= ...
    #collection_list= ...

# Generated at 2022-06-21 01:08:29.996926
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    #p = Play()

    #print("inventorymanager", InventoryManager(loader=d, sources=["/sec/deploy/ansible/inventories/hosts"]))
    #print("variablemanager", VariableManager(loader=d, inventory=inventorymanager))
    #print("playbookexecutor", PlaybookExecutor(playbooks=[], inventory=InventoryManager(loader=d, sources=["/sec/deploy/ansible/

# Generated at 2022-06-21 01:08:39.725895
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook
    my_role_path = os.getcwd() + '/tests/unit/callback_plugins/library'
    with open(my_role_path + '/test_role_include.yaml', 'r') as stream:
        my_role = yaml.safe_load(stream)

    # test correct class initialization
    def test_init():
        my_ri = RoleInclude()
        assert isinstance(my_ri, AggregateLoader)
        assert isinstance(my_ri, Constructable)
        assert isinstance(my_ri, Base)
        assert isinstance(my_ri, RoleInclude)


# Generated at 2022-06-21 01:08:50.474568
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import unittest
    import sys
    import mock

    class RoleInclude_load_TestCase(unittest.TestCase):

        def test_load_with_string(self):
            variable_manager = mock.MagicMock()
            loader = mock.MagicMock()
            play = mock.MagicMock()
            current_role_path = mock.MagicMock()
            parent_role = mock.MagicMock()
            data = 'string'
            collection_list = mock.MagicMock()

            role_include = RoleInclude.load(data=data, play=play, current_role_path=current_role_path,
                                            parent_role=parent_role, variable_manager=variable_manager, loader=loader,
                                            collection_list=collection_list)


# Generated at 2022-06-21 01:08:57.929166
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_path = '/tmp/roles'
    current_role_path = os.path.join(role_path, "myrole")
    variable_manager = variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory())

    play = dict(hosts=["testhost"], gather_facts="no", roles="myrole")

    # test with param in dict
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager)
    role = ri.load(data=dict(name="myrole"), variable_manager=variable_manager)
    assert role.get_name() == "myrole"

    # test with param in string

# Generated at 2022-06-21 01:09:03.618028
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play

    loader = 'default'
    role_basedir = ''
    variable_manager = 'variable_manager'
    collection_list = 'collection_list'
    play = Play()
    rd = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-21 01:09:14.160833
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # make a role dependency object with a role requirement
    role_dep = RoleRequirement.load('role1,role2,role3')

    # load a RoleInclude object from the role dependency
    ri = RoleInclude.load(role_dep)

    # the role_dep object should not have changed
    assert role_dep.role_name == 'role1,role2,role3'
    assert role_dep.role_path is None

    # the RoleInclude object should have been populated
    assert ri.role_name == 'role1'
    assert ri.role_path == 'role2'
    assert ri.role_collections == 'role3'

    # test the case when the role_dep object has a role path

# Generated at 2022-06-21 01:09:20.722447
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.vars import MockVars

    play_context = PlayContext()
    play_context.remote_addr = 'remote_addr'
    play_context.port = 'port'
    play_context.connection = 'connection'
    play_context.remote_user = 'remote_user'
    play_context.password = 'password'
    play_context.private_key_file = 'private_key_file'
    play_context.timeout = 10
    play_context.shell = 'shell'
    play_context.executable = 'python'
    play_context.become = False
    play_context

# Generated at 2022-06-21 01:09:27.619253
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()

    # assert ri.__str__() == 'RoleInclude()'
    # ri = RoleInclude(name='test')
    # assert ri.__str__() == 'RoleInclude(name=test)'
    # ri = RoleInclude(name='test', vars={"key1":"value1"})
    # assert ri.__str__() == 'RoleInclude(name=test, vars={\'key1\': \'value1\'})'

# Generated at 2022-06-21 01:09:35.668490
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = {}
    collection_list = {}
    variable_manager = {}
    loader = {}
    role_basedir = {}
    ri = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    assert ri.play == play
    assert ri.collection_list == collection_list
    assert ri.variable_manager == variable_manager
    assert ri.loader == loader
    assert ri.role_basedir == role_basedir

# Generated at 2022-06-21 01:09:47.142257
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class OptionsModule:
        def __init__(self, ansible_version=None, ansible_verbosity=None, ansible_roles_path=None, ansible_diff=None,
                     ansible_inventory=None, ansible_host_pattern=None, ansible_forks=None, ansible_timeout=None):
            self.ansible_version = "ansible_version"
            self.verbosity = "verbosity"
            self.roles_path = "roles_path"
            self.diff = "diff"
            self.inventory = "inventory"
            self.host_pattern = "host_pattern"
            self.forks = "forks"
            self.timeout = "timeout"


# Generated at 2022-06-21 01:10:35.843613
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-21 01:10:45.454144
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    myplay = Play().load({'name': 'myplay',
                          'hosts': 'localhost',
                          'roles': [{'role': 'myrole'}]},
                         variable_manager=VariableManager(), loader=DataLoader())
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager._fact_cache['localhost'] = dict(ansible_all_ipv4_addresses=[])
    variable_manager.set_inventory

# Generated at 2022-06-21 01:10:53.596900
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    file_name = "test_role_include.json"
    f = open(file_name)
    data = json.load(f)
    ra1 = RoleInclude()
    ra2 = RoleInclude()
    ra1_data = ra1.load_data(data, variable_manager=variable_manager, loader=loader)
    ra2_data = ra2.load_data(data, vars, variable_manager=variable_manager, loader=loader)
    assert ra1_data==ra2_data
    return True



# Generated at 2022-06-21 01:11:01.822776
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    folder = os.path.dirname(os.path.realpath(__file__))
    filepath = os.path.join(folder, "RoleIncludeTest.yml")
    stream = open(filepath, 'r')
    data = yaml.safe_load(stream)

    # The first test case in the yaml data has a var called 'name' with a value 'test'.
    # The second test case in the yaml data is a list and does not contain a var called 'name'.
    for x in data:
        if 'name' in x:
            assert x['name'] == 'test'
            break

# Generated at 2022-06-21 01:11:09.816503
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pb = Playbook()
    pi1 = RoleInclude(play=pb)
    self.assertRaises(AnsibleParserError, pi1.load, 'abc')
    self.assertRaises(AnsibleError, pi1.load, 'abc,def')
    pi2 = RoleInclude(play=pb)
    self.assertTrue(pi2.load('name: abc'))
    pi3 = RoleInclude(play=pb)
    self.assertTrue(pi3.load(dict(name='abc')))
    pi4 = RoleInclude(play=pb)
    self.assertTrue(pi4.load(AnsibleBaseYAMLObject(dict(name='abc'))))

if __name__ == "__main__":
    test_RoleInclude_load()

# Generated at 2022-06-21 01:11:11.921126
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    a = RoleInclude()
    assert 'RoleInclude' == a.__class__.__name__

# Generated at 2022-06-21 01:11:22.301506
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test that method load raises an AnsibleError when data is a string
    # containing a comma
    ri = RoleInclude()
    with pytest.raises(AnsibleError):
        ri.load("foo,bar")
    # Test that data is a string
    ri = RoleInclude()
    data = "test.yml"
    ri.load(data)
    # Test that data is a dictionary
    ri = RoleInclude()
    data = { 'foo': 'bar' }
    ri.load(data)
    # Test that data is a AnsibleBaseYAMLObject
    ri = RoleInclude()
    data = "test.yml"
    ri.load(data)

# Generated at 2022-06-21 01:11:31.743671
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    def get_groups():
        return [Group('web')]

    def get_hosts():
        return [Host('localhost')]

    localhost = Host('localhost')
    localhost.set_groups(get_groups())

    group_vars = VariableManager()
    group_vars.set_inventory(localhost.get_groups())

    host_vars = VariableManager()
    host_vars.set_inventory(localhost.get_hosts())

    role_def = RoleInclude(play=localhost, role_basedir='.', variable_manager=group_vars, loader=None, collection_list=None)

    assert isinstance(role_def, RoleDefinition)
   

# Generated at 2022-06-21 01:11:35.930101
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils import context_objects as coh
    from ansible.vars import VariableManager
    ri = RoleInclude(play=PlayContext(), role_basedir='.', variable_manager=VariableManager())
    assert coh.global_context.play is ri._play



# Generated at 2022-06-21 01:11:37.498069
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None
    assert isinstance(ri, RoleInclude)