

# Generated at 2022-06-21 01:03:43.582032
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import plugins
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import cStringIO as StringIO

# Generated at 2022-06-21 01:03:45.504231
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-21 01:03:53.111442
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = {}
    current_role_path = '/home/roles'
    parent_role = {}
    variable_manager = {}
    loader = {}
    collection_list = {}

    try:
        RoleInclude.load(1, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleParserError as e:
        assert "Invalid role definition" in str(e)

    try:
        RoleInclude.load("1,2", play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleError as e:
        assert "Invalid old style role requirement" in str(e)

# Generated at 2022-06-21 01:04:06.143581
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # Create a play to test the role
    play_context = PlayContext()
    loader = DataLoader()

# Generated at 2022-06-21 01:04:17.156439
# Unit test for constructor of class RoleInclude
def test_RoleInclude():  # write unit test for class RoleInclude
    _test_play = {u'hosts': u'localhost'}
    _test_role_basedir = u'home/vagrant/'
    _test_variable_manager = {u'hosts': u'localhost'}
    _test_loader = 0
    _test_collection_list = {u'hosts': u'localhost'}
    # TestRoleInclude is a RoleInclude with data values set for testing
    TestRoleInclude = RoleInclude(_test_play, _test_role_basedir, _test_variable_manager, _test_loader, _test_collection_list)

    assert TestRoleInclude.play == _test_play
    assert TestRoleInclude.role_basedir == _test_role_basedir

# Generated at 2022-06-21 01:04:20.353558
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.role.meta
    import ansible.playbook.role.definition

    assert 'RoleInclude' == RoleInclude.load('RoleInclude', '', '', '', '').__class__.__name__
    print('Success: test_RoleInclude_load')



# Generated at 2022-06-21 01:04:25.280851
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    fake_play =  {'hosts':
        'all',
        'user': 'bob',
        'roles': [
            {'role': 'testrole'}
        ]
    }

    RoleInclude.load(data=fake_play, play=fake_play, current_role_path='/tmp/testrole', parent_role=fake_play, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-21 01:04:29.742194
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    print(ri)
#test_RoleInclude()

# Generated at 2022-06-21 01:04:35.298905
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import json
    import tempfile

    r = RoleInclude()
    role_path = tempfile.mkdtemp(prefix='ansible_test_role')

    # Test old style role load
    r.load('name', 'some_role')
    assert len(r.get_name()) == 1
    assert r.get_name()[0] == 'some_role'
    assert r.get_role_path() == 'some_role'

    # Test new style role load
    with open(os.path.join(role_path, 'meta', 'main.yml'), 'w') as mf:
        json.dump({'name': 'new_role'}, mf)

    r.load(role_path, 'some_role')
    assert len(r.get_name()) == 1
    assert r.get_

# Generated at 2022-06-21 01:04:35.849018
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:04:47.446121
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task

    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = ""
    collection_list=[]
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    role_basedir = ""
    RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    # test data

# Generated at 2022-06-21 01:04:59.322819
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # No exception here, as the role_basedir is not mandatory
    assert RoleInclude.load(None, None)

    # exception raised due to data is neither of a string nor a dict
    try:
        RoleInclude.load(None, None, None, None, None, None, 4)
    except AnsibleParserError as e:
        assert "Invalid role definition: 4" in to_native(e)

    try:
        RoleInclude.load(4, None, None, None, None, None, None)
    except AnsibleParserError as e:
        assert "Invalid role definition: 4" in to_native(e)

    # exception raised due to data is an old style role requirement

# Generated at 2022-06-21 01:05:09.851895
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    play = Play().load({'name': 'test play', 'hosts': ['dummy']}, variable_manager=None, loader=None)
    ri = RoleInclude(play=play)
    Ac = AnsibleUnicode.from_unicode
    ri.load_data(Ac('test_role'))
    assert ri._role_name == 'test_role'
    ri.load_data(Ac('test_role,test_role2'))
    assert ri._role_name == 'test_role, test_role2'

# Generated at 2022-06-21 01:05:11.017011
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-21 01:05:16.326604
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    roleInclude = RoleInclude()
    data = ['neutron-full']
    play = dict()
    roleInclude.load(data, play)
    assert to_native(roleInclude) == '''<RoleInclude (include.yaml): neu...tron-full>'''

# Generated at 2022-06-21 01:05:25.512535
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
	# Play, variable_manager and loader are not used here
	play = 1
	variable_manager = 2
	loader = 3
	# Create an instance of RoleInclude
	ri = RoleInclude(play=play, variable_manager=variable_manager, loader=loader)
	# Call method load of class RoleInclude
	ri.load([], play=play, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 01:05:32.924583
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Assert correct class instantiation
    r = RoleInclude()
    assert isinstance(r, RoleInclude)
    assert isinstance(r, RoleDefinition)

    # Assert correct instantiation with constructor params
    r = RoleInclude(play='test_play', role_basedir='test_basedir', variable_manager='test_vm',
                    loader='test_loader', collection_list='test_cl')
    assert isinstance(r, RoleInclude)
    assert isinstance(r, RoleDefinition)
    assert r._play == 'test_play'
    assert r._role_basedir == 'test_basedir'
    assert r._variable_manager == 'test_vm'
    assert r._loader == 'test_loader'
    assert r._collection_list == 'test_cl'

    # Assert correct static method `load

# Generated at 2022-06-21 01:05:34.404302
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-21 01:05:37.384962
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    a = 0


# Generated at 2022-06-21 01:05:46.254195
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    play = None
    role_basedir = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude(play, role_basedir, variable_manager, loader, collection_list)
    assert ri is not None


# Generated at 2022-06-21 01:05:57.310509
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    loader = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    play = None
    data = None
    ri = RoleInclude.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role,
                          variable_manager=variable_manager, loader=loader)
    assert ri



# Generated at 2022-06-21 01:06:00.792501
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-21 01:06:11.787942
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # setup
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import yaml

    AnsibleLoader.add_constructor(
        yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
        lambda loader, node: dict(loader.construct_pairs(node))
    )

    AnsibleDumper.add_representer(
        dict,
        lambda dumper, data: dumper.represent_dict(data.items())
    )

    f = sys.modules[__name__]
    loader = AnsibleLoader(f)

    # test
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement

# Generated at 2022-06-21 01:06:17.989957
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,','localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)
    result = RoleInclude(play=None, variable_manager=variable_manager, loader=loader)
    assert result

# Generated at 2022-06-21 01:06:25.080262
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = None
    play = Play().load({'name':'test', 'hosts':["test"]}, variable_manager=variable_manager, loader=loader)
    ri = RoleInclude(play)

# Generated at 2022-06-21 01:06:27.616222
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude(play='play')
    ri.load_data('test1', variable_manager='vm')


# Test original form of RoleInclude

# Generated at 2022-06-21 01:06:33.005571
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    yaml_dict = dict(
        name="test",
        tasks=[
            dict(action=dict(module="shell", args="ls"))
        ],
    )
    ri = RoleInclude()
    try:
        ri.load_data(yaml_dict)
    except Exception as e:
        print (e)
    assert ri["name"] == "test"

# Generated at 2022-06-21 01:06:41.991772
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test if class RoleInclude() can be called with a data value that is a string
    and when ',' is in the string an exception is raised.
    """
    try:
        data = "myRole"
        play = "myPlay"
        current_role_path = "myPath"
        parent_role = "myParentRole"
        variable_manager = "myVariableManager"
        loader = "myLoader"
        collection_list = "myCollectionList"
        ri = RoleInclude.load(data, play, current_role_path, variable_manager, loader, collection_list)
        if ri and isinstance(ri, RoleInclude):
            return True
    except:
        raise
    return False


# Generated at 2022-06-21 01:06:48.182398
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.role_name is None
    assert ri.role_path is None
    assert ri.role_basedir is None
    assert ri.role_vars == {}
    assert ri.role_default_vars == {}
    assert ri.role_tasks == []
    assert ri.role_handlers == []
    assert ri.role_meta == {}
    assert ri.play is None

# Generated at 2022-06-21 01:06:51.074100
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None)
    assert ri.get_name() is None

# Generated at 2022-06-21 01:07:00.517219
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    loader = None
    variable_manager = None
    RoleInclude(loader=loader, variable_manager=variable_manager)
    pass

# Generated at 2022-06-21 01:07:03.921173
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    This one is not tested yet, but it comes from an example in the documentation.
    """
#   RoleInclude.load('role_name', 'another_role', 'role_to_skip')

# Generated at 2022-06-21 01:07:12.344795
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()

    # Test invalid role definition
    data = "foobar"
    try:
        assert ri.load(data=data)
        assert False
    except AnsibleParserError:
        assert True

    # Test invalid old style role requirement
    data = "foo,bar"
    try:
        assert ri.load(data=data)
        assert False
    except AnsibleError:
        assert True

    # Test valid role definition
    data = "foobar"
    try:
        assert ri.load(data=data)
        assert True
    except:
        assert False

# Generated at 2022-06-21 01:07:23.239099
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import find_plugin
    from ansible.vars.manager import VariableManager

    variable_manager=VariableManager()
    variable_manager.set_inventory(loader.load_inventory("./tests/inventory/inventory"))
    variable_manager.extra_vars = {"extra_var_1": "1",
                                   "extra_var_2": "2",
                                   "extra_var_3": "3",
                                   "extra_var_4": "4",
                                   "extra_var_5": "5"}
    variable_manager.options_vars = ["./tests/ansible.cfg"]

# Generated at 2022-06-21 01:07:30.223040
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class Options(object):
        def __init__(self, connection='ssh', remote_user=None, ack_pass=None, sudo=None, sudo_user=None, become=None,
                     become_method=None, become_user=None, verbosity=3, check=False):
            self.connection = connection
            self.remote_user = remote_user
            self.ack_pass = ack_pass
            self.sudo = sudo
            self.sudo_user = sudo_user
            self.become = become
            self.become_method = become_method
            self.become_user = become_user
            self.verbosity = verbosity
            self.check = check

    ri

# Generated at 2022-06-21 01:07:38.489593
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    role_include = RoleInclude()

    assert role_include.role_path == None
    # default value of attribute '_delegate_facts' is False
    assert role_include._delegate_facts == False
    assert role_include.role_name == None
    assert role_include.role_name_path == None
    assert role_include.role_vars == {}
    assert role_include.role_metadata == {}
    assert role_include.role_params == {}
    assert role_include.role_defaults == {}
    assert role_include._role_collection == None



# Generated at 2022-06-21 01:07:40.054809
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
  from ansible.playbook.role.requirement import RoleRequirement
  r = RoleRequirement()
  print(r)

# Generated at 2022-06-21 01:07:42.784012
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri

# Generated at 2022-06-21 01:07:43.948981
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:07:54.830475
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    yaml_data = """
---
- hosts: webservers
  user: asdf
  roles:
    - role: common
      vars:
        foo: bar
    - role: common
      tasks:
        - name: hello
          ping:
"""
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import pack_loader, module_loader
    from ansible.module_utils.facts.system.distribution import Distribution  # noqa - required to support unit test

    loader = AnsibleLoader(yaml_data, pack_loader=pack_loader, module_loader=module_loader)
    play_data = loader.get_single_data()

# Generated at 2022-06-21 01:08:20.404319
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Setup a fake variable_manager object
    variable_manager = variable_manager_mock()

    # instantiate some dependency objects
    loader = DataLoader()
    play = Play()

    # Load an old style RoleInclude, this should raise AnsibleError
    data = "test.test"
    try:
        RoleInclude.load(data=data, play=play, variable_manager=variable_manager, loader=loader)
    except AnsibleError:
        pass

    # Load a bad role definition, this should raise AnsibleParserError
    data = [1, 2, 3]
    try:
        RoleInclude.load(data=data, play=play, variable_manager=variable_manager, loader=loader)
    except AnsibleParserError:
        pass

    # Load an empty role definition, this should raise AnsibleParserError
   

# Generated at 2022-06-21 01:08:26.802332
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # data is an instance of str
    data = 'fake.role.name'
    play = None
    current_role_path=None
    parent_role=None
    variable_manager=None
    loader=None
    collection_list=None
    assert isinstance(RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list), RoleInclude)


# Generated at 2022-06-21 01:08:29.977820
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude()
    assert r is not None
    assert r._role_name is None
    assert r._role_path is None
    assert r._role_action is None

# Generated at 2022-06-21 01:08:31.259795
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-21 01:08:43.469681
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ''' unit testing for method load of class RoleInclude '''
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import os
    import json


# Generated at 2022-06-21 01:08:45.146603
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # FIXME should re-write unit tests in Ansible module
    assert False, "TBD"

# Generated at 2022-06-21 01:08:54.410332
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test when data is str type
    data = 'test'
    play = {}
    current_role_path = 'test_role_path'
    parent_role = {}
    variable_manager = {}
    loader = {}

    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)

    # Test when data is dict type
    data = {}
    play = {}
    current_role_path = 'test_role_path'
    parent_role = {}
    variable_manager = {}
    loader = {}

    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)

    # Test when data is AnsibleBaseYAMLObject type
    data = AnsibleBaseYAMLObject('a')
    play = {}
   

# Generated at 2022-06-21 01:09:01.584941
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # setup
    role_def = 'test_role'
    loader = None
    play = 'test_play'
    current_role_path = '.'
    parent_role = None
    variable_manager = None
    collection_list = None
    expected = 'test_role'
    # execute
    actual = RoleInclude.load(role_def, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    #assert
    assert expected == actual.get_name()

# Generated at 2022-06-21 01:09:08.121055
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play()

    ri = RoleInclude(play=play, role_basedir=None, variable_manager=variable_manager, loader=loader)

    assert isinstance(ri._delegate_to, Attribute)


# Generated at 2022-06-21 01:09:17.423213
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import sys
    import unittest
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleSequence, AnsibleMapping

    class TestYAMLObject(AnsibleBaseYAMLObject):
        pass

    class TestSequence(AnsibleSequence):
        pass

    class TestMapping(AnsibleMapping):
        pass

    class TestPlay(object):
        pass

    class TestRole(object):
        pass

    class TestVariableManager(object):
        pass

    class TestCollectionLoader(object):
        pass
