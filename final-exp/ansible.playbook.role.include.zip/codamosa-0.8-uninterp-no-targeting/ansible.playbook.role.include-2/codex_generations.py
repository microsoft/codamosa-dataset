

# Generated at 2022-06-21 01:03:43.873404
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Setup the test data

# Generated at 2022-06-21 01:03:54.530962
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.group import Group

    class FakePlay(object):
        variable_manager = None
        loader = None

    fake_play = FakePlay()

    class FakeVariableManager(object):
        pass

    fake_variable_manager = FakeVariableManager()

    class FakeLoader(object):
        pass

    fake_loader = FakeLoader()

    class FakeGroup(object):
        variable_manager = None
        loader = None

    fake_group = FakeGroup()

    def fake_load(data, play, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None):
        return data

    fake_data = {}


# Generated at 2022-06-21 01:04:07.944606
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import sys

    import unittest
    from unittest.mock import Mock, patch

    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleMapping

    ###############################################################################
    #
    # Test case: Initialize a RoleInclude with bad param play
    #
    ###############################################################################

    # Mock class RoleInclude
    class MockRoleInclude:
        def __init__(self, play, role_basedir, variable_manager, loader, collection_list):
            assert play != 'foo'

    # Mock class Play
    class MockPlay:
        pass

    # Mock class VariableManager
    class MockVariableManager:
        pass

    # Mock class DataLoader

# Generated at 2022-06-21 01:04:12.902523
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()

    data = dict(
        name='somename'
    )

    role_include = RoleInclude(variable_manager=variable_manager, loader=loader)
    role_include.load_data(data)
    assert role_include.get_name() == 'somename'

# Generated at 2022-06-21 01:04:26.012462
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    pbex = PlaybookExecutor(
        playbooks=[''],
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords={},
    )
    pbex._tqm._unreachable_hosts = dict()

# Generated at 2022-06-21 01:04:27.496787
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert(isinstance(RoleInclude(), RoleInclude))

# Generated at 2022-06-21 01:04:39.107284
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''
    class RoleInclude
    '''
    # Use "validate_conf" method to check parameters of constructor
    ri = RoleInclude()
    ri.validate_conf(dict(
        role_basedir='/var/lib/awx/projects/_1__Project_4/',
        variable_manager='{{ test_var }}',
        loader='',
        collection_list={}))
    ri.validate_conf(dict(
        role_basedir='/var/lib/awx/projects/_1__Project_4/',
        variable_manager='{{ test_var }}',
        loader=None,
        collection_list={}))

# Generated at 2022-06-21 01:04:40.015859
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-21 01:04:46.944832
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    current_role_path = '/home/cloud/.ansible/roles/shell'
    loader = None
    variable_manager = object
    collection_list = ['ansible.builtin']

    play = object
    ri = RoleInclude.load(play, current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri is not None

# Generated at 2022-06-21 01:04:59.080042
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class DummyYAMLObject(AnsibleBaseYAMLObject):
        """
        Dummy class for testing for YAMLObject
        """
        pass


# Generated at 2022-06-21 01:05:10.089338
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import json
    import shutil
    import sys
    import tempfile
    import yaml

    print('TESTING RoleInclude')

    # Set up current directory and role directory for testing
    curdir = os.getcwd()
    testdir = tempfile.mkdtemp()
    os.chdir(testdir)


# Generated at 2022-06-21 01:05:20.262740
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class FakeParentRole():

        class FakePlay():
            class FakeVariableManager():
                class FakeLoader():
                    class FakeCollectionList():

                        def __init__(self, collections_paths):
                            self.collections_paths = collections_paths

            def __init__(self):

                self.collections_paths = ['/path/to/collections']
                self.variable_manager = self.FakeVariableManager()
                self.loader = self.FakeLoader()
                self.loader.collection_list = self.FakeCollectionList(self.collections_paths)

        def __init__(self):
            self.play = self.FakePlay()
            self.role_basedir = './path_to_role'

    # Test for method load of class RoleInclude with invalid role definition
    pr = FakeParentRole()

# Generated at 2022-06-21 01:05:30.940712
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.test.test_data import (
        test_role_path,
        test_playbook_path,
        test_data_loader,
        test_inventory,
    )

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=test_inventory))
    variable_manager.set_basedir(test_playbook_path)


# Generated at 2022-06-21 01:05:41.717409
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.play
    import ansible.playbook.role.definition
    import collections
    import ansible.playbook.role.requirement

    ri = RoleInclude()
    data = {'name': 'ri', 'role_basedir': 'rb', 'play': "p",
            'variable_manager': 'vm'}
    role = ri.load(data, collections.defaultdict(), 'role_basedir',
                   'parent_role', 'variable_manager', 'loader',
                   'collection_list')

    assert role.get_name() == "ri"
    assert role._role_basedir == "role_basedir"
    assert role._play == "p"
    assert role._variable_manager == 'vm'

    data = "ri"

# Generated at 2022-06-21 01:05:47.186029
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Arrange
    current_role_path = None
    loader = None
    variable_manager = None
    play = None
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.definition import RoleDefinition

    rm1 = RoleMetadata()
    rm1.name = "My Role"
    rm1.description = "My Amazing Role"

    rd = RoleDefinition()
    rd.role = rm1

    p = Play()
    p.name = "Dummy Play"

    ri = RoleInclude(play=p)


    # Act
    rm2 = ri.load_data(data=rm1, loader=loader, variable_manager=variable_manager)

    # Assert
    assert rm2 == rm1

# Generated at 2022-06-21 01:06:00.025355
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # load role definition
    # ----------------------------------------------------
    data = dict(role="test-role",
                tasks=dict(playbook="test-playbook.yml"),
                meta=dict(playbook="test-meta.yml"),
                handlers=dict(playbook="test-handlers.yml"),
                vars=dict(playbook="test-vars.yml"),
                defaults=dict(playbook="test-defaults.yml"))

    ri = RoleInclude.load(data, play=None)
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri._role, RoleRequirement)
    assert ri._role.name == "test-role"
    assert ri._role.rolename == "test-role"
    assert ri._role.collections == []
    assert ri._

# Generated at 2022-06-21 01:06:00.839984
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass



# Generated at 2022-06-21 01:06:10.992409
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import ROLE_CACHE

    play_ctx = PlayContext()
    play = Play().load({
        'name': 'test',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'roles': [
            {'role': 'common'},
            {'role': 'webservers', 'foo': 'bar'},
            {'role': 'dbservers'}
        ]
    }, variable_manager=play_ctx.variable_manager, loader=play_ctx.loader)

# Generated at 2022-06-21 01:06:13.499094
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {
        'role': 'test_role'
    }
    role = RoleInclude.load(data, None)
    assert role.get_name() == 'test_role'

# Generated at 2022-06-21 01:06:14.363966
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True == True


# Generated at 2022-06-21 01:06:24.624267
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Constructor of class RoleInclude
    """
    data = "name,role_path,task_list"
    play = None
    ri = RoleInclude(play=play, role_basedir=None, variable_manager=None, loader=None)
    assert(isinstance(ri, RoleInclude))

    ri = RoleInclude.load(data=data, play=play, current_role_path=None, 
            parent_role=None, variable_manager=None, loader=None)
    assert(isinstance(ri, RoleInclude))

# Generated at 2022-06-21 01:06:35.475265
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import sys, os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../../')
    from ansible.module_utils.module_common import AnsibleModule
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='dict', required=True),
        )
    )

    data = module.params['data']


# Generated at 2022-06-21 01:06:38.755496
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    #import validators
    role_include_1 = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    #validators.url()



# Generated at 2022-06-21 01:06:44.189153
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'myrole'
    play = 'myplay'
    current_role_path = 'myrolepath'
    parent_role = 'myparentrole'

    # Calling load with required paramters
    roleInclude = RoleInclude.load(data, play, current_role_path, parent_role)

    # Assertions
    assert isinstance(roleInclude, RoleInclude)
    assert roleInclude.name == 'myrole'
    assert roleInclude._role_name == 'myrole'
    assert roleInclude._role_path == 'myrolepath'

# Generated at 2022-06-21 01:06:56.387011
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    print('TEST: RoleInclude - load')
    print('TEST: RoleInclude - load, with string')
    data = 'test'
    role_include = RoleInclude(variable_manager=variable_manager, loader=loader)
    role_include.load_data(data=data)
    print('TEST: RoleInclude - load, with string, test _load_role_data')

# Generated at 2022-06-21 01:06:58.747322
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    RoleInclude - constructor test
    """
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)

# Generated at 2022-06-21 01:07:09.877302
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    fake_loader = DictDataLoader({})
    # Test RoleInclude.load without optional parameters
    pf = Play().load(dict(
        hosts='localhost',
        roles=['test_role']
    ), loader=fake_loader)
    assert pf.get_roles_list() == [ RoleInclude(play=pf, role_basedir=None, variable_manager=pf._variable_manager, loader=fake_loader, collection_list=None) ]
    # Test RoleInclude.load with optional parameters
    pf = Play().load(dict(
        hosts='localhost',
        roles=['test_role']
    ), loader=fake_loader)

# Generated at 2022-06-21 01:07:15.235947
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    a = {'role': 'common',
         'delegate_to': 'localhost',
         'delegate_facts': 'yes'}

    pi = RoleInclude(a)
    assert pi._role_name == 'common'
    assert pi._delegate_to == 'localhost'
    assert pi._delegate_facts is True

# Generated at 2022-06-21 01:07:25.321947
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    v_data_1 = 'role'
    v_data_2 = 'role, task'
    v_data_3 = {'role': 'task'}
    v_data_4 = {'role': 'task', 'role': 'task'}

    obj_playbook = Playbook()
    obj_role_definition = RoleDefinition()

    #1
    obj_role_include_1 = RoleInclude.load(v_data_1, obj_playbook)
    assert isinstance(obj_role_include_1, RoleInclude)
    assert isinstance(obj_role_include_1, RoleDefinition)

    #2

# Generated at 2022-06-21 01:07:32.663037
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    R = RoleInclude()
    assert R.load('role_name') == 1
    assert R.load('role_name,role_name_2') == 1
    assert R.load('role_name,role_name_2') == 1
    assert R.load(dict(role='role_name', lists=dict(role_name_1='role_name_1', role_name_2='role_name_2'))) == 1
    assert R.load(AnsibleBaseYAMLObject()) == 1