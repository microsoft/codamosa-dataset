

# Generated at 2022-06-21 01:03:44.444763
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    db = dict(
        name="dummy-role",
        tasks=[]
    )

    d = dict(
        name="dummy-role",
        tasks=[]
    )

    r = RoleRequirement.load(db, play=None, variable_manager=VariableManager(), loader=DataLoader())

    ri = RoleInclude()
    ri._role = r
    ri._role_path = "/tmp"
    ri._delegate_to = None
    ri._delegate_facts = False
    ri._play = None


# Generated at 2022-06-21 01:03:45.043765
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:03:54.942179
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Example of data
    data = dict(
        name='example_name',
        tasks='example_tasks',
        handlers='example_handlers',
        vars='example_vars',
        default_vars='example_default_vars',
        meta='example_meta',
        files='example_files',
        templates='example_templates',
        dependencies='example_dependencies',
        galaxy_info='example_galaxy_info',
        galaxy_tags='example_galaxy_tags',
        galaxy_ignore_tags='example_galaxy_ignore_tags',
        galaxy_roles_path='example_galaxy_roles_path',
        collection_list='example_collection_list'
    )

    # Create a RoleInclude object such as in role.py

# Generated at 2022-06-21 01:04:00.978191
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import ansible
    from ansible.playbook.play_context import PlayContext

    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    display = Display()
    loader = DataLoader()
    play = Play()
    play.display = display
    pm = play.get_variable_manager()

    role_basedir = os.path.join(ansible.__path__[0], "roles/")
    play.set_variable_manager(VariableManager())
    play.set_loader(loader)

    ri = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=pm, loader=loader)

    assert ri
    assert isinstance

# Generated at 2022-06-21 01:04:06.422886
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    pc = PlayContext()
    variable_manager = VariableManager()
    loader = None

    ri = RoleInclude(play=pc, variable_manager=variable_manager, loader=loader)
    assert ri._play is pc
    assert ri._variable_manager is variable_manager
    assert ri._loader is loader

# Generated at 2022-06-21 01:04:06.993842
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
   pass

# Generated at 2022-06-21 01:04:14.238429
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {}
    play = {}
    current_role_path = {}
    parent_role = {}
    variable_manager = {}
    loader = {}
    collection_list = {}
    x = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    x.load_data(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:04:26.515870
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._lazy_vars = lambda: {}
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=[]))

    play_context = PlayContext()
    play_context._init_globals()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 01:04:38.543124
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play

    fake_play = Play()
    test_data = ['role_name']
    test_data2 = {'role': 'role_name'}
    try:
        RoleInclude.load(test_data, fake_play)
        RoleInclude.load(test_data2, fake_play)
    except AnsibleError:
        assert False, 'RoleInclude call with valid arguments raised AnsibleError'
    except:
        assert False, 'RoleInclude call with valid arguments raised wrong exception'

    test_data3 = {'role': ['role_name1', 'role_name2']}
    test_data4 = 'role_name1,role_name2'

# Generated at 2022-06-21 01:04:47.622106
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    current_role_path = 'test/role/path'
    parent_role = 'test/parent/role'
    variable_manager = 'test_variable_manager'
    loader = 'test_loader'
    collection_list = 'test_collection_list'

    # This should throw exception: data is not string type, dict type or AnsibleYAMLObject type
    data = []
    play = ''

# Generated at 2022-06-21 01:05:00.410169
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement

    data1 = {'name': 'ri0', 'hosts': 'host0'}
    p1 = Play().load(data1, variable_manager=None, loader=None)
    # Test a dict variable
    data2 = {'name': 'ri1'}
    ri1 = RoleInclude.load(data2, p1, variable_manager=None, loader=None)
    assert ri1._role_name == 'ri1'
    assert not ri1._role_uuid
    # Test a new style string variable
    data3 = 'ri2'
    ri2 = RoleInclude.load(data3, p1, variable_manager=None, loader=None)
    assert ri

# Generated at 2022-06-21 01:05:10.174409
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=Loader, variable_manager=variable_manager, host_list='/dev/null'))

    # string type
    role_definition = RoleInclude.load('role_name', Play(), variable_manager=variable_manager)
    assert role_definition._role_name == 'role_name'
    assert role_definition._role_path == ''
    assert role_definition._role_params == {}

    # dict type
    role_definition = RoleInclude.load({'name': 'role_name'}, Play(), variable_manager=variable_manager)
    assert role_definition._role_name == 'role_name'
    assert role_definition._role_path == ''

# Generated at 2022-06-21 01:05:20.296034
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # check for the file
    assert os.path.exists("test_role.yml")
    assert os.path.exists("test_role_b.yml")

    # load the file into memory
    data = None
    with open("test_role.yml", 'r') as f:
        data = f.read()

    # create a RoleInclude object
    ri = RoleInclude()

    # load the data into memory
    r_data = yaml.load(data)

    # test the constructor if it functions as intended
    assert ri.metadata == r_data['role']['meta']
    assert ri.post == r_data['role']['post']
    assert ri.dependencies == r_data['role']['dependencies']
    assert ri.handlers == r_data

# Generated at 2022-06-21 01:05:28.297959
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    play = Play()
    play.variable_manager = variable_manager

    data = {'name': 'test'}

    role = RoleInclude(play, variable_manager=variable_manager, loader=loader)
    role.load_data(data)
    assert role._role_name == 'test'

# Generated at 2022-06-21 01:05:40.677983
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    _play = dict(
        name = 'test_play',
        hosts = 'all',
        gather_facts = 'no',
        roles = [
                dict(
                  name                  = 'test_role',
                  my_variable           = 'foo',
                  role_broken_variable  = '{{ my_variable }}'
                ),
                dict(
                  name                  = 'test_role',
                  my_variable           = 'bar',
                  role_broken_variable  = '{{ my_variable }}'
                )
        ],
        tasks = [
          dict(
            name = 'test_task',
            debug = dict(
              msg = '{{ test_variable }}'
            )
          )
        ]
    )


# Generated at 2022-06-21 01:05:53.365824
# Unit test for method load of class RoleInclude
def test_RoleInclude_load(): # noqa
    class Play:
        name = None
        hosts = None
        roles = []
        include_role = None
        pass

    class VariableManager:
        host_vars = {}
        group_vars = {}
        extra_vars = {}
        pass

    play = Play()
    variable_manager = VariableManager()

    data = 'test1,test2'
    ri = RoleInclude(play=play, variable_manager=variable_manager)
    assert ri.load(data, play, variable_manager=variable_manager)

    data = 'test1'
    ri = RoleInclude(play=play, variable_manager=variable_manager)
    assert ri.load(data, play, variable_manager=variable_manager)

    data = 'test1,test2'
    ri = RoleRequ

# Generated at 2022-06-21 01:05:53.781965
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:05:57.632592
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Given
    def test_create_loader(self, variable_manager=None, loader=None):
        return DummyLoader()

    # When
    RoleInclude.load(data=None, play=None, current_role_path=None, parent_role=None, variable_manager=None,
                     loader=None, collection_list=None)
    # Then
    assert True



# Generated at 2022-06-21 01:06:06.194852
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader

    ri = RoleInclude()
    ri.set_loader(DataLoader())
    ri.set_variable_manager()
    ri.set_play(1)


# skip test if we're not on a posix system
if os.name != 'posix':
    test_RoleInclude = None

# Generated at 2022-06-21 01:06:15.973881
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = None
    current_role_path = 'role_path'
    parent_role = None
    loader = None
    collection_list = None
    variable_manager = None
    role_include = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, 
                               collection_list=collection_list)

    data = 'test'
    assert role_include.load(data, play, current_role_path, parent_role, loader=loader, collection_list=collection_list)
    assert role_include.role_basedir == current_role_path
    assert role_include.play == play
    assert role_include.variable_manager == variable_manager
    assert role_include.loader == loader
    assert role_include.collection_list == collection_list

# Generated at 2022-06-21 01:06:32.693878
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test define
    assert hasattr(RoleInclude, '_load_role')
    assert hasattr(RoleInclude, '_load_from_file')
    assert hasattr(RoleInclude, '_load_role_data')
    assert hasattr(RoleInclude, '_load_from_inventory')
    assert hasattr(RoleInclude, '_load_data')
    assert hasattr(RoleInclude, '__init__')
    assert hasattr(RoleInclude, 'load')

    test_loader = object()
    test_variable_manager = object()
    test_collection_list = object()
    test_play = object()
    

# Generated at 2022-06-21 01:06:42.343385
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.vault import VaultLib

    play_yaml = """
---
- name: test
  hosts: localhost
"""
    role_yaml = """
---
- name: test
  hosts: localhost
  roles:
    - role_one
    - { role: role_two}
"""
    collection = '/tmp/ansible_collections/namespace/collection'
    json_collection = '{0}/{0}.json'.format(collection)
    meta_collection = '{0}/meta/main.yml'.format(collection)
    role_one = '{0}/roles/role_one/tasks/main.yml'.format(collection)

# Generated at 2022-06-21 01:06:55.179342
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    play = Play().load({'name': 'fakeplay',
                        'hosts': 'fakehosts',
                        'gather_facts': 'no',
                        'roles': [{'role': 'common', 'tasks': [{'name': 'fake1'}]},
                                  {'role': 'other', 'tasks': [{'name': 'fake2'}]},
                                  {'role': 'testing', 'tasks': [{'name': 'fake3'}]}]},
                       variable_manager=None, loader=None)


# Generated at 2022-06-21 01:06:56.517704
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert issubclass(RoleInclude, RoleDefinition)


# Generated at 2022-06-21 01:07:03.444720
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    play_context = PlayContext()

# Generated at 2022-06-21 01:07:11.800224
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Create role
    role_include = RoleInclude()

    # Create play
    play = {}

    # Test load with string
    data = 'test'
    result = role_include.load(data=data, play=play)
    assert result is not None
    assert result._role_name == 'test'
    assert result._role_path == 'test'
    assert result._role_original_path == 'test'

    # Test load with dict
    data = {'test'}
    result = role_include.load(data=data, play=play)
    assert result is not None


# Generated at 2022-06-21 01:07:17.287024
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.config.manager import ConfigManager

    ri = RoleInclude(variable_manager=VariableManager(_loader=DataLoader()), loader=DataLoader())
    assert ri is not None

# Generated at 2022-06-21 01:07:26.885297
# Unit test for method load of class RoleInclude
def test_RoleInclude_load(): 

    from ansible.playbook.play import Play 
    from ansible.parsing.yaml.loader import AnsibleLoader 
    from ansible.parsing.dataloader import DataLoader 
    from ansible.vars.manager import VariableManager 
    from ansible.module_utils.six import PY2

    # Fake play data
    PL = AnsibleLoader(None, 'python_version').load(
        u"""
        
        - hosts: localhost
          connection: local
          gather_facts: False
          roles:
          - { role: foo, tags: [ 'bar' ] }
          pre_tasks:
          - debug: msg={{ item }}
            with_items:
            - 1
            - 2
        """)

    PB = Play().load(PL[0], loader=DataLoader())

# Generated at 2022-06-21 01:07:30.545579
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri != None


# Generated at 2022-06-21 01:07:41.138869
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.vault import get_vault_secret
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from yaml import load

    vault_secret = get_vault_secret(open('./test/ansible_vault.txt'))

    dataloader = DataLoader()
    variable_manager = VariableManager()
    play = Play.load("./test/test_role.yml", variable_manager=variable_manager, loader=dataloader)
    print(play._role_paths)
    print(play.get_vars())
    print(play.get_roles())
    print(play.get_roles()["roles"][0])

# Generated at 2022-06-21 01:07:54.258020
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-21 01:07:57.148598
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    constructor of class RoleInclude
    """
    t = RoleInclude()
    print("t.__dict__=%s" % t.__dict__)

# Generated at 2022-06-21 01:07:59.709834
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri
    print("Unit test of constructor of class RoleInclude - PASS")

# Unit test case for load() function

# Generated at 2022-06-21 01:08:09.654749
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    variable_manager = VariableManager()
    variable_manager._extra_vars = dict()
    variable_manager._extra_vars.update(variable_manager._get_vars(loader=None, play=pc))
    variable_manager._extra_vars.update(variable_manager.get_vars(loader=None, play=pc))
    t = Templar(loader=None, variables=variable_manager.get_vars(loader=None, play=pc))


# Generated at 2022-06-21 01:08:10.811376
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude()
    assert r

# Generated at 2022-06-21 01:08:11.373776
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:08:14.025751
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    assert RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-21 01:08:25.918736
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    variable_manager = None
    loader = None
    play = None
    parent_role = None
    collection_list = None
    current_role_path = None

    role = Role(play = play, 
                role_basedir = current_role_path, 
                variable_manager = variable_manager, 
                loader = loader,
                collection_list = collection_list)

    print (role.get_dep_chain())

    for key in dir(role):
        print(key)

    role_data = {'name': 'test'}


# Generated at 2022-06-21 01:08:32.966773
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Make sure the RoleInclude constructor is setup correctly.
    """
    fixture_loader = None
    fixture_role = None
    fixture_play = None
    fixture_collection_list = None

    fixture_role_include = RoleInclude(
                                       play=fixture_play,
                                       role_basedir=fixture_role,
                                       loader=fixture_loader,
                                       collection_list=fixture_collection_list
                                      )


# Generated at 2022-06-21 01:08:33.896841
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:09:04.179271
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'
    assert ri.__doc__ == '\n    A derivative of RoleDefinition, used by playbook code when a role\n    is included for execution in a play.\n    '

# Generated at 2022-06-21 01:09:12.512959
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    loader = None
    variable_manager = None
    play = None
    collection_list = None
    current_role_path = None
    role_include = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    role_include.role_name = 'Tom'
    role_include.role_name = 'sue'
    print(role_include.role_name)
    print(role_include.action)

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-21 01:09:13.817355
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude()
    assert isinstance(r, RoleInclude)

# Generated at 2022-06-21 01:09:17.194452
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.init import Inventory
    from ansible.plugins import get_all_plugin_loaders
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-21 01:09:28.896847
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.role.requirement import RoleRequirement

    current_role_path = os.path.dirname(__file__)
    play_context=Play().set_loader(loader=None)
    variable_manager=play_context._variable_manager
    loader=play_context._loader

    yml=[]
    yml.append("- name: test-role")
    yml.append("  tasks:")
    yml.append("  - name: test task")
    yml.append("    debug: msg=\"just a test\"")
    yml='\n'.join(yml)


# Generated at 2022-06-21 01:09:40.984707
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    play_context = Play().set_loader(None).load()
    variable_manager = play_context.variable_manager
    loader = play_context.loader

    test_data = {'role_name': 'foo', 'role_path': '/path/to/roles/foo'}
    role_definition = RoleDefinition.load(test_data, play_context)

    role_include = RoleInclude.load(test_data, play_context, variable_manager=variable_manager, loader=loader)

    assert test_data['role_name'] is role_definition.get_name()
    assert test_data['role_path'] is role_definition.get_role_path()

    assert test_data['role_name']

# Generated at 2022-06-21 01:09:44.555532
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri

# Generated at 2022-06-21 01:09:45.763118
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:09:56.140230
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import sys
    import os

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestCallback(CallbackBase):
        """
        Test callback that prints task results.
        """
        def v2_runner_on_ok(self, result, **kwargs):
            print(json.dumps({result._host.get_name(): result._result}, cls=AnsibleDumper))

    # create the tmp dir and write the test file there
    test_dir

# Generated at 2022-06-21 01:09:57.083869
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:10:58.203705
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObj
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    variable_manager = VariableManager

# Generated at 2022-06-21 01:11:00.280853
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = Play()
    data = RoleInclude(play=play)
    assert data is not None

# Generated at 2022-06-21 01:11:08.997883
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.utils.template as t
    import ansible.parsing.yaml.objects as yaml_objects
    import ansible.vars.manager as vars_manager
    import ansible.inventory.manager as inventory_manager
    import ansible.inventory.host as inventory_host
    import ansible.parsing.dataloader as dataloader
    import ansible.playbook.play_context as play_context
    import ansible.playbook.task_include as task_include

    class NameSpace(object):
        def __init__(self):
            self.config = None

    class PlayContext(play_context.PlayContext):
        def __init__(self):
            self.remote_addr = None
            self.remote_user = None
            self.connection = None
            self.port = None

# Generated at 2022-06-21 01:11:14.662510
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    import os

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    pc = PlayContext()
    t

# Generated at 2022-06-21 01:11:16.366933
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:11:18.423467
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert(ri.__dict__ == {'_role_params': []})

# Generated at 2022-06-21 01:11:20.299944
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

if __name__ == "__main__":
    test_RoleInclude_load()

# Generated at 2022-06-21 01:11:29.310793
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    def fake_open():
        pass

    def fake_yaml(self, stream, Loader=None, object_pairs_hook=None):
        return 'yaml_dict'

    class fake_RoleInclude(RoleInclude):

        def __init__(self):
            pass

        def load_data(self, data, file_name=None, parent_role=None, variable_manager=None, loader=None):
            self.data=data
            self.file_name=file_name
            self.parent_role=parent_role
            self.variable_manager=variable_manager
            self.loader=loader

    m = fake_RoleInclude()
    m.play = 'play'
    m.role_basedir = 'role_basedir'
    m.variable_manager = 'var_mgr'
   

# Generated at 2022-06-21 01:11:30.353698
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()

# Generated at 2022-06-21 01:11:33.141911
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("RoleInclude: test")
    ri = RoleInclude()
    assert type(ri) == RoleInclude

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-21 01:13:30.386571
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Instanciating play
    from ansible.playbook.play import Play
    play = Play.load({
        'name' : 'test play',
        'hosts' : 'all',
        'gather_facts' : 'no',
        'vars' : {
            'key' : 'val'
        }
    })
    # Instanciating variable manager
    from ansible.playbook.play_context import PlayContext
    pc = PlayContext()
    from ansible.vars.manager import VariableManager
    var_manager = VariableManager(loader=None, inventory=None, version_info=pc.version_info)
    var_manager._extra_vars = {'key': 'val'}
    var_manager._host_vars = {}

    # Test method load

# Generated at 2022-06-21 01:13:38.231668
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print('Executing tests on method load of class RoleInclude')
    ri = RoleInclude()
    data1 = 'test1'
    data2 = {'test2': 2}
    data3 = 'test3,test4'
    data4 = '123,test5'
    data5 = 123
    data6 = 'test6'
    data7 = 'test7,test8'
    play = 'test_play'
    current_role_path = 'test_current_role_path'
    parent_role = 'test_parent_role'
    variable_manager = 'test_variable_manager'
    loader = 'test_loader'
    collection_list = 'test_collection_list'