

# Generated at 2022-06-21 01:03:35.832080
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-21 01:03:44.618968
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Invalid role definition
    test_play = Play()
    test_loader = DictDataLoader({})
    test_variable_manager = VariableManager()
    test_collection_list = None
    # data is an integer
    test_data = 1
    assert RoleInclude.load(test_data, test_play, variable_manager=test_variable_manager, loader=test_loader, collection_list=test_collection_list)
    test_data = 1.1
    assert RoleInclude.load(test_data, test_play, variable_manager=test_variable_manager, loader=test_loader, collection_list=test_collection_list)
    test_data = []

# Generated at 2022-06-21 01:03:49.942635
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """ test the constructor of class RoleInclude for no paramaters.
    """
    role_include = RoleInclude()
    assert role_include._play is None
    assert role_include._role_name is None
    assert role_include._role_path is None
    assert role_include._role_basedir is None
    assert role_include._variable_manager is None
    assert role_include._loader is None



# Generated at 2022-06-21 01:03:50.902322
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-21 01:03:57.701663
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ''' unit test for constructor of class RoleInclude in ansible/playbook/role/include.py
    '''

    role_include = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

    assert_equal(role_include._delegate_to, None)
    assert_equal(role_include._delegate_facts, False)
    assert_equal(role_include._metadata, None)
    assert_equal(role_include._role_name, None)
    assert_equal(role_include._role_path, None)
    assert_equal(role_include._role_vars, None)
    assert_equal(role_include._tags, None)
    assert_equal(role_include._tasks, None)

# Generated at 2022-06-21 01:03:59.210040
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-21 01:04:08.156771
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import os
    import pytest
    import pprint
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    current_dir = os.path.dirname(os.path.realpath(__file__))
    data_file = os.path.join(current_dir, 'data/role_include.yaml')
    with open(data_file) as f:
        data_yaml = f.read()

    play = Play.load(data_yaml, variable_manager=VariableManager(), loader=DataLoader())
    loader = AnsibleCollectionLoader()
    collection_list

# Generated at 2022-06-21 01:04:17.734076
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.manager import VariableManager

    fake_host = "localhost"
    play_source = dict(
        name="Ansible Play",
        hosts=fake_host,
        gather_facts='no',
        vars=dict(),
        roles=list(),
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=None)



# Generated at 2022-06-21 01:04:18.783861
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:04:26.534831
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    ri = RoleInclude()
    ri.load_data("ceph-osd", variable_manager=VariableManager(loader = None, inventory = InventoryManager()), loader = None)
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri._role_name, Attribute)
    assert ri._role_name.get_name() == "ceph-osd"
    #assert isinstance(ri._role_path, Attribute)
    #assert ri._role_path == None
    #assert isinstance(ri._role_collection, Attribute)
    #assert ri._role_collection == None

# Generated at 2022-06-21 01:04:31.210309
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play={})
    assert ri is not None

# Generated at 2022-06-21 01:04:36.268553
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def role_definition_cls(data, play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None):
        from ansible.playbook.role.definition import RoleDefinition
        return RoleDefinition.load(data, play, role_basedir, variable_manager, loader, collection_list)

    def role_include_cls(data, play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None):
        return RoleInclude.load(data, play, role_basedir, None, variable_manager, loader, collection_list)

    def role_requirement_cls(data, play=None, role_basedir=None):
        from ansible.playbook.role.requirement import RoleRequirement

# Generated at 2022-06-21 01:04:45.086495
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    loader = None
    variable_manager = None
    collection_list = None
    data = {}
    play = None
    ri = RoleInclude(play=play, role_basedir=None, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    ri.load_data(data, variable_manager=variable_manager, loader=loader)
    assert type(ri) == RoleInclude

# Generated at 2022-06-21 01:04:58.090028
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    some_role = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None)
    assert some_role.get_vars() =={}
    assert some_role.get_default_vars() =={}
    assert some_role.default_vars == {}
    assert some_role.default_vars_files == []
    assert some_role.role_path == ""
    assert some_role.vars == {}
    assert some_role.vars_files == []
    assert some_role.task_blocks == {}
    assert some_role.handlers == []
    assert some_role.meta == {}
    assert some_role.dependencies == []
    assert some_role.name == ""
    assert some_role._parent_role == None

# Generated at 2022-06-21 01:05:09.307867
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    """
    Test loading role from string and from dict.
    """

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    ex_loader = AnsibleLoader(None)
    ex_variable_manager = VariableManager()
    ex_play_context = PlayContext()
    ex_play_context._set_loader(ex_loader)
    ex_play_context._set_variable_manager(ex_variable_manager)


# Generated at 2022-06-21 01:05:19.918673
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.utils.vars import merge_hash
    ri = RoleInclude()
    ri_2 = RoleInclude()

    data = """
    - role1
    - role: role2
      tags: [tag1,tag2]
    - role: role2
      tasks_from: role2.yml
      vars_from: role2.yml
      other_parameter: somevalue
      tags:
        - tag3
    - name: role3
      tasks_from: role3.yml
      vars_from: role3.yml
      other_parameter: somevalue
      tags:
        - tag3
    - role: role4
      vars:
        role_variable: 'somevalue'
    """

    data = ri.load_data(data)

    data_

# Generated at 2022-06-21 01:05:23.405185
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    try:
        RoleInclude()
    except:
        pass
    else:
        assert False, "Should have raised exception"

# Generated at 2022-06-21 01:05:32.102493
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory import Inventory

    # Patch definitions to make the input data definition valid
    def _load_data(self, data, variable_manager=None, loader=None):
        self._requirements = RoleRequirement.load()
        self._name = 'test_RoleInclude'
        self._defaults = {}
        self._vars = {}
        self._handlers = {}
        self._tasks = []
        self._meta = {}
        self._dependencies = []
        self._role_path = 'test_playbook'

    from unittest.mock import MagicMock
    RoleDefinition._load_data = _load

# Generated at 2022-06-21 01:05:40.564891
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test with invalid inputs.
    try:
        RoleInclude.load(1, 1, 1, 1, 1)
    except AnsibleParserError as e:
        assert isinstance(e, AnsibleParserError)
    try:
        RoleInclude.load(["my_role"], 1, 1, 1, 1)
    except AnsibleParserError as e:
        assert isinstance(e, AnsibleParserError)
    try:
        RoleInclude.load("my_role,test", 1, 1, 1, 1)
    except AnsibleError as e:
        assert isinstance(e, AnsibleError)

# Generated at 2022-06-21 01:05:51.742616
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_native
    from ansible.utils.display import Display
    display = Display()

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["/path/to/inventory"])

    play_context = PlayContext()
    play_context._init_globals()

    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 01:05:59.910893
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # Test one parameter constructor
    test_variable_manager = object()
    test_loader = object()
    test_collection_list = object()

    ri = RoleInclude(variable_manager=test_variable_manager, loader=test_loader, collection_list=test_collection_list)

    assert ri._loader                == test_loader
    assert ri._variable_manager      == test_variable_manager



# Generated at 2022-06-21 01:06:03.395673
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'example_role'
    play = object()
    variable_manager = object()
    loader = object()
    ri = RoleInclude.load(data=data, play=play, variable_manager=variable_manager, loader=loader)
    assert type(ri) == RoleInclude
    assert ri.get_name() == 'example_role'

# Generated at 2022-06-21 01:06:10.066827
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = {
        'tasks': [
            {
                'include_role': {
                    'name': 'myrole',
                    'tasks_from': 'main.yml'
                }
            }
        ]
    }

    loader = None
    variable_manager = None
    role_basedir = None
    ri = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader)
    print(ri)

# Generated at 2022-06-21 01:06:15.243268
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

    if ri.name is not None:
        raise AssertionError("RoleInclude.name should be None by default")
    if ri.role_basedir is not None:
        raise AssertionError("RoleInclude.role_basedir should be None by default")
    if ri.play is not None:
        raise AssertionError("RoleInclude.play should be None by default")


# Generated at 2022-06-21 01:06:17.290301
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import sys
    from ansible.playbook import Play

    # Make sure constructor fails if provided with object of wrong type
    try:
        RoleInclude(play=Play())
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-21 01:06:28.236643
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-21 01:06:33.004874
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader

    play = None
    role_basedir = None
    variable_manager = None
    loader = DataLoader()
    collection_list = None
    role_include = RoleInclude(play, role_basedir, variable_manager, loader, collection_list)
    print(role_include)

# Generated at 2022-06-21 01:06:42.554907
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    loader = None
    collection_list = None
    path = '/path/to/role'
    role_name = 'role1'
    role_path = os.path.join(path, role_name)

# Generated at 2022-06-21 01:06:54.274454
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Define a YAML object

# Generated at 2022-06-21 01:07:02.406825
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-21 01:07:17.364047
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    loader = unittest.mock.Mock()
    variable_manager = unittest.mock.Mock()
    play = unittest.mock.Mock()
    data = unittest.mock.Mock()
    current_role_path = unittest.mock.Mock()
    parent_role = unittest.mock.Mock()
    collection_list = unittest.mock.Mock()

    ri = RoleInclude(play, current_role_path, variable_manager, loader, collection_list)
    assert ri is ri.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)



# Generated at 2022-06-21 01:07:23.361995
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    variable_manager = ""
    loader = ""
    result = role_include.load({'name': 'test'}, variable_manager, loader)
    if result.name != 'test':
        raise AssertionError("RoleInclude.load() method failed on checking name attribute")
    if result.load_path != 'test':
        raise AssertionError("RoleInclude.load() method failed on checking load_path attribute")

# Generated at 2022-06-21 01:07:32.908375
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Play class test
    play = {
            'name': 'web',
            'hosts': 'dbservers',
            'gather_facts': 'no',
            'roles': [
                {
                    "prod_db":
                        [],
                    "name": "prod_db",
                    "delegate_to": "localhost"
                }
            ],
            'tasks': [
                {'name': 'example', 'action': {'module': 'shell', 'args': 'id'}}
            ]
    }
    # VariableManager clas
    # Loader class test
    data = "prod_db"
    current_role_path = RoleRequirement()
    parent_role = RoleRequirement()
    ansible_base_yaml_object = ""
    ri = RoleInclude.load

# Generated at 2022-06-21 01:07:42.990342
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create role_basedir for all tests
    role_basedir_path = os.path.join(os.getcwd(), 'test_data', 'roles')

    data = 'test_role'
    play = 'test_play'
    current_role_path = 'test_path'
    variable_manager = dict()
    loader = 'test_loader'
    collection_list = 'test_collection_list'
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    role = ri.load(data, play, current_role_path, variable_manager, loader, collection_list)
    assert role.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-21 01:07:43.801739
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True


# Generated at 2022-06-21 01:07:45.527096
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    R = RoleInclude(play=object, role_basedir='/etc', variable_manager=object, loader=object, collection_list=object)

# Generated at 2022-06-21 01:07:56.624842
# Unit test for method load of class RoleInclude

# Generated at 2022-06-21 01:07:58.170060
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri,RoleInclude)

# Generated at 2022-06-21 01:08:04.092797
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    role_include = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

    # test _delegate_to
    assert role_include._delegate_to == None, "delegate_to is not None"

    # test _delegate_facts
    assert role_include._delegate_facts == False, "delegate_facts is not False"

# Generated at 2022-06-21 01:08:04.656981
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:08:18.395424
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:08:22.094245
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Note (FYI):
    # - instantiation test of `super()` is not needed, it is tested in test_RoleDefinition
    # - instantiation test of `load()` is not needed, it is tested in test_RoleDefinition
    RoleInclude()

# Generated at 2022-06-21 01:08:26.918513
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = None
    current_role_path = None
    variable_manager = None
    loader = None
    collection_list = []
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-21 01:08:39.117201
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # data is string
    data = "ansible.builtin,version=2.5" # role_name,version=xxx
    play = "play"
    variable_manager = "var_mgr"
    loader = "loader"
    current_role_path = "current_role_path"
    collection_list = "collection_list"
    ri = RoleInclude.load(data, play, current_role_path, variable_manager, loader, collection_list)

    assert(ri._role_name == 'ansible.builtin')
    assert(ri._role_collection._collection_name == 'ansible.builtin')
    assert(ri._role_collection._version == '2.5')

    # data is dict

# Generated at 2022-06-21 01:08:42.223604
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    #constructor of RoleInclude
    roleInclude = RoleInclude()
    assert roleInclude is not None,\
        "roleInclude should be initialized"

# Generated at 2022-06-21 01:08:53.521790
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-21 01:08:55.548911
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude()
    assert isinstance(r, RoleDefinition)
    assert r._delegate_to is None
    assert r._delegate_facts is False

# Generated at 2022-06-21 01:09:06.236883
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = mock.Mock()
    variable_manager = mock.Mock()
    loader = mock.Mock()
    collection_list = mock.Mock()

    # Load is used to convert old yaml notation to new style requirement
    # when data is a string
    data = "role_name"
    ri = RoleInclude.load(data=data, play=play, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    assert ri.name == 'role_name' and \
           ri.play == play and \
           ri.role_basedir == None and \
           ri.variable_manager == variable_manager and \
           ri.loader == loader and \
           ri.collection_list == collection_list

    # When data is neither a string nor a path like obj

# Generated at 2022-06-21 01:09:16.191973
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_in = Play.load(dict(
        name="Ansible Play",
        hosts=['old_hosts', 'all'],
        gather_facts='no',
        roles=[
            dict(
                name="common",
            ),
        ],
    ), variable_manager=VariableManager(), loader=None,)

    play_context_in = PlayContext()


# Generated at 2022-06-21 01:09:17.168561
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()

# Generated at 2022-06-21 01:09:43.340491
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-21 01:09:46.649802
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_role_include = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    print(test_role_include)

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-21 01:09:57.790721
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert(True)


    # This is a string
    ri = RoleInclude.load("ansible-role-apache,1.0,other/dir", None, None, None, None, None)

    assert(ri.get_name() == "ansible-role-apache")
    assert(ri.get_role_path() == "other/dir")
    assert(ri.get_src() == None)

    ri = RoleInclude.load("ansible-role-apache,other/dir", None, None, None, None, None)

    assert(ri.get_name() == "ansible-role-apache")
    assert(ri.get_role_path() == "other/dir")
    assert(ri.get_src() == None)


# Generated at 2022-06-21 01:10:07.958562
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "test_role"
    play = {'hosts': 'test_host',
            'tasks': [{'name':'test_task',
                       'include_role': {'name':'test_role',
                                        'tasks_from': 'main.yml',
                                        'vars_from': 'vars/main.yml'},
                       'hosts': 'test_host'}]}
    current_role_path = '.'
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ri.name == 'test_role'

# Generated at 2022-06-21 01:10:16.329700
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    data_list = {'roles':
                    {'role1':
                        {'tasks':
                            {'name': 'task 1'}
                        }
                    }
                }
    data_dict = {'tasks':
                    {'name': 'task 1'}
                }
    data_str = 'role1'

    assert(isinstance(ri.load(data=data_list, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None), RoleInclude))
    assert(isinstance(ri.load(data=data_dict, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None), RoleInclude))

# Generated at 2022-06-21 01:10:27.321559
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test for method load of class RoleInclude
    """

    # We need to mock the fact that RoleInclude is a subclass of RoleDefinition
    # to avoid loading the RoleDefinition class and call the load method
    # (we don't need for this unit test).
    import types
    import mock

    RoleDefinition = mock.MagicMock()

    def load(self, data, play, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None):
        self.loaded = True
        self.data = data
        self.role_basedir = current_role_path
        self.variable_manager = variable_manager
        self.loader = loader
        return self

    RoleDefinition.load = types.MethodType(load, None)
    RoleDefinition.__bases__

# Generated at 2022-06-21 01:10:35.808090
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    inventory.set_play_context(play_context)

# Generated at 2022-06-21 01:10:45.454145
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.utils.display import Display
    import collections

    display = Display()
    def mock_display(msg, color=None, stderr=False, screen_only=False, log_only=False):
        return msg

    display.display = mock_display
    display.verbosity = 3

    vm = collections.defaultdict(lambda: collections.defaultdict(dict))
    loader = None

    ri = RoleInclude()
    ri.role_name = "rolename"

    ri.variable_manager = vm
    ri.loader = loader

    # Testing data is of type string

# Generated at 2022-06-21 01:10:50.073598
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__dict__['_role_path'] == "roles"
    assert ri.__dict__['_play'] == None
    assert ri.__dict__['_role_name'] == "all"

# Generated at 2022-06-21 01:10:57.724939
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play
    from ansible.utils.display import Display
    from ansible.vars import VariableManager

    display = Display()
    loader = DictDataLoader()

    variable_manager = VariableManager()

    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='ping', args='')),
        ]
    ), variable_manager=variable_manager, loader=loader)

    role_path = os.path.abspath('my_role')

    RoleInclude.load(dict(role='my_role'), play, current_role_path=role_path, variable_manager=variable_manager, loader=loader, display=display)
    RoleInclude.load

# Generated at 2022-06-21 01:11:50.674829
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-21 01:11:51.631959
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert role

# Generated at 2022-06-21 01:11:59.179397
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)
    assert ri._load_name is not None
    assert ri._load_role_path is not None
    ri = RoleInclude(role_basedir='/mock/path')
    assert ri._load_role_path == '/mock/path'
    ri = RoleInclude(role_basedir=['/mock/path/1', '/mock/path/2'])
    assert ri._load_role_path == ['/mock/path/1', '/mock/path/2']

# Generated at 2022-06-21 01:12:01.544682
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert r is not None, "test_RoleInclude: r is None"


# Generated at 2022-06-21 01:12:02.726190
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleDefinition)

# Generated at 2022-06-21 01:12:13.961897
# Unit test for method load of class RoleInclude

# Generated at 2022-06-21 01:12:14.852517
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-21 01:12:15.999845
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
    # TODO: write a unit test for loading a RoleInclude stanza

# Generated at 2022-06-21 01:12:16.522830
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:12:21.645584
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = dict(include=dict(role=dict(name="testrole")))
    play = ""
    current_role_path = ""
    parent_role = ""
    role_include = RoleInclude.load(data, play, current_role_path, parent_role)
    print(role_include.__dict__.keys())
    assert "name" in list(role_include.__dict__.keys())

if __name__ == "__main__":
    test_RoleInclude()