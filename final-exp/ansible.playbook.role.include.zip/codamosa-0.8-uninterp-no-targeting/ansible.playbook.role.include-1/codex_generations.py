

# Generated at 2022-06-21 01:03:34.862635
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:03:42.973277
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_data = """
    - name: foo
      collections:
        - foo.bar
      import_role:
        name: foo.bar
    """

    collection_list = []

    p = Play()
    p._variable_manager = FakeVariableManager()
    p._loader = AnsibleLoader(yaml_data, collection_list)

    ri = RoleInclude.load(yaml_data, p)
    assert ri is not None

# Generated at 2022-06-21 01:03:46.809421
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import unittest

    class TestRoleIncludeLoad(unittest.TestCase):
        def test_load(self):
            RoleInclude.load()

    unittest.main()

# Generated at 2022-06-21 01:03:55.461020
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = dict(foo = "bar")
    play=object()
    var=object()
    loader=object()
    ri = RoleInclude(play=play,role_basedir=None,variable_manager=var, loader=loader)
    assert ri.play == play
    assert ri.role_basedir is None
    assert ri.variable_manager == var
    assert ri.loader == loader
    assert ri.role_path is None
    assert ri.metadata is None
    assert ri.name is None
    assert ri.collections is None
    assert ri._task_blocks == []
    assert ri._handlers == []
    assert ri._vars == []
    assert ri._default_vars == {}
    assert ri._parent is None

# Generated at 2022-06-21 01:04:07.127246
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from yaml.constructor import ConstructorError
    import yaml

    current_role_path = '/some/path/to/role/defaults/main.yml'
    t_var_mgr = None # TODO: Create mock variable manager
    t_loader = None # TODO: Create mock loader

    role_collection = None # TODO: Create mock role collection

    ri1 = RoleInclude(None, current_role_path, t_var_mgr, t_loader, role_collection)
    assert(isinstance(ri1, RoleInclude))
    
    ri2 = RoleInclude.load("some_role", None, current_role_path, None, t_var_mgr, t_loader, role_collection)
    assert(isinstance(ri2, RoleInclude))
    
    ri3

# Generated at 2022-06-21 01:04:17.346396
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import yaml

    current_dir = os.getcwd()


# Generated at 2022-06-21 01:04:21.233956
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test valid old style role requirement
    load_role = RoleInclude.load("myrole", None)
    assert "myrole" in load_role.get_name()

    load_role = RoleInclude.load("myrole,v2.0", None)
    assert "myrole" in load_role.get_name()


# Generated at 2022-06-21 01:04:28.463180
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create fake play parameters
    fakePlay = {}
    fakePlay['hosts'] = {}
    fakePlay['hosts']['host1'] = {}
    fakePlay['hosts']['host2'] = {}

    fakeRolePath = {}
    fakeRolePath['role1'] = {}
    fakeRolePath['role2'] = {}
    fakeRolePath['role3'] = {}

    fakeVariableManager = {}
    fakeLoader = {}

    # Check method load with a string
    data = 'role1'
    ri = RoleInclude(play=fakePlay, role_basedir=fakeRolePath, variable_manager=fakeVariableManager, loader=fakeLoader)
    assert ri.load(data) == None

    # Check method load with a dict
    data = {'name': 'role1'}
    ri = RoleIn

# Generated at 2022-06-21 01:04:34.447586
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    - include: example.yml
      name: foo
      private: yes
      tags: [ tagged ]
      when: foo == 'bar'
      delegate_to: localhost
      delegate_facts: yes
    '''

    yaml_data = AnsibleLoader(data, None, None).get_single_data()
    for item in yaml_data:
        assert isinstance(item, AnsibleBaseYAMLObject)

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader

    ri = RoleInclude.load

# Generated at 2022-06-21 01:04:35.906076
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

import unittest


# Generated at 2022-06-21 01:04:39.106717
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Constructor of class RoleInclude
    role_include = RoleInclude()
    assert role_include is not None



# Generated at 2022-06-21 01:04:50.586137
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''
    This is a unit test for constructor of class RoleInclude.
    It checks if the class manages two attribues: play and role_basedir
    :return:
    '''
    from ansible.playbook import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    yaml_obj = AnsibleBaseYAMLObject()
    role_metadata = RoleMetadata.load(yaml_obj, get_role_path=True)

    play = Play()
    role_basedir = 'role_basedir'

    role_include = RoleInclude(play,role_basedir)
    assert (play == role_include._play)

# Generated at 2022-06-21 01:04:54.225597
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = None
    play_context = PlayContext()
    test_include = RoleInclude(loadable_from='roles/include/role.yml', variable_manager=variable_manager,
                              loader=loader, play=play_context)
    print(test_include)

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-21 01:04:56.751187
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None , role_basedir=None , variable_manager=None , loader=None , collection_list=None)
    assert ri is not None

# Generated at 2022-06-21 01:05:08.779447
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    import os

    file_name = os.path.join(os.path.dirname(__file__), '../../../test/test_playbook/role_definition/test_role_definition_include.yml')

# Generated at 2022-06-21 01:05:12.381724
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    # This is to test idempotence of __init__ method
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-21 01:05:21.114213
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    os.chdir('ansible_spec')
    f1 = '/etc/ansible/roles/testmodule0.py'
    # f2 = '/etc/ansible/roles/testmodule1.py'
    f3 = '/etc/ansible/roles/testmodule2.py'
    f4 = '/etc/ansible/roles/testmodule3.py'
    f5 = '/etc/ansible/roles/testmodule4.py'
    f6 = '/etc/ansible/roles/testmodule5.py'
    f7 = '/etc/ansible/roles/testmodule6.py'
    f8 = '/etc/ansible/roles/testmodule7.py'
    f9 = '/etc/ansible/roles/testmodule8.py'

    #

# Generated at 2022-06-21 01:05:24.425880
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    ri = RoleInclude()
    assert isinstance(ri, RoleDefinition)
    assert isinstance(ri, Task)
    assert isinstance(ri, TaskInclude)
    del ri

# Generated at 2022-06-21 01:05:28.748740
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("Constructor test of class RoleInclude")
    r=RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    print("Constructor of class RoleInclude was sucessfull")

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-21 01:05:40.330387
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    my_play = object()
    my_role_basedir = object()
    my_variable_manager = object()
    my_loader = object()
    my_collection_list = object()

    ri = RoleInclude(play=my_play, role_basedir=my_role_basedir,
                     variable_manager=my_variable_manager,
                     loader=my_loader, collection_list=my_collection_list)
    assert ri._play is my_play
    assert ri._role_basedir is my_role_basedir
    assert ri._variable_manager is my_variable_manager
    assert ri._loader is my_loader
    assert ri._collection_list is my_collection_list
