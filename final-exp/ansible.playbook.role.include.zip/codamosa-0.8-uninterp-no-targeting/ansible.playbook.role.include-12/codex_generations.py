

# Generated at 2022-06-21 01:03:44.178725
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    data = 'some text'

    # Basic test
    try:
        RoleInclude.load(data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    except AnsibleParserError as e:
        assert e.message == 'Invalid role definition: some text'

    data = 'some,text'

    # Basic test

# Generated at 2022-06-21 01:03:54.617653
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    current_role_path = '/home/xyz/ansible/roles/foo'
    role_basedir = 'home/xyz/ansible/roles'
    ri = RoleInclude(play=Play(), role_basedir=current_role_path, variable_manager=VariableManager(), loader=DataLoader())
    ri_wrong_type = RoleInclude(play=Play(), role_basedir=current_role_path, variable_manager=VariableManager(), loader=DataLoader())

    # Load string
    data = 'xyz'


# Generated at 2022-06-21 01:03:55.948999
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
   role_include = RoleInclude()

# Generated at 2022-06-21 01:04:01.632565
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    this test, for methods of class RoleInclude
    - load()
    """

    from ansible.playbook.play import Play
    from ansible.template import Templar


# Generated at 2022-06-21 01:04:02.502994
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert True

# Generated at 2022-06-21 01:04:09.904146
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def test_stdin_load(data, play, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None):
        out1 = None
        out2 = None
        out3 = None
        out4 = None
        out5 = None
        out6 = None
        try:
            out1 = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
        except Exception as ex:
            out1 = 'Exception'
        try:
            out2 = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
        except Exception as ex:
            out2 = 'Exception'

# Generated at 2022-06-21 01:04:16.412205
# Unit test for method load of class RoleInclude

# Generated at 2022-06-21 01:04:27.187239
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/label')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 01:04:29.280611
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

if __name__ == "__main__":
    test_RoleInclude()

# Generated at 2022-06-21 01:04:30.701812
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass


# Generated at 2022-06-21 01:04:41.942055
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    error_list = []

    a= RoleInclude()
    # check if object is a RoleInclude object
    if not isinstance(a, RoleInclude) :
        error_list.append("RoleInclude(): Returned object is not a RoleInclude object")

    b= RoleInclude(play="name", role_basedir="path", variable_manager="variableManger", loader="loader")
    # check if object is a RoleDefinition object
    if not isinstance(b, RoleDefinition) :
        error_list.append("RoleInclude(): Returned object is not a RoleDefinition object")

    # check if data was initilized with the given parameters
    if str(b.play.get_name()) != "name":
        error_list.append("RoleInclude(): Play was not initialized with given value")

# Generated at 2022-06-21 01:04:51.631520
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.strategy.linear import StrategyModule
    a = AnsiblePlaybook()
    b = Playbook()
    b.load_from_file("test_parser/playbook_include_role/playbook_include_role.yml")
    a.load(b.inventory, b.strategy, b.host_list, b.play_source)
    assert isinstance(a.playbook, Playbook)
    assert isinstance(a.play, Play)
    assert isinstance(a.loader, PlaybookFileLoader)
    assert isinstance(a.variable_manager, VariableManager)
    assert isinstance(a.notified_handlers, dict)

# Generated at 2022-06-21 01:05:01.107022
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    role_content = '''
    - include_tasks: tasks/main.yml
    - import_tasks: tasks/common.yml
    '''

    # Return a file path
    def _find_needle(haystack, needle):
        return __file__

    def _loader(path):
        return role_content

    class Options:
        roles_path = "/tmp"

    variable_manager = VariableManager()
    loader = DictDataLoader({})
    loader.set_basedir('/')
    variable_

# Generated at 2022-06-21 01:05:06.323774
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = dict()
    data['name'] = 'foo'
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri.get_name() == 'foo'

# Generated at 2022-06-21 01:05:18.533588
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    # Define the playbook
    yaml_inventory = """
    ---
    all:
      hosts:
        localhost:
      vars:
        var1: "var1"
        var2: "var2"
    """


# Generated at 2022-06-21 01:05:30.234209
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-21 01:05:32.064524
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert isinstance(RoleInclude(), RoleDefinition)

# Generated at 2022-06-21 01:05:32.476250
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False

# Generated at 2022-06-21 01:05:34.761036
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ins = RoleInclude()
# end of test_RoleInclude()

# Generated at 2022-06-21 01:05:43.288039
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test 1: If data is not string/dictionary/AnsibleBaseYAMLObject, then it should throw exception.
    data = 'ansible-role-apache'
    play = ''
    current_role_path = ''
    parent_role = ''
    variable_manager = ''
    loader = ''
    collection_list = ''
    try:
        role_instance = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except Exception as e:
        raise

    # Test 2: If data is string/dictionary/AnsibleBaseYAMLObject, then it should not throw exception.

# Generated at 2022-06-21 01:05:53.365589
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Test case to check constructor of class RoleInclude
    """
    ri = RoleInclude()

# Generated at 2022-06-21 01:05:54.260442
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude(loader=None)
    assert r
    assert True

# Generated at 2022-06-21 01:05:56.710423
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test of method load of class RoleInclude.

    """
    pass


# Generated at 2022-06-21 01:06:05.250982
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    current_role_path = os.path.join(os.path.dirname(__file__), '../split', 'roles', 'dummy_role')
    data = 'dummy_role'
    role_include = RoleInclude(role_basedir=current_role_path)

    role_include.load_data(data)
    assert role_include.get_name() == 'dummy_role'

    data = {'role': 'dummy_role'}
    role_include.load_data(data)
    assert role_include.get_name() == 'dummy_role'

    data = {'name': 'dummy_role'}
    role_include.load_data(data)
    assert role_include.get_name() == 'dummy_role'


# Generated at 2022-06-21 01:06:15.243749
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import tempfile
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import load_extra_vars
    import json

    # Create data to load into instance of RoleDefinition
    TESTS_PATH = os.path.dirname(__file__)
    # Create temporary directory to store role info
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 01:06:17.047496
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    i = RoleInclude()
    print(i)

# Unit test execution
if __name__ == "__main__":
    test_RoleInclude()

# Generated at 2022-06-21 01:06:18.381247
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:06:19.466609
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:06:27.383219
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = None
    variable_manager = None
    loader = None
    collection_list = None
    current_role_path = None
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri.name == None
    assert ri.play == None
    assert ri.role_basedir == None
    assert ri.variable_manager == None
    assert ri.loader == None


# Generated at 2022-06-21 01:06:29.010779
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include._role_name is None

# Generated at 2022-06-21 01:06:42.921260
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = Play().load(dict(
        name = "test play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            'test_role',
            dict(
                role = 'test_role',
                delegate_to = 'otherhost',
            ),
            'test_role2',
        ],
    ))
    # not really lazy, but we're checking defaults here
    assert play.get_roles()[0].get_name() == 'test_role'
    assert play.get_roles()[0].get_delegate_to() is None
    assert play.get_roles()[1].get_delegate_to() == 'otherhost'
    assert play.get_roles()[2].get_name() == 'test_role2'

# Generated at 2022-06-21 01:06:47.256055
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()

    assert ri.basedir is None
    assert ri.role_name is None
    assert ri.collection_name is None
    assert ri.namespace is None
    assert ri.use_role is None
    assert ri.deprecated is False

# Generated at 2022-06-21 01:06:51.073503
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = dict()
    data['name'] = "test"

    ri = RoleInclude()
    ri.load_data(data)

    assert ri.get_name() == "test"



# Generated at 2022-06-21 01:06:59.284013
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_list = [
        {
            'comment': 'test_RoleInclude_load: test when the load func is called with a string, the result should be a string',
            'result': 'test',
            'expected': 'test'
        },
        {
            'comment': 'test_RoleInclude_load: test when the load func is called with a dict, the result should be a dict',
            'result': dict(name='test'),
            'expected': dict(name='test')
        },
    ]

    for test in test_list:
        assert test['result'] == test['expected'], test['comment']

# Generated at 2022-06-21 01:06:59.849247
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:07:05.024902
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    pb = Play.load(dict(
        name = "test play",
        hosts = "test_hosts",
        gather_facts = True,
    ), variable_manager=variable_manager, loader=loader)

    pb = pb.load(dict(
        roles = [dict(
            role = "test role",
        )],
    ), variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 01:07:15.903949
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    .. code-block:: python

        # content of test_playbook.yml
        - hosts: localhost
          gather_facts: no
          roles:
             - test
    """

    # prepare data for test
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    pb_dir = os.path.dirname(os.path.abspath(__file__))
    test_playbook = os.path.abspath(os.path.join(pb_dir, 'test_playbook.yml'))

    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-21 01:07:17.336816
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    testObj = RoleInclude()
    assert testObj is not None


# Generated at 2022-06-21 01:07:25.729210
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {"name": "test", "hosts": "host"}
    class MockPlay(object):
        pass
    play = MockPlay()
    class MockVariableManager(object):
        pass
    variable_manager = MockVariableManager()
    class MockLoader(object):
        def __init__(self, *args, **kwargs):
            pass
    loader = MockLoader()
    class MockCollectionList(object):
        pass
    collection_list = MockCollectionList()

    ri = RoleInclude.load(data, play, current_role_path='test', parent_role='test', variable_manager=variable_manager, loader=loader, collection_list=collection_list)



# Generated at 2022-06-21 01:07:28.179258
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play

# Generated at 2022-06-21 01:07:45.670978
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {
             'role': 'common',
             'tags': ['foo', 'bar'],
             'when': 'ansible_facts["distribution"] == "Ubuntu"',
             'runtask': [
                          {
                           'name': 'task1',
                           'action': {
                             'module': 'setup',
                             'args': '',
                           }
                          },
                          {
                           'name': 'task2',
                           'action': {
                             'module': 'copy',
                             'args': {
                               'src': 'foo',
                               'dest': 'bar',
                               'mode': 'foo',
                               'content': '{{ bar }}',
                             }
                           },
                          }
                        ],
            }

# Generated at 2022-06-21 01:07:56.760272
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # create fake play obj
    '''
    FakePlay:
        play_source = {
            'name'    : 'test_play', 
            'hosts'   : 'localhost', 
            'gather_facts' : 'no'
            }
        hosts = {'localhost': 'dummy'}
    '''
    FakePlay = type('FakePlay', (object,), 
        {
            'play_source': {'name':'test_play', 'hosts':'localhost', 'gather_facts':'no'},
            'hosts': {'localhost':'dummy'}
        })
    fake_play = FakePlay()

    # create fake variable manager obj
    '''
    FakeVarManager:
        get_vars = lambda self, host: return {}
    '''

# Generated at 2022-06-21 01:07:57.527159
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:07:58.428823
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, "No test implemented"

# Generated at 2022-06-21 01:08:08.833973
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.module_utils.common._collections_compat import Mapping

    #Creating Variable,Loader and PlayBookExecutor objects
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 01:08:20.542234
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    host_list = [
        'localhost'
    ]
    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(), host_list=host_list)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'local',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='/usr/bin/uptime'))
             ]
        )
    loader = DataLoader()
    variable_manager=VariableManager()
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-21 01:08:30.025583
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    yaml = '''
    - name: install apache
      hosts: all
      roles:
        - role: apache
          become: yes
          become_user: root
          become_method: su
          become_flags: '-c'
          tags:
            - webservers
          vars:
            listen_port: 80
            max_clients: 10
            httpd_version: 1.8
            #...
          handlers:
            - name: restart httpd
              tags:
                - always
              service:
                name: httpd
                state: restarted
    '''
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.playbook.role import Role

# Generated at 2022-06-21 01:08:32.124529
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = dict()
    ri = RoleInclude(play=play)
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-21 01:08:32.761675
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:08:44.836887
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test1 = dict(name='test',
                 role_basedir='./test/unit/lib/ansible/playbook/role/',
                 data=dict(name='role_name', app='app1'),
                 current_role_path='./test/unit/lib/ansible/playbook/role/',
                 parent_role=dict(name='role_name', app='app1'),
                 variable_manager=None,
                 loader=None)

# Generated at 2022-06-21 01:09:07.437817
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play

    # TODO:
    # Create a fake Play here

    # Create a fake VariableManager here
    # Create a fake Loader here

    # TODO:
    # Create a fake collection_list here

    # TODO:
    # Create a fake data here

    ri = RoleInclude(play=Play)
    ri.load(data=data, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-21 01:09:16.568527
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    ri = RoleInclude()
    ri.load({
        "role": "test",
        "delegate_to": "localhost",
        "delegate_facts": True,
        "tags": ["test"],
        "vars": {"test": {"key1": "value1", "key2": "value2"}}
    })
    assert ri.role == "test"
    assert ri.name == "test"
    assert ri.role_path == "test"
    assert ri._delegate_to == "localhost"
    assert ri._delegate_facts is True
    assert ri.tags == ["test"]
    assert ri.vars == {"test": {"key1": "value1", "key2": "value2"}}

# Generated at 2022-06-21 01:09:23.466931
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    try:
        ri.load(None, None)
    except AnsibleParserError:
        pass
    else:
        assert False, "Should have thrown AnsibleParserError"
    try:
        ri.load("role1,role2", None)
    except AnsibleError:
        pass
    else:
        assert False, "Should have thrown AnsibleError"

# Generated at 2022-06-21 01:09:30.015518
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    ri = RoleInclude(variable_manager=variable_manager, loader=loader)
    result = ri.load('no-role')
    assert result is None

    role = {}
    result = ri.load(role)
    assert result is None

# Generated at 2022-06-21 01:09:31.014236
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()

    assert ri

# Generated at 2022-06-21 01:09:38.068200
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    test method load of class RoleInclude
    '''
    # basic test
    role_include = RoleInclude.load("", None)
    assert role_include._role_name is None
    assert role_include._role_path is None

    # test if the second parameter is None
    role_include = RoleInclude.load("", None)
    assert role_include._role_name is None
    assert role_include._role_path is None

# Generated at 2022-06-21 01:09:40.140966
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''
    class RoleInclude(RoleDefinition):
    '''
    # TODO: write test for class RoleInclude

# Generated at 2022-06-21 01:09:41.428901
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri,RoleInclude)

# Generated at 2022-06-21 01:09:49.900816
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Unit test for method load of class RoleInclude"""
    # Initialize a variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'role1':{'hosts':'hosts1'},'role2':{'hosts':'hosts2'}}
    loader = DataLoader()

    from ansible.playbook.play import Play
    play = Play()
    play.hosts = "localhost"

    # Test case 1: The data is a string
    data = "test"
    result = RoleInclude.load(data, play, variable_manager=variable_manager, loader=loader)
    assert(result._role_name=="test")

    # Test case 2: The data is a dict
    data = {"role":"test","hosts":"localhost"}

# Generated at 2022-06-21 01:10:00.794435
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook.play import Play

    from ansible.playbook.role.meta import RoleMetadata
    from ansible.utils.vars import combine_vars
    r = RoleInclude()
    assert r.get_name() == 'role'

    r = RoleInclude(play=Play().load({'name': 'test_play'}, variable_manager=None, loader=None))
    assert r.get_name() == 'role'
    assert r.get_vars() == {'play_name': 'test_play'}

    loader = DictDataLoader({
        '/foo/roles/a/meta/main.yml': '''
dependencies:
  - role: b
    role_path: '/foo/roles'
    tasks_from: '*'
'''
    })

   

# Generated at 2022-06-21 01:10:44.255314
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    # Create the Play
    play_source =  dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args='')),
            dict(action=dict(module='ping', args=''))
        ]
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())
    host = Host(name="localhost")

# Generated at 2022-06-21 01:10:46.446492
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None)
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-21 01:10:50.422217
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert RoleInclude

# Generated at 2022-06-21 01:10:56.284405
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.get_loader() == None
    assert ri.get_variable_manager() == None
    assert ri.get_play() == None
    assert ri.get_role_basedir() == None
    assert ri.get_role_path() == None
    assert ri.is_meta() == False
    assert ri.is_import_playbook() == False
    assert ri.is_role() == False
    assert ri.has_tasks() == False
    assert ri.compile() == None

# Generated at 2022-06-21 01:10:57.348005
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:11:05.139165
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {"name": 'geerlingguy.ntp'}
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    ri1 = ri.load_data(data, variable_manager=variable_manager, loader=loader)
    assert(ri1._role_name == 'geerlingguy.ntp')

# Generated at 2022-06-21 01:11:08.485775
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    role_include_data = "geerlingguy.nginx"
    role_include_obj = RoleInclude.load(role_include_data)
    print(role_include_obj.get_name())
    assert role_include_obj.get_name() == 'geerlingguy.nginx'

# Generated at 2022-06-21 01:11:14.255275
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    from ansible.playbook.play import Play
    current_dir = os.path.dirname(os.path.abspath(__file__))
    current_dir, directory_name = os.path.split(current_dir)
    current_dir, directory_name = os.path.split(current_dir)
    current_dir, directory_name = os.path.split(current_dir)


# Generated at 2022-06-21 01:11:16.974983
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    my_role_include = RoleInclude()
    assert my_role_include

# Generated at 2022-06-21 01:11:26.650734
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    def _create_loader(mocker, content=None):
        mocker.patch('os.path.exists')
        if content:
            mocker.patch('io.open', mocker.mock_open(read_data=content))
        else:
            mocker.patch('io.open', mocker.mock_open())
        return DataLoader()

    def _create_play(mocker, variable_manager, loader, inventory=None, options=None):
        return Play().load({}, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 01:12:37.992172
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:12:39.361158
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri



# Generated at 2022-06-21 01:12:41.237222
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Test that the correct class is used when validating data.
    """
    ri = RoleInclude()
    assert isinstance(ri, RoleDefinition)

# Generated at 2022-06-21 01:12:43.600019
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    ri.load("test-role", variable_manager=None, loader=None)
    assert ri.get_name() == "test-role"

test_RoleInclude_load()


# Generated at 2022-06-21 01:12:54.873342
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext

    MockRole = namedtuple('Role', ['get_role_path', 'get_default_vars'])
    mock_role = MockRole(get_role_path=lambda: './tests/unit/v2/', get_default_vars=lambda: dict(foo=1))

    MockPlay = namedtuple('Play', ['get_variable_manager', 'get_loader'])
    MockVariables = namedtuple('MockVariables', ['set_nonpersistent_facts', 'set_fact', 'get_facts'])
    MockLoader = namedtuple('MockLoader', ['load_from_file'])


# Generated at 2022-06-21 01:12:59.239157
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "test"
    play = {}
    current_role_path = {}
    parent_role = {}
    variable_manager = {}
    loader = {}
    role = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)
    assert data == role.get_name()
    assert parent_role == role.get_parent()

# Generated at 2022-06-21 01:13:02.026529
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    dicttest = dict(
        delegate_to = 'local',
        delegate_facts = False,
        pre_tasks = [],
        post_tasks = [],
        vars = {},
        block = {},
        handlers = []
    )
    test = RoleInclude()
    assert test.__dict__ == dicttest

# Generated at 2022-06-21 01:13:05.361464
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import ansible.playbook.play
    p = ansible.playbook.play.Play()
    role_definition = RoleInclude(play=p)
    assert role_definition is not None
    print(role_definition._variable_manager)


# Generated at 2022-06-21 01:13:16.422834
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import ansible.parsing.yaml.objects as yaml_object
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text
    from ansible.parsing.utils.addresses import parse_address
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.playbook.playbook_include import IncludeLoader
    # initialize the loader so we can load the roles
    add_all_plugin_dirs()
    loader = IncludeLoader()

    # Building up the data structure needed for RoleInclude class


# Generated at 2022-06-21 01:13:24.564956
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import unittest

    # Create a mock of class RoleInclude in order to mock the method
    # load_data which is called inside the method load of class RoleInclude
    class RoleIncludeMock(RoleInclude):
        def __init__(self, play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None):
            return

        def load_data(self, data, variable_manager=None, loader=None):
            if data == 'Error':
                raise AnsibleError("Error")
            else:
                return data
