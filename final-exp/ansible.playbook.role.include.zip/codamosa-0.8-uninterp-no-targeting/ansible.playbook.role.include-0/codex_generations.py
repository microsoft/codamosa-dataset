

# Generated at 2022-06-21 01:03:44.044026
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test for valid role definition
    role_defn = 'myrole'
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None)
    ri.load(data=role_defn, variable_manager=None, loader=None)

    # Test for commas in requirement
    try:
        role_defn = 'myrole,myrole-sibling'
        ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None)
        ri.load(data=role_defn, variable_manager=None, loader=None)
    except AnsibleError:
        pass

    # Test for a dict with only 'role' key
    role_defn = {'role': 'myrole'}
    ri

# Generated at 2022-06-21 01:03:44.828696
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:03:46.739727
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:03:47.584052
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:03:48.255803
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-21 01:03:55.946860
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import connection_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.role_context import RoleContext


# Generated at 2022-06-21 01:04:07.251896
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #
    # Test with a fully qualified role definition.
    #
    role_definition = dict(name='foo', tasks=[] )
    ri = RoleInclude.load(role_definition, None, None, None, None, None, None)
    assert ri.name == 'foo'
    assert isinstance(ri.tasks, list)
    #
    # Test with a short style role requirement
    #
    role_requirement = dict(role='foo', tasks=[] )
    ri = RoleInclude.load(role_requirement, None, None, None, None, None, None)
    assert ri.name == 'foo'
    assert isinstance(ri.tasks, list)
    #
    # Test with a bad role requirement
    #

# Generated at 2022-06-21 01:04:17.404494
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    p = Play.load({'name': 'test'})
    vars = VariableManager()
    t = Templar(loader=None, variables=vars)

    # Test invalid inputs
    for data in [1, 2.0, [], {'role': 'no_name'}, {'role': 2.0}]:
        assert False == isinstance(RoleInclude.load(data, p, variable_manager=vars, loader=None), RoleInclude)
    assert False == isinstance(RoleInclude.load('role_name', p, variable_manager=vars, loader=None), RoleInclude)

# Generated at 2022-06-21 01:04:27.554812
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reservered
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    play_obj = Play().load({'name': 'first_play', 'hosts': 'all'}, variable_manager=VariableManager(), loader=None)

    role_include_obj = RoleInclude(play=play_obj)
    assert role_include_obj.get_name() == ''
    assert role_include_obj.get_role_name() == ''
    assert role_include_obj.get_role_path() == ''
    assert len(role_include_obj.get_tasks()) == 0

# Generated at 2022-06-21 01:04:33.601765
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.splitter import parse_kv
    from yaml.nodes import MappingNode, ScalarNode

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    C.DEFAULT_ROLES_PATH = '/etc/ansible/roles'
    context = PlayContext()
    variable_manager = VariableManager()
    play = Play.load({}, variable_manager=variable_manager, loader=None)

    # simple test

# Generated at 2022-06-21 01:04:36.340386
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-21 01:04:37.609455
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:04:50.041751
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.play

    play = ansible.playbook.play.Play()
    role_basedir = ""
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    # old style role requiremen
    data = "jdoe.common,jdoe.webservers"
    try:
        result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
        assert(False)
    except AnsibleError:
        pass

    # string
    data = "jdoe.common"
    result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
   

# Generated at 2022-06-21 01:04:54.588092
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri._play is None
    assert ri._role_basedir is None
    assert ri._variable_manager is None
    assert ri._loader is None

# Generated at 2022-06-21 01:05:03.346283
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class AnsibleFake:
        def __init__(self):
            self.settings = {
                'DEFAULT_ROLES_PATH': 'roles'
            }
    class AnsibleFake2:
        def __init__(self):
            self.roles = []
    class AnsibleFake3:
        def __init__(self):
            self.path = '__test__'
            self.loader = AnsibleFake2()
            self.variable_manager = AnsibleFake2()
            self.collection_list = AnsibleFake2()
    class AnsibleFake4:
        def __init__(self):
            self.ansible = AnsibleFake()
    ansibleModule = AnsibleFake4()

    #
    # Test the load method using pattern 1
    #
    test_data1 = 'test'


# Generated at 2022-06-21 01:05:04.095038
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()


# Generated at 2022-06-21 01:05:04.572565
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:05:17.462226
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("\n Testing RoleInclude")
    play = None
    load = None
    loader = None
    current_role_path = "/Users/username/Ansible/", None
    parent_role = None
    variable_manager = None
    collection_list = None
    
    idata = 'base'
    ri = RoleInclude.load(idata, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    
    print(" RoleInclude: %s" % ri)
    
    idata = 'base,1.2.3'
    ri = RoleInclude.load(idata, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    
    print(" RoleInclude: %s" % ri)
    

# Generated at 2022-06-21 01:05:29.696603
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import json
    import os.path
    import sys
    import unittest
    from copy import deepcopy as copy
    from ansible.parsing.mod_args import ModuleArgsParser

    class TestPlaybook(unittest.TestCase):
        """
        Unit test for class RoleInclude:load
        """

        def setUp(self):
            self.parser = ModuleArgsParser()

        def tearDown(self):
            pass

        def test_load_invalid_type(self):
            """
            Test load method with invalid type as input
            """
            roleincl = RoleInclude()
            variable_manager = self.parser.parse(dict(), use_cache=False)

            self.assertRaises(AnsibleParserError, lambda: roleincl.load(1, variable_manager=variable_manager))

       

# Generated at 2022-06-21 01:05:38.564685
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_play = None
    test_current_role_path = None
    test_parent_role = None
    test_variable_manager = None
    test_loader = None
    test_collection_list = None

    test_data = "some.rol.e,"
    result = RoleInclude.load(test_data, test_play, test_current_role_path, test_parent_role, test_variable_manager, test_loader, test_collection_list)
    assert isinstance(result, RoleRequirement)

# Generated at 2022-06-21 01:05:44.301906
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data= dict()

    ri = RoleInclude()
    assert( ri is not None)
    assert(isinstance(ri, RoleInclude))
    assert(isinstance(ri, RoleDefinition))

# Generated at 2022-06-21 01:05:44.675742
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:05:46.112364
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert isinstance(RoleInclude(), RoleInclude)

# Generated at 2022-06-21 01:05:53.869555
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader

    contents = dict(
        name='example',
        become=True,
        become_user='root',
        become_method='sudo',
        connection='local',
        gather_facts='no',
        roles=dict(
            role1=dict(
                name='role1',
                tasks=['task1', 'task2']
            ),
            role2=dict(
                name='role2',
                tags=['tag1', 'tag2']
            ),
        ),
    )

    import io
    import yaml

    fake_loader = role_loader

    fake_loader.path_exists = lambda _: True

# Generated at 2022-06-21 01:05:58.807257
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    current_role_path = os.path.join(os.getcwd(), 'myrole')
    variable_manager = {}

    ri = RoleInclude(role_basedir=current_role_path, variable_manager=variable_manager)

    print(ri)
    if ri:
        print('True')
    else:
        print('False')

# Generated at 2022-06-21 01:06:11.200698
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    import copy

    play_context = Play().post_validate()

    # test 1
    play_context.variable_manager.extra_vars = dict(ansible_connection='local')
    role_include = RoleInclude(play=play_context)
    assert role_include._play is play_context

    # test 2
    role_include._play = None
    role_include.play_context.variable_manager.extra_vars = dict(ansible_connection='local')
    assert role_include._play is None

    # test 3
    role_include2 = RoleInclude(play=play_context)
    role_include2.play_context.variable_manager.extra_vars = dict(ansible_connection='local')
    assert role_include2._play is play

# Generated at 2022-06-21 01:06:19.629861
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost')
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )

# Generated at 2022-06-21 01:06:31.028991
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Constructor of class RoleInclude
    path = './../../../../test/units/module_utils/test_role_include.yml'
    path = os.path.abspath(path)
    with open(path, 'r', encoding='utf-8') as stream:
        role_include = RoleInclude.load(data=stream, play=None, current_role_path=None,
                                        variable_manager='', loader='', collection_list='')
        assert role_include._name == 'test_role_include'
        assert role_include._role_name == 'test_role_include'
        assert role_include._task_blocks == []
        assert role_include._default_vars == []
        assert role_include._vars == []
        assert role_include._default_vars_files == []

# Generated at 2022-06-21 01:06:41.283005
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import ansible.parsing.yaml.data
    x = ansible.parsing.yaml.data.AnsibleMapping()
    x.yaml_set_line_col(2,3)
    x.yaml_set_end_line_col(9,9)

    pi = RoleInclude(loader=None, play=None, role_basedir=None, collection_list=None)
    pi.load_data(x, variable_manager=None)

    assert pi._line_number == 2
    assert pi._col_number == 3
    assert pi._end_line_number == 9
    assert pi._end_col_number == 9
    assert pi._data == x
    assert pi._loader is None
    assert pi._play is None
    assert pi._role_basedir is None
    assert pi

# Generated at 2022-06-21 01:06:51.985089
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.requirement import RoleRequirement

    # Test data
    # 1. good sync yaml, no path

# Generated at 2022-06-21 01:06:58.624664
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert (role_include.__doc__ == 'A derivative of RoleDefinition, used by playbook code when a role\n    is included for execution in a play.\n    ')
    assert (role_include._delegate_to == None)
    assert (role_include._delegate_facts == False)


# Generated at 2022-06-21 01:07:09.891329
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.playbook import Play

    play_context = PlayContext()
    loader = None
    variable_manager = VariableManager(loader=loader, inventory=InventoryManager())
    variable_manager._extra_vars = {}
    variable_manager._priority = ['role_path']
    variable_manager._options = {'role_path': './role/roles'}


# Generated at 2022-06-21 01:07:11.645939
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, "No tests for RoleInclude.load()"

# Generated at 2022-06-21 01:07:12.341884
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:07:12.928584
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()

# Generated at 2022-06-21 01:07:14.364944
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude(play=play)

# Generated at 2022-06-21 01:07:24.661962
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import unittest2 as unittest
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager

    class TestRole(unittest.TestCase):

        def setUp(self):
            self.play = Play()

# Generated at 2022-06-21 01:07:30.898609
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.parsing.metadata import extract_metadata
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.role.hashivault import HashivaultSecret


# Generated at 2022-06-21 01:07:39.313182
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = [
        ('foo,bar', True),
        ('foo', True),
        ('foo:', True),
        ('- include: foo.yml', True),
        ('- hosts: localhost', False),
        ('foo:', False),
        ('- include: foo.yml', False),
    ]
    for d, result in data:
        assert RoleInclude.load(d, None, None, None, None, None) == result
        assert RoleRequirement.load(d, None, None, None, None, None) != result

# Generated at 2022-06-21 01:07:47.694532
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['localhost,']))

    pc = PlayContext()
    variable_manager.set_play_context(pc)


# Generated at 2022-06-21 01:07:58.649214
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {
        'name': 'test',
        'hosts': 'localhost',
        'roles': [
            {
                'role': 'common',
                'tasks_from': 'main.yml',
                'become': False
            },
            {
                'role': 'web',
                'become': False,
                'vars': {
                    'http_port': 80
                },
                'tags': [ 'web' ],
                'vars_files': [ '/etc/foo.yml' ]
            }
        ]
    }

# Generated at 2022-06-21 01:08:08.989050
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    (Unit Test) test_RoleInclude_load

    This function is used as Unit test for method load of class RoleInclude
    """

    # Initialize variables for test
    test_obj = RoleInclude()
    test_data = {"hosts": "host1", "hosts": "host2"}
    test_play = "play1"
    test_current_role_path = "current_role_path"
    test_parent_role = "parent_role"
    test_variable_manager = None
    test_loader = "loader"
    test_collection_list = None

    # Call method
    ret = test_obj.load(test_data, test_play, test_current_role_path, test_parent_role, test_variable_manager, test_loader, test_collection_list)

    # Ass

# Generated at 2022-06-21 01:08:09.762448
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:08:10.810284
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    assert(True)


# Generated at 2022-06-21 01:08:16.872263
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Covers the case where no role is loaded and the data is a string
    """
    from ansible.playbook.play import Play

    p = Play()
    p._variable_manager = {}
    p._loader = None
    p.collection_list = []
    try:
        RoleInclude.load('my_role', p)
    except AnsibleError:
        pass

# Generated at 2022-06-21 01:08:27.638331
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test load with good data
    data = {
        'name': 'myrole',
        'meta': 'main.yml'
    }

    play = 'myplay'
    variable_manager = 'myvarman'
    loader = 'myloader'
    collection_list = ['mycollection']
    ri = RoleInclude(play, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    ri.load_data(data, loader=loader)

    assert ri.name == 'myrole'
    assert ri.role_path == 'myrole'
    assert ri.meta_path == 'myrole/meta/main.yml'
    assert ri._variable_manager == variable_manager
    assert ri._loader == loader
    assert ri._collection_list == collection_

# Generated at 2022-06-21 01:08:39.896684
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook import play as playbook_play
    from ansible.playbook.role.meta import RoleMetadata

    variable_manager = VariableManager()
    loader = DictDataLoader({})

    play_context = playbook_play.PlayContext()
    play_context.network_os = 'default'
    play_context.remote_addr = 'default'
    play_context.remote_user = 'default'

    play = Play().load({}, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 01:08:45.993473
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    print(ri)
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    print(ri)
    ri = RoleInclude.load(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    print(ri)

# Generated at 2022-06-21 01:08:53.521861
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # objects on which class RoleInclude is dependent
    p = object()
    v = object()
    l = object()
    c = object()

    # constructor call
    ri = RoleInclude(play=p, 
                     role_basedir=p,
                     variable_manager=v,
                     loader=l,
                     collection_list=c)
    # assertions
    assert ri is not None
    assert v == ri._variable_manager
    assert l == ri._loader

# Generated at 2022-06-21 01:08:54.365361
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:09:05.949602
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert isinstance(RoleInclude(), RoleInclude)

# Generated at 2022-06-21 01:09:15.916979
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play, PlayContext
    from ansible.module_utils.parsing.convert_bool import boolean

    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    ))

    play._variable_manager = VariableManager()
    play._variable_manager.extra_vars = load_extra_vars(loader, play, 'all')
    play._variable_manager.options_vars = load_options_vars(loader, play, play.options)


# Generated at 2022-06-21 01:09:27.495513
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import doctest

    class MockArgs(object):
        pass

    m = MockArgs()
    m.tags = ['all']
    m.skip_tags = []

    class MockOptions(object):
        def __init__(self):
            pass
    m.options = MockOptions()
    m.options.tags = ['all']
    m.options.skip_tags = ['none']

    class MockVarMgr(object):
        pass
    variable_manager = MockVarMgr()

    class MockPlay(object):
        def __init__(self):
            self.playbook = 'playbook.yml'
        def set_variable_manager(self, variable_manager):
            self.variable_manager = variable_manager
    play = MockPlay()
    play.set_variable_manager(variable_manager)


# Generated at 2022-06-21 01:09:34.785901
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    # from AnsibleParserError
    data = "./library"
    try:
        ri.load(data, None, None, None, None, None)
    except AnsibleParserError:
        pass
    # from AnsibleError
    data = "./library, ./library"
    try:
        ri.load(data, None, None, None, None, None)
    except AnsibleError:
        pass


# Generated at 2022-06-21 01:09:35.397401
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:09:46.990613
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars


# Generated at 2022-06-21 01:09:48.165754
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-21 01:09:59.098765
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    current_role_path = '/Users/dawid/ansible/ansible/test_data/sanity/roles/role_include'
    data = {'role': 'foo', 'tasks': 'main.yml'}
    loader_mock = 'loader_mock'
    play_mock = 'play_mock'
    collection_list_mock = 'collection_list_mock'
    variable_manager_mock = 'variable_manager_mock'
    ri = RoleInclude(play=play_mock, role_basedir=current_role_path, variable_manager=variable_manager_mock, loader=loader_mock, collection_list=collection_list_mock)
    assert ri.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-21 01:10:00.922163
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-21 01:10:03.743080
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri

# Generated at 2022-06-21 01:10:37.973235
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.cli import CLI
    import ansible.const

# Generated at 2022-06-21 01:10:39.574065
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()

    assert ri.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-21 01:10:41.959509
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    (Unit Test) test the method load of class RoleInclude
    """

    role_include = RoleInclude()
    print(role_include)

# Generated at 2022-06-21 01:10:53.378208
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    data = ['role1']
    role = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert type(role) == RoleRequirement
    assert role._role_name == 'role1'
    assert role._role_path == None
    assert role._role_path == None
    assert role._role_params == None

    data = [{'role' : 'role1'}]
    role = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert type(role) == RoleInclude

# Generated at 2022-06-21 01:11:03.570453
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test case to test the loading of role definition
    """

    # Create a role and a parent role
    r = RoleRequirement()
    r.role_name = 'test'
    r.role = RoleDefinition(role_name='test')
    parent_role = RoleRequirement()
    parent_role.role_name = 'test'
    parent_role.role = RoleDefinition(role_name='test')

    # Create a variable manager to test the loading
    vm = MagicMock()
    vm.get_vars.return_value = {}

    # Test load with null data
    ri = RoleInclude()
    assert ri.load(None, None, None, None, vm) is None

    # Test load with string data
    ri = RoleInclude()

# Generated at 2022-06-21 01:11:04.821222
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:11:11.795735
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    import ansible.constants as C
    import os
    import os.path
    import sys

    p = Play().load(dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [
            'somewhere/somerole',
            dict(
                name = 'myrole',
                something = 'test',
                tasks = [
                    dict(action=dict(module='shell', args='whoami')),
                ],
            ),
        ],
    ), variable_manager=None, loader=None)

    pb_dir=os.path.dirname(sys.modules['ansible.playbook'].__file__)
    C.DEFAULT_ROL

# Generated at 2022-06-21 01:11:22.952340
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from collections import namedtuple
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader

    # input data
    test_input = {"include_role": {"name": "foo"}}

    # role_path
    role_path = "/home/foo/include_role/include_role.yml"

    # current_role_path

# Generated at 2022-06-21 01:11:28.266442
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    vars = {"var1": "value1", "var2": "value2"}
    ri = RoleInclude("test_role", vars)
    assert(ri.is_meta() == False)
    assert(ri.is_import_role() == False)
    assert(ri.is_role() == True)
    assert(ri.role_name == "test_role")
    assert(ri.vars == vars)

# Generated at 2022-06-21 01:11:37.696942
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    The constructor of class RoleInclude should check that data is a string, a dictionary or a AnsibleBaseYAMLObject
    :return:
    """
    # Check that not passing the right parameters raise an exception
    data = ['item1', 'item2']
    try:
        ri = RoleInclude.load(data=data, play="", variable_manager="", loader="", collection_list="")
    except Exception as e:
        assert type(e) == AnsibleParserError and "Invalid role definition" in to_native(e)

    # Check that a string raises an exception
    data = "string"
    try:
        ri = RoleInclude.load(data=data, play="", variable_manager="", loader="", collection_list="")
    except Exception as e:
        assert type(e) == Ansible

# Generated at 2022-06-21 01:12:31.197319
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri,  RoleInclude)
    assert isinstance(ri,  RoleDefinition)

# Generated at 2022-06-21 01:12:40.452600
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.role.definition import RoleDefinition

    import os
    import json
    import sys


    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_file

# Generated at 2022-06-21 01:12:49.283438
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    Test load and load_data methods of class RoleInclude
    '''
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleParserError
    from collections import namedtuple
    import pytest

    # Set up a test playbook
    loader = DataLoader()
    options = namedtuple('Options', ['connection', 'module_path', 'become', 'become_method', 'become_user', 'check', 'listhosts', 'listtasks', 'listtags', 'syntax'])
    options = options('local', '', False, '', '', False, False, False, False, False)

# Generated at 2022-06-21 01:12:59.025946
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import random
    import string
    import copy
    import unittest
    from ansible.plugins.loader import write_copy_tree

    from ansible.module_utils.six import PY3
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class TestRoleInclude(unittest.TestCase):
        def setUp(self):
            self.loader = DataLoader()
            self.variable_manager = VariableManager()
            self.inventory_manager = InventoryManager(loader=self.loader, sources=None, variable_manager=self.variable_manager)

# Generated at 2022-06-21 01:13:03.055459
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # define a data
    data = {'role_name': 'test'}
    play = RoleInclude.load(data, data)
    assert play.name == 'test'
    assert play.role_basedir == None
    assert play.variable_manager == None
    assert play.loader == None

# Generated at 2022-06-21 01:13:04.105631
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.role.requireme

# Generated at 2022-06-21 01:13:15.258206
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Load class roleinclud and test method load
    from ansible.parsing.dataloader import DataLoader
    def _load_data_from_file(name, *args, **kwargs):
        pass
    def _load_data_from_mixed_args(name, *args, **kwargs):
        pass
    def get_basedir(self):
        return './'
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.cli.arguments import options

# Generated at 2022-06-21 01:13:23.607242
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = dict()
    data['name'] = 'test_name'
    data['vars'] = dict()
    data['vars']['var1'] = "hello"
    data['vars']['var2'] = "world"
    data['vars']['var3'] = dict()
    data['vars']['var3']['var4'] = "test"
    data['tasks'] = dict()
    data['tasks']['task1'] = dict()
    data['tasks']['task1']['action'] = dict()
    data['tasks']['task1']['action']['module'] = "echo"
    data['tasks']['task1']['action']['args'] = dict()

# Generated at 2022-06-21 01:13:29.668887
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.playbook.role.include import RoleInclude
    assert issubclass(RoleInclude, RoleDefinition)
    assert RoleInclude.__doc__

    data = (
        "role_name"
        ,"name: role_name"
        ,"- name: role_name"
        ,"name: role_name, foo: bar, baz: zar"
    )

    class test_obj():
        def __init__(self, data, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None):
            e = None

# Generated at 2022-06-21 01:13:31.544956
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri


RoleInclude._load = RoleInclude.load