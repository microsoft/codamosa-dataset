

# Generated at 2022-06-21 01:03:41.392770
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class TestClass():
        def __init__(self, play=None, role_basedir=None, loader=None):
            self.variable_manager = None
            self.loader = None

    TestClass = TestClass()
    TestClass.variable_manager = 'None'
    TestClass.loader = None
    result = RoleInclude.load(data='', play=TestClass, variable_manager='None', loader=None)
    assert isinstance(result, RoleInclude)
    assert result.play == TestClass
    assert result.variable_manager == 'None'


# Generated at 2022-06-21 01:03:54.226875
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create an instance of class AnsibleParserError with argument s
    arg0 = AnsibleParserError('Invalid role definition: %s')
    # Create an instance of class AnsibleError with argument s
    arg1 = AnsibleError('Invalid old style role requirement: %s')
    # Create an instance of class RoleInclude with arguments play, variable_manager, and loader
    arg2 = RoleInclude(play, variable_manager, loader)
    try:
        # Call method load of class RoleInclude with arguments data, play, variable_manager, and loader
        ret = RoleInclude.load(data, play, variable_manager, loader)
    except AnsibleParserError as e:
        # Compare exception e with arg0
        assert(type(e) == type(arg0))

# Generated at 2022-06-21 01:04:01.560526
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "test_role"
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

# Generated at 2022-06-21 01:04:02.424307
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:04:09.837515
# Unit test for method load of class RoleInclude

# Generated at 2022-06-21 01:04:16.365714
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 01:04:20.282726
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("RoleInclude")
    testInclude = RoleInclude()
    assert testInclude.__class__.__name__ == 'RoleInclude'


# Generated at 2022-06-21 01:04:21.073810
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:04:27.870989
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Arrange
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    my_data = {
        "role_name": "r_name"
    }
    # Act
    ri = RoleInclude.load(data=my_data, play=play, current_role_path=current_role_path, parent_role=parent_role,
            variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    my_role_name = ri._role_name
    # Assert
    assert my_role_name == "r_name"
    assert ri._play == play
    assert ri._delegate_to == None
    assert ri._delegate_facts == False

# Generated at 2022-06-21 01:04:39.262317
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_data1 = {'name': 'myRole'}
    test_data2 = {'name': 'myRole2', 'tags': ['myTag'], '_delegate_to': 'myDelegate', '_delegate_facts': True}
    test_data3 = {'name': 'myRole3', 'tags': False,
        'vars': {'var1': 'value1', 'var2': 'value2'}}
    role1 = RoleInclude.load(test_data1, None)
    role2 = RoleInclude.load(test_data2, None)
    role3 = RoleInclude.load(test_data3, None)
    assert (role1.get_name() == 'myRole')
    assert (role2.get_name() == 'myRole2')

# Generated at 2022-06-21 01:04:45.934030
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = Play()
    ri = RoleInclude(play=play)
    assert ri.loader == 'unset'
    assert not hasattr(ri, 'name')


# Generated at 2022-06-21 01:04:58.567947
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    play_context = PlayContext()
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../plugins/action'))
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../plugins/cache'))
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../plugins/connection'))

# Generated at 2022-06-21 01:05:09.445209
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_from_file("test/inventory"))
    context = PlayContext()


# Generated at 2022-06-21 01:05:16.171489
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import get_all_plugin_loaders

    PLUGIN_LOADERS = get_all_plugin_loaders()

    data = {'name': 'role1', 'tasks': []}
    play = Play().load(data, variable_manager=None, loader=PLUGIN_LOADERS)
    current_role_path = '/home/xyz/roles'
    variable_manager = 'variable_manager'
    loader = 'loader'
    collection_list = 'collection_list'

    # Test with string_types
    role = 'role1'

# Generated at 2022-06-21 01:05:18.272295
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Functional test for method load of class RoleInclude

# Generated at 2022-06-21 01:05:26.576734
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = dict(hosts=['localhost'], gather_facts='no')
    play['vars'] = dict()
    play['vars']['a'] = 'a'
    play['vars']['b'] = 'b'
    ri = RoleInclude(play=play, role_basedir='/', variable_manager=None, loader=None, collection_list=None)
    assert ri.name == None

# Generated at 2022-06-21 01:05:39.995388
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import role_loader

# Generated at 2022-06-21 01:05:51.455440
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    res = ri.load('- name: foo\n  tasks:\n  - name: task 1\n    command: echo hello')
    assert isinstance(res, RoleInclude)
    assert res.get_name() == 'foo'
    assert res._tasks[0]['name'] == 'task 1'
    assert res._tasks[0]['command'] == 'echo hello'

    res = ri.load('foo,1.2')
    assert res.get_name() == 'foo'
    assert res.get_role_path() == 'foo'
    assert res.get_version() == '1.2'
    assert res._tasks == []

    with pytest.raises(AnsibleError):
        res = ri.load('foo')


# Generated at 2022-06-21 01:05:59.027882
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    #test__init__
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri is not None

    #test__init__all_params
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri is not None

#Unit test for method load() inside class RoleInclude

# Generated at 2022-06-21 01:06:11.200199
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    role_include = RoleInclude()
    role_include._attributes['role'] = "apache"
    role_include._attributes['private'] = True

    assert type(role_include.role) == Attribute
    assert role_include.role.default is None
    assert role_include.role.name == "role"
    assert role_include.role.value == "apache"

    assert type(role_include.private) == Attribute
    assert role_include.private.default is None
    assert role_include.private.name == "private"
    assert role_include.private.value == True

    role_include._attributes['role'].value = "cron"

# Generated at 2022-06-21 01:06:17.380014
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude()
    print(roleInclude)

# Generated at 2022-06-21 01:06:18.457678
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-21 01:06:19.203570
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # FIXME: write tests
    assert 0

# Generated at 2022-06-21 01:06:20.167475
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude()
    assert roleInclude is not None

# Generated at 2022-06-21 01:06:21.213830
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include_instance = RoleInclude()

# Generated at 2022-06-21 01:06:21.914328
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:06:24.665487
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-21 01:06:31.338939
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Loads should fail if parameters are invalid
    """
    import sys

    ri = RoleInclude()

    # Parameter 2 play:
    try:
        ri.load([], [])
        assert False
    except AssertionError:
        pass
    except:
        exc_info = sys.exc_info()
        assert False, exc_info[0]

    # Parameter 3 current_role_path:

# Generated at 2022-06-21 01:06:39.177629
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    data = 'test_role'
    current_role_path = '/'
    variable_manager = None
    loader = None
    play = None
    parent_role = False

    role_obj = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)
    assert role_obj is not None
    assert role_obj.name == data

# Generated at 2022-06-21 01:06:39.611915
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:06:57.964319
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None
    assert ri._play is None
    assert ri._role_basedir is None
    assert ri._delegate_to is None
    assert ri._delegate_facts is False
    assert ri._variable_manager is None
    assert ri._loader is None
    assert ri._collection_list is None
    assert ri._role_params is not None
    assert len(ri._role_params) == 0


# Generated at 2022-06-21 01:07:09.199092
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class Data(object):
        pass

    data = Data()
    data.name = 'test'
    data.parent = None
    data.collection_list = {}
    data.loader = None
    data.variable_manager = None
    data.vault_errors = 'ignore'

    play = RoleInclude(play=data, role_basedir='test_case',
                       variable_manager='test', loader=data.loader,
                       collection_list=data.collection_list)
    assert play._play is data
    assert play._role_basedir == 'test_case'
    assert play._variable_manager == 'test'
    assert play._loader is data.loader
    assert play._collection_list is data.collection_list

    assert play.name == 'test'
    assert play.tasks == []
    assert play.hand

# Generated at 2022-06-21 01:07:10.802589
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include is not None

# Generated at 2022-06-21 01:07:11.593124
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:07:12.289864
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()

# Generated at 2022-06-21 01:07:13.192635
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert issubclass(RoleInclude, RoleDefinition)

# Generated at 2022-06-21 01:07:24.027770
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test load() when a role_definition is defined as string.
    """
    from ansible.playbook import Play
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar

    play = Play()
    play._variable_manager = VariableManager()
    play._loader = DataLoader()
    play._loader._basedir = './'
    play._hostvars = {
        'host1': {}
    }
    play._variable_manager.set_host_variable('host1', 'ansible_delegate_to', 'node1')
    template = Templar(loader=play._loader, variables=play._variable_manager.get_vars(play=play))

    role_definition = "test-role"
    current_role_

# Generated at 2022-06-21 01:07:34.390591
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import load_plugin_whitelist
    from ansible.plugins.strategy import ActionModule
    from ansible.plugins.strategy.linear import LinearStrategy
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-21 01:07:35.293793
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False


# Generated at 2022-06-21 01:07:44.866381
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['./hosts'])
    variable_manager.set_inventory(inventory)

    context = PlayContext()
    context.CLIARGS = {}
    context.vars = {}

# Generated at 2022-06-21 01:08:13.168931
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(env=dict(ANSIBLE_ROLES_PATH='/etc/ansible/roles')))

    # test with a string containing a role name and a variable
    obj = RoleInclude.load("{{role_name}}", play=None, variable_manager=variable_manager, loader=None, collection_list=None)

    assert str(obj) == '/etc/ansible/roles/{{role_name}}'
    assert obj._role_name == '{{role_name}}'
    assert obj._role_path == '/etc/ansible/roles/{{role_name}}'

# Generated at 2022-06-21 01:08:15.043428
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    print(ri)


# Generated at 2022-06-21 01:08:26.435473
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import fragment_loader
    from ansible.utils.display import Display
    import ansible.constants as C

    display = Display()
    variable_manager = VariableManager()

    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()
    fragment_loader.add_directory(loader, os.path.join(C.DEFAULT_ROLES_PATH, 'test_role'))
    fragment_loader.add_directory(loader, os.path.join(C.DEFAULT_ROLES_PATH, 'test_subrole'))
    options = Options()


# Generated at 2022-06-21 01:08:34.843116
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'ansible.builtin.succeed'
    play = "some_play"
    current_role_path = "some_path"
    parent_role = None
    variable_manager = "some_var_man"
    loader = "some_loader"
    collection_list = "some_collection"

    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-21 01:08:46.217795
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host, Group
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-21 01:08:47.817677
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri


# Generated at 2022-06-21 01:08:56.285085
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    pb = PlaybookExecutor('test', playbook_paths=['constructor_role_include.yml'])
    host = Host('localhost')
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager.get_vars(host=host, include_hostvars=True)
    variable_manager.set_host_variable(host, 'ansible_connection', 'local')
    variable_manager.set_host_variable

# Generated at 2022-06-21 01:09:07.220268
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    obj = RoleInclude()
    data = '''
    name: dummy
    '''
    ri = RoleInclude.load( data=data, play=None, current_role_path='/home', parent_role=None, variable_manager=None, loader=None, collection_list=None )
    assert ri.get_name() == 'dummy'

    # load_data() of class RoleRequirement is indirectly tested
    data = '''
    repo: https://github.com/myorg/myrole
    ref: v1.0
    '''
    ri = RoleInclude.load( data=data, play=None, current_role_path='/home', parent_role=None, variable_manager=None, loader=None, collection_list=None )

# Generated at 2022-06-21 01:09:16.972198
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    play_context = PlayContext()
    inventory = InventoryManager()
    variable_manager = VariableManager()

    role_definition = RoleDefinition()

    role_definition.name = "test"
    role_definition.description = "test"
    role_definition.default_vars = []
    role_definition.max_loop = 0
    role_definition.vars_prompt = []
    role_definition.tags = []
    role_definition.tasks = []
    role_definition.handlers = []
    role_definition.meta = []
    role_definition.pre_tasks = []
    role_definition.post_tasks = []


# Generated at 2022-06-21 01:09:27.000922
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = 'test'
    play = {'hosts': 'test'}
    current_role_path = 'test'
    parent_role = 'test'
    variable_manager = {'hosts': 'test'}
    loader = {'hosts': 'test'}
    collection_list = {'hosts': 'test'}

    ri = RoleInclude.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-21 01:10:13.697467
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    current_role_path = "path/to/role"
    play = None
    variable_manager = None
    loader = None
    collection_list = None

    # test_load_with_string(current_role_path, play, variable_manager, loader, collection_list)

    # test_load_with_dict(current_role_path, play, variable_manager, loader, collection_list)

    # test_load_with_object(current_role_path, play, variable_manager, loader, collection_list)

    # test_with_invalid_data(current_role_path, play, variable_manager, loader, collection_list)


# Generated at 2022-06-21 01:10:24.720015
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor


# Generated at 2022-06-21 01:10:27.579122
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-21 01:10:35.503738
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # AssertionError: Invalid old style role requirement: only_role
    # with pytest.raises(AnsibleError):
    #     RoleInclude.load(data="only_role", play=None, current_role_path=None, parent_role=None,
    #                      variable_manager=None, loader=None, collection_list=None)
    # AssertionError: Invalid old style role requirement: role1,role2
    # with pytest.raises(AnsibleError):
    #     RoleInclude.load(data="role1,role2", play=None, current_role_path=None, parent_role=None,
    #                      variable_manager=None, loader=None, collection_list=None)
    pass

# Generated at 2022-06-21 01:10:36.332553
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:10:37.395565
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-21 01:10:46.872747
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import callback_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    data = """- name: myrole
  hosts: localhost
  tasks:
   - include_role:
       name: myrole"""
    play_context = PlayContext()
    play_context.remote_addr = "10.0.0.1"
    variable_manager = VariableManager()
    loader = DataLoader()
    callback_plugins = callback_loader.get_all_plugins(play_context)
    collection_list = []

    ri = RoleInclude.load(data, play_context, variable_manager, loader, collection_list)
    print(ri)

# Generated at 2022-06-21 01:10:56.638477
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = '''
- name: apache
  hosts: all
  become: true
  vars:
    http_port: 80
    max_clients: 200
  roles:
    - role: common
    - role: webapp
      vars:
        do_frontend: yes
      delegate_to: localhost
      delegate_facts: yes
    - { role: database, become: false }
    - { role: webservers, tags: [ 'frontend' ] }
- name: ntp
  hosts: ntp_servers
  roles:
    - { role: common }
    - { role: ntp, ntp_user: bob }
'''

# Generated at 2022-06-21 01:11:06.867308
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def test_data_load(play, role_basedir):
        variable_manager = VariableManager()
        variable_manager.set_inventory(Inventory(loader=None, variable_manager=None, host_list=['localhost']))
        ri = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=None, collection_list=None)
        return ri.load_data('geerlingguy.pip', variable_manager=variable_manager, loader=None)

    hostvars = dict(ansible_distribution='Debian', ansible_distribution_major_version='8')

# Generated at 2022-06-21 01:11:07.985220
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-21 01:12:24.058838
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include.get_name() is None

# Generated at 2022-06-21 01:12:34.242558
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ''' test the load method of RoleInclude class
    '''
    import sys
    import os
    import tempfile
    import shutil

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory

# Generated at 2022-06-21 01:12:42.697310
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.play is None
    assert ri.role_basedir is None
    assert ri.variable_manager is None
    assert ri.files is None
    assert ri.loader is None
    assert ri.collection_list is None
    assert ri.name is None
    assert ri.module_args is None
    assert ri.module_vars is None
    assert ri.module_inline is None
    assert ri.when is None
    assert ri.async_val is None
    assert ri.poll is None
    assert ri.sudo is None
    assert ri.sudo_user is None
    assert ri.tags is None
    assert ri.run_once is None
    assert ri.ignore_errors is None

# Generated at 2022-06-21 01:12:44.028592
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test creation of RoleInclude object
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:12:45.266396
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()
    assert ri != None

# Generated at 2022-06-21 01:12:51.559878
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'test.role'
    play = 'test'
    current_role_path = 'test'
    parent_role = 'test'
    variable_manager = 'test'
    loader = 'test'
    collection_list = 'test'

    expected = True

    result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    actual = isinstance(result, RoleInclude)

    assert expected == actual

# Generated at 2022-06-21 01:12:54.872090
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass
    # TODO: add example test(s)
    # assert True

# Generated at 2022-06-21 01:12:59.511870
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    collection_list = None
    variable_manager = None
    loader = DataLoader()
    play = Play.load(dict(name="test"), variable_manager, loader, collection_list)
    ri = RoleInclude(play=play)
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-21 01:13:05.512120
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    if not (isinstance(data, string_types) or isinstance(data, dict) or isinstance(data, AnsibleBaseYAMLObject)):
        raise AnsibleParserError("Invalid role definition: %s" % to_native(data))

    if isinstance(data, string_types) and ',' in data:
        raise AnsibleError("Invalid old style role requirement: %s" % data)

    ri = RoleInclude()
    return ri.load_data(data)

# Generated at 2022-06-21 01:13:07.982494
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude()
    assert roleInclude is not None