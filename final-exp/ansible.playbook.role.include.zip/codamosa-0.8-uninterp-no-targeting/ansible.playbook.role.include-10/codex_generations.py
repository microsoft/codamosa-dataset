

# Generated at 2022-06-21 01:03:43.525979
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.module_utils.six import BytesIO

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader

    def get_play_context(loader):
        loader.load_plugin_filters()
        variable_manager = VariableManager()
        inventory = InventoryManager(loader=loader, sources='localhost,')
        variable_manager.set_inventory(inventory)
        play_context = PlayContext()
        return variable_manager, play_context

    loader = DataLoader()
    variable_manager, play_context = get_play_context(loader)

# Generated at 2022-06-21 01:03:44.352679
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:03:46.809602
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include is not None
    assert role_include._role_path is None

# Generated at 2022-06-21 01:03:50.482490
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    pl = PlayContext()
    lo = DataLoader()
    inv = InventoryManager()
    var = VariableManager()
    collection_list = None
    current_role_path = None
    parent_role = None

    test_data_str = 'test'
    test_data_dict = {'test': 'test'}
    test_data_AnsibleBaseYAMLObject = AnsibleBaseYAMLObject()

    role_include = RoleInclude.load(test_data_str, pl, current_role_path, parent_role, var, lo, collection_list)

# Generated at 2022-06-21 01:03:56.706770
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # create variable manager
    variable_manager = VariableManager()

    # create data
    data = dict()
    data.update({'role_name': 'test'})
    data.update({'role_name_1': 'test'})
    data.update({'role_name_2': 'test'})

    # create role include
    ri = RoleInclude()

    # test of load_data
    assert ri.load(data, variable_manager.extra_vars) == ri
    assert ri.role_name == 'test'

    # test of load
    assert RoleInclude.load(data, None, variable_manager=variable_manager.extra_vars) == ri

# Generated at 2022-06-21 01:04:02.109528
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert role
    from ansible.playbook.play import Play
    play = Play().load('roles: [ { role: other_role } ]')
    role = RoleInclude()
    assert role

# Generated at 2022-06-21 01:04:04.159130
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)


# Generated at 2022-06-21 01:04:16.343199
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import os

    role_constructor_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..', 'playbooks', 'delegation.yml')
    with open(role_constructor_path) as role_constructor_fd:
        role_constructor_data = role_constructor_fd.read()
    data = {
            "delegate_to": "localhost",
            "delegate_facts": True,
            "roles": [
                      "dummy_role_name"
                      ],
            "tasks": [
                      {
                       "name": "dummy_task_name",
                       "debug": {
                                 "var": "dummy_var_name"
                                 }
                       }
                      ]
            }


# Generated at 2022-06-21 01:04:26.148585
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Given
    data = {'name': 'test_role', 'role_name': 'test_role'}
    from ansible.playbook import Play
    play = Play()
    current_role_path = '/etc'
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    # When
    role_include = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    # Then
    assert role_include.get_name() == 'test_role'
    assert role_include.get_role_name() == 'test_role'

# Generated at 2022-06-21 01:04:28.801907
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # This is a test of constructor.
    roleInclude = RoleInclude()
    assert roleInclude