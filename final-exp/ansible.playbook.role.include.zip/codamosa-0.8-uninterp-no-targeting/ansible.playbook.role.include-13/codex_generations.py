

# Generated at 2022-06-21 01:03:43.718393
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.module_utils.six import PY3

    p = Play().load({'hosts': 'all',
                     'roles': [{'role': 'common'},
                               {'role': 'webservers', 'foo': 'bar'}]},
                    variable_manager=None, loader=None)
    assert isinstance(p, Play)
    r = p.get_roles()
    assert len(r) == 2
    assert r[0].get_name() == 'common'
    assert r[0].get_path() is not None
    assert r[1].get_name() == 'webservers'
    if PY3:
        if isinstance(r[1].get_role_params(), dict):
            assert r[1].get_

# Generated at 2022-06-21 01:03:54.942855
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    loader.set_basedir(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, os.pardir))
    play = Play()
    pm = VariableManager()
    play.variable_manager = pm
    play.variable_manager.set_loader(loader)
    play.variable_manager.set_fact_cache({})
    play.variable_manager.extra_vars = pm.get_vars()


# Generated at 2022-06-21 01:04:06.861265
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.parsing.yaml.data import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactModule
    import ansible.module_utils.facts as module_utils_facts
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.collection import get_file_contents
    from ansible.module_utils.facts import get_module_path


# Generated at 2022-06-21 01:04:07.943695
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:04:15.163094
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources="localhost,"))
    hostvars = variable_manager.get_vars(play=None, host=None, include_hostvars=True)
    block = Block

# Generated at 2022-06-21 01:04:22.300180
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    if __name__ == '__main__':
        import os
        import sys

        try:
            from __main__ import display
        except ImportError:
            from ansible.utils.display import Display
            display = Display()

        test_vm = VariableManager()
        test_loader = DataLoader()

        test_play = Play.load(dict(
            name = "Test Play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        ), variable_manager=test_vm, loader=test_loader)

        # Test default constructor
        test_role_include = RoleIn

# Generated at 2022-06-21 01:04:23.786157
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    x = RoleInclude()
    assert isinstance(x, RoleInclude)

# Generated at 2022-06-21 01:04:27.198982
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Test class RoleInclude
    """

    print("Test RoleInclude class")


# Generated at 2022-06-21 01:04:31.066505
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    try:
        ri = RoleInclude()
    except:
        assert False, "RoleInclude object creation failed"
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-21 01:04:39.025097
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {'name':'Dummy', 'hosts': 'all'}
    variable_manager = 'abc'
    loader = 'xyz'
    role_basedir = 'pqr'
    collection_list = ['aws', 'ansible.builtin']
    ri = RoleInclude('play', role_basedir, variable_manager, loader, collection_list)
    ri.load_data(data, variable_manager, loader)
    assert data['name'] == ri.get_name()
    hosts = ri.get_hosts()
    assert hosts[0] == 'all'

# Generated at 2022-06-21 01:04:51.070700
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Every role definition requires a playbook that includes them.
    # Let's create a dummy playbook for our role.
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play_ctx = PlayContext()
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=None, loader=None)

    # Create a fake role path to load the test data.
    test

# Generated at 2022-06-21 01:05:00.847166
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


    loader = DictDataLoader({
        "a:b:c:d:e:f:g:defaults/main.yml": "var1: value1",
        "a:b:c:d:e:f:g:tasks/main.yml": "",
    })


# Generated at 2022-06-21 01:05:04.546184
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Testcase for RoleInclude.load()
    """
    ri = RoleInclude.load(data="redhat.yum")
    assert ri is not None

# Generated at 2022-06-21 01:05:06.013007
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-21 01:05:18.378874
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Constructor without any arguments
    ri1 = RoleInclude()

    assert ri1.role_name is None
    assert ri1.role_path is None
    assert ri1.role_collection is None
    assert ri1.role_collection_name is None
    assert ri1.role_collection_namespace is None
    assert ri1.role_collection_version is None
    assert ri1.role_basedir is None
    assert ri1.filter_spec is None
    assert ri1.play is None
    assert ri1.variable_manager is None
    assert ri1.loader is None
    assert ri1.collection_list is None
    assert ri1.role_vars is None
    assert ri1.role_params is None

# Generated at 2022-06-21 01:05:23.244745
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass


RoleDefinition.add_type('role', RoleInclude)
RoleDefinition.add_type('include', RoleInclude)
RoleRequirement.ROLE_REQUIREMENT_TYPES.append('role')

# Generated at 2022-06-21 01:05:32.048908
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            dict(role=dict(role_name=['foo', 'bar'])),
            'unittest_role'
        ]
    )
    play = Play.load(play_source, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:05:32.897096
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()
    assert(ri) is not None

# Generated at 2022-06-21 01:05:37.896233
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    ri.__dict__.get('_dependent_roles')[0].tasks.append('unit test')
    assert ri.__dict__.get('_dependent_roles')[0].tasks[0] == 'unit test'


# Generated at 2022-06-21 01:05:50.172667
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.plays.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.six import string_types
    from copy import deepcopy

# Generated at 2022-06-21 01:05:59.613522
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = ""
    play = ""
    current_role_path = ""
    parent_role = ""
    variable_manager = ""
    loader = ""
    collection_list = ""

    data = {"hosts":'all'}
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    data = {"hosts":'x.x.x.x'}
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    data = {"hosts":'all',
            "gather_facts":'no'}
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)


# Generated at 2022-06-21 01:06:11.339328
# Unit test for method load of class RoleInclude

# Generated at 2022-06-21 01:06:19.763007
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data1 = "test_role"
    data2 = {'role': data1, 'role2': "test_role2"}
    data3 = {'name': data1, 'name2': "test_role2"}
    data4 = "role1,role2"

    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    try:
        ri = RoleInclude.load(data1, play, current_role_path, parent_role, variable_manager, loader, collection_list)
        print(ri)
    except AnsibleError as e:
        print(e)


# Generated at 2022-06-21 01:06:31.201145
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # parameter test(1)
    data = 'role1'
    play = 'play1'
    current_role_path = 'current_role_path1'
    parent_role = 'parent_role1'
    variable_manager = 'variable_manager1'
    loader = 'loader1'
    collection_list = 'collection_list1'
    # parameter test(2)
    data = 'roles'
    play = 'play1'
    current_role_path = 'current_role_path1'
    parent_role = 'parent_role1'
    variable_manager = 'variable_manager1'
    loader = 'loader1'
    collection_list = 'collection_list1'
    # parameter test(3)
    data = 'role.name'
    play = 'play1'
    current_role_path

# Generated at 2022-06-21 01:06:41.124168
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    current_role_path = os.path.join(os.path.dirname(__file__), '..', 'invoke')
    collection_path = os.path.dirname(current_role_path)
    variable_manager = None
    loader = None
    data = {'roles': ['role1', 'role2']}
    play = None
    ri = RoleInclude(play=play, role_basedir=current_role_path, collection_list=[collection_path], variable_manager=variable_manager, loader=loader)
    assert ri.load(data, play=play, current_role_path=os.path.dirname(__file__), parent_role=None, variable_manager=variable_manager, loader=loader, collection_list=[collection_path])

# Generated at 2022-06-21 01:06:43.616482
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class Foo(RoleInclude):
        pass
    a = Foo()
    b = Foo()
    a.some_attribute = 1
    assert a.some_attribute == b.some_attribute == 1

# Generated at 2022-06-21 01:06:48.131444
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = None
    role_basedir = None
    variable_manager = None
    loader = None
    role_include = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader)

    assert isinstance(role_include, RoleInclude)

# Generated at 2022-06-21 01:06:56.652749
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = dict(
        name='Foo',
        become_method='sudo',
        become_user='root',
        delegate_to='localhost',
        delegate_facts=True
    )

    role = RoleInclude.load(data)

    assert role.get_become_method() == 'sudo'
    assert role.get_become_user() == 'root'
    assert role.get_name() == 'Foo'
    assert role.get_delegate_to() == 'localhost'
    assert role.get_delegate_facts() == True

# Generated at 2022-06-21 01:07:03.491842
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    data = '''
    - hosts: helloworld
      roles:
        - role1
        - role2
    '''

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    play = Play().load(data, variable_manager=variable_manager, loader=loader)

    # construct a role include from a play
    role_include = RoleInclude(play=play, role_basedir=None, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 01:07:14.673447
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    group = Group('all')
    group.vars = dict(a=1)
    host = Host('test1')
    host.groups.append(group)
    inventory = InventoryManager(loader=loader, sources=[])
    inventory.add_group(group)
    inventory.add_host(host)

    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 01:07:21.178132
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:07:25.445485
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Prepare inputs and expected results
    data = ['test', 'test2']
    expected = None

    with pytest.raises(AnsibleParserError) as excinfo:
        # test function
        RoleInclude.load(data)
    assert "Invalid role definition: %s" % str(data) in str(excinfo.value)


# Generated at 2022-06-21 01:07:36.319440
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins import plugin_loader
    import os
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestRoleInclude(unittest.TestCase):

        def setUp(self):

            self.play_context = PlayContext()
            self.play_context._set_namespace = 'test'
            self.play_context.network_os = 'ios'
            self.play_context.remote_addr = '192.168.99.4'
            self.play_context.port = 22
            self.play_context.remote_user = 'ubuntu'
            self.play_context

# Generated at 2022-06-21 01:07:45.740349
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data={"name":"geerlingguy.git"}
    play={}
    current_role_path=".."
    parent_role=None
    variable_manager=None
    loader=None
    collection_list=None
    ri=RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert not ri is None
    assert ri.name == data['name']
    assert ri.play == play
    assert ri.role_basedir == current_role_path
    assert ri.parent_role == parent_role
    assert ri.variable_manager == variable_manager
    assert ri.loader == loader

    data="geerlingguy.git"
    play={}
    current_role_path=".."
    parent_

# Generated at 2022-06-21 01:07:56.751800
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.inventory import Inventory

    def test_load_string():
        ri = RoleInclude(play=Play().load(dict(name="testplay", hosts=['testhost']), variable_manager=VariableManager(), loader=DataLoader()))
        ri.load_data('/tmp/roles', variable_manager=VariableManager(), loader=DataLoader())


# Generated at 2022-06-21 01:08:08.005450
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import copy
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.yaml.loader import YAMLLoader
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars

    play_context = PlayContext()
    templar = Templar(loader=None, variables=VariableManager())

    loader = YAMLLoader()
    loader._options = copy.deepcopy(loader.DEFAULT_OPTIONS)

# Generated at 2022-06-21 01:08:12.142772
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test RoleInclude class without args
    ri = RoleInclude()
    assert ri is not None
    assert ri.__class__.__name__ == 'RoleInclude'

    # Test RoleInclude class with args
    ri = RoleInclude(play='test_play')
    assert ri is not None
    assert ri.__class__.__name__ == 'RoleInclude'
    assert ri._role_path == 'test_play'



# Generated at 2022-06-21 01:08:20.622273
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    mock_play = mock.Mock()
    mock_loader = mock.Mock()
    mock_data = mock.Mock()
    mock_data.get_vars = mock.Mock()

    new_ri = RoleInclude(play=mock_play, loader=mock_loader)
    new_ri.load_data = mock.Mock()

    new_ri.load(mock_data)
    assert new_ri.load_data.call_count == 1
    '''

    pass

# Generated at 2022-06-21 01:08:30.099255
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class MockLoader(object):
        pass

    class MockRoleBasedir(object):
        pass

    class MockVariableManager(object):
        pass

    class MockPlay(object):
        pass

    class MockCollectionList(object):
        pass

    play = MockPlay()
    collection_list = MockCollectionList()
    variable_manager = MockVariableManager()
    role_basedir = MockRoleBasedir()
    loader = MockLoader()

    roleDef = RoleInclude(play, role_basedir, variable_manager, loader, collection_list)
    ri = RoleInclude.load('test', play=play, current_role_path=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    assert isinstance(ri, RoleInclude)


RoleRequirement.ROLE_

# Generated at 2022-06-21 01:08:42.172133
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri._play == None
    assert ri._role_basedir == None
    assert ri._variable_manager == None
    assert ri._loader == None
    assert ri._role_path == None
    assert ri._metadata_path == None
    assert ri._task_blocks == None
    assert ri._handlers == None
    assert ri._default_vars == None
    assert ri._task_vars == None
    assert ri._include == None
    assert ri._include_role == None
    assert ri._include_tasks == None
    assert ri._include_vars == None
    assert ri._prepare_blocks == None
    assert ri._name == None
    assert ri._private == False

# Generated at 2022-06-21 01:08:54.876127
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-21 01:08:56.614436
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Create object of class RoleInclude
    ri = RoleInclude()
    assert ri != None

# Generated at 2022-06-21 01:08:58.759751
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None)

# Generated at 2022-06-21 01:09:09.564187
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    ri.load("foo,bar")
    ri.load("geerlingguy.nginx")
    ri.load("geerlingguy.nginx,var=value")
    ri.load("geerlingguy.nginx,var=value,tags=tag1")
    ri.load("geerlingguy.nginx,tags=tag1,var=value")
    ri.load({'geerlingguy.nginx': None})
    ri.load({'geerlingguy.nginx': {'var': 'value'}})
    ri.load({'geerlingguy.nginx': {'var': 'value', 'tags': 'tag1'}})

# Generated at 2022-06-21 01:09:16.827847
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play

    play = Play()
    data = '''
- hosts: localhost
  roles:
    - role: myrole
'''
    data = load_data(data)
    role = RoleInclude.load(data, play)
    print(role.get_vars())
    print(role.get_files())
    print(role.get_handlers())
    print(role.get_meta())
    print(role.get_tasks())
    print(role.get_setup_tasks())
    print(role.get_task_blocks())


# Generated at 2022-06-21 01:09:22.590117
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test init
    role_include = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert isinstance(role_include, RoleInclude)
    assert(role_include._delegate_to == None)
    assert(role_include._delegate_facts == False)

# Generated at 2022-06-21 01:09:33.410366
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources="/dev/null")
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play = Play.load({
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [{'name': 'test', 'action': {'module': 'shell', 'args': 'echo "hello"'}}]
    }, variable_manager=variable_manager, loader=DataLoader())

    collection_list = [('test', ['./', './test'])]


# Generated at 2022-06-21 01:09:43.791302
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class TestPlay:
        def __init__(self):
            self.connection = 'local'
            self.variable_manager = 'variable_manager'
            self.loader = 'loader'
            self.basedir = 'test_basedir'
            self.collection_list = 'collections'

    role_include = RoleInclude(play=TestPlay())

    assert role_include.basedir == 'test_basedir'
    assert role_include.play == TestPlay()
    assert role_include.connection == 'local'
    assert role_include.variable_manager == 'variable_manager'



# Generated at 2022-06-21 01:09:44.564404
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # RoleInclude().load
    pass

# vim: set noexpandtab:

# Generated at 2022-06-21 01:09:45.002181
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert True

# Generated at 2022-06-21 01:10:10.455480
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-21 01:10:17.484236
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a PlayContext object
    context = PlayContext()

    # Create a new Play object 

# Generated at 2022-06-21 01:10:28.767423
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition

    variable_manager = VariableManager()
    loader = DataLoader()
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=variable_manager, loader=loader)
    assert isinstance(ri, Role)
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleRequirement)
    assert isinstance(ri, RoleDefinition)
    assert ri.name == ''
    assert ri.options == {}

# Generated at 2022-06-21 01:10:30.629280
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-21 01:10:31.159565
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:10:32.337263
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert not ri._role_name

# Generated at 2022-06-21 01:10:33.011447
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:10:41.404232
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import ansible.playbook.play
    import ansible.playbook.role.definition

    args = {}
    args['play'] = ansible.playbook.play.Play()
    r = ansible.playbook.role.definition.RoleDefinition()
    args['role_basedir'] = r._role_basedir
    args['variable_manager'] = r._variable_manager
    args['loader'] = r._loader

    ansible.playbook.role.include.RoleInclude(**args)

if __name__ == "__main__":
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-21 01:10:42.816429
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_definition = RoleInclude()
    assert isinstance(role_definition, RoleDefinition)

# Generated at 2022-06-21 01:10:53.716495
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.compat.tests import unittest
    from ansible.parsing.yaml.data import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    import ansible.constants as C

    class TestPlay(Play):
        name = 'test'
        roles = []

    class TestVariableManager(VariableManager):
        pass

    class TestRoleInclude(RoleInclude):

        def __init__(self, play=TestPlay(), role_basedir=C.DEFAULT_ROLES_PATH, variable_manager=TestVariableManager(), loader=DataLoader(),
                     collection_list=AnsibleCollectionRef.from_string('ansible.builtin')):
            self._play = play
            self._

# Generated at 2022-06-21 01:11:46.873140
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Test tht "load" factory method of class RoleInclude

# Generated at 2022-06-21 01:11:57.053605
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri
    assert ri._delegate_to is None
    assert not ri._delegate_facts
    assert ri._ignore_errors is False
    assert ri._loop is None
    assert ri._loop_control is None
    assert ri._no_log is False
    assert ri._loop_with is None
    assert ri._name is None
    assert ri._pause_before is None
    assert ri._tasks is None
    assert ri._until is None
    assert ri._vars is None
    assert ri._vars_files is None
    assert ri._when is None
    assert ri._always_run is False
    assert ri._changed_when is None
    assert ri._failed_when is None
    assert ri._meta

# Generated at 2022-06-21 01:12:03.497385
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from units.mock.variable_manager import VariableManager
    from units.mock.loader import DictDataLoader
    from ansible.parsing.vault import VaultSecret

    def test_data(dict1, dict2):
        for k, v in iteritems(dict1):
            if k in ('module_defaults', 'cleanup', 'post_tasks', 'handlers'):
                continue
            assert k in dict2
            if k == 'vars' or k == 'vars_files':
                assert sorted(dict1[k]) == sorted(dict2[k])
            elif isinstance(v, dict):
                test_data(dict1[k], dict2[k])
            elif k == 'any_errors_fatal' or k == 'ignore_errors':
                assert sorted(dict1[k])

# Generated at 2022-06-21 01:12:14.388235
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class Assignment(object):
        def __init__(self,value):
            self.value=value
    x=Assignment('load')
    x.role=RoleInclude()

    collection_list=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'examples', 'ansible_collections', 'example_playbook_prefix')
    collection_list = os.path.abspath(collection_list)

    x.role.load_data(data='/tmp/apb_role', variable_manager=None, loader=None)

# Generated at 2022-06-21 01:12:22.220540
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils import context_objects as co
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    with co.global_context(directive='role_include_load'):
        # setup
        loader = DataLoader()
        variable_manager = VariableManager()
        variable_manager.extra_vars = dict(a_var='bar')

# Generated at 2022-06-21 01:12:33.198883
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import play_context

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    display = Display()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    play_context.CLIARGS = dict(inventory=inventory)


# Generated at 2022-06-21 01:12:41.988091
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Unit test for method load of class RoleInclude for if isinstance(data, string_types)
    def test_load_if_data_string():
        RoleInclude.load('string', play='play', current_role_path='current_role_path', parent_role='parent_role',
                         variable_manager='variable_manager', loader='loader', collection_list='collection_list')

    # Unit test for method load of class RoleInclude for if isinstance(data, string_types) and ',' in data

# Generated at 2022-06-21 01:12:46.740465
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    role_basedir = 'tests/data/role_include'
    relative_path = '../../'
    role_name_1 = 'role1'
    role_name_2 = 'role2'
    role_name_3 = 'role3'
    role_name_4 = 'role4'
    role_name_5 = 'role5'
    role_name_6 = 'role6'
    role_name_7 = 'role7'
    role_name_8 = 'role8'
    role_name_9 = 'role9'

    # test string type data
    # 1. test valid str

# Generated at 2022-06-21 01:12:52.071369
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Constructor test:
      The object RoleInclude is instantiated as follows:
        ri = RoleInclude(play=play, role_basedir=current_role_path,
            variable_manager=variable_manager, loader=loader,
            collection_list=collection_list)
    where play and current_role_path are string and variable_manager,
    loader and collection_list are objects.
    """
    assert True

# Generated at 2022-06-21 01:13:00.421317
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
	try:
		# A valid role definition for previous version of Ansible.
		print(RoleInclude.load("role_name", None, None, None, None, None))

		# A valid role definition for ansible 2.6 with collections.
		print(RoleInclude.load("collection.role_name", None, None, None, None, None))

		# A invalid role definition for previous version of Ansible.
		print(RoleInclude.load("role_name,role_name1", None, None, None, None, None))
	except Exception as e:
		print(e)

# Invoke the method load of class RoleInclude
test_RoleInclude_load()