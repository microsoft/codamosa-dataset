

# Generated at 2022-06-21 01:03:44.522032
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import connection_loader

    inventory = InventoryManager(loader=DataLoader(), sources="127.0.0.1,")
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()
    options = None
    passwords = {}
    play_context = PlayContext(options, passwords)

# Generated at 2022-06-21 01:03:45.471013
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-21 01:03:55.002589
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from collections import namedtuple

    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.loader import AnsibleLoader

    p = Play()
    role_include = RoleInclude(play=p)

    loader = AnsibleLoader(None, variable_manager=VariableManager())

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.meta import RoleMetadata

    # Simulate a LoadedTask instance with a settings attribute in it
    LoadedTask = namedtuple('LoadedTask', ['settings'])
    LoadedTask.settings = {'defaults': {'force_handlers': True}}

    # Test

# Generated at 2022-06-21 01:04:01.025676
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor import playbook_executor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    display = Display()

# Generated at 2022-06-21 01:04:09.320853
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Constructor args play and role_basedir are not used in static function load...
    # ... so use null objects
    null_object = None

    # Test no data passed in
    try:
        RoleInclude.load(null_object, null_object, null_object, null_object, null_object, null_object)
        assert False
    except AnsibleParserError:
        assert True

    # Test non string or dict passed in
    try:
        RoleInclude.load(25, null_object, null_object, null_object, null_object, null_object)
        assert False
    except AnsibleParserError:
        assert True

    # Test string passed in and RoleRequirement.load raises an error

# Generated at 2022-06-21 01:04:10.235555
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-21 01:04:16.690282
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    ret = RoleInclude(play=None, role_basedir="", variable_manager=variable_manager, loader=loader, collection_list=None)
    assert ret is not None

# Generated at 2022-06-21 01:04:19.349660
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# --- end test_RoleInclude() ---

# Generated at 2022-06-21 01:04:20.816977
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

RoleRequirement()

# Generated at 2022-06-21 01:04:22.258011
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test = RoleInclude()
    assert test

# Generated at 2022-06-21 01:04:36.831581
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play

    # create play for testing
    play = Play().load({
        'name': 'test',
        'hosts': 'all',
        'gather_facts': 'no'
    }, variable_manager={}, loader=None)

    ri = RoleInclude(play=play, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri._load_name, Attribute)
    assert isinstance(ri._role_path, Attribute)
    assert isinstance(ri._role_name, Attribute)
    assert isinstance(ri.get_vars(), dict)

# Generated at 2022-06-21 01:04:39.146623
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.playbook.play import Play
    pb = Play()
    role = RoleInclude(play=pb)
    assert role
    assert role._play is pb
    assert role._variable_manager is None
    assert role._loader is None
    assert role._role_name is None
    assert role._collections is None
    assert role._collection_list is None

# Generated at 2022-06-21 01:04:41.901749
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    # since the constructor of RoleInclude is empty, nothing to assert

# Generated at 2022-06-21 01:04:42.756175
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:04:47.903675
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test case for RoleInclude.load

    Arguments:
    data: role variable data 
    play: play for this role include
    current_role_path: current role path
    parent_role: parent role
    variable_manager: variable manager
    loader: ansible loader
    collection_list: list of Ansible collections
    """
    pass

# Generated at 2022-06-21 01:04:59.391790
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import find_plugin_filenames

    variables = {
        'variable1': 'value 1',
        'variable2': 'value 2',
        'variable3': 'value 3',
        'variable4': 'value 4',
        'variable5': 'value 5',
    }

    pc = PlayContext()
    pc.setup_cache()
    pc.vars_cache = {}
    pc.vars_cache.update(variables)

    vm = dict()
    vm['var'] = dict()
    vm['var']['hostvars'] = dict()
    vm['var']['hostvars']['fake_host'] = dict()
    vm['var']['hostvars']['fake_host'].update

# Generated at 2022-06-21 01:05:00.572727
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:05:05.687100
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {'role': 'test_role'}
    ri = RoleInclude()
    ri.load_data(data)
    assert ri._role_name == 'test_role'
    assert ri._role_path == 'test_role'

# Generated at 2022-06-21 01:05:07.678688
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude();
    assert ri != None



# Generated at 2022-06-21 01:05:16.606731
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    with pytest.raises(AnsibleError) as excinfo:
        RoleInclude.load('role,version', object)
    assert 'Invalid old style role requirement' in excinfo.value.message
    assert excinfo.value.obj is 'role,version'

    with pytest.raises(AnsibleParserError) as excinfo:
        RoleInclude.load(None, object)
    assert 'Invalid role definition: None' in excinfo.value.message
    assert excinfo.value.obj is None

# Generated at 2022-06-21 01:05:31.961483
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import find_plugin
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager.set_inventory(inventory)

    host = inventory.get_host(host)

# Generated at 2022-06-21 01:05:34.264436
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:05:43.114126
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['localhost', 'otherhost']))
    variable_manager.extra_vars = {'hostvars': {'otherhost': {'ansible_connection': 'local'}}}
    playcontext = PlayContext()


# Generated at 2022-06-21 01:05:45.222662
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data_string = "string"
    data_dictionary ={'name':'test'}
    data_AnsibleBaseYAMLObject = AnsibleBaseYAMLObject()
    assert RoleInclude(data_string)
    assert RoleInclude(data_dictionary)
    assert RoleInclude(data_AnsibleBaseYAMLObject)

# Generated at 2022-06-21 01:05:45.920883
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:05:49.675168
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    collection_list = ['/etc/ansible/collections']
    ri = RoleInclude(variable_manager=None, loader=None, collection_list=collection_list)


# Generated at 2022-06-21 01:05:59.875481
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    import unittest
    import ansible.playbook.role.include as role_include
    import ansible.playbook.role.definition as role_definition

    class TestRoleInclude(unittest.TestCase):

        def setup_method(self, method):

            self.role_include = role_include.RoleInclude()
            self.role_definition = role_definition.RoleDefinition()

        def test_def_constructor(self):

            self.assertEqual(self.role_include.__class__.__name__, 'RoleInclude')
            self.assertEqual(self.role_definition.__class__.__name__, 'RoleDefinition')


# Generated at 2022-06-21 01:06:05.915006
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test constructor of class RoleInclude when it is called without agruments

    # When called without agruments
    # RoleInclude is created
    # This function returns 1 when RoleInclude is created
    assert RoleInclude()

# Test method load of class RoleInclude

# Generated at 2022-06-21 01:06:15.734037
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # When data is a string
    play = Play().load({
        'name': "Ansible Playbook",
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'action': {'module': 'setup'}},
            {'action': {'module': 'command', 'args': 'id'}},
            {'include': {'name': 'run_command'}}
        ]
    }, variable_manager=None, loader=None)
    assert play.tasks[2].include.name == 'run_command'

    # When data is a dict

# Generated at 2022-06-21 01:06:22.318393
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    collection_list = []
    data = AnsibleUnsafeText('{"name":"helloworld2", "included_var":"value2"}')
    play = PlayContext()
    variable_manager = VariableManager()
    loader = None
    # Invoke the method with normal params
    # result = Role