

# Generated at 2022-06-21 01:03:36.353465
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:03:44.760167
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    plain_include = 'common_role'
    common_role = {
        'role': 'common_role',
        'some_attrib': "attrib_value"
    }
    expected_include = {
        'some_attrib': "attrib_value"
    }


    class FakeRoleDefinition:
        def __init__(self):
            self.attributes = dict()


    class FakeLoader:
        def load_from_file(self, filename):
            return FakeRoleDefinition()
    loader = FakeLoader()

    fake_play = object()
    fake_variable_manager = object()

    ri = RoleInclude.load(plain_include, play=fake_play, variable_manager=fake_variable_manager, loader=loader)
    assert ri.get_name() == "common_role"

   

# Generated at 2022-06-21 01:03:54.807157
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        roles=[
            dict(name='rolename', tasks=[dict(action=dict(module='shell', args='ls'))])
        ]
    )

    # instantiate needed objects
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    # actually run it
    tqm = None


# Generated at 2022-06-21 01:04:07.944583
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Unit test for class RoleInclude"""
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Test default case
    role_data = {'role': 'common'}
    play = Play()
    role_include = RoleInclude.load(role_data, play)
    assert isinstance(role_include, RoleInclude), "role_include should be instance of class RoleInclude."
    assert role_include._role_name == role_data['role'], "RoleInclude.role_name should be initialized to data['role']."

    # Test case of role data as string
    role_data = 'common'
    play = Play()
    role_include = Role

# Generated at 2022-06-21 01:04:15.162932
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader
    from ansible.template import Templar

    pc = PlayContext()

    class DummyVariableManager():
        def __init__(self):
            self.extra_vars = dict()

    class DummyLoader():
        def __init__(self):
            pass

        def load_role_definition(self, path):
            assert path == '/roles/foo.yml'
            return {'_meta': {'hostvars': {'foo': 'bar'}}}

    class DummyRoleLoader():
        def __init__(self):
            pass

        def get_role_definition(self, role_name):
            assert role_name == 'foo'

# Generated at 2022-06-21 01:04:15.590967
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:04:21.808866
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Create a RoleInclude using the constructor
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

    # Check to make sure the constructor for RoleInclude did not return None
    assert ri is not None

# Generated at 2022-06-21 01:04:25.869407
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass


# AnsibleRoleInfo as a class 
#
#   * role_root, role_name, role_path => defined in RoleDefinition
#   * role_vars
#   * role_metadata
#   * role_dependencies : loaded from META/main.yml which contains `depends` 


# Generated at 2022-06-21 01:04:38.178170
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    role_basedir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    ri = RoleInclude()
    assert ri.role_basedir == role_basedir
    ri = RoleInclude(role_basedir='/path/name')
    assert ri.role_basedir == '/path/name'
    ri = RoleInclude(role_basedir='/path/name', variable_manager=VariableManager())
    assert isinstance(ri.variable_manager, VariableManager)
    assert ri.role_based

# Generated at 2022-06-21 01:04:39.067928
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-21 01:04:51.130912
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader=loader)

    role_include = RoleInclude.load('geerlingguy.apache', role_basedir='/etc/ansible/roles', variable_manager=variable_manager, loader=loader)
    assert isinstance(role_include, RoleInclude)
    assert(role_include._role_name == 'geerlingguy.apache')
    assert(role_include._role_path == '/etc/ansible/roles/geerlingguy.apache')
    assert(role_include.get_vars() == {})

    yaml_str = """
      - role: geerlingguy.apache
        become: yes
        vars:
          - http_port: 8080
    """
    data = yaml

# Generated at 2022-06-21 01:04:58.681862
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Set object
    play = None
    current_role_path = None
    parent_role = None

    # Set variable_manager
    variable_manager = None
    loader = None
    collection_list = None

    # Function to test
    role_req_list = []
    for role_req in role_req_list:
        role_req = role_req.strip()
        role = RoleInclude.load(role_req, play, current_role_path, parent_role,
                                loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-21 01:05:01.576267
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert (ri.__class__.__name__ == 'RoleInclude')

# Generated at 2022-06-21 01:05:08.042608
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_basedir='/root/ansible-linux-hardening/roles'
    role_definition=RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert role_definition.__class__.__name__, 'RoleInclude'
    assert role_definition.role_basedir, '/root/ansible-linux-hardening/roles'



# Generated at 2022-06-21 01:05:19.239401
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=1, role_basedir=2, variable_manager=3, loader=4, collection_list=5)
    assert ri.play is 1
    assert ri.role_basedir is 2
    assert ri.role_path is None
    assert ri.variable_manager is 3
    assert ri.loader is 4
    assert ri.collection_list is 5
    assert len(ri.get_vars()) == 0
    assert ri.get_vars(include_hostvars=False) == {}
    assert ri.get_vars(include_hostvars=True) == {}
    assert not ri.post_validate(templar=6)
    assert not ri.is_import_playbook
    assert not ri.is_handler

# Generated at 2022-06-21 01:05:21.401871
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-21 01:05:31.354782
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    TaskExecution = collections.namedtuple('TaskExecution', ['noop_task', 'fail_task', 'retry_task', 'retry_task_result'])
    task_execution = TaskExecution(noop_task=True, fail_task=False, retry_task=0, retry_task_result=None)
    Host = collections.namedtuple('Host', ['get_vars', 'get_name'])
    host = Host(get_vars=lambda: {}, get_name=lambda: 'test_host')

# Generated at 2022-06-21 01:05:33.692639
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:05:35.040040
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    print(ri)

# Generated at 2022-06-21 01:05:43.372715
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins import callback_loader

    loader = DataLoader()
    variable_manager = VariableManager()

    # init inventory
    inventory = Inventory(loader, variable_manager)
    variable_manager.set_inventory(inventory)

    # init play and tasks
    play_source = dict(
        name="test",
        hosts="localhost",
        gather_facts="no",
        tasks=[],
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    # init callbacks
    results_

# Generated at 2022-06-21 01:05:51.385906
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    test_RoleInclude_load: Verify AnsibleError is raised when the include
    line has ',' separating the requirement.
    """
    data = 'role1,role2'
    play = None
    variable_manager = None
    loader = None
    collection_list = None
    with pytest.raises(AnsibleError):
        RoleInclude.load(data, play, variable_manager, loader, collection_list)


# Generated at 2022-06-21 01:06:01.812999
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Syntax:
      name: string
      tasks: list of tasks
      handlers: list of handlers
      vars: hash of vars
      defaults: hash of default vars
      meta: hash of role meta
      include_tasks: list of includes
      include_role: list of includes
      pre_tasks: list of tasks
      post_tasks: list of tasks
      dependencies: list of roles

    """

    play = {
        'roles': ['role_history', 'role_present'],
        'name': 'Historical record',
    }

    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    d = Play()
    d.vars = VariableManager()
    d.loader = DataLoader()

# Generated at 2022-06-21 01:06:02.529771
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-21 01:06:12.373052
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # pylint: disable=unused-variable
    loader = DictDataLoader({
        "test_role": {"tasks": {"main.yml": "---\n- debug: msg='included role task'"}},
    })

    # pylint: disable=unused-variable
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        roles=[
            dict(name="test_role"),
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    assert play._included_file_

# Generated at 2022-06-21 01:06:16.840239
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Testing load method of class RoleInclude
    data = "testrole"
    play = "testplay"
    current_role_path = "."
    parent_role = "testparentrole"
    variable_manager = "testvariable"
    loader = "testloader"
    collection_list = "testlist"
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    # Testing if the returned value is an instance of RoleInclude 
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-21 01:06:19.020721
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict1 = dict(a=1, b=2, c=3)
    RoleInclude.load(dict1, None, None, None, None, None)
    assert 1

# Generated at 2022-06-21 01:06:20.619667
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # Create new object RoleInclude
    ri = RoleInclude()


# Generated at 2022-06-21 01:06:31.571679
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """Unit test for constructor of class RoleInclude"""
    from ansible.parsing.mod_args import ModuleArgsParser
    import os
    import sys

    current_dir = os.path.dirname(sys.modules[__name__].__file__)
    root = os.path.join(current_dir, '../..')
    lib = os.path.join(root, 'lib')
    if lib not in sys.path:
        sys.path.append(lib)

    from ansible.playbook.play_context import PlayContext
    ansible_vars = dict(
        connection='ssh',
        remote_user='vagrant',
    )

# Generated at 2022-06-21 01:06:33.255627
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri,RoleInclude)

# Generated at 2022-06-21 01:06:41.591295
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "test,test"
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    try:
        ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
        ri.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
        assert False, "Should raise AnsibleError"
    except AnsibleError:
        assert True
    except:
        assert False, "Should raise AnsibleError"

# Generated at 2022-06-21 01:06:58.978305
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import mock
    import ansible.playbook.role.include
    import ansible.playbook.role.definition
    import ansible.playbook.role.requirement
    import ansible.playbook.role
    import ansible.parsing.dataloader
    import ansible.vars.manager

    test_instance = RoleInclude()
    target_dict = dict()
    target_dict['name'] = 'foobar'
    target_dict['scenario'] = 'spam'
    target_dict['role_path'] = '/path/to/roles'
    target_dict['include_vars'] = dict(
        file='/some/path.yml',
        name='some_var',
        version='v1.0'
    )

    # call _load_role_vars to validate `name

# Generated at 2022-06-21 01:07:04.574298
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.fake import FakePlaybook

    test_role = RoleInclude(play=FakePlaybook)
    assert test_role.name == 'fake_playbook'
    assert test_role.play is not None
    assert test_role.role_basedir == 'fake_playbook'
    assert test_role.loader is not None

# Generated at 2022-06-21 01:07:15.390174
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from io import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_context import PlaybookContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.helpers import load_list_of_blocks, load_list_of_tasks
    from ansible.errors import AnsibleParserError

    rname = "role_name"
    rpath = "/path/to/roles_path"

    ldr = AnsibleLoader(StringIO(''), variable_manager=VariableManager())
    variable_manager = VariableManager()

# Generated at 2022-06-21 01:07:16.009008
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:07:25.922438
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from collections import namedtuple

    class Options(object):
        connection = ()
        module_path = ()
        forks = ()
        become = ()
        become_method = ()
        become_user = ()
        check = ()
        diff = ()
        syntax = ()
        vault_password_files = ()
        verbosity = ()
        start_at_task = ()

    options = Options()

    test_loader = DataLoader()
    mock_

# Generated at 2022-06-21 01:07:30.448306
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class Object(object):
        pass

    attribute = Attribute()
    roleInclude = RoleInclude()
    roleInclude.play = Object()
    roleInclude.play.role_path = []
    assert(isinstance(roleInclude, RoleInclude))

# Generated at 2022-06-21 01:07:33.757805
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("test_RoleInclude_load")
    return 0

if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-21 01:07:34.992677
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert role

# Add more test cases

# Generated at 2022-06-21 01:07:44.604093
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.module_utils.six import StringIO, binary_type
    from ansible.parsing.yaml import objects

    variable_manager = Mock()
    variable_manager.get_vars = MagicMock(return_value={})

    data = {"name": "webserver", "hosts": "foo"}
    loader = DictDataLoader({
        "/etc/ansible/roles/webserver/meta/main.yml": b"dependencies:\n  - { role: apache, foo: 42 }\n  - { role: mysql }\n",
    })  # type: DataLoader
    play = MagicMock()

    ri = RoleInclude.load(data, play, current_role_path=None, parent_role=None, variable_manager=variable_manager, loader=loader)

   

# Generated at 2022-06-21 01:07:55.685764
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.utils.vars import load_extra_vars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    import os
    inventory = InventoryManager(loader=DataLoader(), sources=os.getenv('ANSIBLE_HOSTS', '/etc/ansible/hosts'))
    pb = Play()
    vars_data = load_extra_vars(loader=DataLoader(), inventory=inventory)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager.set_play_context(pb)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 01:08:11.958006
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    return True

if __name__ == "__main__":
    ret = test_RoleInclude()
    if ret:
        print("TEST PASS")
    else:
        print("TEST FAIL")

# Generated at 2022-06-21 01:08:14.313243
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("test_RoleInclude: class constructor")
    obj = RoleInclude()



# Generated at 2022-06-21 01:08:17.579526
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.is_meta == False
    assert ri.is_playbook == False
    assert ri.is_role == False

# Generated at 2022-06-21 01:08:28.184331
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    loader = DictDataLoader({
        "/src/play.yml": """
- hosts: all
  gather_facts: no
  roles:
    - { role: common }
    - { role: foobar, tags: [ 'app' ] }
""",
        "/src/roles/foobar/tasks/main.yml": """
- name: task 1
  shell: /bin/false
  tags:
    - always
""",
    })
    all_roles = RoleRequirement.load_roles_from_list([
        "/src/roles/common:unknown",
        "/src/roles/foobar:unknown",
    ], None, loader)

    all_includes = RoleInclude.load({RoleDefinition.DEFAULT_ATTRIBUTE_NAME: "foobar"}, None, loader=loader)


# Generated at 2022-06-21 01:08:30.106672
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    try:
        RoleInclude()
    except:
        pass

# Generated at 2022-06-21 01:08:42.229732
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader)
    play_context = PlayContext()
    playbooks = ["playbook.yml"]
    pbex = PlaybookExecutor(playbooks=playbooks, inventory=inventory, variable_manager=variable_manager,
                            loader=loader, options=None, passwords={})
    play_datas = pbex.inventory.get_plays(pbex._play_name)

# Generated at 2022-06-21 01:08:52.258960
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # From a string
    role_include_str = RoleInclude.load('test.role', None)
    assert role_include_str.get_name() == 'test.role'
    assert role_include_str.get_role_path() == 'test.role'
    assert role_include_str.get_role_name() == 'test.role'

    # From a dict
    data = dict(
        name='test.role',
        when='ok',
        become='yes',
        become_user='root',
        delegate_to='other-machine'
    )
    role_include_dict = RoleInclude.load(data, None)
    assert role_include_dict.get_name() == 'test.role'
    assert role_include_dict.get_role_path() == 'test.role'
   

# Generated at 2022-06-21 01:09:00.737187
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    host_var_values = {
        "host1": {
            "host_var": "host_var_value"
        },
        "host2": {
            "host_var": "host_var_value"
        }
    }
    role_var_values = {
        "role_var": "role_var_value"
    }
    group_var_values = {
        "group_var": "group_var_value"
    }

    role_path = os.path.join(os.path.dirname(__file__), "../../support/role-include-load")

    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

   

# Generated at 2022-06-21 01:09:08.009056
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    obj = RoleInclude()
    assert obj.metadata is None
    assert obj.handlers is None
    assert obj.tasks is None
    assert obj._play is None
    assert obj._role_name is None
    assert obj._role_path is None
    assert obj._role_basedir is None
    assert obj.dependencies is None
    assert obj.variable_manager is None
    assert obj.loader is None
    assert obj.post_validate is None
    assert obj._collection_list is None

# Generated at 2022-06-21 01:09:08.988808
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    a=RoleInclude()

# Generated at 2022-06-21 01:09:40.097350
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Without name
    data = {}
    result = RoleInclude.load(data, None)
    assert result.get_name() == ''

    # With name
    data = {'name': 'test_role'}
    result = RoleInclude.load(data, None)
    assert result.get_name() == 'test_role'

# Generated at 2022-06-21 01:09:49.251275
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    loader.set_basedir('.')
    play_context = PlayContext()
    play = Play.load(dict(
        name="Ansible Play",
        hosts=["all"],
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ), loader=loader, variable_manager=None)


# Generated at 2022-06-21 01:09:49.812484
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-21 01:09:53.445374
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert isinstance(ri, RoleDefinition)

# Generated at 2022-06-21 01:09:53.993686
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:10:05.173034
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    # load - exception (1)
    data = {'role1': 1, 'role2': 2}
    expected_msg = "Invalid role definition: {'role1': 1, 'role2': 2}"
    try:
        ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except Exception as e:
        assert str(e) == expected_msg

    # load - exception (2)
    data = "role1,role2"
    expected_msg = "Invalid old style role requirement: role1,role2"

# Generated at 2022-06-21 01:10:08.036594
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("Running Unit Test: test_RoleInclude_load")
    ri = RoleInclude()
    assert ri.load(None, None) == None
    print("Unit Test for method load passed")


# Generated at 2022-06-21 01:10:16.385842
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case = [
        # (test_input, expected)
        # test_input is a dict
        (
            dict(
                name='test',
                become=True,
                become_user='testuser',
            ),
            dict(
                name='test',
                become_user='testuser',
            ),
        ),
        # test_input is a str
        (
            'test',
            dict(
                name='test',
            ),
        ),
        # test_input is a str of two roles: 'test,test2'
        (
            'test,test2',
            dict(
                name='test,test2',
            ),
        ),
    ]
    for test_input, expected in test_case:
        current_role_path = './tmp'
        variable_manager = None


# Generated at 2022-06-21 01:10:27.362951
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    dataloader = DataLoader()
    variable_manager = VariableManager()

    # Test with a simple string
    data = 'apache'
    role = RoleInclude.load(data=data, play=None, current_role_path='/some/path', parent_role=None,
                            variable_manager=variable_manager, loader=dataloader, collection_list=None)
    assert role.get_name() == 'apache'

    # Test with a dictionary
    data = {'name': 'apache'}

# Generated at 2022-06-21 01:10:33.112893
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.callback import CallbackBase


if __name__ == "__main__":
    test_RoleInclude()

# Generated at 2022-06-21 01:11:35.298871
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    cache = AnsibleCache(0)
    variable_manager = VariableManager(loader=None, inventories=[], cache=cache)
    variable_manager._extra_vars = load_extra_vars(loader=None, options=None, variable_manager=variable_manager)
    pb = Playbook.load('/tmp/dummy.yml', variable_manager=variable_manager, loader=None)

    # test with string
    data = 'role_name'
    ri = RoleInclude.load(data, play=pb, current_role_path=None, parent_role=None, variable_manager=variable_manager, loader=None)

    assert isinstance(ri, RoleInclude)
    assert isinstance(ri.role, RoleRequirement)
    assert ri.role.name == 'role_name'

    # test with

# Generated at 2022-06-21 01:11:42.027698
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = Play()

    current_role_path = 'current_role_path'
    parent_role = 'parent_role'
    variable_manager = 'variable_manager'
    loader = 'loader'
    collection_list = 'collection_list'

    if isinstance(loader, string_types) or loader is None:
        loader = DataLoader()
    if isinstance(variable_manager, string_types) or variable_manager is None:
        variable_manager = VariableManager()
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    data1 = 'test_role'

# Generated at 2022-06-21 01:11:53.485869
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class FakeVariableManager:
        def __init__(self):
            self.extra_vars = ''

    class FakeLoader:
        def __init__(self, variable_manager=None, search_path=[]):
            self.variable_manager = FakeVariableManager()
            self.search_path = search_path

    class FakePlay:
        def __init__(self):
            self.variable_manager = FakeVariableManager()
            self.loader = FakeLoader(self.variable_manager, search_path=[])

    class FakeRoleDefinition:
        def __init__(self, play):
            self.play = play
            self.dependencies = []

        def load_data(self, data, variable_manager=None, loader=None):
            return self


# Generated at 2022-06-21 01:12:01.710486
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from collections import namedtuple
    from ansible.parsing.yaml.data import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Load the role definition file

# Generated at 2022-06-21 01:12:09.969606
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''Check the constructor for class RoleInclude'''
    play = 'play'
    basedir = 'basedir'
    vm = 'vm'
    loader = 'loader'
    collection_list = 'collection_list'
    ri = RoleInclude(play=play, role_basedir=basedir, variable_manager=vm, loader=loader, collection_list=collection_list)
    assert ri.play == play
    assert ri.role_basedir == basedir
    assert ri.variable_manager == vm
    assert ri.loader == loader
    assert ri.collection_list == collection_list

# Generated at 2022-06-21 01:12:19.421520
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.mod_args import ModuleArgsParser
    arguments = ModuleArgsParser.parse(dict())

    # Create a test play object
    testplay = Play().load({'name': 'TestPlay', 'hosts': 'localhost', 'gather_facts': 'no', 'tasks': []},
                           variable_manager=None, loader=None)

    # Create an empty role include
    role_include = RoleInclude(play=testplay)

    # Assert that the attributes are correct
    assert role_include._play is testplay
    assert role_include._variable_manager is None
    assert role_include._loader is None
    assert role_include._name == ''
    assert not role_include._enabled
    assert not role_include._sourcedir
    assert role

# Generated at 2022-06-21 01:12:23.012047
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..','..','..','..','..', 'test', 'unit', 'modules', 'test_meta.py'))
    ri = RoleInclude(play=None, parent_role=None, role_basedir=role_path)
    assert (ri is not None)

# Generated at 2022-06-21 01:12:28.853152
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = "TEST"
    role_basedir = "/some/path"
    variable_manager = None
    loader = None
    collection_list = None
    role = RoleInclude(play = play, role_basedir=role_basedir, variable_manager = variable_manager, loader = loader, collection_list = collection_list)
    assert role.role_basedir == role_basedir


# Generated at 2022-06-21 01:12:32.799219
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play

    play = Play()
    role_include = RoleInclude(play=play, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert isinstance(role_include, RoleInclude)


# Generated at 2022-06-21 01:12:35.297625
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)