

# Generated at 2022-06-21 01:03:32.209103
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    This test method should return True if the given input value is
    successfully loaded.
    """

    data = 'git+https://github.com/ansible/ansible-examples.git,test-server'
    ri = RoleInclude()
    try:
        result = ri.load(data)
    except AnsibleError:
        result = False

    assert result == False

# Generated at 2022-06-21 01:03:43.717785
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.module_utils.six import PY3, text_type
    from ansible.utils.unsafe_proxy import to_unicode, to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role


# Generated at 2022-06-21 01:03:54.486064
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    p = Play()
    p.vars = dict(foo="bar")
    r = RoleInclude(play=p, role_basedir="some/path", variable_manager=VariableManager(loader=DictDataLoader()), collection_list=Mock())
    assert r.play == p

    r = RoleInclude(play=p, variable_manager=VariableManager(loader=DictDataLoader()), collection_list=Mock())
    assert r.get_path() == 'some/path'

    # Tests for role_basedir
    p.ROLE_CACHE = dict(a="path1", b="path2")

# Generated at 2022-06-21 01:04:07.943778
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = """
        - src: https://github.com/example/ansible-role-example.git
          scm: git
          version: v1.0.0
        - src: https://github.com/example/ansible-role-example-dependency.git
          version: v1.7.5
    """
    ri = RoleInclude.load(data, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert ri.get_dep_chain()[0].role_name == 'example.ansible-role-example'
    assert ri.get_dep_chain()[0].role_path == 'github.com/example/ansible-role-example.git'
    assert ri.get_dep_

# Generated at 2022-06-21 01:04:14.296134
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.tests.unit.test_role.test_definition import MockVariableManager, MockLoader, MockPlay
    from ansible.playbook.role.definition import RoleDefinition

    ri = RoleInclude(MockPlay(), MockVariableManager(), MockLoader())
    assert ri.load('test_load', MockVariableManager(), MockLoader()) == RoleDefinition.load('test_load', MockPlay(), None, None, MockVariableManager(), MockLoader())
    assert ri.load('test_load,another_test_load', MockVariableManager(), MockLoader()) == RoleDefinition.load('test_load,another_test_load', MockPlay(), None, None, MockVariableManager(), MockLoader())

# Generated at 2022-06-21 01:04:25.442825
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class TestRoleInclude(RoleInclude):
        _base_class = RoleInclude

        def __init__(self, role_basedir, play=None, variable_manager=None, loader=None, collection_list=None):
            super(TestRoleInclude, self).__init__(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    play = "play"
    role_basedir = '/path/to/role'
    role_include = TestRoleInclude(role_basedir, play)
    assert role_include.role_basedir == role_basedir

# Generated at 2022-06-21 01:04:37.932293
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {
        'role': 'dummy',
        'tasks': [
            {'name': 'Test task', 'debug': 'msg={{ test_var }}'}
        ],
        'vars': {
            'test_var': 'Test variable'
        }
    }

    variable_manager = MagicMock()
    variable_manager.get_vars.return_value = {
        'playbook_dir': os.path.dirname(__file__)
    }

    playbook_path = os.path.join(os.path.dirname(__file__), 'test_playbook.yml')
    collection_list = [os.path.join(os.path.dirname(__file__), 'ansible_collections/dummy/dummy_collection')]

# Generated at 2022-06-21 01:04:46.520410
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    hosts = ['192.168.1.0', '192.168.2.0']
    variable_manager = VariableManager(loader=None, inventory=None)

    # Instantiate object of class RoleInclude
    ri = RoleInclude(variable_manager=variable_manager)
    assert ri.name is None
    assert ri.role_path is None
    assert ri.role_name is None
    assert len(ri.default_vars) == 0
    assert len(ri.role_vars) == 0
    assert ri.vars == dict()
    assert ri.block is None
    assert len(ri.task_blocks) == 0
    assert len(ri.always_run) == 0
    assert ri.tags == ['all']
    assert ri.run_once is False

# Generated at 2022-06-21 01:04:53.693106
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.errors import AnsibleParserError

    # Create dummy context
    variable_manager = VariableManager()
    loader = AnsibleLoader(None, variable_manager)
    inventory = InventoryManager(loader, variable_manager, 'localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 01:05:02.795227
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.dumper import AnsibleDumper

    play = Play()
    play_context = PlayContext()
    system_vars = {'ansible_system_capabilities': ['privileged']}

    ansible_vars = {
        'foo': 'bar',
    }

    role_include1 = RoleInclude.load(data='test_role', play=play, variable_manager=play_context, loader=None)
    role_include2 = RoleInclude.load(data='test_role,foo=bar', play=play, variable_manager=play_context, loader=None)

# Generated at 2022-06-21 01:05:18.274853
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    load_object = RoleInclude.load(data='test', play=None, current_role_path='/test/test', parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert load_object._role_name == 'test'

    # test raise AnsibleParserError
    try:
        load_object_1 = RoleInclude.load(data='{1:2}', play=None, current_role_path='/test/test', parent_role=None, variable_manager=None, loader=None, collection_list=None)
        raise Exception('AnsibleParserError is not raised')
    except AnsibleParserError:
        pass

    # test raise AnsibleError

# Generated at 2022-06-21 01:05:30.093609
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    p = AnsibleParser(for_test=True)
    s = io.StringIO("""
    - hosts: all
      roles:
       - common
       - { role: 'foo', other: 'thing' }
       - foo
       - foo,bar
       - include: foo.yml
    """)
    p._read_vault = lambda x,y,z: None
    p.parse(s)
    yaml = p.yaml
    play = yaml[0]
    ri = RoleInclude(play=play)
    ri.load_data(play.get_roles(), variable_manager=None, loader=None)
    ri = RoleInclude(play=play).load(play.get_roles(), None, None, None, None, None)
    assert ri.get_name()

# Generated at 2022-06-21 01:05:37.385568
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.plugins.loader import inventory_loader

    data = "role_name"

    p = Play()
    p._variable_manager = inventory_loader.get('variable_manager')(loader=p._loader)

    ri = RoleInclude.load(data, p)

    assert ri._role_name == data

# Generated at 2022-06-21 01:05:41.591512
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)
    assert isinstance(ri, RoleRequirement)

# Generated at 2022-06-21 01:05:50.422706
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    loader = AnsibleLoader(None, variable_manager=VariableManager())
    p = Play().load('foo', loader, None)
    role = RoleInclude(play=p, role_basedir='role_basedir', variable_manager=VariableManager(), loader=loader)
    assert isinstance(role, RoleInclude)
    assert isinstance(role.attribute_class, type)
    #assert isinstance(RoleInclude.__doc__, str)



# Generated at 2022-06-21 01:06:01.192652
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.utils.collection_loader import AnsibleCollectionRef

    data = {'role': 'geerlingguy.docker'}
    ri = RoleInclude()
    role = ri.load(data, None, None)
    assert role.get_name() == 'geerlingguy.docker'

    # Load with a variable
    data = {'role': 'geerlingguy.docker', 'version': '1.3.3'}
    ri = RoleInclude()
    role = ri.load(data, None, None)
    assert role.get_name() == 'geerlingguy.docker'
    assert role.get_collection() is None
    assert role.get_version() == '1.3.3'

    # Load with a collection, then with a variable

# Generated at 2022-06-21 01:06:04.057476
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pl = RoleInclude()
    assert pl.play
    assert pl._play_name == u"myplaybook"

# Generated at 2022-06-21 01:06:12.255809
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    variable_manager = DummyVariableManager()
    loader = DataLoader()
    play = Play().load({}, loader=loader, variable_manager=variable_manager)
    role_basedir = './test/data/playbook/roles'
    role_def = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader)
    assert role_def._role_path == role_basedir



# Generated at 2022-06-21 01:06:12.835590
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    raise NotImplementedError()


# Generated at 2022-06-21 01:06:19.917888
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Using a special class for testing
    class AnsibleModuleTest(object):
        pass

    # Define arguments for AnsibleModuleTest
    class AnsibleModuleTestArguments(object):
        def __init__(self):
            self.basedir = './test-data/playbooks'
            self.role_path = None
            self.role = './test-data/playbooks/roles'

    # Define options for AnsibleModuleTest
    class AnsibleModuleTestOptions(object):
        def __init__(self):
            self.connection = None
            self.become = False
            self.remote_user = None
            self.module_path = None

    # Define fake command line options

# Generated at 2022-06-21 01:06:30.839532
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude(play=1, role_basedir=2, variable_manager=3, loader=4, collection_list=5)
    assert role_include.play == 1
    assert role_include.role_basedir == 2
    assert role_include.variable_manager == 3
    assert role_include.loader == 4
    assert role_include.collection_list == 5

# Generated at 2022-06-21 01:06:35.561510
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager,  host_list='/etc/ansible/hosts'))
    variable_manager.extra_vars = load_extra_vars(options, variable_manager)

    # Test with a string for input data
    data = "./foo/bar"
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader)
    ri.load_data(data, variable_manager=variable_manager, loader=loader)

    assert ri.get_name() == "./foo/bar"

    # Test with a dict for input data
    data = {"role": "./foo/bar/baz"}

# Generated at 2022-06-21 01:06:36.931945
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.role_basedir == ''

# Generated at 2022-06-21 01:06:38.316588
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert role is not None

# Generated at 2022-06-21 01:06:41.629967
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert role is not None, 'role is not None'
    assert role._delegate_to == '', 'role._delegate_to is wrong'

    role2 = RoleInclude(play=None)
    assert role2 is not None, 'role2 is not None'


# Generated at 2022-06-21 01:06:53.702629
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.constants import DEFAULT_LOAD_CALLBACK_PLUGINS
    from ansible.plugins.callback import CallbackBase

    class TestCallback(CallbackBase):
        """
        Test callback
        """
        def __init__(self, *args, **kwargs):
            super(TestCallback, self).__init__(*args, **kwargs)
            self.calls = []

        def v2_playbook_on_play_start(self, play):
            self.calls.append(('playbook_on_play_start', play.name))


# Generated at 2022-06-21 01:06:55.395110
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:06:57.530829
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == "RoleInclude"


# Generated at 2022-06-21 01:07:09.107081
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test whether method load of class RoleInclude can be
    # called correctly. If it can't be, the  defined test will fail.
    data = {"role1": "role1", "role2": "role2"}
    play = "play"
    current_role_path = "current_role_path"
    parent_role = "parent_role"
    variable_manager = "variable_manager"
    loader = "loader"
    collection_list = "collection_list"
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    ri.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)


# Generated at 2022-06-21 01:07:20.308205
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    test_dir = os.path.dirname(__file__)
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources='localhost,')
    variable_manager.set_inventory(inventory)
    current_role_path = test_dir + '/../../../lib/ansible/playbook/roles/test_role'

# Generated at 2022-06-21 01:07:38.006809
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'apache,geerlingguy.git'
    play = 'test'
    current_role_path = '~/ansible/roles/'
    variable_manager = ''
    loader = ''
    collection_list = ''

# Generated at 2022-06-21 01:07:46.818584
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import role_loader
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=DataLoader(), variable_manager=variable_manager, host_list='/dev/null'))
    loader = DataLoader()
    play_context = PlayContext()

    current_role_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test', 'roles', 'test_role1')


# Generated at 2022-06-21 01:07:47.315257
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert True

# Generated at 2022-06-21 01:07:50.426874
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test PlaybookIncludeRole is not empty
    test_RoleInclude = RoleInclude()
    assert len(test_RoleInclude.__dict__) > 10

# Generated at 2022-06-21 01:08:00.716854
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook import Play

    # Case 1: RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader).
    #         Simply call parent class's constructor, so no any parameter.
    play = Play()
    role_basedir = "abc"
    ri = RoleInclude(play=play, role_basedir=role_basedir)

    assert ri._play == play
    assert ri._role_basedir == role_basedir
    assert ri._variable_manager is None
    assert ri._loader is None
    assert ri._metadata is None
    assert ri._role_params is None
    assert ri._role_path is None
    assert ri._role_name is None
    assert ri._collection_name is None


# Generated at 2022-06-21 01:08:03.875886
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("Constructor of RoleInclude test:")
    ri = RoleInclude()
    # prove the arguments were received by the constructor
    print("Done")


# Generated at 2022-06-21 01:08:05.122566
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:08:12.790852
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.module_utils.six import PY3

    # initialize data for the test
    data = {
        "name": "role name",
        "tasks": [{
            "action": "action name",
            "args": {
            },
            "module": "module name",
            "tags": ["tag 1", "tag 2"],
            "when": "when name"
        }],
        "vars": {
            "IFS": "IFS name",
            "list": ["list 1", "list 2"]
        }
    }

    # initialize play and variable_manager for the test

# Generated at 2022-06-21 01:08:24.773713
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play().load(
        dict(
            name = "Ansible Play",
            hosts = 'all',
            gather_facts = 'no',
            roles = [
                "test_role_1",
                "test_role_2"
            ]
        ),
        variable_manager=variable_manager,
        loader=loader
    )
    variable_manager._extra_vars = {"ansible_ssh_user": "remote_user", "ansible_ssh_pass": "remote_pass"}
    template_uid = 1000
    template_

# Generated at 2022-06-21 01:08:25.368712
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:08:57.405755
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.utils.vars import combine_vars

    play_ds =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            dict(role1 = dict(become='root', become_method='sudo')),
            dict(role2 = dict(become='root', become_method='sudo')),
            dict(role3 = dict(become='root', become_method='sudo')),
            'role8',
            'role9',
        ]
    )
    play = Play().load(play_ds, variable_manager=None, loader=None)
    print("Play name: %s" % play.name)
    print

# Generated at 2022-06-21 01:09:00.544669
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude()
    assert r._play is None
    assert r._role_basedir is None
    assert r._variable_manager is None
    assert r._loader is None
    assert r._collection_list is None

# Generated at 2022-06-21 01:09:01.132498
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()

# Generated at 2022-06-21 01:09:02.152172
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role = RoleInclude.load()

# Generated at 2022-06-21 01:09:05.711493
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Execute the constructor and verify that it throws no execeptions
    try:
        RoleInclude()
    except Exception as e:
        assert False, "Failed to construct class RoleInclude due to %s" % str(e)

# Generated at 2022-06-21 01:09:09.211031
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: The method load of the RoleInclude class only calls the load_data function of the RoleDefinition class.
    # TODO: Need to write unit test for the load_data function of the RoleDefinition class.
    pass

# Generated at 2022-06-21 01:09:18.146417
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    hostname = 'localhost'
    inventory = loader.load_from_source("""
        [test_group]
        localhost
    """)
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()

    filename = "test_role"

# Generated at 2022-06-21 01:09:29.020154
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import plugins
    from ansible.template import Templar
    ri = RoleInclude(loader=plugins, collection_list=[], variable_manager={}, play={'context': PlayContext()})
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri.loader, plugins)
    assert isinstance(ri.templar, Templar)
    assert ri.play is not None
    assert isinstance(ri.play['context'], PlayContext)
    assert ri.collection_list == []
    assert isinstance(ri.vars, dict)
    assert isinstance(ri.module_vars, dict)
    assert isinstance(ri.module_defaults, dict)

# Generated at 2022-06-21 01:09:30.787051
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri,RoleDefinition)

# Generated at 2022-06-21 01:09:31.483819
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert True

# Generated at 2022-06-21 01:10:31.859907
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import yaml
    yaml.load = lambda x, Loader=yaml.SafeLoader: yaml.load(x, Loader)
    from ansible.playbook.role.definition import RoleDefinition

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    data = """
- role: apache
  when: inventory_hostname == 'vagrant-ubuntu-trusty-64'
  become_user: apache

- role: shell-scripting
  when: inventory_hostname == 'vagrant-ubuntu-trusty-64'
  become_user: apache
"""

# Generated at 2022-06-21 01:10:38.017421
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''
    ansible/test/units/test_role.py::test_RoleInclude_constructor[basic]
    tests for basic functionality of the RoleInclude constructor by creating
    an instance of RoleInclude and checking for type correctness.
    '''

    from ansible.playbook.play import Play

    data = dict(
        name="myrole",
        foo="bar",
    )

    play = Play()

    role_include = RoleInclude(play=play)

    role_include.load_data(data)

    assert isinstance(role_include, RoleInclude), \
        "RoleInclude instance is not valid"

    assert isinstance(role_include.get_name(), string_types), \
        "RoleInclude's name is not valid"


# Generated at 2022-06-21 01:10:39.294575
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclusi = RoleInclude()
    print(RoleInclusi)

# Generated at 2022-06-21 01:10:50.479341
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import load_extra_vars
    d = dict(name='test',
             hosts='host',
             tasks=[dict(action=dict(module='test', args='test'))])
    play = Play.load(d)
    variable_manager = VariableManager()
    loader = DataLoader

# Generated at 2022-06-21 01:10:51.072242
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:10:58.203003
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    assert isinstance(RoleInclude.load(data=AnsibleBaseYAMLObject({"roles": "foo"}), play=None), RoleDefinition)
    assert isinstance(RoleInclude.load(data=AnsibleBaseYAMLObject({"include_role": "foo"}), play=None), RoleInclude)

    # test role included via old style role requirement

# Generated at 2022-06-21 01:10:58.984876
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:10:59.753118
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
      pass

# Generated at 2022-06-21 01:11:07.986111
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pb = object()
    vm = object()
    ld = object()
    cl = object()
    ri = RoleInclude(play=pb, variable_manager=vm, loader=ld, collection_list=cl)
    assert_raises(AnsibleParserError, ri.load, 'bogus', pb, '/path', vm, ld, cl)
    assert_raises(AnsibleError, ri.load, 'role1,role2', pb, '/path', vm, ld, cl)
    assert_raises(AnsibleError, ri.load, 'role1, role2', pb, '/path', vm, ld, cl)



# Generated at 2022-06-21 01:11:08.841140
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include