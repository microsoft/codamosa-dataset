

# Generated at 2022-06-21 01:03:36.775587
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include._delegate_to == None
    assert role_include._delegate_facts == False

# Generated at 2022-06-21 01:03:44.856670
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import load_extra_vars

    data = 'test-user.test-role'
    play_data = dict(
        name='test',
        hosts='all'
    )
    play = Play.load(play_data, variable_manager=VariableManager(), loader=None)
    ri = RoleInclude(play=play, role_basedir='/usr/share/ansible/roles', variable_manager=VariableManager(), loader=None)
    ri = ri.load

# Generated at 2022-06-21 01:03:46.119509
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-21 01:03:53.016614
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def load(data, play):
        return RoleInclude.load(data, play, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    data1 = load("role1", play='name')
    assert data1._role_name['name'] == 'role1'
    assert data1._role_name['namespace'] == 'name'
    data2 = load("role2", play=None)
    assert data2._role_name['name'] == 'role2'
    assert data2._role_name['namespace'] == 'name'

# Generated at 2022-06-21 01:04:06.107594
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import load_extra_vars
    from ansible.cli import CLI
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=CLI.args.inventory)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = []
        )

# Generated at 2022-06-21 01:04:08.039179
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()

# Generated at 2022-06-21 01:04:17.710074
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a mock class instead of a proper one
    class MockClass():
        def __init__(self, role_basedir):
            self.role_basedir = role_basedir

    # Mock object and values
    # Create mock object for current class
    role_include = RoleInclude()
    role_include.role_basedir = "my_base_dir"

    # Create a mock object for RoleDefinition class
    role_definition = RoleDefinition()
    role_definition.role_basedir = "my_base_dir"

    # Create a mock object for Loader class
    loader = Loader()
    loader.set_basedir = "my_base_dir"

    # Create mock object for VariableManager class

# Generated at 2022-06-21 01:04:27.645378
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    if os.getenv('TEST_ANSIBLE_ROLEINCLUDE') is not None:
        from ansible.parsing.dataloader import DataLoader
        from ansible.utils.collection_loader import AnsibleCollectionConfig
        from ansible.vars.manager import VariableManager
        from ansible.modules.loader import add_all_plugin_dirs
        from ansible.playbook.play import Play


# Generated at 2022-06-21 01:04:29.739800
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include._play is None

# Generated at 2022-06-21 01:04:31.719297
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()


RoleInclude.register_loader()

# Generated at 2022-06-21 01:04:36.413331
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude()
    assert roleInclude is not None

# Generated at 2022-06-21 01:04:40.538272
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    try:
        data = '{"name":"role-name"}'
        ri = RoleInclude(data)
    except Exception:
        pass

# Generated at 2022-06-21 01:04:51.134822
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test for method load of class RoleInclude
    """
    # Create a temporary file for our test
    import tempfile

    fd, path = tempfile.mkstemp()
    file_path = os.path.join(os.path.dirname(__file__), "load.yml")
    # Create the playbook
    yaml_doc = open(file_path, "r")
    yaml_input = yaml_doc.read()
    yaml_doc.close()
    os.write(fd, yaml_input)
    os.close(fd)

    import sys
    import io

    # Redirect the standard output
    stdout = sys.stdout
    sys.stdout = io.StringIO()


# Generated at 2022-06-21 01:04:51.986549
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:04:57.171283
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri._play is None
    assert ri._role_basedir is None
    assert ri._variable_manager is None
    assert ri._loader is None


# Generated at 2022-06-21 01:05:01.788742
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # initialize
    ri = RoleInclude()

    if ri == None:
        raise AssertionError()

if __name__ == "__main__":
    test_RoleInclude()

# Generated at 2022-06-21 01:05:05.772160
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
#    r = RoleInclude()
#    d = "role1,role2"
#    result = r.load(d)
#    assert result == r
#    assert r.get_name() == d

# Generated at 2022-06-21 01:05:18.278027
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import sys
    import os
    import json
    from ansible.playbook.role.meta import RoleMetadata

    file_path = os.path.realpath(__file__)
    file_dir = os.path.dirname(file_path)
    test_dir = os.path.realpath(os.path.join(file_dir, u'..', u'test_data'))
    sys.path.insert(0, test_dir)

    # pylint: disable=unused-variable

    try:
        from test_data.unit.ansible_test_mock import AnsiblePlay, AnsiblePlaybook
    except ImportError:
        print('Module import error')

# Generated at 2022-06-21 01:05:30.093974
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create some fake data to test RoleInclude.load()
    current_role_path = "current_role_path"
    data = dict(
        name="name",
        become=True,
        become_user="user",
        become_method="method",
        collect_facts=False,
        delegate_to="delegate",
        delegate_facts=True,
        serial=10
    )

    # Create fake objects to be used to create RoleInclude object
    play = Play()
    play_context = PlayContext()
    inventory = InventoryManager

# Generated at 2022-06-21 01:05:41.520916
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-21 01:05:59.808836
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class Dummy:
        pass
    play = Dummy()
    play.name = "test"
    role_basedir = "/tmp/role-basedir"
    variable_manager = Dummy()
    loader = Dummy()
    collection_list = Dummy()
    role_include = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert role_include is not None
    assert role_include._play == play
    assert role_include._role_basedir == role_basedir
    assert role_include._variable_manager == variable_manager
    assert role_include._loader == loader
    assert role_include._collection_list == collection_list

    # This function is not tested
    # role_include.load(data

# Generated at 2022-06-21 01:06:11.409630
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    playlist = Play().load(dict(
        name="Ansible Play APIC EM",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='ping', args=dict()))
        ]
    ), variable_manager=variable_manager, loader=None)

    # role name is not valid
    data = dict(name="not_found_role")
    result = RoleInclude.load(data, playlist, None, None, variable_manager=variable_manager, loader=None)
    assert result is None

    #

# Generated at 2022-06-21 01:06:14.946395
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    varManager = dict()
    play = dict()
    loader = dict()
    ri = RoleInclude(play, "role_basedir", varManager, loader)
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)


# Generated at 2022-06-21 01:06:15.495294
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-21 01:06:22.196598
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    play = Play.load(dict(name="test",
                          hosts=['localhost'],
                          tasks=[dict(action=dict(module='setup'), register='setup_results')]
                          ))
    data = AnsibleLoader(None).load('''
- role: test
  name: test
  delegate_to: localhost
  delegate_facts: yes
''').data[0]
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}
    variable_manager.set_inventory(None)

# Generated at 2022-06-21 01:06:23.587844
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-21 01:06:34.830248
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # assert expandvars is called if data is a string
    with mock.patch("ansible.playbook.role.include.RoleInclude.expand_role_vars") as mock_expandvars:
        role_path = "/fake_role_path"
        variable_manager = mock.Mock()
        loader = mock.Mock()
        RoleInclude.load(data="test_role", current_role_path=role_path, variable_manager=variable_manager, loader=loader)
        mock_expandvars.assert_called_once_with("test_role", variable_manager, loader)

    # assert expandvars is not called is data is not a string

# Generated at 2022-06-21 01:06:43.467928
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    play_ds = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )

    import os
    from .playbook_include import PlaybookInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    pb = PlaybookInclude.load(play_ds, variable_manager=VariableManager(), loader=None)
    assert pb.name == play_ds['name']
   

# Generated at 2022-06-21 01:06:55.578872
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        u'hostvars': {
            u'127.0.0.1': {
                u'foo': u'bar',
            }
        }
    }

    loader = DictDataLoader({})
    options = Options()
    inventory = InventoryManager(loader=loader, sources="localhost")
    play_context = PlayContext(variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:07:02.962544
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_in = "role_name,role_args"
    data_out = "role_name"

    # Test with wrong data type in
    try:
        RoleInclude.load(data=123, play=None, current_role_path=None, parent_role=None,
                variable_manager=None, loader=None, collection_list=None)
    except AnsibleParserError as e:
        assert e.message == "Invalid role definition: 123"

    # Test with a string that contains a comma, so that AnsibleError is raised

# Generated at 2022-06-21 01:07:23.384841
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ri = RoleInclude()
    assert ri.play is None
    assert ri.role_basedir is None
    assert ri.variable_manager is None
    assert ri.loader is None

    v = VariableManager()
    loader = DataLoader()

    p = Play()
    p.variable_manager = v
    p.loader = loader

    ri = RoleInclude(play=p)
    assert ri.play == p
    assert ri.role_basedir is None
    assert ri.variable_manager is None
    assert ri.loader is None


# Generated at 2022-06-21 01:07:33.001430
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import pprint
    from ansible.playbook.role.include import RoleInclude
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    import pprint
    loader = DataLoader()

# Generated at 2022-06-21 01:07:33.321161
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-21 01:07:33.980852
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    raise
    # TODO: unit test for this class
    pass


# Generated at 2022-06-21 01:07:34.733109
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-21 01:07:44.375414
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = Play()
    play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='ping', args=dict())),
        ]
    ))
    current_role_path = "/Users/nandor/Projects/Git/ansible/test/integration/roles/test_role_include"
    parent_role = PlaybookRole()
    parent_role.load(dict(
        name = "Ansible Playbook Role",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='ping', args=dict())),
        ]
    ))
    variable_manager = VariableManager()
    loader = DataLoader()
   

# Generated at 2022-06-21 01:07:47.784986
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    if False:
        # FIXME: this can't be done with a base class reference
        ri = RoleInclude()
        res = ri.load(data=None, play=None)
        assert res is not None


# Generated at 2022-06-21 01:07:48.815359
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-21 01:07:49.477126
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass



# Generated at 2022-06-21 01:07:58.787957
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    global_variable_manager = {}
    global_loader = {}
    main_play=[]
    current_role_path=''
    parent_role=''
    data = {
        'role': 'example',
        'hosts': 'server1',
        'user': 'root',
    }
    ri = RoleInclude(play=main_play, role_basedir=current_role_path, variable_manager=global_variable_manager, loader=global_loader)
    # test whether the constructor is correct
    assert 'role' in data.keys()
    assert 'hosts' in data.keys()
    assert 'user' in data.keys()


# Generated at 2022-06-21 01:08:13.458014
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext

    variable_manager = "variablemanager"
    loader = "loader"
    collection_list = "collection_list"

    data = AnsibleUnicode("role")

    ri = RoleInclude(play="play", role_basedir="role_basedir", variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    ri.load(data, play="play", current_role_path="role_basedir", parent_role="parent_role", variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Test load from file

# Generated at 2022-06-21 01:08:14.892841
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("Testing RoleInclude constructor")


# Generated at 2022-06-21 01:08:26.352570
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # python 2.7 and higher
    if hasattr(RoleInclude, "load"):
        # invalid role definition
        # role definition must be dict
        test_data_role_definition_is_not_dict = None
        try:
            role_include_instance = RoleInclude.load(
                test_data_role_definition_is_not_dict, None)
            assert False
        except AnsibleParserError as e:
            assert str(e) == 'Invalid role definition: None'

        # invalid role definition
        # role definition must be dict
        test_data_role_definition_is_not_dict = []

# Generated at 2022-06-21 01:08:26.907755
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
# vim:

# Generated at 2022-06-21 01:08:39.726290
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test empty constructor
    ri = RoleInclude()
    assert ri._play is None
    assert ri._role_basedir is None
    assert ri._variable_manager is None
    assert ri._loader is None
    assert ri._collection_list is None

    # Test constructor with some arguments
    from ansible.playbook.play import Play
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import tempfile
    fd, fp = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-21 01:08:50.476234
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()

    # test with string
    requirement = "galaxy, 1.23"
    data_object = role_include.load(requirement, None, None)
    assert data_object.get_name() == "galaxy"
    assert data_object.get_vars()['version'] == 1.23
    assert data_object.get_vars()['tags'] is None

    # test with dict with scalars
    requirement = dict(name="galaxy", version=1.23, tags=["a", "b"])
    data_object = role_include.load(requirement, None, None)
    assert data_object.get_name() == "galaxy"
    assert data_object.get_vars()['version'] == 1.23
    assert data_object.get_vars()

# Generated at 2022-06-21 01:08:57.929338
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import sys
    import os
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
    import ansible.playbook.role.definition as role_definition
    import ansible.playbook.role.include as role_include
    import ansible.parsing.yaml.loader as yaml_loader
    import ansible.parsing.yaml.objects as yaml_objects
    import ansible.vars.manager as vars_manager
    import ansible.vars.unsatisfied as unsatisfied
    # Test for method load of class RoleInclude
    # test for role include with a string as data
    current_role_path = os.path.abspath(u'.')
    role_basedir

# Generated at 2022-06-21 01:09:08.767135
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Setting the 'name' key of input data to a value of the wrong data type
    used to result in a TypeError because the method `RoleInclude.load` uses
    a plain assignment to set the value of the attribute '_name' to the
    value of `data['name']`.
    """
    # Setup
    class RoleIncludeSubclass(RoleInclude):

        def __init__(self, play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None):
            super(RoleIncludeSubclass, self).__init__(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    data = {
        'name': object(),
        'tasks': [],
    }


# Generated at 2022-06-21 01:09:17.844835
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play

    ri = RoleInclude(play=Play())
    assert ri

    # Test loading with an invalid data argument
    try:
        from ansible.parsing.yaml.objects import AnsibleUnicode
        ri.load(AnsibleUnicode(), None)
    except AnsibleParserError as e:
        assert isinstance(e, AnsibleParserError)
    else:
        assert False, "Expected AnsibleParserError to be raised"

    # Test loading with an invalid role definition
    try:
        ri.load('a, b, c', None)
    except AnsibleError as e:
        assert isinstance(e, AnsibleError)
    else:
        assert False, "Expected AnsibleError to be raised"

    # Test loading a string


# Generated at 2022-06-21 01:09:25.850508
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_basedir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), 'test', 'support', 'roles', 'test1')
    ri = RoleInclude(play=None, role_basedir=role_basedir)
    ri.load(role_basedir, ri, role_basedir)
    print(ri.role_basedir)
    print(ri.dependencies)

# Generated at 2022-06-21 01:09:52.196724
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import _load_role_definition
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager

    # Test 1
    display = Display()
    variable_manager_1 = VariableManager()
    loader_1 = DataLoader()

    data_1 = '''
---
- name: test-name
  connection: test-connection
  hosts: test-hosts
  tasks: test-tasks
  vars: test-vars
  handlers: test-handlers
'''
    role_definition = _load_role_definition(data_1, display, variable_manager_1, loader_1)


# Generated at 2022-06-21 01:10:01.008848
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        RoleInclude.load(None, None)
    except AnsibleParserError as e:
        assert 'Invalid role definition' in to_native(e)

    try:
        RoleInclude.load(10, None)
    except AnsibleParserError as e:
        assert 'Invalid role definition' in to_native(e)

    try:
        RoleInclude.load('a,b', None)
    except AnsibleError as e:
        assert 'Invalid old style role requirement' in to_native(e)

    try:
        RoleInclude.load('a', None)
        assert True
    except Exception:
        assert False

# Generated at 2022-06-21 01:10:11.258653
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.module_utils.six import PY3
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    dummy_loader = DataLoader()
    dummy_variable_mgr = None
    dummy_collection_list = None
    dummy_role = Role().load({'name': 'test_role', 'tasks': []}, loader=dummy_loader, variable_manager=dummy_variable_mgr, collection_list=dummy_collection_list)

# Generated at 2022-06-21 01:10:11.962584
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass


# Generated at 2022-06-21 01:10:12.481188
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-21 01:10:18.602876
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import unittest
    import ansible.playbook
    import ansible.module_utils.six
    import ansible.module_utils.six.moves.builtins

    # Initialise variables and mocks
    class MockPlay(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    mock_play = MockPlay(
        vars=dict(),
        vars_prompt=dict(),
        vars_files=list(),
        roles=dict()
    )

    class MockVariableManager(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    mock_variable_manager = MockVariableManager(
        extra_vars=dict()
    )


# Generated at 2022-06-21 01:10:20.877350
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude.load("", None, None, None, None, None)

# Generated at 2022-06-21 01:10:21.980808
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert 1 == 1

# Generated at 2022-06-21 01:10:26.088951
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    name = 'RoleInclude'
    play = None
    role_basedir = None
    variable_manager = None
    loader = None
    collection_list = None
    assert RoleInclude(play, role_basedir, variable_manager, loader, collection_list)

# Generated at 2022-06-21 01:10:35.011213
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    variable_manager = AnsibleCoreVars()
    loader = DataLoader()
    play = Play()
    ri = RoleInclude(play, variable_manager=variable_manager, loader=loader)
    ri.load_data("- role1", variable_manager=variable_manager, loader=loader)
    ri.load_data("- role2", variable_manager=variable_manager, loader=loader)
    ri.load_data("- role1", variable_manager=variable_manager, loader=loader)
    ri.load_data("- role3", variable_manager=variable_manager, loader=loader)
    print(ri)
    ri.post_validate(variable_manager=variable_manager, loader=loader)
    print(ri)

if __name__ == "__main__":
    test_RoleIn

# Generated at 2022-06-21 01:11:22.951605
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    if __name__ == '__main__':
        test_file_path = os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                                    "..", "..", "..", "lib", "ansible", "playbook", "role"))
        data = {'name':'app', 'roles':['role1', 'role2']}
        play = {'hosts':'127.0.0.1'}
        role = RoleInclude.load(data, play, current_role_path=test_file_path)
        assert role._delegate_to == '127.0.0.1'
        assert role._ignore_errors == False
        assert role._name == 'app'
        assert len(role._roles) == 2


# Generated at 2022-06-21 01:11:24.980337
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
   print('create RoleInclude')
   r = RoleInclude()


# Generated at 2022-06-21 01:11:34.325156
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {
        'role_definition': 'role_definition_1',
        'name': 'name_1',
        'role_path': 'role_path_1',
        'role_name': 'role_name_1',
        'default_vars': {'default_vars_a': 'default_vars_v_a'},
    }
    ri = RoleInclude(**data)
    assert ri.role_definition == 'role_definition_1'
    assert ri.name == 'name_1'
    assert ri.role_path == 'role_path_1'
    assert ri.role_name == 'role_name_1'
    assert ri.default_vars['default_vars_a'] == 'default_vars_v_a'

    ri = RoleIn

# Generated at 2022-06-21 01:11:41.492809
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.module_utils.six import string_types

    class Play:
        pass
    play = Play()

    class RoleRequirement:
        def __init__(self, data, role_basedir=None, variable_manager=None, loader=None, collection_list=None):
            pass
        def load_data(self, data, variable_manager=None, loader=None):
            pass
    rr = RoleRequirement(None)

    # Setup for test
    answer_true = True
    answer_false = False
    test

# Generated at 2022-06-21 01:11:51.901905
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'role1,role2,role3'
    play = 'web'
    current_role_path = 'ansible/playbooks'
    parent_role = ''
    variable_manager = ''
    loader = ''
    collection_list = ''

    try:
        ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader,
                         collection_list=collection_list)
        ri.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role,
                variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    except AnsibleError as e:
        assert str(e) == "Invalid old style role requirement: %s" % data

   

# Generated at 2022-06-21 01:12:00.722215
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs

    # Create a PlaybookExecutor to test the RoleInclude class constructor
    yaml_data = """
    - hosts: localhost
      tasks:
        - debug: msg="RoleInclude Constructor Unit Test"
    """
    p = Play().load(yaml_data, variable_manager=VariableManager(), loader=DataLoader())
    add_all_plugin_dirs()
    i = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    p

# Generated at 2022-06-21 01:12:05.072393
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test RoleInclude constructor
    ri = RoleInclude()
    ri.name.setdefault = "test_role_name"
    ri.name.value = "test_role_name"
    assert ri.name.setdefault == "test_role_name"
    assert ri.name.value       == "test_role_name"

# Generated at 2022-06-21 01:12:07.907721
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Returns true if the constructor for the RoleInclude class runs
    """
    return True

# Unit tests for load function of class RoleInclude

# Generated at 2022-06-21 01:12:17.516548
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = [{'name': 'myrole'}]
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    role_path = os.getcwd()
    play = Play()
    task = Task()
    task._role = RoleInclude(play=play, role_basedir=role_path)
    task._role = RoleInclude.load(data, play, current_role_path=role_path, variable_manager=None, loader=None)
    play.add_role(TaskInclude.load(data, play, variable_manager=None, loader=None))
    assert play._role_map[0]['name'] == 'myrole'

if __name__ == "__main__":
    test

# Generated at 2022-06-21 01:12:24.099472
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.requirement import RoleRequirement
    import os
    import imp
    import tempfile
    import ansible
    import ansible.module_utils.six as six
    import ansible.module_utils.six.moves.configparser as configparser
    import shlex

    collection_spec = os.path.join(os.path.dirname(ansible.__file__), 'collections', 'ansible_collections', 'testns', 'testcoll', 'tests', 'fixtures', 'plugins', 'modules')
    collection_args = shlex.split(os.environ.get('ANSIBLE_COLLECTIONS_PATHS', ''))