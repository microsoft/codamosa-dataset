

# Generated at 2022-06-23 06:44:54.108846
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:45:04.562966
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_context = dict(
        remote_addr="10.0.0.1",
        remote_user="root",
        password="123",
        port="22"
    )


# Generated at 2022-06-23 06:45:14.180315
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    class MockRole():
        def __init__(self, name):
            self.name = name

    class MockPlay():
        def __init__(self, roles, variable_manager, loader):
            self.roles = roles
            self.variable_manager = variable_manager
            self.loader = loader

        def get_roles(self, include_parent=False):
            return self.roles

    class MockVariableManager():
        def __init__(self, loader):
            self.loader = loader
            self.extra_vars = {}

        def set_extra_vars(self, new_vars):
            self.extra_vars = new_vars


# Generated at 2022-06-23 06:45:14.916856
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:45:15.454234
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-23 06:45:25.958149
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """test the static load method"""

    # if no data is provided, we should expect a failure

# Generated at 2022-06-23 06:45:38.513374
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.collection_loader import AnsibleCollectionLoader

    options = {'host_key_checking': False,
               'forks': 10,
               'become': None,
               'become_method': None,
               'become_user': None,
               'verbosity': 5}
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-23 06:45:49.345473
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    import ansible.constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    vars_manager = VariableManager()
    loader = DataLoader()
    context = PlayContext()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    templar = Templar(loader=loader, variables=vars_manager)


# Generated at 2022-06-23 06:45:49.846796
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:45:59.710860
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from units.mock.loader import DictDataLoader
    from ansible.inventory.manager import InventoryManager
    import unittest
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()



# Generated at 2022-06-23 06:46:10.586957
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.role import definition

    play_context = PlayContext()
    role_definition = RoleInclude.load(data={"role": "web"}, play=None, variable_manager=None, loader=None, collection_list=None)
    assert role_definition.get_name() is None
    role_definition = RoleInclude.load(data={}, play=None, variable_manager=None, loader=None, collection_list=None)
    assert role_definition.get_name() is None
    role_definition = RoleInclude.load(data=None, play=None, variable_manager=None, loader=None, collection_list=None)
    assert role_definition.get_name() is None

# Generated at 2022-06-23 06:46:22.869537
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class TestPlaybook:
        def __init__(self):
            self.ROLE_CACHE = '/path/to/ansible-role-cache'

    class Test:
        def __init__(self):
            self.current_path = '/path/to/current/playbook/path'

    class TestLoader:
        def __init__(self):
            pass

    class TestCollectionList:
        def __init__(self):
            pass

    class TestVariableManager:
        def __init__(self):
            self.extra_vars = 'some extra vars'

    my_play = TestPlaybook()
    my_play.ROLE_CACHE = '/path/to/ansible-role-cache'
    my_role = Test()

# Generated at 2022-06-23 06:46:35.136549
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.yaml.loader import AnsibleLoader, Reader
    from ansible.parsing.yaml import objects
    import ansible.constants as C

    role_base_dir = os.path.join(C.DEFAULT_ROLES_PATH, 't1')
    contents = '''
- include_role:
    name: test
    tags: test
    tasks_from: ok
'''
    reader = Reader()
    loader = AnsibleLoader(reader, {}, variable_manager=None)
    data = loader.get_single_data(contents)
    assert data[0]['include_role']['name'] == 'test'
    assert data

# Generated at 2022-06-23 06:46:47.605387
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )

    class LoaderMock():
        def load_from_file(self, path):
            print("Loading from file %s" % path)
            if path == "../test-playbooks/playbooks/library/test_shell.py":
                return dict(ANSIBLE_MODULE_ARGS=dict(arg1="Test"))

# Generated at 2022-06-23 06:46:51.813722
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {
        "name": "test",
        "role_name": "test_role"
    }
    role_include = RoleInclude.load(data, play=None)
    assert role_include.get_name() == "test"
    data = "test,role_name=test_role"
    role_include = RoleInclude.load(data, play=None)
    assert role_include.get_name() == "test"
    assert len(role_include.get_role_params()) == 1


# Generated at 2022-06-23 06:47:00.015460
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play

    data="""
    - include: sample-role
      some_key: some_value
    """
    play=Play.load("", variable_manager=None, loader=None)
    current_role_path='/etc/ansible/roles'

    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=None, loader=None, collection_list=None)
    ri.load_data(data, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:47:02.462973
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    t = RoleInclude.load("name", "play")
    assert isinstance(t, RoleInclude)


# Generated at 2022-06-23 06:47:06.314534
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_obj = RoleInclude(
        play=None,
        role_basedir=None,
        variable_manager=None,
        loader=None,
        collection_list=None
    )
    # RoleInclude instance created successfully
    assert test_obj



# Generated at 2022-06-23 06:47:18.634730
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def fake_loader(pathname, basedir):
        data = {}
        data['name'] = os.path.basename(pathname)
        return data

    def fake_var_manager(loader):
        return 'variable_manager'

    def fake_play(var_manager):
        play = {}
        play['variable_manager'] = var_manager
        return play

    fake_loader.get_basedir = lambda x: '/'
    fake_loader.path_dwim = lambda x,y: x
    fake_loader.list_directory = lambda x: []

    ri = RoleInclude.load('nginx',fake_play(fake_var_manager(fake_loader)),'/',loader=fake_loader)

    assert ri.get_name() == 'nginx'

# Generated at 2022-06-23 06:47:19.664055
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:47:26.060401
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = {}
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri is not None

# Generated at 2022-06-23 06:47:34.007109
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Create a dictionary with ansible modules, that overwrite the current one
    available_modules = dict()

    # Create the fake module
    def fake_module(name, args=None):
        return dict(
                    params=dict(
                                param_1=0,
                                param_2=1,
                                param_3=2,
                                )
                    )

    available_modules['fake_module'] = fake_module

    # Load the module in the loaders module path
    from ansible.plugins import loader
    loader.add_directory(os.path.join(os.path.dirname(__file__), 'modules'))

    # Create fake inventory and ansible variables
    fake_inventory = dict()
    fake_inventory['hosts'] = dict()
    fake_inventory['hosts']['host_1'] = dict

# Generated at 2022-06-23 06:47:39.952433
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert (ri._play is None)
    assert (ri._role_basedir is None)
    assert (ri._variable_manager is None)
    assert (ri._loader is None)
    assert (ri._collection_list is None)

# Generated at 2022-06-23 06:47:47.566099
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri1 = RoleInclude()
    assert ri1._play is None
    assert ri1._role_basedir is None
    assert ri1._variable_manager is None
    assert ri1._loader is None

    ri2 = RoleInclude(play='testplay', role_basedir='testdir', variable_manager='testmanager')
    assert ri2._play is 'testplay'
    assert ri2._role_basedir is 'testdir'
    assert ri2._variable_manager is 'testmanager'
    assert ri2._loader is None


# Generated at 2022-06-23 06:47:57.214282
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # param 1 data type is AnsibleBaseYAMLObject
    data = AnsibleBaseYAMLObject()
    play = dict()
    current_role_path = dict()
    parent_role = dict()
    variable_manager = dict()
    loader = dict()
    collection_list = dict()
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleError as e:
        print("AnsibleError", e)
    except Exception as e:
        print("Exception", e)

    # param 1 data type is an unicode string
    data = u'unicode'

# Generated at 2022-06-23 06:48:05.561265
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = ""
    role_basedir = ""
    variable_manager = ""
    loader = ""
    collection_list = ""
    ri = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri is not None, "Unable to create object RoleInclude"

if __name__ == "__main__":
    test_RoleInclude()

# Generated at 2022-06-23 06:48:09.086515
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:48:20.019197
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import module_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import os
    import sys

    current_dir = os.getcwd()
    options = {}
    options["listhosts"] = False
    options["listtasks"] = False
    options["listtags"] = False
    options["syntax"] = False
    options["connection"] = "local"
    options["module_path"] = None

# Generated at 2022-06-23 06:48:21.269677
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    role_include.__repr__()

# Generated at 2022-06-23 06:48:32.000157
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import pytest
    from ansible.errors import AnsibleError, AnsibleParserError
    from collections import namedtuple
    import os
    import sys
    import tempfile
    import yaml

    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.yaml_loader import AnsibleLoader

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude

    # Make a mock AnsibleLoader
    AnsibleLoaderMock = namedtuple('AnsibleLoader', 'get_basedir')

    # Make a mock play

# Generated at 2022-06-23 06:48:39.951759
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Test case to validate the working of method load of class RoleInclude
    """

    data = "test_role"
    play = 'test_play'
    current_role_path = '/var/tmp'
    parent_role = 'test_role_parent'
    variable_manager = 'test_var_manager'
    loader = 'test_loader'
    role_collection_list = None

    ri_object = RoleInclude(play, current_role_path, variable_manager, loader, role_collection_list)
    ri_object.load(data, play, current_role_path, parent_role, variable_manager, loader, role_collection_list)

# Generated at 2022-06-23 06:48:43.417207
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert r.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-23 06:48:54.335373
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test case 1:
    from ansible import playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    play = playbook.Play()

    data = ""
    try:
        RoleInclude.load(data, play, variable_manager=variable_manager, loader=loader)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    # Test case 2:
    data = {}
    try:
        RoleInclude.load(data, play, variable_manager=variable_manager, loader=loader)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    # Test case 3:
    data = ", "

# Generated at 2022-06-23 06:48:56.030322
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert isinstance(RoleInclude(), RoleInclude)


# Generated at 2022-06-23 06:48:58.507804
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    required:
        data:
            - string types
            - dict types
            - AnsibleBaseYAMLObject types
    '''
    pass

# Generated at 2022-06-23 06:49:08.143234
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    data = 'test1,test2'
    try:
        ri.load(data)
    except AnsibleError:
        assert True
    else:
        assert False

    data = 'test'
    try:
        ri.load(data)
    except AnsibleError:
        assert True
    else:
        assert False

    data = 'geerlingguy.apache,test2'
    try:
        ri.load(data)
    except AnsibleError:
        assert False
    else:
        assert False

    data = 'test.apache'
    ri.load(data)



# Generated at 2022-06-23 06:49:11.318761
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # Test calling constructor without parameter
    # for class RoleInclude, using assertRaise()
    pass

# Generated at 2022-06-23 06:49:20.895888
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_dict = dict()
    test_dict['test_data'] = "test_data"
    test_variable_manager = "test_variable_manager"
    test_loader = "test_loader"
    test_collection_list = "test_collection_list"
    ri = RoleInclude(test_dict, test_variable_manager, test_loader, test_collection_list)
    assert ri._variable_manager == test_variable_manager
    assert ri._loader == test_loader
    assert ri._collection_list == test_collection_list

# Generated at 2022-06-23 06:49:21.543350
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert True

# Generated at 2022-06-23 06:49:25.684246
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert True

# Generated at 2022-06-23 06:49:37.325945
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os, tempfile
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Args:
        connection = 'local'
        module_path = ''
        forks = 10
        become = False
        become_method = 'sudo'
        become_user = 'root'
        check = False
        diff = False
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        sudo_user = 'root'
        verbosity = 5
        start_at_task=None


# Generated at 2022-06-23 06:49:38.105215
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:49:48.542618
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-23 06:49:57.090988
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import ansible.utils.plugin_docs
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    yaml_str = '''
        - role: role1
          tasks:
            - debug: msg="role1 task1"
        - role: role2
          tasks:
            - debug: msg="role2 task1"
            - debug: msg="role2 task2"
    '''
    options = ansible.utils.plugin_docs.Options([])
    options.roles_path = os.path.join(os.path.dirname(__file__), 'roles')
    loader

# Generated at 2022-06-23 06:49:57.623622
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass



# Generated at 2022-06-23 06:49:58.884142
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # not tested
    pass

# Generated at 2022-06-23 06:50:01.026403
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-23 06:50:03.575238
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude()
    assert roleInclude is not None


# Generated at 2022-06-23 06:50:06.739695
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    This is a unit test for the constructor of the class RoleInclude
    """
    role_include = RoleInclude()
    assert (isinstance(role_include, RoleInclude))
    assert (isinstance(role_include, RoleDefinition))

# Generated at 2022-06-23 06:50:13.445514
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host, Group
    from six import StringIO
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import os     
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-23 06:50:22.625465
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    my_loader = None
    my_inventory = InventoryManager(loader=my_loader, sources='/etc/ansible/hosts')
    my_variable_manager = VariableManager(loader=my_loader, inventory=my_inventory)
    my_variable_manager._extra_vars = {'role_name': 'test'}
    my_play_context = PlayContext()
    my_play = Play.load("", variable_manager=my_variable_manager, loader=my_loader, play_context=my_play_context)

    my_play.SET_FACT_VARS = []

# Generated at 2022-06-23 06:50:35.194584
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("Testing Ansible.RoleInclude.RoleInclude.load()")
    loader = None
    variable_manager = None
    play = None
    current_role_path = os.path.join("sandbox", "roles", "test_role")
    parent_role = None
    collection_list = None
    role_definition = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)


# Generated at 2022-06-23 06:50:45.710831
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from units.mock.loader import DictDataLoader
    import os
    
    play_context = PlayContext()

# Generated at 2022-06-23 06:50:46.650345
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True


# Generated at 2022-06-23 06:50:53.137396
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.errors import AnsibleError

    mydata = { "hosts" : "host1",
               "roles" : [
                            { "inc": "include.yml",
                              "roles": "role1"
                            }
                         ]
              }
    dl = DataLoader()
    iv = InventoryManager(loader=dl, sources='localhost,')
    vm = VariableManager(loader=dl, inventory=iv)
    p = Play.load(mydata, variable_manager=vm, loader=dl)

# Generated at 2022-06-23 06:51:05.008800
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class Test_RoleInclude_load():

        def test_data_type_string_with_comma_is_invalid_old_style_role_requirement(self, monkeypatch):
            data = 'test,test'
            play = 'play'
            current_role_path = '/test'
            parent_role = 'parent_role'
            variable_manager = 'variable_manager'
            loader = 'loader'

            def test_AnsibleError(msg):
                print(msg)

            monkeypatch.setattr(AnsibleError, '__init__', test_AnsibleError)

# Generated at 2022-06-23 06:51:14.428599
# Unit test for method load of class RoleInclude

# Generated at 2022-06-23 06:51:15.848861
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Create empty RoleInclude object
    """
    r = RoleInclude()


# Generated at 2022-06-23 06:51:20.734731
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    p = Play().load({
      'name': 'test',
      'hosts': 'localhost',
      'roles': {
        'test': {
          'include_role': {
            'name': 'test',
            'tasks_from': 'test.yaml'
          }
        }
      }
    }, variable_manager=VariableManager(), loader=None)
    assert isinstance(p.roles[0], RoleInclude)
    assert p.roles[0].get_name() == 'test'

# Generated at 2022-06-23 06:51:24.283902
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    try:
        RoleInclude()
    except:
        pass
    else:
        assert False, "We expected an exception"


# Generated at 2022-06-23 06:51:32.274932
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        fake_loader = DictDataLoader({})
        RoleInclude.load('dummy string', 'dummy play', variable_manager='dummy variable manager', loader=fake_loader)
        assert False
    except AnsibleParserError as e:
        assert str(e) == 'Invalid role definition: dummy string'
    try:
        RoleRequirement.load('role1,role2', 'dummy play', variable_manager='dummy variable manager', loader=fake_loader)
        assert False
    except AnsibleError as e:
        assert str(e) == 'Invalid old style role requirement: role1,role2'

# Generated at 2022-06-23 06:51:33.182647
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:51:37.416755
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:51:44.571090
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import role_loader

    # role_definition1-1
    role_definition1 = RoleInclude(play=Play())
    role_definition1.load_data(dict(name='role-1', tasks=dict(first=dict(action=dict(module='ping')))))


# Generated at 2022-06-23 06:51:45.383283
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()

# Generated at 2022-06-23 06:51:48.332838
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test that RoleInclude constructor can be called
    assert RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-23 06:51:50.170480
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-23 06:51:53.560587
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    yaml_obj = AnsibleBaseYAMLObject('foo')
    role = RoleInclude(yaml_obj, '/foo/bar')
    assert isinstance(role, RoleDefinition)
    assert(role.role_path == '/foo/bar')
    assert(role.role_name == 'foo')

# Generated at 2022-06-23 06:52:00.285584
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    play = object()
    current_role_path = object()
    parent_role = object()
    variable_manager = object()
    loader = object()
    collection_list = object()

    data = 'string'
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ri == None


# Generated at 2022-06-23 06:52:10.803251
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six import string_types
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader

    data = dict(
        name="httpd",
        scm="git",
        scm_uri="git://github.com/ansible/ansible-examples.git",
        scm_version="v1.x",
        scm_subdir="apache"
    )
    data = RoleRequirement.load(data, play=None, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:52:11.868300
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert RoleInclude.load("mytest") == "mytest"

# Generated at 2022-06-23 06:52:17.699041
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.get_path() is None
    assert ri.get_role_name() is None
    assert ri.get_name() is None
    assert ri.get_role_params() == {}
    assert ri.get_role_dep_params() == {}

# Generated at 2022-06-23 06:52:28.670500
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.base import Base
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role_context import RoleContext

    host_list = [
        'localhost',
    ]
    loader = DataLoader()
    passwords = {}
    inventory = InventoryManager(loader=loader, sources=host_list)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 06:52:39.364699
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test that the RoleInclude.load method can load a RoleInclude object
    from an old style YAML role requirment string,
    e.g. ``apache,{role: apache, tags: foo}``
    """
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager
    import ansible.parsing.dataloader as dl
    import ansible.vars.manager as vm
    import ansible.playbook.play as play

    fake_loader = None

# Generated at 2022-06-23 06:52:40.860487
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude()
    assert r is not None

# Generated at 2022-06-23 06:52:41.821217
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude.__base__ == RoleDefinition

# Generated at 2022-06-23 06:52:53.539371
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Incomplete test coverage of RoleInclude.load() function.
    class loaderMock(object):
        def load_from_file(self, path):
            return {}

    class playMock(object):
        def get_variable_manager(self):
            return variable_managerMock()

    class variable_managerMock(object):
        def get_vars(self, play=None, host=None, task=None, include_hostvars=True):
            return {}

    loader = loaderMock()
    play = playMock()
    RoleInclude.load('xyz', play, loader=loader)



# Generated at 2022-06-23 06:53:05.015118
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test for string types for isinstance(data, string_types)
    def test_object_string_types_1(tmpdir):
        data = "name"
        play = "play"
        current_role_path = None
        parent_role = None
        variable_manager = None
        loader = None

        # Test the AnsibleError is raised
        with pytest.raises(AnsibleError) as excinfo:
            RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)

        # Test the error message
        assert "Invalid old style role requirement: name" in to_native(excinfo.value)

    # Test for list types for isinstance(data, string_types)
    def test_object_string_types_2(tmpdir):
        data = ["name"]

# Generated at 2022-06-23 06:53:08.799344
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = Play()
    play.name = "test play"
    play.hosts = ["host1", "host2"]
    play.gather_facts = False
    play.auto_handlers = False
    play.serial = 1
    play.tasks = []
    play.roles = []

    RoleInclude.load(data=[], play=play)
    try:
        RoleInclude.load(data='test,test2', play=play)
    except AnsibleError:
        pass
    try:
        RoleInclude.load(data=(), play=play)
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 06:53:11.034633
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Test the constructor of RoleInclude to see if it is working correctly
    """
    ri = RoleInclu

# Generated at 2022-06-23 06:53:16.096311
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = 'test_play'
    current_role_path = 'test_current_role_path'
    parent_role = 'test_parent_role'
    #variable_manager = 'test_variable_manager'
    #loader = 'test_loader'
    #data = 'test_data'
    x = RoleInclude.load(play, current_role_path, parent_role)

# Generated at 2022-06-23 06:53:28.950165
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', ), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-23 06:53:34.285555
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.role_name is None
    assert ri.role_path is None
    assert ri.get_vars() == {}
    assert ri.get_default_vars() == {}
    assert ri.get_role_params() == {}
    assert ri.get_role_dependencies() == []
    assert ri.get_role_metadata() == {}
    assert ri.get_tasks() == []
    assert ri.get_handlers() == []

# Generated at 2022-06-23 06:53:43.180903
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play import Playbook
    from ansible.vars.manager import VariableManager

    loader = None
    play = Playbook()
    play._variable_manager = VariableManager(loader=loader, inventory=None)
    play.load(dict(
        name='play',
        hosts=None,
        user='root',
        connection='local',
    ))

    # Pass a dictionary
    data = dict(
        name='role'
    )
    ri = RoleInclude(play=play, role_basedir=None, variable_manager=None, loader=loader)
    ri.load_data(data)
    assert ri._role_name == 'role'

    # Pass a string
    data = 'role'

# Generated at 2022-06-23 06:53:45.881666
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
      obj = RoleInclude()

# Generated at 2022-06-23 06:53:46.800833
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    result = RoleInclude()
    assert result

# Generated at 2022-06-23 06:53:58.715888
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    hostvars = {}
    host_vars_manager = VariableManager(loader=None, inventory=None)
    host_vars_manager._fact_cache = hostvars
    host_vars_manager._vault_lookup_cache = {}

    host_vars_manager._host_facts = host

# Generated at 2022-06-23 06:54:00.075537
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-23 06:54:02.030836
# Unit test for constructor of class RoleInclude
def test_RoleInclude():     

    # construct an object of class RoleInclude
    ri = RoleInclude()

# Generated at 2022-06-23 06:54:10.525880
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.plugins.loader import role_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_bytes

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.get_vars()

    role1_path = './test_role1'
    role2_path = './test_role2'


# Generated at 2022-06-23 06:54:19.372537
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.loader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import plugin_loader
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Instantiate play object
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources="")
    variable_manager.set_inventory(inventory)
    play = Play.load(dict(name="Ansible Play", hosts=['all'], gather_facts='no', tasks=[dict(action=dict(module='shell', args='ls'))]), variable_manager=variable_manager, loader=loader)
    # Instantiate plugin loader
   

# Generated at 2022-06-23 06:54:29.709334
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    #Retrieve the class RoleInclude
    RoleInclude()

    #Retrieve the metaclass of class RoleInclude
    assert RoleInclude.__class__.__name__ == 'RoleInclude'

    #Retrieve the constructor of class RoleInclude
    assert RoleInclude.__init__.__class__.__name__ == 'instancemethod'

    #Retrieve the docstring of the constructor of class RoleInclude
    assert RoleInclude.__init__.__doc__ == '\n    A derivative of RoleDefinition, used by playbook code when a role\n    is included for execution in a play.\n    '
    
    
    

# Generated at 2022-06-23 06:54:41.294298
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.play
    import ansible.playbook.role.definition
    # import ansible.playbook.task.include
    import ansible.template
    import ansible.vars

    p = ansible.playbook.play.Play()
    rd = ansible.playbook.role.definition.RoleDefinition()
    ti = ansible.playbook.task.include.TaskInclude()
    t = ansible.template.Template()
    v = ansible.vars.VariableManager()

    ri = RoleInclude()
    assert ri.load(data='geerlingguy.nginx', play=p, current_role_path=rd) == 'geerlingguy.nginx'

# Generated at 2022-06-23 06:54:52.836170
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from collections import namedtuple
    from ansible.playbook.role.description import RoleDescription
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.taggable import Taggable

    Taggable.__bases__ = (object,)
    RoleDescription.__bases__ = (object,)
    RoleMeta.__bases__ = (object,)

    role_include = RoleInclude()

    # test the init code
    assert role_include._role_path is None
    assert role_include.task_blocks == []
    assert role_include.handler_blocks == []
    assert role_include.name is None
    assert role_include.errors == []
    assert role_include._metadata is None
    assert role_include.post_validation_failed is False
    assert role_include._copy