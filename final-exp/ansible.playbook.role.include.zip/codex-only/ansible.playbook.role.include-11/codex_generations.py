

# Generated at 2022-06-23 06:44:56.641524
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    variable_manager = None
    loader = None

    data = dict( name='test-role' )
    play = Play()
    current_role_path = None
    parent_role = None
    role_req = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)

    assert role_req is not None
    assert role_req.get_name() == 'test-role'


# Generated at 2022-06-23 06:44:59.154870
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleDefinition)
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-23 06:45:00.766924
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    print(ri.__dict__)

# Generated at 2022-06-23 06:45:10.932949
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.dataloader import DataLoader
    from os.path import join
    from ansible.vars.manager import VariableManager

    fake_loader = DataLoader()

    def fake_basedir(path):
        return join("/fake/where/my/role/is")

    def fake_getloadername(path):
        return "test_collection"

    def fake_find_file(path, collection_search_paths):
        return "/fake/where/my/role/is/test_role/main.yml"

    fake_loader.get_basedir = fake_basedir
    fake_loader.get_collection_name = fake_getloadername
    fake_loader.find_file = fake_find_file

    variable_manager = VariableManager()


# Generated at 2022-06-23 06:45:22.047373
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {
        'name': 'test-role',
        'tasks': [{'debug': {'msg': 'this is a test'}}]
    }
    play = {}
    current_role_path = '/path/to/role'
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri is not None
    assert ri.get_name() == 'test-role'
    assert ri.get_tasks() == [{'debug': {'msg': 'this is a test'}}]


# Generated at 2022-06-23 06:45:31.909688
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # test for issue #34263
    data = {'role': 'apache', 'tags': ['httpd'], 'when': 'ansible_os_family != "RedHat"'}
    from ansible.playbook.play import Play
    play = Play().load(data, variable_manager=None, loader=None)
    data = {'apache': [{'tags': ['httpd'], 'when': 'ansible_os_family != "RedHat"'}]}
    import ansible.playbook.role.include
    role_include = ansible.playbook.role.include.RoleInclude(play=play, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-23 06:45:35.299464
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: Implement unit test
    # assert_equal(expected, RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader))
    assert False # TODO: implement your test here


# Generated at 2022-06-23 06:45:42.427811
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.tests.unit.test_helpers import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    import os
    import shutil
    import tempfile
    import yaml

    # create a temporary directory to hold our 'ansible' directory
    local_working_directory = tempfile.mkdtemp()

    # create a temporary directory to hold our 'ansible' directory
    local_test_file = tempfile.mkdtemp()

    # create a temporary directory to hold our 'ansible' directory
    local_test_directory = tempfile.mkdtemp()

    fd, test_task_file

# Generated at 2022-06-23 06:45:43.216603
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:45:45.203402
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Constructor for RoleInclude.
    :return: None
    """
    r_i = RoleInclude()

# Generated at 2022-06-23 06:45:54.625946
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    fake_play = dict(
        roles = [dict(
            name = 'some_role',
        )],
        roles_path = ["./test/data/test_roles"],
    )
    ri = RoleInclude(play=fake_play, role_basedir=os.path.dirname(os.path.realpath(__file__)))
    assert ri.get_name() == 'some_role'
    assert ri.role_basedir == './test/data/test_roles/some_role'
    assert ri.is_importable() == True
    assert ri.is_import_role() == True


# Generated at 2022-06-23 06:45:59.127198
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri._delegate_to is None
    assert ri._delegate_facts is False
    assert ri._role_path is None
    assert ri._role_name is None
    assert ri._role_collection is None
    assert ri._role_collection_name is None
    assert ri.play is None
    assert ri.tags == ['all']
    assert ri.tasks is None

# Generated at 2022-06-23 06:46:10.404036
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    obj = RoleInclude()
    assert obj is not None
    assert isinstance(obj, RoleInclude)
    assert obj.play is None
    assert obj.role_basedir is None
    assert obj.variable_manager is None
    assert obj.loader is None
    assert obj.collection_list is None
    assert obj.tags is None
    assert obj.ignore_errors is None
    assert obj.always_run is None
    assert obj.any_errors_fatal is None
    assert obj.become is None
    assert obj.become_user is None
    assert obj.become_method is None
    assert obj.check_mode is False
    assert obj.delegate_to is None
    assert obj.environment is None
    assert obj.role_name is None
    assert obj.role_path is None

# Generated at 2022-06-23 06:46:12.865913
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri != None

# Generated at 2022-06-23 06:46:23.878376
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Testing constructor of class RoleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    loader = DataLoader()
    options = dict(connection='local', module_path='/home/ansible/modules', forks=100, become=None, become_method=None, become_user=None, check=False, diff=False)
    passwords

# Generated at 2022-06-23 06:46:28.309799
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # create instance of RoleInclude
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:46:42.533348
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    # load() with a string
    data = "my-role"
    variable_manager = VariableManager()
    loader = DataLoader()
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    play = Play.load({'name': 'test_play1', 'hosts': 'localhost',
                      'gather_facts': 'no', 'tasks': []},
                     variable_manager=variable_manager, loader=loader)
    ri = RoleInclude.load(data, play)
   

# Generated at 2022-06-23 06:46:43.922807
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri._play is None

# Generated at 2022-06-23 06:46:51.944398
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_from_file('./test/unittest_data/test_playbook/inventory'))

    data = variable_manager.resolve_variable('role_name', variable_manager)
    variable_manager.set_fact('foo_var', 'boo_value')
    variable_manager.set_fact(UnsafeProxy({'bar_var': 'baz_value'}))


# Generated at 2022-06-23 06:47:03.117803
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = None
    collection_list = []
    play = PlayContext()

    t = RoleInclude.load(data="baz",play=play, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert t.name == "baz"
    t = RoleInclude.load(data={"role":"baz","tasks_from":"foobar"},play=play, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert t.name == "baz"
    assert t.tasks_from == "foobar"

# Generated at 2022-06-23 06:47:11.906400
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test RoleInclude.load
    """
    # Process with abs_path
    ri = RoleInclude.load("/tmp/my-role", None)
    assert ri.get_name() == "/tmp/my-role"
    assert ri.get_role_path() == "/tmp/my-role"
    assert ri.get_path() == "/tmp/my-role"

    # Process without abs_path
    ri = RoleInclude.load("my-role", None)
    assert ri.get_name() == "my-role"
    assert ri.get_role_path() == "my-role"
    assert ri.get_path() == "my-role"

    # Process with old style abs_path

# Generated at 2022-06-23 06:47:12.869262
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:47:15.098698
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Test creating a new RoleInclude object
    """
    r = RoleInclude()


# Generated at 2022-06-23 06:47:15.849942
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert True

# Generated at 2022-06-23 06:47:24.918138
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play

    fake_play_context = dict(
        forks=5,
        become=True,
        become_method='sudo',
        become_user='root',
        check=False,
        diff=False,
        listhosts=None,
        listtasks=None,
        listtags=None,
        syntax=None,
        start_at_task=None,
        verbosity=5,
        connection='ssh',
        private_key_file='/home/centos/.ssh/id_rsa',
        timeout=10,
        remote_user='centos',
        remote_pass=None,
        tags=[],
        skip_tags=[],
        host_vars={},
        group_vars={},
        run_once=False,
    )

    fake

# Generated at 2022-06-23 06:47:29.799273
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play

    p = Play().load({
        'hosts': 'all',
        'roles': [
            'test.test',
        ],
    }, variable_manager=dict(), loader=dict())

    assert isinstance(p._entries[0], RoleInclude)
    assert p._entries[0].get_name() == 'test.test'



# Generated at 2022-06-23 06:47:30.870949
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleinclude = RoleInclude()

# Generated at 2022-06-23 06:47:39.797794
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.role.definition
    import ansible.playbook.role.requirement
    playbook1 = dict(
        name = 'test',
        hosts = 'all',
        roles = ['test1']
    )

    playbook2 = dict(
        name = 'test',
        hosts = 'all',
        roles = ['test1','test2']
    )

    playbook3 = dict(
        name = 'test',
        hosts = 'all',
        roles = ['test1', dict(role='test2')]
    )

    playbook4 = dict(
        name = 'test',
        hosts = 'all',
        roles = [['test1','test2'],['test3']]
    )


# Generated at 2022-06-23 06:47:50.053666
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.play
    ri = RoleInclude(play=ansible.playbook.play.Play())
    assert ri.load({'name': 'test'}, None) == ri
    assert ri.get_name() == 'test'
    assert ri.load({'name': 'test', 'delegate_to': 'localhost'}, None) == ri
    assert ri.get_name() == 'test'
    assert ri.get_delegate_to() == 'localhost'
    assert ri.load({'name': 'test', 'delegate_to': 'localhost', 'delegate_facts': True}, None) == ri
    assert ri.get_name() == 'test'
    assert ri.get_delegate_to() == 'localhost'
    assert ri.get_

# Generated at 2022-06-23 06:47:56.523144
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play

    play = Play.load(dict(
        name="Ansible Play",
        hosts="all",
        gather_facts="no",
        roles="basics,another_role"
    ))

    assert play.get_roles_list() == ['basics', 'another_role']
    assert len(play.get_roles()) == 2

# Generated at 2022-06-23 06:48:06.069496
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # test for:
    #   - isinstance(data, string_types) or isinstance(data, dict) or isinstance(data, AnsibleBaseYAMLObject)
    yaml_data = [{'name': 'dummyname', 'hosts': 'dummyhosts'}, {'include_tasks': 'dummyinclude_tasks'}]
    for data in yaml_data:
        RoleInclude.load(data, None, None, None, None, None)

    # test for:
    #   - isinstance(data, string_types) and ',' in data
    yaml_data = ['dummyname, dummyhosts']

# Generated at 2022-06-23 06:48:09.265184
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude()

# Generated at 2022-06-23 06:48:13.762240
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play

    cstr = Play().get_dependency_injector()
    RoleInclude(play=cstr.get('play'), loader=cstr.get('loader'), variable_manager=cstr.get('vars')).post_validate()

# Generated at 2022-06-23 06:48:22.685719
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a fake RoleInclude object
    a = RoleInclude()
    assert isinstance(a, RoleInclude)
    assert isinstance(a, RoleDefinition)

    # Test without parameters
    with pytest.raises(AnsibleError) as h:
        a.load()
    assert "AnsibleError" in str(h.value)

    # Test with a string parameter
    with pytest.raises(AnsibleError) as h:
        a.load("test")
    assert "AnsibleError" in str(h.value)

    # Test with a dict parameter
    with pytest.raises(AnsibleError) as h:
        a.load({})
    assert "AnsibleError" in str(h.value)

# Generated at 2022-06-23 06:48:26.248106
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Test load function of RoleInclude

# Generated at 2022-06-23 06:48:35.864435
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    p = dict(
        name="the play",
        hosts='all',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    pc = PlayContext()
    p = Play().load(p, variable_manager=VariableManager(), loader=DataLoader())
    assert p is not None

# Generated at 2022-06-23 06:48:45.316860
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # All the valid cases of creating role object.
    # if the role successfully created, then the assertion should pass
    try:
        RoleInclude(play = "a play", role_basedir = "a role basedir", variable_manager = "a variable manager", loader = "a loader")
        assert True
    except:
        assert False

    # All the invalid cases of creating role object.
    # if the assertion passes, it means the error is properly raised and caught
    try:
        RoleInclude()
        assert False
    except:
        assert True

    # All the valid cases of objects in load() method
    # if the assertion passes, it means role object is properly created

# Generated at 2022-06-23 06:48:56.204207
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test legacy string role requirement
    data = "role1, role2"
    play = None
    current_role_path = None
    variable_manager = None
    loader = None
    collection_list=None
    try:
        ri = RoleInclude.load(data, play, current_role_path, variable_manager, loader, collection_list)
    except AnsibleError as e:
        assert str(e).startswith('Invalid old style role requirement:')

    # Test non-dict and non-string
    data = []
    play = None
    current_role_path = None
    variable_manager = None
    loader = None
    collection_list=None

# Generated at 2022-06-23 06:48:58.618778
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    p1 = RoleInclude()
    print("RoleInclude.load(): OK.")

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:49:02.811446
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    l = RoleInclude()


# TODO: remove this in Ansible 2.12, copy/pasted from role.py.
#       it is here to allow the unit tests to bootstrap.

# Generated at 2022-06-23 06:49:05.285087
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    playbook = {'hosts' : 'test', 'tasks' : []}
    play = [playbook]
    ri = RoleInclude(play=play)
    assert ri

# Generated at 2022-06-23 06:49:12.927201
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import StringIO
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins import module_utils_loader
    from ansible.plugins.callback import CallbackModule
    from ansible.template import Templar
   

# Generated at 2022-06-23 06:49:13.770278
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:49:25.274619
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Constructor using the three required parameters and one optional parameters

# Generated at 2022-06-23 06:49:37.324501
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.variable_manager import VariableManager
    from ansible.vars.manager import VarsModule
    from ansible.galaxy import Galaxy
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = {'testvar': 'testvalue'}
    inventory = None
    play_context = PlayContext(loader=loader)
    variable_manager.set_inventory(inventory)
    variable_manager.set_play_context(play_context)

    play = Play()
    play.variable_manager = variable_manager
    play.vars_prompt = {}
    play_context.accelerate

# Generated at 2022-06-23 06:49:46.048120
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    ri = RoleInclude(play=Play().load(dict(
        name = "test play",
        hosts = 'webservers',
        roles = 'test-role'
    ), variable_manager=VariableManager(), loader=DataLoader()), role_basedir='./', variable_manager=VariableManager(), loader=DataLoader())
    assert ri._role_name == 'test-role'
    assert ri._role_path == './'


# Generated at 2022-06-23 06:49:58.635676
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    host = Host(name="testhost")
    group = Group(name="all")
    group.add_host(host)

    vars_manager = VariableManager()
    vars_manager.set_inventory(host)
    vars_manager.set_inventory(group)

    vars_manager.extra_vars = {
        'var1': 'value1',
        'var2': 'value2',
        'var3': 'value3'
    }


# Generated at 2022-06-23 06:50:10.901528
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    with pytest.raises(AnsibleParserError) as ex:
        ri = RoleInclude(data=1, play=None, role_basedir='/tmp/downloads', variable_manager=None, loader=None)
    assert str(ex.value) == 'Invalid role definition: 1'
    ri = RoleInclude(data='test', play=None, role_basedir='/tmp/downloads', variable_manager=None, loader=None)
    assert ri.get_name() == 'test'
    assert ri.role_path is None
    with pytest.raises(AnsibleError) as ex:
        ri = RoleInclude(data='a,b', play=None, role_basedir='/tmp/downloads', variable_manager=None, loader=None)

# Generated at 2022-06-23 06:50:21.151741
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import pytest

    # Test with data = string
    data = "INVALID ROLE"
    with pytest.raises(AnsibleParserError) as err_info:
        RoleInclude.load(data, "")
    assert "Invalid role definition: %s" % data in str(err_info)

    # Test data = string with ','
    data = "role1,role2"
    with pytest.raises(AnsibleError) as err_info:
        RoleInclude.load(data, "")
    assert "Invalid old style role requirement: %s" % data in str(err_info)

    # Test data = dict
    data = {}
    RoleInclude.load(data, "")

    # Test data = AnsibleBaseYAMLObject

# Generated at 2022-06-23 06:50:31.049046
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    pb = Play().load({
        'name': 'test play',
        'roles': [
            {'role': 'some_role', 'delegate_to': '127.0.0.1', 'delegate_facts': True},
            {'role': 'some_role', 'delegate_to': '127.0.0.1', 'delegate_facts': True}
        ]
    })

    variable_manager = VariableManager()
    variable_manager.set_inventory(IncludedFile("dummy_inventory"))


# Generated at 2022-06-23 06:50:38.924499
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    loader = FakeLoader()
    variable_manager = FakeVariableManager()
    play = FakePlay()
    role_include = RoleInclude(play=play, role_basedir=None, variable_manager=variable_manager, loader=loader)
    data = dict(
        name='test_role'
    )

    role_include.load_data(data, variable_manager=variable_manager)
    assert role_include.name == 'test_role'


# Generated at 2022-06-23 06:50:41.766430
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # This method is not really testable, as it loads data from roles.
    assert True

# Generated at 2022-06-23 06:50:50.464053
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.executor.task_queue_manager import TaskQueueManager
    facts_collector = DistributionFactCollector()
    facts_collector.collect()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["/home/ansible/hosts"])

# Generated at 2022-06-23 06:50:51.011481
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert True==True

# Generated at 2022-06-23 06:50:51.548031
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:51:03.885597
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import get_all_plugin_loaders

    # Create the loader object, because RoleDefinition needs a loader
    loader = DataLoader()

    loader.set_basedir('../../../test/units/module_utils')
    # Create the Inventory, because the Play object will need it
    # to run the tasks.
    inventory = InventoryManager(loader=loader, sources='localhost,')
    # Create the variable_manager, because the Play object will need it
    # to run the tasks.
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create the plugin_loader

# Generated at 2022-06-23 06:51:05.007745
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:51:13.442860
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    "Test the load method of class RoleInclude"

    try:
        data = {'rolename': 'rolename'}
        RoleInclude.load(data, None)
    except Exception as e:
        if not hasattr(e, 'message'):
            raise Exception('Invalid exception type caught. expected AnsibleParserError, got {}'.format(type(e)))

    try:
        data = 'fortinet.fortigate'
        RoleInclude.load(data, None)
    except:
        raise Exception('Exception raised, exception not expected')


# Generated at 2022-06-23 06:51:14.369629
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude

# Generated at 2022-06-23 06:51:24.046947
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    in_play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ a }}')))
        ]
    ), variable_manager=VariableManager(), loader=None)

    in_context = PlayContext(play=in_play)

    a_role_include = RoleInclude()

# Generated at 2022-06-23 06:51:31.011368
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test to validate RoleInclude class load method with no arguments
    try:
        RoleInclude.load()
    except Exception as err:
        print(err)
        assert type(err) == TypeError
    # Test to validate RoleInclude class load method with invalid arguments
    try:
        RoleInclude.load("",'play', 'current_role_path', 'parent_role', 'variable_manager', 'loader')
    except Exception as err:
        print(err)
        assert type(err) == TypeError

# Generated at 2022-06-23 06:51:31.987819
# Unit test for method load of class RoleInclude

# Generated at 2022-06-23 06:51:32.537780
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:51:35.666311
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_1 = RoleInclude()
    assert isinstance(test_1, RoleInclude)
    test_2 = RoleInclude(None)
    assert isinstance(test_2, RoleInclude)

# Generated at 2022-06-23 06:51:44.197508
# Unit test for method load of class RoleInclude

# Generated at 2022-06-23 06:51:45.966223
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Test module
    """
    # Construct the object and make sure it doesn't raise any exceptions
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:51:54.484962
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    tmp_args = load_fixture('load_ansible_module_args')
    args = tmp_args['args']
    args['current_role_path'] = '/etc/ansible/roles/example'
    mod = AnsibleModule(**args)
    current_role_path = '/etc/ansible/roles/example'
    data = 'example'
    play = 'test'
    obj = RoleInclude.load(data, play, current_role_path)
    assert obj.get_name() == 'example'
    assert obj.get_role_path() == '/etc/ansible/roles/example'

# Generated at 2022-06-23 06:51:57.772286
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("\nUnit test for constructor of class RoleInclude")
    print("\n================================\n")
    ri = RoleInclude()


# Generated at 2022-06-23 06:52:02.652815
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
  pass

if __name__ == '__main__':
  test_RoleInclude()

# Generated at 2022-06-23 06:52:06.956382
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import ROLE_CACHE
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.vault import VaultLib

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = AnsibleLoader(None, None, vault_secrets=[('default', '', VaultLib(['vaultpassword']))])


# Generated at 2022-06-23 06:52:11.197233
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.vars import VariableManager

    pb = Play.load(dict(name="test", hosts=set("localhost"), roles=["myrole"]), VariableManager())
    r = RoleInclude(play=pb)
    assert r.get_name() == "myrole"



# Generated at 2022-06-23 06:52:14.246784
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'test_role'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    RoleInclude_load = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)

# Generated at 2022-06-23 06:52:16.001669
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include is not None

# Generated at 2022-06-23 06:52:16.716890
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:52:26.210761
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create RoleInclude object
    my_role_include = RoleInclude()
    # Create arguments to be passed to method load
    data = 'name'
    play = "my_play"
    current_role_path = "my_current_role_path"
    parent_role = "my_parent_role"
    variable_manager = "my_variable_manager"
    loader = "my_loader"
    collection_list = "my_collection_list"
    # Call method load with arguments
    my_role_include.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)


# Generated at 2022-06-23 06:52:33.393328
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=['localhost,'], variable_manager=variable_manager)
    play_context = dict(
        remote_user='root',
        port=22,
    )

# Generated at 2022-06-23 06:52:38.817855
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/unit/inventory'])

    # construct a base play
    play_ds = dict(
        name="Ansible Play",
        hosts="test_host",
        gather_facts="no",
        roles=[]
    )
    play = Play().load(play_ds, loader=loader, variable_manager=variable_manager, inventory=inventory)

    # load it using the static method

# Generated at 2022-06-23 06:52:41.459320
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-23 06:52:49.807982
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    tester = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert "RoleInclude" in str(tester)
    assert "Role definition" in str(tester)
    assert isinstance(tester._delegate_to, Attribute)
    assert isinstance(tester._delegate_facts, Attribute)


# Generated at 2022-06-23 06:52:59.707815
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.role.definition

    p = ansible.playbook.Play()
    ri = ansible.playbook.role.include.RoleInclude(play=p)
    # RoleInclude from dict
    assert isinstance(ri.load(
        {'role': [
         {'name': 'test'},
         {'name': 'test2'},
        ]},
    ), ansible.playbook.play.IncludedFile)
    assert isinstance(ri.load(
        {'include': [
         {'name': 'test'},
         {'name': 'test2'},
        ]},
    ), ansible.playbook.play.IncludedFile)

# Generated at 2022-06-23 06:53:00.326814
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:53:01.194907
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Instantiate class object
    role_include = RoleInclude()
    assert role_include

# Generated at 2022-06-23 06:53:01.854158
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:53:02.886798
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    x = RoleInclude()
    assert x is not None

# Generated at 2022-06-23 06:53:11.575592
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import ROLE_URI_SCHEME

    data = 'role_name'
    play = Play()
    current_role_path = '/home/user/roles_path'
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    role_include = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert role_include._role_name == 'role_name'
    assert role_include._role_path == os.path.join(ROLE_URI_SCHEME, 'role_name')



# Generated at 2022-06-23 06:53:12.440799
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert True

# Generated at 2022-06-23 06:53:15.417364
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert(ri.role_basedir == None)
    assert(ri.play == None)
    assert(ri.variable_manager == None)
    assert(ri.loader == None)

# Generated at 2022-06-23 06:53:16.498116
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    testLoad = RoleInclude()

    assert(testLoad is not None)

# Generated at 2022-06-23 06:53:17.499185
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:53:29.134230
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a RequiredData
    required_data = { "role": [ "Path to folder containing role" ] }
    # Create a Data
    data = { 'role': "Path to a role" }
    # Create a RoleInclude
    roleInclude = RoleInclude()
    # Test the scenario when data is not a string, dictionary or object
    try:
        roleInclude.load(123, None)
    except AnsibleParserError as e:
        assert "Invalid role definition" in to_native(e)

    # Test the scenario when data is a string that contains ','
    try:
        roleInclude.load("test, role", None)
    except AnsibleError as e:
        assert "Invalid old style role requirement" in to_native(e)

# Generated at 2022-06-23 06:53:29.716018
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:53:41.713747
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    # test for constructor
    play = PlayContext()
    role_basedir = '/home/user/ansible-test/roles'
    variable_manager = ''
    ri = RoleInclude(play, role_basedir, variable_manager)
    assert type(ri) == RoleInclude

    # test for method load
    data = {'role': 'toto', 'tasks': [{'debug': {'msg': 'test'}}]}
    play = PlayContext()
    role_basedir = './tests/data/playbooks/test_playbook'
    ri = RoleInclude(play, role_basedir, '')
    tmp = ri.load(data, play)
    assert tmp.get_name() == 'toto'
    assert len

# Generated at 2022-06-23 06:53:50.915191
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    include1 = RoleInclude()
    include2 = RoleInclude()

    assert include1.__class__.__name__ == 'RoleInclude'
    assert include1.__doc__ == '\n    A derivative of RoleDefinition, used by playbook code when a role\n    is included for execution in a play.\n    '
    assert include1._delegate_to.name == '_delegate_to'
    assert include1._delegate_facts.name == '_delegate_facts'

    assert include1._play == None
    assert include1._role_basedir == None
    assert include1._role_params == dict()
    assert include1._variable_manager == None
    assert include1._loader == None
    assert include1._tasks == list()
    assert include1._handlers == list()
    assert include1._

# Generated at 2022-06-23 06:53:52.721766
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude()
    assert roleInclude is not None

# Generated at 2022-06-23 06:53:56.558517
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    p = PlayContext()
    l = DataLoader()
    RoleInclude.load({}, p, variable_manager=None, loader=l)

# Generated at 2022-06-23 06:53:57.151637
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:54:05.705430
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play

    play = Play.load(dict(name='test'), variable_manager=None, loader=None)
    role_include = RoleInclude.load('test-role', play=play, current_role_path='/path/to/role', parent_role=None, variable_manager=None, loader=None)
    assert role_include._role_name == 'test-role'
    assert role_include._role_path == '/path/to/role'
    assert role_include._role_params == dict()

    role_include = RoleInclude.load('test-role', play=play, current_role_path='/path/to/role', parent_role=None, variable_manager=None, loader=None)
    assert role_include._role_name == 'test-role'

# Generated at 2022-06-23 06:54:10.216354
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = None
    role_basedir = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)


# Generated at 2022-06-23 06:54:20.713070
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
   from ansible.playbook.play_context import PlayContext
   from ansible.vars.manager import VariableManager
   from ansible.inventory.manager import InventoryManager
   from ansible.playbook.play import Play

   variable_manager = VariableManager()
   loader = DataLoader()
   variable_manager.set_loader(loader)
   inventory = InventoryManager(loader=loader, sources='')
   play_context = PlayContext(remote_user='root')
   play = Play(
       name='test',
       hosts='localhost',
       gather_facts=variable_manager.get_vars(),
       tasks=[],
       variable_manager=variable_manager,
       loader=loader,
       inventory=inventory,
       context=play_context,
   )
   test_ri = RoleInclude(play=play)
   data = test

# Generated at 2022-06-23 06:54:27.168133
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    def test_RoleInclude_fail_init():
        r = RoleInclude(0, '', '', '')
        assert(r.play == None)
        assert(r.role_basedir == '')
        assert(r.variable_manager == None)
        assert(r.loader == None)
        assert(r.collection_list == None)
    test_RoleInclude_fail_init()

# Generated at 2022-06-23 06:54:31.167901
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    #testing with empty constructor
    r = RoleInclude()

    if not r:
        raise AssertionError("RoleInclude is not an empty object")
    else:
        pass


# Generated at 2022-06-23 06:54:31.678229
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:54:40.840197
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    if __name__ == '__main__' and not os.path.exists('./test/files/file'):
        # Create file for test
        open('./test/files/file', 'w').close()
    ri = RoleInclude()
    # assert ri is an instance of class RoleInclude
    assert isinstance(ri, RoleInclude)
    # assert ri._attribute_map is a dictionary
    assert isinstance(ri._attribute_map, dict)
    # assert len(ri._attribute_map) is 6
    assert len(ri._attribute_map) == 6

# Generated at 2022-06-23 06:54:52.493509
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

    try:
        ri.load(None, None)
        raise AssertionError("AnsibleParserError has not been raised")
    except AnsibleParserError:
        pass

    try:
        ri.load(1, 2)
        raise AssertionError("AnsibleParserError has not been raised")
    except AnsibleParserError:
        pass

    try:
        ri.load(True, False)
        raise AssertionError("AnsibleParserError has not been raised")
    except AnsibleParserError:
        pass
