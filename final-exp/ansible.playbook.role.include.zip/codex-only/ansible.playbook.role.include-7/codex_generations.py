

# Generated at 2022-06-23 06:44:49.494995
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri._role_vars == dict()
    assert ri.role_name == None
    assert ri.role_path == None   
    assert ri._play == None

# Generated at 2022-06-23 06:44:53.526412
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

    assert ri is not None
    assert not ri.private
    assert not ri.vars
    assert not ri.defaults
    assert not ri._handlers

# Generated at 2022-06-23 06:45:05.479159
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader

    play_source = dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        roles = [
            dict(
                name = 'apache',
                tasks = dict(
                    debug = dict(
                        msg = 'This is a debug statement'
                    )
                ),
                handlers = dict(
                    main = dict(
                        debug = dict(
                            msg = 'This is a debug message, too'
                        )
                    )
                )
            )
        ]
    )


# Generated at 2022-06-23 06:45:14.526644
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.requiremenets import RoleRequirements
    import ansible.plugins.loader
    ri = RoleInclude()
    # ri_load = ri.load()

# Generated at 2022-06-23 06:45:15.834539
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:45:22.782376
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook.play import Play

    myPlay = Play().load({
        'name'   : 'foobar',
        'hosts'  : 'all',
        'roles'  : 'web_servers'
    }, variable_manager=None, loader=None)

    ri = RoleInclude(play = myPlay)
    ri.role_name = 'web_servers'
    ri.role_path = '/path/to/roles'
    ri.role_dependencies = []

# Generated at 2022-06-23 06:45:26.894581
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Instantiation
    ri = RoleInclude(123, [], None, None)

    assert(ri._role_path == '')
    assert(isinstance(ri.default_vars, dict))
    assert(isinstance(ri.dependencies, list))


# Generated at 2022-06-23 06:45:38.671170
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.execute import task_execute

    # Load a sample playbook into memory
    loader = DataLoader()
    playbook = Play.load('/etc/ansible/test_require.yml', loader=loader)
    # Create a task executor to run the sample playbook
    executor = task_execute.TaskExecutor()
    # Execute the sample playbook and check the output
    result = executor._run_play(playbook, None)
    assert result, "Failed sample playbook execution"
    # Get the sample playbook's tasks
    tasks = playbook._get_tasks()
    # Check the tasks have one or more RoleInclude object
    for task in tasks:
        role_include = task.role_include

# Generated at 2022-06-23 06:45:48.427029
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {'name': 'test_roleinclude_name',
            'role_path': 'test_roleinclude_role_path',
            'defaults_path': 'test_roleinclude_defaults_path',
            'vars_path': 'test_roleinclude_vars_path',
            'tasks_path': 'test_roleinclude_tasks_path',
            'meta_path': 'test_roleinclude_meta_path',
            'files_path': 'test_roleinclude_files_path',
            'handlers_path': 'test_roleinclude_handlers_path',
            'playbook_dir': 'test_roleinclude_playbook_dir'}
    ri = RoleInclude()
    ri.load_data(data)
    for key in data:
        assert getattr(ri, key)

# Generated at 2022-06-23 06:45:56.165966
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = None
    collection_list = None

    current_role_path = os.path.abspath('.')
    ri = RoleInclude(play=play_context, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri._role_basedir == current_role_path

# Generated at 2022-06-23 06:45:57.930103
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayCreate
    from ansible.vars import VariableManager
    fr

# Generated at 2022-06-23 06:45:59.972340
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:46:10.798508
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import sys
    import unittest

    sys.path.append(os.path.dirname(__file__) + "/../")
    import lib.ansible.playbook

    class TestRoleInclude(unittest.TestCase):
        def test_RoleInclude_load_string(self):
            try:
                from ansible.parsing.yaml.loader import AnsibleLoader
            except ImportError:
                from ansible.parsing.yaml.loader import BaseLoader as AnsibleLoader
            from ansible.parsing.vault import VaultLib

            yaml_text = "''"
            data = AnsibleLoader(yaml_text, vault_password=VaultLib().get_vault_password()).get_single_data()

# Generated at 2022-06-23 06:46:11.797596
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass # TODO

# Generated at 2022-06-23 06:46:13.736814
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:46:17.118189
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None)
    assert role_include is not None

# Generated at 2022-06-23 06:46:25.882343
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test loading role by name
    role_include = RoleInclude.load(data=dict(name="role_name", tasks=dict(task="some task")))

    assert role_include.get_name() == 'role_name'
    assert role_include.get_tasks() == dict(task="some task")

    # Test loading role by path
    role_include = RoleInclude.load(data=dict(name="role_name", tasks=dict(task="some task")), role_basedir=".")

    assert role_include.get_name() == 'role_name'
    assert role_include.get_tasks() == dict(task="some task")
    assert role_include.get_role_basedir() == os.path.realpath(os.path.expanduser('.'))

    # Test loading role by path

# Generated at 2022-06-23 06:46:27.493523
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    result = RoleInclude()
    assert result != None

# Generated at 2022-06-23 06:46:27.944988
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:46:42.545459
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    dl = DataLoader()
    play = Play()

    # test that a string representation of a requirement works properly
    req = 'role'
    ri = RoleInclude.load(req, play)
    assert isinstance(ri, RoleInclude)
    assert ri.get_name() == 'role'
    assert not ri.has_default_vars()
    assert ri.attributes.get('vars') is None

    # test that a dict representation of a requirement works properly
    req = {
        'role': 'role'
    }
    ri = RoleInclude.load(req, play)
    assert isinstance(ri, RoleInclude)
    assert ri.get_name()

# Generated at 2022-06-23 06:46:51.031664
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 06:46:52.557419
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print('Test constructor of class RoleInclude')


# Generated at 2022-06-23 06:47:05.143525
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    mock_data = {
        'name': 'testrole',
        'someattr': 'somevalue',
        'tasks': 'tasks',
        'handlers': 'handlers',
        'defaults': 'defaults',
        'vars': 'vars',
        'meta': 'meta',
        'otherattr': 'othervalue'
    }
    mock_role = RoleInclude()
    # If a string is passed as param to load, the method must raise an exception
    try:
        mock_role.load("not a dict")
        assert False, "RoleInclude.load() did not raise Exception"
    except AnsibleParserError:
        assert True
    # If not a string or a dict is passed, the method must raise an exception

# Generated at 2022-06-23 06:47:08.082376
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # roleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    pass


# Generated at 2022-06-23 06:47:10.159761
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleinclude = RoleInclude()
    return

# Generated at 2022-06-23 06:47:11.386385
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #TODO: Write test.
    assert True

# Generated at 2022-06-23 06:47:12.693844
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    a = RoleInclude()
    assert(isinstance(a, RoleInclude))

# Generated at 2022-06-23 06:47:19.637991
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def do_test(data, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None):
        try:
            RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
            assert False
        except AnsibleError:
            assert True

    do_test('foo,bar')
    do_test([])
    do_test({})

# Generated at 2022-06-23 06:47:32.472460
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Create a play and add the role to it
    from ansible.playbook import Play
    play_obj = Play().load({
        'name': 'Null test play',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [],
    }, variable_manager=None, loader=None)
    role_name = 'test_role'
    role_path = '/tmp/test_role'
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    task_obj = Task()
    task_obj._parent = Block()
    task_obj._role = role_name
    task_obj._role_path = role_path
    play_obj._included_filenames = ['/etc/ansible/playbook']
    # The

# Generated at 2022-06-23 06:47:39.249811
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = "test"
    current_role_path = "test2"
    parent_role = "test3"
    assert RoleInclude().__init__(
        data=data,
        play=current_role_path,
        role_basedir=parent_role,
        variable_manager=None,
        loader=None,
        collection_list=None,
    )


# Generated at 2022-06-23 06:47:40.314898
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    return ri

# Generated at 2022-06-23 06:47:43.250999
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-23 06:47:52.642299
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import collections
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.base import Base


    class MockVariableManager:
        def __init__(self):
            self.vars = None

        def get_vars(self, play=None, host=None, task=None, include_hostvars=True):
            return self.vars



# Generated at 2022-06-23 06:48:04.397867
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class DummyPlay(object):

        def __init__(self, exclude_tasks=None, exclude_handlers=None):
            self.exclude_tasks = exclude_tasks
            self.exclude_handlers = exclude_handlers

        def get_tasks(self):
            return []

    class DummyData():

        def __init__(self, data):
            self.data = data

        def __getattr__(self, name):
            return self.data[name]

    class DummyRole(object):

        def __init__(self, task_blocks, variable_manager=None, loader=None, collection_list=None):
            self.task_blocks = task_blocks
            self.variable_manager = variable_manager
            self.loader = loader
            self.collection_list = collection_list

       

# Generated at 2022-06-23 06:48:05.546817
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    obj = RoleInclude()
    assert obj.load(data=None)

# Generated at 2022-06-23 06:48:06.058001
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert True

# Generated at 2022-06-23 06:48:09.263554
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:48:12.109999
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = 'geerlingguy.ntp'
    ansible_dir = 'ansible-dir'
    ri = RoleInclu

# Generated at 2022-06-23 06:48:21.917240
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_data = {'name': 'role_name', 'tasks': [{'debug': 'role_name'}]}

    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    play = Play().load(test_data)
    play_context = PlayContext()
    task = play.get_tasks()[0]
    assert isinstance(task, RoleInclude)
    assert task.name == 'role_name'
    assert task._role_name == 'role_name'
    assert task._role_path == None
    assert task._role_params == {}
    assert task._role_opts == {}
    assert task._task == test_data['tasks'][0]
    assert task._tasks == []

# Generated at 2022-06-23 06:48:32.480039
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    play_context = PlayContext()
    variable_manager = VariableManager()

    host_list = [
        'localhost',
        'localhost',
    ]

    play = Play().load({}, loader=loader, variable_manager=variable_manager, loader_basedir='.')
    play._variable_manager = variable_manager
    play._tqm = None

# Generated at 2022-06-23 06:48:41.017849
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test for method load of RoleInclude class.
    """
    data = "name"
    play = "play"
    current_role_path = "current_role_path"
    parent_role = "parent_role"
    variable_manager = "variable_manager"
    loader = "loader"
    collection_list = "collection_list"
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert isinstance(ri, RoleInclude)
    data = ["name", "name2"]
    try:
        ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleParserError:
        assert True

# Generated at 2022-06-23 06:48:52.093264
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test old style role requirement
    data = 'some_role,some_role_variables'
    data_dict = {'include': data}
    with pytest.raises(AnsibleError) as e:
        RoleInclude.load(data_dict, None, None, None, None, None)
    assert 'Invalid old style role requirement' in str(e)
    # Test invalid role definition:
    data_list = ['some_role']
    with pytest.raises(AnsibleParserError) as e:
        RoleInclude.load(data_list, None, None, None, None, None)
    assert 'Invalid role definition' in str(e)
    # Test valid role definition:
    data_dict = {'name': 'some_role', 'include': data}
    ri = RoleInclude.load

# Generated at 2022-06-23 06:49:00.312739
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    
    role_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    variablemanager = None
    loader = None
    role = RoleInclude(role_basedir=role_path, variable_manager=variablemanager, loader=loader) 
    init_test = getattr(role, "_initialized")
    assert init_test 
    

# Generated at 2022-06-23 06:49:11.031082
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_variable_manager = {'hostvars': {'hostname': {'hostvars_hostname': 'localhost', 'ansible_host': '127.0.0.1'}}}
    test_loader = {'_basedir': '.', 'searchpath': ['/home/user/playbook']}

    test_playbook = []
    test_Include = RoleInclude(play=test_playbook, role_basedir=os.path.realpath('.'), variable_manager=test_variable_manager, loader=test_loader)
    test_var = 'hostvars_hostname'
    test_val = test_Include.get_variable_manager().get_vars(loader=None, play=None)
    assert isinstance(test_val, dict)
    assert test_var in test_val
   

# Generated at 2022-06-23 06:49:18.450248
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible import constants as C

    play_context = PlayContext()
    play_context._set_options(verbosity=0, become=C.DEFAULT_BECOME)
    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=None, loader=None)
    play._tqm._stdout_callback

# Generated at 2022-06-23 06:49:28.558119
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import pytest
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.static_vars import StaticVars
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    vault_password = os.environ.get('VAULT_PASSWORD', '')
    vault_password_file = os.environ.get('ANSIBLE_VAULT_PASSWORD_FILE', '')

    if not vault_password:
        vault_password = VaultLib(password_file=vault_password_file).read_vault_password_file()

   

# Generated at 2022-06-23 06:49:38.774476
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    current_role_path = './test/ansible/roles'
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = dict(vault_pass='secret')


# Generated at 2022-06-23 06:49:47.860268
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    variable_manager = ansible.vars.VariableManager()
    loader = DataLoader()
    play_context = PlayContext()
    action_plugins = action_loader.all(class_only=True)

    play = Play().load(
        dict(
            hosts='localhost',
            roles='myrole',
            vars={
                'ansible_connection': 'local',
            },
        ),
        variable_manager=variable_manager,
        loader=loader,
        play_context=play_context,
    )

    RoleInclude.load_data(play, 'myrole', action_plugins)

# Generated at 2022-06-23 06:49:59.893299
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    play = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'tasks': [
            {'action': {'module': 'all', 'args': 'arg'}},
        ],
    }, variable_manager=variable_manager, loader=loader)

    role_include = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:50:03.987998
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: Populate the test data
    data = None

    ri = RoleInclude()

    returned_result = ri.load(data)

    assert returned_result is not None
    assert True is True # TODO: implement your test here

# Generated at 2022-06-23 06:50:15.696035
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    from ansible.utils.display import Display

    # Logging setup
    display = Display()
    display.verbosity = 3
    display.deprecated('TEST DEPRECATED')
    display.display(u"TEST DISP")

    loader = DataLoader()
    variable_manager = VariableManager()

    play = Play().load({
            "name": "Ansible Play",
            "hosts": ["localhost"],
            "connection": "local",
            "tasks": [
                {"action": {"module": "debug",
                            "args": {"msg": "Hello, World!"}}}

            ]}, variable_manager=variable_manager, loader=loader)

    play

# Generated at 2022-06-23 06:50:17.104729
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri._play is None

# Generated at 2022-06-23 06:50:24.731760
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os, sys
    import unittest
    
    sys.path.insert(0, os.path.abspath('..'))
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    
    class TestRoleInclude(unittest.TestCase):
        def test_load(self):
            ri = RoleInclude()
            role = "../../tests/data/ansible_collections/ansible_namespace/collection_name/roles/role_name"
            data = {'role': 'role_name', 'namespace': 'ansible_namespace', 'collection': 'collection_name'}

# Generated at 2022-06-23 06:50:35.880137
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.utils.display import Display
    from units.mock.loader import DictDataLoader

    display = Display()
    variable_manager = None
    loader = DictDataLoader({})
    play_context = PlayContext()
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'hosts',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args=dict())),
                dict(action=dict(module='ping', args=dict())),
            ]
        )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    data = 'roles'
    current

# Generated at 2022-06-23 06:50:38.341379
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    res = RoleInclude._load('test', dict(role='test'))
    assert 'test' == res[0].name


# Generated at 2022-06-23 06:50:41.552574
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    p = RoleInclude()
    assert p.__class__.__name__ == 'RoleInclude'


# Generated at 2022-06-23 06:50:43.069118
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """ unit testing for class RoleInclude load method """
    pass

# Generated at 2022-06-23 06:50:48.915996
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
  current_role_path = '/home/fenglou/workspace/ec/pe/roles'
  loader = None
  variable_manager = None
  # construct an object of class Play
  play = None
  # construct an object of class RoleInclude
  ri = RoleInclude(play = play, role_basedir = current_role_path, variable_manager = variable_manager, loader = loader)
  ri.load_data('a', variable_manager = variable_manager, loader = loader)

# Generated at 2022-06-23 06:50:56.680953
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Initialize a mock play with mock variable manager and loader
    play = AutomatedPlay()
    variable_manager = VariableManager(loader=None)
    loader = DataLoader()
    data = {u'name': u'role1', u'vars': u'var1=val1 var2=val2', u'tasks': {u'name': u'task1', u'debug': u'msg1'}}
    role_1 = RoleInclude.load(data, play, variable_manager=variable_manager, loader=loader)
    var1_value = role_1.vars.get('var1')
    var2_value = role_1.vars.get('var2')
    name_value = role_1.get_name()
    assert var1_value == u'val1'

# Generated at 2022-06-23 06:51:07.481101
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    fake_loader = DataLoader()
    fake_play = Play()
    ri = RoleInclude(play=fake_play, role_basedir='/absolute_path', variable_manager=VariableManager(), loader=fake_loader)
    test_dir = os.path.dirname(__file__)
    test_data = os.path.join(test_dir, 'files/role_include')
    data = ri.load_data(test_data, variable_manager=VariableManager(), loader=fake_loader)
    assert data == test_data

    test_data2 = os.path.join(test_dir, 'files/absolute_path/../role_include')
    data = ri.load_data

# Generated at 2022-06-23 06:51:08.083963
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-23 06:51:20.724639
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import ROLE_CACHE
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.yaml.loader import AnsibleLoader

    ROLE_CACHE.clear()
    def test_data(data):
        p = Play.load(data, variable_manager=None, loader=AnsibleLoader)
        assert p is not None
        assert len(p.role_includes) == 1

    test_data({ 'hosts': 'all', 'roles': [ { 'role': 'foobar' } ] })
    test_data({ 'hosts': 'all', 'roles': [ { 'name': 'foobar' } ] })

# Generated at 2022-06-23 06:51:22.869060
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
# vim: set syntax=ansible

# Generated at 2022-06-23 06:51:30.105673
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play = Play.load({}, variable_manager=variable_manager, loader=None)
    play.load({'roles': [{'name': 'test'}]}, variable_manager=variable_manager, loader=None)


# Generated at 2022-06-23 06:51:39.423797
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.galaxy.role import GalaxyRole
    from ansible.plugins.loader import role_loader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    test_play = Play.load(dict(name = "test play", hosts = "all", gather_facts = "no", roles = [dict(name = "test")]))
    test_play_context = PlayContext(become_method='sudo', become_user='root', connection=None, network_os=None, remote_addr=None)
    test_task_vars = dict()
    test_task_vars['ansible_connection'] = 'local'
    test_task

# Generated at 2022-06-23 06:51:44.359405
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader)
    ri.load_data(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:51:47.763575
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)
    assert isinstance(ri, Attribute)
    assert isinstance(ri, object)

# Generated at 2022-06-23 06:51:52.932866
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert role.get_name() == None
    assert isinstance(role, RoleInclude)
    assert isinstance(role, RoleDefinition)
    assert isinstance(role, Attribute)
    assert isinstance(role, object)
    assert issubclass(RoleInclude, RoleDefinition)
    assert issubclass(RoleInclude, Attribute)
    assert issubclass(RoleInclude, object)

# Generated at 2022-06-23 06:52:04.145211
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-23 06:52:12.644745
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    hosts = ['localhost']
    inventory.add_group('local')
    for host in hosts:
        inventory.add_host(host, group='local')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
   

# Generated at 2022-06-23 06:52:22.501543
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    p = Play()
    task = Task()
    b = Block()
    pc = PlayContext()
    vm = VariableManager()

    ri = RoleInclude()
    ri.load_data(dict(name='role'))
    ri.post_validate(play=p)

    ri.get_vars(loader=None, play=p)



# Generated at 2022-06-23 06:52:31.128635
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.playbook.role.definition import RoleDefinition

    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        roles = [
            dict(
                name='my_role',
            ),
        ],
    ), variable_manager=dict(), loader=dict())

    role_definition = RoleDefinition.load(dict(
        name='my_role',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hi there!'))),
        ],
    ), play=play)


# Generated at 2022-06-23 06:52:36.606113
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    current_role_path = '/home/roles/a'
    data = dict(role='test-role')
    play = dict(name='test-play')
    variable_manager = 'TBD'
    loader = 'TBD'

    ri = RoleInclude.load(data, play, current_role_path)


# Generated at 2022-06-23 06:52:38.647320
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include
    assert isinstance(role_include, RoleInclude)

# Generated at 2022-06-23 06:52:39.188841
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:52:47.381651
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.executor.task_result

    play_context = PlayContext()
    play = Play().load({
            'name' : "Ansible Play",
            'hosts' : 'all',
            'gather_facts' : 'no',
            'tasks' : [
                dict(action=dict(module='raw', args='whoami')),
                dict(action=dict(module='debug', args=dict(msg="I am the test"),
                                                       sudo=True)),
                ]
            },
            variable_manager=play_context.variable_manager,
            loader=play_context.loader)

    tqm

# Generated at 2022-06-23 06:52:48.509631
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass


# Generated at 2022-06-23 06:52:58.737466
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class Dummy(object):
        pass

    collection_list = Dummy()
    collection_list.repo_paths = '/tmp'
    variable_manager = Dummy()
    variable_manager.extra_vars = dict()
    variable_manager.options_vars = dict()
    variable_manager.options_vars["inventory"] = dict()
    variable_manager.options_vars["inventory"]["basedir"] = '/tmp'
    variable_manager.options_vars["inventory"]["default_vars"] = dict()
    variable_manager.options_vars["inventory"]["variables"] = dict()
    variable_manager.options_vars["inventory"]["host_vars"] = dict()
    variable_manager.options_vars["inventory"]["group_vars"] = dict()
   

# Generated at 2022-06-23 06:52:59.914090
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-23 06:53:00.553203
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:53:06.579797
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.role_basedir is None, "Failed to initialize role basedir, default value is None"
    assert ri.variable_manager is None, "Failed to initialize variable_manager, default value is None"
    assert ri.loader is None, "Failed to initialize loader, default value is None"
    assert ri.collection_list is None, "Failed to initialize collection_list, default value is None"

# Generated at 2022-06-23 06:53:17.521185
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    loader, inventory, variable_manager = \
        _prepare_mocks(hosts=['host1', 'host2'])
    play_context = PlayContext()

# Generated at 2022-06-23 06:53:29.842126
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    import os

    playbook_path = os.path.join(os.path.dirname(__file__),
                                 os.path.pardir, os.path.pardir,
                                 'examples', 'ansible-playbook.yml')

    play = Play().load(playbook_path, variable_manager=VariableManager(), loader=DataLoader())

    play_context = PlayContext()


# Generated at 2022-06-23 06:53:39.126965
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = [{'role': 'restart-service'}]
    play = {}
    current_role_path = os.path.join('roles', 'myrole')
    parent_role = 'myrole'
    variable_manager = {}
    loader = {}
    collection_list = {}
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ri._role_name == 'restart-service'



# Generated at 2022-06-23 06:53:48.465537
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class Mockloader:
        def __init__(self, loader_data):
            self.loader_data = loader_data
            self.saved_data = None
        def load_from_file(self, path):
            self.saved_data = self.loader_data
            return self.loader_data
    class Mockvariable_manager:
        def __init__(self):
            self.saved_vars = None
    class Mockplay:
        def __init__(self, play_data):
            self.saved_data = None
            self.play_data = play_data
        def get_variable_manager(self):
            return Mockvariable_manager()
    class Mockrole_basedir:
        def __init__(self, role_basedir_data):
            self.role_basedir_data = role_

# Generated at 2022-06-23 06:53:59.405415
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Expected role definition has been loaded
    role = RoleInclude(play="myplay", role_basedir="/my/path", variable_manager="myvariable", loader="myloader", collection_list="mycollection_list")
    assert role._play == "myplay"
    assert role._role_basedir == "/my/path"
    assert role._variable_manager == "myvariable"
    assert role._loader == "myloader"
    assert role._collection_list == "mycollection_list"
    assert role._role_name == None
    assert role._role_path == None
    assert role._run_once == False
    assert role._tasks == None
    assert role._handlers == None
    assert role._default_vars == dict()
    assert role._vars == dict()
    assert role._role_vars == dict()

# Generated at 2022-06-23 06:54:09.404160
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play_context = dict(
        port=5000,
        become_method='sudo',
        become_user='root',
        remote_user='vagrant',
        remote_addr='127.0.0.1',
        password='vagrant',
        connection='ssh',
        sudo_user='root',
        forked=0,
        sudo=False,
        become=False,
        become_exe='sudo',
        no_log=False,
        diff=False)


# Generated at 2022-06-23 06:54:16.797632
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = dict(name='test', hosts='test')
    variable_manager = dict(name='test', hosts='test')
    loader = dict(name='test', hosts='test')
    collection_list = dict(name='test', hosts='test')
    test = RoleInclude(play=play, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert test._play == play
    assert test._variable_manager == variable_manager
    assert test._loader == loader
    assert test._collection_list == collection_list

# Generated at 2022-06-23 06:54:25.415296
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    ri.load(data=[], play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None)
    ri.load(data={}, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None)
    ri.load(data='ansible.builtin.postgresql', play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:54:37.748319
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class Play:
     def __init__(self):
         self.hosts = 'hosts'

    class VariableManager:
     def __init__(self):
         self.hostvars = 'hostvars'
         self.extra_vars = {}

    class Loader:
     def __init__(self):
         self.path_settings = 'path_settings'

    play=Play()
    variable_manager=VariableManager()
    loader=Loader()

    ri=RoleInclude(play=play, role_basedir='current_role_path', variable_manager=variable_manager, loader=loader)
    assert ri._play is not None
    #assert ri._variable_manager.hostvars is not None
    assert ri._loader.path_settings is not None

# Generated at 2022-06-23 06:54:46.556795
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = "role_name"
    play = None
    variable_manager = None
    loader = None
    collection_list = None
    current_role_path = None
    ri = RoleInclude(play, current_role_path, variable_manager, loader, collection_list)
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)
    assert isinstance(ri, Attribute)


# Generated at 2022-06-23 06:54:47.971585
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None