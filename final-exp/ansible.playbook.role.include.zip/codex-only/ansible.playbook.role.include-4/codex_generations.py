

# Generated at 2022-06-23 06:45:01.379710
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # test fixture
    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            dict(
                name = 'rolename'
            ),
            dict(
                name = 'rolename2'
            )
        ]
    )
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=DataLoader()))
    play = Play().load(play_source, variable_manager=variable_manager, loader=DataLoader())
    current_role_path = "/home/user/test"

# Generated at 2022-06-23 06:45:09.170862
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.requiremenst import RoleRequirement
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    current_role_path = '/home/user/playbookdir/roles'
    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play()
    role_include = RoleInclude.load('apache', play, current_role_path, variable_manager=variable_manager, loader=loader)
    assert role_include is not None


# Generated at 2022-06-23 06:45:16.193839
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test RoleInclude.load with role name
    role_name = 'test_role'
    loader = None
    coll_list = None
    var_mgr = None
    play = None
    current_role_path = None
    parent_role = None

    data = 'test_role'
    RoleInclude = RoleInclude.load(data, play, current_role_path, parent_role, var_mgr, loader, coll_list)
    assert RoleInclude._role_name == role_name

    # Test RoleInclude.load with role name and a dict
    role_name = 'test_role'
    role_args = dict()
    role_args['file'] = 'test_role.yaml'
    role_args['name'] = 'test_role'

    data = dict()

# Generated at 2022-06-23 06:45:27.769532
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook
    import ansible.parsing.yaml.objects
    
    # create object of Play
    play_obj = ansible.playbook.Play()

    # create object of Attribute
    attr_obj = ansible.playbook.attribute.Attribute()

    # create object of FieldAttribute
    field_attr_obj = ansible.playbook.attribute.FieldAttribute()

    # create object of AnsibleBaseYAMLObject
    ansible_base_yaml_obj = ansible.parsing.yaml.objects.AnsibleBaseYAMLObject()
    
    # create object of RoleInclude and invoke load method    
    role_include_obj = RoleInclude()

# Generated at 2022-06-23 06:45:29.095716
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert (ri != None)

# Generated at 2022-06-23 06:45:36.923962
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    RoleInclude: Test load method of class RoleInclude
    """
    # RoleInclude.load with valid role definition
    ri = RoleInclude.load("test", "play", variable_manager=None, loader=None)
    assert ri is not None

    # RoleInclude.load with invalid role definition
    try:
        ri = RoleInclude.load("test,test2", "play", variable_manager=None, loader=None)
        raise Exception("RoleInclude.load didn't throw exception with invalid role definition as input")
    except AnsibleError as e:
        assert to_native(e) == "Invalid old style role requirement: test,test2"

# Generated at 2022-06-23 06:45:43.528537
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.play_context
    import unittest
    import os
    import tempfile
    import shutil
    import ansible.errors
    import ansible.parsing.yaml.objects

    class TestRoleInclude(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_tempdir_exists(self):
            self.assertTrue(os.path.exists(self.temp_dir))
            self.assertTrue(os.path.isdir(self.temp_dir))

        def test_load_data_string_type_not_comma_in_data(self):
            data = "foo"
           

# Generated at 2022-06-23 06:45:54.625641
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class TestRoleDefinition(RoleDefinition):
        def __init__(self, play=None, role_basedir=None, variable_manager=None, loader=None):
            super().__init__(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader)

    # test name only
    data = 'myrolename'
    assert isinstance(RoleInclude.load(data, 'fake_play'), RoleRequirement)

    # test name and vars
    data = {'role': 'myrolename', 'vars': {'foo': 'bar'}}
    result = RoleInclude.load(data, 'fake_play')
    assert isinstance(result, RoleDefinition)
    assert result._role_name == 'myrolename'

# Generated at 2022-06-23 06:45:55.193184
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:46:01.554176
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class MockPlay(object):
        def __init__(self, **kwargs):
            self.connection = kwargs.get("connection")
            self.remote_user = kwargs.get("remote_user")
            self.become = kwargs.get("become")
            self.become_user = kwargs.get("become_user")
        def get_connection(self):
            return self.connection
        def get_remote_user(self):
            return self.remote_user
        def get_become(self):
            return self.become
        def get_become_user(self):
            return self.become_user

    class MockVariable(object):
        def __init__(self, **kwargs):
            pass

    data = {'name': 'pacman'}
   

# Generated at 2022-06-23 06:46:11.551537
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars

    fake_loader = get_loader()
    fake_loader.add_directory('./test/units/playbooks/library')
    fake_loader.add_directory('./plugins/modules')
    fake_loader.add_directory('./plugins/filter')

    fake_playbook = []
    fake_play_context = PlayContext()
    fake_variable_manager = VariableManager()
    fake_possible_var_

# Generated at 2022-06-23 06:46:23.196102
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    data = dict()

    import inspect
    import os
    import sys
    import unittest

    # Hack to load untested module
    class AnsibleParserError(Exception):
        pass
    class AnsibleError(Exception):
        pass
    class Attribute(object):
        pass
    class FieldAttribute(Attribute):
        pass
    sys.modules['ansible.errors'] = sys.modules[__name__]
    sys.modules['ansible.playbook.attribute'] = sys.modules[__name__]
    sys.modules['ansible.parsing.yaml.objects'] = sys.modules[__name__]
    from ansible.playbook.role.include import RoleInclude

    # import tested class
    class_name = 'RoleInclude'

# Generated at 2022-06-23 06:46:35.343258
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import ansible.playbook
    import ansible.inventory
    import ansible.parsing.dataloader

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.VariableManager()
    inventory = ansible.inventory.Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    play_source = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )


# Generated at 2022-06-23 06:46:36.557830
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude()
    assert r

# Generated at 2022-06-23 06:46:48.439328
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play()
    variable_manager.set_inventory(InventoryManager(loader=loader, variable_manager=variable_manager, host_list=[None]))

    assert isinstance(play, Play)
    assert isinstance(variable_manager, VariableManager)
    assert isinstance(loader, DataLoader)
    assert isinstance(TaskQueueManager, TaskQueueManager)

    # test 1

# Generated at 2022-06-23 06:46:51.204181
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include is not None

# Generated at 2022-06-23 06:46:52.657442
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-23 06:46:55.418038
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    #TODO
    pass

# Generated at 2022-06-23 06:46:57.896408
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert isinstance(RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None), RoleInclude)


# Generated at 2022-06-23 06:47:08.254787
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''Unit test for constructor of class RoleInclude'''

    field_attribute_mock = MagicMock(spec=FieldAttribute)
    role_definition_mock = MagicMock(spec=RoleDefinition)
    play_mock = MagicMock(spec=play)
    role_basedir_mock = MagicMock(spec=role_basedir)
    variable_manager_mock = MagicMock(spec=variable_manager)
    loader_mock = MagicMock(spec=loader)
    collection_list_mock = MagicMock(spec=collection_list)

    from ansible.playbook.role.definition import RoleDefinition

# Generated at 2022-06-23 06:47:11.704187
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # This testcase always fails until someone writes a correct test for it.
    # TODO: See issue #4250 for details.
    assert False

# Generated at 2022-06-23 06:47:22.116554
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar

    variable_manager = VariableManager()
    variable_manager.set_inventory(host_list=['host1','host2','host3'])
    variable_manager.set_variable('role_path', '/root/roles/')
    variable_manager.set_variable('role_path', '/root/roles/')
    variable_manager.set_variable('inventory_dir', '/root/')
    variable_manager.set_variable('x_static', 'static_value')

    templar = Templar(loader=None, variables=variable_manager)

# Generated at 2022-06-23 06:47:34.251214
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    
    play = Play.load(dict(
            name = "Ansible Play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args=''))
                ]
            ),
            variable_manager=VariableManager(), loader=DataLoader(),
            options=None, passwords=None)
    
    role_basedir = "./../Geth"
    
    variable_manager=Variable

# Generated at 2022-06-23 06:47:45.712485
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test for method load of class RoleInclude
    # 01. Cannot include a role if the role is included from a different role
    ri1 = RoleInclude()
    data1 = 'test-role'
    play1 = 'test-play'
    current_role_path1 = None
    parent_role1 = 'test-role'
    variable_manager1 = 'test-variable-manager'
    loader1 = 'test-loader'
    collection_list1 = 'test-collection-list'

# Generated at 2022-06-23 06:47:48.053449
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    i = RoleInclude(play=None, role_basedir='/etc', variable_manager=None, loader=None)
    assert(isinstance(i, RoleInclude))

# Generated at 2022-06-23 06:47:49.949441
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()

# Generated at 2022-06-23 06:48:01.322612
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ##################################################
    # Test 1: Normal use
    ##################################################
    data = '"./"'
    role = RoleInclude.load(data, None, None, None, None, None, None)
    assert len(role) == 1
    assert isinstance(role[0], RoleRequirement)
    assert role[0].role_name is None
    assert role[0].role_path is None
    assert role[0].role_collections is None
    assert role[0].role is None
    assert role[0].role_params is None
    assert role[0].role_args is None
    ##################################################
    # Test 2: Without data
    ##################################################
    data = None
    role = RoleInclude.load(data, None, None, None, None, None, None)

# Generated at 2022-06-23 06:48:08.813161
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    RoleInclude.load() is used in ansible-playbook and ansible/executor/task_result.py
    """
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    import os

    current_directory = os.path.dirname(os.path.abspath(__file__))


# Generated at 2022-06-23 06:48:10.480183
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True


# Generated at 2022-06-23 06:48:21.576751
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test the load method of class RoleInclude.
    """
    test_RoleInclude = RoleInclude()
    ansible_module_utils_six = __import__("ansible.module_utils.six", globals(), locals(), ['object'], -1)
    # Test conditions with string type data
    data = "role_name"
    play = ansible_module_utils_six.Mock()
    current_role_path = "current_role_path"
    parent_role = "parent_role"
    variable_manager = "variable_manager"
    loader = "loader"
    result = test_RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)
    assert result is not None
    # Test conditions with dict type data

# Generated at 2022-06-23 06:48:28.868255
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_basedir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'roles')
    play = Play().load(dict(hosts=hosts, roles=[]), variable_manager=variable_manager, loader=loader)
    play.post_validate()

    data = 'myrole'
    ri = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader)
    try:
        ri.load(data, variable_manager=variable_manager, loader=loader)
    except AnsibleError as e:
        assert "Invalid role definition" in str(e)
    else:
        assert False, "load should raise an exception if string doesn't contain ','."

    data = []
    ri = Role

# Generated at 2022-06-23 06:48:34.609680
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    data='test'
    play=None
    current_role_path=None
    parent_role=None
    variable_manager=None
    loader=None

    assert ri.load(data, play, current_role_path, parent_role, variable_manager, loader)


# Generated at 2022-06-23 06:48:37.653030
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()

# Generated at 2022-06-23 06:48:48.688537
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    dummy_loader = object()
    dummy_variable_manager = object()
    dummy_play = object()
    dummy_current_role_path = object()
    dummy_parent_role = object()
    role_include = RoleInclude(play=dummy_play, role_basedir=dummy_current_role_path,
                               variable_manager=dummy_variable_manager, loader=dummy_loader)
    assert role_include.play == dummy_play
    #assert role_include.role_basedir == dummy_current_role_path
    #assert role_include.parent_role == dummy_parent_role
    assert role_include.variable_manager == dummy_variable_manager
    assert role_include.loader == dummy_loader

# Generated at 2022-06-23 06:49:01.068887
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    with pytest.raises(AnsibleParserError):
        RoleInclude.load(1, None)

    with pytest.raises(AnsibleError):
        RoleInclude.load("test,test", None)

    with pytest.raises(AnsibleError):
        RoleInclude.load([1], None)

    class MockRoleRequirement():
        def __init__(self):
            pass

    with patch.object(RoleRequirement, 'load', MockRoleRequirement):
        # Just testing the role requirement loads
        assert RoleInclude.load("test", None)

# Generated at 2022-06-23 06:49:03.239367
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    This class contains no unit test for it's constructor
    """
    pass

# Generated at 2022-06-23 06:49:11.093456
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing import load as load_parser
    from ansible.playbook.play_context import PlayContext

    play = Play.load(load_parser(dict()), variable_manager=None, loader=None)
    play_context = PlayContext()

    # test with play and role_basedir
    role_include = RoleInclude(play=play, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert role_include.get_parent_attribute('play') == play
    assert role_include.get_parent_attribute('role_basedir') == None

# Generated at 2022-06-23 06:49:13.122645
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    print(ri)

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:49:24.922552
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.inventory.group import Group
    from ansible.inventory.patterns import Pattern

    yaml = """
- hosts: localhost
  roles:
    - foo.bar
  """

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:49:37.124644
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from io import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils import context_objects as co
    from ansible.vars.unsafe_proxy import UnsafeProxy
    test_data = """---
- import_playbook: /home/test/playbook.yml
- name: test1
  connection: local
- name: test2
  connection: ssh
"""
    vault_password = 'test'
    vault_text = VaultLib().encrypt(test_data, vault_password)
    test_data = '[%s]' % vault_text.strip()
    test_data = AnsibleVaultEncryptedUnicode(test_data, vault_password)

    test_loader

# Generated at 2022-06-23 06:49:42.088546
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    for input_data in ({"name": "test_role"}, "test_role"):
        role_include = RoleInclude.load(
            input_data,
            loader=None,
            variable_manager=None,
            collection_list=None
        )
        assert isinstance(role_include, RoleInclude)


# Generated at 2022-06-23 06:49:52.521577
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import pytest
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    data = {
        "name": "foobar",
        "somevar": "foobar"
    }
    current_role_path = '/home/user/.../roles'
    play = Play().load(dict(
        name="test",
        hosts=['fake_host'],
        tasks=[dict(action=dict(module='raw', args=dict(msg='test')))]
    ))
    with pytest.raises(AnsibleError):
        RoleInclude.load(data, play, current_role_path=current_role_path)

    data = {
        "name": "foobar",
        "somevar": "foobar"
    }
    current_role

# Generated at 2022-06-23 06:49:57.681284
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    u = RoleInclude.load("role1,role2", "play", "current_role_path", "parent_role", "variable_manager", "loader", "collection_list")
    assert u.__class__.__name__ == "RoleInclude"

# Generated at 2022-06-23 06:50:05.276574
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create fake AnsibleBaseYAMLObject object
    class MyAnsibleBaseYAMLObject(AnsibleBaseYAMLObject):
        pass
    # Construct class RoleInclude with fake parameters
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    role_include_list = [("string", 'string'), ("dict", dict()), ("MyAnsibleBaseYAMLObject", MyAnsibleBaseYAMLObject())]
    for role_include_item in role_include_list:
        # Load fake data with fake parameters
        ri.load_data(role_include_item[1], variable_manager=None, loader=None)

# Generated at 2022-06-23 06:50:14.499518
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml
    data = '''
- hosts: all
  tasks:
  - include_role:
      name: test
'''
    loader = AnsibleLoader(yaml.load(data), None, False)

    play_snippet = loader.get_single_data()
    play = Play().load(play_snippet, variable_manager=None, loader=loader)
    assert isinstance(play.get_tasks()[0][0], RoleInclude)

# Generated at 2022-06-23 06:50:23.155536
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [ dict(role='test') ],
        vars = dict()
    )

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    p = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    play_context = PlayContext()
   

# Generated at 2022-06-23 06:50:25.060599
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # TODO
    pass

# Generated at 2022-06-23 06:50:33.530812
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Data
    d = {'role': 'package-dummy', 'become': 'yes'}
    # Expected result
    e = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

    # Testing the load method of class RoleInclude
    assert isinstance(e.load(d, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None), \
                        RoleInclude)

# Generated at 2022-06-23 06:50:42.660978
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {}
    data['name'] = 'test_role'
    data['hosts'] = 'localhost'
    data['tasks'] = []

    ri = RoleInclude()
    ri.load_data(data)

    assert ri is not None
    role_data = ri.get_info()
    assert role_data['name'] == 'test_role'
    assert role_data['hosts'] == 'localhost'
    assert role_data['tasks'] == []


# Generated at 2022-06-23 06:50:44.815913
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-23 06:50:52.246775
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.playbook.play import Play
    from ansible.playbook.role.manager import RoleIncludeManager
    from ansible.playbook.role.requirement import RoleRequirementSpec

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # we create our own play here to control the path we follow
    # in the loaders and paths modules
    play = Play().load({}, variable_manager=VariableManager(), loader=DataLoader())

    # and we use our own loader so we can control file contents

# Generated at 2022-06-23 06:50:59.939386
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Invalid role definition
    data = [123]
    play = {}
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    try:
        ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    except AnsibleError:
        pass

    assert ri == None


# Generated at 2022-06-23 06:51:08.074878
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = dict()
    role_basedir = os.getcwd()
    variable_manager = []
    loader = []
    collection_list = []
    role_include = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    print(role_include)

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:51:09.313156
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test inheritance
    assert issubclass(RoleInclude, RoleDefinition)

# Generated at 2022-06-23 06:51:17.284272
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.playbook.play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory()

# Generated at 2022-06-23 06:51:21.979600
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    ri.load_data({'name': 'role1'})
    ri.run()
    assert ri.get_name() == 'role1'
    ri.get_dependencies()

# Generated at 2022-06-23 06:51:32.442275
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    ri = RoleInclude()
    assert isinstance(ri, RoleDefinition)
    ri = RoleInclude(loader=DataLoader(), variable_manager=VariableManager(), play=Play())
    assert isinstance(ri._loader, DataLoader)
    assert isinstance(ri._variable_manager, VariableManager)
    assert isinstance(ri._play, Play)
    ri = RoleInclude(play=Play())
    assert isinstance(ri._play, Play)
    ri = RoleInclude(role_basedir=os.path.dirname(os.path.dirname(__file__)))

# Generated at 2022-06-23 06:51:41.248084
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/test_included_role/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-23 06:51:51.262422
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.parsing.dataloader import DataLoader

    d = dict(
        name="foo",
        tasks=[]
    )
    p = Play().load(d, variable_manager=VariableManager(), loader=DataLoader())
    r = RoleInclude(play=p)
    assert r
    assert not hasattr(r, "_delegate_facts")  # Missing from test data
    assert not isinstance(r, RoleRequirement)  # Must be a role include, not a role requirement

# Generated at 2022-06-23 06:52:03.677443
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    context.CLIARGS = {}
    current_working_directory = os.path.dirname(os.path.realpath(__file__))
    loader, inventory, variable_manager = TaskQueueManager.setup_init(context.CLIARGS, current_working_directory)

    play = PlayContext()
    play.set_loader(loader)
    play.set_variable_manager(variable_manager)

    role_definition = RoleInclude(play)
    assert role_definition._role_name is None
    assert role_definition._role_path is None

    test_data = "role_definition"

# Generated at 2022-06-23 06:52:09.558090
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Create a variable manager
    var_manager = variable_manager.VariableManager()
    variable_manager.set_defaults(var_manager)

    # Initialize a RoleInclude object
    ri = RoleInclude()

    # Assert that the created object is of class RoleInclude
    assert ri.__class__ == RoleInclude

# Generated at 2022-06-23 06:52:18.022759
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    
    # test for invalid input data type
    test_data = set([1,2,3])
    try:
        ri = RoleInclude.load(test_data,1,2,3,4,5)
    except AnsibleParserError as e:
        print('Test pass!')
    
    # test for invalid role requirement
    test_data = 'test,test'
    try:
        ri = RoleInclude.load(test_data,1,2,3,4,5)
    except AnsibleError as e:
        print('Test pass!')
        
test_RoleInclude()

# Generated at 2022-06-23 06:52:20.488604
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert type(ri) == RoleInclude
    assert isinstance(ri, RoleDefinition)



# Generated at 2022-06-23 06:52:30.225285
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    ri = RoleInclude('play', 'role_basedir', 'variable_manager', 'loader')

    assert ri == ri.load('test', 'play', 'role_basedir', 'parent_role', 'variable_manager', 'loader', None)

    try:
        ri = ri.load(1, 'play', 'role_basedir', 'parent_role', 'variable_manager', 'loader', None)
        assert False
    except AnsibleParserError:
        assert True

    try:
        ri = ri.load(None, 'play', 'role_basedir', 'parent_role', 'variable_manager', 'loader', None)
        assert False
    except AnsibleParserError:
        assert True


# Generated at 2022-06-23 06:52:34.319480
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # Test for constructor, since we can't test the load() function yet
    # (it requires an AnsibleCollectionFinder() object)
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    ri = RoleInclude(play=PlayContext(), variable_manager=Attribute(), loader=DataLoader())
    assert ri is not None

    # FIXME: Unit test the load() method

# Generated at 2022-06-23 06:52:44.924140
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test roles/role1
    # Test roles/role1/tasks/main.yml
    # Test roles/role2
    # Test roles/role2/tasks/main.yml

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar

    context = PlayContext()
    loader = None
    variable_manager = None
    collection_list = None

    # No allow_duplicates:
    #   - name: role1
    #     tags: ['role2']
    #   - name: role2
    #     tags: ['role1']

# Generated at 2022-06-23 06:52:56.443929
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 06:53:03.840640
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class TestPlaybook:
        def __init__(self, variable_manager):
            self.variable_manager = variable_manager
    class TestVariableManager:
        def __init__(self):
            self.hostvars = dict()
    class TestLoader:
        def __init__(self, paths):
            self.paths = paths
    class TestCollectionList:
        def __init__(self, paths):
            self.paths = paths
    class TestCollection:
        def __init__(self, name, version, variable_manager, loader):
            self.name = name
            self.version = version
            self.variable_manager = variable_manager
            self.loader = loader
    class TestHost:
        def __init__(self, name):
            self.name = name

# Generated at 2022-06-23 06:53:13.962385
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    import os

    play_path = 'tests/test_module.py'
    current_role_path = 'ansible/playbook/role/test'
    role_path = os.path.join(current_role_path, 'role_include.yml')
    var_manager = None
    loader = None
    collection_list = None
    play = Play.load(play_path, var_manager, loader)

    # 1) Test invalid role definition
    data = [123]
    try:
        role_include = RoleInclude.load(data, play, current_role_path, var_manager, loader, collection_list)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)
        assert e.message == "Invalid role definition: 123"

    #

# Generated at 2022-06-23 06:53:14.759546
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()


# Generated at 2022-06-23 06:53:27.067058
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class TestObject(object):
        pass
    attr = Attribute()
    play = TestObject()
    play.role_basedir = None
    play.variable_manager = None
    play.loader = None
    play.collection_list = []
    test_role_include = RoleInclude(play=play)
    assert test_role_include.play is play
    assert test_role_include.role_basedir is None
    assert test_role_include.variable_manager is None
    assert test_role_include.loader is None
    assert test_role_include.collection_list == []
    assert test_role_include.attr is attr
    assert test_role_include.role_name is None
    assert test_role_include.role_path is None
    assert test_role_include.role_params is None


# Generated at 2022-06-23 06:53:29.411076
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Returns a RoleInclude instance initialized with
    the specified arguments.
    """
    return RoleInclude()

# Generated at 2022-06-23 06:53:31.546469
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-23 06:53:37.470360
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play

    t = RoleInclude(play=Play().load({
            'name' : "test play",
            'hosts' : 'all',
            'roles' : 'common'
        },
        loader=None,
        variable_manager=None
    ))
    assert t is not None

# Generated at 2022-06-23 06:53:44.089064
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri1 = RoleInclude()
    print(ri1._role_path)
    print(ri1._role_name)
    print(ri1._role_params)
    print(ri1._task_blocks)
    print(ri1._default_vars)
    print(ri1._dependency)
    print(ri1._metadata)

# Generated at 2022-06-23 06:53:53.309633
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test load with string parameter
    from ansible.playbook.tests.test_role_include import TestPlayRoleInclude
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = AnsibleLoader(None, variable_manager=None, loader=None)
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=loader, collection_list=None)

    # Create a fake inventory object

# Generated at 2022-06-23 06:53:59.558639
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    obj = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert(obj.load("httpd", play=None, current_role_path=None, parent_role=None,
                    variable_manager=None, loader=None, collection_list=None))
    assert(obj.load("httpd,1.2.3", play=None, current_role_path=None, parent_role=None,
                    variable_manager=None, loader=None, collection_list=None))
    assert(obj.load("httpd, 1.2.3", play=None, current_role_path=None, parent_role=None,
                    variable_manager=None, loader=None, collection_list=None))

# Generated at 2022-06-23 06:54:01.371255
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test creation of RoleInclude with None
    RoleInclude(None)

# Generated at 2022-06-23 06:54:03.372144
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Tested in role/definition.py
    pass


# Generated at 2022-06-23 06:54:06.717218
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude()
    assert isinstance(r, RoleInclude)
    assert isinstance(r, RoleDefinition)
    assert isinstance(r, Attribute)

# Generated at 2022-06-23 06:54:11.426049
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude
    assert isinstance(ri, object)

# Generated at 2022-06-23 06:54:13.244176
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-23 06:54:18.386078
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = {'hosts': 'dummy'}
    variable_manager = {}
    ri = RoleInclude(play=play, variable_manager=variable_manager)
    if not isinstance(ri, RoleInclude):
        raise AssertionError('Constructor must yield instance of class RoleInclude')
    else:
        return True

# Generated at 2022-06-23 06:54:21.554673
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = None
    role_basedir = None
    variable_manager = None
    loader = None
    collection_list = None
    assert RoleInclude(play, role_basedir, variable_manager, loader, collection_list)


# Generated at 2022-06-23 06:54:28.373124
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Construct an instance of class 'RoleInclude' for unit test
    RoleInclude(play=Play().load({'name': 'test', 'hosts': 'all'}),
                loader=None, variable_manager=None)

    # Construct an instance of class 'RoleInclude' with invalid play parameter
    try:
        RoleInclude(play="some_fake_play",
                    loader=None, variable_manager=None)
    except AnsibleError as e:
        pass

    # Construct an instance of class 'RoleInclude' with invalid loader parameter

# Generated at 2022-06-23 06:54:35.882779
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class DummyPlay:
        pass

    data = {"name": "role_name", "private_role_vars_1": "private_role_vars_1_value"}
    my_role_include = RoleInclude({}, role_basedir=None, variable_manager=None, loader=None, play=DummyPlay(), collection_list=None)
    my_role_include.load_data(data, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:54:41.603758
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Create an instance of class RoleInclude
    play = {'name': 'fake-play'}
    proc = RoleInclude(play = play)
    # Check that play is property of proc
    assert proc.play == play
    # Check that role_basedir is property of proc
    assert proc.role_basedir == None
    # Check that variable_manager is property of proc
    assert proc.variable_manager == None
    # Check that loader is property of proc
    assert proc.loader == None
    # Check that roles is property of proc
    assert len(proc.roles) == 0

# Generated at 2022-06-23 06:54:42.709030
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:54:51.355340
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri1 = RoleInclude.load("geerlingguy.jenkins",
                           play=None,
                           current_role_path=None,
                           parent_role=None,
                           variable_manager=None,
                           loader=None,
                           collection_list=None)
    assert isinstance(ri1, RoleInclude)
    assert ri1.original_name == "geerlingguy.jenkins"

    ri2 = RoleInclude.load("name: geerlingguy.jenkins",
                           play=None,
                           current_role_path=None,
                           parent_role=None,
                           variable_manager=None,
                           loader=None,
                           collection_list=None)
    assert isinstance(ri2, RoleInclude)
    assert ri2.original