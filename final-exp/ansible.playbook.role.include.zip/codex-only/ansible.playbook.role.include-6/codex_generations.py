

# Generated at 2022-06-23 06:44:56.255252
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.get_name() == None
    assert ri.get_role_path() == None
    assert ri.get_tasks() == []
    assert ri.get_vars() == {}
    assert ri.get_default_vars() == {}
    assert ri.get_handlers() == []
    assert ri.get_dependencies() == []

# Generated at 2022-06-23 06:45:01.278078
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri._play is None
    assert ri._role_basedir is None
    assert ri._variable_manager == dict()
    assert ri._loader is None
    assert ri._collection_list is None

# Generated at 2022-06-23 06:45:07.952519
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    rr = RoleInclude()
    if rr._role_name is not None:
        raise AssertionError("RoleInclude() constructor failed: _role_name is not None")

    if rr._role_path is not None:
        raise AssertionError("RoleInclude() constructor failed: _role_path is not None")

    if rr._role_action is not 'include':
        raise AssertionError("RoleInclude() constructor failed: _role_action is not 'include'")


# Generated at 2022-06-23 06:45:08.552852
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:45:15.847145
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.variable_manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # create everything needed for a RoleInclude
    p = Play()
    p.hosts = "localhost"
    i = InventoryManager(loader=DataLoader())
    i.hosts.add("localhost")
    v = VariableManager()

    # create the RoleInclude object
    ri = RoleInclude(play=p, role_basedir="./", variable_manager=v, loader=DataLoader())
    assert(not ri.is_meta)
    assert(isinstance(ri, RoleInclude))
    assert(isinstance(ri._play, Play))

# Generated at 2022-06-23 06:45:27.582089
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=['localhost', 'otherhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:45:29.278565
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None, "Expect RoleInclude object"

# Generated at 2022-06-23 06:45:35.650479
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test load to call other functions
    ri = RoleInclude()
    data = 'string'
    ri.load(data, 'play')
    ri.load_data('', 'variable_manager')

    # Test load to raise error
    try:
        ri.load('string' + 'string', 'play')
    except Exception as error:
        print(error)

# Generated at 2022-06-23 06:45:42.928832
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("Testing RoleInclude")
    ri = RoleInclude()
    assert ri._play is None
    assert ri._role_basedir is None
    assert ri._variable_manager is None
    assert ri._loader is None
    assert ri._collection_list is None

# Generated at 2022-06-23 06:45:54.079599
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # pylint: disable=redefined-outer-name

    import ansible.playbook.play_context

    play_context = ansible.playbook.play_context.PlayContext()

    import ansible.playbook.role.definition

    role_definition = ansible.playbook.role.definition.RoleDefinition()

    import ansible.plugins.loader

    plugin_loader = ansible.plugins.loader.PluginLoader(None)

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-23 06:45:59.847086
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    ri = RoleInclude(play=play_context, variable_manager=variable_manager, loader=loader)
    assert ri == ri.load_data("apache", variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:46:10.694116
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # 1. Passing a string, not a comma-separated role requirement
    data = 'role1'
    play = 'play1'
    current_role_path = 'role_path1'
    variable_manager = 'var1'
    loader = 'ld1'
    collection_list = 'coll_list1'
    assert RoleInclude.load(data, play, current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list) != None

    # 2. Passing a comma-separated role requirement
    data = 'role1,role2'
    play = 'play1'
    current_role_path = 'role_path1'
    variable_manager = 'var1'
    loader = 'ld1'
    collection_list = 'coll_list1'

# Generated at 2022-06-23 06:46:22.907049
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    fake_loader = lambda x: dict(foo=dict(role1=dict(tasks=[dict(action=dict(module='foo'))])))

    # Test with loads of parameters supplied
    current_role_path = '/root/ansible/playbooks'

    fake_play = Play()
    fake_play._variable_manager = VariableManager()
    fake_play._variable_manager.set_inventory(InventoryManager(loader=None))


# Generated at 2022-06-23 06:46:24.600683
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude

# Generated at 2022-06-23 06:46:25.261003
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    assert RoleInclude()

# Generated at 2022-06-23 06:46:33.995154
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    play = Play()
    variable_manager = VariableManager()
    loader = DataLoader()

    ri = RoleInclude(play=play, variable_manager=variable_manager, loader=loader)

    assert ri._play is not None
    assert ri._loader is not None
    assert ri.name is None
    assert ri.role_name is None
    assert list(ri.tasks) == []
    assert ri.default_vars == {}
    assert ri.default_task_vars == {}
    assert ri.vars == {}
    assert ri.task_vars == {}

# Generated at 2022-06-23 06:46:34.723883
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    print(role_include)

# Generated at 2022-06-23 06:46:36.471927
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play='play')
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:46:41.509215
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleinclude = RoleInclude()
    assert roleinclude.get_name() == None
    assert roleinclude.get_role_path() == None
    assert roleinclude.get_role_dependencies() == []

# Generated at 2022-06-23 06:46:42.919328
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass



# Generated at 2022-06-23 06:46:51.294464
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.variable_manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VaultSecret
    from ansible.utils.vars import load_extra_vars
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.facts import MythicalFactCollector
    from ansible.module_utils._text import to_text

    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = dict(vault_pass='secret')
    inventory = InventoryManager

# Generated at 2022-06-23 06:46:51.965112
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:47:03.569795
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    s = """
- name: test steve
  hosts: localhost
  roles:
    - some_role
    - some_role:
       delegate_to: localhost
       delegate_facts: yes
    - somesql_role
"""
    add_all_plugin_dirs()
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:47:12.207297
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    collection_list = {}
    data = "a_dummy_role_definition"
    play = RoleDefinition()
    current_role_path = "some_path/some_role"
    parent_role = "parent_role"
    variable_manager = Attribute()
    object_loader = Attribute()
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader=object_loader, collection_list=collection_list)
    assert(ri.get_name == "a_dummy_role_definition")
    assert(ri.get_dependencies == [])
    assert(ri.get_vars == [])
    assert(ri.get_default_vars == [])
    assert(ri.get_handlers == [])

# Generated at 2022-06-23 06:47:23.733847
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.variable_manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VarsManager
    from ansible.vars.reserved import Reserved

    role_path = "/test/testRoles"
    current_role_path= "/test/testRoles/test1"

    inv_data = {'all': {'hosts': {'localhost': {'connection': 'local'}}}}
    inventory = InventoryManager(loader=DataLoader(), sources=[inv_data])

    play_context = PlayContext()
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager._add_pending_override

# Generated at 2022-06-23 06:47:35.136524
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.ansible_release import __version__

# Generated at 2022-06-23 06:47:46.364443
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Create a RoleInclude object and verify that all of the data
    comes through in the repr
    """

# Generated at 2022-06-23 06:47:55.779512
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_file = "test.yml"
    test_data = "test_data"
    test_variables = "test_variables"
    test_loader = "test_loader"
    test_role_basedir = "test_role_basedir"
    ri = RoleInclude(test_file, role_basedir=test_role_basedir, variable_manager=test_variables, loader=test_loader)
    assert ri._play == test_file
    assert ri._role_basedir == test_role_basedir
    assert ri._variable_manager == test_variables
    assert ri._loader == test_loader

# Generated at 2022-06-23 06:47:56.643229
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:48:06.135180
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    play_context = PlayContext()
    play_context.VARIABLE_MANAGER = variable_manager
    play_context.LOADER = loader
    variable_manager._extra_vars = load_extra_vars(loader=loader, play=None)
    variable_manager.set_inventory(loader.inventory)


# Generated at 2022-06-23 06:48:19.108322
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # 1.Testing with role-basedir supplied and variable_manager supplied
    play = RoleInclude(play='play', role_basedir='/tmp', variable_manager='variable_manager')
    # 1.1 Testing with data supplied being string
    data = 'test_role'
    test1_1 = RoleInclude.load(data, play, current_role_path='/tmp', variable_manager='variable_manager')
    assert isinstance(test1_1, RoleInclude)
    # 1.2 Testing with data supplied being dictionary
    data = {'role': 'test_role'}
    test1_2 = RoleInclude.load(data, play, current_role_path='/tmp', variable_manager='variable_manager')
    assert isinstance(test1_2, RoleInclude)
    # 1.3 Testing with data supplied

# Generated at 2022-06-23 06:48:30.409316
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #%YAML 1.1
    #---
    #- hosts: all
    #  roles:
    #    - role: osm_roles_git.osm_roles_git
    #    - role: osm_roles_git.osm_roles_git
    yaml_doc = '''- hosts: all
                  roles:
                    - role: osm_roles_git.osm_roles_git
                    - role: osm_roles_git.osm_roles_git'''
    yaml_out = yaml.load(yaml_doc)
    #print json.dumps(yaml_out, indent=4, sort_keys=True)

    #print "----------------  Ansible playbook run  ----------------- "
    #print json.dumps(yaml_out['

# Generated at 2022-06-23 06:48:32.432049
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Unit test to inherit the constructor of RoleDefinition class

# Generated at 2022-06-23 06:48:37.064925
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play

    play = Play().load({})
    temp = RoleInclude(play=play, role_basedir=None, variable_manager=None, loader=None)
    assert temp.__class__ == RoleInclude
    assert isinstance(temp, RoleDefinition)


# Generated at 2022-06-23 06:48:38.429681
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-23 06:48:39.046438
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:48:41.415677
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    p = RoleInclude()
    assert p.get_name() == 'ROLE'

# Generated at 2022-06-23 06:48:42.956536
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude()
    assert roleInclude

# Generated at 2022-06-23 06:48:46.674983
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

    assert(ri.role_basedir == None)
    assert(ri.play == None)
    assert(ri.variable_manager == None)



# Generated at 2022-06-23 06:48:47.290757
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:48:57.705728
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=None, sources=[]))

    play = Play.load({
        'hosts': 'all',
        'roles': [
            {'name': 'role1', 'role1_param1': 'value1', 'role1_param2': 'value2'},
            'role2',
            {'name': 'role3', 'role3_param': 'value3'},
        ]
    }, variable_manager=variable_manager)

    assert play.name is None

# Generated at 2022-06-23 06:48:59.390805
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:49:10.234612
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader, [{'hosts': [{'hostname': 'localhost', 'vars': {'ansible_connection': 'local'}}]}])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with a basic role
    data = dict()
    data["name"] = "test.rolename"
    data["tasks"] = list()
    data["tasks"].append(dict(action=dict(module='debug', args=dict(msg='Test role'))))

    role = RoleInclude(loader=loader, variable_manager=variable_manager)
    role.load_

# Generated at 2022-06-23 06:49:13.127184
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    current_role_path = os.getcwd()
    collector_1 = RoleInclude(play=None, role_basedir=current_role_path)
    print(collector_1._attributes['role_basedir']._get_value())


# Generated at 2022-06-23 06:49:24.922323
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    # Test with a string (for a single role)
    role_include = RoleInclude.load(
        data='common',
        play=Play(),
        current_role_path=os.path.realpath(os.path.join(os.path.dirname(__file__), '../data/roles')),
        parent_role=None,
        loader=AnsibleLoader(None),
        collection_list=None,
        variable_manager=VariableManager()
    )

# Generated at 2022-06-23 06:49:37.124723
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    variable_manager=None
    loader=None
    collection_list=None
    ri=RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert isinstance(ri, RoleInclude)
    assert ri.meta_args == []
    assert ri.meta is None
    assert ri.collections is None
    assert ri.role_vars is None
    assert ri.role_defaults is None
    assert ri.defaults is None
    assert ri.vars is None
    assert ri.tasks is None
    assert ri.handlers is None
    assert ri.dependencies is None
    assert ri.pre_tasks is None
    assert ri.post_tasks is None
    assert ri

# Generated at 2022-06-23 06:49:42.425331
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    loader = open('/home/wang/ansible/ansible-2.7.0/lib/ansible/playbook/role/role_include.yml', 'rb')
    data = loader.read()
    ri = RoleInclude.load(data, None, None, None, None, None)
    print(ri)

test_RoleInclude()

# Generated at 2022-06-23 06:49:44.881177
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-23 06:49:52.750909
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata

    pb = Play().load({}, variable_manager=None, loader=None)
    ri = RoleInclude(pb)

    assert isinstance(ri.load("somerole", current_role_path=None, parent_role=None), RoleRequirement)
    assert isinstance(ri.load({"somerole": {}}, current_role_path=None, parent_role=None), RoleDefinition)
    assert isinstance(ri.load({"somerole": {"become": True}}, current_role_path=None, parent_role=None), RoleDefinition)

# Generated at 2022-06-23 06:49:54.737865
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:50:03.890856
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.utils.display import Display
    class fake_loader(object):
        def __init__(self):
            pass
    loader = fake_loader()

    # NOTE: This is not a complete list, but rather a short test to ensure that the
    #       necessary elements are covered.
    #
    #       Many other tests exist within the role tests to cover the majority of the
    #       necessary data.
    #

# Generated at 2022-06-23 06:50:07.382408
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert RoleInclude.load('test_role', 'play', 'role_basedir', 'variable_manager', 'loader', 'collection_list') == 'this is a test'


RoleInclude._load = RoleInclude.load


# Generated at 2022-06-23 06:50:13.750710
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import mock
    from ansible.playbook.play_context import PlayContext

    ri = RoleInclude(play=mock.Mock(), role_basedir=".", variable_manager=mock.Mock(), loader=mock.Mock(), collection_list=mock.Mock())

    with mock.patch.object(ri, 'load_data') as mocked_load_data:
        ri.load('blah', variable_manager=mock.Mock(), loader=mock.Mock())
        mocked_load_data.assert_called_once_with('blah', variable_manager=mock.ANY, loader=mock.ANY)


# Generated at 2022-06-23 06:50:14.916405
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()


# Generated at 2022-06-23 06:50:20.516713
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''
    constructor test
    '''
    # Test for class RoleInclude without parameter
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)
    # Test for class RoleInclude with parameters
    ri = RoleInclude(play='play', role_basedir=None, variable_manager='variable_manager', loader='loader', collection_list='collection_list')
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-23 06:50:24.237631
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None)

    ri._load_name_file(file_name=None, file_path=None)

# Generated at 2022-06-23 06:50:27.774425
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert ri.load('test')
    assert ri.load('test,vars')


# Generated at 2022-06-23 06:50:34.291899
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {"name": "common-services",
            "description": "This role will apply common services to the host",
            "dependencies": [],
            "default_vars": {},
            "vars": {},
            "tasks": [],
            "handlers": [],
            "meta": {}
            }
    ri = RoleInclude()
    ri.load_data(data)
    if not ri:
        raise Exception("test_RoleInclude failed")

# Generated at 2022-06-23 06:50:42.161676
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = "some_play"
    role_basedir = "some_basedir"
    variable_manager = "some_variable_manager"
    loader = "some_loader"
    collection_list = "/tmp/some_collection_list"

    role_include = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert role_include.play == play
    assert role_include.role_path == role_basedir
    assert role_include.variable_manager == variable_manager
    assert role_include.loader == loader
    assert role_include.collection_list == collection_list

# Generated at 2022-06-23 06:50:50.709223
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext

    ri = RoleInclude(play=object(), role_basedir='/foo', variable_manager=object(), loader=object(),
                     collection_list=object())

    assert ri.play == object()
    assert ri.role_basedir == '/foo'
    assert ri.variable_manager == object()
    assert ri.loader == object()
    assert ri.collection_list == object()
    assert ri.task_blocks == []
    assert ri.name is None
    assert ri.role_name is None

    assert not ri.when
    assert ri.default_vars == dict()
    assert ri.default_vars_files == []
    assert not ri.file_name

    assert not ri.handlers

# Generated at 2022-06-23 06:50:52.215063
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    role_include = RoleInclude()

# Unit testing the static method load of class RoleInclude

# Generated at 2022-06-23 06:50:56.639986
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude.__name__ == 'RoleInclude'
    assert RoleInclude().__class__.__name__ == 'RoleInclude'
    assert RoleInclude().__module__ == 'ansible.playbook.role.include'

# Generated at 2022-06-23 06:50:58.316802
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    Test to verify RoleInclude load method
    '''
    pass

# Generated at 2022-06-23 06:51:02.345054
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
  loader = None
  variable_manager = None
  play = None
  RoleInclude.load(data=None, play=play, variable_manager=variable_manager, loader=loader)
  # ToDo: test the other code lines in constructor

# Generated at 2022-06-23 06:51:13.659495
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    options = [('connection', 'ssh'), ('module_path', '/path/to/mymodules'), ('forks', '10'), ('remote_user', 'someuser'), ('private_key_file', '/path/to/some.key')]
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hosts': 'mywebserver'}
    loader = DataLoader()
    passwords = {}
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play = Role

# Generated at 2022-06-23 06:51:20.937021
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    variable_manager = PlayContext()
    ri = RoleInclude(variable_manager=variable_manager)
    assert ri.name is None
    assert ri.role_basedir is None
    assert ri.actions is None
    assert ri.default_vars is None
    assert ri.role_vars is None
    assert ri.role_path is None

# Generated at 2022-06-23 06:51:24.744641
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude.load('test')
    RoleInclude.load(None)
    RoleInclude.load(dict(name='test'))


# Generated at 2022-06-23 06:51:26.417580
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    print (ri)

# Generated at 2022-06-23 06:51:32.441969
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'name'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)


# Generated at 2022-06-23 06:51:33.913051
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()


# Generated at 2022-06-23 06:51:34.795057
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # FIXME
    pass

# Generated at 2022-06-23 06:51:42.678352
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create test variables for the unit test
    test_play = None
    test_path = '.'
    test_variable_manager = None
    test_loader = None
    test_collection_list = None

    test_parsed_data = {}
    test_parsed_data['role_0'] = {
        'name': 'role_0'
    }
    test_parsed_data['role_1'] = {
        'role_0': {
            'name': 'role_1',
            'scenario': 'scenario_0'
        }
    }

# Generated at 2022-06-23 06:51:45.813027
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test class RoleInclude.
    """
    pass


# load the role from a requirements.yml file, checking for circular dependencies in the process

# Generated at 2022-06-23 06:51:55.757220
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)
    current_role_path = os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, os.pardir, 'test', 'lib', 'ansible', 'roles', 'a_role')

# Generated at 2022-06-23 06:51:56.821965
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # TODO: implement test
    pass

# Generated at 2022-06-23 06:52:02.217636
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO
    variable_manager, loader, data, role_basedir = initialize_test()

    play = MagicMock()
    ri = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader)
    ri.load_data(data, variable_manager=variable_manager, loader=loader)


role_basedir = '/etc/ansible/roles'
collection_path = '/etc/ansible/collections'



# Generated at 2022-06-23 06:52:02.942304
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:52:04.636594
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-23 06:52:12.939719
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.utils.vars import load_extra_vars

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 06:52:24.373855
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Play
    try:
        play_context = PlayContext()
        play_source = dict(
                name = "Ansible Play",
                hosts = 'local',
                gather_facts = 'no',
                tasks = [
                    dict(action=dict(module='shell', args='ls'), register='shell_out'),
                    dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
                 ]
        )
        ri = RoleInclude(play=Play().load(play_source, play_context), role_basedir='/home/yunsheng/ansible/role', )
        assert ri
    except Exception as e:
        print(e)

# Generated at 2022-06-23 06:52:33.059673
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    test_data = {u'role': u'role_name'}
    role = RoleInclude.load(data=test_data, play=None, current_role_path=None, parent_role=None, variable_manager=variable_manager, loader=loader)
    assert role._name == u'role_name'
    assert role._get_vars()[u'role_name'] == u'role_name'

# Generated at 2022-06-23 06:52:34.181371
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:52:39.684698
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    variable_manager = None
    loader = None
    collection_list = None
    play = None
    role_basedir = None
    ri = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri

# Generated at 2022-06-23 06:52:42.556154
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri._role_path == None
    assert ri._role_name == None
    assert ri._role_action == None

# Generated at 2022-06-23 06:52:43.458410
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:52:52.905101
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    my_role_include = RoleInclude()
    my_role_definition = 'app'
    my_role_structure = {'name': 'app'}
    assert my_role_include.load(my_role_definition, None, None, None) == my_role_structure
    my_role_include = RoleInclude(loader="my_loader", variable_manager="my_variable_manager")
    assert my_role_include.load(my_role_structure, None) == my_role_structure

# Generated at 2022-06-23 06:53:04.399350
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    load method returns the data and do not raise any exception
    """
    data = 'test'
    play = 'play'
    current_role_path = 'current_role_path'
    parent_role = 'parent_role'
    variable_manager = 'variable_manager'
    loader = 'loader'
    collection_list = 'collection_list'
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    ri.load_data = MagicMock(return_value=data)

    assert ri.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list) == data
    ri.load_data.assert_called_once_

# Generated at 2022-06-23 06:53:05.473813
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleinclude = RoleInclude()


# Generated at 2022-06-23 06:53:16.240949
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    collection_list = [
        RoleRequirement.load({"role": "Ansible.pigz"}, variable_manager="", loader=""),
        RoleRequirement.load({"role": "Ansible.extras"}, variable_manager="", loader=""),
        RoleRequirement.load({"role": "fubar.foo"}, variable_manager="", loader=""),
        RoleRequirement.load({"role": "common"}, variable_manager="", loader="")
    ]
    role = RoleInclude(play="playbook", role_basedir="roles", variable_manager="", loader="", collection_list=collection_list)
    role_definition = role.load(data={"include": {"role": "Ansible.pigz"}}, variable_manager="", loader="")

# Generated at 2022-06-23 06:53:29.133805
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.collections.list import AnsibleCollectionLoader
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    play_source = '''
    - hosts: localhost
      connection: local
      tasks:
        - include_role:
            name: test1
            tasks_from: test1
    '''


# Generated at 2022-06-23 06:53:38.345156
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    map = {
        'include': {
            'name': None,
            'public': False,
            'role_path': None,
            'vars': {},
            'default_vars': False,
            'handlers': {},
            'tasks': []
        }
    }
    assert 'name' in map['include']
    assert 'role_path' in map['include']
    assert 'vars' in map['include']
    assert 'handlers' in map['include']
    assert 'tasks' in map['include']

# Generated at 2022-06-23 06:53:38.963125
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:53:39.325998
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:53:42.083348
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = dict(
        name='testrole',
        src='/home/testuser/ansible-testrole',
    )

    ri = RoleInclude.load(data,'')
    assert ri._role_name == 'testrole'
    assert ri._role_path == '/home/testuser/ansible-testrole'


# Generated at 2022-06-23 06:53:42.811284
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()

# Generated at 2022-06-23 06:53:46.591846
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    a = RoleInclude()
    assert isinstance(a, RoleDefinition)



# Generated at 2022-06-23 06:53:47.113964
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:53:59.099872
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    # load is an instance method
    # load(self, data, play, current_role_path=None, parent_role=None)

    # Prepare Ansible options

# Generated at 2022-06-23 06:54:09.253263
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test empty constructor
    role_include = RoleInclude()

    assert role_include.role_name is None
    assert role_include._role_path is None
    assert role_include.role_collection is None
    assert role_include.role_collection_name is None
    assert role_include.role_collection_namespace is None
    assert role_include.role_collection_version is None
    assert role_include.role_action is None
    assert role_include.role_action_args is None
    assert role_include._metadata is None
    assert role_include._role_params is None
    assert role_include._post_validated_data is None
    assert role_include._task_blocks is None
    assert role_include._handlers is None
    assert role_include._default_vars is None
    assert role_include

# Generated at 2022-06-23 06:54:14.910578
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {'name': 'test', 'hosts': 'testhost'}
    collection_list = []
    play = {}
    role_path = ""
    parent_role = ""
    variable_manager = ""
    loader = ""
    role_include = RoleInclude.load(data, play, role_path, parent_role, variable_manager, loader, collection_list)
    assert role_include._loader

# Generated at 2022-06-23 06:54:17.255804
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    load_data = {'role_name': 'test_role'}
    RoleInclude.load(load_data, None)

# Generated at 2022-06-23 06:54:29.055318
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    
    # Create object data
    data1 = 'apache'
    data2 = dict(name="apache")
    data3 = dict(name="apache", become="false")
    data4 = dict(name='apache', become="false", delegated_vars=dict(foo='bar'))
    data5 = dict(name='apache', become="false", gather_facts="yes")
    data6 = dict(name='apache', become="false", when="hello")

    # Create objects
    ri = RoleInclude()

    # Create variable_manager
    variable_manager = dict()

    # Create loader 
    loader = dict()
    
    # Test1: role requirement is string
    ri1 = ri.load(data1, variable_manager, loader)
    # 1.1 ri1 is AnsibleBaseYAMLObject


# Generated at 2022-06-23 06:54:40.944519
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    play = Play()
    variable_manager = VariableManager()
    loader = DataLoader()
    meta_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    collection_list = [os.path.join(meta_dir, 'ansible_collections/ansible/builtin/')]

    test_role = RoleDefinition()
    test_role.name = 'test_role'

# Generated at 2022-06-23 06:54:45.135818
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri
    # Make sure we are a subclass of RoleDefinition
    assert isinstance(ri,RoleDefinition)


# Generated at 2022-06-23 06:54:45.733847
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:54:54.397979
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test with an empty role (No role name)
    data = {}
    play = {}
    current_role_path = None
    parent_role = None
    variable_manager = {}
    loader = {}
    collection_list = {}

    with pytest.raises(AnsibleParserError):
        RoleInclude.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role,
                         variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    # Test with invalid data type
    data = 123