

# Generated at 2022-06-23 06:44:52.462632
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleDefinition)


# Generated at 2022-06-23 06:45:04.095540
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    ri = RoleInclude()
    ri.variable_manager = VariableManager()
    ri.variable_manager._fact_cache = dict(all=dict(a=1, b=2, c=3))

    # 'include_role' is not a valid key in a role
    data = {
        'include_role': 'xyz',
    }
    try:
        ri.load(data)
        assert(False)
    except AnsibleParserError:
        pass

    # 'include_role' is not a valid key in a role

# Generated at 2022-06-23 06:45:09.083213
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Playbook
    from ansible.playbook.role import RoleRequirement

    cwd = os.getcwd() # Retrieve current working directory
    p = Playbook.load('../../playbooks/test_playbooks/roles/playbook_roles.yml')
    assert isinstance(p.get_roles()[0]._role, RoleRequirement)

# Generated at 2022-06-23 06:45:13.255636
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    assert isinstance(data, string_types) and ',' in data
    assert isinstance(data, string_types) and ',' not in data
    assert isinstance(data, dict) or isinstance(data, AnsibleBaseYAMLObject)

# Generated at 2022-06-23 06:45:23.648052
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    path = os.path.dirname(os.path.realpath(__file__))
    test_yml = path + '/test_RoleInclude_load.yml'
    with open(test_yml) as f:
        yml = f.read()

    import ansible.playbook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    loader = DataLoader()
    collections = AnsibleCollectionLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost,'])

    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 06:45:27.855894
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.name == ''
    assert ri.tags == set()
    assert ri.tasks == []
    assert ri.defaults == {}
    assert ri.vars == {}
    assert ri.handlers == []

# Generated at 2022-06-23 06:45:29.190861
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:45:31.155464
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'


# Generated at 2022-06-23 06:45:33.091205
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert (RoleInclude.load("name", 1, 2, 3, 4, 5, 6) is not None)

# Generated at 2022-06-23 06:45:34.444841
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.name == 'roleinclude'

# Generated at 2022-06-23 06:45:37.276119
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri
    assert not ri._delegate_to
    assert not ri._delegate_facts
# test_RoleInclude


#

# Generated at 2022-06-23 06:45:46.976705
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    yaml_snippet = '''
    - hosts: all
      roles:
        -
          role: my_role
          my_var: some_value
          delegate_to: localhost
          delegate_facts: False
        -
          role: my_role2
          my_var2: some_value2
          delegate_to: localhost
          delegate_facts: False
    '''
    yaml_obj = RoleInclude.load(yaml_snippet, None)
    assert yaml_obj.name == "my_role"
    assert yaml_obj._delegate_to == "localhost"
    assert yaml_obj._delegate_facts == False

# Generated at 2022-06-23 06:45:50.229640
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: This is just a placeholder. Remove this once you add tests
    assert True

# Generated at 2022-06-23 06:45:59.859052
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert isinstance(ri.load('role1'), RoleRequirement)
    assert isinstance(ri.load('role1, role2'), RoleRequirement)
    assert isinstance(ri.load('role1,role2'), RoleRequirement)
    assert isinstance(ri.load(dict(role='role1')), RoleRequirement)
    assert isinstance(ri.load(dict(role='role1, role2')), RoleRequirement)
    assert isinstance(ri.load(dict(role='role1,role2')), RoleRequirement)

    assert isinstance(ri.load(dict(name='role1')), RoleRequirement)
    assert isinstance(ri.load(dict(name='role1', tasks_from='main')), RoleRequirement)

# Generated at 2022-06-23 06:46:10.696310
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test case 1:
    # Test case when data is a string_types
    data = "role1"
    play = "play.yml"
    RoleInclude.load(data, play)

# Test case 2:
# Test case when data is a dict
    data = {'role1': 'role1'}
    RoleInclude.load(data, play)

# Test case 3:
# Test case when data is a class AnsibleBaseYAMLObject
    data = AnsibleBaseYAMLObject("role1")
    RoleInclude.load(data, play)

# Test case 4:
# Test case when data is a class AnsibleBaseYAMLObject
    data = "role1,role2"

# Generated at 2022-06-23 06:46:17.118041
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible import context
    from ansible.playbook import Play
    from ansible.vars import VariableManager

    ri = RoleInclude(play=Play(), role_basedir="role_basedir", variable_manager=VariableManager(loader=context.Loader()))
    ri.load_data("role_name")

# Generated at 2022-06-23 06:46:25.882221
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.plugins.loader import action_loader, lookup_loader, filter_loader
    from ansible.template import Templar
    
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_inventory('tests/unit/inventory.yml'))
    variable_manager.set_extra_vars(RoleRequirement.load_extra_vars(variable_manager, 'tests/unit/', loader))
    play_

# Generated at 2022-06-23 06:46:31.556526
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import pytest
    from ansible.playbook.role.definition import RoleDefinition

    data = {}
    play = RoleDefinition()
    # current_role_path = None
    # parent_role = None
    # variable_manager = None
    # loader = None
    # collection_list = None
    role_include = RoleInclude.load(data, play)

    assert isinstance(role_include, RoleInclude)

# Generated at 2022-06-23 06:46:33.402221
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    Unit tests for RoleInclude.load()
    '''
    pass

# Generated at 2022-06-23 06:46:44.940696
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list='/dev/null'))
    play_context = PlayContext(variable_manager=variable_manager, loader=loader)
    play = Play().load({'name': 'foobar', 'hosts': 'all'}, variable_manager=variable_manager, loader=loader)
    # test string

# Generated at 2022-06-23 06:46:51.917513
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-23 06:47:03.520767
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.task.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.block import Block
    from ansible.module_utils.six import iteritems
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.loader import action_loader, cache_loader, callback_loader, connection_loader, lookup_loader, shell_loader, strategy_loader, test_loader


# Generated at 2022-06-23 06:47:05.380021
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    "This is the page to edit to run unittest"
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 06:47:13.290636
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play

    # simple string
    play = Play()
    play.variable_manager.extra_vars = dict(
        sdk_root="/path/to/sdk/root",
    )

# Generated at 2022-06-23 06:47:14.562669
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:47:24.011287
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Testing method load of class RoleInclude"""
    data = dict(
        name = "name",
        tasks = dict(
            main = dict(
                include = "include",
                meta = dict(
                    key = "value"
                )
            )
        )
    )
    
    play = {}
    current_role_path = ""
    parent_role = None
    variable_manager = {}
    loader = None
    collection_list = None

    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)


# Generated at 2022-06-23 06:47:32.781405
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #Prepare variable
    data = 'foo,bar,baz'

    #Create an instance of class RoleInclude
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

    #Act and Assert
    try:
        return ri.load(data, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    except Exception as e:
        assert(isinstance(e, AnsibleError))

# Generated at 2022-06-23 06:47:37.597680
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
  ri = RoleInclude()
  role = ri.load({"name": "role1", "path":"./roles/role1", "tasks": [{'name':'task1'}]})
  print(role.name)
  assert role.name == 'role1'
  print(role.tasks)
  assert len(role.tasks) == 1



# Generated at 2022-06-23 06:47:48.812464
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.yaml.loader import AnsibleLoader

    variable_manager=None
    loader=None
    collection_list=None


# Generated at 2022-06-23 06:47:52.921180
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None
    assert ri._play is None
    assert ri._role_basedir is None
    assert ri._variable_manager is None
    assert ri._loader is None
    assert ri._role_params is None
    assert ri._role_default_vars is None
    assert ri._metadata is None
    assert ri._collection_list is None

# Generated at 2022-06-23 06:47:55.522331
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    s = RoleInclude()
    assert isinstance(s, RoleInclude)

# Generated at 2022-06-23 06:48:05.547240
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMeta

    host_pattern = 'host.domain.com'
    hosts = 'host.domain.com'
    name = 'foobar'
    file_name = '/tmp/foo.yml'
    roles = [{'foobar': {'hosts': 'host.domain.com'}}]
    tqm = None


# Generated at 2022-06-23 06:48:12.595351
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Created temporary files and directories used in test
    temp_dir_path = tempfile.mkdtemp()

    # Created a temporary file used for testing
    temp_file = tempfile.NamedTemporaryFile(prefix='ansible-temp-', delete=False)
    temp_file.close()
    temp_file_path = temp_file.name
    temp_file = open(temp_file_path, 'w')
    temp_file.writelines(b'''
        foo:
          bar: baz
        '''
    )
    temp_file.close()

    data = "roles: [name: %s]" % temp_file_path

# Generated at 2022-06-23 06:48:22.547082
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    Unit test for method load of class RoleInclude
    '''

    ## If data is not a string, dict or AnsibleBaseYAMLObject instance, an AnsibleParserError is thrown
    # AnsibleBaseYAMLObject is the parent class of AnsibleMapping and AnsibleSequence
    # Test AnsibleMapping
    class TestAnsibleMapping(AnsibleBaseYAMLObject):
        '''
        A test class inherited from AnsibleBaseYAMLObject
        '''
        pass

    ansiblemapping = TestAnsibleMapping()

    # Test AnsibleSequence
    class TestAnsibleSequence(AnsibleBaseYAMLObject):
        '''
        A test class inherited from AnsibleBaseYAMLObject
        '''
        pass

    ansiblesequence = TestAns

# Generated at 2022-06-23 06:48:25.532765
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()

# Generated at 2022-06-23 06:48:27.924541
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:48:30.463487
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-23 06:48:40.095524
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    yaml_obj = AnsibleUnicode('host.example.com')

    # yaml_obj is an AnsibleUnicode object
    assert isinstance(yaml_obj, AnsibleUnicode)
    assert isinstance(yaml_obj, string_types)

    # Play instance

# Generated at 2022-06-23 06:48:40.689840
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    #TODO: write unit test
    pass

# Generated at 2022-06-23 06:48:51.856591
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test role_basedir
    role_basedir = '/etc/ansible/roles/my_role'
    ri = RoleInclude(role_basedir=role_basedir, loader=None)
    assert ri._role_basedir == '/etc/ansible/roles/my_role'

    # test load, test old style role definition
    yaml_loader = DummyObject()
    play = DummyObject()
    
    ri = RoleInclude(role_basedir=role_basedir, loader=None, variable_manager=None, play=play)
    ri.load(data='my_role', variable_manager=None, loader=yaml_loader)
    assert play.set_loader_called == 1
    assert play.set_variable_manager_called == 1
    assert play.add_role

# Generated at 2022-06-23 06:48:52.772122
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None


# Generated at 2022-06-23 06:48:57.642188
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test for method load of class RoleInclude

    Args:
       None

    Returns:
       None

    Raises:
       None
    """
    print('=== test_RoleInclude_load')
    role_include = RoleInclude()
    # test success
    try:
        role_include.load({'test':'test'},None)
    except AnsibleError:
        assert False

    role_include.load(None,None)

    # test failure
    try:
        role_include.load({1:1},None)
    except AnsibleParserError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 06:49:09.786758
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.playbook.role.definition import RoleDefinition, RoleRequirement

    loader = DataLoader()
    variable_manager = {}
    current_role_path = '/tmp'
    collection_list = []

    # data is not string or dict
    # should raise exception
    data = ['hello', 'world']
    try:
        RoleInclude.load(data, None, current_role_path, None, variable_manager, loader, collection_list)
        assert False
    except AnsibleParserError as e:
        assert str(e) == 'Invalid role definition: [hello, world]'

    # data is string and contains ','
    data = 'hello,world'

# Generated at 2022-06-23 06:49:12.529340
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = dict(
        name = dict(
            name='test'
        ),
        role = []
    )

    role = RoleInclude(data)

    name = role.get_name()
    assert name == 'test'
    assert isinstance(name, string_types)

# Generated at 2022-06-23 06:49:24.808003
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class AnsibleModule:
        def __init__(self, **kwargs):
            self.params = kwargs

    class VariableManager:
        def __init__(self, **kwargs):
            self.options = kwargs

    class Play:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    play = Play(connection='local', hosts=['127.0.0.1'], gather_facts='no')

    var_mgr = VariableManager(vault_password='test')


# Generated at 2022-06-23 06:49:29.573426
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-23 06:49:32.445001
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # This test is not really testing anything, it is just to get full code coverage
    ri = RoleInclude()
    ri.load()
    ri.load_data()
    ri.load_from_file()

# Generated at 2022-06-23 06:49:38.102492
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    #test constructor
    r = RoleInclude(play = None, role_basedir = None, variable_manager = None, loader = None, collection_list = None)
    print(r)


# Generated at 2022-06-23 06:49:43.315088
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri is not None

# Generated at 2022-06-23 06:49:51.421931
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    loader = DataLoader()
    vault = VaultLib(loader=loader, passwords={'key1': '', 'key2': ''})
    var_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    play_context = PlayContext(remote_addr='127.0.0.1')

# Generated at 2022-06-23 06:49:59.096235
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    current_role_path = os.getcwd()
    loader = None
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'role_paths': ['.']}
    play_context = PlayContext(become_method=None)
    play_context.accelerate = 10
    play_context.accelerate_port = 5099
    play_context.become = True
    play_context.become_method = "sudo"
    play_context.become_user = "root"
    play_context.become_pass = "PassWord"
    play_context.connection = "ssh"
    play_context.sudo_user = "root"

# Generated at 2022-06-23 06:50:01.612220
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri

# Generated at 2022-06-23 06:50:03.634082
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:50:04.817191
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:50:06.590494
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-23 06:50:08.242901
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_instance = RoleInclude()
    assert test_instance is not None


# Generated at 2022-06-23 06:50:12.921390
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import mock
    pb_play = mock.MagicMock()
    mock_data = mock.MagicMock()
    mock_vm = mock.MagicMock()
    mock_loader = mock.MagicMock()

    ri = RoleInclude.load(mock_data, pb_play, variable_manager=mock_vm, loader=mock_loader)

    assert ri.play == pb_play
    ri.load_data.assert_called_with(mock_data, variable_manager=mock_vm, loader=mock_loader)

# Generated at 2022-06-23 06:50:14.112505
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    This is a unittest for the method load of class RoleInclude
    """

# Generated at 2022-06-23 06:50:26.900454
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import role_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-23 06:50:37.252729
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    Unit test for method load of class RoleInclude
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.manager import VariableManager

    r = RoleInclude()
    p = Play()
    pctx = PlayContext()
    d = DataLoader()
    v = VariableManager()

    data = dict(
      name = "testrole1",
      become = True,
      become_method = "sudo",
      become_user = "root"
    )

    r.load(data, p, variable_manager=v, loader=d)

    ##
    ## test for load with string type argument
    ##
    data = "testrole2"

# Generated at 2022-06-23 06:50:38.762916
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:50:41.071918
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert not RoleInclude()

# Generated at 2022-06-23 06:50:49.056699
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Create an instance of class RoleDefinition (a base class for class RoleInclude)
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert isinstance(ri, RoleDefinition)

    # Test of class method load()
    with pytest.raises(AnsibleError) as excinfo:
        RoleInclude.load(data='role[n,e,w]', play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert "Invalid old style role requirement" in str(excinfo.value)

# Generated at 2022-06-23 06:50:54.162226
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play='play', role_basedir='/var/lib/awx/projects/playbook', variable_manager='variable_manager', loader='loader')
    assert ri.play == "play"
    assert ri.role_basedir == "/var/lib/awx/projects/playbook"
    assert ri.variable_manager == "variable_manager"
    assert ri.loader == "loader"


# Generated at 2022-06-23 06:51:05.620419
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude.load(data=dict(name="test_role_include"),
                                    play=None,
                                    current_role_path=None,
                                    parent_role=None,
                                    variable_manager=None,
                                    loader=None,
                                    collection_list=None)
    assert isinstance(role_include, RoleInclude)
    assert role_include._role_path == "test_role_include"


# Generated at 2022-06-23 06:51:07.560088
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:51:08.144929
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:51:20.724596
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play

    # Set up the play
    play_data = dict(
        name='play1',
        connection = 'local',
        hosts='localhost',
        roles=[dict(role1)],
        gather_facts=False
    )

    play = Play().load(play_data, variable_manager=variable_manager, loader=loader)

    # Set up the include
    variable_manager = variable_manager.set_temporary_vars(dict(
        include_role1=dict(
            name='role1',
            tasks=['task1.yml']
        )
    ))
    
    ri = RoleInclude(play=play, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:51:22.869136
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-23 06:51:23.324026
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:51:34.050403
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    fake_loader = DictDataLoader({})
    fake_variable_manager = VariableManager(loader=fake_loader)
    fake_play_context = PlayContext()
    templar = Templar(loader=fake_loader, variables=fake_variable_manager)

    fake_role = type('FakeRole', (object,), {})
    fake_role._role_name = "myrole"
    fake_role._role_path = "."
    fake_play = type('FakePlay', (object,), {})
    fake_play._included_file_search_path = []


# Generated at 2022-06-23 06:51:37.080447
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:51:44.105679
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    p = Play()
    v = VariableManager()
    l = DataLoader()
    i = InventoryManager(loader=l, sources=[])

    ri = RoleInclude(play=p, variable_manager=v, loader=l)
    assert ri.load_data('name')
    assert ri.name == 'name'

    ri = RoleInclude(play=p, variable_manager=v, loader=l)
    assert ri.load_data('name', variable_manager=v, loader=l)
    assert ri.name == 'name'

# Generated at 2022-06-23 06:51:54.875602
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import os
    import sys
    import unittest2 as unittest

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import string_types
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    class TestRoleInclude(unittest.TestCase):

        def setUp(self):
            self._original_unfrack_path = os.path.realpath

            os.path.realpath = mock_un

# Generated at 2022-06-23 06:51:57.668429
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

    # TODO:
    # Please write unit test for method load of class RoleInclude

# Generated at 2022-06-23 06:52:10.019117
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    play1 = Play().load({
        'name': 'test play',
        'hosts': 'test_hosts',
        'tasks': [{'action': {'module': 'ping'}}]
    }, variable_manager=VariableManager(), loader=None)


    data = {
            'name': 'test-role',
            }

    role_include = RoleInclude(play=play1, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

    try:
        role_include.load(data, None)
        assert True
    except Exception as e:
        assert False

# Generated at 2022-06-23 06:52:14.882862
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    def _create_fake_play(variable_manager):
        play_source = dict(
            name="Ansible Play ... [webservers]",
            hosts='webservers',
            gather_facts='no',
            tasks=[
                dict(action=dict(module='shell', args='/bin/sleep 0')),
            ]
        )
        play = Play().load(play_source, variable_manager=variable_manager, loader=None)
        play._variable_manager = variable_manager
        play._hosts = [Host(name="hostname")]
        play._groups = [Group('webservers')]


# Generated at 2022-06-23 06:52:15.528512
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-23 06:52:27.162489
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    os.environ["ANSIBLE_ROLES_PATH"] = os.path.join(role_dir, 'test/unit/playbook/roles/')

    from ansible.playbook.play import Play
    from ansible.utils.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    role_data = {'roles': {"a0_basic": {"localhost":"a0_basic_role"}}, 'tasks': [{'action': {'module': 'debug', 'msg': 'hi'}}]}

    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-23 06:52:31.601565
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Check default values of RoleInclude
    ri = RoleInclude()
    assert not ri._role_path
    assert not ri._role_name
    assert not ri._role_collection

# Generated at 2022-06-23 06:52:35.096571
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    loader = None
    play = None
    role = None
    variable_manager = None
    role = RoleInclude(play, role, variable_manager, loader)
    assert role is not None

# Generated at 2022-06-23 06:52:37.188807
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:52:46.157452
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test the case that an invalid role definition
    data = dict(role="test")
    play = dict()
    current_role_path = os.path.join(os.path.dirname(__file__), "../../../../")
    parent_role = dict()
    variable_manager = dict()
    loader = dict()
    collection_list = dict()
    from ansible.parsing.yaml.objects import AnsibleMapping
    try:
        assert RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleParserError as e:
        assert to_native(e) == "Invalid role definition: {'role': 'test'}"

    # Test the case that an invalid role definition
    data = dict(role="")

# Generated at 2022-06-23 06:52:57.593375
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class MockRoleDefinition:
        def __init__(self, data):
            self.data = data
        def load_data(self, data, variable_manager=None, loader=None):
            return self.data

    roleDefinition = MockRoleDefinition('success')
    RoleInclude.load_data = Mock(return_value=roleDefinition)
    def test_dict():
        assert RoleInclude.load({'name': 'common'}, 'test_play') == 'success'
        assert RoleInclude.load_data.call_count == 1
        assert RoleInclude.load_data.call_args[0][0] == {'name': 'common'}
        assert RoleInclude.load_data.call_args[1] == {'play': 'test_play'}

# Generated at 2022-06-23 06:53:07.966181
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders

    play_context = PlayContext(var_manager={})
    play = Play()
    role = RoleInclude(play=play, loader=get_all_plugin_loaders(), role_basedir = 'test/test_files/roles', variable_manager = 'test/test_files/vars', collection_list='test/test_files/collections')
    role.load_data('test/test_files/roles', play_context)
    print(role)

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:53:08.874970
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:53:11.527211
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test with string
    data = 'role1'
    ri = RoleInclude.load(data)
    assert isinstance(ri,RoleInclude)

# Generated at 2022-06-23 06:53:19.534403
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class MockRoleInclude(RoleInclude):
        def __init__(self, data, play, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None):
            self.data = data
            self.play = play
            self.current_role_path = current_role_path
            self.parent_role = parent_role
            self.variable_manager = variable_manager
            self.loader = loader
            self.collection_list = collection_list
            super(MockRoleInclude, self).__init__(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

        def load_data(self, data, variable_manager=None, loader=None):
            return data

# Generated at 2022-06-23 06:53:23.572134
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """Unit test for constructor of class RoleInclude"""
    play = _get_play()
    ri = RoleInclude(play=play)
    assert ri is not None


# Generated at 2022-06-23 06:53:32.574489
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.mod_args import ModuleArgsParser

    data = dict(
            include = dict(
                role = "michael.dehaan",
                tasks = dict(
                    test = dict(
                        shell = "whoami"
                    )
                )
            )
        )

    args = ModuleArgsParser.parse(data['include'])
    play = dict()
    ri = RoleInclude(play=play)
    ri.load_data(args, loader=None)
    assert ri.tasks[0].name == 'test'
    assert ri.tasks[0].get_vars()['shell'] == 'whoami'
    assert ri.tasks[0].action == 'shell'


# Generated at 2022-06-23 06:53:42.303927
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.safe_loader import AnsibleSafeLoader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    play_context = PlayContext(variable_manager=variable_manager)

    role_name = 'test'
    role_path = './test/ansible/roles/{}'.format(role_name)
    role = RoleInclude.load(role_name, play_context, role_path)

    assert(role.get_name() == 'test')

# Generated at 2022-06-23 06:53:51.118688
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude

    play_srv = Play.load(dict(
        name="Ansible Play ",
        hosts='web',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    ))
    task1 = Task()
    task2 = Task()

    assert play_srv.serialize() == play_srv.serialize()

    play_copy = Play().load(play_srv.serialize(), loader=play_srv._loader)


# Generated at 2022-06-23 06:53:57.919420
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = {'vars': {'test_var': 'test_val'}}
    variable_manager = 'variables'
    loader = 'loader'
    data = {'role': 'role', 'become': False}
    ri = RoleInclude(play=play, variable_manager=variable_manager,loader=loader)
    ri.load_data(data, variable_manager=variable_manager, loader=loader)
    data.pop('role')
    ri.load_data(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:53:58.853554
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:54:09.158018
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost', 'otherhost'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    role_include = RoleInclude(play=play_context,
                              role_basedir='/some/path',
                              variable_manager=variable_manager)

    data = dict(name='somerole')
    role_include.load_data(data, variable_manager=variable_manager)
    assert role_include is not None

# Generated at 2022-06-23 06:54:14.016774
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    #
    # Checks for init method
    #
    assert role.__class__.__name__ == 'RoleInclude'
    assert role._role_name == 'include'
    assert role._role_path == ['tasks']

RoleInclude._load_attributes(Attribute.NO_ARGS_FIELD, RoleInclude)

# Generated at 2022-06-23 06:54:21.950543
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import loader as plugin_loader
    from ansible.vars import VariableManager

    pc = PlayContext()
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../test_utils/fake_plugins'))

    vars_mgr = VariableManager()
    vars_mgr.extra_vars = {'foo': 'bar'}

    data = 'test,foo'

    result = RoleInclude.load(data, pc)

    assert type(result) is RoleRequirement

# Generated at 2022-06-23 06:54:22.937603
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:54:35.882512
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import json
    import ansible.playbook
    from ansible.module_utils.six import string_types
    from ansible.parsing.dataloader import DataLoader
    from units.mock.loader import DictDataLoader
    file_data = """
    - hosts: localhost
      roles:
        - role1
        - role2
        - role3
    """
    # file_data_json = json.dumps(file_data)
    loader = DictDataLoader({
        "test.yml": file_data
    })
    variable_manager = ansible.playbook.VariableManager()
    pb = ansible.playbook.Playbook.load(loader=loader,
                                        variable_manager=variable_manager,
                                        playbooks=["test.yml"])

# Generated at 2022-06-23 06:54:43.083267
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # test invalid data type
    data = [False]

    try:
        RoleInclude.load(data, None, None, None, None, None)
    except AnsibleParserError as e:
        assert "Invalid role definition" in str(e)
    else:
        raise AssertionError('AnsibleParserError not raised')

    # test invalid role include
    data = "someuser,foo,bar"

    try:
        RoleInclude.load(data, None, None, None, None, None)
    except AnsibleError as e:
        assert "Invalid old style role requirement" in str(e)
    else:
        raise AssertionError('AnsibleError not raised')

    # test role definition
    data

# Generated at 2022-06-23 06:54:49.801783
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_base_path = 'fake_path'
    test_play = 'fake_play'
    test_variable_manager = 'fake_variable_manager'
    variable_manager = 'fake_variable_manager'
    test_loader = 'fake_loader'
    test_collection_list = 'fake_collection_list'

    # test no-args constructor
    assert RoleInclude()

    # test full constructor
    assert RoleInclude(test_play, test_base_path, test_variable_manager, test_loader, test_collection_list)