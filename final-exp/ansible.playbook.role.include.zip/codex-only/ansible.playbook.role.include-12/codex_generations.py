

# Generated at 2022-06-23 06:44:52.002534
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()

# Generated at 2022-06-23 06:44:58.341630
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    if PY3:
        ansible_host_collection = dict(
            ansible.collections.ansible_host_collection.plugins.module_utils.facts.__dict__)
        os_facts = dict(ansible.collections.notstdlib.moveitallout.plugins.module_utils.facts.__dict__)
        del ansible_host_collection['os'], os_facts['os']

# Generated at 2022-06-23 06:44:59.193416
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass


# Generated at 2022-06-23 06:45:09.574895
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # test_yaml_string_fail
    data = "name,another_name"
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    with pytest.raises(AnsibleError) as err:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    err.match("Invalid old style role requirement: name,another_name")

    # test_yaml_string_pass
    data = "name"
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    # test_yaml_dict_fail
    data = {"name": "name"}

# Generated at 2022-06-23 06:45:21.141172
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """ role_include_load.py
    Test cases for load method of class RoleInclude
    """

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    loader = DataLoader()
    play = {}
    data = '''
    - hosts: all
      tasks:
        - include:
            - foo
          when: foo == true
        - block:
            - include: bar
              when: bar == false
              tags:
                - bar_tag
            - include: baz
              when: baz == false
            - include: qux
              when: qux == false
          when: baz == true
    '''
    yaml_obj = loader.load(data)

# Generated at 2022-06-23 06:45:24.966593
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

    ri1 = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri1



# Generated at 2022-06-23 06:45:25.576605
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:45:28.911048
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    res = RoleInclude.load('geerlingguy.apache', 'play', '/tmp/ansible_roles', None, None, None)
    assert res._role_name == 'geerlingguy.apache'


# Generated at 2022-06-23 06:45:30.586638
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, "No test for RoleInclude.load"


RoleInclude._load = RoleInclude.load



# Generated at 2022-06-23 06:45:39.475044
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.variable_manager import VariableManager
    from ansible.vars.manager import VarsModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    import os
    import yaml
    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    # Create the loader

# Generated at 2022-06-23 06:45:48.741796
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = None    # An instance of class Play
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    data = 'some_role'
    # The method load should raise RuntimeError if the first param is not a string or a dict
    # The method load should raise AnsibleParserError if the first param is not a string or a dict
    assert False
    # The method load should raise AnsibleError if the first param is a string containing the character ','
    assert False
    # The method load should return an instance of class RoleInclude if the second param is None
    assert False
    # The method load should return an instance of class RoleRequirement if the second param is not None
    assert False

# Generated at 2022-06-23 06:45:49.690462
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:45:57.426445
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO:
    #  - fix the test to use the right path to files
    #  - fix the load method to use the right path to files
    #  - add more assertions on the result
    test_path = '/home/travis/build/ansible/ansible/test/unit/test_playbook_include.yml'
    with open(test_path) as f:
        test_data = f.read()
        vars = {}
        ri = RoleInclude(vars)
        ri.load_data(test_data)

# Generated at 2022-06-23 06:46:06.260470
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # what if RoleInclude is called with no arguments
    try:
        ri = RoleInclude()
    except Exception:
        pass
    else:
        raise Exception("failed to throw exception with no arguments")
    # now test with arguments
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert(ri)


# Generated at 2022-06-23 06:46:06.884480
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    

# Generated at 2022-06-23 06:46:15.351401
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_path = os.path.join('test', 'units', 'parsing', 'parser', 'test_role_include.yml')
    with open(test_path, 'rb') as data:
        result = yaml.safe_load(data)
    role_include = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    role_include.__init__(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    role_include.load(result, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-23 06:46:25.047672
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    # Instantiating an empty Play object
    play_obj = Play()

    # Instantiating a RoleDefinition object
    rd = RoleDefinition()

    # Instantiating a RoleInclude object
    role_include = RoleInclude(play = play_obj, role_basedir = None, variable_manager = None, loader = None, collection_list = None)

    # Case 1:
    # Passing a dict to load_data method

# Generated at 2022-06-23 06:46:26.853708
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pi = RoleInclude()
    assert pi is not None


# Generated at 2022-06-23 06:46:27.496974
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:46:29.408075
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    rid = RoleInclude()
    assert isinstance(rid, RoleInclude)


# Generated at 2022-06-23 06:46:33.855730
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    variable_manager = {'foo': 'bar'}
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=variable_manager, loader=None)

# Generated at 2022-06-23 06:46:38.138586
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_RoleInclude = RoleInclude()
    assert test_RoleInclude != None

# Generated at 2022-06-23 06:46:45.144326
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.role_basedir is None
    assert ri.role_path is None
    assert ri.name is None
    assert ri.default_vars is None
    assert ri.default_tasks is None
    assert ri.default_handlers is None
    assert ri.vars is None
    assert ri.tasks is None
    assert ri.handlers is None

# Generated at 2022-06-23 06:46:49.650593
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:47:01.187903
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    current_role_path = os.path.join(os.path.dirname(__file__), '../../../test/roles/test')
    data = dict(name='test',
                some_key=dict(some_key='some_value'))
    ri = RoleDefinition.load(data, current_role_path)

# Generated at 2022-06-23 06:47:03.267586
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert(1==1)
#    r=RoleInclude()
#    assert(r is not None)

# Generated at 2022-06-23 06:47:08.733456
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {
        'name': 'test',
        'collection': 'test',
        'src': 'test',
        'path': 'test',
        'version': 'test',
    }
    play = None
    loader = None

    ri = RoleInclude.load(data, play, loader)
    assert ri._role_name == 'test'

# Generated at 2022-06-23 06:47:11.296687
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, "No tests for RoleInclude.load"


# Generated at 2022-06-23 06:47:12.605629
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.role_name is None

# Generated at 2022-06-23 06:47:22.865891
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    err_msg = "Invalid old style role requirement: foo,bar"
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    data = "foo,bar"
    err = None
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleError as e:
        err = e
    assert repr(err) == repr(AnsibleError(err_msg))
    assert err.message == err_msg
    assert err.exception == AnsibleError
    assert err.traceback == None

    data = "foo"
    err = None

# Generated at 2022-06-23 06:47:26.535169
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {'name': 'test1', 'hosts': 'dehnungsstreifen'}
    role = RoleInclude.load(data)
    assert role.get_name() == 'test1'

# Generated at 2022-06-23 06:47:30.139043
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

RoleInclude._load = classmethod(RoleInclude.load)


# main class for role dependencies, which may include a version
# requirement as well as the actual role

# Generated at 2022-06-23 06:47:31.188545
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert role is not None

# Generated at 2022-06-23 06:47:38.266089
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Construct a RoleInclude object with None as play
    role_include = RoleInclude(play=None)
    assert role_include is not None
    assert role_include._play is None
    assert role_include.role_basedir is None

    # RoleInclude is not a RoleDefinition
    assert not isinstance(role_include, RoleDefinition)

    # Construct a RoleInclude object with play
    role_include = RoleInclude(play=play)
    assert role_include is not None
    assert role_include._play == play
    assert role_include.role_basedir is None

# Generated at 2022-06-23 06:47:39.202800
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:47:45.204403
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources='localhost,'))

    ri = RoleInclude(play=Play().load(dict(
        name = "test play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            dict(name='test'),
        ]
    ), variable_manager=variable_manager, loader=loader), role_basedir='/blah', variable_manager=variable_manager, loader=loader)

    assert ri.get_name() == 'test'
    # get_vars()

# Generated at 2022-06-23 06:47:53.512824
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import mock
    loader = mock.MagicMock()
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=loader, collection_list=None)
    assert isinstance(ri, RoleInclude)
    # test class variable load of type string
    data = "test_data"
    assert isinstance(data, string_types)
    ri_load = ri.load(data=data, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    #assert isinstance(ri_load, RoleInclude)
    data = {"name": "test_data"}
    assert isinstance(data, dict)

# Generated at 2022-06-23 06:47:55.353916
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print(RoleInclude())

# Generated at 2022-06-23 06:47:57.186752
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert isinstance(role, RoleInclude)

# Generated at 2022-06-23 06:48:05.593289
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test the constructor of class RoleInclude
    ri = RoleInclude()
    assert(ri.__class__.__name__ == 'RoleInclude')
    assert(ri._attributes['_delegate_to']  == { "default" : "", "isa" : "string", "name" : "_delegate_to", "private" : False, "version_added" : "historical", "no_log" : False})
    assert(ri._attributes['_delegate_facts']  == { "default" : False, "isa" : "bool", "name" : "_delegate_facts", "private" : False, "version_added" : "historical", "no_log" : False})

# Generated at 2022-06-23 06:48:11.734498
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("\nSTART - RoleInclude: test_RoleInclude")
    ri_obj = RoleInclude()
    assert(isinstance(ri_obj, RoleInclude))
    print("\nEND - RoleInclude: test_RoleInclude")

# Generated at 2022-06-23 06:48:21.655621
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    # Load a basic role file
    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play()
    role_dir = os.path.dirname(__file__ + "/../..")
    role_file = role_dir + "/examples/ansible-dnf/meta/main.yml"
    role_data = loader.load_from_file(role_file)
    RoleInclude.load(role_data, play, parent_role=None, variable_manager=variable_manager, loader=loader)

    # Load with an old style role requirement
    role_data = "example-role"

# Generated at 2022-06-23 06:48:28.920618
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Creating inventory
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager()

    play_source = dict(
        name="test play",
        hosts=['localhost'],
        gather_facts='no',
        tasks=[],
        vars={"test_var": "some test value"}
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 06:48:39.475483
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from collections import namedtuple
    FakeOptions = namedtuple('FakeOptions', 'connection_plugins')
    options = FakeOptions(connection_plugins=['ssh', 'paramiko'])
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)

# Generated at 2022-06-23 06:48:43.158462
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Create an instance of the RoleInclude class
    test_obj = RoleInclude()
    assert test_obj is not None

if __name__ == "__main__":
    test_RoleInclude()

# Generated at 2022-06-23 06:48:49.191426
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'some_path'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    assert isinstance(RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader,
                                       collection_list), RoleInclude)



# Generated at 2022-06-23 06:48:56.384073
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:49:08.401480
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 06:49:15.157536
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class TestPlaybook:
        def __init__(self):
            self.vars = []
            # self.vars_prompt
            self.tags = []
            self.gather_facts = "yes"
            # self.roles
            # self.handlers
            # self.tasks
            self.basedir = None

    class TestVariableManager:
        def get_vars(self, loader, play, task, include_hostvars=True):
            if include_hostvars:
                return {}
            else:
                return {}

    class TestLoader:
        def find_file(self, name):
            return name

    class TestCollectionList:
        def find_file(self, name):
            return name

    play = TestPlaybook()
    varm = TestVariableManager()
    loader = TestLoader

# Generated at 2022-06-23 06:49:19.462128
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create the test object
    role_include = RoleInclude()

    # Create test data
    # Load the data
    role_include.load_data(data=None, variable_manager=None, loader=None)


# Generated at 2022-06-23 06:49:27.389763
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # ensure that we are testing the right class
    assert (RoleInclude.__name__ == 'RoleInclude')
    # ensure that we are testing the subclass of RoleDefinition
    assert (RoleDefinition in RoleInclude.__bases__)

    # note that because there is no assertRaises in python 2.6,
    # we have to use try/except to test for exceptions.
    play = object
    try:
        # no args should fail
        ri = RoleInclude()
        assert (False)
    except TypeError:
        pass
    # role_basedir is optional
    ri = RoleInclude(play=play)
    assert (ri)

# Generated at 2022-06-23 06:49:37.936424
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.variable_manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    context = PlayContext()
    inventory = InventoryManager(loader=loader, sources="localhost")

    ri = RoleInclude(play=None, role_basedir=None, variable_manager=variable_manager, loader=loader)

    ##################################################################################################################
    # data: ansible 2.5 yaml file

# Generated at 2022-06-23 06:49:48.454950
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Initialize all required variables
    play = None
    role_basedir = None
    variable_manager = None
    loader = None
    collection_list = None

    role_name = "role_name"
    role_path = "path/to/role"
    role_collection = "@collection/role"
    role_collection2 = "@username.collection/role"
    role_collection3 = "@namespace.username.collection/role"
    role_collection4 = "@username.collection.space/role"
    role_collection5 = "@username.collection/role.space"
    
    # Test constructor with only required parameters
    test_role1 = RoleInclude(play, role_basedir, variable_manager, loader, collection_list)
    # Test constructor with all parameters

# Generated at 2022-06-23 06:49:49.886444
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: add test
    pass

# Generated at 2022-06-23 06:49:57.261556
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class TestObj():
        def __init__(self, fake_attr):
            self.fake_attr = fake_attr
        def __nonzero__(self):
            return True
        __bool__ = __nonzero__

    fake_play = TestObj('fake_play')
    fake_variable_manager = TestObj('fake_variable_manager')
    fake_loader = TestObj('fake_loader')
    ri = RoleInclude(play=fake_play, variable_manager=fake_variable_manager, loader=fake_loader)
    assert ri.play == 'fake_play'
    assert ri.variable_manager == 'fake_variable_manager'
    assert ri.loader == 'fake_loader'
    assert ri.path is None

# Generated at 2022-06-23 06:50:04.406823
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Simple test for just one call
    import ansible.playbook.play

    loader = ansible.playbook.play.Play.load
    play = ansible.playbook.play.Play()
    role_basedir = os.path.dirname(os.path.abspath(__file__))

    data = {'role': 'test_role'}

    role = RoleInclude.load(data, play, role_basedir, variable_manager=None, loader=loader)

    assert role.get_name() == 'play'
    assert role.get_role_name() == 'test_role'
    assert role.delegate_to is None
    assert role.delegate_facts is False


# Generated at 2022-06-23 06:50:16.054759
# Unit test for method load of class RoleInclude

# Generated at 2022-06-23 06:50:27.238236
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.objects import AnsibleSequence
    ansible_version_info = {'version': '2.10.3.dev1', 'full': '2.10.3.dev1'}
    import ansible.constants
    ansible.constants.__version__ = ansible_version_info

    # test load with data as string
    try:
        RoleInclude.load('name', None)
        failed = True
    except AnsibleError:
        failed = False

    assert not failed


    # test load with data as dict
    try:
        RoleInclude.load({'name': 'role1', 'role_name': 'role1'}, None)
        failed = True
    except AnsibleError:
        failed

# Generated at 2022-06-23 06:50:31.789075
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    a = RoleInclude()
    assert a is not None
    b = RoleInclude(play={})
    assert b is not None

if __name__ == "__main__":
    # Unit test for the RoleInclude() class
    test_RoleInclude()

# Generated at 2022-06-23 06:50:33.013901
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:50:45.759395
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = {'roles': ['../test/roles/include']}
    loader = AnsibleLoader(False, None, None)
    variable_manager = VariableManager(loader=loader, play=play)
    role_include = RoleInclude.load(data='../test/roles/include', play=play, variable_manager=variable_manager, loader=loader)
    assert role_include.role_name == 'include'
    assert role_include.role_path == '../test/roles/include'
    assert role_include.role_root == '../test/roles'
    assert role_include.role_basedir == '../test/roles/include'

    play = {'roles': ['include']}

# Generated at 2022-06-23 06:50:47.726018
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # create a RoleInclude object
    obj = RoleInclude(play='testPlay')
    print(obj)
    assert obj != None

# Generated at 2022-06-23 06:50:56.301012
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = None
    for plugin_loader in get_all_plugin_loaders():
        if plugin_loader.name == 'loader':
            loader = plugin_loader
            break

    if loader is None:
        raise Exception("could not find loader plugin")

    vault_secrets = VaultLib([])
    v = VariableManager()
    i = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-23 06:51:05.038201
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    data = 'abc'
    ri.load(data, None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-23 06:51:06.512408
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Constructor of RoleInclude
    """
    role = RoleInclude()

# Generated at 2022-06-23 06:51:14.360578
# Unit test for method load of class RoleInclude

# Generated at 2022-06-23 06:51:22.827066
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test_data', 'roles')
    role_definition = {
        'name': 'apache',
        'hosts': 'testhost',
        'roles': [
            {'name': 'common', 'some_attribute': 'foo'},
            'geerlingguy.apache'
        ]
    }
    role_relation = {
        'name': 'apache',
        'hosts': 'testhost',
        'roles': [
            {'name': 'common'},
            'geerlingguy.apache'
        ]
    }
    ri = RoleInclude(role_basedir=role_path)
    # Load role definition

# Generated at 2022-06-23 06:51:33.667406
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # test loading of a simple role
    test_data = """
    name: test_role
    """
    ri = RoleInclude()
    try:
        ri.load_data(test_data, variable_manager=None, loader=None)
    except AnsibleError as e:
        assert False, "Error loading simple role: %s" % to_native(e)
    # test parsing error on invalid role definition
    test_data = """
    name = invalid
    """
    ri = RoleInclude()
    try:
        ri.load_data(test_data, variable_manager=None, loader=None)
    except AnsibleParserError:
        pass
    else:
        assert False, "Error expected on invalid role definition"
    # test error on old style role requirement

# Generated at 2022-06-23 06:51:41.791271
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.vars import combine_vars
    import os
    import pytest

    vault_file_path = os.path.join(os.path.dirname(__file__), '../../test_utils/vault_test_data')
    args = {'vault_password_file': vault_file_path}
    vault_pwd = VaultLib(args)
    vault_secret = VaultSecret('$ANSIBLE_VAULT;1.2;AES256;test')

    data = vault_pwd.decrypt(vault_secret.data)
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:51:47.010783
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude_obj = RoleInclude()
    #__init__() will throw exception if new names/fields are added to the class and
    #they are not present in the init function.
    pass

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:51:56.277487
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    fp = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'load_role_sample.yml')
    block = None
    try:
        with open(fp, 'r') as f:
            block = f.read()
    except Exception as ex:
        msg = "Unable to open file"
        raise AnsibleError(msg)

    data = {'block': block}

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VarManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import become_loader

# Generated at 2022-06-23 06:51:57.670088
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass



# Generated at 2022-06-23 06:52:10.654327
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class MockPlay:
        def __init__(self):
            self.variables = {}
    class MockVariableManager:
        def __init__(self):
            self.extra_vars = {}
            self.host_vars = {}
            self.group_vars = {}
            self.task_vars = {}
    class MockLoader:
        def __init__(self):
            self.vars_plugins = []
    class MockCollectionList:
        def __init__(self):
            self.collections = []
    class MockPath:
        def __init__(self):
            self.path = ""
    class MockRoleDefinition:
        def __init__(self):
            pass

# Generated at 2022-06-23 06:52:11.223246
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:52:13.135922
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test class constructor
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:52:24.497120
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from copy import deepcopy

    role_include_data = {
        'role': 'test'
    }
    role_include_data_copy = deepcopy(role_include_data)
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    result = RoleInclude.load(
        data=role_include_data,
        play=play,
        current_role_path=current_role_path,
        parent_role=parent_role,
        variable_manager=variable_manager,
        loader=loader,
        collection_list=collection_list
    )
    assert result.get_name() == role_include_data['role']
    assert role_include_data_copy == role_include_data

# Generated at 2022-06-23 06:52:33.389016
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=loader)
    variable_manager.options_vars = load_extra_vars(loader=loader, options_only=True)
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    play_context.loader = loader
   

# Generated at 2022-06-23 06:52:34.581705
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, "Not implemented"

# Generated at 2022-06-23 06:52:36.688837
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass
    #TODO

# Generated at 2022-06-23 06:52:45.889866
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    class MyDisplay(Display):
        def vv(self, msg, host=None):
            print(msg)
        vvv = vv
        verbosity = 2

    class MyPlay(object):
        def __init__(self):
            self._variable_manager = MyVariableManager()
            self._loader = 'loader'
            self._hosts = 'hosts'
            self._tasks = []
            self._roles = []


# Generated at 2022-06-23 06:52:50.542218
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    ri.load("role_def", play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None)

# Unit tests for actions methods

# Generated at 2022-06-23 06:53:00.126744
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    mock_loader = lambda : None
    mock_loader.path_exists = lambda a: True
    mock_loader.is_file = lambda a: True

    p = Play().load({
         'hosts': 'all',
         'tasks': [
           dict(action=dict(module='shell', args='ls')),
           dict(action=dict(module='shell', args='whoami')),
           dict(action=dict(module='shell', args='lsof')),
         ],
         'roles': [ 'common' ]
    }, variable_manager=VariableManager(), loader=DataLoader())

    inv

# Generated at 2022-06-23 06:53:10.268370
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.role import definition as role_definition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
        ), variable_manager=variable_manager, loader=loader)
    role_

# Generated at 2022-06-23 06:53:19.005599
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test RoleInclude.load with data of type string
    data1 = 'val_of_data1'
    play1 = 'val_of_play1'
    current_role_path1 = 'val_of_current_role_path1'
    parent_role1 = 'val_of_parent_role1'
    variable_manager1 = 'val_of_variable_manager1'
    loader1 = 'val_of_loader1'
    collection_list1 = 'val_of_collection_list1'
    result1 = RoleInclude.load(data1, play1, current_role_path1, parent_role1, variable_manager1, loader1, collection_list1)

    # Test RoleInclude.load with data of type dict
    data2 = dict()
    play2 = dict()
    current_role

# Generated at 2022-06-23 06:53:19.799231
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:53:21.557981
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-23 06:53:26.824439
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {}
    if data == RoleInclude.load(data):
        print("test_RoleInclude_load: OK")
        return True
    return False

print("")
print("------------------------------------")
print("Testing file RoleInclude.py")
print("------------------------------------")
print("")

test_RoleInclude_load()

# Generated at 2022-06-23 06:53:35.351736
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import sys
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost, '])
    play_source = dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

# Generated at 2022-06-23 06:53:49.138393
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook.play import Play
    from ansible.plugins.loader import role_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 06:53:50.014140
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: unit tests for RoleInclude class
    pass

# Generated at 2022-06-23 06:53:52.474482
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """RoleInclude - constructor test cases"""

    # test case: RoleInclude constructor with empty arguments
    role_include = RoleInclude()
    assert role_include is not None

# Generated at 2022-06-23 06:54:07.560342
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.unsafe_proxy import wrap_var
    import os

    # Create class instances

# Generated at 2022-06-23 06:54:16.926652
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook
    import ansible.inventory.host
    import ansible.vars.manager

    host = ansible.inventory.host.Host('127.0.0.1')
    callbacks = ansible.playbook.PlaybookCallbacks(verbose=0)
    runner_callbacks = ansible.playbook.PlaybookRunnerCallbacks(callbacks, verbose=0)
    stats = ansible.playbook.PlaybookStats(setup=True, runner_callbacks=runner_callbacks)
    vars_manager = ansible.vars.manager.VariableManager()


# Generated at 2022-06-23 06:54:28.784667
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_vault_secrets({"vault_password":"12345"})

    # Test for a string type
    data = "foo-role"
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'hosts'
    ), variable_manager, loader)

    ri = RoleInclude(play=play, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:54:40.089671
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ''' usage: python -m test.units.role.test_RoleInclude '''
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_source = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=dict()))
        ]
    )
    play = Play.load(play_source, variable_manager=VariableManager(), loader=DataLoader())
    role_include = RoleInclude(play=play)
    role_include.get_vars()

# Generated at 2022-06-23 06:54:52.175232
# Unit test for method load of class RoleInclude