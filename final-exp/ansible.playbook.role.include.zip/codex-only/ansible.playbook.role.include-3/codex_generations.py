

# Generated at 2022-06-23 06:44:57.649322
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # Test with bad input
    try:
        _ = RoleInclude.load([])
    except AnsibleParserError:
        pass
    except:
        raise

    try:
        _ = RoleInclude.load({})
    except AnsibleParserError:
        pass
    except:
        raise

    # Test with good input
    role_include = RoleInclude.load({'role': 'foobar'})
    assert role_include.get_name() == 'foobar'

    role_include = RoleInclude.load('foobar')
    assert role_include.get_name() == 'foobar'

# Generated at 2022-06-23 06:44:59.450586
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''Unit test for constructor of class RoleInclude'''
    pass

# Generated at 2022-06-23 06:45:09.978874
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Sanity check for constructor of class RoleInclude
    """
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ri = RoleInclude(play=Play(), role_basedir='/tmp', variable_manager=VariableManager(), loader=DataLoader())

    assert ri._play is not None
    assert ri._role_name is None
    assert ri._role_path is '/tmp'
    assert ri._role_params is None
    assert ri._role_vars is None
    assert ri._task_blocks is None
    assert ri._handler_blocks is None
    assert ri._metadata is None
    assert ri._

# Generated at 2022-06-23 06:45:15.669147
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    fail_msg = ""
    pass_msg = ""
    # Variables
    class AnsibleParserError(Exception):
        pass
    class AnsibleError(Exception):
        pass
    class RoleInclude(object):
        pass
    VariableManager = object
    RoleInclude = RoleInclude
    # Test

# Generated at 2022-06-23 06:45:19.040962
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = dict(name="role")
    play = dict(name="play")
    test_obj = RoleInclude.load(data, play)
    assert test_obj == data

# Generated at 2022-06-23 06:45:30.946579
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    play_source = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=None, loader=None)


# Generated at 2022-06-23 06:45:40.182939
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import mock
    import os

    play = mock.Mock()
    play.heads = ['a', 'b', 'c']

    variable_manager = mock.Mock()

    loader = mock.Mock()

    play.roles = ['a', 'b', 'c']

    try:
        RoleInclude.load(data='', play=play, current_role_path=os.getcwd(), variable_manager=variable_manager, loader=loader)
        assert False
    except AnsibleParserError as ae:
        assert "Invalid role definition:" in to_native(ae)


# Generated at 2022-06-23 06:45:48.049170
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_dir = os.path.dirname(os.path.dirname(__file__))
    data = {"name": "test", "role_path":  os.path.join(test_dir, "lib")}
    r = RoleInclude(**data)
    assert 'test' == r['name']
    assert type(r['name']) is Attribute # Check type of Attribute
    assert os.path.join(test_dir, "lib") == r['role_path']
    assert type(r['role_path']) is Attribute # Check type of Attribute

# Generated at 2022-06-23 06:45:53.556518
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # pylint: disable=unused-variable
    def load(data, play, current_role_path=None, parent_role=None, variable_manager=None, loader=None):
        return RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)
    # pylint: enable=unused-variable

# Generated at 2022-06-23 06:45:55.316159
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(None, None, None, None)
    assert ri



# Generated at 2022-06-23 06:45:59.857507
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from .loader import DataLoader

    test_data = """
    ---
    - name: test_role
    - include_role:
        name: test_role
        tasks_from: main
    """
    loader = DataLoader()
    results = list(loader.load_from_file(filename=None, data=test_data, variable_manager=None, loader=loader))
    assert len(results) == 2
    assert results[0] == results[1]


# Generated at 2022-06-23 06:46:10.112030
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    result = RoleInclude.load("name", "play", "current_role_path", "parent_role", "variable_manager", "loader")
    # catch exception and check if exception is ansible error type
    if isinstance(result, AnsibleError):
        print(str(result) + "is an instance of AnsibleError")
    # if no exception then check if result is instance of RoleInclude
    elif isinstance(result, RoleInclude):
        print(str(result) + "is an instance of RoleInclude")

# this is for test to get the docstring for sphinx
f = RoleInclude.load
f.__doc__ = RoleInclude.load.__doc__
setattr(RoleInclude, 'load', f)
# end test

# Generated at 2022-06-23 06:46:22.513636
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    import os

    os.chdir("/home/mihai/ansible-playground")
    pl = Play().load("/home/mihai/ansible-playground/playbook/playbook.yml", variable_manager=None, loader=None)
    assert(pl)
    # print(pl._entries)
    # print("+++++++++++++++++++++++++++++++++++++")
    # print(len(pl._entries))

    assert(pl._entries[0]._role._role_path == os.getcwd() + '/roles/common')
    assert(pl._entries[1]._role._role_path == os.getcwd() + '/roles/common')

# Generated at 2022-06-23 06:46:34.780048
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import tempfile
    from ansible.playbook.play import Play
    from ansible.playbook.role import role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
              dict(action=dict(module='ping', args=''))
           ])

    play = Play().load

# Generated at 2022-06-23 06:46:36.245738
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert not isinstance(ri, dict)


# Generated at 2022-06-23 06:46:39.675521
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass
#    task = RoleInclude()
#    print task
#    assert task.get_name() is None

# Generated at 2022-06-23 06:46:43.419325
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = [
        {
            'role': 'b'
        }
    ]

    ri = RoleInclude.load(data)
    assert ri == {
        'role': 'b'
    }

# Generated at 2022-06-23 06:46:45.100147
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play

# Generated at 2022-06-23 06:46:46.032723
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    a = RoleInclude()
    assert a is not None

# Generated at 2022-06-23 06:46:55.324958
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    current_role_path = os.path.abspath("../tests/roles")
    play = {}
    variable_manager = {}
    loader = {}
    collection_list = {}

    data = {'role': 'test-name'}
    role_include = RoleInclude.load(data, play, current_role_path, None, variable_manager, loader, collection_list)
    assert role_include is not None

# Generated at 2022-06-23 06:47:06.823138
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar

    from ansible.vars.manager import VariableManager

    loader = AnsibleLoader(None, None)
    play = Play().load(
        loader.load(dict(
            name="Ansible Play",
            hosts='all',
            tasks=[],
        ))
    )
    variable_manager = VariableManager()
    vars = Templar(loader=loader, variables=variable_manager)
    ri = RoleInclude(play=play, variable_manager=variable_manager)
    assert ri._play._loader == loader
    assert ri._play == play
    assert ri._variable_manager == variable_manager
    assert ri._loader == loader
    assert ri

# Generated at 2022-06-23 06:47:09.342440
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_dict = {'name': 'abc'}
    role_include = RoleInclude()
    ri = role_include.load(role_include_dict)
    assert ri.name == 'abc'

# Generated at 2022-06-23 06:47:14.229949
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Set up parameters
    data = 'apache:name=httpd'
    task = '/etc/ansible/test.yml'
    current_role_path = '/etc/ansible/roles'
    variable_manager = 'variable_manager'
    loader = 'loader'
    collection_list = 'collection_list'

    # Execute the test
    result = RoleInclude.load(data, task, current_role_path, variable_manager, loader, collection_list)

    # Verify the results
    assert(result._role_name == 'apache')
    assert(result._role_name == 'httpd')

# Generated at 2022-06-23 06:47:23.831017
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # Create a fake ansible.playbook.play object
    class FakePlay:
        pass
    play = FakePlay()

    # Create a fake ansible.variable_manager.VariableManager object
    class FakeVariableManager:
        pass
    variable_manager = FakeVariableManager()

    # Create a fake ansible.parsing.dataloader.DataLoader object
    class FakeLoader:
        pass
    loader = FakeLoader()

    # Create a fake ansible._collections_loader.CollectionsLoader object
    class FakeCollectionList:
        pass
    collection_list = FakeCollectionList()

    # Create an instance of class RoleInclude
    role_include = RoleInclude(play=play, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    # Check instance of class RoleInclude

# Generated at 2022-06-23 06:47:35.161384
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import pytest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.playbook.role import definition
    from ansible.playbook.play import Play
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    ri = RoleInclude()
    assert isinstance(ri, definition.RoleDefinition)

    with pytest.raises(Exception):
        assert RoleInclude(play=Play().load({'name': 'testplay'}, variable_manager=None, loader=None),
                           variable_manager=None, loader=AnsibleCollectionLoader())

    assert RoleInclude(play=Play().load({'name': 'testplay'}, variable_manager=None, loader=None),
                       role_basedir=None, variable_manager=None, loader=AnsibleCollectionLoader())._

# Generated at 2022-06-23 06:47:46.411115
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import become_loader, role_loader

    become_loader.add_directory('./test/utils/plugins/become')
    role_loader.add_directory('./test/utils/plugins/roles')

    loader = DataLoader()
    context = PlayContext()
    inventory = InventoryManager(loader=loader, sources=['localhost', './test/utils/plugins/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 06:47:57.042284
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=None, sources='')
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()

    ri = RoleInclude()
    ri.play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=dict()))
        ]
    ), variable_manager=variable_manager, loader=None)
    r

# Generated at 2022-06-23 06:47:58.836559
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude()
    assert roleInclude != None

RoleInclude.register_loader()

# Generated at 2022-06-23 06:48:01.182658
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()


RoleInclude.register_namespace('meta')

# Generated at 2022-06-23 06:48:06.288736
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    mgr = Attribute()
    mgr.register('delegate_to', FieldAttribute(isa='string'))
    mgr.register('delegate_facts', FieldAttribute(isa='bool', default=False))
    ri = RoleInclude()
    assert ri.delegate_to is None
    assert ri.delegate_facts is False
    assert id(mgr) == id(ri._attributes_mgr)

# Generated at 2022-06-23 06:48:19.108684
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    variable_manager = None
    loader = None
    collection_list = None
    data = None
    play = None
    current_role_path = None
    parent_role = None
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleParserError as e:
        assert str(e) == "Invalid role definition: None"
    else:
        assert False, "AnsibleParserError was not raised"

    data = "some_string"

# Generated at 2022-06-23 06:48:30.409226
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    args = dict(
        play=None,
        role_basedir=None,
        variable_manager=None,
        loader=None,
        collection_list=None,
    )
    ri = RoleInclude(**args)
    ri.load("test_role", **args)
    assert ri.get_name() == "test_role"
    assert ri.get_role_path() is None
    assert ri.get_role_name() == "test_role"
    assert ri.get_role_def_params() == {}
    assert ri.get_tags() is None
    assert ri.get_when() is None
    assert ri.get_become() is True
    assert ri.get_become_user() is None
    assert ri.get_become_method

# Generated at 2022-06-23 06:48:32.022739
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = dict()
    data['name'] = 'test'

# Generated at 2022-06-23 06:48:34.661778
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    data = {'name':'test role'}
    assert(ri.load(data) == ri)

# Generated at 2022-06-23 06:48:45.749992
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    # data is a dict
    data = {'role': 'my_role'}
    assert ri.load(data, {}) == None
    # data is a string
    data = 'my_role'
    assert ri.load(data, {}) == None
    data = 'my_role,my_role2'
    try:
        ri.load(data, {})
    except AnsibleError as e:
        pass
    else:
        assert False, "AnsibleError not raised"


# Generated at 2022-06-23 06:48:51.054611
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
  import ansible.playbook.play
  import ansible.playbook.task
  import ansible.playbook.role
  import ansible.playbook.role.definition

  role_include = ansible.playbook.role.RoleInclude(play=ansible.playbook.play.Play(), role_basedir=['r'], variable_manager='v', loader='l')

# Generated at 2022-06-23 06:48:57.090068
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert str(RoleInclude()).startswith("<RoleInclude>")

# Generated at 2022-06-23 06:49:00.688564
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    some_include = RoleInclude()
    assert some_include.__class__.__name__ == "RoleInclude"

# Generated at 2022-06-23 06:49:04.522416
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()
    assert ri._loader is None
    assert ri._role_basedir is None
    assert ri._variable_manager is None
    assert ri._play is None



# Generated at 2022-06-23 06:49:12.582912
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.task import Task

    # test empty constructor
    play = Play()
    assert play.hosts == 'all'

    # test constructor with a play
    play = Play(
        role_name='apache',        
        name='main',
        hosts=['localhost'],
        user='root',
        tasks=[
            Task(action=dict(module='shell', args='ls'))
        ],
    )

# Generated at 2022-06-23 06:49:18.331589
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-23 06:49:27.396161
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # Test 1: test of correct initialization
    obj1 = RoleInclude()
    assert obj1._name == Attribute(name='name', default=None, static=True)
    assert obj1._play == Attribute(name='play', default=None, static=True)
    assert obj1._role_basedir == Attribute(name='role_basedir', default=None, static=True)
    assert obj1._variable_manager == Attribute(name='variable_manager', default=None, static=True)
    assert obj1._loader == Attribute(name='loader', default=None, static=True)
    assert obj1._dep_chain == []
    assert obj1._include_role_tasks == True
    assert obj1._task_blocks == []
    assert obj1._handlers == []
    assert obj1._default_vars

# Generated at 2022-06-23 06:49:35.540097
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import pytest

    class MockRoleDefinition:
        pass

    role_def = MockRoleDefinition()
    role_include = RoleInclude(play=role_def)
    assert role_include.play == role_def
    assert role_include.role_basedir == None
    assert role_include.variable_manager == None
    assert role_include.loader == None
    assert role_include.collection_list == None

    role_def = MockRoleDefinition()
    role_include = RoleInclude(play=role_def, role_basedir=role_def, variable_manager=role_def
                               , loader=role_def, collection_list=role_def)
    assert role_include.play == role_def
    assert role_include.role_basedir == role_def
    assert role_include.variable_manager == role_

# Generated at 2022-06-23 06:49:41.871111
# Unit test for method load of class RoleInclude

# Generated at 2022-06-23 06:49:52.304238
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class TestAnsibleModule():
        def __init__(self, path, names):
            self.path = path
            self.names = names
    class TestPlaybook():
        def __init__(self, ansible_modules):
            self.ansible_modules = ansible_modules
    a1 = TestAnsibleModule("path1", ["name1"])

    t1 = TestPlaybook([a1])
    ri = RoleInclude(t1)
    assert ri.file_name == 'main'
    assert ri.name is None
    assert ri.role_basedir is None
    assert ri.default_vars is {}
    assert ri._metadata is None
    assert ri.task_blocks == []
    assert ri.handler_blocks == []
    assert ri.play is t1

# Generated at 2022-06-23 06:49:54.046420
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)



# Generated at 2022-06-23 06:49:56.105326
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''Unit Tests'''
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-23 06:49:57.732274
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import collections

# Generated at 2022-06-23 06:50:09.178260
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class TestFuncLoad(object):
        def __init__(self, play, role_basedir, variable_manager=None, loader=None):
            self.play = play
            self.role_basedir = role_basedir
            self.variable_manager = variable_manager
            self.loader = loader
            self.tasks = list()
            self.handlers = list()
            self.vars = list()
            self.defaults = list()
            self.meta = list()
            self.dependencies = list()

        def load_data(self, data, variable_manager=None, loader=None):
            return data

    result = RoleInclude.load(data=TestFuncLoad(play='play', role_basedir='role_basedir'),
                              variable_manager='variable_manager', loader='loader')
   

# Generated at 2022-06-23 06:50:09.892870
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:50:11.653098
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    raise NotImplementedError("Please implement me!")

# Generated at 2022-06-23 06:50:12.495441
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:50:13.627180
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-23 06:50:20.558594
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude(play="", role_basedir="", variable_manager="", loader="", collection_list="")
    test_playbook_path = os.path.join(os.path.dirname(__file__), '../../../../test/integration/targets/test_playbook.yml')
    data_string = """
    - name: test
      hosts: localhost
      roles:
        - role_include
    """
    role_include.load_data(data=data_string, variable_manager="", loader="")

# Generated at 2022-06-23 06:50:23.589358
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    roleInclude = RoleInclude(
        play=None,
        role_basedir=None,
        variable_manager=None,
        loader=None,
        collection_list=None,
    )
    assert roleInclude.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-23 06:50:29.044485
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    variable_manager = 'vm'
    loader = 'loader'
    ri = RoleInclude(variable_manager=variable_manager, loader=loader)
    assert ri._variable_manager is variable_manager
    assert ri._loader is loader

# Generated at 2022-06-23 06:50:39.232654
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = DataLoader()

    play = dict(
        name = "Test Play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = 'simple_role',
    )

    play_context = PlayContext()
    all_vars = dict()
    variable_manager = VariableManager()
    variable_manager.extra_vars = all_vars
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-23 06:50:42.504895
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-23 06:50:50.887114
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.utils.vars import merge_hash

    r1 = {
        'name': 'apache',
        'roles': [
            'common',
            {
                'role': 'tomcat',
                'vars': {
                    'tomcat_port': '8080'
                },
                'tasks': [
                    {
                        'include': 'apache_vhost'
                    },
                    'foo'
                ]
            },
            {
                'role': 'nginx'
            }
        ]
    }

    p1 = Play.load(r1)

# Generated at 2022-06-23 06:50:52.614944
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test RoleInclude constructor
    role_include = RoleInclude()

# Generated at 2022-06-23 06:51:04.547798
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition

    role_include = RoleInclude()
    role_data = dict(
        name='name',
        description='description',
        tasks=[dict(
            action=dict(
                module='module',
                args='args',
            ),
            async_val=10,
            poll=10,
        )],
        handlers=[
            dict(
                action=dict(
                    module='module',
                    args='args',
                ),
            )
        ],
        vars=[
            dict(
                test='test',
            )
        ],
        meta=[
            dict(
                test='test',
            )
        ],
        defaults=[
            dict(
                test='test',
            )
        ],
    )


# Generated at 2022-06-23 06:51:12.345705
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    ri_play = "play"
    ri_current_role_path = "role_path"
    ri_parent_role = "parent_role"
    ri_variable_manager = "variable_manager"
    ri_loader = "loader"
    ri_collection_list = "collection"
    ri_data = {"role_name":"role"}

    assert ri.load(ri_data, ri_play, ri_current_role_path, ri_parent_role, ri_variable_manager, ri_loader, ri_collection_list) == ri.load_data(ri_data, ri_variable_manager, ri_loader)

# Generated at 2022-06-23 06:51:22.711006
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    play_context = PlayContext()
    play_source = dict(
        name = "Ansible Play",
        hosts = 'test',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=dict()))
            ]
        )
    play = Play().load(play_source, variable_manager=play_context.variable_manager, loader=play_context.loader)

    test_result = False
    expected_result = True
    role_path = None
    data = "test.rolefilename"

# Generated at 2022-06-23 06:51:23.718562
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-23 06:51:32.320404
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Execute the load method
    collection_list = "./tests/lib/ansible/collection/collection_data.yaml"
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=collection_list)
    ri.load_data('test_collection.test_namespace.test_role')
    # Check the attributes of the created object
    assert ri.get_name() == "test_role"
    assert ri.get_namespace() == "test_collection.test_namespace"
    assert ri.get_collection() == "test_collection"

# Generated at 2022-06-23 06:51:35.426224
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    with pytest.raises(AnsibleParserError) as err:
        role_include.load()
    assert "Invalid role definition" in str(err)

# Generated at 2022-06-23 06:51:36.595865
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
# vim: set expandtab: ts=4:sw=4:

# Generated at 2022-06-23 06:51:40.481448
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    ri = RoleInclude(PlayContext)

    if ri is not None:
        print("RoleInclude instantiate test passed")
    else:
        print("RoleInclude test failed")

# Generated at 2022-06-23 06:51:41.009730
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:51:44.825795
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert isinstance(role, RoleInclude)
    assert isinstance(role, RoleDefinition)


# Generated at 2022-06-23 06:51:55.233143
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    role = RoleInclude()
    assert role is not None
    assert role._loader is None
    assert role._variable_manager is None
    assert role._role_basedir is None
    assert role._role_name is None
    assert role._task_blocks is None
    assert role._main_task_block is None
    assert role._handlers is None
    assert role._main_task_block is None
    assert role._role_path is None
    assert role._default_vars is None
    assert role._task_vars is None
    assert role._role_params is None
    assert role._role_dep_map is None
    assert role._metadata is None
    assert role._play is None
    assert role._tags is None
    assert role._when is None
    assert role._allow_duplicates is False
    assert role._

# Generated at 2022-06-23 06:51:56.132087
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:52:00.919254
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # assertRaises(AnsibleParserError, lambda: RoleInclude.load('test',None,None,None,None,None))
    assertRaises(AnsibleError, lambda: RoleInclude.load('test, test2', None, None, None, None, None))


# Generated at 2022-06-23 06:52:01.858809
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-23 06:52:06.521304
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    result = RoleInclude.load(
        data=None,
        play=None,
        current_role_path=None,
        parent_role=None,
        variable_manager=None,
        loader=None,
        collection_list=None
    )
    assert result is None, "Task expected to be None but return value is " + str(result)

# Generated at 2022-06-23 06:52:08.694737
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("testing class RoleInclude\n")
    ri = RoleInclude()
    assert ri

test_RoleInclude()

# Generated at 2022-06-23 06:52:13.229983
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # Test 1: VariableManager is required
    try:
        ri = RoleInclude(variable_manager=None)
        assert ri == False
    except Exception as err:
        assert err.message == "variable_manager is required"

    # Test 2: Invalid RoleInclude definition
    try:
        ri = RoleInclude()
        ri.load(data={}, variable_manager=None)
        assert ri == False
    except Exception as err:
        assert err.message == "invalid role definition"

# Generated at 2022-06-23 06:52:14.626700
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()

# Generated at 2022-06-23 06:52:17.362838
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import test_RoleDefinition_load
    test_RoleDefinition_load(RoleInclude)

# Generated at 2022-06-23 06:52:28.440492
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class TestRoleInclude(RoleInclude):

        def load_data(self, data, variable_manager=None, loader=None):
            self.name = data
            self.role_name = data
            self.role_path = data
            return None

    try:
        ri = TestRoleInclude.load(None, None)
    except AnsibleParserError as e:
        assert e.message == 'Invalid role definition: None'

    ri = TestRoleInclude.load('testrole', None)
    assert ri.name == 'testrole'
    assert ri.role_name == 'testrole'
    assert ri.role_path == 'testrole'

    ri = TestRoleInclude.load({'name': 'testrole'}, None)
    assert ri.name == 'testrole'

# Generated at 2022-06-23 06:52:34.517470
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import pytest
    import tempfile
    import json
    import os


    class MockPlay():
        pass

    fh, temp_path = tempfile.mkstemp()
    os.close(fh)
    os.unlink(temp_path)
    p = MockPlay()
    v = None
    l = None

    # Test error condition: if data is not a string, dict or YAML object
    try:
        ri = RoleInclude.load(object(), p, temp_path, None, v, l)
    except AnsibleParserError as e:
        assert 'Invalid role definition' in str(e)

    # Test error condition: if data is a string and has comma in it

# Generated at 2022-06-23 06:52:40.761543
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = ('test_data', 'other_data', 'more_data')
    ri = RoleInclude.load(data, play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert(data == ri.load_data(data, variable_manager=None, loader=None))

# Generated at 2022-06-23 06:52:41.196911
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:52:47.864334
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test for method RoleInclude.load
    """
    args = {
        'data': {
            u'name': u'zabbix-agent',
            u'basic_role': {
                u'role': {
                    u'name': u'mysql',
                    u'basic_role': {
                        u'role': {
                            u'name': u'zabbix-agent',
                            u'basic_role': {
                                u'role': {
                                    u'name': u'mysql'
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    ri = RoleInclude(**args)
    assert ri.load(**args) == False, "Unexpected load result"

# Generated at 2022-06-23 06:52:53.081948
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    #print("Constructor test")
    #playbook = Playbook()
    #play = Play()
    #playbook.add_play(play)
    #play.add_role(RoleInclude())
    return

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:52:53.705298
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:53:05.269927
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.playbook.play_context import PlayContext

    class VariableManager():
        def __init__(self):
            self._vars = {}
            self._dist_vars = {}
            self._extra_vars = {}
            self._options_vars = {}

    role_include = RoleInclude()
    ri = role_include.load('test', 'sample_playbook', 'sample_current_role_path', 'sample_parent_role', VariableManager(), 'sample_loader', 'sample_collection_list')
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-23 06:53:13.578367
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-23 06:53:16.883805
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include._play is None
    assert role_include._role_basedir is None
    assert role_include._variable_manager is None
    assert role_include._loader is None
    assert role_include._collection_list is None


# Generated at 2022-06-23 06:53:25.828113
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    p = Play().load({'name': 'test', 'hosts': 'all'}, variable_manager=None, loader=AnsibleLoader(False))
    ri = RoleInclude(play=p, role_basedir=None, variable_manager=None, loader=AnsibleLoader(False))
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:53:35.157038
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    class test_args:
        def __init__(self, **args):
            self.__dict__.update(args)

    # testing RoleInclude constructor
    data = {
        'name': 'test',
        'hosts': 'all',
        'gather_facts': 'yes',
        'roles': [
            {'role': 'test1'},
            {'role': 'test2', 'when': 'ansible_os_family == "RedHat"'},
            {'role': 'test3', 'var1': 'first', 'var2': 'second'}
        ]
    }


# Generated at 2022-06-23 06:53:38.578234
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:53:49.513504
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # The output of the test results
    results = []
    results += [{'description':'test_RoleInclude_load_string_comma_in_data',
                'data':{'testdata': 'testrole,testrole2'},
                'expectation': 'Invalid old style role requirement: testrole,testrole2'}]
    results += [{'description':'test_RoleInclude_load_none_data',
                'data':None,
                'expectation': 'Invalid role definition: None'}]
    results += [{'description':'test_RoleInclude_load_dict_data',
                'data':'testrole',
                'expectation': None}]

    for result_dict in results:
        print(result_dict['description'])

# Generated at 2022-06-23 06:53:59.492820
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data1 = 'test_role'
    data2 = {'role': 'test_role'}
    parent_role = None
    role_basedir = 'test_role_basedir'
    variable_manager = 'test_variable_manager'
    loader = 'test_loader'
    play = 'test_play'
    collection_list = 'test_collection_list'

    ri1 = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    ri2 = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-23 06:54:09.445823
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import ROLE_CACHE
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleParserError

    play_path = os.path.join('test-data', 'playbooks', 'valid', 'role_definition')
    play_path_valid_2 = os.path.join('test-data', 'playbooks', 'valid', 'role_definition_valid_2')

    play = Play.load(play_path, variable_manager=VariableManager(), loader=module_loader)
    play_2 = Play.load(play_path_valid_2, variable_manager=VariableManager(), loader=module_loader)

   

# Generated at 2022-06-23 06:54:20.037595
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import fragments_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import task_loader
    from ansible.plugins.loader import filter_loader
    from ansible.template import Templar

    loader = fragments_loader
    task_loader.add_directory(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tasks'))
    filter_loader.add_directory(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'filters'))

# Generated at 2022-06-23 06:54:31.269727
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import ansible.playbook.block as block
    import ansible.playbook.task as task
    import ansible.template as template
    import ansible.variables.manager as variable_manager
    tmp_vm = variable_manager.VariableManager()
    tmp_loader = None
    tmp_play = block.Play()
    tmp_task = task.Task()
    tmp_data = template.Templatable("foo")
    RoleInclude(play=tmp_play, role_basedir="foo", variable_manager=tmp_vm, loader=tmp_loader, collection_list="foo")
    RoleInclude.load(tmp_data, tmp_play, "foo", tmp_task, tmp_vm, tmp_loader, "foo")

# Generated at 2022-06-23 06:54:42.211156
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import pytest

    from ansible.compat.tests.mock import patch

    from ansible import constants as C
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.plugins.loader import load_plugin_roles
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-23 06:54:53.296268
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()

    current_dir = os.path.dirname(os.path.abspath(__file__))
    test_file = os.path.join(current_dir, 'test.yml')
    test_data = open(test_file, 'r').read()

    play = Play.load(test_data, variable_manager=None, loader=None)
    ri = RoleInclude.load(play.get_roles()[0], play, current_role_path=None, parent_role=None, variable_manager=None, loader=None)