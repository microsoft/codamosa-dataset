

# Generated at 2022-06-23 06:44:49.437704
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:45:01.433609
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import collection_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    collections = collection_loader._load_collections([])
    collection_loader._set_collection_playbook_paths(collections)
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])

# Generated at 2022-06-23 06:45:02.092328
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:45:11.641256
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class MockPlay:

        def __init__(self):
            self.become_method = None
            self.become_user = None
            self.environment = None
            self.force_handlers = None
            self.force_tags = None
            self.gather_facts = None
            self.hosts = None
            self.name = None
            self.no_log = None
            self.port = None
            self.serial = None
            self.tags = None
            self.tasks = None
            self.transport = None
            self.vars = None
            self.vars_files = None
            self.vars_prompt = None
            self.vault_password = None
            self.ignore_errors = None
            self.when = None
            self.roles = None
            self._variable

# Generated at 2022-06-23 06:45:22.434228
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    import ansible.parsing.yaml.objects
    import ansible.parsing.yaml.loader
    import ansible.parsing.dataloader
    
    data = "TestRole"
    # Define test classes for AnsibleBaseYAMLObject
    class Loader(object):
        def load(self, data, file_name=None, *args, **kwargs):
            return data
        def add_constructor(self, tag, constructor):
            pass
        def add_multi_constructor(self, tag_prefix, multi_constructor):
            pass
    class Dumper(object):
        pass
    class Resolver(object):
        def add(self, kind, value):
            pass

# Generated at 2022-06-23 06:45:32.653298
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    data = """
    - src: /path/to/role
      path: /some/other/path
      name: test_role

    - src: https://github.com/geerlingguy/ansible-role-apache.git
      version: 2.0.0

    """
    role_collection = RoleInclude.load(data, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert role_collection[0].src == '/path/to/role'
    assert role_collection[0].name == 'test_role'
    assert role_collection[0].path == '/some/other/path'

# Generated at 2022-06-23 06:45:35.420454
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()

    assert role_include is not None

    print('RoleInclude Class is imported correctly.')

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:45:39.120923
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    play1 = Play()
    loader = DataLoader()
    ri = RoleInclude(play=play1, loader=loader)
    assert(ri is not None)
    assert(ri.loader is not None)

# Generated at 2022-06-23 06:45:40.985443
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert isinstance(role_include, RoleInclude)

# Generated at 2022-06-23 06:45:52.138388
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["tests/ansible/inventory/test_inventory"])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-23 06:45:55.144628
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.role_path is None
    assert ri.role_name is None
    assert ri.roles is None

# Generated at 2022-06-23 06:45:57.307467
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert isinstance(role_include, RoleInclude)
    assert isinstance(role_include, RoleDefinition)


# Generated at 2022-06-23 06:46:01.527751
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Instantiate class RoleInclude
    ri = RoleInclude()
    # Assertions
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:46:02.171468
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:46:04.842223
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-23 06:46:13.746982
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import ansible.playbook.play
    import ansible.playbook.role
    class my_vm(object):
        def get_vars(self):
            return dict()

    role_inc = RoleInclude(play=ansible.playbook.play.Play(), variable_manager=my_vm())
    # Check the default values
    attrs = role_inc.__dict__
    assert attrs['_name'] == 'role_include'
    assert attrs['_role_name'] == None
    assert attrs['_role_path'] == None
    assert attrs['_role_collection'] == None
    assert attrs['_role_collection_name'] == None
    assert attrs['_role_collection_namespace'] == None
    assert attrs['_role_collection_version'] == None

# Generated at 2022-06-23 06:46:22.726305
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import module_loader, callback_loader
    options = None
    passwords = {}
    inventory = ansible.inventory.Inventory(loader=DataLoader(), variable_manager=None, host_list='localhost')
    variable_manager = ansible.vars.VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()

    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=passwords,
        stdout_callback=None,
    )

    play_context = Play

# Generated at 2022-06-23 06:46:23.378840
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:46:25.719332
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
    #TODO


# Generated at 2022-06-23 06:46:36.172428
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Tests the method 'load' of class 'RoleInclude'
    """
    from ansible.playbook.play import Play

    # Test with correct data type
    # Test with a string type
    role_include = RoleInclude.load("role_name", Play(), "/tmp")
    assert role_include.get_name() == "role_name"
    assert role_include.get_role_path() == "/tmp/role_name"
    # Test with a dict type
    role_include = RoleInclude.load({"role": "role_name"}, Play(), "/tmp")
    assert role_include.get_name() == "role_name"
    assert role_include.get_role_path() == "/tmp/role_name"

    # Test with incorrect data type

# Generated at 2022-06-23 06:46:38.940248
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

    # TODO: Write tests for method load of class RoleInclude

# Generated at 2022-06-23 06:46:49.242172
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    play_source = dict(
        name = "Ansible Play",
        hosts = 'foo',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
        ]
    )

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='/tmp/ansible/hosts')
    variable_manager.set_inventory(inventory)

    play = Play.load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 06:47:01.363573
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    host = Host('test')
    host.set_variable('test_var1', 'test_value1')
    inventory = Inventory(loader=None)
    inventory.add_host(host)

    variable_manager = VariableManager(loader=None, inventory=inventory)

    role_path = './test/test_utils/test_tasks'
    role = RoleInclude(play=None, role_basedir=role_path, variable_manager=variable_manager, loader=None, collection_list=None)
    data = {'role': 'test_role'}
    role.load_data(data, variable_manager=variable_manager)

    assert role._role_name == 'test_role'
    assert role._role_path == os.path.join(role_path, 'test_role')
    assert role._task_blocks

# Generated at 2022-06-23 06:47:05.133008
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude()
    # constructor tests
    assert isinstance(r, RoleDefinition)
    assert isinstance(r, RoleInclude)
    assert r._delegate_to == None
    assert r._delegate_facts == False

# Generated at 2022-06-23 06:47:13.148632
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    ri = RoleInclude()
    assert(ri.load('geerlingguy.ntp', Play()) == None)
    assert(ri.load('', Play()) == None)
    assert(ri.load('geerlingguy.ntp,1.1.1.1', Play()) == None)
    assert(ri.load({}, Play()) == None)
    assert(ri.load(AnsibleUnicode('geerlingguy.ntp'), Play()) == None)
    assert(ri.load(AnsibleUnicode(''), Play()) == None)

# Generated at 2022-06-23 06:47:24.662109
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # create a temporary file
    test_dir = os.path.dirname(__file__)
    sandbox = os.path.join(test_dir, "sandbox")

    test_file = os.path.join(sandbox, "test_file")
    with open(test_file, "w") as fc:
        fc.write("hello world")

    # create temporary role directory
    role_dir = os.path.join(sandbox, "foobar")
    os.mkdir(role_dir)

    # create the role file
    role_file = os.path.join(role_dir, "meta", "main.yml")
    content = 'galaxy_info: author: "{{ author }}"'
   

# Generated at 2022-06-23 06:47:26.147029
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Basic unit test for role_include.py
    """
    pass

# Generated at 2022-06-23 06:47:29.721487
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_obj = RoleInclude()
    data = "webservers"
    play = create_play()
    current_role_path = "/tmp"
    errs = role_include_obj.load(data,play,current_role_path)
    assert(errs==0)



# Generated at 2022-06-23 06:47:30.548698
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:47:33.404342
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    with pytest.raises(AnsibleParserError) as exec_info:
        ri = RoleInclude()
        ri.load(1, None, None, None, None)

    assert "Invalid role definition" in str(exec_info.value)


# Generated at 2022-06-23 06:47:38.944969
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    fake_role_path = '/a/fake/path'
    fake_data = {
        "role_path": fake_role_path
    }
    # Test that we are returning an istance of RoleInclude
    assert(isinstance(RoleInclude.load(fake_data), RoleInclude))


# Generated at 2022-06-23 06:47:49.338503
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    os.environ['ANSIBLE_DEFAULT_HOST'] = 'localhost'
    os.environ['ANSIBLE_DEFAULT_IFACE'] = 'eth0'
    os.environ['ANSIBLE_DEFAULT_PORT'] = '22'
    os.environ['ANSIBLE_DEFAULT_REMOTE_USER'] = 'root'
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleError
    from ansible.inventory.host import Host

# Generated at 2022-06-23 06:47:50.498211
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role = RoleInclude.load("geerlingguy.ntp", None)

# Generated at 2022-06-23 06:47:51.480136
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ''' Unit test for method load of class RoleInclude '''
    pass

# Generated at 2022-06-23 06:47:58.725041
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class TestLoader():
        def __init__(self, is_role=False):
            self.path_exists = is_role

    class TestInventoryManager():
        def __init__(self):
            self.hosts = dict()
        def get_hosts(self, pattern="all"):
            return [h.name for k, h in iteritems(self.hosts)]

    class TestPlay():
        def __init__(self):
            self.hosts = dict()
            self.variable_manager = VariableManager()
            self.loader = TestLoader(is_role=True)
        def set_loader(self, loader):
            self.loader

# Generated at 2022-06-23 06:48:07.298051
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Given
    data = 'name,foo,bar'
    play = {}
    current_role_path = 'some/role_path'
    parent_role = 'parent_role'
    variable_manager = {}
    loader = {}
    collection_list = {}

    # When
    x = RoleInclude(play, current_role_path, variable_manager, loader)
    from ansible.playbook.role.requirement import RoleRequirement
    result = RoleRequirement.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    # Then
    assert(isinstance(result, RoleRequirement))
    # TODO : assert more

# Generated at 2022-06-23 06:48:18.721735
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()

    from ansible.playbook.play import Play

    play_obj = Play.load(dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
        ), variable_manager=context.variable_manager, loader=context.loader)

    RoleInclude.load('myrole', play=play_obj, variable_manager=context.variable_manager, loader=context.loader)

# Generated at 2022-06-23 06:48:27.058049
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    test_play = None
    test_role_basedir = None
    loader = None
    vm = None
    collection_list = None

    test_RoleInclude = RoleInclude(play=test_play, role_basedir=test_role_basedir, loader=loader, vm=vm, collection_list=collection_list)

    assert(test_RoleInclude._role_path is None), "Role path should be none"
    assert(test_RoleInclude._role_name is None), "Role name should be none"
    assert(test_RoleInclude._role_action is None), "Role action should be none"
    assert(test_RoleInclude._role_defaults is None), "Role defaults should be none"
    assert(test_RoleInclude._role_handlers is None), "Role handlers should be none"

# Generated at 2022-06-23 06:48:38.755397
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create a new role
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['hosts'])
    playbook = PlaybookExecutor(loader=loader, inventory=inventory, variable_manager=variable_manager,
                                playbooks=['playbook.yml'])


# Generated at 2022-06-23 06:48:41.526431
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("Test class RoleInclude")
    ri = RoleInclude()
    print(ri)
    assert(ri)


# Generated at 2022-06-23 06:48:50.035219
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    roleInclude = RoleInclude()
    assert isinstance(roleInclude, RoleInclude)
    #assert_raises(type_error, roleInclude.load(dict, dict, string_types, dict, dict, dict))
    #assert_raises(type_error, roleInclude.load(str, dict, string_types, dict, dict, dict))
    #assert_raises(type_error, roleInclude.load(dict, dict, dict, dict, dict, dict))
    assert_raises(type_error, roleInclude.load(str, dict, str, dict, dict, dict))

# Generated at 2022-06-23 06:48:58.582772
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    
    # Test constructor with default arg

    roleInclude = RoleDefinition()

    # Test constructor with arg 

    roleInclude = RoleDefinition(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-23 06:49:04.008027
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test constructor with no arguments
    ri = RoleInclude()

    # test constructor with all arguments
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

# unit test for load function of class RoleInclude

# Generated at 2022-06-23 06:49:13.630248
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import json
    import pprint
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)


# Generated at 2022-06-23 06:49:14.817418
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    obj = RoleInclude()


# Generated at 2022-06-23 06:49:15.614469
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()

# Generated at 2022-06-23 06:49:21.218703
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    ri = RoleInclude(play=play_context, variable_manager=variable_manager)
    assert ri.role_path is None


# Generated at 2022-06-23 06:49:24.092437
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_RoleInclude = RoleInclude()
    print(test_RoleInclude.__dict__)

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:49:34.379217
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class MockPlaybook:
        pass
    class MockCollectionList:
        pass
    collection_list = MockCollectionList()
    mock_play = MockPlaybook()
    current_role_path = '/path/to/role'
    variable_manager = None
    loader = None

    test_role = RoleInclude(play=mock_play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert test_role.get_role_path() == current_role_path
    assert isinstance(test_role, RoleDefinition)

# Generated at 2022-06-23 06:49:45.404605
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # test success, no exception raised
    test1_data = 'some-role-name'
    assert RoleInclude.load(test1_data) is not None
    assert RoleInclude.load(test1_data) is not None

    # test error, exception raised, not a dict and no string with comma
    test2_data = []
    exceptionRaised1 = False
    try:
        assert RoleInclude.load(test2_data) is not None
    except Exception as e:
        exceptionRaised1 = True
        assert type(e) == AnsibleParserError
        assert 'Invalid role definition' in e.__str__()
    assert exceptionRaised1

    # test error, exception raised, a string with a comma
    test3_data = 'some,role,name'
    exceptionRaised2 = False

# Generated at 2022-06-23 06:49:49.242063
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert ri.load(True, None) == None
    assert ri.load(None, None) == None
    assert ri.load({}, None) == None

# Generated at 2022-06-23 06:49:57.401408
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    ri = RoleInclude(
        play=None,
        role_basedir=None,
        variable_manager=None,
        loader=None,
        collection_list=None
    )
    ri._load_name = "test_role.yml"
    ri._role_name = "test_role"
    ri._role_path = "./test_role"

    assert ri.name == "test_role"
    assert ri.get_role_path(ri._role_path) == os.path.realpath("./test_role")
    assert ri.get_role_path(ri._role_name) == "./test_role"

# Generated at 2022-06-23 06:49:59.076791
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    role_include = RoleInclude()
    assert role_include is not None

# Generated at 2022-06-23 06:50:04.854176
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
   ri = RoleInclude()
   class Attibutes:
      def __init__(self):
        self.fields = {}
        self.aliases = {}
   class Option:
      def __init__(self):
         self.attributes = Attibutes()
   class Play:
      def __init__(self):
         self.options = Option()
   class Data:
      def __init__(self):
         self.loader = None
         self.variable_manager = None
         self.collection_list = None
   data = Data()
   play = Play()
   ri.load(data, play)


# Generated at 2022-06-23 06:50:05.838086
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: implement
    pass

# Generated at 2022-06-23 06:50:17.375906
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

    # Create host and group
    host1 = Host()
    host1.name = 'host1'
    group = Group()
    group.name = 'group1'
    group.add_host(host1)
    inventory.add_group(group)

# Generated at 2022-06-23 06:50:24.873640
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    variable_manager = "variable_manager"
    loader = "loader"
    collection_list = "collection_list"

    # Test case 1
    data = "ansible-role-nginx,0.1.0"
    play = "play"
    current_role_path = "current_role_path"
    parent_role = "parent_role"
    ri1 = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    assert ri1._role_name == "ansible-role-nginx"
    assert ri1._role_path == "ansible-role-nginx"
    assert ri1._role_collection == None
    assert ri1._role_collection_name == None
    assert ri1._role_collection_

# Generated at 2022-06-23 06:50:25.457403
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:50:26.546986
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:50:28.778869
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:50:30.147388
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # (object, str, str, dict, dict) -> dict
    pass

# Generated at 2022-06-23 06:50:40.013427
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy

    play = Play().load(dict(
        name="Ansible Play",
        hosts='localhost',
        roles=[dict(
            name='example_role',
            tasks=[]
        )]
    ), variable_manager=UnsafeProxy({}), loader=AnsibleLoader)
    assert play.get_roles()[0].get_name() == 'example_role'
    assert play.get_roles()[0].get_tasks() == []
    assert play.get_roles()[0].get_vars() == {}
    assert play.get_roles()[0].get_default_vars() == {}

# Generated at 2022-06-23 06:50:41.610660
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, "TODO"


# Generated at 2022-06-23 06:50:52.606317
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # test with string_type role include
    role_include_str = 'webservers'
    role_include_obj = RoleInclude.load(role_include_str)
    assert role_include_obj.role_name == 'webservers'
    assert role_include_obj.role_path is None

    # test with string_type role include with path
    role_include_str = 'webservers:../../roles'
    role_include_obj = RoleInclude.load(role_include_str)
    assert role_include_obj.role_name == 'webservers'
    assert role_include_obj.role_path == '../../roles'

    # test with dict role include
    # test with name, path and private

# Generated at 2022-06-23 06:51:04.547866
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test loading static role definition
    roledef = {"role": "apache", "name": "test"}
    ri = RoleInclude.load(roledef, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert ri.role == 'apache'
    assert ri.name == 'test'

# Generated at 2022-06-23 06:51:13.206653
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.role.definition import RoleDefinition
    # example role dependency file
    role_def = {
        'name': 'geerlingguy.java',
        'description': 'Install Oracle Java 8 on CentOS/RHEL.',
        'min_ansible_version': '2.3',
        'galaxy_info': {
            'author': 'Jeff Geerling',
            'issues': 'https://github.com/geerlingguy/ansible-role-java/issues',
            'role_name': 'java'
        }
    }

    role = RoleInclude.load(role_def)

    assert isinstance(role, RoleInclude)
    assert role.name == 'geerlingguy.java'
    assert role.description == 'Install Oracle Java 8 on CentOS/RHEL.'

# Generated at 2022-06-23 06:51:21.785561
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include.get_dependency_links() == []
    assert role_include.get_vars() == {}

    role_include.set_vars({
        'key1': 'value1',
        'key2': 'value2'
    })
    assert role_include.get_vars() == {
        'key1': 'value1',
        'key2': 'value2'
    }
    assert role_include.get_vars().get('key1') == 'value1'
    assert role_include.get_vars().get('key2') == 'value2'
    assert role_include.get_vars().get('key3') is None



# Generated at 2022-06-23 06:51:31.099384
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {'role': 'tomcat'}
    play = 'play.yml'
    role_basedir = 'roles'
    variable_manager = 'var_manager'
    loader = 'loader'
    collection_list = {'collections': 'list'}

    ri = RoleInclude.load(data, play, role_basedir, variable_manager, loader, collection_list)
    assert ri.play == play
    assert ri.role_basedir == role_basedir
    assert ri.variable_manager == variable_manager
    assert ri.loader == loader
    assert ri.collection_list == collection_list

# Unit test RoleInclude.load

# Generated at 2022-06-23 06:51:35.979165
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'test'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager=None
    loader = None
    collection_list = None
    s = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager,loader, collection_list)
    assert s.name == data

# Generated at 2022-06-23 06:51:44.232166
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create temporary file path
    temp_file = '/tmp/' + 'test_RoleInclude.yml'
    # Get content
    data = """
        - include_role:
            name: common
        - include_role:
            name: web
            tasks_from: lemp_tasks
            vars:
                nginx_dir: /opt
            tags: [debug]
            when: nginx_dir == '/opt'
        - include_role:
            name: common
            delegate_to: some.host
    """

    # Create a temporary file to run test case

# Generated at 2022-06-23 06:51:54.908864
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    import unittest

    try:
        from test.support import EnvironmentVarGuard
    except ImportError:
        from ansible_test._data import EnvironmentVarGuard

    class TestRoleInclude(unittest.TestCase):
        def setUp(self):
            self.env = EnvironmentVarGuard()
            self.env.set('ANSIBLE_ROLES_PATH', 'test/ansible/roles-test/test1/roles')

            self.loader = DataLoader()
            self.play_context = PlayContext()
            self.play_context.ROLE_CACHE = dict()
            self.play_context.ROLE_ERRORS = dict()


# Generated at 2022-06-23 06:51:58.095728
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude()
#
# Load method of class RoleInclude to return a RoleInclude instance from the given data
#

# Generated at 2022-06-23 06:52:10.691998
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible import context

    c = PlayContext()
    c._options = context.CLIARGS._parser.parse_args([])
    i = InventoryManager(c._options.inventory, loader=None)
    v = VariableManager(loader=None, inventory=i)
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=v, loader=None)
    assert isinstance(ri, RoleInclude)
    assert(ri.get_vars()=={})
    assert(ri.get_default_vars()=={})
    assert(ri.get_role_name()==None)

# Generated at 2022-06-23 06:52:22.649564
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Note: This test does not check the correct behavior, just the correct parsing.
    
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    # prepare test objects (note, this is a test, not real code)

# Generated at 2022-06-23 06:52:23.753531
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-23 06:52:28.477145
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play="fake_play", role_basedir="fake_role_basedir", variable_manager="fake_variable_manager",
                     loader="fake_loader", collection_list="fake_collection_list")
    # verify the class of ri
    assert(isinstance(ri, RoleDefinition))
    # verify the class of ri.attributes
    assert(isinstance(ri.attributes, Attribute))

# Generated at 2022-06-23 06:52:39.333095
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import ROLE_CACHE
    from ansible.playbook.role import ROLE_CACHE_MAX
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Create objects required for RoleInclude.load method
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-23 06:52:42.316251
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert isinstance(ri, RoleDefinition)

# Generated at 2022-06-23 06:52:55.491202
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.plugins.loader import callback_loader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    from collections import namedtuple

# Generated at 2022-06-23 06:53:07.255456
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test for type 'string_type'
    #
    # Arrange
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.loader import role_loader

    play_context = PlayContext()
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [dict(name="foo")],
    ), variable_manager=play_context.variable_manager, loader=role_loader)

    current_role_path = 'mock'
    parent_role = 'mock'
    variable_manager = 'mock'
    loader = AnsibleCollectionLoader()

# Generated at 2022-06-23 06:53:11.680080
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    obj = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert not RoleRequirement.load(data, play=play, role_basedir=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-23 06:53:19.596886
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars import VariableManager

    ri = RoleInclude()

    assert ri.play == None
    assert ri.role_basedir == None
    assert ri.variable_manager == None
    assert ri.loader == None
    assert ri.collection_list == None
    assert ri.role_name == None
    assert ri.role_path == None
    assert ri.namespace == None
    assert ri.name == None
    assert ri.include_role == None
    assert ri.meta == None

    # Test load_data method of RoleInclude class

# Generated at 2022-06-23 06:53:29.539258
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
  role_include = RoleInclude()
  try:
    role_include.load("")
    assert True
  except RoleInclude:
    assert False
  try:
    role_include.load("a")
    assert True
  except RoleInclude:
    assert False
  try:
    role_include.load("a,b")
    assert False
  except RoleInclude:
    assert True
  try:
    role_include.load("{x:xy}")
    assert True
  except RoleInclude:
    assert False
  try:
    role_include.load("[a,b]")
    assert True
  except RoleInclude:
    assert False

# Generated at 2022-06-23 06:53:41.616097
# Unit test for method load of class RoleInclude

# Generated at 2022-06-23 06:53:48.560425
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Set up test env
    """
    current_role_path = '/Users/me/.ansible/collections/ansible_collections/test_collection/roles'
    role_path = 'myrole'

    ri = RoleInclude(role_basedir=current_role_path, role_path=role_path)

    assert ri._role_path == role_path
    assert ri._role_name == role_path
    assert ri._role_basedir == current_role_path
    """

# Generated at 2022-06-23 06:53:55.499110
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert not ri.get_vars()
    assert not ri.get_include_tasks()
    assert not ri.get_include_vars()
    assert not ri.get_include_roles()
    assert not ri.get_include_role_tasks()
    assert not ri.get_modules()
    assert not ri.get_module_defaults()
    assert not ri.get_handlers()

# Generated at 2022-06-23 06:54:08.786143
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.mod_args import ModuleArgsParser

    pb = Play.load(dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello World'))),
        ]
    ), variable_manager=VariableManager(), loader=None)
    # Create a role inside the role dir
    role_path = os.path.join(os.path.dirname(__file__), 'roles', 'test_role1')
    os.mk

# Generated at 2022-06-23 06:54:09.319261
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:54:14.203199
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        role_include = RoleInclude.load("test", "play", "current_role_path", "parent_role", "variable_manager", "loader", "collection_list")
    except AnsibleError as exception:
        raise AssertionError("test fail: exception is %s" % exception)
    except:
        raise AssertionError("test fail")

# Generated at 2022-06-23 06:54:24.300730
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''
    Unit test for constructor of class RoleInclude
    '''
    role_src = {"roleA":{"tasks":[{"action":{"module":"ping"}}]}}
    fh_src=open("test.yml","w")
    yaml.dump(role_src,fh_src)
    fh_src.close()
    # default constructor
    ri = RoleInclude()
    assert ri
    # parameterized constructor
    play = Play()
    ri = RoleInclude(play=play)
    assert ri
    # load method
    ri = RoleInclude.load(role_src["roleA"],play)
    assert ri
    # load method with collection_list
    ri = RoleInclude.load(role_src["roleA"], play, collection_list=[collection_loader])
   

# Generated at 2022-06-23 06:54:36.757548
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    import os
    import pytest
    import yaml
    loader = DataLoader()
    # 定义一个有效的yaml模块

# Generated at 2022-06-23 06:54:44.292533
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class TestObj:
        def __init__(self, test_data):
            self.test_data = test_data

        def __repr__(self):
            return self.test_data

    my_test_obj = TestObj('test_data')
    test_inc = RoleInclude()

    try:
        res = test_inc.load(None)
        assert False, 'Test should result in an exception'
    except AnsibleParserError as e:
        assert 'Invalid role definition' in str(e)

    try:
        res = test_inc.load(my_test_obj)
        assert False, 'Test should result in an exception'
    except AnsibleParserError as e:
        assert 'Invalid role definition' in str(e)

    # test_data is a string

# Generated at 2022-06-23 06:54:52.605472
# Unit test for method load of class RoleInclude