

# Generated at 2022-06-23 06:44:54.105806
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:45:05.486137
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def mocked_load_data(*args, **kwargs):
        pass
    RoleInclude.load_data = mocked_load_data

    data = 'test_role'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    assert isinstance(ri, RoleInclude)

    data = 'test_role'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

# Generated at 2022-06-23 06:45:12.899491
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    arg = {'hosts': 'host1', 'roles': [{'role': '/etc/ansible/roles/role1', 'tasks': []},
                                       {'role': '/etc/ansible/roles/role2', 'tasks': []}]}
    play = Play().load(arg, variable_manager=None, loader=None)

    var = {'key1': 'value1', 'key2': 'value2'}
    variable_manager = VariableManager()
    variable_manager.extra_vars = var
    ri = RoleInclude(play=play, variable_manager=variable_manager)

# Generated at 2022-06-23 06:45:15.996344
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {'name':'test', 'asdf': 'asdf_value'}
    try:
        RoleInclude.load(data, None)
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 06:45:18.173234
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None


# Generated at 2022-06-23 06:45:20.793636
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = { 'role': 'common' }
    ri = RoleInclude()
    ri.load_data(data)
    assert ri._role_name == 'common'

# Generated at 2022-06-23 06:45:23.045699
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Constructor of class RoleInclude
    :return:
    """
    ri = RoleInclude()

# Generated at 2022-06-23 06:45:29.824651
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    "Unit test for constructor of class RoleInclude"
    # Load empty role
    role = RoleInclude()
    assert role.get_path() is None
    assert role.get_role_path() is None
    assert role.get_name() is None

    # Load role with data
    data = {
        'name': 'test',
        'hosts': 'test'
    }
    role = RoleInclude.load(data, None)
    assert role.get_name() == 'test'

# Generated at 2022-06-23 06:45:30.730134
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:45:35.737604
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {
        'name': 'someuser.somerole',
        'include': 'myrole'
    }
    ri = RoleInclude(data)
    assert ri.name == 'someuser.somerole'
    assert ri.include == 'myrole'

# Generated at 2022-06-23 06:45:49.231457
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Checks if the given role definition is a list or a dictionary
    def _roleDefinition_instance(role_definition):
        return isinstance(role_definition, string_types) or isinstance(role_definition, dict) or isinstance(role_definition, AnsibleBaseYAMLObject)

    # Checks if the given role definition is an old style role requirement
    def _old_style_roleRequirement(role_definition):
        if isinstance(role_definition, string_types):
            return True if ',' in role_definition else False

        return False

    # Valid role definitions
    role_definition_1 = 'geerlingguy.apache'
    role_definition_2 = 'geerlingguy.apache,vars'
    role_definition_3 = {'role': 'geerlingguy.apache'}

# Generated at 2022-06-23 06:45:58.566065
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class FakeVariableManager(object):
        def __init__(self):
            self.vars = dict(
                x=dict(
                    y=dict(
                        z='test')),
                roles="roles")

    class FakeLoader(object):
        def __init__(self):
            pass

    class FakePlay(object):
        def __init__(self):
            self.loader = FakeLoader()

    class FakeCollectionList(object):
        def __init__(self):
            self.collections = list()


# Generated at 2022-06-23 06:46:09.981885
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play

    yaml_data = """
- hosts: localhost
  gather_facts: False
  roles:
    - role: myrole1
      tags:
        - role1tag
    - role: myrole2
      tags:
        - role2tag
      when: not foo
    - myrole3
"""

    from ansible.parsing.yaml.loader import AnsibleLoader

    pb = AnsibleLoader(yaml_data, 'test-data.yml').get_single_data()
    play = Play.load(pb[0], variable_manager=None, loader=None)
    role_includes = play.get_roles()

    assert len(role_includes) == 3

    assert isinstan

# Generated at 2022-06-23 06:46:12.104174
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:46:17.229176
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    play = "test.yml"
    data = "role_name"

    role_basedir = "/home/test"
    variable_manager = "no"
    loader = "no"
    collection_list = ""

    ri = RoleInclude.load(data, play, role_basedir, variable_manager, loader, collection_list)
    assert ri is not None


# Generated at 2022-06-23 06:46:18.731023
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()


# Generated at 2022-06-23 06:46:19.329639
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:46:27.645257
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    raw_data = {
        'name': 'test-role',
        'include': {
            'role': 'test-role-include'
        }
    }

    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    play = Play()
    task_qm = TaskQueueManager(inventory=None, play=play, variable_manager=None, loader=None, passwords=None, stdout_callback=None)
    ri = RoleInclude(play=play, role_basedir='/tmp', variable_manager=None, loader=None, collection_list=None)
    ri.load_data(raw_data, variable_manager=None, loader=None)
    assert ri._role_name == 'test-role'

# Generated at 2022-06-23 06:46:33.947525
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {
        "name": "role1",
        "description": "Role to test loading methods of class RoleInclude",
        "tasks": {
            "main": [
                {"debug": {"var": "hostvars[inventory_hostname]"}}
            ]
        }
    }
    role_def = RoleInclude.load(data, None, None)
    assert(role_def.get_name() == "role1")

# Generated at 2022-06-23 06:46:44.992483
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Simple test to ensure that load of role_include works.
    role_basedir = "./test/units/modules/test_include/roles"
    import os
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = module_loader._load_path_based_loader()

    play = Play.load(dict(name="test"),
                     loader=loader,
                     variable_manager=VariableManager(),
                     loader=DataLoader(),
                     inventory=InventoryManager())


# Generated at 2022-06-23 06:46:52.509718
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    play_context = PlayContext()
    templar = Templar(loader=None, variables=dict())
    variable_manager = VariableManager()

    path = os.path.join(os.getcwd(), 'lib/ansible/roles/webserver')
    variable_manager.set_inventory(inventory=None)
    variable_manager.set_play_context(play_context=play_context)
    variable_manager._extra_vars = UnsafeProxy(dict())


# Generated at 2022-06-23 06:46:56.805082
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-23 06:46:59.687064
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """This is the test for the RoleInclude class constructor
    """
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:47:09.619209
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play_context = dict(
        port=5309
    )

    variable_manager = dict(
        hostvars=dict(
            hostname=dict(
                ansible_host="127.0.0.1",
                ansible_port=5308,
                ansible_user="test_user",
                ansible_ssh_pass="passwd",
                ansible_become_pass="become_passwd"
            )
        )
    )

    role_include = dict(
        name="common"
    )

    role_include_2 = dict(
        name="common",
        vars=dict(
            var1="value1"
        )
    )


# Generated at 2022-06-23 06:47:20.526991
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_loader_obj = AnsibleLoaderMock()
    test_var_manager_obj = AnsibleVariableManagerMock()
    test_play_obj = AnsiblePlayMock()
    # testing string type role definition
    test_str_role_def = 'testrole'
    test_result_obj = RoleInclude.load(data=test_str_role_def,
                                       play=test_play_obj,
                                       variable_manager=test_var_manager_obj,
                                       loader=test_loader_obj)
    assert isinstance(test_result_obj, RoleDefinition)
    assert isinstance(test_result_obj, RoleInclude)

    # testing dict type role definition
    test_dict_role_def = {'role': 'testrole'}

# Generated at 2022-06-23 06:47:26.482349
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    obj = RoleInclude()
    data = "{'role1': {'default': { 'var1' : 'default_var1'}}} "
    variable_manager = None
    loader = None
    play = None

    obj.load(data=data, play=play, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-23 06:47:29.621441
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    x = ''
    y = RoleInclude.load(x, '', '')
    assert type(y) is RoleInclude

# Generated at 2022-06-23 06:47:30.771370
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude.load('name', None, None, None, None, None)

# Generated at 2022-06-23 06:47:33.851061
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleDefinition)
    assert ri.get_role_path() == None
    assert ri.get_role_name() == None
    assert ri.is_loaded() == False
    assert ri.is_implicit() == False


# Generated at 2022-06-23 06:47:44.652742
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    data = {}
    play = {}
    current_role_path = ""
    parent_role = {}
    variable_manager = VariableManager()
    loader = DataLoader()
    collection_list = {}
    role_definition = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    # role_definition is an instance of RoleDefinition
    if isinstance(role_definition, RoleDefinition):
        print('pass')

if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-23 06:47:53.195197
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.plugins import module_loader
    from ansible.utils.vars import load_extra_vars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.role.definition import RoleDefinition
    import os
    import json

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    ROLE

# Generated at 2022-06-23 06:47:54.530631
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:47:55.734962
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-23 06:48:05.687444
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import copy
    ri = RoleInclude()
    assert ri.get_name() == 'RoleInclude'
    assert ri.get_delegate_to() == 'local'
    assert ri.get_delegate_facts() == False
    ri.set_delegate_to('test')
    assert ri.get_delegate_to() == 'test'
    ri.set_delegate_facts(True)
    assert ri.get_delegate_facts() == True
    ri2 = RoleInclude()
    assert ri2.get_delegate_to() == 'local'
    assert ri2.get_delegate_facts() == False
    ri.load_from_file('/test', None)
    assert ri.get_delegate_to() == 'local'
   

# Generated at 2022-06-23 06:48:14.835998
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Initialization
    data = "geerlingguy.jenkins"
    play = ""
    current_role_path = ""
    parent_role = ""
    variable_manager = ""
    loader = ""
    collection_list = ""

    # Action
    result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    # Assertion
    assert isinstance(result, RoleInclude)

# Generated at 2022-06-23 06:48:17.005051
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)


# Generated at 2022-06-23 06:48:25.881734
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.compat.mock import MagicMock
    my_play = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'roles':[
            {
                'name': 'role_included_name_1'
            },
            {
                'name': 'role_included_name_2',
                'tasks': [
                    {'debug': 'msg=Hello world'}
                ]
            }
        ]
    }, variable_manager=VariableManager(), loader=DataLoader())
    my_variable_manager = my_play.get_

# Generated at 2022-06-23 06:48:38.649865
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    loader, inventory, variable_manager = (None, None, VariableManager())

    play_context = PlayContext()
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )
    # Create play object, playbook objects use .load instead of init or new methods,
    # this

# Generated at 2022-06-23 06:48:40.518830
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Create a new RoleInclude object
    ri = RoleInclude()

# Generated at 2022-06-23 06:48:42.333372
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_RoleInclude = RoleInclude()
    assert(test_RoleInclude is not None)

# Generated at 2022-06-23 06:48:54.165334
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    my_config = "test_config.yml"
    my_role = "test_RoleInclude_load"

    role_include = RoleInclude()

    # Test with invalid role definition
    try:
        role_include.load(data=None, play=None, current_role_path=my_role, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)
        assert e.message == "Invalid role definition: None"

    # Test with invalid old style role requirement

# Generated at 2022-06-23 06:49:04.994882
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Create play
    play = Play()

    # Create variable_manager
    variable_manager = VariableManager()

    # Create loader
    loader = DataLoader()

    # Create role_basedir
    role_basedir = "/user/roles"
    roleInclude = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader)

    # Check class variable
    assert isinstance(roleInclude._delegate_to, Attribute)
    assert isinstance(roleInclude._delegate_facts, Attribute)

    # Test load() with invalid datas
    data = 123

# Generated at 2022-06-23 06:49:08.528688
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__ == RoleInclude
    assert ri._parent_role == None
    assert ri._role_params == {}
    assert ri._role_path == None
    assert type(ri._role_name) == Attribute

# Generated at 2022-06-23 06:49:09.931086
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri._variables, dict)
    assert isinstance(ri._tags, list)

# Generated at 2022-06-23 06:49:10.911146
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Load constructor of class RoleInclude
# test_RoleInclude()

# Generated at 2022-06-23 06:49:18.379989
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.playbook.block import Block
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-23 06:49:27.421599
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import ansible.playbook
    import ansible.playbook.play
    import ansible.utils.vars

    from ansible.playbook.play import Play

    ri = RoleInclude()

    host = ansible.inventory.host.Host(name="myhost", port=22)
    groups = [ ansible.inventory.group.Group(name="mygroup") ]
    groups[0].add_host(host)
    inventory = ansible.inventory.inventory.Inventory(hosts=[host], groups=groups)

    variable_manager = ansible.utils.vars.VariableManager()
    variable_manager.set_inventory(inventory)
    loader = ansible.parsing.dataloader.DataLoader()


# Generated at 2022-06-23 06:49:29.677713
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = Play()
    loader = DataLoader()
    variable_manager = VariableManager()
    ri =  RoleInclude(play=play, loader=loader, variable_manager=variable_manager)
    assert ri

# Generated at 2022-06-23 06:49:30.879954
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # FIXME: needs a real unit test
    pass

# Generated at 2022-06-23 06:49:38.526191
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class _FakeRole:
        def __init__(self, name, conf, variable_manager, loader, play):
            pass
    for _var in ([], ['a'], [('a', 'b')]):
        assert isinstance(RoleInclude.load('a', _FakeRole, variable_manager=_var, loader='b', play='c'), RoleRequirement)
    assert isinstance(RoleInclude.load({'role': 'a'}, _FakeRole, variable_manager='b', loader='c', play='d'), RoleInclude)
    assert isinstance(RoleInclude.load(yaml.AnsibleBaseYAMLObject({'include_role': 'a'}), _FakeRole, variable_manager='b', loader='c', play='d'), RoleInclude)

# Generated at 2022-06-23 06:49:41.810730
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == "RoleInclude"
    assert ri.__class__.__bases__[0].__name__ == "RoleDefinition"    
    

# Generated at 2022-06-23 06:49:46.412280
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    a = RoleInclude()
    a.load("ansible-role-a")
    a.load("role: ansible-role-a")
    a.load("role: ansible-role-a, app")
    a.load("- role: ansible-role-a")
    a.load("- role: ansible-role-a, app")

# Generated at 2022-06-23 06:49:58.785290
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.get_vars() == {}
    ri._load_attr_values({"vars": "None"})
    assert ri.get_vars() == "None"
    ri._load_attr_values({"vars": "A"})
    assert ri.get_vars() == "A"
    ri._load_attr_values({"tasks": "B"})
    assert ri.get_tasks() == "B"
    ri._load_attr_values({"tasks": "None"})
    assert ri.get_tasks() == None
    ri._load_attr_values({"tasks": "A"})
    assert ri.get_tasks() == "A"
    ri._load_attr_values

# Generated at 2022-06-23 06:50:10.901494
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager._extra_vars = {"foo": "bar"}
    loader = None
    play_context = PlayContext()
    play_context._extra_vars = {"foo": "bar"}
    templar = Templar(loader=loader, variables=variable_manager)

    ri = RoleInclude(play=play_context, variable_manager=variable_manager, loader=loader)

    assert ri._delegate_to == None
    assert ri._delegate_facts == False

    # _delegate_facts: True
    data1 = {"name": "role_name", "foo": "bar", "_delegate_facts": True}

# Generated at 2022-06-23 06:50:13.180388
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert(False), "TODO: Write unit tests for RoleInclude"


# Generated at 2022-06-23 06:50:15.742984
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("test RoleInclude  Constructor")
    a = RoleInclude()
    print(a)

# test_RoleInclude()

# Generated at 2022-06-23 06:50:18.781103
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-23 06:50:28.761280
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    hostvars = dict()
    variable_manager = VariableManager()
    role_include = RoleInclude()

    assert role_include.loader is None
    assert role_include.play is None
    assert role_include.role_basedir is None
    assert role_include.variable_manager is None
    assert role_include.tags is None
    assert role_include.skip_tags is None
    assert role_include.name is None
    assert role_include.collections is None
    assert role_include.collection_list is None
    assert role_include.default_vars == dict()
    assert role_include.dep_chain == []
    assert role_include.description is None
    assert role_include.dirname is None
    assert role_include.handlers == dict()
    assert role_include.vars == dict()
   

# Generated at 2022-06-23 06:50:35.532740
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri
    data = {
        'name': 'role1',
        'tasks': [{'action': {'module': 'debug', 'msg': 'hi'}}],
        'handlers': [{'action': {'module': 'debug', 'msg': 'hello'}}],
    }
    variable_manager = 'variable_manager'
    loader = 'loader'
    ri = RoleInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert ri

# Generated at 2022-06-23 06:50:47.224010
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.variable_manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    data = {
        'name': 'common',
        'description': 'common role'
    }

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources='localhost,'))
    play = Play().load(data, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 06:50:56.270418
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
        Unit test for method load of class RoleInclude
    '''

    import unittest
    import yaml

    try:
        # Ansible < 2.3
        from ansible.playbook.role.definition import RoleDefinition
        from ansible.playbook.role.requirement import RoleRequirement
    except ImportError:
        # Ansible >= 2.3
        from ansible.playbook.role.definition import RoleDefinition
        from ansible.playbook.role.requirement import RoleRequirement


    class TestRoleInclude(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_load_data(self):
            ''' test load_data method of class RoleInclude '''


# Generated at 2022-06-23 06:51:11.085342
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Check role definition with string
    def test_string(value):
        # Calling load()
        role = RoleInclude.load(value, object(), object(), object(), object(), object(), object())
        assert role
        assert role._role_name == value

    # Check with string value
    test_string("toto")
    test_string("toto.tata")

    # Check with a bad string value
    try:
        test_string("toto,tata")
    except AnsibleError as e:
        assert "Invalid old style role requirement" in str(e)

    # Check role definition with dict (role)
    def test_dict(value):
        # Calling load()
        role = RoleInclude.load(value, object(), object(), object(), object(), object(), object())
        assert role
        assert role._role_name

# Generated at 2022-06-23 06:51:21.695543
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Loads the processing  for RoleInclude for the unit test
    """
    _loader = DictDataLoader({})
    role = RoleInclude(loader=_loader)
    role_list = [{"role_list": {"name":"test1", "role": "test2"}},
                 {"test_dict": {"name":"test1", "role": "test2"}}
                ]
    for elem in role_list:
        try:
            role.load(elem)
        except AnsibleParserError as e:
            assert e.message == "Invalid role definition: %s" % (elem,)


# Generated at 2022-06-23 06:51:22.958718
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-23 06:51:33.782717
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play

    p = Play.load(dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = 5
    ))
    assert isinstance(p, Play)
    assert p.hosts == ['localhost']
    try:
        r = RoleInclude.load(5, play=p)
        assert False, "Invalid role definition not detected"
    except AnsibleParserError:
        pass
    try:
        r = RoleInclude.load(dict(name = "test", roles=5), play=p)
        assert False, "Invalid role definition not detected"
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 06:51:34.998873
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:51:37.087137
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    obj = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert obj is not None

# Generated at 2022-06-23 06:51:43.597860
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {'role': {'name': 'test-role', 'scenario': 'test-scenarion'}}
    p = Play()
    ri = RoleInclude(play=p, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert(isinstance(ri, object))
    assert(isinstance(ri.load_data(data), RoleInclude))
    assert(isinstance(RoleInclude.load(data, p, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None), RoleInclude))

# Generated at 2022-06-23 06:51:54.736972
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    fake_loader = {'some': 'data'}
    fake_variable_manager = {'some': 'data'}
    fake_play = {'some': 'data'}

    ri = RoleInclude(loader=fake_loader, variable_manager=fake_variable_manager, play=fake_play)
    assert ri.loader == fake_loader
    assert ri.variable_manager == fake_variable_manager
    assert ri.play == fake_play

    # Data is a string type
    data = 'invalid,old,style,role,requirement'
    ri = RoleInclude(loader=fake_loader, variable_manager=fake_variable_manager, play=fake_play)

# Generated at 2022-06-23 06:52:04.825427
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Construct one object of class RoleInclude
    """
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role_include import RoleInclude

    # create one object of class Play
    p = Play()

    # create one object of class RoleDefinition
    rd = RoleDefinition()

    # create one object of class RoleRequirement
    rr = RoleRequirement()

    # create an object of class RoleInclude
    ri = RoleInclude(play=p, role_basedir=rd, variable_manager=rr)
    print(ri)

    # create an object of class RoleInclude
    ri = RoleInclude()
    print(ri)



# Generated at 2022-06-23 06:52:14.279129
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = 'play.yml'
    current_role_path = 'role/path'
    parent_role = None
    variable_manager = 'variable_manager'
    loader = 'loader'
    collection_list = 'collection_list'

    ri = RoleInclude.load('', play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert(ri == None)

    ri = RoleInclude.load('role', play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert(ri == None)

    #data = dict(name='role.name', tasks=[])
    #data = dict(name='role.name', tasks=[], tags=[])
    #data = dict(include='role.name', tasks=[], tags=[])
   

# Generated at 2022-06-23 06:52:17.418952
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude()
    assert isinstance(roleInclude, RoleInclude)


#  Unit test for method load of class RoleInclude

# Generated at 2022-06-23 06:52:19.358534
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert issubclass(RoleInclude, RoleDefinition)
    assert RoleInclude.__doc__

# Generated at 2022-06-23 06:52:24.159824
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = '''
- role:
        name: test
        src: /tmp/test
    - role:
        name: test2
        src: /tmp/test2
    '''
    _data = [0, {}]
    ri = RoleInclude(data, _data)
    print(ri)
# --- End: class RoleInclude

# Generated at 2022-06-23 06:52:33.153586
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import ansible.playbook.role.definition

    objects = [{},          # dict
              '',          # str
              'test'       # str
              ]

    for obj in objects:
        # RoleInclude class expects a dictionary object.
        #   - raises AnsibleParserError if obj is of other types
        #   - raises AnsibleError if obj is of type str and contains ','
        #   - returns the object 'obj' back if obj is of type str and does not contain ','
        try:
            obj = ansible.playbook.role.definition.RoleInclude.load(data=obj, play=True, current_role_path=True, parent_role=True, variable_manager=True, loader=True)
        except (AnsibleParserError, AnsibleError) as e:
            print(e)
            continue

# Generated at 2022-06-23 06:52:34.181744
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:52:44.723137
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    p = dict(
        name = 'test_play',
        hosts = 'all',
        roles = [
            dict(
                name = 'common',
                tasks = [
                    dict(
                        command = 'ls'
                    )
                ]
            )
        ]
    )
    host_list = [
        {
            'hostname': 'test-host',
            'groups': [
                'group1'
            ]
        }
    ]
    collection_list = ['/path/to/collections/']
    variable_

# Generated at 2022-06-23 06:52:56.376738
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test with invalid string type data
    fake_data = ["some string"]
    fake_play = object()
    fake_role_path = object()
    fake_variable_manager = object()
    fake_loader = object()
    fake_collection_list = object()
    try:
        RoleInclude.load(fake_data, fake_play, fake_role_path, None, fake_variable_manager, fake_loader, fake_collection_list)
    except Exception as e:
        print(e)
        assert isinstance(e, AnsibleParserError)

    # Test with invalid dict type data
    fake_data = {'name': None, 'some_key': 'some_value'}
    fake_play = object()
    fake_role_path = object()
    fake_variable_manager = object()
    fake_loader

# Generated at 2022-06-23 06:52:57.695972
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert role

# Generated at 2022-06-23 06:53:08.408801
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    fn = os.path.dirname(os.path.abspath(__file__)) + '/import_playbook_test.yml'
    play_path = os.path.dirname(fn)
    pb = AnsibleParser(playbook_path=play_path)
    pb.parse()
    play = pb.playbook[0]
    role = RoleInclude(play=play, role_basedir=play_path, variable_manager={}, loader={})
    assert role.get_vars()
    assert role.get_default_vars()
    assert role.get_role_params()
    assert role._delegate_to is None
    assert role._delegate_facts is False
    print(role.get_unregistered_vars())
    assert role.get_unregistered_vars() == set

# Generated at 2022-06-23 06:53:18.254191
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = dict()
    role_basedir = dict()
    variable_manager = dict()
    loader = dict()
    collection_list = dict()
    ri = RoleInclude(play, role_basedir, variable_manager, loader, collection_list)
    assert ri._play == play
    assert ri._role_basedir == role_basedir
    assert ri._variable_manager == variable_manager
    assert ri._loader == loader
    assert ri._collection_list == collection_list
    assert ri._metadata == dict()
    assert ri._role_name == None
    assert ri._role_path == None
    assert ri._role_params == dict()
    assert ri._role_vars == dict()
    assert ri._role_default_vars == dict()
    assert ri._

# Generated at 2022-06-23 06:53:19.107174
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert False

# Generated at 2022-06-23 06:53:30.605408
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """ 
    @role: Input a role instance and call load method
    @assert: role instance
    """
    role_name = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../lib/ansible/playbook/test_roles/some_role')
    role = RoleInclude()
    role.name = role_name
    role.role_basedir = role_name

    var_manager = PluginLoader('AnsibleInventoryManager', 'TestInventory', '')
    # var_manager = VariableManager()
    ansible_loader = DataLoader()
    collection_loader = CollectionsLoader()
    collection_paths = collection_loader._get_paths()


# Generated at 2022-06-23 06:53:41.810043
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test load when invalid role definition is given
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventories = []
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost'))

# Generated at 2022-06-23 06:53:52.625740
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import os

    os.environ['ANSIBLE_GATHERING'] = 'smart'
    # os.environ['ANSIBLE_DEPRECATION_WARNINGS'] = '1'
    # os.environ['ANSIBLE_DEBUG'] = '1'
    os.chdir(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))))
    # print(os.getcwd())


    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-23 06:53:59.099447
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play

    # test old style
    play_data = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        roles=[
            'foo,1.0',
            'bar,2.0',
            'baz,3.0'
        ],
    )
    play = Play.load(play_data, variable_manager=None, loader=None)
    assert(len(play.get_roles()) == 3)
    assert(play.get_roles()[0] == 'foo,1.0')
    assert(play.get_roles()[1] == 'bar,2.0')
    assert(play.get_roles()[2] == 'baz,3.0')



# Generated at 2022-06-23 06:54:06.021263
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    loader = None
    collection_list = None
    role_basedir = '/path/to/roledir'
    play = {'hosts': 'myhost'} 
    variable_manager = Attribute()
    data = 'myrole'
    role_include = RoleInclude(play, role_basedir, variable_manager, loader, collection_list)
    ret = role_include.load(data, play, role_basedir, parent_role=None, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    print("ret : %s" % ret)


if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:54:09.026163
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude.load('good_role', None, None, None, None, None)
    RoleInclude.load({'name': 'good_role'}, None, None, None, None, None)

# Generated at 2022-06-23 06:54:19.517313
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import sys
    import os
    import shutil
    import __main__
    #__main__.__file__ = '/tmp/unit_test_file'

    t_path = os.path.join(os.path.dirname(__file__), 'unit-test-roles')

    p = AnsibleParser()
    p.set_playbook_basedir(t_path)
    p.set_remote_user('bob')
    p.command_line = CommandLine()
    args = p.parse()
    args['inventory'] = Inventory(loader=p.loader, variable_manager=p.variable_manager, host_list='test/unit/ansible_hosts')
    p.variable_manager.set_inventory(args['inventory'])

# Generated at 2022-06-23 06:54:32.294489
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    play_context = dict(
        become=False,
        become_method=None,
        become_user=None,
        check_mode=False,
        diff=False
    )

    variable_manager_constructor_args = dict(
        loader=DataLoader(),
        inventory=None
    )

    variable_manager_constructor_kwargs = dict(
        extra_vars=dict(
            foo='bar'
        )
    )

    variable_manager = VariableManager(
        *variable_manager_constructor_args,
        **variable_manager_constructor_kwargs
    )


# Generated at 2022-06-23 06:54:42.701568
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    ri = RoleInclude.load('test', 'play', 'role_basedir', 'parent_role', 'variable_manager', 'loader')
    assert ri._role_name == 'test'
    assert ri._play == 'play'
    assert ri._role_path == 'role_basedir'
    assert ri._role_name == 'test'
    assert ri._role_name == 'test'

    ri = RoleInclude.load('variable_manager', 'loader', 'play', 'role_basedir', 'parent_role')
    assert ri._role_name == 'variable_manager'
    assert ri._play == 'loader'
    assert ri._role_path == 'play'
    assert ri._role_name == 'variable_manager'

# Generated at 2022-06-23 06:54:53.388259
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = "tests.unit.test_playbook_include.test_RoleInclude"
    play = "tests.unit.test_playbook_include.test_RoleInclude"
    current_role_path = "tests.unit.test_playbook_include.test_RoleInclude"
    parent_role = "tests.unit.test_playbook_include.test_RoleInclude"
    variable_manager = "tests.unit.test_playbook_include.test_RoleInclude"
    loader = "tests.unit.test_playbook_include.test_RoleInclude"
    collection_list = "tests.unit.test_playbook_include.test_RoleInclude"
