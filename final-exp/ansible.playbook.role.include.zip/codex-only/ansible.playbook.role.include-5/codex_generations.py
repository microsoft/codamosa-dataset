

# Generated at 2022-06-23 06:44:49.857137
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri_test = RoleInclude()
    assert ri_test is not None

# Generated at 2022-06-23 06:45:01.978869
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """ This is a unit test for method RoleInclude.load """
    print("Testing method load of class RoleInclude")

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_context = PlayContext()
    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello World!')))
        ]
    ), variable_manager=variable_manager, loader=None)
    play._variable_manager = variable_

# Generated at 2022-06-23 06:45:11.572649
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    Test RoleInclude.load()
    '''
    # Roles in a list
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    role_include = RoleInclude(play=None, role_basedir=None, variable_manager=variable_manager, loader=loader)
    data = [
            {'role': 'common'},
            {'role': 'webservers', 'ports': [80, 443]},
          ]
    role_include.load_data(data, variable_manager=variable_manager, loader=loader)
    assert role_include._role_name == ['role[common]', 'role[webservers]']
    assert role_include._role_params == [{}, {'ports': [80, 443]}]

    # Roles in a dict
   

# Generated at 2022-06-23 06:45:22.561459
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import ansible.errors as errors
    import ansible.playbook.role.definition as rdef
    from ansible.module_utils import six
    from collections import Mapping


    ri = RoleInclude()

    # Check data type (string)
    input_data = "test.test1"
    output_data = ri.load(input_data, None)

    assert isinstance(output_data, rdef.RoleInclude)

    # Check data type (dict)
    input_data = {"role": "test.test1"}
    output_data = ri.load(input_data, None)

    assert isinstance(output_data, rdef.RoleInclude)

    # Check data type (mapping)
    input_data = Mapping()

# Generated at 2022-06-23 06:45:27.189754
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert r.__class__.__name__ == 'RoleInclude'
    assert r.__class__.__base__.__name__ == 'RoleDefinition'

# Generated at 2022-06-23 06:45:28.498705
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test for method load.
    """
    pass

# Generated at 2022-06-23 06:45:39.223139
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ''' unit tests for load method of class RoleInclude '''

    # load method of class RoleInclude requires 4 arguments
    # 1. data : dictionary or string
    # 2. play : playbook object
    # 3. current_role_path : string
    # 4. parent_role : role object
    # 5. variable_manager : object
    # 6. loader : object
    # 7. collection_list = []
    # 1. data : dictionary or string
    # data = {'name': 'test'}
    data = {'name': 'test'}
    # 2. play : playbook object
    play = {'hosts': ['host1', 'host2']}
    # 3. current_role_path : string
    current_role_path = 'roles_path'
    # 4. parent_role : role object
   

# Generated at 2022-06-23 06:45:41.022332
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play

# Generated at 2022-06-23 06:45:52.197156
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import ROLE_CACHE
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager

    my_var_manager = VariableManager()
    ROLE_CACHE.clear()

# Generated at 2022-06-23 06:45:58.589525
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude.load('geerlingguy.docker', '', variable_manager=None, loader=None, collection_list=None)
    assert ri.name == 'geerlingguy.docker'
    assert ri.role_name == 'docker'

    ri = RoleInclude.load('geerlingguy.docker', '', variable_manager=None, loader=None, collection_list=None)
    assert ri.name == 'geerlingguy.docker'
    assert ri.role_name == 'docker'


# Generated at 2022-06-23 06:46:10.341857
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-23 06:46:22.636381
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # Load data as string
    string_data = """
    - test
    """
    ri = RoleInclude.load(string_data, None)
    assert ri.get_name() == 'test'

    # Load data as dict
    dict_data = dict(name="test",role_path="test/path")
    ri2 = RoleInclude.load(dict_data, None)
    assert ri2.get_name() == 'test'
    assert ri2.get_role_path() == 'test/path'

    # Load data as dict
    dict_data = dict(name="test",role_path="test/path")
    ri2 = RoleInclude.load(dict_data, None)
    assert ri2.get_name() == 'test'
    assert ri2.get_

# Generated at 2022-06-23 06:46:34.920051
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test for method load of class RoleInclude.
    """
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # Case 1: The parameter data is not a string type nor a dictionary type nor a AnsibleBaseYAMLObject type,
    #         we try to raise an AnsibleParserError exception.
    data = 'test_data'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    try:
        role_include = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleParserError:
        pass

# Generated at 2022-06-23 06:46:47.255853
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Simple test need to be improved with fixtures.
    # Priorities are :
    #   * avoid test side effects
    #   * test all cases
    # And in same time we try to optimize the number of dependencies.
    # so we try to init the minimal object to pass in load.

    # We create a load to init the dict of AnsibleBaseYAMLObject._yaml_loader_cls_keys
    # and we use the same loader for the test
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

# Generated at 2022-06-23 06:46:52.771977
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext as pcontext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager as tqm

    args_str = {'name': 'tom'}
    play = Play().load(dict(
        name="Ansible Play",
        hosts=['all'],
        gather_facts='no',
        tasks=[dict(action=dict(module='debug', args=args_str))]
    ), variable_manager=pcontext(), loader=tqm())
    assert not play is None
    assert isinstance(play, Play)

# Generated at 2022-06-23 06:47:04.217124
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext

    role_include = RoleInclude(play=None, role_basedir='/home', variable_manager=None, loader=None)
    role_include_ = RoleInclude(play=None, role_basedir='/home', variable_manager=None, loader=None)
    role_include_._load_role_data(False)

    context = PlayContext()
    context.remote_addr = '127.0.0.1'
    context.accelerate_ipv6 = ''
    context.network_os = ''
    context.remote_user = 'root'
    context.port = 100
    context.become = False
    context.become_method = ''
    context.become_user = ''
    context.become_ask_pass = False


# Generated at 2022-06-23 06:47:05.726896
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri


# Generated at 2022-06-23 06:47:13.496736
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a role include instance
    role_include = RoleInclude()
    # Load a string
    assert isinstance(role_include.load(name="apache"), RoleRequirement)
    # Load a dict
    assert isinstance(role_include.load({"role": "apache"}), RoleRequirement)
    # Load a AnsibleBaseYAMLObject
    assert isinstance(role_include.load(AnsibleBaseYAMLObject({"role": "apache"})), RoleRequirement)
    # Load a invalid data
    try:
        assert isinstance(role_include.load(1), RoleRequirement)
    except AnsibleParserError:
        pass
    # Load a string which contains ','

# Generated at 2022-06-23 06:47:23.192900
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    from ansible.plugins.loader import role_loader, module_loader

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = module_loader.get('file')
    rl = role_loader.get('file')

    inventory = InventoryManager(loader=loader, sources=["/home/travis/build/ansible/ansible/test/units/inventory"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    assert( isinstance(rl, role_loader.RoleFileLoader) )
    assert( isinstance(loader, module_loader.FileModuleLoader) )

    play = Play()
    playctx = PlayContext()
    play._variable_manager = variable_manager
    play._variable

# Generated at 2022-06-23 06:47:32.165871
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(path_sep='/', terse=False)

# Generated at 2022-06-23 06:47:44.439144
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test Case 1: Define a role in a namespace
    # Please note that name of the namespace is in 'namespace.name' format.
    loader = DictDataLoader({
        '/etc/ansible/roles/namespace.name/tasks/main.yml': """
            - debug: msg="Inside task main.yml"
        """,
    })
    collection_list = CollectionList()
    loader.set_basedir('/etc/ansible/roles/')
    collection_list.add(loader)

    play = Play().load({
        'name': 'test',
        'hosts': 'localhost',
        'roles': [
            'namespace.name'
        ]
    }, variable_manager=VariableManager(), loader=loader)
    play._included_files = []
    play._ad_

# Generated at 2022-06-23 06:47:49.598218
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    data = {
        'name': 'test_role',
        'scenario': 'playbook',
    }
    role_include = RoleInclude()
    role_include.load_data(data, variable_manager=variable_manager)

# Generated at 2022-06-23 06:48:00.936599
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = 'test'
    current_role_path = 'test'
    parent_role = 'test'
    variable_manager = 'test'
    loader = 'test'
    collection_list = 'test'
    data = 'test'


# Generated at 2022-06-23 06:48:08.854589
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-23 06:48:10.658919
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    RoleInclude._load_role_data(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader):
    '''
    # Not implement test.
    return True


# Generated at 2022-06-23 06:48:21.699308
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class Options(object):
        _connection = 'local'
        _shell = '/bin/sh'
        _python_interpreter = '/usr/bin/python'
    class Play(object):
        pass
    play = Play()
    ri = RoleInclude(play=play)
    assert ri._play is play
    assert ri._role_name is None
    assert ri._role_path is None
    assert ri._dep_chain is None
    assert ri._task_blocks == []
    assert ri._handler_blocks == []
    assert ri._metadata is None
    assert ri._filters is None
    assert ri._roles == []
    assert ri._role_params is None
    assert ri._default_vars is None
    assert ri._vars is None
    assert r

# Generated at 2022-06-23 06:48:23.754327
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)

# Generated at 2022-06-23 06:48:28.988152
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri



# Generated at 2022-06-23 06:48:31.053389
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:48:40.337545
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        roles=[
            dict(
                name="test_required_fields_role",
                tasks=[]
            )
        ]
    )
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'role_name': 'test_required_fields_role'}
    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list=[])
    play = Play().load(play_source, variable_manager=variable_manager, loader=None)
    tqm = None

# Generated at 2022-06-23 06:48:51.695332
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.collection import get_collection_dirs
    from ansible.module_utils.facts.system import get_system_facts
    from ansible.module_utils.facts.virtual.base import BaseFactCollector

    vault_pass = None
    vault_pass = VaultLib(None,  force_order=True).decrypt(vault_pass)

    dataloader = DataLoader()
    dataloader.set_vault_secrets([('default', vault_pass)])


# Generated at 2022-06-23 06:49:02.052753
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    play_context = dict(
        basedir='/foo/bar',
    )
    loader = None
    collection_loader = None
    variable_manager = None
    play = Play().load(dict(
        name='myplay',
        hosts='all',
        gather_facts='no',
        become='yes',
    ), loader=loader, variable_manager=variable_manager, collection_loader=collection_loader, play_context=play_context)
    role_basedir = os.path.join(play_context['basedir'], 'roles')
    RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader,
                collection_list=collection_loader)

# Generated at 2022-06-23 06:49:12.497541
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader

    # Test exception on load method
    ri = RoleInclude()
    try:
        ri.load([])
    except AnsibleParserError:
        assert True
    else:
        assert False

    # Test exception on load method
    ri = RoleInclude()
    try:
        ri.load('webservers,prod')
    except AnsibleError:
        assert True
    else:
        assert False

    # Test load method
    ri = RoleInclude()
    rd = ri.load('test', current_role_path='test/test1/test2', variable_manager=None)
    assert isinstance(rd, RoleDefinition)

    # Test load method
    ri

# Generated at 2022-06-23 06:49:22.659804
# Unit test for method load of class RoleInclude

# Generated at 2022-06-23 06:49:27.356331
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    a = RoleInclude()
    assert hasattr(a,'_delegate_to'), 'No _delegate_to'
    assert hasattr(a,'_delegate_facts'), 'No _delegate_facts'

# Generated at 2022-06-23 06:49:37.936899
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert hasattr(RoleInclude, '_load_attr')
    assert hasattr(RoleInclude, '_load_name')
    assert hasattr(RoleInclude, '_load_role')
    assert hasattr(RoleInclude, '_validate_attrs')
    assert hasattr(RoleInclude, '_load_tags')
    assert hasattr(RoleInclude, '_load_when')
    assert hasattr(RoleInclude, '_load_loop')
    assert hasattr(RoleInclude, '_load_delegate_to')
    assert hasattr(RoleInclude, '_load_delegate_facts')
    assert hasattr(RoleInclude, 'load')
    assert hasattr(RoleInclude, 'get_vars')
    assert hasattr(RoleInclude, '_get_parent_attribute')


# Generated at 2022-06-23 06:49:46.280590
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class Object(object):
        pass

    class Play():
        pass

    class VariableManager():
        pass

    class Loader():
        pass

    var_manager = VariableManager()
    play = Play()
    loader = Loader()
    role_include = RoleInclude(play, '/var/lib/awx/projects/_1__test-project/', var_manager, loader)
    assert isinstance(role_include, RoleInclude), 'role_include variable should be an instance of RoleInclude class'

# Generated at 2022-06-23 06:49:47.410982
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:49:59.646179
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test that class raises exception when invalid argument is used for parameter "data"
    try:
        RoleInclude.load(1, None, None, None, None, None)
        assert False, "RoleInclude.load() did not raise AnsibleParserError"
    except AnsibleParserError:
        pass

    # Test that class raises exception when old style role requirements are used
    try:
        RoleInclude.load('role1,role2', None, None, None, None, None)
        assert False, "RoleInclude.load() did not raise AnsibleError"
    except AnsibleError:
        pass

    # Test that class returns instance of class RoleInclude
    assert isinstance(RoleInclude.load('role', None, None, None, None, None), RoleInclude)

# Generated at 2022-06-23 06:50:05.406294
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None)
    assert(isinstance(ri, RoleInclude))
    assert(ri.role_basedir is None)
    assert(ri.play is None)
    assert(ri.variable_manager is None)
    assert(ri._loader is None)

# Generated at 2022-06-23 06:50:06.833083
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_RI = RoleInclude()
    # todo: write tests

# Generated at 2022-06-23 06:50:15.261304
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(foo="bar")
    variable_manager.options_vars = dict(ansible_role_foo="testfoo")
    variable_manager.options_vars = dict(ansible_role_bar="testbar")

    play = Play()

    role_include = RoleInclude(play=play, variable_manager=variable_manager)

    assert role_include is not None

# Generated at 2022-06-23 06:50:16.797844
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test RoleInclude.__init__()
    pass

# Generated at 2022-06-23 06:50:27.731248
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("Testing module RoleInclude with method load")
    # Test with a valid role
    data = RoleInclude.load("roles/web/tasks/main.yaml")
    assert isinstance(data, RoleInclude)
    assert data.role_path == "roles/web"
    assert data.role_name == "web"
    assert not data.role_collections
    assert data.dependencies == []
    assert data.tasks == "tasks/main.yaml"
    assert data.meta == "tasks/meta/main.yaml"
    assert data.vars == "vars/main.yaml"
    assert data.defaults == "defaults/main.yaml"
    assert data.handlers == "handlers/main.yaml"
    assert data.files == "files"
   

# Generated at 2022-06-23 06:50:38.188068
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play

    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    from ansible.vars import VariableManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.inventory.manager import InventoryManager

    from ansible.utils.display import Display

    display = Display()
    options = dict()
    options['connection'] = 'local'
    options['module_path'] = '/home/centos/ansible/ansible_module_helloworld/library'
    options['forks'] = 10
    options['timeout'] = 10
    options['remote_user'] = 'centos'
    options['ask_pass'] = False
    options['verbosity'] = 1
    options

# Generated at 2022-06-23 06:50:49.090203
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import os
    import unittest
    import sys
    
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.module_utils.six import iteritems, string_types
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.attribute import Attribute, FieldAttribute
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.module_utils._text import to_native
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-23 06:50:56.816037
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
# end of method load

    def set_parent_role(self, parent_role):
        '''
        Sets the parent role for the role include.
        '''

        self._parent_role = parent_role

    def _load_role_data(self, data, boolean_parser=Attribute.data_from_yaml):
        """
        Returns the role data from YAML/JSON strings, file names or dictionaries,
        after applying the optional role defaults and the role dependencies.
        """

        data = super(RoleInclude, self)._load_role_data(data, boolean_parser=boolean_parser)

        # Now that we have the raw data, apply defaults and merge dependencies

# Generated at 2022-06-23 06:50:57.493011
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:51:04.988229
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("test_RoleInclude")

    # test class construction
    ri = RoleInclude()
    print("- Constructor")
    assert ri.__class__.__name__ == "RoleInclude"

test_RoleInclude()

# Generated at 2022-06-23 06:51:05.575918
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:51:13.832858
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # create an instance of class RoleInclude
    role_inc = RoleInclude()

    # create an instance of class AnsibleParserError
    ansible_parse_err = AnsibleParserError("Invalid role definition: %s")

    # create a dictionary
    data = dict()

    # define variables
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    #collection_list = None
    collection_list = list()

    # test for exception
    # AnsibleParserError - Invalid role definition: %s
    try:
        role_inc.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except Exception as err:
        assert type(err) == type(ansible_parse_err)

# Generated at 2022-06-23 06:51:16.420844
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Constructor test: RoleInclude instance with default arguments
    ri = RoleInclude()
    assert ri


# Generated at 2022-06-23 06:51:19.629720
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass # TODO

# Generated at 2022-06-23 06:51:31.932571
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.module_utils.six import StringIO
    from ansible.plugins.loader import action_loader

    # Create a play
    play_name = 'test-play'
    play_hosts = ['host1']
    play_connection = 'smart'
    play_gather_facts = 'no'
    play_vars = {}
    play_file = 'test-play.yaml'

    play = Play().load(
        play_name,
        play_hosts,
        play_connection,
        play_gather_facts,
        play_vars,
        play_file,
        loader=None,
        variable_manager=None,
    )

    # Create a RoleInclude object and assert that it is not None
    role_include = RoleInclude()

# Generated at 2022-06-23 06:51:33.196916
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-23 06:51:36.514285
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:51:44.385130
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_list = [
        {'name': 'test_0', 'role': 'test_0'},
        {'name': 'test_1', 'role': {'role': 'test_1'}},
        {'name': 'test_3', 'role': {'role': 'test_3', 'tasks': ['test.yml']}},
        {'name': 'test_4', 'role': 'test_4', 'tasks': ['test.yml']},
        {'name': 'test_5', 'role': 'test_5', 'tasks': {'main': ['test.yml']}},
        {'name': 'test_6', 'role': 'test_6', 'tasks': {'main': ['test.yml']}},
    ]


# Generated at 2022-06-23 06:51:47.405802
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    try:
        RoleInclude(None)
    except TypeError:
        pass
    else:
        assert False, 'RoleInclude() did not raise TypeError'



# Generated at 2022-06-23 06:51:56.297221
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = None
    role_basedir = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    data = None
    test_cases = {
            "data is not string or dict": [None, AnsibleParserError],
            "data is string and doesn't have comma": ["my_role", RoleInclude]
            }
    for test, expected in iteritems(test_cases):
        result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)
        if isinstance(expected, type) and isinstance(result, expected):
                continue
        elif expected == result:
                continue

# Generated at 2022-06-23 06:52:05.269034
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude.load('name: foo',
                          dict(hosts='hosts',
                               remote_user='remote_user',
                               sudo='sudo',
                               sudo_user='sudo_user',
                               gather_facts='gather_facts',
                               serial='serial',
                               any_errors_fatal='any_errors_fatal',
                               become='become',
                               become_method='become_method',
                               become_user='become_user',
                               check='check',
                               diff='diff',
                               file='file',
                               force_handlers='force_handlers',
                               include='include',
                               roles='roles',
                               tasks='tasks'))
    assert ri.get_name() == 'foo'
    assert ri

# Generated at 2022-06-23 06:52:13.238228
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    var_manager = VariableManager()
    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader, sources='localhost,')
    play_context = dict(
        port=22,
        remote_user='root',
        password='123456',
        connection='ssh',
        become=False,
        become_method=None,
        become_user=None,
        become_pass=None,
        become_exe=None,
        become_flags=None,
        verbosity=5,
    )

# Generated at 2022-06-23 06:52:21.063377
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import ansible.playbook.role.definition
    import ansible.playbook.play
    import ansible.playbook.role.requirement
    ri = ansible.playbook.role.definition.RoleInclude()
    assert isinstance(ri, ansible.playbook.role.definition.RoleInclude)
    assert isinstance(ri._play, ansible.playbook.play.Play)
    assert isinstance(ri._role, ansible.playbook.role.requirement.RoleRequirement)

# Generated at 2022-06-23 06:52:31.019910
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    
    play = {
        'hosts': 'all',
        'tasks': [
            {
                'name': 'Gathering Facts',
                'setup': ''
            }
        ],
        'vars': {
            'ansible_user': 'cloud',
            'ansible_sudo_pass': 'password'
        },
        'roles': [
            'apache',
            'jenkins'
        ]
    }

    role_basedir = os.getcwd()

    loader = "loader"

    collection_list = collections.deque()
    collection_list.appendleft(loader)

    # Loading a role from a file
    role = RoleInclude.load('apache', play, role_basedir, None, None, loader, collection_list)
    print(role)

# Generated at 2022-06-23 06:52:32.348590
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:52:40.757316
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = None
    current_role_path = "../../playbooks"
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    data = None
    with pytest.raises(AnsibleParserError) as excinfo:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    # assert 'Invalid role definition: None' in str(excinfo.value)


    data = 'mysql'
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    data = 'mysql,'

# Generated at 2022-06-23 06:52:47.845591
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    loader = DataLoader()

# Generated at 2022-06-23 06:52:48.522768
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:52:58.747533
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context._task_vars = {'item': '1'}


# Generated at 2022-06-23 06:53:05.701935
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-23 06:53:07.340468
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_role = RoleInclude()
    assert test_role is not None

# Generated at 2022-06-23 06:53:17.660048
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play_context import PlayContext

    ri = RoleInclude()

    assert ri._role_name is None
    assert ri._role_path is None
    assert ri._metadata is None
    assert ri._task_include is None
    assert not ri._do_handlers
    assert not ri._do_tasks
    assert not ri._tasks
    assert not ri._default_vars
    assert not ri._dependencies
    assert not ri._handlers
    assert not ri._role_vars
    assert not ri._default_vars
    assert not ri._registered_vars

    assert not ri._play is None
    assert not ri._role_basedir is None
   

# Generated at 2022-06-23 06:53:19.157877
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude is not None

# Generated at 2022-06-23 06:53:30.643190
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.role.definition
    from ansible.playbook.role.requirement import RoleRequirement

    class FakeRequirement(RoleRequirement):
        _role_name=FieldAttribute(isa='string')
        _role_path=FieldAttribute(isa='string')

    ansible.playbook.role.definition.RoleRequirement = FakeRequirement
    ansible.playbook.role.definition.AnsibleBaseYAMLObject = str
    ri = RoleInclude.load("memcached", None, "roles/memcached/tasks/file.yml")
    assert ri._role_name == "memcached"
    assert ri._role_path == "roles/memcached"

# Generated at 2022-06-23 06:53:41.809481
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.module_utils.six import binary_type
    from ansible.playbook.play import Play
    from ansible.parsing.yaml import objects
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a new role definition using a yaml string
    role_def_yaml = """
    ---
    name: myrole
    # some metdata can go here, see the docs
    """
    role_def = RoleDefinition.load(role_def_yaml)

    # Create a new variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=DataLoader()))

# Generated at 2022-06-23 06:53:52.340351
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Constructor of RoleInclude should set role_basedir and variable_manager
    """
    play = None
    current_role_path = 'test_current_role_path'
    variable_manager = 'test_variable_manager'
    loader = 'test_loader'
    collection_list = None
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri.role_basedir == 'test_current_role_path'
    assert ri.variable_manager == 'test_variable_manager'
    assert ri.loader == 'test_loader'
    assert ri.collection_list == collection_list


# Generated at 2022-06-23 06:54:07.570612
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook.play import Play
    from ansible.playbook import role

    variable_manager = role.RoleDefinition._variable_manager
    loader = role.RoleDefinition._loader

    play_context = dict(
        port=9090,
        become_user='root',
    )

    play_source =  dict(
        name = "Ansible Play",
        hosts = '127.0.0.1',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=dict()), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-23 06:54:10.428030
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass
#     ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-23 06:54:11.015121
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:54:12.349748
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

if __name__ == "__main__":
    test_RoleInclude()

# Generated at 2022-06-23 06:54:15.315608
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test with neither a play nor a role_basedir
    ri = RoleInclude()
    assert ri._play is None
    assert ri._role_basedir is None

# Generated at 2022-06-23 06:54:24.909614
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play import Playbook
    from ansible.playbook.task import Task
    import os.path
    import tempfile

    test_playbook = Playbook()
    test_play = Play()
    test_play._playbook = test_playbook
    test_play._variable_manager = VariableManager()
    test_play.post_validate()

# Generated at 2022-06-23 06:54:26.313305
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert ri.load(data='/temp', variable_manager='/temp', loader='/temp')


# Generated at 2022-06-23 06:54:27.929967
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import ansible.playbook.role.defaults
    ri = RoleInclude()
    assert ri.role_basedir == ansible.playbook.role.defaults.ROLES_PATH

# Generated at 2022-06-23 06:54:40.237579
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=dict()), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    play = Play().load(play_source, variable_manager=None, loader=None)

    results = list(play.compile())
    play_context = PlayContext(play=play)

    print(results[0].serialize())



# Generated at 2022-06-23 06:54:47.604163
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = "play"
    current_role_path = "./"
    variable_manager = "variable_manager"
    loader = "loader"
    collection_list = "collection_list"
    role_include = RoleInclude(play, current_role_path, variable_manager, loader, collection_list)
    assert role_include.name == ''
    assert role_include.role_basedir == './'


# Generated at 2022-06-23 06:54:48.317760
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:54:50.097749
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    current_role_path = os.getcwd()+'/ansible/roles/myansible.myrole'
    ri = RoleInclude(current_role_path)