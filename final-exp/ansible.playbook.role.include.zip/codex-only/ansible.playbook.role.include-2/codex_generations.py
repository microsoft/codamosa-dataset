

# Generated at 2022-06-23 06:45:04.216555
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class DataObj:
        def __init__(self, data):
            self.data = data
    class AnsibleParserError(Exception):
        pass

    class RoleInclude(object):
        def __init__(self, play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None):
            return
        @staticmethod
        def load(data, play, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None):
            return True

    data = ['foo.bar', 'el.foo.bar', 'el.foo.bar,foo.bar']

    for d in data:
        r = RoleInclude.load(d, None, None, None, None, None, None)
        assert r


# Generated at 2022-06-23 06:45:13.839914
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    path = os.getcwd()
    play = Play()
    play._included_file = path #_included_file always assume to be the same path as 
    play._role_paths = [] #_role_paths is used to track path of role included
    play.ROLE_CACHE = dict() #ROLE_CACHE is a dictionary of role
    play.INCLUDED_FILE_CACHE = dict() #INCLUDED_FILE_CACHE is a dictionary of included file 
    ri = RoleInclude(play=play, role_basedir=path)
    assert(ri.get_path() == path)
    play.INCLUDED_FILE_CACHE[path] = ri
    assert(ri == play.INCLUDED_FILE_CACHE[path])
    
# Unit

# Generated at 2022-06-23 06:45:22.936691
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    # Create a play
    p = Play().load({'name':'test', 'hosts': 'dummy'}, variable_manager=VariableManager(), loader=DataLoader())
    # Pass an empty inventory, not required for class RoleInclude
    inv = Inventory(loader=DataLoader())
    ri = RoleInclude(p, inventory=inv)
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri.inventory, Inventory)
    assert isinstance(ri.play, Play)

# Generated at 2022-06-23 06:45:33.139122
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # _load_data should raise an error because data is a invalid role requirement
    data = 'test'
    play = object()
    current_role_path = object()
    parent_role = object()
    variable_manager = object()
    loader = object()
    collection_list = object()
    try:
        RoleInclude.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role,
                         variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    except AnsibleError:
        pass

    # _load_data should return a RoleInclude instance
    data = 'test'
    play = object()
    current_role_path = object()
    parent_role = None
    variable_manager = object()
    loader = object

# Generated at 2022-06-23 06:45:40.900898
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    r = RoleInclude()
    assert isinstance(r, RoleDefinition)
    assert isinstance(r, RoleRequirement)
    assert r._variable_manager is None
    assert r._loader is None
    assert isinstance(r.get_vars(), dict)
    assert not r._is_meta
    assert not r._is_tasks
    assert not r._is_handler
    assert not r._is_default
    assert not r._is_include

# Generated at 2022-06-23 06:45:44.985335
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ''' unit test for the role include constructor '''
    ri = RoleInclude()
    assert ri is not None
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)


# Generated at 2022-06-23 06:45:55.784527
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.variable_manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VaultSecret

    from io import StringIO

    mock_loader = DataLoader()
    mock_loader.set_vault_secrets([(VaultSecret('secret1', 'secret1', False))])

    mock_inventory = InventoryManager(loader=mock_loader, sources=StringIO('localhost'))

    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)


# Generated at 2022-06-23 06:45:57.400301
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Constructor test
    """
    role_include = RoleInclude()


# Generated at 2022-06-23 06:45:59.923521
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:46:01.690592
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include is not None

# Generated at 2022-06-23 06:46:05.979002
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class Play():
        pass
    class VariableManager():
        pass

    play = Play()
    variable_manager = VariableManager()
    ri = RoleInclude(play=play, variable_manager=variable_manager)


# Generated at 2022-06-23 06:46:15.205307
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #This is the dummy playbook we will use to test 'RoleInclude.load()'
    playbook_data = {
        'hosts': 'localhost',
        'roles':
        [
            {
                'role_1': {
                    'role_0': [{}],
                    'role_1': [{'role_0': [{}]}]
                }
            }
        ]
    }

    #We set the test configuration
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.config.manager import ConfigManager
    from ansible.config.data import ConfigData
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
   

# Generated at 2022-06-23 06:46:16.960022
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: write unit test
    pass


# Generated at 2022-06-23 06:46:17.589871
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:46:26.113179
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import collection_loader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)


# Generated at 2022-06-23 06:46:30.618431
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {
        'name': 'apache',
        'description': 'This is a description',
    }

    ri = RoleInclude()
    role_obj = ri.load_data(data)

    assert role_obj.name == "apache"
    assert role_obj.description == "This is a description"

# Generated at 2022-06-23 06:46:39.296820
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader

    ri = RoleInclude()

    ri_test_str = "test.example"
    try:
        ri.load(ri_test_str) # the test string cannot be processed
    except AnsibleError as e:
        assert str(e) == "Invalid old style role requirement: test.example"

    ri_test_dict = dict()
    try:
        ri.load(ri_test_dict) # the test dict cannot be processed
    except AnsibleParserError as e:
        assert str(e) == "Invalid role definition: {}"

    ri_test_obj = AnsibleBaseYAMLObject()

# Generated at 2022-06-23 06:46:49.389981
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os, sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from ansible_collections.ansible.community.tests.unit.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.scriptvars import ScriptVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible_collections.ansible.community.plugins.loader import add_all_plugin_dirs

# Generated at 2022-06-23 06:46:50.509746
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:46:51.713955
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, 'Test is not implemented'

# Generated at 2022-06-23 06:46:57.207278
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    req = RoleRequirement.load('name,version')
    print (req)

    req = RoleRequirement.load({'name':'jdoe', 'version':'1.0'})
    print (req)

    req = RoleRequirement.load({'name':'jdoe', 'version':'1.0', 'tags': ['test']})
    print (req)


# Generated at 2022-06-23 06:46:58.377812
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:47:10.297197
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    ut = RoleInclude()
    assert ut.play is None
    assert ut.role_basedir is None
    assert ut.variable_manager is None
    assert ut.loader is None

    ut = RoleInclude(Play())
    assert ut.play is not None
    assert ut.role_basedir is None
    assert ut.variable_manager is None
    assert ut.loader is None

    ut = RoleInclude(Play(), 'abc')
    assert ut.play is not None
    assert ut.role_basedir is not None
    assert ut.variable_manager is None
    assert ut.loader is None

    ut = RoleInclude(Play(), 'abc', 'def')
    assert ut.play is not None

# Generated at 2022-06-23 06:47:17.229233
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    my_role_path = './test_data/'
    my_role_name = 'test_role'
    my_role_path_full = my_role_path + my_role_name
    my_role = RoleInclude(role_basedir=my_role_path, role_name=my_role_name)
    assert my_role.get_path() == my_role_path_full


# Generated at 2022-06-23 06:47:22.875726
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Case 1: Without parameters
    ri = RoleInclude()
    assert ri.play is None
    assert ri.role_basedir is None
    assert ri.variable_manager is None
    assert ri.loader is None

    # Case 2: With parameters
    # Create a dummy class for testing purpose
    class DummyClass(object):
        pass
    role_basedir = "/etc"
    variable_manager = DummyClass()
    variable_manager.extra_vars = None
    variable_manager.options_vars = None
    variable_manager.get_vars = None
    variable_manager.set_options = None
    loader = DummyClass()
    loader.get_basedir = None

# Generated at 2022-06-23 06:47:34.774642
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ri = RoleInclude(play=Play(), role_basedir='', variable_manager=VariableManager(), loader=DataLoader())

    # As RoleInclude we have default value for this attributes
    assert isinstance(ri._role_name, string_types)
    assert ri._role_name == ''
    assert isinstance(ri._role_path, string_types)
    assert ri._role_path == ''

    assert isinstance(ri._compile_vars, string_types)
    assert ri._compile_vars == 'all'

    assert isinstance(ri._default_vars, dict)
    assert not ri._default_vars


# Generated at 2022-06-23 06:47:40.801673
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_object =  dict(name="testname",
         role=["role1", "role2"],
         vars={"testvar":"testvarval"},
         vars_prompt={"testvar2":"testvar2prompt"},
         vars_files=["testvar3.yml"],
         handlers=["hand1"],
         meta=["meta1"],
         tasks=["tasks1", "tasks2"],
         when="testwhen"
         )

    for (key, value) in iteritems(test_object):
        assert getattr(RoleInclude, key) == value



# Generated at 2022-06-23 06:47:43.351556
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'


# Generated at 2022-06-23 06:47:52.426589
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'pki'
    play = {}
    current_role_path = '/etc/ansible/roles/pki'
    parent_role = None
    variable_manager = {}
    loader = {}
    collection_list = {}
    if not (isinstance(data, string_types) or isinstance(data, dict) or isinstance(data, AnsibleBaseYAMLObject)):
        raise AnsibleParserError("Invalid role definition: %s" % to_native(data))
    if isinstance(data, string_types) and ',' in data:
        raise AnsibleError("Invalid old style role requirement: %s" % data)
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)


# Generated at 2022-06-23 06:47:59.699362
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Test with no argument
    role_include = RoleInclude()
    if role_include.get_role_path():
        raise Exception("Test failed")

    role_include = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    if role_include.get_role_path():
        raise Exception("Test failed")

# Generated at 2022-06-23 06:48:08.028058
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # 1) test validate role name
    data = "test,1.2.2"
    try:
        ri = RoleInclude.load(data, None)
        assert False
    except AnsibleError:
        pass

    # 2) test validate role name
    data = "test"
    try:
        ri = RoleInclude.load(data, None)
        assert True
    except AnsibleError:
        assert False

    # 3) test role version
    data = {"role": "test", "version": "1.2.3"}
    try:
        ri = RoleInclude.load(data, None)
        assert True
    except AnsibleError:
        assert False

    # 4) test invalid role version
    data = {"role": "test", "version": "1.2"}

# Generated at 2022-06-23 06:48:19.526955
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.include_role import IncludeRole
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import Playbook

# Generated at 2022-06-23 06:48:27.422397
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # AnsibleModuleTestCase's substitute for AnsibleModule.
    class FakeAnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     mutually_exclusive=None, supports_check_mode=False, required_together=None, required_one_of=None,
                     required_if=None, add_file_common_args=False):
            super(FakeAnsibleModule, self).__init__()

    # AnsibleModuleTestCase's substitute for AnsibleModule.

# Generated at 2022-06-23 06:48:38.791299
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    data = {}
    play = {}
    current_role_path = None
    parent_role = None
    variable_manager = {}
    loader = {}
    collection_list = {}
    # TODO: not sure what should be passed to PlayContext init
    pc = PlayContext()
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    try:
        ri.load(data, pc, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    except Exception as e:
        assert type(e) == AnsibleParserError

    data = 'bar' #TODO: should be dict

# Generated at 2022-06-23 06:48:40.714200
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:48:51.885891
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    s = '''
---
- name: tomcat
  hosts: webserver
  become: yes
  become_method: sudo
  become_user: root
  gather_facts: False
  pre_tasks:
    - name: upgrade os
      yum:
        name: "*"
        state: latest
  roles:
     - { role: apache, when: ansible_os_family == "RedHat" }
     - { role: tomcat, when: ansible_os_family == "Debian" }
'''
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()

# Generated at 2022-06-23 06:48:57.950163
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-23 06:49:03.137871
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test constructor of class RoleInclude
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-23 06:49:09.342675
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    with pytest.raises(AnsibleParserError) as excinfo:
        RoleInclude.load("localhost", "my_play", "role_path")
    assert 'Invalid role definition' in str(excinfo.value)
    with pytest.raises(AnsibleError) as excinfo:
        RoleInclude.load("localhost,domain", "my_play", "role_path")
    assert 'Invalid old style role requirement' in str(excinfo.value)


# Generated at 2022-06-23 06:49:10.026645
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    r = RoleInclude()



# Generated at 2022-06-23 06:49:11.704360
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri
    ri.load_data(data)
    assert ri

# Generated at 2022-06-23 06:49:14.063364
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass


# Generated at 2022-06-23 06:49:17.247520
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri is not None

# Generated at 2022-06-23 06:49:25.029863
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager.set_variable("hostvars", {"hostname": {}})
    ri = RoleInclude(play=Play().load(dict(name = 'testplay', hosts = 'all', gather_facts = 'no'), variable_manager=variable_manager, loader=None))
    assert ri is not None
    assert ri.get_name() == 'testplay'
# Test ends


# Generated at 2022-06-23 06:49:37.256814
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    Playbook_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    print("Playbook path %s" % Playbook_dir)
    play_path = os.path.join(Playbook_dir, 'test/test_playbooks/roles_test')
    print("Play path: %s" % play_path)
    Role_path = os.path.join(Playbook_dir, 'test/test_playbooks/roles_test/roles')

# Generated at 2022-06-23 06:49:39.206514
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    utils.get_configuration_definition(module_name="foo")
    assert False

# Generated at 2022-06-23 06:49:49.443765
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    variable_manager = None
    loader = None
    collection_list = None
    play = None
    current_role_path = None
    parent_role = None

    data = "team_geek"

    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
        assert False
    except Exception as e:
        if "Invalid old style role requirement" not in e.message:
            assert False
        assert True

    data = {"name": "team_geek"}

    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
        assert True
    except Exception as e:
        assert False

# Generated at 2022-06-23 06:49:50.338167
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:49:53.192839
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "."
    ri = RoleInclude()
    ri.load(data)
    assert ri.metadata.name == "."

if __name__ == "__main__":
    test_RoleInclude_load()

# Generated at 2022-06-23 06:50:00.342988
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    variable_manager = None
    loader = None # TODO
    collection_list = None
    play = None
    current_role_path = None
    parent_role = None
    role_include = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert role_include is not None

# Generated at 2022-06-23 06:50:01.780777
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:50:09.178174
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {}
    data['name'] = 'test'
    data['menu'] = 'test'
    data['options'] = 'test'

    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    obj = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert obj is not None


# Generated at 2022-06-23 06:50:17.947299
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    class DummyVariableManager:
        pass

    class DummyLoader:
        pass

    class DummyPlay:
        pass

    play = DummyPlay()
    play._variable_manager = DummyVariableManager()
    play._loader = DummyLoader()
    play._play_context = PlayContext()
    data = 'zoo'
    role_include = RoleInclude.load(data, play, 'current_role_path', None, None, None)
    assert role_include._role_name == data


# Generated at 2022-06-23 06:50:20.461934
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # load_data method has been called in load method, so just test load_data
    pass



# Generated at 2022-06-23 06:50:30.363086
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class DummyPlaybook:
        def __init__(self):
            self.vars = dict()

    class DummyRole:
        def __init__(self):
            self.tasks = dict()
            self.vars = dict()
            self.default_vars = dict()
            self.meta = dict()

    class DummyVariableManager:
        def __init__(self):
            self.extra_vars = dict()

    class DummyLoader:
        def __init__(self):
            pass

    # Create play, role and inventory objects
    dummy_play = DummyPlaybook()
    dummy_vars = dict(a=1, b=2)
    dummy_play.vars = dummy_vars

    dummy_role = RoleRequirement()
    dummy_role.name = "dummy"


# Generated at 2022-06-23 06:50:43.620075
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.template import Templar

    play = Play().load({}, variable_manager=None, loader=None)
    play.ROLE_CACHE = {'name': RoleRequirement(role='name', play=play)}
    data = "role: name"
    ri = RoleInclude(play=play, role_basedir=None, variable_manager=None, loader=None)
    x = ri.load_data(data, variable_manager=None, loader=None).get_vars()
    assert x['role_name'] == 'name'
    assert ri.name == 'name'
    assert ri.role_name == 'name'
    assert ri.role_path == 'name'
    assert ri.role_path == ri.basedir


# Generated at 2022-06-23 06:50:50.112026
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.variable_manager import VariableManager
    from ansible.vars.manager import VarsModule

    play = dict()
    play["hosts"] = 'all'
    play["remote_user"] = 'root'
    play["name"] = "test_role_include_load"
    play["gather_facts"] = 'no'

    current_role_path = "/home/ansible/roles"
    parent_role = None

    loader = None

    variable_manager = VariableManager()
    variable_manager.set_vars_modul

# Generated at 2022-06-23 06:50:59.806409
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    try:
        ri.load(None, None)
    except AnsibleParserError as e:
        assert len(e.args) == 1
        assert e.args[0] == 'Invalid role definition: None'
    except:
        assert False

    try:
        ri.load('a', None)
    except AnsibleParserError as e:
        assert len(e.args) == 1
        assert e.args[0] == 'Invalid role definition: a'
    except:
        assert False

    try:
        ri.load(1, None)
    except AnsibleParserError as e:
        assert len(e.args) == 1
        assert e.args[0] == 'Invalid role definition: 1'
    except:
        assert False


# Generated at 2022-06-23 06:51:05.522504
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.playbook.play import Play
    from ansible.playbook.role.attribute import FieldAttribute
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.constructor import AnsibleConstructor

# Generated at 2022-06-23 06:51:13.759745
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import unittest
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    class TestRoleDefinition(unittest.TestCase):
        def test_load(self):
            data = AnsibleUnsafeText(u'gce')
            role_basedir = AnsibleUnsafeText(u'gce')
            variable_manager = AnsibleUnsafeText(u'gce')
            loader = AnsibleUnsafeText(u'gce')
            collection_list = AnsibleUnsafeText(u'gce')
            ri = RoleInclude(play=None, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-23 06:51:14.212944
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:51:14.841499
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-23 06:51:23.127318
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import yaml
    from ansible.playbook.play_context import PlayContext

    data = yaml.load("""
   - name: test
     become: yes
     become_user: root
     become_method: sudo
     """)[0]

    assert data == {'become': True,
                    'become_method': 'sudo',
                    'become_user': 'root',
                    'name': 'test',
                    }
    # end of data for test

    assert isinstance(data, dict)

    play_context = PlayContext(become=False)

    # TODO: create 'null loader' and test it as well
    assert isinstance(loader, object)

    ri = RoleInclude()

    # TODO: set loader and variable_manager to ri
    ri.variable_manager = object


# Generated at 2022-06-23 06:51:32.493297
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib

    class TestLoader(object):
        pass

    play = Play().load({'hosts': 'host1',
                        'gather_facts': 'yes',
                        'roles': [{'role': 'test'}]},
                       variable_manager=VariableManager(), loader=TestLoader())
    role = RoleInclude(play=play, role_basedir=os.path.dirname(__file__) + "/../../examples/ansible-example-playbook/roles",
                       variable_manager=VariableManager(), loader=TestLoader())
    assert role

# Generated at 2022-06-23 06:51:41.285842
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.variable_manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.config.manager import ConfigManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    loader = action_loader
    vault_secrets_file = os.path.join(os.path.dirname(__file__), 'vault.yml')

# Generated at 2022-06-23 06:51:52.612469
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    #import ansible.playbook.play
    from ansible.playbook.play import Play
    from ansible.playbook.connection_info import ConnectionInformation

    #import ansible.inventory.manager
    from ansible.inventory.manager import InventoryManager

    #import ansible.variables.manager
    from ansible.variables.manager import VariableManager

    #import ansible.parsing.dataloader
    from ansible.parsing.dataloader import DataLoader

    #import ansible.constants
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE

    #import ansible.cli.playbook
    from ansible.cli.playbook import PlaybookCLI

    class Options(object):
        listtags    = False
        listtasks   = False

# Generated at 2022-06-23 06:51:53.621529
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:52:04.266451
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    ri = RoleInclude()

    assert ri._templar is not None
    assert ri._loader is not None

    assert isinstance(ri, RoleDefinition)
    assert not isinstance(ri, RoleRequirement)

    assert isinstance(ri._role_path, string_types)
    assert isinstance(ri._role_name, string_types)
    assert ri._role_name == ""
    assert isinstance(ri._role_params, dict)
    assert isinstance(ri._tasks, list)
    assert isinstance(ri._handlers, list)
    assert isinstance(ri._default_vars, dict)
    assert isinstance(ri._dependencies, list)
   

# Generated at 2022-06-23 06:52:09.402790
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    current_role_path = "."
    play = "test"
    variable_manager = "test"
    loader = "test"
    collection_list = "test"
    data = "test"
    RoleInclude(current_role_path, play, variable_manager, loader, collection_list)

# Generated at 2022-06-23 06:52:10.336576
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:52:17.556055
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Test method load of class RoleInclude"""

    # Test without parameters
    with pytest.raises(AnsibleParserError):
        RoleInclude.load(data=None, play=None, current_role_path=None, parent_role=None, variable_manager=None,
                            loader=None, collection_list=None)

    # Test with string types
    role_path = "/path/to/role"
    role_name = "role_name"
    role_include_string_type = role_name
    assert isinstance(role_include_string_type, string_types)

    # Test with dictionary
    role_include_dict = {"role": role_name}
    assert isinstance(role_include_dict, dict)

    # Test with AnsibleBaseYAMLObject
    role_include_yaml_

# Generated at 2022-06-23 06:52:18.673879
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    results = dict(
    )
    return results

# Generated at 2022-06-23 06:52:22.061515
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri != None

    return ri

if __name__ == '__main__':

    roleinclude = test_RoleInclude()
    print(roleinclude)

# Generated at 2022-06-23 06:52:31.001887
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar


# Generated at 2022-06-23 06:52:40.498733
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import json
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.role import role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler import Handler
    from ansible.playbook.task.include import IncludeTask
    from ansible.playbook.task.include_role import IncludeRole
    from ansible.config.manager import ConfigManager

    ansible_path = os.environ['HOME'] + '/.ansible'

# Generated at 2022-06-23 06:52:52.058326
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # check that strings and dictionaries are accepted
    data1 = "role1"
    data2 = {
        'name': 'role2'
    }
    # try to create an object with wrong data
    data3 = ["role3"]
    # test method load
    # check that load method works for string and dictionary data
    ri = RoleInclude()
    ri.load(data1, None)
    ri.load(data2, None)
    # check that exception is raised for wrong data format
    failed = False
    try:
        ri.load(data3, None)
    except Exception:
        failed = True
    assert failed

# Generated at 2022-06-23 06:53:00.905427
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # create a RoleInclude object and convert it to string
    ri = RoleInclude()
    str(ri)
    # creating a RoleInclude object with some properties
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    # change each property and again convert it to string
    ri.local_action = 'test'
    str(ri)
    ri.local_action = False
    str(ri)
    ri.register = 'test'
    str(ri)
    ri.register = 'result'
    str(ri)
    ri.task_tags = 'test'
    str(ri)
    ri.run_once = 'test'
    str(ri)

# Generated at 2022-06-23 06:53:07.063239
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    host_list = [{
        "hostname": "127.0.0.1",
        "ip": "127.0.0.1",
        "port": 22,
        "username": "root",
        "password": "",
        "private_key_file": os.environ['HOME'] + "/.ssh/id_rsa",
    }]
    inventory = InventoryManager(loader=loader, sources=None, hosts=host_list)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-23 06:53:13.597013
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {'name': {'test': '1'}}
    try:
        RoleInclude.load(data)
    except AnsibleError as e:
        if str(e) == 'Invalid role definition: {\'name\': {\'test\': \'1\'}}':
            print("test success")
    else:
        print("test fail")


# Generated at 2022-06-23 06:53:14.287074
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:53:16.498008
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Initialize the class with and without play.
    ri = RoleInclude()
    ri = RoleInclude(play=True)
    
if __name__ == "__main__":
    test_RoleInclude()

# Generated at 2022-06-23 06:53:29.405484
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.plugin_docs import read_docstring

    class MockVariableManager():

        def __init__(self):
            pass

    class MockLoader():

        def __init__(self):
            pass

    class MockPlaybook():

        def __init__(self):
            self.variable_manager = MockVariableManager()
            self.loader = MockLoader()
            self.FILTERS = {}

        def _role_is_meta(self, role):
            if role == 'meta':
                return True
            else:
                return False

        def get_variable_manager(self):
            return self.variable_manager


# Generated at 2022-06-23 06:53:36.538006
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.cli import CLI
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_bytes
    import os

    class Options(object):
        def __init__(self):
            self.syntax = False
            self.connection = 'local'
            self.module_path = None
            self.forks = 5
            self.remote_user = 'root'
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.sc

# Generated at 2022-06-23 06:53:49.202271
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    fake_data = {
            'role': 'common',
            'tasks': {
                'first.yml': '',
                'second.yml': '',
            },
            'handlers': {
                'first.yml': '',
                'second.yml': '',
            },
           }
    play = {}
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude.load(fake_data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    
    assert(isinstance(ri, RoleInclude))
    assert(hasattr(ri, '_role_name') is True)

# Generated at 2022-06-23 06:53:50.674848
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Constructor test for class RoleInclude
    :return:
    """
    role_include = RoleInclude(None)
    assert isinstance(role_include, RoleInclude)

# Generated at 2022-06-23 06:53:51.225029
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:54:01.257658
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.legacy.core import LegacyRoleDefinition

    # Test with string parameter
    try:
        RoleInclude.load(data='my_string', play=Play(), current_role_path=None, parent_role=None)
    except AnsibleParserError:
        pass  # This is the current behavior of the class
    # Test with dictionary parameter
    try:
        RoleInclude.load(data={'name': 'my_name'}, play=Play(), current_role_path=None, parent_role=None)
    except AnsibleParserError:
        pass  # This is the current behavior of the class

    # Test with dictionary parameter with oldstyle key

# Generated at 2022-06-23 06:54:03.231433
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    role_include.load_data({})

# Generated at 2022-06-23 06:54:13.963967
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    myroleinclude = RoleInclude()
    data = {}
    play = None
    current_role_path = "/some/path"
    parent_role = None
    variable_manager = None
    loader = None
    assert myroleinclude.load(data, play, current_role_path, parent_role, variable_manager, loader)

    data = "test"
    assert myroleinclude.load(data, play, current_role_path, parent_role, variable_manager, loader)

    data = "test"
    myroleinclude = RoleInclude()
    parent_role = "test"
    assert myroleinclude.load(data, play, current_role_path, parent_role, variable_manager, loader)

    data = "test"
    myroleinclude = RoleInclude()
    parent_role = "test"
   

# Generated at 2022-06-23 06:54:15.754065
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:54:24.042192
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ''' test_roleinclude.py: Test the constructor of RoleInclude '''

    # create an object of RoleInclude
    ri = RoleInclude()

    # test the constructor of RoleInclude
    args = (1, 1, 1, 1)
    if ri.play is not None:
        assert ri.play is args[0]
    if ri.role_basedir is not None:
        assert ri.role_basedir is args[1]
    if ri.variable_manager is not None:
        assert ri.variable_manager is args[2]
    if ri.loader is not None:
        assert ri.loader is args[3]

# Generated at 2022-06-23 06:54:36.565341
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.collections.ansible.community.plugins.module_utils.facts import ansible_collection_mapper
    from ansible.module_utils.facts import is_collection_installed, get_all_collections
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    import ansible.playbook.block as block
    import unittest

    class TestRoleInclude(unittest.TestCase):

        def setUp(self):
            self.loader = DataLoader()

            # Load the collection paths from a config file
            current_directory = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-23 06:54:37.647561
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert role is not None

# Generated at 2022-06-23 06:54:38.496812
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # TODO: Implement
    pass

# Generated at 2022-06-23 06:54:40.557907
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_inc = RoleInclude.load({"role": "role1"}, "play", "current_role_path", "variable_manager", "loader", "collection_list")



# Generated at 2022-06-23 06:54:43.629210
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    a = RoleInclude()
    assert a is not None
    assert isinstance(a, RoleInclude)

# Generated at 2022-06-23 06:54:44.295085
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:54:52.605507
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.constants import DEFAULT_DEBUG
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import action_loader, cache_loader, callback_loader, connection_loader, lookup_loader, module_loader, shell_loader, strategy_loader, test_loader, vars_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader         = AnsibleLoader(None, 'yaml', False)
    module_loader  = module_loader
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts({})
    variable_manager.set_inventory(Inventory(loader=loader, sources=[], vault_password=None))
    variable