

# Generated at 2022-06-23 06:44:56.641525
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Initialize the variables
    play = ""
    role_basedir = ""
    variable_manager = ""
    loader = ""

    # Create object for RoleInclude class
    obj = RoleInclude()

    # Check if object is properly created
    assert obj is not None, "Object not initialized properly"


# Generated at 2022-06-23 06:45:07.454664
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test loading dict
    this_dict = {
            'role': 'test_role',
            'delegate_to': '127.0.0.1'
    }
    ri = RoleInclude()
    res = ri.load_data(this_dict)
    assert res is not None
    assert ri.role == 'test_role'
    assert ri.name == 'test_role'
    assert ri.delegate_to == '127.0.0.1'

    # test loading string
    ri = RoleInclude()
    res = ri.load_data("delegate_to=127.0.0.1")
    assert res is not None
    assert ri.role == ''
    assert ri.name == ''

# Generated at 2022-06-23 06:45:12.540433
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=None, options=None)
    variable_manager.options_vars = load_options_vars(loader=None, options=None)

    data = RoleRequirement.load(data='Common', role_basedir='/data/ansible/roles', variable_manager=variable_manager, loader=None)
    assert type(data) == RoleRequireme

# Generated at 2022-06-23 06:45:18.088715
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import RoleRequirement
    import os
    import pytest

    my_play = Play()
    my_loader = None
    my_role = RoleRequirement('rolename')
    ri = RoleInclude.load(my_role, my_play, None, None, None, my_loader, None)
    assert isinstance(ri,RoleInclude)

    # Check if exception is generated when invalid class type is passed in
    with pytest.raises(AnsibleParserError) as excinfo:
        ri = RoleInclude.load(my_role, my_play, None, None, None, None, None)
    assert "Invalid role definition" in str(excinfo.value)

    # Check if exception is generated when improper definition is passed in


# Generated at 2022-06-23 06:45:25.110533
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    current_role_path = '/path/to/roles'
    data = 'myrole'
    play = {'name': 'play1'}
    variable_manager = {'host_vars':{}, 'group_vars':{}}
    loader = {}
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader)
    ri.load_data(data, variable_manager=variable_manager, loader=loader)
    assert ri.get_name() == 'myrole'

# Generated at 2022-06-23 06:45:25.728997
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:45:26.339798
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:45:26.950813
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:45:33.167411
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    ri.__init__(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-23 06:45:41.106757
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    # Create the play
    play = Play()
    # Create the inventory
    inventory = Inventory("/tmp/test_hosts")
    # Create a loader
    loader = DataLoader()
    # Create a variable manager
    variable_manager = VariableManager()
    vars_dirs = [
        "/etc/ansible/group_vars",
        "/etc/ansible/host_vars",
    ]
    # Load inventory

# Generated at 2022-06-23 06:45:52.284500
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = '''
    - hosts: localhost
      tasks:
        - name: test ansible variable
          shell: echo {{ ansible_shell_type }}
          register: shell_type
        - debug: var=shell_type.stdout_lines
        - name: run locally
          command: echo hello
    '''

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.facts import Facts

    loader = DataLoader()

# Generated at 2022-06-23 06:45:53.990121
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri == {}
    

# Generated at 2022-06-23 06:46:02.355696
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    mock_variable_manager = VariableManager()
    mock_loader = DataLoader()
    mock_inventory = InventoryManager(loader=loader, sources=['localhost, '])
    play_context = PlayContext(become_method='sudo')

# Generated at 2022-06-23 06:46:04.636823
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:46:08.249060
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    RoleInclude: load
    """
    module = AnsibleModule(
        argument_spec = dict()
    )

    results = dict(
        original_message='foo',
        message='bar'
    )

    module.exit_json(**results)


# Generated at 2022-06-23 06:46:10.506675
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    a = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert a

# Generated at 2022-06-23 06:46:22.792912
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print('\nTest RoleInclude:')
    test_dict = {'hosts': 'localhost', 'vars': {'var1': 'Hello'}, 'tasks': [{'name': 'test_name', 'debug': 'msg={{var1}}'}]}
    test_loader = loader
    test_vm = variable_manager.VariableManager()
    test_play = Play().load(test_dict, loader=test_loader, variable_manager=test_vm)
    # test RoleInclude.__init__
    test_include = RoleInclude(play=test_play, role_basedir='~/roles')
    # test RoleInclude.load

# Generated at 2022-06-23 06:46:35.052134
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.yaml.data import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    p = Play()
    p.load(dict(
        name = 'foo',
        hosts = 'all',
        gather_facts = 'no',
        roles = ['somerole']
    ))

    fake_role_1 = p.get_roles()[0]
    assert fake_role_1.get_name() == 'somerole'
    assert fake_role_1.get_path() is None
    assert isinstance(fake_role_1, RoleInclude)
    assert fake_role

# Generated at 2022-06-23 06:46:36.391211
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    pass


# Generated at 2022-06-23 06:46:48.357911
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Instanciate data
    data = dict()
    data['name'] = 'testname'
    data['tasks'] = 'testtasks'
    data['handlers'] = 'testhandlers'
    data['vars'] = dict()
    data['vars']['testvars'] = 'testvars'
    data['pre_tasks'] = []
    data['post_tasks'] = []
    data['meta'] = dict()
    data['meta']['anything'] = dict()
    data['meta']['anything']['can'] = dict()
    data['meta']['anything']['can']['go'] = 'here'

    # Instanciate current_role_path
    current_role_path = '/path/to/current/role'

    # Instanciate play

# Generated at 2022-06-23 06:46:49.437593
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Constructor of the RoleInclude class.

    :return:
    """
    RoleInclude()

# Generated at 2022-06-23 06:47:01.458869
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    test_playbook = """
- hosts: all
  roles:
    - role_one
    - { role: role_two }
    - { role: role_three, delegation_facts: True }
    - { role: role_four, delegate_to: "localhost" }
    - { role: role_five, delegate_to: "192.168.1.1" }
    """
    data = Play.load(test_playbook, variable_manager=VariableManager(), loader=DataLoader()).data

# Generated at 2022-06-23 06:47:07.477794
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    loader = None
    variable_manager = None
    path = os.getcwd()
    collection_list = ""
    play = None
    role_basedir = path + "tests/data/roles/test_role"
    role_inclusion = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert role_inclusion is not None

# Generated at 2022-06-23 06:47:10.247562
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # test constructor of class RoleInclude
    ri = RoleInclude()
    assert ri == {}

# Generated at 2022-06-23 06:47:14.075241
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    variable_manager = 'abc'
    loader = 'xyz'
    r = RoleInclude(variable_manager=variable_manager, loader=loader)
    assert r._variable_manager == variable_manager
    assert r._loader == loader

# Generated at 2022-06-23 06:47:15.895768
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert (type(ri) is RoleInclude)

# Generated at 2022-06-23 06:47:24.955041
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-23 06:47:26.942526
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-23 06:47:34.537063
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
     Test load function of RoleInclude class.
     Test edge cases and normal case.
    """
    import sys
    if sys.version_info >= (3,):
        import unittest
        # Unit test for method load of class RoleInclude
        class load_test(unittest.TestCase):
            def setUp(self):
                print("\nIn method", self._testMethodName)

            def test_load_string(self):
                """
                Test for string type
                """
                try:
                    RoleInclude.load('valid_string', None)
                except Exception as err:
                    self.fail("load failed with unexpected error: " + str(err))

            def test_load_dict(self):
                """
                Test for dict type
                """

# Generated at 2022-06-23 06:47:45.854110
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.plugins.loader import find_roles
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    role_paths = ['../test/roles/role_1', '../test/roles/role_2']
    find_roles(role_paths, loader=DataLoader())

    variable_manager = VariableManager()
    context = PlayContext()
    context.variable_manager = variable_manager
    play = Play()
    play._variable_manager = variable_manager
    play._context = context
    load_data = dict()
    load_data['name']='role_1'

# Generated at 2022-06-23 06:47:49.120605
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude.load(
        data="test_role",
        play=None,
        current_role_path=None,
        parent_role=None,
        variable_manager=None,
        loader=None
    )

# Generated at 2022-06-23 06:47:51.006940
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleDefinition = RoleInclude()
    assert roleDefinition
    assert roleDefinition.__class__ == RoleInclude

# Generated at 2022-06-23 06:47:56.333317
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    Unit test for method load of class RoleInclude
    '''

    data = '''
    - role1
    - role2
    '''

    # test with illegal data
    RoleInclude.load('', None)

    # test with illegal data
    RoleInclude.load(['role1,role2'], None)

    # test with illegal data
    RoleInclude.load({}, None)

    # test with legal data
    RoleInclude.load(data, None)

# Generated at 2022-06-23 06:48:05.091202
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class Test1(object):
        pass

    class AnsibleBaseYAMLObject1(object):
        pass

    assert RoleInclude.load("role1",Test1()) == None
    assert RoleInclude.load({"role1":"task1"},Test1()) == None
    assert RoleInclude.load(AnsibleBaseYAMLObject1(),Test1()) == None
    try:
        RoleInclude.load(object(),Test1())
    except Exception as e:
        assert "Invalid role definition" in str(e)
    try:
        RoleInclude.load("role1,role2",Test1())
    except Exception as e:
        assert "Invalid old style role requirement:" in str(e)


# Generated at 2022-06-23 06:48:06.419035
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.loader is None
    assert not ri.get_actions()

# Generated at 2022-06-23 06:48:19.108269
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition
    
    ansible_loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({}, variable_manager, DataLoader())
    
    # Test with a string value
    role_data = 'test_role'
    role_obj = RoleInclude.load(
        role_data, play, current_role_path=None, parent_role=None,
        variable_manager=variable_manager, loader=ansible_loader
    )
    assert isinstance(role_obj, RoleRequirement)


# Generated at 2022-06-23 06:48:19.937817
# Unit test for constructor of class RoleInclude

# Generated at 2022-06-23 06:48:25.675133
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
	from ansible.playbook.play_context import PlayContext

	pc = PlayContext()
	Play.set_defaults(pc)

	variable_manager=None
	loader=None

	collection_list=None

	rif = RoleInclude(pc, "/home/myrole", variable_manager, loader, collection_list)
	assert isinstance(rif, RoleInclude)

	data="test"
	rif = RoleInclude.load(data, pc, "/home/myrole2", None, variable_manager, loader, collection_list)

# Generated at 2022-06-23 06:48:38.613644
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    play = Play()
    play._variable_manager = VariableManager()
    play.hostvars = dict()
    play.vars = dict()
    loader = DataLoader()
    current_role_path = "."
    parent_role = RoleDefinition(play=play,
                                 role_basedir=current_role_path,
                                 variable_manager=play._variable_manager,
                                 loader=loader)
    variable_manager = VariableManager()

    # Case1: Test variable is AnsibleBaseYAMLObject
    data = AnsibleBaseYAMLObject()

# Generated at 2022-06-23 06:48:41.796255
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext

    roleInclude = RoleInclude()
    roleInclude.__init__(PlayContext(), '', None, None, None)

# Generated at 2022-06-23 06:48:52.511607
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import sys
    import json
    import unittest

    from six import StringIO

    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser

    from ansible.plugins.callback import CallbackModule


# Generated at 2022-06-23 06:48:58.462107
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts import Facts

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    loader = AnsibleLoader(None, vault_password_files=["~/.vault_pass.txt"])
    my_vars = dict()
    my_vars['vault_p'] = 'fakePassword'
    vault_passwords = {'vault_password_file': './test/ansible_test_vault_pass.txt', 'vault_password': my_vars['vault_p']}

# Generated at 2022-06-23 06:48:59.490471
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:49:10.304305
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader

    #
    # When RoleInclude is instantiated, it calls super class RoleDefinition, which calls
    # RoleDefinition._load_default_vars. This causes an error as the YAML file test_role_include/vars/main.yml
    # does not exist
    #
    # We have to do some patching here, to fake the existence of the file
    #
    import tempfile
    import shutil
    TEST_ROLE_INCLUDE_DIR = tempfile.mkdtemp()
    os.mkdir(os.path.join(TEST_ROLE_INCLUDE_DIR, "vars"))

# Generated at 2022-06-23 06:49:16.835352
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    variable_manager = VariableManager()
    variable_manager.set_host_variable('127.0.0.1', 'host_name', '127.0.0.1')
    load_options = dict(
        connection='ssh',
        module_path='/home/michael/git/ansible/modules',
        forks=10,
        become=True,
        become_method='sudo',
        become_user='root',
        check=False,
        diff=False,
        listhosts=None,
        listtasks=None,
        listtags=None,
        syntax=None,
        vault_password_file=None,
        host_key_checking=False,
        private_key_file=None,
        remote_user='ansible',
        timeout=10,
    )
    loader = DataLoader()

# Generated at 2022-06-23 06:49:26.879417
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['localhost,']))
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'hostvars': {'localhost': {}}}
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    play_context.CLIARGS = {}
    play_context.CLIARGS['syntax'] = 'json'

# Generated at 2022-06-23 06:49:37.587578
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import loader as plugin_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    ds = plugin_loader.get("lookup", "file")
    pc = PlayContext()
    pc.variable_manager.extra_vars = {"foo": "bar"}
    pc.variable_manager.options_vars = []
    pc.variable_manager.options_vars.append("vars")
    pc.options_vars = ["vars"]
    pc.global_vars = {"global_foo": "global_bar"}

# Generated at 2022-06-23 06:49:48.710030
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.loader import AnsibleLoader

    # load playbook.yml with name "include"
    data = AnsibleLoader(None, None, None, None).load_from_file("test/playbooks/roles/include/playbook.yml")
    play = Play.load(data, None)
    for r in play.get_roles():
        # Check class RoleDefinition
        if isinstance(r, RoleDefinition):
            # Check method load
            assert(isinstance(RoleInclude.load(r.get_name(), play), RoleInclude))
            # Load playbook.yml with name "include" (with ./)

# Generated at 2022-06-23 06:49:57.124389
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import pprint
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
    myinven = os.path.join(current_dir, "../../../../../examples/ansible_hosts")
    stats = namedtuple('stats', ['host'])

    loader, variable_manager, inventory = TaskQueueManager.load

# Generated at 2022-06-23 06:49:58.775591
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()

# Load method of RoleInclude class
if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:50:07.972671
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    inventory = Inventory(variable_manager)
    ri = RoleInclude(variable_manager=variable_manager)

    assert ri.basedir is None
    assert ri.play is None
    assert ri.tags == set()
    assert ri.when is None
    assert ri._metadata is None
    assert ri._dep_chain is None
    assert ri.ignore_errors is False
    assert ri.allow_duplicates is False
    assert ri.roles == []

# Generated at 2022-06-23 06:50:11.017792
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''
    Unit test to check constructor of class RoleInclude
    '''

    obj = RoleInclude()
    assert obj._play == None
    assert obj._role_basedir == None
    assert obj._variable_manager == None
    assert obj._loader == None
    assert obj._collection_list == None
    assert obj._role_name == None

# Generated at 2022-06-23 06:50:12.576167
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    This is testing method in class RoleInclude
    '''
    pass

# Generated at 2022-06-23 06:50:22.047315
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test role with yaml format
    data = '''
- role: my_role
  vars:
    ansible_connection: local
    ansible_python_interpreter: python3
    ansible_python_interpreter: python3.6
'''
    def return_data(url):
        return data
    loader = MockLoader(return_data)
    ri = RoleInclude.load(data, None, None, None, None, loader)
    assert(ri.get_vars() == {'ansible_python_interpreter': 'python3.6'})
    # Test role with string format
    data = 'my_role'
    ri = RoleInclude.load(data, None, None, None, None, loader)
    assert(ri.get_name() == 'my_role')


# Generated at 2022-06-23 06:50:31.210665
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    p = Play().load({
        'name' : 'test play',
        'roles' : [
            'role1',
            {'role': 'role2', 'someoption': 'somevalue'},
            {'role': 'role3', 'tasks': [
                {'action': {'module':'do_something', 'args': {'foo': 'bar'}}}
            ]}
        ]
    }, loader=None)

    pb = p.get_blocks()
    assert len(pb) == 3
    assert isinstance(pb[0], RoleInclude)
    assert isinstance(pb[1], RoleInclude)
    assert isinstance(pb[2], Block)

# Generated at 2022-06-23 06:50:32.472483
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:50:35.885692
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri

# Generated at 2022-06-23 06:50:37.913528
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    if __name__ == '__main__':
        import doctest
        doctest.testmod()

# Generated at 2022-06-23 06:50:48.918175
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play.load(play_source, variable_manager=VariableManager(), loader=DataLoader())
    role_include = RoleInclude(play=play)
    assert role_include._play is play
    assert not role_include._role_basedir

# Generated at 2022-06-23 06:50:52.072247
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {"include": "../another"}
    play = dict()
    current_role_path = ""
    parent_role = ""
    variable_manager = ""
    loader = ""
    collection_list = ""
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ri is not None

# Generated at 2022-06-23 06:50:55.282678
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(collection_list=["base", "more", "collections"])
    assert ri.collection_list == ["base", "more", "collections"]

# Generated at 2022-06-23 06:51:00.691102
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    loader = 'loader'
    data = {'name':'test_role'}

    ri = RoleInclude(loader=loader)
    ri._load_data(data,loader=loader)

    assert ri._role_name == 'test_role'
    assert ri._loader == loader

# Generated at 2022-06-23 06:51:10.249647
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.tests.test_utils.mock import patch

    play = Play()
    role = RoleInclude(play=play)

    with patch('ansible.playbook.role.include.RoleDefinition.load') as mocked_load:
        role.load('dummy', play)
        assert mock_load.called

    ##################################################
    # test normal roles

    data = AnsibleUnicode('role1')


# Generated at 2022-06-23 06:51:17.531336
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class Object(object):
        pass
    play             = Object()
    variable_manager = Object()
    loader           = Object()

    role_info = RoleInclude(
        play=play,
        variable_manager=variable_manager,
        loader=loader
    )
    assert role_info.name is None
    assert role_info.play is play
    assert role_info.variable_manager is variable_manager

# Generated at 2022-06-23 06:51:18.916402
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include.role_basedir is None
    assert role_include.loader is None
    assert role_include.variable_manager is None

# Generated at 2022-06-23 06:51:31.760553
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play

    variable_manager = None
    loader = None
    current_role_path = '../test/test/test'
    play = Play().load(dict(name = 'test',
                            hosts = 'all',
                            gather_facts = 'no',
                            connection = 'local',
                            roles = [dict(role_name = 'test_role_name',
                                          role_path = '../test/test/test/roles',
                                          role_hosts = 'all'
                                         )
                                    ]
                            ), variable_manager=variable_manager, loader=loader)

    assert play is not None
    assert play._variable_manager == variable_manager
    assert play._loader == loader
    assert play.hosts == 'all'

# Generated at 2022-06-23 06:51:34.592296
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert RoleInclude


# Generated at 2022-06-23 06:51:42.519166
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #
    # Setup
    #
    data = {
        'name': 'my-role',
        'description': 'This is my new role'
    }
    parent_role = True
    variable_manager = True
    loader = True
    play = True
    current_role_path = True
    collection_list = True

    #
    # Exercise
    #
    role_include = RoleInclude.load(
        data,
        play,
        current_role_path,
        parent_role,
        variable_manager,
        loader,
        collection_list
    )

    #
    # Verify
    #
    assert role_include.get_name() == 'my-role'
    assert role_include.get_description() == 'This is my new role'


# Generated at 2022-06-23 06:51:43.135400
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:51:54.411230
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:52:03.076742
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    data = 'bkj'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ansible_error = None
    try:
        ri.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleError as err:
        ansible_error = err
    print(ansible_error)


if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-23 06:52:03.669330
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:52:07.173034
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = RoleInclude()
    assert play is not None

# test_RoleInclude_load_old_style_role_requirement

# Generated at 2022-06-23 06:52:15.206004
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Instance of class RoleInclude
    ri = RoleInclude()

    # Test string type
    load_invalid_string = ri.load("invalid string", None, None, None, None, None)
    if isinstance(load_invalid_string, string_types):
        assert load_invalid_string == "Invalid role definition: '%s'" % "invalid string"

    load_string = ri.load("test_string", None, None, None, None, None)
    if isinstance(load_string, string_types):
        assert load_string == "Invalid role definition: '%s'" % "test_string"

    # Test dict type
    d = dict()
    load_dict = ri.load(d, None, None, None, None, None)

# Generated at 2022-06-23 06:52:16.542409
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ''' constructor test'''
    RoleInclude()

# Generated at 2022-06-23 06:52:17.638083
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    p=RoleInclude()
    print(p)

# Generated at 2022-06-23 06:52:28.632207
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.collection.manager import CollectionsManager
    class Ansible:
        class Options:
            default_vars = False
            inventory = None
        class Context:
            def __init__(self):
                self.CLIARGS = None
                self.variables = None
        options = Options()
        context = Context()
    ansible_mock = Ansible
    ansible_mock.context.CLIARGS = Mock()
    ansible_mock.options.inventory = InventoryManager(loader=None, sources='localhost,')

# Generated at 2022-06-23 06:52:30.298300
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, "RoleInclude.load() is untested"

# Generated at 2022-06-23 06:52:38.458839
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Testing load function with different parameters"""

    # 1) testing load function with string_type parameter
    data = 'webserver'
    ri = RoleInclude()
    result = ri.load(data, None)
    assert result.get_name() == 'webserver', "test_RoleInclude_load 1 failed"

    # 2) testing load function with dict parameter
    data = {"role": "apache"}
    result = ri.load(data, None)
    assert result.get_name() == 'apache', "test_RoleInclude_load 2 failed"

# Generated at 2022-06-23 06:52:39.350293
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    print(ri)

# Generated at 2022-06-23 06:52:41.266650
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert RoleInclude.load('role_name', None)



# Generated at 2022-06-23 06:52:54.908743
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.task import Task

    ri = RoleInclude()

    # Test with string
    data = "apache"
    assert ri.load(data, variable_manager=None, loader=None) == (None, None, True)
    assert ri.name == "apache"
    assert ri.filename == "apache"

    # Test with dictionary
    data = {'role': 'apache'}
    assert ri.load(data, variable_manager=None, loader=None) == (None, None, True)
    assert ri.name == "apache"
    assert ri.filename == "apache"

    # Test with dictionary containing tags

# Generated at 2022-06-23 06:52:55.391839
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:52:56.168958
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:53:07.865074
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test case: data is a string and ',' is not in the data 
    ri = RoleInclude()
    data = 'role2'
    play = {'vars': {'var1': 'value 1'}}
    current_role_path = '/home/cmoulliard/work/github/ansible/roles/role1/'
    parent_role = {}
    variable_manager = {}
    loader = {}
    collection_list = {}
    ret = ri.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ret.get_name() == data
    assert ret.get_role_path() == current_role_path

    # Test case: data is a dict and role_name is in the dict
    ri = RoleInclude()


# Generated at 2022-06-23 06:53:18.065698
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    loader = AnsibleLoader(None)
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'localhost',
        roles = [
            'test.fixture_roles.role0'
        ]
    ), loader=loader, variable_manager=VariableManager())

    assert play is not None
    assert len(play.roles) == 1
    assert isinstance(play.roles[0], RoleInclude)
    assert play.roles[0].name == 'test.fixture_roles.role0'

# Generated at 2022-06-23 06:53:22.440153
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    variable_manager = DictData({})
    test_data = "ansible_role_example"
    result = RoleInclude.load(test_data, variable_manager)
    assert isinstance(result, RoleInclude)

# Generated at 2022-06-23 06:53:32.081683
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.module_utils.six import PY3, iteritems
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext

    if PY3:
        unicode = str

    def _load(data, variable_manager=None, loader=None):
        ri = RoleInclude()
        ri.load_data(data, variable_manager=variable_manager, loader=loader)
        return ri

    # Test with simple string
    data = "jdoe.example.org"
    role_include = _load(data)
    assert isinstance(role_include, RoleInclude)
    assert role_include.get_name() == data

    # Test with bad data type
    data = 42

# Generated at 2022-06-23 06:53:33.797546
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-23 06:53:36.298181
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pl = AnsibleParserError("Playbook 'test' is missing required attribute 'hosts'")
    vi = RoleInclude(play=pl)

# Generated at 2022-06-23 06:53:49.168725
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = {"hosts": "all"}
    data = {"name": "test"}
    current_role_path = "roles/test"
    variable_manager = {}
    loader = {}
    collection_list = {}
    assert isinstance(RoleInclude.load(data, play, current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list), RoleInclude)

    # Test for exception type AnsibleParserError
    data = ["name", "test"]
    try:
        RoleInclude.load(data, play, current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    except AnsibleParserError:
        pass

    # Test for exception type AnsibleError
    data = "name, test"

# Generated at 2022-06-23 06:54:03.577989
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """Test that we can create a RoleInclude instance."""

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    # Create a Play instance that we can use
    my_play = Play().load({})

    # Create a Role instance that we can use
    my_role = Role().load({'tasks': []}, play=my_play, variable_manager=None)

    # Create a Block instance that we can use
    my_block = Block().load({'tasks': []}, play=my_play, variable_manager=None, block=None)

    # Create a TaskInclude instance that we can use
    my_

# Generated at 2022-06-23 06:54:04.230449
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude()

# Generated at 2022-06-23 06:54:10.071046
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    pdata = Play.load('Play', dict(hosts=['host1','host2','host3'], gather_facts='no'))
    ri = RoleInclude(play=pdata, role_basedir=None, variable_manager=None, loader=None)
    ri._role_name = 'TEST'
    print(repr(ri))

# Generated at 2022-06-23 06:54:11.501945
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    with pytest.raises(AttributeError):
        RoleInclude()

# Generated at 2022-06-23 06:54:16.491856
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import lookup_loader

    test_play_context = PlayContext()
    test_variable_manager = VariableManager()
    test_loader = lookup_loader

    role_include = RoleInclude(play=test_play_context, variable_manager=test_variable_manager, loader=test_loader)
    assert role_include.play == test_play_context
    assert role_include.variable_manager == test_variable_manager
    assert role_include.loader == test_loader

# Generated at 2022-06-23 06:54:20.344779
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    var_manager = VariableManager()
    load = dict(
        include='test'
    )
    role_include = RoleInclude.load(load, var_manager=var_manager)
    assert role_include.get_name() == 'test'

# Generated at 2022-06-23 06:54:21.336574
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:54:22.640950
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri


# Generated at 2022-06-23 06:54:34.787815
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_data = [{
        "name": "role_name",
        "file": "role_file.yml",
        "defaults": {},
        "vars": {},
        "tasks": [],
        "handlers": [],
        "meta": {
            "galaxy_info": {
                "namespace": "namespace",
                "name": "name",
                "version": "0.3.1",
            },
        },
    }]
    role_include = RoleInclude.load(role_data, None)
    assert len(role_include.tasks) == 0
    assert len(role_include.handlers) == 0
    assert role_include.get_vars() == dict()

# Generated at 2022-06-23 06:54:43.605383
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri.get_name() == ""
    assert ri.get_role_path() == ""
    assert ri.get_file_name() == ""
    assert ri.get_parent_role() == None

    ri.set_role_path("/opt/my_role")
    assert ri.get_role_path() == "/opt/my_role"
    assert ri.get_file_name() == "/opt/my_role/tasks/main.yml"
    ri.set_file_name("/opt/my_role/some_other_file.yml")
    assert ri.get_file_name() == "/opt/my_role/some_other_file.yml"
    

# Generated at 2022-06-23 06:54:52.251942
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''
    Unit test for constructor of class RoleInclude
    '''
    play = dict(
            name = 'test_role',
            hosts = 'test_host'
            )

    current_role_path = os.path.dirname(os.path.dirname(__file__))
    ri = RoleInclude(play=play, role_basedir=current_role_path)
    assert ri.play == play
    assert ri.name == 'test_role'
    assert ri._role_path is None
    assert ri._role is None
    assert ri._parent is None
    assert ri._implied_state is None
    assert ri._metadata is None
    assert ri._dependencies is None
    assert ri._default_vars is None
    assert ri._roles_path