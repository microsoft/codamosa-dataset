

# Generated at 2022-06-23 06:45:03.577416
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = dict(
        name='test',
        role_path=['.', '/usr/share/ansible/roles'],
        default_vars={},
        skip_tags=[],
        tags=[],
        when={'test': 'test'},
        handlers={},
        tasks={},
        dependencies={},
        pre_tasks={},
        post_tasks={},
        become=False,
        become_user=False,
        become_method=False,
        become_info=False,
        become_flags=False,
        allow_duplicates=False,
        delegate_to=False,
        delegate_facts=False
    )
    ri = RoleInclude(data)
    assert ri.name == data['name']
    assert ri.role_path == data['role_path']

# Generated at 2022-06-23 06:45:13.222649
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.template as template
    import json

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

# Generated at 2022-06-23 06:45:14.733575
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
#    ans_test = None
#    assert RoleInclude.load(ans_test, "test_role") == None


# Generated at 2022-06-23 06:45:25.143082
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    Test load method of class RoleInclude
    '''
    role_dir = os.path.dirname(__file__).rsplit('/', 1)[0]
    role_name = 'myrole'
    role_path = os.path.join(role_dir, role_name)
    test_data = 'tests/resources/include'
    loader = None
    collection_list = None

    ri = RoleInclude(role_basedir = role_path, loader = loader, collection_list = collection_list)
    assert ri.load(test_data, role_basedir = role_path) == True

    ri = RoleInclude(role_basedir = role_path, loader = loader, collection_list = collection_list)

# Generated at 2022-06-23 06:45:26.593211
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri


# Generated at 2022-06-23 06:45:36.079511
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    current_role_path = "/tmp/role/name"
    parent_role_path = "/tmp/parent/role"
    data = {}
    vars = {}
    vars["ansible_check_mode"] = True
    vars["def"] = "abc"
    vars["abc_def"] = "xyz"
    vars["roles"] = [
        { 'name': 'role1' },
        {
            'name': 'role2',
            'some_var': 'some_value'
        }
    ]
    vars["some_var"] = "some_value"

    class mock_variable_manager:
        def get_vars(self, loader=None, play=None, host=None, task=None):
            return vars

    class mock_loader:
        pass


# Generated at 2022-06-23 06:45:49.308888
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    playbook_path = os.path.join(os.path.dirname(__file__), 'role_include_loader_test.yml')

    my_vars = VariableManager()
    my_vars.extra_vars = {'role_path': os.path.join(os.path.dirname(__file__), 'roles')}

    my_inventory = InventoryManager(my_vars, loader=None)
    my_play = Play.load(playbook_path, variable_manager=my_vars, loader=None)

    assert len(my_play.get_roles()) == 3


# Generated at 2022-06-23 06:45:59.296252
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play

    play = Play()
    role_include = RoleInclude(play=play)

# Generated at 2022-06-23 06:46:00.607996
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:46:01.850682
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

    assert ri

# Generated at 2022-06-23 06:46:11.700881
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Test the loading of a role definition"""
    from ansible.playbook.tests.unit.helpers import load_fixture
    from ansible.playbook.play_context import PlayContext

    play_pc = PlayContext()
    variable_manager = DummyVarsModule()

    # Test that an error is raised when loading something that does not have a valid type
    loader = DummyLoaderModule()
    my_ri = RoleInclude()

    fake_data = None
    # The expected argument is a string, or a dictionary
    with pytest.raises(AnsibleParserError):
        my_ri.load(fake_data, None, variable_manager=variable_manager, loader=loader)

    fake_data = []
    # The expected argument is a string, or a dictionary

# Generated at 2022-06-23 06:46:23.300382
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


    # from units.compat.mock import patch, MagicMock
    # from units.modules.utils import set_module_args
    # from ansible.modules.source_control.git import GitRepo
    #
    #
    # class TestGitRepo(unittest.TestCase):
    #
    #     def setUp(self):
    #         self.mock_git_path = patch('ansible.modules.source_control.git.get_bin_path', lambda x, opts: 'git')
    #         self.mock_git_path.start()
    #
    #         self.mock_module = MagicMock(name='AnsibleModule')
    #         self.mock_module.check_mode = False
    #
    #         self.mock_run

# Generated at 2022-06-23 06:46:32.011937
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    play = Play().load({
        'name': 'test',
        'hosts': ['127.0.0.1'],
        'vars': {
            'var': 'value'
        }
    }, loader=loader)

    role = RoleInclude(play=play, role_basedir='/path/to/basedir', loader=loader)
    assert type(role) == RoleInclude

# Generated at 2022-06-23 06:46:40.212175
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    if not isinstance(RoleInclude.load('webserver,database', PlayContext), RoleRequirement):
        raise AssertionError('RoleInclude.load with a string argument must return a RoleRequirement')
    if not isinstance(RoleInclude.load('webserver', PlayContext), RoleRequirement):
        raise AssertionError('RoleInclude.load with a string argument must return a RoleRequirement')

    if not isinstance(RoleInclude.load({'role': 'webserver,database'}, PlayContext), RoleRequirement):
        raise AssertionError('RoleInclude.load with a dict argument must return a RoleRequirement')
    if not isinstance(RoleInclude.load({'role': 'webserver'}, PlayContext), RoleRequirement):
        raise

# Generated at 2022-06-23 06:46:47.342725
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    try:
        ri.load(None)
        assert False, 'AnsibleParserError not raised'
    except AnsibleParserError:
        pass
    try:
        ri.load({'FROM ROLE': 'myrole'})
        assert False, 'AnsibleError not raised'
    except AnsibleParserError:
        pass
    try:
        ri.load('myrole,anotherrole')
        assert False, 'AnsibleError not raised'
    except AnsibleError:
        pass

# Generated at 2022-06-23 06:46:48.562809
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri != None

# Generated at 2022-06-23 06:46:54.251263
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.role import include
    data = AnsibleBaseYAMLObject()
    data.name = 20
    data.tasks = 'tasks'
    data.vars = 'vars'

    play = 'play'
    role = 'role'
    variable_manager = 'variable_manager'
    loader = 'loader'
    ri = include.RoleInclude(play=play, role_basedir=role, variable_manager=variable_manager, loader=loader)

    try:
        ri.load_data(data, variable_manager=variable_manager, loader=loader)
        assert False
    except AnsibleParserError as e:
        assert True
        assert e

# Generated at 2022-06-23 06:47:05.578176
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    current_path = os.path.dirname(__file__)
    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()

    try:
        role_include = RoleInclude.load(
            data='test',
            play=play_context,
            current_role_path=current_path,
            variable_manager=variable_manager,
            loader=loader,
            collection_list=None
        )
    except AnsibleError as e:
        print(e)


# Generated at 2022-06-23 06:47:06.409542
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-23 06:47:10.494390
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    my_class = RoleInclude()
    assert isinstance(my_class, RoleDefinition)
    assert my_class._role_path is None
    assert my_class._role_name is None
    assert my_class._role_collection is None
    assert my_class.get_vars() == {}
    assert my_class.get_default_vars() == {}

# Generated at 2022-06-23 06:47:12.430132
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''Unit test for constructor of class RoleInclude'''
    role_include = RoleInclude()
    assert role_include

# Generated at 2022-06-23 06:47:22.742035
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Variable manager object is passed to role include object
    variable_manager = 'variable_manager'
    # Play object is passed to RoleInclude object
    play = 'play'
    # Directory path is passed to RoleInclude object
    role_basedir = 'role_basedir'
    # Loader object is passed to RoleInclude object
    loader = 'loader'
    # Collection List object is passed to RoleInclude object
    collection_list = 'collection_list'
    # Create object for RoleInclude class
    ri = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    # Assert statements
    # Assert that the play object of RoleInclude class is same as the object passed in the constructor
    assert ri._play

# Generated at 2022-06-23 06:47:34.698463
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    loader = None
    variable_manager = None
    play = None
    current_role_path = None
    collection_list = None
    variable_manager = None
    parent_role = None
    data_string = None
    try:
        RoleInclude.load(data_string, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except Exception as e:
        assert os.environ['TEST_ERROR'] == "Invalid role definition: None"
   
    data_dict = {}
    try:
        RoleInclude.load(data_dict, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except Exception as e:
        assert "Invalid role definition" in to_native(e)
   

# Generated at 2022-06-23 06:47:36.152668
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri

# Generated at 2022-06-23 06:47:36.710313
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:47:47.833404
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Create a mock object for class Play
    play_obj = object()

    # Create a mock object for class RoleRequirement
    role_req_obj = object()

    # Create a mock object for class RoleInclude
    ri = RoleInclude(play=play_obj)

    # Create a mock data stucture
    data = {
        "name": "test-role"
    }

    # Mock import of class RoleRequirement
    with patch('ansible.playbook.role.include.RoleRequirement') as mock_rr:

        # Mock the actual instance creation method
        mock_rr.return_value = role_req_obj

        # Call the method under test
        ri.load(data, play=play_obj)

        # Check if the the method was called once
        assert mock_rr.call_count == 1



# Generated at 2022-06-23 06:47:53.276752
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """Test RoleInclude constructor."""

    temp = RoleInclude()
    #print(dir(temp))
    print('RoleInclude: ' + str(RoleInclude))


# RoleBase._load_name/1 method goes here
# TODO: needs tests

# include_role method goes here
# TODO: needs tests

# Generated at 2022-06-23 06:47:57.261105
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
    #TODO: implement
    #TODO: the load function of RoleInclude  is a static method, it will be difficult to unit-test.

# Generated at 2022-06-23 06:48:07.996400
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #Testing for valid data string
    data="test_module"
    assert(RoleInclude.load(data, None) is not None)

    #Testing for invalid data string
    data=','
    try:
        RoleInclude.load(data, None)
    except AnsibleError as e:
        assert(e)

    #Testing data with string types
    data = 'test,test1'
    try:
        RoleInclude.load(data, None)
    except AnsibleParserError as e:
        assert(e)

    #Testing data with dict types
    data = {'collections': [{'name': 'my.collection', 'version': '1.0'}]}
    assert(RoleInclude.load(data, None) is not None)

    #Testing data with AnsibleBaseYAMLObject
    data

# Generated at 2022-06-23 06:48:19.486271
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    temp_var_manager = Attribute()
    temp_loader = Attribute()
    temp_data_1 = ''
    temp_data_2 = {}
    temp_data_3 = []
    temp_data_4 = None
    temp_data_5 = 0
    temp_play = ''
    temp_current_role_path = ''
    temp_parent_role = ''
    try:
        RoleInclude.load(temp_data_1, temp_play, temp_current_role_path, temp_parent_role,
                         temp_var_manager, temp_loader)
    except AnsibleParserError as e:
        assert 'Invalid role definition' in str(e)


# Generated at 2022-06-23 06:48:21.145557
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:48:31.950114
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    p = Play().load(dict(
        name = "test-play",
        hosts = "localhost",
        gather_facts = "no",
        roles = [
            dict(
                name = "test-role",
                tasks = [
                    dict(action=dict(module="debug", args=dict(msg="Hello World!")))
                ]
            )
        ]
    ), variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 06:48:32.995747
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude is not None

# Generated at 2022-06-23 06:48:48.600229
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    def False_func():
        return False
    def True_func():
        return True

    req = RoleInclude()
    print(req.__dict__)
    assert req._invalid_attributes == {}

# Generated at 2022-06-23 06:48:56.385270
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-23 06:49:02.802006
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import os
    import tempfile
    import yaml

    # Write a test yaml file
    file_path = tempfile.mkstemp()[1]
    with open(file_path, 'w') as f:
        yaml.dump(dict(roles=['my_role'], vars=dict(var1='foo')), f)


# Generated at 2022-06-23 06:49:13.086620
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    ri = RoleInclude(play=0, role_basedir='/home/me', variable_manager=0, loader=0)
    if ri._play is not 0:
        raise AssertionError('Expected play to equal 0')
    if ri._role_basedir is not '/home/me':
        raise AssertionError('Expected _role_basedir to equal /home/me')
    if ri._variable_manager is not 0:
        raise AssertionError('Expected _variable_manager to equal 0')

# Generated at 2022-06-23 06:49:24.885525
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.vars.manager import VariableManager

    yaml_data = """
---
name: test
hosts: webservers
pre_tasks:
  - name: pre_task
    debug:
      msg: pre_task
    delegate_to: 127.0.0.1
    delegate_facts: true
"""
    yaml_data = yaml_data.strip()
    results = yaml.load(yaml_data, Loader=AnsibleLoader)



# Generated at 2022-06-23 06:49:34.804913
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {
        'name': 'foo',
        'hosts': 'bar',
        'roles': [
            {'role': 'baz'},
            {'role': 'qux', 'x': 1},
        ]
    }

    def make_play():
        return {
            'hosts': 'all',
        }
    play = make_play()

    role = RoleInclude.load(data, play)
    assert role.get_name() == data.get('name')
    assert role._role_name == ['foo']
    assert role._role_path == ['foo']

# Generated at 2022-06-23 06:49:41.400409
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    role_include_dict = {
        'role': 'my_role'
    }
    role_include = RoleInclude.load( role_include_dict, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None)

    assert role_include is not None

    assert role_include._role_moved is False

    # set attribures
    role_include._role_name = 'my_role'
    role_include._role_path = '/tmp/my_role'

    assert 'my_role' == role_include._role_name
    assert '/tmp/my_role' == role_include._role_path

    # test one more time with a path
    role_include_dict = {
        'role': '/tmp/my_role'
    }
    role

# Generated at 2022-06-23 06:49:43.543184
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:49:44.570930
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude()
    assert roleInclude is not None

# Generated at 2022-06-23 06:49:50.944520
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude.load(data='mytestrole', play=None,
                          current_role_path='/tmp/roles',
                          parent_role=None,
                          variable_manager=None,
                          loader=None)
    assert ri._role_name == 'mytestrole'

    with pytest.raises(AnsibleError):
        RoleInclude.load(data='mytestrole,role1,role2', play=None,
                         current_role_path='/tmp/roles',
                         parent_role=None,
                         variable_manager=None,
                         loader=None)

# Generated at 2022-06-23 06:49:51.472264
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:49:59.125533
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from collections import namedtuple
    from ansible.playbook.role.definition import ROLE_CACHE
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager
    from ansible.template import Templar

    # Mock objects needed to test load method of class RoleInclude
    class Play(object):
        pass
    class DataLoader(object):
        pass
    class VariableManager(object):
        def __init__(self):
            self.extra_vars = {}
        def __setitem__(self, key, value):
            self.extra_vars[key] = value

# Generated at 2022-06-23 06:50:05.858751
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import ansible.playbook.role.definition
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    myPlay = ansible.playbook.play.Play()
    myPlay._variable_manager = VariableManager()
    myPlay._context = PlayContext()
    myPlay._loader = DataLoader()
    myPlay._inventory = InventoryManager(loader=myPlay._loader, sources='localhost,')

    myRole = RoleInclude(play=myPlay, role_basedir="./data/roles/myRole/")
    assert(myRole.get_name() == "myRole") # no name is

# Generated at 2022-06-23 06:50:07.464844
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    RoleInclude.load("role_name", "Play", "role_path", "test", "resolve", "loader")

# Generated at 2022-06-23 06:50:08.578398
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert(ri is not None)

# Generated at 2022-06-23 06:50:14.119570
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("Testing constructor of class RoleInclude")
    assert RoleInclude
    assert RoleInclude.__doc__
    assert RoleInclude.__init__.__doc__
    assert RoleInclude.load.__doc__
    # Make some tests with the constructor:
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None)
    assert ri
    assert type(ri) == RoleInclude
    # and with the load method:
    assert RoleInclude.load(data=None, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    print("Success: constructor of class RoleInclude")


# Generated at 2022-06-23 06:50:26.900255
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    p = Play()
    m = RoleMetadata(name='foo')
    ri = RoleInclude(play=p, role_basedir=m.basedir)
    assert ri.play == p
    assert ri.role_basedir == m.basedir
    assert ri.role_path is None
    assert ri.role_name is None
    assert len(ri.dependencies) == 0
    assert ri.name is None
    assert ri.vars is None
    assert ri.task_blocks is None

# Generated at 2022-06-23 06:50:27.669509
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    #TODO write unit tests for RoleInclude.load
    """
    return

# Generated at 2022-06-23 06:50:32.809062
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = "Test Play"
    role_basedir = "/ansible/test/playbook"
    variable_manager = ""
    loader = "Test Loader"

    role_include = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader)
    assert role_include is not None

# Generated at 2022-06-23 06:50:35.425169
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    result = RoleInclude.load('./role-test', None, None, None, None, None)
    assert result

# Generated at 2022-06-23 06:50:37.023522
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    rd = RoleInclude()
    assert rd



# Generated at 2022-06-23 06:50:46.291211
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play
    from ansible.vars import VariableManager

    # Create a play for the RoleInclude
    play = Play().load({
        'name': 'play',
        'hosts': 'host',
        'gather_facts': 'no',
        'roles': [
            {
                'role': 'role1',
            }
        ]
    }, variable_manager=VariableManager(), loader=None)

    data = 'role1'
    role_include = RoleInclude.load(data, play, loader=None)
    assert role_include._role_name == 'role1'

# Generated at 2022-06-23 06:50:55.499050
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import role_loader

    p = Play().load({
        'name' : 'test',
        'hosts' : 'all',
        'roles' : [
            {
                'test_role': None,
            },
            {
                'test_role': {
                    'tasks': [
                        { 'debug': 'msg="test role override"' }
                    ]
                },
            }
        ],
    }, variable_manager=None, loader=None)

    role_loader.add_directory(os.path.join(os.path.dirname(__file__), 'fixtures', 'test_role'))

# Generated at 2022-06-23 06:50:58.355134
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert RoleInclude.load('geerlingguy.apache', None, None, None, None, None).get_name() == 'geerlingguy.apache'

# Generated at 2022-06-23 06:51:00.047621
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleDefinition)

# Generated at 2022-06-23 06:51:00.905704
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:51:10.401646
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence

    loader = AnsibleLoader(None, None)

    play = Play().load(dict(name="some play", hosts=['foo'], roles=['some_role']), loader=loader, variable_manager=None)

    assert play._entries[0]['include'][0].__class__ == RoleInclude

    # Test to see if an exception

# Generated at 2022-06-23 06:51:16.194472
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # role_basedir = os.path.join(current_dir, '..')
    role_basedir = ''
    role = RoleInclude(role_basedir=role_basedir)
    assert role.role_basedir == role_basedir

# Generated at 2022-06-23 06:51:21.948448
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Basic test, just want to make sure it runs through
    variable_manager = {}
    loader = None
    collection_list = ['foo']
    play = None

    RoleInclude(play, None, variable_manager, loader, collection_list)

# Generated at 2022-06-23 06:51:32.401705
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import ansible.playbook
    import ansible.parsing.yaml.objects
    import ansible.playbook.play
    import ansible.playbook.role.definition
    import ansible.playbook.role.requirement

    #case1:normal
    path = os.path.dirname(ansible.playbook.__file__)
    data = ansible.parsing.yaml.objects.AnsibleBaseYAMLObject(string_value=path)
    play = ansible.playbook.play.Play()
    role_definition = ansible.playbook.role.definition.RoleDefinition.load(data, play)
    role_require = ansible.playbook.role.requirement.RoleRequirement(role_definition=role_definition)
    #print(role_require)

# Generated at 2022-06-23 06:51:33.292226
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:51:36.518077
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert True

# Generated at 2022-06-23 06:51:38.087056
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    x = RoleInclude()
    assert (isinstance(x, RoleInclude))

# Generated at 2022-06-23 06:51:45.099359
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Base case : load string
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    data = 'test'

    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ri == data

    # Non string case : raise Exception
    data = False
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleParserError:
        assert True
    else:
        assert False

    # string case with ',' : raise exception
    data = 'test,test2'

# Generated at 2022-06-23 06:51:55.434377
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import load_plugins

    variable_manager = VariableManager()

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 06:51:57.826517
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri_obj = RoleInclude()
    ri_obj.load(None, None, None, None, None)

# Generated at 2022-06-23 06:52:04.498611
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    obj = RoleInclude()
    assert obj._play is None
    assert obj._role_basedir is None
    assert obj._variable_manager is None
    assert obj._loader is None
    assert hasattr(obj, '_attributes')

# Generated at 2022-06-23 06:52:12.867246
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    inventory.clear_pattern_cache()
    host = inventory.get_host("foobar")
    play_context = PlayContext(inventory=inventory, loader=loader, variable_manager=variable_manager)
    tqm = None

# Generated at 2022-06-23 06:52:14.800470
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

if __name__ == '__main__':
    test_RoleInclude()

# Generated at 2022-06-23 06:52:16.597844
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # create empty RoleInclude object
    ri = RoleInclude()

# Generated at 2022-06-23 06:52:27.894125
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play

    play = Play.load(dict(name='test play', hosts=['all'], tasks=[
        dict(action=dict(module='setup'), register='setup_facts'),
        dict(action=dict(module='include_role', name='name'))
    ]), variable_manager=None, loader=None)

    task = play.task_blocks[0].block[0].role

    assert task.name == 'name'
    assert task.default_vars == {}
    assert task.private == False

    task.load_data(dict(name='name', private=True, default_vars=dict(a=1, b=2)))

    assert task.name == 'name'
    assert task.default_vars == dict(a=1, b=2)

# Generated at 2022-06-23 06:52:37.448992
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Example of an old-style role requirement
    data = 'foobar'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleError as e:
        assert str(e) == 'Invalid old style role requirement: %s' % data
    else:
        assert False, "AnsibleError not raised"



# Generated at 2022-06-23 06:52:46.251455
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(name='test', debug='msg="{{ test_var }}"', vars=dict(test_var='ansible')),
                dict(action=dict(module='debug', args=dict(msg='{{role_var}}')))
            ]
        )

# Generated at 2022-06-23 06:52:53.854678
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    p = PlayContext()
    ri = RoleInclude(play=p, loader=loader)
    ri.initialize()
    
    assert ri._play is not None
    assert ri._loader is not None

# Generated at 2022-06-23 06:53:00.068904
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # ============
    # Unit: RoleInclude.load
    # ============
    
    # ============
    # Unit: RoleInclude.load: raise AnsibleError
    # ============
    try:
        ri = RoleInclude.load('a,b', 'play')
    except AnsibleError:
        pass
    

# Generated at 2022-06-23 06:53:10.233004
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play
    from ansible.module_utils.six import PY3
    from ansible.vars.manager import VariableManager

    play1 = Play.load(dict(
        name="test play",
        hosts=['127.0.0.1'],
        gather_facts='no',
        vars=dict(
            a=5,
            b=dict(
                c=6,
                d=8,
            )
        ),
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{foo}}'))),
        ]
    ), loader=None, variable_manager=VariableManager())
    play1._variable_manager.extra_

# Generated at 2022-06-23 06:53:11.701124
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:53:18.677005
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {}
    data['role_name'] = 'abc'
    data['role_path'] = 'xyz'
    data['role_args'] = {}
    data['role_metadata'] = 'test'
    data['role_collections'] = []
    data['role_dep_facts'] = {}
    role = RoleInclude.load(data)
    assert role.get_name() == 'abc'
    assert role.get_role_path() == 'xyz'
    assert role.get_role_args() == {}
    assert role.get_role_metadata() == 'test'
    assert role.get_role_collections() == []

# Generated at 2022-06-23 06:53:30.335219
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    # Test attributes
    ri = RoleInclude()
    assert ri.role_name is None
    assert ri.tasks_include is None
    assert ri.handlers_include is None
    assert ri.default_vars == dict()
    assert ri.default_vars_files == list()
    assert ri.vars_files == list()
    assert ri.vars == dict()
    assert ri.tags == list()
    assert ri.meta == dict()
    assert ri.name == 'PLAY_ROLE_INCLUDE'
    assert ri.play is None
    assert ri.role_path is None
    assert ri.is_meta is False
    assert ri.is_playbook is False
    assert ri.role_basedir is None
    assert ri

# Generated at 2022-06-23 06:53:41.778282
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition

    p = Play()
    p._loader = None
    p._variable_manager = None

    r = Role()
    r._loader = None
    r._variable_manager = None


    # Load TaskInclude data with unset RoleInclude instance
    # Expected: AnsibleParserError
    try:
        RoleInclude.load(None, play=p, current_role_path=None, parent_role=r, variable_manager=None, loader=None)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("AnsibleParserError not raised")

    # Load TaskInclude data with unset RoleInclude instance
    #

# Generated at 2022-06-23 06:53:42.180496
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:53:51.038116
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 06:54:00.127080
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = dict()
    data["name"] = "role_include_test"
    data["vars_prompt"] = dict()
    data["vars_prompt"]["name"] = dict()
    data["vars_prompt"]["name"]["type"] = "string"
    data["vars_prompt"]["name"]["description"] = "description"
    data["vars_prompt"]["name"]["default"] = "test"
    data["vars_prompt"]["name"]["private"] = False
    data["allow_duplicates"] = False
    ri = RoleInclude()
    assert ri.load_data(data).attributes["name"] == "role_include_test"

# Generated at 2022-06-23 06:54:08.232778
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # We set loader to None, but this is not the best idea.
    # However, in order to test the method load, we do not want to load
    # another file.
    ri = RoleInclude(loader=None)
    data = dict(
        name="role_name",
        tasks=[1, 2, 3],
        handlers=[4, 5, 6],
    )
    ri.load_data(data)
    assert ri.name == "role_name"
    assert ri.tasks == [1, 2, 3]
    assert ri.handlers == [4, 5, 6]

# Generated at 2022-06-23 06:54:10.171213
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
#def test_RoleInclude(self):
    ri = RoleInclude(data=[], role_basedir=None)
    pass

# Generated at 2022-06-23 06:54:18.891933
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import module_utils_loader

    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.plugins import PluginLoader

    class mock_connection:
        def __init__(self):
            self.transport = "mock"


# Generated at 2022-06-23 06:54:26.950533
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins import module_loader

    lookup_loader = module_loader.LookupModuleLoader()
    lookup_plugins = {'lookup_loader': lookup_loader}

# Generated at 2022-06-23 06:54:29.312492
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include is not None

# Generated at 2022-06-23 06:54:40.245120
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import copy
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import collection_loader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()

# Generated at 2022-06-23 06:54:52.215489
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class Dummy(object):
        pass
    ri = RoleInclude()

    ri.load_data.__dict__['_is_new_style'] = True
    ri.load_data.__dict__['_parent'] = None
    # Test normal loading without errors
    data = dict(name='test_role', src='test-role')
    ri.load_data(data, variable_manager="variable_manager", loader="loader")
    # Test loading with exceptions
    ri.load_data.__dict__['_is_new_style'] = False
    data = dict(name='test_role', src='test-role')