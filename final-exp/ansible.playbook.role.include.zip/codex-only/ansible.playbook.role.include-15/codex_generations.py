

# Generated at 2022-06-23 06:44:48.757308
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO
    pass

# Generated at 2022-06-23 06:45:03.577500
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """validates that load() method of class RoleInclude - succeeds if it loads the role correctly"""

    role_data = '''
    - role: 'role_name'
        role_tasks:
        - name: 'task1'
        - name: 'task1'
        tags:
        - task1
        - task2
        vars:
        - var_name1
        - var_name2
        pre_tasks:
          - name: 'pre_task1'
        post_tasks:
          - name: 'post_task1'
        handlers:
          - name: 'handler1'
    '''

    variable_manager = None
    loader = None
    role_basedir = None
    play = None

# Generated at 2022-06-23 06:45:04.356186
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-23 06:45:13.984641
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import collection_loader, role_loader
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionFinder
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Prepare the environment
    # The embedded file is a copy of the file in Ansible source code,
    # with corrected path for:
    #   - galaxy.yml
    #   - meta/main.yml
    #   - tasks/image.yml
    embedded_test_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Generated at 2022-06-23 06:45:24.419006
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a play for testing
    play = Play().load({
        'name': "Ansible Play",
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [
            {'name': 'debug', 'debug': 'msg="This is a test."'},
        ]
    }, variable_manager=VariableManager(), loader=DataLoader())
    play._tqm._inventory.clear_pattern_cache()

    # Create a role for testing
    role = RoleInclude(play=play, role_basedir="test/roles/role1", variable_manager=VariableManager(), loader=DataLoader())
    role

# Generated at 2022-06-23 06:45:34.359169
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    # Do some tests with the RoleInclude class
    role_include = RoleInclude()

    # test with both the python 2 and python 3 style of object id
    if PY3:
        assert isinstance(role_include.__repr__(), str)
    else:
        assert isinstance(role_include.__repr__(), unicode)
    # test with both the python 2 and python 3 style of object id
    if PY3:
        assert isinstance(role_include.__str__(), str)
    else:
        assert isinstance(role_include.__str__(), unicode)

    # Raise assertion error trying to set an invalid attribute in the RoleInclude class

# Generated at 2022-06-23 06:45:34.919941
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Generated at 2022-06-23 06:45:45.086873
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    def get_playbook_executor(playbooks, host_list, inventory=None):
        loader = DataLoader()
        variable_manager = VariableManager()
        if inventory:
            variable_manager.set_inventory(inventory)
        executor = PlaybookExecutor(
            playbooks=playbooks,
            inventory=inventory,
            variable_manager=variable_manager,
            loader=loader,
        )
        return executor

    # test method load of class RoleInclude
    # case 1: 
    # create a role include object with

# Generated at 2022-06-23 06:45:46.957500
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert isinstance(role_include, RoleInclude)

# Generated at 2022-06-23 06:45:57.028173
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.requirement import RoleRequirement
    ri = RoleInclude()

    # constructor with parameters
    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'web',
        roles = 'common',
        gather_facts = 'no'
    ), loader=None)
    ri = RoleInclude(play=play,
                     role_basedir="~/ansible/roles",
                     variable_manager=None,
                     loader=None,
                     collection_list="")
    assert ri.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-23 06:46:09.718088
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play

    class MockVariableManager():
        def __init__(self):
            self.extra_vars = {}
            self.options = {}
            self.options['roles_path'] = '/path/to/roles'

        def get_vars(self, loader, play, host, task):
            return {}

    class MockRole():
        def __init__(self):
            self.name = 'test_role'
            self.path = os.path.join(MockVariableManager().options['roles_path'], self.name)

    class MockLoader():
        def __init__(self):
            self.get_basedir = lambda x: os.path.join(MockVariableManager().options['roles_path'], x.name)


# Generated at 2022-06-23 06:46:20.240738
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    vars = {'variable': 'value'}

    # Test case 1: data is not a string/dict:
    with pytest.raises(AnsibleParserError) as error:
        RoleInclude.load(list(), vars)
    assert 'invalid role definition' in str(error)

    # Test case 2: data is a string and contains ',':
    with pytest.raises(AnsibleError) as error:
        RoleInclude.load('role1,role2', vars)
    assert 'invalid old style role requirement' in str(error.value)


# Generated at 2022-06-23 06:46:21.065375
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False

# Generated at 2022-06-23 06:46:26.914077
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    myRoleInclude = RoleInclude()
    myRoleInclude.set_loader(object())
    myRoleInclude.set_variable_manager(object())
    assert myRoleInclude.loader is not None
    assert myRoleInclude.variable_manager is not None

# Generated at 2022-06-23 06:46:30.469220
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    test_instance = RoleInclude()
    assert test_instance._play is None
    assert test_instance._role_basedir is None
    assert test_instance._variable_manager is None
    assert test_instance._loader is None


# Generated at 2022-06-23 06:46:42.856728
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import os
    import sys
    import pytest
    # we need to put the path to this module into the python path temporarily
    sys.path.insert(0, os.path.abspath(
      os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib')))

# Generated at 2022-06-23 06:46:51.233047
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.inventory
    import ansible.variables.manager
    import ansible.executor.play_context

    # Create a Fake Play object
    play = ansible.playbook.play.Play()
    play.hosts = [1,2,3]
    play.name = 'FAKE_PLAY'
    play.connection = 'FAKE_CONNECTION'
    play._variable_manager = ansible.variables.manager.VariableManager()
    play._variable_manager._fact_cache = dict()

    # Create a Fake Task object
    task = ansible.playbook.task.Task()
    task.action = 'FAKE_ACTION'
    task.name = 'FAKE_TASK'

# Generated at 2022-06-23 06:47:02.909317
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory_from_list({'test_host': {'vars': {'var1': 'test_value'}}}))


    p = Play()
    role_basedir = '/tmp'

    current_role_path = './roles/my_role'


    # test case with dict

# Generated at 2022-06-23 06:47:11.765810
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    ri = RoleInclude()

    assert isinstance(ri.load("pgsql", None, variable_manager=None, loader=None), RoleRequirement)
    assert isinstance(ri.load({"role": "pgsql"}, None, variable_manager=None, loader=None), RoleRequirement)

    assert isinstance(ri.load({"role": "pgsql", "tags": ["tag1"], "when": "simple"}, None, variable_manager=None, loader=None), RoleDefinition)
    assert isinstance(ri.load({"include_role": "pgsql", "tags": ["tag1"], "when": "simple"}, None, variable_manager=None, loader=None), RoleDefinition)

# Generated at 2022-06-23 06:47:12.693021
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()

# Generated at 2022-06-23 06:47:17.133459
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    ri = RoleInclude(play=Play(), variable_manager=VariableManager())
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:47:19.578397
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # check class constructor behavior when valid data provided
    ri = RoleInclude()
    assert (isinstance(ri, RoleInclude))

    # check class constructor behavior when invalid data provided
    # TODO: add a test case with invalid data


# Generated at 2022-06-23 06:47:32.368145
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import fragments_loader, task_loader, module_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.plugins import get_all_plugin_loaders
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude

    inv = InventoryManager(loader=DataLoader(), sources=['test/ansible/hosts'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inv)
    loader = DataLoader()

# Generated at 2022-06-23 06:47:44.439106
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    class MyFakePlay:
        pass
    fake_play = MyFakePlay()
    class MyFakeVarManager:
        def get_vars(self, loader, play, host, task):
            return {}
    fake_var_manager = MyFakeVarManager()
    class MyFakeLoader:
        def load_file(self, path):
            return dict(
                name = "TEST_ROLE",
                tasks = dict(
                    main = [ dict( include = 'other' ) ]
                ),
                handlers = dict(
                    main = [ dict( include = 'other' ) ]
                )
            )
    fake_loader = MyFakeLoader()
    ri = RoleInclude(play=fake_play, role_basedir='.', variable_manager=fake_var_manager, loader=fake_loader)
    assert ri._

# Generated at 2022-06-23 06:47:53.076771
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    ri.async_seconds = 10
    assert ri.async_seconds == 10
    pr = RoleRequirement()
    pr.role = 'test'
    ri.role = pr
    assert isinstance(ri.role, RoleRequirement)
    assert ri.role.role == 'test'
    assert ri.role == pr
    assert ri.role['role'] == 'test'
    ri.tasks_from = 'main'
    assert ri.tasks_from == 'main'
    ri.vars_from = 'main'
    assert ri.vars_from == 'main'
    ri.handlers_from = 'main'
    assert ri.handlers_from == 'main'

# Generated at 2022-06-23 06:48:04.479668
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-23 06:48:08.964749
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    testRole = RoleInclude()
    assert(isinstance(testRole, RoleInclude))
    assert(isinstance(testRole, RoleDefinition))
    assert(testRole.get_name() == None)


# Generated at 2022-06-23 06:48:19.938313
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.parsing.yaml.dumper import AnsibleDumper

    rd = RoleDefinition(None, None, None, None, None)
    ri = RoleInclude(None, None, None, None, None)
    rq = RoleRequirement()
    rq.spec = AnsibleCollectionRef.from_str('myns.mycoll.myrole')

    assert ri.load({}, None, None, None, None, None) is None
    assert ri.load([], None, None, None, None, None) is None
    with pytest.raises(AnsibleParserError):
        ri

# Generated at 2022-06-23 06:48:25.534799
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    '''
    Unit test for constructor of class RoleInclude
    '''
    role_include = RoleInclude()
    assert role_include


# Generated at 2022-06-23 06:48:27.936437
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass



# Generated at 2022-06-23 06:48:31.992771
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Create a new object of the class
    result = RoleInclude()
    # Assert that the class of the object is equal to the class we created
    assert isinstance(result, RoleInclude)

# Generated at 2022-06-23 06:48:37.060485
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    file_name = os.path.abspath(os.path.dirname(__file__)) + '/test_files/test_RoleInclude.yml'
    data = RoleInclude.load(data=file_name)
    print(data)


if __name__ == "__main__":
    test_RoleInclude()

# Generated at 2022-06-23 06:48:49.033460
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Setup dummy data
    data = {'name': 'test'}
    current_role_path = '/my/role/path'
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    # Run method

# Generated at 2022-06-23 06:48:57.092183
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
     ri = RoleInclude()
     assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:49:09.383432
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # Since RoleInclude is a subclass of RoleDefinition,
    # constructors of RoleDefinition and RoleInclude will be executed.
    # For test the RoleInclude, we need to mock RoleDefinition.
    # Note that _validate_fields is a static method which cannot be mocked with patch.
    # To ficilitate the test, we add a flag to set _all_field_names to empty.
    # This flag should be set properly and removed after test.
    # These changes will not affect the implementation of RoleInclude.
    from ansible.playbook.role.definition import RoleDefinition
    RoleDefinition._test_fields_flag = True
    ri = RoleInclude()
    assert ri._all_field_names is None
    RoleDefinition._test_fields_flag = False

# Generated at 2022-06-23 06:49:16.066680
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    os.environ['ANSIBLE_ROLE_INCLUDE_LOAD_TEST_VAR'] = "some_value"

    assert 'some_value' == os.environ.get('ANSIBLE_ROLE_INCLUDE_LOAD_TEST_VAR')

    import copy
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    def _load_collection(collection_name):
        from ansible.collections import AnsibleCollectionLoader
        from ansible.playbook.play_context import PlayContext

        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager

        loader = DataLoader()
        # FIXME: workaround until collection_loader is inventory dependant
        loader.set

# Generated at 2022-06-23 06:49:26.484649
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    data = ("myrole", dict(foo="bar"))
    play = Play().load({'name': 'test', 'hosts': 'all', 'roles': ['myrole']})
    current_role_path = '/home/stack/ansible/roles'
    role_definition = RoleDefinition(play=play, role_basedir=current_role_path)
    role_requirement = RoleRequirement(play=play, role_basedir=current_role_path)
    assert isinstance(role_requirement.load(data, play, current_role_path=current_role_path, parent_role=role_definition), RoleRequirement)

# Generated at 2022-06-23 06:49:33.236241
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
   loader = Mock(loader_module=None)
   variable_manager = Mock(variable_manager_module=None)
   play = Mock(play_module=None)

   ri = RoleInclude(play=play, role_basedir=None, variable_manager=variable_manager, loader=loader, collection_list=None)

   assert ri._delegate_to == ''
   assert ri._delegate_facts == False

# Generated at 2022-06-23 06:49:33.984923
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    print(ri)

# Generated at 2022-06-23 06:49:45.360627
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    data = {'role': 'foo'}
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'role': 'bar'}
    loader = None
    variable_manager.set_available_variables(loader=loader, play=None)
    variable_manager.set_nonpersistent_facts(variable_manager.get_vars(loader=loader, play=None))
    play = Play().load('', loader=loader, variable_manager=variable_manager)
    role_basedir = os.getcwd()
    collection_list = None
    role_include = RoleInclude(play, role_basedir, variable_manager, loader, collection_list)
    role_include.load(data)

    assert role

# Generated at 2022-06-23 06:49:57.733588
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.yaml import objects
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.utils.vars import combine_vars

    # file vars
    p1 = dict(
        k2="v2",
        k1="v1",
    )
    # role_vars
    p2 = dict(
        k3="v3",
        k1="r1",
    )
    # inventory vars
    p3 = dict(
        k4="v4",
        k1="i1",
    )
    # extra vars
    p4 = dict(
        k5="v5",
        k1="e1",
    )

    # testinclude:
    #  

# Generated at 2022-06-23 06:49:59.768114
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
        this test is supposed to be used by unit test
    """
    pass

# Generated at 2022-06-23 06:50:00.985825
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None)
    print(ri)

# Generated at 2022-06-23 06:50:03.096230
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:50:03.829011
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:50:11.545201
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.variable_manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import find_plugin
    from ansible.executor.playbook_executor import PlaybookExecutor

    host_list = ['/etc/ansible/hosts']
    loader = DataLoader()
    inventory = Inventory(host_list, loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os

# Generated at 2022-06-23 06:50:13.952478
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass

# Make sure load function is defined
assert RoleInclude.load
print('RoleInclude: ok')

# Generated at 2022-06-23 06:50:21.388396
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {"role": "example_role", "delegate_to": "127.0.0.1"}
    from ansible.playbook import Play
    play_ds =  Play().load(data, variable_manager=None, loader=None)
    ri = RoleInclude(play = play_ds)
    assert ri != None

# Generated at 2022-06-23 06:50:31.165272
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-23 06:50:34.390248
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    my_role = RoleInclude()
    assert(isinstance(my_role, RoleInclude))
    assert(isinstance(my_role, RoleDefinition))

# Generated at 2022-06-23 06:50:36.359916
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()

    # Interface test
    assert hasattr(role_include, 'load')
    assert hasattr(role_include, 'load_data')

# Generated at 2022-06-23 06:50:47.892799
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.action as action_loader
    import ansible.plugins.lookup as lookup_loader
    import ansible.plugins.filter as filter_loader
    import ansible.plugins.test as test_loader
    import ansible.plugins.connection as connection_loader
    import ansible.plugins.strategy as strategy_loader
    import ansible.plugins.shell as shell_loader
    import ansible.plugins.module_utils as module_utils_loader
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import ROLE_CACHE
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

   

# Generated at 2022-06-23 06:50:56.300345
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible import context
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '0.0'
    play_context.port = 22
    play_context.verbosity = 0
    play_context.check_mode = True
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.set_options(direct={'no_log': True, 'role_paths': [], 'roles_path': os.path.join(os.path.dirname(__file__),'unit_test_roles')})

# Generated at 2022-06-23 06:51:01.320861
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert(ri._play is None)
    assert(ri._role_basedir is None)
    assert(ri._variable_manager is None)
    assert(ri._loader is None)

# Generated at 2022-06-23 06:51:03.466698
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pl = Play()
    data = {
        'name': 'test',
    }
    RoleInclude.load(data, pl)


# Generated at 2022-06-23 06:51:04.958275
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None


# Generated at 2022-06-23 06:51:14.398005
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    play_context = dict(
        conduit="",
        basedir=".",
        paths_cache={},
        loader="",
        variable_manager="",
        connection_plugins={},
        action_plugins={},
        module_utils={},
        filters={},
        default_vars={},
    )
    play = Play().load({'hosts': 'localhost', 'gather_facts': 'no', 'connection': 'local'}, variable_manager=play_context['variable_manager'], loader=play_context['loader'])
    block = Block()

# Generated at 2022-06-23 06:51:19.411821
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # class RoleInclude(RoleDefinition)
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'
# -- end

# Generated at 2022-06-23 06:51:31.847416
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test for method load of class RoleInclude
    """
    role1 = {"name": "test", "path": "/home/test/test"}
    role2 = "test,test1,test2"
    role3 = ["test", "test1", "test2"]

    ans = {
        "test": {"name": "test/test", "path": "/home/test/test", "role_path": "/home/test/test"},
        "test1": {"name": "test/test1", "path": "/home/test/test1", "role_path": "/home/test/test1"},
        "test2": {"name": "test/test2", "path": "/home/test/test2", "role_path": "/home/test/test2"}
    }

    # check if load return valid data


# Generated at 2022-06-23 06:51:33.069295
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    ri.__init__()

# Generated at 2022-06-23 06:51:44.071540
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test default construction
    ri = RoleInclude()
    assert ri.role_path == None
    assert ri.role_name == None
    assert ri.role_collection == None
    assert ri.role_collections == []
    assert ri.action == 'include'
    assert ri.loop == None
    assert ri.loop_control == None
    assert ri.tasks == []
    assert ri.tags == ['all']
    assert ri.when == None
    assert ri.name == None
    assert ri.delegate_to == None
    assert ri.delegate_facts == False
    assert ri.register == None
    assert ri.ignore_errors == False
    assert ri.environment == {}
    assert ri.vars == {}
    assert ri.role

# Generated at 2022-06-23 06:51:45.641616
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test for method load of class RoleInclude
    """
    assert True

# Generated at 2022-06-23 06:51:55.887340
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.requirement import RoleRequirement

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager

    from collections import namedtuple

    from units.mock.loader import DictDataLoader

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))

    variable_manager.set_host_variable('host_one', dict(ansible_ssh_pass='pass1'))
    variable_manager.set_host_variable('host_two', dict(ansible_ssh_pass='pass2'))

    play_context = PlayContext()
    play_context.port = 2222
    play_context.remote

# Generated at 2022-06-23 06:52:05.079326
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import ansible.parsing.yaml.objects
    ri = RoleInclude()

    if isinstance(ri, dict):
        raise AssertionError("Expected instance of dict, got %s" % type(ri))

    if not isinstance(ri, ansible.parsing.yaml.objects.AnsibleBaseYAMLObject):
        raise AssertionError("Expected instance of AnsibleBaseYAMLObject, got %s" % type(ri))

    test_data = {'role': 'dummy_role'}

    ri.load_data(test_data)


# Generated at 2022-06-23 06:52:13.159861
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    variable_manager = MagicMock()
    loader = MagicMock()
    play = MagicMock()
    parser = MagicMock()

    current_role_path = "/home/roy/ansible/lib/ansible/roles/test"
    parent_role = "Test Role"

    data1 = "/home/roy/ansible/lib/ansible/roles/apache"
    role_include = RoleInclude.load(data=data1, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader, parser=parser)
    assert role_include.get_name() == "apache"

    data2 = "/home/roy/ansible/lib/ansible/roles/apache, test_role"
    role_include = RoleIn

# Generated at 2022-06-23 06:52:14.967721
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-23 06:52:17.200083
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-23 06:52:26.533874
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri._role_name is None
    assert ri._role_path is None
    assert ri._role_basedir is None
    assert ri._default_vars is None
    assert ri._role_params is None
    assert ri._tasks is None
    assert ri._handlers is None
    assert ri._meta is None
    assert ri._playbook_files is None
    assert ri._playbook_dir is None
    assert ri._play is None
    assert ri._loader is None
    assert ri._variable_manager is None


# Generated at 2022-06-23 06:52:32.699268
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    play = 'test_play'
    role_basedir = 'test_role_basedir'
    variable_manager = 'test_variable_manager'
    loader = 'test_loader'
    collection_list = 'test_collection_list'
    test_RoleInclude = RoleInclude(play, role_basedir, variable_manager, loader, collection_list)
    assert test_RoleInclude.play == play
    assert test_RoleInclude.role_basedir == role_basedir
    assert test_RoleInclude.variable_manager == variable_manager
    assert test_RoleInclude.loader == loader
    assert test_RoleInclude.collection_list == collection_list

# Generated at 2022-06-23 06:52:35.393819
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    try:
        RoleInclude()
        raise Exception("Expected an error")
    except:
        pass


# Generated at 2022-06-23 06:52:39.644968
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.role import ROLE_CACHE, RoleMetadata

# Generated at 2022-06-23 06:52:41.497976
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:52:42.887186
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()

# Generated at 2022-06-23 06:52:56.060807
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    start_dir = os.getcwd()

# Generated at 2022-06-23 06:53:07.769079
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import ROLE_CACHE
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from io import open

    loader = DataLoader()
    play_context = dict(
        basedir="/playbook_dir"
    )
    inventory = dict()
    variable_manager = dict()
    all_vars = dict()


# Generated at 2022-06-23 06:53:14.552913
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # todo: implement a unit test for method load of class RoleInclude
    # some possible scenarios:
    # 1 -- data is not string, dict or AnsibleBaseYAMLObject
    # 2 -- data is string and contains comma
    # 3 -- data is string, does not contain comma, and contains name in it
    # 4 -- data is string, does not contain comma, and does not contain name in it
    pass


# Generated at 2022-06-23 06:53:26.822329
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.path import unfrackpath
    from ansible.context import CLIContext

    if not os.path.exists('/tmp/test_playbook_vars'):
        os.mkdir('/tmp/test_playbook_vars')


# Generated at 2022-06-23 06:53:28.571715
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = ""
    ri = RoleInclude()
    ri.load(data)

# Generated at 2022-06-23 06:53:29.911230
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert True
    pass

# Generated at 2022-06-23 06:53:31.563241
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:53:35.889225
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
        # ri = RoleInclude()
        # ri.load(data, play, current_role_path, parent_role, variable_manager, loader)

# Generated at 2022-06-23 06:53:49.167248
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play, Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{role_path}}'))),
            dict(action=dict(module='debug', args=dict(msg='{{role_name}}'))),
        ]
    )

    current_role_path = os.path.expanduser("~/.ansible/roles/role1")
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(role_path=current_role_path)
    variable_manager.options

# Generated at 2022-06-23 06:53:50.650815
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    assert ri

# Generated at 2022-06-23 06:53:51.796969
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: find a way to test this method withou creating a role repository
    pass

# Generated at 2022-06-23 06:53:53.661480
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert isinstance(role, RoleInclude)
    assert isinstance(role, RoleDefinition)
    assert isinstance(role, Attribute)

# Generated at 2022-06-23 06:53:54.392739
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-23 06:54:04.583952
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    with open(os.path.join(os.path.dirname(__file__), "../../test_data/include_role.yaml"), "r") as f:
        data_test = f.readlines()
        data_test = "".join(data_test)

    assert RoleInclude.load(data_test, None) is not None

# Generated at 2022-06-23 06:54:08.255446
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # need to call a class method to test
    # assert RoleInclude.load(data, play, current_role_path, variable_manager, loader) == expected, 'RoleInclude creation failed'
    pass

# Generated at 2022-06-23 06:54:18.578309
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = \
        """
        - hosts: test
          vars:
            var1: "test"
            var2: "test2"
          connection: smart
          remote_user: root
          gather_facts: False
          roles:
            - ansible.builtin
        """

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.playbook.play import Play
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
   

# Generated at 2022-06-23 06:54:26.754368
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # FIXME: remove need for the following two lines
    os.environ['ANSIBLE_CONFIG'] = ''
    os.environ['ANSIBLE_LIBRARY'] = ''

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.role import Role

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=None, variable_manager=variable_manager, host_list='tests/inventory'))

    # Load a role definition
    play_context = PlayContext()
    play_context.network_os = 'ios'

# Generated at 2022-06-23 06:54:38.842281
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_role_include = {
        'name': 'test.role',
        'services': ['http', 'mysql'],
        'dependencies': ['cron', 'nginx']
    }
    class Fake_VM():
        def __init__(self):
            self.roles_path = None
        def get_vars(self):
            return {'server_role': 'testserver'}

    class Fake_Play():
        def __init__(self):
            self.hostvars = {'testhost': {'ec2_tag_Name': 'testhost', 'ec2_tag_internal_service_name': 'testhead', 'ec2_tag_Role': 'testserver'}}
            self.ansible_vars = {}
            self.roles_path = None


# Generated at 2022-06-23 06:54:41.933910
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role = RoleInclude()
    assert role == {}, "%s" % role
    assert role.role_basedir is None, "%s" % role

    role = RoleInclude(role_basedir='role_basedir')
    assert role == {}, "%s" % role
    assert role.role_basedir == 'role_basedir', "%s" % role


# Generated at 2022-06-23 06:54:53.292699
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    variable_manager = DummyVars()