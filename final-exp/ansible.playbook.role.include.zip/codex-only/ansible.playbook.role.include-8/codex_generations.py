

# Generated at 2022-06-23 06:45:04.216056
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    ri = RoleInclude.load("sath89.oracle-xe-11g", None, "/etc/ansible/roledir", None, None, None)

    assert "sath89" == ri.get_name(), "Failed to retrieve role name"
    assert "/etc/ansible/roledir/sath89.oracle-xe-11g" == ri.get_path(), "Failed to retrieve role path"
    assert "/etc/ansible/roledir/sath89.oracle-xe-11g/meta/main.yml" == ri.get_metadata_path(), "Failed to retrieve metadata path"


# Generated at 2022-06-23 06:45:10.664396
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Creating role object with role name, role path, variable manager and loader
    role_object = RoleInclude(role_name='test1', role_path='path1', variable_manager='manager1', loader='loader1')
    # Calling method
    result = role_object.load(data=None, variable_manager=None, loader=None)
    # Asserting result
    assert result is None
# end of method test_RoleInclude_load

# Generated at 2022-06-23 06:45:21.996325
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test case for function load of class RoleInclude
    """
    data = "a"
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude(play, current_role_path, variable_manager, loader, collection_list)

    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-23 06:45:31.870293
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    if os.path.isdir("/tmp/ansible_test_galaxy_roles"):
        os.system("rm -rf /tmp/ansible_test_galaxy_roles")
    os.mkdir("/tmp/ansible_test_galaxy_roles")
    os.system("cp -r /usr/local/share/ansible_collections/ansible/dist/ansible_collections/nxos/nxos/plugins/action/nxos.py /tmp/ansible_test_galaxy_roles/nxos.py")

# Generated at 2022-06-23 06:45:40.445334
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    """
    Create a dummy play and variable_manager to test constructor of
    class RoleInclude
    """

    # Create a dummy play with variable_manager instance
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-23 06:45:41.104099
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-23 06:45:52.284968
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import collection_loader
    import shutil

    # Init Ansible play
    play_context = PlayContext()    # play context needs to have a dict of all the variable files
    play_source = dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )

# Generated at 2022-06-23 06:45:59.155732
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print()
    role_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'roles/test_collection.test_role')
    current_role_path = os.path.join(role_path, 'tasks')
    ri = RoleInclude.load('name=test_collection.test_role', play=None, current_role_path=current_role_path, parent_role=None)
    assert ri._role_name == 'test_collection.test_role'
    assert ri._role_path == role_path
    print("PASS")

# Generated at 2022-06-23 06:46:10.404174
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from io import StringIO

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost")

# Generated at 2022-06-23 06:46:17.222691
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    R_I = RoleInclude
    R_I.load(data = 'foo', play = 'play', current_role_path = 'current_role_path', parent_role = 'parent_role', variable_manager = 'variable_manager', loader = 'loader')


if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-23 06:46:25.935285
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test with a string as data parameter
    test_role_include = RoleInclude()
    data_string = 'role_name'
    try:
        test_role_include.load(data=data_string)
    except TypeError as e:
        (e)
        assert False
    except ValueError as e:
        assert False
    except AttributeError as e:
        assert False
    except:
        assert False
    else:
        assert True

    # Test with a dict as data parameter
    data_dict = {'role_name1': 'role_name1'}
    try:
        test_role_include.load(data=data_dict)
    except TypeError as e:
        assert False
    except ValueError as e:
        assert False
    except AttributeError as e:
        assert False
   

# Generated at 2022-06-23 06:46:31.733486
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager._options = {'vault_password': "pass"}
    variable_manager._extra_vars = dict(
        vault_password='pass',
        ansible_connection='local',
        ansible_network_os='default'
    )
    variable_manager._vault = VaultLib(variable_manager._options)

# Generated at 2022-06-23 06:46:43.168846
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play import Play
    play = Play().load(dict(
        name = "test play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [ 'some_role' ],
    ), variable_manager=dict(), loader=dict())

    role_req1 = RoleRequirement.load("test_role")
    role_req2 = RoleRequirement.load("test_role2")
    role_req3 = RoleRequirement.load("test_role3")
    assert isinstance(role_req1, RoleRequirement)
    assert isinstance(role_req2, RoleRequirement)
    assert isinstance(role_req3, RoleRequirement)

    role_reqs = {}

# Generated at 2022-06-23 06:46:45.898288
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    example_role = {'name': 'example'}
    role = RoleInclude.load(example_role)
    assert role.get_name() == 'example'
    assert role.get_path() == None

# Generated at 2022-06-23 06:46:52.023200
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None) is not None

# Generated at 2022-06-23 06:47:03.620674
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    # role_definitions = []

# Generated at 2022-06-23 06:47:05.577966
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    assert RoleInclude().__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-23 06:47:17.737890
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play

    ri = RoleInclude(play=None, role_basedir='/path/to/', variable_manager=None, loader=None, collection_list=[])
    assert isinstance(ri, RoleDefinition)
    assert ri.get_name() == 'all'
    assert ri.get_parent() is None
    assert ri._play is None
    assert ri._role_basedir == '/path/to/'
    assert ri._variable_manager is None
    assert ri._loader is None
    assert ri._collection_list == [], type(ri._collection_list)

    p = Play()
    ri = RoleInclude(play=p, role_basedir=None, variable_manager=None, loader=None, collection_list=[])
    assert ri

# Generated at 2022-06-23 06:47:21.817229
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = {
        'role': 'Apache',
        'tasks': [
            {'action': {'module': 'file', 'args': {'path': '/tmp/whatever'}}}
        ]
    }
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'myvar': 'good'}
    loader = DataLoader()
    role_include = RoleInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert role_include is not None, "role include should not be none"

# Generated at 2022-06-23 06:47:33.991493
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class UserRole:
        def __init__(self, name, version, collection_name):
            self.name = name
            self.role_name = name
            self.version = version
            self.collection_name = collection_name

    class TestPlay:
        def __init__(self, roles_path=None, role_collection_load=None, role_collection_path=None):
            self.roles_path = roles_path
            self.role_collection_load = role_collection_load
            self.role_collection_path = role_collection_path

    test_roles_path = [
        '/tmp/example/roles',
        '/etc/ansible/roles'
    ]

# Generated at 2022-06-23 06:47:45.574254
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native
    from ansible.playbook import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleFileConfig
    from ansible.utils.path import unfrackpath

    # Test load with non string or dict data
    role_path = unfrackpath('./_data/test_RoleInclude')
    collection_config = AnsibleCollectionConfig(unfrackpath('./_data/test_RoleInclude_test_collection'))
    collection_config.validate()

# Generated at 2022-06-23 06:47:54.952265
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_path = "test-ansible-role-repo"
    role_include = RoleInclude(role_basedir=role_path)
    assert(role_include._role_basedir == role_path)
    assert(role_include._name == None)
    assert(role_include._task_blocks == [])
    assert(role_include._handlers == {})
    assert(role_include._default_vars == {})
    assert(role_include._meta_dir == None)
    assert(role_include._role_dir == None)
    assert(role_include._role_name == None)

# Generated at 2022-06-23 06:48:03.168038
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    data = {'role': 'role1'}
    ri = RoleInclude(_load=False)
    res = ri.load_data(data, variable_manager=None, loader=None)
    assert res is True
    assert ri.get_name() == 'role1'

    data = {'tasks': 'overridden'}
    ri = RoleInclude(_load=True)
    res = ri.load_data(data, variable_manager=None, loader=None)
    assert res is True
    assert ri.get_name() == 'role1'

# Generated at 2022-06-23 06:48:04.437568
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    role_include = RoleInclude()
    assert role_include is not None

# Generated at 2022-06-23 06:48:16.867876
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.module_utils import basic
    from ansible.module_utils.six import StringIO

    class TestModule(object):
        def __init__(self, argument_spec, bypass_checks=False):
            self.argument_spec = argument_spec
            self.check_mode = bypass_checks
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

    class Play(object):
        def __init__(self, play_hosts):
            self.play_hosts = play_hosts

    class Options(object):
        def __init__(self, verbosity=1):
            self.verbosity = verbosity

    class Inventory(object):
        def __init__(self, hosts=None, iterator=None, loader=None):
            self.hosts = hosts

# Generated at 2022-06-23 06:48:20.266801
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None)
    assert isinstance(roleInclude, RoleDefinition) and not isinstance(roleInclude, RoleRequirement)

# Generated at 2022-06-23 06:48:31.613309
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager

    display = Display()
    loader = None
    collection_list = None
    iterator = None

    play = Play().load(
        dict(_hosts="localhost",
             gather_facts=False,
             roles="test_role"
             ),
        variable_manager=VariableManager(), loader=loader, collection_list=collection_list
    )

    play_context = play.set_context()

    # Constructor of class RoleInclude
    ri = RoleInclude(play=play, role_basedir="test_role", variable_manager=VariableManager(), loader=loader, collection_list=collection_list)

    # r

# Generated at 2022-06-23 06:48:40.592446
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    variable_manager = None
    loader = None
    collection_list = None
    play = None
    current_role_path = None
    parent_role = None

    # test for invalid role definition
    data = ['a', 'b']
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleError as e:
        assert 'Invalid role definition' in e.message

    # test for invalid old style role requirement
    data = 'a,b'
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleError as e:
        assert 'Invalid old style role requirement' in e.message


# Generated at 2022-06-23 06:48:51.002215
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    var_manager = VariableManager()
    loader = DataLoader()
    play = Play().load({}, loader=loader, variable_manager=var_manager, constructor=RoleInclude)
    loaded_play = RoleInclude(play=play, role_basedir='', variable_manager=var_manager, loader=loader)

    assert loaded_play.play == play
    assert loaded_play.role_basedir == ''
    assert loaded_play.variable_manager == var_manager
    assert loaded_play.loader == loader

# Generated at 2022-06-23 06:48:58.008430
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    os.environ['ANSIBLE_ROLES_PATH']='/Users/michael/ansible/roles'
    ri = RoleInclude()
    return ri

# Generated at 2022-06-23 06:49:03.910047
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, None)
    
    role_include = RoleInclude.load('some_role', None, '/etc', None, None, loader)
    assert(isinstance(role_include, RoleRequirement))

# Generated at 2022-06-23 06:49:12.324555
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    Unit test for method load of class RoleInclude.
    '''
    # RoleInclude.load() without parameters
    # This should raise an exception
    try:
        a = RoleInclude.load()
    except Exception as e:
        a = '{0}'.format(e)
    assert a == 'load() takes at least 5 arguments (1 given)'
    # RoleInclude.load() with a string_types
    # This should return a RoleInclude Object
    try:
        a = RoleInclude.load('foo')
    except SystemExit:
        a = 'Error'
    assert isinstance(a, RoleInclude)
    # RoleInclude.load() with a string_type with ","
    # This should raise an exception

# Generated at 2022-06-23 06:49:22.273800
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    mydata = {}
    mydata['name'] = 'testrole'
    mydata['tasks'] = []

    myrole = RoleInclude.load(mydata,
                        play=None,
                        current_role_path=None,
                        parent_role=None,
                        variable_manager=None,
                        loader=None,
                        collection_list=None
                        )
    print(myrole)
    print(myrole.name)
    print(myrole.tasks)

    for role in myrole.default_tasks:
        print(role)


# Generated at 2022-06-23 06:49:31.530033
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    C.DEFAULT_HOST_LIST = './tests/inventory/ansible_hosts'

    base_dir = './tests/playbooks'

# Generated at 2022-06-23 06:49:34.765740
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    result = role_include.load(data="test", play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    

# Generated at 2022-06-23 06:49:45.447921
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    data = dict(
        name="test",
        hosts=["test_host"],
        user="test_user",
    )
    pc = PlayContext()
    pc.serialize = data

    vm = VariableManager()
    hostvars = HostVars(hostname="test_host", variables={"ansible_user": "root"}, port=22, play_context=pc)
    vm.add_host_vars("test_host", hostvars)

    ri = RoleInclude(play=None, role_basedir=None, variable_manager=vm)

    assert ri._play == None
    assert ri._role_basedir

# Generated at 2022-06-23 06:49:51.108293
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude.load(
        {'role': 'test_RoleInclude_load', 'vars': {'test_RoleInclude_load': True}},
        {
            'hosts': ['test_RoleInclude_load'],
            'tasks': [{'name': 'test_RoleInclude_load'}]
        })


# Generated at 2022-06-23 06:49:58.855215
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    variable_manager = None
    loader = None
    play1 = Play()
    play2 = Play()

    ri = RoleInclude(play=play1)

    # first element of data is a string, so a AnsibleParserError will raise
    data1 = ['/tmp/test.yml']
    try:
        ri.load(data1, play1, current_role_path='.', variable_manager=variable_manager, loader=loader)
    except AnsibleParserError:
        pass

    # data is a dict, so a AnsibleParserError will raise
    data2 = {'roles': [{'name': 'test'}]}

# Generated at 2022-06-23 06:50:08.381126
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_obj = {"name":"role1","hosts":"host1"}
    role_name = "role"
    host_name = "host"
    play = AnsiblePlay(hosts=host_name)
    play.add_var("role_name",role_name)
    play.add_var("host_name",host_name)
    play.add_var("play_name",play)
    ri = RoleInclude(play=play, role_basedir=role_name, variable_manager=variable_manager, loader=loader)
    ri.load(role_obj,play,current_role_path=role_name)



# Generated at 2022-06-23 06:50:16.059429
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    print("Test role include's constructor")

    ri = RoleInclude()

    # The attributes of class RoleInclude
    print("\tThe attributes of class RoleInclude:")
    all_attributes = [attr for attr in dir(ri) if not callable(getattr(ri, attr)) and not attr.startswith("__") and attr != '_parent']
    for attr in all_attributes:
        print("\t\t" + attr)

# Generated at 2022-06-23 06:50:21.013104
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    ri = RoleInclude()
    assert ri.role_basedir == ''
    assert ri.play is None
    assert ri.variable_manager is None
    assert ri.loader is None
    assert ri.collection_list is None

# Generated at 2022-06-23 06:50:30.931615
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    class TestClass:
        pass

    # Test for constructor with play and role_basedir
    ri = RoleInclude(play=TestClass(), role_basedir='/home/test')
    assert ri.role_basedir == '/home/test'
    assert ri.play == TestClass()

    # Test for constructor with play, role_basedir and variable_manager
    ri = RoleInclude(play=TestClass(), role_basedir='/home/test', variable_manager='test1')
    assert ri.role_basedir == '/home/test'
    assert ri.play == TestClass()
    assert ri.variable_manager == 'test1'

    # Test for constructor with play, role_basedir, variable_manager and loader

# Generated at 2022-06-23 06:50:44.258810
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.role.definition
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.parsing.vault

    fake_loader = ansible.parsing.dataloader.DataLoader()
    fake_loader._basedir = os.getcwd()
    fake_variable_manager = ansible.vars.manager.VariableManager()
    fake_variable_manager.extra_vars = {'user_name': 'test_user', 'user_email': 'test_user@123.com'}
    fake_variable_manager.options_vars = {'roles_path': '/some/roles/path'}
    fake_variable_manager.set_inventory(('localhost', 'all'))

    ansible.parsing.v

# Generated at 2022-06-23 06:50:51.931806
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True


#   def load_data(self, data, variable_manager=None, loader=None):
#
#       # First, create the RoleRequirement() object
#       data = super(RoleInclude, self).load_data(data, variable_manager=variable_manager, loader=loader)
#
#       if self.task_block:
#           raise AnsibleParserError("role include statements do not support task blocks")
#
#       # Set task include level
#       self._role = data.get_name()
#       self._role_path = data.get_role_path()
#       self._role_name = os.path.basename(self._role_path)
#       self._role_params = data.get_role_params()
#
#       self._load_dependencies()
#       self._post

# Generated at 2022-06-23 06:50:52.975637
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test __init__
    a = RoleInclude()

# Generated at 2022-06-23 06:50:54.846778
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert ri is not None

# Generated at 2022-06-23 06:51:01.986771
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.utils.display import Display
    display = Display()
    loader = None
    variable_manager = None
    role_definition = RoleInclude(loader=loader, variable_manager=variable_manager)
    role_definition.display = display
    role_definition.__init__(loader=loader, variable_manager=variable_manager)
    assert loader == role_definition._loader
    assert variable_manager == role_definition._variable_manager


# Generated at 2022-06-23 06:51:08.112783
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {
        'role': 'foobar',
        'delegate_to': 'baz',
        'delegate_facts': True
    }
    role_include = RoleInclude.load(data)
    assert role_include._delegate_to == 'baz'
    assert role_include._delegate_facts == True

# Generated at 2022-06-23 06:51:17.136018
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    # test if can create the object
    ri = RoleInclude()
    assert ri
    # test if the object has attribute: _attributes
    assert ri._attributes
    # test if the element in _attributes is instance of class Attribute
    for v in ri._attributes:
        assert isinstance(v, Attribute)
    # test if the object has attribute: _load_name
    assert ri._load_name



# Generated at 2022-06-23 06:51:20.622421
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert(ri.__class__ == RoleInclude)


# Generated at 2022-06-23 06:51:32.407442
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Load(self, data, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None):
    # First: Test play is none
    data = {'name': 'test_role', 'version': '1.0'}
    variable_manager = object()
    loader = object()
    collection_list = object()
    ri = RoleInclude()
    ri = ri.load(data, None, None, None, variable_manager, loader, collection_list)
    assert ri is not None
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri.role_name, string_types)
    assert ri.role_name == data['name']
    assert isinstance(ri.role_version, string_types)


# Generated at 2022-06-23 06:51:34.256682
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
    # TODO: Create unit test for RoleInclude



# Generated at 2022-06-23 06:51:38.849421
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    result = isinstance(RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None), RoleInclude)
    assert result == True

# Generated at 2022-06-23 06:51:40.715725
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    d = RoleInclude()
    assert d is not None


# Generated at 2022-06-23 06:51:52.365197
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    import sys
    cwd = os.getcwd()
    print('INFO: Current work directory: %s' % cwd)
    sys.path.insert(0, cwd + "/library/")
    from ansible.module_utils import ssh as sshModule
    from ansible.module_utils.network.common.utils import transform_commands
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.utils import dict_merge
    from ansible.module_utils import basic
    from ansible.module_utils.network.dmos.dmos import run_commands
    from ansible.parsing.dataloader import DataLoader

    # Instantiate NetworkConfig with empty data and network_os as 'dmos'

# Generated at 2022-06-23 06:52:03.837263
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.cli.adhoc import AdHocCLI
    import json
    import os

    # Block test

# Generated at 2022-06-23 06:52:05.574114
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    try:
        test_obj = RoleInclude()
    except:
        pass

# Generated at 2022-06-23 06:52:06.727988
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri, RoleDefinition)

# Generated at 2022-06-23 06:52:11.886387
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    result = []
    class play:
        pass
    ri = RoleInclude(play=play, role_basedir=".", variable_manager=None, loader=None, collection_list=None)
    result.append(ri.get_dep_chain() == [])
    result.append(ri.get_name() == "")
    result.append(ri.get_role_path() == "")

    return all(result)


# Generated at 2022-06-23 06:52:14.333742
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, 'Test Not Implemented'


# Generated at 2022-06-23 06:52:26.048687
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    load = RoleInclude.load

    class FakePlay(object):
        def __init__(self):
            self.roles_path = '/does/not/exist'

    class FakeVarsManager(object):
        def __init__(self):
            self.extra_vars = dict()

    class AnsibleFakeYamlObject(object):
        def __init__(self):
            pass

    class FakeLoader(object):
        def __init__(self):
            pass

    class FakeCollection(object):
        def __init__(self):
            pass

    # Without params
    try:
        load(data=None, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    except Exception:
        pass

# Generated at 2022-06-23 06:52:33.279303
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # In the old style, the inclusion was a string specifying the role name
    # and optionally the version of the role to use.

    # This is the old style of specifying a role: a string
    ri1 = RoleInclude.load("role1", None, None, None)
    assert ri1.get_name() == "role1"
    assert len(ri1.get_role_dependencies()) == 0

    # This is the old style specifying a role and a version
    ri2 = RoleInclude.load("role2,v1.0", None, None, None)
    assert ri2.get_name() == "role2"
    assert ri2.get_role_dependency("role2").get_name() == "role2"
    assert ri2.get_role_dependency("role2").get_

# Generated at 2022-06-23 06:52:40.986490
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.role.definition
    import ansible.playbook.role.requirement
    import ansible.vars.manager
    import ansible.parsing.dataloader
    import ansible.inventory.manager
    import ansible.utils.vars

    yml_role_def = u'---\n- name: apache\n  sudo: yes\n\n'
    from ansible.parsing.yaml.objects import AnsibleUnicode
    yml_role_req = AnsibleUnicode(u'apache')

    # TODO
    # inventory = ansible.inventory.manager.InventoryManager(loader=ansible.parsing.dataloader.DataLoader())
    # variable_manager = ansible.vars.manager.VariableManager(loader=ansible.pars

# Generated at 2022-06-23 06:52:54.589096
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Executed by py.test test_playbook.py -k test_RoleInclude_load
    # The test will fail unless the following is true
    # 1. The playbook fails to run, as collections are not installed
    # 2. The playbook runs, as collections are installed

    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from collections import namedtuple

    # test the RoleInclude load method
    # with a named tuple
    test_data1 = namedtuple('test_data1', 'first second')
    test_data2 = namedtuple('test_data2', 'first second')
    test_data3 = namedtuple('test_data3', 'name')

# Generated at 2022-06-23 06:53:06.252686
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test load method of class RoleInclude
    """
    ri = RoleInclude()
    try:
        ri.load(None)
        assert False # Should not reach here
    except AnsibleParserError:
        assert True

    try:
        ri.load('1,2,3')
        assert False # Should not reach here
    except AnsibleError:
        assert True

    try:
        ri.load([])
        assert False # Should not reach here
    except AnsibleParserError:
        assert True

    try:
        ri.load('a')
        assert False
    except AnsibleParserError:
        assert True

    ri.load({'role':'a'})


# Generated at 2022-06-23 06:53:11.005224
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ''' 
    Unit test for checking if the load of class RoleInclude works correctly
    ''' 
    ri=RoleInclude.load('role', None)
    assert ri._role_name == 'role'
    ri=RoleInclude.load('role,master', None)
    assert ri._role_name == 'role'
    assert ri._role_name == 'master'

# Generated at 2022-06-23 06:53:19.290175
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    assert RoleInclude.load(data="blah",
                            play=None,
                            current_role_path=None,
                            parent_role=None,
                            variable_manager=None,
                            loader=None,
                            collection_list=None).get_name() == 'blah'

    assert RoleInclude.load(data="blah",
                            play=None,
                            current_role_path=None,
                            parent_role=None,
                            variable_manager=None,
                            loader=None,
                            collection_list=None)._role_name == 'blah'


# Generated at 2022-06-23 06:53:30.718905
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    loader = None
    collection_list = None

    test_play = Play()
    test_play.playbook = "someplaybook.yml"
    test_play.hosts = [ "host1", "host2"]

    test_varmgr = VariableManager()

    test_include = RoleInclude(play=test_play, variable_manager=test_varmgr, loader=loader, collection_list=collection_list)

    assert test_include.role_basedir is None
    assert test_include.play_context == play_context
    assert test_include.vars == {}
    assert test_include.default_vars

# Generated at 2022-06-23 06:53:33.803924
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    pass


# Load side-effect for constructor of class RoleInclude

# Generated at 2022-06-23 06:53:35.615075
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    roleInclude = RoleInclude()
    assert roleInclude is not None

# Generated at 2022-06-23 06:53:42.461925
# Unit test for constructor of class RoleInclude
def test_RoleInclude():

    class test_play:
        pass

    ds = RoleInclude(play=test_play())
    assert isinstance(ds, RoleInclude)

    ds = RoleInclude.load(None)
    assert isinstance(ds, RoleInclude)

# Generated at 2022-06-23 06:53:51.152548
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    data = {'a': 1, 'b': 2}

    if not isinstance(data, AnsibleBaseYAMLObject):
        data = AnsibleBaseYAMLObject(data)

    data.ansible_pos = (1, 0)

    # assert isinstance(data, AnsibleBaseYAMLObject)
    # assert isinstance(data['a'], int)

    # # If use loop to iterate each element of the data,
    # # it will raise error:
    # # TypeError: 'int' object is not iterable
    # # Because the type of element in data is int, not dict
    # for item in data:
    #     p = item.__class__.__name__
    #     print(p)

   

# Generated at 2022-06-23 06:53:58.068915
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

# Generated at 2022-06-23 06:54:08.838694
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import definition as role_definition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    ri = RoleInclude.load(
        {'role': 'webservers',
         'tasks': [
             {'action': {'module': 'setup'}},
         ]},
        'play',
        current_role_path=None,
        parent_role=None,
        variable_manager=None,
        loader=None,
        collection_list=None
    )

    assert isinstance(ri, role_definition.RoleDefinition)

    assert isinstance(ri._role_name, string_types)

# Generated at 2022-06-23 06:54:14.764148
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    #inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager()

    ri = RoleInclude()
    ri.load({'role': 'test'}, loader, variable_manager)

# Generated at 2022-06-23 06:54:19.857120
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    data = 'foo'
    collection_list = []
    instance = RoleInclude.load(data, play=None, current_role_path=None, parent_role=None,
                                variable_manager=None, loader=None, collection_list=collection_list)
    assert isinstance(instance, RoleInclude)
    assert instance.__class__.__name__ == 'RoleInclude'

# Generated at 2022-06-23 06:54:32.391052
# Unit test for constructor of class RoleInclude
def test_RoleInclude():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = {'test_var1': 'test_value1', 'test_var2': 'test_value2'}
    variable_manager.set_inventory(loader.load_inventory('hosts'))
    variable_manager.set_variable_manager(variable_manager)
    variable_manager.set_loader(loader)
    variable_manager.set_options(verbosity=0)

# Generated at 2022-06-23 06:54:37.846416
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {'name': 'test'}
    var = None
    loader = None
    play = None
    ri = RoleInclude.load(data, play, var, var, loader)
    assert ri is not None

# Generated at 2022-06-23 06:54:46.093897
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Load data for role definition
    """
    # Test for case where data is string type and ',' is in data
    # Here we expect to catch an exception as error message
    
    data_1 = "bad,data"
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    assert RoleInclude.load(data_1, play, current_role_path, parent_role, variable_manager, loader, collection_list) == AnsibleError("Invalid old style role requirement: bad,data")
    
    # Test for case where data is string type but ',' is not in data
    # Also test if the returned value is a RoleInclude object
    data_2 = "name"

# Generated at 2022-06-23 06:54:54.064339
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    # Test for string
    data = 'test'
    assert isinstance(ri.load(data),RoleInclude)
    # Test for dict and AnsibleBaseYAMLObject
    data = {'test':'test'}
    assert isinstance(ri.load(data),RoleInclude)
    # Test for  ',' in data
    ri = RoleInclude()
    data = 'test,test'
    try:
        assert isinstance(ri.load(data),RoleInclude)
        assert False
    except:
        assert True # Test properly 


if __name__ == '__main__':
    import __main__
    test_RoleInclude_load()