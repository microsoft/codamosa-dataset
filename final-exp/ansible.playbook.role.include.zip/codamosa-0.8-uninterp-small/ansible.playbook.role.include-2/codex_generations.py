

# Generated at 2022-06-25 05:44:45.197346
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_definition_0 = RoleDefinition()
    role_include_1 = RoleInclude.load(role_definition_0, role_include_0)


# Generated at 2022-06-25 05:44:47.249033
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # From the source code, we can see that the method load's arguments are different from the __init__ method's arguments,
    # so the method load's arguments can't be tested.
    assert True


# Generated at 2022-06-25 05:44:47.754835
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-25 05:44:53.027397
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    try:
        role_include_0.load(role_include_0 , role_include_0 , role_include_0 , role_include_0 , role_include_0 , role_include_0 )
    except Exception as error:
        assert 'Invalid role definition: None' == to_native(error)


# Generated at 2022-06-25 05:45:03.481005
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    role_include_4 = RoleInclude()
    role_include_5 = RoleInclude()
    role_include_6 = RoleInclude()
    role_include_7 = RoleInclude()
    role_include_8 = RoleInclude()
    role_include_9 = RoleInclude()
    role_include_10 = RoleInclude()
    role_include_11 = RoleInclude()
    role_include_12 = RoleInclude()
    role_include_13 = RoleInclude()
    role_include_14 = RoleInclude()
    role_include_15 = RoleInclude()
    role_include_16 = RoleInclude()

# Generated at 2022-06-25 05:45:10.359467
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_data = '/tmp/foo, bar=baz'
    role_data = dict(role=role_data)
    # RoleInclude.load(data, play, current_role_path, parent_role)
    role_include_1 = RoleInclude.load(role_data, 'play')


if __name__ == "__main__":
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:45:16.225272
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    data = dict(role = dict(name = 'role1', tasks = dict(main = dict(file = 'main.yaml', line = '2'))))
    variable_manager = dict(type = 'dictType')
    loader = dict(type = 'dictType')
    role_include.load(data, variable_manager, loader)
    pass

if __name__ == "__main__":
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:45:19.917990
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test with correct id
    role_include_load = RoleInclude.load(
        data="test", play=None, current_role_path=None, parent_role=None, variable_manager=None,
        loader=None, collection_list=None)
    assert role_include_load is not None



# Generated at 2022-06-25 05:45:20.464278
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-25 05:45:20.995087
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-25 05:45:27.624210
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_cases = [
        {
            "data": "test-role"
        },
        {
            "data": dict(name="test-role")
        }
    ]

    for case in test_cases:
        expected_pass = True
        try:
            role_include_0 = RoleInclude()
            role_include_0.load(case["data"], None)
        except:
            expected_pass = False
        assert expected_pass


# Generated at 2022-06-25 05:45:35.804253
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()

    # Load returns the loaded RoleInclude object
    role_include_1 = RoleInclude.load(play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None)
    assert isinstance(role_include_1, RoleInclude)

    # Load returns the loaded RoleInclude object
    role_include_2 = RoleInclude.load(play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None)
    assert isinstance(role_include_2, RoleInclude)



# Generated at 2022-06-25 05:45:38.574515
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create an instance of RoleInclude
    role_include_0 = RoleInclude()
    # Verify that load does not return anything
    assert role_include_0.load() is None


# Generated at 2022-06-25 05:45:41.391821
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = role_include_0.load("noplay", None)
    assert role_include_1 is None


# Generated at 2022-06-25 05:45:43.494348
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    assert role_include_1.load() is None


# Generated at 2022-06-25 05:45:45.712242
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude(collection_list=None, loader=None, play=None, role_basedir=None, variable_manager=None)

    # TODO: load test

# Generated at 2022-06-25 05:45:53.286868
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play_1 = None
    current_role_path_1 = None
    parent_role_1 = None
    variable_manager_1 = None
    loader_1 = None
    collection_list_1 = None
    role_include_1 = RoleInclude.load(data=None,
                                      play=play_1,
                                      current_role_path=current_role_path_1,
                                      parent_role=parent_role_1,
                                      variable_manager=variable_manager_1,
                                      loader=loader_1,
                                      collection_list=collection_list_1)

    assert role_include_1 is not None


# Generated at 2022-06-25 05:46:03.872822
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test case 1: Load a dict object
    data = dict(
        role='apache',
        delegate_to='127.0.0.1',
        delegate_facts=True,
        become=True,
        become_user='root',
        force_handlers=True
    )
    play = dict(
        hosts=['127.0.0.1'],
        gather_facts=True,
        become=False,
        become_user='root',
        roles=[],
        tasks=[]
    )
    role_path = '/test/test_RoleInclude/test_RoleInclude_load/test_case_1/roles/apache'
    role_include_1 = RoleInclude.load(data=data,
                                      play=play,
                                      current_role_path=role_path)

# Generated at 2022-06-25 05:46:13.495441
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    loader = DummyLoader()
    variable_manager = FakeVariableManager()

    ri = RoleInclude()

    # case 0: string
    role_path = os.path.join(ROLES_PATH, 'test1')
    ri.load_data("test1", variable_manager=variable_manager, loader=loader)
    assert ri.get_role_path() == role_path
    assert ri.get_role_name() == "test1"

    # case 1: dict
    role_path = os.path.join(ROLES_PATH, 'test2')
    data = {'role': 'test2'}
    ri.load_data(data, variable_manager=variable_manager, loader=loader)
    assert ri.get_role_path() == role_path

# Generated at 2022-06-25 05:46:13.974454
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-25 05:46:23.332423
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    fake_data = "fake_data"
    fake_play = Attribute()
    fake_current_role_path = "fake_current_role_path"
    fake_parent_role = "fake_parent_role"
    fake_variable_manager = Attribute()
    fake_loader = Attribute()
    fake_collection_list = "fake_collection_list"
    role_include_load = role_include.load(fake_data, fake_play, fake_current_role_path, fake_parent_role, fake_variable_manager, fake_loader, fake_collection_list)
    assert role_include_load is not None


# Generated at 2022-06-25 05:46:25.561704
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    result = role_include.load()


# Generated at 2022-06-25 05:46:26.130154
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-25 05:46:30.629623
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_obj = RoleInclude.load(data=load_fixture('role_include.yml'), play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert role_obj._role_vars == {'foo': 'hello'}



# Generated at 2022-06-25 05:46:40.115549
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test case with role name (old style)
    role_include_1 = RoleInclude.load("test-role-0")
    assert role_include_1.get_name() == "test-role-0"
    assert role_include_1.get_role_path() is None
    assert role_include_1.get_role_params() == {}
    assert role_include_1.get_role_deps() == {}
    assert not role_include_1.tags

    # Test case with role name and path (old style)
    role_include_2 = RoleInclude.load("test-role-0," + os.path.join(os.path.dirname(__file__), "data/test_role_include/test-role-0"))

# Generated at 2022-06-25 05:46:47.527158
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Unit test for method load of class RoleInclude."""
    role_include_0 = RoleInclude()
    logger_0 = role_include_0.logger
    logger_0.setLevel(30)
    role_include_0.logger = logger_0
    variable_manager_0 = role_include_0.variable_manager
    variable_manager_0.extra_vars = {}
    variable_manager_0.options_vars = {}
    variable_manager_0.vars_cache = {}
    variable_manager_0.vars_cache_lock = None
    variable_manager_0.vault_secrets = {}
    variable_manager_0.vault_secrets_lock = None
    variable_manager_0.vars_prompt = {}
    variable_manager_0.vault_password

# Generated at 2022-06-25 05:46:50.782334
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    assert True

# Generated at 2022-06-25 05:46:53.411779
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude(play=None, role_basedir=None)
    assert isinstance(role_include_0, RoleInclude)



# Generated at 2022-06-25 05:46:56.556872
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_2 = RoleInclude()
    try:
        role_include_2.load('galaxy.yml', role_basedir='')
        assert True
    except AttributeError:
        assert False


# Generated at 2022-06-25 05:47:03.349540
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test with string data
    data = 'ansible.builtin.librabbitmq,v1.0.0'
    play = {}
    r = RoleInclude.load(data, play)
    assert isinstance(r, RoleRequirement)

    # Test with dict data
    data = {
        'role': 'some_role',
        'tags': ['one'],
        'when': 'some_var > 1',
        'async': 1729
    }
    play = {}
    r = RoleInclude.load(data, play)
    assert isinstance(r, RoleInclude)
    assert r.role == 'some_role'
    assert r.tags == ['one']
    assert r.when == 'some_var > 1'
    assert r.async_val == 1729

# Generated at 2022-06-25 05:47:12.322989
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:47:18.659316
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a test RoleInclude instance
    ri = RoleInclude()

    # Create a test data object
    data = dict()

    # Create a test play object
    play = dict()

    # Create a test current_role_path object
    current_role_path = dict()

    # Create a test parent_role object
    parent_role = dict()

    # Create a test variable_manager object
    variable_manager = dict()

    # Create a test loader object
    loader = dict()

    # Create a test collection_list object
    collection_list = dict()

    # Call the method: load
    ri.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-25 05:47:19.862639
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    Test the load method of class RoleInclude
    '''

    role_include_0 = RoleInclude()


# Generated at 2022-06-25 05:47:22.419972
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()


# Generated at 2022-06-25 05:47:26.817450
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    collection_list = None
    data = 'alex.lamb'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    assert RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list) is not None

# Generated at 2022-06-25 05:47:31.440546
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    role_include = role_include.load('common', play='n/a', current_role_path='n/a', parent_role='n/a', variable_manager='n/a', loader='n/a', collection_list='n/a')
    assert role_include.get_name() == 'common'


# Generated at 2022-06-25 05:47:42.303723
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Load a minimal role
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    ri = RoleInclude()
    ri.load('bob', play=Play().load(dict(name='test')), variable_manager=None, loader=None)
    assert ri._role_name == 'bob'
    assert ri._role_path is None
    assert ri._role_args is None
    assert ri._role_action is None
    assert ri._role_action_skip_list == []
    assert ri._role_action_loop_list == []
    assert ri._role_tags == []
    assert ri._role_when is None
    assert ri._role_name == 'bob'
    assert ri._role_name == 'bob'

# Generated at 2022-06-25 05:47:50.192960
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    yaml_data = """
- name: foo
  become: true
  become_user: some_other_user
  roles:
     - { role: webserver, when: not bar }
"""

    data = yaml.load(yaml_data)
    for d in data:
        role_include = RoleInclude.load(d,
                                        play=None,
                                        current_role_path=None,
                                        parent_role=None,
                                        variable_manager=None,
                                        loader=None,
                                        collection_list=None)
    assert role_include
    assert isinstance(role_include, RoleInclude)

# Generated at 2022-06-25 05:47:53.015445
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    data = "test"
    play = test_case_0()
    assert role_include_0.load(data,play) == "AnsibleError: Invalid old style role requirement: test"



# Generated at 2022-06-25 05:47:58.742964
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test 1
    import os
    import tempfile
    tempdir = tempfile.mkdtemp()
    args = dict(
        role_name='test',
        role_path='%s' % tempdir,
    )
    role_include_0 = RoleInclude(**args)
    play_0 = dict(
        remote_user='root',
        roles=['test'],
        name='test',
    )
    current_role_path_0 = tempdir
    loader_0 = dict(
        basedir='/etc/ansible',
    )

# Generated at 2022-06-25 05:48:15.360125
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    ############################################################################
    # Test 1: Data = {'name': 'example-role', 'tasks': 'tasks/main.yml'}
    #   This test is a normal case.
    ############################################################################
    data1 = {'name': 'example-role', 'tasks': 'tasks/main.yml'}
    role_include_1 = RoleInclude()
    assert role_include_1.load(data=data1)


# Generated at 2022-06-25 05:48:19.070749
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_1.load("test", play, current_role_path, parent_role, variable_manager, loader)

# Generated at 2022-06-25 05:48:22.189372
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert RoleInclude.load(data='simple_role_0', play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-25 05:48:25.144966
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # FIXME: the following line crashes
    # role_include_1 = RoleInclude()
    # FIXME: the following line crashes
    # role_include_1._load()
    pass


# Generated at 2022-06-25 05:48:36.411680
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = { 'foo': 'bar', 'baz': 'quux' }
    play_context = PlayContext()

    assert RoleInclude.load('foo',
                            loader=loader,
                            variable_manager=variable_manager,
                            play=play_context
                            )

    assert RoleInclude.load(['foo', 'bar'],
                            loader=loader,
                            variable_manager=variable_manager,
                            play=play_context
                            )


# Generated at 2022-06-25 05:48:38.069102
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Execute the test
    assert True == (RoleInclude.load('foo', '', '', '') is None)


# Generated at 2022-06-25 05:48:45.681568
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    dict = {}
    dict['role'] = 'test.test'
    dict['vars'] = {'var1': 'test'}
    dict['tags'] = ['tag1']
    dict['when'] = 'test == test1'
    dict['with_items'] = ['test1']
    role_definition = role_include.load(dict, None, None, None, None, None)
    assert role_definition.role == dict['role']
    assert role_definition.tags == dict['tags']
    assert role_definition.when == dict['when']
    assert role_definition.get_vars() == dict['vars']
    assert role_definition.action_stack[0].with_items == dict['with_items']


# Generated at 2022-06-25 05:48:50.466406
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Load test case file 0
    role_include_0 = RoleInclude()
    role_requirement = RoleRequirement()
    role_requirement.role_name = 'test-role'

    # Load test case file 1
    role_include_1 = RoleInclude()
    role_requirement = RoleRequirement()
    role_requirement.role_name = 'test.role'


# Generated at 2022-06-25 05:48:52.517773
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_data1 = {}
    test_data2 = []
    test_data3 = "test"
    test_data4 = "test,"


# Generated at 2022-06-25 05:48:55.586580
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    with pytest.raises(AnsibleParserError):
        assert role_include_1.load(
            data=None,
            play=None,
            current_role_path=None,
            parent_role=None,
            variable_manager=None,
            loader=None,
            collection_list=None)


# Generated at 2022-06-25 05:49:20.904845
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Create a RoleInclude object for testing
    role_include = RoleInclude()

    # Get the method to test
    test_method = role_include.__getattribute__('load')

    ##################################################
    # Unit test setup
    ##################################################

    # Create a mock data object
    mock_data = {'any_key': 'any_value'}

    # Create a mock play object
    mock_play = 'mock_play'

    # Create a mock role path
    mock_current_role_path = 'mock_role_path'

    # Create a mock parent role
    mock_parent_role = 'mock_parent_role'

    # Create a mock variable_manager object
    mock_variable_manager = 'mock_variable_manager'

    # Create a mock loader object

# Generated at 2022-06-25 05:49:30.673254
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader

    play_1 = Play().load(dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='debug', args=dict(msg='{{role_include_0.files[0].path}}')))
        ]
    ))

    loader = module_loader


# Generated at 2022-06-25 05:49:31.612842
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # do the test
    pass


# Generated at 2022-06-25 05:49:39.997995
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    data = '''
    - name: David
    - name: Peter
    '''
    play = ''
    current_role_path = ''
    parent_role = ''
    variable_manager = ''
    loader = ''
    collection_list = ''
    role_include_0.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

if __name__ == '__main__':
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:49:51.121834
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Dummy object for testing
    class DummyPlay:
        pass

    dummy_play = DummyPlay()

    # Dummy object for testing
    class DummyVariableManager:
        pass

    dummy_variable_manager = DummyVariableManager()

    # Dummy object for testing
    class DummyLoader:
        pass

    dummy_loader = DummyLoader()

    # Dummy object for testing
    class DummyCollectionList:
        pass

    dummy_collection_list = DummyCollectionList()

    role_include = RoleInclude()

    role_include.load("test", dummy_play, '', None, dummy_variable_manager, dummy_loader, dummy_collection_list)
    assert isinstance(role_include, RoleInclude)
    assert role_include.get_name() == 'test'


# Generated at 2022-06-25 05:50:02.482044
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:50:09.205637
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "test"
    play = "play"
    current_role_path = "current_role_path"
    parent_role = "parent_role"
    variable_manager = "variable_manager"
    loader = "loader"
    collection_list = "collection_list"
    obj = RoleInclude()
    # Call function load
    assert obj.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list) == None

# Generated at 2022-06-25 05:50:15.237581
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("RoleInclude_load")
    arg1 = None
    arg2 = None
    arg3 = None
    arg4 = None
    arg5 = None
    arg6 = None
    role_include_load = RoleInclude.load(arg1, arg2, arg3, arg4, arg5, arg6)
    print("role_include_load = %s" % role_include_load)


# Generated at 2022-06-25 05:50:23.252722
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    data = {'role': 'test'}
    variable_manager = object()
    loader = object()
    role_include_0 = ri.load(data, play=None, current_role_path=None, parent_role=None, variable_manager=variable_manager, loader=loader, collection_list=None)
    for attr in ['_role_name', '_role_path', '_role_collection_name']:
        assert hasattr(role_include_0, attr)
    for attr, value in iteritems(data):
        assert hasattr(role_include_0, attr)
        assert getattr(role_include_0, attr) == value
    assert role_include_0._variable_manager is variable_manager

# Generated at 2022-06-25 05:50:34.833710
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_1.did_something = True
    role_include_1.name = 'test-name-0'
    role_include_1.role_path = 'test-role_path-1'
    role_include_1.relative_path_to_basedir = 'test-relative_path_to_basedir-2'
    role_include_1.collection_list = [ 'test-collection_list-3', 'test-collection_list-4' ]

# Generated at 2022-06-25 05:51:23.761147
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # This code is based on test cases with the following common settings
    play = {}
    current_role_path = '.'
    parent_role = {}
    variable_manager = {}
    loader = {}
    collection_list = {}

    # Case 0, test for class
    assert 1 == test_case_0()
    # Case 1, test for class RoleInclude
    role_include_1 = RoleInclude()
    assert test_case_0() == 1
    # Case 2, test for class RoleInclude
    role_include_1 = RoleInclude(play=play)
    assert test_case_0() == 1
    # Case 3, test for class RoleInclude
    role_include_1 = RoleInclude(play=play, role_basedir=current_role_path)
    assert test_case_0() == 1

# Generated at 2022-06-25 05:51:34.294905
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude.load(data="geerlingguy.java", play=None, current_role_path=None, parent_role=None,
                     variable_manager=None, loader=None, collection_list=None)

    RoleInclude.load(data=RoleRequirement.load(data="geerlingguy.java", play=None,
                                               current_role_path=None), play=None, current_role_path=None,
                     parent_role=None, variable_manager=None, loader=None, collection_list=None)


# Generated at 2022-06-25 05:51:35.690852
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:51:37.055987
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_1.load("test_role", None)
    assert role_include_1.name == "test_role"

# Generated at 2022-06-25 05:51:46.249350
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.collection_loader import AnsibleCollectionRef

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play_context = PlayContext()

# Generated at 2022-06-25 05:51:55.388040
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    parent_role = 'parent_role'
    current_role_path = '.'
    role_include = RoleInclude()
    role_include.load('name: test', None, current_role_path, parent_role, None, None)
    assert role_include.get_display_name() == 'test'
    assert role_include.get_path() == current_role_path
    assert role_include.get_parent_role() == parent_role

    data = dict(name='test', tasks=dict(main=dict(debug=dict())))
    role_include.load(data, None, current_role_path, parent_role, None, None)
    assert role_include.get_display_name() == 'test'
    assert role_include.get_path() == current_role_path

# Generated at 2022-06-25 05:52:04.643117
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:52:05.392043
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: add unit test for RoleInclude.load
    pass

# Generated at 2022-06-25 05:52:13.329605
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = None
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-25 05:52:20.418027
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    lconfig = configparser.ConfigParser()
    lconfig.add_section('ssh_connection')
    lconfig.set('ssh_connection', 'pipelining', 'True')
    lconfig.set('ssh_connection', 'scp_if_ssh', 'True')
    lconfig.set('ssh_connection', 'ssh_args', '')
    lconfig.set('ssh_connection', 'control_path_dir', '')

    lconfig.add_section('defaults')
    lconfig.set('defaults', 'inventory', 'localhost,')

    lconfig.add_section('privilege_escalation')
    lconfig.set('privilege_escalation', 'become', 'True')
    lconfig.set('privilege_escalation', 'become_method', 'sudo')

# Generated at 2022-06-25 05:53:50.132554
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    :return:
    """
    role_include_1 = RoleInclude()
    role_include_1.load([1, 2, 3])
    assert(role_include_1.as_dict() == [1, 2, 3])


# Generated at 2022-06-25 05:53:56.333902
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Loading a dict should be fine
    role_data = dict()
    role_data['name'] = 'some_name'
    role_data['path'] = 'path_to_role'
    role = RoleInclude.load(role_data, None)
    assert role._role_name == role_data['name']
    assert role._role_path == role_data['path']

    # Loading a string (name only) should be fine
    role_data = 'some_name'
    role = RoleInclude.load(role_data, None)
    assert role._role_name == role_data
    assert role._role_path == 'some_name'

# Generated at 2022-06-25 05:54:00.401124
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    ri.load([{'role': 'test'}], play=None, loader=None)
    assert ri.role_path == None
    assert ri.role_name == 'test'

# Unit test to ensure that role_path is returned as absolute path

# Generated at 2022-06-25 05:54:02.607315
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    assert not role_include_0._delegate_to
    assert not role_include_0._delegate_facts

# Generated at 2022-06-25 05:54:09.483061
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    load() should check that data is a dict instance or a string instance that doesn't contain comma
    """

    ri = RoleInclude()
    with pytest.raises(AnsibleParserError):
        ri.load(1, None, None, None, None, None)
    with pytest.raises(AnsibleParserError):
        ri.load({}, None, None, None, None, None)
    with pytest.raises(AnsibleParserError):
        ri.load("1,2", None, None, None, None, None)
    assert ri.load("1", None, None, None, None, None) is not None

# Generated at 2022-06-25 05:54:15.339503
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    data = dict()
    play = dict()
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    role_include_result = role_include_1.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    assert role_include_result == role_include_1

# Generated at 2022-06-25 05:54:24.268989
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # RoleInclude_load: correct load
    role_include_0 = RoleInclude()
    role_include_0 = role_include_0.load('test_role', None, None, None, None, None)
    assert role_include_0 is not None
    # RoleInclude_load: wrong load
    role_include_2 = RoleInclude()
    try:
        role_include_2 = None
        assert False
    except:
        assert True
    # RoleInclude_load: wrong load
    role_include_3 = RoleInclude()
    try:
        role_include_3 = role_include_3.load('test_role,test_role2', None, None, None, None, None)
        assert False
    except:
        assert True
    # RoleInclude_load: wrong load
    role

# Generated at 2022-06-25 05:54:29.275019
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()

    try:
        role_include_0.load("ansible-role-apache")
    except Exception as e:
        assert isinstance(e, AnsibleParserError) == True


# Generated at 2022-06-25 05:54:33.873344
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    data = "test"
    play = "test"
    current_role_path = "test"
    parent_role = "test"
    variable_manager = "test"
    loader = "test"
    collection_list = "test"
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

# Generated at 2022-06-25 05:54:38.572271
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    test_data = {'name': 'test_name'}
    test_play = None
    test_current_role_path = 'current_role_path'
    test_parent_role = None
    test_variable_manager = None
    test_loader = None
    test_collection_list = None
    role_include_1.load(test_data, test_play, test_current_role_path, test_parent_role, test_variable_manager, test_loader, test_collection_list)