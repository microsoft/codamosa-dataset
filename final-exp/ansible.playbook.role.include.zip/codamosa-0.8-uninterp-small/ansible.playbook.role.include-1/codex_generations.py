

# Generated at 2022-06-25 05:44:41.805258
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Load data.
    assert True


# Generated at 2022-06-25 05:44:48.703219
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    bytes_1 = 'dummy'
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    data = 'good'
    current_role_path = 'good'
    variable_manager = 'good'
    loader = 'good'
    assert role_include_0.load('good', current_role_path, None, None, variable_manager, loader)

    # FIXME: get rid of the following two tests once the deprecated 'include'
    #        keyword is removed
    role_include_1 = RoleInclude(bytes_0, tuple_0)
    data = 'good'
    current_role_path = 'good'
    variable_manager = 'good'
    loader = 'good'

# Generated at 2022-06-25 05:44:53.677183
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    bytes_1 = b'a'
    tuple_1 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    str_0 = role_include_0.load((bytes_1, ), tuple_1)
    assert str_0 == 'a'

# Generated at 2022-06-25 05:45:02.058335
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    target = RoleInclude()
    bytes_0 = None
    tuple_0 = ()
    str_0 = load()
    # In order to make a test case, there is a need to check the conditions of being raised an exception so I added raise_on_error=True
    role_include_0 = target.load(str_0, bytes_0, tuple_0, raise_on_error=True) # Actual result: the value of the role_include_0 is the same as the one given in the test case.
    assert role_include_0 is not None, "The output of method load() should not be none."

# Generated at 2022-06-25 05:45:08.029579
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Dummy call to method load to satisfy coverage
    bytes_0 = None
    tuple_0 = ()
    str_0 = "fileExist"
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    role_include_0.load(str_0)


# Generated at 2022-06-25 05:45:12.971849
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    string_0 = ""
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    assert role_include_0.load(string_0) is not None

# Generated at 2022-06-25 05:45:20.242140
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
	bytes_0 = None
	tuple_0 = ()
	role_include_0 = RoleInclude(bytes_0, tuple_0)
	bytes_0 = None
	tuple_1 = ()
	role_definition_1 = RoleDefinition.load(bytes_0, tuple_1)
	str_0 = None
	str_1 = None
	str_2 = None
	dict_0 = {'task_files': str_0, 'handlers_path': str_1, 'role_name': str_2}
	variable_manager_0 = RoleRequirement(dict_0)
	loader_0 = None
	collection_list_0 = None

# Generated at 2022-06-25 05:45:23.771749
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    data = dict()
    play = dict()
    current_role_path = dict()
    parent_role = dict()
    variable_manager = dict()
    loader = dict()
    collection_list = dict()
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

# Generated at 2022-06-25 05:45:29.955889
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Load a simple role from a string
    bytes_0 = b'simple_role'
    tuple_0 = ()
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude.load(bytes_0, tuple_0)
    # TODO: assert whether expected result is in role_include_1
    # Load a simple role as a dictionary
    bytes_1 = {b'role': b'simple_role_2'}
    tuple_1 = ()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude.load(bytes_1, tuple_1)
    # TODO: assert whether expected result is in role_include_3
    # Load a role requiring extra vars

# Generated at 2022-06-25 05:45:34.140899
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    bytes_1 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, role_basedir=tuple_0)
    role_include_load_0 = role_include_0.load(bytes_1)

# Generated at 2022-06-25 05:45:43.681103
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = dict()
    role_include_0 = RoleInclude(dict_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_0['_usage'] = dict_1
    dict_1 = dict()
    dict_2 = dict()
    dict_1['serial'] = dict_2
    dict_1 = dict()
    dict_2 = dict()
    dict_2['_default'] = "required"
    dict_1['role'] = dict_2
    dict_1 = dict()
    dict_2 = dict()
    dict_2['_default'] = "required"
    dict_1['include'] = dict_2
    dict_0['_terms'] = dict_1
    dict_1 = dict()
    dict_2 = dict()

# Generated at 2022-06-25 05:45:52.738097
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play_0 = None
    current_role_path_0 = None
    parent_role_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    string_0 = 'You must specify a role name.'
    bytes_0 = None
    tuple_0 = ('',)
    # Test with a dict object
    dict_0 = {}
    dict_1 = {'role': 'role'}
    dict_2 = {'role': 'role', 'name': 'name'}
    dict_3 = {'role': 'role', 'name': 'name', 'async': 'async'}
    dict_4 = {'role': 'role', 'name': 'name', 'async': 'async', 'delegate_to': 'delegate_to'}


# Generated at 2022-06-25 05:45:55.601907
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Provisioning test cases

    # Test case 0
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)


# Generated at 2022-06-25 05:45:58.391905
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)

    # test without raise
    try:
        role_include_0.load('string_s', 'string_s', 'string_s', 'string_s', 'string_s', 'string_s', 'string_s')
    except:
        assert False


# Generated at 2022-06-25 05:46:06.707765
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    role_definition_0 = None
    role_definition_1 = RoleDefinition(role_definition_0)
    str_0 = None
    # self_0.playbook = role_definition_1
    role_definition_1.post_validate()
    exitStatus = 1
    if sys.exc_info()[0]:
        _stderr.write("Unexpected Error: " + sys.exc_info()[0])
        exitStatus = 99
    sys.exit(exitStatus)

# Generated at 2022-06-25 05:46:12.536658
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("Testing RoleInclude.load")

    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    bytes_0 = b'R'
    tuple_0 = ()
    data = role_include_0.load(bytes_0, tuple_0)
    print(data)

test_case_0()
test_RoleInclude_load()

# Generated at 2022-06-25 05:46:17.994824
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    bytes_1 = None
    tuple_1 = ()
    role_include_1 = RoleInclude(bytes_1, tuple_1, )
    bytes_2 = None
    tuple_2 = ()
    role_include_2 = RoleInclude(bytes_2, tuple_2)
    bytes_3 = None
    tuple_3 = ()
    role_include_3 = RoleInclude(bytes_3, tuple_3)
    role_include_3.load(role_include_0)



# Generated at 2022-06-25 05:46:24.525071
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    data = ""
    play = ()
    current_role_path = ()
    parent_role = ()
    variable_manager = ()
    loader = ()
    collection_list = ()
    definition = role_include_0.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    # TODO: assert the result of definition

# Generated at 2022-06-25 05:46:33.847370
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    dict_0 = dict()
    dict_0['tuple_0'] = tuple_0
    dict_0['dict_0'] = dict_0
    dict_0['role_include_0'] = role_include_0
    dict_0['bytes_0'] = bytes_0
    dict_0['dict_0'] = dict_0
    dict_0['role_include_0'] = role_include_0
    dict_1 = dict_0
    dict_0['dict_1'] = dict_1
    dict_0['dict_1'] = dict_1
    dict_1 = dict_0
    dict_0['dict_1'] = dict_1
    dict_0

# Generated at 2022-06-25 05:46:39.954769
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    string_0 = None
    string_1 = '1'
    dict_0 = dict()
    role_include_0 = RoleInclude(string_0, string_1, variable_manager=dict_0)
    role_include_0.load()


# Generated at 2022-06-25 05:46:52.414115
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    dict_0 = {"tuple_0": "", "tuple_1": "roles: ansible-role-ansistrano-deploy", "dict_0": "requirements.yml"}
    role_include_0 = RoleInclude.load(dict_0)
    bytes_0 = "rolex"
    dict_0 = {"tuple_0": "", "tuple_1": "roles: ansible-role-x"}
    role_include_0 = RoleInclude.load(bytes_0, dict_0)
    dict_0 = {"tuple_0": "", "tuple_1": "roles: ansible-role-ansistrano-deploy"}
    role_include_0 = RoleInclude.load(dict_0)

# Generated at 2022-06-25 05:46:59.559465
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Assume: role_include_0.load is called with arguments data= set() , play='YnNt' , current_role_path='AaDh' , parent_role='evafK' , variable_manager='EaYt' , loader='KvTW' , collection_list=set() .
    # Assume: role_include_0.load is called with arguments data= set() , play='ZjKU' , current_role_path='qxqv' , parent_role='KPjRE' , variable_manager='UJfo' , loader='MgAc' , collection_list=set() .
    pass


# Generated at 2022-06-25 05:47:06.730299
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    bytes_1 = None
    tuple_1 = ()

    data_0 = '@'
    data_1 = '|'
    play_0 = None
    tuple_2 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    role_include_1 = role_include_0.load(data_0, data_1, tuple_2)

# Generated at 2022-06-25 05:47:14.782992
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = dict()
    dict_0['name'] = 'tgz'
    dict_0['src'] = 'http://1.2.3.4/tgz'
    list_0 = list()
    list_0.append(dict_0)
    dict_1 = dict()
    dict_1['name'] = 'rpms'
    dict_1['src'] = 'http://1.2.3.4/rpms'
    list_0.append(dict_1)
    dict_2 = dict()
    dict_2['name'] = 'tgz2'
    dict_2['src'] = 'http://1.2.3.4/tgz2'
    list_0.append(dict_2)
    dict_3 = dict()

# Generated at 2022-06-25 05:47:19.306589
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    bytes_1 = None
    role_include_1 = role_include_0.load(bytes_1, role_include_0)


# Generated at 2022-06-25 05:47:22.009635
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    dict_0 = dict()
    string_0 = str()
    role_include_0 = RoleInclude(bytes_0, dict_0, string_0)
    dict_1 = dict()
    role_include_1 = role_include_0.load(dict_1)

# Generated at 2022-06-25 05:47:25.488187
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    role_include_0.load_data('roles', role_basedir='roles', loader='roles')

# Generated at 2022-06-25 05:47:32.704454
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play_0 = Play()
    current_role_path_0 = None
    parent_role_0 = None
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    collection_list_0 = None
    data_0 = 'test_value'
    role_include_0 = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)
    assert role_include_0.load_data(data_0, variable_manager=variable_manager_0, loader=loader_0) is None

# Generated at 2022-06-25 05:47:42.419584
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:47:48.519461
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    data_0 = (3, 1)
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    assert isinstance(RoleInclude.load(data_0, tuple_0), RoleInclude) == True



# Generated at 2022-06-25 05:47:56.140475
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    list_0 = []
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    assert RoleInclude.load(dict(), bytes_0, tuple_0, role_include_0, bytes_0, list_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 05:48:01.213666
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)

    # AssertionError: Invalid role definition: b''
    assert role_include_0.load()



# Generated at 2022-06-25 05:48:09.140361
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    role_include_0.get_role_path = mock_get_role_path

    with pytest.raises(AnsibleError) as excinfo:
        RoleInclude.load("foo1,foo2,foo3", bytes_0, tuple_0, tuple_0, tuple_0, tuple_0)
    assert to_native(excinfo.value) == "Invalid old style role requirement: foo1,foo2,foo3"


# Generated at 2022-06-25 05:48:14.765563
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    data = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None

    # Call the method
    result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)
    assert result == None

# Generated at 2022-06-25 05:48:18.049902
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    role_include_0 = str('str')
    role_include_1 = role_include_0.load(role_include_0, role_include_0)


# Generated at 2022-06-25 05:48:22.626375
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    param_0 = None
    param_1 = None
    param_2 = None
    param_3 = None
    param_4 = None
    param_5 = None
    role_include_0 = RoleInclude.load(param_0, param_1, param_2, param_3, param_4, param_5)

# Generated at 2022-06-25 05:48:27.025196
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Arrange
    #load(data, play, current_role_path, parent_role, variable_manager, loader)

    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)

    # Act
    result = role_include_0.load()

    # Assert
    assert result is None


# Generated at 2022-06-25 05:48:36.172859
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    # Fail
    try:
        data_0 = None
        play_0 = None
        current_role_path_0 = None
        parent_role_0 = None
        variable_manager_0 = None
        loader_0 = None
        collection_list_0 = None
        role_include_0.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)
    except Exception as e:
        print('Unhandled exception: %s' % e)


# Generated at 2022-06-25 05:48:41.565143
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    tuple_0 = ()
    data_0 = '''\
hosts:
- example42
roles:
- role_1
- role2
- role_3
'''
    play_0 = ansible.playbook.play.Play.load(data_0, tuple_0)
    data_1 = '''\
- role_2
'''
    role_include_0 = RoleInclude.load(data_1, play_0, tuple_0)


# Generated at 2022-06-25 05:48:44.953059
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print('Testing load')

    # test case with 0 parameters
    test_case_0()

# Generated at 2022-06-25 05:48:56.584337
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

if __name__ == "__main__":
    test_RoleInclude_load()

# Generated at 2022-06-25 05:49:04.268374
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    collection_list = None
    data = None
    variable_manager = None
    loader = None
    play = None
    current_role_path = None
    parent_role = None
    # Test case where string_types exists

    result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert isinstance(result, RoleInclude)
    #TODO: add more tests here


# Generated at 2022-06-25 05:49:08.363817
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    data = {}
    assert role_include_0.load(data) is None


# Generated at 2022-06-25 05:49:17.687585
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    bytes_0 = None
    str_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    d = AnsibleBaseYAMLObject()
    play = Play(loader=d, variable_manager=d, host_manager=d, options=d)
    role_include_0.load(d, play, str_0, role_include_0, d, d)

test_case_0()
test_RoleInclude_load()

# Generated at 2022-06-25 05:49:28.501495
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    play_0 = Play()
    current_role_path_0 = None
    parent_role_0 = None
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    data_0 = None
    collection_list_0 = None
    role_definition_0 = RoleDefinition.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)

# Generated at 2022-06-25 05:49:39.643775
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # role_include_0 is a RoleInclude instance
    role_include_0 = RoleInclude()
    # str_0 is a str instance
    str_0 = 'ansible.builtin.yum'
    # str_1 is a str instance
    str_1 = 'ansible.posix'
    # dict_0 is a dict instance
    dict_0 = {}
    # str_2 is a str instance
    str_2 = '/root/ansible/lib/ansible/plugins/action/'
    # str_3 is a str instance
    str_3 = 'yum'
    # str_4 is a str instance
    str_4 = 'action'
    # str_5 is a str instance
    str_5 = '__main__.py'

# Generated at 2022-06-25 05:49:50.637610
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.plugins.callback import CallbackBase
    from ansible.utils import context_objects as co

    context = PlayContext()
    variable_manager = VariableManager()
    data_loader = DataLoader()

# Generated at 2022-06-25 05:49:52.964582
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)

# Generated at 2022-06-25 05:49:58.005980
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    value_0 = RoleInclude.load(bytes_0, tuple_0)
    # Verifies if the value of attribute loader is setted with the value of parameter loader
    assert value_0.loader is tuple_0



# Generated at 2022-06-25 05:49:59.957551
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = None
    tuple_0 = ()
    role_include_0 = RoleInclude(bytes_0, tuple_0)
    role_include_0.load()
