

# Generated at 2022-06-25 05:44:47.542788
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    ansible_error_1 = AnsibleError('Invalid role definition: ')
    ansible_error_2 = AnsibleError('Invalid old style role requirement: ')
    with pytest.raises(AnsibleError, match=ansible_error_1.message):
        role_include_0.load(None, None)
    with pytest.raises(AnsibleError, match=ansible_error_2.message):
        role_include_0.load(None, None, None, None, None, None)

# Generated at 2022-06-25 05:44:52.129745
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    try:
        dict_0 = dict()
        dict_0.update(dict())
        role_include_0.load(dict_0)
    except:
        pass

# Generated at 2022-06-25 05:44:56.781486
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = [b'']
    role_include_0 = RoleInclude(list_0)
    str_0 = 'role1,role2'
    play_0 = AnsiblePlay()
    str_1 = 'role1_path'
    role_include_1 = role_include_0.load(str_0, play_0, str_1)

# Generated at 2022-06-25 05:45:02.474503
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("==== test_RoleInclude_load")

    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = role_include = RoleInclude(list_0)
    role_include_1 = role_include.load("blah")
    print("==== test_RoleInclude_load: pass")



# Generated at 2022-06-25 05:45:13.381864
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    dict_0 = {'tasks':{'name': 'b2'}}
    dict_1 = {}
    dict_2 = {'tasks':{'name': 'b2'}}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {'tasks':{'name': 'b2'}}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {'tasks':{'name': 'b2'}}
    dict_14 = {}
    dict_15 = {}


# Generated at 2022-06-25 05:45:22.493766
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'run_once'
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    data_0 = b'/etc/ansible/roles/a'
    play_0 = [data_0]
    data_1 = b'/etc/ansible/roles/a/tasks'
    role_basedir_0 = [data_1]
    data_2 = b'/etc/ansible/roles/a/handlers'
    variable_manager_0 = [data_2]
    data_3 = b'/etc/ansible/roles/a/vars'
    loader_0 = [data_3]
    data_4 = b'become_user'
    collection_list_0 = [data_4]
    role_include

# Generated at 2022-06-25 05:45:26.596083
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    bytes_1 = b'1'
    result_0 = role_include_0.load(bytes_1)
    assert isinstance(result_0, RoleInclude)



# Generated at 2022-06-25 05:45:29.341321
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    list_1 = ['', role_include_0]
    list_2 = ['', role_include_0]
    role_include_0.load(list_1, list_2)

# Generated at 2022-06-25 05:45:31.850301
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'1'
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)



# Generated at 2022-06-25 05:45:37.631867
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'role_name: foo'
    obj_0 = Attribute.construct(bytes_0)
    list_0 = [obj_0]
    obj_1 = RoleInclude.load(list_0)
    assert False


# Generated at 2022-06-25 05:45:41.500112
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    play_0 = Play()
    role_include_0.load(None, play_0, None, None)

# Generated at 2022-06-25 05:45:41.978477
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-25 05:45:48.128513
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    bytes_0 = b''
    list_1 = [bytes_0]
    role_include_1 = RoleInclude(list_1)
    with raises(AnsibleError) :
        role_include_1 = role_include_0.load(list_0)
    bytes_0 = b''
    list_2 = [bytes_0]
    role_include_2 = RoleInclude(list_2)
    with raises(AnsibleError) :
        role_include_2 = role_include_1.load(list_1)
    bytes_0 = b''
    list_3 = [bytes_0]

# Generated at 2022-06-25 05:45:50.930285
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    role_include_0.load(bytes_0, list_0)


# Generated at 2022-06-25 05:45:54.699822
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    args = [b'']
    role_include = RoleInclude(args)
    if role_include is None:
        assert False, 'RoleInclude.load() no role include'
    else:
        assert True if isinstance(role_include, RoleInclude) else False, 'RoleInclude.load() incorrect role include'

# Generated at 2022-06-25 05:45:57.744116
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("Testing RoleInclude.load")
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    bytes_1 = b'wjxvp'
    bytes_2 = b'ejg'
    role_include_1 = role_include_0.load(bytes_1, bytes_2)
    print("Test: %s" % str(role_include_1))


# Generated at 2022-06-25 05:46:03.167498
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    data = 'a'
    play = 'b'
    current_role_path = 'c'
    parent_role = 'd'
    variable_manager = 'e'
    loader = 'f'
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)

# Generated at 2022-06-25 05:46:12.862224
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)

    # Test which raises an exception because the 2nd argument is not of the right type.
    # The test is currently disabled because there is a bug in the code
    # def test_RoleInclude_load_exception():
    #     # Test which raises an exception because the 2nd argument is not of the right type.
    #     # The test is currently disabled because there is a bug in the code
    #     bytes_0 = b''
    #     list_0 = [bytes_0]
    #     role_include_0 = RoleInclude(list_0)
    #     with pytest.raises(AnsibleError) as pytest_wrapped_e:
    #         role_include_

# Generated at 2022-06-25 05:46:13.379472
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-25 05:46:21.561256
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    role_include_0 = RoleInclude(list_0)
    list_0 = [bytes_0]
    bytes_0 = b''
    dict_0 = {}
    list_1 = []
    str_0 = "run"
    int_0 = 0
    ansible_playbook_1 = AnsiblePlaybook(str_0, list_0, dict_0)

# Generated at 2022-06-25 05:46:32.712176
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    role_include_0.get_path()
    bytes_0 = b'\x00\x00'
    os_stat_result_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    os_stat_result_0.__getitem__(0)
    os_stat_result_0.__getitem__(1)
    os_stat_result_0.__getitem__(2)
    os_stat_result_0.__getitem__(3)
    os_stat_result_0.__getitem__(0)
    os_stat_result_0.__getitem__(0)
    os_stat_result_0

# Generated at 2022-06-25 05:46:42.251699
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = bytes()
    play_0 = object()
    current_role_path_0 = bytes()
    parent_role_0 = Play(play_0, current_role_path_0)
    variable_manager_0 = object()
    loader_0 = object()
    collection_list_0 = object()
    role_include_0 = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0,
                                      variable_manager_0, loader_0, collection_list_0)
    assert type(role_include_0) == RoleInclude


# Generated at 2022-06-25 05:46:48.353323
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # check returned value of returns_none_when_obj_None
    passed = True
    data = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ret = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ret is None


# Generated at 2022-06-25 05:46:54.384256
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)

    list_1 = ["x"]

    role_include_0.load(list_1, list_0)

if __name__ == "__main__":
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:46:58.778570
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        bytes_0 = b''
        list_0 = [bytes_0]
        dict_0 = {"key_0": "value_0"}
        bytes_0 = b''
        role_include_0 = RoleInclude(list_0)
        role_include_0.load(dict_0, bytes_0)
    except:
        raise

# Generated at 2022-06-25 05:47:05.664961
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    assert isinstance(bytes_0, bytes) and isinstance(list_0, list) and isinstance(role_include_0, RoleInclude)

# Generated at 2022-06-25 05:47:07.588553
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = s
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_1.load(s)
    pass

# Generated at 2022-06-25 05:47:15.470877
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print('\n********** Method load of class RoleInclude *********')
    try:
        print('test 1')
        bytes_0 = b'param'
        list_0 = [bytes_0]
        try:
            role_include_0 = RoleInclude(list_0)
            role_name_0 = role_include_0.role_name
            print('*** The role name is : %s' % role_name_0)
        except:
            print('Unexpected error:', sys.exc_info()[0])
            raise
    except:
        print('Unexpected error:', sys.exc_info()[0])
        raise

# Generated at 2022-06-25 05:47:22.957850
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    # 'str' object has no attribute 'get'

    # 'str' object has no attribute 'role'

    # 'str' object has no attribute 'role'

    # 'str' object has no attribute 'role'

    # 'str' object has no attribute 'role'

    # 'str' object has no attribute 'role'

    # 'str' object has no attribute 'role'

    # 'str' object has no attribute 'role'

    # 'str' object has no attribute 'role'

    # 'str' object has no attribute 'role'

    # 'str' object has no attribute 'role'

    # 'str' object has no attribute 'role'

    # 'str' object has no

# Generated at 2022-06-25 05:47:23.745036
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Test for catch of AnsibleError exception

# Generated at 2022-06-25 05:47:33.101052
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = []
    role_include_0 = RoleInclude(list_0)
    data_0 = object()
    play_0 = object()
    current_role_path_0 = object()
    parent_role_0 = object()
    variable_manager_0 = object()
    loader_0 = object()
    collection_list_0 = object()
    role_include_1 = role_include_0.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)

# Generated at 2022-06-25 05:47:40.079951
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test case
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    dict_0 = dict()
    dict_0['run_once'] = True
    dict_0['name'] = 'web'
    dict_0['pause_for'] = 0
    dict_0['default_vars'] = dict()
    dict_0['handlers'] = list_0
    dict_0['hosts'] = list_0
    dict_0['hosts'] = list_0
    dict_0['roles'] = list_0
    dict_0['tasks'] = list_0
    dict_0['post_tasks'] = list_0
    dict_0['vars'] = dict()
    dict_0['tags'] = list

# Generated at 2022-06-25 05:47:45.614634
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = list()
    role_include_0 = RoleInclude(list_0)
    path = "fixtures/ansible-role-requirement-1.yml"
    path = os.path.realpath(path)
    role_include_1 = role_include_0.load(path)


# Generated at 2022-06-25 05:47:46.432441
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-25 05:47:55.097876
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    b'Tests role include load'
    bytes_0 = b'/home/automaton/ansible/lib/ansible/plugins/action'
    list_0 = [bytes_0]
    bytes_1 = b'install_subversion'
    bytes_2 = b''
    list_1 = [bytes_2]
    bytes_3 = b''
    list_2 = [bytes_3]
    bytes_4 = b''
    bytes_5 = b'common'
    role_include_0 = RoleInclude(list_0)
    role_include_0._loader = bytes_4
    role_include_0._role_params = list_1
    role_include_0.get_vars = list_2
    role_include_0.play = list_1
    bool_0 = role_include_0

# Generated at 2022-06-25 05:47:59.673528
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude.load(list_0)

# Generated at 2022-06-25 05:48:02.940891
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    variable_manager = variable_manager()
    loader = loader()
    collection_list = collection_list()
    data = data()
    play = play()
    current_role_path = current_role_path()
    parent_role = parent_role()
    role_include_0.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)


# Generated at 2022-06-25 05:48:10.681014
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    list_1 = ['', '']
    role_include_0.load(list_1)

if __name__ == "__main__":
    import sys
    import types
    import unittest
    # import coverage
    sys.path.append('../..')
    # coverage.process_startup()
    ansible_test_path = os.path.abspath(__file__ + '/../../../')
    if os.path.isdir(ansible_test_path):
        sys.path.append(ansible_test_path)

# Generated at 2022-06-25 05:48:17.117807
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    str_0 = 'test_RoleInclude_load.py'
    assert RoleInclude.load(list_0, list_0, current_role_path=list_0, loader=list_0, collection_list=list_0) != None
    assert RoleInclude.load(str_0, list_0, current_role_path=list_0, parent_role=list_0, loader=list_0) != None

# Generated at 2022-06-25 05:48:21.873014
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = b'string'
    play = b'string'
    current_role_path = b'string'
    parent_role = b'string'

    role_include_0 = RoleInclude.load(data, play, current_role_path, parent_role)

# Generated at 2022-06-25 05:48:38.214371
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    file_0 = '/tmp/ansible_RoleInclude_load_file_0.tmp'
    open(file_0, 'w').close()
    file_1 = '/tmp/ansible_RoleInclude_load_file_1.tmp'
    open(file_1, 'w').close()
    file_2 = '/tmp/ansible_RoleInclude_load_file_2.tmp'
    open(file_2, 'w').close()
    role_include_0.load(file_0, file_1, file_2)
    os.remove(file_0)
    os.remove(file_1)
    os.remove(file_2)



# Generated at 2022-06-25 05:48:43.921071
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'vz8wZG1hc3Rlcg%3D%3D'
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    data_0 = dict()
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    role_include_0.load(data_0, variable_manager_0, loader_0, collection_list_0)

# Generated at 2022-06-25 05:48:51.915297
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print('Testing RoleInclude.load')

    # Input parameters to the method
    bytes_0 = b'bar'
    str_0 = 'foo'
    list_0 = [bytes_0]
    role_definition_0 = RoleDefinition(list_0)
    role_definition_1 = RoleDefinition(list_0)
    dict_0 = dict([(str_0, role_definition_0)])
    str_1 = 'test'
    dict_1 = dict([(str_1, dict_0)])
    dict_2 = dict([(str_1, dict_1)])
    dict_3 = dict([(str_0, role_definition_1)])
    dict_4 = dict([(str_1, dict_3)])

# Generated at 2022-06-25 05:49:03.621352
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'--name apache --role-path /home/robert/ansible/roles/'
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    bytes_0 = b'--name apache --role-path /home/robert/ansible/roles/'
    list_0 = [bytes_0]
    role_include_0.load(list_0)
    bytes_1 = b'- src: username.role_name'
    list_1 = [bytes_1]
    kwargs =  {'play': list_1, 'current_role_path': list_0, 'variable_manager': list_0, 'loader': list_0, 'collection_list': list_1}

# Generated at 2022-06-25 05:49:07.891685
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Testing Load Method
    # Test Case No-0

    # Test Case No-1
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)

# Generated at 2022-06-25 05:49:13.518083
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    bytes_1 = b''
    list_1 = [bytes_1]
    role_include_0 = RoleInclude(list_0)
    role_include_0.load(list_1)


# Generated at 2022-06-25 05:49:16.061749
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)


# Generated at 2022-06-25 05:49:20.644929
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = [b'', b'']
    list_1 = [b'', b'', b'']
    list_2 = [b'', b'', b'']
    role_include_0 = RoleInclude.load(list_0, list_1, list_2)
    role_include_1 = RoleInclude.load(list_0, list_1, list_2)

# Generated at 2022-06-25 05:49:24.172606
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    arg_0 = "abcd"
    arg_1 = "bcde"
    arg_2 = None
    try:
        role_include_0.load(arg_0, arg_1, current_role_path=arg_2)
    except TypeError:
        pass


# Generated at 2022-06-25 05:49:28.212184
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    x = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)


# Generated at 2022-06-25 05:49:48.759195
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = '0'
    play_0 = RoleInclude(data_0)
    role_include_0 = RoleInclude.load(data_0, play_0)
    assert role_include_0.__class__.__name__ == 'RoleRequirement'
    play_0 = RoleInclude(data_0)
    role_include_0 = RoleInclude.load(data_0, play_0)
    assert role_include_0.__class__.__name__ == 'RoleRequirement'

# Generated at 2022-06-25 05:49:52.793884
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = []
    role_include_0 = RoleInclude(list_0)

    assert isinstance(role_include_0, RoleInclude)
    assert isinstance(role_include_0, RoleDefinition)

if __name__ == "__main__":
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:49:56.587780
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
    # TODO: implement this test


if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-25 05:50:04.008443
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = [{'x': 'y'}]
    list_1 = [{'y': 'x'}]
    list_2 = [{'z': 'x', 'y': 'y'}]
    list_3 = [{'a': 'b'}]
    list_4 = [{'c': 'd'}]
    list_5 = [{'e': 'f'}]
    list_6 = [{'e': 'f'}, {'g': 'f'}]
    list_7 = [{'x': 'y'}]
    list_8 = [{'y': 'x'}]
    list_9 = [{'z': 'x', 'y': 'y'}]
    list_10 = [{'a': 'b'}]
    list_

# Generated at 2022-06-25 05:50:09.578206
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def test_function(self, play, current_role_path):
        print('Called test_function, play: ' + play + ' and current_role_path: ' + current_role_path)
    
    role_include_0 = RoleInclude('', '', '', test_function, '')

    # Code coverage for load when the data is a string and contains a comma
    data = 'testdetect,'
    try:
        role_include_0.load(data, {}, {}, {}, {}, {})
    except AnsibleError as e:
        assert True
        print(e)
    
    # Code coverage for load when the data is a string and contains a comma

# Generated at 2022-06-25 05:50:19.781273
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # import pdb; pdb.set_trace()
    list_0 = [{u'tasks': {u'name': u'Example tasks file', u'task': [{u'copy': {u'dest': u'/etc/foo.conf', u'group': u'wheel', u'mode': u'0640', u'owner': u'root', u'src': u'files/foo.j2'}}, {u'my_task': {u'my_var': u'some_value'}}], u'vars': {u'http_port': 80, u'max_clients': 200}}}]
    ri = RoleInclude(list_0)
    role = ri.load(list_0)
    # print(role.get_vars())
    # assert role.get_vars() == {'http_

# Generated at 2022-06-25 05:50:26.042679
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = []
    role_include_0 = RoleInclude(list_0)
    list_1 = ['test_path']
    role_include_1 = role_include_0.load(list_1)
    assert role_include_1.role_path == 'test_path'

# Wrapper for:
# RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-25 05:50:32.986465
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    if not isinstance(False, bool):
        # Instance argument passing not supported in 2.x
        raise ValueError('2.x does not support instance method argument passing')
    else:
        bytes_0 = b'p'
        list_0 = [bytes_0, bytes_0]
        role_include_0 = RoleInclude()
        # Loads the specified roledefs in the current role context
        role_include_0.load(list_0, role_include_0)

# Generated at 2022-06-25 05:50:40.223508
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        test_RoleInclude_load_0()
    except AttributeError as error:
        print("AttributeError: " + str(error))
    except AnsibleParserError as error:
        print("AnsibleParserError: " + str(error))
    except Exception as error:
        print("Exception: " + str(error))
    else:
        raise Exception("Expected exception was not raised")

#Unit test for method __init__ of class RoleInclude

# Generated at 2022-06-25 05:50:47.801875
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = {}
    play_0 = {}
    variable_manager_0 = {}
    loader_0 = {}
    collection_list_0 = {}
    role_include_0 = RoleInclude()
    result_0 = role_include_0.load(data_0, play_0, variable_manager=variable_manager_0, loader=loader_0, collection_list=collection_list_0)



# Generated at 2022-06-25 05:51:20.257603
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    dict_0 = dict()
    dict_0["key"] = "value"
    dict_0["key2"] = "value2"
    try:
        role_include_0.load(dict_0)
    except AnsibleParserError:
        pass
# vim: set fileencoding=utf-8 sw=4 tabstop=4 expandtab :

# Generated at 2022-06-25 05:51:26.610811
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play_0 = Play()
    role_include_0 = RoleInclude(play_0)
    data_0 = b'yum'
    variable_manager_0 = VariableManager()
    loader_0 = None
    collection_list_0 = None
    role_include_1 = RoleInclude.load(data_0, play_0, role_include_0, role_include_0, variable_manager_0, loader_0, collection_list_0)



# Generated at 2022-06-25 05:51:34.594194
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    loader_0 = ModuleLoader()
    str_0 = "ansible.playbook.include"
    module_loader_0 = loader_0.load_module(str_0)
    str_1 = "ansible.playbook.attribute"
    module_loader_1 = loader_0.load_module(str_1)
    # FIXME: TypeError: 'module' object is not callable
    # assertRaises(TypeError, module_loader_1.Attribute.attribute.__init__)
    str_2 = "xyz"
    str_3 = "xyz"
    str_4 = "xyz"
    str_5 = "xyz"
    str_6 = "xyz"
    str_7 = "xyz"


# Generated at 2022-06-25 05:51:38.584580
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    obj_RoleInclude = RoleInclude()
    obj_RoleInclude.load()

# Generated at 2022-06-25 05:51:44.543244
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    dict_0 = dict()
    dict_0['foo'] = 'bar'
    dict_1 = dict()
    dict_1['foo'] = 'bar'
    dict_1['foo'] = 'bar'
    dict_2 = dict()
    dict_2['foo'] = 'bar'
    dict_2['foo'] = 'bar'
    dict_3 = dict()
    dict_3['foo'] = 'bar'
    dict_3['foo'] = 'bar'
    role_include_0.load(dict_0, dict_1, dict_2, dict_3)


# Generated at 2022-06-25 05:51:47.377098
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.get_role_path = get_role_path
    list_0 = []
    value_0 = role_include_0.load(list_0)


# Generated at 2022-06-25 05:51:49.441995
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)

# Generated at 2022-06-25 05:51:55.110120
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test cases
    test_cases = [
        # test_case_0,
    ]

    # Generate expected failures
    failures = [
        # (test_case, ),
    ]

    for test_case in test_cases:
        try:
            test_case()
        except Exception:
            if (test_case, ) not in failures:
                raise


if __name__ == "__main__":
    test_RoleInclude_load()

# Generated at 2022-06-25 05:51:58.808858
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    bytes_0 = b'fghgfhg'
    str_0 = role_include_0.load(bytes_0)
    assert str_0 == 'fghgfhg'


# Generated at 2022-06-25 05:52:01.053752
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # try:
    #     test_case_0()
    # except Exception as e:
    #     print(e)
    pass

# Generated at 2022-06-25 05:52:59.445941
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:53:03.694084
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = Attribute()
    play_0 = Attribute()
    role_include_0 = RoleInclude(play_0)
    role_include_1 = role_include_0.load(data_0,play_0)

# Generated at 2022-06-25 05:53:05.024322
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("Testing RoleInclude_load")
    # case 0
    try:
        test_case_0()
    except Exception:
        print("Exception when processing case 0")

# Generated at 2022-06-25 05:53:07.543605
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-25 05:53:11.604161
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {}
    play = {}
    current_role_path = {}
    parent_role = {}
    variable_manager = {}
    loader = {}
    collection_list = {}

    result = RoleInclude.load(data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert result is None

# Generated at 2022-06-25 05:53:16.762718
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    list_1 = []
    variable_manager_0 = VariableManager(loader=None, variables=list_1)
    bytes_1 = b'role_name'
    list_2 = [bytes_1]
    loader_0 = DataLoader()
    role_include_0.load(list_2, variable_manager=variable_manager_0, loader=loader_0)

# Generated at 2022-06-25 05:53:24.671279
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    bytes_1 = b'p\xdf\xe9\x1e\xe1\xe3\x15\xf3\xef\x19\\\xe8\xd8\x9d'
    ansible_error_0 = AnsibleError(bytes_1)
    bytes_2 = b'\x8b9\xdb\x1f\xddM\x8d\xfc\x99\x1f\xaf\x9f\xe3\x9a\x94\xad\x90'
    ansible_parser_error_0 = AnsibleParserError(bytes_2)

# Generated at 2022-06-25 05:53:29.648886
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    bytes_0 = b'role include'
    list_1 = [bytes_0]
    role_include_1 = RoleInclude(list_1)
    list_2 = [role_include_1]
    bytes_1 = b'role include'
    role_include_2 = RoleInclude.load(bytes_1, list_2)

# Generated at 2022-06-25 05:53:33.335104
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    str_0 = '&LQ\x9d\x8e\xda\x84\x00'
    role_include_0.load(str_0)

# Generated at 2022-06-25 05:53:37.705425
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b''
    list_0 = [bytes_0]
    role_include_0 = RoleInclude(list_0)
    assert False # TODO: implement your test here