

# Generated at 2022-06-25 05:44:48.933679
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Initialization
    data = 'role-name'
    play = 'play-0'

    # Invocation
    role_include_0 = RoleInclude.load(data, play)

    # Return
    return role_include_0


# Generated at 2022-06-25 05:44:56.145757
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
  bool_0 = False
  string_0 = "dummy"
  play_0 = Play()
  variable_manager_0 = VariableManager()
  playbook_loader_0 = DataLoader()

  # role definition
  role_include_0 = RoleInclude(play_0, None, unittest=True)
  role_include_0.load(string_0, play_0, None, None, variable_manager_0, playbook_loader_0)
  if(not bool_0):
    raise Exception("Expected exception")


# Generated at 2022-06-25 05:45:01.140057
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_0 = False
    str_0 = "a string"
    str_1 = "another string"
    role_include_0 = RoleInclude(bool_0)
    role_include_1 = RoleInclude()
    role_include_1.load(str_0, str_1)


# Generated at 2022-06-25 05:45:01.710840
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    return


# Generated at 2022-06-25 05:45:07.933518
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()

    try:
        role_include_0.load('=>')
        fail("Expected a ValueError to be raised")
    except Exception as e:
        assert isinstance(e, ValueError)
        assert str(e) == 'invalid syntax for set literal: =>'
    try:
        role_include_1.load(int())
        fail("Expected a ValueError to be raised")
    except Exception as e:
        assert isinstance(e, ValueError)
        assert str(e) == 'expected string or buffer'

# Generated at 2022-06-25 05:45:13.081314
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Loads a role definition from a file or dict and returns a RoleInclude object.
    data_0 = dict()
    # play = None
    # current_role_path = None
    # parent_role = None
    # variable_manager = None
    # loader = None
    role_include_0 = RoleInclude.load(data_0, None, None, None, None, None)

# Units tests for method delegate_to of class RoleInclude

# Generated at 2022-06-25 05:45:20.241933
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_data = dict()
    test_data['role_basedir'] = dict()
    test_data['role_basedir']['role_basedir_0'] = '_'
    test_data['loader_0'] = dict()
    test_data['loader_0']['loader_0_0'] = dict()
    test_data['loader_0']['loader_0_0']['loader_0_0_0'] = 'd'
    test_data['role_basedir']['role_basedir_1'] = 't'
    test_data['loader_0']['loader_0_1'] = dict()
    test_data['loader_0']['loader_0_1']['loader_0_1_0'] = '_'

# Generated at 2022-06-25 05:45:24.922061
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    data = {}
    play = None
    current_role_path = "."
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert 1 == 1


# Generated at 2022-06-25 05:45:28.385859
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    valid_data = 'test'
    play = Playbook().load('./ansible/test/playbook_data/play_one.yaml')
    role_include = role_include_0.load(valid_data, play)
    assert type(role_include) is RoleInclude


# Generated at 2022-06-25 05:45:29.851530
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_RoleInclude_load()


# vim: set fileencoding=utf-8 ts=4 sw=4 sts=4 ei noet :

# Generated at 2022-06-25 05:45:41.225329
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_0 = False
    role_include_0 = RoleInclude(bool_0)
    role_include_1 = RoleInclude()
    str_1 = "foo"
    str_2 = "foo"
    str_3 = "foo"
    str_4 = "foo"
    str_5 = "foo"
    str_6 = "foo"
    str_7 = "foo"
    str_8 = "foo"
    str_9 = "foo"
    str_10 = "foo"
    str_11 = "foo"
    str_12 = "foo"
    str_13 = "foo"
    str_14 = "foo"
    str_15 = "foo"
    str_16 = "foo"
    str_17 = "foo"
    str_18 = "foo"
    str

# Generated at 2022-06-25 05:45:44.216356
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    string_0 = "foo"
    role_definition_0 = RoleDefinition()
    role_definition_0.load(string_0)
    bool_1 = False
    role_include_4 = RoleInclude(bool_1)
    role_include_4.load(role_definition_0)


# Generated at 2022-06-25 05:45:49.689165
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_0 = False
    data_0 = {}
    role_include_0 = RoleInclude()
    role_include_1 = role_include_0.load(data_0, bool_0)
    # Possible bug in this test case?
    formatted_0 = 'RoleInclude()'
    assert formatted_0 == str(role_include_0)
    assert formatted_0 == str(role_include_1)


# Generated at 2022-06-25 05:45:56.716322
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()

    play_0 = Play()
    role_basedir_0 = "roles"
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    collection_list_0 = CollectionList()
    arg0 = [play_0, role_basedir_0, variable_manager_0, loader_0, collection_list_0]
    role_include_1 = role_include_0.load(*arg0)
    # assert role_include_1 == null
    # assert role_include_1 == null
    # assert role_include_1 == null
    # assert role_include_1 == null
    # assert role_include_1 == null
    # assert role_include_1 == null
    # assert role_include_1 == null
    # assert role_include

# Generated at 2022-06-25 05:46:07.196102
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Testing for when the data is an instance of str
    bool_0 = True
    role_include_1 = RoleInclude(bool_0)
    role_include_2 = RoleInclude()
    data_0 = "{'foo': 'bar'}"
    play_0 = RoleRequirement(data_0)
    current_role_path_0 = None
    parent_role_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    retval_1 = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)
    # Testing for when the data is an instance of dict
    bool_0 = True

# Generated at 2022-06-25 05:46:10.823530
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_0 = False
    role_include_0 = RoleInclude(bool_0)
    role_include_0.load()

    assert role_include_0 is not None
    assert role_include_0.play is False


# Generated at 2022-06-25 05:46:17.994776
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test case 0.
    str_0 = '---'
    bool_0 = False
    role_include_0 = RoleInclude.load(str_0, bool_0)
    assert isinstance(role_include_0, RoleInclude)
    # Test case 1.
    str_0 = '---'
    bool_0 = False
    str_1 = '---'
    role_include_0 = RoleInclude.load(str_0, bool_0, str_1)
    assert isinstance(role_include_0, RoleInclude)
    # Test case 2.
    str_1 = 'hostfile'
    str_2 = 'vars_prompt'
    str_3 = 'name'
    role_include_0 = RoleInclude.load(str_1, str_2, str_3)

# Generated at 2022-06-25 05:46:22.071680
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    s = string_types()
    play = Play()
    current_role_path = string_types()
    variable_manager = VariableManager()
    loader = DataLoader()
    collection_list = CollectionList()
    role_include_0 = RoleInclude.load(s, play, current_role_path, variable_manager, loader, collection_list)


# Generated at 2022-06-25 05:46:28.707620
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'ansible.builtin.yum'
    play = False
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    try:
        role_include = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except Exception as e:
        print("Shouldn't throw error here: %s" %to_native(e))


# Generated at 2022-06-25 05:46:32.210110
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "test"
    play = "test"
    current_role_path = "test"
    parent_role = "test"
    variable_manager = "test"
    loader = "test"
    collection_list = "test"



# Generated at 2022-06-25 05:46:39.879674
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_0 = False
    role_include_0 = RoleInclude(bool_0)
    role_include_1 = RoleInclude()
    role_include_1.testRoleInclude_load()


# Generated at 2022-06-25 05:46:48.411000
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_1 = False
    role_include_2 = RoleInclude(bool_1) # supports varargs, defaults to True
    # arg1, arg2
    # arg1, arg2, arg3, arg4
    # arg1, arg2, arg3, arg4, arg5
    # arg1, arg2, arg3, arg4, arg5, arg6
    # arg1, arg2, arg3, arg4, arg5, arg6, arg7
    # arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8
    # arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9
    # arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10

# Generated at 2022-06-25 05:46:58.331612
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_0 = True
    role_include_0 = RoleInclude(bool_0)
    current_role_path_0 = 'sAo}4u?7H:yT<TQ7l&'
    parent_role_0 = "role"
    variable_manager_0 = "role"
    loader_0 = 'U-~?9$z%%,C8IxWif5m'
    collection_list_0 = "role"
    test_case_0()
    role_include_0.load(current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)

# Generated at 2022-06-25 05:47:03.523317
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ret = None
    str_0 = 'foo'
    bool_0 = False
    role_include_0 = RoleInclude(bool_0)
    role_include_1 = RoleInclude()
    data_0 = 'data'
    data_1 = 'data'
    current_role_path_0 = None
    parent_role_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    ret = RoleInclude.load(str_0, role_include_0, current_role_path_0, parent_role_0,
                           variable_manager_0, loader_0, collection_list_0)
    ret = RoleInclude.load(data_0, role_include_1, None, None, None, None, None)
    ret = Role

# Generated at 2022-06-25 05:47:09.707606
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_0 = False
    str_0 = "This is a test"
    role_include_0 = RoleInclude(bool_0)
    try:
        result = role_include_0.load(str_0)
    except:
        #
        # exception handler for load
        #
        result = False
    assert result == False, "load did not return False"

# Generated at 2022-06-25 05:47:17.781059
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "test_value"
    play = False
    current_role_path = "test_value"
    variable_manager = "test_value"
    loader = "test_value"
    collection_list = "test_value"
    parent_role = "test_value"

    # Invoke method
    role_include_0 = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    role_include_1 = role_include_0.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader, collection_list=collection_list)



# Generated at 2022-06-25 05:47:19.924813
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    role_include_0 = RoleInclude()

    # check that the load method of the RoleInclude class works as expected
    pytest.xfail("Need to write test case for load method of the RoleInclude class")

# Generated at 2022-06-25 05:47:27.115986
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "fake data"
    play = "fake play"
    current_role_path = "fake current_role_path"
    parent_role = "fake parent_role"
    variable_manager = "fake variable_manager"
    loader = "fake loader"
    collection_list = "fake collection_list"
    role_include = RoleInclude()
    role_include.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

# Generated at 2022-06-25 05:47:33.989559
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_2 = RoleInclude()
    data_0 = ""
    current_role_path_0 = ""
    parent_role_0 = ""
    bool_0 = False
    variable_manager_0 = ""
    loader_0 = ""
    ret_val_0 = role_include_2.load(data_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0)
    print(ret_val_0)


if __name__ == '__main__':
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:47:40.993327
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader, module_loader, lookup_loader
    from ansible.playbook.play import Play
    from ansible.module_utils.six import PY3
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import TaskInclude

# Generated at 2022-06-25 05:47:53.139545
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play_0 = Play()
    current_role_path_0 = '/etc/ansible/roles'
    parent_role_0 = None
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    collection_list_0 = None
    data_0 = None
    result = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)
    assert result is not None


# Generated at 2022-06-25 05:47:56.676609
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    data = ''
    play = Play()
    current_role_path = ''
    parent_role = Role()
    variable_manager = VariableManager()
    loader = DataLoader()
    # test exception is raised for data of type string and containing ','
    with pytest.raises(AnsibleError):
        role_include_0.load(data, play, current_role_path, parent_role, variable_manager, loader)

# Generated at 2022-06-25 05:48:06.558450
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_0 = False
    role_include_0 = RoleInclude(bool_0)
    str_0 = 'a'
    dict_0 = {}
    dict_0['a'] = 1
    dict_0['b'] = 2
    dict_0['c'] = 3
    obj_0 = AnsibleBaseYAMLObject(dict_0)
    bool_0 = False
    variable_manager_0 = variable_manager()
    loader_0 = loader()
    collection_list_0 = collection_list()
    result = role_include_0.load(str_0, role_include_1, role_include_1, role_include_1, variable_manager_0, loader_0, collection_list_0)

# Generated at 2022-06-25 05:48:17.804727
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    subprocess = MockSubprocess()
    subprocess.call = MockSubprocessCall()
    subprocess.call.return_value = 0
    subprocess.check_output = MockSubprocessCall()
    subprocess.check_output.return_value = "role_collection"
    ansible.module_utils.basic.AnsibleModule.run_command = MockAnsibleModuleRunCommand()
    ansible.module_utils.basic.AnsibleModule.run_command.return_value = 0
    ansible.module_utils.basic.AnsibleModule.log = MockAnsibleModuleLog()

    data = {
        'name': 'test1',
        'collections': [ 'namespace1.collection1' ],
    }

    temp_directory = tempfile.mkdtemp()

# Generated at 2022-06-25 05:48:20.980822
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_0 = False
    role_include_0 = RoleInclude(bool_0)
    role_include_1 = RoleInclude()


# Generated at 2022-06-25 05:48:24.683948
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # when role def is a string
    role_include_0 = RoleInclude(None)
    # when role definition is a dict
    role_include_1 = RoleInclude()

# Generated at 2022-06-25 05:48:28.611563
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    load_0 = load
    load_1 = load_0
    load_2 = load_1
    load_3 = load_2
    load_4 = load_3
    _ = load_4


# Generated at 2022-06-25 05:48:38.248853
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # test with string_types
    data_0 = "ansible-test Role name"
    play_0 = role_include_0.get_play()
    current_role_path_0 = role_include_0.get_current_role_path()
    parent_role_0 = role_include_0.get_parent_role()
    variable_manager_0 = role_include_0.get_variable_manager()
    loader_0 = role_include_0.get_loader()
    collection_list_0 = role_include_0.get_collection_list()
    role_include_2 = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)

# Generated at 2022-06-25 05:48:40.684375
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.load()


# Generated at 2022-06-25 05:48:42.862832
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'this'
    role_include_0 = RoleInclude()
    role_include_0.load(str_0, None, None, None, None)
 