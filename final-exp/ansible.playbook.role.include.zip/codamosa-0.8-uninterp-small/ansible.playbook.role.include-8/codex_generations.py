

# Generated at 2022-06-25 05:44:46.957498
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    role_include_0.get_role_params = MagicMock(return_value=dict_0)
    role_include_0.load_data = MagicMock(return_value=role_include_0)
    role_include_1 = RoleInclude.load(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    assert_equal(role_include_1, role_include_0)


# Generated at 2022-06-25 05:44:53.702293
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    role_include_0.load(dict_0)
    role_include_0.load(bool_0)
    role_include_0.load(dict_0)
    role_include_0.load(bool_0)
    role_include_0.load(dict_0)
    role_include_0.load(bool_0)
    role_include_0.load(dict_0)
    role_include_0.load(bool_0)
    role_include_0.load(dict_0)
    role_include_0.load(bool_0)
    role_include_0.load(dict_0)

# Generated at 2022-06-25 05:44:56.953822
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    role_include_0.load(dict_0, bool_0, bool_0)

# Generated at 2022-06-25 05:45:02.645091
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    try:
        role_include_0.load(dict_0, bool_0, bool_0, bool_0, bool_0, bool_0)
        assert False
    except AnsibleParserError:
        assert True

# Generated at 2022-06-25 05:45:04.545381
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-25 05:45:11.563549
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_load = {}
    bool_load = False
    role_include_load = RoleInclude(bool_load, bool_load, bool_load)
    dict_load = {'role': 'something'}
# Load in dict_load
    with pytest.raises(AnsibleError) as excinfo:
        role_include_load.load(dict_load, bool_load, bool_load, bool_load, bool_load)
    excinfo.match(r'Invalid old style role requirement')


# Generated at 2022-06-25 05:45:18.243052
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    role_include_1 = RoleInclude(bool_0, bool_0, bool_0)
    test_data = [
        (dict, dict_0),
        (dict, dict_0),
        (dict, dict_0)]
    for index, (arg1, expected) in enumerate(test_data):
        with test_case(index, arg1, expected):
            result = role_include_0.load(arg1, role_include_1, bool_0, bool_0, bool_0, bool_0)
            assert result == expected

test_case_0()
test_RoleInclude_load()

# Generated at 2022-06-25 05:45:28.920042
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    dl=DataLoader()
    vm=VariableManager()
    role_include_0 = RoleInclude(bool_0, bool_0, vm)

    dict_0 = dict({"roles": [{"role": "foo"}]})
    dict_1 = dict({"role": "foo"})
    dict_2 = dict({"role": "foo"})
    yaml_1 = dict_1
    dict_3 = dict({"role": "foo"})
    dict_4 = dict({"role": "foo"})

    role_include_0.load(dict_0, bool_0, vm, loader=dl)

# Generated at 2022-06-25 05:45:35.311047
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    dict_0 = {}
    bool_0 = False
    variable_manager_0 = variable_manager_0 = {}
    loader_0 = loader_0 = {}
    collection_list_0 = collection_list_0 = {}
    item_0 = role_include_0.load(dict_0, bool_0, bool_0, bool_0, variable_manager_0, loader_0, collection_list_0)

# Generated at 2022-06-25 05:45:43.711495
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def mock_load_data(data, variable_manager=None, loader=None):
        """Mock function used instead of load_data() when called from RoleInclude.load()"""
        return data

    def mock_load(data, play, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None):
        """Mock function used instead of load() when called from RoleInclude.load()"""
        return data

    # Test case where data is a dict
    data = {}
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    # Replace mock_load_data and mock_load instead of calling them
    RoleInclude.load_data = mock_load_

# Generated at 2022-06-25 05:45:48.252914
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    role_include_0.load(dict_0, bool_0, bool_0, bool_0, bool_0)
    print("Ran test_RoleInclude_load")


# Generated at 2022-06-25 05:45:53.431393
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    bool_1 = True
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    # testing for exception here, as the method will not return
    # a value if an exception is raised in the method
    try:
        role_include_0.load(dict_0, bool_0, bool_0, bool_0, bool_1, bool_1)
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 05:45:55.642343
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    # Testing of load is an implementation.



# Generated at 2022-06-25 05:46:01.606830
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    str_0 = ""
    str_1 = ""
    role_include_0 = RoleInclude(dict_0, dict_0, dict_0)
    try:
        role_include_0.load(str_0, dict_0, str_1, dict_0, dict_0, dict_0)

    except TypeError:
        return
    assert False



# Generated at 2022-06-25 05:46:06.176879
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    assert role_include_0.load(dict_0, bool_0) == role_include_0, "RoleInclude_load should return the instance"


# Generated at 2022-06-25 05:46:08.820215
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    # TODO: Add test here

# Generated at 2022-06-25 05:46:12.901205
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    assert isinstance(RoleInclude.load(dict_0, bool_0, bool_0, bool_0, bool_0), RoleInclude)

# Generated at 2022-06-25 05:46:16.058446
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    role_0 = role_include_0.load(dict_0, bool_0, bool_0)
    return role_0


test_case_0()
test_RoleInclude_load()

# Generated at 2022-06-25 05:46:24.287767
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    string_0 = '@(7[R,v1$V;'
    string_1 = '~5.6U-q5`<E`Z=H?*D:>gK>:3-C9]{Nk-J'
    bool_0 = False
    with pytest.raises(AnsibleError) as exception_info:
        ri.load(string_0, None, string_1, None)
        assert exception_info.value.args[0] == "Invalid old style role requirement: %s" % string_0

    string_2 = ""
    with pytest.raises(AnsibleParserError) as exception_info:
        ri.load(string_2, None, None, None)

# Generated at 2022-06-25 05:46:28.760423
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    role_definition_0 = role_include_0.load(dict_0, bool_0, bool_0, bool_0, bool_0, bool_0)


# End of generated test code

# Generated at 2022-06-25 05:46:39.920409
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    str_0 = ','
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    if not (isinstance(str_0, string_types) or isinstance(str_0, dict) or isinstance(str_0, AnsibleBaseYAMLObject)):
        return
    else:
        if isinstance(str_0, string_types) or ',' in str_0:
            raise AnsibleError('')
        ri = RoleInclude(bool_0, bool_0, bool_0)
        return ri.load(str_0, bool_0, bool_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 05:46:40.851116
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Work in progress
    pass


# Generated at 2022-06-25 05:46:42.610212
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    role_include_0 = RoleInclude()
    role_include_1 = role_include_0.load(dict_0)


# Generated at 2022-06-25 05:46:45.821484
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    role_include_0.load(dict_0)

# Generated at 2022-06-25 05:46:47.874215
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def test_func():
        dict_arg = {}
        test_obj = RoleInclude()
        dict_ret = test_obj.load(dict_arg)
        return dict_ret
    test_func()

# Generated at 2022-06-25 05:46:58.897861
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {"tasks": ["name: foo", {"local_action": {"_delegate_to": "foo"}}], "name": "foo", "role_name": "foo", "__ansible_roles_path": [], "vars": {"foo": ["name: foo", "val"]}, "_ansible_role_path": "/etc/ansible/roles", "__ansible_roles_path2": ["/etc/ansible/roles"], "handlers": ["name: foo"], "hosts": ["host1", "host2"], "block": {"block": "foo"}, "import_playbook": None}
    dict_1 = {"hosts": ["host1", "host2"], "name": "foo"}
    dict_2 = {"hosts": ["host1", "host2"], "name": "foo"}
   

# Generated at 2022-06-25 05:47:10.075848
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    string_0 = 'test_string'
    string_1 = 'test_string'
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, string_1, bool_0)
    role_include_0.load_data(dict_0, bool_0)
    role_include_0.loader = bool_0
    role_include_0.play = bool_0
    role_include_0.load_data(string_0, bool_0)
    loader_0 = role_include_0.loader
    play_0 = role_include_0.play
    try:
        role_include_0.load_data(string_1, bool_0)
    except Exception as exc:
        assert isinstance(exc, AnsibleParserError)
    role_

# Generated at 2022-06-25 05:47:17.340214
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    variable_manager_0 = VariableManager(bool_0)
    role_include_0 = RoleInclude.load(dict_0, bool_0, bool_0, bool_0, variable_manager_0, bool_0, bool_0)
    assert isinstance(role_include_0, RoleInclude)
    role_include_0 = RoleInclude.load(dict_0, '', bool_0, bool_0, bool_0, bool_0, bool_0)
    assert isinstance(role_include_0, RoleInclude)
    role_include_0 = RoleInclude.load('', bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    assert isinstance(role_include_0, RoleInclude)

# Generated at 2022-06-25 05:47:18.323976
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    role_include_0 = RoleInclude.load(dict_0)


# Generated at 2022-06-25 05:47:27.798475
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    dict_1 = {'key_0': dict_0}
    dict_1.update(dict_0)
    dict_2 = {'key_2': dict_1}
    dict_2.update(dict_1)
    dict_3 = {'key_3': dict_2}
    dict_3.update(dict_2)
    dict_4 = {'key_2': dict_3}
    dict_4.update(dict_3)
    dict_5 = {'key_1': dict_4}
    dict_5.update(dict_4)
    dict_6 = {'key_0': dict_5}

# Generated at 2022-06-25 05:47:40.993479
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    dict_1 = {}
    dict_2 = {}
    dict_1['name'] = dict_2
    dict_2['field_0'] = dict_0
    dict_2['field_1'] = dict_0
    dict_0['field_0'] = dict_0
    dict_0['field_1'] = dict_0
    dict_1['field_0'] = dict_0
    dict_1['field_1'] = dict_0
    dict_0['field_0'] = dict_1
    dict_0['field_1'] = dict_0
    dict_1['field_0'] = dict_0
    dict_1['field_1'] = dict_0
    dict_1['field_2'] = dict_0

# Generated at 2022-06-25 05:47:45.231393
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    dict_1 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    role_include_0.load(dict_0, dict_1)

# Generated at 2022-06-25 05:47:48.744550
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    role_include_1 = RoleInclude(bool_0, bool_0, bool_0)
    role_include_0 = role_include_1.load(dict_0, bool_0)

# Generated at 2022-06-25 05:47:55.107602
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Arguments
    data_0 = 'role'
    play_0 = 'name'
    current_role_path_0 = None
    parent_role_0 = 'name'
    variable_manager_0 = 'name'
    loader_0 = 'name'
    collection_list_0 = 'name'
    # Return value
    # Execution
    with pytest.raises(AnsibleError):
        RoleInclude.load(data_0, play_0, current_role_path=current_role_path_0, parent_role=parent_role_0, variable_manager=variable_manager_0, loader=loader_0, collection_list=collection_list_0)
    # at line 316

# Generated at 2022-06-25 05:48:02.298424
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    dict_0 = {}
    # AssertionError: u'Invalid role definition: {}' != None
    #assert role_include_0.load(None, bool_0, bool_0, bool_0, bool_0, bool_0) == None


test_case_0()

# Generated at 2022-06-25 05:48:10.659219
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    attr_0 = Attribute(dict_0, loader=bool_0)
    str_0 = "debug"
    str_1 = "hosts"
    str_2 = "hosts"
    str_3 = "role_name"
    str_4 = "name"
    str_5 = "playbook_dir"
    str_6 = "play_dir"
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    role_include_1 = RoleInclude.load(attr_0, attr_0)
    role_include_2 = RoleInclude.load(attr_0, attr_0)
    str_7 = "tasks"
    str_8 = "vars"

    # Verify that this only works for string types

# Generated at 2022-06-25 05:48:19.228630
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:48:26.724275
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    bool_1 = True
    str_0 = "a"
    str_1 = "b"
    role_include_0 = RoleInclude(bool_1, bool_1, bool_1)
    role_include_0.get_attr_metadata = mock_get_attr_metadata
    role_include_0.process_block_args = mock_process_block_args
    role_include_0.load_data = mock_load_data
    list_0 = [str_0, str_1]
    role_include_0.load(list_0, bool_0, bool_0, bool_1)


# Generated at 2022-06-25 05:48:36.917887
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    dict_0 = {}
    bool_0 = False
    role_include_1 = RoleInclude(bool_0, bool_0, bool_0)
    role_include_1.load(dict_0, bool_0, bool_0, bool_0, bool_0, dict_0)
    dict_1 = {}
    role_include_1.load(dict_1, bool_0, bool_0, bool_0, bool_0, dict_1)
    dict_2 = {}
    role_include_1.load(dict_2, bool_0, bool_0, bool_0, bool_0, dict_2)
    dict_3 = {}

# Generated at 2022-06-25 05:48:41.615939
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    current_role_path = 'ping'
    parent_role = 'ping'
    play_0 = 'ping'
    loader_0 = 'ping'
    variable_manager_0 = 'ping'
    data_0 = 'ping'
    role_include_0 = RoleInclude()
    ret = role_include_0.load(data_0, play_0, current_role_path, parent_role, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:49:01.555827
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Init some variables
    string_0 = "file.yml"
    role_include_0 = RoleInclude()

    # Create a RoleInclude object from string
    try:
        role_include_0.load(string_0, string_0, string_0, string_0, string_0)
    except AnsibleError as e:
        print("AnsibleError caught: {0}".format(e))
        return


# Generated at 2022-06-25 05:49:09.565196
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # set-up mock
    mock_dict = {}
    mock_dict['_ansible_no_log'] = None
    mock_dict['changed_when'] = None
    mock_dict['environment'] = None
    mock_dict['failed_when'] = None
    mock_dict['handlers'] = None
    mock_dict['ignore_errors'] = None
    mock_dict['pre_tasks'] = None
    mock_dict['post_tasks'] = None
    mock_dict['always'] = None
    mock_dict['any_errors_fatal'] = None
    mock_dict['no_log'] = False
    mock_dict['notify'] = None
    mock_dict['register'] = None
    mock_dict['retries'] = None

# Generated at 2022-06-25 05:49:19.582008
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = dict()
    play_0 = Play()
    current_role_path_0 = 'dXNlci9zb21lb25lL2Fuc2libGUvcGxheWJvb2tzL2NvbnRyb2xsZXIucGxheWJvb2s='
    parent_role_0 = AnsibleRole(play_0, 'dXNlci9zb21lb25lL2Fuc2libGUvcGxheWJvb2tzL2NvbnRyb2xsZXIucGxheWJvb2s=')
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    collection_list_0 = [
        AnsibleCollectionRequirement()
    ]

# Generated at 2022-06-25 05:49:28.909906
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.reader import AnsibleFileReader

    # Create an instance of a parser and load the data
    # Create an instance of a AnsibleFileReader
    ansible_file_reader_0 = AnsibleFileReader('roles/test/tasks/main.yml')
    # Get the data from the instance of AnsibleFileReader
    data = ansible_file_reader_0.read()

    # Create an instance of a AnsibleDumper
    ansible_dumper_0 = AnsibleDumper()
    # Get the data from the instance of AnsibleD

# Generated at 2022-06-25 05:49:34.222452
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    dict_1 = {}
    # Test with: (dict_0, dict_1, False, None, False)
    test_case_0()

if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-25 05:49:43.929301
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Setting of mutable_mapping attributes requires special handling
    # (__setattr__, __getattr__)
    ri = RoleInclude()
    ri.load('test_case_0', bool_0, bool_0, bool_0)
    pass

if __name__ == '__main__':
    test_RoleInclude_load()

    import ansible.playbook.a
    import ansible.playbook.play
    import ansible.playbook.role.definition
    import ansible.playbook.role.requirement
    import ansible.playbook.task

    # Unit test for class RoleInclude
    # staticmethod load of class C
    role_include_0_1 = RoleInclude.load('test_case_0', bool_0, bool_0, bool_0)
    assert isinstance

# Generated at 2022-06-25 05:49:51.893875
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bool_0 = bool()
    role_definition_0 = RoleDefinition(bool_0, bool_0, bool_0)
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    obj_0 = AnsibleParserError("Invalid role definition")
    obj_1 = AnsibleError("Invalid old style role requirement")
    obj_2 = "Invalid old style role requirement"
    str_0 = str()
    obj_3 = AnsibleBaseYAMLObject(str_0)
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool

# Generated at 2022-06-25 05:49:59.680960
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    dict_1 = {}
    dict_0.__setitem__("role_name", dict_1)
    bool_0 = False
    role_0 = RoleInclude(bool_0, bool_0, bool_0)
    role_include_0 = role_0.load(dict_0, bool_0)
    _var_0 = role_include_0.get_name()
    assert _var_0 == "role_name"


# Generated at 2022-06-25 05:50:06.533858
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    bool_0 = False
    role_include_0 = RoleInclude(bool_0, bool_0, bool_0)
    role_include_0.load(dict_0)


# Generated at 2022-06-25 05:50:18.378061
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    int_2 = 3
    str_0 = 'test'
    # role_include_0 = RoleInclude(dict_0, dict_0, dict_0)
    # role_include_1 = role_include_0.load(int_2, dict_0, dict_0)
    # assert role_include_1.include is dict_0
    # assert role_include_1.include_role is dict_0
    # assert role_include_1.role is dict_0
    # assert role_include_1.tasks is dict_0
    # role_include_2 = role_include_0.load(str_0, dict_0, dict_0)
    # assert role_include_2.include is dict_0
    # assert role_include_2.include_role is dict_