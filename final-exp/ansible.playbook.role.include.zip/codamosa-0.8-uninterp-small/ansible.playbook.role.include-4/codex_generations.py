

# Generated at 2022-06-25 05:44:45.772216
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        role_define_0 = RoleDefinition()
        str_0 = 'E\r!RB}#'
        dict_0 = dict()
        # Act
        RoleInclude.load(str_0, str_0, str_0, str_0, dict_0, dict_0, dict_0)
        # Assert
        #assert role_include_0 == role_include_1
    except Exception as e:
        # Assert
        assert False
    else:
        # Assert
        assert True

# Generated at 2022-06-25 05:44:49.864530
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'E\r!RB}#'
    str_1 = 'E\r!RB}#'
    role_include_0 = RoleInclude(str_0)
    role_include_1 = role_include_0.load(str_1)

# Generated at 2022-06-25 05:45:01.010124
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'become_user'
    str_1 = 'become_method'
    str_2 = 'become_ask_pass'
    str_3 = 'become'
    str_4 = 'remote_user'
    str_5 = 'sudo_user'
    str_6 = 'sudo'
    str_7 = 'sudo_ask_pass'
    str_8 = 'serial'
    str_9 = 'hosts'
    str_10 = 'name'
    str_11 = 'Y\r!dR}#'
    role_include_0 = RoleInclude(str_11)
    str_12 = 'B\r!~R}#'
    str_13 = 'A\r!OR}#'
    str_14 = 'F\r!vR}#'


# Generated at 2022-06-25 05:45:03.940711
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'En,glp'
    str_1 = 'En,glp'
    role_include_0 = RoleInclude(str_0)
    role_include_0.load(str_1)


# Generated at 2022-06-25 05:45:13.932506
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'E\r!RB}#'
    dict_0 = {}
    dict_1 = {'B~1#%': '#_<JwH%m', '+j': 'E\r!RB}#', '-j': 'E\r!RB}#', '#': 'E\r!RB}#'}
    dict_2 = {'B~1#%': '#_<JwH%m', '+j': 'E\r!RB}#', '-j': 'E\r!RB}#', '#': 'E\r!RB}#'}

# Generated at 2022-06-25 05:45:19.336839
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'E\r!RB}#'
    role_include_0 = RoleInclude(str_0)
    # Test call with new style of role
    list_0 = ["blah"]
    dict_0 = {"include_role": list_0}
    dict_1 = {"include_tasks": dict_0}
    role_include_0.load(dict_1)

# Generated at 2022-06-25 05:45:23.773422
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    var_0 = '- src: ./lib/my-stuff\n    name: my_stuff\n    version: 1.2\n    private: yes\n'
    var_1 = None
    var_2 = '\n'
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None


# Generated at 2022-06-25 05:45:26.820206
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'E\r!RB}#'
    role_include_0 = RoleInclude(str_0)

# vim: set fileencoding=utf-8 filetype=python expandtab shiftwidth=4 tabstop=4 softtabstop=4 :

# Generated at 2022-06-25 05:45:31.294666
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    os.environ['ANSIBLE_CONFIG'] = '/tmp/eyx_7444489259814999535'
    str_0 = 'E\r!RB}#'
    str_1 = 'C6\x1dKZ#'
    role_include_0 = RoleInclude(str_0)
    role_definition_0 = role_include_0.load(str_1)

    print(role_definition_0)


if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-25 05:45:39.870874
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = '\n'
    play_0 = ''
    current_role_path_0 = 'PF/`c%Tg'
    variable_manager_0 = ''
    loader_0 = 'n1l8'
    collection_list_0 = 'y3kx'
    role_include_0 = RoleInclude.load(str_0, play_0, current_role_path_0, variable_manager_0, loader_0, collection_list_0)

if __name__ == '__main__':
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:45:50.853543
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'E\r!RB}#'
    str_1 = '`2&N%c'

# Generated at 2022-06-25 05:45:58.468513
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'E\r!RB}#'
    str_1 = '%|2hE^'
    str_2 = '$&N>Q-L'
    str_3 = '6`(ZJ~'
    str_4 = '^bBm*}'
    role_include_0 = RoleInclude(str_0, 'd\x7fFnQ<', str_1, '', str_4, str_3)
    role_include_1 = role_include_0.load(str_2, 'h}Q{Ya[')


# Generated at 2022-06-25 05:46:08.777258
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'E\r!RB}#'
    str_1 = 'E\r!RB}#'
    str_2 = 'E\r!RB}#'
    str_3 = 'E\r!RB}#'
    str_4 = 'E\r!RB}#'
    str_5 = 'E\r!RB}#'
    str_6 = 'E\r!RB}#'
    str_7 = 'E\r!RB}#'
    str_8 = 'E\r!RB}#'
    role_include_0 = RoleInclude(str_0)
    role_include_0.load(str_1, str_2, str_3, str_4, str_5, str_6, str_7, str_8)


# Generated at 2022-06-25 05:46:11.518007
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = dict()
    RoleInclude_load_0 = RoleInclude.load(data_0)
    assert RoleInclude_load_0 is not None

# Generated at 2022-06-25 05:46:12.740354
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()
# Test exceptions for class RoleInclude

# Generated at 2022-06-25 05:46:17.913549
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_basedir_0 = 'tLH&%'
    loader_0 = 'w,p*1'
    role_include_0 = RoleInclude(role_basedir=role_basedir_0, loader=loader_0)
    data_0 = ''
    play_0 = '^dQe+'
    variable_manager_0 = 'Zh\x7f'
    collection_list_0 = ':Uz'
    ret = role_include_0.load(data_0, play_0, variable_manager=variable_manager_0, collection_list=collection_list_0)

# Generated at 2022-06-25 05:46:19.853828
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test case 0
    str_0 = 'E\r!RB}#'
    role_include_0 = RoleInclude.load(str_0)

# Generated at 2022-06-25 05:46:22.389017
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        str_3 = 'A'
        role_include_1 = RoleInclude(str_3)

        assert False
    except Exception:
        assert True


# Generated at 2022-06-25 05:46:23.234414
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-25 05:46:28.912968
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    collection_list = {'name': 'test_collections/ansible_test_test', 'version': '1.0'}
    str_0 = 'E\r!RB}#'
    yaml_0 = 'test'
    path_0 = 'test'

    role_include_0 = RoleInclude.load(str_0, yaml_0, path_0, collection_list=collection_list)

# Generated at 2022-06-25 05:46:40.177080
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:46:48.206476
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    definition_0 = 'E\r!RB}#'
    play_0 = '<3'
    role_include_0 = RoleInclude(definition_0, play=play_0)

if __name__ == '__main__':
    import os
    import sys

    if len(sys.argv) != 2:
        print("Usage: %s <case_name>" % sys.argv[0])
        sys.exit(1)

    test_case = sys.argv[1]

    if test_case == 'test_0':
        test_case_0()
    elif test_case == 'test_1':
        test_RoleInclude_load()
    else:
        print('Unknown test case')
        sys.exit(1)

# Generated at 2022-06-25 05:46:52.154267
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'my_role\r!RB}#'
    role_include_0 = RoleInclude.load(str_0)


# Generated at 2022-06-25 05:47:00.690118
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'E\r!RB}#'
    str_1 = 'b>%\x1fJv?j'
    str_2 = '\x0e\x1e\x1d\x10>%\x1fJv?j'
    str_3 = '\x0e\x1e\x1d\x10>%\x1fJv?j\rp\x0f\x0e\x1d:R\x0e'
    ansible_base_yaml_object_0 = AnsibleBaseYAMLObject(str_3)
    role_include_0 = RoleInclude(str_0)

# Generated at 2022-06-25 05:47:04.758596
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'E\r!RB}#'
    role_include_0 = RoleInclude.load(str_0)

# Generated at 2022-06-25 05:47:10.060451
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'E\r!RB}#'
    role_include_0 = RoleInclude(str_0)
    str_1 = 'E\r!RB}#'
    data = str_1
    role_include_1 = RoleInclude.load(data, role_include_0)
    print(role_include_1)

# Generated at 2022-06-25 05:47:15.533472
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Input parameters
    data = ''
    play = ''
    current_role_path = ''
    parent_role = ''
    variable_manager = ''
    loader = ''
    collection_list = ''

    # Passing parameter data
    role_include_0 = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)


# Generated at 2022-06-25 05:47:17.581563
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = "fO.d\r'`6U`}\rF)O\rK'\r:i$M\rB}#"
    role_include_0 = RoleInclude.load(data_0, play)


# Generated at 2022-06-25 05:47:23.716891
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'E\r!RB}#'
    role_basedir_0 = 'iFj0`'
    variable_manager_0 = Attribute(role_basedir_0)
    play_0 = 'KpCX~'
    role_include_0 = RoleInclude(play_0, role_basedir_0, variable_manager_0)
    role_basedir_1 = RoleRequirement(str_0)
    current_role_path_0 = 'g1'
    parent_role_0 = 'b'
    loader_0 = RoleDefinition(current_role_path_0, parent_role_0)
    data_0 = '&'

# Generated at 2022-06-25 05:47:32.780717
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = '"&'
    str_1 = '$c%7'
    str_2 = 'It'
    dict_0 = {}
    role_include_0 = RoleInclude(str_0, str_2, dict_0, str_1)
    str_3 = 'g'
    str_4 = 'PG'
    dict_1 = {}
    str_5 = '!'
    dict_2 = {}
    str_6 = 'B'
    str_7 = ';'
    dict_3 = {}
    role_include_1 = role_include_0.load(str_7, dict_1, str_3, dict_2, dict_3, str_4, str_5, str_6)

if __name__ == '__main__':
    test_case_0()
