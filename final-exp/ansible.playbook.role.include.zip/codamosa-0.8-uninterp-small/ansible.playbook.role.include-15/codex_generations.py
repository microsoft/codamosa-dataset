

# Generated at 2022-06-25 05:44:40.225973
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-25 05:44:47.477933
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    tuple_0 = ()
    role_include_0 = RoleInclude(tuple_0)
    # No exception for a play, role basedir, or variable manager is required
    # if the data is a string and there is a comma present.
    role_include_0.load('lib-0.0.1,0.0.2', tuple_0, tuple_0, tuple_0, tuple_0)
    # For the exception test, load will be called with a string and no comma.
    role_include_0.load('lib-0.0.3', tuple_0, tuple_0, tuple_0, tuple_0)
    # No exception for a play, variable manager, or loader is required,
    # and current role path will be set to the default value, None.
    # If the data is a dict or AnsibleBaseYAM

# Generated at 2022-06-25 05:44:54.520965
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    tuple_0 = ()
    role_include_0 = RoleInclude(tuple_0)
    int_0 = -2284
    float_0 = 2810.5161
    role_include_1 = role_include_0.load(int_0, float_0, int_0, tuple_0)
    str_0 = role_include_1.__str__()
    assert str_0 == '<RoleInclude /tmp/ansible/test_role_include/tasks/main.yml>'


# Generated at 2022-06-25 05:45:01.140948
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    tuple_1 = ()
    role_include_1 = RoleInclude(tuple_1)
    str_0 = '.'
    int_1 = -1918
    tuple_2 = ()
    int_2 = -2284
    float_1 = 2810.5161
    var_1 = role_include_1.load(str_0, int_1, int_2, tuple_2)
    print(var_1)


# Generated at 2022-06-25 05:45:04.613279
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    tuple_0 = ()
    role_include_0 = RoleInclude(tuple_0)
    int_0 = -2284
    float_0 = 2810.5161
    var_0 = role_include_0.load(int_0, float_0, int_0, tuple_0)

# Generated at 2022-06-25 05:45:09.655420
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    tuple_0 = ()
    role_include_0 = RoleInclude(tuple_0)
    int_0 = -2284
    float_0 = 2810.5161
    var_0 = role_include_0.load(int_0, float_0, int_0, tuple_0)

# Generated at 2022-06-25 05:45:14.745707
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    tuple_11 = ()
    tuple_12 = (tuple_11,)
    role_include_2 = RoleInclude(tuple_12)
    str_2 = 'abc'
    int_10 = 25
    float_1 = 2439.0
    var_1 = role_include_2.load(str_2, float_1, int_10, tuple_12)
    # AssertionError: False is not True
    assert var_1

# Generated at 2022-06-25 05:45:18.738134
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    tuple_0 = ()
    role_include_0 = RoleInclude(tuple_0)
    int_0 = -2284
    float_0 = 2810.5161
    var_0 = role_include_0.load(int_0, float_0, int_0, tuple_0)


# Generated at 2022-06-25 05:45:19.574227
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #test_case_0()
    pass

# Generated at 2022-06-25 05:45:24.241131
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    tuple_0 = ()
    role_include_0 = RoleInclude(tuple_0)
    int_0 = -2284
    float_0 = 2810.5161
    var_0 = role_include_0.load(int_0, float_0, int_0, tuple_0)

# Generated at 2022-06-25 05:45:26.286569
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:45:28.186169
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = -1023.6
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(float_0, role_include_0)

# Generated at 2022-06-25 05:45:29.910992
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = -1023.6
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(float_0, role_include_0)

# Generated at 2022-06-25 05:45:35.727934
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    # Invoke method load with a few valid values
    test_case_0()
    # Invoke method load with a few invalid values
    try:
        test_case_0()
    except AnsibleParserError:
        # Expected to throw an exception
        pass
    except:
        # Unexpected exception
        test_case_0()

########################################################################
#

# Generated at 2022-06-25 05:45:43.887195
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = -1023.6
    float_1 = -1023.6
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(float_0, role_include_0)
    role_include_0.load(float_1, role_include_0, loader=role_include_0)
    role_include_0.load(float_1, role_include_0, loader=role_include_0, variable_manager=role_include_0)
    role_include_0.load(float_1, role_include_0, loader=role_include_0, variable_manager=role_include_0, collection_list=role_include_0)

# Generated at 2022-06-25 05:45:46.950200
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = -6591.08
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(float_0, role_include_0)


# Generated at 2022-06-25 05:45:49.958737
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = 100
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(float_0, role_include_0)
    #assert var_0 == '1.123'


# Generated at 2022-06-25 05:45:56.687760
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import tempfile
    import ansible_test_data
    import os
    datafile = tempfile.NamedTemporaryFile()
    datafile.write(bytes(ansible_test_data.ANSIBLE_TEST_DATA_ROLE_INCLUDE, 'utf-8'))
    datafile.flush()

    r = RoleInclude()
    r.load_data(datafile.name)

    assert r.name == 'test'
    try:
        r.load_data(datafile.name)
    except AnsibleParserError:
        os.unlink(datafile.name)
    else:
        assert False, "Test case should have failed"
    datafile.close()
    # Clean up temporary files
    os.unlink(datafile.name)

# Generated at 2022-06-25 05:45:58.905019
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        test_case_0()
    except Exception as e:
        raise e


# Example usage

# Generated at 2022-06-25 05:46:04.549281
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    assert role_include_0.load(role_include_0, role_include_1) == role_include_2.load(role_include_3, role_include_3)


# Generated at 2022-06-25 05:46:10.694391
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = -1023.6
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(float_0, role_include_0)
    assert var_0 == role_include_0, 'var_0 = %s' % var_0
    pass


# Generated at 2022-06-25 05:46:13.261699
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = -1023.6
    role_include_0 = RoleInclude()
    a_0 = role_include_0.load(float_0, role_include_0)
    assert role_include_0

# Generated at 2022-06-25 05:46:15.067741
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = -1023.6
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(float_0, role_include_0)

# Generated at 2022-06-25 05:46:23.301158
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    data_0 = u'role_include_2'
    data_1 = u'role_include_1'
    data_2 = u'role_include_0'

# Generated at 2022-06-25 05:46:26.571921
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = -1023.6
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(float_0, role_include_0)


# Generated at 2022-06-25 05:46:29.606025
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = -1023.6
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(float_0, role_include_0)


# Generated at 2022-06-25 05:46:31.640212
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # load is handling a float
    with pytest.raises(AnsibleParserError):
        test_case_0()


# Generated at 2022-06-25 05:46:42.741716
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    float_0 = float(10)
    float_1 = float(100)
    float_2 = float(1000)

    role_include_0 = RoleInclude()

    str_0 = str()
    path_0 = 'roles/test_dir_0/test_dir_1/role_name'
    path_1 = 'roles/test_dir_0/test_dir_1'
    path_2 = 'roles/test_dir_0'
    path_3 = 'role_name'
    role_basedir_0 = os.path.abspath(os.path.sep)
    role_basedir_1 = os.path.abspath(os.path.sep)
    role_basedir_2 = os.path.abspath(os.path.sep)
    role

# Generated at 2022-06-25 05:46:44.908667
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("Testing load of RoleInclude")
    test_case_0()


if __name__ == "__main__":
    test_RoleInclude_load()

# Generated at 2022-06-25 05:46:46.080061
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-25 05:46:51.243504
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    c = RoleInclude()
    var_1 = c.load(c, c)


# Generated at 2022-06-25 05:46:54.596904
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    host = Host()
    role_include = RoleInclude(play=host)
    role_include = role_include.load(host, host)
    expected = None
    actual = host
    assert expected == actual


# Generated at 2022-06-25 05:46:58.335886
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Check if the method load of class RoleInclude
    # can return a RoleRequirement instance.

    role_include_0 = RoleInclude()
    role_1 = role_include_0.load(role_include_0, role_include_0)
    assert isinstance(role_1, RoleRequirement)

# Generated at 2022-06-25 05:47:04.192917
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_definition_0 = RoleDefinition()
    role_definition_0.load(role_include_0, role_include_0)


# Generated at 2022-06-25 05:47:08.054330
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load('some string: some value', role_include_0)

# Generated at 2022-06-25 05:47:12.430359
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class Mock_role_basedir:
        role_basedir = "role_basedir"

    class Mock_variable_manager:
        variable_manager = "variable_manager"

    ri = RoleInclude()
    role_include_0 = ri.load("role_definition", "play", Mock_role_basedir, "parent_role", Mock_variable_manager)
    assert role_include_0 == {}

# Generated at 2022-06-25 05:47:18.612401
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Load of 'ansible.playbook.role.include.RoleInclude' class
    role_include_1 = RoleInclude()

    # Load of 'ansible.playbook.role.include.RoleInclude' class
    role_include_2 = role_include_1.load(role_include_1, role_include_1)

    # TypeError: load() missing 1 required positional argument: 'role_basedir'
    with pytest.raises(TypeError) as excinfo:
        role_include_3 = role_include_1.load(role_basedir, role_include_1)
    assert 'missing 1 required positional argument' in str(excinfo.value)

    # TypeError: load() missing 1 required positional argument: 'play'
    with pytest.raises(TypeError) as excinfo:
        role_

# Generated at 2022-06-25 05:47:21.178567
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.load(role_include_0, role_include_0)

# Loads a module from a path and returns it, useful for testing modules

# Generated at 2022-06-25 05:47:23.490394
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    arg0 = 'foo'
    arg1 = 'bar'

    test_case_0()

# Generated at 2022-06-25 05:47:26.602141
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    data_0 = ''
    play_0 = RoleInclude()
    var_0 = role_include_0.load(data_0, play_0)


# Generated at 2022-06-25 05:47:37.396289
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    load
    """
    def test_load_helper(data, play, current_role_path, parent_role, variable_manager, loader, collection_list):
        role_include_0 = RoleInclude()
        var_0 = role_include_0.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
        assert var_0 is not None
    def test_load_helper_1(data, play, current_role_path, parent_role, variable_manager, loader, collection_list):
        role_include_0 = RoleInclude()
        var_0 = role_include_0.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
        assert var_0.get_default_v

# Generated at 2022-06-25 05:47:40.163842
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    role_include_0 = RoleInclude(play=None, role_basedir=None)
    var_0 = role_include_0.load(role_include_0, role_include_0)
    #assert( var_0 )
    #assert( isinstance(var_0, RoleRequirement) )

# Generated at 2022-06-25 05:47:44.212820
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    role_include.load(role_include, role_include)


# Generated at 2022-06-25 05:47:45.798563
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert 1 == 1

# Generated at 2022-06-25 05:47:54.672692
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    role_include_4 = RoleInclude()
    role_include_5 = RoleInclude()
    role_include_6 = RoleInclude()
    role_include_7 = RoleInclude()
    role_include_8 = RoleInclude()
    role_include_9 = RoleInclude()
    role_include_10 = RoleInclude()
    role_include_11 = RoleInclude()
    role_include_12 = RoleInclude()
    role_include_13 = RoleInclude()
    role_include_14 = RoleInclude()
    role_include_15 = RoleInclude()

# Generated at 2022-06-25 05:47:59.673528
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def test_case_0():
        role_include_0 = RoleInclude()
        var_0 = role_include_0.load(role_include_0, role_include_0)

# Generated at 2022-06-25 05:48:09.838369
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_basedir_0 = '/tmp/ansible_nnhcsw'
    play_0 = Play()
    data_0 = play_0.load(play_0, play_0)
    loader_0 = '{{perl_module_soname}}'
    variable_manager_0 = '-k'
    collection_list_0 = '{{perl_module_soname}}'
    current_role_path_0 = role_basedir_0
    role_include_0 = RoleInclude(play=play_0, role_basedir=role_basedir_0, variable_manager=variable_manager_0, loader=loader_0, collection_list=collection_list_0)

# Generated at 2022-06-25 05:48:13.290588
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    assert type(role_include_0.load(role_include_0, role_include_0)) is AnsibleError

# Generated at 2022-06-25 05:48:25.440086
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:48:36.736616
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    role_include_4 = RoleInclude()
    role_include_5 = RoleInclude()
    role_include_6 = RoleInclude()
    role_include_7 = RoleInclude()

    # unit test input data
    data_0 = "test_data_0"
    data_1 = {"test_data_1": "test_data_1"}
    data_2 = ["test_data_2"]
    data_3 = "test_data_3"
    # unit test output data
    retval_0 = role_include_0.load(role_include_0, data_0)

# Generated at 2022-06-25 05:48:52.593692
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    role_include_4 = RoleInclude()
    role_include_5 = RoleInclude()
    role_include_6 = RoleInclude()
    role_include_7 = RoleInclude()

    with pytest.raises(AnsibleError):
        var_0 = role_include_0.load(role_include_0, role_include_0)

    with pytest.raises(AnsibleError):
        var_0 = role_include_1.load(role_include_1, role_include_1)

    with pytest.raises(AnsibleError):
        var_0 = role_include_

# Generated at 2022-06-25 05:48:54.027705
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_cases = [test_case_0]

    for test_case in test_cases:
        test_case()


# Generated at 2022-06-25 05:48:59.338798
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    role_include_0 = RoleInclude()
    role_include_0.variable_manager = dict()
    var_0 = role_include_0.load_data('test')
    assert var_0 == dict()
    var_1 = role_include_0.load(role_include_0, role_include_0)
    assert var_1 == dict()
    role_include_0.load_data(role_include_0)
    assert role_include_0.variable_manager == dict()
    role_include_0.load('test')
    assert role_include_0.variable_manager == dict()


# Generated at 2022-06-25 05:49:03.044788
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_1.load(role_include_1, role_include_1)


# Generated at 2022-06-25 05:49:08.911678
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_1.play = None
    role_include_1.role_basedir = None
    role_include_1.variable_manager = None
    role_include_1.loader = None
    role_include_1.collection_list = None
    var_1 = role_include_1.load(role_include_1, role_include_1)

# Generated at 2022-06-25 05:49:19.499213
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    var_0 = [
        'ansible.builtin.debug',
        'ansible.builtin.ping']
    var_1 = [
        'ansible.builtin.debug',
        'ansible.builtin.ping']
    var_2 = [
        'ansible.builtin.debug',
        'ansible.builtin.ping']
    var_3 = [
        'library/curl',
        'library/tar',
        'library/grep',
        'library/rsync']
    var_4 = [
        'ansible.builtin.debug',
        'ansible.builtin.ping',
        'library/curl',
        'library/tar',
        'library/grep',
        'library/rsync']

    data = {}

# Generated at 2022-06-25 05:49:23.556995
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("Test for method load in class RoleInclude")
    # Test method load in class RoleInclude
    role_include_1 = RoleInclude()
    role_include_1.load(role_include_1, role_include_1)


# Generated at 2022-06-25 05:49:29.308959
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_data = {
        "role": "db",
        "mongo_bind_ip": "127.0.0.1",
        "postgres_encoding": "UTF8",
        "postgres_lc_collate": "de_DE.UTF-8",
        "postgres_lc_ctype": "de_DE.UTF-8"
    }
    ri = RoleInclude()
    result = ri.load(ri, role_include_data)
    assert result == role_include_data

# Generated at 2022-06-25 05:49:31.471284
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:49:38.766599
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # AnsibleModule.run_command() is not implemented in this case
    from ansible.module_utils.basic import AnsibleModule

    # Use dummy class
    class DummyModule(object):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False, check_invalid_arguments=True, mutually_exclusive=None, required_together=None, required_one_of=None, add_file_common_args=False, supports_check_mode=False, required_if=None):
            self.argument_spec = argument_spec
            self.bypass_checks = bypass_checks
            self.no_log = no_log
            self.check_invalid_arguments = check_invalid_arguments
            self.mutually_exclusive = mutually_exclusive or []
            self.required_together

# Generated at 2022-06-25 05:49:52.032230
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    role_include.load()


# Generated at 2022-06-25 05:50:00.236281
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "test_value"
    play = "test_value"
    current_role_path = "test_value"
    parent_role = "test_value"
    variable_manager = "test_value"
    loader = "test_value"
    collection_list = "test_value"

    # AssertionError: Invalid role definition: None
    # assert RoleInclude.load(data, play, current_role_path, parent_role,
    #                         variable_manager, loader, collection_list) == (
    #        "test_value")

# Generated at 2022-06-25 05:50:06.911370
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    assert role_include_0.load(role_include_0, role_include_0) == None
    assert type(role_include_0.load(role_include_0, role_include_0)) == None


# Generated at 2022-06-25 05:50:11.383032
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_0.load(role_include_1, role_include_0)


# Generated at 2022-06-25 05:50:15.143918
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    var_1 = role_include_1.load(role_include_1, role_include_1)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:50:16.731203
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    try:
        role_include.load(role_include, role_include)
    except Exception as e:
        assert False, "Failed to load RoleInclude object: {0}".format(e)

# Generated at 2022-06-25 05:50:17.964955
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    var_1 = role_include_1.load(role_include_1, role_include_1)


# Generated at 2022-06-25 05:50:19.238132
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    assert role_include_0.load(role_include_0, role_include_0) == role_include_0

# Generated at 2022-06-25 05:50:23.923657
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:50:27.572585
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)


# Generated at 2022-06-25 05:50:53.087716
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    var_1 = role_include_1.load(role_include_1.load, role_include_1)
# Test case for method load

# Generated at 2022-06-25 05:50:55.573820
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    data = ri.load(ri, ri)
    for key in data['tasks']:
        assert type(data['tasks'][key]) is not dict



# Generated at 2022-06-25 05:51:06.323026
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_1 = dict()
    var_1['path'] = '../../common'
    var_1['name'] = 'common'
    var_1['scm'] = None
    var_1['role_path'] = '../..'
    var_1['version'] = None
    var_1['subdir'] = None
    var_1['_role_def_loaded'] = True
    var_1['role_name'] = 'common'
    var_1['collections'][0] = dict()
    var_1['collections'][0]['name'] = 'test_collection'
    var_1['collections'][0]['version'] = '0.1.0'


# Generated at 2022-06-25 05:51:12.841048
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.module_utils import basic
    play_0 = basic.AnsiblePlay()
    role_include_0 = RoleInclude() # instantiate an object
    role_basedir_0 = '/tmp/test/ansible' # Should be a string, not a module!!!
    role_include_0.load(role_include_0, play_0, role_basedir_0)


# Generated at 2022-06-25 05:51:20.324483
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {
        "name": "Common",
        "tasks": [
            {
                "name": "debug",
                "debug": {
                    "msg": "This file is a part of common role and contains all the common tasks."
                }
            }
        ],
        "vars": {
            "server": "webserver",
            "db_name": "shopmania"
        },
        "handlers": {
            "name": "Restart Apache",
            "service": {
                "name": "httpd",
                "state": "restarted"
            }
        }
    }
    play = RoleInclude()
    current_role_path = '/home/vagrant/ansible/playbooks/'
    parent_role = RoleInclude()
    variable_manager = 'variable_manager'
   

# Generated at 2022-06-25 05:51:25.026086
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test_var_0 = { 'loader' : None, 'collection_list' : None }
    role_include_0 = RoleInclude()
    # test_var_1 = { 'role_basedir' : current_role_path, 'loader' : None, 'collection_list' : None, 'play' : play, 'variable_manager' : variable_manager }
    role_include_1 = RoleInclude()

    # Call method load from class RoleInclude and pass test_var_0 and test_var_1 as arguments
    var_0 = role_include_0.load(var_0, var_1)


# Generated at 2022-06-25 05:51:34.386861
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:51:43.805086
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()

    # Input data
    data_1 = dict()

    # Expected output
    expected_result_1 = RoleInclude()

    # Actual output
    result_1 = role_include_1.load(data_1, role_include_2)

    assert result_1 == expected_result_1

    # Input data
    data_2 = role_include_2
    # Expected output
    expected_result_2 = role_include_2

    # Actual output
    result_2 = role_include_1.load(data_2, role_include_3)

    assert result_2 == expected_result_2


# Generated at 2022-06-25 05:51:45.340185
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude.load(role_include_1, role_include_1)

# Generated at 2022-06-25 05:51:46.208627
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:52:46.303424
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = Play()
    current_role_path = ''
    parent_role = ''
    variable_manager = VariableManager()
    loader = DataLoader()
    collection_list = [{'name': 'some_collection', 'version': 'some_version'}]

    role_include_0 = RoleInclude(play, current_role_path, parent_role, variable_manager, loader, collection_list)
    role_include_0._sub_role_paths = ['/tmp/test_case_0.py']
    role_include_0.role = None
    role_include_0.tags = []
    role_include_0.vars = {}
    role_include_0.default_vars = []
    role_include_0.role_path = ''
    role_include_0.playbook = None
   

# Generated at 2022-06-25 05:52:49.028331
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    yaml_data = ''
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(yaml_data, role_include_0)
    assert var_0.role_basedir == '.'

# Generated at 2022-06-25 05:52:59.235470
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)
    assert role_include_0._role_blocks == []
    assert role_include_0._role_path == None
    assert role_include_0._metadata['name'] == None
    assert role_include_0._metadata['namespace'] == None
    assert role_include_0._metadata['version'] == None
    assert role_include_0._metadata['description'] == None
    assert role_include_0._metadata['min_ansible_version'] == None
    assert role_include_0._metadata['max_ansible_version'] == None
    assert role_include_0._metadata['company'] == None
    assert role_include_0._metadata['license'] == None

# Generated at 2022-06-25 05:53:03.329351
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    data_0 = role_include_1.load(role_include_0, role_include_1)

# Generated at 2022-06-25 05:53:09.836330
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_1 = RoleInclude.load('foo', 'play')
    assert isinstance(test_1, RoleInclude)
    assert hasattr(test_1, '_role_name')
    assert hasattr(test_1, '_role_path')
    assert isinstance(test_1._role_name, string_types)
    assert isinstance(test_1._role_path, string_types)
    assert test_1._role_name == "foo"
    assert test_1._role_path is None
    assert hasattr(test_1, '_play')
    assert test_1._play == 'play'


# Generated at 2022-06-25 05:53:12.087656
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Unit test for method load of class RoleInclude
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)
    assert var_0 == role_include_0

# Generated at 2022-06-25 05:53:12.767851
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:53:14.043218
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0(cmd, argspec)
    pass

# Generated at 2022-06-25 05:53:16.216512
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Check the case when data is a string and when data is a dict
    # and when data is an AnsibleBaseYAMLObject
    assert test_case_0()


# Generated at 2022-06-25 05:53:18.192205
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.load(role_include_0, role_include_0)