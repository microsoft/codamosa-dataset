

# Generated at 2022-06-25 05:44:56.462124
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)

    data = 'galaxy.role.name'

    variable_manager = 'z'
    loader = '_\xe1\n\xfc\x9f\x9a\xf6\x0c\xab'

# Generated at 2022-06-25 05:45:03.830087
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    bytes_2 = b'\xfe\xeb\xda\x9d\x9f\xdd\xf8\x93'
    assert type(RoleInclude.load(bytes_0, bytes_1, bytes_2)) == RoleInclude

# Generated at 2022-06-25 05:45:13.540929
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b""
    bytes_1 = b"\xa0\x9e\xae\x8e\x8c\x81\xc1\xaf\r\xf2\xae\xb9'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    str_0 = ansible_playbook_0
    dict_0 = {'yaml_data': str_0}
    len_0 = len(str_0)
    str_1 = str()
    str_0 = str_0[:len_0]
    str_0 = (str_1 + str_0)
    role_include_1 = RoleInclude.load(dict_0, role_include_0)


# Generated at 2022-06-25 05:45:22.644535
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9fY\x15\xd8\xac\x9f\x1f\xe2\x8b'
    bytes_1 = b'\xa7\xac\x9d\xa1\x0e\xf8(\x19'
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    role_include_1 = RoleInclude(role_include_0)
    bytes_2 = b'\x8d\x1f\xed\xbb\x9d\x9b\x93\xa5Y\xedc\x8a\xac\x9d\xa1\x0e\xf8('
    bytes_3 = b'\x19\xac\x9d\xa1\x0e\xf8('

# Generated at 2022-06-25 05:45:29.484299
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:45:40.150795
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    my_loader, test_data = dict(), dict()
    data_0, data_1 = dict(), dict()
    test_data['role_path'] = './test/integration/targets/test_collections/ansible_collections/test/tasks_in_subdirs/'
    variable_manager_0, variable_manager_1 = dict(), dict()
    variable_manager_0['test_data'], variable_manager_1['test_data'] = test_data, test_data
    loader_0, loader_1 = dict(), dict()
    loader_0['test_data'], loader_1['test_data'] = test_data, test_data
    test_data['loader'], test_data['variable_manager'] = loader_0, variable_manager_0
    test_data['collection_list']

# Generated at 2022-06-25 05:45:45.320551
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    data = 'test_value'
    play = 'test_value'
    current_role_path = 'test_value'
    parent_role = 'test_value'
    variable_manager = 'test_value'
    loader = 'test_value'
    role_include_0 = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)

# Generated at 2022-06-25 05:45:54.047360
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x1d\x04\xf3\xa3H\xdf\xa2\xf2\x08'
    bytes_1 = b'\xb8E\x9c\x9f\x80+'
    bytes_2 = b'\xcf\x94\xef\xfa\x96\xb4\x83\xb4\x8e\x1b'
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    role_include_0.load(bytes_1, bytes_2)
    py_0 = '\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'

# Generated at 2022-06-25 05:45:56.989905
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: AnsibleError(msg)
    # TODO: AnsibleBaseYAMLObject
    # TODO: string_types
    # TODO: AnsibleParserError(msg)
    pass


# Generated at 2022-06-25 05:46:07.683514
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    loader_0 = DictDataLoader({
        'role_1': '''\
meta/main.yml
tasks/other.yml''',
    })
    dict_0 = dict()
    dict_1 = dict()
    dict_0['name'] = 'role_1'
    dict_0['tasks'] = ['meta/main.yml', 'tasks/other.yml']
    dict_1['role_1'] = dict_0
    role_include_0 = RoleInclude.load(dict_1, 'role_1', loader=loader_0)
    assert role_include_0._role_name == 'role_1'
    dict_2 = dict()
    dict_2['role_include_0'] = role_include_0
    list_0 = []
    dict_3 = dict()

# Generated at 2022-06-25 05:46:17.116546
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    str_0 = 'foo,bar'
    role_include_1 = RoleInclude.load(str_0, role_include_0)
    str_0 = 'foo'
    role_include_2 = RoleInclude.load(str_0, role_include_0)
    str_0 = 'foo,bar'
    str_1 = 'foo,bar'

# Generated at 2022-06-25 05:46:21.855273
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    role_include_1 = RoleInclude(role_include_0)


# Generated at 2022-06-25 05:46:28.859827
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    file_path = os.path.dirname(os.path.abspath(__file__))
    os.chdir(file_path)
    role_include_0 = RoleInclude()
    str_0 = 'this_is'
    str_1 = 'this_is'
    str_2 = 'this_is'
    role_include_0.load(str_0, str_1, str_2)

if __name__ == "__main__":
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:46:37.544817
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    index_0 = Attribute()
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    index_1 = RoleInclude(bytes_0, bytes_1)
    index_2 = loader.load_from_file('')
    index_3 = RoleInclude()
    assert index_3.load(index_2, index_1, index_0) == index_1


# Generated at 2022-06-25 05:46:45.869623
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import os.path
    import sys

# Generated at 2022-06-25 05:46:51.021383
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    str_0 = 'c'
    int_0 = 1
    instance_0 = RoleInclude(bytes_0, bytes_1)
    try:
        instance_0.load(str_0, str_0, str_0, int_0, int_0, int_0)
    except AnsibleError:
        pass
    else:
        assert False


# Generated at 2022-06-25 05:46:57.322244
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b'\xdc\xe9\xc1z\xab\xc0\x0e\x12\xde\xfc\x00\xb0\x9f'
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    role_include_1 = RoleInclude(role_include_0)

# Generated at 2022-06-25 05:47:08.442546
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test_case_0 is a valid role include
    test_case_0 = dict(name="ansible-role-memcached", src="https://github.com/jdauphant/ansible-role-memcached")
    assert RoleInclude.load(test_case_0, play=None, variable_manager=None, loader=None)

    # test_case_1 is an invalid role include
    test_case_1 = dict(name="ansible-role-memcached", src="git+https://github.com/jdauphant/ansible-role-memcached")
    try:
        RoleInclude.load(test_case_1, play=None, variable_manager=None, loader=None)
        assert False
    except AnsibleParserError:
        assert True

    # test_case_2 is

# Generated at 2022-06-25 05:47:17.879627
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'examples/roles/foo'
    play = AnsiblePlay()
    current_role_path = os.path.join(os.getcwd(), 'examples/roles')
    parent_role = 'examples/roles/foo'
    variable_manager = AnsibleVariableManager()
    loader = AnsibleLoader()
    collection_list = AnsibleCollectionFinder()
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager,
                     loader=loader, collection_list=collection_list)
    ri.name = data
    ri.collection = None
    ri.role_basedir = current_role_path
    ri.play = play
    ri.loader = loader
    ri.variable_manager = variable_manager


# Generated at 2022-06-25 05:47:24.664146
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    def load_mock(self, data):
        return data

    role_include_0 = RoleInclude()
    role_include_0._load = load_mock
    var_0 = bytes('bytes_0', 'utf-8')
    var_1 = bytes('bytes_1', 'utf-8')
    var_return_0 = role_include_0.load(var_0, var_1)
    assert var_return_0 == var_0

# vim: set expandtab ts=4 sw=4 ai fenc=utf-8 ft=python:

# Generated at 2022-06-25 05:47:30.895301
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Load tests
    for k in iteritems(RoleRequirement.VALID_KEYS):
        role_include = RoleInclude(None)
        role_include.load(k, None, None)


# Generated at 2022-06-25 05:47:38.432912
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    data_0 = "/"
    play_0 = None
    current_role_path_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    role_include_1 = RoleInclude.load(data_0, play_0, current_role_path_0, variable_manager_0, loader_0, collection_list_0)
    data_1 = ","
    play_1 = None

# Generated at 2022-06-25 05:47:43.840149
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "test"
    play = "test"
    current_role_path = "test"
    parent_role = "test"
    variable_manager = "test"
    loader = "test"
    collection_list = "test"
    ansible_host = "test"
    ansible_no_log = "test"
    ansible_connection = "test"
    ansible_network_os = "test"
    ansible_user = "test"
    ansible_ssh_user = "test"
    ansible_ssh_host = "test"
    ansible_ssh_pass = "test"
    ansible_become = "test"
    result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)


# Generated at 2022-06-25 05:47:50.493945
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    role_include_1 = RoleInclude(role_include_0)


import unittest


# Generated at 2022-06-25 05:47:59.495817
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'/\x06\x80\xcd'
    bytes_1 = b'\xca\x17'
    bytes_2 = b'\xbc\x92\xec\x98\xbc\x01\xd5+\xdc\x10\xe9\x1a\x93\x17\x05\x8b'
    bytes_3 = b'\xa4\x9a\x04\xed\xcf\x16\x1b\xfb\xb7\xd1'

# Generated at 2022-06-25 05:48:02.821171
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9d\xac\x9d\xed0\xcd\xe4\xc4\xa6'
    role_include_0 = RoleInclude()
    bytes_1 = b'\xa5\xac\x9d\xa1\x0e\xf8(\x19'
    bytes_2 = {}
    role_include_1 = RoleInclude.load(bytes_0, bytes_1, bytes_2)

# Generated at 2022-06-25 05:48:10.487564
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #data = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    #data2 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    variable_manager = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    data = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    ansible_result = RoleInclude.load(data, variable_manager)
    print("TEST ANSIBLE ------------->",ansible_result)
    assert ansible_result


# Generated at 2022-06-25 05:48:14.587008
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Arguments
    data = "null"
    play = "null"
    current_role_path = "null"

    # Return value
    load_value = RoleInclude.load(data, play, current_role_path)

    # Return code
    assert 0 == 0

# Generated at 2022-06-25 05:48:25.549335
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xe3\x98\x8e\xed\xb6\x9d\x18h\x18\x90\xfe\xcc\xbe'
    bytes_1 = b"F\xba\x90W_\xad'\x0e\xcd"
    bytes_2 = b'\x07\xa00\xd7\x15\x99n\xef\x0b'
    bytes_3 = b'\xaa\xac\x9d\xa1\xd5\xec\xde\xeb'
    bytes_4 = b'\xb0\xac\x9d\xa1\x0e\xa2\xc6\x8c'

# Generated at 2022-06-25 05:48:36.804893
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x92\x8c\x88\xa9\xd6\xf4\x8d\x8e'
    bytes_1 = b"\x8c\xa0\x9a\x9e\x8d\xfc\x86\x89"
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    bytes_2 = b'\x81\x91\x8f\x95\x9f\x9b\x8d\x82'
    bytes_3 = b'\x8f\x8c\x9a\x92\x8e\xf8\x81\x84'
    role_include_0.load(bytes_2, bytes_3)

# Generated at 2022-06-25 05:48:51.667455
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    bytes_0 = b"\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6"
    bytes_1 = b'\xa7\xac\x9d\xa1\x0e\xf8(\x19\''
    role_include_1 = RoleInclude(bytes_0, bytes_1)
    play_0 = Play()

# Generated at 2022-06-25 05:48:56.201728
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #import tempfile
    #tmpdir = tempfile.mkdtemp()
    #included_role_0 = RoleInclude(tmpdir, role_include_1)
    #os.makedirs(os.path.join(tmpdir, 'roles', 'x'))

    # TODO: test load()
    pass

# Generated at 2022-06-25 05:49:07.291564
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    bytes_2 = b';\xe4\x93\xd7+\x1b\xfe\x84\x8d'
    bytes_3 = b'\xf1\x8ct\x07\xba\x80\xce\xc0'
    bytes_4 = b'\xe3\xf1\xa1\xd1\x82\xc6\xde\xa8'
    role_include_2 = role_include_0.load

# Generated at 2022-06-25 05:49:18.425549
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xad\xad\x9b\x9b\x9et\xca\xca\xca'
    bytes_1 = b"\xae\x9dV\xa1\xde7\xdd'"
    bytes_2 = b';\x93\xb5\xdf\x19\xe9\xac\xcc'
    bytes_3 = b'\xa4\x8c\xd1(\x9c\xde\xf8\xde'
    bytes_4 = b'\xad\x82\x95B\x9f\xd9\x82\xe1'
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5


# Generated at 2022-06-25 05:49:28.560113
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    data = dict(
        name='common',
        _role_name='common',
        _role_path='/etc/ansible/roles/common',
        _role_collection_name='ansible_namespace.common'
    )
    # TODO(hboldewin): refactor to use python mock lib
    # Mock class for testing
    class MockVariableManager:
        def __init__(self):
            self.vars = dict()

        def add_group_vars(self, host, data):
            print(self.vars)
            #for k in data:
            #    self.vars[k] = data[k]

    variable_manager = MockVariableManager()
    variable_manager.add_group_vars('localhost', dict(v0='test'))


# Generated at 2022-06-25 05:49:35.857118
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    assert_equal(role_include_0.load(), None)


# Generated at 2022-06-25 05:49:40.436762
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = role_include_0.load("foo", "foo", "foo", "foo", "foo", "foo")


# Generated at 2022-06-25 05:49:45.884784
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    bytes_0 = b"\n\x05\xbd\x83\x9d]\xc1\x12"

# Generated at 2022-06-25 05:49:53.617354
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Setup
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)

    # Setup
    string_0 = '3f\xb3\xad\x00\xeb\x05}\xb9\xd9\xe79t]\x8b\x97\x1d\xf1\xb1\xdb\xa9\xaa\x9c\xfa\x91\x80\xca\xd2\xdd\x1a\x9a\x9f\x00\x8e'


# Generated at 2022-06-25 05:49:58.038690
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    testcase_RoleInclude_load_0 = {
        "constants.py": "/etc/ansible/roles/",
        "action": "erase_units",
        "parameters": {
                          "types": "",
                          "bypass_unit": "",
                          "unit": ""
                      },
        "when": "",
        "files": "",
        "vars": "",
        "tags": []
    }

# Generated at 2022-06-25 05:50:17.656071
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    attr_0 = Attribute()
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude(role_include_0)
    assert role_include_1 == role_include_0
    role_include_1.load(attr_0, role_include_0, '.', role_include_1, role_include_1, role_include_1)
    assert role_include_1 == role_include_0

# Generated at 2022-06-25 05:50:24.483899
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    current_role_path = b'D\x00\x00\x00'
    parent_role = b'\x00\x00\x00@'

# Generated at 2022-06-25 05:50:34.027986
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    inp_data = "foo"
    inp_play = "foo"
    inp_current_role_path = "foo"
    inp_parent_role = "foo"
    inp_variable_manager = "foo"
    inp_loader = "foo"
    inp_collection_list = "foo"
    test_obj = RoleInclude.load(inp_data, inp_play, inp_current_role_path, inp_parent_role, inp_variable_manager, inp_loader, inp_collection_list)
    assert test_obj is not None



# Generated at 2022-06-25 05:50:43.133990
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    bytes_2 = b'2\x8a\x1e\x1a\xff\x04\xff\xd8'
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    role_include_1 = RoleInclude(role_include_0)
    role_include_1.load(bytes_1, bytes_0)
    assert bytes_2 != bytes_1


# Generated at 2022-06-25 05:50:53.097873
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude(role_include_1)
    role_include_3 = RoleInclude(role_include_0, role_include_2)
    role_include_4 = RoleInclude(role_include_1, role_include_0)
    data_0 = 'sYrgQ2'
    if (len(data_0) < 9):
        raise Exception('Assertion failed')
    if (len(data_0) < 7):
        raise Exception('Assertion failed')
    if (len(data_0) < 10):
        raise Exception('Assertion failed')
    if (len(data_0) < 11):
        raise Exception('Assertion failed')

# Generated at 2022-06-25 05:51:00.135591
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\x9c\xfc\xb5\x1b\x84\xe5\x8e\xdf\x9a0c\xab\xb8$\xba\xbe\xec"
    bytes_2 = b':'
    bytes_3 = b'true'
    bytes_4 = b'\x98\x10\x9b\xbd\x01\x8c\x91\xea\x98\xe6\x8f'

# Generated at 2022-06-25 05:51:10.456934
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    dict_0 = {'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 'value_2'}
    role_include_0 = RoleInclude.load(dict_0, bytes_0, bytes_1)
    role_include_0 = RoleInclude.load(dict_0, bytes_0, bytes_1, role_include_0)
    str_0 = to_native(role_include_0)

# Generated at 2022-06-25 05:51:18.649944
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    str_0 = '\x80\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 05:51:22.600809
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_basedir = ''
    with pytest.raises(AnsibleError) as excinfo:
        RoleInclude.load("\xcf\xa8", role_basedir)
    assert 'Invalid old style role requirement' in str(excinfo.value)
    with pytest.raises(AnsibleParserError) as excinfo:
        RoleInclude.load(object(), role_basedir)
    assert 'Invalid role definition' in str(excinfo.value)

# Generated at 2022-06-25 05:51:29.579074
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = u'TASK [test_console_terminal : debug] *****************************************************\nok: [localhost] => {\n    "msg": "The inventory source (script) is: /etc/ansible/hosts"\n}\n\nTASK [test_console_terminal : debug] *****************************************************\nok: [localhost] => {\n    "msg": "The inventory source (script) is: /etc/ansible/hosts"\n}\n\nPLAY RECAP *************************************************************************************\nlocalhost                  : ok=2    changed=0    unreachable=0    failed=0\n'
    data_1 = {u'delegate_to': u'', u'delegate_facts': False}
    data_2 = {u'y': 10}

# Generated at 2022-06-25 05:52:01.088686
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
  # No play specified
  # No current_role_path specified
  # No parent_role specified
  # No variable_manager specified
  # No loader specified
  # No collection_list_0 specified

  # TEST CODE
  # Load the required objects
  # Create the appropriate objects

  # Extract the needed data
  # Call the right function
  raise NotImplementedError()

test_case_0()

# Generated at 2022-06-25 05:52:05.907267
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

"""
Overload for class RoleInclude
"""

# Overload __init__ method for class RoleInclude

# Generated at 2022-06-25 05:52:15.935150
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Set up objects
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    role_data = {'role': 'foo', 'files': 'bar'}
    role_include_1 = RoleInclude(role_include_0)
    role_include_2 = RoleInclude(role_include_1)
    role_include_3 = RoleInclude(role_include_2)
    role_include_4 = RoleInclude(role_include_3)

# Generated at 2022-06-25 05:52:24.311293
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "some_role_name" 
    play = "some_play" 
    current_role_path = "some_current_role_path" 
    parent_role = "some_parent_role" 
    variable_manager = "some_variable_manager" 
    loader = "some_loader" 
    collection_list = "some_collection_list" 
    result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
#     assert result
    #assert result == the expected result

# Generated at 2022-06-25 05:52:28.250205
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    cmd_0 = 'vagrant ssh-config'
    role_include_0 = RoleInclude(cmd_0)
    role_include_0.load(cmd_0)

    role_include_1 = RoleInclude()
    role_include_1.load(cmd_0)


# Generated at 2022-06-25 05:52:37.061171
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = {'neptune', 'saturn', 'jupiter', 'venus', 'mercury'}
    data_1 = {'pluto', 'mercury', 'uranus', 'venus', 'mars'}
    role_include_0 = RoleInclude()

    # call RoleInclude.load()
    data = role_include_0.load(data_0, data_1)


# Generated at 2022-06-25 05:52:43.613369
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_1 = b'\xf1u\xad\x0c\xfeV\x9e'
    role_include_0 = RoleInclude(bytes_1)
    bytes_2 = b'.\x0e\x05\xd7l\xf4\xdb\xb4'
    dict_0 = {
        'foo': 'bar',
        'bar': 'baz'
    }
    dict_1 = {
        'foo': 'bar'
    }
    dict_2 = {
        'bar': 'foo'
    }
    dict_3 = {
        'foo': 'bar',
        'bar': dict_2
    }
    list_0 = ['bar']
    list_1 = ['foo', 'bar']
    list_2 = ['bar', 'foo']
    list_3

# Generated at 2022-06-25 05:52:50.821036
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0)
    bytes_0 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    bytes_1 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    str_0 = "nj^\x0f\xb8\x85\xd7`\xde\xae\\\xa9\x0e"
    bytes_2 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"

# Generated at 2022-06-25 05:52:55.424503
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # FIXME:
    #      The test suite assumes that the data passed to RoleInclude.load is
    #      a str and not a unicode object. That caused test failure on
    #      Python 3.5. We need to fix the test suite to make it more python 3
    #      friendly.

    working_directory = os.getcwd()
    variable_manager = None  # FIXME
    loader = None  # FIXME
    collection_list = []  # FIXME

    # FIXME:
    #      The test suite assumes that the data passed to RoleInclude.load is
    #      a str and not a unicode object. That caused test failure on
    #      Python 3.5. We need to fix the test suite to make it more python 3
    #      friendly.

# Generated at 2022-06-25 05:53:01.516345
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    try:
        role_include_1 = RoleInclude.load(None, role_include_0)
    except RuntimeError:
        pass


# Generated at 2022-06-25 05:54:05.129385
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:54:12.152511
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_2 = RoleInclude()
    bytes_2 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    bytes_3 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    exception_message = 'Invalid old style role requirement: {}'.format(bytes_3)
    expected_exception = AnsibleError(exception_message)
    expected_exception.__cause__ = None
    try:
        role_include_2.load(bytes_3, bytes_2)
        fail('AssertionError expected')
    except AnsibleError as e:
        actual_exception = e
        assert actual_exception.args == expected_exception.args

# Generated at 2022-06-25 05:54:15.393293
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-25 05:54:22.898761
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    bytes_2 = b'\xb5\x00\xdf\xd2\xdc\x81\x87\x1e'
    role_include_0 = RoleInclude.load(bytes_0, bytes_1, bytes_2)
    role_include_1 = RoleInclude.load(bytes_2, bytes_1, bytes_0)
    role_include_2 = RoleInclude.load(bytes_1, bytes_0, bytes_2)


# Generated at 2022-06-25 05:54:24.478046
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    assert isinstance(test_case_0(), RoleInclude)

# Generated at 2022-06-25 05:54:34.994351
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    variable_manager_0 = Mock()
    variable_manager_0.add_host_vars = Mock(return_value=False)
    loader_0 = Mock()
    current_role_path_0 = Mock()
    collection_list_0 = Mock()

    # Call method load of class RoleInclude
    RoleInclude.load('test_value_1', current_role_path_0, None, None, variable_manager_0, loader_0, collection_list_0)

test_RoleInclude_load()

# Generated at 2022-06-25 05:54:41.593057
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    yaml_0 = 'H5\xae4\xab\xa0\xcf\x7f\x19\xf1'
    yaml_1 = '{\xc2'
    data_0 = '\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    data_1 = '9\x8c\x8bv\\\x7f\xca\x1c{'
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()

    RoleInclude.load(yaml_0, data_0, data_1, role_include_0, yaml_1, role_include_1)


# Generated at 2022-06-25 05:54:51.085010
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9e\xac\x9e\xed0\xcd\xe4\xc4\xa6'
    bytes_1 = b"\xa7\xac\x9d\xa1\x0e\xf8(\x19'"
    role_include_0 = RoleInclude(bytes_0, bytes_1)
    str_0 = 'e0Q'
    str_1 = 'D\x1c\xd3\x9b'
    dict_0 = {}