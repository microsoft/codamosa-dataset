

# Generated at 2022-06-25 05:44:44.923325
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    str_1 = None
    str_2 = None
    role_include_0 = RoleInclude(str_0)
    role_definition_0 = RoleDefinition.load(str_1, str_2)

# Generated at 2022-06-25 05:44:55.043149
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    os.environ['ANSIBLE_DEPRECATION_WARNINGS'] = 'False'
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    str_1 = "var=1"
    role_include_0.load(str_1, str_0)
    str_2 = dict()
    str_3 = "var=2"
    str_4 = "var=3"
    str_5 = "var=4"
    str_2['vars'] = str_3
    str_2['vars_files'] = str_4
    str_2['vars_prompt'] = str_5
    role_include_0.load(str_2, str_1)

# Generated at 2022-06-25 05:45:04.997638
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test case #1:
    # str_0 = None
    # role_include_0 = RoleInclude(str_0)
    role_include_load_0 = RoleInclude.load(str_0, str_0, str_0, str_0, str_0, str_0)

    # test case #2:
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    role_include_load_1 = role_include_0.load(str_1, str_2, str_3, str_4, str_5)

    # test case #3:
    str_0 = None
    str_1 = None


# Generated at 2022-06-25 05:45:09.987770
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    role_include_0 = RoleInclude.load(str_0, str_1, str_2, str_3, str_4)



# Generated at 2022-06-25 05:45:12.729899
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    RoleInclude_load(str_0, str_1, str_2, str_3)
    return None


# Generated at 2022-06-25 05:45:14.168530
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    obj_RoleInclude = RoleInclude()
    obj_RoleInclude.load()


# Generated at 2022-06-25 05:45:18.495963
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    str_1 = None
    str_2 = None
    result_role_include_0 = role_include_0.load(str_1, str_2)
    return result_role_include_0

# Generated at 2022-06-25 05:45:19.653310
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)

# Generated at 2022-06-25 05:45:27.030937
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0_0 = "foo"
    str_0_1 = "bar"
    str_0_2 = "baz"
    str_0_3 = "bar"
    str_0_4 = "foo"
    str_0_5 = "bar"
    str_0_6 = "foo"
    str_0_7 = "baz"
    str_0 = '%s,%s,%s,%s,%s,%s,%s,%s' % (str_0_0, str_0_1, str_0_2, str_0_3, str_0_4, str_0_5, str_0_6, str_0_7)
    role_include_0 = RoleInclude(str_0)

# Generated at 2022-06-25 05:45:32.807497
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    str_1 = None
    dict_0 = dict()
    dict_1 = dict()
    #str_2 = None
    str_2 = 'ansible.builtin.debug'
    dict_1['name'] = str_2
    dict_0['module'] = dict_1
    #str_2 = None
    str_2 = 'tests'
    dict_0['path'] = str_2
    role_include_0 = (RoleInclude.load(dict_0, str_0, str_1))
    #assert role_include_0._role.get_name() == 'debug'
    #assert role_include_0._role.get_path() == '/etc/ansible/roles/tests'


# Generated at 2022-06-25 05:45:38.705388
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    role_include_0 = RoleInclude(str_0)
    role_include_0.load(str_0, str_1, str_2, str_3)

# Generated at 2022-06-25 05:45:42.199854
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_definition_0 = None
    str_0 = None
    str_1 = None
    role_include_0 = RoleInclude(role_definition_0)
    try:
        role_include_0.load(str_0, str_1)
    except NameError as e:
        print(e)
        raise


# Generated at 2022-06-25 05:45:45.928782
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    role_include_0 = RoleInclude.load(str_0, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert role_include_0 is not None
    assert role_include_0 == None


# Generated at 2022-06-25 05:45:51.955855
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_1 = None
    role_include_0 = RoleInclude(str_1)
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    try:
        role_definition_0 = role_include_0.load(str_0, str_1, str_2, str_3, str_4, str_5)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 05:45:55.881749
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = 'test_value'
    str_1 = 'test_value'
    str_2 = 'test_value'
    str_3 = 'test_value'
    str_4 = 'test_value'
    role_include_0 = RoleInclude(str_0)
    role_include_1 = role_include_0.load(str_1, str_2, str_3, str_4)


# Generated at 2022-06-25 05:46:02.067924
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    role_include_1 = RoleInclude.load(str_1, str_2, str_3, str_4, str_5, str_6)

# Generated at 2022-06-25 05:46:08.159166
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    data_1 = None
    current_role_path_1 = None
    parent_role_1 = None
    variable_manager_1 = None
    loader_1 = None
    return_value = role_include_0.load(data_1, current_role_path_1, parent_role_1, variable_manager_1, loader_1)


# Generated at 2022-06-25 05:46:10.562252
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = role_include_0
    str_1 = load(str_0)
    assert str_1 != None


# Generated at 2022-06-25 05:46:15.780807
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    role_include_0 = RoleInclude(str_0)
    ansible_error_0 = None
    try:
        role_include_0.load(str_1, str_2, str_3, str_4)
    except AnsibleError as e:
        ansible_error_0 = e
    assert ansible_error_0 is not None

# Generated at 2022-06-25 05:46:20.925242
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    str_1 = 'test_value_1'
    dict_1 = dict()
    dict_1['test_key_2'] = 'test_value_2'
    dict_1['test_key_1'] = 'test_value_1'
    role_include_1 = role_include_0.load(str_1, dict_1)

# Generated at 2022-06-25 05:46:30.343075
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = ''
    play_0 = ''
    current_role_path_0 = ''
    parent_role_0 = ''
    variable_manager_0 = ''
    loader_0 = ''
    collection_list_0 = ''
    role_include_1 = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)
    assert role_include_1 is not None


# Generated at 2022-06-25 05:46:36.735631
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    arg0 = str()
    arg1 = str()
    arg2 = str()
    arg3 = str()
    arg4 = str()
    arg5 = str()
    try:
        RoleInclude.load(arg0, arg1, arg2, arg3, arg4, arg5)
    except:
        pass



# Generated at 2022-06-25 05:46:41.941430
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test for TypeError
    try:
        str_0 = 'my_role'
        str_1 = 'my_role'
        role_include_0 = RoleInclude(str_0)
        role_include_0.load(str_1)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 05:46:46.806275
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # play = None
    # str_0 = None
    # current_role_path = None
    # parent_role = None
    # variable_manager = None
    # loader = None
    # collection_list = None

    # role_include_0 = RoleInclude.load(str_0, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    pass


# Generated at 2022-06-25 05:46:53.851247
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    file = os.path.join(os.path.dirname(__file__), './test_data/sample.yaml')
    with open(file, 'r') as f:
        data = yaml.load(f.read())
    RoleInclude.load(data, current_role_path='/test')


# Generated at 2022-06-25 05:46:58.619784
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    # Load the file but don't raise
    role_include_0.load(str_1, str_2, str_3, None, str_4, str_5)

# Generated at 2022-06-25 05:47:05.086754
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:47:14.419939
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    str_1 = None
    str_2 = None
    dict_0 = {}
    str_3 = 'gevent.lock'
    dict_1 = dict({'when': 'ok', 'action': 'gevent.lock'})
    dict_2 = dict({'when': 'ok', 'action': 'gevent.lock', 'filter': 'gevent.lock'})
    dict_3 = dict({'filter': 'gevent.lock'})
    dict_4 = dict({'action': str_3})
    dict_5 = dict({'action': str_3, 'when': 'ok'})
    dict_6 = dict({'filter': 'gevent.lock', 'when': 'ok'})

# Generated at 2022-06-25 05:47:22.037084
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    data_0 = None
    play_0 = None
    current_role_path_0 = None
    parent_role_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    RoleInclude_0 = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)


if __name__ == '__main__':
    test_case_0()
    RoleInclude_load()

# Generated at 2022-06-25 05:47:24.077995
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude.load(str_0)

# Generated at 2022-06-25 05:47:33.527160
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    role_include_0 = RoleInclude.load(str_0,str_1,str_2,str_3,str_4)

# Generated at 2022-06-25 05:47:34.572465
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
  print("Test: test_RoleInclude_load")
  assert False


# Generated at 2022-06-25 05:47:40.181506
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = to_native('cereal')
    role_include_0 = RoleInclude(str_0)
    str_1 = to_native('desk')
    str_2 = to_native('table')
    str_3 = '{0}{1}{2}'.format(str_1,str_2,str_0)
    role_include_1 = role_include_0.load(str_3)

# Test case 4: load a role from a path relative to the current playbook

# Generated at 2022-06-25 05:47:47.683573
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print('')
    data = {"role": "test"}
    play = {}
    current_role_path = "/etc/ansible/roles"
    parent_role = {}
    variable_manager = {}
    loader = {}
    collection_list = {}

# Generated at 2022-06-25 05:47:49.940699
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-25 05:47:56.608600
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    self = RoleInclude()
    data = RoleRequirement(data = "requirements.yml")
    play = ""
    current_role_path = ""
    parent_role = ""
    variable_manager = ""
    loader = ""
    assert self.load(data, play, current_role_path, parent_role, variable_manager, loader), "test_case_0"

test_RoleInclude_load()

# Generated at 2022-06-25 05:48:06.559209
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Setup
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    str_0 = None
    dict_0 = dict()
    dict_0['name'] = str_0
    dict_0['tasks'] = list()
    dict_0['tasks'].append(dict())
    dict_0['tasks'][0]['name'] = str_0
    dict_0['tasks'][0]['local_action'] = str_0
    dict_0['vars'] = dict()
    dict_0['vars']['somedir'] = str_0
    str_1 = None
    dict_0['vars']['somethingelse'] = str_1
    dict_0['handlers'] = list()

# Generated at 2022-06-25 05:48:17.804972
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
#    print "test_RoleInclude_load"
    str_test_data_file = 'ansible/test/test_role_include.yml'
    str_current_role_path = 'ansible/test'
    role_include_1 = RoleInclude(str_current_role_path)
    role_include_1.load("ansible.test", str_current_role_path)
    role_include_1.load("../role_dir", str_current_role_path)
    role_include_1.load("test", str_current_role_path)
    role_include_1.load("test:test", str_current_role_path)
    role_include_1.load("test:test as my_test", str_current_role_path)

# Generated at 2022-06-25 05:48:19.344179
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    assert True, 'This is a stub'



# Generated at 2022-06-25 05:48:22.468915
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = ["ansible-role-apache", {"role": "bob", "name": "jim"}]
    """
    :type data: list
    """
    role_include_0 = data



# Generated at 2022-06-25 05:48:39.654992
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    loader_0 = AnsibleLoader()
    str_0 = None
    role_include_0 = RoleInclude.load(str_0, loader_0, loader_0, loader_0)


# Generated at 2022-06-25 05:48:45.420860
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    str_1 = None
    role_include_0 = None
    role_include_1 = RoleInclude.load(str_0, str_1, role_include_0, None)


# Generated at 2022-06-25 05:48:53.710147
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    int_0 = None
    str_5 = None
    # arguments: str_0, str_1, str_2, str_3, int_0, str_4, str_5
    # The third argument to the method RoleInclude.load is expected to be of type string_types: (<class 'str'>, <class 'unicode'>)
    with pytest.raises(TypeError) as excinfo:
        test_case_0(str_0, str_1, str_2, str_3, int_0, str_4, str_5)
    assert 'argument 3 must be an instance of string_types' in str(excinfo.value)



# Generated at 2022-06-25 05:49:04.921200
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    ansible_errors_7 = None
    ansible_errors_8 = None
    # test for exceptions:
    try:
        role_include_0.load(str_1, str_2, str_3, str_4, str_5, str_6)
    except AnsibleParserError as ansible_errors_7:
        pass
    except AnsibleError as ansible_errors_8:
        pass
    assert ansible_errors_7 is not None
    assert ansible_errors_8 is not None


# Generated at 2022-06-25 05:49:10.960890
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    path = "/home/vagrant/ansible/lib/ansible/playbook/role/include.py"
    data = "test_case_0"
    str_0 = None
    role = RoleInclude(str_0)
    role_include_0 = RoleInclude.load(data, None, None, role)


# Generated at 2022-06-25 05:49:20.343371
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = "/home/ansible/roles/foo/bar"
    str_1 = None
    str_2 = "foobar"
    str_3 = None
    str_4 = None
    str_5 = "/home/ansible/roles/foo"
    str_6 = None
    str_7 = None

# Generated at 2022-06-25 05:49:27.275124
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    object_0 = None
    str_1 = None
    object_1 = None
    str_2 = None
    object_2 = None
    str_3 = None
    role_include_1 = role_include_0.load(object_0, str_1, object_1, str_2, object_2, str_3)

# Generated at 2022-06-25 05:49:36.536327
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    attribute_0 = Attribute(str_0)
    attribute_1 = Attribute(str_1, attribute_0)
    str_4 = "test_value"
    str_5 = "test_value"
    role_include_0 = RoleInclude(str_2, str_3, attribute_1, attribute_0, attribute_1)
    role_include_0.load(str_4, str_5, attribute_0, attribute_1, attribute_1, attribute_0, attribute_1)

# Generated at 2022-06-25 05:49:44.763273
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Save the original values of the arguments
    args = [
        # Arguments for the function
        # Argument play
        None,
        # Agrument current_role_path
        None,
        # Agrument parent_role
        None,
        # Agrument variable_manager
        None,
        # Agrument loader
        None,
        # Agrument collection_list
        None
    ]

    # Call the function
    role_include_0 = RoleInclude.load(*args)

    # Save the original values of the arguments

# Generated at 2022-06-25 05:49:50.633390
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    role_include_0 = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    # Test
    assert role_include_0.get_role_name() == 'test'

# Generated at 2022-06-25 05:50:22.814200
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    loader_0 = None
    data_0 = None
    current_role_path_0 = None
    play_0 = None
    parent_role_0 = None
    variable_manager_0 = None
    collection_list_0 = None
    role_include_1 = RoleInclude(str_0)
    result = role_include_1.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)


# Generated at 2022-06-25 05:50:28.497641
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    args = [(None, None, None, None, None, None)]
    if not "AnsibleError" in [e.__name__ for e in RoleInclude.load(*args).__class__.__bases__ if e.__name__ != "object"]:
        raise AssertionError("RoleInclude.load did not raise AnsibleError")


# Generated at 2022-06-25 05:50:30.143961
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)

# Generated at 2022-06-25 05:50:32.584362
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Create a new RoleInclude object
    role_include_0 = RoleInclude()

    # Load the object with data
    role_include_0.load(dict_0)

# Generated at 2022-06-25 05:50:36.785323
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = '  - role: foo\n    bar: baz\n          '
    role_include_0 = RoleInclude.load(str_0, str_0)
    assert role_include_0.__class__.__name__ == 'RoleInclude'


# Generated at 2022-06-25 05:50:43.902485
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    yaml_1 = dict()
    play_1 = dict()
    current_role_path_1 = dict()
    parent_role_1 = dict()
    variable_manager_1 = dict()
    loader_1 = dict()
    collection_list_1 = dict()
    role_include_1 = RoleInclude.load(yaml_1, play_1, current_role_path_1, parent_role_1, variable_manager_1, loader_1, collection_list_1)

if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-25 05:50:49.985933
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    # Invoke method
    role_include_0 = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)



# Generated at 2022-06-25 05:50:53.439125
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    str_0 = None
    str_1 = None
    str_2 = None
    str_2 = RoleInclude.load(str_0,str_1,str_2)


# Generated at 2022-06-25 05:50:58.284237
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # create variables
    data = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    # execute test case
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except TypeError:
        pass
    else:
        print("Expected TypeError to be raised")


# Generated at 2022-06-25 05:51:03.208797
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a mock object
    mock_self = Mock()
    str_0 = 'test__str_0'
    str_1 = 'test__str_1'
    str_2 = 'test__str_2'
    str_3 = 'test__str_3'
    str_4 = 'test__str_4'
    str_5 = 'test__str_5'
    mock_self.get_role_params = Mock(return_value=(str_2,str_3,str_4))
    mock_self.get_dependencies = Mock(return_value=str_5)
    mock_self.vars = dict()
    mock_self.default_vars = dict()
    mock_self.handler_blocks = []
    mock_self.tasks = []
    mock_self.meta = dict()


# Generated at 2022-06-25 05:52:01.252595
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    result = RoleInclude.load('str_0','str_1','str_2','str_3','str_4','str_5')
    assert type(result) == RoleInclude

if __name__ == '__main__':
    test_RoleInclude_load()
    test_case_0()

# Generated at 2022-06-25 05:52:10.416026
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)

    data = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    try:
        result_0 = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except Exception as e:
        print(e)
    else:
        raise Exception("Expected error not raised" + "Exception message: " + str(e))


# Generated at 2022-06-25 05:52:11.091758
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True


# Generated at 2022-06-25 05:52:17.240653
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test if load returns False
    str_0 = None
    role_include_0 = RoleInclude(str_0)

    assert role_include_0.load() == False

    assert role_include_0._valid_attrs == {
        'apply', 'allow_duplicates', 'block', 'block_errors', 'deprecated', 'delegate_facts',
        'delegate_to', 'handlers', 'ignore_errors', 'import_role', 'post_tasks',
        'pre_tasks', 'register', 'role', 'roles', 'tasks', 'tags', 'vars', 'vars_files',
        'when'}


# Generated at 2022-06-25 05:52:27.378641
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # These tests are a bit brittle.  I'd like to figure out how to not
    # depend on the error text itself, because it makes this harder
    # to read, and also if the text changes it'll break these tests.
    # However, I want to assert that certain errors were generated and
    # these seem to be the only ways to do that.

    # Test that a string is OK if it's just a role name.
    var0 = 'foo'
    role_include_0 = RoleInclude(var0)

    # Test that a dict is OK if it has a 'role' attribute.
    # I'm using a dict here because it's easier to directly create
    # a dict than an AnsibleBaseYAMLObject.  The AttributeVariables
    # that AnsibleBaseYAMLObject depends on is not easy to directly
    # construct.

# Generated at 2022-06-25 05:52:36.010632
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Input and expected result.
    data_0 = "data_0"
    play_0 = "play_0"
    current_role_path_0 = "current_role_path_0"
    parent_role_0 = "parent_role_0"
    variable_manager_0 = "variable_manager_0"
    loader_0 = "loader_0"
    expected_result = None

    # Perform the test
    result = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0)

    # Verify the results
    assert(result == expected_result)


# Generated at 2022-06-25 05:52:36.861543
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True


# Generated at 2022-06-25 05:52:42.089137
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
  str_0 = None
  role_include_0 = RoleInclude(str_0)
  str_1 = None
  list_0 = None
  str_2 = None
  boolean_0 = False
  role_include_0.load(str_1, list_0, str_2, boolean_0)


# Generated at 2022-06-25 05:52:50.627203
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = "data_0"
    play_0 = "play_0"
    current_role_path_0 = "current_role_path_0"
    parent_role_0 = "parent_role_0"
    variable_manager_0 = "variable_manager_0"
    loader_0 = "loader_0"
    collection_list_0 = "collection_list_0"
    role_include_1 = RoleInclude(play_0, current_role_path_0, variable_manager_0, loader_0, collection_list_0)
    role_include_0 = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)

# Generated at 2022-06-25 05:53:00.743395
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    str_0 = None
    role_include_0 = RoleInclude(str_0)
    str_1 = None
    role_include_0.load(str_1)
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    str_7 = None
    str_8 = None
    role_include_1 = RoleInclude.load(str_2, str_3, str_4, str_5, str_6, str_7, str_8)
    str_9 = None
    str_10 = None
    str_11 = None
    str_12 = None
    str_13 = None
    str_14 = None
    str_15 = None
    str_16 = None
    role_include_2 = Role