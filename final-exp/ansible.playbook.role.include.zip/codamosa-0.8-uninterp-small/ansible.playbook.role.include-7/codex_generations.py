

# Generated at 2022-06-25 05:44:45.277068
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)

# Generated at 2022-06-25 05:44:48.352122
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Generate empty RoleInclude object
    RoleInclude_instance = RoleInclude()

    # Call load
    # load(data, play, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    RoleInclude_instance.load()

test_case_0()

# Generated at 2022-06-25 05:44:53.028101
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

# Generated at 2022-06-25 05:45:03.480878
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    str_0 = None
    dict_0 = {}
    dict_1 = {}
    role_include_0 = role_include_0.load(str_0, role_include_0, dict_0, dict_1, dict_0, dict_1)
    assert role_include_0 is not None
    assert dict_1 is not None
    assert dict_0 is not None
    assert dict_1 is not None
    assert dict_0 is not None
    assert dict_1 is not None
    assert dict_0 is not None
    assert dict_1 is not None
    assert dict_0 is not None
    assert dict_1 is not None
    assert dict_0 is not None
    assert dict_1 is not None
    assert dict

# Generated at 2022-06-25 05:45:06.057189
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)

# Generated at 2022-06-25 05:45:10.111749
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    foo = "'foo'"
    bar = "'bar'"
    baz = "'baz'"
    data_0 = RoleInclude()
    assert data_0.load(foo) == "'foo'" and data_0.load(bar) == "'bar'" and data_0.load(baz) == "'baz'"

# Generated at 2022-06-25 05:45:15.978941
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    list_1 = None
    list_2 = None
    list_3 = None
    list_4 = None
    list_5 = None
    role_include_0.load(list_1, True, list_2, list_3, list_4, list_5)

if __name__ == '__main__':
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:45:24.370497
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    # Unit test for role_include_0.load(data, play, current_role_path=None)
    # test case for exception AnsibleError
    try:
        role_include_0.load('', '', '', '', '')
    except AnsibleError as err:
        print(err)
        pass
    # test case for exception AnsibleParserError
    try:
        role_include_0.load('', '', '', '', '')
    except AnsibleParserError as err:
        print(err)
        pass

    # and now for something completely different
    # test case for exception AnsibleError

# Generated at 2022-06-25 05:45:25.872777
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    assert role_include_0.load() is None


# Generated at 2022-06-25 05:45:29.064735
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    variable_manager_0 = None
    data = None
    variable_manager_1 = None
    role_include_0 = RoleInclude(list_0)
    return_value = role_include_0.load(data, variable_manager_0, variable_manager_1)
    assert return_value is None


# Generated at 2022-06-25 05:45:38.310394
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    assert issubclass(RoleInclude, RoleDefinition) == True
    assert isinstance(RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list), RoleInclude) == True

# Generated at 2022-06-25 05:45:45.541651
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    str_1 = "ansible/includes/role.yml"
    str_2 = "ansible/includes"
    str_3 = "name"
    ansible_variable_manager_2 = AnsibleVariableManager()
    ansible_loader_1 = AnsibleFileLoader("ansible/includes/role.yml")
    ansible_collection_list_2 = AnsibleCollectionList()
    ansible_collection_list_2.list.append("peerdns=no  ipv6.disable=1")
    ansible_collection_list_2.list.append("no")
    ansible_collection_list_2.list.append("yes")
    ansible_collection_list_2.list.append("yes")
    ans

# Generated at 2022-06-25 05:45:54.253013
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    data_0 = None
    data_1 = None
    variable_manager_0 = None
    loader_0 = None
    variable_manager_0 = None
    loader_0 = None
    variable_manager_0 = None
    loader_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager_0 = None
    variable_manager

# Generated at 2022-06-25 05:45:59.572349
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    path_0 = os.path.join(__file__, '../../lib/ansible/playbook/role', '__init__.py')
    role_include_0 = RoleInclude.load(path_0)
    print(role_include_0)

if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-25 05:46:06.617680
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = []
    role_include_0 = RoleInclude(list_0)
    data_0 = {}
    play_0 = ''
    current_role_path_0 = ''
    parent_role_0 = ''
    variable_manager_0 = ''
    loader_0 = ''
    collection_list_0 = ''
    role_include_1 = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)

# Generated at 2022-06-25 05:46:12.781623
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Parameters:
    #   data: (string or dict) -
    #   play: (Play) -
    #   current_role_path: (string) -
    #   parent_role: (Role) -
    #   variable_manager: (VariableManager) -
    #   loader: (DataLoader) -
    #   collection_list: (CollectionList) -
    # Returns: RoleInclude instance

    # No return value specified, test here is useless
    pass

# Generated at 2022-06-25 05:46:16.896138
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    requirement = "role=test"
    play = None
    current_role_path = ""
    parent_role = None
    variable_manager = None
    loader = None
    data = {u'role': u'test'}
    result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)

    assert result.get_name() == 'test'


# Generated at 2022-06-25 05:46:24.694248
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition

    # test what happens when RoleDefinition.load does not return None
    list_0 = None
    role_definition_0 = RoleDefinition()
    role_definition_0._role_collection_list = list_0
    role_definition_0._role_path = None
    role_definition_0._role_name = None
    role_include_0 = RoleInclude(list_0)
    assert role_include_0.load('a_string', role_definition_0, None, None) == role_definition_0
    assert role_include_0.load('a_string', role_definition_0, None, None) != None
    assert role_include_0.load('a_string', role_definition_0, None, None) != False

# Generated at 2022-06-25 05:46:27.536678
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    dict_0 = {}
    assert role_include_0.load(dict_0) is None


# Generated at 2022-06-25 05:46:31.593579
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_1 = None
    dict_2 = None
    str_3 = None
    dict_4 = None
    role_include_1 = RoleInclude(list_1)
    role_include_0 = role_include_1.load(dict_2, str_3, dict_4)


# Generated at 2022-06-25 05:46:44.496870
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    string_0 = 'pre_tasks: []'
    play_0 = None
    current_role_path_0 = None
    parent_role_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    obj_0 = RoleInclude.load(string_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)
    assert isinstance(obj_0, RoleInclude)
    assert obj_0 is not None

# Generated at 2022-06-25 05:46:48.985561
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Initialize class instance
    data = [
        "string123"
    ]
    role_include = RoleInclude(data)
    # Initialize method paramerts
    play = "string"
    current_role_path = "string"
    parent_role = "string"
    variable_manager = "string"
    loader = "string"
    # Invoke method
    assert role_include.load(data, play, current_role_path, parent_role, variable_manager, loader) == None

# Generated at 2022-06-25 05:46:58.626295
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    data = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    # Invoke method
    try:
        data = "string value"
        role_include_0.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except ValueError:
        pass

    # Invoke method
    try:
        data = dict(foo="bar")
        role_include_0.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except ValueError:
        pass

# Generated at 2022-06-25 05:47:03.846379
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    data_0 = dict()
    play_0 = __import__('ansible.playbook.play')
    current_role_path_0 = 'playbooks/default'
    parent_role_0 = None
    variable_manager_0 = __import__('ansible.vars.manager')
    loader_0 = __import__('ansible.parsing.dataloader')
    collection_list_0 = __import__('ansible.collections.list')
    role_include_1 = role_include_0.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)

    data_1 = 'test'


# Generated at 2022-06-25 05:47:14.014295
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    #Test cases for method load of class RoleInclude

    list_0 = None
    str_0 = "1,2,3,4,5"
    role_include_0 = RoleInclude(list_0)
    role_include_0.load(str_0)

    str_0 = "1,2,3,4,5"
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    role_include_0.load(str_0)

    list_0 = None
    str_0 = "1,2,3,4,5"
    role_include_0 = RoleInclude(list_0)
    role_include_0.load(str_0)

    str_0 = "1,2,3,4,5"
    list_0 = None


# Generated at 2022-06-25 05:47:17.830763
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        test_case_0()
    except:
        print('Exception caught in test_case_0')
        raise

# Generated at 2022-06-25 05:47:21.924790
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # AnsibleParserError raised testing with isinstance(data, string_types) or isinstance(data, dict) or isinstance(data, AnsibleBaseYAMLObject)
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    data_0 = object()
    play_0 = object()
    current_role_path_0 = object()
    role_include_0.load(data_0, play_0, current_role_path_0)

# Generated at 2022-06-25 05:47:31.636093
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:47:37.918986
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    data_0 = 'test'
    play_0 = None
    current_role_path_0 = None
    parent_role_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    RoleInclude_0 = Rol

# Generated at 2022-06-25 05:47:42.272712
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    data = 'ansible-role-test'
    play = 'ansible-play-test'
    variable_manager = 'ansible-variable-manager-test'
    loader = 'ansible-loader-test'
    collection_list = 'ansible-collection-list-test'

    role_include_0.load(data, play, variable_manager, loader, collection_list)

# Generated at 2022-06-25 05:48:00.015563
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Requirement for variable.manager
    variable_manager_0 = None
    variable_manager_0 = VariableManager(loader=None, inventory=None)
    # Requirement for get_options
    parser = None

# Generated at 2022-06-25 05:48:00.638845
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-25 05:48:06.821305
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = None
    play = None
    current_role_path = None
    parent_role = None
    role_include_1 = RoleInclude.load(data, play, current_role_path=None, parent_role=parent_role)

# Generated at 2022-06-25 05:48:08.759678
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: implement unit test for load
    assert True


# Generated at 2022-06-25 05:48:16.283893
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    print('***** RoleInclude.load() unit test start *****')

    data = 'sample'
    play = [1, 2, 3]
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = [1, 2, 3]

    # Test case:
    role_include_0 = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)

    print('***** Unit test for RoleInclude.load() end *****\n')


# Generated at 2022-06-25 05:48:19.021934
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-25 05:48:21.511852
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    obj = RoleInclude()
    inp_obj = None
    assert obj.load(inp_obj) is not None


# Generated at 2022-06-25 05:48:26.607718
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        list_0 = None
        role_include_0 = RoleInclude(list_0)
        path_0 = '/root/ansible/test/units/lib/ansible/playbook/role/include.py'
        ya_0 = role_include_0._get_parent_attribute(path_0)
    except Exception as e:
        # print(e)
        pass


# Generated at 2022-06-25 05:48:29.750447
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "test string 0"
    play = "test string 1"
    role_include_0 = RoleInclude.load(data, play)
    assert(role_include_0 is not None)

# Generated at 2022-06-25 05:48:33.934381
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    data_0 = dict(name='default-role-name')
    role_include_0 = RoleInclude(list_0)
    role_include_0 = RoleInclude.load(data_0, list_0)

# Generated at 2022-06-25 05:49:00.900567
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    param_data = None
    param_play = None
    param_current_role_path = None
    param_parent_role = None
    param_variable_manager = None
    param_loader = None
    param_collection_list = None
    role_include_0 = RoleInclude.load(param_data, param_play, param_current_role_path, param_parent_role, param_variable_manager, param_loader, param_collection_list)


# Generated at 2022-06-25 05:49:08.070786
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)

    loader_0 = None
    role_basedir_0 = "hoge"
    list_1 = None
    variable_manager_0 = None
    data_0 = None
    play_0 = None
    parent_role_0 = None
    current_role_path_0 = None
    role_include_1 = role_include_0.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, list_1)



# Generated at 2022-06-25 05:49:15.245327
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None 
    current_role_path = None 
    parent_role = None 
    variable_manager = None 
    loader = None 
    collection_list = None 
    data = None # Expected exception
    try:
        RoleInclude.load(data, list_0, current_role_path, parent_role, variable_manager, loader, collection_list)
    except:
        pass



# Generated at 2022-06-25 05:49:23.082609
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play_0 = '{k8b)S<i}'

    variable_manager_0 = Attribute(play_0)

    loader_0 = '!#Mc=S@'
    collection_list_0 = 'qB;F4|'

    data_0 = 'xpl~HV'

    current_role_path_0 = 'L!uV;'

    parent_role_0 = '%{1u#'
    try:
        role_include_0 = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)
    except AnsibleParserError:
        pass
    else:
        raise Exception

    data_1 = '2!yg,'

    current_role_path

# Generated at 2022-06-25 05:49:31.709315
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    data_0 = 4
    play_0 = 4
    current_role_path_0 = 4
    variable_manager_0 = 4
    loader_0 = 4
    ansible_0 = 'Ansible'
    collection_1 = 'Collection'
    collection_2 = 'Collection'
    collection_3 = 'Collection'
    collection_4 = 'Collection'
    collection_list_0 = 'CollectionList'
    collection_list_1 = 'CollectionList'
    collection_list_2 = 'CollectionList'
    collection_list = [collection_0, collection_1, collection_2, collection_3, collection_4]
    collection_list_3 = 'CollectionList'
    collection_list_4 = 'CollectionList'


# Generated at 2022-06-25 05:49:37.984175
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    data_0 = None
    play_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    role_include_0 = RoleInclude.load(data_0, play_0, None, None, variable_manager_0, loader_0, collection_list_0)


# Generated at 2022-06-25 05:49:39.758739
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)

# Generated at 2022-06-25 05:49:47.068077
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    # [self, data, play, current_role_path, parent_role, variable_manager, loader]
    role_include_0 = RoleInclude(list_0)

    # [data, play, current_role_path, parent_role, variable_manager, loader]
    role_include_0.load_data(list_0, list_0, list_0, list_0, list_0)



# Generated at 2022-06-25 05:49:52.108750
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None

    role_include_0 = RoleInclude(list_0)
    dict_0 = dict()
    dict_0['tasks'] = [dict()]

    result = role_include_0.load(dict_0)
    assert result is not None

# Generated at 2022-06-25 05:50:02.039340
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    arg_0 = []
    arg_1 = 'test_value_1'
    arg_2 = 'test_value_2'
    arg_3 = 'test_value_3'
    arg_4 = 'test_value_4'
    arg_5 = 'test_value_5'
    arg_6 = 'test_value_6'
    arg_7 = 'test_value_7'
    arg_8 = 'test_value_8'
    try:
        RoleInclude.load(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
    except AnsibleError as e:
        print("AnsibleError: {0}".format(e))


# Generated at 2022-06-25 05:50:46.515234
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)

    try:
        role_include_0.load(list_0, list_0)
    except Exception as exception_0:
        print(exception_0)

# Generated at 2022-06-25 05:50:49.681382
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    RoleInclude.load(list_0, list_0)


# Generated at 2022-06-25 05:50:59.867396
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.parsing.dataloader import DataLoader
    data_loader_0 = DataLoader()
    list_0 = None
    file_path_0 = 'a_file_path'
    role_include_0 = RoleInclude(list_0)
    variable_manager_0 = 'variable_manager_0'
    loader_0 = None
    collection_list_0 = None
    role_metadata_0 = RoleMetadata()
    role_metadata_0.role_name = 'role_metadata_0_role_name'
    role_metadata_0.role_path = file_path_0
    role_metadata_0.main_file_name = 'role_metadata_0_main_file_name'

# Generated at 2022-06-25 05:51:06.187574
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    role_path_0 = None
    role_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    str_0 = RoleInclude.load(role_path_0, role_0, role_path_0, role_0, variable_manager_0, loader_0, collection_list_0)


# Generated at 2022-06-25 05:51:13.632964
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    data = 'data'
    list_1 = None
    current_role_path = 'current_role_path'
    parent_role = 'parent_role'
    loader = 'loader'
    collection_list = 'collection_list'
    var_0 = RoleInclude.load(data, list_1, current_role_path, parent_role, loader, collection_list)
    var_0.load_data(data, loader=loader)


# Generated at 2022-06-25 05:51:17.976787
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test for load
    """
    role_include_0 = RoleInclude()
    data = {}
    play = None
    assert role_include_0.load(data, play) == None


# Generated at 2022-06-25 05:51:25.390931
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    str_0 = "name"
    dict_0 = {'role': str_0}
    dict_1 = dict_0
    role_include_1 = role_include_0.load(dict_1)
    assert role_include_1.get_name() == "name"


# Generated at 2022-06-25 05:51:31.893223
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play_0 = 2.5
    current_role_path_0 = AnsibleParserError()
    variable_manager_0 = 5.0
    loader_0 = 6.1
    collection_list_0 = object()
    data_0 = object()
    retval_0 = RoleInclude.load(data_0, play_0, current_role_path_0, variable_manager_0, loader_0, collection_list_0)
    raise NotImplementedError()

test_case_0()
test_RoleInclude_load()

# Generated at 2022-06-25 05:51:35.120101
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:51:44.255361
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_definition = RoleInclude(list_0)
    data = "ansible."
    play = "ansible.playbook.play.Play.Play"
    current_role_path = os.path.dirname(__file__)
    parent_role = "ansible.playbook.role.definition.RoleDefinition.RoleDefinition"
    variable_manager = "ansible.vars.manager.VariableManager.VariableManager"
    loader = "ansible.parsing.dataloader.DataLoader.DataLoader"
    collection_list = "ansible.playbook.collections.base.BaseCollection"
    role_definition_load = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

# Generated at 2022-06-25 05:53:28.647980
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)

    # RoleInclude.load with defaults
    list_0 = None
    string_0 = 'test_string'
    role_include_0.load(string_0, list_0)

    # RoleInclude.load with defaults
    list_0 = None
    string_0 = 'test_string'
    role_include_0.load(string_0, list_0)

    # RoleInclude.load with defaults
    list_0 = None
    string_0 = 'test_string'
    role_include_0.load(string_0, list_0)

    # RoleInclude.load with defaults
    list_0 = None
    string_0 = None

# Generated at 2022-06-25 05:53:35.376416
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)

    data_0 = None
    play_0 = None
    current_role_path_0 = None
    parent_role_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    role_include_1 = role_include_0.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)
    assert role_include_1 is not None


# Generated at 2022-06-25 05:53:40.106979
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    var_name_0 = None
    var_name_1 = role_include_0
    var_name_1 = RoleInclude.load(var_name_0, var_name_1)


# Generated at 2022-06-25 05:53:49.932526
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #pass
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    arg_0 = 'param: value'
    play = 'param: value'
    current_role_path = 'param: value'
    parent_role = 'param: value'
    variable_manager = 'param: value'
    loader = 'param: value'
    collection_list = 'param: value'
    out = role_include_0.load(arg_0, play, current_role_path, parent_role, variable_manager, loader, collection_list)

if __name__ == '__main__':
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:53:52.758362
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    list_1 = None
    role_include_0 = role_include_0.load(list_1)

# Generated at 2022-06-25 05:53:55.286614
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)



# Generated at 2022-06-25 05:53:59.333581
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = 'a, b, c'
    role_include_0 = RoleInclude(list_0)
    with pytest.raises(AnsibleError):
        role_include_0.load('a, b, c', variable_manager=None, loader=None)

# Generated at 2022-06-25 05:54:04.259559
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    object_0 = None
    str_0 = "roles/jdoe.apache"
    str_1 = "jdoe.apache"
    role_include_0 = RoleInclude(list_0)
    role_include_0.load(str_0, list_0, str_1, object_0, object_0, object_0)


# Generated at 2022-06-25 05:54:08.035498
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    role_include_0 = RoleInclude(list_0)
    str_0 = 'test_value'
    loader_0 = None
    variable_manager_0 = None
    role_include_0.load(str_0, loader_0, variable_manager_0)

    assert True

# Generated at 2022-06-25 05:54:17.319901
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = None
    variable_manager_0 = object()
    loader_0 = object()
    list_1 = None
    role_include_0 = RoleInclude(list_0)
    data_0 = {}
    play_0 = object()
    current_role_path_0 = object()
    parent_role_0 = object()
    boolean_0 = role_include_0.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, list_1)
    assert boolean_0 is True, 'boolean_0 is False'