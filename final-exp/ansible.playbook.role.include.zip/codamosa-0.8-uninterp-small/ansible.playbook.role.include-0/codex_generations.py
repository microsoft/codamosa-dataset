

# Generated at 2022-06-25 05:44:49.672604
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    loader_0 = DataLoader()
    variable_manager_0 = VariableManager()
    data_0 = dict()
    data_0['vars'] = dict()
    data_0['vars']['hostvars'] = dict()
    data_0['vars']['hostvars']['test_1'] = dict()
    data_0['vars']['hostvars']['test_1']['hostname'] = 'test'
    data_0['vars']['hostvars']['test_1']['inventory_hostname'] = 'test'
    data_0['vars']['hostvars']['test_1']['inventory_hostname_short'] = 'test'
    data_0['remote_user'] = 'test'

# Generated at 2022-06-25 05:44:52.025769
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)


# Generated at 2022-06-25 05:45:01.446010
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    data_0 = 'data'
    play_0 = 'play'
    current_role_path_0 = 'current_role_path'
    parent_role_0 = 'parent_role'
    variable_manager_0 = 'variable_manager'
    loader_0 = 'loader'
    collection_list_0 = 'collection_list'

    role_include_0 = RoleInclude()

    role_include_1 = RoleInclude.load(data_0, play_0, current_role_path_0,
                                      parent_role_0, variable_manager_0,
                                      loader_0, collection_list_0)
    assert isinstance(role_include_1, RoleInclude)

# Generated at 2022-06-25 05:45:11.993445
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    
    # data = dict(role)
    # play = AnsiblePlay()
    # current_role_path = None
    # parent_role = AnsibleRole()
    # variable_manager = AnsibleVariableManager()
    # loader = DataLoader()

    # ri = RoleInclude(play, current_role_path=current_role_path, variable_manager=variable_manager, loader=loader)

    # actual = ri.load(data, play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader)
#     assert actual == expected

    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)

    str_0 = 'host'
    int_0

# Generated at 2022-06-25 05:45:21.123737
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("=== Running tests/unit/RoleInclude_load unit tests ===")
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    data_0 = ''
    play_0 = ['']
    current_role_path_0 = '$'
    parent_role_0 = ['']
    variable_manager_0 = ['']
    loader_0 = ['']
    collection_list_0 = ['']
    RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_

# Generated at 2022-06-25 05:45:25.744663
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)

    data_1 = {'test_key': 'test_value'}
    try:
        role_include_0.load(data_1, role, None)
    except AssertionError:
        pass
    except:
        import traceback
        exception = traceback.format_exc()
        raise AssertionError(exception)

# Generated at 2022-06-25 05:45:27.053605
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    role_include_1 = role_include_0.load(role_include_0, role_include_0)


# Generated at 2022-06-25 05:45:30.255505
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = dict()
    dict_0['yaml_data'] = "{'name': 'test', 'tasks': [{'action': {'module': 'ping', 'args': {}}, 'name': 'ping'}]}"
    dict_0['play'] = {'hosts': 'all', 'name': 'test'}
    dict_0['role_basedir'] = '../test/unit/lib/ansible/playbook/test_data/roles_defaults/'
    role_include_0 = RoleInclude(dict_0)


# Generated at 2022-06-25 05:45:38.845381
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    bytes_1 = b'\xdcQC]$J\xfe'
    bytes_2 = b'\xdcQC]$J\xfe'
    bytes_3 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    assert isinstance(role_include_0, RoleInclude) == True
    role_include_0.load(bytes_1, bytes_2, current_role_path=bytes_3)

# Generated at 2022-06-25 05:45:40.277180
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print(to_native(RoleDefinition.load('foo', 'bar')))

test_RoleInclude_load()

# Generated at 2022-06-25 05:45:46.904184
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    role_include_0.task_blocks = 0
    role_include_0.role_path = 0
    role_include_0.role_name = 0
# TODO: need more programming


# Generated at 2022-06-25 05:45:48.979784
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)

# Generated at 2022-06-25 05:45:52.291599
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)

    bytes_1 = b'\xdcQC]$J\xfe'
    role_include_1 = RoleInclude(bytes_1)


# Generated at 2022-06-25 05:45:53.697489
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-25 05:45:55.602318
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)

# Generated at 2022-06-25 05:46:00.138521
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    role_include_0.load()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:46:07.502478
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()

    data = "foo"
    ri = role_include_1.load(data)
    assert isinstance( ri, RoleRequirement)

    data = "foo,bar,baz"
    ri = role_include_1.load(data)
    assert isinstance( ri, RoleRequirement)

    data = dict(role="foo", tasks="main.yml", tags='t0')
    ri = role_include_1.load(data)
    assert isinstance( ri, RoleRequirement)



# Generated at 2022-06-25 05:46:12.369805
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'foo'
    play = 'bar'
    role_include_0 = RoleInclude(data, play)
    play = 'foo'
    data = 'foo'
    role_include_1 = RoleInclude(data, play)
    data = 'foo'
    play = 'foo'
    role_include_2 = RoleInclude(data, play)


# Generated at 2022-06-25 05:46:20.700332
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_obj0 = RoleInclude()
    #assert role_include_obj0.load is __invert__
    #assert role_include_obj0.load is __index__
    #assert role_include_obj0.load is __new__
    #assert role_include_obj0.load is __reversed__
    #assert role_include_obj0.load is __rand__
    #assert role_include_obj0.load is __repr__
    #assert role_include_obj0.load is __rshift__
    #assert role_include_obj0.load is __and__
    #assert role_include_obj0.load is __rrshift__
    #assert role_include_obj0.load is __ror__
    #assert role_include_obj0.load is __rxor__
    #assert

# Generated at 2022-06-25 05:46:24.778437
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    str_0 = ''
    str_1 = ''
    dict_0 = dict()
    dict_1 = dict()
    role_0 = RoleInclude.load(str_0, str_1, dict_0, role_include_0, dict_1)


# Generated at 2022-06-25 05:46:33.227422
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    data_0 = '`\xfd\xde\xc7\x98\xeb\xa0\xff'
    role_include_0 = RoleInclude(bytes_0)
    role_include_0.RoleRequirement.RoleRequirement(data_0)
    role_include_0.RoleDefinition.load()
    role_include_0.load()


# Generated at 2022-06-25 05:46:37.504205
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    test_case_0()

# Generated at 2022-06-25 05:46:44.860622
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    yaml_0 = '\x00\x00'
    data_0 = Attribute()
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.definition import RoleDefinition
    play_0 = RoleDefinition(data_0, yaml_0, yaml_0, data_0, yaml_0, yaml_0, data_0)
    role_include_0.load(yaml_0, play=play_0)


# Generated at 2022-06-25 05:46:50.571805
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    data_0 = None
    play_0 = None
    current_role_path_0 = None
    parent_role_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    assert isinstance(RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0), RoleRequirements)


# Generated at 2022-06-25 05:46:58.457862
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    assert role_include_0._delegate_to == 'kPPz\x12\x01'
    assert role_include_0._delegate_facts == False
    assert role_include_0.get_vars() == {
        'roles': {
            'vars': {
                'delegate_to': 'kPPz\x12\x01',
                'delegate_facts': False
            }
        }
    }

# vim: set ansi sts=4 expandtab ft=python :

# Generated at 2022-06-25 05:47:00.866481
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    role_include_0.load(bytes_0, bytes_0)


# Generated at 2022-06-25 05:47:08.623796
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    data_0 = bytes_0
    play_0 = None
    current_role_path_0 = None
    parent_role_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    role_include_0 = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)


# Generated at 2022-06-25 05:47:16.280927
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Tests that the correct error is thrown if the input (data) is in incorrect format

    :return: None
    """
    # Tests if data is not a string, dict, or AnsibleBaseYAMLObject
    test_int = 5
    try:
        RoleInclude.load(data=test_int, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    except AnsibleParserError:
        assert True
    else:
        assert False

# Generated at 2022-06-25 05:47:18.572515
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)

    assert bytes_0 != role_include_0

# Generated at 2022-06-25 05:47:27.878305
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    try:
        role_include_1 = role_include_0.load()
    except Exception as exception_0:
        print('Exception:')
        print(type(exception_0))
        print(exception_0)
    else:
        if type(role_include_1) == type(role_include_0):
            print('Test passed.')
        else:
            print('Test failed:')
            print('    role_include_1 is not of type RoleInclude')

if __name__ == '__main__':
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:47:42.334034
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)

    # set up mock objects
    role_include_0._play = mock()
    role_include_0._play._basedir = '/tmp/ansible_collections/ansible_collections/ceph/ping/'
    role_include_0._variable_manager = mock()
    role_include_0._loader = mock()
    role_include_0._collection_list = mock()
    role_include_0._collection_list.all = mock()

    # Load test data from file
    data = yaml.load(open(u'ansible/test/unit/parsing/yaml/data/role_include-load.yml'))

    # Run the tested method with

# Generated at 2022-06-25 05:47:43.048447
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    raise NotImplementedError


# Generated at 2022-06-25 05:47:51.961416
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    bytes_1 = b'l\xf0\x1f\xf7\x8b\xbf\xe4\x87\x9c\xd6\xbc\x0f\xf1'
    role_include = RoleInclude(bytes_0)
    assert role_include.load((b'\xdcQC]$J\xfe')) == role_include
    assert role_include.load((b'\xdcQC]$J\xfe', bytes_0)) == role_include
    assert role_include.load((b'\xdcQC]$J\xfe', bytes_0, bytes_1)) == role_include


# Generated at 2022-06-25 05:47:58.064897
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = b'\xf5\x96\xec'
    play_0 = b'\x15\x81\x9a'
    current_role_path_0 = b'6\xde]\x98\x9a\xb2\x9c\xce\x99\xa0\x1f\x8f\x81'
    parent_role_0 = b'\xad\xdc\x0c\xe1\xfe\xf0\x14\x83\xeb_\x9f\x84\xe1'
    variable_manager_0 = b'\xc3\xa4\xeb\x94\xdb\xf6\xac\x17\xe2\xf6\x85\x1b'

# Generated at 2022-06-25 05:48:06.731118
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    bytes_1 = b'\xc0\xed*\xdc\xd8\x1b\x00\x1b\x03\x9c\xc9\xc2\x02\x1f\x99s\xac\xee\xa2E\x0f\xc9\x91\x1c\xb0L\xa4\'\xe0\xfa<\xfa\x924\x0e\x0b\xdc\xe6\xcc?5\xee'
    loader_0 = None
    collection_list_0 = None
    variable_manager_0 = None
    play_0 = None
    role_include_1

# Generated at 2022-06-25 05:48:17.900920
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    str_0 = ansible.base_vars.get('ansible_distribution')
    assert isinstance(ansible.base_vars.get('ansible_distribution'), string_types)

    str_1 = ansible.base_vars.get('ansible_distribution')
    assert isinstance(ansible.base_vars.get('ansible_distribution'), string_types)

    str_2 = ansible.base_vars.get('ansible_distribution')
    assert isinstance(ansible.base_vars.get('ansible_distribution'), string_types)

    str_3 = str_2


# Generated at 2022-06-25 05:48:19.228913
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        test_case_0()
        assert True
    except:
        assert False

#
#Test for overriding methods
#

# Generated at 2022-06-25 05:48:26.923574
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    play_0 = Mock()
    current_role_path_0 = Mock()
    parent_role_0 = Mock()
    variable_manager_0 = Mock()
    loader_0 = Mock()
    collection_list_0 = Mock()
    role_include_1 = RoleInclude._load(role_include_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)
    assert role_include_0 is role_include_1
    assert role_include_1._loader is loader_0

# Generated at 2022-06-25 05:48:30.936799
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Load_data (data, variable_manager = None, loader = None)
    role_include_0 = RoleInclude()
    data = ""
    play = ""
    result = role_include_0.load(data, play)
    assert isinstance(result, RoleInclude)


# Generated at 2022-06-25 05:48:39.956390
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # NOTE: this test is not complete
    bytes_0 = b'\x97\xd6\x18\x93\xd0\x84\xdb\xd1\x8d\x9d\xdcQC]$J\xfe\x06\x89\x10\xbc\x8b\x9f\xdc\xe7\x88\xd8a\x97\xf6'
    role_include_0 = RoleInclude(bytes_0)
    # testing for equality with a known value
    assert(role_include_0._delegate_to is None)
    assert(role_include_0._delegate_facts is False)

# Generated at 2022-06-25 05:48:50.034013
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create test objects
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)

    # Run the test
    role_include_0.load()

# Generated at 2022-06-25 05:48:56.824389
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play_0 = object()
    current_role_path_0 = object()
    parent_role_0 = object()
    variable_manager_0 = object()
    loader_0 = object()
    data_0 = object()
    collection_list_0 = object()

    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    role_include_0.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0)

# Generated at 2022-06-25 05:49:07.690789
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    loader_0 = DataLoader()
    variable_manager_0 = VariableManager()
    collection_list_0 = CollectionList()

    path_0 = 'a'
    path_1 = '/tmp/ansible-test'
    path_2 = '/usr/local/share/ansible/ansible_collections/nagios/plugins/config'
    path_3 = '/usr/local/share/ansible/ansible_collections/nagios/plugins/action/__init__.py'
    path_4 = '/usr/local/share/ansible/ansible_collections/nagios/plugins/action/__init__.pyc'
    path_5 = '/usr/local/share/ansible/ansible_collections/nagios/plugins/action/ping.pyc'

# Generated at 2022-06-25 05:49:18.885119
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test 1
    # test_case_0
    bytes_0 = b'\xdcQC]$J\xfe'

    role_include_0 = RoleInclude.load(bytes_0)

    # Verify
    assert(role_include_0.get_role_name() == "test_case_0")
    assert(role_include_0.get_role_path() == "/path/to/roles/test_case_0")
    assert(role_include_0.get_action_suffix() == "test_case_0")
    assert(role_include_0.get_dependencies() == [])
    assert(role_include_0.get_implicit() == False)
    assert(role_include_0.get_default_vars() == {})

    # Test 2
    # test

# Generated at 2022-06-25 05:49:25.327912
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    data_0 = '7>1W_\u0019.\u0017\u0012\u001b'

# Generated at 2022-06-25 05:49:35.844897
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:49:44.722094
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'q\xd9\x01P\xd6\x1b\x19\xbcl\xeb\xff`'
    bytes_1 = b'J\x16\x1a\x92\x06\x95\xf7\x18\x9a\xe9\x9d'
    role_include_0 = RoleInclude(bytes_0)
    role_include_1 = RoleInclude(bytes_1)
    role_definition_0 = role_include_0.load(role_include_1, role_include_1)
    int_0 = 0
    str_0 = "H'\x8e\x90\xd9"
    str_1 = str_0.lower()
    int_1 = len(str_1)

# Generated at 2022-06-25 05:49:51.937038
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    bytes_1 = b'^\x0b'
    bytes_2 = b'\xfc\x1c\x92\x9e\xa5\x8b\xa2\xe3a.\x96'
    bytes_3 = b';\x9f\n'

# Generated at 2022-06-25 05:50:02.558753
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:50:07.172443
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    assert isinstance(role_include_0, RoleInclude)


# Generated at 2022-06-25 05:50:32.000906
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:50:42.716530
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    # Empty dict
    dict_0 = {}
    bytes_0 = b'\xdcQC]$J\xfe'
    # Empty dict
    dict_1 = {}
    bytes_1 = b'\xdcQC]$J\xfe'
    # Empty dict
    dict_2 = {}
    bytes_1 = b'\xdcQC]$J\xfe'
    # Empty dict
    dict_3 = {}
    bytes_2 = b'\xdcQC]$J\xfe'
    # Empty dict
    dict_4 = {}
    bytes_3 = b'\xdcQC]$J\xfe'
    # Empty

# Generated at 2022-06-25 05:50:52.725516
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
 
    # source data
    bytes_0 = b'R\x00\x00\x00'
    role_include_0 = RoleInclude(bytes_0)

    # target data
    string_0 = 'testcase_RoleInclude_load'
    int_0 = 9
    list_0 = [string_0, None]
    role_requirement_0 = RoleRequirement.load(list_0)
    list_1 = [role_requirement_0]
    list_2 = [int_0]
    list_3 = [string_0]
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}

# Generated at 2022-06-25 05:50:54.520741
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    with pytest.raises(AnsibleError) as ansible_error:
        test_case_0()

# Generated at 2022-06-25 05:51:00.978885
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)

    def side_effect_function_0(*args, **kwargs):
        return role_include_0

    role_include_0._RoleInclude__load_role = MagicMock(return_value=1, side_effect=side_effect_function_0)
    role_include_0.load_data = MagicMock(return_value=1)
    bytes_1 = b'\xdcQC]$J\xfe'
    role_include_1 = RoleInclude(bytes_1)

    def side_effect_function_1(*args, **kwargs):
        return role_include_1

    role_include_1._RoleInclude__load_role = MagicM

# Generated at 2022-06-25 05:51:11.681514
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    loader_0 = MockLoader()
    data_0 = 'apa'
    current_role_path_0 = 'junk'
    parent_role_0 = 'matt'
    variable_manager_0 = MockVariableManager()
    play_0 = MockPlayBook()
    test_value_0 = role_include_0.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, None)    
    assert test_value_0 is not None
    assert test_value_0.role_path == os.path.join(b'apa'.decode(encoding='UTF-8'), b'junk'.decode(encoding='UTF-8'))

# Generated at 2022-06-25 05:51:16.196642
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = 8
    play_0 = Play()
    current_role_path_0 = 8
    parent_role_0 = 8
    variable_manager_0 = 8
    loader_0 = 8
    result = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:51:23.057388
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    #role_basedir
    os.chdir('..')
    role_basedirs = [os.getcwd(), '', 'site.yml', None, to_native('\u5357\u5bab\u8def\u8857')]
    #data
    playbooks = ['../lib/ansible/playbook/__init__.py', to_native('\u5357\u5bab\u8def\u8857'), '', b'\xdcQC]$J\xfe', '../lib/ansible/playbook']

# Generated at 2022-06-25 05:51:28.497712
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    def test_load_0(arg_0):
        ri = RoleInclude()
        assert ri.load(arg_0) == None

        test_load_0('ian')


# Generated at 2022-06-25 05:51:38.509932
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    Unit test for method load of class RoleInclude
    '''
    byte_str = bytes('abc', 'utf-8')
    role_include_0 = RoleInclude(byte_str)
    # test case for type 'str'
    #assert "assertion failed" in role_include_0.load(None,None,None,None,None,None)
    # test case for type 'dict'
    #assert "assertion failed" in role_include_0.load(None,None,None,None,None,None)
    # test case for type 'AnsibleBaseYAMLObject'
    #assert "assertion failed" in role_include_0.load(None,None,None,None,None,None)
    # test case for type 'list'
    #assert "assertion failed" in role_

# Generated at 2022-06-25 05:52:13.504598
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_1 = RoleInclude(bytes_0)
    bytes_1 = b'\xdcQC]$J\xfe'
    variable_manager_0 = VariableManager(loader=None, variables=dict())
    loader_0 = DataLoader()
    str_0 = role_include_1.load(bytes_1, variable_manager=variable_manager_0, loader=loader_0)


# Generated at 2022-06-25 05:52:20.562194
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'[\xde\x02\x8f'
    variable_manager = os.urandom(34)
    role_include_0 = RoleInclude(bytes_0)
    dict_0 = dict()
    dict_0[role_include_0] = os.urandom(37)
    role_include_0.load(dict_0, variable_manager)
    # test to see if method load is overridden
    dict_1 = dict()
    dict_1[role_include_0] = os.urandom(33)
    role_include_0.load(dict_1, variable_manager)
    dict_2 = dict()
    dict_2[role_include_0] = os.urandom(29)
    role_include_0.load(dict_2, variable_manager)


# Generated at 2022-06-25 05:52:24.968657
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    vars_0 = dict()
    data_0 = ''
    loader_0 = None
    collection_list_0 = ''
    variable_manager_0 = ''
    play_0 = ''
    role_basedir_0 = ''
    parent_role_0 = ''

    # Test no exception is raised
    try:
        role_include_0 = RoleInclude.load(data_0, play_0, role_basedir_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)

    except Exception as returned:
        assert True
    else:
        assert False


# Generated at 2022-06-25 05:52:35.501476
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    new_attributes = {
        'ansible_connection': 'ssh',
        'ansible_ssh_pass': 'hunter2'
    }


# Generated at 2022-06-25 05:52:46.075755
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    int_0 = 0
    str_1 = '\U0001d5e6\U00027942\U0001cdd8\U0001b6d1Ad\xba\xcf\U00029a1a\U0003fdf3\U00018e61\U000199b3\U000120f3\U00014b4a\U000284e4\xce\xe0\U000160fd\U000294ab\xf4\U00027c85\U00038d13\U00027e2a'

# Generated at 2022-06-25 05:52:52.863831
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)
    data_0 = 'fh'
    play_0 = {}
    current_role_path_0 = 'A'
    parent_role_0 = '_Fp\xfc'
    variable_manager_0 = 'o'
    collection_list_0 = 'yG\x99'
    role_include_0 = role_include_0.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, variable_manager_0, collection_list_0)
    variable_manager_1 = '7\x92'
    variable_manager_2 = variable_manager_0
    variable_manager_3 = variable

# Generated at 2022-06-25 05:53:00.809783
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:53:03.658433
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)

    bytes_1 = b'\xdd\x1d-\xc5\x10\xe7\x03'
    assert role_include_0._delegate_to == bytes_1


# Generated at 2022-06-25 05:53:05.890479
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    play_0 = object()
    role_include_0 = RoleInclude.load(bytes_0, play_0)

if __name__ == "__main__":
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:53:10.847692
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print('unit test for RoleInclude.load')
    # Note that this test is expected to fail, as the 
    #  generated test function for load calls the 
    #  load function with incorrect arguments.
    #  Add assert(0, msg) statements at the start of 
    #  the load instrumented code below to help 
    #  diagnose the problem.
    # test_case_0()
    print('finished test')

# Generated at 2022-06-25 05:54:18.479003
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("Test load")
    # test loads a yaml file related to a role
    import os
    import sys
    import yaml
    file = "../../create-user/meta/main.yml"
    stream = open(os.path.join(sys.path[0], file), 'r')
    dataMap = yaml.safe_load(stream)
    stream.close()
    for key, value in dataMap.items():
        if key == "dependencies":
            deps = value
            break
    #print(deps)
    data = deps[0]
    #print(data)
    play = 0
    current_role_path = "../../create-user"
    parent_role = 0
    variable_manager = 0
    loader = 0
    collection_list = 0
    role_include_

# Generated at 2022-06-25 05:54:23.044050
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("Testing RoleInclude_load...")
    bytes_0 = b'\xdcQC]$J\xfe'
    role_include_0 = RoleInclude(bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:54:32.680214
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    args_0 = {
        Attribute.ROLES_PATH: '',
        Attribute.ROLE: '',
        'variable_manager': {
            Attribute.VARIABLES: '',
            Attribute.DEFAULT: '',
            Attribute.SET_FACT: ''
        },
        Attribute.LOADER: '',
        Attribute.CONNECTION_PLUGIN_PATH: '',
        Attribute.VARS_PLUGINS: '',
        Attribute.PLAY: '',
        Attribute.FILE_NAME: ''
    }
    assert args_0.keys() == RoleInclude.load.__code__.co_varnames
    assert isinstance(RoleInclude.load.__code__, type(test_RoleInclude_load.__code__))

# Generated at 2022-06-25 05:54:35.409453
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_1 = b'\xdcQC]$J\xfe'
    role_include_1 = RoleInclude(bytes_1)

if __name__ == '__main__':
    # test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:54:39.730402
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xdcQC]$J\xfe'
    dict_0 = dict()
    tuple_0 = (RoleInclude(tuple_0, dict_0, dict_0, dict_0, dict_0), RoleInclude(dict_0, bytes_0, dict_0, dict_0, dict_0))

# Test for method __init__ of class RoleInclude

# Generated at 2022-06-25 05:54:50.212308
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_3 = b'\xdcQC]$J\xfe'
    bytes_4 = b'\xfb\x04\x1b\xf2\x86\xc5\xfd\x81\xec\xac\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'