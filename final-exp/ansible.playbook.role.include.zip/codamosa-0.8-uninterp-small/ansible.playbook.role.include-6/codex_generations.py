

# Generated at 2022-06-25 05:44:49.467289
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = 'role_name'
    play_0 = 'play_string'
    try:
        RoleInclude.load(data_0, play_0)
        assert False
    except TypeError as e:
        print(e)
        assert True


# Generated at 2022-06-25 05:44:56.279619
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    list_0 = [int(), int(), int(), int()]
    role_include_0 = RoleInclude(list_0)
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    load_1 = role_include_0.load(var_0, var_1, var_2, var_3, var_4, var_5)
    print(load_1)

# Generated at 2022-06-25 05:45:06.437575
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_2 = 3
    list_1 = [int_2, int_2, int_2, int_2, int_2, int_2, int_2, int_2]
    str_0 = '__main__'
    str_1 = 'load'
    dict_0 = dict()
    dict_0['<string>'] = str_1
    dict_0['<><>'] = str_0
    dict_0['<>'] = str_0
    role_include_0 = RoleInclude(list_1)
    bin_0 = b'\xA0'
    dict_1 = dict()
    dict_1[b'\xA2'] = bin_0
    dict_1['<>\xA0'] = bin_0
    dict_1['<>'] = bin_0


# Generated at 2022-06-25 05:45:12.344770
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -2951
    list_0 = [int_0, int_0, int_0, int_0]
    role_include_0 = RoleInclude(list_0)
    role_include_1 = RoleInclude(int_0)
    role_include_0 = role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0)

    assert isinstance(role_include_0, RoleInclude)


# Generated at 2022-06-25 05:45:15.674003
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:45:18.098989
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def test():
        raise AnsibleParserError("Invalid role definition: %s" % data)

    test.exception = AnsibleParserError
    test.expected_result = "Invalid role definition: Invalid role definition: data"
    test()


# Generated at 2022-06-25 05:45:25.318916
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -2951
    list_0 = [int_0, int_0, int_0, int_0]
    role_include_0 = RoleInclude(list_0)
    role_include_1 = RoleInclude(int_0)
    role_include_0.load(int_0)
    role_include_0.load(int_0)
    role_include_1.load(int_0)

# Generated at 2022-06-25 05:45:34.954659
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:45:37.517108
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

if __name__ == '__main__':
    # Unit tests for class RoleInclude
    test_RoleInclude_load()

# Generated at 2022-06-25 05:45:45.012597
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -2951
    role_include_0 = RoleInclude(int_0)
    role_include_1 = RoleInclude(int_0)
    list_0 = [int_0, int_0, int_0, int_0]
    role_include_2 = RoleInclude(list_0)
    role_include_3 = RoleInclude(int_0)
    list_1 = [int_0, int_0, int_0, int_0]
    role_include_4 = RoleInclude(list_1)
    role_include_5 = RoleInclude(int_0)
    list_2 = [int_0, int_0, int_0, int_0]
    role_include_6 = RoleInclude(list_2)
    role_include_7 = RoleIn

# Generated at 2022-06-25 05:45:49.536267
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -2951
    role_include_0 = RoleInclude(int_0)
    var_0 = role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0)

# Generated at 2022-06-25 05:45:53.104241
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -2951
    str_0 = 'lS '
    role_include_0 = RoleInclude(int_0)
    role_include_0.load(int_0)
    role_include_1 = RoleInclude(int_0)
    role_include_1.load(str_0)


# Generated at 2022-06-25 05:45:57.144725
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -4739
    int_1 = -6290
    int_2 = -2795
    int_3 = 6154
    int_4 = -9229
    int_5 = -4001
    role_include_0 = RoleInclude(int_3, int_3, int_3, int_3, int_3)
    role_include_0.load(int_2, int_3, int_3, int_3, int_3, int_3)


# Generated at 2022-06-25 05:46:01.606347
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -7175
    role_include_0 = RoleInclude(int_0)
    var_0 = role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0)

# Method load_data of class RoleInclude

# Generated at 2022-06-25 05:46:11.819337
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = (17)
    play_0 = {('2', '3', '3'): (1)}
    current_role_path_0 = {('2', '3', '3'): (1)}
    parent_role_0 = {('2', '3', '3'): (1)}
    variable_manager_0 = {('2', '3', '3'): (1)}
    loader_0 = {('2', '3', '3'): (1)}
    collection_list_0 = {('2', '3', '3'): (1)}
    role_include_0 = RoleInclude(play_0, current_role_path_0, variable_manager_0, loader_0, collection_list_0)

# Generated at 2022-06-25 05:46:13.310097
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:46:14.106572
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()


# Generated at 2022-06-25 05:46:22.315582
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -26310
    int_1 = -55667
    role_include_0 = RoleInclude(int_0)
    str_0 = '0'
    str_1 = '1'
    str_2 = '2'
    str_3 = '3'
    str_4 = '4'
    dict_0 = {str_4: str_4, str_3: str_3, str_2: str_2, str_1: str_1, str_0: str_0}
    dict_1 = dict_0
    dict_2 = dict_0
    dict_3 = dict_0
    dict_4 = dict_0
    dict_5 = dict_0
    dict_6 = dict_0
    dict_7 = dict_0
    dict_8 = dict_0
   

# Generated at 2022-06-25 05:46:28.556747
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -2951

    role_include_0 = RoleInclude(int_0)
    var_0 = role_include_0.load(int_0)
    var_1 = role_include_0.load(int_0, int_0, int_0, int_0, int_0)
    var_2 = role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0)

# Generated at 2022-06-25 05:46:31.407377
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -2848
    role_include_0 = RoleInclude()
    role_include_0.load(int_0, int_0)
    # Need to implement test for this functionality


# Generated at 2022-06-25 05:46:41.808130
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -2951

# Generated at 2022-06-25 05:46:51.719407
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Method load of class RoleInclude
    """
    int_0 = -1704
    role_include_0 = RoleInclude(int_0)
    var_0 = role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0)
    role_include_1 = RoleInclude(int_0)
    var_0 = role_include_1.load(int_0, int_0, int_0, int_0, int_0, int_0)
    dict_0 = dict
    dict_1 = dict
    int_1 = 572
    var_0 = RoleInclude.load(dict_0, dict_1, int_1, int_1, int_1, int_1, int_1)



# Generated at 2022-06-25 05:46:56.388431
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -27619
    role_include_0 = RoleInclude(int_0)
    int_1 = -1678
    str_0 = 'abc,xyz'
    role_include_0 = role_include_0.load(str_0, int_1, int_1, int_1, int_1, int_1)

# Generated at 2022-06-25 05:46:58.328955
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()


# Generated at 2022-06-25 05:47:00.777964
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 7
    role_include_0 = RoleInclude()
    role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 05:47:06.663559
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -2951
    int_0 = -2951
    role_include_0 = RoleInclude(int_0)
    role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0)
    int_0 = -2951
    int_0 = -2951
    rule_0 = RoleInclude(int_0)
    var_0 = rule_0.load(int_0, int_0, int_0, int_0, int_0, int_0)
    int_0 = -2951
    int_0 = -2951
    rule_0 = RoleInclude(int_0)

# Generated at 2022-06-25 05:47:07.502820
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:47:15.407614
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 13
    role_include_0 = RoleInclude(int_0)
    #call method
    ret = role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0)
    # verify
    assert not ret
    # verify the following fields
    assert role_include_0.files == None
    assert role_include_0.handlers == None
    assert role_include_0.tasks == None
    assert role_include_0.pre_tasks == None
    assert role_include_0.post_tasks == None
    assert role_include_0._role_path == int_0
    assert role_include_0.default_vars == {}
    assert role_include_0.meta == {}
    assert role_include_0._

# Generated at 2022-06-25 05:47:17.041638
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()



# Generated at 2022-06-25 05:47:17.869525
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()



# Generated at 2022-06-25 05:47:27.712117
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    int_0 = -2951
    role_include_0 = RoleInclude(int_0)
    int_1 = -2951
    str_0 = "a"
    int_2 = -2951
    int_3 = -2951
    int_4 = -2951
    int_5 = -2951
    var_0 = role_include_0.load(int_0, int_1, str_0, int_2, int_3, int_4, int_5)


# Generated at 2022-06-25 05:47:31.008890
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -2951
    role_include_0 = RoleInclude(int_0)
    var_0 = role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0)

# Generated at 2022-06-25 05:47:38.530998
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Arrange
    # Variables
    int_0 = -2951
    int_1 = 539
    int_2 = -4444
    int_3 = -3859
    int_4 = -5385
    int_5 = -2796
    str_0 = "baz"
    str_1 = "bar"
    int_6 = -18
    role_include_0 = RoleInclude(int_6)
    # Object variables
    int_7 = 44
    int_8 = 44
    str_2 = "foo"
    int_9 = -3
    int_10 = -3
    str_3 = "foo"

    # Act
    # RoleInclude.load(int_0, int_0, int_0, int_0, int_0, int_0)
    # Role

# Generated at 2022-06-25 05:47:44.281106
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -2951
    role_include_0 = RoleInclude(int_0)
    var_0 = role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0)



# Generated at 2022-06-25 05:47:53.814884
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:47:59.293570
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 703
    role_include_0 = RoleInclude(int_0)
    var_0 = role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 05:48:03.340852
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Just passing an invalid value to load should throw a parser error
    int_0 = -2951
    role_include_0 = RoleInclude(int_0)
    result = role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0)
    assert type(result) == AnsibleParserError

# Generated at 2022-06-25 05:48:13.983301
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 77593
    role_0 = 9289
    role_1 = -26665
    role_include_0 = RoleInclude(role_0, role_0, role_0, role_0, role_0)
    role_include_1 = RoleInclude(role_0, role_0, role_0, role_0, role_0)
    var_0 = role_include_0.load(int_0, role_0, role_0, role_0, role_0, role_0)
    var_1 = role_include_1.load(role_include_0, role_0, role_0, role_0, role_0, role_0)

# Generated at 2022-06-25 05:48:19.157273
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    var_0 = "test_value"
    var_1 = "test_value2"
    int_0 = -748
    role_include_0 = RoleInclude(int_0)
    role_include_0.load(var_0, int_0, var_0, var_0, int_0, int_0)


if __name__ == '__main__':

    #
    # Unit tests
    #
    test_case_0()

    test_RoleInclude_load()

# Generated at 2022-06-25 05:48:22.626786
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude(int_0)
    assert role_include_0.load(int_0, int_0, int_0, int_0, int_0, int_0) == int_0


# Generated at 2022-06-25 05:48:30.495126
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()



# Generated at 2022-06-25 05:48:31.941707
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    ansible_host_0 = AnsibleHost()
    var_0 = role_include_0.load(role_include_0, role_include_0)

# Generated at 2022-06-25 05:48:35.233178
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    loader_0 = DataLoader()
    collection_list_0 = [ 'foo', 'bar' ]
    ansible_playbook_0 = AnsiblePlaybook()
    ansible_playbook_0._variable_manager = AnsibleVariableManager()
    data_0 = 'foo'
    var_0 = role_include_0.load(role_include_0, role_include_0, loader_0, collection_list_0, ansible_playbook_0, data_0)

# Generated at 2022-06-25 05:48:43.891622
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    if 1:
        arg_0 = ''
        arg_1 = ''
        arg_2 = ''
        arg_3 = ''
        arg_4 = ''
        arg_5 = ''
        var_0 = role_include_0.load(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
        assert True
    if 1:
        arg_0 = 'foo'
        arg_1 = ''
        arg_2 = ''
        arg_3 = ''
        arg_4 = ''
        arg_5 = ''
        var_0 = role_include_0.load(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
        assert True

# Generated at 2022-06-25 05:48:50.646549
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    data = "role_name"
    play = "play_obj"
    current_role_path = "current_role_path_value"
    parent_role = "parent_role_value"
    variable_manager = "variable_manager_value"
    loader = "loader_value"
    collection_list = "collection_list_value"
    # Call method load of class RoleInclude
    # Nothing happens
    role_include.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

# Generated at 2022-06-25 05:48:51.550313
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:48:53.221053
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)


# Generated at 2022-06-25 05:48:56.871205
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    role_include_0 = RoleInclude()

    # Verify the expected exception was raised
    raised = False
    try:
        test_case_0()
    except:
        raised = True
    assert raised




# Generated at 2022-06-25 05:49:03.396520
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("Test RoleInclude.load...")
    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        print("Test case 0 failed: %s" %(e))
    print("Test RoleInclude.load done successfully!")


if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-25 05:49:07.637684
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.load(role_include_0, role_include_0)
    assert role_include_0 == role_include_0


# Generated at 2022-06-25 05:49:21.980392
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

    # variable_manager
    variable_manager = 'variable_manager'

    # loader
    loader = 'loader'

    # current_role_path
    current_role_path = 'current_role_path'

    # play
    play = 'play'

    # data
    data = 'data'

    # parent_role
    parent_role = 'parent_role'

    # collection_list
    collection_list = 'collection_list'
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    var_0.__class__
    assert True



# Generated at 2022-06-25 05:49:23.985601
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    var_1 = role_include_1.load(role_include_1, role_include_1)
    #assert var_1 == ?


# Generated at 2022-06-25 05:49:28.928845
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    var_0 = role_include_1.load(role_include_1, role_include_1)
    del var_0
    var_0 = role_include_1.load(role_include_1, role_include_1)
    del var_0
    var_0 = role_include_1.load(role_include_1, role_include_1)
    del var_0

# Generated at 2022-06-25 05:49:39.956673
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = '{"name": "geerlingguy.apache", "scenario": "apache", "version": "1.2.3", "src": "geerlingguy.apache", "collections": [{"name": "apache", "version_requirement": ">=1.0.0,<2.0.0"}]}'
    play = '{"hosts": "localhost", "tasks": []}'
    current_role_path = '/Users/asmo/projects/ansible/test/sanity/roles/local-role-included/tasks'
    parent_role = 'parent_role'
    variable_manager = 'variable_manager'
    loader = 'loader'
    collection_list = 'collection_list'

    role_include_1 = RoleInclude()
    var_0 = role_include_1.load

# Generated at 2022-06-25 05:49:42.349304
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    a = RoleInclude()
    assert a.load(a, a) is None

# Generated at 2022-06-25 05:49:43.271211
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-25 05:49:46.183572
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        raise AssertionError()

# Generated at 2022-06-25 05:49:53.764434
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:49:54.968195
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: implement it
    assert test_case_0() == 0

# Generated at 2022-06-25 05:49:57.967191
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.load(role_include_0, role_include_0)

# Generated at 2022-06-25 05:50:17.233989
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Get the temp folder
    current_dir = os.path.dirname(__file__)
    temp_dir = os.path.abspath(current_dir + "/../../temp")

    # Creating test role_include_0 with required fields
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)

# Generated at 2022-06-25 05:50:18.863207
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)

# Generated at 2022-06-25 05:50:28.010992
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:50:30.394637
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.load(role_include_0, role_include_0)

# Generated at 2022-06-25 05:50:33.109945
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    try:
        role_include_0.load(role_include_0, role_include_0)
    except Exception as err:
        assert type(err) == AnsibleParserError



# Generated at 2022-06-25 05:50:34.159834
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:50:40.883606
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Define a mock for the method RoleInclude.load_data in order to get the mock_data
    with patch.object(RoleInclude,
                      'load_data',
                      return_value=mock_data) as mock_method:

        # Call the method of the class RoleInclude that we want to test
        result = RoleInclude().load(data=mock_data)

        # Test the result of the method load



# Generated at 2022-06-25 05:50:44.250437
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:50:46.421573
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.load(role_include_0, role_include_0)


# Generated at 2022-06-25 05:50:51.158993
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    role_include_0 = RoleInclude()
    assert "AnsibleBaseYAMLObject" in repr(role_include_0.load(role_include_0, role_include_0))

# Generated at 2022-06-25 05:51:20.823275
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    param_role_include_0 = RoleInclude()
    param_role_include_1 = RoleInclude()
    param_role_include_2 = RoleInclude()
    role_include_0 = RoleInclude()
    role_include_0.load(param_role_include_0, param_role_include_1, param_role_include_2)

# Generated at 2022-06-25 05:51:26.641773
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_basedir_0 = '/var/folders/z7/q8q4dzrn3tqf4nyrrmh39jwf_vjv34/T/ansible_kzHWK9/ansible_module_set_fact/roles/test_role_0'
    var_0 = role_include_0.load(role_include_0, role_basedir_0)


# Generated at 2022-06-25 05:51:34.603291
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    current_role_path = 'role_path'
    parent_role = None
    loader = None
    variable_manager = None
    play = None
    collection_list = None

    # Success case
    # Checks if the method load of class role_include is called with all the required parameters
    def test_case_1():
        collection_list = ["abc.xyz", "abc.pqr"]
        role_include_options = ['name', 'become', 'become_user', 'become_method',
                                'tags', 'run_once', 'delegate_to', 'delegate_facts', 'env', 'register']
        role_include_1 = RoleInclude()

# Generated at 2022-06-25 05:51:39.708829
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    role_include_0 = role_include.load(role_include, role_include)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:51:41.877557
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    assert test_case_0() == None, "test_case_0"


if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-25 05:51:49.485682
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create mock instances for each parameter
    data = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    # Set up attribute values for test cases
    data = "this is a string"
    role_include_1 = RoleInclude()
    var_1 = role_include_1.load(data)
    print(var_1)

    data = {"dict" : "this is a dictionary"}
    var_2 = role_include_1.load(data)
    print(var_2)


# Generated at 2022-06-25 05:51:54.835902
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = {"test": "role-include"}
    ri = RoleInclude(role_include_0, ri)
    # Unit test for __repr__()
    assert repr(ri) == "RoleInclude"
    try:
        var_0 = role_include_0.load(role_include_0, role_include_0)
    except SystemExit:
        pass
    else:
        raise Exception("SystemExit expected")

# Generated at 2022-06-25 05:51:57.417493
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        test_case_0()
    except AnsibleParserError:
        pass
    except AnsibleError:
        pass
    except Exception as e:
        assert False, "Unhandled exception in unit test: %s" % e

# Generated at 2022-06-25 05:52:00.515776
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    # Call of method with invalid params
    with pytest.raises(AnsibleParserError):
        role_include_0.load(role_include_0, role_include_0)


# Generated at 2022-06-25 05:52:11.000338
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.utils.addresses import parse_address
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.six import string_types

    ansible_loader = AnsibleLoader(None, None)

    test_loader = DataLoader()

    role_include_1 = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=test_loader)
    role_definition_1 = RoleDefinition(play=None, role_basedir=None, variable_manager=None, loader=test_loader)

# Generated at 2022-06-25 05:53:11.573527
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    param_0 = object()
    param_1 = object()
    param_2 = object()
    param_3 = object()
    param_4 = object()
    param_5 = object()

    # Call method load of class RoleInclude with args (param_0, param_1, param_2, param_3, param_4, param_5)
    # test_case_0()
    RoleInclude.load(param_0, param_1, param_2, param_3, param_4, param_5)

# Generated at 2022-06-25 05:53:15.383038
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Tests that an exception is raised when invalid arguments are passed.
    var_0 = RoleInclude()
    # This will fail to raise an exception because the only required argument is not met
    with pytest.raises(TypeError):
        var_0.load(role_include_0, role_include_0)


# Generated at 2022-06-25 05:53:17.706386
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.load_data(role_include_0, role_include_0, role_include_0)

# Generated at 2022-06-25 05:53:19.527706
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    role_include_0 = RoleInclude()
    role_include_0.load(role_include_0, role_include_0)



# Generated at 2022-06-25 05:53:26.663348
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    __ansible_module__ = os.path.basename(__file__).split('.')[0]
    __ansible_module__ = os.path.splitext(__ansible_module__)[0]
    __ansible_module__ = os.path.basename(__ansible_module__)
    __test_data__ = dict()
    __test_data__['test_case_0'] = dict()

# Generated at 2022-06-25 05:53:30.327508
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert not test_case_0()

# Generated at 2022-06-25 05:53:36.733463
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test function calls
    var_0 = test_case_0()

    # Set the variable var_0 of type class 'RoleInclude'
    var_1 = to_native({"task": "The first task.", "vars": {"blah": "foo"}})

    # Set the variable var_1 of type class 'Attribute'
    var_2 = to_native({"blah": "foo"})

    # Set the variable var_2 of type class 'Attribute'

# Generated at 2022-06-25 05:53:42.449852
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_basedir_0 = os.path.join(os.path.dirname(__file__), "test_role_include")
    name_0 = "jdoe.myrole"
    role_include_0 = RoleInclude(role_basedir=role_basedir_0)
    ansible_vault_password_0 = '12345'
    var_0 = role_include_0.load(name=name_0, ansible_vault_password=ansible_vault_password_0)


# Generated at 2022-06-25 05:53:49.161674
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()

    var_0 = role_include_0.load_data(role_include_0, variable_manager='', loader='')
    var_1 = role_include_1.load_data(role_include_1, variable_manager='', loader='')
    var_2 = role_include_2.load_data(role_include_2, variable_manager='', loader='')


# Generated at 2022-06-25 05:53:53.259670
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Load a role include
    ri = RoleInclude()
    ri.load({
        'name': 'web',
        'role': 'common'
    })
    # Verify the name of the role include
    assert ri.get_name() == 'web'
    # Verify the role from the role include
    assert ri.get_role() == 'common'