

# Generated at 2022-06-25 05:44:52.555206
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1539
    str_0 = '@[D!d\x7fvF8T'
    bytes_0 = b'Y\xabe\x0b'
    int_1 = 1
    str_1 = ''' \n\n    - 1\n    - 2\n    - 3\n    - 4\n'''
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(int_1, str_1, bytes_0)
    assert(var_0 is None)


# Generated at 2022-06-25 05:44:58.516845
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    str_0 = '1"X,0z0a##{HMl\x0c/hkN'
    bytes_0 = b'\x84\xd7\xfa\xc84\x87'
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(int_0, str_0, bytes_0)
    assert var_0 == None

# Generated at 2022-06-25 05:45:00.432385
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:45:04.358993
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    str_0 = '1"X,0z0a##{HMl\x0c/hkN'
    bytes_0 = b'\x84\xd7\xfa\xc84\x87'

    assert RoleInclude.load(int_0, str_0, bytes_0) == None


# Generated at 2022-06-25 05:45:14.622656
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -0x756f0d13
    str_0 = '\x12\x10.\x0fJ\x19\x97\xfd\x03\xb5^\xac%9'
    bytes_0 = b'H\xcd\x05\xc3\x13\n\xf6\xa9\xde\xd5\xec\xfe'
    role_include_0 = RoleInclude()
    str_1 = 'X]o"\x8d\xaa\xcb\x06\xcc\xcdeO1\x04]\x7f\xda\xb8'

# Generated at 2022-06-25 05:45:23.232800
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    str_0 = '1"X,0z0a##{HMl\x0c/hkN'
    bytes_0 = b'\x84\xd7\xfa\xc84\x87'
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(int_0, str_0, bytes_0)
    var_1 = role_include_0.get_role_path()
    var_2 = role_include_0.load(int_0, str_0, bytes_0)
    var_3 = role_include_0.get_role_path()
    str_1 = '1"X,0z0a##{HMl\x0c/hkN'

# Generated at 2022-06-25 05:45:27.268852
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 6786
    str_0 = 'Io0l#}b\x1b\x0b'
    bytes_0 = b'Y\x1cg'
    role_include_0 = RoleInclude()
    var_1 = role_include_0.load(int_0, str_0, bytes_0)
    

# Generated at 2022-06-25 05:45:31.508431
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 2
    str_0 = ';@$+{oBJ`\r'
    str_1 = '_ua#m9'
    bytes_0 = b'\xd7\x87\x98\x19\xb9N\x1a\xf9'
    role_include_0 = RoleInclude()
    role_0 = role_include_0.load(int_0, str_0, str_1, bytes_0)
    assert role_0
    assert isinstance(role_0,  RoleInclude)

if __name__ == '__main__':
    test_RoleInclude_load()
    test_case_0()

# Generated at 2022-06-25 05:45:38.310754
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    str_0 = '1"X,0z0a##{HMl\x0c/hkN'
    bytes_0 = b'\x84\xd7\xfa\xc84\x87'
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(int_0, str_0, bytes_0)

# Generated at 2022-06-25 05:45:43.768951
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    str_0 = '1"X,0z0a##{HMl\x0c/hkN'
    bytes_0 = b'\x84\xd7\xfa\xc84\x87'
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(int_0, str_0, bytes_0)

# Generated at 2022-06-25 05:45:46.392600
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    test_case_0()

# Generated at 2022-06-25 05:45:50.814115
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = -7103
    str_0 = 'rO)Y\r#'
    bytes_0 = b'\xb9%\xc3\x8b\xdd\x88'
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(int_0, str_0, bytes_0)

# Generated at 2022-06-25 05:45:55.682858
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    str_0 = '1"X,0z0a##{HMl\x0c/hkN'
    bytes_0 = b'\x84\xd7\xfa\xc84\x87'
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(int_0, str_0, bytes_0)


# Generated at 2022-06-25 05:46:01.649026
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    str_0 = '1"X,0z0a##{HMl\x0c/hkN'
    bytes_0 = b'\x84\xd7\xfa\xc84\x87'
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(int_0, str_0, bytes_0)


# Generated at 2022-06-25 05:46:03.461213
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 3159
    str_0 = '1"X,0z0a##{HMl\x0c/hkN'
    bool_0 = True 
    role_include_0 = RoleInclude()
    role_include_0.load(int_0, str_0, bool_0)

# Generated at 2022-06-25 05:46:05.832004
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    role_include_0 = RoleInclude()
    str_0 = role_include_0.load(int_0)


# Generated at 2022-06-25 05:46:08.471245
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        RoleInclude_load_0()
    except Exception as exception:
        print('\n')
        print(str(exception))


# Generated at 2022-06-25 05:46:12.576935
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 15905
    str_0 = 'I6#&'
    bytes_0 = b'4\xab\xfdf\xc7'
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(int_0, str_0, bytes_0)

# Generated at 2022-06-25 05:46:16.492235
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    str_0 = '1"X,0z0a##{HMl\x0c/hkN'
    bytes_0 = b'\x84\xd7\xfa\xc84\x87'
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(int_0, str_0, bytes_0)


# Generated at 2022-06-25 05:46:24.448773
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 47102
    str_0 = '^:F]jZ9\x0b?\x1b\x1a4t\x7f3d\x0c@\x14SX\x1a\x1e1f\x010\x07'

# Generated at 2022-06-25 05:46:30.584864
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    role_include_0 = RoleInclude()
    bool_0 = True
    var_0 = role_include_0.load(int_0, bool_0)



# Generated at 2022-06-25 05:46:33.609500
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:46:40.340770
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    role_include_0 = RoleInclude()
    bool_0 = True
    role_definition_0 = role_include_0.load(int_0, bool_0)
    assert isinstance(role_definition_0, RoleDefinition)
    assert role_definition_0.private is False


# Generated at 2022-06-25 05:46:42.592613
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()


if __name__ == '__main__':
    import unittest2 as unittest
    unittest.main()

# Generated at 2022-06-25 05:46:49.075822
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    role_include_0 = RoleInclude()
    bool_0 = True
    try:
        var_0 = role_include_0.load(int_0, bool_0)
    except Exception as error:
        print("Error: %s" % error)
        return False
    return True

test_cases = [
    (test_case_0),
]

test_set = {
    "RoleInclude": {
        "test_cases": test_cases,
    }
}

# Generated at 2022-06-25 05:46:50.331526
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:46:59.455715
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert_1 = 1583
    assert_0 = True
    assert_2 = False
    assert_3 = -1379505502
    assert_4 = -2
    role_include_1 = RoleInclude()
    role_include_1.load(assert_1, assert_0)
    assert_5 = []
    assert_6 = "test_name"
    role_include_1.load(assert_5, assert_6)
    assert_7 = {'test':'value'}
    assert_8 = "test_name"
    role_include_1.load(assert_7, assert_8)
    assert_9 = -1228
    assert_10 = "test_name"
    role_include_1.load(assert_9, assert_10)
    assert_11 = 'test_name'

# Generated at 2022-06-25 05:47:02.093880
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 1583
    role_include_0 = RoleInclude()
    bool_0 = False
    var_0 = role_include_0.load(int_0, bool_0)
    obj = role_include_0
    str_0 = "asd"
    bool_1 = False
    var_1 = obj.load(str_0, bool_1)
    str_1 = "@@"
    bool_2 = False
    var_2 = obj.load(str_1, bool_2)

    #assert var_0 == var_2

# Generated at 2022-06-25 05:47:04.083619
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        test_case_0()
    except Exception as exc:
        print(exc)

if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-25 05:47:12.163921
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    string_0 = "ansible.modules.my_test.my_test"
    string_1 = "file:../../test/integration/fake_collections/ansible_namespace.test_fake/tasks/main.yml"
    string_2 = ""
    string_3 = "test_fake"
    dict_0 = {string_1:{string_2:string_3}}
    bool_0 = True
    var_0 = role_include_0.load(dict_0, bool_0)

# Generated at 2022-06-25 05:47:16.976248
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    float_0 = -1370.524
    var_0 = role_include_0.load(role_include_0, float_0)

# Generated at 2022-06-25 05:47:23.365336
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print('Testing RoleInclude.load()')
    test_cases = [
        {   "input": {
            "play": "play",
            "role_basedir": "role_basedir",
            "variable_manager": "variable_manager",
            "loader": "loader"},
            "output": {
                "fail": False,
                "assert": "",
                "expected": ""
            }
        },
        {   "input": {
                "play": "play",
                "role_basedir": "role_basedir",
                "variable_manager": "variable_manager",
                "loader": "loader"},
            "output": {
                "fail": False,
                "assert": "",
                "expected": ""
            }
        }
    ]


# Generated at 2022-06-25 05:47:32.487822
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:47:35.815408
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    assert role_include_0


# Generated at 2022-06-25 05:47:40.215974
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Setup
    role_include_0 = RoleInclude()
    float_0 = -1370.524
    var_0 = role_include_0.load(role_include_0, float_0)

    # Verification
    assert var_0 == None, "unit test failed"

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 05:47:43.525406
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    inp = 1
    role_include_0 = RoleInclude()
    float_0 = -1370.524
    str_0 = 'AnsibleError'

    # Call load() with correct arguments
    try:
        role_include_0.load(inp, float_0)
    except Exception as e:
        assert type(e).__name__ == str_0


# Generated at 2022-06-25 05:47:44.293621
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()

# Generated at 2022-06-25 05:47:52.464574
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # BEGIN testcase_0
    role_include_0 = RoleInclude()
    float_0 = -1370.524
    test_case_0_actual = role_include_0.load(role_include_0, float_0)
    it_0 = role_include_0.variables
    it_1 = it_0.__iter__()
    it_2 = it_1.__next__()
    test_case_0_expected = it_2
    assert (test_case_0_expected == test_case_0_actual)
    # END testcase_0


# BEGIN testcase_1_setup

# Generated at 2022-06-25 05:47:56.252397
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    float_0 = -1370.524
    var_0 = role_include_0.load(role_include_0, float_0)

# Generated at 2022-06-25 05:47:57.838145
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    float_0 = -1370.524
    var_0 = role_include_0.load(role_include_0, float_0)

# Generated at 2022-06-25 05:48:06.637319
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    float_0 = 743.918
    assert role_include_0.load(float_0, role_include_0) is None



# Generated at 2022-06-25 05:48:14.146369
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    str_0 = 'n'
    bool_0 = bool(str_0)
    float_0 = -1370.524
    role_include_0.load(str_0, float_0)
    role_include_0.load(bool_0, float_0)
    role_include_0.load(float_0, float_0)


# Generated at 2022-06-25 05:48:15.512519
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-25 05:48:17.876676
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    roleinclude = RoleInclude()
    roleinclude.load()


# Generated at 2022-06-25 05:48:27.665019
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test case to check if method load is working as expected
    try:
        test_case_0()
    except:
        print("Test case failed")

# class RoleInclude :
#     def __init__(self, role_name, role_path=None, role_vars=None, role_basedir=None, role_tasks=None, role_handlers=None, role_meta=None, role_default_vars=None, role_actions=None,):
#         self._role_name = str(role_name)
#         self._role_path = role_path
#         self._role_vars = role_vars or []
#         self._role_basedir = role_basedir
#         self._role_tasks = role_tasks
#         self._role_handlers = role_hand

# Generated at 2022-06-25 05:48:37.548597
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    dict_0 = dict()
    dict_0['an_integer'] = 1
    dict_0['a_float'] = 2.0
    dict_0['a_string'] = '3'
    dict_0['a_unicode_string'] = u'4'
    dict_0['a_list'] = ['5', '6']
    dict_0['a_dict'] = dict(seven=7, eight=8)
    dict_0['a_bool'] = True
    dict_0['a_none'] = None
    dict_0['a_bytes'] = b'\x08'

# Generated at 2022-06-25 05:48:40.217956
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    float_0 = -1550.86
    list_0 = ['', '/c', 'b', 5, float_0, float_0, float_0]
    str_0 = './test/ansible_collections/ansible/builtin/tmp%s' % (str('E'))
    var_0 = role_include_0.load(list_0, str_0)
    assert(var_0 is None)


# Generated at 2022-06-25 05:48:46.193833
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    dict_0 = dict(
        a=5,
        b=6
    )
    var_0 = role_include_0.load(dict_0, role_include_0)
    assert var_0 == dict_0

# Generated at 2022-06-25 05:48:49.250490
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Load (enum)
    role_include = RoleInclude()
    float = -8.91
    var = role_include.load(role_include, float)

if __name__ == '__main__':
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:48:55.036975
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: update for actual data
    data = dict()
    play = dict()
    current_role_path = dict()
    parent_role = dict()
    variable_manager = dict()
    loader = dict()
    collection_list = dict()

    #Setup test subject
    role_include_0 = RoleInclude()

    # Execute test case
    var_0 = role_include_0.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert var_0 == None

# Generated at 2022-06-25 05:49:05.180925
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #Case 1:
    #role_include_0 = RoleInclude()
    role_include_0 = RoleInclude()
    float_0 = -1370.524
    with pytest.raises(AnsibleError) as excinfo:
        role_include_0.load(role_include_0, float_0)
    assert excinfo.value.message == 'You must specify a role name'


# Generated at 2022-06-25 05:49:09.581135
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    float_0 = -1370.524
    def role_inc(self, play, data, current_role_path=None, parent_role=None, variable_manager=None, loader=None):
        return self.load_data(data, variable_manager=variable_manager, loader=loader)
    role_inc.__name__ = 'role_inc'
    role_inc.__dict__ = role_include_0.__dict__
    role_inc(role_include_0, float_0)

# Generated at 2022-06-25 05:49:19.578014
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # This wouldn't be valid for a stack trace (it's invalid YAML), but we verify at least this works
    play = None
    current_role_path = '/home/vagrant/ansible/ansible/playbooks/roles/os_keystone_user_and_group'
    parent_role = None
    variable_manager = 'ansible'
    loader = None
    collection_list = 'ansible'
    role_include_0 = RoleInclude()
    float_0 = -1370.524
    data = '{{foo}}'
    try:
        var_0 = role_include_0.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 05:49:21.100095
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    float_0 = -1370.524
    var_0 = role_include_0.load(role_include_0, float_0)


# Generated at 2022-06-25 05:49:28.467331
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()

    try:
        role_include_0.load(role_include_0)
    except TypeError:
        assert False

    try:
        role_include_0.load(role_include_0)
    except Exception as e:
        assert False

    try:
        role_include_0.load(role_include_0)
    except Exception as e:
        assert False

# Generated at 2022-06-25 05:49:39.615525
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_0 = 0
    str_0 = 'string'
    int_1 = 0
    path_0 = 'path'
    var_0 = RoleInclude.load(str_0, path_0, path_0, int_0, int_1, str_0)
    var_1 = RoleInclude.load(str_0, path_0, path_0, int_0, int_1, str_0)
    var_2 = RoleInclude.load(str_0, path_0, path_0, int_0, int_1, str_0)
    var_3 = RoleInclude.load(str_0, path_0, path_0, int_0, int_1, str_0)

# Generated at 2022-06-25 05:49:42.691425
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False

# Generated at 2022-06-25 05:49:43.716669
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()



# Generated at 2022-06-25 05:49:47.812257
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    float_1 = -1370.524
    var_1 = role_include_1.load(role_include_1, float_1)

# Generated at 2022-06-25 05:49:48.935614
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:49:54.401323
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_1()



# Generated at 2022-06-25 05:49:59.288600
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case = [
        ('role_include_0', 'float_0', 'var_0')
    ]

    def test_inner(role_include, float, var):
        role_include = RoleInclude()
        float = -1370.524
        var = role_include.load(role_include, float)




# Generated at 2022-06-25 05:50:07.134843
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    float_0 = 4.503623
    try:
        role_include_0.load(float_0)
        print('test_RoleInclude_load passed')
    except:
        print('test_RoleInclude_load failed')


# Generated at 2022-06-25 05:50:11.382335
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    float_0 = -1370.524
    var_0 = role_include_0.load(role_include_0, float_0)



# Generated at 2022-06-25 05:50:15.139239
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    float_0 = -1272.49
    var_0 = role_include_0.load(role_include_0, float_0)
    assert var_0 is None


# Generated at 2022-06-25 05:50:23.167980
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    tuple_0 = (2, 3)
    str_0 = "actionable"
    dict_0 = {"key" : "value", "name" : "foo"}
    int_0 = -8
    tuple_1 = (int_0, dict_0)
    list_0 = [tuple_1, dict_0]
    tuple_2 = (2, 3)
    dict_1 = {"key" : "value", "name" : "foo"}
    int_1 = -8
    tuple_3 = (int_1, dict_1)
    list_1 = [tuple_3, dict_1]
    dict_2 = dict()

# Generated at 2022-06-25 05:50:23.956907
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:50:34.919618
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    role_include_0 = RoleInclude()
    float_0 = -1370.524
    with pytest.raises(AnsibleError) as excinfo:
        var_0 = role_include_0.load(role_include_0, float_0)
    excinfo.match("Invalid old style role requirement: -1370.524")
    role_include_0 = RoleInclude()
    float_1 = -1472.508
    with pytest.raises(AnsibleParserError) as excinfo:
        var_1 = role_include_0.load(role_include_0, float_1)
    excinfo.match("Invalid role definition: -1472.508")

# Return a list of roles from the directory

# Generated at 2022-06-25 05:50:44.556336
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # define local variable data
    data = []

    # define local variable play
    play = ...

    # define local variable current_role_path
    current_role_path = ...

    # define local variable parent_role
    parent_role = ...

    # define local variable variable_manager
    variable_manager = ...

    # define local variable loader
    loader = ...

    # define local variable collection_list
    collection_list = ...

    # create instance of class 'RoleInclude'
    ri = RoleInclude()

    # try call to load method of class 'RoleInclude'
    try:
        RoleInclude_load(ri, data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except Exception as exception:
        print(exception)
        assert False

# Unit

# Generated at 2022-06-25 05:50:51.975090
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    role_include_0 = RoleInclude(loader=AnsibleLoaderStub(), play=AnsiblePlayStub())
    role_include_1 = RoleRequirement.load(data=AnsibleBaseYAMLObject(), play=role_include_0, current_role_path=frozenset())
    assert isinstance(role_include_1, RoleRequirement)
    assert not hasattr(role_include_1, '_loader')

    role_include_0.loader = AnsibleLoaderStub()
    role_include_1 = RoleInclude.load(data=AnsibleBaseYAMLObject(), play=role_include_0, current_role_path='/var/lib/awx/tmp')
    assert isinstance(role_include_1, RoleInclude)