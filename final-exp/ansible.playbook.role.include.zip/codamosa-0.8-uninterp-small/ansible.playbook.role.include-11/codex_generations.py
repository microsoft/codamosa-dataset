

# Generated at 2022-06-25 05:44:48.168471
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = dict()
    dict_0['name'] = 'test role 0'
    dict_0['description'] = 'test description 0'
    role_definition_0 = RoleDefinition(dict_0)
    role_definition_0.load_data(dict_0)

    # Test 1
    dict_1 = dict()
    dict_1['name'] = 'test role 1'
    dict_1['description'] = 'test description 1'
    role_definition_1 = RoleDefinition(dict_1)
    role_definition_1.load_data(dict_1)
    role_definition_2 = role_definition_1
    role_definition_1 = role_definition_0

    assert role_definition_0 == role_definition_2
    assert role_definition_1 != role_definition_2
    assert role_definition_

# Generated at 2022-06-25 05:44:54.580808
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    valid_module_name = list(iteritems(dict()))
    valid_module_name_0 = valid_module_name
    data = valid_module_name_0
    role_include_0 = RoleInclude()
    role_include_1 = role_include_0.load(data)
    role_include_1.task_blocks
    role_include_1.handlers
    role_include_1.tasks
    role_include_1.vars
    role_include_1.pre_tasks
    role_include_1.post_tasks
    role_include_1.role_path
    role_include_1.role_vars_files
    role_include_1.role_vars
    role_include_1.role_defs
    role_include_1.role_meta
    role

# Generated at 2022-06-25 05:45:04.752925
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b"\xe2\x1e\x1c\x14\xa9\x16\x8d\xf8\xb6\x1b\x19\x0f\xa2\x86\x07\x82"
    bytes_1 = b"\x0f\xf8\x90\xf9\x9f\xcf\xb2\xb2\x84\x06\x97\x19"
    bytes_2 = b"\x04\x0c\x97\x1d\x99\x14\x8e\xcc\xbc\x9b\x12\x1f\x91\x86\x18\x8b"

# Generated at 2022-06-25 05:45:14.991570
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Loads a role definition from a string or dictionary. This method is intended
    # to be used primarily by an ansible.playbook.Play object, and should not
    # be used in general by other code.

    role_include_0 = RoleInclude()

    data_0 = 'foo'
    play_0 = None
    current_role_path_0 = 'foo'
    parent_role_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    role_include_0.load_data(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)

    # Asserts that the file was read.
    # logging.debug(str(sys.stder

# Generated at 2022-06-25 05:45:23.566252
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xfc\xc1\x86\n\xf3\xcf\xcc\x12\xd8\x9d\xd0\x84\xf1\x8e'
    bytes_1 = b'\x9f'
    bytes_2 = b'\xcf\xa0\xac\x1f'
    bytes_3 = b'\xd9\x9f'

# Generated at 2022-06-25 05:45:29.890877
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xad\xbd\x8f\xd1\xef\x94\x96\x8e\xf3\xef\x16\x15\x1e\xde\xcd\x12\x06\x15\x1e\xe5\xe2\x12\x8f\xc2\xbd\x9b\x08\xce'
    bytes_1 = b"\x96xEm\xc6\xe7\xd6\xb3D'\x84\x89\xf2\xa6\xd3\x91\x8b\x1f"
    dict_0 = {bytes_0: bytes_1, bytes_1: bytes_0}

# Generated at 2022-06-25 05:45:38.008644
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    loader_0 = object()
    variable_manager_0 = object()
    bytes_0 = b'role_b'
    dict_0 = {'roles': [bytes_0]}
    play_0 = object()
    role_include_0 = RoleInclude.load(dict_0, play_0, variable_manager=variable_manager_0, loader=loader_0)

if __name__ == '__main__':
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:45:45.309271
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play

    role_include_0 = RoleInclude(dict())

    from ansible.module_utils.six import string_types

    role_include_1 = RoleInclude(string_types)
    role_include_2 = RoleInclude(string_types)

    from ansible.playbook.attribute import FieldAttribute

    field_attribute_0 = FieldAttribute(dict())

    from ansible.module_utils.six import string_types
    str_0 = '--separate-git-dir=%s'
    role_include_3 = RoleInclude(string_types)

    assert isinstance(role_include_0, RoleInclude)
    assert isinstance(role_include_1, RoleInclude)
    assert isinstance(role_include_2, RoleInclude)

# Generated at 2022-06-25 05:45:54.048192
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play_0 = object()
    role_include_0 = RoleInclude(play_0)
    bytes_0 = b'\x00\x02\x00\x00\x00\x00\x00\x00'
    bytes_1 = b'\x00\x02\x00\x00\x00\x00\x00\x00'
    str_0 = '--separate-git-dir=%s'
    role_include_1 = RoleInclude.load(bytes_1, play_0)
    role_include_0 = RoleInclude.load(bytes_0, play_0)
    role_include_0 = RoleInclude.load(None, play_0)
    role_include_0 = RoleInclude.load(None, play_0)

# Generated at 2022-06-25 05:46:04.773598
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xb6\xa5\xeb\xd5\xf8\xb5\xd4\x1c\xaf\x8d4\xde\xad\x95\xce#6\x8c\xcc\x9b\xee\x8b\xe0\x1f'
    int_0 = None
    str_0 = '#H\x0c)\xef'
    str_1 = '-\x18\xa8\x15\x9a'
    str_2 = '\xdc\xb2\x87\xbe\x1d\xbe\x89\xc6\x87\xd4\x8b\xfa\x0c\x8d\xf6'

# Generated at 2022-06-25 05:46:12.032722
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = ''
    play = None
    current_role_path = ''
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)


# Generated at 2022-06-25 05:46:16.545977
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    data = None
    bytes_0 = b"\x96xEm\xc6\xe7\xd6\xb3D'\x84\x89\xf2\xa6\xd3\x91\x8b\x1f"
    bytes_1 = None
    dict_0 = {bytes_0: bytes_1, bytes_1: bytes_0}
    data = dict_0
    role_include_0 = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)


# Generated at 2022-06-25 05:46:20.811544
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {"a": "b"}
    play = None
    current_role_path = "azad"
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    role_include_2 = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

# Generated at 2022-06-25 05:46:30.624125
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b"\x96xEm\xc6\xe7\xd6\xb3D'\x84\x89\xf2\xa6\xd3\x91\x8b\x1f"
    bytes_1 = None
    dict_0 = {bytes_0: bytes_1, bytes_1: bytes_0}
    role_include_0 = RoleInclude(dict_0)
    str_0 = '--separate-git-dir=%s'
    role_include_1 = RoleInclude(str_0)
    bytes_2 = None
    str_1 = '--separate-git-dir=%s'
    role_include_2 = RoleInclude.load(str_1, role_include_0, role_include_1)


# Generated at 2022-06-25 05:46:37.443468
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        role_include_0 = RoleInclude()
        data = ''
        play = ''
        current_role_path = ''
        variable_manager = ''
        loader = ''
        collection_list = 'f'
        role_include_0.load(data, play, current_role_path, variable_manager, loader, collection_list)
    except Exception as exception_0:
        assert(False)


# Generated at 2022-06-25 05:46:45.812066
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xd5\x1a\x9e\x0b\x9f\xbd\x18\x96\x856\xf1\xa9\x93\x9f\xf3\x06'
    bytes_1 = b"\x96xEm\xc6\xe7\xd6\xb3D'\x84\x89\xf2\xa6\xd3\x91\x8b\x1f"
    dict_0 = {bytes_0: bytes_1, bytes_1: bytes_0}
    role_include_0 = RoleInclude(dict_0)
    role_include_1 = RoleInclude(dict_0)
    str_0 = '--separate-git-dir=%s'

# Generated at 2022-06-25 05:46:52.007326
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = '''
- include_role:
    name: foo
    tasks_from: bar
'''
    path = '/tmp/test-file'
    with open(path, 'w') as f:
        f.write(data)
    with open(path) as f:
        results = RoleInclude.load(f.read(), path, current_role_path='/tmp', variable_manager=None, loader=None, collection_list=None)
    assert len(results) == 1
    assert results[0].get_name() == 'foo'
    assert results[0].get_role_path() == '/tmp/foo'
    assert results[0].get_tasks() == 'bar'
    assert results[0].get_files() is None
    assert results[0].get_vars() is None
    assert results

# Generated at 2022-06-25 05:47:00.631315
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Setup test objects
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    def load_mock(data):
        assert isinstance(data, str)

    data_0 = 'foo'
    role_include_0 = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    role_include_0.load_data = load_mock
    result = role_include_0.load(data=data_0, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-25 05:47:10.919407
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xe0d\xf1\xfe\xde\xee\xda\x96\xb7'
    bytes_1 = b'\xc9\x9c:\x1f\x86\x8d\x1a\xb3\xe6'
    dict_0 = {bytes_0: bytes_1, bytes_1: bytes_0}
    role_include_0 = RoleInclude(dict_0)
    str_0 = '!@4'
    dict_1 = {str_0: bytes_1}
    dict_2 = {str_0: dict_1}
    dict_3 = {str_0: dict_1}
    dict_4 = {str_0: dict_2, bytes_0: dict_3}
    role_include_1 = RoleInclude

# Generated at 2022-06-25 05:47:17.052218
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Verify test data is correct
    assert test_RoleInclude_load_data() == ['A', 'BC', 'DEF']

    # Verify that ANSIBLE_DISPLAY_SKIPPED_HOSTS=no does not cause iterator to raise StopIteration exception
    assert test_RoleInclude_load_data() == ['A', 'BC', 'DEF']
    assert test_RoleInclude_load_data() == ['A', 'BC', 'DEF']
    assert test_RoleInclude_load_data() == ['A', 'BC', 'DEF']
    assert test_RoleInclude_load_data() == ['A', 'BC', 'DEF']


# Generated at 2022-06-25 05:47:24.241441
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # used for testing directly
    from ansible.playbook import Play
    from ansible.vars import VariableManager

    # TODO: implement test_RoleInclude_load

    # sanity check
    assert True

# Generated at 2022-06-25 05:47:31.048473
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b"\x96xEm\xc6\xe7\xd6\xb3D'\x84\x89\xf2\xa6\xd3\x91\x8b\x1f"
    bytes_1 = None
    dict_0 = {bytes_0: bytes_1, bytes_1: bytes_0}
    role_include_0 = RoleInclude(dict_0)
    str_0 = '--separate-git-dir=%s'
    role_include_1 = RoleInclude(str_0)


# Generated at 2022-06-25 05:47:38.568614
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    dict_0 = {}
    dict_1 = dict_0
    dict_2 = dict_1
    dict_3 = {}
    dict_4 = dict_3
    dict_5 = dict_4
    dict_6 = dict_5
    dict_7 = dict_6
    dict_8 = dict_7
    dict_9 = dict_8
    dict_10 = dict_9
    dict_11 = dict_10
    dict_12 = dict_11
    dict_13 = {}
    dict_14 = dict_13
    dict_15 = dict_14
    dict_16 = dict_15
    dict_17 = {}
    dict_18 = dict_17
    dict_19 = dict_18
    dict_20 = dict_19
    dict_21 = {}
    dict_22 = dict_21
    dict

# Generated at 2022-06-25 05:47:45.784505
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Setup test data
    dict_0 = {'foo': 'bar'}
    dict_1 = {}
    dict_2 = {'foo': 'bar'}
    dict_3 = {'foo': 'bar'}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24

# Generated at 2022-06-25 05:47:54.073942
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    
    # Case 1
    #
    # Input:
    # dict_0 = {'test': None, None: 'test'}
    # bytes_0 = b"\x96xEm\xc6\xe7\xd6\xb3D'\x84\x89\xf2\xa6\xd3\x91\x8b\x1f"
    # bytes_1 = None
    # dict_0 = {bytes_0: bytes_1, bytes_1: bytes_0}
    #
    # Expected Output:
    # RoleInclude(dict_0)
    #
    dict_0 = {'test': None, None: 'test'}

# Generated at 2022-06-25 05:48:04.925053
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    for _ in [0]:
        role_basedir = ' ./.git/modules/ansible/roles/role_name'
        variable_manager = 1
        assert_raises(AnsibleParserError, RoleInclude.load, None,None, role_basedir, None, variable_manager)
        assert_raises(AnsibleError, RoleInclude.load, 1, None, role_basedir, None, variable_manager)
        assert_raises(AnsibleParserError, RoleInclude.load, role_basedir, None, role_basedir, None, variable_manager)
    for _ in [1]:
        role_basedir = '.'
        variable_manager = 2

# Generated at 2022-06-25 05:48:13.863147
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b"\x96xEm\xc6\xe7\xd6\xb3D'\x84\x89\xf2\xa6\xd3\x91\x8b\x1f"
    bytes_1 = None
    dict_0 = {bytes_0: bytes_1, bytes_1: bytes_0}
    role_include_0 = RoleInclude(dict_0)
    str_0 = '--separate-git-dir=%s'
    role_include_1 = RoleInclude(str_0)

# Generated at 2022-06-25 05:48:25.478981
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    interest_0 = {'path': 'bar', 'name': 'foo'}
    bytes_0 = b"\x96xEm\xc6\xe7\xd6\xb3D'\x84\x89\xf2\xa6\xd3\x91\x8b\x1f"
    bytes_1 = None
    dict_0 = {bytes_0: bytes_1, bytes_1: bytes_0}
    role_include_0 = RoleInclude(dict_0)
    str_0 = '--separate-git-dir=%s'
    role_include_1 = RoleInclude(str_0)
    role_include_2 = role_include_0.load(interest_0, None, 'bar', loader=role_include_1)
    str_1 = 'm4'
    str

# Generated at 2022-06-25 05:48:36.765937
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x96{\x82\r\xbd\x03\x1c\xde\x0f\x8eJ\x85\xaf\xcb\x8a\x1e\x9d\x18\x7f\x19\x8f\xa2\xc1\x86\x8a\x9b\x9bX\xcf\x8a\x81?\x0c'
    bytes_1 = None
    dict_1 = {bytes_0: bytes_1, bytes_1: bytes_0}
    role_include_0 = RoleInclude(dict_1)
    role_include_1 = role_include_0.load(bytes_0, bytes_1)
    assert role_include_1.loader == role_include_0.loader


# Generated at 2022-06-25 05:48:40.750078
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b"\x96xEm\xc6\xe7\xd6\xb3D'\x84\x89\xf2\xa6\xd3\x91\x8b\x1f"
    bytes_1 = None
    dict_0 = {bytes_0: bytes_1, bytes_1: bytes_0}
    role_include_0 = RoleInclude(dict_0)
    str_0 = '--separate-git-dir=%s'
    role_include_1 = RoleInclude(str_0)
    role_include_2 = RoleInclude(dict_0)
    str_1 = '--bare'
    role_include_3 = RoleInclude(str_1)
    str_2 = './'

# Generated at 2022-06-25 05:48:47.271949
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # FIXME: add tests for this method
    pass

# Generated at 2022-06-25 05:48:55.713276
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    def test_load_0():

        # setup
        float_0 = None
        role_include_0 = RoleInclude()
        var_0 = role_include_0.load(float_0, float_0)
        float_1 = float_0
        role_include_1 = RoleInclude()
        var_1 = role_include_1.load(float_1, float_1)
        float_2 = float_1
        role_include_2 = RoleInclude()
        var_2 = role_include_2.load(float_2, float_2)

        # assertion
        assert var_0 == var_1
        assert var_0 == var_2

    # setup
    float_0 = None
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load

# Generated at 2022-06-25 05:49:06.968277
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = None
    role_include_0 = RoleInclude()
    str_0 = role_include_0.load(float_0, float_0)
    assert type(str_0) is str
    str_1 = role_include_0.load(float_0, float_0)
    assert type(str_1) is str
    str_2 = role_include_0.load(float_0, float_0)
    assert type(str_2) is str
    str_3 = role_include_0.load(float_0, float_0)
    assert type(str_3) is str
    str_4 = role_include_0.load(float_0, float_0)
    assert type(str_4) is str

# Generated at 2022-06-25 05:49:18.096128
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = None
    role_include_0 = RoleInclude()
    str_0 = 'test_value'
    str_1 = 'test_value'
    str_2 = 'test_value'
    str_3 = 'test_value'
    str_4 = 'test_value'
    str_5 = 'test_value'
    str_6 = 'test_value'
    str_7 = 'test_value'
    str_8 = 'test_value'
    str_9 = 'test_value'
    str_10 = 'test_value'
    str_11 = 'test_value'
    str_12 = 'test_value'
    str_13 = 'test_value'
    str_14 = 'test_value'
    str_15 = 'test_value'
    str_16

# Generated at 2022-06-25 05:49:22.367108
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 =  None
    role_include_0 = RoleInclude()
    role_include_0.load(float_0, float_0)

# Generated at 2022-06-25 05:49:24.778970
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_2 = RoleInclude() # instantiate object of class RoleInclude
    float_0 = None
    var_0 = role_include_2.load(float_0, float_0) # load method of class RoleInclude


# Generated at 2022-06-25 05:49:27.284548
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    float_0 = None
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(float_0, float_0)

    return

# Generated at 2022-06-25 05:49:34.422084
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_1 = AnsibleBaseYAMLObject()
    var_2 = None
    var_3 = role_include_0.load(var_1, var_2)
    assert var_3 is None


# Generated at 2022-06-25 05:49:36.381354
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    float_0 = None
    role_include_0 = RoleInclude()
    role_include_0.load(float_0, float_0)

# Generated at 2022-06-25 05:49:38.900090
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0._load_attributes("foo bar baz")
    role_include_0.get_name()
    role_include_0.load(__file__, None)


if __name__ == '__main__':
    test_case_0()