

# Generated at 2022-06-25 05:44:48.258449
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    var_manager_0 = Attribute(bytes_0)
    role_basedir_0 = '_'
    play_0 = Attribute(var_manager_0)
    data_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude.load(data_0, play_0, role_basedir_0, var_manager_0)

# Generated at 2022-06-25 05:44:56.324682
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    str_0 = '\x1c+\xb3t\x8d\xf5`\xe5\xf0\x90\x15\x9e\xaf\xed\xfe\x89\xa5'
    int_0 = -1
    role_include_0 = RoleInclude(bytes_0)
    role_include_0.load(str_0, int_0, bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-25 05:45:06.465261
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude.load(bytes_0)
    role_include_0.get_path()
    role_include_0.get_name()
    role_include_0.get_role_path()
    role_include_0.get_collections_paths()
    role_include_0.get_role_params()
    role_include_0.get_tags()
    role_include_0.get_when()
    role_include_0.get_become()
    role_include_0.serialize()
    role_include_0.post_validate()
    role_include_0.get_main_file_name()
    role

# Generated at 2022-06-25 05:45:17.423186
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude(bytes_0)
    play_0 = None
    current_role_path_0 = None
    parent_role_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    data_0 = "\\xde\\xf7>\\xd0.\\x85\\x9br\\xd06\\xb0s"
    role_include_1 = RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)
    # Test for equality
    assert role_include_

# Generated at 2022-06-25 05:45:24.280431
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    #Params:
    #data: {}
    string_0 = 'passwd'
    role_include_0 = RoleInclude(bytes_0)
    role_include_0.load(string_0)

# Generated at 2022-06-25 05:45:33.844355
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b':|\xfb\xde\x06\xa5\xfa\xe5\x9f\x88\x13M\x8a\x0e\xac%\xe4\xe1\x8b.\xd4\x9a\x02@\xed\x03\xf1\x1e\x1c\x8b\xeb\xde\xa5\x81\x04\x88\xd5\xa0\xbb\x8b]\xd5\xc0\x0b\x8f\xf5\x05\x0c\x0e\x8a$\x06\x17\x1b\x8b\x05\x17\x1b\x8b\xeb\xde}'
    role_include_

# Generated at 2022-06-25 05:45:42.782103
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a mock object for class RoleDefinition, where the load method is defined.
    mock_RoleDefinition_class = MagicMock()
    mock_RoleDefinition_load = Mock()
    mock_RoleDefinition_class.load = mock_RoleDefinition_load  # Attach MagicMock object to mock object as attribute.
    mock_RoleDefinition_load.return_value = 'load_return_value'  # Set a return value for mock object 'mock_RoleDefinition_load'.
    mock_RoleDefinition_load.side_effect = AnsibleError('AnsibleError exception')  # Set the side effect when calling the mock method.

    mock_RoleInclude_class = RoleInclude
    mock_RoleInclude_load = Mock()
    mock_RoleInclude_class.load = mock_RoleInclude_load  # Attach MagicMock object to

# Generated at 2022-06-25 05:45:50.206947
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_passed = True

    # Test for valid parameter types
    try:
        bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
        role_include_0 = RoleInclude(bytes_0)
        test_passed = True
    except AnsibleError:
        test_passed = False

    if test_passed:
        print("Test passed")
    else:
        print("Test failed")


if __name__ == '__main__':
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:46:00.365169
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create the data object:
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'

# Generated at 2022-06-25 05:46:04.998764
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = bytearray(b'w\x8a\xe7\xdc\xae\xf6\x8dI\xea')
    str_0 = str()
    dict_0 = dict()
    role_include_0 = RoleInclude.load(dict_0, str_0, str_0, role_include_0)

# Generated at 2022-06-25 05:46:16.130379
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    int_0 = hash(bytes_0)
    dict_0 = dict()
    dict_0['name'] = int_0
    dict_1 = dict()
    dict_1[str('name')] = dict_0
    dict_2 = dict()
    dict_2[str('name')] = dict_1
    dict_2[str()] = dict_2
    dict_3 = dict()
    dict_3[str('name')] = dict_2
    dict_3[str()] = dict_3
    dict_3['name'] = 'name'
    dict_3['name'] = dict_3['name']
    dict_4 = dict()
    dict_

# Generated at 2022-06-25 05:46:21.125178
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:46:27.846725
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    bytes_1 = b'\xe2\x0b\x9c\xd9@\x11;\x82\x01\xf8'
    role_include_0 = RoleInclude(bytes_0)
    role_include_1 = role_include_0.load(bytes_0, bytes_1)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:46:31.490806
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test load
    """
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude.load('role_basedir', 'play', 'current_role_path', 'parent_role', 'variable_manager', 'loader')



# Generated at 2022-06-25 05:46:33.563138
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        RoleInclude.load('<isinstance(data, str)>')
    except Exception:
        pass
    else:
        raise Exception("Unexpected Exception")



# Generated at 2022-06-25 05:46:37.151328
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # assert False # TODO: implement your test here
    assert True # TODO: implement your test here


# Generated at 2022-06-25 05:46:45.568510
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    _data_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    play_1 = _data_0
    data_2 = _data_0
    _data_3 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    current_role_path_4 = _data_3
    parent_role_5 = bytes_0
    _data_6 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    variable_manager_7 = _data_6
    _data

# Generated at 2022-06-25 05:46:48.914313
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 0
    play = 0
    current_role_path = 0
    parent_role = 0
    variable_manager = 0
    loader = 0
    collection_list = 0
    role_include_0 = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)


# Generated at 2022-06-25 05:46:54.770060
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {'roles:': 'apache'}
    play = {}
    current_role_path = './roles'
    parent_role = './roles'
    variable_manager = []
    loader = {}
    collection_list = 'None'
    assert RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list) == 0

# Generated at 2022-06-25 05:47:02.290883
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:47:14.420048
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xec\xf5\x98\xcd\x9d\x8f\xce\r\xdf\xb0\xc5\x99\xe64\x10~'
    role_include_0 = RoleInclude(bytes_0)
    bytes_1 = b'\xec\xf5\x98\xcd\x9d\x8f\xce\r\xdf\xb0\xc5\x99\xe64\x10~'
    bytes_2 = b'\xb3\x96\x0b\t\x9b\xf1\x08k\xe8\x95\xc5\xba\xdc\x13\xf0\x0e\xea\xcf\xa4'
    role_include_1 = role_include_

# Generated at 2022-06-25 05:47:22.848092
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri_0 = RoleInclude()
    def test_case_0(self):
        data_0 = 'role_name: some_role'
        ri_1 = RoleInclude.load(data_0)
        assert (ri_1 == ri_0)
    def test_case_1(self):
        data_0 = ''
        ri_1 = RoleInclude.load(data_0)
        assert (ri_1 == ri_0)
    def test_case_2(self):
        data_0 = 'role_name: some_role,when: some_condition'
        ri_1 = RoleInclude.load(data_0)
        assert (ri_1 == ri_0)

# Generated at 2022-06-25 05:47:32.054012
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Setup a test environment.
    bytes_0 = b'\x9f\xa1\xa3\xf3\x8d\xd3\xed\x1d\x92\x94\xc2\x1b\x0b\t\x8a'
    role_include_0 = RoleInclude(bytes_0)
    dict_0 = dict()
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'
    dict_0['key'] = 'value'


# Generated at 2022-06-25 05:47:39.247227
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xa4A\xd4\xfc\x8d'

# Generated at 2022-06-25 05:47:43.221708
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    data_0 = {}
    play_0 = Play()
    current_role_path_0 = {}
    parent_role_0 = ParentRole()
    variable_manager_0 = PlayContext(loader=loader_0, templar=None, shared_loader_obj=None)
    loader_0 = None
    RoleInclude.load(data_0, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0)

# Generated at 2022-06-25 05:47:47.940433
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # test_case_0
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    assert_equal(RoleInclude(bytes_0), test_case_0())


# Generated at 2022-06-25 05:47:55.482665
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    current_role_path_0 = '\x03\x06\x9f\x8aD\xb5\xba\\\xab\xcf\x1f\xc7\x81\xa9\xe6\xb3\x13:\xce\x88\x8c\xbc\xe3'
    data_0 = None
    variable_manager_0 = None
    role_include_0 = RoleInclude.load(data_0, bytes_0, current_role_path_0, variable_manager_0)



# Generated at 2022-06-25 05:48:06.453824
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test role
    role_name = 'test_role'
    role_type = 'tasks'
    play_name = 'TestPlay'
    ri = RoleInclude()

    dict_name = dict(role=role_name, include=role_name)

    ri._play = Play()
    ri._play.name = play_name
    ri.role_basedir = '/ansible/test/role/'

    role_include_dict = dict()
    role_include_dict['role'] = role_name

    role_file_name = 'test_role.yml'
    role_file_path = os.path.join(ri.role_basedir, role_name, role_file_name)

    role_data = dict()
    role_data['name'] = role_name
    role_

# Generated at 2022-06-25 05:48:07.837886
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()


# Generated at 2022-06-25 05:48:18.311546
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    loader_mock = Mock(Loader)
    variable_manager_mock = Mock(VariableManager)
    play_mock = Mock(Play)

    data_mock = Mock(_data)
    data_mock.get_data = Mock(return_value = ('foo', 'bar', 'baz'))
    data_mock._data = data_mock.get_data()
    role_basedir_mock = Mock()
    parent_role_mock = Mock()

    role_include_0 = RoleInclude(play=play_mock, role_basedir=role_basedir_mock, variable_manager=variable_manager_mock, loader=loader_mock)
    role_include_0.load_data = Mock(return_value = role_include_0)
    role_include_0.load

# Generated at 2022-06-25 05:48:34.718395
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    byte_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    variable_manager_0 = VariableManager()
    data_0 = '\xf4\xb4\xb4\xb4\xb4\xb4\xb4\xb4\xb4\xb4\xb4'
    loader_0 = DataLoader()
    collection_list_0 = [loader_0]
    role_include_0 = RoleInclude.load(data_0, byte_0, variable_manager_0, loader_0, collection_list_0)
    assert role_include_0.role_name == '4'


# Generated at 2022-06-25 05:48:43.491079
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'ansible.builtin.apt'
    play = 'ansible.module_utils.six._six'
    current_role_path = 'ansible.parsing.dataloader._load_from_file'
    parent_role = 'ansible.playbook.play_context.PlayContext'
    variable_manager = 'ansible.vars.manager.VariableManager'
    loader = 'ansible.vars.manager.VariableManager'
    collection_list = 'ansible.module_utils.six._six'
    RoleInclude_load = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert RoleInclude_load == (None)

# Generated at 2022-06-25 05:48:51.716204
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    variable_manager_0 = variable_manager()
    variable_manager_1 = variable_manager()
    variable_manager_2 = variable_manager()
    variable_manager_3 = variable_manager()
    variable_manager_4 = variable_manager()
    variable_manager_5 = variable_manager()
    variable_manager_6 = variable_manager()
    variable_manager_7 = variable_manager()
    variable_manager_8 = variable_manager()
    variable_manager_9 = variable_manager()
    variable_manager_10 = variable_manager()
    variable_manager_11 = variable_manager()
    variable_manager_12 = variable_manager()
    variable_manager_13 = variable_

# Generated at 2022-06-25 05:48:57.794389
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Loads a role based on the passed data and variables
    #
    # Given a hash which can be found in a play's list of roles, or a
    # string which represents an ansible galaxy or github style role name,
    # load the role (which could be a galaxy role or a role which exists
    # on disk) and create a RoleInclude object out of it.
    os.chdir('/')
    assert False # TODO: implement your test here




# Generated at 2022-06-25 05:49:01.921752
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude(bytes_0)


# Generated at 2022-06-25 05:49:08.884174
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # str -> None
    role_include_0 = RoleInclude(str)
    # assumptions
    assert isinstance(role_include_0.load, object)
    # cleanup
    del role_include_0
    # str, string_types -> None
    role_include_1 = RoleInclude(str, string_types)
    # assumptions
    assert isinstance(role_include_1.load, object)
    # cleanup
    del role_include_1


# Generated at 2022-06-25 05:49:12.215859
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_0 = '0'
    play_0 = '0'
    RoleInclude.load(data_0, play_0)

# Generated at 2022-06-25 05:49:21.112747
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Load a role requirement string.
    req_str = 'role-a,role-b,role-c'
    role_include_0 = RoleInclude.load(req_str, None)
    assert len(role_include_0.get_dep_chain()) == 3

    # Load a role definition dict.
    role_def = dict(
        role='role-a',
        when='condition-a',
    )
    role_include_1 = RoleInclude.load(role_def, None)
    assert role_include_1.get_name() == 'role-a'
    assert role_include_1.get_when().evaluate_conditional('', dict()) == 'condition-a'

    # Load a plain role requirement string.
    req_str_1 = 'role-a'

# Generated at 2022-06-25 05:49:26.187077
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude(bytes_0)


# Generated at 2022-06-25 05:49:27.502810
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    assert True # TODO: implement your test here


# Generated at 2022-06-25 05:49:50.799810
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x93\x80\x91\xfb\xb4\x95\xd8\xc9\xdb\xde\xf7>\xd0.\x85\x9br\xd06\xb0s\x9b\x0e\xee\xe5'
    bytes_1 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    list_0 = []
    role_include_0 = RoleInclude.load(bytes_0, list_0)
    print(repr(role_include_0))
    role_include_1 = RoleInclude.load(bytes_1, list_0)
    print(repr(role_include_1))
    print(repr(list_0))


#

# Generated at 2022-06-25 05:50:00.821283
# Unit test for method load of class RoleInclude

# Generated at 2022-06-25 05:50:07.818644
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_1 = RoleInclude(bytes_0)
    assert role_include_1.delegate_to == 'localhost'
    assert role_include_1.delegate_facts == 'true'
    assert role_include_1.files == 'files'
    assert role_include_1.name == 'role_name'
    assert role_include_1.role_path == '/path/to/ansible/roles/role_name'
    assert role_include_1.vars == 'vars'
    assert role_include_1.default_vars == 'default_vars'
    assert role_include_1.meta

# Generated at 2022-06-25 05:50:19.045809
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # These are the inputs to the function:
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    # This is the return value of the function:
    role_include_0 = RoleInclude(bytes_0)

    # Execute the function:
    role_include_1 = RoleInclude.load(bytes_0, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    print("The function returned: %s" % type(role_include_1))
    # Verify the function call:
    assert type(role_include_1)

# Generated at 2022-06-25 05:50:23.222208
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    data = None
    result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

if __name__ == '__main__':
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:50:34.791887
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test with a basic data value
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude(bytes_0)

    # Test with another basic data value
    bytes_1 = b'\xbb\x18\x90\xbf\x8e6\x9b\xdf\x1e\x1a\x83\xc6\xad'
    role_include_1 = role_include_0.load(bytes_1)

    # Test with a more complex data value
    bytes_2 = b'\x9b\xa1\x0e\xde!'
    role_include_2 = role_include_1.load(bytes_2)

    # Test with a more complex data

# Generated at 2022-06-25 05:50:42.316862
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x88\xb6,\x83\x8b\x80\x17\xd5\x8d\x11\xb2\x00\x89\x01L\x01\xad\x03\x84\x15u\xb0\x8f\x05B\x10\x91\x06\xae\x03'
    role_include_0 = RoleInclude(bytes_0)
    assert role_include_0.load(bytes_0, bytes_0) == None


# Generated at 2022-06-25 05:50:48.264712
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude(bytes_0)
    # Unit test: test_case_0
    data_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    play_0 = {}
    variable_manager_0 = {}
    loader_0 = 2
    collection_list_0 = {}
    # Perform the test action
    # Parameter data_0 is not used.
    # Parameter play_0 is not used.
    # Parameter current_role_path_0 is not used.
    # Parameter parent_role_0 is not used.
    # Parameter variable_manager_0 is not

# Generated at 2022-06-25 05:50:53.580938
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude(bytes_0)
    role_include_0.name = "RoleInclude"

# Generated at 2022-06-25 05:51:00.028539
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    data_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    play_0 = os.urandom(10)
    variable_manager_0 = os.urandom(10)
    loader_0 = os.urandom(10)
    result_0 = RoleInclude.load(data_0, play_0, variable_manager=variable_manager_0, loader=loader_0)
    assert isinstance(result_0, RoleRequirement)
    assert isinstance(result_0, RoleInclude)



# Generated at 2022-06-25 05:51:17.124618
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x1a\xdb\xa1Ou\x9c\xa2\xb7\x80\xdc\x1a&'
    role_include_0 = RoleInclude(bytes_0)


# Generated at 2022-06-25 05:51:23.708419
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude(bytes_0)
    data = "testdata"
    play = "testdata"
    current_role_path = "testdata"
    parent_role = "testdata"
    variable_manager = "testdata"
    loader = "testdata"
    collection_list = "testdata"
    # Calling the function to test
    test_role_include = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert type(test_role_include) == RoleInclude


# Generated at 2022-06-25 05:51:28.761710
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude(bytes_0)


# Generated at 2022-06-25 05:51:34.690083
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude(bytes_0)
    assert role_include_0 == None

# Generated at 2022-06-25 05:51:44.243354
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude(bytes_0)
    bytes_1 = b'?\xdf'
    role_include_1 = RoleInclude(bytes_1)
    str_0 = '\x00AV\x0c\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 05:51:53.470972
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Verify first use case
    YAMLObject = RoleInclude.load(data=bytes_0, play=bytes_0, current_role_path=bytes_0, parent_role=bytes_0, variable_manager=bytes_0, loader=bytes_0, collection_list=bytes_0)
    assert isinstance(YAMLObject, RoleInclude)
    # Verify second use case
    YAMLObject = RoleInclude.load(data=dict_0, play=bytes_0, current_role_path=bytes_0, parent_role=bytes_0, variable_manager=bytes_0, loader=bytes_0, collection_list=bytes_0)
    assert isinstance(YAMLObject, RoleInclude)
    # Verify third use case

# Generated at 2022-06-25 05:52:00.273379
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = AnsibleBaseYAMLObject()
    play = AnsibleBaseYAMLObject()
    current_role_path = AnsibleBaseYAMLObject()
    parent_role = AnsibleBaseYAMLObject()
    variable_manager = AnsibleBaseYAMLObject()
    loader = AnsibleBaseYAMLObject()
    collection_list = AnsibleBaseYAMLObject()
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except:
        pass
    else:
        raise AssertionError()



# Generated at 2022-06-25 05:52:10.791929
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # create an instance of the class to be tested
    role_include_1 = RoleInclude()

    # create the object to be used as input to the method
    play_1 = Attribute()
    play_1.value = b'\xc54\xde0\x92\x9e9\xe3\x82\x90\x8b\x8b\x90\xbf\x9c\x94\x82\x98\xae\x90\x1f\x8c\x18\xa2\xed'

# Generated at 2022-06-25 05:52:15.828906
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    role_include_0 = RoleInclude(bytes_0)
    assert role_include_0.load(bytes_0) == None

# Generated at 2022-06-25 05:52:21.756179
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xde\xf7>\xd0.\x85\x9br\xd06\xb0s'
    role_include_0 = RoleInclude(bytes_0)
    role_include_0.load()

