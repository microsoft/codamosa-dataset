

# Generated at 2022-06-25 05:44:43.494182
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xb9\x98L\xdb\xe3~c'
    float_0 = 0.2
    role_include_0 = RoleInclude()
    assert isinstance(var_0, RoleRequirement)

# Generated at 2022-06-25 05:44:44.300636
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:44:48.933715
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xb9\x98L\xdb\xe3~c'
    float_0 = 0.2
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(bytes_0, float_0)



# Generated at 2022-06-25 05:44:56.549783
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    string_0 = 'test,test'
    float_0 = 0.3
    with pytest.raises(AnsibleError):
        role_include_0.load(string_0, float_0)
    float_0 = 0.5
    with pytest.raises(AnsibleParserError):
        role_include_0.load(string_0, float_0)
    float_0 = 0.5
    role_include_0.load(string_0, float_0)


# Generated at 2022-06-25 05:44:58.425552
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True is True

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 05:45:02.815800
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    bytes_0 = b'\xb9\x98L\xdb\xe3~c'
    float_0 = 0.2
    var_0 = role_include_0.load(bytes_0, float_0)



# Generated at 2022-06-25 05:45:06.525518
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Check that the method is generated successfully.
    RoleInclude.load(None, None, None, None, None, None)

# Generated at 2022-06-25 05:45:12.689677
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x1c\x1f\x06\xc9\x15\xc7\xf4\xba'
    str_0 = '\x14\x1d\x10\xc9\x1b\xc2\xf2\xbb\x18\x07\rgc\x0e\x1f'
    float_0 = 0.0
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(bytes_0, str_0, float_0)

# Generated at 2022-06-25 05:45:18.034030
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x9a\xbc\x7fA\x8e'
    float_0 = 6.7
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(bytes_0, float_0)

    # Test method load of class RoleInclude
    role_include_0.load('0.3', '1.7')

# Generated at 2022-06-25 05:45:28.922895
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\x8a\x1d\x91\x0f\x9a\xe2\x98\xc1\x84\x86\x90\x97\x10\xed\x8b\xe6\x9aT'
    float_0 = 0.13203046607687698
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(bytes_0, float_0)
    var_1 = role_include_0.load(bytes_0, float_0)
    role_include_0.load(bytes_0, float_0)
    role_include_0.load(bytes_0, float_0)
    role_include_0.load(bytes_0, float_0)
    role_include_0

# Generated at 2022-06-25 05:45:40.637085
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    int_1 = 0
    dict_1 = dict()
    dict_1['role_path'] = '/etc/ansible/roles'
    dict_1['roles'] = list()
    dict_1['roles'].append('somename')
    dict_1['roles'].append(dict())
    dict_1['roles'][1]['vars'] = dict()
    dict_1['roles'][1]['name'] = 'somename'
    dict_1['roles'][1]['vars']['variable'] = 'value'
    dict_1['roles'][1]['vars']['variable2'] = "value2"
    float_1 = 0.0

# Generated at 2022-06-25 05:45:50.285634
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xe0\xaaP\x95\x8f\x8c\xf2\xd6\x9e'
    float_0 = 0.2
    role_include_0 = RoleInclude()
    # Call the method
    var_0 = role_include_0.load(bytes_0, float_0)
    # Check type of var_0
    if not isinstance(var_0, RoleInclude):
        print("Expected var_0 to be RoleInclude, got " + str(type(var_0)))
        return False
    # Check if the method called handle_errors()
    if not hasattr(role_include_0, 'handle_errors'):
        print("Expected role_include_0 to have handle_errors() method")
        return False
    return True



# Generated at 2022-06-25 05:45:54.035184
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
  bytes_0 = b'+\xb8\xfe\x82\x98\x1d\xbf\xe0'
  float_0 = 0.7
  role_include_0 = RoleInclude()
  var_0 = role_include_0.load(bytes_0, float_0)

# Generated at 2022-06-25 05:45:54.855239
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:45:59.475573
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xb9\x98L\xdb\xe3~c'
    float_0 = 0.2
    role_include_0 = RoleInclude()
    dict_0 = dict(a=bytes_0, b=float_0)
    dict_1 = dict(a=bytes_0)
    dict_2 = dict(a=dict(b=bytes_0), c=dict_1)
    role_include_1 = RoleInclude()
    var_0 = role_include_1.load(dict_2, float_0)
    var_1 = role_include_0.load(bytes_0, float_0)
    float_1 = 0.6
    str_0 = 'y'
    dict_3 = dict(a=float_1, b=str_0)
    dict

# Generated at 2022-06-25 05:46:04.052407
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
  bytes_0 = b'\xb9\x98L\xdb\xe3~c'
  float_0 = 0.2
  role_include_0 = RoleInclude()
  var_0 = role_include_0.load(bytes_0, float_0)


# Generated at 2022-06-25 05:46:04.998421
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()


# Generated at 2022-06-25 05:46:06.617562
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.load()


# Generated at 2022-06-25 05:46:14.032621
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    bytes_0 = b'\xb9\x98L\xdb\xe3~c'
    float_0 = 0.2
    role_include_0 = RoleInclude()

    # Test for a case where an exception is raised for an invalid old style role requirement
    try:
        var_0 = role_include_0.load(bytes_0, float_0)
        assert False
    except AnsibleError as e:
        assert isinstance(e, AnsibleError)
        assert e.message == "Invalid old style role requirement: b'\\xb9\\x98L\\xdb\\xe3~c'"

# Generated at 2022-06-25 05:46:16.670600
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    bytes_0 = b'\xb9\x98L\xdb\xe3~c'
    float_0 = 0.2
    role_include_0 = RoleInclude()
    role_include_0.load(bytes_0, float_0)


# Generated at 2022-06-25 05:46:22.107409
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    try:
        var_0 = role_include_0.load(role_include_0, role_include_0)
    except Exception as e:
        print(e.args)
        print(e.message)
        print(e.__class__)
        print(e.__doc__)



# Generated at 2022-06-25 05:46:32.094064
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class Fake_RoleInclude(RoleInclude):
        def __init__(self):
            self.fake = None
            self.role_basedir = "role_basedir"
            self.variable_manager = "variable_manager"
            self.loader = "loader"
            self.collection_list = "collection_list"

            # AnsibleBaseEntity

            self.created = "created"
            self.name = "name"
            self.namespace = "namespace"
            self.parent = "parent"
            self.play = "play"
            self.playbook = "playbook"
            self.play_path = "play_path"
            self.role_name = "role_name"
            self.task = "task"
            self.tags = "tags"
            self.vars = "vars"


# Generated at 2022-06-25 05:46:43.129061
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import tempfile
    import ansible.plugins.loader

    # Ansible Plugin Loader is loaded lazily. This causes problems
    # when testing because it may not be loaded properly to patch.
    # Thus, we load it up manually.
    ansible.plugins.loader.find_plugin_files()

    # verify imports
    assert ansible.plugins.loader

    # create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # create the `lib` directory inside temporary directory
    # and create a `role` directory inside that
    lib_dir = os.path.join(tmp_dir, 'lib')
    os.makedirs(lib_dir)

    # create a fake loadable role
    role_dir = os.path.join(lib_dir, 'role')

# Generated at 2022-06-25 05:46:45.586196
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    assert role_include_0.load(role_include_0, role_include_0) == var_0

# Generated at 2022-06-25 05:46:51.916289
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("in test_unit_load_for_RoleInclude_class")
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    role_include_4 = RoleInclude()
    role_include_5 = RoleInclude()
    role_include_6 = RoleInclude()
    try:
        var_0 = role_include_0.load(role_include_0, role_include_0)
    except:
        pass

    role_include_1.load_data(role_include_0, role_include_1)

# Generated at 2022-06-25 05:47:00.537983
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print('')
    print('Executing test_RoleInclude_load')
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    data_0 = "name"

    print('            data : ' + str(data_0))
    print('             play : ' + str(play))
    print('current_role_path : ' + str(current_role_path))
    print('     parent_role : ' + str(parent_role))
    print('variable_manager : ' + str(variable_manager))
    print('          loader : ' + str(loader))
    print(' collection_list : ' + str(collection_list))

    role_include_0 = RoleInclude()
    var_0 = role_include

# Generated at 2022-06-25 05:47:01.429691
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print('Testing RoleInclude.load')
    test_case_0()


# Generated at 2022-06-25 05:47:10.228306
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_cases = [
        # Case 0: Test load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
        {
            "description": "No data loaded for this case",
            "data": None,
            "role_include_0": RoleInclude(),
            "variable_manager": None,
            "loader": None,
            "collection_list": None,
            "expected_return": None
        }
    ]


# Generated at 2022-06-25 05:47:17.426598
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    loader_0 = DataLoader()
    """
    Test for method load of class RoleInclude with paramters(data, play, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    """
    loader_1 = DataLoader()

    role_include_0 = RoleInclude()
    # Load RoleInclude object from role name, role path and play, parent_role, variable_manager, loader and collection_list
    var_0 = role_include_0.load(role_include_0, role_include_0)
    assert var_0 == None

    # Load RoleInclude object src and play, parent_role, variable_manager, loader and collection_list

# Generated at 2022-06-25 05:47:26.339671
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0._play = Play()
    role_include_0._variable_manager = VariableManager()
    role_include_0._loader = DataLoader()
    role_include_1 = RoleInclude()
    role_include_1._play = Play()
    role_include_1._variable_manager = VariableManager()
    role_include_1._loader = DataLoader()
    role_include_0._role_basedir = os.path.dirname(os.path.abspath(__file__))
    role_include_1._role_basedir = os.path.dirname(os.path.abspath(__file__))
    role_include_0._collection_list = role_include_1._collection_list = CollectionLoader()
    var_0 = role

# Generated at 2022-06-25 05:47:31.542252
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    args = {}
    obj = RoleInclude()
    try:
        obj.load(args)
    except Exception as exception:
        assert False


# Generated at 2022-06-25 05:47:38.749934
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    exception_thrown = False
    try:
        role_include_0 = RoleInclude()
        role_include_0.load(role_include_0, role_include_0)
    except NotImplementedError as e:
        exception_thrown = True
        assert True
    assert exception_thrown
    # TODO: add tests of load


# Generated at 2022-06-25 05:47:41.481884
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    args = {"play": None, "role_basedir": None, "variable_manager": None, "loader": None, "collection_list": None}
    tc = RoleInclude(**args)

    # Call method load from class RoleInclude
    assert tc.load == tc.__init__()

# Generated at 2022-06-25 05:47:44.550602
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)

# Generated at 2022-06-25 05:47:48.402399
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)


# Generated at 2022-06-25 05:47:50.116086
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_1.load(role_include_1, role_include_1)

# Generated at 2022-06-25 05:47:52.107268
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("Testing RoleInclude.load")

    # Test with no args
    role_include = RoleInclude()
    assert role_include.load() == None


# Generated at 2022-06-25 05:47:58.631046
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_1 = role_include_0.load("role0", "role_include_0")
    assert isinstance(var_1, RoleRequirement)
    assert var_1._parent == "role_include_0"
    assert var_1._role_name == "role0"
    assert role_include_0.get_role_params() == {}
    assert role_include_0.vars == {}
    assert role_include_0.default_vars == {}



# Generated at 2022-06-25 05:48:02.256500
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    role_path = './example_role'
    data = {
        'role': 'jdauphant.nginx',
        #'role': '../../example_role',  # Role import from relative path
        'tags': ['role_test']
    }
    role = ri.load(data=data, play=None, current_role_path=role_path, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    print(role.get_role_path())

# Generated at 2022-06-25 05:48:06.425522
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = RoleInclude.load(role_include_0, role_include_0)


# Generated at 2022-06-25 05:48:11.641518
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert 1==1

# Generated at 2022-06-25 05:48:14.254827
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)

# Generated at 2022-06-25 05:48:19.020879
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleRequirement()
    var_0 = role_include_0.load(role_include_1, role_include_0)


# Generated at 2022-06-25 05:48:26.591763
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
        role_include_0 = RoleInclude()
        role_include_0_role_basedir = None
        variable_manager_0 = VariableManager()
        variable_manager_0.extra_vars = {}
        variable_manager_0.options = Options()
        variable_manager_0._fact_cache = {}
        variable_manager_0.registered_vars = {}
        variable_manager_0.vars = {}
        variable_manager_0.next_seq = 0
        var_0 = role_include_0.load(role_include_0, role_include_0)

if __name__ == '__main__':
    test_case_0()
    test_RoleInclude_load()

# Generated at 2022-06-25 05:48:31.195982
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = role_include_0
    role_include_2 = role_include_1
    role_include_3 = {'role': 'storage'}
    var_0 = role_include_2.load(role_include_3, role_include_0)
    pass

# Generated at 2022-06-25 05:48:36.816595
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    role_include_4 = RoleInclude()
    role_include_5 = RoleInclude()
    role_include_6 = RoleInclude()
    var_1 = role_include_6.load(role_include_6, role_include_6)


# Generated at 2022-06-25 05:48:37.325988
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False

# Generated at 2022-06-25 05:48:40.317627
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Try to load a valid role
    try:
        res = RoleInclude()
        res.load(res)
    except Exception as e:
        print("LOAD TEST FAILED!")
        print(e)
        raise e



# Generated at 2022-06-25 05:48:41.454085
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:48:46.182575
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    play_0 = Play()
    current_role_path_0 = None
    parent_role_0 = Role()
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    collection_list_0 = []
    role_include_2 = RoleInclude.load(role_include_1, play_0, current_role_path_0, parent_role_0, variable_manager_0, loader_0, collection_list_0)


# Generated at 2022-06-25 05:48:58.335945
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """AnsibleRoleInclude"""
    os.environ['test_RoleInclude_load'] = 'test_RoleInclude_load'
    os.environ['test_RoleInclude_load_file'] = 'test_RoleInclude_load_file'
    os.environ['test_RoleInclude_load_dict'] = 'test_RoleInclude_load_dict'
    os.environ['test_RoleInclude_load_bool'] = 'True'
    test_case_0()

# Generated at 2022-06-25 05:49:02.940689
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    var_1 = role_include_1.load(role_include_1, role_include_2)


# Generated at 2022-06-25 05:49:11.455204
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    role_include_4 = RoleInclude()
    role_include_5 = RoleInclude()
    role_include_6 = RoleInclude()
    role_include_7 = RoleInclude()
    role_include_8 = RoleInclude()
    role_include_9 = RoleInclude()
    role_include_10 = RoleInclude()
    role_include_11 = RoleInclude()
    role_include_12 = RoleInclude()
    role_include_13 = RoleInclude()
    role_include_14 = RoleInclude()
    role_include_15 = RoleInclude()
    role_include_16 = RoleInclude()

# Generated at 2022-06-25 05:49:20.643235
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    role_include_4 = RoleInclude()
    role_include_5 = RoleInclude()
    role_include_6 = RoleInclude()
    role_include_7 = RoleInclude()
    role_include_8 = RoleInclude()
    role_include_9 = RoleInclude()
    role_include_10 = RoleInclude()
    role_include_11 = RoleInclude()
    role_include_12 = RoleInclude()
    role_include_13 = RoleInclude()
    role_include_14 = RoleInclude()
    role_include_15 = RoleInclude()

# Generated at 2022-06-25 05:49:28.406458
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()

    # all args passed.
    role_include_2 = RoleInclude()
    var_3 = role_include_2.load(role_include_2, role_include_2)

    # all args passed.
    role_include_3 = RoleInclude()
    var_4 = role_include_3.load(role_include_3, role_include_3, role_include_3, role_include_3, role_include_3)

# Generated at 2022-06-25 05:49:30.785789
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    target = RoleInclude()
    #target.load(arg0, arg1)
    raise Exception("No test for this method")


# Generated at 2022-06-25 05:49:34.927151
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    role_include1 = RoleInclude()
    role_include2 = RoleInclude()
    var = role_include.load(role_include, role_include1, role_include2)
    assert var == None, "Incorrect return type"


# Generated at 2022-06-25 05:49:39.749360
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    role_include_4 = RoleInclude()
    role_include_5 = RoleInclude()
    role_include_6 = RoleInclude()
    role_include_7 = RoleInclude()
    role_include_8 = RoleInclude()
    role_include_9 = RoleInclude()
    role_include_10 = RoleInclude()
    role_include_11 = RoleInclude()
    role_include_12 = RoleInclude()
    role_include_13 = RoleInclude()
    role_include_13 = RoleInclude()
    role_include_14 = RoleInclude()

# Generated at 2022-06-25 05:49:46.374233
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    with pytest.raises(AnsibleError) as excinfo:
        role_include_1.load(role_include_1, role_include_1)
    assert 'Invalid old style role requirement' in str(excinfo.value)

if __name__ == "__main__":
    test_RoleInclude_load()

# Generated at 2022-06-25 05:49:52.653825
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    role_include_4 = RoleInclude()

    # Test with invalid inputs for the first parameter of method load
    try:
        var_0 = role_include_0.load(role_include_0, role_include_0)
    except ValueError as e:
        assert "invalid literal for int() with base 10: '{}'".format(role_include_0) in str(e)
    except Exception as e:
        print(e)
        assert False

    # Test with invalid inputs for the second parameter of method load

# Generated at 2022-06-25 05:50:08.399324
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    variable_manager_0 = variable_manager()
    role_include_0.load(role_include_0, variable_manager_0)

    variable_manager_0 = variable_manager()
    # Here use the RoleRequirement class, the type of data argument is the same as that of the second parameter.
    role_requirement_0 = RoleRequirement()
    role_include_0.load(role_requirement_0, variable_manager_0)


# Generated at 2022-06-25 05:50:12.010603
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    (my_var, expected_result) = test_case_0()
    result = my_var.load(my_var)
    assert result == expected_result

# Generated at 2022-06-25 05:50:21.433633
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()

    var_0 = role_include_0.load(var_0, var_1)
    var_2 = role_include_0.load(var_2, var_3)
    var_4 = role_include_1.load(var_4, var_5)
    var_6 = role_include_1.load(var_6, var_7)
    var_8 = role_include_2.load(var_8, var_9)
    var_10 = role_include_2.load(var_10, var_11)

# Generated at 2022-06-25 05:50:32.260564
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)
    return var_0
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
# Autogenerated method for RoleInclude
#

# Generated at 2022-06-25 05:50:42.752960
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class TestPlay:
        pass
    
    test_play = TestPlay()
    test_role_basedir = "/test_dir"
    
    test_variable_manager = {}

    class TestLoader:
        def __init__(self, module_utils=''):
            self.module_utils = module_utils
    test_loader = TestLoader()
    test_collection_list = {}

    role_include_1 = RoleInclude(play=test_play, role_basedir=test_role_basedir, variable_manager=test_variable_manager, loader=test_loader, collection_list=test_collection_list)
    assert isinstance(role_include_1, RoleInclude)
    # Test the method with an Attribute object as the first argument:

# Generated at 2022-06-25 05:50:46.089995
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    assert isinstance(role_include_0.load(role_include_0, role_include_0), RoleInclude)


# Generated at 2022-06-25 05:50:53.451818
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    role_include_2.load(role_include_0, role_include_1)
    role_include_3.load_data(role_include_0, role_include_1)
    #role_include_2.load(role_include_0, role_include_1)


# Generated at 2022-06-25 05:51:00.908465
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    #Create an instance of RoleInclude
    role_include_0 = RoleInclude()
    data = ''
    play = ''
    role_basedir = ''
    current_role_path = ''
    parent_role = ''
    variable_manager = ''
    loader = ''
    collection_list = ''
    #Invoke method load on class RoleInclude
    var_0 = role_include_0.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert var_0 == None
    assert True


# Generated at 2022-06-25 05:51:11.938542
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    role_include_4 = RoleInclude()
    role_include_5 = RoleInclude()
    role_include_6 = RoleInclude()
    role_include_6.load(role_include_6, role_include_6)
    role_include_7 = RoleInclude()
    role_include_7.load(role_include_7, role_include_7)
    role_include_8 = RoleInclude()
    role_include_8.load(role_include_8, role_include_8)
    role_include_9 = RoleInclude()

# Generated at 2022-06-25 05:51:13.882673
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.load(role_include_0, role_include_0)

# Generated at 2022-06-25 05:51:36.533799
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_case_0()

# Generated at 2022-06-25 05:51:39.639025
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.load(role_include_0, role_include_0)

# Generated at 2022-06-25 05:51:46.054352
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ex_1 = AnsibleError
    ex_2 = AnsibleParserError
    var_0 = 'roles/load'
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    role_include_0 = RoleInclude()
    role_include_0.role_basedir = var_0
    role_include_0.loader = var_1
    role_include_0.variable_manager = var_2
    role_include_0.collection_list = var_3
    var_5 = getattr(role_include_0, "play", None)
    var_6 = getattr(role_include_0, "role_basedir", None)
    var_7 = getattr(role_include_0, "variable_manager", None)
    var_8

# Generated at 2022-06-25 05:51:48.690236
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    assert role_include_0.load(role_include_0, role_include_1) is None


# Generated at 2022-06-25 05:51:51.846584
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Run the unittest and store the result
    test_RoleInclude_load.result = RoleInclude.load('test')

test_RoleInclude_load.result = None


# Generated at 2022-06-25 05:51:58.206207
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_1 = RoleInclude()
    role_include_2 = RoleInclude()
    role_include_3 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_1)
    var_1 = role_include_1.load(role_include_1, role_include_2)
    var_2 = role_include_2.load(role_include_2, role_include_3)
    var_3 = role_include_3.load(role_include_3, role_include_0)


# Generated at 2022-06-25 05:52:04.650131
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    global RoleInclude_test1_data
    global RoleInclude_test2_data
    global var_0

    # Test for role_include.load(role_include, role_include)
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)

    # Test for role_include.load(role_include, role_include)
    role_include_1 = RoleInclude()
    with pytest.raises(AnsibleError) as excinfo:
        role_include_1.load(role_include_1, role_include_1)
    # assert excinfo.value.errno == errno.ENOTDIR
    # assert str(excinfo.value) == "Fake error"

# Generated at 2022-06-25 05:52:09.679982
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)
    assert var_0.__class__.__name__ == 'RoleRequirement'


assert(test_RoleInclude_load())

# Generated at 2022-06-25 05:52:16.237742
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Assigning argument 'data' to a wrong type should raise a TypeError
    # Assigning argument 'current_role_path' to a wrong type should raise a TypeError
    # Assigning argument 'parent_role' to a wrong type should raise a TypeError
    # Assigning argument 'variable_manager' to a wrong type should raise a TypeError
    # Assigning argument 'loader' to a wrong type should raise a TypeError
    # Assigning argument 'collection_list' to a wrong type should raise a TypeError
    # Calling load() with incorrect arguments should raise a TypeError
    try:
        test_case_0()
    except TypeError as e:
        assert type(e) == TypeError
    else:
        assert False, "Expected TypeError"



# Generated at 2022-06-25 05:52:20.730866
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)


# Generated at 2022-06-25 05:53:10.347552
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    yamlstr = '''
        - name: role1
        - role:
            - role2
            - role3
    '''
    role_include_1 = RoleInclude()
    data = {'name': 'role1', 'role': ['role2', 'role3']}
    var_1 = role_include_1.load(data, role_include_1)

# Generated at 2022-06-25 05:53:14.278008
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    args_0 = ['test_case_0']
    if 'test_case_0' in args_0:
        test_case_0()


if __name__ == "__main__":
    os.environ["ANSIBLE_LIBRARY"] = "{}/ansible/playbook/library".format(os.getcwd())
    test_RoleInclude_load()

# Generated at 2022-06-25 05:53:16.859204
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    var_0 = role_include_0.load(role_include_0, role_include_0)
    assert var_0 == True


# Generated at 2022-06-25 05:53:19.365326
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_1.load(role_include_1, role_include_1)

# =======
#  Remove the line(s) above before test
# =======

# Generated at 2022-06-25 05:53:26.549708
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    path_spec_1 = os.path.normpath("/usr/local/lib/python2.7/dist-packages/ansible/playbook/__init__.py")
    yaml_1 = u"ansible.playbook.__init__.py"
    os_path_normpath_1 = os.path.normpath("/usr/local/lib/python2.7/dist-packages/ansible/playbook/__init__.py")
    cwd_1 = u"."
    ansible_dir_1 = u"/usr/local/lib/python2.7/dist-packages/ansible/playbook/"
    path_spec_2 = os.path.normpath("/usr/local/lib/python2.7/dist-packages/ansible/playbook/__init__.py")
    yaml

# Generated at 2022-06-25 05:53:31.827550
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    # test_case_0 is calling the method with no argument, but the method needs argument
    role_include_0.load()



# Generated at 2022-06-25 05:53:36.179558
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_1 = RoleInclude()
    role_include_1.load(str(0), role_include_1, role_include_1, role_include_1, role_include_1, role_include_1, role_include_1)


# Generated at 2022-06-25 05:53:40.802400
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.set_loader(role_include_0)
    # No exception thrown
    assert role_include_0.get_loader() == role_include_0
    assert role_include_0.load(role_include_0, role_include_0) is None


# Generated at 2022-06-25 05:53:45.892048
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        test_case_0()
        print('PASS')
    except Exception as e:
        print('FAILED')
        print('test case: test_case_0')
        print('message:', e)

if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-25 05:53:48.570735
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_0 = RoleInclude()
    role_include_0.load(role_include_0, role_include_0)