

# Generated at 2022-06-11 10:39:07.096289
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude.load("myuser.myrole")

# Generated at 2022-06-11 10:39:17.848909
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_context = dict(
        port=9090
    )
    play = Play().load({
        "name": "Ansible Play",
        "hosts": "localhost",
        "gather_facts": "no",
        "tasks": [
            {"action": {"module": "shell", "args": "ls"}}
        ]},
        variable_manager=variable_manager, loader=None)

# Generated at 2022-06-11 10:39:25.291894
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test AnsibleParserError is raised for invalid 'data' parameter
    try:
        RoleInclude.load([], None, None, None, None, None)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('AnsibleParserError not raised')

    # test AnsibleError is raised for invalid 'data' parameter
    try:
        RoleInclude.load(',', None, None, None, None, None)
    except AnsibleError:
        pass
    else:
        raise AssertionError('AnsibleError not raised')

# Generated at 2022-06-11 10:39:27.949756
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    parser = AnsibleParser(None, None)
    assert not parser._load_role_definition('junk')
    assert parser._load_role_definition('www_role')

# Generated at 2022-06-11 10:39:36.651639
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = None
    current_role_path = os.path.dirname(os.path.realpath(__file__))
    data = 'testrole'
    play = PlayContext(play=None)
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play))
    role_data = {'role': 'testrole'}
    role_result = RoleInclude.load(role_data, play, current_role_path, variable_manager=variable_manager,
                                   loader=loader)
    assert role_result.name == 'testrole'
    assert role_result.get_name

# Generated at 2022-06-11 10:39:47.612533
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import plugin_loader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(os.path.join(os.path.dirname(__file__), '../../inventory_hosts')))

    host = variable_manager.get

# Generated at 2022-06-11 10:39:58.371199
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test with good data
    data = 'foo,bar'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ret = RoleInclude.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    str = "role_1"
    assert(ret._role_name == str)
    data = 'roles/foo'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

# Generated at 2022-06-11 10:40:01.785116
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {'name': 'bob',
            'role1': {'name': 'role1'},
            'role2': {'name': 'role2'},
            'role3': {'name': 'role3'}
            }

# Generated at 2022-06-11 10:40:02.785028
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    return 0


# Generated at 2022-06-11 10:40:12.945409
# Unit test for method load of class RoleInclude

# Generated at 2022-06-11 10:40:26.633049
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:40:36.692452
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    data = "ansible-role-test"
    play = Play()
    current_role_path = ""
    parent_role = RoleDefinition()
    variable_manager = None
    loader = None

    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)
    assert ri.get_name() == "test"

    data = "test"

# Generated at 2022-06-11 10:40:43.961821
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ##
    ## RoleInclude.load() test cases
    ##
    ri = RoleInclude()
    ri.name = "test_RoleInclude_load"

    #
    # Test 1: invalid role definition
    #
    try:
        data = ('foo', 'baz')
        ri.load(data)
        assert False, "Expected exception when passing tuple as data to load()"
    except AnsibleParserError as e:
        assert 'Invalid role definition' in to_native(e)

    #
    # Test 2: old style role requirement
    #

# Generated at 2022-06-11 10:40:56.298830
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    try:
        role_include.load("")
    except AnsibleParserError as e:
        assert(e.message == "Invalid role definition: ")
    except:
        raise AssertionError("Expected AnsibleParserError")

    try:
        role_include.load("test,test1")
    except AnsibleError as e:
        assert(e.message == "Invalid old style role requirement: test,test1")
    except:
        raise AssertionError("Expected AnsibleError")

    try:
        role_include.load(123)
    except AnsibleParserError as e:
        assert(e.message == "Invalid role definition: 123")
    except:
        raise AssertionError("Expected AnsibleParserError")


# Generated at 2022-06-11 10:40:56.881466
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False

# Generated at 2022-06-11 10:41:04.581520
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    loader = None
    role_basedir = None
    variable_manager = None
    play = None
    current_role_path = None
    parent_role = None

    # 1.
    # Test load with string parameter.
    string_param = "string_param"

    # Create an instance
    ri1 = RoleInclude(play, role_basedir, variable_manager, loader, None)
    ri1.load(string_param, play, current_role_path, parent_role, variable_manager, loader, None)

    # 2.
    # Test load with dict parameter.
    dict_param = {'1': 1, '2': 2}

    # Create an instance
    ri2 = RoleInclude(play, role_basedir, variable_manager, loader, None)

# Generated at 2022-06-11 10:41:13.291801
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.cli import CLI

    playbook_path = os.path.join(os.getcwd(),'tests','playbooks','test-role-include.yml')

    pb = Play.load(playbook_path, variable_manager=VariableManager(), loader=DataLoader())
    pb.post_validate(loader=DataLoader())
    play = pb.get_plays()[0]
    play.post_validate

# Generated at 2022-06-11 10:41:14.124934
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
        load():
    """
    pass

# Generated at 2022-06-11 10:41:24.236479
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Data for load method
    data_load_test = dict(
        role=dict(
            name="my_role",
            tasks=dict(main=dict(include=dict(a="a", b="1", c="3", d="4"))),
            handlers=dict(main=dict(include=dict(a="a", b="1", c="3", d="4"))),
            meta=dict(a="a", b="1", c="3", d="4")
        )
    )

    # RoleInclude instance
    ri = RoleInclude(
        play="my_play",
        role_basedir="my_basedir",
        variable_manager="my_variable_manager",
        loader="my_loader",
        collection_list="my_collection_list"
    )

    # Code to test load method

# Generated at 2022-06-11 10:41:34.255864
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Simple role requirement
    ri = RoleInclude.load(data = 'role_name', play = 'play', current_role_path = None, parent_role = None, variable_manager = None, loader = None)
    assert ri.get_name() == 'role_name'
    assert ri.is_old_style()
    assert not ri._delegate_to

    # Simple role requirement with version
    ri = RoleInclude.load(data = 'role_name,1.0', play = 'play', current_role_path = None, parent_role = None, variable_manager = None, loader = None)
    assert ri.get_name() == 'role_name'
    assert ri.get_version() == '1.0'
    assert ri.is_old_style()
    assert not r

# Generated at 2022-06-11 10:41:52.419719
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play

    from ansible.playbook.role.meta import RoleMetadata
    meta = RoleMetadata({'ver': '1.2.3', 'bogus': 'foo'})
    assert meta.ver == '1.2.3'
    assert meta.bogus == 'foo'

    args = {'name': 'test_name', 'ver': 'test_ver', 'private': 'test_private'}
    meta = RoleMetadata(args)
    assert meta.ver == 'test_ver'
    assert meta.private == 'test_private'

    args = {'name': 'test_name', 'ver': 2, 'private': 'test_private'}
    meta = RoleMetadata(args)
    assert meta.ver == 2

# Generated at 2022-06-11 10:42:01.527535
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_single={"role1": {"include_tasks": "main.yml"}}
    data_single_dict={"role1": {"include_tasks": {"file": "main.yml"}}}
    data_single_dict_no_file={"role1": {"include_tasks": {"file1": "main.yml"}}}
    data_double={"role1": {"include_tasks": "main.yml", "include_tasks": "other.yml"}}
    data_double_dict={"role1": {"include_tasks": {"file": "main.yml"}, "include_tasks": {"file": "other.yml"}}}

# Generated at 2022-06-11 10:42:12.710502
# Unit test for method load of class RoleInclude

# Generated at 2022-06-11 10:42:16.371462
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    def mock_load_data(data):
        assert data == "fakerole"
        return {}
    ri.load_data = mock_load_data
    ri.load("fakerole", variable_manager=None, loader=None)

# Generated at 2022-06-11 10:42:25.622781
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import sys
    import unittest
    import tempfile

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.module_utils._text import to_native

    # Prepare a test
    class TestCase(unittest.TestCase):
        def __init__(self, methodName):
            super(TestCase, self).__init__(methodName)

        def test_role_include_load(self):
            ri = RoleInclude()

        def test_role_include_load_string(self):
            ri = RoleInclude()

        def test_role_include_load_dict(self):
            ri = RoleInclude()


# Generated at 2022-06-11 10:42:35.975379
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    inventory = InventoryManager(loader=DataLoader(), sources=["localhost"])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # Initialize loader and variable manager
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 10:42:44.891929
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Dummy play to test the RoleInclude class.
    class TestDummyPlay(object):
        def __init__(self):
            self.hosts = 'localhost'

    from ansible.playbook.role.definition import ROLE_CACHE
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.collection.collection_loader import AnsibleCollectionLoader
    from ansible.utils.display import Display

    display = Display()
    ROLE_CACHE = {}
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    collection_loader = AnsibleCollectionLoader()

   

# Generated at 2022-06-11 10:42:45.747029
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO
    pass

# Generated at 2022-06-11 10:42:48.742136
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    data = dict()
    data['name'] = 'sample'
    data['include'] = 'all'
    out = ri.load(data)
    assert out is not None
    assert out.get_name() == 'sample'

# Generated at 2022-06-11 10:42:58.111724
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play = Play().load({
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [
            {'action': {'module': 'debug', 'args': {'msg': "Hello World"}}}
        ]
    }, variable_manager=variable_manager, loader=loader)

    tqm = TaskQueueManager

# Generated at 2022-06-11 10:43:22.809320
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test the method load of class RoleInclude
    """
    print('Test RoleInclude load')
    #
    role_basedir = '/tmp'
    role_name = 'my_role'
    role_path = os.path.join(role_basedir, role_name)
    #
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.role.definition
    p = PlayContext()
    #
    from ansible.playbook.play import Play
    play = Play()
    #
    data = {'name': role_name}
    role = RoleInclude.load(data, play, role_basedir)
    #role = RoleInclude(play=play, role_basedir=role_basedir)
    #role.load_data(data, variable_

# Generated at 2022-06-11 10:43:32.433029
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Verify the old style role requiremnt is rejected by the load method
    from ansible.playbook.role.definition import RoleInclude
    from ansible.parsing.yaml.dumper import AnsibleDumper
    data = 'role1,role2'
    loader = DictDataLoader({'__main__': data})
    ri = RoleInclude()
    try:
        ri.load(data, play='play', current_role_path='/path', parent_role=None, variable_manager='variable_manager', loader=loader)
        assert False, "Should not be able to parse 'role1,role2' as it is an old style role requiremnt."
    except AnsibleError:
        assert True, "AnsibleError was raised"


# Generated at 2022-06-11 10:43:32.942331
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:43:41.966873
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    This test covers all the cases for the method load of class RoleInclude()
    We are validating the returned object (RoleInclude instance)
    """

    ### Testing a string
    data = 'fake_role'
    # Creating a fake play which will be the argument "play"
    class fake_play:
        pass
    play = fake_play()
    # Creating a fake role which will be the argument "parent_role"
    class fake_role:
        def __init__(self):
            self.name = "fake_role"
            self.get_role_dependencies = lambda: []
    parent_role = fake_role()
    # Creating a fake variable manager which will be the argument "variable_manager"
    class fake_variable_manager:
        pass
    variable_manager = fake_variable_manager()
    #

# Generated at 2022-06-11 10:43:50.525613
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test for module load method for class RoleInclude
    # Given
    play=None
    current_role_path=None
    parent_role=None
    loader=None
    variable_manager=None

    # When

    # Test without passing data as a string
    # Then
    try:
        RoleInclude.load(data=[], play=play, current_role_path=current_role_path, parent_role=parent_role, loader=loader,
                         variable_manager=variable_manager)
    except Exception as ex:
        assert str(ex) == "Invalid role definition: []"

    # Test when data is a valid string
    # Then
    data="myrole"

# Generated at 2022-06-11 10:43:51.338099
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, "Not implemented yet"

# Generated at 2022-06-11 10:44:01.388256
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # check if loading a string as role requirement works
    ri = RoleInclude.load("test_role_requirement_load", None, None, None, None, None)
    assert ri.get_name() == "test_role_requirement_load"

    # check if loading an old style requirement will raise an error
    try:
        ri = RoleInclude.load("foo,bar", None, None, None, None, None)
        assert False, 'Expected an AnsibleError exception when no requirement name is given.'
    except Exception as err:
        assert isinstance(err, AnsibleError)

    # check if loading a dictionary with role name will work
    ri = RoleInclude.load({'name': 'test_RoleInclude_load_dict'}, None, None, None, None, None)

# Generated at 2022-06-11 10:44:05.524172
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert ri.load('foo')
    assert ri.load('foo,1.0')
    assert ri.load({'role': 'foo'})
    assert ri.load({'role': 'foo', 'tasks_from': 'main'})
    assert ri.load({'role': 'foo', 'tasks': 'main'})
    assert ri.load({'role': 'foo', 'handlers': 'main'})
    assert ri.load({'role': 'foo', 'vars': 'main'})
    assert ri.load({'role': 'foo', 'defaults': 'main'})
    assert ri.load({'role': 'foo', 'meta': 'main'})
    assert ri.load({'include': 'foo'})
    assert r

# Generated at 2022-06-11 10:44:06.980416
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
# end of test for method load of class RoleInclude


# Generated at 2022-06-11 10:44:18.128280
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import json
    import base64
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars

    with open("test_data/collection_test_load.json", "r") as f:
        test_data = json.load(f)

    vars_manager = HostVars()
    vars_manager.add_host("localhost")
    vars_manager.add_host("otherhost")
    vars_manager.set_host_variable("localhost", "test_var", "TEST_VAR_VALUE")

# Generated at 2022-06-11 10:44:55.134297
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    class Options:
        def __init__(self):
            self.connection = 'local'
            self.module_path = ''
            self.forks = 5
            self.remote_user = 'root'
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None

# Generated at 2022-06-11 10:45:05.809274
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data_list = ["test-role-name",
                 {
                  "role": "test-role-name"
                 },
                 {
                  "role": "test-role-name",
                  "tags": ["test-role-name-1", "test-role-name-2"]
                 },
                 {
                  "role": "test-role-name",
                  "tags": ["test-role-name-1", "test-role-name-2"],
                  "when": "inventory_hostname == 'test-role-name-3'"
                 }
                ]

# Generated at 2022-06-11 10:45:06.653874
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-11 10:45:10.919467
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'foo'
    current_role_path = '/home/user/test/roles/'
    parent_role = 'test'
    variable_manager = 'test'
    loader = 'test'
    collection_list = 'test'
    ri = RoleInclude.load(data, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ri is None

# Generated at 2022-06-11 10:45:20.063437
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    yaml_data = '''
        name: testing
        hosts: all
        roles:
        - test_role_1
        - test_role_2
        '''

    mock_loader = MagicMock()
    mock_variable_manager = MagicMock()
    mock_variable_manager.get_vars.return_value = {}

    play_ctx = PlayContext()
    play = Play().load(yaml_data, variable_manager=mock_variable_manager, loader=mock_loader)

    mock_loader.path_dwim.return_value = '/path/to/role_1'
    mock_loader.path_exists.return_value = True

    role_include = RoleInclude

# Generated at 2022-06-11 10:45:31.157819
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    # inv: AnsibleUnicode with value 'win'
    inv = AnsibleUnicode('win')
    # variable_manager: Attribute with value 'haha'
    variable_manager = Attribute()
    variable_manager.value = 'haha'
    # loader: AnsibleUnicode with value 'hehe'
    loader = AnsibleUnicode('hehe')
    # collection_list: AnsibleSequence
    collection_list = AnsibleSequence()

    ri = RoleInclude()
    rtn = ri.load(inv, variable_manager, loader, collection_list)
    print("rtn:", rtn)
    assert rtn is ri



# Generated at 2022-06-11 10:45:31.974270
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: write unit test
    pass

# Generated at 2022-06-11 10:45:40.992941
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO not do this
    class Play:
        pass
    play = Play()
    play.variable_manager = VariableManager()

    # Test when input data is a dict
    data = dict(name='test', tasks=[dict(name='set name', debug=dict(msg='my name is {{ name }'))])
    ri = RoleInclude(play=play)
    role = ri.load(data)

    assert isinstance(role, RoleInclude)
    assert role.name == 'test'
    assert role.tasks == [dict(name='set name', debug=dict(msg='my name is {{ name }'))]

    # Test when input data is a string
    data = 'test'
    role = ri.load(data)

    assert isinstance(role, RoleInclude)
    assert role.name

# Generated at 2022-06-11 10:45:49.021341
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.errors import AnsibleParserError
    from ansible.module_utils._text import to_text

    data = AnsibleLoader(os.path.relpath('./library/ansible/test/units/data/role_include_args.yml')).get_single_data()
    ri = RoleInclude()
    assert to_text(ri.load(data[0], None)) == '---\ndelegate_to: localhost\ndelegate_facts: true'

# Generated at 2022-06-11 10:45:57.814382
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources="localhost,")
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args='')),
            ]
        )
    play = Play().load(play_source, loader=loader, variable_manager=variable_manager, inventory=inventory)


# Generated at 2022-06-11 10:47:02.074565
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    path = os.path.dirname(os.path.realpath(__file__))+'/../../../../test/unit/module_utils/test_role_loader.yml'
    print(path)
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=path)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    context = PlayContext()
    role_name = 'test'
    role_basedir = '/etc/ansible/roles/'
    data = 'test'
    play = None
    current_role

# Generated at 2022-06-11 10:47:02.517657
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-11 10:47:09.120674
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Host, Inventory

    variable_manager = VariableManager()
    loader = DataLoader()

    host = Host(name="127.0.0.1")
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[host])
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            roles = [
                {'role': 'apache'}
            ]
        )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    assert None == RoleInclude.load(None, play, variable_manager, loader)

# Generated at 2022-06-11 10:47:17.629437
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    fh = open("/home/vaibhav/main.yml", "r")
    data = fh.read()
    fh.close()

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.base import Base
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.module_utils.six import iteritems, string_types
    from ansible.errors import AnsibleError, AnsibleParserError

    if not (isinstance(data, string_types) or isinstance(data, dict) or isinstance(data, AnsibleBaseYAMLObject)):
        raise AnsibleParserError("Invalid role definition: %s" % to_native(data))


# Generated at 2022-06-11 10:47:18.172010
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:47:25.734005
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test case for class RoleInclude, method RoleInclude.load
    # Note: This test case only tests the format of the data returned
    # by method load of class RoleInclude.
    test_data = load_fixture('role_include_load')
    ri = RoleInclude.load(test_data, None)
    # test the members of class RoleInclude
    assert ri.get_name() == test_data['name']
    assert ri.get_role_params() == test_data['role_params']
    assert ri.get_role_path() == test_data['role_path']
    assert ri.get_role_vars() == test_data['role_vars']
    assert ri.get_role_vars_files() == test_data['role_vars_files']


# Generated at 2022-06-11 10:47:27.675680
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    ri = RoleInclude()
    ri.load_data("role: martin_xyz")
    assert ri.get_name() == "martin_xyz"

# Generated at 2022-06-11 10:47:36.848839
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    play_context.network_os = 'ios'
    play_context.remote_addr = '10.10.10.10'
    play_context.port = 22

    current_role_path = os.getcwd()

    data = {
        'name' : 'role1',
        'hosts': 'host1'
    }

    # Instantiate RoleInclude

# Generated at 2022-06-11 10:47:46.010728
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ansible_module_utils = os.path.splitext(os.path.basename(os.path.realpath(__file__)))[0].split('_', 1)[1]
    role_lib_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'modules', '%s' % ansible_module_utils))
    role_def_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'modules'))

# Generated at 2022-06-11 10:47:55.049962
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.module_utils.connection import Connection
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    role_include = "test_role"
    loader = DataLoader()
    hosts = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=hosts)
    play_source =  dict(
        name = "test_role_include_load",
        hosts = 'localhost',
        gather_facts = 'no',
        connection = 'local',
        roles = [dict(name=role_include, tasks=[dict(action=dict(module='shell', args='ls'))])]
    )

    play