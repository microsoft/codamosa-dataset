

# Generated at 2022-06-11 10:39:10.629442
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    
    ##############################################
    # data is str, ',' in data, throw Exception
    ##############################################

    # data is str, ',' in data, throw Exception
    data = "str"
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    try:
        ri.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except Exception as e:
        print(e)
        assert isinstance(e, AnsibleError)

    #########################################

# Generated at 2022-06-11 10:39:12.602662
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

    # if __name__ == '__main__':
    # test_RoleInclude_load()

# Generated at 2022-06-11 10:39:23.570728
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import pytest
    from ansible.playbook.play_context import PlayContext

    def get_link_mock(self, fieldname):
        return None

    def get_host_mock(self, fieldname):
        return None

    def get_task_mock(self, fieldname):
        return None

    # Test with data = "string"
    data = "string"
    play = PlayContext()
    play._set_link = get_link_mock
    play._set_host = get_host_mock
    play._set_task = get_task_mock

    # Test with valid data
    ri = RoleInclude.load(data, play)
    assert ri

    # Test with data = "string,"
    data = "string,"

# Generated at 2022-06-11 10:39:33.801985
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude.load("test_role", None)
    assert ri._role_name == "test_role"
    assert ri._role_path == "test_role"
    assert ri._role_path.startswith("test_role")

    ri = RoleInclude.load("test_role,other=role_parameter", None)
    assert ri._role_name == "test_role"
    assert ri._role_path == "test_role"
    assert ri._role_path.startswith("test_role")
    assert ri._role_params['other'] == 'role_parameter'

    ri = RoleInclude.load({"name":"test_role"}, None)
    assert ri._role_name == "test_role"
    assert ri._role_path

# Generated at 2022-06-11 10:39:43.482095
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-11 10:39:54.857296
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    from ansible.module_utils._text import to_bytes

    from ansible.plugins import plugin_loader as plugin_loader_modules
    import ansible.plugins.loader as plugin_loader
    def get_all_plugin_loaders():
        ''' Returns a dict of all available plugin loaders '''

# Generated at 2022-06-11 10:40:03.682349
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test with a valid role name
    role_name = 'myapp'
    data = role_name
    variable_manager = None
    loader = None
    role_include = RoleInclude.load(data=data, variable_manager=variable_manager, loader=loader)
    assert isinstance(role_include, RoleInclude)

    # Test with an empty string
    data = ''
    variable_manager = None
    loader = None
    try:
        role_include = RoleInclude.load(data=data, variable_manager=variable_manager, loader=loader)
    except AnsibleError:
        pass
    else:
        raise AssertionError('AnsibleError expected')


# Generated at 2022-06-11 10:40:11.968709
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class fake_play(object):
        def __init__(self):
            self.hostvars = dict()

    class fake_data(object):
        def __init__(self):
            self.ROLE_CACHE = dict()
            self.CURRENT_ROLE_PATH = None

    play = fake_play()
    data = fake_data()
    ri = RoleInclude(play=play, role_basedir=data.CURRENT_ROLE_PATH)
    ri.load(data, play, data.CURRENT_ROLE_PATH)

# Unit Test for method get_implied_deps of class RoleInclude

# Generated at 2022-06-11 10:40:19.629925
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    import ansible.constants as C
    from ansible.plugins.loader import action_loader, connection_loader, lookup_loader, module_loader, callback_loader
    display = Display()

# Generated at 2022-06-11 10:40:29.705385
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    ri.load('test')
    ri.load('test[0]')
    ri.load('test[0].subtest')
    ri.load('test[0].subtest[0]')
    ri.load('test[0].subtest[0].subsubtest')
    ri.load('test[0].subtest[0].subsubtest[0]')
    ri.load('test[-1].subtest')
    ri.load('test[-1].subtest[-1].subsubtest')
    ri.load('test[-1].subtest[-1].subsubtest[-1]')

    ansible_module.fail_json(msg='should fail here')

# Generated at 2022-06-11 10:40:40.538678
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # test with no data
    if __name__ == '__main__':
        from ansible.playbook.play import Play
        from ansible.vars import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.parsing.dataloader import DataLoader

        loader = DataLoader()
        vars_manager = VariableManager()
        inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-11 10:40:50.782080
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import ansible

    ri = RoleInclude()

    fake_play = ansible.playbook.play.Play()
    fake_play._variable_manager = ansible.vars.manager.VariableManager()
    fake_play._loader = ansible.parsing.dataloader.DataLoader()

    # Test load with string type
    data = 'testrole'
    result = ri.load(data, fake_play)
    assert isinstance(result, RoleRequirement)
    assert result.name == data
    assert result.role == data

    # Test load with dict type
    data = {'role': 'testrole'}
    result = ri.load(data, fake_play)
    assert isinstance(result, RoleRequirement)
    assert result.name == data['role']
    assert result.role == data

# Generated at 2022-06-11 10:41:01.745471
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    display = Display()
    options = PlaybookExecutor.default_playbook_options()
    loader = DataLoader()
    variable_manager = VariableManager()
    passwords = dict()
    inventory = InventoryManager(loader=loader, sources=['./test/ansible_hosts'])
    playbook_path = './test/test.yml'
    if not os.path.exists(playbook_path):
        print('[INFO] The playbook does not exist')
        sys.exit()
   

# Generated at 2022-06-11 10:41:10.567162
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.module_utils.six import PY3

    # Create play
    myplay = Play().load({
        'name': 'test play',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'vars': {
            'a': 'va',
            'b': 'vb',
        },
    }, variable_manager=VariableManager(), loader=DataLoader())

    # Create an action plugin

# Generated at 2022-06-11 10:41:17.270153
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Raise error when data is not a string or dict
    try:
        RoleInclude.load(data=1,play=None)
        assert False
    except AnsibleParserError as e:
        assert str(e)=="Invalid role definition: 1"

    # Raise error when data is a string and ',' exists in string
    try:
        RoleInclude.load(data="role1, role2",play=None)
        assert False
    except AnsibleError as e:
        assert str(e)=="Invalid old style role requirement: role1, role2"

# Generated at 2022-06-11 10:41:19.107938
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''Unit test for method ``load`` of class ``RoleInclude``
    '''
    pass

# Generated at 2022-06-11 10:41:28.359609
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class Mock(object):
        def __init__(self, x):
            self.x = x

    r = RoleInclude()
    assert r._delegate_to == None
    assert r._delegate_facts == False

    class TestData(object):
        def __init__(self, x, y=None):
            self.x = x
            self.y = y


# Generated at 2022-06-11 10:41:37.814998
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    pm = module_loader.all()

    loader = DataLoader()

    play_context = PlayContext()
    variable_manager = VariableManager()

    role_include = RoleInclude(play=play_context, variable_manager=variable_manager, loader=loader)

    assert role_include.load({}, variable_manager=variable_manager, loader=loader) is False

    assert role_include.load('role_directory_not_exist', variable_manager=variable_manager, loader=loader) is False

# Generated at 2022-06-11 10:41:46.287974
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a RoleInclude object based on a YAML file
    from ansible.plugins.loader import role_loader
    role_loader.resolve_roles_path([])

    from ansible import context
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    play_context = PlayContext()

# Generated at 2022-06-11 10:41:57.516809
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_data = """
    ---
    - hosts: all
      roles:
        - test
        - test2
        - {role: 'test3', tags: ['foo', 'bar']}
        - { role: test4, tags: [ 'foo', 'bar' ] , some_param: 1 }
        - { role: 'test4', some_param: 1 }
        - { role: 'test4', some_param: 1, baz: 'quux' }
        - { role: 'test4', some_param: '{{ a_var }}', baz: 'quux' }
    """
    yamldata = AnsibleLoader(yaml_data, 'test').get_single_

# Generated at 2022-06-11 10:42:00.986748
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-11 10:42:11.730764
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test with invalid data type
    data = 123
    from ansible.playbook import Play
    play = Play().load({}, variable_manager={}, loader={})
    play._variable_manager = {}
    loader = {}
    with pytest.raises(AnsibleParserError) as excinfo:
        role_include = RoleInclude.load(data, play, current_role_path=None, parent_role=None, variable_manager={}, loader={})
    assert 'Invalid role definition' in str(excinfo.value)

    # test with old style role requirement `data`
    data = 'role,role1,role2'

# Generated at 2022-06-11 10:42:21.729380
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    play_context.remote_addr= '127.0.0.1'
    play_context.connection = 'local'
    play_context.remote_user = 'root'
    play_context.port = 22
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.froce_handlers = False
    play_context.no_log = False
    play_context.verbosity = 3
    play_context.check_mode = False
    play_context.diff = False

# Generated at 2022-06-11 10:42:28.985868
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print('Testing RoleInclude_load()')
    import unittest
    import ansible.parsing.dataloader
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.plugins.loader import role_loader

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.parsing.vault.VaultLib(loader=loader)
    play_context = ansible.playbook.play_context.PlayContext()
    play = Play()
    play._variable_manager = variable_manager
    role_basedir = 'role_basedir'
   

# Generated at 2022-06-11 10:42:29.487677
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-11 10:42:40.566787
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = dict()
    data['name'] = 'test_name'
    data['scenario'] = 'test_scenario'
    data['conflict'] = ['test_conflict1', 'test_conflict2']
    data['tags'] = ['test_tags1', 'test_tags2']
    data['connection'] = 'test_connection'
    data['any_errors_fatal'] = True
    data['ignore_errors'] = True
    data['sudo'] = True
    data['sudo_user'] = 'test_sudo_user'
    data['transport'] = 'test_transport'
    data['remote_user'] = 'test_remote_user'
    data['environment'] = ['test_env1', 'test_env2']
    data['no_log'] = True
    data['defaults_from']

# Generated at 2022-06-11 10:42:48.957695
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    host = Host()
    host.set_variable('ansible_python_interpreter', '/usr/bin/python')
    host.set_variable('ansible_connection', 'smart')
    host.set_variable('ansible_shell_type', 'sh')
    host.set_variable('ansible_shell_executable', '/bin/sh')
    host.set_variable('ansible_shell_executable', 'None')

    all = All()
    all.add_child(host)

    defaults = dict(
        name='name',
        connection='connection',
        gather_facts='no',
        become='no',
        become_method='sudo',
        become_user='root',
        become_ask_pass='True',
        vars=dict(),
        tasks=list()
    )

    pb = Play

# Generated at 2022-06-11 10:42:58.449058
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play, Playbook
    from ansible.module_utils.six import PY2
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()

# Generated at 2022-06-11 10:42:58.980159
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:43:09.952035
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    #load a string
    class MockRoleInclude(RoleInclude):
        def load_data(self, data, variable_manager, loader):
            assert self._play == 'play'
            assert self._role_basedir == 'role_basedir'
            assert self._variable_manager == 'variable_manager'
            assert self._loader == 'loader'

    role_include = MockRoleInclude('play', 'role_basedir', 'variable_manager', 'loader')
    result = role_include.load('string', 'play', 'role_basedir', 'parent_role', 'variable_manager', 'loader', None)
    assert result is None

    # load a dict

# Generated at 2022-06-11 10:43:18.626312
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert ri.load('role_name') == 'role_name'
    assert ri.load('role_name,role_name2') == 'role_name,role_name2'

# Generated at 2022-06-11 10:43:29.214515
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Example 1
    ri = RoleInclude()
    assert ri.load({
        'role': 'role1',
        'when': 'a == b and c'
    }, variable_manager=None, loader=None) == True
    assert ri.when == 'a == b and c'
    assert ri.role == 'role1'

    # Example 2
    ri = RoleInclude()
    assert ri.load({
        'name': 'role1',
        'when': 'a == b and c'
    }, variable_manager=None, loader=None) == True
    assert ri.when == 'a == b and c'
    assert ri.role == 'role1'

    # Example 3
    ri = RoleInclude()

# Generated at 2022-06-11 10:43:29.766543
# Unit test for method load of class RoleInclude

# Generated at 2022-06-11 10:43:38.546161
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    This method tests the load method of class RoleInclude.
    """
    from ansible.playbook.playbook import Playbook
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault_password = 'secret'
    vault_secret = 'default'
    vault_filename = '/etc/ansible/vault'


# Generated at 2022-06-11 10:43:39.845690
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert ri.load("", "", "", "", "") == None

# Generated at 2022-06-11 10:43:48.710155
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    data = {"role1":"role_name"}
    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar',
                                   'servers':
                                       {'foo': 'foo.example.org',
                                        'bar': 'bar.example.org'},
                                   'my_hosts': ['foo', 'bar']}
    play_context._variable_manager = variable_manager
    play_context._hostvars = variable_manager.get_vars(Host(name='localhost'))

# Generated at 2022-06-11 10:43:49.889971
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: mock play object
    # TODO: mock load data object
    pass

# Generated at 2022-06-11 10:43:51.790685
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role = RoleInclude()
    assert role.load("test.test") is None
    assert role.load("test,test") is None

# Generated at 2022-06-11 10:44:01.830587
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = [
        {
            'name': 'test1',
            'tasks': [ {'debug': {'msg': 'foo'}}, {'debug': {'msg': 'bar'}} ],
            'vars': {'foo': 'bar'}
        }
    ]
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)


# Generated at 2022-06-11 10:44:12.765534
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # data: A string, dict or AnsibleBaseYAMLObject type
    # role_basedir: A role basedir string
    # play: A play object
    # variable_manager: A variable manager object

    # Set up the result for the role basedir string
    role_basedir = '/home/peter/ansible/ansible_playbooks/roles'

    # Set up the result for the variables dictionary
    variables = dict()
    variables['test_variable1'] = 'value1'
    variables['test_variable2'] = 'value2'
    variables['test_variable3'] = 'value3'

    # Set up the result for the extra_vars dictionary
    extra_vars = dict()
    extra_vars['test_extra_vars'] = 'test_extra_vars_value'

    # Set up

# Generated at 2022-06-11 10:44:26.638980
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
   ''' RoleInclude.load() Unit test '''
   pass


# Generated at 2022-06-11 10:44:36.536089
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = {
        'hosts': 'all',
        'vars': {
            'the_name': 'venkat',
            'the_home': '/home/venkat',
            'the_roles': ['role-1']
        },
        'roles': [
            {
                'role-1': {
                    'name': "{{ the_name }}",
                    'home': "{{ the_home }}",
                    'tasks': [
                        {'debug': {'msg': 'the_name is {{ the_name }}'}}
                    ]
                }
            }
        ]
    }
    from .hosts import Hosts
    from .variable_manager import VariableManager
    from .play import Play
    from .loader import DataLoader
    from .playbook import Playbook
    from .vars import VarsModule

# Generated at 2022-06-11 10:44:40.631505
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    res = None
    try:
        with open(os.path.join(os.path.dirname(__file__), '../ansible/vars/foo.yml')) as f:
            res = RoleInclude.load(f, None)
    except AnsibleError:
        pass
    assert res

# Generated at 2022-06-11 10:44:46.281457
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    roleInclude = RoleInclude.load(
        'rhel-systemd',
        play=None,
        current_role_path=None,
        parent_role=None,
        variable_manager=None,
        loader='loader',
        collection_list=None
    )
    assert roleInclude._name == 'rhel-systemd'
    assert roleInclude._play == None
    assert roleInclude._role_basedir == None
    assert roleInclude._variable_manager == None
    assert roleInclude._loader == 'loader'

# Generated at 2022-06-11 10:44:47.279689
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: write more tests
    pass

# Generated at 2022-06-11 10:44:57.083708
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.data import AnsibleUnicode
    assert not isinstance(RoleInclude.load({'role': 'test'}, play='play', current_role_path='/test/test', parent_role=None, variable_manager=None,
                                           loader=None, collection_list=None), RoleRequirement)
    assert not isinstance(RoleInclude.load('test', play='play', current_role_path='/test/test', parent_role=None, variable_manager=None,
                                           loader=None, collection_list=None), RoleRequirement)

# Generated at 2022-06-11 10:45:07.027777
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    templar = Templar(loader=None, shared_loader_object=None, variables=None)
    variable_manager = VariableManager()


# Generated at 2022-06-11 10:45:15.491414
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # called with a string, that is not a dict or AnsibleBaseYAMLObject, as data
    # AnsibleParserError is thrown
    data = 'ansible'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources="localhost,")
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

# Generated at 2022-06-11 10:45:24.375917
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Setup
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    data = {
             "name" : "test_role"
            }
    # Execute
    result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    # Verify
    assert isinstance(result, RoleInclude)
    assert result.name == 'test_role'
    assert len(result.get_dependency_graph().nodes()) == 1
    # Cleanup - none necessary



# Generated at 2022-06-11 10:45:26.188309
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: write unit test for method load of class RoleInclude
    raise NotImplementedError


# Generated at 2022-06-11 10:45:51.464014
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:46:01.377234
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test for method load of class RoleInclude
    """

    # Test with string
    role_include = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None)
    data = {'name': 'test_role'}
    role_include.load_data(data, variable_manager=None, loader=None)

    # Test with dict
    role_include = RoleInclude(play=None, role_basedir=None, variable_manager=None, loader=None)
    data = 'test_role'
    role_include.load_data(data, variable_manager=None, loader=None)

    # Test with AnsibleBaseYAMLObject

# Generated at 2022-06-11 10:46:08.375743
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    play_context = PlayContext()

# Generated at 2022-06-11 10:46:13.574876
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.module_utils.six import string_types

    # Execute the method load of class RoleInclude
    data = {  # Update the yaml as per your system
        "name": "vi_update",
        "src": "git+https://github.com/geerlingguy/ansible-role-vi.git",
        "scm": "git",
        "version": "v1.0.0"
    }
    # Creating role_basedir path
    role_basedir = os.path.join(os.getcwd(), "../../../../lib/ansible/playbook/roles/")
    # Creating play object

# Generated at 2022-06-11 10:46:20.059382
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
#    import json
#    from ansible.playbook.tests.unit.test_include_role import read_vars_file, read_text_file
#    from ansible.playbook.tests.unit.test_include_role import BLOCK_VARS, BLOCK_TASK, BLOCK_UNKNOWN, BLOCK_META, BLOCK_HANDLER
#    from ansible.playbook.tests.unit.test_include_role import FOO_VARS, FOO_TASK, FOO_UNKNOWN, FOO_META, FOO_HANDLER
#    from ansible.playbook.tests.unit.test_include_role import ANSIBLE_SELINUX, FOO_SELINUX, BAR_SELINUX
#    from ansible.playbook.tests.unit.test

# Generated at 2022-06-11 10:46:20.814332
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO impelment unit test
    pass

# Generated at 2022-06-11 10:46:28.042841
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.taggable import Taggable
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    import os,yaml,json
    TEST_PATH = os.path.dirname(__file__)
    display = Display()
    options = {'verbosity': 3}
    loader = DataLoader()

# Generated at 2022-06-11 10:46:35.580003
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import os
    import sys
    import unittest

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import PY3

    from ansible.module_utils import basic
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text
    
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.become import Become
    from ansible.playbook.connection import ConnectionBase

# Generated at 2022-06-11 10:46:42.610792
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import sys
    import os
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    #the role definition in v2

# Generated at 2022-06-11 10:46:43.308223
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert RoleInclude.load('string', None)

# Generated at 2022-06-11 10:47:43.779607
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a mock object of class Attribute
    attr = Attribute()
    ri = RoleInclude(attr)

    data = 33
    collection_list = ['test', 'test1']

    # Test for class RoleInclude with invalid data type
    try:
        assert ri.load(data, None, None, None, attr, attr, collection_list)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    data = 'test1,test2'
    # Test for class RoleInclude with invalid data type
    try:
        assert ri.load(data, None, None, None, attr, attr, collection_list)
    except Exception as e:
        assert isinstance(e, AnsibleError)

    data = {'test1': 'test2'}
   

# Generated at 2022-06-11 10:47:52.822069
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common._collections_compat import IterableUserDict

# Generated at 2022-06-11 10:47:57.407387
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = {}
    data = ""
    try:
        print("test_RoleInclude_load() expects AnsibleParserError")
        ri = RoleInclude.load(data, play)
    except AnsibleParserError:
        pass
    except:
        print("test_RoleInclude_load() failed")
    

# Generated at 2022-06-11 10:48:06.929686
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import collections

    assert RoleInclude.load('test', None, None, None, None, None) == None

    assert RoleInclude.load([1], None, None, None, None, None) == None

    assert RoleInclude.load({}, None, None, None, None, None) == None

    assert RoleInclude.load('test,test2', None, None, None, None, None) == None

    play = collections.OrderedDict([('name', 'test')])

    assert RoleInclude.load('test', play, None, None, None, None)._role_name == 'test'

    assert RoleInclude.load('test1', play, None, None, None, None)._role_name == 'test1'


# Generated at 2022-06-11 10:48:07.928925
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: create test
    assert False

# Generated at 2022-06-11 10:48:15.429534
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import _get_role_definition_params

    role_path = 'role_path'
    data = {'roles': ['role1']}
    play = None

    ri = RoleInclude.load(data, play, current_role_path=role_path)

    assert isinstance(ri, RoleInclude)
    assert ri._role_path == role_path
    assert ri.get_name() == 'role1'
    assert ri._role_collection_list == []

    # role name with role path - role name SHOULD be only role name part
    data = {'roles': ['role1/role1']}
    ri = RoleInclude.load(data, play, current_role_path=role_path)
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-11 10:48:23.049638
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    class Play:
        def __init__(self, loader=None, variable_manager=None, play_context=None):
            self._loader = loader
            self._variable_manager = variable_manager
            self._play_context = play_context

    play = Play(loader=loader, variable_manager=variable_manager, play_context=play_context)


# Generated at 2022-06-11 10:48:30.409024
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    import ansible.utils.vars as ans_vars
    # Setup fake data
    data = ['test_role']
    pc = PlayContext()
    pc.remote_addr = '127.0.0.1'
    pc.port = '22'
    pc.remote_user = 'test_user'
    pc.password = 'testing'
    # Setup fake Loader
    loader = DataLoader()

    # Test string type
    result = RoleInclude.load(data, pc)
    assert isinstance(result, RoleDefinition)

    # Test list
    data = ['test_role', 'other_role']
    result = RoleInclude.load(data, pc)
    assert isinstance

# Generated at 2022-06-11 10:48:39.307061
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Load RoleInclude for testing
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager

    play = Play.load(dict(
        name="Ansible Generated",
        hosts=["all"],
        roles=["test_role_1", "test_role_2"]
    ), variable_manager=VariableManager(), loader=DataLoader())

    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    display = Display()
    tqm = None

# Generated at 2022-06-11 10:48:41.782906
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    test_data = "test.test"

    ri = RoleInclude()
    ri.load_data(test_data)

    assert ri._role_name == test_data
    assert ri._role_path is None
    assert ri._role_params is None