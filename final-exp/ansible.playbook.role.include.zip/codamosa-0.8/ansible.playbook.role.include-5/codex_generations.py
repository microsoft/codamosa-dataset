

# Generated at 2022-06-11 10:39:10.915615
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.cli.playbook.playbook_cli import PlaybookCLI
    from ansible.executor.playbook_executor import PlaybookExecutor
    _loader = DataLoader()
    _variable_manager = VariableManager()

# Generated at 2022-06-11 10:39:13.596948
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    This test is for class RoleInclude and method load.
    """
    pass


    #assert ri == RoleInclude()

# Generated at 2022-06-11 10:39:14.350521
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:39:25.124277
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import sys
    #sys.path.append('../lib/ansible/playbook')
    #sys.path.append('../lib/ansible/module_utils')
    from ansible.playbook.play import Play
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    try:
        from ansible.module_utils.ansible_release import __version__ as ANSIBLE_VERSION
    except ImportError:
        # For Ansible 1.9 or older
        from ansible.release import __version__ as ANSIBLE_VERSION
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar

# Generated at 2022-06-11 10:39:34.834557
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import os
    import tempfile
    import shutil
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.role.definition import RoleDefinition

    # Create a temporary directory to use as the directory
    # containing the roles and create a trivial role
    tmp_dir = tempfile.mkdtemp()
    role_dir = os.path.join(tmp_dir, 'role1')
    os.makedirs(role_dir)
    with open(os.path.join(role_dir, 'main.yml'), 'w') as f:
        f.write("""---
        foo: bar
        """)

   

# Generated at 2022-06-11 10:39:45.081545
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play

    data = "name"

    ri = RoleInclude.load(data, play = Play().load(dict()))
    assert ri.get_name() == "name"
    assert ri.get_role_path() == "./"
    assert ri.get_path() == "./"

    data = dict(
        name = "name",
    )

    ri = RoleInclude.load(data, play = Play().load(dict()))
    assert ri.get_name() == "name"
    assert ri.get_role_path() == "./"
    assert ri.get_path() == "./"

    data = dict(
        name = "name",
        role_path = "/path/to/role"
    )

    ri

# Generated at 2022-06-11 10:39:56.173402
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test case:

    on:
      - block1
    tasks:
      - name: task1
        debug: msg="task1"
      - block:
        - name: task2
          debug: msg="task2"
        rescue:
        - name: task3
          debug: msg="task3"
        always:
        - name: task4
          debug: msg="task4"
    """

    # Load play into memory.
    play_file = os.path.join(os.path.dirname(__file__), 'test_plays', 'test_play_block.yaml')
    play_source = open(play_file).read()
    play_data = {}
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    tqm

# Generated at 2022-06-11 10:40:03.444749
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    temp = dict()
    temp['role_name'] = 'test_role_name'
    temp['_delegate_to'] = 'test_delegate_to'
    temp['_delegate_facts'] = 'test_delegate_facts'
    temp['_role_path'] = 'test_role_path'
    temp['_role_name'] = 'test_role_name'
    ri = RoleInclude()
    result = ri.load(temp, variable_manager='test_variable_manager', loader='test_loader')
    assert result.__dict__ == temp

# Generated at 2022-06-11 10:40:04.042197
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:40:09.523636
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "myrole"
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    ans = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ans.__class__.__name__ == "RoleInclude"

# Generated at 2022-06-11 10:40:13.588453
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    obj = RoleInclude()
    assert isinstance(obj, RoleInclude)

# Generated at 2022-06-11 10:40:20.554855
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible import context
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader, cache_loader, callback_loader, connection_loader, lookup_loader, module_loader, strategy_loader, test_loader
    mock_loader, inventory, variable_manager, loader, play_context = mock_loader()

# Generated at 2022-06-11 10:40:29.807208
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # TODO: Rewrite this test
    # 'when' is a reserved word for Roles and throws an error using the 'when' keyword
    from ansible.playbook.task import Task
    data = dict(
        name = 'test',
        tasks = [
            dict(
                action = dict(
                    module = 'shell',
                    args   = "echo hi"
                )
            )
        ]
    )
    play = {}
    current_role_path = {}
    parent_role = {}
    variable_manager = {}
    loader = {}
    collection_list = {}
    role = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

# Generated at 2022-06-11 10:40:36.327590
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {
        'name': 'test',
        'defaults': {'test': 'test2'},
    }
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list=None
    role_definition = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert role_definition.get_name() == 'test'

# Generated at 2022-06-11 10:40:43.774800
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("##### RoleInclude_load Method Test starts here #####")
    import yaml
    # SAMPLE DATA
    # Old data in a single string
    old_data_1 = 'ansible.builtin.apt ansible.builtin.yum' # Simple format
    old_data_2 = 'ansible.builtin.apt,ansible.builtin.yum' # Test for a ',' in requirement
    old_data_3 = 'ansible.builtin.apt ansible.builtin.yum ansible.builtin.git ansible.builtin.unarchive' # Long format
    old_data_4 = 'ansible.builtin.apt,ansible.builtin.yum,ansible.builtin.git,ansible.builtin.unarchive' # Test for a ',' in requirement
    old_data_5

# Generated at 2022-06-11 10:40:56.023191
# Unit test for method load of class RoleInclude

# Generated at 2022-06-11 10:40:56.412171
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:41:04.346104
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()

    try:
        data = True
        ri.load(data, play=None, current_role_path=None, parent_role=None)
        raise AssertionError("RoleInclude load method accepts True.")
    except (AnsibleParserError, AssertionError) as e:
        assert(str(e) == "Invalid role definition: True")

    try:
        data = 0.1
        ri.load(data, play=None, current_role_path=None, parent_role=None)
        raise AssertionError("RoleInclude load method accepts 0.1.")
    except (AnsibleParserError, AssertionError) as e:
        assert(str(e) == "Invalid role definition: 0.1")


# Generated at 2022-06-11 10:41:13.171466
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import ansible.playbook
    import ansible.constants
    from units.mock.loader import DictDataLoader

    old_basedir = ansible.constants.DEFAULT_ROLES_PATH
    old_roles_path = ansible.constants.DEFAULT_ROLES_PATH

    ansible.constants.DEFAULT_ROLES_PATH = '/doesnotexist'
    current_role_path = os.path.join(os.path.dirname(__file__), 'roles', 'a_role')

# Generated at 2022-06-11 10:41:23.186732
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Create array of test data
    test_data = [
        {
            "data": "role_name",
            "exception": AnsibleError,
        },
        {
            "data": ["role_name"],
            "exception": AnsibleError,
        },
        {
            "data": {},
            "exception": AnsibleParserError,
        },
        {
            "data": {
                "role": "role_name"
            }
        }
    ]
    # Iterate through the test data
    for test in test_data:
        with pytest.raises(test["exception"]):
            ri = RoleInclude(play=play)
            ri.load(test["data"], variable_manager=variable_manager, loader=loader)

# Load test data

# Generated at 2022-06-11 10:41:26.425721
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:41:27.066294
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:41:37.527678
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude()
    result = role_include.load("role", play="play", current_role_path="path", parent_role="parent", variable_manager="variable", loader="loader")
    assert result.role_name == "role"
    assert result.play == "play"
    assert result.role_path == "path"
    assert result.parent.name == "parent"
    assert result.variable_manager == "variable"
    assert result.loader == "loader"

    with pytest.raises(AnsibleError, match="Invalid old style role requirement"):
        role_include.load("role,role", play="play", current_role_path="path", parent_role="parent", variable_manager="variable", loader="loader")


# Generated at 2022-06-11 10:41:43.963382
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.six.moves import StringIO
    from ansible.errors import AnsibleParserError
    from ansible.playbook.role.requirement import RoleRequirement

    data_loader = DataLoader()

    ## PlaybookExecutor setup
    inventory = InventoryManager(data_loader, 'localhost,')
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)


# Generated at 2022-06-11 10:41:44.603340
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:41:55.931046
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # Load the RoleInclude class
    class_load = RoleInclude()

    # Create the fake data to load
    data1 = 'name'
    data2 = 'name,foo=bar'
    data3 = {'name': 'name'}
    data4 = {'name': 'name', 'foo': 'bar'}

    # Create the dummy Play object
    play = Play()
    play.name = 'fake_play'
    play

# Generated at 2022-06-11 10:42:03.856113
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = dict(
        name="common",
        include=dict(
            role="myrole"
        ),
    )
    # TODO: make this test to pass
    # ansible_playbook_variable_manager = VariableManager()
    # ansible_playbook_loader = DataLoader()
    #
    # ansible_include = RoleInclude()
    # ansible_role = ansible_include.load(data, ansible_playbook_variable_manager, ansible_playbook_loader)
    #
    # assert(ansible_role is not None)
    # assert(ansible_role.get_name() == "common")

#def test_RoleInclude_load_to_fail():
#    import pytest
#    from ansible.errors import AnsibleError
#    from ansible.module_utils

# Generated at 2022-06-11 10:42:14.451546
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play

    from ansible.playbook.role import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    play = Play()
    current_role_path = ''
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    #
    # Test if 'data' is a string type.
    #
    data_str = "my_role"
    ri = RoleInclude.load(data_str, play=play, current_role_path=current_role_path, parent_role=parent_role,
                          variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-11 10:42:24.298612
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class Play:
        def __init__(self):
            self.vars = dict()
    class Loader:
        class MockVarsModule:
            plugin_type = 'vars'
            def __init__(self):
                self.vars = dict()
        def get_basedir(self):
            return "."
        def find_plugin(self, plugin_name, plugin_type=None):
            return self.MockVarsModule()

    play = Play()
    loader = Loader()

    role_name = 'testrole'

    # Simple role name
    role_data = role_name
    role = RoleInclude.load(data=role_data, play=play, variable_manager=None, loader=loader)
    assert role.get_name() == role_name

    # Fully qualified role name
   

# Generated at 2022-06-11 10:42:30.163487
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    variable_manager = VariableManager()
    loader = DataLoader()
    role_include = RoleInclude.load('geerlingguy.apache', variable_manager=variable_manager, loader=loader)
    assert isinstance(role_include, RoleRequirement)

    role_include = RoleInclude.load('geerlingguy.apache,1.0', variable_manager=variable_manager, loader=loader)
    assert isinstance(role_include, RoleRequirement)

    role_include = RoleInclude.load('geerlingguy.apache, src=somesource, version=1.0', variable_manager=variable_manager, loader=loader)
    assert isinstance(role_include, RoleRequirement)

    data = {'role': 'geerlingguy.apache'}

# Generated at 2022-06-11 10:42:36.379217
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
# Test method load of class RoleInclude

# Generated at 2022-06-11 10:42:36.918757
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False

# Generated at 2022-06-11 10:42:39.422576
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # FIXME: unit tests should not have external imports
    #from ansible.module_utils.six import iteritems
    pass
# /Unit test for method load of class RoleInclude

# Generated at 2022-06-11 10:42:40.998957
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

if __name__ == "__main__":
    test_RoleInclude_load()

# Generated at 2022-06-11 10:42:49.326773
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class MockVariableManager:
        def __init__(self):
            self.extra_vars = {'key': 'value'}

    class MockLoader:
        def get_real_file(self, filename):
            return

    class MockPlay:
        def __init__(self, include_role):
            self.include_role = include_role
            self.variable_manager = MockVariableManager()
            self.loader = MockLoader()

    class MockRoleDefinition:
        def __init__(self, play, role_basedir, variable_manager, loader, collection_list):
            self.play = play
            self.role_basedir = role_basedir
            self.variable_manager = variable_manager
            self.loader = loader
            self.collection_list = collection_list


# Generated at 2022-06-11 10:42:53.078100
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    variable_manager = VariableManager()
    loader = DataLoader()
    role = RoleInclude.load('role1,role2',play=play, current_role_path=None,\
                            parent_role=None, variable_manager=variable_manager, loader=loader, collection_list=None)

# Generated at 2022-06-11 10:42:57.259805
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    item = RoleInclude()
    assert not item.load(data = 1, play = None)
    assert not item.load(data = 'aaa,bbb', play = None)

    # assert not item.load(data = 'aaa', play = None)
    # print(item)



# Generated at 2022-06-11 10:43:08.139472
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play.load(dict(name='test'), variable_manager=variable_manager, loader=loader)
    role_basedir = os.path.join(os.getcwd(), 'tests/lib/ansible/playbook/test_data/test_roles')

    parent_role = {'name': 'test_role'}
    ri = RoleInclude(play=play, role_basedir=role_basedir,
                     variable_manager=variable_manager, loader=loader)

    # string type
    # assert can't create instance of class RoleInclude with string type

# Generated at 2022-06-11 10:43:15.643364
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    current_role_path = os.path.join(os.getcwd(), 'test/data/roles/test_role_1')
    play = Play().load(dict(
        name = "Ansible Play test_RoleInclude_load",
        hosts = 'testhost',
        roles = [
            "test_role_1",
            dict(
                name="test_role_2",
                tasks=[
                    dict(action=dict(module='debug', args=dict(msg="Hello World!")))
                ]
            )
        ]
    ), VariableManager(), DataLoader(), None)

# Generated at 2022-06-11 10:43:25.929768
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a RoleInclude object
    ri = RoleInclude()
    # Define data needed by the role

# Generated at 2022-06-11 10:43:45.011820
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_dir=os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    tmp_path = os.path.join(role_dir, 'gcp/roles/gcp/tasks/main.yml')
    tmp_file = open(tmp_path, 'r')
    i_load = tmp_file.read()
    print(i_load)
    print('\n\n')
    tmp_file.close()

    #ansible.parsing.yaml.objects.AnsibleBaseYAMLObject
    tmp_yaml = yaml.safe_load(i_load)
    print(tmp_yaml)
    print('\n\n')

    #ansible.playbook.play.Play
    #tmp_play = Play()
    #

# Generated at 2022-06-11 10:43:53.712124
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.play
    import ansible.playbook.role.definition
    import ansible.module_utils.six
    import ansible.parsing.yaml.loader
    import collections
    import six

    loader = ansible.parsing.yaml.loader.AnsibleLoader

    # Create mock objects
    play = ansible.playbook.play.Play()
    parent_role = ansible.playbook.role.definition.RoleDefinition()
    variable_manager = collections.Mock(spec=ansible.vars.manager.VariableManager)
    collection_list = collections.Mock(spec=ansible.utils.collection_loader.CollectionLoader)

    # Create instance of RoleInclude

# Generated at 2022-06-11 10:44:03.857072
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from .mock import patch

    from ansible.errors import AnsibleError
    from ansible.playbook.role import RoleRequirement

    yaml_obj = {'when': 'foo',
                'name': 'role_name',
                'tags': ['one', 'two', 'three'],
                'tasks': {'one': {},
                          'two': {}},
                'handlers': {'one': {},
                             'two': {}}}

    yaml_role_requirement = 'role_name, foo'

    # Load the test cases

# Generated at 2022-06-11 10:44:15.403729
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test with invalid data
    data = ['item1', 'item2']
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    try:
        RoleInclude.load(data, play, current_role_path, parent_role,
                         variable_manager, loader, collection_list)
    except Exception as e:
        assert e.args[0] == "Invalid role definition: [u'item1', u'item2']"

    # Test with string
    data = "test_role"
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None


# Generated at 2022-06-11 10:44:23.141524
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a RoleInclude object
    play_obj = {}
    current_role_path = "myrole"
    parent_role = "myparent"
    loader = {}
    variable_manager = {}
    collection_list = {}
    role_include = RoleInclude.load(current_role_path, play_obj, current_role_path, parent_role, variable_manager, loader, collection_list)
    # Assert attributes of the created object
    assert role_include is not None
    assert not role_include._dep_errors
    assert not role_include._dep_warnings
    assert (role_include.get_path() == 'myrole')
    assert (role_include.get_parent_role_path() == 'myparent')
    assert role_include._play == play_obj

# Generated at 2022-06-11 10:44:33.849636
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Setup
    test_play = "fake_play"
    test_current_role_path = "fake_current_role_path"
    test_parent_role = "fake_parent_role"
    test_variable_manager = "fake_variable_manager"
    test_loader = "fake_loader"
    test_collection_list = "fake_collection_list"

    test_data_array = ["fake_data_array_string",
                       "fake_data_array_string2",
                       ]

    # Exercise
    ri = RoleInclude()

    # Verify

# Generated at 2022-06-11 10:44:43.109081
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.dataloader import DataLoader

    ####################################################################################################################
    #
    # test_RoleInclude_load_1
    #
    # tests: method load of class RoleInclude:
    #            data = string_types
    #
    ####################################################################################################################
    # Create a global variable_manager
    variable_manager = VariableManager()
    # Create a host_vars dict

# Generated at 2022-06-11 10:44:43.784986
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:44:50.899456
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test with input as string
    data1 = "test_string"
    # expected result
    ri1 = RoleInclude()

    # test with input as dict
    data2 = {"tasks/main.yml": "test_dict"}
    # expected result
    ri2 = RoleInclude()

    # test with input as AnsibleBaseYAMLObject
    data3 = "test_AnsibleBaseYAMLObject"
    # expected result
    ri3 = RoleInclude()

    # test the failure case for input as AnsibleBaseYAMLObject
    data4 = "test_AnsibleBaseYAMLObject"
    # expected result
    ri4 = RoleInclude()



# Generated at 2022-06-11 10:44:52.207409
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude.load('ansible.linux-system-roles.ntp',Play())

# Generated at 2022-06-11 10:45:14.492338
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: Need to write unit tests for this method and class
    assert True

# Generated at 2022-06-11 10:45:16.238153
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test load
    """
    # Test with a string
    assert True

    # Test with a dict
    assert True



# Generated at 2022-06-11 10:45:17.749385
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, "FIXME: implement test for 'load' method"

# Generated at 2022-06-11 10:45:23.975321
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude.load("not_a_string_type", "not_a_string_type")
    RoleInclude.load(["not_a_string_type"], "not_a_string_type")
    try:
        RoleInclude.load("not_a_string_type,not_a_string_type", "not_a_string_type")
        assert False
    except:
        assert True

# Generated at 2022-06-11 10:45:33.734711
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import DEFAULT_HASH_BEHAVIOUR
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from os.path import dirname, join, realpath

    # Create a dummy Playbook object
    loader = DataLoader()
    play_source_dict = {}
    play_source_dict['name'] = 'foo bar'
    play_source_dict['hosts'] = 'all'
    play_source_dict['gather_facts'] = 'no'
    play_source_dict['roles']

# Generated at 2022-06-11 10:45:42.597072
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    ri = RoleInclude()

    # Test case 1 :
    try:
        ri.load(["a", "b"], None, None, None, None, None)
        assert False
    except AnsibleError:
        assert True

    # Test case 2 :
    try:
        ri.load(True, None, None, None, None, None)
        assert False
    except AnsibleParserError:
        assert True

    # Test case 3 :

# Generated at 2022-06-11 10:45:50.649911
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    data = {'name': 'webservers',
            'vars': {'a': '1', 'b': '2'},
            'tags': {'a', 'b'},
            'default_vars': {'a': '3'},
            'remote_user': 'admin',
            'become': True,
            'become_user': 'root'
            }
    ri.load_data(data)
    assert ri._name == 'webservers'
    assert ri._vars == {'a': '1', 'b': '2'}
    assert ri._tags == {'a', 'b'}
    assert ri._default_vars == {'a': '3'}
    assert ri._remote_user == 'admin'

# Generated at 2022-06-11 10:46:00.391378
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.utils.collection_loader import AnsibleCollectionRequirement

    role_path = 'roles/somerole'
    role_basedir = '.'
    role_name = 'somerole'
    role_def = 'somealias'
    role_vars = dict(somevar='somevalue')
    role_vars2 = dict(somevar2='somevalue2')
    role_tasks = ['some task', 'some task2']
    role_defaults = dict(somevar3='somevalue3')
    role_tasks2 = ['some task', 'some task2', 'some task3']
    role_meta = dict

# Generated at 2022-06-11 10:46:04.276446
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude.load('web,geerlingguy.java,1.8.0', play=1, current_role_path=None, parent_role=None, variable_manager=1, loader=1, collection_list=1)
    assert role_include.get_name() == 'geerlingguy.java'


# Generated at 2022-06-11 10:46:05.021701
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
# vim: set et sta:

# Generated at 2022-06-11 10:46:57.243791
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert ri.load('basic.role') == {'role': 'basic.role'}
    assert ri.load({'role': 'basic.role'}) == {'role': 'basic.role'}
    assert ri.load(AnsibleBaseYAMLObject('basic.role')) == {'role': 'basic.role'}
    assert ri.load(os.path.sep.join(['basic.role', 'tasks', 'main.yml'])) == {'role': 'basic.role', 'tasks': 'tasks/main.yml'}

# Generated at 2022-06-11 10:46:57.984120
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-11 10:46:58.435727
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:46:58.968564
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:46:59.441151
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:47:06.145189
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a test RoleInclude instance
    ri = RoleInclude()

    # Check that the data cannot be None
    data = None
    try:
        ri.load_data(data)
    except AnsibleParserError:
        pass
    else:
        # The exception was not raised
        assert False, "The data cannot be None"

    # Check that the data cannot be a list
    data = []
    try:
        ri.load_data(data)
    except AnsibleParserError:
        pass
    else:
        # The exception was not raised
        assert False, "The data cannot be a list"

    # Check that the data cannot be a dict with an unknown key
    data = {'unknown_key': 'value'}

# Generated at 2022-06-11 10:47:07.985369
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.requirement import RoleRequirement
    assert RoleInclude.load('foo', 'bar') == RoleInclude.load(RoleRequirement('foo'), 'bar')

# Generated at 2022-06-11 10:47:10.806811
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print ("Executing unit test for: load method of class RoleInclude")
    isset = False
    try:
        ri = RoleInclude()
        ri.load(None, None)
    except TypeError as e:
        print (e)
        isset = True
    finally:
        assert isset == True
print ("Unit test run completed")

# Generated at 2022-06-11 10:47:11.822326
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO
    pass


# Generated at 2022-06-11 10:47:20.577048
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import os
    import unittest
    import ansible.parsing.yaml.objects

    data = {'name': 'fake'}

    class FakePlay(object):
        def __init__(self):
            self._variable_manager = None

    class FakeVariableManager(object):
        def __init__(self):
            self._fact_cache = dict()
            self.extra_vars = dict()
            self.options_vars = dict()

    class FakeLoader(object):
        def __init__(self):
            self._basedirs = ['/root/fake']
            self._collection_list = ['a', 'b']

        def path_dwim_relative(self, basedir, path):
            return '%s/%s' % (basedir, path)
