

# Generated at 2022-06-11 10:39:10.546043
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # RoleInclude.load() returns a RoleInclude object with populated field 'action'
    # RoleInclude.load() raises an AnsibleError("Invalid old style role requirement") when it gets a role name with a comma
    # RoleInclude.load() raises an AnsibleParserError("Invalid role definition") when it gets an invalid role name or role_name: role_args pair

    # For now, just make sure the methods don't raise exceptions
    # TODO: test this with real arguments

    RoleInclude.load(data="role_name1", play="", current_role_path="", parent_role="",
                     variable_manager="", loader="", collection_list="")

# Generated at 2022-06-11 10:39:21.783705
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.executor import task_queue_manager
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    loader = C.DEFAULT_LOADER

    variable_manager = VariableManager()

    # Create the inventory and pass to var manager
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

    pb = Play().load(dict(
        name="Ansible Play",
        hosts=['all'],
        gather_facts='no',
        roles='apache',
        tasks=[
            dict(action=dict(module='setup', args=''))
        ]
    ), variable_manager=variable_manager, loader=loader)

    pb.RO

# Generated at 2022-06-11 10:39:27.901174
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # RoleInclude.load(data, play, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    ri = RoleInclude()
    result = ri.load(data=None, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert result is None

# Generated at 2022-06-11 10:39:36.622999
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.executor import task_queue_manager
    from ansible.module_utils.six import StringIO
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.tasks import Task
    from ansible.template import Templar

    data = dict(
        name='test',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='MOCK'))),
            dict(action=dict(module='debug', args=dict(msg='MOCK')))
        ]
    )

    ri = RoleInclude.load(data, play=Play())
    assert ri.name == 'test'
    assert ri._role_path == ''

# Generated at 2022-06-11 10:39:37.880479
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test that load method of RoleInclude loads a role
    pass

# Generated at 2022-06-11 10:39:39.616973
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude.load(None, None, None, None, None, None)


# Generated at 2022-06-11 10:39:51.062786
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext

    class BaseTestRoleInclude(RoleDefinition):
        name = FieldAttribute(isa='string')

    ri = BaseTestRoleInclude()
    with pytest.raises(AnsibleParserError):
        ri.load('my role', None)

    ri = BaseTestRoleInclude()
    ri.load_data('my role', variable_manager=None, loader=None)

    assert ri.name == "my role"

    ri = BaseTestRoleInclude()
    with pytest.raises(AnsibleParserError):
        ri.load_data({})

    data = dict(
        name='my role',
        other_attribute='my other attribute'
    )

   

# Generated at 2022-06-11 10:40:01.487984
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ''' Unit test for method load of class RoleInclude '''

    # import needed modules
    from ansible.playbook.play import Play
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # init needed objects

    class playbook:
        class vault_password:
            pass

        class connection:
            pass

        class network:
            pass

       

# Generated at 2022-06-11 10:40:11.727573
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Test load of class RoleInclude"""

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager


    def _create_unsafe_vardict(self, play=None, host=None, include_hostvars=False, include_delegate_to=False):
        variable_manager = self._variable_manager

        if not play:
            play = variable_manager._play

        # this happens when we are calling a module directly
        # without a play (ie. command or shell)
        if not host:
            host = variable_manager

# Generated at 2022-06-11 10:40:19.460004
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    var_manager = 'var_manager'
    loader = 'loader'

    # test exception "Invalid old style role requirement"
    data = ','
    play = 'play'
    current_role_path = 'current_role_path'
    parent_role = 'parent_role'
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, var_manager, loader)
    except AnsibleError:
        pass
    else:
        raise Exception("AnsibleError is not raised")

    # test exception "Invalid role definition"
    non_string_types = [4, [], {}, set()]

# Generated at 2022-06-11 10:40:31.127467
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars

    # Create a dictionary of data for testing
    data = dict(
        name='common',
        become='True',
        become_user='root',
        tasks=[
            dict(
                name='Expand hostvars',
                debug=dict(
                    var="{{hostvars}}"
                )
            )
        ]
    )

    # Convert the dictionary to a AnsibleBaseYAMLObject
    data = AnsibleBaseYAMLObject(data)

    # Create VariableManager and InventoryManager objects
    variable_manager = VariableManager()


# Generated at 2022-06-11 10:40:40.577544
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader, inventory, variable_manager = setup_loader()

    ri = RoleInclude()
    play_context = PlayContext()
    play_source =  dict(
            name = "Ansible Play 1",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )

# Generated at 2022-06-11 10:40:50.782707
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from pprint import pprint

    data1 = 'ansible.apache'
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    ri = RoleInclude(play=None, role_basedir=None, variable_manager=variable_manager, loader=loader, collection_list=None)
    assert ri.load_data(data1)['name'] == 'apache'

    # ansible.apache,ansible.base,ansible.mys

# Generated at 2022-06-11 10:41:01.746112
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data1 = "name1"
    data2 = {"role": "name2"}
    data3 = {"name": "name3"}
    data4 = "name4, name5"
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)


# Generated at 2022-06-11 10:41:10.567681
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()

    ri = RoleInclude(play=play_context, variable_manager=variable_manager, loader=loader)

    # using instance of class to test
    role_include_test_1 = ri.load('apollo-test', current_role_path='/usr/share/ansible/roles', variable_manager=variable_manager, loader=loader)
    assert role_include_test_1._role_name == 'apollo-test'

# Generated at 2022-06-11 10:41:20.182849
# Unit test for method load of class RoleInclude

# Generated at 2022-06-11 10:41:29.285316
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import os
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    my_tasks = [ Task() for x in range(0, 5) ]

    my_block = Block(
        block=my_tasks
    )

    my_handlers = [ Task() for x in range(0, 5) ]
    my_block.post_validate(my_handlers, [])

    play1 = Play()
    play1.post_validate([my_block], [])

    path = os.path.dirname(__file__)

# Generated at 2022-06-11 10:41:38.986242
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    play = Play.load(dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ), loader=DataLoader(), variable_manager=VariableManager())

    ri = RoleInclude(play=play, role_basedir="path")
    ri.load('name', variable_manager=VariableManager())

# Generated at 2022-06-11 10:41:44.716313
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.loader import role_loader
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.yaml import objects

    from io import StringIO

    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.task import Task
    from ansible.template import Templar

    loader = role_loader
    collection_list = ['ansible.builtin']


# Generated at 2022-06-11 10:41:56.021370
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # First test that only valid data types are accepted
    # TODO: make this test atomic
    for data in [None, [], 1234, 0.23, 1.34e+12]:
        try:
            RoleInclude.load(data, None)
            raise AssertionError('Invalid data type accepted')
        except AnsibleParserError:
            pass

    # Test that incorrect usage of include_role raises an error
    for data in ['role1', 'role1, role2']:
        try:
            RoleInclude.load(data, None)
            raise AssertionError('Invalid include_role usage accepted')
        except AnsibleError:
            pass

    # Test correct usage of include_role
    RoleInclude.load('role1', None)
    RoleInclude.load('role1,role2', None)