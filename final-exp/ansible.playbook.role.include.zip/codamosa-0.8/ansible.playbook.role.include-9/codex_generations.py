

# Generated at 2022-06-11 10:39:10.299788
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play_source =  dict(
        name = "Ansible Play 0",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
        )


# Generated at 2022-06-11 10:39:21.452242
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    loader_mock = MagicMock()
    variable_manager_mock = MagicMock()
    collection_list_mock = MagicMock()
    current_role_path = '.'
    play = collections.namedtuple('Play', 'hosts')
    play.hosts = []

    role_include = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager_mock, loader=loader_mock, collection_list=collection_list_mock)
    role_include.load_data = MagicMock()

    data = 'test_data'
    ri = RoleInclude.load(data, play, current_role_path, variable_manager=variable_manager_mock, loader=loader_mock, collection_list=collection_list_mock)
   

# Generated at 2022-06-11 10:39:24.971914
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include = RoleInclude.load("geerlingguy.apache", "geerlingguy.apache", ".", "test_role", None, None, None)
    assert role_include.get_name() == "geerlingguy.apache"

# Generated at 2022-06-11 10:39:27.006851
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role = RoleInclude.load('test_role')
    assert role.get_name() == 'test_role'

# Generated at 2022-06-11 10:39:36.054275
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test to Load role definition
    """
    role_def = RoleInclude()
    # First test case with string type
    data = "role_name"
    variable_manager = 'variable_manager'
    try:
        result = role_def.load(data, variable_manager=variable_manager)
        assert result is None
    except AnsibleError as exception:
        assert 'Invalid role definition' in exception.message
    # Second test case with dict type
    data = dict()
    data['name'] = 'test'
    try:
        result = role_def.load(data, variable_manager=variable_manager)
        assert result is None
    except AnsibleError as exception:
        assert 'Invalid role definition' in exception.message
    # Third test case with AnsibleBaseYAMLObject type
    data = Ansible

# Generated at 2022-06-11 10:39:47.013807
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )


# Generated at 2022-06-11 10:39:57.827756
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.playbook.block import Block

    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play().load({
        'name': 'test',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'roles': [
            {'role': './role'},
            {'role': 'role1', 'tags': ['test1', 'test2']},
            {'role': 'role2', 'tasks': [
                {'debug': 'test'}
            ]},
        ]
    }, variable_manager=variable_manager, loader=loader)
    block = play.get

# Generated at 2022-06-11 10:40:07.948444
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Unit test for method load of class RoleInclude"""
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader, lookup_loader, cache_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    import yaml

    yaml_doc = """
    - name: Configure NTP
      hosts: all
      remote_user: root

      tasks:
      - name: include role to configure NTP
        include_role:
            name: ntp
            become: yes
            become_user: root
            tasks_from: ntp.yml
"""
    yaml_data = yaml.safe_load(yaml_doc)

    play_context = PlayContext()

    # Initialize a variable manager

# Generated at 2022-06-11 10:40:10.462463
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        RoleInclude.load(None)
    except Exception as err:
        print("exception as expected: "+str(err))

    RoleInclude.load("",None)

# Generated at 2022-06-11 10:40:13.683256
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    result = ri.load(["test_string"], play=None, parent_role=None)
    assert isinstance(result, RoleInclude)
    assert result._role_name == "test_string"

# Generated at 2022-06-11 10:40:21.352362
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test for a string without any comma
    data = "a.b.c"
    ret = RoleInclude.load(data)
    assert ret is not None
    assert ret.get_name() == "a.b.c"
    assert ret.get_role_path() is None

    # Test for a string with comma
    data = "a.b.c,v1.0"
    try:
        ret = RoleInclude.load(data)
        assert False
    except AnsibleError:
        pass

    # Test for a old style role requirement
    data = "a.b.c,v1.0"
    try:
        ret = RoleInclude.load(data)
        assert False
    except AnsibleError:
        pass

    # Test for a dict

# Generated at 2022-06-11 10:40:31.571918
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils.six import iteritems
    import os
    import pprint
    import importlib

    # Load the playbook
    pb_path=os.path.join('tests/sanity/playbooks', 'test_include_role.yml')
    loader = DataLoader()
    inv_path=os.path.join('tests/sanity/inventory', 'test_include_role.yml')
    inventory = InventoryManager(loader, sources=[inv_path])
    var_manager = VariableManager

# Generated at 2022-06-11 10:40:40.937809
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Testing isinstance(data, dict)
    data = dict(name='common')
    loader = None
    variable_manager = None
    play = None
    collection_list = None
    current_role_path = None
    parent_role = None
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    # Testing isinstance(data, string_types)
    data = 'common'
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ri._role_name == 'common'
    assert ri._role_path is None

    # Testing isinstance(data, AnsibleBaseYAMLObject)
    data = AnsibleBaseYAMLObject

# Generated at 2022-06-11 10:40:51.657170
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()

    # This is a simple test case to test the RoleInclude.load method.
    # The test code is replaced by the code in the playbook object unit test.
    # To run the test, execute this file as a python script
    # from ansible/lib/ansible/playbook/__init__.py
    #
    # Expected results:
    #
    # Ok: RoleInclude.load() - {
    # 'role': 'common',
    # 'name': 'Common role for all machines',
    # 'tasks': [
    # {'action': {

# Generated at 2022-06-11 10:40:52.588053
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:41:02.625337
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 10:41:08.945509
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.role.definition
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader

    ri = RoleInclude()
    assert (type(ri) == RoleInclude)

    data1 = {'foo': 'bar'}
    with pytest.raises(AnsibleParserError) as excinfo:
        ri.load_data(data1)
    assert 'Invalid role definition' in str(excinfo.value)



# Generated at 2022-06-11 10:41:18.089798
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # test case for role name in a string
    data = 'role_a'
    play = Play()
    role_basedir = '/path/to/role_basedir'
    collection_list = [AnsibleCollectionRef.from_ansible_collection('ansible.collection.foo', AnsibleCollectionRef.CollectionRequirement.minimum('1.0.0'))]
    ri = RoleInclude.load(data, play=play, current_role_path=role_basedir, collection_list=collection_list)

    assert ri.name == 'role_a'
    assert ri.role_basedir == role_basedir
    assert ri.collection_list == collection_list
    # role_a

# Generated at 2022-06-11 10:41:24.484903
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variables = VariableManager(loader=loader, inventory=inventory)

    result = RoleInclude.load('test', 'play', 'role_basedir', 'parent_role', variables, loader)
    assert isinstance(result, RoleInclude)

# Generated at 2022-06-11 10:41:34.532731
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible.playbook.role.definition
    import ansible.parsing.dataloader
    import ansible.inventory.host
    import ansible.vars.manager
    import ansible.playbook.play
    data = { u'name': u'foo', 'role_path': u'bar'}
    role_base_dir = '/baz'
    variable_manager = ansible.vars.manager.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    host = ansible.inventory.host.Host()
    play = ansible.playbook.play.Play(loader=loader, variable_manager=variable_manager, host=host)

# Generated at 2022-06-11 10:41:43.319401
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.template import Templar

    data = dict(
        name="foobar",
        validate_certs=False
    )

    play = Play().load(dict(
        name = "test play",
        hosts = 'webservers',
        gather_facts = 'no',
        roles = [ data ],
    ), variable_manager=dict(), loader=dict())

    role_include = RoleInclude.load(data, play)

    assert isinstance(role_include, RoleInclude)
    assert not isinstance(role_include, RoleRequirement)



# Generated at 2022-06-11 10:41:45.476646
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "miyagawa.role-x"
    ri = RoleInclude()
    ri.load(data)



# Generated at 2022-06-11 10:41:55.266883
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.vars import VariableManager

    play = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'roles': [
            'geerlingguy.jedit',
            {
                'role': 'geerlingguy.java',
                'java_packages': ['icedtea-7-jre-jamvm'],
            },
            'geerlingguy.mysql',
        ],
    }, variable_manager=VariableManager(), loader=None)

    for included_role in play.get_roles():
        assert isinstance(included_role, RoleInclude)

# Generated at 2022-06-11 10:41:55.887897
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:41:56.451962
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-11 10:42:00.246864
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ret = RoleInclude.load(
        data={'name' : 'myrole'},
        play=None,
        current_role_path=None,
        parent_role=None,
        variable_manager=None,
        loader=None,
        collection_list=None)
    assert ret == None

# Generated at 2022-06-11 10:42:05.854011
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    p = MockPlay()
    vm = MockVars()
    l = MockLoader()
    ri.load(data="role1", play=p, variable_manager=vm, loader=l)
    assert "role1" in p._tasks
    assert "role1" in p._roles


# Generated at 2022-06-11 10:42:15.786268
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.Requirement import RoleRequirement
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import pytest
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from io import StringIO
    import os


# Generated at 2022-06-11 10:42:16.374793
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:42:25.622390
# Unit test for method load of class RoleInclude

# Generated at 2022-06-11 10:42:41.351871
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Try to instantiate a RoleInclude object using an integer
    # This should raise an error
    data = 1
    play = 'my_play'
    current_role_path = 'my_role'
    parent_role = 'my_role'
    variable_manager = 'my_var'
    loader = 'my_loader'
    collection_list = 'my_collections'
    try:
        ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleError as err:
        assert 'Invalid role definition:' in str(err)

    # Try to instantiate a RoleInclude object using a list
    # This should raise an error
    data = [1, 2, 3]
    play = 'my_play'
    current

# Generated at 2022-06-11 10:42:49.524922
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    host_list = [
        'localhost',
    ]

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=host_list)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    playbook_path = './test_data/test_cases/test_role_include_load/role1'

# Generated at 2022-06-11 10:42:59.366760
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    yaml_snippet = """
    ---
    - role: 'example.foo'
      tasks:
        - name: task 1
          ping:
      handlers:
        - name: handler 1
          ping:
    """

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext

    from ansible.template import Templar

    class DummyLoader:
        def load_from_file(self, filename):
            return AnsibleLoader(yaml_snippet).get_single_data()

    class DummyPlay:
        def __init__(self):
            self.context = PlayContext()
            self.loader = DummyLoader()
            self.variable_manager = Templar()


# Generated at 2022-06-11 10:43:10.140740
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.facts.collector import BaseFactCollector

    playbook_path = os.path.join(os.path.dirname(__file__), '../../../test/unit/module_utils/test_role_include_load.yml')
    loader, inventory, variable_manager = Play().load_playbook_from_file(playbook_path)
    hosts = inventory.get_hosts()
    hosts[0].set_variable('ansible_os_family', 'RedHat')
    hosts[0].set_variable('ansible_architecture', 'x86_64')

# Generated at 2022-06-11 10:43:11.150113
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # not implemented
    return True

# Generated at 2022-06-11 10:43:16.805733
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # test load dict data
    print('test load dict data')
    data = dict(role='role')
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    # test load string data
    print('test load string data')
    data = 'role'
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    # test load object data
    print('test load object data')
    data = AnsibleBaseYAMLObject()

# Generated at 2022-06-11 10:43:26.957991
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    role_include = RoleInclude()

    # test load with string type
    data = "test_role_include"
    result = role_include.load(data=data, play=PlayContext(), variable_manager=variable_manager, loader=loader)
    assert result and isinstance(result, RoleInclude)

    # test load with dict type
    data = dict(name="test_role_include")

# Generated at 2022-06-11 10:43:36.153009
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test case 1: Invalid role definition
    role_data = None
    play = "play"
    current_role_path = "current_role_path"
    parent_role = "parent_role"
    variable_manager = "variable_manager"
    loader = "loader"
    collection_list = "collection_list"
    success = False
    try:
        role_include = RoleInclude.load(role_data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except Exception as e:
        if isinstance(e, AnsibleParserError) and str(e) == "Invalid role definition: None":
            success = True
    assert success
    
    # Test case 2: Invalid old style role requirement
    role_data = "role_name,role_file"
    success

# Generated at 2022-06-11 10:43:45.237342
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import shutil
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.playbook.play_context import PlayContext

    # XXX: I have no idea what's up with this class.  This is
    # just a placeholder in case I need it later to do any
    # emulation of whatever it is this class is actually doing.
    class Mock(object):
        pass


# Generated at 2022-06-11 10:43:53.938805
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a mock object for class RoleInclude
    # The object will get it class attribute
    # from the mock object created in the class FieldAttribute
    ri = RoleInclude()
    # Create a mock object for class FieldAttribute
    # and mock it class attribute isa
    class AttributeMock(Attribute):
        isa = "string"

    class FieldAttributeMock():
        def __get__(self, instance, owner):
            return AttributeMock

    role_definition_instance = RoleDefinition()
    role_definition_instance.FieldAttribute = FieldAttributeMock()

    # Store the class RoleDefinition in the class RoleInclude
    # to make possible to iterate over fields of the class RoleDefinition
    # to get the name and type of the field
    ri.RoleDefinition = role_definition_instance
    # Create a mock object