

# Generated at 2022-06-11 10:39:03.588342
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert not ri.load(data=1)
    assert not ri.load(data="this,is,an,invalid,role,requirement")

# Generated at 2022-06-11 10:39:04.622391
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, "NO test for method load of class RoleInclude"


# Generated at 2022-06-11 10:39:13.937014
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    data = {
        'role': 'a',
        'with_items': ['a'],
    }
    yaml_data = AnsibleDumper().dump(data, Dumper=AnsibleDumper)
    parsed_yaml_data = AnsibleLoader(yaml_data, file_name=None).get_single_data()
    assert type(parsed_yaml_data) is dict
    assert len(parsed_yaml_data) == 1

# Generated at 2022-06-11 10:39:24.731094
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # test with string data
    data = 'geerlingguy.mysql'
    play = ParentClass()
    current_role_path = '/home/roles/geerlingguy.mysql'
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ri._role_name == 'geerlingguy.mysql'
    assert ri._role_path == '/home/roles/geerlingguy.mysql'
    assert ri._role_params == {}

    # test with string data with comma
    data_str_comma = 'geerlingguy.mysql,foo=bar'
    play = Parent

# Generated at 2022-06-11 10:39:34.573574
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Imports needed for the test
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.utils.display import Display

    display = Display()
    variable_manager = VariableManager()
    loader = DataLoader()

    # Test for when data is an empty string
    data = ''
    play = Play()
    play.role_path = []
    loader.set_basedir('./')
    current_role_path = './'
    with pytest.raises(AnsibleParserError) as excinfo:
        RoleInclude.load(data, play, current_role_path, variable_manager=variable_manager, loader=loader)
    assert "Invalid role definition:" in str(excinfo.value)

    # Test for when data is a comma-

# Generated at 2022-06-11 10:39:44.372675
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
    #_RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__RoleInclude_load_data__Role

# Generated at 2022-06-11 10:39:50.614923
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    data = dict(
        name="test-role",
        tasks=dict(
            test=dict(
                ping=dict()
            )
        )
    )

    ri = RoleInclude.load(data, None)

    assert 'name' in ri._attributes
    assert 'tasks' in ri._attributes
    assert ri._attributes['name'] == 'test-role'



# Generated at 2022-06-11 10:39:59.049202
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class FakeVariableManager(object):
        pass
    class FakeLoader(object):
        pass
    class FakePlay(object):
        pass
    class FakeCollectionList(object):
        pass
    input_data = 'https://github.com/my-role.git'
    play_object = FakePlay()
    variable_manager = FakeVariableManager()
    data = {'name': 'my-role'}
    loader = FakeLoader()
    collection_list = FakeCollectionList()
    ri = RoleInclude.load(input_data, play_object, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-11 10:40:08.873913
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test case for load method of class RoleInclude
    """
    data = {'role1': {'description': 'A description'}}
    play = 'play1'
    current_role_path = '/usr/ansible'
    parent_role = 'role2'
    variable_manager = 'var1'
    loader = 'loader1'
    collection_list = []
    role_include = RoleInclude(play, current_role_path, variable_manager, loader, collection_list)
    for key, val in iteritems(data['role1']):
        msg = "RoleInclude.load() failed to update '%s' attribute."
        assert getattr(role_include, '_' + key) == val, msg % key
    return True


# Generated at 2022-06-11 10:40:17.722787
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play

    loader, inventory, variable_manager = ansible_playbook_test_support()

    play_path = '../../../test/playbooks/priorities.yml'

    play_context = dict()
    play_source = dict(name=play_path, hosts='all', gather_facts='no', vars=[])
    pb = Play.load(play_source, loader=loader, variable_manager=variable_manager, play_context=play_context)

    result = []
    for role in pb.get_roles():
        play_context = dict()
        role_path = role['role_path']
        role_name = role['name']

# Generated at 2022-06-11 10:40:21.010990
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert 1 == 1

# Generated at 2022-06-11 10:40:22.105417
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    req = RoleRequirement.load()

# Generated at 2022-06-11 10:40:32.211324
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.role.definition import RoleDefinition

    current_role_path = "/path/to/role"
    parent_role = None
    ri = RoleInclude()


# Generated at 2022-06-11 10:40:33.822771
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # set up simple object and ensure it has expected values
    assert False # TODO: Write a test case here

# Generated at 2022-06-11 10:40:35.012460
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-11 10:40:43.141527
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    loader = DataLoader()
    inventory = None
    variable_manager = None
    play = Play().load(dict(name='test', hosts=[], gather_facts='no', roles=['foo', 'bar']), loader=loader, variable_manager=variable_manager, loader_cache=dict())
    role_basedir='roles'
    role_names=['foo', 'bar']
    for role_name in role_names:
        path = os.path.join(role_basedir, role_name)
        if path not in loader._search_paths['roles']:
            loader.path_dwim_relative

# Generated at 2022-06-11 10:40:55.127114
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    data = None

    # Testing if data is string type and ',' is in data
    data = "role1,role2"
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleError:
        assert True
    else:
        assert False

    # Testing if data is not string, dict or AnsibleBaseYAMLObject
    data = []
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleParserError:
        assert True
   

# Generated at 2022-06-11 10:41:03.809460
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.role import role
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.utils.path import path_dwim
    import datetime
    import os
    import pprint

    # Instantiate objects
    ansible_loader = AnsibleLoader(None, None)
    ansible_loader.set_basedir("/tmp/test_collection")
    ansible_loader.set_collection_playbook_path("/tmp/test_collection/test_playbook.yml")

    role_name = 'test-role'
    role_path = path_dwim("/tmp/test_collection/roles/%s" % role_name)

# Generated at 2022-06-11 10:41:12.637652
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test load: data is either a string or an object
    def test_data_is_str(mocker):
        mock_data = mocker.patch('ansible.parsing.mod_args.AnsibleModuleArgSpec')
        mock_data.__contains__ = mocker.MagicMock(return_value=True)
        mock_data.__setitem__ = mocker.MagicMock(return_value=True)

        mock_play = mocker.patch('ansible.playbook.play_context.PlayContext')
        mock_play.DEFAULT_ROLES_PATH = 'ansible/roles'

        mocker.patch('ansible.parsing.dataloader.DataLoader')
        mock_role_basedir = mocker.patch('ansible.playbook.role.definition.RoleDefinition')

# Generated at 2022-06-11 10:41:13.215589
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:41:27.737477
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Testing the load method of RoleInclude class when the data is a valid string
    string_data = "test_role"
    play = object()
    current_role_path = object()
    parent_role = object()
    variable_manager = object()
    loader = object()
    collection_list = object()
    test_role = RoleInclude.load(data=string_data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager,
                         loader=loader, collection_list=collection_list)
    assert test_role._role_name == "test_role"
    assert test_role._role_path == current_role_path

    # Testing the load method of RoleInclude class when the data is a valid string

# Generated at 2022-06-11 10:41:34.622131
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "apache"
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    ret = RoleInclude.load(data=data, play=play, current_role_path=current_role_path,
                              parent_role=parent_role, variable_manager=variable_manager, loader=loader,
                              collection_list=collection_list)

    assert isinstance(ret, RoleInclude)

# Generated at 2022-06-11 10:41:42.614346
# Unit test for method load of class RoleInclude

# Generated at 2022-06-11 10:41:53.885560
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    really_long_role_name = 'really-long-role-name-that-is-more-than-1024-bytes'

    for role_name in ['example-role', really_long_role_name]:
        trivial_role_definition = {
            'name': role_name,
            'tasks': {
                'main': {
                    'local_action': 'echo "Hello world!"'
                }
            },
        }
        variable_manager.set_nonpersistent_facts({
            'role_name': role_name
        })

       

# Generated at 2022-06-11 10:41:57.811673
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_include_instance = RoleInclude.load('roles/web', play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert role_include_instance._role_name == 'web'


# Generated at 2022-06-11 10:42:04.841493
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    RoleInclude: Test method load()
    """
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    path = os.getcwd()

    loader = AnsibleLoader(None, True)
    play_context = PlayContext()
    variables = VariableManager(loader=loader, play_context=play_context)

# Generated at 2022-06-11 10:42:11.646811
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Initialize all parameters for method
    data = None
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    expected_result = None

    # Determine if the method returns the expected value
    actual_result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert expected_result == actual_result




# Generated at 2022-06-11 10:42:21.651235
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 10:42:28.962687
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())

# Generated at 2022-06-11 10:42:39.876314
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    ri.load_data('test-role')
    assert ri.get_name() == 'test-role'

    try:
        ri.load_data('test-role,1.2.3')
        raise AssertionError('RoleInclude.load() should throw AnsibleError on role definition with version')
    except AnsibleError:
        pass

    ri.load_data('test-role,v1.2.3')
    assert ri.get_name() == 'test-role'
    assert ri.get_version() == 'v1.2.3'


# Generated at 2022-06-11 10:43:02.250841
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test role format 'name', 'name:default'
    role = RoleInclude.load('name', play=None, current_role_path=None, parent_role=None,
                            variable_manager=None, loader=None, collection_list=None)
    assert role.get_name() == 'name'
    assert role.get_role_path() == 'name'
    assert role.get_collections() == []
    assert role.get_default_vars() == dict()

    role = RoleInclude.load('name:default', play=None, current_role_path=None, parent_role=None,
                            variable_manager=None, loader=None, collection_list=None)
    assert role.get_name() == 'name'
    assert role.get_role_path() == 'name'

# Generated at 2022-06-11 10:43:12.303262
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import role_loader
    from ansible.module_utils.six import PY3, iteritems
    try:
        from __main__ import display

        # Note: this try block is only needed when running the unit tests using
        # `python -m test.units.test_role_include`
        display = display
    except ImportError:
        from ansible.utils.display import Display

        display = Display()


# Generated at 2022-06-11 10:43:22.193887
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.playbook.play_context import PlayContext

    # Get a fake PlaybookExecutor and a fake Playbook
    pbex = PlaybookExecutor()
    pbex.loader = DataLoader()
    pbex.inventory = InventoryManager(loader=pbex.loader, sources=[])
    pbex.variable_manager = VariableManager(loader=pbex.loader, inventory=pbex.inventory)

# Generated at 2022-06-11 10:43:23.610001
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: add unit test for method load of class RoleInclude
    pass

# Generated at 2022-06-11 10:43:30.816219
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # It should not raise an AnsibleError when load a valid old style role
    RoleInclude.load('test_role')
    try:
        RoleInclude.load('test_role,test_namespace')
    except AnsibleError:
        assert True
    else:
        assert False
    # It should not raise an AnsibleParserError when load a valid new style role
    RoleInclude.load({'role': 'test_role'})
    RoleInclude.load({'role': 'test_role', 'namespace': 'test_namespace', 'name': 'test_name'})

# Generated at 2022-06-11 10:43:32.014568
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Make following tests pass
    assert True

# Generated at 2022-06-11 10:43:40.639349
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.utils.vars import load_extra_vars
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=None, options=None)
    play = Play().load({'name': 'test_play', 'hosts': 'localhost', 'gather_facts': 'no', 'tasks': []}, variable_manager=variable_manager, loader=None)
    play_context = PlayContext()
    role_include = RoleInclude(play=play, role_basedir=None, variable_manager=variable_manager, loader=None)
    data_test1 = 'test_role'
    data_test2

# Generated at 2022-06-11 10:43:43.506609
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # We can't test this method since it is dependent on class RoleDefinition which is also
    # dependent on class Attribute. It means that if we try to make the objects, they will
    # return the error.
    pass

# Generated at 2022-06-11 10:43:51.997984
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.template import Templar
    add_all_plugin_dirs()
    import collections

    path = os.path.dirname(os.path.abspath(__file__))

    d = collections.OrderedDict()
    d['name'] = 'testRole'
    d['hosts'] = '127.0.0.1'

# Generated at 2022-06-11 10:44:02.044493
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play = Play()
    play_context = PlayContext()
    play_context.CLIARGS = dict()
    play._play_context = play_context

    play.set_loader(Loader())
    play.set_variable_manager(VariableManager())

    data = dict(when="{{ ansible_distribution == 'CentOS' }}")
    ri = RoleInclude(play=play)
    #assert(ri.load(data).__dict__ == data)

# Generated at 2022-06-11 10:44:34.435729
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'role_name'
    play = MyPlay()
    current_role_path = 'roles'
    parent_role = 'my_parent_role'
    variable_manager = 'my_variable_manager'
    loader = 'my_loader'
    collection_list = 'my_collection_list'

    ####
    # Test 1: data is not a string_types or a dict. AnsibleParserError is raised.
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ri is None

# Generated at 2022-06-11 10:44:43.858104
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    This is the test for the method load in class RoleInclude
    """

    print("\n")
    print("Testing load method")
    print("==================")

    # Load the test data
    fname = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test_data', 'role_include', 'test_data.yml')
    with open(fname,'rb') as role_include_test_data:
        data = role_include_test_data.read()

    # Import ansible modules to be used in the test
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # create the loader and load the test data

# Generated at 2022-06-11 10:44:47.963401
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test role include load
    """
    data = "abcd"
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    ri = RoleInclude.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role,
                          variable_manager=variable_manager, loader=loader)
    assert(isinstance(ri, RoleInclude))


# Generated at 2022-06-11 10:44:48.550614
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:44:51.712675
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    with pytest.raises(AnsibleError) as e:
        ri = RoleInclude()
        assert ri.load("role1,role2", None)
    assert "Invalid old style role requirement" in str(e)

# Generated at 2022-06-11 10:45:01.872457
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module="ping")),
        ]
    )

    # Create play object to initialize loader
    play = Play().load(play_source, variable_manager=VariableManager(), loader=None)
    loader = play._loader

    current_role_path = "/home/user/ansible_workspace/ansible-role-test"


# Generated at 2022-06-11 10:45:03.183335
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude
    assert True

# Generated at 2022-06-11 10:45:11.562902
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # String role
    role = RoleInclude.load(
        data='test',
        play=None,
        current_role_path=None,
        parent_role=None,
        variable_manager=None,
        loader=None,
        collection_list=None
    )
    assert isinstance(role, RoleRequirement)

    # List of string roles
    role = RoleInclude.load(
        data=['test_site', 'test_role.name'],
        play=None,
        current_role_path=None,
        parent_role=None,
        variable_manager=None,
        loader=None,
        collection_list=None
    )
    assert isinstance(role, RoleRequirement)
    assert len(role.roles) == 2

    # Dict roles
    role = RoleInclude

# Generated at 2022-06-11 10:45:21.103963
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    test_play = dict(
        name = 'test play',
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ foo }} is set to {{ foo }}')))
        ]
    )

    test_role_def = dict(
        name = 'test role',
        description = 'test description',
        default_vars = dict(foo='bar'),
        vars = dict(baz='baz'),
        tasks = [
            dict(action=dict(module='setup'))
        ]
    )

    test_role = RoleInclude(play=test_play)

# Generated at 2022-06-11 10:45:31.789834
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts import Facts
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    # Put the fake role path in the role_path
    fake_role_path = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', '..', 'test_utils', 'roles'))
    assert isinstance(fake_role_path, string_types)
    facts = Facts()
    facts.setup(play_context=PlayContext(), variables=VariableManager())
    fake_

# Generated at 2022-06-11 10:46:30.870878
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''Unit test for method load of class RoleInclude'''

    # 1. Check errors on parsing
    data = ['abc', [1], 123]
    for input in data:
        try:
            RoleInclude.load(input, play, current_role_path, parent_role, variable_manager, loader)
            print('The test for method load of class RoleInclude failed!')
        except:
            pass

    # 2. Check errors on parsing role requirement
    data = '''test%test,test'''
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader)
        print('The test for method load of class RoleInclude failed!')
    except:
        pass

# Generated at 2022-06-11 10:46:38.554635
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    playbook_path = os.path.join(cur_dir, '../../../../lib/ansible/playbook/playbooks')
    play_data = dict(
        name='test_playbook'
    )
    play = Play().load(play_data, variable_manager=None, loader=None)
    data = dict(
        name='test_role_include_load'
    )
    ri = RoleInclude(play=play, role_basedir=playbook_path, variable_manager=None, loader=None)
    assert ri.load(data, play, current_role_path=playbook_path, parent_role=None, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:46:45.555047
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """ Check that RoleInclude.load() works correctly with multiple roles
        as input.
        Tests for the following type of inputs
        - string
        - dict as input
        - list as input with valid and invalid values
    """

    from ansible.playbook import Play
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    valid_string_list = [
        'role1',
        'role2',
        'role3',
        'role4',
        'role5'
    ]

    invalid_string_list = [
        'role',
        'role,role2',
        'role1,role2,role3'
    ]


# Generated at 2022-06-11 10:46:51.631844
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Case1:
    data = 'test'
    play = object()
    current_role_path = '.'
    parent_role = object()
    variable_manager = object()
    loader = object()
    collection_list = object()
    expected_result = None
    returned_result = None
    try:
        RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleError as result:
        returned_result = result.args
    assert expected_result == returned_result

    # Case2:
    data = 'test, test2'
    play = object()
    current_role_path = '.'
    parent_role = object()
    variable_manager = object()
    loader = object()
    collection_list = object()


# Generated at 2022-06-11 10:46:52.494388
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-11 10:47:00.313709
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    mock_loader = None
    mock_collection_list = None
    mock_play_context = PlayContext()
    mock_variable_manager = VariableManager()


    data1 = ''' - name: foo
                role: bar
              '''
    expected1 = {'name': 'foo', 'role': 'bar'}

    data2 = ''' - name: foo
                role: bar
                delegate_to: localhost
              '''
    expected2 = {'name': 'foo', 'role': 'bar', 'delegate_to': 'localhost'}

    data3 = "foobar"
    expected3 = "foobar"

    data4 = 1
    expected4 = 1

    data5 = None
   

# Generated at 2022-06-11 10:47:06.969191
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.play import Play
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-11 10:47:13.990754
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.required_collection import RoleRequirementSpec
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["test/test_role_include.yml"])
    play_source =  dict(
            name = "test play",
            hosts = 'testhost',
            gather_facts = 'no',
            roles = [
                dict(name='test_role_1'),
            ]
        )


# Generated at 2022-06-11 10:47:22.785196
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader, callback_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from units.mock.vars import VariableManager


# Generated at 2022-06-11 10:47:30.193200
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play
    from ansible.module_utils.common.collections import ImmutableDict

    data = '''
    - include_role:
        name: example_role1
        tasks_from: example_task1
        vars_from: example_vars
    '''
    result = RoleInclude.load(data=data, play=None)
    assert(isinstance(result, list))
    assert(isinstance(result[0], RoleInclude))
    assert(result[0]._role_name == 'example_role1')
    assert(result[0]._role_path == 'example_role1')
    assert(result[0]._role_params == ImmutableDict(tasks_from='example_task1', vars_from='example_vars'))