

# Generated at 2022-06-11 10:39:11.079947
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play  # The import of RoleInclude and RoleDefinition cause an import loop
    from ansible.vars.manager import VariableManager  # So we import these classes here
                                                     # For more info, see https://stackoverflow.com/a/52785008/3787889
    variable_manager = VariableManager()
    loader = None
    current_role_path = "../"
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    role_definition = RoleInclude.load(None, play=play, current_role_path=current_role_path, variable_manager=variable_manager, loader=loader)
    assert role_definition == None

# Generated at 2022-06-11 10:39:19.252181
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    input_data = """
    - name: some_role
    - foo: bar
    """

    # load data
    role_include = RoleInclude.load(input_data, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert role_include is not None

    # check data
    assert role_include.get_name() == 'some_role'
    assert role_include.get_vars() == dict(foo="bar")

# Generated at 2022-06-11 10:39:29.709202
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = dict(
      port=22,
      become_user='root',
      become_method='sudo'
    )

    v = VariableManager()
    v.extra_vars = dict(
      ansible_connection='ssh',
      ansible_ssh_user='jansible',
      ansible_ssh_pass='V3rys3cr3t',
      ansible_ssh_port=22
    )

# Generated at 2022-06-11 10:39:37.595427
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    class TestPlay(object):
        def __init__(self, connection, become_user, become_method, become_pass, user_namespace):
            self._connection = connection
            self._become_user = become_user
            self._become_method = become_method
            self._become_pass = become_pass
            self._user_namespace = user_namespace

        def set_become_plugin(self, become):
            pass

        connection = property(lambda self: self._connection)
        become_user = property(lambda self: self._become_user)
        become_method = property(lambda self: self._become_method)
        become_pass = property(lambda self: self._become_pass)

# Generated at 2022-06-11 10:39:48.723220
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'app'
    play = mock.Mock()
    current_role_path = ''
    parent_role = mock.Mock()
    variable_manager = mock.Mock()
    loader = mock.Mock()
    collection_list = mock.Mock()

    # Case 1
    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert isinstance(ri, RoleInclude)
    assert isinstance(ri.get_name(), list)
    assert isinstance(ri.get_task_blocks(), list)

    # Case 2
    data = 'a,b,c'

# Generated at 2022-06-11 10:39:59.345286
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: AnsibleBaseYAMLObject can't be created here
    # Only create simple dict object
    dict_obj_data = dict()
    dict_obj_data['role_name'] = 'test_role'
    dict_obj_data['role_path'] = 'test_role_path'
    dict_obj_data['scenario'] = 'test_scenario'
    dict_obj_data['role_tags'] = dict()
    dict_obj_data['role_tags']['tag1'] = 'tag1'
    dict_obj_data['role_tasks'] = 'test_role_tasks'
    dict_obj_data['role_default_vars'] = dict()
    dict_obj_data['role_default_vars']['test_key'] = 'test_value'
    dict_

# Generated at 2022-06-11 10:40:00.574539
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude.load("localhost,", None)


RoleInclude.register_loader()

# Generated at 2022-06-11 10:40:01.879396
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass # tested in test_playbook.py

# Generated at 2022-06-11 10:40:02.878928
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    raise NotImplementedError


# Generated at 2022-06-11 10:40:13.023899
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
   # Load role in ./roles/role1.yml
   role1 = RoleInclude.load("./roles/role1", None, None)
   assert role1.get_name() == "role1"

   # Load role in ./roles/role2.yml
   role2 = RoleInclude.load("./roles/role2", None, None)
   assert role2.get_name() == "role2"

   # Load role in ./roles/role3.yml
   role3 = RoleInclude.load("./roles/role3", None, None)
   assert role3.get_name() == "role3"

   # Load role in ./roles/custom_role.yml
   role4 = RoleInclude.load("./roles/custom_role", None, None)


# Generated at 2022-06-11 10:40:16.221759
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:40:26.103415
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import ansible.playbook.role.include
    current_path = os.path.dirname(os.path.abspath(ansible.playbook.role.include.__file__))
    current_role_path = os.path.join(current_path, 'tests')
    loader = None
    variables_manager = None
    data = {'role': 'foo',
            'name': 'bar'}
    ri = RoleInclude.load(data=data,
                          play=None,
                          current_role_path=current_role_path,
                          parent_role=None,
                          variable_manager=variables_manager,
                          loader=loader)
    assert ri.get_role_name() == 'foo'
    assert ri.get_name() == 'bar'

# Generated at 2022-06-11 10:40:36.170694
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    play = Play()
    playbook = PlaybookExecutor(playbooks=['./test_runner/role_include.yml'], inventory=inventory,
                                variable_manager=variable_manager, loader=loader, options=None, passwords={})
    play._variable_manager = variable_manager
    play._loader

# Generated at 2022-06-11 10:40:43.697470
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(system_name='test', system_id='test')

    play = Play().load(dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        roles=[
            dict(
                name='testRole1',
                tasks=[
                    dict(action=dict(module='shell', args='ls')),
                ]
            )
        ]
    ), variable_manager=variable_manager, loader=None)

    # should add role

# Generated at 2022-06-11 10:40:55.966049
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    mordred:
        host_list:
            localhost:

#    ansible.errors.AnsibleError: Invalid old style role requirement: web,mordred

    web,mordred:
        host_list:
            localhost:

#    AnsibleError: Invalid old style role requirement: web,mordred

    web:
        host_list:
            localhost:

#    AnsibleParserError: Invalid role definition: web

    '''
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    #from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-11 10:40:56.744902
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:41:04.513109
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    try:
        RoleInclude.load(data=None, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    except AnsibleParserError as e:
        assert "Invalid role definition: None" in str(e)
    else:
        assert False
    
    try:
        RoleInclude.load(data=[], play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    except AnsibleParserError as e:
        assert "Invalid role definition: []" in str(e)
    else:
        assert False
    

# Generated at 2022-06-11 10:41:05.574730
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-11 10:41:12.758764
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test function RoleInclude._load_role_data
    def _load_role_data(self, variable_manager, loader):
        data = dict()
        data['name'] = self.get_name()
        data['path'] = self._role_path
        data['default_vars'] = self._task_vars
        if self._role_params:
            data['vars'] = self._role_params
        data['dependencies'] = self._role.get_dependencies()

    ri = RoleInclude()
    variable_manager = "variable_manager"
    loader = "loader"
    ri._load_role_data(variable_manager, loader)

# Generated at 2022-06-11 10:41:13.650757
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, "TODO"

# Generated at 2022-06-11 10:41:28.115171
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test for method load of class RoleInclude
    """
    obj_RoleInclude = RoleInclude()

    data = 'test'
    play = 'test'
    current_role_path = 'test'
    parent_role = 'test'
    variable_manager = 'test'
    loader = 'test'
    collection_list = 'test'

    ## Make method load callable for testing
    obj_RoleInclude.load_data = RoleRequirement.load_data
    obj_RoleInclude.load = RoleInclude.load


# Generated at 2022-06-11 10:41:38.551899
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 10:41:40.203297
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    result = ri.load("roleName")
    assert result.get_name() == 'roleName'

# Generated at 2022-06-11 10:41:50.724308
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.plugins import plugin_loader
    import pytest

    # Load test data
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    play = Play().load({}, loader=loader, variable_manager=variable_manager, inventory=inventory)
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../test/_data/'))
    collection_list = None

    # Test data variables
    test_data_variable_role_basedir = "/tmp"
    test_

# Generated at 2022-06-11 10:41:51.620045
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:41:56.571809
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_name = 'role1'
    role_definition = RoleInclude.load(role_name, None,None,None)
    assert role_definition.get_name() == role_name
    
    role_definition_2 = RoleInclude.load(role_definition, None,None,None)
    assert role_definition_2.get_name() == role_name

# Generated at 2022-06-11 10:42:04.213878
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task import Task

    fake_play = Play()
    fake_loader = DataLoader()
    fake_variable_manager = None

    fake_role_definition = RoleRequirement.load(data="myrole")
    fake_task = Task.load(data={'local_action': 'shell echo 42'}, play=fake_play, variable_manager=fake_variable_manager, loader=fake_loader, task_vars={}, collection_list=[])

    fake_role_definition.tasks = [fake_task]


# Generated at 2022-06-11 10:42:14.740129
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import ansible.constants as C

    class DictObj(object):
        pass

    obj = DictObj()
    obj.DEFAULT_HANDLERS_PATH = 'DEFAULT_HANDLERS_PATH'
    obj.DEFAULT_MODULE_PATH = 'DEFAULT_MODULE_PATH'
    obj.DEFAULT_ROLES_PATH = 'DEFAULT_ROLES_PATH'
    obj.DEFAULT_TASKS_PATH = 'DEFAULT_TASKS_PATH'
    obj.DEFAULT_VARS_PATH = 'DEFAULT_VARS_PATH'
    obj.DEFAULT_FILTER_PLUGINS_PATH = 'DEFAULT_FILTER_PLUGINS_PATH'

# Generated at 2022-06-11 10:42:24.395373
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Create an object of class RoleInclude
    ri = RoleInclude()

    assert ri.load('name') == {'name':'name'}
    assert ri.load('name, some_var=foo') == {'name':'name', 'vars': {'some_var': 'foo'}}
    assert ri.load({'name': 'httpd'}) == {'name':'httpd'}
    assert ri.load({'name': ['httpd', 'nginx']}) == {'name': ['httpd', 'nginx']}
    assert ri.load({'name': ['httpd', 'nginx'], 'vars': {'port': '80'}}) == {'name': ['httpd', 'nginx'], 'vars': {'port': '80'}}

    assert r

# Generated at 2022-06-11 10:42:25.736670
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True



# Generated at 2022-06-11 10:42:43.057042
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Check for string input
    ri = RoleInclude([], "aRole", "aRolePath", "VManager", "Loader", "CollList")
    assert ri.load("test", "aRole", "aRolePath", "VManager", "Loader", "CollList") == ri

    # Check for dict input
    ri = RoleInclude([], "aRole", "aRolePath", "VManager", "Loader", "CollList")
    assert ri.load({"name": "test"}, "aRole", "aRolePath", "VManager", "Loader", "CollList") == ri

# Generated at 2022-06-11 10:42:50.602016
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "role1"
    play = None
    current_role_path = None
    parent_role= None
    variable_manager= None
    loader= None
    collection_list= None
    assert(isinstance(RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list), RoleInclude))
    data = "role1,role2"
    assert(isinstance(RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list), RoleRequirement))
    data = { "role1" : [] }
    assert(isinstance(RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list), RoleInclude))

# Generated at 2022-06-11 10:43:00.956137
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Create an instance of class RoleInclude without play, role_basedir, variable_manager, loader and collection_list
    ri = RoleInclude()
    # Test for exception when data parameter is not of type string, dict or AnsibleBaseYAMLObject
    # Exception should be returned
    try:
        ri.load(['test'], variable_manager=None, loader=None)
    except AnsibleParserError as e:
        assert isinstance(e, AnsibleParserError)

    # Test for exception when data is a role requirement string with a comma
    # Exception should be returned
    try:
        ri.load(['test'], variable_manager=None, loader=None)
    except AnsibleParserError as e:
        assert isinstance(e, AnsibleParserError)

    # Test for a return value of type RoleInclude

# Generated at 2022-06-11 10:43:11.529437
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.requiremenets import RoleRequirement
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    current_dir = os.path.dirname(__file__)
    play_path = os.path.join(current_dir, '../data/playbooks/include_role/include_role.yml')
    role_path = os.path.join(current_dir, '../data/playbooks/include_role/roles/dependency')
    role_path_without_collections = os.path.join(current_dir, '../data/playbooks/include_role/roles_with_collections')

    # load and parse playbook

# Generated at 2022-06-11 10:43:21.008868
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Pass data which is dictionary
    data = {}
    play = None
    current_role_path = None
    parent_role = None
    variable_manage = None
    loader = None
    collection_list = None
    RoleInclude.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manage, loader=loader, collection_list=collection_list)

    # Pass data which is string
    data = 'test'
    RoleInclude.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manage, loader=loader, collection_list=collection_list)

    # Pass data which is not string or dictionary
    data = []


# Generated at 2022-06-11 10:43:30.816219
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    p = Play().load({}, [], variable_manager=VariableManager(), loader=DataLoader())
    pc = PlayContext(play=p)
    pc.CLIARGS._parse_cli()
    inventory_manager = InventoryManager(loader=DataLoader(), sources=pc.CLIARGS['inventory'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory_manager)
    data_list = ['test_role', 'role: test_role', {'role': 'test_role'}]

# Generated at 2022-06-11 10:43:39.754064
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class AttributeDict(dict):
        def __getattr__(self, key):
            try:
                return self[key]
            except KeyError as k:
                raise AttributeError(k)
        def __setattr__(self, key, value):
            self[key] = value
        def __delattr__(self, key):
            try:
                del self[key]
            except KeyError as k:
                raise AttributeError(k)
        def __repr__(self):
            return '<AttributeDict ' + dict.__repr__(self) + '>'

    class Play(object):
        def __init__(self, roles_path=None, options=None):
            self.roles_path = roles_path
            self.options = options


# Generated at 2022-06-11 10:43:48.605694
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class MockVariableManager(object):
        pass
    class MockCollectionList(object):
        pass
    class MockLoader(object):
        pass
    class MockPlay(object):
        pass
    class MockRoleDefinition(object):
        pass
    # 1st test case
    data={'role':'test'}
    play=MockPlay()
    current_role_path='/test/test'
    parent_role=MockRoleDefinition()
    variable_manager=MockVariableManager()
    loader=MockLoader()
    collection_list=MockCollectionList()

    ri=RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert isinstance(ri, RoleInclude)
    # 2nd test case 
    data='test'


# Generated at 2022-06-11 10:43:51.790760
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    role_data = {'name': 'foo', 'tasks': []}
    role = RoleInclude.load(role_data)
    assert role.get_name() == 'foo'
    assert len(role.get_tasks()) == 0


# Generated at 2022-06-11 10:44:01.827504
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common.collections import ImmutableDict

    yaml_obj = AnsibleBaseYAMLObject()
    yaml_obj.data = "test"
    yaml_obj.ansible_pos = (0,0)
    yaml_obj.ansible_line = 1

    fake_loader = DataLoader()