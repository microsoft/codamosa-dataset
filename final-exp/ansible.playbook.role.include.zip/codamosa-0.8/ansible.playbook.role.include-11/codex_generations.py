

# Generated at 2022-06-11 10:39:06.334746
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False, "Test not implemented"

# vim: set expandtab:ts=4:sw=4

# Generated at 2022-06-11 10:39:16.668532
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.playbook.role.definition import RoleDefinition

    variable_manager = DictDataLoader({'a':1, 'b':2})
    variable_manager.set_variable_manager()

    role_definition_from_dict = {
        'name': 'some_role_from_dict',
        'description': 'A role to ...',
        'tasks': [
            {
                'name': 'task1',
                'action': {
                    'module': 'shell',
                    'args': 'echo "{{ a }}++{{ b }}"'
                }
            }
        ]
    }


# Generated at 2022-06-11 10:39:27.255214
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import ansible.playbook.role.meta
    import ansible.playbook.play

    from ansible.parsing.dataloader import DataLoader

    p = ansible.playbook.play.Play()
    r = ansible.playbook.role.definition.RoleDefinition(play=p, role_basedir='/etc/ansible/roles/', variable_manager=None, loader=DataLoader())
    r._role_name = 'name'
    r._role_path = '/etc/ansible/roles/name'
    r._role_paths = ['/etc/ansible/roles/name']

    m = ansible.playbook.role.meta.RoleMeta()
    m._role_name = 'name'
    m._role_path = '/etc/ansible/roles/name'
   

# Generated at 2022-06-11 10:39:30.177894
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    ri.load("test_role", "test_play", "test_current_role_path", "test_parent_role", "test_variable_manager", "test_loader")

# Generated at 2022-06-11 10:39:31.225869
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO
    pass

# Generated at 2022-06-11 10:39:33.504979
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude(play='play', role_basedir='role_basedir', variable_manager='variable_manager', loader='loader', collection_list='collection_list')
    assert ri.load('data', 'variable_manager') is None

# Generated at 2022-06-11 10:39:42.853553
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.utils.collection_loader import AnsibleCollectionRef, AnsibleRoleRef

    loader = DataLoader()
    #loader.set_basedir("/home/yym/temp/role_base/")
    loader.set_basedir("..")
    inventory = InventoryManager()
    variable_manager = VariableManager()

    context = PlayContext()
    context.variable_manager = variable_manager
    context.loader = loader
    context.inventory = inventory


# Generated at 2022-06-11 10:39:54.433017
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars.manager import VariableManager

    # load test only
    yaml_data = '''
            - hosts: localhost
              vars:
                 foo1: bar1
              tasks:
                 - debug:
                     msg: "{{ foo1 }}"
                 - include_role:
                     name: foo1
                   vars:
                     foo2: bar2
              handlers:
                 - debug: msg="Handler1: {{ foo1 }}"
                 - include_role:
                     name: foo1
                   vars:
                     foo3: bar3
                   handlers:
                     - debug: msg="Handler2: {{ foo2 }}"
    '''

# Generated at 2022-06-11 10:40:04.397894
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import sys
    import os

    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import iteritems
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_bytes
    from ansible.utils.vars import load_extra_vars, load_options_vars, combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.vault import VaultAwareInventory
    from ansible.inventory.inventory import BaseInventoryPlugin
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-11 10:40:14.334784
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    test_definition = '''
- name: foo
  src: git://github.com/foo/bar.git
  scm: git
  version: stable
  roles:
    - src: git://github.com/foo/bar.git
      scm: git
      version: stable
      name: bar
    - foo
    - src: git://github.com/foo/bar.git
      scm: git
      version: stable
      name: bar
      delegate_to: localhost
      delegate_facts: true
'''
    test_definition = dict(AnsibleVaultEncryptedUnicode.load(test_definition)['roles'][2])

# Generated at 2022-06-11 10:40:26.850814
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    play_source =  dict(
        name = 'Ansible Playbook',
        hosts = 'all',
        gather_facts = 'no',
        roles = [
            dict(role1),
            dict(role2),
        ]
    )
    play = Play.load(play_source, variable_manager=variable_manager, loader=loader)
    assert len(play._role_includes) == 2
    assert isinstance(play._role_includes[0], RoleDefinition)
    assert play._role_includes[0]._role_name == 'role1'

# Generated at 2022-06-11 10:40:36.918162
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.display import Display
    display = Display()
    import os

    def load_vars(filepath):
        vars_files = loader.load_from_file(filepath)
        if len(vars_files) > 0:
            return vars_files[0]
        return None

    base_dir = '../../test/roles/test_role'
    current_role_path = os.path.join(base_dir, 'tasks')
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.add_directory(base_dir)
    variable_manager.add

# Generated at 2022-06-11 10:40:44.070914
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    test_data_roles = {
        'TESTRoleName1': {
            'tasks': ['main.yml']},
        'TESTRoleName2': {
            'tasks': ['main.yml']}
    }


# Generated at 2022-06-11 10:40:56.401229
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    ### Set the requirement
    requirement = 'test'
    required_parameters = {
            'name': 'test',
            'src': 'test',
            'version': 'test',
            'scm': 'test',
            'path': 'test',
            'private': True,
            'apply': 'test',
            'meta': 'test',
    }

    ### Generate play for the requirement

# Generated at 2022-06-11 10:41:02.842981
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    current_role_path = '/home/user/ansible/roles'

    data = AnsibleMapping()
    data["name"] = "role1"
    data["role_path"] = "/home/user/ansible/roles/role1"
    data["_original_file"] = "/home/user/ansible/roles/role1/tasks/main.yml"
    data["_role_name"] = "role1"

# Generated at 2022-06-11 10:41:09.821425
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Unit test for method RoleInclude.load"""
    data = \
    {
        'hosts': 'dbservers',
        'roles': [
            'dbservers'
        ]
    }
    
    # Test Exception
    try:
        ri = RoleInclude.load("oldstyle", data)
        assert False
    except AnsibleError:
        assert True
    
    # Test AnsibleString
    ri = RoleInclude.load("dbservers", data)
    assert ri.get_name() == "dbservers"


# Generated at 2022-06-11 10:41:19.316368
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
   
    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play()

    result = RoleInclude.load('role2', play, None, None, variable_manager, loader, ["collections"])
    assert result.get_name() == 'role2'

    result = RoleInclude.load({'role': 'role2'}, play, None, None, variable_manager, loader, ["collections"])
    assert result.get_name() == 'role2'

    result = RoleInclude.load({'role': 'role2', 'tags': ['bar']}, play, None, None, variable_manager, loader, ["collections"])

# Generated at 2022-06-11 10:41:28.552604
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C

    yaml_loader = DataLoader()
    variable_manager = VariableManager()
    myinventory = InventoryManager(loader=yaml_loader, sources=['test/unit/inventory'])
    variable_manager

# Generated at 2022-06-11 10:41:34.766351
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from units.mock.loader import DictDataLoader

    data = {}
    play = None
    parent_role = None
    current_role_path = None
    variable_manager = None
    loader = DictDataLoader({})
    collection_list = None

    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-11 10:41:42.668519
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleParserError

    loader = DataLoader()
    variable_manager = VariableManager()
    data = { 'name': 'apache', 'role_path': '/etc/ansible/roles' }

    ri = RoleInclude()
    ri.load(data=data, role_basedir='/etc/ansible/roles', variable_manager=variable_manager, loader=loader)

    assert ri.name == 'apache'
    assert ri.role_path == '/etc/ansible/roles'
    assert ri._role_path == '/etc/ansible/roles/apache'


# Generated at 2022-06-11 10:41:57.812343
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.collection.collection_list import CollectionList
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    current_role_path='/home/abhijit/ansible_home/ansible_practice/roles/org_role'
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)
    col_list = CollectionList()

# Generated at 2022-06-11 10:42:04.842567
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.loader import become_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-11 10:42:15.331576
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import ROLE_CACHE
    from ansible.playbook.play import Play
    from ansible.playbook.role.metadata import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

# Generated at 2022-06-11 10:42:24.872544
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    fake_play = {}
    data = {'role': 'my-role', 'meta': 'meta-def.yml'}
    fake_loader = 'fake-loader'
    fake_variable_manager = 'fake-variable-manager'
    fake_loader_return = 'fake-loader-return'
    fake_loader_results = {'meta': 'fake-meta-result'}
    fake_loader_results_file = {'meta': 'fake-meta-result-file'}
    fake_loader_results_list = [{'meta': 'fake-meta-result'}, {'meta': 'fake-meta-result-1'}]
    fake_loader_results_list_file = [{'meta': 'fake-meta-result-file'}, {'meta': 'fake-meta-result-1-file'}]


# Generated at 2022-06-11 10:42:25.540739
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:42:35.856660
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    role = Role.load({"name": "myrole"}, variable_manager=variable_manager, loader=loader)
    role.load_role(loader=loader, variable_manager=variable_manager)
    role_include = RoleInclude.load({"role": "myrole"}, play=None, current_role_path=None, parent_role=None, variable_manager=variable_manager, loader=loader)
    assert isinstance(role_include, RoleInclude)
    assert role_include.get_role_name() == "myrole"

# Generated at 2022-06-11 10:42:36.410793
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:42:45.345651
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test for invalid data types
    with pytest.raises(AnsibleParserError) as excinfo:
        RoleInclude.load(None, None, None, None, None, None)
    assert 'Invalid role definition: None' in str(excinfo.value)
    with pytest.raises(AnsibleParserError) as excinfo:
        RoleInclude.load(1, None, None, None, None, None)
    assert 'Invalid role definition: 1' in str(excinfo.value)

# Generated at 2022-06-11 10:42:51.876739
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import plugin_loader
    from ansible.cli import CLI

    options = CLI.base_parser('').parse_args()[0]
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../test/unit/plugins/test_loader/action_plugins'))

# Generated at 2022-06-11 10:43:02.366258
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.yaml.dumper import AnsibleDumper

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    assert loader
    assert inventory
    assert variable_manager

    # Load json data file
    test_rolejson = os.path.join(os.path.dirname(os.path.realpath(__file__)), '__role_test.json')

# Generated at 2022-06-11 10:43:21.333013
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.errors import AnsibleParserError
    from ansible.module_utils.six import string_types

    pr = Play()
    pr.vars = dict()
    pr.vars["playbook_dir"] = ".."

    pc = PlayContext()
    pc.vars = dict()

# Generated at 2022-06-11 10:43:31.069462
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Setup objects for RoleInclude.load()

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.config.manager import ConfigManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    config_manager = ConfigManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-11 10:43:39.975969
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''
    1. Create variable_manager
    2. Create role_basedir
    3. Create loader
    4. Create play
    5. Create collection_list
    6. Load data
    '''
    variable_manager = mock_variable_manager()
    role_basedir = mock_role_basedir()
    loader = mock_loader()
    play = mock_play()
    collection_list = mock_collection_list()

# Generated at 2022-06-11 10:43:48.825054
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    play = Play()
    play.variable_manager = VariableManager()
    ri = RoleInclude(play=play)
    assert not isinstance(ri, list)
    ri = RoleInclude(play=play, role_basedir="role_basedir")
    assert not isinstance(ri, list)
    ri = RoleInclude(play=play, role_basedir="role_basedir", variable_manager=play.variable_manager)
    assert not isinstance(ri, list)
    ri = RoleInclude(play=play, role_basedir="role_basedir", variable_manager=play.variable_manager, loader=play._loader)
    assert not isinstance(ri, list)

# Generated at 2022-06-11 10:43:58.880230
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 10:44:04.371920
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {'role': 'Apache', 'tags': ['httpd']}
    play = object()
    current_role_path = object()
    parent_role = object()
    variable_manager = object()
    loader = object()
    collection_list = object()
    role_include = RoleInclude
    role_include.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    return "SUCCESS"

# Generated at 2022-06-11 10:44:15.722142
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inv = InventoryManager(loader=AnsibleLoader(None))
    v = VariableManager(loader=AnsibleLoader(None), inventory=inv)
    p = Play().load({}, variable_manager=v, loader=AnsibleLoader(None))
    r = RoleInclude.load({'name': 'test_role'}, play=p, variable_manager=v, loader=AnsibleLoader(None))
    assert 'test_role' == r._role_name
    assert 'test_role' in r._role_path


# Generated at 2022-06-11 10:44:23.350567
# Unit test for method load of class RoleInclude

# Generated at 2022-06-11 10:44:34.098909
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    p = Play()
    p._variable_manager = VariableManager()
    p._variable_manager.set_inventory(p.get_variable_manager().get_inventory())  # pylint: disable=protected-access
    p.set_loader(p._variable_manager.get_vars_loader())
    p.set_options({'retry_files_enabled': False})
    play_context = PlayContext()
    p.set_context(play_context)

    ri = RoleInclude(play=p)
    role_basedir = '/home/ansible/data/project/ansible/roles'

# Generated at 2022-06-11 10:44:43.369117
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.vars.manager import VariableManager

    class Data(object):
        """
        This class is used as a fake data object in test
        """
        def __init__(self, data):
            self._data = data

        def get_data(self):
            """
            Return the data item
            """
            return self._data

    class Play(object):
        """
        This class is used as a fake play object in test
        """
        def __init__(self, variable_manager=None):
            self._variable_manager = variable_manager

        def get_variable_manager(self):
            """
            Return the variable manager of this play
            """
            return self._variable_manager

    # Test case 1: data is a string and data string is not a comma separated string
    # Expected result: return a Role

# Generated at 2022-06-11 10:45:10.846100
# Unit test for method load of class RoleInclude

# Generated at 2022-06-11 10:45:13.975572
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import ansible.module_utils.common as common

    print(__doc__)

    fr = common.FeatureRequest()
    fr.load()
    print(fr)
    print(fr.__dict__)


# test_RoleInclude_load()


# Generated at 2022-06-11 10:45:24.376766
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create sample play
    play = Play()
    play.vars = dict()

    # Create sample inventory
    inventory = Inventory(loader=DataLoader())

    # Create sample variable manager
    variable_manager = combine_vars(loader=DataLoader(), inventories=[inventory], play=play)
    variable_manager.set_inventory(inventory)

    # Load sample data
    ri = RoleInclude(play=play, variable_manager=variable_manager)
    data = dict()
    data['hosts'] = 'all'
    ri.load_data(data=data, variable_manager=variable_manager)

   

# Generated at 2022-06-11 10:45:34.005769
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.requirement import RoleRequirement

    # create play
    play = Play()
    play._variable_manager = None

    # create role
    role_req = RoleRequirement()
    role_req.name = 'myrole'
    role_req.role = 'myrole'
    role_req._role_path = '../foo'
    role_req._role_name = 'myrole'
    role_req._parent_role = None
    role_req._play = play
    role_req._collections = None
    play._role_requirements = [role_req]

    # create task
    task = Task()
    task._role = role_req
    role_req.tasks

# Generated at 2022-06-11 10:45:42.902715
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.parsing.yaml.dumper import AnsibleDumper
    data_str = """
        ---
        - hosts: all
          gather_facts: False
          tasks:
          - name: Install test package
            package:
              name: 'apache2'
              state: present
        """

    fake_play = Play().load(data_str, variable_manager=VariableManager(), loader=None)
    variable_manager = VariableManager()
    variable_manager.set_variable('hostvars', dict())


# Generated at 2022-06-11 10:45:46.763476
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    role = RoleDefinition()
    RoleInclude.load(data=role, loader=False, variable_manager=False, play=False, collection_list=False)
    role = RoleDefinition()
    RoleInclude.load(data=role, loader=True, variable_manager=False, play=False, collection_list=False)

# Generated at 2022-06-11 10:45:47.252206
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True == True

# Generated at 2022-06-11 10:45:55.562179
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
     print("Testing RoleInclude.load() class method")

     # Create role
     role_name = "role1"
     role_data = {
           "name": role_name,
           "status": "role1_status",
           "description": "role1_description"
     }

     # Create a RoleDefinition object
     role_definition = RoleDefinition(role_data)

     # Check the attribtes
     assert(role_definition.name == role_name)
     assert(role_definition.status == "role1_status")
     assert(role_definition.description == "role1_description")

     # Create a object of class RoleInclude
     role_include = RoleInclude(role_definition)

     # Check the attribtes
     assert(role_include.name == role_name)

# Generated at 2022-06-11 10:46:05.194028
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.objects import AnsibleUnicode

    RoleDefinition._role_path = 'roles'

    ri_a = RoleInclude.load('role_a', None)
    assert ri_a.get_name() == 'role_a'
    assert isinstance(ri_a._role_name, AnsibleUnicode)
    assert ri_a._role_name == 'role_a'
    assert ri_a.get_role_path() == os.path.join(RoleDefinition._role_path, 'role_a')

    ri_b = RoleInclude.load({'role': 'rolenamespace.role_b'}, None)

# Generated at 2022-06-11 10:46:11.183176
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    rd=RoleInclude.load('role_name', 'play')
    assert(rd._role_name == 'role_name')
    assert(rd._role_path is None)
    assert(rd._role_name is not None)
    assert(rd._role_path is not None)
    assert(rd._default_vars is None)
    assert(rd._default_vars_path is None)
    assert(rd._main_task_path is None)
    assert(rd._metadata is None)
    assert(rd._metadata_path is None)

# Generated at 2022-06-11 10:46:54.158536
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    '''testing method RoleInclude.load'''
    pass


    # Requirement is set when the class is being loaded

    # Requirement is added to the list of roles in the play


# Generated at 2022-06-11 10:47:01.567281
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    class TestRoleIncludeLoad(unittest.TestCase):

        def test_data_string(self):
            '''
            Test RoleInclude.load for data passed as string.
            '''
            loader = DataLoader()
            var_mgr = VariableManager()
            role_include_data_str = 'Ansible.apache'
            role_include_obj = RoleInclude.load(role_include_data_str,
                                                play=Play().load(dict(), var_mgr=var_mgr, loader=loader),
                                                variable_manager=var_mgr, loader=loader)


# Generated at 2022-06-11 10:47:08.252706
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test case 1
    data = ['apache']
    play = 'apache'
    current_role_path = 'apache'
    parent_role = None
    variable_manager = 'apache'
    loader = None
    collection_list = None

    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ri

    # Test case 2
    data = 'apache'
    play = 'apache'
    current_role_path = 'apache'
    parent_role = None
    variable_manager = 'apache'
    loader = None
    collection_list = None

    ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert ri

   

# Generated at 2022-06-11 10:47:10.070480
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    role_include = RoleInclude()
    assert role_include.load(AnsibleUnsafeText('test'), 'play') == role_include

# Generated at 2022-06-11 10:47:18.965130
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # just load from a yaml file
    def __init__(self, play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None):
        super(RoleInclude, self).__init__(play=play, role_basedir=role_basedir, variable_manager=variable_manager,
                                          loader=loader, collection_list=collection_list)

    # just load from a yaml file
    def load_data(self, data, variable_manager=None, loader=None):

        if isinstance(data, string_types) and ',' in data:
            raise AnsibleError("Invalid old style role requirement: %s" % data)

        all_vars = []
        errors = []
        el = None
        entry = {}

# Generated at 2022-06-11 10:47:26.415700
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import tempfile
    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 10:47:35.006373
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    method load of class RoleInclude
    """
    from ansible.playbook.play import Play
    import os
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import Sequence

    mock_loader = DataLoader()

# Generated at 2022-06-11 10:47:35.506456
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:47:45.108282
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  {'name': 'test play',
                    'hosts': 'localhost',
                    'gather_facts': 'no',
                    'tasks': []}
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

   

# Generated at 2022-06-11 10:47:54.235462
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # 1. test for AnsibleParserError
    play = None
    role_basedir = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude(play=play, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    data = None
    try:
        ri.load(data, play, role_basedir, None, variable_manager, loader, collection_list)
    except AnsibleParserError:
        assert True
    else:
        assert False

    data = {}
    try:
        ri.load(data, play, role_basedir, None, variable_manager, loader, collection_list)
    except AnsibleParserError:
        assert False
    else:
        assert True