

# Generated at 2022-06-11 10:39:15.356088
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    test_loader = DictDataLoader(dict())
    test_loader.set_basedir('/home/robert/ansible/my_roles')

    vars_manager = VariableManager()
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            dict(
                name="my_role",
                delegate_to="localhost",
                delegate_facts="yes",
            )
        ]
    ),variable_manager=vars_manager,loader=test_loader)

    assert play.get_roles()[0].get_name() == "my_role"
    assert play.get_roles()[0].get_delegate_to() == "localhost"

# Generated at 2022-06-11 10:39:26.097188
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    data = {}

    play = Play()
    current_role_path = 'role_path'
    # Create a role definition which is a parent to the role definition to be tested.
    parent_role = RoleDefinition(play=play, role_basedir=current_role_path)
    requirements = [ RoleRequirement(name='test_name') ]

# Generated at 2022-06-11 10:39:35.422446
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import RoleRequirement

    playbook = Playbook()
    pb = Playbook()
    play = pb.get_play("test play")
    block = Block()
    task = Task()
    role_requirement = RoleRequirement()

    data = "test"

    role_definition = RoleInclude.load(data, play, variable_manager, loader, collection_list)

    assert(role_definition.get_role_path() == play.ROLE_CACHE_PATH)

    data = {'role': 'test'}


# Generated at 2022-06-11 10:39:46.182080
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # create test objects
    play = RoleRequirement.load('name=collection.namespace.my_role', variable_manager=None, loader=None, collection_list=None)

    ri = RoleInclude.load(data='one', play=play, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    ri = RoleInclude.load(data={'dummy': 'key'}, play=play, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)

# Generated at 2022-06-11 10:39:47.259938
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Nothing to test
    pass

# Generated at 2022-06-11 10:39:58.057694
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test for method load of class RoleInclude
    # data is ansible.errors.AnsibleError
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.playbook.play import Play
    from ansible.playbook.role import ROLE_CACHE
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role_include import RoleInclude
    from ansible.template import Templar

    class VarManager(object):
        """
        Used only to test the RoleInclude load method
        """

        def __init__(self, host=None):
            self.extra_v

# Generated at 2022-06-11 10:40:08.230076
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Arrange
    play = None
    current_role_path=None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    # Act
    ri = RoleInclude.load('test', play, current_role_path, parent_role, variable_manager, loader, collection_list)

    # Assert
    assert ri is not None
    assert ri.get_name() == 'test'
    assert ri._role_path == ''
    assert ri._role_name == 'test'
    assert ri._role_params == {}
    assert ri._role_vars == {}
    assert ri._role_default_vars == {}
    assert ri._role_metadata == {}
    assert ri._delegate_to == ''
    assert ri

# Generated at 2022-06-11 10:40:17.286088
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play = PlayContext()
    play.connection = "local"
    loader = None
    collection_list = None
    variable_manager = VariableManager()
    variable_manager._fact_cache = {}
    ri = RoleInclude(play=play, role_basedir="", variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    data = {'role': 'apache'}
    role_def = ri.load(data, play)
    assert isinstance(role_def, RoleDefinition)
    assert role_def._role_name == 'apache'
    assert role_def._role_path == ""
    assert role

# Generated at 2022-06-11 10:40:27.646844
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    meta_dir = os.getcwd()
    meta_dir = os.path.join(meta_dir, 'test/support/roles')
    try:
        rd = RoleDefinition.load('test1', search_path=[meta_dir])
    except Exception as e:
        print(repr(e))
        assert False
    assert rd is not None

    meta_dir = os.getcwd()
    meta_dir = os.path.join(meta_dir, 'test/support/collections')

# Generated at 2022-06-11 10:40:37.580793
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.module_utils._text import to_bytes
    import ansible.constants as C
    import pytest

    # given
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'host1',
        gather_facts = 'no',
        roles = ['role_path_1', 'role_path_2'],
        vars = dict(
            a1 = 'a1',
            a2 = dict(
                    b1 = 'b1',
            ),
        ),
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{x1}}'))),
        ],
    ), variable_manager=None, loader=None)


# Generated at 2022-06-11 10:40:50.628800
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import ansible.parsing.yaml.objects
    import ansible.vars.manager
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.plugins.loader

    # create mock objects
    dataloader_mock = ansible.parsing.dataloader.DataLoader()
    templar_mock = Templar(loader=dataloader_mock)
    context_mock = PlayContext()
    vm = ansible.vars.manager.VariableManager()
    vm.set_inventory(ansible.inventory.manager.InventoryManager(loader=dataloader_mock, sources=[]))

    # create play
    play_

# Generated at 2022-06-11 10:40:51.523718
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:41:02.107246
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def test_data(data, expected):
        ri = RoleInclude.load(data, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
        assert ri == expected

    test_data("foo", "foo")
    test_data("foo,bar", "foo")
    test_data("foo@bar", "foo")
    test_data("foo,bar@test", "foo")
    test_data("foo@sha256:90d2b1c0d2acbc7e2f2db21d8fc84a5c955bbe9a9a240a829e59c1a69a735cda", "foo")

    test_data(dict(role="foo"), "foo")
    test_data

# Generated at 2022-06-11 10:41:10.961027
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        playbook_dir='/data',
        foo='bar',
        my_collection=Reserved('My Collection', 'my_collection'),
    )
    play_context = PlayContext()
    task_vars = dict()
    loader = None
    ri = RoleInclude.load(dict(role="my_collection.my_role"), play=None)
    assert len(ri.dependencies) == 1
    assert isinstance(ri.dependencies[0], RoleRequirement)
    assert ri.dependencies[0].role == "my_collection.my_role"


# Generated at 2022-06-11 10:41:20.589833
# Unit test for method load of class RoleInclude

# Generated at 2022-06-11 10:41:29.691405
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    pc = PlayContext()
    ri = RoleInclude(play=pc)
    rdata = {
        'name': 'geerlingguy.apache',
        'foo': 'bar',
        'bar': 'baz',
        'foobar': 'bazbar'
    }
    try:
        ri.load_data(rdata)
    except:
        pass
    assert ri.name == "geerlingguy.apache", "role name should be geerlingguy.apache"
    assert ri.foo == "bar", "role attribute foo should be bar"
    assert ri.bar == "baz", "role attribute bar should be baz"

# Generated at 2022-06-11 10:41:39.633838
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Setup
    data = 'https://github.com/geerlingguy/ansible-role-apache.git,apache'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    # Test
    result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    # Verify
    assert isinstance(result, RoleInclude)
    assert result._role_name == 'apache'
    assert result._role_path is not None
    assert result._role_path.startswith('https://github.com/geerlingguy/ansible-role-apache.git')


# Generated at 2022-06-11 10:41:44.094423
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # First, make sure the method doesn't crash when data is of the wrong type
    # Check that when data is a string but the string contains a comma, then an error is raised
    # Check that when data is a dict, it should return an object of type RoleInclude
    # Check that when data is a str but not containing a comma, it should return an object of type RoleRequirement
    assert True

# Generated at 2022-06-11 10:41:55.457345
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Test when data is string
    data1 = "myhost"
    play1 = []
    current_role_path1 = "current_role_path1"
    parent_role1 = 5
    variable_manager1 = 5
    loader1 = 5
    collection_list1 = 5
    ri1 = RoleInclude.load(data=data1, play=play1, current_role_path=current_role_path1, parent_role=parent_role1,
                           variable_manager=variable_manager1, loader=loader1,
                           collection_list=collection_list1)

    print(ri1.__dict__)
    assert ri1.play == play1
    assert ri1.role_basedir == current_role_path1
    assert ri1.variable_manager == variable_manager1
   

# Generated at 2022-06-11 10:42:03.559332
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data1 = 'name'
    data2 = {'role': 'name'}
    data3 = {'name': 'name'}
    data4 = {'name': 'name', 'delegate_to': '10.10.10.10'}
    data5 = {'name': 'name', 'delegate_to': '10.10.10.10', 'delegate_facts': 'yes'}

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    import ansible.parsing.yaml.objects
    from ansible.module_utils.six import string_types
    from ansible.playbook.play import Play

    from ansible.plugins.loader import collection_loader

    yaml = ansible.parsing.yaml.objects.Ansible

# Generated at 2022-06-11 10:42:13.993249
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    assert RoleInclude.load('foo', {'some': 'play'}, 'bar')

    assert RoleInclude.load({'name': 'foo'}, {'some': 'play'}, 'bar')

    assert RoleInclude.load({'name': 'foo', 'become': 'true'}, {'some': 'play'}, 'bar')



# Generated at 2022-06-11 10:42:23.732625
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.role.definition import RoleDefinition, RoleRequirement
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    import os

    data = """
- name: test-include
  include_role:
    name: webservers
    tasks_from: deploy
    vars:
      http_port: 80
      max_clients: 200
  delegate_to: localhost

  when: ansible_os_family == 'Debian'
"""


# Generated at 2022-06-11 10:42:29.895242
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/ansible/inventory/test_inventory.yaml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 10:42:33.547768
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "role,"
    if ',' in data:
        raise AnsibleError("Invalid old style role requirement: %s" % data)


# Generated at 2022-06-11 10:42:43.018649
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    def check_data(data, expected_result):
        from ansible.playbook.play import Play
        from ansible.plugins.loader import action_loader

        play = Play().load({'hosts': 'all', 'roles': [data]}, variable_manager=variable_manager, loader=loader)
        play._role_entries[0] = RoleInclude.load(data, play, variable_manager=variable_manager, loader=loader)

        assert play._role_entries[0].name == expected_result['name']
        assert play._role_entries[0]._role_name == expected_result['_role_name']
        assert play._role_entries[0]._role_path == expected_result['_role_path']
        assert play._role_entries[0]._role_collection_name == expected_

# Generated at 2022-06-11 10:42:49.930943
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    test_data1 = 'role'
    test_data2 = {'role': 'role'}
    test_data3 = AnsibleBaseYAMLObject()
    test_data3.role = 'role'
    test_data4 = 'role,role'
    try:
        RoleInclude.load(test_data1, None, None, None, None, None)
        RoleInclude.load(test_data2, None, None, None, None, None)
        RoleInclude.load(test_data3, None, None, None, None, None)
        RoleInclude.load(test_data4, None, None, None, None, None)
    except Exception:
        pass

# Generated at 2022-06-11 10:42:59.954179
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import mock
    import yaml
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    variable_manager = mock.Mock()
    loader = mock.Mock()
    play_context = PlayContext()
    play_context.network_os = 'junos'
    play = Play.load(dict(
            name = "Ansible Play",
            hosts = 'junos',
            gather_facts = 'no',
            connection = 'local',), variable_manager=variable_manager, loader=loader)

    current_role_path = "/var/ansible/roles:/etc/ansible/roles"

    play._tqm = mock.Mock()
    play._tqm._variable_manager

# Generated at 2022-06-11 10:43:10.801656
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Non-list of type string is an error
    ARG_NON_STRING = 8
    try:
        RoleInclude.load(ARG_NON_STRING, None, None, None, None, None)
        assert False, "AnsibleParserError Exception not generated for param not string"
    except AnsibleParserError:
        pass
    # Non-list of type dict is an error
    ARG_NON_DICT = {"role_name": "something"}
    try:
        RoleInclude.load(ARG_NON_DICT, None, None, None, None, None)
        assert False, "AnsibleParserError Exception not generated for param not dict"
    except AnsibleParserError:
        pass
    # Non-list of type AnsibleBaseYAMLObject is an error
    ARG_

# Generated at 2022-06-11 10:43:16.647988
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    pb = Play.load(dict(
        name = "test play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [
            dict(
                name = 'role1',
                tasks = [
                    dict(action=dict(module='debug', args=dict(msg='role1 task1')))
                ]
            ),
            dict(
                include = 'role2'
            )
        ]
    ), variable_manager=VariableManager())

    assert pb.name == 'test play'
    assert len(pb.roles) == 2

    role1 = pb.roles[0]
    assert role1.get_name() == 'role1'

# Generated at 2022-06-11 10:43:17.630176
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO
    pass