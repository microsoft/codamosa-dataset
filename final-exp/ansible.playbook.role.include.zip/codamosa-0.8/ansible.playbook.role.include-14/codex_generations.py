

# Generated at 2022-06-11 10:39:08.893403
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:39:19.909520
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    p = PlayContext()
    p.remote_addr = '127.0.0.1'
    p.become = True
    p.become_method = 'sudo'
    p.become_user = 'root'
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    path = '/tmp/'
    data = dict()
    data['name'] = 'test'
    data['roles'] = [{ 'role': './../examples/ansible-lxc', 'other': '123' }]


# Generated at 2022-06-11 10:39:30.324752
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    # Create an empty object of class RoleInclude
    obj1 = RoleInclude()

    # Create an object of class object
    obj2 = object()

    # Create a string object with a dictionary using the keys role, tasks, etc.
    data = "1, 2, 3"

    # Create an empty object of class PlayContext which is required for the
    # load method
    obj3 = PlayContext()

    # Create an object of class RoleRequirement
    obj4 = RoleRequirement()

    # Create an object of class dict
    obj5 = {}
    obj5['a'] = 1
    obj5['b'] = 2

    # Create an object of class AnsibleBaseYAMLObject
    obj6 = AnsibleBaseYAMLObject()

    # Create an object of class

# Generated at 2022-06-11 10:39:31.046181
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:39:33.424042
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # unittest.TestCase.skipTest(self, reason)
    # raises unittest.SkipTest with the given reason.
    raise unittest.SkipTest('todo')

# Generated at 2022-06-11 10:39:42.706158
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import sys
    import os
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.plugins.loader import role_loader

    def FakeVarsModule(vars_dict):
        module = AnsibleMapping()
        for key, value in iteritems(vars_dict):
            module[key] = value
        return to_bytes(module.to_yaml())

    collection_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..', 'test', 'support', 'ansible_collections'))


# Generated at 2022-06-11 10:39:54.385322
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class mock_loader(object):
        def load_from_file(self,f):
            return {'name':'fake_role'}
    class mock_play(object):
        def __init__(self,role_path=None,vars=None):
            self.ROLE_PATH = role_path
            self.vars = vars
    class mock_variable_manager(object):
        def get_vars(self,host):
            return {}
    class mock_collection_list(object):
        def search_collections(self,role_name):
            return []
    role_dir = '/fake/dir'
    var_manager = mock_variable_manager()
    loader = mock_loader()

# Generated at 2022-06-11 10:40:04.392959
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, module_loader, lookup_loader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager._extra_vars = {'vars_data': {}}

    # play_context = PlayContext(variable_manager=variable_manager)
    # play_context = PlayContext()

    src_path = './'
    variable_manager.set_inventory(loader.load_inventory(host_list=src_path + 'hosts'))
    variable_manager.set_loader(loader)
   

# Generated at 2022-06-11 10:40:14.333689
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class Dummy(object):
        pass

    data = Dummy()
    data.name = 'foo'
    data.tags = ['bar']
    data.when = 'quux'
    data.become = 'moo'
    rie = RoleInclude()
    rie.load_data(data)
    assert rie.role_name == 'foo'
    assert rie.tags == ['bar']
    assert rie.when == 'quux'
    assert rie.become == 'moo'
    data_yaml = AnsibleUnicode('foo')
    rie.load_data(data_yaml)
    assert rie.role_name == 'foo'
    assert rie.tags == ['bar']


# Generated at 2022-06-11 10:40:21.012037
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.taggable import Taggable
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved

    # Create a play object