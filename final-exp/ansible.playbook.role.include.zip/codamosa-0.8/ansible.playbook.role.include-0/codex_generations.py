

# Generated at 2022-06-11 10:39:03.657648
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert False


# Generated at 2022-06-11 10:39:12.224770
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test RoleInclude.load method.
    """

    class FakeRoleDefinition():
        pass

    class FakeRoleInclude():
        pass

    current_role_path = os.path.join('fake_path', 'role1')
    variable_manager = None
    loader = None

    def fake_load_data(*args, **kwargs):
        my_instance = FakeRoleInclude()
        my_instance.data = { "role1": "role1", "role2": "role2" }
        for key, value in iteritems(my_instance.data):
            setattr(my_instance, key, value)
        return my_instance

    FakeRoleInclude.load_data = fake_load_data
    RoleInclude.load_data = fake_load_data

    # test old style role requirement, should raise

# Generated at 2022-06-11 10:39:23.287902
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader, sources=[])
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    playbook = PlaybookExecutor(playbooks=['test_role_include.yaml'], inventory=fake_inventory, variable_manager=fake_variable_manager, loader=fake_loader)

# Generated at 2022-06-11 10:39:24.267175
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    RoleInclude.load("dummy", None)

# Generated at 2022-06-11 10:39:31.226880
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'role_name'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    role_include_test_object = RoleInclude.load(data,  play, current_role_path, parent_role, variable_manager, loader, collection_list)
    if role_include_test_object:
        raise AssertionError("RoleInclude load method failed")



# Generated at 2022-06-11 10:39:39.161114
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    class Test_role(RoleInclude):
        _delegate_to = FieldAttribute(isa='string')
        _delegate_facts = FieldAttribute(isa='bool', default=False)

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # test for string input
    data='role1'
    Play=PlayContext()
    Variable=VariableManager()
    loader = DataLoader()
    t=Test_role(play=Play,variable_manager=Variable,loader=loader)
    role_definition=t.load(data,Play)

# Generated at 2022-06-11 10:39:40.550170
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print("ansible.playbook.role_include.RoleInclude_load")

# Generated at 2022-06-11 10:39:41.492046
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True
    # RoleInclude.load()

# Generated at 2022-06-11 10:39:42.178455
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:39:54.045431
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {}
    play = None
    current_role_path="path_to_roles"
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    res = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert res is not None
    assert (isinstance(res, RoleInclude))

    data = "name"
    res = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert res is not None
    assert (isinstance(res, RoleInclude))

    data = "name,name,n a me"

# Generated at 2022-06-11 10:40:05.370673
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.reserved import Reserved

    # Testing load method of class RoleInclude with empty ansible Base YAML Obj
    data = AnsibleBaseYAMLObject()
    assert RoleInclude.load(data=data, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None) == None

    # Testing load method of class RoleInclude with data as string and delimiter
    data = "foo"
    assert RoleIn

# Generated at 2022-06-11 10:40:06.668442
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
    # obj = RoleInclude()
    # obj.load()

# Generated at 2022-06-11 10:40:14.731519
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    obj = RoleInclude()
    data = {
        'role': 'Common',
        'tasks': './plays/tasks/main.yml'
    }
    variable_manager = None
    loader = None
    current_role_path = None
    collection_list = None
    play = None
    parent_role = None
    result = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    assert result._role_name == 'Common'
    assert result.get_tasks() == ['./plays/tasks/main.yml']


# Generated at 2022-06-11 10:40:21.225433
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.plugins.loader import find_plugin
    from ansible.playbook.play import Play
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    plugin_loader = dict()
    plugin_loader['callback'] = callback_loader
    plugin_loader['action'] = action_loader
    plugin_loader['lookup'] = lookup_loader
    plugin_loader['module'] = module_loader
    plugin_loader['connection'] = connection_loader
    plugin_loader['filter'] = filter_loader
    plugin

# Generated at 2022-06-11 10:40:26.102348
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    data = 'foo'
    obj = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

# Generated at 2022-06-11 10:40:26.682421
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:40:36.735684
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import ansible
    from ansible.module_utils.my_test import MockModuleUtilsTestCase
    ansible_path = os.path.dirname(ansible.__file__)
    collection_path = os.path.join(ansible_path, 'collections')

# Generated at 2022-06-11 10:40:43.984533
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    +'roles: # A comment, not an attribute'
    -'roles: # A comment, not an attribute'
    + '- name: foo'
    -'- name: foo'
    + '  bar: baz'
    -'  bar: baz'


    parent_role = RoleRequirement.load(dict(role='test'), variable_manager=MockVariableManager(), loader=MockLoader())

    ri = RoleInclude.load(
        play=MockPlay(),
        data='test',
        current_role_path='test',
        parent_role=parent_role,
        variable_manager=MockVariableManager(),
        loader=MockLoader(),
    )
    # Test it is a RoleInclude
    assert isinstance(ri, RoleInclude)

    # Test it is the same RoleIn

# Generated at 2022-06-11 10:40:44.924895
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    #TODO
    pass

# Generated at 2022-06-11 10:40:57.301387
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.plugins.loader import role_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    if not role_loader.all():
        role_loader.add_directory(os.path.join(os.getcwd(), 'test', 'data', 'test_role_included'))

    current_role_path = os.path.join(os.getcwd(), 'test', 'data', 'test_role_included')
