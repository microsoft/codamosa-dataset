

# Generated at 2022-06-11 10:39:18.142684
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    s = """
---
- hosts: localhost
  roles:
    - role: devops
      delegate_to: localhost
      delegate_facts: yes
      tags:
        - devops
        - p1
      args:
        role_arg1: val1
        role_arg2: val2
"""
    yaml_obj = AnsibleUnicode.from_unicode(s)
    yaml_data = AnsibleDumper.as_data(yaml_obj)
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_data = AnsibleLoader(yaml_data, None).get_single_data()

# Generated at 2022-06-11 10:39:28.575954
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
    
    # data = 'nginx_server'
    # current_role_path = 'roles/nginx_server'
    # parent_role = None
    # 
    # # expected_output = {'tasks': [{'name': 'printHello', 'action': {'': 'print', 'msg': 'Hello World!'}}, {'name': 'printGoodbye', 'action': {'': 'print', 'msg': 'Goodbye World!'}}], 'vars': {}, 'handlers': {}, 'meta': {'dependencies': [], 'application': '', 'galaxy_info': {'author': {'email': '', 'name': ''}, 'platforms': [], 'company': '', 'tags': [], 'min_ansible_version': '', 'documentation_url': '', 'issue_tr

# Generated at 2022-06-11 10:39:34.268041
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test for old style role requirements:
    try:
        RoleInclude.load("some,role", None)
        assert False
    except AnsibleError:
        assert True

    # Test for correct format:
    try:
        RoleInclude.load({}, None)
        assert True
    except AnsibleError:
        assert False

    # Test for invalid format:
    try:
        RoleInclude.load([], None)
        assert False
    except AnsibleError:
        assert True

# Generated at 2022-06-11 10:39:35.049838
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO:
    pass

# Generated at 2022-06-11 10:39:45.359835
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.loader import collection_loader
    from ansible.plugins.loader import resolve_collections_for_path

    play = Play.load(dict(
        name="Ansible Play",
        hosts=['all'],
        roles=[
            'geerlingguy.docker'
        ]
    ), variable_manager=None, loader=None)

    # Test roles:
    #    - named string - geerlingguy.docker
    #    - list - [geerlingguy.docker]
    #    - dict - {role: geerlingguy.docker}
    #    - dict with tags - {role: geerlingguy.docker, tags: docker}
    #    - dict with

# Generated at 2022-06-11 10:39:56.412434
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test

# Generated at 2022-06-11 10:40:06.212767
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleError
    
    # initialize needed objects
    loader = DataLoader()

# Generated at 2022-06-11 10:40:12.699435
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    roleInclude = RoleInclude.load(data=None, play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None)
    assert roleInclude is not  None

    roleInclude = RoleInclude.load(data='test_role', play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert roleInclude is not  None

# Generated at 2022-06-11 10:40:20.013321
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    - import_tasks: test1.yml
      allow_duplicates: True
      ignore_errors: False
    - import_tasks: test2.yml
      allow_duplicates: True
      ignore_errors: False
    - import_tasks: test3.yml
      allow_duplicates: True
      ignore_errors: False
    - import_playbook: test4.yml
    '''
    input_data = AnsibleLoader(data, 'test1.yml').get_single_data()

    current_role_path = '/home/test/demo'
    play = 'test_play'
    collection_list = []

# Generated at 2022-06-11 10:40:20.642094
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:40:32.341655
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    data = "test_data"
    # test for normal conditions
    try:
        role_include = RoleInclude.load(
            data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleParserError as e:
        assert 'Invalid role definition' in str(e)

    data = {
        'name': 'myrole',
        'description': u'foobar',
        'somevar': 'somevalue',
        'unknown': 'field',
        'collections': ['my.namespaced.collection'],
    }
    # test for normal conditions

# Generated at 2022-06-11 10:40:37.453681
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def foo1():
        RoleInclude.load(42)

    def foo2():
        RoleInclude.load('foo,bar')

    from pytest import raises
    from ansible.errors import AnsibleParserError
    from ansible.errors import AnsibleError

    with raises(AnsibleParserError):
        foo1()

    with raises(AnsibleError):
        foo2()

# Generated at 2022-06-11 10:40:40.284340
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

    #r = RoleRequirement()
    #r.role_name = 'geerlingguy-apache'
    #r.role_collections = None
    #ri.load('geerlingguy-apache')

# Generated at 2022-06-11 10:40:50.727584
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    vm = VariableManager()
    vm.extra_vars = {'foo': 'bar'}
    vm.options_vars = []

    play_context = PlayContext()
    play_context.connection = 'local'
    play_context.remote_user = 'test'

    role_definition = {
        'name': 'Test_role',
        'description': 'Just a test role',
        'tasks': [
            {
                'name': 'test',
                'debug': 'msg={{ foo }}'
            }
        ]
    }

    role_include = RoleInclude.load(data=role_definition, play=play_context, variable_manager=vm)


# Generated at 2022-06-11 10:41:01.745493
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    play_context.network_os = 'ios'
    assert play_context.network_os == 'ios'

    loader = DataLoader()
    variable_manager = VariableManager()
    #example of a dictionary that could be created by loading a playbook file
    d = {
        'hosts': 'localhost',
        'roles': ['common', 'apache'],
        'tasks': [{'name': 'Dummy task', 'command': 'dummy'}]
    }
    #example of a dictionary that could be created by loading a role file

# Generated at 2022-06-11 10:41:03.032115
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO(nandkumar): Write unit test for method load of class RoleInclude
    pass

# Generated at 2022-06-11 10:41:11.990007
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Unit test for method load of class RoleInclude."""
    # Setup required test variables
    data = {}
    data['name'] = 'role-name'
    data['tasks'] = []
    data['pre_tasks'] = []
    data['post_tasks'] = []
    data['default_vars'] = {}
    data['vars'] = {}
    data['metadata'] = {}
    data['handlers'] = {}
    data['files'] = []
    data['templates'] = {}
    data['dependencies'] = []
    
    # Create a AnsibleRole to test with
    arole = AnsibleRole()

    # Create a parser to load role definition.
    ri = RoleInclude()
    role_def = ri.load(data, arole)

    # Test the Role with data loaded

# Generated at 2022-06-11 10:41:12.841021
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-11 10:41:19.774855
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = dict(name="role name")
    play = dict(name="play name")
    current_role_path = "./some/role/path"
    ri = RoleInclude.load(data=data,
                          play=play,
                          current_role_path=current_role_path,
                          variable_manager=None,
                          loader=None)
    assert ri.get_name() == data["name"]
    assert ri._play == play
    assert ri._role_basedir == current_role_path

# Generated at 2022-06-11 10:41:28.914036
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Setup test variables
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.role.requiremen
    import ansible.parsing.yaml.data
    import ansible.utils.collection_loader

    from ansible.module_utils.six import string_types
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    from ansible.errors import AnsibleError, AnsibleParserError

    # Verify load raises AnsibleParserError on invalid role_definition
    fake_data = AnsibleBaseYAMLObject()
    fake_play = ansible.playbook.play.Play()
    fake_current_role_path = None
    fake_parent_role = None
    fake_variable_manager = None
    fake_loader = None
