

# Generated at 2022-06-11 10:39:12.834358
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # 1. not (string_types or dict or AnsibleBaseYAMLObject)
    try:
        RoleInclude.load([], None)
    except AnsibleParserError as e:
        assert "Invalid role definition: []" in to_native(e)

    # 2. string_types, not ','
    ri = RoleInclude.load('nginx', None)
    assert ri.get_name() == 'nginx'

    # 3. string_types and ','
    try:
        RoleInclude.load('nginx,hoge', None)
    except AnsibleError as e:
        assert "Invalid old style role requirement: nginx,hoge" in to_native(e)

    # 4. AnsibleBaseYAMLObject
    o = AnsibleBaseYAMLObject()

# Generated at 2022-06-11 10:39:23.665356
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    This test case tests method load of class RoleInclude
    """
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Creating inventory obj
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='local')

    # Creating variable obj
    variable_manager = VariableManager()

    # Creating play obj
    play_obj = Play()

    # Creating play_context obj
    play_context = play_obj.set_play_context(variable_manager=variable_manager, loader=loader)

    # Creating RoleInclude obj

# Generated at 2022-06-11 10:39:33.917321
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager, PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-11 10:39:35.925149
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # Test load
    # Test load with invalid data
    # Test load with string
    # Test load with dict
    # Test load with AnsibleBaseYAMLObject

    assert True

# Generated at 2022-06-11 10:39:36.498744
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert True

# Generated at 2022-06-11 10:39:47.457124
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    
    loader = DataLoader()
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello World!'))),
        ]
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=loader)


# Generated at 2022-06-11 10:39:58.228633
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    class FakeRole(RoleDefinition):
        _role_name = FieldAttribute(isa='string')
        _role_path = FieldAttribute(isa='string')
        _role_collection = FieldAttribute(isa='string')
        _task_blocks = FieldAttribute(isa='list', default=[])
        _default_vars = FieldAttribute(isa='dict', default={})
        _role_vars = FieldAttribute(isa='dict', default={})
        _role_metadata = FieldAttribute(isa='dict', default={})
        _role_params = FieldAttribute(isa='dict', default={})
        _role_default_vars = FieldAttribute(isa='dict', default={})


# Generated at 2022-06-11 10:40:03.953514
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Initialize a role include object
    ri = RoleInclude.load(
        data='name=geerlingguy.apache',
        play=None,
        current_role_path=None,
        parent_role=None,
        variable_manager=None,
        loader=None,
        collection_list=None
    )
    # Assert name attribute of the object
    assert ri.get_name() == 'geerlingguy.apache'

# Generated at 2022-06-11 10:40:10.664623
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.parsing.yaml.objects import AnsibleUnicode

    try:
        RoleInclude.load('role1', None, None)
    except AnsibleError as e:
        pass

    try:
        RoleInclude.load(AnsibleUnicode('- role1'), None, None)
    except AnsibleError as e:
        pass

    try:
        RoleInclude.load(dict(role1='something'), None, None)
    except AnsibleError as e:
        pass

# Generated at 2022-06-11 10:40:18.809186
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    pc = PlayContext()
    current_role_path = os.getcwd()
    templar = Templar(loader=None, variables=VariableManager(), shared_loader_obj=None)
    ri = RoleInclude.load('"{{ var1 }}" , "{{ var2 }}"', pc, current_role_path, templar)
    assert ri
    assert ri._role_name == '"{{ var1 }}"'
    assert ri._role_path == '"{{ var2 }}"'

    ri = RoleInclude.load('var1, var2', pc, current_role_path, templar)
    assert ri
    assert ri._role