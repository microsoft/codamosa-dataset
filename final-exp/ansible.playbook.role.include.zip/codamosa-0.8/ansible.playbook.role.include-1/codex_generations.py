

# Generated at 2022-06-11 10:39:07.307828
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert isinstance(ri, RoleInclude)


# Generated at 2022-06-11 10:39:18.191153
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # testing with name as string, valid requirement
    data_str = "users,nostart=yes,tags=role"
    role_path = "/etc/ansible/roles"
    play = None
    variable_manager = None
    collection_list = None

    # testing with valid old style string
    assert RoleInclude.load(data_str, play, role_path, variable_manager, collection_list) == None

    # testing with empty string
    data_empty_str = ""
    assert RoleInclude.load(data_empty_str, play, role_path, variable_manager, collection_list) == None

    # testing with name as dictionary
    data = {
                "role": "users",
                "tags": "role",
                "nostart": "yes"
            }


# Generated at 2022-06-11 10:39:28.669561
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test old role requirement style
    data = 'nginx'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None

    try:
        ri = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
    except AnsibleError:
        pass
    else:
        assert False, "Old role requirement style should raise an AnsibleError."

    # test case of a simple string
    data = 'common'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None


# Generated at 2022-06-11 10:39:37.039597
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test for method load of class RoleInclude
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    my_loader = DataLoader()
    my_inventory = InventoryManager(loader=my_loader, sources=['/etc/ansible/hosts'])
    my_variable_manager = VariableManager(loader=my_loader, inventory=my_inventory)
    my_play_context = PlayContext(variable_manager=my_variable_manager)

# Generated at 2022-06-11 10:39:37.578027
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    assert 0

# Generated at 2022-06-11 10:39:48.722731
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import tempfile
    import shutil
    import os.path
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins import role_loader

    p = Play()
    p.hosts = 'all'
    p.vars = {'foo': 'bar'}

    role_def_path_src = 'test_role_def'
    role_def_path = tempfile.mkdtemp()
    shutil.copytree(os.path.dirname(__file__) + '/' + role_def_path_src, role_def_path)

    ri = RoleInclude(play=p, role_basedir=role_def_path, variable_manager=None, loader=role_loader)
    role_def = ri.load

# Generated at 2022-06-11 10:39:59.344638
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    try:
        from ansible.plugins.loader import get_all_plugin_loaders
        has_your_plugin = False
        for name, cls in iteritems(get_all_plugin_loaders()):
            if name == 'your_plugin':
                has_your_plugin = True
                break
        if not has_your_plugin:
            raise Exception('your_plugin')
    except ImportError:
        pass
    except Exception as e:
        if str(e) != 'your_plugin':
            raise

    data = 'your_plugin'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None

# Generated at 2022-06-11 10:40:09.682791
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import RoleRequirement
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback.default import CallbackModule
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native
    from ansible.parsing.yaml.loader import AnsibleLoader
    import os
    import sys

    #test case for string type
    loader = DataLoader()
    inventory = InventoryManager

# Generated at 2022-06-11 10:40:17.723727
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {'role': 'role1', 'tags': ['tag1', 'tag2'], 'when': 'when1'}
    play = dict()
    current_role_path = 'rolepath'
    variable_manager = VariableManager()
    loader = DataLoader()
    collection_list = None

    ri = RoleInclude.load(data, play, current_role_path, None, variable_manager, loader, collection_list)

    assert ri.role_name == 'role1'
    assert ri._role_name == 'role1'
    assert ri.name == 'role1'
    assert ri.tags == set(['tag1', 'tag2'])
    assert ri.when == 'when1'

# Generated at 2022-06-11 10:40:28.249655
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 'from_extra'}
    variable_manager.options_vars = [{'test_var': 'from_options'}]

    variable_manager.set_nonpersistent_facts({'test_variable': 'from_fact'})

    context = PlayContext()
    context._hosts = ['127.0.0.1']

# Generated at 2022-06-11 10:40:40.215962
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Create a new RoleInclude object
    ri = RoleInclude(None)

    # Check that raise exception for invalid role definition (integer)
    try:
        ri.load(42, None)
        assert False
    except AnsibleParserError:
        assert True

    # Check that raise exception for invalid role definition (none)
    try:
        ri.load(None, None)
        assert False
    except AnsibleParserError:
        assert True

    # Check that raise exception for invalid role definition (list)
    try:
        ri.load([], None)
        assert False
    except AnsibleParserError:
        assert True

    # Check that raise exception for invalid role definition (dict)
    try:
        ri.load({}, None)
        assert False
    except AnsibleParserError:
        assert True



# Generated at 2022-06-11 10:40:40.942058
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:40:51.657577
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.variable_manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    collection_loader = AnsibleCollectionLoader()

    inventory = PlaybookExecutor.inventory
    variable_manager = PlaybookExecutor.variable_manager

    # load the role definition and test it
    ri = RoleInclude()
    ri.load('role1',  AnsibleBaseYAMLObject('[1, 2]'))
    assert 'role1' == ri._role_name
    assert 'role1' == ri._role_name

    ri = RoleInclude()


# Generated at 2022-06-11 10:41:02.178838
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.dumper import AnsibleDumper

    loader = None
    collection_list = None

    # data = dict(role=dict(name='test-role', tasks=[dict(action=dict(module='debug', args=dict(msg='hello world')))]))
    data = dict(role=dict(name='test-role', tasks=[dict(action=dict(module='debug', args=dict(msg='hello world')))]))
    print('data=')
    print('%s' % AnsibleDumper(data, default_flow_style=False).get_value())

    play_context = PlayContext()
    variable_manager = VariableManager()
    # variable_manager.

# Generated at 2022-06-11 10:41:11.038372
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.factory import Factory as ProcessExecutorFactory
    from ansible.executor.action_writer import ActionWriter

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    context = PlayContext()
    play = Play()
   

# Generated at 2022-06-11 10:41:20.670581
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    """Unit test for method load of class RoleInclude"""

    # Create a loader for loading playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import combine_vars

    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 10:41:29.772418
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play
    from ansible.vars import VariableManager

    variables = VariableManager()
    play = Play()
    role = RoleInclude(play=play, role_basedir="roles", variable_manager=variables, loader=None)
    d = dict(
        name="test",
        foo="bar"
    )

    try:
        role.load(d, play, None, None,
                  variables, None)
        assert False
    except AnsibleParserError:
        assert True

    except AnsibleError:
        assert False
    try:
        role.load(12, play, None, None,
                  variables, None)
        assert False
    except AnsibleParserError:
        assert True

    except AnsibleError:
        assert False


# Generated at 2022-06-11 10:41:39.980148
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    d = dict()
    d['playbook'] = dict()
    d['playbook']['tasks'] = [{'debug':'msg="hello world"'}]

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.modules.debug import *
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'dummy': 'dummmy'}
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])

# Generated at 2022-06-11 10:41:50.423275
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    # 1. simple play
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-11 10:42:00.400253
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    l = []
    ri = RoleInclude.load("mdehaan.a_role",l,None,None)
    assert ri._role_name == "a_role"
    assert ri._role_path == "mdehaan.a_role"
    ri = RoleInclude.load("mdehaan.a_role,v1.0,devel",l,None,None)
    assert ri._role_name == "a_role"
    assert ri._role_path == "mdehaan.a_role"
    assert ri._role_requirements_file == "v1.0"
    assert ri._embedded_role_vars_file == "devel"