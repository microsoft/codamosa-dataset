

# Generated at 2022-06-11 10:39:13.821148
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    # Setup the loader, inventory, variable manager
    loader = DataLoader()
    inv = Inventory("tests/inventory")
    var_mgr = VariableManager()
    var_mgr.set_inventory(inv)

    play = Play()
    play._variable_manager = var_mgr
    play._loader = loader
    role = RoleInclude(play=play, role_basedir=None, variable_manager=var_mgr, loader=loader, collection_list=None)

    # Test function load of class RoleInclude
    data = "ansible.test1.role-test"

# Generated at 2022-06-11 10:39:24.503599
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test for method load of class RoleInclude
    Supported only for python3.
    """
    from ansible.playbook import Play
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader

    if PY3:
        loader = DataLoader()
    else:
        loader = None
    variabl_manager = VariableManager()
    vault_secrets = dict(vault_password='secret')
    vault

# Generated at 2022-06-11 10:39:28.252960
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert ri.load("my-name",None,None,None,None,None) is not None
    assert ri.load("my-name,other-name",None,None,None,None,None) is not None

# Generated at 2022-06-11 10:39:36.819381
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.requirement import RoleRequirement

    class MockPlayContext(PlayContext):
        def __init__(self):
            pass
    class MockStr(object):
        def __init__(self):
            self.module_name = 'shell'
        def __str__(self):
            return "mock string object"


# Generated at 2022-06-11 10:39:47.805719
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    This method tests whether the load method of the RoleInclude class loads the role definition
    from the role
    """
    from collections import namedtuple
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_options_vars


# Generated at 2022-06-11 10:39:58.538609
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    a = '''
    - role: myrole
    '''
    b = '''
    - role: myrole
      delegate_to: localhost
      delegate_facts: yes
      vars:
        x: 1
        y:
          - 1
          - 2
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode

    x = AnsibleMapping()
    x.update(dict(
        name=AnsibleUnicode('myrole'),
        tasks='main.yml',
        handlers='main.yml',
        meta='main.yml'
    ))

    y = AnsibleMapping()

# Generated at 2022-06-11 10:40:08.699179
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Instantiate an object and load data with it
    test_data = {'name': 'test_role', 'role_path': 'some/path/to/role', 'defaults': {'foo': 'bar'}, 'vars': {'baz': 'foo'}, 'meta': {'qux': 'quux'}}
    role = RoleInclude()
    role.load_data(test_data)

    assert role.get_name() == test_data['name']
    assert role.get_role_path() == test_data['role_path']
    assert role.get_default_vars() == test_data['defaults']
    assert role.get_vars() == test_data['vars']
    assert role.get_metadata() == test_data['meta']



# Generated at 2022-06-11 10:40:17.625594
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    def _mock_collection_finder(collection):
        return collection

    class _mock_loader(object):
        def __init__(self):
            self.collection_finder = _mock_collection_finder

    class _mock_variable_manager(object):
        def __init__(self):
            self.extra_vars = {}

    # what we're testing
    from ansible.playbook.role.definition import RoleDefinition

    class RoleInclude(RoleDefinition):
        # Override for testing purposes
        @staticmethod
        def _load_list_of_roles(data, parent_role=None, loader=None):
            return data


# Generated at 2022-06-11 10:40:28.122927
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    context = PlayContext()
    play = Play().load({}, loader=loader, variable_manager=VariableManager())

    data={"name": "geerlingguy.apache"}
    ri = RoleInclude.load(data, play)
    assert isinstance(ri, RoleInclude)
    assert ri.name == "geerlingguy.apache"
    assert ri.role_name == "apache"
    assert ri.role_path is None
    assert ri.role_basedir is None
    assert isinstance(ri.role, RoleRequirement)


# Generated at 2022-06-11 10:40:29.173532
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-11 10:40:35.242389
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print('Test RoleInclude load')

    # TODO: write unit test
    # The method load from class RoleInclude is used in the following files:
    # * ansible/playbook/play_context.py
    # * ansible/playbook/play.py

# Generated at 2022-06-11 10:40:37.075899
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play

# Generated at 2022-06-11 10:40:44.152636
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Unit test of method `RoleInclude.load`
    """
    # Data fixtures
    # ------------
    # Strings with data to load
    str_data0 = "test_RoleInclude_load"
    str_data1 = "test_RoleInclude_load,test_RoleInclude_load"
    str_data2 = {"test_RoleInclude_load": "test_RoleInclude_load"}
    str_data3 = {"test_RoleInclude_load": {"test_RoleInclude_load": "test_RoleInclude_load"}}
    str_data4 = {"test_RoleInclude_load": {"test_RoleInclude_load": "test_RoleInclude_load"}, "test_RoleInclude_load1": "test_RoleInclude_load"}

# Generated at 2022-06-11 10:40:56.501435
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import role_loader

    role_include = RoleInclude(play=Play())

    play_context = dict(
        network_os='ios',
        other=dict(some_var=123)
    )

    role_include.play._variable_manager = dict()
    role_include.play._variable_manager._fact_cache = dict()
    #role_include.play.context = play_context
    #role_include.play._variable_manager._extra_vars = play_context
    role_include._variable_manager = dict()
    role_include._variable_manager._fact_cache = dict()
    #role_include._variable_manager.set_extra_v

# Generated at 2022-06-11 10:41:00.737208
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = "testuser.testapp"
    play = {}
    current_role_path = None
    parent_role = None
    variable_manager = {}
    loader = {}
    collection_list = []
    ri = RoleInclude.load(data=data, play=play, current_role_path=current_role_path, parent_role=parent_role, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri.get_name() == "testuser.testapp"


# Generated at 2022-06-11 10:41:09.383512
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader


    myplay = Play().load({"hosts": "all", "gather_facts": "no", "tasks": [{"action": {"module": "debug", "args": {"msg": "Hello World"}}}]}, variable_manager=None, loader=action_loader)
    PlayContext().load('all', None, 'none', None)
    ri = RoleInclude()

    ri.load('jdauphant.nginx', play=myplay)
    assert ri._role_name == "jdauphant.nginx"
    assert ri._role_path == "jdauphant.nginx"
    assert ri._task_blocks == []


# Generated at 2022-06-11 10:41:18.580468
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    import tempfile
    import shutil
    import ansible.playbook.role.definition

    # create a test directory with a subdirectory containing a test role
    tmpdir_path = tempfile.mkdtemp()
    tmpdir_path2 = tempfile.mkdtemp(prefix='ansible_test_roles2')
    tmpdir_path3 = tempfile.mkdtemp(prefix='ansible_test_roles3')

# Generated at 2022-06-11 10:41:25.960158
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    if '__unittest_RoleInclude' in globals():
        return globals()['__unittest_RoleInclude']
    # Initialize a role include object and data to test
    ri = RoleInclude()
    data = {'name':'test', 'remote_user': 'test'}

    # Result is returned
    test_result = ri.load(data, [])
    __unittest_RoleInclude = test_result
    globals()['__unittest_RoleInclude'] = __unittest_RoleInclude
    return test_result



# Generated at 2022-06-11 10:41:36.521136
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    data = 'role1'
    collection_list = None
    play = PlayContext()
    current_role_path = None
    parent_role = None
    variable_manager = VariableManager()
    loader = None
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert ri.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list) == ri
    data = 'role2,rolename'

# Generated at 2022-06-11 10:41:43.415104
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()

    current_role_path = os.path.join(os.path.dirname(__file__), "../../../test/units/module_utils/test_role_include")
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list='./test/units/module_utils/ansible_inventory_test'))
    play_context = dict(
        basedir=current_role_path,
        roles_path='../../../../test/units/roles'
    )
   

# Generated at 2022-06-11 10:41:58.316193
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager(loader=None)

    role_include = RoleInclude(play=None, role_basedir=None, variable_manager=variable_manager, loader=None)

    res = role_include.load(data=None, play=None, current_role_path=None, parent_role=None, variable_manager=variable_manager, loader=None, collection_list=None)
    assert res == False

    res = role_include.load(data="str", play=None, current_role_path=None, parent_role=None, variable_manager=variable_manager, loader=None, collection_list=None)
    assert res == False

    res = role

# Generated at 2022-06-11 10:42:07.767557
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory


# Generated at 2022-06-11 10:42:17.847003
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """Tests RoleInclude's load method"""


# Generated at 2022-06-11 10:42:24.307054
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = 'test,test'
    play = ''
    current_role_path = ''
    parent_role = ''
    variable_manager = ''
    loader = ''
    collection_list = ''
    try:
        x = RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)
        raise Exception('Expected an AnsibleError in the load method of RoleInclude class')
    except AnsibleError:
        pass
    except Exception as e:
        raise e

# Generated at 2022-06-11 10:42:35.070453
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play = dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    variable_manager = VariableManager()
    loader = None
    collection_list = []
    context = PlayContext(play=play, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    play._variable_manager = variable_manager

    ri = RoleInclude(play=play)

    role_data

# Generated at 2022-06-11 10:42:39.549565
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = dict(
        name="test-role",
        tasks=dict(
            a="do something",
        )
    )
    # TODO: Find another way to do this test
    #if not isinstance(data, string_types) or ',' not in data:
    ri = RoleInclude()
    return ri.load_data(data)

# Generated at 2022-06-11 10:42:48.136518
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import Role
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.plugins.loader import load_plugin_cache

    def load_module_expect_failure(module_name, *args, **kwargs):
        try:
            load_plugin_cache(module_name, *args, **kwargs)
        except:
            return True
        return False

    # play.yml
    play_i = Play.load({
        "name": "test_RoleInclude_load",
        "hosts": ["localhost"],
        "roles": [
            {"role": "sub_role"}
        ]
    }, loader=None)
    # sub_role/meta/main.yml
    sub

# Generated at 2022-06-11 10:42:52.735804
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # test load of string type
    data = 'role'
    play = None
    current_role_path = None
    parent_role = None
    variable_manager = None
    loader = None
    collection_list = None
    ri = RoleInclude()
    assert isinstance(ri.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list), RoleInclude)

    # test load of dict type
    data = {'role': 'role'}
    ri = RoleInclude()
    assert isinstance(ri.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list), RoleInclude)

# Generated at 2022-06-11 10:42:53.553026
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass

# Generated at 2022-06-11 10:42:58.362553
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    data = 'foo,bar,baz'

    try:
        ri.load(data)
    except Exception as e:
        if e.__str__() == 'Invalid old style role requirement: foo':
            print("Exception captured as expected")
        else:
            assert False, "Expected an exception saying Invalid old style role requirement"

# Generated at 2022-06-11 10:43:15.514055
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # No role name
    data = dict()
    try:
        RoleInclude.load(data, None, None)
        assert False
    except AnsibleError as e:
        assert 'Must define a role name' in str(e)

    # Role name is invalid
    data = dict(role="foo,bar")
    try:
        RoleInclude.load(data, None, None)
        assert False
    except AnsibleError as e:
        assert 'Invalid old style role requirement' in str(e)

    # Role name is not a string
    data = dict(role=dict())
    try:
        RoleInclude.load(data, None, None)
        assert False
    except AnsibleParserError as e:
        assert 'must be a string' in str(e)

    # Role name is a string

# Generated at 2022-06-11 10:43:23.249535
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.variable_manager import VariableManager

    loader=None
    collection_list=None
    variable_manager = VariableManager()
    play = Play().load({}, loader=loader, variable_manager=variable_manager, collection_list=collection_list)
    play._included_file = "/root/role.yml"

    data = "common,database"

    ri = RoleInclude.load(data, play)

    assert isinstance(ri, RoleInclude)

# Generated at 2022-06-11 10:43:33.058752
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import sys
    import os
    import pytest
    from ansible.playbook.play import Play
    from ansible.playbook.play import Playbook
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    cur_dir = os.path.dirname(os.path.abspath(__file__))
    data_file = os.path.join(cur_dir, '../../../../lib/ansible/playbook/data/role_include_data.yml')

    variable_manager = Variable

# Generated at 2022-06-11 10:43:42.090797
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    current_role_path='/var/lib/awx/projects/test/roles'
    role_definition={
        'name': 'test_role',
        'description': 'Ansible Galaxy test role.',
        'defaults': {
            'some_var': 'some_value',
        },
        'tasks': [
            {
                'name': 'name'
            }
        ],
    }
    ri = RoleInclude(current_role_path=current_role_path)
    ri.load(role_definition)
    assert ri.role_name == "test_role"
    assert ri._role_path == current_role_path+'/test_role'
    assert ri.role_name == "test_role"
    assert ri.default_vars['some_var']

# Generated at 2022-06-11 10:43:45.808806
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    result = RoleInclude.load('test_role', play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
    assert result is not None
    assert result._role_name == 'test_role'
    assert result._role_path == ['test_role']

# Generated at 2022-06-11 10:43:55.018656
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # test with string
    data = 'role_name,another_role_name'
    loader = 'loader'
    variable_manager = 'variable_manager'
    play = 'play'
    current_role_path = 'current_role_path'
    with pytest.raises(AnsibleError):
        RoleInclude.load(data, play, current_role_path, variable_manager=variable_manager, loader=loader)
    # test with dict
    data = {'role_name': 'another_role_name'}
    with pytest.raises(AnsibleParserError):
        RoleInclude.load(data, play, current_role_path, variable_manager=variable_manager, loader=loader)
    # test with AnsibleBaseYAMLObject
    data = AnsibleBaseYAMLObject()
   

# Generated at 2022-06-11 10:43:59.909593
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    result = RoleInclude.load(data='myrole', play=None, current_role_path=None, parent_role=None,
                              variable_manager=None, loader=None, collection_list=None)
    assert result.name == 'myrole'

# The only way to run this is doing it serperately with py.test

# Generated at 2022-06-11 10:44:08.631627
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play

    fake_loader = DictDataLoader({
        os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test', 'data', 'roles', 'test1', 'meta', 'main.yml'): """
        dependencies:
            - { role: test2 }
        """
    })

    play = Play().load({}, variable_manager={}, loader=fake_loader)
    ri = RoleInclude.load('test1', play, collection_list=['local'])
    assert len(ri.get_dependencies()) == 1
    assert ri.get_dependencies()[0].get_name() == 'test2'


# Generated at 2022-06-11 10:44:14.823111
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data=dict(
        name='test_role',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='This is a test')))
        ]
    )
    loader = None
    play = None
    ri = RoleInclude.load(data, play)
    assert ri._role_name == 'test_role'


# Generated at 2022-06-11 10:44:17.068193
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    data = {'name': 'myrole'}
    role = RoleInclude()
    assert role.load_data(data) is True