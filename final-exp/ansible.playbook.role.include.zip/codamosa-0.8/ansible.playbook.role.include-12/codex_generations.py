

# Generated at 2022-06-11 10:39:04.982823
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # TODO: to be implemented.
    ret = True

    return ret


# Generated at 2022-06-11 10:39:14.593624
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # start testing
    ri = RoleInclude()
    try:
        ri.load(data="test", play=None, current_role_path=None, parent_role=None, variable_manager=None, loader=None, collection_list=None)
        assert False, "Expected AnsibleError, but was not raised."
    except AnsibleError as e:
        assert "Invalid role definition" in str(e), "Unexpected error raised: '%s'." % str(e)

    ri = RoleInclude()

# Generated at 2022-06-11 10:39:16.180199
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    print('Executing tests for method load of class RoleInclude')



# Generated at 2022-06-11 10:39:17.358640
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # TODO: implement this test
    pass

# Generated at 2022-06-11 10:39:27.852077
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    # Testing load a role of a role_definition
    data = "test-role"
    ri = RoleInclude()
    result = ri.load(data, None)
    assert result.get_name() == "test-role"
    assert result.get_var("role_name") == "test-role"
    assert result.get_var("role_path") is None

    # Testing load a role_requirement
    data = dict(role=dict(name="test-role"))
    ri = RoleInclude()
    result = ri.load(data, None)
    assert result.get_name() == "test-role"
    assert result.role_name == "test-role"
    assert result.role_path is None

    # Testing load a role_requirement

# Generated at 2022-06-11 10:39:36.622655
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    queue_manager = TaskQueueManager(inventory=None, variable_manager=variable_manager, loader=loader, options=None, passwords={})


# Generated at 2022-06-11 10:39:47.615432
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.module_utils.pkg_resources import parse_requirements
    import ansible.constants as C

    add_all_plugin_dirs()

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play()

    basedir = './test/lib/ansible/modules/network/cloudengine'

# Generated at 2022-06-11 10:39:58.369303
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    import sys
    sys.path.insert(0, os.path.dirname(__file__))
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # Create a new play
    play = Play()

    # Create a new variable manager
    variable_manager = VariableManager()

    # Create a new inventory

# Generated at 2022-06-11 10:39:59.302288
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-11 10:40:05.062635
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert ri.load('name,scenario=foo,version=0.1,private=true') == {
        'name': 'name', 'scenario': 'foo', 'version': '0.1', 'private': True}
    assert ri.load('name') == {'name': 'name'}
    assert ri.load({'name': 'name'}) == {'name': 'name'}

# Generated at 2022-06-11 10:40:16.111454
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    # role-include.yml
    # ---
    # - name: test-role-include
    #   become: False
    #   vars:
    #     test_role_include_var: test role include var
    #   tasks:
    #     - name: test role include task
    #       debug: msg="Test role include task"

    from ansible.playbook.play import Play

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    from unit.mock.loader import DictDataLoader
    from unit.mock.vault import VaultLib

    import yaml

    # Load example play
    example_play_file_path = os

# Generated at 2022-06-11 10:40:18.273104
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    obj = RoleInclude.load("test_role", "play")
    assert isinstance(obj, RoleInclude)


if __name__ == "__main__":
    test_RoleInclude_load()

# Generated at 2022-06-11 10:40:19.088898
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass


# Generated at 2022-06-11 10:40:29.559777
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.play import Play
    from ansible.playbook.role import RoleRequirement

    # Dummy data
    current_role_path='/home/kwebster/servers/'
    data='fail2ban'
    play = Play()
    variable_manager = None
    loader = None
    collection_list = None
    parent_role = None
    RoleInclude.load(data, play, current_role_path, parent_role, variable_manager, loader, collection_list)

    # Annoyingly, load_data isn't called, so do it manually
    ri = RoleInclude(play=play, role_basedir=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

# Generated at 2022-06-11 10:40:35.193645
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    ri = RoleInclude()
    assert ri.__class__.__name__ == 'RoleInclude'
    # load with wrong data type
    # load with deprecated role requirement
    with pytest.raises(AnsibleError) as execinfo:
        ri.load(data=[1, 2, 3], play='play.yml')
    assert 'Invalid role definition:' in execinfo.value.message


# Generated at 2022-06-11 10:40:41.253965
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    from ansible.playbook.play import Play
    data = '''
    - role: apache
    - role: tomcat
        tasks_from: deploy
        vars_from: vars/main.yml
    - role:
      - webserver
      - tomcat
    '''

    for i in RoleInclude.load(data, Play().load(data, dict(), True)):
        assert type(i) == RoleInclude

if __name__ == '__main__':
    test_RoleInclude_load()

# Generated at 2022-06-11 10:40:52.206827
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader, AnsibleLoaderBase

    yaml_str = """
---
include: test
"""
    yaml_data = AnsibleLoader(yaml_str, file_name='test_playbook.yml', class_loader_module=AnsibleLoaderBase).get_single_data()

    RoleInclude.load(yaml_data, None)

    # with error
    yaml_str = """
---
include: test
      raise_errors: True
      ignore_errors: True
"""

# Generated at 2022-06-11 10:41:02.493921
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    pass
#'''
if __name__ == '__main__':
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-11 10:41:10.481578
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():

    from ansible.playbook.role.definition import RoleDefinition
    # This will first create a new role
    # Then it will load the role
    # After that it will check if the attributes are correctly loaded

    req = RoleDefinition()
    req_dict = req.get_info()
    # The dictionary req_dict contains the default values for the attributes of a RoleDefinition
    # We will use these default values to test if the method load of class RoleInclude is
    # using the correct values

    # Create new role
    my_role = RoleInclude()
    my_role_dict = my_role.get_info()
    # Check if all attributes are correctly loaded
    assert my_role_dict == req_dict

# Generated at 2022-06-11 10:41:20.080966
# Unit test for method load of class RoleInclude
def test_RoleInclude_load():
    """
    Test load method of RoleInclude class

    Unit test function to test the load method of class RoleInclude.
    """
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=DataLoader(), sources=["localhost", "test_inventory"])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_context = PlayContext()

    my_role = AnsibleBaseYAMLObject()
    my_role.role = "test-role"
    my_role.collections = []
