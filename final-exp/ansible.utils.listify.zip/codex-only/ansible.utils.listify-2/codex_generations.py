

# Generated at 2022-06-23 14:17:35.197562
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.plugins import PluginLoader

    vault_pass = 'secret'
    loader = DataLoader()
    vault = VaultLib([], [], loader=loader)

    vars_manager = VariableManager()
    vars_manager.set_vault_secrets(['default'], loader=loader, vault_ids=['default'], vault_password=vault_pass)

    templar = Templar(loader=loader, variables=vars_manager)

    # Testing string expansion from templar

# Generated at 2022-06-23 14:17:45.488785
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    templar = Templar(loader=None, variables={'a': 'b'})

    assert listify_lookup_plugin_terms("yes", templar, None) == ["yes"]
    assert listify_lookup_plugin_terms(["yes", "no"], templar, None) == ["yes", "no"]
    assert listify_lookup_plugin_terms("{{ a }}", templar, None) == ["b"]
    assert listify_lookup_plugin_terms(["{{ a }}", "no"], templar, None) == ["b", "no"]

    # test with vault
    data = VaultLib([])

# Generated at 2022-06-23 14:17:49.824175
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.loader import lookup_loader
    pl = lookup_loader._create_plugin_loader()
    filt = pl.get('random')
    assert isinstance(filt, pl._get_interface('lookup').random)
    assert filt.run([], {}) is not None

# Generated at 2022-06-23 14:17:58.253066
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    import ansible.parsing.yaml.objects
    import ansible.utils.unsafe_proxy
    from ansible import context
    from ansible.vars.manager import VariableManager
    terms = ' not_a_list '
    templar = Templar(loader=None, variables=VariableManager())
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['not_a_list']
    terms = '''[item1, item2]'''
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['item1', 'item2']
    terms = [ansible.parsing.yaml.objects.AnsibleUnicode('item1')]


# Generated at 2022-06-23 14:18:08.993539
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'nums': [1,2,3]}
    templar = Templar(loader=loader, variable_manager=variable_manager)

    assert listify_lookup_plugin_terms("{{ nums }}", templar, loader) == [1,2,3]
    assert listify_lookup_plugin_terms("{{ [1, 2, 3] }}", templar, loader) == [1, 2, 3]
    assert listify_lookup_plugin_terms("{{ 1 }}", templar, loader) == [1]
    assert listify_lookup

# Generated at 2022-06-23 14:18:20.188977
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import os
    import sys
    lib = os.path.join(os.path.dirname(__file__), "..", "..")
    if lib not in sys.path:
        sys.path.insert(0, lib)

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Options:
        connection = 'local'
        module_path = ''
    class PlayContext:
        def __init__(self):
            self.connection = 'local'
    loader = DataLoader()

# Generated at 2022-06-23 14:18:30.166736
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.templating.templar import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    display = Display()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 14:18:37.524785
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import safe_eval

    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']
    assert listify_lookup_plugin_terms(u'foo', None, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(safe_eval('["foo", "bar"]'), None, None) == ['foo', 'bar']

# Generated at 2022-06-23 14:18:41.962736
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms("foo", templar, None) == ["foo"]
    assert listify_lookup_plugin_terms("foo bar", templar, None) == ["foo bar"]
    assert listify_lookup_plugin_terms("foo,bar", templar, None) == ["foo,bar"]
    assert listify_lookup_plugin_terms(["foo", "bar"], templar, None) == ["foo", "bar"]
    assert listify_lookup_plugin_terms("{{ myvar }}", templar, None, convert_bare=True) == ["{{ myvar }}"]

# Generated at 2022-06-23 14:18:51.120769
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    loader = DataLoader()
    paths = C.DEFAULT_MODULE_PATH

    lookup_loader.add_directory(paths)
    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=False)
    inventory = Inventory(loader=loader, variable_manager=variable_manager)


# Generated at 2022-06-23 14:19:01.546847
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class DummyVars(object):
        def __init__(self):
            self.hostvars = dict(
                host1=dict(ansible_facts=dict(foo=1)),
                host2=dict(ansible_facts=dict(foo=2)),
                host3=dict(ansible_facts=dict(foo=3)),
            )

    class DummyModule(object):
        def __init__(self):
            self.vars = DummyVars()


# Generated at 2022-06-23 14:19:11.450592
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list='localhost')

    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 14:19:16.463377
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = [[1,2],[3,4]]
    assert listify_lookup_plugin_terms(terms) == terms
    assert listify_lookup_plugin_terms([terms]) == terms
    assert listify_lookup_plugin_terms(str(terms)) == terms
    assert listify_lookup_plugin_terms(str([terms])) == terms

# Generated at 2022-06-23 14:19:26.399455
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    from ansible.vars import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    assert listify_lookup_plugin_terms([], templar, loader=None, fail_on_undefined=True, convert_bare=False) == []

    assert listify_lookup_plugin_terms(' {{ foo }} ', templar, loader=None, fail_on_undefined=True, convert_bare=False) == []

    assert listify_lookup_plugin_terms(' {{ foo }} ', templar, loader=None, fail_on_undefined=False, convert_bare=False) == [' {{ foo }} ']


# Generated at 2022-06-23 14:19:37.274328
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    fail_on_undefined = True
    convert_bare = False

    # Check with a string
    test_string = "this,is,a,string"
    expected_result = ["this", "is", "a", "string"]

    test_result = listify_lookup_plugin_terms(terms=test_string, templar=None, loader=None, fail_on_undefined=fail_on_undefined, convert_bare=convert_bare)
    assert test_result == expected_result

    # Check with a list containing a string
    test_list = ["this,is,a,string"]
    expected_result = ["this,is,a,string"]


# Generated at 2022-06-23 14:19:47.607535
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Return an empty list if a blank string is passed in
    assert listify_lookup_plugin_terms('', None, None) == []

    # Return a list with a single item if a non-blank string is passed in
    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']

    # Return a single-item list with a single AnsibleUnsafeText item if a non-blank AnsibleUnsafeText string is passed in
    assert listify_lookup_plugin_terms(AnsibleUnsafeText('foo'), None, None) == [AnsibleUnsafeText('foo')]

    # Return a list with a single item if a list of one item is passed in

# Generated at 2022-06-23 14:19:58.861031
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    ldr = AnsibleLoader(None, variable_manager=None)
    t = Templar(loader=ldr, variable_manager=None, shared_loader_obj=None)

    # Make sure simple string returns a list of strings
    simple_strings = ['hello', 'world', 'how', 'are', 'you']
    simple_output = listify_lookup_plugin_terms(simple_strings, t, ldr)
    assert(simple_output == simple_strings)

    # Make sure complex type returns a list
    complex_strings = ['{{ myvar }}', '{{ yourvar }}', '{{ var1 }}', '{{ var2 }}', '{{ var3 }}']

# Generated at 2022-06-23 14:20:08.095382
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager

    def _mock_loader(self, path):
        ds = {}
        ds['b.yml'] = """
        foo: bar
        """
        ds['c.yml'] = """
        foo: [ "a", "b", "c" ]
        """

        if path in ds:
            return ds[path]
        else:
            raise Exception("bad path given")

    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        'a': '1',
        'b': '2',
    }
    templar = Templar(loader=_mock_loader, variables=variable_manager)

# Generated at 2022-06-23 14:20:20.565422
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    v = VariableManager()
    ds = DataLoader()
    t = Templar(vars=v, loader=ds)
    assert listify_lookup_plugin_terms('foo', t, ds) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], t, ds) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('{{ foo }}', t, ds) == ['bar']
    v.set_variable('foo', 'bar')
    assert listify_lookup_plugin_terms('{{ foo }}', t, ds) == ['bar']
    assert listify_lookup_plugin_terms

# Generated at 2022-06-23 14:20:31.193780
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.splitter import parse_kv

    terms = '{{ foo }}, {{ bar }}'
    templar = DummyTemplar(terms)
    assert listify_lookup_plugin_terms(terms, templar, None) == ['{{ foo }}', '{{ bar }}']

    terms = 'foo, bar'
    templar = DummyTemplar(terms)
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo', 'bar']

    terms = '{{ foo }}, bar'
    templar = DummyTemplar(terms)
    assert listify_lookup_plugin_terms(terms, templar, None) == ['{{ foo }}', 'bar']

    terms = 'foo, {{ bar }}'
    templar = D

# Generated at 2022-06-23 14:20:41.460356
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_vault_secrets(['test'])
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a string
    terms = '{{ lookup_value }}'
    expected = ['lookup_value']
    actual = listify_lookup_plugin_terms(terms, templar, loader)
    assert actual == expected

    # test with a list
    terms = ['{{ lookup_value1 }}', '{{ lookup_value1 }}']
    expected = ['lookup_value1', 'lookup_value1']
    actual = listify_lookup_

# Generated at 2022-06-23 14:20:47.392135
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.vars.manager import VariableManager

    terms = AnsibleUnicode('123')
    templar = Templar(loader=None, variables=VariableManager())
    test_terms = listify_lookup_plugin_terms(terms=terms, templar=templar, loader=None)
    assert (isinstance(test_terms, list) and test_terms == ['123'])

    terms = AnsibleUnicode('123')
    templar = Templar(loader=None, variables=VariableManager())
    test_terms = listify_lookup_plugin_terms(terms=terms, templar=templar, loader=None, convert_bare=True)

# Generated at 2022-06-23 14:20:56.553859
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible import errors
    from ansible.utils.vars import combine_vars

    class MyTemplar(Templar):

        def __init__(self):
            pass

        def template(self, data, convert_bare=False, preserve_trailing_newlines=True, fail_on_undefined=True, override_vars=None):
            results = []
            for item in data:
                if isinstance(item, (list, tuple)):
                    results.append([x.strip() for x in item if x not in ['', None]])
                else:
                    if item is None or item.strip() == '':
                        results.append(item)
                    else:
                        if isinstance(item, string_types):
                            results.append(item.strip())
                       

# Generated at 2022-06-23 14:21:05.784106
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # This is the minimal ansible options needed to run the templar
    fake_options = lambda: None
    fake_options.lookup_plugins = []
    fake_options.acquired_plugins = {}
    fake_options.verbosity       = 0
    fake_options.cwd             = "/tmp"
    fake_options.roles_relative_to = None

    templar = Templar(loader=None, shared_loader_obj=None, variables={}, options=fake_options)

    # Basic string
    listify_result = listify_lookup_plugin_terms('{{hostvars[inventory_hostname]["ansible_eth0"]["ipv4"]["address"]}}', templar, None)

# Generated at 2022-06-23 14:21:14.509852
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # We can't test the templar in isolation, so just make this is a no-op
    class TestTemplar(object):
        def add_unknown_vars(self, var_list):
            return

        def template(self, terms, convert_bare=False, fail_on_undefined=True):
            return terms

    tt = TestTemplar()

    # Trivial success case
    results = listify_lookup_plugin_terms('a', tt, None)
    assert results == ['a']

    # Test that a simple error case works
    results = listify_lookup_plugin_terms('a b', tt, None)
    assert results == ['a b']

    # We have to have a way to trigger an error, which we do by passing a
    # dict (which should always fail with the default

# Generated at 2022-06-23 14:21:24.505022
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.loader import lookup_loader

    f = lambda x, y, z, fail_on_undefined=True, convert_bare=False:listify_lookup_plugin_terms(x, y, z, fail_on_undefined, convert_bare)
    g = lambda x:isinstance(x, string_types) or not isinstance(x, Iterable)
    h = lambda x:True

    loader = lookup_loader
    templar = DummyVars()

    assert f(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert f(('foo', 'bar'), templar, loader) == ['foo', 'bar']

# Generated at 2022-06-23 14:21:35.055414
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template.template
    import ansible.parsing.yaml.objects
    import ansible.utils.unsafe_proxy

    mock_templar = ansible.template.template.Templar(loader=None)
    ds = ansible.parsing.yaml.objects.AnsibleMapping()
    ds.update({'a': 'helloworld'})
    unsafe_ds = ansible.utils.unsafe_proxy.AnsibleUnsafeText(ds)

    list = listify_lookup_plugin_terms('{{ a }}', mock_templar, loader=None)
    assert list == ['helloworld']

    list = listify_lookup_plugin_terms('{{ a }}', mock_templar, loader=None, convert_bare=True)

# Generated at 2022-06-23 14:21:45.245209
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['localhost,'])

    variables = VariableManager(loader=loader, inventory=inv)

    # verify non strings get converted to a list
    data = [1, 2]
    result = listify_lookup_plugin_terms(data, Templar(variables=variables), loader)
    assert result == data
    assert isinstance(result, list)
    assert isinstance(result[0], int)

    # verify non templated strings get converted to lists
    data = '1, 2'

# Generated at 2022-06-23 14:21:51.939441
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={'hello': 'world'})

    assert listify_lookup_plugin_terms('{{hello}}', templar, None) == ['world']
    assert listify_lookup_plugin_terms('{{nx}}', templar, None) == ['']
    assert listify_lookup_plugin_terms('{{nx}}', templar, None, False) == ['']
    assert listify_lookup_plugin_terms('{{nx}}', templar, None, True) == ['']
    assert listify_lookup_plugin_terms(['1', '2', '{{hello}}'], templar, None)

# Generated at 2022-06-23 14:22:01.922917
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_vars({'a': ['b', 'c']})
    variable_manager.set_vars({'d': 'foo'})
    variable_manager.set_vars({'boo': True})
    variable_manager.set_vars({'foo': False})
    variable_manager.set_vars({'foo': False})

    templar = Templar(loader=loader, variables=variable_manager)
    terms = 'foo'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
   

# Generated at 2022-06-23 14:22:13.576385
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import loader as plugin_loader

    from ansible.plugins.lookup import LookupBase

    # Fake inventory
    inventory = plugin_loader.get('inventory', class_only=True)()

    # Fake variables
    variable_manager = VariableManager(loader=DataLoader())
    variable_manager.set_inventory(inventory)

    context = PlayContext()

    templar = Templar(loader=DataLoader(), variables=variable_manager,
                      shared_loader_obj=LookupBase(), play_context=context)


# Generated at 2022-06-23 14:22:21.463136
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible import constants as C
    from ansible.parsing.vault import VaultLib

    templar = Templar(loader=None, variables={'foo': 'bar'})

    # test string
    assert listify_lookup_plugin_terms('hello', templar, loader=None) == ['hello']
    # test list
    assert listify_lookup_plugin_terms(['hello', 'world'], templar, loader=None) == ['hello', 'world']
    # test string with template
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader=None) == ['bar']
    # test list with template

# Generated at 2022-06-23 14:22:32.892712
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class TestTemplar(object):
        def __init__(self):
            self._available_variables = dict(
                hello='world',
                foo='bar',
                baz=[1,2,3]
            )
        def template(self, data, fail_on_undefined=True, convert_bare=False):
            if isinstance(data, string_types):
                return self._available_variables.get(data, data)
            return data

    templar = TestTemplar()
    assert listify_lookup_plugin_terms('{{hello}}', templar, loader, fail_on_undefined=False, convert_bare=False) == ['world']

# Generated at 2022-06-23 14:22:42.790914
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Import mock and module-under-test
    try:
        from ansible.module_utils.six.moves import builtins
        builtins.__dict__['__import__'] = None  # No importing for your unit tests
        from ansible.plugins.lookup import listify_lookup_plugin_terms
    except ImportError:
        from ansible.plugins.lookup import listify_lookup_plugin_terms

    # Mock away Templar()
    class MockTemplar:
        def template(self, terms, **kwargs):
            return terms

    # Mock away AnsibleLoader

# Generated at 2022-06-23 14:22:53.199513
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Test function listify_lookup_plugin_terms'''
    from ansible.template import Templar
    from ansible.module_utils.common._collections_compat import defaultdict
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils._text import to_native
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleSequence, AnsibleMapping

    class MyFailOnUndefinedClass(object):
        def __init__(self, fail_on_undefined):
            self._fail_on_undefined = fail_on_undefined

        def fail_on_undefined(self, *args, **kwargs):
            return self._fail_on_undefined


# Generated at 2022-06-23 14:23:03.409246
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Make sure that this function works with AnsibleModule and
    # templar.template(). Since this function is mainly intended
    # to be used in lookup plugins, this test is kept simple to
    # avoid importing anything from Ansible.
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class TestTemplar:
        def template(self, data, *args, **kwargs):
            if isinstance(data, string_types):
                return AnsibleUnicode(data)
            else:
                return data


# Generated at 2022-06-23 14:23:04.067519
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:23:13.906511
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.vars import AnsibleVars
    templar = AnsibleVars(loader=None)

    assert listify_lookup_plugin_terms(1, templar, None, fail_on_undefined=True, convert_bare=True) == [1]
    assert listify_lookup_plugin_terms(" 1 ", templar, None, fail_on_undefined=True, convert_bare=True) == [1]
    assert listify_lookup_plugin_terms(" 1 ", templar, None, fail_on_undefined=True, convert_bare=False) == [" 1 "]
    assert listify_lookup_plugin_terms("{{ 1 }}", templar, None, fail_on_undefined=True, convert_bare=True) == [1]
    assert listify_look

# Generated at 2022-06-23 14:23:23.946448
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar


# Generated at 2022-06-23 14:23:34.799541
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar

    assert ["test"] == listify_lookup_plugin_terms("test", Templar(loader=None, variables={}), None)
    assert [] == listify_lookup_plugin_terms([], Templar(loader=None, variables={}), None)
    assert ["test1", "test2"] == listify_lookup_plugin_terms(["test1", "test2"], Templar(loader=None, variables={}), None)
    assert ["1", "2"] == listify_lookup_plugin_terms(AnsibleMapping({"key":"{{ [1, 2] }}"}), Templar(loader=None, variables={}), None)



# Generated at 2022-06-23 14:23:45.617605
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    t = Templar(loader=None, variables={'a': 'foo'})
    assert listify_lookup_plugin_terms(['a'], t, 'loader', False) == ['foo']
    assert listify_lookup_plugin_terms(u'a', t, 'loader', False) == ['foo']
    assert listify_lookup_plugin_terms(u'{{ a }}', t, 'loader', False) == ['foo']
    assert listify_lookup_plugin_terms(['a', 'b'], t, 'loader', False) == ['foo', 'b']
    assert listify_lookup_plugin_terms(['b', 'a'], t, 'loader', False) == ['b', 'foo']

# Generated at 2022-06-23 14:23:56.383191
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    temp = Templar(loader=loader)

    assert len(listify_lookup_plugin_terms(["a", "b", "c"], temp, loader, convert_bare=True)) == 3
    assert len(listify_lookup_plugin_terms(["a", "b", "c"], temp, loader)) == 3
    assert len(listify_lookup_plugin_terms(["a", "b", "{{ c }}"], temp, loader)) == 3
    assert len(listify_lookup_plugin_terms("a b \"c\"", temp, loader, convert_bare=True)) == 3

# Generated at 2022-06-23 14:24:06.544315
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars import VariableManager

    fake_loader = AnsibleLoader(stream=None, file_name=None, search_paths=None)
    variable_manager = VariableManager([])
    variable_manager.extra_vars = {'x': 'test value'}
    variable_manager.options_vars = {'bar': 'test foo'}
    variable_manager.set_available_variables(
        variable_manager.get_vars(loader=fake_loader, play=None))

# Generated at 2022-06-23 14:24:17.541569
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from units.compat import mock

    templar = Templar(loader=DataLoader(), variables={'C': C})

    terms = ['one', 'two', 1, 2, {'foo': 'bar'}]

    assert listify_lookup_plugin_terms(terms, templar, mock.Mock()) == terms
    assert listify_lookup_plugin_terms(terms, templar, mock.Mock(), convert_bare=True) == terms

    terms = 'one two'
    assert listify_lookup_plugin_terms(terms, templar, mock.Mock()) == ['one two']

# Generated at 2022-06-23 14:24:28.806061
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    class FakeVaultSecret(object):
        def __init__(self, secret):
            self.secret = secret

        def load(self):
            return self.secret

    # A lot of this code is copied from the test_templar.py module
    # in Ansible's test suite. We will likely refactor this code later
    # to avoid duplication.

    v = VaultLib([])
    fake_secret = FakeVaultSecret(dict(a=1, b=2, c=3))

    t = Templar(loader=None, variables={'a': 1, 'b': 2, 'c': 3}, vault_secrets={'secret': fake_secret})
    assert t.template('{{ a }}') == "1"

# Generated at 2022-06-23 14:24:35.240206
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing import vault

    from ansible.template import Templar

    from ansible.vars import VariableManager

    from ansible.inventory import Inventory

    assert listify_lookup_plugin_terms([1,2], Templar({}, {}, VariableManager()), None) == [1,2]
    assert listify_lookup_plugin_terms([1,2,3], Templar({"omg": "wtf"}, {}, VariableManager()), None) == [1,2,3]

    v = VariableManager()
    v.extra_vars = dict(foo='bar')
    results = listify_lookup_plugin_terms(['a', 'b', '{{foo}}'], Templar({}, {}, v), None)
    assert results == ['a','b','bar']

    # test vault

# Generated at 2022-06-23 14:24:46.826504
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    dummy_module = {"ansible_module_generated": 1}
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string term
    string_term = "    testterm   "
    result = listify_lookup_plugin_terms(string_term, templar, loader)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == "testterm"

    # Test string term, trimmed

# Generated at 2022-06-23 14:24:55.197230
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar, DictData
    from ansible.parsing.yaml.objects import AnsibleMapping

    t = Templar(loader=None, variables=DictData({}))

    r = listify_lookup_plugin_terms(terms='foo', templar=t, loader=None, fail_on_undefined=False)
    assert isinstance(r, list)
    assert r[0] == 'foo'

    r = listify_lookup_plugin_terms(terms=['foo', 'bar', 42], templar=t, loader=None, fail_on_undefined=False)
    assert isinstance(r, list)
    assert r[0] == 'foo'
    assert r[1] == 'bar'
    assert r[2] == 42

    r = listify_look

# Generated at 2022-06-23 14:24:56.169042
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: write me
    pass

# Generated at 2022-06-23 14:25:06.865152
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class DummyVars(object):
        pass

    dummy_vars = DummyVars()
    dummy_vars.foo = 1
    dummy_vars.bar = 'value'
    dummy_vars.abc = ['first', 'second']

    templar = Templar(loader=None, variables=dummy_vars)
    test_terms = ['{{ foo }}', '{{ bar }}', '{{ abc }}']
    assert listify_lookup_plugin_terms(test_terms, templar, None) == [1, 'value', ['first', 'second']]
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None) == [1]

# Generated at 2022-06-23 14:25:13.359090
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    results = []

# Generated at 2022-06-23 14:25:21.096896
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.playbook.templar
    terms = listify_lookup_plugin_terms('foo', templar=ansible.playbook.templar.Templar(loader=None), loader=None)
    assert isinstance(terms, list)
    assert terms[0] == 'foo'
    terms = listify_lookup_plugin_terms(['foo', 'bar'], templar=ansible.playbook.templar.Templar(loader=None), loader=None)
    assert isinstance(terms, list)
    assert terms[0] == 'foo'
    assert terms[1] == 'bar'

# Generated at 2022-06-23 14:25:31.949673
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib

    variable_manager = VariableManager()
    loader = variable_manager.loader

    the_vars = dict(vault_key1='abc123', my_list=['a', 'b', 'c'], my_string='test string')

    v = VaultLib([])
    v._is_encrypted = lambda x: False

    def get_vault_secret(a):
        return a

    v.decrypt = lambda x: x


# Generated at 2022-06-23 14:25:41.462009
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    loader = None

    assert listify_lookup_plugin_terms([1,2,3], templar, loader) == [1,2,3]
    assert listify_lookup_plugin_terms((1,2,3), templar, loader) == [1,2,3]
    assert listify_lookup_plugin_terms(1, templar, loader) == [1]

    assert listify_lookup_plugin_terms('1', templar, loader) == ['1']
    assert listify_lookup_plugin_terms('1,2', templar, loader) == ['1','2']

# Generated at 2022-06-23 14:25:50.225165
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Test listify_lookup_plugin_terms function
    '''

    from ansible.module_utils import basic
    from ansible.errors import AnsibleError
    from ansible.template import Templar

    templar = Templar(loader=basic.AnsibleModuleLoader())
    # test_json is a list
    test_json = templar.template('[1, 2, 3]', convert_bare=False)
    listify_lookup_plugin_terms(test_json, templar, basic.AnsibleModuleLoader())

    # test_json is a string
    test_json = templar.template('foo', convert_bare=False)
    listify_lookup_plugin_terms(test_json, templar, basic.AnsibleModuleLoader())


# Generated at 2022-06-23 14:25:50.770157
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:26:01.473979
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml import AnsibleLoader
    from ansible.utils.display import Display

    display = Display()

    templar = Templar(loader=AnsibleLoader(None), variables={})

    converted = listify_lookup_plugin_terms('foo', templar, loader)
    assert converted == ['foo']

    converted = listify_lookup_plugin_terms(['foo'], templar, loader)
    assert converted == ['foo']

    converted = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)
    assert converted == ['foo', 'bar']

    converted = listify_lookup_plugin_terms(['{{ foo }}', 'bar'], templar, loader)

# Generated at 2022-06-23 14:26:11.764270
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader

    terms = '{{ foo }}'
    templar = Templar(loader=DataLoader(), variables=dict(foo=['bar', 'baz']))
    results = listify_lookup_plugin_terms(terms, templar, loader=None)

    assert results == ['bar', 'baz']

    templar = Templar(loader=DataLoader(), variables=dict(foo='bar'))
    results = listify_lookup_plugin_terms(terms, templar, loader=None)

    assert results == ['bar']

    templar = Templar(loader=DataLoader(), variables={})
    results = listify_lookup_plugin_terms(terms, templar, loader=None)

    assert results == ['{{ foo }}']

# Generated at 2022-06-23 14:26:22.102741
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.errors import AnsibleError
    module_args = dict(
        terms="{{ foo }},{{ bar }}",
        templar=dict(
            template=lambda x,y,z: ['foo','bar'],
            fail_on_undefined=True,
            convert_bare=False
        ),
        loader=dict(),
        fail_on_undefined=True,
        convert_bare=False
    )
    assert listify_lookup_plugin_terms(**module_args) == ['foo','bar']


# Generated at 2022-06-23 14:26:27.663751
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Test listify lookup plugin terms
    '''

    import os
    import sys
    libdir = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), 'lib')
    sys.path.append(libdir)

    from __main__ import listify_lookup_plugin_terms

    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.template import Templar

    mem_vars = dict()
    mem_vars['a'] = 'a'
    mem_vars['b'] = 'b'
    templar = Templar(loader=None, variables=mem_vars)

# Generated at 2022-06-23 14:26:39.562383
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class MockVaultLib(object):
        def __init__(self, password=None):
            self._password = password

        def _get_decryption_password(self):
            return self._password

        def decrypt(self, value):
            if isinstance(value, AnsibleVaultEncryptedUnicode):
                return value.data
            else:
                return value

        def load_decryption_keys(self):
            pass

    class MockLoader(object):
        def __init__(self):
            self.vault = MockVaultLib()
            self.path_dwim = lambda x: x


# Generated at 2022-06-23 14:26:51.695073
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class Options(object):
        connection = 'local'
        module_path = ''
        forks = 10
        become = None
        become_method = None
        become_user = None
        become_ask_pass = False
        check = False
        diff = False
        syntax = None
        remote_user = 'remote_user'
        private_key_file = None
        listhosts = None
        listtasks = None
        listtags = None
        verbosity = None

    class Play(object):
        name = ''
        hosts = 'all'
        gather_facts = 'no'
        tasks

# Generated at 2022-06-23 14:27:02.836386
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test with list of terms, no templating
    terms = ['key1', 'key2']
    new_terms = listify_lookup_plugin_terms(terms, templar=None, loader=None)
    assert isinstance(new_terms, list)
    assert len(new_terms) == 2
    assert new_terms == ['key1', 'key2']

    # test with dictionary of terms
    terms = {'key1': 'value1', 'key2': 'value2'}
    new_terms = listify_lookup_plugin_terms(terms, templar=None, loader=None, convert_bare=True)
    assert isinstance(new_terms, list)
    assert len(new_terms) == 2
    assert new_terms == ['key1', 'key2']

    # test with a tem

# Generated at 2022-06-23 14:27:13.524415
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # We need to mock the template function of ansible.parsing.dataloader.DataLoader
    class MockTemplar(object):
        def __init__(self):
            self.template_data = {
                "var_in_vars_1": "foo",
                "var_in_vars_2": "bar",
                "var_in_vars_3": "baz",
                "a": 1,
                "b": 2,
                "c": 3
            }

        def template(self, terms, fail_on_undefined=True):
            if isinstance(terms, string_types):
                if self.template_data.get(terms, None) is None:
                    return terms
                else:
                    return self.template_data[terms]
            else:
                templated_terms

# Generated at 2022-06-23 14:27:23.571616
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-23 14:27:32.599354
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DictDataLoader({
        "listify_lookup_plugin_terms.j2": """# some comment
{{ dummy_var }}
{% for x in dummy_list %}{{ x }}{% endfor %}
"""
    })

    env = Environment(loader=loader)
    env.filters['regex_replace'] = lambda value, pattern, replacement: re.sub(pattern, replacement, value)

    dummy_var = "dummy_value"
    dummy_list = ['a', 'b', 'c']
    templar = Templar(loader=loader, variables=dict(dummy_var=dummy_var, dummy_list=dummy_list))

    terms = ['{{ dummy_var }}', '{{ dummy_var }} {{ dummy_list|join("") }}']
   