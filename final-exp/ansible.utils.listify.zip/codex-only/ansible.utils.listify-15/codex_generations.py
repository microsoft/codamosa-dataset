

# Generated at 2022-06-23 14:17:34.489117
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from jinja2 import Environment

    env = Environment()
    templar = Templar(loader=None, variables={})

    # Check that single strings are returned as lists
    assert listify_lookup_plugin_terms('foo', templar, env) == ['foo']

    # Check that the template is rendered
    result = listify_lookup_plugin_terms('{{ ansible_hostname }}', templar, env)
    assert len(result) == 1
    assert result[0].startswith(('localhost', 'pdpdk-jenkins', 'jenkins', 'build', 'worker'))

    # Check that lists are returned as is
    result = listify_lookup_plugin_terms(['foo', 'bar'], templar, env)
    assert len(result) == 2
    assert ''.join(result)

# Generated at 2022-06-23 14:17:45.201448
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    myterms = "foo"
    myterms_list = ["foo"]
    myterms_dict = {"a": "b"}
    fake_loader = DataLoader()
    fake_inventory = VariableManager()
    fake_variable_manager = VariableManager()
    fake_variable_manager.set_inventory(fake_inventory)
    fake_context = PlayContext()
    mytemplar = Templar(loader=fake_loader, variables=fake_variable_manager, fail_on_undefined=True)
    # Test that a string is converted to a list

# Generated at 2022-06-23 14:17:55.181904
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    loader = None
    templar = Templar(loader=loader, variables={'a': 1, 'b': 2})

    # test strings
    assert listify_lookup_plugin_terms('a', templar, loader, True, False) == ['a']
    assert listify_lookup_plugin_terms('a b', templar, loader, True, False) == ['a b']
    assert listify_lookup_plugin_terms(' a b ', templar, loader, True, False) == [' a b ']

# Generated at 2022-06-23 14:18:06.602756
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    templar = None
    loader = None

    assert listify_lookup_plugin_terms('foo.txt', templar, loader) == ['foo.txt']
    assert listify_lookup_plugin_terms(['foo.txt'], templar, loader) == ['foo.txt']
    assert listify_lookup_plugin_terms(['foo.txt', 'bar.txt'], templar, loader) == ['foo.txt', 'bar.txt']
    assert listify_lookup_plugin_terms('{{ ansible_env.HOME }}/foo.txt', templar, loader) == ['{{ ansible_env.HOME }}/foo.txt']

# Generated at 2022-06-23 14:18:18.132942
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext

    v = VariableManager()
    v.extra_vars = dict(
        foo='bar',
        tmpl_idx=[1,2,3,4]
    )

    p = PlayContext()
    t = Templar(v, loader=None, shared_loader_obj=None)

    assert listify_lookup_plugin_terms('{{foo}}', t) == ['bar']
    assert listify_lookup_plugin_terms(t.template('{{foo}}', fail_on_undefined=True), t) == ['bar']

# Generated at 2022-06-23 14:18:25.312040
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import ordereddict
    from ansible.template import Templar

    myterms = u"{{ lookup('foo', {'a': 1}, convert_bare=True) }}:{{ lookup('bar', {'b': 1}, convert_bare=True) }}"
    myvars = ordereddict()
    myvars['foo'] = '1'
    myvars['bar'] = '2'
    myvars['baz'] = '3'
    myvars[u"a"] = 1
    myvars[u"b"] = 2
    templar = Templar(loader=None, variables=myvars)


# Generated at 2022-06-23 14:18:34.789484
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class TestVarsModule(object):
        def __init__(self):
            self.no_template_fields = ['foo']
            self._fail_on_undefined = True

        def get_vars(self, loader, path, entities):
            return {'ansible_vault_password': 'abc123', 'foo': 'bar'}

        def add_no_template_fields(self, fields):
            self.no_template_fields.extend(fields)

        def get_fail_on_undefined(self):
            return self._fail_on_undefined

        def set_fail_on_undefined(self, fail_on_undefined):
            self._fail_on_undefined = fail_on_undefined

    class TestTemplateModule(object):
        def __init__(self):
            self.no

# Generated at 2022-06-23 14:18:44.989009
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test bare vars as strings
    assert listify_lookup_plugin_terms('{{foo}}', {}, {}, convert_bare=True) == ['{{foo}}']
    assert listify_lookup_plugin_terms('{{foo}},{{bar}}', {}, {}, convert_bare=True) == ['{{foo}}', '{{bar}}']
    assert listify_lookup_plugin_terms('{{foo}}:{{bar}}', {}, {}, convert_bare=True) == ['{{foo}}:{{bar}}']
    assert listify_lookup_plugin_terms('foo:{{bar}}', {}, {}, convert_bare=True) == ['foo:{{bar}}']

    # Test bare vars as lists

# Generated at 2022-06-23 14:18:45.682192
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:18:50.102124
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager

    terms = ["string", ["array"], {"hash": "hash"}]
    templar = Templar(VariableManager())

    ret = listify_lookup_plugin_terms(terms, templar, None)
    assert ret[0] == "string"
    assert ret[1][0] == "array"
    assert ret[2]["hash"] == "hash"

# Generated at 2022-06-23 14:19:00.555609
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.utils.display import Display
    import sys

    display = Display()
    templar = Templar(loader=None, variables={}, vault_secrets=VaultLib(password_files=None, passwords=None))


# Generated at 2022-06-23 14:19:11.091766
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = [
        Host(name="foo", vars={u'options': [u'option1', u'option2']}),
        Host(name="bar", vars={u'options': [u'option1', u'option2']}),
        Host(name="baz", vars={u'options': [u'option1', u'option2']}),
    ]
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)
    terms = ['{{ options }}', 'option3']

# Generated at 2022-06-23 14:19:12.696317
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # plugin_utils.listify_lookup_plugin_terms()
    raise Exception

# Generated at 2022-06-23 14:19:23.703071
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    v = VariableManager()
    v.set_fact(u'var1', u"one")
    t = Templar(loader=DataLoader(), variables=v)

    mystr = u"{{ var1 }}"
    mylist = [u'one']
    mylist2 = [u'one', u'two', u'three']
    mylist3 = [u' one', u' two', u' three']

    assert listify_lookup_plugin_terms(mystr, t, loader=DataLoader()) == mylist
    assert listify_lookup_plugin_terms(mylist, t, loader=DataLoader()) == mylist
    assert listify_lookup_

# Generated at 2022-06-23 14:19:32.200353
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.dumper import AnsibleDumper

    def _get_terms_as_yaml(terms):
        dumper = AnsibleDumper(None, width=9999, default_flow_style=False)
        return dumper.represent_data(terms)

    assert _get_terms_as_yaml(listify_lookup_plugin_terms(['1', '2'], Templar(None, None), None)) == "['1', '2']"
    assert _get_terms_as_yaml(listify_lookup_plugin_terms(['1', '2'], Templar(None, None), None, convert_bare=True)) == "['1', '2']"

# Generated at 2022-06-23 14:19:44.164758
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' test_listify_lookup_plugin_terms '''
    from units.module_utils.common.collections import AnsibleMapping, AnsibleSequence
    from ansible.module_utils._text import to_text
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    vault_secrets = [VaultLib(password='secret'), VaultLib(password='secret')]
    v = VariableManager(loader=dataloader)

    # test basic string
    s = listify_lookup_plugin_terms('{"foo":"bar"}', v.template(), dataloader)
    assert isinstance(s, list)
    assert len(s) == 1

# Generated at 2022-06-23 14:19:52.530513
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from io import StringIO
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    ds = StringIO()
    ds.write('---\n')
    ds.write('foo: bar\n')
    ds.seek(0)

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    templar = Templar(loader=loader, variables=variable_manager)

    data = listify_lookup_plugin_terms('{{ [foo] }}', templar, loader, convert_bare=True)

# Generated at 2022-06-23 14:20:03.643306
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    test_cases = [
        ('a', ['a']),
        ('a, b', ['a', 'b']),
        ('', []),
        (' ', []),
        ('a, b,', ['a', 'b']),
        (['a'], ['a']),
        (['a', 'b'], ['a', 'b']),
        (['a', 'b,c'], ['a', 'b,c']),
        ([], []),
    ]

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-23 14:20:10.264234
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Just a string
    terms = listify_lookup_plugin_terms('hello', None, None)
    assert terms == ['hello']

    # A list with a string
    terms = listify_lookup_plugin_terms(['hello'], None, None)
    assert terms == ['hello']

    # A list with a list
    terms = listify_lookup_plugin_terms([['hello']], None, None)
    assert terms == [['hello']]

    # A list with a list of lists
    terms = listify_lookup_plugin_terms([['hello'], ['world']], None, None)
    assert terms == [['hello'], ['world']]

    # A string in a list, with a list
    terms = listify_lookup_plugin_terms(['hello', ['world']], None, None)


# Generated at 2022-06-23 14:20:22.086033
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class DummyVars(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

    class DummyVarsManager(VariableManager):
        def __init__(self):
            pass

    class DummyInventory(object):
        def __init__(self):
            self.vars = {
                'one': DummyVars('one', 'one_value'),
                'two': DummyVars('two', 'two_value'),
            }

    class DummyLoader(object):
        def __init__(self):
            self.inventory = DummyInventory()

    vars_manager

# Generated at 2022-06-23 14:20:33.624130
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.loader import AnsibleLoader

    variable_manager = VariableManager()
    loader = AnsibleLoader(None, variable_manager=variable_manager)

    templar = Templar(loader=loader, variables=variable_manager)

    # Test when terms arg is a string
    terms_string = "item1,item2,item3"
    expected = ['item1', 'item2', 'item3']
    actual = listify_lookup_plugin_terms(terms_string, templar, loader)
    assert expected == actual

    # Test when terms arg is a list of strings
    terms_list_of_strings = [ "item1", "item2", "item3" ]

# Generated at 2022-06-23 14:20:42.628774
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class UnitTestTemplar:
        def template(self, data, fail_on_undefined=True):
            return [data,data]
    class UnitTestLoader:
        def lookup_loader(self, name, imp=None):
            return None

    templar = UnitTestTemplar()
    loader = UnitTestLoader()

    assert listify_lookup_plugin_terms('string', templar, loader, fail_on_undefined=True) == ['string','string']
    assert listify_lookup_plugin_terms(['listOfString'], templar, loader, fail_on_undefined=True) == ['listOfString','listOfString']

# Generated at 2022-06-23 14:20:51.357898
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    variables = VariableManager(loader=loader, inventory=inv_manager)
    # Load lookup plugins to avoid lookup() error
    lookup_loader.get_all_plugins()

    templar = Templar(loader=loader, variables=variables)

    assert listify_lookup_plugin_terms([1, 2, 3], templar, loader) == [1, 2, 3]

# Generated at 2022-06-23 14:21:01.271665
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test with ansible 2.6
    try:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
        have_unsafe_proxy = True
    except:
        have_unsafe_proxy = False

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-23 14:21:07.910849
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    assert(listify_lookup_plugin_terms('1', Templar(DataLoader()), DataLoader()) == ['1'])
    assert(listify_lookup_plugin_terms([1], Templar(DataLoader()), DataLoader()) == [1])
    assert(listify_lookup_plugin_terms([1,2,3], Templar(DataLoader()), DataLoader()) == [1,2,3])
    assert(listify_lookup_plugin_terms('1,2,3', Templar(DataLoader()), DataLoader()) == ['1,2,3'])

# Generated at 2022-06-23 14:21:16.393451
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
    from ansible.module_utils.common.collections import is_sequence
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    # this is the basic way lookup plugins are called, so we use
    # this to ensure our function is doing the right thing
    terms = 'foo'
    templar = Templar(loader=DataLoader(), variables={})
    assert isinstance(listify_lookup_plugin_terms(terms, templar), list)
    assert isinstance(listify_lookup_plugin_terms(terms, templar)[0], string_types)

    # Test a string in a sequence


# Generated at 2022-06-23 14:21:25.413285
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    names = {'one': 1, 'two': 2, 'three': 3}
    variable_manager._extra_vars = dict(foo=names)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, loader) == [['one', 'two', 'three']]
    assert listify_lookup_plugin_terms(['{{ foo.keys() }}'], templar, loader) == [['one', 'two', 'three']]

# Generated at 2022-06-23 14:21:36.751997
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms(['foo'], Templar(loader=None), None) == ['foo']
    assert listify_lookup_plugin_terms(('foo',), Templar(loader=None), None) == ['foo']
    assert listify_lookup_plugin_terms('foo', Templar(loader=None), None) == ['foo']

    # test stringify_lookup_plugin_terms, which also calls listify_lookup_plugin_terms
    # right now this is commented out because the test doesn't work well in the
    # the regular unit test environment, and because I'm not sure what API
    # the new method is supposed to have.
    #assert stringify_lookup_plugin_terms(['foo']) == ['foo']
    #assert stringify_lookup_plugin_

# Generated at 2022-06-23 14:21:37.543149
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-23 14:21:47.241774
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.shell = '/bin/sh'
            self.module_path = None
            self.forks = None
            self.become = False
            self.become_method = None
            self.become_user = None
            self.become_ask_pass = False
            self.remote_user = 'root'
            self.private_key_file = None
            self.ssh_common_args = ""
            self.ssh_extra_args = ""
            self.sftp_extra_args = ""
            self.scp_extra_args = ""
            self.verbosity = 0
            self.check = False
            self.listhosts = None
            self.list

# Generated at 2022-06-23 14:21:58.383693
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class MockVarManager:

        def get_vars(self, loader, play, host=None, task=None, include_hostvars=True, include_delegate_to=False):
            return {'item': 'item_value'}

    class MockTemplar(Templar):

        def __init__(self, loader, variables):
            self._available_variables = variables

    # test with item
    listify_lookup_plugin_terms('"{{ item }}"', templar=MockTemplar(None, MockVarManager()), loader=None, fail_on_undefined=False) == ['"item_value"']

    # test with quoted string

# Generated at 2022-06-23 14:22:02.832508
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader(None, templar_class=Templar)
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(23, templar, loader) == [23]

    assert listify_lookup_plugin_terms(None, templar, loader) == [None]

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']


# Generated at 2022-06-23 14:22:14.346931
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    #from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Make a fake host with a vars dictionary
    #host = Host(name='testhost')
    #group = Group(name='testgroup')
    #group.add_host(host)



    # Make a fake inventory and add our fake host to it
    inventory = InventoryManager(loader=DataLoader(), sources='')
    #inventory.add_group(group)

    # Make a fake variable manager with a dictionary that maps hostnames
    # to the fake host

# Generated at 2022-06-23 14:22:21.853762
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import os
    import sys

    import ansible.template
    import ansible.utils.plugin_docs

    class Counter(object):
        def __init__(self):
            self.count = 0

        def callback(self, *args, **kwargs):
            print('callback: %s %s' % (args, kwargs))
            self.count += 1

    class DummyVars(object):
        def get(self, key, default=None):
            print('get: %s %s' % (key, default))
            return default

    class DummyTemplar(ansible.template.Templar):
        def __init__(self, loader, variables):
            self._available_variables = variables

        def set_available_variables(self, variables):
            self._available_variables = variables

   

# Generated at 2022-06-23 14:22:33.328161
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    test_listify_lookup_plugin_terms
    """
    class FakeModule:
        def __init__(self):
            pass

        def params(self):
            return dict()

    class FakeTemplar:
        def __init__(self):
            pass

        def template(self, data, fail_on_undefined=False, convert_bare=False, keep_trailing_newline=False, preserve_trailing_newlines=False, escape_backslashes=False, fail_on_undefined_vars=False, override_vars=None):
            return data

        def contains_vars(self, data):
            return False

    class FakeLoader:
        pass

    from ansible.utils import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import Ans

# Generated at 2022-06-23 14:22:43.173141
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY3
    from ansible.utils import plugins
    from ansible.template import Templar

    if PY3:
        unicode = str

    templar = Templar(loader=plugins.module_loader)
    terms = listify_lookup_plugin_terms(terms=[u'foo', u'{{bar}}', u'{{baz}}'], templar=templar, loader=plugins.module_loader, fail_on_undefined=True, convert_bare=False)
    assert terms == [u'foo', u'{{bar}}', u'{{baz}}']


# Generated at 2022-06-23 14:22:53.474840
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # noop if an iterable is provided
    terms = [1, 2, 3]
    templar = Templar(loader=None, variables={})
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == terms

    # convert string to one item list
    terms = 'foo'
    templar = Templar(loader=None, variables={})
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['foo']

    # convert bare string to one item list
    terms = '{{ foo }}'
    templar = Templar(loader=None, variables={'foo': 'bar'})

# Generated at 2022-06-23 14:23:03.633095
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()
    templar = Templar(loader=dl)

    ret = listify_lookup_plugin_terms([True, 'foo'], templar, dl)
    assert isinstance(ret, list)
    assert ret == [True, 'foo']

    ret = listify_lookup_plugin_terms('{{ [True, "foo"] }}', templar, dl)
    assert isinstance(ret, list)
    assert ret == [True, 'foo']

    ret = listify_lookup_plugin_terms(['bar', '{{ [True, "foo"] }}'], templar, dl)
    assert isinstance(ret, list)

# Generated at 2022-06-23 14:23:13.523925
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    fake_loader = 'foo'
    empty_vars = dict()
    templar = Templar(loader=fake_loader, variables=empty_vars)

    # Test with bare variables
    result = listify_lookup_plugin_terms('{{ testvar }}', templar, fake_loader, convert_bare=True)
    assert result == ['{{ testvar }}']

    # Test with non-string input
    result = listify_lookup_plugin_terms(42, templar, fake_loader, convert_bare=False)
    assert result == [42]

    # Test with string input
    result = listify_lookup_plugin_terms('foo', templar, fake_loader, convert_bare=False)
    assert result == ['foo']

    # Test with list input
   

# Generated at 2022-06-23 14:23:23.628487
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    from ansible.vars import VariableManager

    t = ansible.template.AnsibleTemplar(VariableManager())


# Generated at 2022-06-23 14:23:34.765335
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Expected to return
    # ['bar','bat','baz','foo','bar','bat','baz','foo','bar','bat','baz','foo','bar','bat','baz','foo','bar','bat','baz','foo']
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../lib'))
    from ansible.template import Templar

    inventory = None # Likely ununsed by listify_lookup_plugin_terms, but needed by the constructor

    lookup_loader = None # Likely ununsed by listify_lookup_plugin_terms, but needed by the constructor
    lookup_basedir = None # Likely ununsed by listify_lookup_plugin_terms, but needed by the constructor

    templar = Templar

# Generated at 2022-06-23 14:23:45.580555
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader, fail_on_undefined=True, convert_bare=False) == ['a', 'b']
    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader, fail_on_undefined=True, convert_bare=True) == ['a', 'b']
    assert listify_lookup_plugin_terms('a, b', templar, loader, fail_on_undefined=True, convert_bare=False) == ['a', 'b']

# Generated at 2022-06-23 14:23:56.381638
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar


# Generated at 2022-06-23 14:24:06.543213
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    vault_secrets = [{'secret_name': 'secret', 'password': 'vault_pass'}]
    vault_secrets_with_id = [{'secret_name': 'secret', 'password': 'vault_pass', 'id': 'id'}]
    vault_secrets_too_many_ids = [{'secret_name': 'secret', 'password': 'vault_pass', 'id': 'id1', 'id2': 'id2'}]
    vault_lib = VaultLib(vault_secrets)

# Generated at 2022-06-23 14:24:17.541748
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(a='bar', b='foo')
    variable_manager.options_vars = dict(b='baz')
    variable_manager.set_available_variables(loader=loader)
    templar = Templar(loader=loader, variable_manager=variable_manager)


# Generated at 2022-06-23 14:24:18.000583
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:24:29.320475
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    dummy_loader = DataLoader()
    dummy_variables = {}
    templar = Templar(loader=dummy_loader, variables=dummy_variables)


# Generated at 2022-06-23 14:24:35.666004
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-23 14:24:47.355194
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Template
    from ansible.template import Templar

    # Create a dummy environment to set the loader
    loader = DummyLoader()
    # Initialize the templar
    templar = Templar(loader=loader)

    # Testing with a string
    terms="a,b"
    expect=["a","b"]
    actual=listify_lookup_plugin_terms(terms, templar, loader)
    assert expect==actual

    # Testing with a list
    terms=["a", "b"]
    expect=["a","b"]
    actual=listify_lookup_plugin_terms(terms, templar, loader)
    assert expect==actual

    # Testing with a comma
    terms=","
    expect=""

# Generated at 2022-06-23 14:24:55.678577
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.host import Host

    # listify_lookup_plugin_terms() should return a tuple of strings when given a single bare string
    templar = Templar(loader=None, variables={})
    play_context = PlayContext()
    terms = "a string"
    res = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert isinstance(res, list)
    assert len(res) == 1
    assert isinstance(res[0], string_types)
    assert res[0] == "a string"

    # listify_lookup_plugin_terms() should return a tuple of strings when given a single string

# Generated at 2022-06-23 14:25:05.488363
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    def test_template(template, convert_bare=False, fail_on_undefined=True):

        if convert_bare:
            return template.replace('{{', '').replace('}}', '')

        return template

    terms = listify_lookup_plugin_terms('{{test1}}', Templar(loader=None, variables={}), loader=None)

    assert terms == ['{{test1}}']

    terms = listify_lookup_plugin_terms(['{{test1}}', '{{test2}}'], Templar(loader=None, variables={}), loader=None)

    assert terms == ['{{test1}}', '{{test2}}']


# Generated at 2022-06-23 14:25:12.556726
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.loader import lookup_loader

    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms('michael', templar, loader) == ['michael']
    assert listify_lookup_plugin_terms(['michael'], templar, loader) == ['michael']
    assert listify_lookup_plugin_terms(['michael', 'sally'], templar, loader) == ['michael', 'sally']
    assert listify_lookup_plugin_

# Generated at 2022-06-23 14:25:22.304531
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Test: String or int
    terms = 'test'
    templar = Templar(loader=None, variables={})
    terms = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert terms[0] == 'test'

    # Test: Iterable
    terms = ['a', 'b']
    templar = Templar(loader=None, variables={})
    terms = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert isinstance(terms, list)
    assert len(terms) == 2
    assert terms[0] == 'a'
    assert terms[1] == 'b'

    # Test: Undefined variable - fail

# Generated at 2022-06-23 14:25:33.502953
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common.collections import AnsibleMapping

    # The dicts here represent the Vars passed to AnsibleModule to emulate the results of running
    # a particular playbook and tasks.

    # No var defined
    vars = AnsibleMapping()
    assert listify_lookup_plugin_terms('{{ foo }}', FakeTemplar(vars), None) == ['{{ foo }}']

    # Var defined but not using jinja
    vars['foo'] = 'bar.baz'
    assert listify_lookup_plugin_terms('{{ foo }}', FakeTemplar(vars), None) == ['{{ foo }}']

    # Var defined and using jinja
    assert listify_lookup_plugin_terms('{{ foo }}', FakeTemplar(vars), None, convert_bare=True)

# Generated at 2022-06-23 14:25:34.419764
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:25:42.701443
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)
    assert isinstance(listify_lookup_plugin_terms(['a','b','c'], templar, None), list)
    assert isinstance(listify_lookup_plugin_terms('a', templar, None), list)
    assert isinstance(listify_lookup_plugin_terms('["a"]', templar, None), list)
    assert isinstance(listify_lookup_plugin_terms('{1:2}', templar, None), list)
    assert isinstance(listify_lookup_plugin_terms(None, templar, None), list)
    assert isinstance(listify_lookup_plugin_terms('{{ foo }}', templar, None), list)

# Generated at 2022-06-23 14:25:50.992520
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms([1, 2], templar, loader) == [1, 2]
    assert listify_lookup_plugin_terms(1, templar, loader) == [1]
    assert listify_lookup_plugin_terms('{{ [1, 2] }}', templar, loader) == [1, 2]
    assert listify_lookup_plugin_terms('{{ [1, 2] }}', templar, loader, convert_bare=True) == ['[1, 2]']

# Generated at 2022-06-23 14:26:01.721381
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    templar = Templar(loader=None)
    result = listify_lookup_plugin_terms('foo', templar, loader=None)
    assert result == ['foo']

#     result = listify_lookup_plugin_terms(['foo'], templar, loader=None)
#     assert result == ['foo']
#
#     result = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader=None)
#     assert result == ['foo', 'bar']
#
#     # test with templating
#     result = listify_lookup_plugin_terms('{{ foo }}', templar, loader=None)
#     assert result == ['{{ foo }}']
#
#     result = listify_lookup_plugin_terms('

# Generated at 2022-06-23 14:26:11.764662
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    terms1 = ['1','2','3','4','5','6']
    terms2 = '123456'
    terms3 = 123456
    templar = Templar(loader=DataLoader())
    result1 = listify_lookup_plugin_terms(terms1, templar, templar)
    result2 = listify_lookup_plugin_terms(terms2, templar, templar)
    result3 = listify_lookup_plugin_terms(terms3, templar, templar)
    assert result1 == ['1','2','3','4','5','6']
    assert result2 == ['123456']
    assert result3 == [123456]

# Generated at 2022-06-23 14:26:22.102315
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.template import Templar

    class LookupModule(object):
        def __init__(self, basedir=None, **kwargs):
            pass

    class VarManager():
        def __init__(self, loader=None):
            pass

        def get_vars(self, loader=None, play=None, host=None, task=None):
            return dict(foo="bar", biz="baz")

    class DataLoader():
        def __init__(self):
            pass

    class Play():
        def __init__(self):
            pass

    class Inventory():
        def __init__(self):
            pass

    class Host():
        def __init__(self):
            pass

    class Task():
        def __init__(self):
            pass

    var

# Generated at 2022-06-23 14:26:29.578992
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    This is a basic unit test that exercises the base of listify_lookup_plugin_terms.
    It doesn't require a playbook or host, but does require the modules to be found
    in the import path.  An alternative would be to use ansible.module_utils.six.moves.mock
    to mock up the objects instead.

    :return:
    '''
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    my_terms = [u'one', u'two', u'three']
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_host_variable('localhost', {'var': 'three'})

# Generated at 2022-06-23 14:26:40.689597
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    import os

    terms_input  = '{{ foo }}'
    foo_input    = [ 'bar', 'baz' ]
    terms_output_expect = [ 'bar', 'baz' ]

    class FakeVars(object):
        def get_vars(self, loader, play, include_hostvars=True):
            return { 'foo': foo_input }

    variable_manager = VariableManager()
    variable_manager.extra_vars = FakeVars()

    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-23 14:26:49.717218
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    env = EnvironmentStub()
    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables=dict())

    terms = [u'{{ foo }}', u'{{ bar }}']
    facts = dict(
        foo='Hello',
        bar='World',
        baz='Foo',
    )

    templar._available_variables = facts
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['Hello', 'World']


# Generated at 2022-06-23 14:26:56.999534
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    def _mock_loader(path):
        return {'_raw_params': ''}


# Generated at 2022-06-23 14:27:07.216579
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.template import Templar
    from ansible.vars import VariableManager
    v = VariableManager()
    t = Templar(loader=None, variables=v)
    terms = "{{ foo }}"
    terms = listify_lookup_plugin_terms(terms, t, None, fail_on_undefined=True, convert_bare=False)
    assert terms == ['{{ foo }}']
    terms = listify_lookup_plugin_terms(terms, t, None, fail_on_undefined=True, convert_bare=True)
    assert terms == []
    terms = "{{ foo }}"
    terms = listify_lookup_plugin_terms(terms, t, None, fail_on_undefined=False, convert_bare=True)
    assert terms == []
    terms = "{{ foo }}"
    terms

# Generated at 2022-06-23 14:27:15.932182
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # equal_to_test is a helper function for testing equality
    def equal_to_test(a, b, err_msg="found in {1} but expected to find {2}"):
        if a != b:
            raise AssertionError(err_msg.format(a, b))

    # Test for case 0: terms is just a string;
    # it should be put into a list
    terms = "term1"
    templar = "templar"
    loader = "loader"
    expected = ["term1"]
    result = listify_lookup_plugin_terms(terms, templar, loader)
    equal_to_test(result, expected, "Test case 0 failed.")

    # Test for case 1: terms is a list of strings;
    # it should remain the same

# Generated at 2022-06-23 14:27:16.520822
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:27:25.689526
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    host = Host(name="localhost")
    play_context = PlayContext()
    # since we're using the ssh connection plugin
    play_context.network_os = 'ios'

    inventory = Inventory([host])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = {'myvar': 'myvalue'}
    templar = Templar(loader=loader, variables=variable_manager)
