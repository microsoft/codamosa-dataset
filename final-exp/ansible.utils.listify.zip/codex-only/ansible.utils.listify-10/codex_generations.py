

# Generated at 2022-06-23 14:17:34.952414
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    terms = "{{ lookup('foo') }}"
    assert listify_lookup_plugin_terms(terms, templar, loader) == ["{{ lookup('foo') }}"]

    terms = ["{{ lookup('foo') }}", "{{ lookup('bar') }}"]
    assert listify_lookup_plugin_terms(terms, templar, loader) == ["{{ lookup('foo') }}", "{{ lookup('bar') }}"]

    terms = ["foo", "{{ lookup('bar') }}", "baz"]

# Generated at 2022-06-23 14:17:45.394497
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    terms_None = None
    terms_str = '{{ var1 }},{{ var2 }}'
    terms_list = ['{{ var1 }}', '{{ var2 }}']
    terms_list2 = ['{{ var1 }}', '{{ var2 }},{{ var3 }}']
    terms_list3 = ['{{ var1 }}', '{{ var2 }},{{ var3 }}', '{{ var4 }}']
    terms_variable = '{{ var1 }},{{ var2 }}'
    templar = DummyTemplar()
    loader = DummyLoader()
    fail_on_undefined = True

    terms_result_None = listify_lookup_plugin_terms(terms_None, templar, loader, fail_on_undefined)
   

# Generated at 2022-06-23 14:17:55.347769
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Import AnsibleModule so we can mock templar
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create mock module to test function
    module = AnsibleModule(argument_spec={})

    # Create mock templar
    class MockVaultSecret:
        def __init__(self, dummy=None):
            pass
    module.vars = {'password': 'test_password'}
    vault_secret = MockVaultSecret()

# Generated at 2022-06-23 14:18:06.802214
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.parsing.yaml.objects
    import ansible.parsing.yaml.loader
    from ansible.template import Templar


# Generated at 2022-06-23 14:18:10.568678
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.templar

    assert listify_lookup_plugin_terms(['foo', 'bar'], ansible.templar.Templar(), loader=None) == ['foo', 'bar']
    asser

# Generated at 2022-06-23 14:18:21.749561
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader

    dataloader = DataLoader()
    inventory = InventoryManager(loader=dataloader, sources=[""])
    variable_manager = VariableManager(loader=dataloader, inventory=inventory)
    loader = None
    play_context = {}

    def _templar(template_name, fail_on_undefined):
        return template_name

    templar = _templar

    # test case: simple string
    terms = 'Hello World'

# Generated at 2022-06-23 14:18:30.884639
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader

    class DummyVarsModule(object):
        """
        Ansible variables are available as attributes
        """
        def __init__(self, d):
            self.__dict__ = d
            self.lookup_file = 'lookup_file'
            self.lookup_dir = 'lookup_dir'

        def __contains__(self, k):
            return k in self.__dict__

    class DummyVar(object):
        def __init__(self, **kwargs):
            self.vars = DummyVarsModule(kwargs)


# Generated at 2022-06-23 14:18:39.524659
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    import os

    my_cwd = os.getcwd()
    # Changes the CWD to the /test directory where the test data is located
    os.chdir(os.path.join(os.path.dirname(__file__), '..', 'test'))

    loader = DataLoader()
    loader.set_basedir(os.path.join(os.path.dirname(__file__), '..', 'test'))
    loader._vault_reload()

# Generated at 2022-06-23 14:18:49.541124
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    import jinja2
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_loader = AnsibleLoader(None, jinja2.Environment())

    vars_dict = {
        'foo': 'FOO',
        'bar': 'BAR',
        'baz': 'BAZ',
        'xyz': ['a', 'b', 'c'],
        'xyasdf': ['a', 'b', 'c'],
    }

    templar = Templar(loader=None, variables=vars_dict, shared_loader_obj=yaml_loader)


# Generated at 2022-06-23 14:19:00.163870
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = {'test_var1': "test_value1", 'test_var2': "test_value2"}
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager))

    terms = [
               '{{ test_var1 }}'
               '{{ test_var2 }}'
            ]

    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=None, host=None))

# Generated at 2022-06-23 14:19:06.689923
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-23 14:19:11.757208
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.validate import Validator

    templar = Templar(loader=None, variables=dict(foo="bar"))
    assert listify_lookup_plugin_terms("{{foo}}", templar, None, fail_on_undefined=True) == ['bar']
    assert listify_lookup_plugin_terms("{{foo}}", templar, None, fail_on_undefined=False) == ['bar']
    assert listify_lookup_plugin_terms(["{{foo}}", "foo", "bar"], templar, None, fail_on_undefined=True) == ['bar', 'foo', 'bar']

# Generated at 2022-06-23 14:19:22.585791
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.template
    import ansible.parsing.yaml.loader
    import jinja2.environment

    terms = {'a': 1, 'b': 2, 'c': '3'}
    templar = ansible.template.AnsibleTemplar(loader=ansible.parsing.yaml.loader.AnsibleLoader(includedirs=[]))
    result = listify_lookup_plugin_terms(terms, templar, loader=ansible.parsing.yaml.loader.AnsibleLoader(includedirs=[]))
    assert terms == result

    terms = ['a', 'b', 'c']

# Generated at 2022-06-23 14:19:30.360653
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    my_vars = dict(one='foo', two='bar', three=dict(four='baz'), other=42, other_list=['a', 'b', 'c'])
    templar = Templar(loader=loader, variables=my_vars)

    assert listify_lookup_plugin_terms('{{ one }}', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('{{ two }}', templar, loader) == ['bar']
    assert listify_lookup_plugin_terms('{{ three.four }}', templar, loader) == ['baz']

# Generated at 2022-06-23 14:19:37.287489
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms("{{ foo }}", templar, loader=None, fail_on_undefined=True, convert_bare=False) == ['{{ foo }}']

    templar._available_variables = dict(foo='hello')
    assert listify_lookup_plugin_terms("{{ foo }}", templar, loader=None, fail_on_undefined=True, convert_bare=True) == ['hello']

    templar._available_variables = dict(foo='hello')
    assert listify_lookup_plugin_terms("{{ foo }}", templar, loader=None, fail_on_undefined=True, convert_bare=False) == ['{{ foo }}']

# Generated at 2022-06-23 14:19:47.609456
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible import context
    from ansible.module_utils._text import to_text

    terms = ['{{ item }}', '1']
    templar = Templar(loader=DataLoader(), variables={
        'item': 'hello'
    })

    results = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert results == ['hello', '1']

    results = listify_lookup_plugin_terms(terms, templar, loader=None, convert_bare=True)
    assert results == ['hello', '1', 'item']

    terms = '{{ item }}'
    result = listify_lookup_plugin_terms(terms, templar, loader=None)

# Generated at 2022-06-23 14:19:58.860669
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """Make sure listify_lookup_plugin_terms works like it is supposed to"""

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import UnsafeProxy

    my_vars = dict(
        foo='first.example.org',
        bar='second.example.org',
        bam='third.example.org fourth.example.org',
        baz=['first.example.org', 'second.example.org'],
        )

    my_inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager

# Generated at 2022-06-23 14:20:08.095032
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    # Setup the objects necessary to test the function
    loader = DataLoader()

    class FakeVarsModule(object):
        pass

    class FakeVarManager(object):
        def __init__(self):
            self.extra_vars = FakeVarsModule()

    class FakeInventory(object):
        vars = FakeVarManager()

    class FakePlayContext(object):
        def __init__(self):
            self.inventory = FakeInventory()

    # Create a fake play context to be passed to the function
    pc = FakePlayContext()
    templar = Templar(loader=loader, variables=pc.inventory.vars)


    # Test with a simple string
    terms = ['test1']
    result_terms

# Generated at 2022-06-23 14:20:20.565959
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable

    templar = Templar(loader=None)

    terms = listify_lookup_plugin_terms('foo, bar, baz', templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert(isinstance(terms, list))
    assert(len(terms) == 3)
    assert(terms[0] == 'foo')
    assert(terms[1] == 'bar')
    assert(terms[2] == 'baz')

    terms = listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert(isinstance(terms, list))

# Generated at 2022-06-23 14:20:31.194047
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    # test_loader = TestDictDataLoader()
    # test_loader.set_data({}, 'test_vars')

    # test_variable_manager = TestVariableManager()
    test_loader = DataLoader()
    test_variable_manager = VariableManager()

    test_env_vars = {
        'env1': 'env1_val',
    }

    test_host_vars = {
        'host_var1': 'host_var1_val',
    }


# Generated at 2022-06-23 14:20:40.868230
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # Setup test environment
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    play_context = PlayContext()

    templar = Templar(loader=loader,
                      variables=variable_manager.get_vars(play=play_context),
                      fail_on_undefined=True)

    # Test string, single value

# Generated at 2022-06-23 14:20:49.751490
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    term = "a string"
    list_term = listify_lookup_plugin_terms(term, None, None)
    assert type(list_term) is list
    assert list_term == ['a string']

    list_term = listify_lookup_plugin_terms([term], None, None)
    assert type(list_term) is list
    assert list_term == ['a string']

    term = AnsibleUnsafeText("a string")
    list_term = listify_lookup_plugin_terms(term, None, None)
    assert type(list_term) is list
    assert list_term == ['a string']

    list_term = listify_lookup_plugin_terms([term], None, None)

# Generated at 2022-06-23 14:20:59.783665
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    password = '$ANSIBLE_VAULT;1.1;AES256'
    items = [
        # Plain value
        "foo",
        # Variable
        "$bar",
        # Vault variable
        VaultLib.encrypt("$vault", password),
        # Jinja2 template
        "{% if True %}foobar{% endif %}",
        # List of strings
        ["baz", "$baz"],
        # String from list of strings
        "['foo', '{{ bar }}']",
        # List from JSON
        '["foo", "bar"]',
    ]


# Generated at 2022-06-23 14:21:07.334693
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    terms = listify_lookup_plugin_terms("hello world", templar, loader)
    assert isinstance(terms, list)
    assert(terms == ['hello world'])

    terms = listify_lookup_plugin_terms("hello world,goodbye world", templar, loader)
    assert(terms == ['hello world', 'goodbye world'])

    terms = listify_lookup_plugin_terms(["hello world", "goodbye world"], templar, loader)
    assert(terms == ['hello world', 'goodbye world'])

    terms = listify_lookup_plugin_terms(["hello world", "{{ goodbye }} world"], templar, loader)
    assert(terms == ['hello world', 'goodbye world'])

# Generated at 2022-06-23 14:21:17.361209
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()
    var_mgr = VariableManager()
    templar = Templar(dl, var_mgr)
    var_mgr.set_inventory(None)

    import ansible.constants as C
    if C.DEFAULT_KEEP_REMOTE_FILES:
        from os import path
        import tempfile
        tempfile.tempdir = path.realpath(path.join(path.dirname(path.realpath(__file__)), '..'))


# Generated at 2022-06-23 14:21:26.418728
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeTerm(object):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return str(self.value)

    def test_terms(terms, end_terms):
        # mock templar to return the original term if the term is a FakeTerm
        class Templar(object):
            def template(self, terms, fail_on_undefined=True, convert_bare=False):
                if isinstance(terms, string_types) or not isinstance(terms, Iterable):
                    terms = [terms]

                new_terms = []
                for term in terms:
                    if isinstance(term, FakeTerm):
                        new_terms.append(str(term))
                    else:
                        new_terms.append(term)
                return new_terms

        templar = Templar

# Generated at 2022-06-23 14:21:37.276118
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    terms1 = AnsibleUnicode('{{ foo }}')
    terms2 = 'mystring'
    terms3 = ['mystring', 'mystring2']

    templar = Templar(loader=None, variables=variable_manager.get_vars(play=None), fail_on_undefined=True)

    assert listify_lookup_plugin_terms(terms1, templar, None) == []
    assert listify

# Generated at 2022-06-23 14:21:44.397020
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    # This test will verify that the function listify_lookup_plugin_terms is working properly.
    # The function is used to:
    #   - convert a string to a list if the string is delimited by the configuration option 'ANSIBLE_LOOKUP_PLUGIN_TERM_TO_LIST_SEPARATOR'
    #   - convert a (previously templated) string to a list
    #   - convert an iterable to a list


# Generated at 2022-06-23 14:21:54.966316
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)
    # First test with a string
    terms = 'first term'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == 'first term'
    # Now test with a list
    terms = ['second term', 'third term']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(result, list)
    assert len(result) == 2
    assert result[0] == 'second term'
    assert result[1] == 'third term'


# Generated at 2022-06-23 14:22:04.153545
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.module_utils.basic as basic

    terms1 = '[ "a", "b" ]'
    terms2 = [ 'a', 'b' ]
    terms3 = 'a'
    terms4 = { "a": "b", "c": "d" }
    terms5 = ' "a" '
    terms6 = ' [ "a", "b" ] '

    (res,) = basic.listify_lookup_plugin_terms(terms1)
    assert res == "a"
    (res,) = basic.listify_lookup_plugin_terms(terms2)
    assert res == "a"
    (res,) = basic.listify_lookup_plugin_terms(terms3)
    assert res == "a"
    (res,) = basic.listify_lookup_plugin_terms(terms4)

# Generated at 2022-06-23 14:22:13.441182
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Unit test for listify_lookup_plugin_term'''
    from ansible.templating import Templar

    templar = Templar(loader=None)

    # simple string
    assert listify_lookup_plugin_terms('test_string', templar, None) == ['test_string']

    # string with spaces, which should be converted to list
    assert listify_lookup_plugin_terms('test_string with spaces', templar, None) == ['test_string', 'with', 'spaces']

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-23 14:22:24.908688
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    my_vars = dict(
        string_var='value',
        list_var=['value1', 'value2'],
        list_var_with_none=[None, 'value3'],
        list_var_with_undef=[None, 'value3'],
        dict_var={'key': 'value'},
        bare_string='{{string_var}}',
        non_bare_string='{{string_var|string}}',
        bare_list='{{list_var}}',
        non_bare_list='{{list_var|list}}',
        bare_dict='{{dict_var}}',
        non_bare_dict='{{dict_var|dict}}',
    )

# Generated at 2022-06-23 14:22:36.511512
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.templar import Templar
    from ansible.template import Templar as NewTemplar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert listify_lookup_plugin_terms([], None, None) == []
    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']
    assert listify_lookup_plugin_terms(['bar','baz'], None, None) == ['bar','baz']
    assert listify_lookup_plugin_terms('a_{{ foo|d() }}_b', Templar(None, {}), None) == ['a__b']
    assert listify_lookup_plugin_terms(1, None, None) == [1]

# Generated at 2022-06-23 14:22:47.971321
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager, TemplateVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventories.inventory import Inventory
    from ansible.templating import Templar
    import os

    templar = Templar(loader=DataLoader(), variables=VariableManager(loader=DataLoader(), inventory=Inventory(".")))
    actual = listify_lookup_plugin_terms("{{foo}} {{bar}}", templar, DataLoader())
    expected = ['{{foo}}', '{{bar}}']
    assert actual == expected, "'%s' != '%s'" % (actual, expected)
    templar.available_variables = TemplateVars(hostvars=dict(foo='val1', bar='val2'))

# Generated at 2022-06-23 14:22:58.620252
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Mock AnsibleModule
    class AnsibleModule(object):
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec

    # Mock AnsibleModule().params
    class AnsibleParams(dict):
        def __init__(self):
            super(AnsibleParams, self).__init__()
            self[u'msg'] = u'this is a test'

    # Mock Templar()
    class AnsibleTemplar(object):
        def __init__(self, loader=None, variables=None):
            self.loader = loader
            self.variables = variables

        def template(self, terms, convert_bare=False, fail_on_undefined=True):
            return terms

    # Mock DataLoader()

# Generated at 2022-06-23 14:23:09.969268
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext

    v = VariableManager()
    vars = dict(
        one = ['a','b','c'],
    )
    v.set_host_variable('testhost', vars)

    context = PlayContext()
    context._variable_manager = v
    templar = Templar(loader=None, variables=v, shared_loader_obj=None)

    # list
    assert listify_lookup_plugin_terms(['a', 'b'], templar=templar, loader=None, fail_on_undefined=False) == ['a', 'b']
    assert listify_

# Generated at 2022-06-23 14:23:20.577405
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''test_listify_lookup_plugin_terms'''

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # Test a simple string result with no templating
    templar = Templar(loader=None)
    assert not isinstance(templar, string_types)
    assert not isinstance(templar, Iterable)

    # Test a simple string result with no templating
    result = listify_lookup_plugin_terms('foo', templar, None, False)
    assert not isinstance(result, string_types)
    assert isinstance(result, list)

    # Test a simple string result with templating

# Generated at 2022-06-23 14:23:28.709496
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unicode import to_unicode

    raw_data = '''
    - foo
    - bar
    - "{{ baz }}"
    - qux
    '''
    data = AnsibleLoader(raw_data).get_single_data()

    templar = Templar(loader=AnsibleLoader(raw_data))
    templar.available_variables = dict(baz='qux')

    # listify_lookup_plugin_terms should return a list (e.g. ['foo', 'bar', ...]) for input 'data'
    result = listify_lookup_plugin_terms(data, templar, loader)

# Generated at 2022-06-23 14:23:37.097216
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'anvar': 'ANVAR'}
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms("firstitem", templar, loader) == ["firstitem"]
    assert listify_lookup_plugin_terms("firstitem", templar, loader, True) == ["firstitem"]
    assert listify_lookup_plugin_terms("firstitem|seconditem", templar, loader) == ["firstitem", "seconditem"]

# Generated at 2022-06-23 14:23:47.086766
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    fake_loader = DataLoader()
    fake_vars = dict(
        one = "foo",
        two = "bar",
        three = "baz",
        four = "a,b,c",
        blank = "",
        empty_list = [],
    )
    templar = Templar(loader=fake_loader, variables=fake_vars)

    terms = listify_lookup_plugin_terms(["{{one}}", "{{two}}", "{{three}}", "{{four}}"], templar, fake_loader)
    assert terms == ["foo", "bar", "baz", "a,b,c"], terms


# Generated at 2022-06-23 14:23:57.306365
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(None, {})

    # Test a simple case
    terms = listify_lookup_plugin_terms("test", templar, None)
    assert terms == ["test"], terms

    # Test a simple case, non-string
    terms = listify_lookup_plugin_terms(["test"], templar, None)
    assert terms == ["test"], terms

    # Test a simple case, non-string iterable
    terms = listify_lookup_plugin_terms(set(["test"]), templar, None)
    assert terms == ["test"], terms

    # Test a simple case, non-string iterable with tuples

# Generated at 2022-06-23 14:24:07.528562
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    class FakeLoader:
        pass
    t = Templar(loader=FakeLoader())

    # basic string term
    assert listify_lookup_plugin_terms('foo', t, None) == ['foo']

    # string term with spaces
    assert listify_lookup_plugin_terms(' foo ', t, None) == ['foo']

    # string term with csv
    assert listify_lookup_plugin_terms('foo,bar', t, None) == ['foo', 'bar']

    # string term with csv and space
    assert listify_lookup_plugin_terms('foo, bar', t, None) == ['foo', 'bar']

    # string term with csv and spaces
    assert listify_lookup_plugin_terms(' foo, bar ', t, None) == ['foo', 'bar']

# Generated at 2022-06-23 14:24:12.175186
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = {'s':'{{foo}}', 'foo':'bar'}
    templar = FakeTemplar(terms)
    loader = False
    fail_on_undefined=True
    convert_bare=True
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    assert result == ['bar']

# Mock object to suppress exceptions on templar calls

# Generated at 2022-06-23 14:24:22.195036
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from jinja2 import Template
    from ansible.template import Templar
    from ansible.module_utils.six import string_types

    templar = Templar(None, loader=None)

# Generated at 2022-06-23 14:24:32.404813
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.errors as errors
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import lookup_loader

    # Setup a minimalistic data loader
    test_loader = DataLoader()

    # Setup templar
    templar = Templar(loader=test_loader, variables={'foo': 'bar'})

    # Test with string and expect a list with one item.
    terms = listify_lookup_plugin_terms('"{{ foo }}"', templar, test_loader)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert terms[0] == 'bar'

    # Test with string and expect a list with two items

# Generated at 2022-06-23 14:24:39.093251
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    # NoopLoader will return an empty dictionary
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)

    # Single term
    assert(listify_lookup_plugin_terms('foo', templar, loader) == ['foo'])
    # List of terms
    assert(listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar'])
    # Only one term even if it's a string in a list
    assert(listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo'])
    # Templating

# Generated at 2022-06-23 14:24:49.536442
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # deepcopy from ansible.compat.tests.mock
    import copy
    import sys
    if sys.version_info[0] < 3:
        from types import ClassType
    else:
        ClassType = type

    def _deepcopy_dispatch(x, memo):
        copier = copy._deepcopy_dispatch.get(type(x))
        if copier:
            return copier(x, memo)
        if isinstance(x, ClassType):
            return x
        raise TypeError("Unable to copy %r" % x)

    copy._deepcopy_dispatch = d = copy.deepcopy._deepcopy_dispatch.copy()
    copy.deepcopy = copy.deepcopy.__func__(copy._deepcopy_dispatch)

# Generated at 2022-06-23 14:24:59.755992
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    my_vars = dict(
        one='foo',
        two='bar',
        three='baz',
        four=['goo', 'gaz'],
        five=[1, 2],
        six=[1, 2, 3],
    )

    my_loader = DictDataLoader({'vars': my_vars})

    my_templar = Templar(loader=my_loader, variables=my_vars)

    assert listify_lookup_plugin_terms('{{ one }}',  my_templar, my_loader) == ['foo']
    assert listify_lookup_plugin_terms(['{{ one }}'], my_templar, my_loader) == ['foo']


# Generated at 2022-06-23 14:25:07.709960
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test strings
    assert listify_lookup_plugin_terms("foo bar", None, None) == ["foo bar"]
    assert listify_lookup_plugin_terms("foo", None, None) == ["foo"]
    assert listify_lookup_plugin_terms("foo \n bar", None, None) == ["foo", "bar"]

    # Test list
    assert listify_lookup_plugin_terms(["foo", "bar"], None, None) == ["foo", "bar"]
    assert listify_lookup_plugin_terms(["foo", "bar", "baz"], None, None) == ["foo", "bar", "baz"]
    assert listify_lookup_plugin_terms(["foo"], None, None) == ["foo"]

# Generated at 2022-06-23 14:25:17.647755
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # function test, basic string
    assert listify_lookup_plugin_terms(u'hello', templar=Templar(None), loader=None, fail_on_undefined=False) == ['hello']
    # function test, handles unicode and list
    assert listify_lookup_plugin_terms(u'hello,world', templar=Templar(None), loader=None, fail_on_undefined=False) == ['hello', 'world']
    assert listify_lookup_plugin_terms([u'hello', 'world'], templar=Templar(None), loader=None, fail_on_undefined=False) == ['hello', 'world']
    # function test, handles list of strings

# Generated at 2022-06-23 14:25:27.407117
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Make a fake PlayContext which we can use
    fake_loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts({'test_fact': "a_fact"})
    # variable_manager.set_host_variable(host, 'test_host_variable', "a_host_variable")
    play_context = PlayContext()

    # Use the Fake PlayContext and VarsManger to make a Templar, which we will use to test

# Generated at 2022-06-23 14:25:38.764429
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    import ansible.constants as C


# Generated at 2022-06-23 14:25:47.996930
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeVarsModule:
        pass

    class FakeLoader:
        pass

    my_vars_module = FakeVarsModule()
    my_loader = FakeLoader()
    my_loader.get_basedir = lambda x: "/"
    templar = Templar(loader=my_loader, variables=my_vars_module)

    # test a string
    assert listify_lookup_plugin_terms("foobar", templar, my_loader) == ["foobar"]

    # test a list
    assert listify_lookup_plugin_terms(["foo", "bar"], templar, my_loader) == ["foo", "bar"]

    # test a tuple

# Generated at 2022-06-23 14:25:58.829495
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Import the class required for testing
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    # Create objects for templar
    loader = DataLoader()
    vault_secrets = {'password': 'secret'}
    vault_password_file = None
    vault = VaultLib(vault_secrets=vault_secrets, vault_password_file=vault_password_file)
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(password='secret')
    templar = Templar(loader=loader, variables=variable_manager, vault_secrets=vault_secrets)

    # Testing the function

# Generated at 2022-06-23 14:26:06.609975
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variable_manager=variable_manager)
    terms = "{{ var1 }}"
    variable_manager.set_nonpersistent_facts(dict(var1='example1.com'))
    assert listify_lookup_plugin_terms(terms, templar=templar, loader=loader) == ['example1.com']

    variable_manager.set_nonpersistent_facts(dict(var1=['example1.com', 'example2.com']))

# Generated at 2022-06-23 14:26:15.938956
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # For each test case, provide arguments to listify_lookup_plugin_terms,
    # use AnsibleJSONEncoder to JSON-ify the result, and compare against
    # the expected value.

# Generated at 2022-06-23 14:26:27.952342
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    result = listify_lookup_plugin_terms('foo', templar, loader)
    assert result == ['foo']
    result = listify_lookup_plugin_terms('foo bar', templar, loader)
    assert result == ['foo bar']
    result = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)
    assert result == ['foo', 'bar']
    result = listify_lookup_plugin_terms(('foo', 'bar'), templar, loader)

# Generated at 2022-06-23 14:26:39.911769
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DictDataLoader({})
    myvars = dict(
        bare1='a',
        bare2='b',
        bare3={'c': '3'},
        bare4={'d': '4'},
        list1='a:b:c',
        list2=['a', 'b', 'c'],
        list3=['a', 'b', 'c:d:e'],
        nested_list=[['a'], ['b']],
    )
    templar = Templar(loader=loader, variables=myvars)

    assert listify_lookup_plugin_terms('{{ bare1 }}', templar, loader) == ['a']

# Generated at 2022-06-23 14:26:51.745252
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager

    terms_to_test = [
        '{{ var_name }}',
        [ '{{ var_name }}', '{{ val_name }}' ],
        {
            'key': '{{ var_name }}',
            'val': '{{ val_name }}'
        }
    ]

    vars_manager = VariableManager()
    vars_manager.extra_vars = { 'var_name': 'var_val', 'val_name': 'val_val' }
    vars_manager.set_nonpersistent_facts(dict(vault_password='ansible'))
    vault_secrets = dict()
    vault = VaultLib(vault_secrets)
    templ

# Generated at 2022-06-23 14:27:02.868828
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible

    from ansible.template import Templar

    ###################################################################
    #### Convert a list into a list
    ###################################################################

    templar = Templar(loader=ansible.utils.loader.Loader())

    terms='[ "a", "b", "c" ]'
    # We don't have anything to look up so we pass None
    t = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(t, list)
    assert len(t) == 3
    assert t[0] == 'a'
    assert t[1] == 'b'
    assert t[2] == 'c'

    ###################################################################
    #### Convert a bare string into a list
    ###################################################################


# Generated at 2022-06-23 14:27:12.204178
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    # Test listify_lookup_plugin_terms on a string
    assert listify_lookup_plugin_terms("foo", templar, None) == ['foo']
    assert isinstance(listify_lookup_plugin_terms("foo", templar, None), list)

    # Test listify_lookup_plugin_terms on a list
    assert listify_lookup_plugin_terms(["foo", "bar"], templar, None) == ['foo', 'bar']
    assert isinstance(listify_lookup_plugin_terms(["foo", "bar"], templar, None), list)

# Generated at 2022-06-23 14:27:21.653898
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.path import makedirs_safe
    from ansible.utils.unicode import to_bytes
    from pyVmomi import vim
    from units.compat.mock import patch
    from units.mock.loader import DictDataLoader


# Generated at 2022-06-23 14:27:25.027166
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms([['a', 'b']], None, None) == [['a', 'b']]
    assert listify_lookup_plugin_terms(['a', 'b'], None, None) == ['a', 'b']
    assert listify_lookup_plugin_terms('a', None, None) == ['a']