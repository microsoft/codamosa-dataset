

# Generated at 2022-06-23 14:17:35.512346
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    class TemporaryModule(object):
        def __init__(self):
            self.params = dict()
            self.params['vars'] = dict()
            self.params['_ansible_no_log'] = False

        def fail_json(*args, **kwargs):
            raise Exception('FAILED: {0}'.format(kwargs['msg']))

        def exit_json(self, **kwargs):
            pass


# Generated at 2022-06-23 14:17:45.782225
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class A(object):
        pass

    class B(object):
        pass

    a = A()
    b = B()
    a.vars = {'a': 'foo', 'b': 'bar'}
    b.vars = {'a': 'fox', 'b': 'far'}
    a.get_vars = lambda: a.vars
    b.get_vars = lambda: b.vars
    a.get_name = lambda: 'a'
    b.get_name = lambda: 'b'
    a.basedir = 'a'
    b.basedir = 'b'

    # We are only testing the logic here, so the templating functions are
    # intentionally left bare.
    templar = a

# Generated at 2022-06-23 14:17:55.712809
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class MockTemplar(Templar):
        def __init__(self, variables):
            self._available_variables = variables
            super(MockTemplar, self).__init__(loader=None)

    class MockHostVars(object):
        def __init__(self, variables):
            self._data = variables

        def get_vars(self, host):
            return self._data

    class MockTaskVars(object):
        def __init__(self, variables):
            self._data = variables

        def get_vars(self, task):
            return self._data


# Generated at 2022-06-23 14:18:07.084534
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # With fail_on_undefined=True (default), undefined variable causes exception
    t = Templar(loader=None, variables=dict())
    try:
        # fail_on_undefined=True
        terms = listify_lookup_plugin_terms('{{ foo }}', t, None)
        assert False, "expected exception"
    except Exception:
        pass

    # With fail_on_undefined=False, undefined variable is stringified properly
    terms = listify_lookup_plugin_terms('{{ foo }}', t, None, fail_on_undefined=False)
    assert isinstance(terms, list) and terms == ['{{ foo }}'], terms

    # With fail_on_undefined=False, undefined variable is stringified properly

# Generated at 2022-06-23 14:18:19.025492
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    class FakeVaultSecret(object):
        def __init__(self, vault_secret):
            self.vault_secret = vault_secret

        def decrypt(self):
            return self.vault_secret

    # Test string with bare variable
    vault_pass = 'foo'
    vault = VaultLib(vault_pass)
    loader = AnsibleLoader(None, vault)
    variable_manager = VariableManager()

# Generated at 2022-06-23 14:18:29.208669
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode

    password = 'password'

    loader, templar, all_vars = VaultLib().load_vault_password(password, ['tests/test_vault.yml'], 'tests', None)
    templar = Templar(loader=loader, variables=all_vars)


# Generated at 2022-06-23 14:18:38.039692
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    """
    Test terms as string
    """
    terms = "{{ ansible_eth0.ipv4.address }}"
    templar, loader = get_test_templar_loader()
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert isinstance(terms[0], string_types)

    """
    Test terms as unicode string
    """
    terms = u"{{ ansible_eth0.ipv4.address }}"
    templar, loader = get_test_templar_loader()
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert len(terms) == 1

# Generated at 2022-06-23 14:18:41.521571
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(DataLoader())

# Generated at 2022-06-23 14:18:51.022683
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    fake_loader = dict(
        path_dwim=lambda x: x,
        get_basedir=lambda x: x,
    )
    fake_inventory = InventoryManager(loader=fake_loader, sources=[])
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    templar = Templar(loader=fake_loader, variables=fake_variable_manager)

    assert listify_lookup_plugin_terms('string', templar, fake_loader) == ['string']

# Generated at 2022-06-23 14:19:01.425614
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('"foo"', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('"foo\n"', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo\n', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']

# Generated at 2022-06-23 14:19:11.450221
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from jinja2 import Template
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None, {}, 'test_listify_lookup_plugin_terms'))

    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader=None) == ['a', 'b']
    assert listify_lookup_plugin_terms('a b', templar, loader=None) == ['a', 'b']
    assert listify_lookup_plugin_terms('a\nb', templar, loader=None) == ['a\nb']

# Generated at 2022-06-23 14:19:22.369116
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    # the Jinja Environment is shared between the two Templar objects,
    # which is important here
    temp = Templar(loader=loader)
    temp_convert_bare = Templar(loader=loader, variables={'ansible_convert_bare': True})
    assert listify_lookup_plugin_terms('foo', temp, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo', temp, loader, convert_bare=True) == ['foo']

    assert listify_lookup_plugin_terms('{{ a }}', temp, loader, convert_bare=True) == ['{{ a }}']

# Generated at 2022-06-23 14:19:28.594275
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)
    assert listify_lookup_plugin_terms('item1', templar, loader) == ['item1']
    assert listify_lookup_plugin_terms(['item1'], templar, loader) == ['item1']
    assert listify_lookup_plugin_terms('item1,item2', templar, loader) == ['item1', 'item2']

# Generated at 2022-06-23 14:19:40.139116
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms([1, 2, 3], Templar(), None) == [1, 2, 3]
    assert listify_lookup_plugin_terms([1, 2, 3], Templar(), None, fail_on_undefined=False) == [1, 2, 3]
    assert listify_lookup_plugin_terms('{{ foo }}', Templar(), None) == [1]
    assert listify_lookup_plugin_terms({'a': 1, 'b': 2}, Templar(), None) == [{'a': 1, 'b': 2}]
    assert listify_lookup_plugin_terms('{{ foo }},{{ bar }}', Templar(), None) == [1, 2]

# Generated at 2022-06-23 14:19:49.731370
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    def _get_vars(v):
        return VariableManager(loader=None, variables=v)

    # Setup templar
    var_mgr = _get_vars({'localhost': 'first'})
    t = Templar(loader=None, variables=var_mgr)

    # Test types (for py2 and py3)
    assert(listify_lookup_plugin_terms('first', t, None, fail_on_undefined=False) == ['first'])
    assert(listify_lookup_plugin_terms(b'first', t, None, fail_on_undefined=False) == ['first'])

# Generated at 2022-06-23 14:20:00.809557
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    terms = "{{ foo }}"
    templar = Templar(loader=None, variables={'foo':'bar'})
    assert(listify_lookup_plugin_terms(terms, templar) == ['bar'])
    assert(listify_lookup_plugin_terms(terms, templar, convert_bare=True) == ['bar'])
    terms = AnsibleUnsafeText(u"{{ foo }}")
    assert(listify_lookup_plugin_terms(terms, templar, convert_bare=True) == [AnsibleUnsafeText(u'bar')])

# Generated at 2022-06-23 14:20:06.358614
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.loader import DataLoader
    from ansible.parsing.dataloader import DataLoader as ParsingDataLoader

    class TestTemplar(Templar):
        def __init__(self, variables):
            self._available_variables = variables
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    variable_manager.set_inventory(None)
    variable_manager.set_variable_manager(variable_manager)
    parser = ParsingDataLoader()
    templar = TestTemplar(variable_manager.get_vars())
    # Test strings
    assert listify_lookup_plugin_terms("1", templar, loader) == ["1"]

# Generated at 2022-06-23 14:20:18.801373
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # setup mock jinja2 environment
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    fake_loader = DictDataLoader({
        "yaml": {"foo": "bar"},
        "list": "- foo\n- bar",
        "dict": "foo: bar",
        "undefined": "{{ missing }}",
    })

    t = Templar(loader=fake_loader)

    # test that a string is converted to a list
    assert listify_lookup_plugin_terms('foo', t, fake_loader) == ['foo']

    # test that a non-iterable non-string is wrapped in a list
    assert listify_lookup_plugin_terms(False, t, fake_loader) == [False]

    # test that a list is unchanged


# Generated at 2022-06-23 14:20:26.061495
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeLoader:
        def get_basedir(self, hostname):
            return 'test'

    class FakeVars:
        vars = { 'test_var': 'bar.txt' }

    templar = Templar(loader=FakeLoader(), variables=FakeVars())
    assert listify_lookup_plugin_terms('foo.txt', templar, loader=None) == ['foo.txt']
    assert listify_lookup_plugin_terms(['foo.txt'], templar, loader=None) == ['foo.txt']
    assert listify_lookup_plugin_terms(['foo.txt', 'bar.txt'], templar, loader=None) == ['foo.txt', 'bar.txt']

# Generated at 2022-06-23 14:20:37.266561
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.template

    t = ansible.template.AnsibleTemplate(None, None)

    assert listify_lookup_plugin_terms(terms=t.template('foo'), templar=t, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(terms=t.template('[ foo ]'), templar=t, loader=None) == ['[ foo ]']
    assert listify_lookup_plugin_terms(terms=t.template('[foo, bar]'), templar=t, loader=None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms=t.template('[foo, bar, ]'), templar=t, loader=None) == ['foo', 'bar']

# Generated at 2022-06-23 14:20:47.216724
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    # setup
    loader = DataLoader()
    vault_secrets = {}
    templar = Templar(loader=loader, variables={}, vault_secrets=vault_secrets)
    terms = '{{ foo }}'
    templar.available_variables = dict(foo='bar')

    # test
    result = listify_lookup_plugin_terms(terms=terms, templar=templar, loader=loader)

    # assert
    assert result == ['bar']


# Generated at 2022-06-23 14:20:56.241868
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(5, templar, loader) == [5]
    assert listify_lookup_plugin_terms('foo', templar, loader, convert_bare=True) == ['foo']
    assert listify_lookup_plugin_terms('foo', templar, loader, convert_bare=False) == ['foo']
    assert listify_lookup_plugin_terms('{{foo}}', templar, loader, convert_bare=True) == ['{{foo}}']

# Generated at 2022-06-23 14:21:05.481426
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing import vault
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Dummy loader and vault secrets
    loader = DummyVars()
    vault_secrets = {'vault_password': 'vault_password'}
    vault.VaultLib.update_vault_secrets(vault_secrets, None, None)

    # Dummy context
    context = PlayContext()
    context._vars_cache={'var_a': 'a', 'var_b': 'b'}

    # Templating engine
    templar = Templar(loader=loader, variables=context._vars_cache, vault_secrets=vault_secrets)

    # Basic test

# Generated at 2022-06-23 14:21:14.232773
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    terms = [u'foo', u'bar', u'baz']
    templar = Templar(loader=DataLoader(), variables=VariableManager())
    templar.set_available_variables(dict(foo=u'foo',
                                         bar=u'bar',
                                         baz=u'baz'))

    results = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert [u'foo', u'bar', u'baz'] == results

    # test bare_vars

# Generated at 2022-06-23 14:21:24.260266
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class TestClass(object):
        def __init__(self):
            self._templar = Templar(loader=None, variables={})

    tc = TestClass()

    # Test list:
    terms = ['a', 'b', 'c']
    assert listify_lookup_plugin_terms(terms, tc._templar, None) == terms
    assert listify_lookup_plugin_terms(terms, tc._templar, None, convert_bare=True) == terms

    # Test string:
    assert listify_lookup_plugin_terms('a', tc._templar, None) == ['a']
    assert listify_lookup_plugin_terms('a', tc._templar, None, convert_bare=True) == ['a']

    # Test template string:
   

# Generated at 2022-06-23 14:21:29.700780
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class DummyVarManager(object):
        def __init__(self):
            self.vars = dict(a=1, b=2, c=3)

    class DummyTemplar(Templar):
        def __init__(self, variables):
            self._templates = []
            self._vars = variables

    class DummyLoader(object):
        def __init__(self):
            self.path_dwim = lambda x: '/etc/ansible/%s' % x

    loader = DummyLoader()
    var_mgr = DummyVarManager()
    templar = DummyTemplar(var_mgr)

    # Test with string type

# Generated at 2022-06-23 14:21:39.503169
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import jinja2

    # TODO: change to test directory
    fake_loader = jinja2.DictLoader({'templates/foo.j2': '{{ foo }}'})

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.set_available_variables(variable_manager.get_vars(loader=fake_loader, play=dict(vars=dict(foo='bar'))))

    templar = Templar(loader=fake_loader, variables=variable_manager)


# Generated at 2022-06-23 14:21:49.654918
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Test listify_lookup_plugin_terms with different types of input
    """
    import jinja2
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    from ansible.utils.vars import combine_vars

    templar = Templar(loader=None, variables=combine_vars(loader=None, variables=None), vault_secrets=dict(VaultLib().secrets))
    # string, return list
    assert listify_lookup_plugin_terms(terms='one,two,three', templar=templar, loader=None) == ['one', 'two', 'three']
    # list, return list

# Generated at 2022-06-23 14:22:00.043515
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system import distribution
    from ansible.template import Templar

    my_dist = Distribution()
    my_dist.name = "Fedora"
    my_dist.version = "21"
    my_dist.version_best = "21"

    distribution.cache = dict(distribution=my_dist)

    my_vars = dict(
        fedora_distribution = "Fedora",
        fedora_version = "21",
        fedora_version_best = "21",
    )

    my_loader = DictDataLoader({})

    my_templar = Templar(loader=my_loader, variables=my_vars)


# Generated at 2022-06-23 14:22:10.047935
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar

    # Setup for the test
    loader = None
    fail_on_undefined = True
    convert_bare = False
    templar = Templar(loader=loader, variables={})
    terms = None
    terms_result = []

    # Test that the function returns an empty list when the terms are None
    terms_result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    assert isinstance(terms_result, list)
    assert len(terms_result) == 0

    # Test that the function returns the terms list when the terms are already a list
    terms = ['one', 'two', 'three']
    terms_result = listify_look

# Generated at 2022-06-23 14:22:19.452605
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext

    terms = '{{ test_var1 }}'
    templar = Templar(loader=None, variables=combine_vars(dict(test_var1='test_str1'), dict()), vault_password=VaultLib(), come_from='main')
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['test_str1']

# Generated at 2022-06-23 14:22:30.050628
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-23 14:22:40.680109
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Setup
    import ansible.parsing.yaml.objects
    import ansible.template

    def templar(template, convert_bare=False, fail_on_undefined=True):
        return str(template)

    templar = ansible.template.Templar(loader=None, variables={})
    templar._available_variables = dict()
    # All the combinations of parameters we want to test

# Generated at 2022-06-23 14:22:51.371982
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Expected:
    # - If a string is passed, it should be returned as a list with one item.
    # - If a list is passed, it should be returned as-is
    #     - Unless some of its items are string, in which case it should convert them to a list
    # - If a non-Iterable value is passed, it should be "listified" (wrapped in a list), even if it is None
    # - If a dict is passed, it should be "listified" (wrapped in a list).
    # - If an Iterable that is not a list, dict or basestring is passed, it should be returned as-is.
    # - Role default arguments **SHOULD NOT** be "listified", they should be returned as-is.

    from ansible.template import Templar

# Generated at 2022-06-23 14:23:02.415528
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    terms = '{{ foo }}'
    templar = Templar(loader=None, shared_loader_obj=None)
    assert terms == listify_lookup_plugin_terms(terms, templar, None)

    terms = AnsibleUnicode('{{ foo }}')
    assert '{{ foo }}' in listify_lookup_plugin_terms(terms, templar, None)

    terms = {'a': '{{ foo }}', 'b': '{{ bar }}'}
    templar = Templar(loader=None, variables={'foo': 'spam', 'bar': 'eggs'}, shared_loader_obj=None)

# Generated at 2022-06-23 14:23:12.732688
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    class Options(object):
        def __init__(self, variables={}):
            self.vars = variables
    t = Templar(Options({'a': '1', 'b': '2'}))
    assert(listify_lookup_plugin_terms('{{a}}', t, None) == ['1'])
    assert(listify_lookup_plugin_terms(['{{a}}'], t, None) == ['1'])
    assert(listify_lookup_plugin_terms(['1', '{{b}}'], t, None) == ['1', '2'])

# Generated at 2022-06-23 14:23:22.884647
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(None, {})
    templar = Templar(loader=loader, variables={'item': 'example'})
    assert listify_lookup_plugin_terms('{{ item }}', templar, loader) == ['example']
    assert listify_lookup_plugin_terms(['{{ item }}'], templar, loader) == ['example']
    assert listify_lookup_plugin_terms(['hello', ['{{ item }}']], templar, loader) == ['hello', ['example']]
    assert listify_lookup_plugin_terms(['hello', 'world'], templar, loader) == ['hello', 'world']

# Generated at 2022-06-23 14:23:34.672143
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    def mock_template(data, convert_bare=False, fail_on_undefined=True):
        if isinstance(data, string_types):
            return data
        else:
            return data['from']


# Generated at 2022-06-23 14:23:45.471149
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Test listify_lookup_plugin_terms function'''
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variables = VariableManager()
    templates = Templar(loader=loader, variables=variables)

    # Test no template
    terms = "hello"
    result = listify_lookup_plugin_terms(terms, templates, loader)
    assert result == ['hello']

    # Test single template
    terms = "{{foo}}"
    variables.set_variable('foo', {'bar': 'myvar'})
    result = listify_lookup_plugin_terms(terms, templates, loader)

# Generated at 2022-06-23 14:23:56.381782
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    def _get_vault_password(prompt=None):
        return 'secret'

    def test_template(data, convert_bare=False, fail_on_undefined=True, override_vars=None):
        return data

    templar = type('FakeTemplar', (object,), {'template':test_template})()
    password = VaultLib.obtain_password(_get_vault_password, 'ask', None)
    editor = VaultEditor(password)
    loader = type('FakeVaultLoader', (object,), {'_vault':editor})()

    assert listify_lookup_plugin_

# Generated at 2022-06-23 14:24:06.543950
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class TestTemplar():
        def template(self, data, convert_bare=False, fail_on_undefined=True):
            return data

    class TestLoader():
        pass

    templar = TestTemplar()
    loader = TestLoader()

    terms = "a, b, c"
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert len(terms) == 3
    assert isinstance(terms[0], string_types)

    terms = ["a", "b", "c"]
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert len(terms) == 3
    assert isinstance(terms[0], string_types)

    terms

# Generated at 2022-06-23 14:24:17.541535
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    templar = Templar(loader=None)

    # Tests where the templar returns a string
    assert listify_lookup_plugin_terms('{{foo}}', templar, None) == ['{{foo}}']
    assert listify_lookup_plugin_terms(['{{foo}}'], templar, None) == ['{{foo}}']
    assert listify_lookup_plugin_terms(['foo', '{{bar}}'], templar, None) == ['foo', '{{bar}}']
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # Tests where the templar returns a list

# Generated at 2022-06-23 14:24:22.629685
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from io import StringIO
    import yaml

    templar = Templar(loader=AnsibleLoader(StringIO()), variable_manager=VariableManager())
    assert listify_lookup_plugin_terms(yaml.load('"foo"'), templar, None) == ['foo']
    assert listify_lookup_plugin_terms(yaml.load('["foo"]'), templar, None) == ['foo']
    assert listify_lookup_plugin_terms(yaml.load('[foo]'), templar, None) == ['foo']

# Generated at 2022-06-23 14:24:32.703159
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class DummyVars(object):
        def __init__(self):
            self.hostvars = {}

    dummy_var_mgr = VariableManager()
    dummy_var_mgr._vars_cache = DummyVars()

    templar = Templar(loader=None, variables=dummy_var_mgr)


# Generated at 2022-06-23 14:24:43.436386
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import sys

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO
    from ansible.template import Templar, DictVars

    from ansible.parsing.yaml.objects import AnsibleUnicode

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, obj):
            raise AssertionError(obj['msg'])

    module = FakeModule()
    templar = Templar(loader=None, variables=DictVars())

    listify_lookup_plugin_terms('foo', templar, loader=None)

    # We don't expect this to work in Python 3

# Generated at 2022-06-23 14:24:52.589755
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = AnsibleLoader(None, variable_manager=VariableManager(), loader_class=AnsibleLoader)
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 14:25:02.716901
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.template import Templar

    templar = Templar(loader=None)

    # Test string terms
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert result == ['foo']

    terms = 'foo, bar'
    result = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert result == ['foo, bar']

    terms = '{{ foo }}, bar'
    result = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)

# Generated at 2022-06-23 14:25:10.195924
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = DictDataLoader({})

    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar,baz'], templar, loader) == ['foo', 'bar,baz']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader, convert_bare=True) == ['{{ foo }}']
    assert listify_look

# Generated at 2022-06-23 14:25:13.824210
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = "{{ foo.bar }}"
    templar = Templar()

    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ["{{ foo.bar }}"]

# Generated at 2022-06-23 14:25:24.423127
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    loader = DictDataLoader({})
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms([], templar, loader) == []
    assert listify_lookup_plugin_terms('', templar, loader) == ['']
    assert listify_lookup_plugin_terms(u'hello world', templar, loader) == ['hello world']
    assert listify_lookup_plugin_terms(AnsibleUnicode('hello world'), templar, loader) == ['hello world']
    assert listify_lookup_plugin_terms(['hello world'], templar, loader) == ['hello world']
    assert listify_lookup_plugin_

# Generated at 2022-06-23 14:25:36.501667
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    from ansible.errors import AnsibleUndefinedVariable

    templar = Templar(loader=DataLoader())

    if PY3:
        u_str = '\u0070\u0079\u0074\u0068\u006f\u006e'
        b_str = '\x70\x79\x74\x68\x6f\x6e'
    else:
        u_str = '\x70\x79\x74\x68\x6f\x6e'
        b_str = u_str

    #

# Generated at 2022-06-23 14:25:43.251499
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    v = VariableManager()
    t = Templar(vars=v)

    assert listify_lookup_plugin_terms("one", t, None) == ["one"]
    assert listify_lookup_plugin_terms("one two", t, None) == ["one two"]
    assert listify_lookup_plugin_terms(["one two"], t, None) == ["one two"]
    assert listify_lookup_plugin_terms(["one", "two"], t, None) == ["one", "two"]

# Generated at 2022-06-23 14:25:51.363426
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Manually import the Ansible plugins
    from ansible.plugins.loader import lookup_loader
    from ansible.playbook.play_context import PlayContext

    # Fake the Ansible context
    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.runner_queue_host=''
        def fail_json(self, *args, **kwargs):
            raise Exception("Module execution failed")

    class FakeAnsiblePlayContext(PlayContext):
        def __init__(self):
            PlayContext.__init__(self)

    # Create a fake ansible context
    context = FakeAnsiblePlayContext()
    context._variable_manager = lookup_loader.variable_manager
    context._loader = lookup_loader.loader

    from ansible.template import Templar
    tem

# Generated at 2022-06-23 14:26:02.088814
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    get_var = lambda x: templar.template('{{ %s }}' % x)

    assert listify_lookup_plugin_terms('a', templar, loader) == ['a']
    assert listify_lookup_plugin_terms([1,2,3], templar, loader) == [ 1, 2, 3 ]
    assert listify_lookup_plugin_terms({}, templar, loader) == [ {} ]

# Generated at 2022-06-23 14:26:12.257760
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    plaintext_vault = VaultLib([])

    templar = Templar(loader=None, shared_loader_obj=None, variables={}, vault_secrets=plaintext_vault, convert_bare=False)

    assert listify_lookup_plugin_terms('1st', templar, None) == ['1st']
    assert listify_lookup_plugin_terms(['1st', '2nd'], templar, None) == ['1st', '2nd']
    assert listify_lookup_plugin_terms(['{{ansible_env.HOME}}', '{{ansible_env.PATH}}'], templar, None) == ['/home/user', '/usr/bin:']

# Generated at 2022-06-23 14:26:22.104548
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    import ansible.vars
    templar = ansible.template.Templar(loader=None, variables=ansible.vars.VariableManager())
    terms = templar.template('{{ foo}}', convert_bare=True)
    assert terms == '{{ foo}}'
    terms = templar.template(None)
    assert terms == None
    terms = templar.template(['foo', 'bar'])
    assert terms == ['foo', 'bar']
    terms = templar.template('foo bar')
    assert terms == 'foo bar'
    terms = templar.template(['foo', '{{ bar }}', 'baz'])
    assert terms == ['foo', '{{ bar }}', 'baz']

# Generated at 2022-06-23 14:26:27.899763
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    var_manager = VariableManager()
    var_manager.set_inventory(loader.load_inventory('localhost,'))
    templar = Templar(loader=loader, variables=var_manager)

    terms = 'foo'
    terms = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False)
    assert terms == ['foo'], terms

    terms = 'foo,bar'
    terms = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False)
    assert terms == ['foo', 'bar'], terms


# Generated at 2022-06-23 14:26:39.869254
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    class VaultSecret(object):
        def __init__(self, ansible_vault_password):
            self.ansible_vault_password = ansible_vault_password

    loader = DataLoader()
    vault_secret = VaultSecret('secret')
    templar = Templar(loader=loader, vault_secrets=[vault_secret])


# Generated at 2022-06-23 14:26:51.745480
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestTemplar(Templar):
        def __init__(self, variables):
            self._available_variables = variables

        def template(self, term, convert_bare=False, fail_on_undefined=True, preserve_trailing_newlines=False, escape_backslashes=True):
            return self._available_variables.get(term, term)

    class TestModuleUtilsCommonLookupPlugins(unittest.TestCase):
        def setUp(self):
            self.mock_loader = MagicMock()

        def tearDown(self):
            pass


# Generated at 2022-06-23 14:27:02.529604
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import template

    test_relative_templates = {
        # String becomes a list, single-element
        'string': [ 'string' ],

        # List is converted to a list, multiple elements
        ['list_element', 'another_element']: [ 'list_element', 'another_element' ],

        # None is converted to a list, single-element
        None: [None],
    }

    for terms, expected_results in test_relative_templates.items():
        results = listify_lookup_plugin_terms(terms, template.Templar(loader=None), None, fail_on_undefined=True)
        assert results == expected_results, 'invalid result for value %s. result should be %s, not %s' % (terms, expected_results, results)

# Generated at 2022-06-23 14:27:13.236969
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = None
    templar = Templar(loader=loader, variable_manager=variable_manager)

    string_terms = 'foo'
    assert listify_lookup_plugin_terms(string_terms, templar, loader) == ['foo']
    int_terms = 42
    assert listify_lookup_plugin_terms(int_terms, templar, loader) == [42]
    list_of_strings_terms = ['foo', 'bar']
    assert listify_lookup_plugin_terms(list_of_strings_terms, templar, loader) == ['foo', 'bar']
   

# Generated at 2022-06-23 14:27:21.470786
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import jinja2
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert listify_lookup_plugin_terms('foo', jinja2.Environment(), jinja2.FileSystemLoader('/')) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], jinja2.Environment(), jinja2.FileSystemLoader('/')) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(AnsibleUnsafeText('foo'), jinja2.Environment(), jinja2.FileSystemLoader('/')) == ['foo']

# Generated at 2022-06-23 14:27:27.882674
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    myvault = VaultLib(password_file='password.txt')
    templar = Templar(loader=loader, variables=VariableManager(), vault_secrets=myvault)
    assert listify_lookup_plugin_terms("foo", templar, loader) == ["foo"]
    assert listify_lookup_plugin_terms("{{ 'foo' }}", templar, loader) == ["foo"]
    assert listify_lookup_plugin_terms("{{'a1'}} {{'a2'}}", templar, loader) == ["a1", "a2"]