

# Generated at 2022-06-23 14:17:32.248708
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    vault_pass = os.path.join(os.path.dirname(__file__), 'test_vault.txt')
    v = VaultLib(vault_pass)
    p = PlayContext()
    hv = HostVars(UnsafeProxy({'localhost': dict(hv='bar')}), vault_password=vault_pass)
    i = InventoryManager([], vault_password=vault_pass)

   

# Generated at 2022-06-23 14:17:40.385202
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'a': 'foo', 'b': [1, 2], 'c': False, 'd': {'e':3, 'f':{'g': 'good'}}})

    assert listify_lookup_plugin_terms(['1', 2, {'a':'b'}, '{{c}}'], templar=templar) == ['1', 2, {'a':'b'}, False]
    assert listify_lookup_plugin_terms('1', templar=templar) == ['1']
    assert listify_lookup_plugin_terms('{{a}}', templar=templar) == ['foo']

# Generated at 2022-06-23 14:17:50.771568
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    def test(terms, expected_terms):
        actual_terms = listify_lookup_plugin_terms(terms, templar, loader=None)
        assert actual_terms == expected_terms

    # None
    test(None, [None])

    # String
    test("one", ['one'])
    test("one,two", ['one', 'two'])
    test("{{one}}", ['{{one}}'])

    # Integer
    test(1, [1])
    test([1], [1])

    # List
    test(['one'], ['one'])
    test(['one', 'two'], ['one', 'two'])
    test(['{{one}}'], ['{{one}}'])

# Generated at 2022-06-23 14:18:00.288604
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Example of function usage:
    # - name: template lookup test
    #   debug: msg="{{ lookup('template', './test.j2', convert_data=True) | list }}"

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.config.manager import ConfigManager, Setting, DataLoader

    config_manager = ConfigManager()
    config_manager.load_settings(
        Setting('ANSIBLE_CONFIG', env_var='ANSIBLE_CONFIG'),
        Setting('ANSIBLE_CONFIG_FILE', env_var='ANSIBLE_CONFIG', default='ansible.cfg'),
    )

    vault_secrets = VaultLib(config_manager)
    loader = DataLoader(config_manager)

# Generated at 2022-06-23 14:18:08.639602
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    listify_lookup_plugin_terms(terms=['1','2'], templar=None, loader=None)
    listify_lookup_plugin_terms(terms=1, templar=None, loader=None)
    listify_lookup_plugin_terms(terms=['1'], templar=None, loader=None)
    listify_lookup_plugin_terms(terms=None, templar=None, loader=None)
    listify_lookup_plugin_terms(terms=1.1, templar=None, loader=None)
    listify_lookup_plugin_terms(terms=False, templar=None, loader=None)

# Generated at 2022-06-23 14:18:19.936879
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Stub a templar and loader, so we don't have to import the whole of Ansible
    class FakeTemplar(object):
        def template(self, terms, fail_on_undefined=True, convert_bare=False):
            return terms

    class FakeLoader(object):
        def path_dwim(self, basedir, basename='', target=''):
            return 'path_dwim/' + os.path.join(basedir, basename, target).strip('/')

    # Create a lookup plugin helper
    templar = FakeTemplar()
    loader = FakeLoader()

    # Basic tests
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader, fail_on_undefined=True) == ['foo', 'bar']
    assert listify_

# Generated at 2022-06-23 14:18:29.966759
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        from ansible.module_utils.common._collections_compat import MutableSequence
    except ImportError:
        MutableSequence = list

    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()
    vault_secrets = VaultLib([])
    variable_manager = VariableManager()

    args = {'loader': dl, 'vault_secrets': vault_secrets, 'variable_manager': variable_manager}
    t = AnsibleTemplate(args)

    assert isinstance(listify_lookup_plugin_terms(None, t, **args), MutableSequence)

# Generated at 2022-06-23 14:18:38.584332
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template.safe_eval
    fake_tmpl = ansible.template.safe_eval.AnsibleUnsafeText('')

    # test for each type of valid non list input
    for i in ('hello', 'hello1, hello2', ['hello', 'hello1, hello2'], ('hello', 'hello1, hello2'), ('hello1, hello2')):
        assert listify_lookup_plugin_terms(i, fake_tmpl, None) == ['hello', 'hello1, hello2']

    # test for each type of valid list input
    for i in ([['hello', 'hello1, hello2']], (['hello', 'hello1, hello2'])):
        assert listify_lookup_plugin_terms(i, fake_tmpl, None) == ['hello', 'hello1, hello2']

# Generated at 2022-06-23 14:18:48.785060
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    templar = Templar(loader=None)

    # test with a string
    assert(listify_lookup_plugin_terms('foo', templar, None, fail_on_undefined=False) == ['foo'])
    assert(listify_lookup_plugin_terms(u'bar', templar, None, fail_on_undefined=False) == ['bar'])
    assert(listify_lookup_plugin_terms(AnsibleUnicode('baz'), templar, None, fail_on_undefined=False) == ['baz'])

    # test with a list

# Generated at 2022-06-23 14:18:59.956141
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext

    # TODO: use test infrastructure for templar
    vault_secrets = VaultLib({})
    play_context = PlayContext(vault_password='dummy')
    templar = Templar(loader=None, variables={}, vault_secrets=vault_secrets,
                      fail_on_undefined=False)

    # Convert a string to a list
    terms = listify_lookup_plugin_terms("dummy", templar, loader=None)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert terms[0] == 'dummy'

    # Convert a list to a list
    terms = listify_lookup

# Generated at 2022-06-23 14:19:06.584539
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.parsing.dataloader
    import ansible.vars.templar

    loader = ansible.parsing.dataloader.DataLoader()
    t = ansible.vars.templar.Templar(loader=loader)

    results = listify_lookup_plugin_terms('foo bar', t, loader)
    assert isinstance(results, list)
    assert results[0] == 'foo'
    assert results[1] == 'bar'

    results = listify_lookup_plugin_terms(['foo', 'bar'], t, loader)
    assert isinstance(results, list)
    assert results[0] == 'foo'
    assert results[1] == 'bar'

    results = listify_lookup_plugin_terms(['foo bar'], t, loader)

# Generated at 2022-06-23 14:19:11.628997
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections import Mapping
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import text_type
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from units.mock.loader import DictDataLoader
    from units.mock.lookup_plugin import MockLookupModule

    loader = DictDataLoader({})

    vars_manager = VariableManager()

# Generated at 2022-06-23 14:19:22.477083
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = { 'test': { 'vars': {'my_var': 'test_var'} } }


# Generated at 2022-06-23 14:19:31.145505
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    import pytest

    display = Display()
    loader = DataLoader()
    options = dict()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    role_definition = RoleDefinition.load(dict(name='test_role'), None, {}, display, variable_manager, loader)
    block = Block(role_definition)

# Generated at 2022-06-23 14:19:43.183763
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import jinja2
    from ansible.template import Templar


# Generated at 2022-06-23 14:19:51.897419
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms(terms="foo", templar=templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(terms=["foo", "bar"], templar=templar, loader=None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms=AnsibleBaseYAMLObject("foo"), templar=templar, loader=None) == ['foo']

# Generated at 2022-06-23 14:20:03.556048
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.vars.manager import VariableManager

    var_manager = VariableManager()
    var_manager.set_available_variables({'testvar1': 'testval1', 'testvar3': 'testval3'})

    empty_test_templar = DummyTemplar(fail_on_undefined=True, convert_bare=False, variables=var_manager)
    empty_test_loader = DummyLoader()

    templar = DummyTemplar(fail_on_undefined=True, convert_bare=False, variables=var_manager)

    # test string
    result = listify_lookup_plugin_terms('{{ testvar1 }}', templar, empty_test_loader)
    assert result == ['testval1']

    # test list
    result = list

# Generated at 2022-06-23 14:20:14.764980
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = ["a", "b"]
    templar = Templar()
    result = listify_lookup_plugin_terms(terms, templar)
    assert result == ["a", "b"]

    terms = "a, b"
    result = listify_lookup_plugin_terms(terms, templar)
    assert result == ["a", "b"]

    terms = ["a", "b", "c", "d"]
    result = listify_lookup_plugin_terms(terms, templar)
    assert result == ["a", "b", "c", "d"]

    terms = ["a b c d"]
    result = listify_lookup_plugin_terms(terms, templar)
    assert result == ["a b c d"]

# Generated at 2022-06-23 14:20:24.347392
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # test to make sure that we can listify a string
    terms = "{{ foo }}"
    templar = DummyVarsModule()
    loader = DummyLoader()
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)
    assert isinstance(result, list)
    assert result[0] == "test_value"
    assert len(result) == 1

    # test that we can listify a list
    terms = ['foo', 'bar', 'baz', '{{ test_2 }}']
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)
    assert isinstance(result, list)

# Generated at 2022-06-23 14:20:35.975922
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vm = VariableManager()
    vm.set_vars(loader=loader, hostvars=dict())

    templar = Templar(loader=loader, variables=vm)

    single_string = '{{ item1 }}'
    single_string_compiled = [u'item1']
    single_list = [u'item1']
    multi_string = '{{ item1 }},{{ item2 }},{{ item3 }}'
    multi_string_compiled = [u'item1', u'item2', u'item3']
    multi_list = [u'item1', u'item2', u'item3']

    assert listify_

# Generated at 2022-06-23 14:20:44.220196
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    def _t(terms, variables=None):
        templar = Templar(loader=loader, variables=variables)
        return listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)

    # test single string
    assert _t('one') == ['one']

    # test list

# Generated at 2022-06-23 14:20:52.289734
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = [
        '{{ item }}',
        '{{ item }}',
        '{{ item }}',
    ]

    templar = Templar(loader=None)
    out = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)
    assert out == ['{{ item }}', '{{ item }}', '{{ item }}']

    terms = '{{ item }}'
    templar = Templar(loader=None)
    out = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)
    assert out == ['{{ item }}']

    terms = 1
    templar = Templar(loader=None)
    out = listify_look

# Generated at 2022-06-23 14:21:02.251043
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    from ansible.config.manager import ConfigManager
    from ansible.template.vars import VarsModule

    mgr = ConfigManager(["/dev/null"])

    templar = Templar(loader=None, variables=VarsModule(loader=None, vault_password='dummy'),
                      shared_loader_obj=None, config=mgr)

    vault = VaultLib(['dummy'])
    templar.set_available_variables({'vault': vault})

    result = listify_lookup_plugin_terms(["{{fakevar}}", "foo", "bar", 42], templar, None)

# Generated at 2022-06-23 14:21:12.101142
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # Need a play context, although not used in the function
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()

    # Need a variable manager for templar, although not used in the function
    from ansible.vars import VariableManager
    variable_manager = VariableManager()

    templar = Templar(play_context=play_context, variable_manager=variable_manager)

    # Need a loader to load jinja2 template
    from ansible.template import Jinja2TemplateModule
    loader = Jinja2TemplateModule()

    # Test success case: a simple singleton string
    testdata = "foo"
    result = listify_lookup_plugin_terms(testdata, templar, loader)
    print("result is: " + result)


# Generated at 2022-06-23 14:21:22.655792
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables={})

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(('foo', 'bar'), templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(set(['foo', 'bar']), templar, loader) == ['foo', 'bar']

    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

# Generated at 2022-06-23 14:21:32.463163
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Imports for unit test

    from ansible.errors import AnsibleError
    from ansible.template import Templar

    from ansible.parsing.vault import VaultLib

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    from ansible.utils.vars import combine_vars
    from ansible.utils.path import unfrackpath

    from ansible.vars.manager import VariableManager
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.play_context import PlayContext

    # initialize empty class objects
    vars_manager = VariableManager()
    play_context = PlayContext()

# Generated at 2022-06-23 14:21:41.617089
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    listify_lookup_plugin_terms is a function that converts a list of strings or a string
    into a list, if the input is a string, it will convert that string into a list of terms
    or a list of a single item
    '''

    from ansible.module_utils.facts import ansible_managed
    from ansible.module_utils.facts import default_facts

    from ansible.template import Templar
    from ansible.module_utils._text import to_text

    from ansible.parsing.yaml.loader import AnsibleLoader

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_

# Generated at 2022-06-23 14:21:49.878271
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    templar = Templar(loader=DataLoader(), variables={'x':'foo'})
    assert listify_lookup_plugin_terms('{{ x }}', templar, loader=None, fail_on_undefined=True, convert_bare=False) == ['foo']
    assert listify_lookup_plugin_terms(['a', '{{ x }}'], templar, loader=None, fail_on_undefined=True, convert_bare=False) == ['a', 'foo']
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], templar, loader=None, fail_on_undefined=True, convert_bare=False) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:21:52.977234
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('a', None, None) == ['a']
    assert listify_lookup_plugin_terms(['a'], None, None) == ['a']

# Generated at 2022-06-23 14:22:02.683887
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # Double quotes
    term_list = listify_lookup_plugin_terms("a,b,c", Templar(None, None), None)
    assert term_list == ['a', 'b', 'c']

    # Single quotes
    term_list = listify_lookup_plugin_terms("'a,b,c'", Templar(None, None), None)
    assert term_list == ['a,b,c']

    # Comma separated list
    term_list = listify_lookup_plugin_terms(["a,b,c"], Templar(None, None), None)
    assert term_list == ['a', 'b', 'c']

    # Comma separated list with single quoted elements

# Generated at 2022-06-23 14:22:14.346034
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.module_utils.ansible_galaxy_local
    from ansible.template import Templar

    class FakeVarsModule(object):

        def __init__(self):
            self.data = {
                'a': 'aval',
                'b': 'bval',
                'c': 'cval',
            }

        def get_vars(self, loader, path, entities=None, include_hostvars=True, include_delegate_to=True):
            return self.data

    vars_mgr = FakeVarsModule()

    templar = Templar(loader=None, variables=vars_mgr)

    assert listify_lookup_plugin_terms(['a', 'b'], templar) == ['a', 'b']

# Generated at 2022-06-23 14:22:25.073852
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)

    # simple test
    assert listify_lookup_plugin_terms(["a", "b"], templar, loader) == ["a", "b"]

    # jinja template test
    assert listify_lookup_plugin_terms(["a", "{{b}}"], templar, loader) == ["a", "{{b}}"]
    assert listify_lookup_plugin_terms([u"a", u"{{b}}"], templar, loader) == [u"a", u"{{b}}"]

# Generated at 2022-06-23 14:22:36.932683
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class FakeVarManager:
        _fact_cache = dict()

        @staticmethod
        def get_vars(loader, path, entities):
            return dict()

        def add_fact(self, name, value):
            self._fact_cache[name] = value

        def get_facts(self):
            return self._fact_cache

    class FakeLoader:

        @staticmethod
        def get_basedir():
            return '/etc/ansible'

    class FakeLoader2(dict):
        pass

    dict1 = dict()
    dict1['name'] = 'John'
    dict1['age'] = '29'

    dict

# Generated at 2022-06-23 14:22:47.972519
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    data = """
    foo:
      bar:
        baz: waldo
    """
    loader = DataLoader()
    inv_data = loader.load_from_string(data)
    variable_manager = VariableManager(loader=loader, inventory=inv_data)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ foo.bar.baz }}', templar, loader) == ['waldo']
    assert listify_lookup_plugin_terms('{{ foo.bar.baz }}', templar, loader, False) == ['waldo']
    assert listify_lookup_plugin

# Generated at 2022-06-23 14:22:58.656294
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # result:
    # 1. Convert string to a single element list
    # 2. Ignore iterable containing a single string
    # 3. Add all elements of an iterable containing more than
    #    one element to the resulting list.
    # 4. Make a list of iterables with only one element.
    # 5. Make iterable from 'None'
    assert listify_lookup_plugin_terms('abc', None, None) == ['abc']
    assert listify_lookup_plugin_terms(['abc'], None, None) == ['abc']
    assert listify_lookup_plugin_terms(['abc', 'def'], None, None) == ['abc', 'def']
    assert listify_lookup_plugin_terms([['abc']], None, None) == ['abc']

# Generated at 2022-06-23 14:23:09.969018
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager.set_inventory(inventory)

    myvars = {'foo': 'bar'}
    variable_manager.set_vars(myvars)

    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms(terms=['a', 'b'], templar=templar, loader=loader, convert_bare=True) == ['a', 'b']
    assert listify_lookup

# Generated at 2022-06-23 14:23:20.581140
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = None
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variable_manager=variable_manager)
    templar._add_host_vars_from_inventory(variable_manager)
    templar._add_host_vars_from_files(variable_manager)

    assert listify_lookup_plugin_terms('test', templar, loader, fail_on_undefined=True, convert_bare=False) == ['test']
    assert listify_lookup_plugin_terms('test', templar, loader, fail_on_undefined=True, convert_bare=True) == ['test']

# Generated at 2022-06-23 14:23:28.728932
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms(1, templar, None) == [1]

    assert listify_lookup_plugin_terms([1], templar, None) == [1]

    assert listify_lookup_plugin_terms('1', templar, None) == ['1']

    assert listify_lookup_plugin_terms(['1'], templar, None) == ['1']

    assert listify_lookup_plugin_terms(['1', '2'], templar, None) == ['1', '2']

    assert listify_lookup_plugin_terms(['1', '2', '1'], templar, None, convert_bare=True) == [1, 2, 1]



# Generated at 2022-06-23 14:23:35.983572
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=dict(foo="alpha"))
    listified = listify_lookup_plugin_terms(terms, templar, None)

    assert( isinstance(listified, list) )
    assert( len(listified) == 1 )
    assert( listified[0] == 'alpha' )

    terms = ['{{ foo }}', '{{ bar }}']
    templar = Templar(loader=None, variables=dict(foo="alpha", bar="beta"))
    listified = listify_lookup_plugin_terms(terms, templar, None)

    assert( isinstance(listified, list) )
    assert( len(listified) == 2 )
    assert( listified[0] == 'alpha' )

# Generated at 2022-06-23 14:23:46.431124
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = [
        dict(term=['term1', 'term2'], expected=['term1', 'term2']),
        dict(term=iter(['term4', 'term5']), expected=['term4', 'term5']),
        dict(term='term6', expected=['term6']),
        dict(term='{{term7}}', expected=['term7'], var=dict(term7='term7')),
        dict(term=('term8',), expected=['term8']),
        dict(term=[], expected=[]),
    ]

    for term in terms:
        if 'var' in term:
            templar = Templar(None, None, variables=term['var'])
        else:
            templar = Templar(None, None)

# Generated at 2022-06-23 14:23:57.094502
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    class TestVars(object):
        pass

    class TestOptions(object):

        def __init__(self):
            self.vault_password = None
            self.tags = None
            self.skip_tags = None
            self.listtags = None
            self.listtasks = None
            self.listhosts = None
            self.syntax = None
            self.connection = None
            self.check = None
            self.module_path = None
            self.forks = None
            self.remote_user = None
            self.private_key_file = None
            self.ssh_common_args = None
            self

# Generated at 2022-06-23 14:24:07.327809
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar

    data = dict(
        a = 1,
        b = 2,
        c = 3,
        d = '{{a}}',
        e = ['{{b}}', '{{c}}']
    )

    loader = DictDataLoader({'/etc/ansible/hosts': ''})
    variables = VariableManager()
    variables.extra_vars = ImmutableDict(data)
    templar = Templar(loader=loader, variables=variables)

    # Test case #1: only one term, string
    terms1 = "{{a}}"
    result = listify_lookup_plugin_terms(terms1, templar, loader)

# Generated at 2022-06-23 14:24:17.794252
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    templar = {"template": lambda x, y, z: x}

    # First test with a string
    terms = "some_string"
    assert listify_lookup_plugin_terms(terms, templar, None) == terms.split()

    # Now test with a dict
    terms = {"username": "fred", "password": "flintstone"}
    assert listify_lookup_plugin_terms(terms, templar, None) == [terms]

    # Now test with a list
    terms = ["first", "second", "last"]
    assert listify_lookup_plugin_terms(terms, templar, None) == terms

    # Now test with a single item in a list
    terms = ["single"]
    assert listify_lookup_plugin_terms(terms, templar, None) == terms

# Generated at 2022-06-23 14:24:21.887284
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms('string', Templar({}, None), None) == ['string']
    assert listify_lookup_plugin_terms([1, 2, 3], Templar({}, None), None) == [1, 2, 3]

# Generated at 2022-06-23 14:24:32.230138
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.utils
    import ansible.constants as C
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Tests that basic strings are unchanged - we can't test all unicode
    # chars here, but we can test 1-2
    assert listify_lookup_plugin_terms(' ', Templar(VariableManager()), None) == [' ']
    assert listify_lookup_plugin_terms(u'\u2603', Templar(VariableManager()), None) == [u'\u2603']
    assert listify_lookup_plugin_terms(u'test1', Templar(VariableManager()), None) == [u'test1']

    # Tests that a single item list returns a single item list

# Generated at 2022-06-23 14:24:38.996376
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    vault_pass = 'dummypass'

    class VaultSecret:
        def __init__(self):
            pass

        def load(self, secret):
            return vault_pass

    class DummyVars:
        def get_vault_secrets(self):
            return [VaultSecret()]

    class Options:
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 1
            self.remote_user = 'root'


# Generated at 2022-06-23 14:24:49.453354
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # setup test objects
    host = Host(name='localhost')
    group = Group(name='all')
    group.add_host(host)
    templar = Templar(loader=None, inventory=group)

    # definition
    class VarManager:
        def __init__(self):
            self._vars = {}

        def set_variable(self, key, value):
            self._vars[key] = value

        def get_vars(self, play=None, host=None, task=None, include_hostvars=False):
            return self._vars

    var_mgr = VarManager()
    templar._available_variables = var_mgr.get_v

# Generated at 2022-06-23 14:24:59.679403
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    templar = Templar(loader=None)
    terms = 'item1 item2 item3'
    ret = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert ret == ['item1', 'item2', 'item3']

    templar = Templar(loader=None)
    terms = ['item1', 'item2', 'item3']
    ret = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert ret == ['item1', 'item2', 'item3']

    templar = Templar(loader=None)
    terms = AnsibleVault

# Generated at 2022-06-23 14:25:03.468193
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    templar = ansible.template.Templar()

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo'], listify_lookup_plugin_terms('foo', templar, None)

# Generated at 2022-06-23 14:25:11.193771
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    # Make a simple inventory with just localhost
    inventory = Inventory(VariableManager(), loader=None, host_list=[])
    inventory.add_host('localhost')
    inventory.add_group('group1')
    inventory.get_host('localhost').add_group('group1')
    inventory.add_group('group2')
    inventory.get_host('localhost').add_group('group2')

    # Instantiate the Ansible Template class
    templar = Templar(loader=None, variables=inventory.get_host('localhost').vars)

    # Run tests

    # Test with a string
    terms = listify_lookup_plugin_terms('a', templar, loader=None)

# Generated at 2022-06-23 14:25:21.135064
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert(listify_lookup_plugin_terms('foo', templar, loader) == ['foo'])
    assert(listify_lookup_plugin_terms(True, templar, loader) == [True])
    assert(listify_lookup_plugin_terms(False, templar, loader) == [False])
    assert(listify_lookup_plugin_terms('yaml', templar, loader) == ['yaml'])
    assert(listify_lookup_plugin_terms('none', templar, loader) == ['none'])

# Generated at 2022-06-23 14:25:28.605701
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # test valid usages of the function

    assert listify_lookup_plugin_terms([], None, None) == []
    assert listify_lookup_plugin_terms('', None, None) == ['']

    # test stringification and templating

    vars_dict = dict(a=1, b=2, c=3)

    assert listify_lookup_plugin_terms(vars_dict['a'], None, None) == [1]
    assert listify_lookup_plugin_terms(vars_dict['b'], None, None) == [2]
    assert listify_lookup_plugin_terms(vars_dict['c'], None, None) == [3]


# Generated at 2022-06-23 14:25:39.531001
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
   from ansible.module_utils.common.plugins import AnsiblePlugin
   from ansible.playbook.play import Play

   class TestPlugin(AnsiblePlugin):
      def __init__(self):
         self.play = Play.load(dict(name="test"), loader=self._loader, variable_manager=self._variable_manager)

   myplugin = TestPlugin()


# Generated at 2022-06-23 14:25:40.438443
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # FIXME: implement
    pass

# Generated at 2022-06-23 14:25:49.433626
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Unit test for function listify_lookup_plugin_terms
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar

    class DummyVars:
        def __init__(self, v):
            self.v = v
        def get_vars(self):
            return self.v

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = DummyVars(dict(foo='bar', baz='bar'))

    test_listify_template_string = listify_look

# Generated at 2022-06-23 14:26:00.250983
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    terms = [None, '', '1', '2']
    templar = Templar(loader=loader)

    listified_terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert listified_terms == [None, '', '1', '2']

    listified_terms = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)
    assert listified_terms == [None, '', 1, 2]

    # call with a string term
    terms = '{{ foo }}'
    foo = 'bar'

# Generated at 2022-06-23 14:26:11.005149
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import errors
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class NullVarsModule(object):

        def __init__(self):
            self.vars = dict()

    class TestLoader(object):

        def __init__(self):
            pass

        def get_basedir(self, path):
            return "/tmp"

    class TestContext(PlayContext):

        def __init__(self):
            pass

    class TestTemplar(Templar):

        def __init__(self):
            pass

    class TestVarManager(object):

        def __init__(self):
            pass

        def __getitem__(self, item):
            return None

        def all(self):
            return dict()

    dummy_loader = TestLoader()

# Generated at 2022-06-23 14:26:22.055479
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    loader = None
    templar = None
    terms = [1, 2, 3]
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == terms

    terms = '{{ [1,2,3] }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == [1, 2, 3]

    terms = '{{ [2, 3, 4] }}'
    result = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)
    assert result == [2, 3, 4]

    terms = '{{ item }}'
    result = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)

# Generated at 2022-06-23 14:26:26.143902
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms('test', templar, None) == ['test']

    assert listify_lookup_plugin_terms(['test'], templar, None) == ['test']

    assert listify_lookup_plugin_terms({
        'a': 'test1',
        'b': 'test2',
        'b': 'test3'}, templar, None) == [{
        'a': 'test1',
        'b': 'test2',
        'b': 'test3'}]

# Generated at 2022-06-23 14:26:30.766690
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    plain_text = 'test\\nvalue'

# Generated at 2022-06-23 14:26:41.216999
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from units.mock.loader import DictDataLoader
    from units.mock.lookup import LookupModule
    from units.mock.template import MockTemplate

    # Test template string that returns a list
    loader = DictDataLoader({'answer.txt': "42"})
    lookup = LookupModule()
    lookup.set_runner(DictDataLoader({}))
    templar = MockTemplate(loader=loader)
    terms = listify_lookup_plugin_terms(['{{ lookup("pipe","cat answer.txt") }}'], templar, loader)
    assert terms == ['42']

    # Test list that returns a list
    lookup = LookupModule()
    lookup.set_runner(DictDataLoader({}))
    templar = MockTemplate(loader=loader)
    terms = listify_lookup

# Generated at 2022-06-23 14:26:51.957745
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    result = listify_lookup_plugin_terms('hello', templar, None, fail_on_undefined=False)
    assert result == ['hello']

    result = listify_lookup_plugin_terms(['hello'], templar, None, fail_on_undefined=False)
    assert result == ['hello']

    result = listify_lookup_plugin_terms(['hello', 'world'], templar, None, fail_on_undefined=False)
    assert result == ['hello', 'world']


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-23 14:27:03.114626
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    AnsibleModule utils unit tests for listify_lookup_plugin_terms
    '''

    import ansible.module_utils.common as utils

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor


# Generated at 2022-06-23 14:27:13.785355
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar1 = Templar(loader=loader, shared_loader_obj=loader)
    templar2 = Templar(loader=loader, shared_loader_obj=loader)

    terms1 = ["{{ item }}", "{{ item }}"]
    terms2 = ["{{ item }} {{ item }}"]

    assert listify_lookup_plugin_terms(terms1, templar1, loader) == ["{{ item }}", "{{ item }}"]
    assert listify_lookup_plugin_terms(terms2, templar1, loader) == ["{{ item }} {{ item }}"]

    terms1 = ["{{ item }}", "{{ item }}"]
    terms2 = ["{{ item }} {{ item }}"]


# Generated at 2022-06-23 14:27:23.566366
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible import constants as C
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    templar = Templar(loader=loader, variables=variable_manager)

    # Test 1: a simple string
    result = listify_lookup_plugin_terms('hello', templar, loader)
    assert result == ['hello']
    variable_manager.extra_vars = {}

    # Test 2: a unicode string
    result = listify_lookup_plugin_terms(u'hello', templar, loader)
    assert result == ['hello']
    variable_manager.extra_vars = {}

