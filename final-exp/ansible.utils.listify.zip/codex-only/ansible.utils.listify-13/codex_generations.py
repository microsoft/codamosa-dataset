

# Generated at 2022-06-23 14:17:31.996943
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    variables = {'foo': 'bar', 'baz': ['spam', 'eggs']}
    templar = Templar(loader=DataLoader(), variables=variables)
    assert listify_lookup_plugin_terms('foo', templar, templar._loader) == ['bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, templar._loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{baz}}'], templar, templar._loader) == ['foo', 'bar', 'spam', 'eggs']

# Generated at 2022-06-23 14:17:40.237270
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    This is not a true unit test in the sense that it doesn't use the
    standard Ansible unit test framework.  Instead, this is a unit test
    that is meant to be run against a real Ansible environment (with
    a virtualenv), using the real Ansible templating and other
    mechanisms.  This is probably the most realistic way to test this
    function.

    To run this test, execute this file as follows:

    python -m test.test_lookup_plugins test_listify_lookup_plugin_terms

    If a test is failing, consider running with -v as follows:

    python -m test.test_lookup_plugins -v test_listify_lookup_plugin_terms

    """
    from ansible.module_utils.six import PY3
    from ansible.template import Templar

# Generated at 2022-06-23 14:17:40.895489
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:17:51.202801
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = None
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager.set_inventory(inventory)
    password = "vaultpass"
    vault = VaultLib(password)
    templar = Templar(loader=loader, variable_manager=variable_manager, vault_secrets=vault)

    assert listify_lookup_plugin_terms("test_template_file.txt", templar, loader) == ["test_template_file.txt"]

# Generated at 2022-06-23 14:17:58.962164
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Confirm that passing in a comma-separated list of items
    in the params causes a list to be returned.  Also confirm that
    passing in something that is not a list causes it to be returned
    as a one-item list.

    TODO: write a test for when the list items are complex objects
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=DataLoader(), variable_manager=VariableManager())

    assert listify_lookup_plugin_terms('foo,bar', templar, DataLoader(), False) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo', templar, DataLoader(), False) == ['foo']
    assert listify_lookup_plugin

# Generated at 2022-06-23 14:18:09.337801
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.vars import VariableManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = C.DEFAULT_LOADER
    variable_manager.set_available_variables(loader.get_basedir())

    templar = Templar(loader=loader, variables=variable_manager)

    # Test listifying a string
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

    # Test listifying a list of strings
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], templar, loader) == ['{{ foo }}', '{{ bar }}']

    # Test listifying a list of variables

# Generated at 2022-06-23 14:18:20.496591
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import os
    import sys

    class Loader():
        def __init__(self):
            self.paths = []

    class DummyHost():
        def __init__(self):
            self.name = 'localhost'

        def get_vars(self):
            v = {}
            v['hostvars'] = {'localhost': {}}
            return v

    loader = Loader()
    host = DummyHost()

    class TestTemplar():
        def __init__(self, host, loader):
            self._fail_on_undefined_errors = []
            self._available_variables = host.get_vars()
            self._loader = loader

        def set_available_variables(self, variables):
            self._available_variables = variables


# Generated at 2022-06-23 14:18:26.877952
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']

# Generated at 2022-06-23 14:18:36.372143
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.playbook.role.definition import RoleDefinition

    loader = 'test'
    templar = Templar(loader=loader, variables={})
    assert listify_lookup_plugin_terms('1 2 3', templar, loader) == ['1 2 3']
    assert listify_lookup_plugin_terms([1,2,3], templar, loader) == [1,2,3]
    assert listify_lookup_plugin_terms('{{ testvar }}', templar, loader) == ['{{ testvar }}']
    templar = Templar(loader=loader, variables={'testvar': 'foobar'})
    assert listify_lookup_plugin_terms('{{ testvar }}', templar, loader) == ['foobar']
    assert listify_lookup_

# Generated at 2022-06-23 14:18:43.411498
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-23 14:18:53.554461
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    terms = '{{ var1 }}'

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_nonpersistent_facts(dict(var1='one', var2='two'))

    t = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms(terms, t, loader) == ['one']

    terms = ['{{ var1 }}', '{{ var2 }}']

    assert listify_lookup_plugin_terms(terms, t, loader) == ['one', 'two']


# Generated at 2022-06-23 14:19:03.486861
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))

    assert listify_lookup_plugin_terms([u'foo', u'bar', u'baz'], templar, loader) == [u'foo', u'bar', u'baz']
   

# Generated at 2022-06-23 14:19:14.412646
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(loader.load_from_file('tests/vars/complex.yml')))

    templar = Templar(loader=loader, variable_manager=variable_manager)

    # string test
    assert listify_lookup_plugin_terms('foo', templar, loader, fail_on_undefined=True) == ['foo']

    # list test

# Generated at 2022-06-23 14:19:24.842675
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Unit test for function listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined)

    It uses a mock class for templar.
    '''
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    class MockTemplar:
        def __init__(self):
            pass

        def template(self, data, fail_on_undefined=True, convert_bare=False):
            if isinstance(data, string_types):
                data = self.t(data, fail_on_undefined, convert_bare)

# Generated at 2022-06-23 14:19:31.444442
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.template import Templar

    from ansible.parsing.mod_args import ModuleArgsParser

    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-23 14:19:43.498926
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.unicode import to_unicode

    loader = DictDataLoader({})
    templar = Templar(loader=loader)

    # Tests for listify_lookup_plugin_terms
    assert listify_lookup_plugin_terms(u'foo', templar, loader) == [to_unicode('foo')]
    assert listify_lookup_plugin_terms(u'foo,bar', templar, loader) == [to_unicode('foo'), to_unicode('bar')]

# Generated at 2022-06-23 14:19:52.116105
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    import os

    test_dir = os.path.dirname(os.path.realpath(__file__))

    loader = DataLoader()
    variables = VariableManager()
    templar = Templar(loader, variables)
    terms = ["{{ test_var }}", "test_string", '{{ lookup("lookup_test") }}']

    res = listify_lookup_plugin_terms(terms, templar, loader, False)
    assert res == ['bar', 'test_string', 'hello world'], res

    res = listify_lookup_plugin_terms('{{ item }}', templar, loader, False, True)

# Generated at 2022-06-23 14:20:03.685640
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template.safe_eval import ANSIBLE_TEST_DATA_ROOT
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import os
    import json

    yaml_loader = AnsibleLoader(None, yaml_dumper=AnsibleDumper)
    with open(os.path.join(ANSIBLE_TEST_DATA_ROOT, 'lookup_plugin_terms.yaml')) as f:
        data = yaml_loader.load(f)

    for t in data:
        j_terms = json.dumps(t['terms'])
        terms = listify_lookup

# Generated at 2022-06-23 14:20:15.159961
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    lookup_plugin_class = lookup_loader.get('file')
    lookup_plugin = lookup_plugin_class()

    templar = Templar(loader=lookup_plugin._loader)

    assert(listify_lookup_plugin_terms(['a', 'b', 'c'], templar) == ['a', 'b', 'c'])
    assert(listify_lookup_plugin_terms('a', templar) == ['a'])
    assert(listify_lookup_plugin_terms(['a', 'b', None, 'c'], templar) == ['a', 'b', None, 'c'])

# Generated at 2022-06-23 14:20:24.622447
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader, fail_on_undefined=True) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', templar, loader, fail_on_undefined=True) == ['foo bar']

# Generated at 2022-06-23 14:20:36.234680
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    t = Templar(pc)

    # test string expansion
    assert listify_lookup_plugin_terms('{{ "foo" }}', t, None) == ['foo']
    assert listify_lookup_plugin_terms('{{ "foo" }}', t, None, convert_bare=True) == ['foo']

    # test unicode expansion
    assert listify_lookup_plugin_terms(u'{{ "foo" }}', t, None) == [u'foo']
    assert listify_lookup_plugin_terms(u'{{ "foo" }}', t, None, convert_bare=True) == [u'foo']

    # test bare string expansion

# Generated at 2022-06-23 14:20:47.109188
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar

    facts = dict(a=1, b='foo', c=False)
    templar = Templar(loader=None, variables=facts)

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader=None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo', templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', templar, loader=None) == ['foo bar']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader=None) == ['foo,bar']

# Generated at 2022-06-23 14:20:48.246507
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:20:58.205175
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    templar = Templar(variables={}, loader=DataLoader())
    terms = listify_lookup_plugin_terms([1,2,3], templar, loader=None)
    assert terms == [1,2,3]
    terms = listify_lookup_plugin_terms(1, templar, loader=None)
    assert terms == [1]
    terms = listify_lookup_plugin_terms(['1','2'], templar, loader=None)
    assert terms == ['1','2']
    terms = listify_lookup_plugin_terms('5', templar, loader=None)
    assert terms == ['5']
    terms = list

# Generated at 2022-06-23 14:21:06.738786
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Empty terms
    assert listify_lookup_plugin_terms(None, None, None) == []

    # Bare string with spaces
    assert listify_lookup_plugin_terms("a b c", None, None) == ['a', 'b', 'c']

    # Quoted string with spaces
    assert listify_lookup_plugin_terms("\"a b c\"", None, None) == ['a b c']

    # List
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], None, None) == ['a', 'b', 'c']

    # List with spaces
    assert listify_lookup_plugin_terms(['a', 'b c', 'd'], None, None) == ['a', 'b c', 'd']

    # List with quoted string with spaces
    assert list

# Generated at 2022-06-23 14:21:12.749144
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.module_utils._text import to_bytes

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar

    TestTemplar = namedtuple('TestTemplar', ['vars'])

    def _template(*args, **kwargs):
        # return ascii(args[0]).encode('utf-8')
        if PY3:
            # Python3 always returns unicode
            return to_bytes(ascii(args[0]))

# Generated at 2022-06-23 14:21:19.784682
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.parsing.yaml.objects
    from ansible.template import Templar

    loader = None
    templar = Templar(loader=loader, variables={'a': 1, 'b': 'value', 'c': False})

    terms = '{{a}}'
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(results, list) and len(results) == 1 and results[0] == 1

    terms = ['{{a}}', 'value']
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(results, list) and len(results) == 2 and results[0] == 1 and results[1] == 'value'

    terms = ['{{b}}', 'default']
    results = listify_look

# Generated at 2022-06-23 14:21:27.496597
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    test_cases = [
        # test case 0
        # the following values should all be made into a list containing a single string and the first element expanded
        dict(terms='{{value}}', value='foo', result=['foo']),
        dict(terms=('{{value}}',), value='foo', result=['foo']),
        # test case 1
        # the following values should be expanded and the result should be a string
        dict(terms='{{value}}', value=['foo'], result=['[u\'foo\']']),
        dict(terms=('{{value}}',), value=['foo'], result=['[u\'foo\']']),
    ]

    loader = DataLoader()

# Generated at 2022-06-23 14:21:37.839187
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    from ansible.parsing.dataloader import DataLoader

    class FakeVarsModule:
        def __init__(self):
            self.search_paths = []
        def add_directory(self, dir):
            self.search_paths.append(dir)

    class TestTemplar(ansible.template.Templar):
        def __init__(self, loader, variables):
            self._available_variables = variables

    loader = DataLoader()
    vars_mgr = FakeVarsModule()
    templar = TestTemplar(loader=loader, variables=vars_mgr)

    assert not listify_lookup_plugin_terms(None, templar, loader)

# Generated at 2022-06-23 14:21:47.814081
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Import the required modules
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.template import Templar

    # Create the loader, inventory and variable manager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)

    # Create the template and listify_lookup_plugin_terms function
    templar = Templar(loader=loader, variables=variable_manager)
    llpt = listify_lookup_plugin_terms

    # Create the test variables

# Generated at 2022-06-23 14:21:58.328424
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.playbook
    from ansible.template import Templar

    playbook = ansible.playbook.PlayBook(loader=ansible.cli.cli.CLI.load, variable_manager=ansible.cli.cli.CLI.variable_manager, runner_callbacks=None)
    variable_manager = playbook.get_variable_manager()
    variable_manager.extra_vars = {'my_list' : ['a', 'b', 'c']}
    templar = Templar(loader=playbook._loader, variables=variable_manager.get_vars(play=None, include_hostvars=True))

    assert set(listify_lookup_plugin_terms('{{ my_list }}', templar, playbook._loader)) == set(['a', 'b', 'c'])

# Generated at 2022-06-23 14:21:59.637996
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    listify_lookup_plugin_terms(terms=['item1', 1, '2'], templar=None)

# Generated at 2022-06-23 14:22:01.629018
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert listify_lookup_plugin_terms(['1', '2', '3'], Templar(loader=None), None) == ['1', '2', '3']
    assert listify_lookup_plugin_terms('1', Templar(loader=None), None) == ['1']

# Generated at 2022-06-23 14:22:13.156342
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variable_manager=variable_manager)

    # Basic test
    terms = listify_lookup_plugin_terms(["1", "2", "3"], templar, loader)
    assert terms ==  ['1', '2', '3']

    # Test with a string
    terms = listify_lookup_plugin_terms("1", templar, loader)
    assert terms ==  ['1']

    # Test with a dict containing a dict

# Generated at 2022-06-23 14:22:21.314500
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        hostvars=dict(
            testhost=dict(
                ansible_facts=dict(
                    os_family='RedHat',
                    distribution='CentOS',
                    distribution_version='7.1.1503'
                )
            )
        )
    )


# Generated at 2022-06-23 14:22:32.699182
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    mock_loader = object()
    variable_manager = VariableManager()
    inventory = Inventory(loader=mock_loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    play_context = Play().set_loader(mock_loader)
    templar = Templar(loader=mock_loader, variables=variable_manager, play_context=play_context)


# Generated at 2022-06-23 14:22:42.645416
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    test_string_1 = 'a, b'
    test_string_2 = '''
        a, b
    '''
    test_string_3 = '''
        a, b
    '''

    terms_1 = listify_lookup_plugin_terms(test_string_1, templar, loader)
    terms_2 = listify_lookup_plugin_terms(test_string_2, templar, loader)
    terms_3 = listify_lookup_plugin_terms(test_string_2, templar, loader)

    assert terms_1 == ['a', 'b']

# Generated at 2022-06-23 14:22:53.060955
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert( listify_lookup_plugin_terms("string", None, None) == [ "string" ] )
    assert( listify_lookup_plugin_terms( [ "string" ], None, None) == [ "string" ] )
    assert( listify_lookup_plugin_terms( "string, string2", None, None) == [ "string", "string2" ] )
    assert( listify_lookup_plugin_terms([ "string", "string2" ], None, None) == [ "string", "string2" ] )
    assert( listify_lookup_plugin_terms([ "string", "string2" ], None, None, convert_bare=True) == [ "string", "string2" ] )

# Generated at 2022-06-23 14:23:03.363177
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.utils.vars import merge_hash

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'username': 'Joe'}
    variable_manager.set_inventory(loader.load_from_file('tests/inventory_vars.yml'))
    myvars = {}
    myvars = merge_hash(variable_manager.get_vars(play=variable_manager.get_vars(play=dict(play_hosts=['localhost']))), myvars)
    templar = Templar(loader=loader, variables=myvars)

    # Test a string is converted to a

# Generated at 2022-06-23 14:23:13.383211
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Basic usage
    results = listify_lookup_plugin_terms([1, 2, 3], templar=None, loader=None)
    assert results == [1, 2, 3]

    # Basic usage with a list
    results = listify_lookup_plugin_terms(1, templar=None, loader=None)
    assert results == [1]

    # Basic usage with an AnsibleUnsafeText type
    results = listify_lookup_plugin_terms(AnsibleUnsafeText(u'foobar'), templar=None, loader=None)
    assert results == [AnsibleUnsafeText(u'foobar')]



# Generated at 2022-06-23 14:23:23.469432
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test a string input.
    # When convert_bare=False, the string is not split.
    assert listify_lookup_plugin_terms('foo', templar, loader, convert_bare=False) == ['foo']
    # When convert_bare=True, the string is split into a list.
    assert listify_lookup_plugin_terms('foo', templar, loader, convert_bare=True) == ['foo']

    # Test a non-iterable input.
    assert listify_lookup_plugin_terms(object(), templar, loader) == [object()]

    # Test an iterable input.
    # When convert

# Generated at 2022-06-23 14:23:34.731342
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class Options(object):
        _boolean = ['f', 'x']
        f = False
        x = True

    class TestVars(object):
        a = '1'
        b = '2'
        c = 3
        d = 4
        e = {'f': 5}
        g = '{{ d + e.f }}'
        h = '{{ a }}/{{ b }}'
        i = [1, 2]
        j = ['{{ a }}', '{{ b }}']
        k = '{{ a + b }}'
        l = '{{ a }}{{ b }}'
        m = '{{ a }}/{{ x }}'
        n = '{{ a }}/{{ f }}'
        o = '{{ a }}/{{ false }}'

# Generated at 2022-06-23 14:23:39.333212
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    class args(object):
        _ansible_no_log = False
        _ansible_verbosity = 0
        module_name = ''
    gi = dict()
    a = dict()

    def get_basedir(self, vars):
        return '/'

    args.connection = None
    args.playbook_dir = None
    templar = Templar(loader=None, variables=VariableManager(loader=None), fail_on_undefined=True)

    # native types
    templar.set

# Generated at 2022-06-23 14:23:48.033588
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    terms = "{{foo}}"
    templar = Templar(variables=VariableManager(), vault_secrets=[VaultLib()])

    result = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=False)
    assert isinstance(result, list)
    assert result == ["{{foo}}"]

    templar._available_variables = MutableMapping(dict(foo='bar'))
    result = listify_lookup_plugin_terms(terms, templar)
    assert isinstance(result, list)
    assert result

# Generated at 2022-06-23 14:23:57.665451
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    listify_lookup_plugin_terms function tests
    '''

    import os
    import sys
    import tempfile
    from ansible.template import Templar

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    vault_secrets_file = os.path.expanduser("~/.vault_pass.txt")

    vault_pass = None

# Generated at 2022-06-23 14:24:07.874621
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    terms = '{{var1}}'
    var1 = '{{var2}}'
    var2 = 'a_string'

    assert(listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False) == var2)

    terms = ['{{var1}}']
    var1 = ['{{var2}}']
    var2 = 'a_string'

    assert(listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False) == var2)

    terms = '{{var1}}'


# Generated at 2022-06-23 14:24:18.083603
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class FakeTemplar(object):
        def template(self, terms, **kwargs):
            return terms

    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = FakeTemplar()
    result = listify_lookup_plugin_terms('foo', templar, None)
    assert isinstance(result, list)
    assert result == ['foo']
    result = listify_lookup_plugin_terms(['foo','bar'], templar, None)
    assert isinstance(result, list)
    assert result == ['foo', 'bar']
    result = listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, None)
    assert isinstance(result, list)
    assert result == ['foo']

# Generated at 2022-06-23 14:24:29.361567
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    templar = Templar(loader=loader, variables=VariableManager())

    # Test 1: string
    terms = "string"
    expected_result = ["string"]
    assert (listify_lookup_plugin_terms(terms, templar, loader) == expected_result)

    # Test 2: array of strings
    terms = ["string", "string2"]
    expected_result = ["string", "string2"]

# Generated at 2022-06-23 14:24:35.720953
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.template import Templar
    from ansible.playbook import Playbook
    from ansible.utils.display import Display

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(Inventory(loader, variable_manager))
    display = Display()

    # create a fake playbook class, we need to set the host and the templar
    # we don't use the real playbook since it is complex, and the host is
    # what we need to set the templar on, which is what we use to
    # template the terms, so we replace the rest of the playbook
    # inheritance with a simple object

# Generated at 2022-06-23 14:24:47.426741
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(
        a_fact='value'
    ))

    templar = Templar(loader=None, variables=variable_manager)

    result = listify_lookup_plugin_terms('{{a_fact}}', templar, loader)
    assert isinstance(result, list)
    assert result == ['value']

    result = listify_lookup_plugin_terms(['a', '{{a_fact}}'], templar, loader)
    assert isinstance(result, list)
    assert result == ['a', 'value']

    result = listify_lookup_plugin_terms(['a', 'b'], templar, loader)

# Generated at 2022-06-23 14:24:55.707423
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    all_cases = (
        ({'lookup_options': {'fail_on_undefined': False}}, [('{{undefined_var}}', ''), ('', ''), ('foo', 'foo'),
                                                            (['', 'foo', '{{undefined_var}}'], ['', 'foo', '']),
                                                            (['', 'foo', '{{undefined_var}}'], ['', 'foo', ''])]),
        ({'lookup_options': {'fail_on_undefined': True}}, [('{{undefined_var}}', 'UNDEFINED!')])
    )

    def template(terms, fail_on_undefined=False):
        templar = Templar(loader=None, variables={}, fail_on_undefined=fail_on_undefined)


# Generated at 2022-06-23 14:25:02.014350
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    my_loader = None
    my_variable_manager = None
    my_host = None
    my_args = dict(convert_bare=False, fail_on_undefined=True)
    my_templar = Templar(loader=my_loader, variables=my_variable_manager, host=my_host, **my_args)
    my_terms = ['a', 'b', 'c', 'd']
    my_terms_dic

# Generated at 2022-06-23 14:25:09.623900
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    from ansible.utils.vars import combine_vars

    class IntentionallyBrokenVarsModule(object):
        def get_vars(self, loader, path, entities, cache=True):
            return {'omg': '{{ omg }}'}

    # test fail_on_undefined true
    args = {'terms': '{{ omg }}', 'fail_on_undefined': True}
    templar = Templar(loader=None, shared_loader_obj=None, variables={})

    result = listify_lookup_plugin_terms(**args)
    assert result == ['{{ omg }}']

    result = templar.template('{{ omg }}')
    assert result == '{{ omg }}'


# Generated at 2022-06-23 14:25:19.364350
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class _DummyTemplar(object):
        def template(self, data, fail_on_undefined=True, convert_bare=False):
            return data

    templar = _DummyTemplar()

    assert listify_lookup_plugin_terms([1, 2, 3], templar, None) == [1, 2, 3]
    assert listify_lookup_plugin_terms([1, 2, 3], templar, None, fail_on_undefined=False) == [1, 2, 3]
    assert listify_lookup_plugin_terms(["{{foo}}", "{{bar}}"], templar, None, fail_on_undefined=False) == ["{{foo}}", "{{bar}}"]

# Generated at 2022-06-23 14:25:20.258841
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # tests are located where function is defined
    pass

# Generated at 2022-06-23 14:25:28.007941
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.play import Play

    loader = DataLoader()
    hosts = InventoryManager(loader=loader, sources='localhost,')
    play_context = dict(
        loader=loader,
        variable_manager=VariableManager(loader=loader, inventory=hosts),
        connection_users={},
        become_passwords={},
        passwords={},
    )

    # Empty terms
    terms = ''

# Generated at 2022-06-23 14:25:36.109071
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-23 14:25:45.961407
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Verify that listify_lookup_plugin_terms() correctly converts a string
    to a list containing that string and converts any variables in that
    string to their value.  Also verify that it correctly converts a value
    that is already a list
    '''

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vars = dict(a_value='a_string')
    templar = Templar(loader=None, variables=vars)
    terms = '{{ a_value }}'
    results = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert results == ['a_string']

    terms = ['a_list', '{{ a_value }}']
    results = listify_lookup_plugin

# Generated at 2022-06-23 14:25:56.618631
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class TestVarsModule:
        def get_vars(self, loader, path, entities, cache=True):
            if isinstance(entities, string_types):
                entities = [entities]
            return dict(zip(entities, range(len(entities))))

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader


# Generated at 2022-06-23 14:26:05.207838
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-23 14:26:15.221230
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = '{{ [ "a", "b" ] }}'
    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == [ "a", "b" ]

    terms = "{% if True %}a{% else %}b{% endif %}"
    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == [ "a" ]

    terms = [1,2,3]
    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == [ 1, 2, 3 ]

    terms = "{{ 'ab' }}"
    tem

# Generated at 2022-06-23 14:26:27.910084
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test with bare strings
    assert listify_lookup_plugin_terms('a', None, None) == ['a']
    assert listify_lookup_plugin_terms(['a'], None, None) == ['a']
    assert listify_lookup_plugin_terms('a,b', None, None) == ['a,b']

    # test with templated strings
    assert listify_lookup_plugin_terms('{{ a }}', {'a': 'b'}, None, convert_bare=True) == ['b']

    # test with bare lists
    assert listify_lookup_plugin_terms(['a,b'], None, None) == ['a,b']
    assert listify_lookup_plugin_terms(['a,b', 'c'], None, None) == ['a,b', 'c']



# Generated at 2022-06-23 14:26:39.869012
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_native
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Using the context/variables set up in this test will hopefully
    # allow us to catch other changes in how these are handled in the future
    pc = PlayContext()
    vm = VariableManager()
    pc.variable_manager = vm
    pc.variable_manager.extra_vars = {'item': "red"}
    templar = Templar(loader=None, variables=vm, shared_loader_obj=None, playcontext=pc)

    # Test a single term
    terms = "blue"
    listified = listify_lookup_plugin_terms(terms, templar, loader=None)

# Generated at 2022-06-23 14:26:51.745893
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import BytesIO
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    def get_loader():
        data = {"password": AnsibleVaultEncryptedUnicode("hello")}
        return AnsibleLoader(data, file_name=BytesIO())

    terms = u"  - foo  - bar \t- baz\n\n-qux"
    data = []
    templar = Templar(loader=get_loader())
    results = listify_lookup_plugin_terms(terms, templar, data)
    assert type(results) is list

# Generated at 2022-06-23 14:27:02.868753
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.templating import Templar, template

    templar = Templar()
    test_data = [
        {'input': 'value1\nvalue2',
         'expected_output': ['value1', 'value2']},
        {'input': 'value1\nvalue2',
         'expected_output': ['value1', 'value2']},
        {'input': ['value1', 'value2'],
         'expected_output': ['value1', 'value2']}
    ]

    for test in test_data:
        result = listify_lookup_plugin_terms(test['input'], templar, False, False)
        assert result == test['expected_output'], \
            "Expected result '%s' got '%s'" % (test['expected_output'], result)

# Generated at 2022-06-23 14:27:13.563226
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    result = listify_lookup_plugin_terms([1, 2, 3], templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert result == [1, 2, 3]

    result = listify_lookup_plugin_terms(1, templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert result == [1]

    result = listify_lookup_plugin_terms("1", templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert result == ['1']


# Generated at 2022-06-23 14:27:23.567094
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    templar = Templar(None, vault_secrets=[], loader=None)

    assert listify_lookup_plugin_terms('foo', templar, None, convert_bare=True) == ['foo']
    assert listify_lookup_plugin_terms('foo', templar, None, convert_bare=False) == ['foo']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None, convert_bare=True) == ['foo']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None, convert_bare=False) == ['foo']
    assert list