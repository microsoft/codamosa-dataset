

# Generated at 2022-06-23 14:17:34.279224
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={
        'groups': {'foo': ['a','b','c']},
        'hostvars': {'host': {'ansible_ssh_host': 'localhost'}}
    })

    assert listify_lookup_plugin_terms([1,2,3], templar, None) == [1,2,3]
    assert listify_lookup_plugin_terms(1, templar, None) == [1]
    assert listify_lookup_plugin_terms('{{foo}}', templar, None) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms('{{foo}}', templar, None, convert_bare=True) == ['a,b,c']
    assert listify

# Generated at 2022-06-23 14:17:44.967360
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test imports
    from ansible import constants as C
    from ansible.template import Templar

    # Test setup
    basedir = './lib/ansible/plugins/lookup/'
    loader = DictDataLoader({basedir: dict()})
    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        'my_var': 'my_value',
        'my_list': [
            'item_one',
            'item_two',
        ],
    }
    templar = Templar(loader=loader, variables=variable_manager)

    # Mock "ansible-doc"

# Generated at 2022-06-23 14:17:55.013691
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    try:
        import ansible.compat.tests.mock as mock
    except ImportError:
        import mock

    from ansible.template import Templar

    # Basic type handling
    assert listify_lookup_plugin_terms(42, None, None) == [42]

    # Templating
    assert listify_lookup_plugin_terms('{{ foo }}', Templar({}, {'bar': 'baz'}), None) == ['baz']

    # Templating with undefined variables
    assert listify_lookup_plugin_terms('{{ foo }} {{ bar }}', Templar({}, {}), None, fail_on_undefined=False) == ['', '']

# Generated at 2022-06-23 14:18:06.509500
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader))
    variable_manager.extra_vars = {'testvar1': 'testval1', 'testvar2': 'testval2'}
    variable_manager.options_vars = {'optionvar1': 'optionval1'}
    templar = Templar(loader=loader, variable_manager=variable_manager)
    assert listify_lookup_plugin_terms('', templar, loader) == ['""']
    assert listify_lookup_plugin_terms('"foo"', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms

# Generated at 2022-06-23 14:18:17.893770
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    string_inputs = [
        ('abc', ['abc']),
        ('abc def', ['abc def']),
        ('abc', ['abc']),
        ('abc def', ['abc def']),
        ('{{ va }}', ['{{ va }}']),
        ('{{ va }} {{ vb }}', ['{{ va }} {{ vb }}']),
        ('{{ va }}', ['{{ va }}']),
        ('{{ va }} {{ vb }}', ['{{ va }} {{ vb }}']),
    ]

    for (input, output) in string_inputs:
        assert output == listify_lookup_plugin_terms(input, None, None)


# Generated at 2022-06-23 14:18:24.833540
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    
    from ansible.module_utils.common._collections_compat import Sequence
    
    from ansible.template import Templar

    terms = [ 1, 2, 3 ]
    t = Templar(loader=None)
    assert isinstance(terms, Iterable) and isinstance(terms, Sequence)
    # Test original sequence
    assert listify_lookup_plugin_terms(terms, t, None) == [ 1, 2, 3 ]
    
    # Test a string
    assert listify_lookup_plugin_terms('6', t, None) == [6]
    # Test a string list
    assert listify_lookup_plugin_terms("[4,5,6]", t, None) == [4,5,6]
    # Test a string with a templated value
    assert listify_lookup_plugin_terms

# Generated at 2022-06-23 14:18:34.392913
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.templar import Templar
    from ansible.template import Jinja2Template
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader(), shared_loader_obj=Jinja2Template)

    # test for simple string
    terms = 'value'
    expected = ['value']
    result = listify_lookup_plugin_terms(terms, templar, templar._loader, fail_on_undefined=True, convert_bare=False)
    assert result == expected

    # test for simple list
    terms = ['value1', 'value2']
    expected = ['value1', 'value2']

# Generated at 2022-06-23 14:18:44.567086
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import loader as plugin_loader

    loader = DataLoader()
    vault_secrets = VaultLib(password_files=[loader.find_file("foo")], vars=[{'secret': 'password'}])
    templar = Templar(loader=loader, vault_secrets=vault_secrets)

    # Test that a string template is converted to terms
    terms = '{{ foo }}'
    terms_res = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms_res, list)
    assert terms_res == ['{{ foo }}']

    # Test that a list of string templates

# Generated at 2022-06-23 14:18:55.211382
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # AnsibleOptions includes the AnsibleOptions() class.
    # The constructor for AnsibleOptions() also includes a call
    # to 'process_common_args' which sets up the self.module_vars
    # value.  The self.module_vars value gets passed to the
    # templar when it gets created.
    from ansible.cli.playbook import PlaybookCLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    cli = PlaybookCLI(['playbook.yml'])
    cli.parse()

# Generated at 2022-06-23 14:19:00.895588
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import jinja2

    template_data = '''
    {% set myvar = ['this','that','another','last'] %}
    {{ myvar }}
    '''

    expected_results = ['this','that','another','last']

    loader = DataLoader()
    env = jinja2.Environment(undefined=jinja2.StrictUndefined)
    templar = Templar(loader=loader, variables={}, environment=env)
    new_terms = listify_lookup_plugin_terms(template_data, templar, loader, fail_on_undefined=True, convert_bare=False)

    assert new_terms == expected_results


# Generated at 2022-06-23 14:19:11.380131
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.plugins import lookup_loader

    assert listify_lookup_plugin_terms(1, Templar(loader=lookup_loader)) == [1]
    assert listify_lookup_plugin_terms(1, Templar(loader=lookup_loader), fail_on_undefined=False) == [1]
    assert listify_lookup_plugin_terms('1', Templar(loader=lookup_loader)) == ['1']
    assert listify_lookup_plugin_terms(['1'], Templar(loader=lookup_loader)) == ['1']
    assert listify_lookup_plugin_terms([1], Templar(loader=lookup_loader)) == [1]

# Generated at 2022-06-23 14:19:21.344698
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    v = VaultLib('asdf')
    t = Templar(loader=None, variables=dict(a=3), shared_loader_obj=True, vault_secrets=v)

    assert listify_lookup_plugin_terms('a', t, None) == ['a']
    assert listify_lookup_plugin_terms([1,'b',2], t, None) == [1,'b',2]
    assert listify_lookup_plugin_terms('{{a}}', t, None) == [3]
    assert listify_lookup_plugin_terms(5, t, None) == [5]

# Generated at 2022-06-23 14:19:30.137182
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Simulate running lookup module, with possible settings for
    terms, as a string or a list.  Verify that correct result is
    returned everytime, which should always be list.

    :return:
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()

# Generated at 2022-06-23 14:19:37.068293
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    def check_equal(terms, result):
        class FakeLoader(object):
            pass
        class FakeTemplar(object):
            def template(self, value, fail_on_undefined=True, convert_bare=False):
                r = value
                if isinstance(r, string_types):
                    r = self.split_args(value)
                return r
        fake_loader = FakeLoader()
        fake_templar = FakeTemplar()
        assert listify_lookup_plugin_terms(terms, fake_templar, fake_loader) == result

    check_equal("{{ lookup('pipe', 'echo test') }}", ['test'])
    check_equal("{{ lookup('pipe', 'echo test') }}|{{ lookup('pipe', 'echo test1') }}", ['test', 'test1'])
    check_

# Generated at 2022-06-23 14:19:47.310882
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class FakeVarsModule(object):
        def get_vars(self, loader, play, host=None, task=None):
            if play.vars:
                value = play.vars.get(var_name, None)
                if value is None:
                    value = host.get_vars().get(var_name, None)
            else:
                value = host.get_vars().get(var_name, None)
            return value

    class FakePlay(object):
        def __init__(self):
            self.vars = None

    class FakeHost(object):
        def __init__(self):
            self.vars = None

# Generated at 2022-06-23 14:19:54.054447
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.mod_args import ModuleArgsParser

    # Disable warning about connection/etc. plugins
    from ansible.constants import DEFAULT_HASH_BEHAVIOUR, HASH_BEHAVIOUR, DEFAULT_KEEP_REMOTE_FILES
    from ansible import context

    context.CLIARGS = {}
    for k in ('connection', 'module_compression', 'remote_tmp', 'module_lang', 'module_set_locale','become_method', 'module_path', 'forks', 'become_user', 'check'):
        context.CLIARGS[k] = None
    context.CLIARGS['diff'] = False
    context.CLIARGS['hash_behaviour'] = DEFAULT_HASH_BEHAVIOUR

# Generated at 2022-06-23 14:20:04.652114
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext

    terms = [
        AnsibleUnicode('{{ foo }}{{ bar }}'),
        AnsibleUnicode('{{ foo }}'),
        AnsibleUnicode('{{ bar }}'),
        AnsibleUnicode('foo')
    ]
    variables = dict(
        foo='a',
        bar='b',
    )
    gv = combine_vars(variables, variables)
    play_context = PlayContext()
    loader = None

# Generated at 2022-06-23 14:20:15.738167
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    mock_loader = object()
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, Templar(loader=mock_loader), mock_loader) == ['foo']
    terms = ['foo']
    assert listify_lookup_plugin_terms(terms, Templar(loader=mock_loader), mock_loader) == ['foo']
    terms = ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms, Templar(loader=mock_loader), mock_loader) == ['foo', 'bar']
    terms = ('foo', 'bar')
    assert listify_lookup_plugin_terms(terms, Templar(loader=mock_loader), mock_loader) == ['foo', 'bar']

# Generated at 2022-06-23 14:20:24.919309
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_loader = AnsibleLoader(None, None)

    # function under test
    def lupt(terms, templar, loader, fail_on_undefined=True, convert_bare=False):
        return listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=fail_on_undefined,
                                           convert_bare=convert_bare)

    templar = Templar(loader=yaml_loader)
    terms = '{{ foo }}'
    expected = ['{{ foo }}']

    result = lupt(terms, templar, yaml_loader)


# Generated at 2022-06-23 14:20:36.753166
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.template import Templar

    from ansible.parsing.vault import VaultLib

    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    loader = None
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])

    vault_password = os.environ.get('VAULT_PASS', 'ansible')

    # create a host
    groups = ['ungrouped']
    host = Host(name='somehost', groups=groups)
    inventory.add_host(host)

# Generated at 2022-06-23 14:20:44.555192
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Tests the listify_lookup_plugin_terms function
    '''
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar

    assert listify_lookup_plugin_terms('1', Templar(loader=None)) == ['1']
    assert listify_lookup_plugin_terms('1,2', Templar(loader=None)) == ['1', '2']
    assert listify_lookup_plugin_terms('1,2', Templar(loader=None), fail_on_undefined=False) == ['1,2']

    assert listify_lookup_plugin_terms(['1'], Templar(loader=None)) == ['1']
    assert listify_lookup_plugin_terms(['1', '2'], Templar(loader=None)) == ['1', '2']


# Generated at 2022-06-23 14:20:53.563634
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C

    # Patch the constants

# Generated at 2022-06-23 14:21:03.654369
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # These tests are structured to avoid import-time dependency on Ansible
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    terms_data = [
        AnsibleUnicode('var1'),
        AnsibleUnicode('{{ var2 }}'),
        AnsibleSequence([AnsibleUnicode('{{ var3 }}'), AnsibleUnicode('{{ var4 }}')]),
        AnsibleUnicode('var5'),
    ]


# Generated at 2022-06-23 14:21:12.959317
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.parsing.dataloader
    import ansible.template
    import ansible.utils.unsafe_proxy
    import ansible.vars.unsafe_proxy

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    templar = ansible.template.Templar(loader=loader, variables=variable_manager)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test bare variables

# Generated at 2022-06-23 14:21:23.570575
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.module_utils.common.collections as collections
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.template.safe_eval import SafeEval

    v = VaultLib()
    base_vars = collections.OrderedDict()
    base_vars['foo'] = 1
    base_vars['bar'] = 2
    base_vars['bat'] = 3
    base_vars['baz'] = {'abc': 1, 'def': 2, 'xyz': 3}
    base_vars['qux'] = (1, 2, 3)
    base_v

# Generated at 2022-06-23 14:21:24.310590
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    pass

# Generated at 2022-06-23 14:21:34.776773
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms('1', templar, None) == ['1']
    assert listify_lookup_plugin_terms('1,2', templar, None) == ['1','2']
    assert listify_lookup_plugin_terms('[1,2]', templar, None) == ['1','2']
    assert listify_lookup_plugin_terms('["1","2"]', templar, None) == ['1','2']
    assert listify_lookup_plugin_terms(['1','2'], templar, None) == ['1','2']
    assert listify_lookup_plugin_terms([1,2], templar, None) == [1,2]

# Generated at 2022-06-23 14:21:41.424310
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = [
        "{{ hostvars['localhost']['ec2_ami'] }}",
        "{{ hostvars['localhost']['ec2_ami'] }}"
    ]
    templar = DummyTemplar(variables={})
    loader = DummyLoader()
    ans = listify_lookup_plugin_terms(terms, templar, loader)
    assert 'ami-00000001' == ans[0]

# Class DummyTemplar for unit test

# Generated at 2022-06-23 14:21:51.778597
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    parent_vars = dict(
        foo_dict=dict(
            bar='Bar'
        ),
        foo_list=[
            123,
            456,
            789,
        ]
    )

    variable_manager = VariableManager()
    variable_manager.set_inventory(host_list=[])

    templar = Templar(loader=DataLoader(), variables=variable_manager)
    variable_manager.set_parent_vars(parent_vars)

    assert listify_lookup_plugin_terms('{{ foo_dict.bar }}', templar, None, fail_on_undefined=True, convert_bare=True) == ['Bar']
    assert list

# Generated at 2022-06-23 14:22:01.805416
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys
    import os
    import io
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from lib.lookup_plugins import LookupBase
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars

    class TestLookupModule(LookupBase):
        def __init__(self, basedir=None, **kwargs):
            self.basedir = basedir

       

# Generated at 2022-06-23 14:22:13.399062
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import loader as plugin_loader
    import pytest

    templar = Templar(loader=None, variables=VariableManager())
    terms = AnsibleUnicode('{{ foo }}')
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert terms == ['{{ foo }}']
    terms = AnsibleUnicode(u'foo')
    terms = listify_lookup_plugin_terms(terms, templar, None, convert_bare=True)

# Generated at 2022-06-23 14:22:24.908977
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager

    _play = Play.load(dict(
        name = "my play",
        hosts = "all",
        tasks = [
            dict(action=dict(
                module = 'debug',
                msg="{{ lookup('file','file_with_commas.yaml') }}"
            ))
        ]
    ), variable_manager=VariableManager(), loader=None)

    _task = _play.get_tasks()[0]

    _loader = '<test loader>'
    _variable_manager

# Generated at 2022-06-23 14:22:36.510663
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.template
    import ansible.parsing.yaml
    import ansible.vars.manager

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    variable_manager.extra_vars = {
        'myvar': "Hello World"
    }
    templar = ansible.template.Templar(loader=loader, variables=variable_manager)

    # Test with a string
    assert listify_lookup_plugin_terms("{{ myvar }}", templar, loader, fail_on_undefined=True, convert_bare=False) == ["Hello World"]
    # Test with a list

# Generated at 2022-06-23 14:22:47.971243
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class FakeVarsModule(object):
        def __init__(self, data):
            self.data = data
        def __getitem__(self, key):
            return self.data[key]

    class FakeLoaderModule(object):
        pass


# Generated at 2022-06-23 14:22:56.066397
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    vault_secret = '$ANSIBLE_VAULT;1.1;AES256\n'+\
        '32643233316336643735313262613033633534366131393537313539306337386439363562396161\n'+\
        '39366535633066306465383332663365303832643039346663396337623164356532363064336335\n'+\
        '64326565373064336139340a61396334653635383634363632623835663039376333646461377430\n'

# Generated at 2022-06-23 14:23:07.002503
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    terms = "{{ test_variable }}"
    loader.set_basedir("/")
    # Passing None as the variable manager to the Templar constructor
    # will set the variable manager to None.  This is used by unit
    # tests to allow the lookup plugins to use the HostVarsVarsManager
    # and other variable managers without having to mock an inventory
    # and variable manager instance.
    templar = Templar(loader=loader, variable_manager=None)
    new_terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert new_terms == [u"{{ test_variable }}"]

    # listify_

# Generated at 2022-06-23 14:23:14.480005
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', None, None) == ['foo bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(('foo', 'bar'), None, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms({'foo': 'bar'}, None, None) == [{'foo': 'bar'}]
    assert listify_lookup_plugin_terms(42, None, None) == [42]

# Generated at 2022-06-23 14:23:24.450725
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    template_t0 = '{{ [ "0", "1", "2" ] }}'
    template_t1 = ['3', '4', '5']
    template_t2 = ['6', '7', '8', '{{ [ "9", "10" ] }}']
    template_t3 = ['5', '7', '9', '11', '{{ [ "13", "15" ] }}']
    template_t4 = ['{{ [ "0", "2", "4" ] + [ "6", "8", "10" ] }}']


# Generated at 2022-06-23 14:23:29.069621
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = listify_lookup_plugin_terms(["a", "b", "c"], None, None)
    assert(terms == ["a", "b", "c"])
    terms = listify_lookup_plugin_terms("a, b, c", None, None)
    assert(terms == ["a", "b", "c"])
    terms = listify_lookup_plugin_terms("a, b, c", None, None, convert_bare=True)
    assert(terms == 'a, b, c')

# Generated at 2022-06-23 14:23:32.629612
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # A string should be converted to list
    assert listify_lookup_plugin_terms('uno', None, None) == ['uno']
    assert listify_lookup_plugin_terms(['uno'], None, None) == ['uno']
    assert listify_lookup_plugin_terms(('uno',), None, None) == ['uno']

    # Only string should be converted to list, not int or other
    assert listify_lookup_plugin_terms(1, None, None) == 1

# Generated at 2022-06-23 14:23:38.448423
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.mod_args import ModuleArgsParser

    dummy_data = dict(
        # common
        a=['a', 'aa', 'aaa'],
        b=dict(
            ba=['ba', 'baa', 'baaa'],
            bb=dict(
                bba=['bba', 'bbaa', 'bbaaa'],
                bbb='bbb',
            ),
            bc='bc',
        ),
        c='c',
    )

# Generated at 2022-06-23 14:23:47.597621
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    terms = listify_lookup_plugin_terms(["a", "b", "c"], templar, loader)
    assert terms == ["a", "b", "c"]

    terms = listify_lookup_plugin_terms("d e f", templar, loader)
    assert terms == ["d", "e", "f"]

    terms = listify_lookup_plugin_terms("{{ ansible_env.FOO }}", templar, loader)
    assert terms == ["{{ ansible_env.FOO }}"]


# Generated at 2022-06-23 14:23:57.615476
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)
    terms = "{{item}}"
    terms = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)

    assert isinstance(terms, list)
    assert isinstance(terms[0], string_types)
    assert terms[0] == u'{{item}}'

    terms = "{{item}}"
    terms = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=True)

    assert isinstance(terms, list)
    assert isinstance(terms[0], string_types)
    assert terms[0] == u'{{item}}'


# Generated at 2022-06-23 14:24:05.562586
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    This test is a regression test to make sure that listify_lookup_plugin_terms
    works as expected (some previous changes broke templating lookup terms).
    """
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    terms = '{{ foo }}'
    templar = Templar(loader=DataLoader())
    templar._available_variables = dict(foo=['bar', 'baz'])
    assert listify_lookup_plugin_terms(terms, templar, templar._loader) == ['bar', 'baz']

# Generated at 2022-06-23 14:24:13.796591
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Test case for string
    # Correct behaviour
    templar = Templar(loader=None)
    test_string_correct = "string_for_tests"
    result = listify_lookup_plugin_terms(test_string_correct, templar, None)
    assert test_string_correct == result[0]

    # Test case for list
    # Correct behaviour
    test_list_correct = ['a', 'b', 'c']
    result = listify_lookup_plugin_terms(test_list_correct, templar, None)
    assert test_list_correct == result

    # Error behaviour 1
    # input is not a string and not an array
    test_list_error = 100

# Generated at 2022-06-23 14:24:24.430612
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    vars_mgr = VariableManager()
    vars_mgr.set_global_vars(Reserved(vars_mgr))
    templar = Templar(loader=None, variables=vars_mgr)

    #returns a list with a string as item
    assert listify_lookup_plugin_terms('string', templar, None) == ['string']

    #returns a list with an AnsibleBaseYAMLObject as item

# Generated at 2022-06-23 14:24:30.336161
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Some of these tests assume that the templar has been initialized with a loader
    loader = None
    templar = Templar(loader=loader, variables={})
    terms = templar.template('{{ foo }}', fail_on_undefined=False)
    assert terms == '{{ foo }}'
    terms = templar.template(terms, fail_on_undefined=False)
    assert terms == '{{ foo }}'

# Generated at 2022-06-23 14:24:36.685543
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    # the jinja2 environment and its important pieces
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=C.DEFAULT_HOST_LIST)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-23 14:24:47.788670
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    # Compare our results to known good results

# Generated at 2022-06-23 14:24:55.948528
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import TemplateVars
    from ansible.template import Templar


# Generated at 2022-06-23 14:25:03.923473
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = '{{ lookup_list }}'
    lookup_list = ['1', '2', '3']
    templar = Templar(loader=None, variables={'lookup_list': lookup_list})
    ret = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=True, convert_bare=False)

    assert ret == lookup_list

    terms = terms = '{{ lookup_list }}'
    lookup_list = '4'
    templar = Templar(loader=None, variables={'lookup_list': lookup_list})
    ret = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=True, convert_bare=False)

    assert ret == [lookup_list]

# Generated at 2022-06-23 14:25:13.732171
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class MockTemplar():
        def template(self, data, fail_on_undefined=True):
            return data

    class MockLoader():
        pass

    templar = MockTemplar()
    loader = MockLoader()

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo','bar'], templar, loader) == ['foo','bar']
    assert listify_lookup_plugin_terms([['foo','bar']], templar, loader) == [['foo','bar']]

    #need to add more tests
    assert -1

# Generated at 2022-06-23 14:25:24.423561
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    terms = '{{ foo }}'
    templar = Templar(loader=DataLoader(), variables=VariableManager())
    new_terms = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True)
    assert isinstance(new_terms, list)
    assert new_terms[0] == '{{ foo }}'

    templar._available_variables = dict(foo='bar')
    terms = '{{ foo }}'
    new_terms = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True)

# Generated at 2022-06-23 14:25:36.458373
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    This implements unit tests for the
    AnsibleModuleUtils.listify_lookup_plugin_terms function.
    """
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.parsing.convert_bool import boolean
    import yaml


# Generated at 2022-06-23 14:25:46.157949
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test string template
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleUndefinedVariable
    loader, inventory, variable_manager = C.get_complex_args()
    variable_manager.extra_vars = dict(foo='bar')
    templar = Templar(loader=loader, variables=variable_manager)
    terms = "{{ foo }}"

# Generated at 2022-06-23 14:25:52.792313
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common import AnsibleModule

    am = AnsibleModule(
        argument_spec = dict(
            terms = dict(type='raw', required=True),
        )
    )

    # Test basic string
    terms = "{{ foo }}"
    assert listify_lookup_plugin_terms(terms, am.environment.loader.get_basedir(""), am._templar) == [AnsibleUnsafeText("{{ foo }}")]

    # Test already-listified terms
    terms = [1,2,3]
    assert listify_lookup_plugin_terms(terms, am.environment.loader.get_basedir(""), am._templar) == terms

    # Test non-string, non-list terms
   

# Generated at 2022-06-23 14:26:01.056808
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms(None, templar) == [None]
    assert listify_lookup_plugin_terms([], templar) == []
    assert listify_lookup_plugin_terms([1,2,3], templar) == [1,2,3]
    assert listify_lookup_plugin_terms('foo', templar) == ['foo']
    assert listify_lookup_plugin_terms('', templar) == ['']

# Generated at 2022-06-23 14:26:11.305888
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    facts=dict(
        inventory_hostname='foobar'
    )

    vars_manager = VariableManager()
    vars_manager.set_fact(facts)

    templar = Templar(loader=None, variables=vars_manager)

    result = listify_lookup_plugin_terms()
    assert result is None
    result = listify_lookup_plugin_terms(None)
    assert result is None

    result = listify_lookup_plugin_terms('foo')
    assert result == ['foo']

    result = listify_lookup_plugin_terms('foo|bar')
    assert result == ['foo','bar']


# Generated at 2022-06-23 14:26:19.832414
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    vars_manager = VariableManager()
    templar = Templar(loader=None, variables=vars_manager)

    assert listify_lookup_plugin_terms("{{ lookup('env','HOME') }}", templar, None) == [os.path.expanduser("~")]
    assert listify_lookup_plugin_terms(['{{ lookup("env","HOME") }}'], templar, None) == [os.path.expanduser("~")]

# Generated at 2022-06-23 14:26:28.305013
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This is a bit of a hack, but it's the shortest route to a templar
    # object that will give us a functioning listify_lookup_plugin_terms().
    # The templar object is just not used otherwise.
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    templar = Templar(loader=None, variables={}, shared_loader_obj=None, play_context=PlayContext())

    from ansible.utils import listify_lookup_plugin_terms as tmpl

    # Test cases: (input, expected output)

# Generated at 2022-06-23 14:26:39.951914
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    # Create a vault lib that encrypts in the same manner as the command line vault tool
    vault_secret = 'test'
    vault_password_file = '/dev/null'
    vault_lib = VaultLib(vault_secrets=[vault_secret], vault_password_files=[vault_password_file])

    vault_encrypted = vault_lib.encrypt(b'foo')
    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(vault_encrypted)


# Generated at 2022-06-23 14:26:51.747271
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys
    import os
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Ansible template to test
    test_template = ["{{ a }}", "{{ a }}", {'A': '{{ a }}'}]

    # Set up the vault secret
    vault_password_file = os.path.join(os.path.dirname(__file__), "vault-password.txt")
    vault = VaultLib(vault_password_file)

    # Set up the Ansible template
    loader = DataLoader()
    loader.set_vault_secrets([('default', vault)])
    templar = Templar(loader=loader, variables=dict(a='A'))



# Generated at 2022-06-23 14:27:01.800430
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test with just a string
    assert ['foo'] == listify_lookup_plugin_terms('foo', templar=None, loader=None, fail_on_undefined=True, convert_bare=False)

    # Test with a string inside a list
    assert ['foo'] == listify_lookup_plugin_terms(['foo'], templar=None, loader=None, fail_on_undefined=True, convert_bare=False)

    # Test with two strings inside a list
    assert ['foo', 'bar'] == listify_lookup_plugin_terms(['foo', 'bar'], templar=None, loader=None, fail_on_undefined=True, convert_bare=False)

# Generated at 2022-06-23 14:27:08.971006
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Use the basic 'assert' style of unit test
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock
    import ansible.parsing.dataloader
    from ansible.plugins.loader import lookup_loader
    import ansible.vars
    from ansible.template import Templar

    class TestLookupPlugin(object):
        def __init__(self, loader, _templar=None, **kwargs):
            self._loader = loader

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self._loader = ansible.parsing.dataloader.DataLoader()
            self._templar = Templar(loader=self._loader, variables=ansible.vars.VariableManager())

       

# Generated at 2022-06-23 14:27:16.836959
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    from ansible.playbook.play_context import PlayContext
    context = PlayContext()
    from ansible.template.template import Templar
    templar = Templar(loader=loader, variables=context.available_variables)
    from ansible.template import generate_ansible_template_vars
    generate_ansible_template_vars(dict(omit='omit'))  # for test, we need to load the vars so lookup_loader.__getattr__ will work

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']


# Generated at 2022-06-23 14:27:25.689542
# Unit test for function listify_lookup_plugin_terms