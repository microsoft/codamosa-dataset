

# Generated at 2022-06-23 14:17:34.231584
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'hosts': ['host1', 'host2', 'host3']})

    # should return a list with a single string value
    terms = listify_lookup_plugin_terms('test', templar, loader=None)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert isinstance(terms[0], string_types)
    assert terms[0] == 'test'

    # should return a list with the same number of items as the original list
    terms = listify_lookup_plugin_terms(['test1', 'test2'], templar, loader=None)
    assert isinstance(terms, list)
    assert len(terms) == 2

# Generated at 2022-06-23 14:17:44.857975
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars import TemplateVars

    templar = Templar(loader=AnsibleLoader(None))
    variable_manager = VariableManager(loader=None, host_vars={}, group_vars={})

    host = Host(name="127.0.0.1")
    variable_manager.set_host_variable(host, "var1", "val1")
    variable_manager.set_host_variable(host, "var2", ["val2", "val3"])

    ret = listify_lookup_plugin_

# Generated at 2022-06-23 14:17:54.886594
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    t = Templar(loader=None, variables={'foo':'bar'})

    assert listify_lookup_plugin_terms('{{foo}}', t, None) == ['bar']
    assert listify_lookup_plugin_terms(['a', 'b'], t, None) == ['a', 'b']
    assert listify_lookup_plugin_terms(['a', 'b', ['c', 'd']], t, None) == ['a', 'b', ['c', 'd']]
    assert listify_lookup_plugin_terms('a{{foo}}', t, None) == ['abar']

# Generated at 2022-06-23 14:18:06.509541
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.unicode import to_bytes

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test use of jinja2 filter within lookup plugin
    assert listify_lookup_plugin_terms(
        to_bytes('{{ "foo, bar" | split(",") }}'), templar, loader
    ) == [to_bytes('foo'), to_bytes('bar')]

    assert listify_lookup_plugin_terms(
        to_bytes('{{ "foo" }}'), templar, loader
    ) == [to_bytes('foo')]


# Generated at 2022-06-23 14:18:17.893566
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    loader = DataLoader()
    templar = Templar(loader=loader, variables={})

    # Test 1: Test for string term
    test1 = listify_lookup_plugin_terms("test_term", templar, loader, False, True)
    assert test1 == ["test_term"]

    # Test 2: Test for list term
    test1 = listify_lookup_plugin_terms(["test_term"], templar, loader, False, True)
    assert test1 == ["test_term"]

    # Test 3: Test for unicode string term

# Generated at 2022-06-23 14:18:24.832412
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import ansible.parsing.dataloader

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()

    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ foo }}.yml', templar, loader, convert_bare=True) == ['foo'], 'failed string input'
    assert listify_lookup_plugin_terms('foo.yml', templar, loader, convert_bare=True) == ['foo'], 'failed bare string input'

# Generated at 2022-06-23 14:18:32.280647
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    # Import Ansible stubs
    from ansible.module_utils.facts.system.distribution import Distribution as AnsibleDistribution
    from ansible.module_utils.facts.system.distribution import DistributionLegacy as AnsibleDistributionLegacy
    from ansible.module_utils.facts.system.platform import Platform as AnsiblePlatform
    from ansible.module_utils.facts.system.selinux import SELinux as AnsibleSelinux
    from ansible.module_utils.facts.system import System as AnsibleSystem

# Generated at 2022-06-23 14:18:41.004069
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    t = Templar(loader=None, variables={})
    terms = ['1', '2', '3']
    val = listify_lookup_plugin_terms(terms, t, None)
    assert type(val) == list
    assert len(val) == 3
    assert type(val[0]) == AnsibleUnicode
    assert type(val[1]) == AnsibleUnicode
    assert type(val[2]) == AnsibleUnicode

    terms = '1 2 3'
    val = listify_lookup_plugin_terms(terms, t, None)
    assert type(val) == list
    assert len(val) == 3
    assert type(val[0]) == AnsibleUnicode

# Generated at 2022-06-23 14:18:50.821261
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # This is the only successful way to get a templar
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    templar = Templar(loader=DataLoader())

    assert listify_lookup_plugin_terms('{{ foo }}', templar, templar.loader) == ['{{ foo }}']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, templar.loader, convert_bare=True) == ['foo']
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], templar, templar.loader) == ['{{ foo }}', '{{ bar }}']

# Generated at 2022-06-23 14:19:01.260578
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.vars import merge_hash

    yaml_data1 = '''
    first: "{{ test_param }}"
    '''
    yaml_data2 = '''
    - "{{ test_param | from_json }}"
    '''

    m = ModuleArgsParser(yaml_data1, 'fake')
    assert m.hash == {'first': '{{ test_param }}'}

    m = ModuleArgsParser(yaml_data1, 'fake', convert_bare=True)
    assert m.hash == {'first': ''}

    m = ModuleArgsParser(yaml_data2, 'fake')

# Generated at 2022-06-23 14:19:11.416740
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template.safe_eval import safe_eval

    assert listify_lookup_plugin_terms('{{ foo }}', safe_eval, None, fail_on_undefined=True, convert_bare=False) == [{'foo': '{{ foo }}'}]
    assert listify_lookup_plugin_terms('{{ foo }}', safe_eval, None, fail_on_undefined=True, convert_bare=True) == ['{{ foo }}']
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}', '{{ bam }}'], safe_eval, None, fail_on_undefined=True, convert_bare=False) == [{'foo': '{{ foo }}'}, {'bar': '{{ bar }}'}, {'bam': '{{ bam }}'}]
    assert list

# Generated at 2022-06-23 14:19:20.731879
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class FakeLoader(object):
        def __init__(self):
            self._basedir = "/some/basedir"

    class FakeTemplar(object):
        def __init__(self):
            pass

        def template(self, terms, convert_bare=False, fail_on_undefined=True):
            return terms

    lp = FakeLoader()
    t  = FakeTemplar()
    assert listify_lookup_plugin_terms("foo", t, lp) == ['foo']
    assert listify_lookup_plugin_terms(["foo", "bar"], t, lp) == ['foo', 'bar']

# Generated at 2022-06-23 14:19:29.911112
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    templar = None
    loader = None
    # Test case: a string, no templating involved
    assert listify_lookup_plugin_terms('test', templar, loader) == ['test']
    # Test case: a list of strings, no templating involved
    assert listify_lookup_plugin_terms(['test', 'list'], templar, loader) == ['test', 'list']
    # Test case: a string, templating involved
    assert listify_lookup_plugin_terms('{{test}}', templar, loader) == ['{{test}}']
    # Test case: a list, templating involved
    assert listify_lookup_plugin_terms(['{{test}}', '{{list}}'], templar, loader) == ['{{test}}', '{{list}}']

# Generated at 2022-06-23 14:19:41.856686
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import safe_eval
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'ansible_check_mode': False}
    variable_manager.options_vars = {'ansible_check_mode': False}
    inventory = variable_manager.get_inventory()
    play_context = PlayContext()

    templar = Templar(loader=loader,
                      variables=variable_manager.get_vars(play=None, host=None),
                      fail_on_undefined=True)


# Generated at 2022-06-23 14:19:50.951422
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.template import Templar
    try:
        from test.support.loader import DictDataLoader
    except ImportError:
        from ansible.parsing.dataloader import DataLoader
        DictDataLoader = DataLoader

    loader = DictDataLoader({'a': 'foo', 'b':  '{{a}}'})
    templar = Templar(loader=loader, variables={})

    assert listify_lookup_plugin_terms('', templar, loader, fail_on_undefined=False) == ['']
    assert listify_lookup_plugin_terms('', templar, loader, fail_on_undefined=True) == ['']
    assert listify_lookup_plugin_terms('foo', templar, loader, fail_on_undefined=False) == ['foo']

# Generated at 2022-06-23 14:20:02.278497
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    class MyVaultLib(VaultLib):
        def decrypt(self, b_data, key):
            return b_data

    class MyTemplar(Templar):
        def __init__(self, loader, variables):
            self._loader = loader
            self._available_variables = variables
            self._vault = MyVaultLib()

        def template(self, data, preserve_trailing_newlines=False, convert_data=False, fail_on_undefined=True):
            return data

    assert listify_lookup_plugin_terms('foo', MyTemplar(None, None), None) == ['foo']
    assert listify_lookup

# Generated at 2022-06-23 14:20:07.691335
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import os
    import json

    loader = DataLoader()
    current_dir = os.path.dirname(__file__)

    inventory = InventoryManager(loader=loader, sources=current_dir + '/listify_lookup_plugin_terms_inventory.yml')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = { 'hello' : 'world' }

    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin

# Generated at 2022-06-23 14:20:20.328804
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    loader=DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variable_manager=variable_manager)

    ## INTMAP
    #Test non-string
    assert listify_lookup_plugin_terms(safe_eval("[1]"), templar, loader) == [1]
    #Test list
    assert listify_lookup_plugin_terms(safe_eval("[1,2,3]"), templar, loader) == [1,2,3]
    #

# Generated at 2022-06-23 14:20:30.507440
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DictDataLoader({
        "test_vars.yml": """
my_var:
  - val1
  - val2
  - val3

my_list:
  - foo
  - bar
  - baz

my_dict:
  foo:
    bar: baz
""",
    })

    templar = Templar(loader=loader)

    # Test with a string

    terms = listify_lookup_plugin_terms("{{ my_var }}", templar, loader, fail_on_undefined=True, convert_bare=False)

    assert terms == ['val1', 'val2', 'val3']

    # Test with a list


# Generated at 2022-06-23 14:20:39.992569
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar

    class FakeVarsModule:
        def get_vars(self, loader, play, hostvars=None, include_hostvars=True):
            return dict(
                a="A",
                b="Test",
                c="{{a}}{{b}}",
                array=[1,2,3],
                dict=dict(a=1, b=2),
                mapping=Mapping({'a': 1, 'b': 2}),
                list=['a', 'b', 'c'],
                stuple=set(['a', 'b']),
                ftuple=(1, 2),
                int=123,
                undef=None,
            )


# Generated at 2022-06-23 14:20:49.514635
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.template import stringcoder
    import pytest

    def loader_mock(self, path):
        return path

    class VariableManager(object):
        _host_vars = dict()
        _host_vars_files = dict()

    v = VariableManager()
    t = Templar(loader=loader_mock, variable_manager=v, shared_loader_obj=loader_mock(v),
                available_variables=v.get_vars(play=None, host=None))

    terms = "item1"
    exp_terms = ["item1"]

    terms = listify_lookup_plugin_terms(terms, t, loader_mock, fail_on_undefined=False)

# Generated at 2022-06-23 14:20:59.524016
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    listify_lookup_plugin_terms: returns a list
    '''
    pass # dummy test for jenkins compatibility
    # from ansible.module_utils.common._collections_compat import Sequence
    # from ansible.module_utils.common.collections import ImmutableDict
    # from ansible.template import Templar
    # from ansible.vars.manager import VariableManager
    # import os

    # test = dict(
    #     list=['a', 'b', 'c'],
    #     tuple=('a', 'b', 'c'),
    #     string="""a
    # b
    # c""",
    #     dict=dict(a='b', c='d'),
    #     number=42
    # )

    # os.environ['ANSIBLE_LOOKUP

# Generated at 2022-06-23 14:21:07.663597
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    context = PlayContext()
    templar = Templar(loader=None, variables=dict(a='b'))

    # A string should be returned as a single-element list.
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # If a list is provided, it should be returned as-is.
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']

    # If a dict is provided, it should be returned as-is.
    assert listify_lookup_plugin_terms({'foo': 'bar'}, templar, None) == {'foo': 'bar'}

    # A comma-

# Generated at 2022-06-23 14:21:16.144743
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    # Make sure it converts a variable to a list.
    variable_manager.set_nonpersistent_facts(dict(
        foo='bar'
    ))
    templar = Templar(loader=loader, variables=variable_manager)
    terms = listify_lookup_plugin_terms('{{ foo }}', templar, loader)
    assert type(terms) == list
    assert terms == ['bar']

    # Make sure it returns lists as lists
    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-23 14:21:25.683614
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    test_templar = templar.Templar(loader=loader, variable_manager=variable_manager,
                                   shared_loader_obj=None,
                                   disable_lookups=True)
    test_context = PlayContext(variable_manager=variable_manager)


# Generated at 2022-06-23 14:21:37.127314
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 14:21:47.086780
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.utils.encrypt import do_encrypt, do_encrypt_text
    from ansible.plugin import plugin_loader
    from ansible.config.manager import ConfigManager

    config = ConfigManager()
    config.set_remote_user('root')
    config.set_remote_port(22)

    vault_pass = 'testpass'
    vault_secret_1 = VaultLib([u'Encrypted lookup plugin term'], vault_pass)
    vault_secret_2 = VaultLib([u'Another Encrypted lookup plugin term'], vault_pass)
    secret_1 = do_encrypt_text(vault_secret_1, vault_pass)

# Generated at 2022-06-23 14:21:57.989496
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    t = Templar(loader=None, variables={})

    assert [u'first'] == listify_lookup_plugin_terms(AnsibleUnicode(u'first'), t, None)
    assert [u'first'] == listify_lookup_plugin_terms(u'first', t, None)

    assert [u'first', u'second'] == listify_lookup_plugin_terms([u'first', u'second'], t, None)
    assert [u'first', u'second'] == listify_lookup_plugin_terms([u'first', u'second'], t, None, convert_bare=True)
    assert [u'first', u'second'] == list

# Generated at 2022-06-23 14:22:06.058297
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Required for templating
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['/dev/null']))
    vault_secrets = VaultLib(None, variable_manager)
    templar = Templar(loader=loader, variables=variable_manager, vault_secrets=vault_secrets)

    # Test cases

# Generated at 2022-06-23 14:22:17.294150
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    import ansible.parsing.yaml.loader

    assert listify_lookup_plugin_terms('test', None, None, convert_bare=True) == ['test']
    assert listify_lookup_plugin_terms('foo\nbar', None, None, convert_bare=True) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None, convert_bare=True) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo\nbar'], None, None, convert_bare=True) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo', None, None, convert_bare=True) == ['foo']
    assert list

# Generated at 2022-06-23 14:22:28.331830
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()

    results = []
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    variable_manager.extra_vars = {'nonesuch': 'success'}

    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=C.DEFAULT_UNDEFINED_VARIABLE_FAILURE)

    # Test simple string

# Generated at 2022-06-23 14:22:39.421509
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    fake_loader = AnsibleLoader(None, variable_manager=dict())

    # TEST 1
    # Simple test
    variable_manager = fake_loader.get_variable_manager()
    variable_manager.set_nonpersistent_facts(dict(a="hello"))

    test_string = "{{ a }}"
    templar = Templar(loader=fake_loader, variables=variable_manager)
    assert listify_lookup_plugin_terms(test_string, templar, fake_loader) == ["hello"]

    # TEST 2
    # Test list
    test_list = ["{{ a }}"]

# Generated at 2022-06-23 14:22:50.423417
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import PY3
    from ansible.template import Templar

    if PY3:
        unicode = str

    assert listify_lookup_plugin_terms("a", Templar(loader=None)) == ["a"]
    assert listify_lookup_plugin_terms("1", Templar(loader=None)) == ["1"]
    assert listify_lookup_plugin_terms(1, Templar(loader=None)) == [1]
    assert listify_lookup_plugin_terms([1], Templar(loader=None)) == [1]
    assert listify_lookup_plugin_terms([1,2], Templar(loader=None)) == [1,2]
    assert listify_lookup_plugin_terms({"a":1}, Templar(loader=None)) == [{"a":1}]
   

# Generated at 2022-06-23 14:23:02.302116
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variable_manager=variable_manager)

    # Single term, single item
    # ------------------------
    foo = 'foo'
    bar = ['bar']
    baz = [u'bar']
    assert listify_lookup_plugin_terms(foo, templar) == bar
    assert listify_lookup_plugin_terms(bar, templar) == bar
    assert listify_lookup_plugin_terms(baz, templar) == bar

    # Multiple terms, multiple items
    # ------------------------------
    foo = 'foo,bar'

# Generated at 2022-06-23 14:23:12.627362
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert listify_lookup_plugin_terms(None, Templar()) == [None]
    assert listify_lookup_plugin_terms([None, False, 1], Templar()) == [None, False, 1]
    assert listify_lookup_plugin_terms((None, False, 1), Templar()) == [None, False, 1]
    assert listify_lookup_plugin_terms(['None', 'False', 'a'], Templar(), fail_on_undefined=False) == ['None', 'False', 'a']
    assert listify_lookup_plugin_terms('None, False, a', Templar(), fail_on_undefined=False) == ['None', 'False', 'a']

# Generated at 2022-06-23 14:23:22.979178
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vars_manager = VariableManager()
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=vars_manager,
                      shared_loader_obj=loader)

    # Test simple list
    terms = [ '{{ item }}' ]
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['{{ item }}']

    terms = [ 'item1', 'item2' ]
    terms = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-23 14:23:34.693215
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.errors import AnsibleError

    templar = Templar(loader=None, variables={})

    # string
    assert listify_lookup_plugin_terms('foo', templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader=None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(u'foo\u00e9', templar, loader=None) == [u'foo\u00e9']

    # list
    assert listify_lookup_plugin_terms(['foo'], templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader=None)

# Generated at 2022-06-23 14:23:45.503272
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    mgr = DummyMgr()
    templar = Templar(loader=mgr, variables=dict(d1='foo', d2='bar'))

    def _test_terms(terms, expected_terms, convert_bare=False):
        ret = listify_lookup_plugin_terms(terms, templar, mgr, fail_on_undefined=True, convert_bare=convert_bare)
        assert ret == expected_terms

    terms = '{{ d1 }}'
    expected_terms = ['foo']
    _test_terms(terms, expected_terms)

    terms = ['bar', '{{ d2 }}']
    expected_terms = ['bar', 'bar']
    _test_terms(terms, expected_terms)


# Generated at 2022-06-23 14:23:56.381014
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Create some test fixtures for testing the function
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    lookup_loader = DictDataLoader({
        'terms.yml': 'Item One\nItem Two\nItem Three',
        ' ': '',
        'complex.yml': """
---
- 1
- 2
- 3
""",
        'complex2.yml': """
- 1
- 2
- 3
"""
    })

    variable_manager = VariableManager()
    variable_manager.set_fact_cache

# Generated at 2022-06-23 14:24:06.543224
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    var_mgr = VariableManager()
    inv_mgr = InventoryManager(loader=loader, sources=['localhost,'])
    var_mgr.set_inventory(inv_mgr)
    inv_mgr.set_variable_manager(var_mgr)

    templar = AnsibleTemplar(loader=loader, variables=var_mgr, fail_on_undefined=True)

    assert listify_lookup_plugin_terms(['a', 'b'], templar) == ['a', 'b']

# Generated at 2022-06-23 14:24:17.500057
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import jinja2

    env = jinja2.Environment(undefined=jinja2.StrictUndefined)
    args = [ 'foo', 'bar', 'baz' ]

    # Tesing with a string
    terms = '{{ foo }}, {{ bar }}, {{ baz }}'
    result = listify_lookup_plugin_terms(terms, env, loader, True)
    assert 3 == len(result)
    assert 'foo' == result[0]
    assert 'bar' == result[1]
    assert 'baz' == result[2]

    # Tesing with a list of strings
    terms = [ '{{ foo }}', '{{ bar }}', '{{ baz }}' ]
    result = listify_lookup_plugin_terms(terms, env, loader, True)
    assert 3 == len(result)

# Generated at 2022-06-23 14:24:28.760548
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    results = []

    results.append(listify_lookup_plugin_terms(1, {}))
    results.append(listify_lookup_plugin_terms([1, 2], {}))
    results.append(listify_lookup_plugin_terms('foo', {}))
    results.append(listify_lookup_plugin_terms(True, {}))

    results.append(listify_lookup_plugin_terms(1, None, None, False))
    results.append(listify_lookup_plugin_terms([1, 2], None, None, False))
    results.append(listify_lookup_plugin_terms('foo', None, None, False))

# Generated at 2022-06-23 14:24:29.614094
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Todo: write test cases, then create unit test

    return

# Generated at 2022-06-23 14:24:35.980937
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Dummy vars
    fake_loader = DataLoader()
    fake_play_context = PlayContext()
    fake_play_context.variable_manager = None
    templar = Templar(loader=fake_loader, variables=dict(),
                      shared_loader_obj=fake_loader,
                      templar_implementation='python')

    # Test case:
    # listify_lookup_plugin_terms takes a terms variable, a templar variable and a loader variable
    # If a list or a string is passed, return a list
    # If a list is passed, return a list
    # If a dict is passed, fail (not json serializable)

# Generated at 2022-06-23 14:24:47.577071
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 14:24:55.818257
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.plugins.loader import lookup_loader

    # Setup
    variable_manager = VariableManager()

# Generated at 2022-06-23 14:25:03.732123
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib

    var_manager = VariableManager()
    var_manager.extra_vars = {'test_var': 'test_value'}
    vault_secrets = dict()
    template_dir = None
    loader = None
    vault_password = None
    vault = VaultLib(vault_password, loader, vault_secrets)
    templar = Templar(var_manager, loader, vault)

    list_result = listify_lookup_plugin_terms("{{ test_var }}", templar, loader, fail_on_undefined=True, convert_bare=False)
    assert list_result == ['test_value']

    list_result_2 = listify_lookup_plugin

# Generated at 2022-06-23 14:25:15.475760
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import pytest
    import jinja2

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)
    variable_manager.set_fact('foo', 'bar')

    # Test string input
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['bar']

    # Test list of strings input
    assert listify_lookup_plugin_terms(['/foo', '/bar'], templar, loader) == ['/foo', '/bar']

    # Test list of objects makes no change

# Generated at 2022-06-23 14:25:25.229380
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils.six import PY2

    templar = Templar(loader=None, variables=dict(foo='bar'))

    # Test with string input
    terms = templar.template('{{ foo }}')
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['bar']

    # Test with already processed string input
    terms = 'bar'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['bar']

    # Test with list

# Generated at 2022-06-23 14:25:37.287166
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(None)

    def templar_template(data, fail_on_undefined=True):
        if isinstance(data, string_types):
            raise errors.AnsibleError("Expected list, got string!")

        return data

    templar = Templar(loader=loader, variables={'foo': 'bar'}, fail_on_undefined=True)
    templar.template = templar_template

    listify_lookup_plugin_terms(['{{ foo }}'], templar, loader, convert_bare=True)
    listify_lookup_plugin_terms('{{ foo }}', templar, loader, convert_bare=True)


# Generated at 2022-06-23 14:25:46.576420
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeTemplar:
        def __init__(self, value):
            self.value = value

        def template(self, terms, fail_on_undefined=True, convert_bare=False):
            return self.value

    class FakeLoader:
        pass

    assert listify_lookup_plugin_terms(1, FakeTemplar([]), FakeLoader(), fail_on_undefined=True) == [1]
    assert listify_lookup_plugin_terms([], FakeTemplar([]), FakeLoader(), fail_on_undefined=True) == []
    assert listify_lookup_plugin_terms(None, FakeTemplar([]), FakeLoader(), fail_on_undefined=True) == []

# Generated at 2022-06-23 14:25:53.044286
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import jinja2
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence

    def parser(term):
        # needs to mimic the Template method
        term = jinja2.Template("{{%s}}" % term).render()
        if term == "{{foo}}":
            term = AnsibleUnsafeText("bar")
        elif term == "{{goo}}":
            term =  AnsibleUnsafeText("car")
        elif term == "{{val}}":
            term =  AnsibleUnsafeText("zaphod")
        return term

    def loader(term):
        # needs to mimic the AnsibleLoader method
        term = jinja2.Template("{{%s}}" % term).render()

# Generated at 2022-06-23 14:26:03.495998
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    data = 'foo'
    templar = Templar(loader=None, variables=VariableManager(), vault_secrets=VaultLib())
    terms = listify_lookup_plugin_terms(data, templar, loader=None)
    assert(terms == ['foo'])

    data = ['a','b','c']
    templar = Templar(loader=None, variables=VariableManager(), vault_secrets=VaultLib())
    terms = listify_lookup_plugin_terms(data, templar, loader=None)
    assert(terms == ['a','b','c'])

    data = '{{ a }}'

# Generated at 2022-06-23 14:26:13.721487
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['localhost'])
    loader.set_inventory(inventory)
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = dict()
    templar = Templar(loader=loader, variable_manager=variable_manager)
    fail_on_undefined = False


# Generated at 2022-06-23 14:26:22.200348
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def get_loader(file_name):
        return DataLoader()

    def get_basedir(file_name):
        return '.'

    def get_vars(play=None):
        return dict()

    t = AnsibleTemplate(get_loader=get_loader,
                        get_basedir=get_basedir,
                        get_vars=get_vars)


# Generated at 2022-06-23 14:26:26.657306
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import errors
    from ansible.template import Templar

    loader = DictDataLoader({
        'test_string.j2': '{{ var_template }}',
    })
    templar = Templar(loader=loader)
    terms = u'foo,bar'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['foo', 'bar']

    terms = '{{ var_template }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['{{', 'var_template', '}}']

    terms = '{{ var_template }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)
    assert terms == ['foo', 'bar']



# Generated at 2022-06-23 14:26:38.179157
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from io import BytesIO
    import sys
    import yaml
    import jinja2
    sys.path.append("../")
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.lookup import LookupBase

# Generated at 2022-06-23 14:26:44.821047
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test with list of strings
    assert listify_lookup_plugin_terms(terms=['one', 'two', 'three'], templar=None, loader=None) == ['one', 'two', 'three']

    # test with one string
    assert listify_lookup_plugin_terms(terms='one', templar=None, loader=None) == ['one']

    # test with not-list
    try:
        assert listify_lookup_plugin_terms(terms=None, templar=None, loader=None)
    except TypeError:
        # we expect to get a TypeError for terms not-list
        pass

    # test with list of lists

# Generated at 2022-06-23 14:26:54.431728
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar()

    assert listify_lookup_plugin_terms('hello', templar, None) == ['hello']
    assert listify_lookup_plugin_terms(['hello', 'world'], templar, None) == ['hello', 'world']
    assert listify_lookup_plugin_terms([0, 1], templar, None) == [0, 1]
    assert listify_lookup_plugin_terms([False, True], templar, None) == [False, True]
    assert listify_lookup_plugin_terms({'hello', 'world'}, templar, None) == ['hello', 'world'] # template() accepts set

# Generated at 2022-06-23 14:27:04.841659
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)
    assert isinstance(listify_lookup_plugin_terms([1, 2, 3], templar, loader), list)
    assert isinstance(listify_lookup_plugin_terms(['1', '2', '3'], templar, loader), list)
    assert isinstance(listify_lookup_plugin_terms(1, templar, loader), list)
    assert isinstance(listify_lookup_plugin_terms('1', templar, loader), list)

# Generated at 2022-06-23 14:27:13.952838
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.template import Templar

    terms = [('foo', None), 'bar', 'baz']
    results = listify_lookup_plugin_terms(terms, Templar(VariableManager()), None)
    assert results == ['foo', 'bar', 'baz']

    terms = '{{var}}'
    results = listify_lookup_plugin_terms(terms, Templar(VariableManager()), None)
    assert results == ['{{var}}']

    terms = ['{{var}}', '{{var2}}']
    results = listify_lookup_plugin_terms(terms, Templar(VariableManager()), None)
    assert results == ['{{var}}', '{{var2}}']

# Generated at 2022-06-23 14:27:23.692194
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        from ansible.template import Templar
        from ansible.vars import VariableManager
    except ImportError:
        # no testing..
        return

    import os
    import sys
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    inv_path = os.path.join(os.path.dirname(__file__), 'hosts')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[inv_path])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    my_dict = {'a': 1, 'b': 2, 'c': 3}