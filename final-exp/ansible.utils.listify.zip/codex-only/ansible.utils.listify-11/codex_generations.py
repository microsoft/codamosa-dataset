

# Generated at 2022-06-23 14:17:32.435828
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Testing for Ansible 2.4, 2.5 and 2.6
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='')
    host = Host(name='example')
    group = Group(name='example')
    group.add_host(host)
    inv.add_group(group)
    inv.add_host(host)
    variable_manager = VariableManager(loader=loader, inventory=inv)
    templar = Templar(loader=loader, variables=variable_manager)

   

# Generated at 2022-06-23 14:17:37.540128
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    mock_loader = DataLoader()
    mock_inventory = InventoryManager(loader=mock_loader, sources=['localhost,'])
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)
    mock_options = {'verbosity': 0}

# Generated at 2022-06-23 14:17:48.040059
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils import template as template_module
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = template_module.Templar(loader=AnsibleLoader(None))

    assert listify_lookup_plugin_terms(1, templar, None) == [1]
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']
    assert listify_lookup_plugin_terms('{{ test_var }}', templar, None, convert_bare=True) == ['{{ test_var }}']

# Generated at 2022-06-23 14:17:57.276100
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Unit test for function listify_lookup_plugin_terms'''
    from ansible.template import Templar
    import ansible.parsing.yaml.loader

    assert listify_lookup_plugin_terms(None, None, None) is None
    assert listify_lookup_plugin_terms('foobar', None, None) == 'foobar'
    assert listify_lookup_plugin_terms(['foo','bar'], None, None) == ['foo','bar']

    templar = Templar(loader=ansible.parsing.yaml.loader.AnsibleLoader)

    result = listify_lookup_plugin_terms('{{ foo }}', templar, None, convert_bare=True)
    assert result == [ '{{ foo }}' ]


# Generated at 2022-06-23 14:18:05.331141
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test single terms
    terms = ["a", "b", "c"]
    for term in terms:
        assert listify_lookup_plugin_terms(term, None, None) == [term]

    # Test multiple terms
    assert listify_lookup_plugin_terms(terms, None, None) == terms

    # Test invalid types
    invalid_terms = [None, True, False]
    for term in invalid_terms:
        assert listify_lookup_plugin_terms(term, None, None) == []

# Generated at 2022-06-23 14:18:12.192120
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Dummy classes for dependency injection
    class Dummy:
        pass

    class DummyTemplar:

        def __init__(self):
            self.vars = dict()

        def __getitem__(self, item):
            return self.vars[item]

        def __setitem__(self, item, value):
            self.vars[item] = value

        def template(self, value, convert_bare=False, fail_on_undefined=True):
            return value

    class DummyLoader:
        def __init__(self):
            pass

        def get_basedir(self):
            return '/basedir'

    # Set up dummy dependencies
    dummy = Dummy()
    dummy.templar = DummyTemplar()
    dummy.loader = DummyLoader()

    # Test converting strings

# Generated at 2022-06-23 14:18:23.658877
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Setup AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # Setup FakeLoader
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)

    # Setup data which can be templated
    var1 = '{{ var1 }}'
    var2 = '{{ var2 }}'
    var3 = '{{ var3 }}'
    test_data = {}
    test_data["var1"] = 10
    test_data["var2"] = "hello"
    test_data["var3"] = "world"

    # Setup FakeVars object to store template data
    from ansible.vars import VariableManager
   

# Generated at 2022-06-23 14:18:33.085667
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    The lookup plugin terms is listified, converted to dict keys.

    :kwarg templar: AnsibleTemplar
    :kwarg loader: AnsibleLoader
    :kwarg fail_on_undefined: Boolean
    :kwarg convert_bare: Boolean

    :return: list
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import pytest
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import LookupBase


# Generated at 2022-06-23 14:18:42.752524
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(['foo', '{{var}}'], None, None) == ['foo', '{{var}}']
    assert listify_lookup_plugin_terms(['foo', '{{var}}'], None, None, convert_bare=True) == ['foo', '{{var}}']
    assert listify_lookup_plugin_terms(['foo', '{{var}}'], None, None, fail_on_undefined=False) == ['foo', '{{var}}']
    assert listify_lookup_plugin_terms(['foo', '{{var}}'], None, None, fail_on_undefined=False, convert_bare=True) == ['foo', '{{var}}']
    assert listify_lookup_plugin_terms('foo', None, None) == 'foo'
    assert listify_look

# Generated at 2022-06-23 14:18:51.393136
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' listify_lookup_plugin_terms should return a list '''
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from units.mock.loader import DictDataLoader

    variable_manager = VariableManager()
    loader = DictDataLoader({})

    def get_vault_password(prompt=None):
        return 'asdf'

    variable_manager.set_vault_secrets(['asdf'])

    vault_secret = AnsibleVaultEncryptedUnicode.from_plaintext('asdf', 'asdf')

    # Make sure these are working with or without vaulting
    vars_to_

# Generated at 2022-06-23 14:19:01.782787
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # test string arg
    loader = DummyLoader()
    templar = Templar(loader=loader)
    terms = 'test string'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == result and isinstance(terms, string_types)

    # test list arg
    terms = ['test', 'list']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == result and isinstance(terms, list)

    # test dict arg (should return original dict)
    terms = {'test': 'dict'}
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == result and isinstance(terms, dict)


# Generated at 2022-06-23 14:19:10.619373
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager,
                      templar=templar,
                      all_vars=variable_manager,
                      fail_on_undefined=True)

    assert listify_lookup_plugin_terms('{{ var }}', templar, loader) == ['{{ var }}']
    assert listify_lookup_plugin_terms(['{{ var }}'], templar, loader) == ['{{ var }}']

# Generated at 2022-06-23 14:19:22.176767
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    var_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=var_manager)

    assert listify_lookup_plugin_terms("foo", templar, loader) == ["foo"]
    assert listify_lookup_plugin_terms("foo", templar, loader, fail_on_undefined=False) == ["foo"]
    assert listify_lookup_plugin_terms("{{undefval}}", templar, loader) == [None]

# Generated at 2022-06-23 14:19:30.938335
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader, shared_loader_obj=loader)

    data = [
        (["a","b"], [u'a', u'b']),
        (u"a b", [u'a', u'b']),
        (u"a\nb", [u'a', u'b']),
    ]

    for input,expected in data:
        result = listify_lookup_plugin_terms(input, templar, loader)
        assert result == expected


# Generated at 2022-06-23 14:19:37.718638
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    # Create templar with dummy vault secret
    loader = DataLoader()
    vault = VaultLib([], None)
    templar = Templar(loader=loader, variables={}, vault_secrets=[vault])

# Generated at 2022-06-23 14:19:48.044257
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.template import Templar
    from ansible.vars import VariableManager
    mock_loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.set_host_variable("foo", {"bar": "baz"})
    templar = Templar(loader=mock_loader, variable_manager=variable_manager, shared_loader_obj=mock_loader, lookup_loader=mock_loader)
    templar.set_available_variables(variable_manager.get_vars(play=dict(name="foo")))

    # test a string

# Generated at 2022-06-23 14:19:59.044451
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms("1", templar, loader) == ['1']
    assert listify_lookup_plugin_terms(["1"], templar, loader) == ['1']
    assert listify_lookup_plugin_terms(["1", "2"], templar, loader) == ['1', '2']
    assert listify_lookup_plugin_terms(1, templar, loader) == [1]
    assert listify_lookup_plugin_terms(1.1, templar, loader) == [1.1]

# Generated at 2022-06-23 14:20:03.671484
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    fake_loader = object()
    templar = Templar(loader=fake_loader)

    # test string input
    assert listify_lookup_plugin_terms('1 2 3', templar, fake_loader) == ['1', '2', '3']
    assert listify_lookup_plugin_terms('www.example.com', templar, fake_loader) == ['www.example.com']
    assert listify_lookup_plugin_terms('  www.example.com  ', templar, fake_loader) == ['www.example.com']
    assert listify_lookup_plugin_terms('', templar, fake_loader) == ['']
    assert listify_lookup_plugin_terms(' ', templar, fake_loader) == ['']
    assert list

# Generated at 2022-06-23 14:20:15.162027
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # The purpose of this function is to make sure that terms are always a list.
    # For example, if terms is a string it should be put into a list.
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    # Test for string input
    terms = 'foo'
    templar = Templar(loader=AnsibleLoader)
    assert(listify_lookup_plugin_terms(terms, templar, fail_on_undefined=True) == ['foo'])
    # Test for list input
    terms = ['foo', 'bar', 'baz']
    assert(listify_lookup_plugin_terms(terms, templar, fail_on_undefined=True) == ['foo', 'bar', 'baz'])
    # Test for non-iterable input

# Generated at 2022-06-23 14:20:24.610240
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts.system.distribution as distribution
    from ansible.template import Templar

    distro = distribution.Distribution()
    module = AnsibleModule(argument_spec={})
    templar = Templar(loader=module._loader, variables=distro.get_facts())

    assert listify_lookup_plugin_terms('foo', templar) == ['foo']
    assert listify_lookup_plugin_terms([None], templar) == [None]
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar) == ['foo', 'bar']

# Generated at 2022-06-23 14:20:36.239017
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar, Jinja2Environment

    jj2env = Jinja2Environment(
        trim_blocks=True,
        undefined=StrictUndefined
    )


# Generated at 2022-06-23 14:20:47.065281
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.errors import AnsibleError
    from ansible.plugins.loader import lookup_loader, module_loader
    from ansible.template import Templar
    from ansible.utils.context_objects import AnsibleContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # create a dummy environment so we can create the templar object below
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    variable_manager.set_loader(loader)
    variable_manager.set_builtin_facts(dict())


# Generated at 2022-06-23 14:20:57.171312
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = {}
    playbook_vars = dict(foo='bar')
    vars_manager._vars_per_host = combine_vars(playbook_vars, vars_manager._vars_per_host)
    templar = Templar(loader=loader, variables=vars_manager)

    # Test with a string containing a single term 'foo'
    terms='{{ foo }}'
    expected=['bar']
    result = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)

# Generated at 2022-06-23 14:21:06.243139
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()

    test_list = [ 'value1', 'value2' ]
    templar = Templar(loader=loader, variables=variable_manager)
    assert listify_lookup_plugin_terms(test_list, templar, loader, fail_on_undefined=False) == test_list
    assert listify_lookup_plugin_terms("value3", templar, loader, fail_on_undefined=False) == [ "value3" ]

# Generated at 2022-06-23 14:21:14.929082
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    fake_loader = AnsibleLoader(None, {})
    fake_templar = Templar(loader=fake_loader)

    assert listify_lookup_plugin_terms('foo', fake_templar, fake_loader) == ['foo']

    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], fake_templar, fake_loader) == ['foo', 'bar', 'baz']

    assert listify_lookup_plugin_terms('       ', fake_templar, fake_loader) == ['']

    assert listify_lookup_plugin_terms(False, fake_templar, fake_loader) == [False]

    assert listify_lookup_plugin_

# Generated at 2022-06-23 14:21:19.047829
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' Test listify_lookup_plugin_terms function '''

    import yaml
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types
    from ansible.utils.display import Display
    display = Display()

    # Get fixture data
    with open("unittests/lookup_plugins/test_listify_lookup_plugin_terms.yml", "r") as terms_file:
        terms_list = yaml.load(terms_file.read())

    for term in terms_list:
        # Assert for proper type for each term
        assert isinstance(term, Mapping)
        assert term.get('term') is not None
        assert term.get('expected') is not None

        # Build args for function based on fixture data

# Generated at 2022-06-23 14:21:27.124910
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.parsing.yaml.objects
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    def fail_on_undefined(obj):
        return obj

    templar._fail_on_undefined = fail_on_undefined


# Generated at 2022-06-23 14:21:35.093339
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms('a', Templar({}, None)) == ['a']
    assert listify_lookup_plugin_terms(['a'], Templar({}, None)) == ['a']
    assert listify_lookup_plugin_terms(1, Templar({}, None)) == ['1']
    assert listify_lookup_plugin_terms(['a', 'b'], Templar({}, None)) == ['a', 'b']

    assert listify_lookup_plugin_terms(['a', ['b']], Templar({}, None)) == ['a', ['b']]

# Generated at 2022-06-23 14:21:45.291194
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(1, None, None) == [1]
    assert listify_lookup_plugin_terms([1], None, None) == [1]
    assert listify_lookup_plugin_terms((1, 2, 3), None, None) == [1, 2, 3]
    assert listify_lookup_plugin_terms(set([1, 2, 3]), None, None) == [1, 2, 3]
    assert listify_lookup_plugin_terms('test', None, None) == ['test']
    assert listify_lookup_plugin_terms(' test ', None, None) == ['test']
    assert listify_lookup_plugin_terms('    test', None, None) == ['test']
    assert listify_lookup_plugin_terms('test    ', None, None)

# Generated at 2022-06-23 14:21:55.884892
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    the_list = [
        'one',
        'two three',
        [
            None,
            'four',
            [
                'five',
                'six',
            ],
        ],
    ]

    templar = Templar(loader=loader, variables=variable_manager)
    result = listify_lookup_plugin_terms(the_list, templar, loader)

    assert result[0] == 'one'
    assert result[1] == 'two three'
    assert result[2][0] == None
    assert result[2][1] == 'four'
    assert result

# Generated at 2022-06-23 14:22:04.762836
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    vars_dict = dict(a_str='long_str', b_str='short', a_list=[1,2,3])
    templar = Templar(loader=None, variables=vars_dict)

    terms = "{{a_str}}"
    expected_result = ['long_str']
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == expected_result, "Expected %s, got %s" % (expected_result, result)

    terms = ["{{a_str}}"]
    expected_result = ['long_str']
    result = listify_lookup_plugin_terms(terms, templar, loader=None)

# Generated at 2022-06-23 14:22:10.845328
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms("1 2 3") == ['1', '2', '3']
    assert listify_lookup_plugin_terms(["1", "2", "3"]) == ['1', '2', '3']
    assert listify_lookup_plugin_terms("{{ [1,2,3] }}") == ['1', '2', '3']

# Generated at 2022-06-23 14:22:11.699254
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:22:20.015551
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # this test really doesn't do much, but it will fail with an
    # error if refactoring breaks the function
    import ansible.parsing.yaml.objects
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager(), shared_loader_obj=None)
    result = listify_lookup_plugin_terms(terms=["foo as var", "bar"], templar=templar, loader=None)
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode)
    assert result[1] == "bar"

# Generated at 2022-06-23 14:22:30.434139
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar

    templar = Templar(loader=None)

    test_string = "{{ my_var }}"
    test_string_with_comma = "{{ my_var }}, {{ my_var2 }}"
    test_list = ["{{ my_var }}", "{{ my_var2 }}"]
    test_list_with_comma = ["{{ my_var }}", "{{ my_var2 }}", "{{ my_var3 }}"]

    # Test string
    myvars = dict(my_var='foo')
    result = listify_lookup_plugin_terms(test_string, templar, None, fail_on_undefined=True, convert_bare=False, myvars=myvars)
    assert isinstance

# Generated at 2022-06-23 14:22:40.963405
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.plugins.lookup
    from ansible.template import Templar

    mock_loader = ansible.plugins.lookup.LookupBase()

    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, Templar(loader=mock_loader, variables={}), mock_loader)
    assert result == ['foo']

    terms = ['foo']
    result = listify_lookup_plugin_terms(terms, Templar(loader=mock_loader, variables={}), mock_loader)
    assert result == ['foo']

    terms = ['foo', 'bar']
    result = listify_lookup_plugin_terms(terms, Templar(loader=mock_loader, variables={}), mock_loader)
    assert result == ['foo', 'bar']

    terms = '{{ foo }}'

# Generated at 2022-06-23 14:22:51.289466
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # empty list
    assert listify_lookup_plugin_terms([], None, None) == []
    # empty string
    assert listify_lookup_plugin_terms('', None, None) == ['']
    # list
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], None, None) == ['a', 'b', 'c']
    # list that is just a string
    assert listify_lookup_plugin_terms(['a'], None, None) == ['a']
    # string
    assert listify_lookup_plugin_terms('a', None, None) == ['a']
    # string with spaces
    assert listify_lookup_plugin_terms('a b c', None, None) == ['a b c']

# Generated at 2022-06-23 14:23:02.417570
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = DictDataLoader({
        "/etc/ansible/vars.yml": """
foobar:
  - name: foo
    bar: bar
    baz: baz
""",
    })

    myvars = dict(
        foo="foo",
        bar="bar",
        baz="baz",
        foobar=dict(
            name="foo",
            bar="bar",
            baz="baz",
            ),
        )

    templar = Templar(loader=loader, variables=myvars)

    assert listify_lookup_plugin_terms("{{ foo }}", templar, loader) == ["foo"]
    assert listify_lookup_plugin_terms("'{{ foo }}'", templar, loader) == ["foo"]
    assert list

# Generated at 2022-06-23 14:23:12.732926
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Get a set of valid arguments
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = []
    play = Play().load(dict(
        name = "Ansible Play dummy text for unit test",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
        ), variable_manager=variable_manager, loader=loader)

    # Create

# Generated at 2022-06-23 14:23:23.061966
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    terms = 'var'
    templar = Templar(loader=loader, variables=variable_manager)
    terms = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert terms[0] == 'var'

    variable_manager.set_nonpersistent_fact('var', 'test')
    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-23 14:23:34.693693
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
     from ansible.plugins.lookup import do_lookup
     from ansible.template import Templar

     sc = dict(lookup_plugins=dict(), basedir='/some/base/dir')
     lookup_plugin = sc['lookup_plugins']['file'] = do_lookup
     lookup_plugin.set_options()
     templar = Templar(loader=None, variables={})

     test_input = "hello world"
     expected = ['hello world']
     actual = listify_lookup_plugin_terms(test_input, templar, None, fail_on_undefined=False)
     print('actual:   %s' % actual)
     print('expected: %s' % expected)
     assert actual == expected


     test_input = ['hello world', 'goodbye world']

# Generated at 2022-06-23 14:23:45.503101
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': '1', 'b': '2'}
    loaded_lookup_plugin = 'lookup_plugins.foo'

    loader = 'lookup_plugins.dummy_loader'
    inventory = Inventory(loader, variable_manager, host_list=[])
    templar = Templar(loader=loader, variables=variable_manager, inventory=inventory)

    assert listify_lookup_plugin_terms('{{a}}', templar, loader) == ['1']

# Generated at 2022-06-23 14:23:56.381889
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from collections import namedtuple
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import sys

    if sys.version_info[0] < 3:
        _unicode = unicode
    else:
        _unicode = str

    # Create data structures required for templar to function.
    fake_loader = DataLoader()
    fake_variable_manager = VariableManager()

    def mock_template(self, value, convert_bare=False, fail_on_undefined=True):
        return value

    # Override the templar template function.
    Templar._template = mock_template

    test_case = namedtuple('test', 'terms expected')

# Generated at 2022-06-23 14:24:06.542999
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # This is here to support unit testing directly within this file,
    # without having to create a corresponding module elsewhere
    import sys
    sys.modules['ansible'] = type('module', (object,), {})
    from ansible.template import Templar

    # Tests for 'listify_lookup_plugin_terms'

# Generated at 2022-06-23 14:24:17.500195
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar

    terms = '{{ lookup("foo") }}'
    templar = Templar(loader=None, variables={})

    results = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(results, list), results

    terms = AnsibleBaseYAMLObject('{{ lookup("foo") }}')
    templar = Templar(loader=None, variables={})

    results = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(results, list), results

    terms = '{{ lookup("foo") }}'
    templar = Templar(loader=None, variables={})


# Generated at 2022-06-23 14:24:22.592001
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variable_manager=variable_manager)
    variable_manager.set_nonpersistent_facts(dict(a="b"))

    terms = listify_lookup_plugin_terms(['{{a}}', '{{b}}'], templar, loader)
    assert terms == ['b', '{{b}}']

    terms = listify_lookup_plugin_terms(['{{a}}', '{{ b }}'], templar, loader)
    assert terms == ['b', '{{ b }}']


# Generated at 2022-06-23 14:24:32.670460
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar

    loader = DataLoader()
    inv_mgr = InventoryManager(loader=loader)
    var_mgr = VariableManager(loader=loader, inventory=inv_mgr)

    # empty
    terms = None
    result = listify_lookup_plugin_terms(terms, Templar(loader=loader, variables=var_mgr), loader, fail_on_undefined=True, convert_bare=False)
    assert result == [None], result

    # single item, no templating
    terms = "one"

# Generated at 2022-06-23 14:24:43.388711
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    my_vars = dict(
        a_list = [1, 2, 3],
        a_dict = dict(
            key1 = 1,
            key2 = 2,
            key3 = 3,
        ),
        a_var = "{{ a_list[1] }}_and_{{ a_dict.key2 }}",
        a_single_int = 1,
        a_none = None,
        a_string = 'a_string',
        a_list_with_none = [ 1, None, 3],
    )

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 14:24:52.553292
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    def test_template(v, fail_on_undefined=True):
        return v
    def test_template2(v, fail_on_undefined=True):
        return [ v ]

    templar = Templar(loader=None)
    templar.template = test_template

    # Check fail_on_undefined
    assert listify_lookup_plugin_terms('foo', templar, None, True) == [ 'foo' ]
    assert listify_lookup_plugin_terms('foo', templar, None, False) == [ 'foo' ]

    # Check string
    assert listify_lookup_plugin_terms('foo', templar, None) == [ 'foo' ]

    # Check list

# Generated at 2022-06-23 14:25:02.717015
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    listify_lookup_plugin_terms(['a', 'b', 'c']) == ['a', 'b', 'c']
    listify_lookup_plugin_terms('a') == ['a']
    listify_lookup_plugin_terms(u'a') == ['a']
    listify_lookup_plugin_terms(['a', 'b', u'c']) == ['a', 'b', 'c']
    listify_lookup_plugin_terms('a b c') == ['a b c']
    """
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    variable_manager = VariableManager()

   

# Generated at 2022-06-23 14:25:14.208144
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    listify_lookup_plugin_terms: make sure all results are lists
    '''
    from ansible import context
    from ansible.template import Templar

    context.CLIARGS = {}
    loader = context.CLIARGS['_ansible_loader']
    templar = Templar(loader=loader)

    # Make sure we don't break non-strings
    assert(listify_lookup_plugin_terms([], templar, loader) == [])
    assert(listify_lookup_plugin_terms([1,2,3], templar, loader) == [1,2,3])
    # Convert list of strings to list of string-lists
    test = "{{'a','b','c'}}"

# Generated at 2022-06-23 14:25:24.739085
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vault import VaultLib
    from ansible.module_utils._text import to_bytes

    vault_secrets = {'secret': 'password'}
    vault = VaultLib(vault_secrets)
    templar = Templar(loader=None, variables={'vault': vault_secrets})

    # test for scalar
    test_val = 'test'
    result_val = listify_lookup_plugin_terms(test_val, templar, loader=None)
    assert result_val == [test_val]

    # test for list
    test_val = ['test1', 'test2']
    result_val = listify_lookup_

# Generated at 2022-06-23 14:25:36.815187
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.unicode import to_bytes

    dl = DataLoader()
    passwords = {'vault_password_file': to_bytes(None)}

    vault_secret = 'vault_secret'
    vault_password = 'vault_password'


# Generated at 2022-06-23 14:25:46.392770
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert listify_lookup_plugin_terms(1, Templar(), None) == [1]
    assert listify_lookup_plugin_terms([1, 2, 3], Templar(), None) == [1, 2, 3]
    assert listify_lookup_plugin_terms('foo', Templar(), None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], Templar(), None) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', Templar(), None) == ['foo bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], Templar(), None) == ['foo', 'bar']

    assert listify_lookup_plugin_terms(1, Templar(), None, convert_bare=True) == [1]
    assert list

# Generated at 2022-06-23 14:25:52.931698
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Test listify_lookup_plugin_terms function
    """

    from ansible.template import Templar

    loader = "foo"
    templar = Templar(loader=loader)

    # Test input as string
    term = "{{ test_var }}"
    expected_result = ['{{ test_var }}']
    result = listify_lookup_plugin_terms(term, templar, loader)
    assert result == expected_result

    # Test input as list
    term = ['{{ test_var }}']
    expected_result = ['{{ test_var }}']
    result = listify_lookup_plugin_terms(term, templar, loader)
    assert result == expected_result

    # Test input as list of string and list
    term = ['{{ test_var }}', ["{{ test_var }}"]]


# Generated at 2022-06-23 14:26:03.423291
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Validate proper handling of string and Iterable input to listify_lookup_plugin_terms
    '''

    from ansible.module_utils.common import AnsibleModule
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    args = dict(
        templar = Templar(loader=None, variables={}),
        loader = None,
        fail_on_undefined = True,
        convert_bare = False,
    )

    # Test string_types term and template
    for term in ['{{ var1 }}', 'var1']:
        for vars in [['var1', 'var1'], dict(var1='var1')]:
            ansible_module = AnsibleModule(argument_spec=args)

# Generated at 2022-06-23 14:26:13.634490
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    def test(tpl, expected):
        #import sys
        #sys.stderr.write("testing %s -> %s" % (tpl, expected))
        assert listify_lookup_plugin_terms(tpl, DummyTemplar(), DummyLoader()) == expected

    class DummyTemplar:
        def template(self, terms, fail_on_undefined=True, convert_bare=True):
            #sys.stderr.write("template--> %s" % terms)
            return terms
    class DummyLoader:
        pass
    test('foo', ['foo'])
    test('foo, bar', ['foo', 'bar'])
    test([1, 2, 3], [1, 2, 3])
    test(['foo', 'bar'], ['foo', 'bar'])

# Generated at 2022-06-23 14:26:22.201458
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    listify_lookup_plugin_terms:
        - test string
        - test list
        - test none
    '''
    from ansible.template import Templar
    from ansible.template import Jinja2TemplateModule
    from ansible.module_utils.six import PY3
    if PY3:
        from importlib import reload

    m = Jinja2TemplateModule()
    t = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms(terms="string", templar=t, loader=None) == ['string']
    assert listify_lookup_plugin_terms(terms=reload(m).params['test string'], templar=t, loader=None) == ['string']

# Generated at 2022-06-23 14:26:22.783266
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:26:28.419213
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    def assert_result(terms, expected_result, variables=None, convert_bare=False, fail_on_undefined=True):
        templar = Templar(loader=loader, variables=variables)

        result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=fail_on_undefined,
                                             convert_bare=convert_bare)

        assert result == expected_result

    # Setup test
    loader = AnsibleLoader(None, '<test>')

    # Test when terms is a string
    assert_result('{{ foo }}', ['1'], variables={'foo': 1})

# Generated at 2022-06-23 14:26:39.992698
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert listify_lookup_plugin_terms([1, 2, 3], None, None) == [1, 2, 3]
    assert listify_lookup_plugin_terms(["1", "2", "3"], None, None) == ["1", "2", "3"]
    assert listify_lookup_plugin_terms(["{{", "}}"], None, None) == ["{{", "}}"]
    assert listify_lookup_plugin_terms("{{", None, None) == ["{{"]
    assert listify_lookup_plugin_terms("1", None, None) == ["1"]
    assert listify_lookup_plugin_terms("1,{{foo}},2", None, None) == ["1,{{foo}},2"]

# Generated at 2022-06-23 14:26:51.830294
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={'foo': 'bar'})
    assert listify_lookup_plugin_terms([1,2,3], templar, None) == [1,2,3]
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None) == ['bar']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None, convert_bare=True) == ['bar']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None, convert_bare=True, fail_on_undefined=False) == ['{{ foo }}']
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup

# Generated at 2022-06-23 14:27:02.953853
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    import ansible.constants as C

    class DummyVarsModule():
        def __init__(self):
            self._templar = Templar(loader=AnsibleLoader(None))

        def get_vars(self, play, host):
            return dict(a='a_value', b='b_value', c='c_value')

    dummy_ds = dict(a=dict(b=dict(c='a.b.c', d=['a.b.d1', 'a.b.d2'], e='{{a}}.b.e')))

# Generated at 2022-06-23 14:27:13.640462
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.loader import lookup_loader
    from ansible.vars import VariableManager

    # Create a templar for StringVars
    vars_manager = VariableManager()
    vars_manager.set_inventory(lookup_loader.get('inventory_dir', {}).get('inventory_dirs', ['.'])[0])
    templar = Templar(loader=lookup_loader, variables=vars_manager)

    # Test a string
    terms = listify_lookup_plugin_terms(
        terms='a',
        templar=templar,
        loader=lookup_loader,
    )
    assert isinstance(terms, list)
   

# Generated at 2022-06-23 14:27:23.566270
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import sys
    import os
    import tempfile
    import shutil
    import ansible.constants as C

    # need to do this weird dance so the test on Python3 can properly 
    # import this module while avoiding an import error initially
    my_name = os.path.basename(__file__).rsplit('.', 1)[0]
    module_utils_dir = os.path.dirname(__file__)

    sys.path.insert(0, module_utils_dir)
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
