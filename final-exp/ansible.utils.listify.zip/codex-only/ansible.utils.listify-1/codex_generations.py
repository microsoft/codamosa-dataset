

# Generated at 2022-06-23 14:17:24.202986
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert listify_lookup_plugin_terms(["a", "b", "c"], Templar(loader=None), None) == ["a", "b", "c"]
    assert listify_lookup_plugin_terms("a", Templar(loader=None), None) == ["a"]
    assert listify_lookup_plugin_terms("  a  ", Templar(loader=None), None) == ["a"]
    assert listify_lookup_plugin_terms(["a", "b"], "  c  ", Templar(loader=None), None) == ["a", "b", "c"]

# Generated at 2022-06-23 14:17:30.158889
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Setup test
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'x': "test"})
    terms = "$x"

    # Run function
    try:
        terms = listify_lookup_plugin_terms(terms, templar, None)
    except:
        terms = None

    # Verify result
    assert terms == ["test"]

# Generated at 2022-06-23 14:17:39.033480
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar

    terms = "{{ foo }}"
    templar = Templar(loader=AnsibleLoader(VaultLib()), shared_loader_obj=False)

    result = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=True, convert_bare=False)
    assert result == [AnsibleUnsafeText('{{ foo }}')]

    terms = "{{ foo }}\n{{ bar }}"

# Generated at 2022-06-23 14:17:49.413220
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert listify_lookup_plugin_terms('foo', Templar({}, {}), {}) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], Templar({}, {}), {}) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', '{{ item }}'], Templar({}, {}), {}, convert_bare=True) == ['foo', '{{ item }}']
    assert listify_lookup_plugin_terms(['foo', '{{ item }}'], Templar({'item': 42}, {}), {}, convert_bare=True) == ['foo', 42]

# Generated at 2022-06-23 14:17:58.118107
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext

    from ansible.template import Templar

    # setup test environment
    C.DEFAULT_HASH_BEHAVIOUR = 'merge'

    variables = dict(
        hostvars = dict(
            testhost=dict(
                ansible_facts = dict(
                    distribution = 'Debian',
                )
            )
        ),
        groups = dict(
            webservers = ['testhost'],
            dbservers = ['testhost']
        ),
    )

    loader = DictDataLoader({})
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader, inventory=inventory))
    templar = Templar(loader=loader, variables=variables)

    testlist = listify_look

# Generated at 2022-06-23 14:18:03.882031
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    terms = '{{list_data}}'
    loader = DataLoader()
    templar = Templar(loader=loader)
    listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-23 14:18:11.184722
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # listify_lookup_plugin_terms should return a list of one element for a single term,
    # and return a list of multiple elements if it is a list already.
    # In either case, the elements of the list should be the evaluated
    # string values, taking into account template processing.
    results = listify_lookup_plugin_terms(
        ['one', 'two', 'three'],
        Templar(loader=None, variables=dict(one='1', two='2', three='3')),
        loader=None
    )
    assert results == ['1', '2', '3']

    results = listify_lookup_plugin_terms(
        'foo',
        Templar(loader=None, variables=dict(foo='foo')),
        loader=None
    )

# Generated at 2022-06-23 14:18:22.173823
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    vars = AnsibleVars(loader=AnsibleLoader(), shared_loader_obj=None)
    templar = Templar(loader=None, variables=vars)

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(' foo  bar ', templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, None) == ['foo']
    assert list

# Generated at 2022-06-23 14:18:31.141512
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.templating.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms("foo bar", templar, loader) == ['foo bar']
    assert listify_lookup_plugin_terms("bar", templar, loader) == ['bar']
    assert listify_lookup_plugin_terms("foo", templar, loader) == ['foo']
    assert listify_lookup_plugin_terms([1, 2], templar, loader) == [1, 2]

# Generated at 2022-06-23 14:18:36.692198
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(None, templar) == [None]
    assert listify_lookup_plugin_terms("{{foo}}", templar) == [None]
    assert listify_lookup_plugin_terms("{{foo}}", templar, convert_bare=True) == ['{{foo}}']
    assert listify_lookup_plugin_terms("foo", templar) == ['foo']
    assert listify_lookup_plugin_terms("foo", templar, convert_bare=True) == ['foo']
    assert listify_lookup_

# Generated at 2022-06-23 14:18:47.098242
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    T_STRING = u'123'
    T_LIST = [u'123', u'456', u'789']
    T_DICT = { u'key1': u'value1', u'key2': u'value2', u'key3': u'value3' }

    terms = (T_STRING, T_LIST, T_DICT)

    dl = DataLoader()
    vault = VaultLib(None, dl)

# Generated at 2022-06-23 14:18:58.684438
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DummyLoader()
    templar = Templar(loader=loader)
    terms = 'foo'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['foo']

    templar = Templar(loader=loader)
    terms = 'foo,bar'
    terms = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)
    assert terms == ['foo', 'bar']

    templar = Templar(loader=loader)
    terms = 'foo,bar'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == 'foo,bar'

    templar = Templar(loader=loader)
    terms = ['foo','bar']

# Generated at 2022-06-23 14:19:09.142306
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import simplejson
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    vars_manager = VariableManager()
    vars_manager.set_inventory(None)
    vars_manager._extra_vars = dict(foo="bar")
    templar = Templar(loader=None, variables=vars_manager)

    assert listify_lookup_plugin_terms(1, templar, loader=None, fail_on_undefined=True, convert_bare=False) == [1]

# Generated at 2022-06-23 14:19:20.779108
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeVarsModule():
        def __init__(self):
            self.__dict__ = dict()

    class FakeLoader():
        def __init__(self):
            self.vars = FakeVarsModule()
            self.set_fact = self.vars.__setitem__

    term_list = listify_lookup_plugin_terms("{{ test_var }}", Templar(loader=FakeLoader()), FakeLoader())
    assert term_list == ['']

    term_list = listify_lookup_plugin_terms(["{{ test_var }}"], Templar(loader=FakeLoader()), FakeLoader())
    assert term_list == ['', '']


# Generated at 2022-06-23 14:19:29.950727
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Test that listify_lookup_plugin_terms() creates a list
    '''

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    terms = '{{ foo }}'

    def templar_template(terms, fail_on_undefined=False):
        return terms

    templar = Templar(DataLoader(), None, None)
    templar.template = templar_template

    result = listify_lookup_plugin_terms(terms, templar, None)

    assert isinstance(result, Iterable)
    assert isinstance(result, list)
    assert not isinstance(result, string_types)
    assert not isinstance(result, Mapping)

# Generated at 2022-06-23 14:19:41.889884
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # test_loader = DataLoader()
    test_loader = None
    test_variables = combine_vars(loader=test_loader, variables=dict(test_variable='test'))
    test_templar = Templar(loader=test_loader, variables=test_variables)

    # test for string
    terms = "{{test_variable}}"
    results = listify_lookup_plugin_terms(terms, templar=test_templar, loader=test_loader)
    assert(isinstance(results, list))
    assert(len(results) == 1)
    assert(results[0] == 'test')

    # test for list


# Generated at 2022-06-23 14:19:50.952153
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=AnsibleLoader(), variables=VariableManager())
    terms = listify_lookup_plugin_terms("{{ roles_path }}/common/tasks/main.yml", templar, templar.loader)
    assert len(terms) == 1
    assert terms[0] == "/etc/ansible/roles/common/tasks/main.yml"

    terms = listify_lookup_plugin_terms("{{ roles_path }}/common/tasks/main.yml", templar, templar.loader, convert_bare=True)
    assert len(terms) == 1

# Generated at 2022-06-23 14:20:02.278586
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader)
    assert listify_lookup_plugin_terms("foo", templar, loader=AnsibleLoader) == ["foo"]
    assert listify_lookup_plugin_terms("foo bar baz", templar, loader=AnsibleLoader) == ["foo bar baz"]
    assert listify_lookup_plugin_terms("{{ foo }}", templar, loader=AnsibleLoader) == ["{{ foo }}"]
    assert listify_lookup_plugin_terms(["foo", "bar"], templar, loader=AnsibleLoader) == ["foo", "bar"]

# Generated at 2022-06-23 14:20:09.888380
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.template import Templar

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    mock_loader = DataLoader()
    mock_loader._search_paths = ['/does/not/exist']

    vars_manager = VariableManager(loader=mock_loader)

    fake_template = Templar(loader=mock_loader, variables=vars_manager)

    assert listify_lookup_plugin_terms("foo", fake_template, mock_loader) == ['foo']
    assert listify_lookup_plugin_terms("foo bar", fake_template, mock_loader) == ['foo bar']

# Generated at 2022-06-23 14:20:21.962558
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    dummy_loader = None

    v = VaultLib([])
    t = Templar(loader=dummy_loader, variables=VariableManager(), vault_secrets=[v])

    assert listify_lookup_plugin_terms("a", t, dummy_loader) == ['a']
    assert listify_lookup_plugin_terms(["a"], t, dummy_loader) == ['a']
    assert listify_lookup_plugin_terms(["a", "b"], t, dummy_loader) == ['a', 'b']
    assert listify_lookup_plugin_terms(["a", ["b", "c"]], t, dummy_loader) == ['a', ['b', 'c']]

# Generated at 2022-06-23 14:20:33.425066
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class MockLoader(object):
        pass

    loader = MockLoader()

    templar = Templar(loader=loader)
    results = []

# Generated at 2022-06-23 14:20:42.442702
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = '{{ string }}'
    templar = Templar(loader=None)
    expected = 'string'
    assert expected == listify_lookup_plugin_terms(terms, templar, loader=None)[0]


    terms = ['one', 'two', 'three']
    templar = Templar(loader=None)
    expected = ['one', 'two', 'three']
    assert expected == listify_lookup_plugin_terms(terms, templar, loader=None)


    terms = [ '{{ string }}', 'two', 'three' ]
    templar = Templar(loader=None)
    expected = ['string', 'two', 'three']
    assert expected == listify_lookup_plugin_terms(terms, templar, loader=None)

# Generated at 2022-06-23 14:20:48.021180
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Yes this is a bad mock
    class FakeVarsModule:
        @staticmethod
        def get_vars(loader, path, entities, cache=True):
            return dict(a=1, b=2)

        @staticmethod
        def get_file_vars(loader, path, entities):
            return dict(c=1, d=2)


    class FakeLoaderModule:
        def __init__(self):
            self.path_dwim_result = '/some/path'

    t = Templar(loader=FakeLoaderModule(), variables=FakeVarsModule())

    assert listify_lookup_plugin_terms('1', t) == ['1']
    assert listify_lookup_plugin_terms(['1', '2'], t) == ['1', '2']


# Generated at 2022-06-23 14:20:57.782560
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    # test with a scalar
    assert listify_lookup_plugin_terms(terms='{{ foo }}', templar=templar) == ['{{ foo }}']

    # test with a list that also includes a template string
    assert listify_lookup_plugin_terms(terms=['a', 'b', '{{ foo }}'], templar=templar) == ['a', 'b', '{{ foo }}']

    # test with a list with a list in it
    assert listify_lookup_plugin_terms(terms=['a', 'b', ['c', 'd']], templar=templar) == ['a', 'b', ['c', 'd']]

    # test with a template string
    assert listify_lookup

# Generated at 2022-06-23 14:21:06.441464
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    env = {
        'omit_token': False,
        'vars': {
            'z': 'bar'
        }
    }

    templar = Templar(loader=None, variables=env)
    # Assert that strings are successfully returned as a list
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    # Assert that lists are left intact
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']
    # Assert that if a list contains a string, the string is templated
    assert listify_lookup_plugin_terms(['foo', '{{ z }}'], templar, None) == ['foo', 'bar']
    # Assert that if a list contains

# Generated at 2022-06-23 14:21:08.036989
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Test function listify_lookup_plugin_terms
    """
    pass

# Generated at 2022-06-23 14:21:16.481067
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import json
    import jinja2

    terms = [ "{{", "foo", "}}" ]
    templar = jinja2.Template("{{ terms[0] }}")

    # Avoid being overly chatty
    old_display_skipped_hosts = None


# Generated at 2022-06-23 14:21:25.718593
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY2

    # test setup
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)

    result = listify_lookup_plugin_terms(u'test_name', templar, loader)

    # TODO: figure out why PY3 returns [u'test_name']
    # while PY2 returns ['test_name']
    if PY2:
        expected = [u'test_name']
    else:
        expected = [u'test_name']

    assert result == expected, "%s != %s" % (result, expected)

# Generated at 2022-06-23 14:21:37.128661
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.template import Templar

    import yaml
    data = """
    foo:
    - 1
    - 2
    bar: 3
    baz:
      - 4
      - 5
    """
    data_stream = StringIO(data)
    data = yaml.safe_load(data_stream)
    vault_pass = 'secret'
    loader, inventory, variable_manager = (None, None, None)
    templar = Templar(loader=loader, variables=variable_manager.get_vars(loader=loader, inventory=inventory))

    # Test single term

# Generated at 2022-06-23 14:21:47.087167
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    lookup_loader = DummyLoader()
    lookup_loader.path_dwim = lambda x: 'dummy-path'

    class DummyVarsModule:
        pass

    t = Templar(loader=DummyLoader(), variables=DummyVarsModule())

    def _test_listify_lookup_plugin_terms(terms, expected):

        actual = listify_lookup_plugin_terms(terms, t, lookup_loader, convert_bare=False)

        assert actual == expected, actual

    # simple string
    _test_listify_lookup_plugin_terms('foo', ['foo'])
    _test_listify_lookup_plugin_terms('1', ['1'])

    # list of strings

# Generated at 2022-06-23 14:21:57.989374
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ds = DataLoader()
    v = VariableManager(loader=ds)
    t = Templar(vars=v, loader=ds)

    assert listify_lookup_plugin_terms('hello', t, ds) == ['hello']
    assert listify_lookup_plugin_terms('hello world', t, ds) == ['hello world']

    assert listify_lookup_plugin_terms(['hello', 'world'], t, ds) == ['hello', 'world']

# Generated at 2022-06-23 14:22:06.058699
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # test simple string
    assert listify_lookup_plugin_terms('a', None, None) == ['a']

    # test simple list
    assert listify_lookup_plugin_terms(['a','b','c'], None, None) == ['a','b','c']

    # test list in a variable
    assert listify_lookup_plugin_terms('{{ foo }}', None, None, convert_bare=True) == ['{{ foo }}']

    # test list in a variable being passed in
    assert listify_lookup_plugin_terms(['{{ foo }}'], None, None) == ['{{ foo }}']

    # test bare variable
    assert listify_lookup_plugin_terms('{{ foo }}', None, None) == ['{{ foo }}']

    # test bare variable in a list
    assert listify_lookup_

# Generated at 2022-06-23 14:22:17.294538
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.config.manager import ConfigManager

    config_manager = ConfigManager()
    variable_manager = VariableManager(loader=None, inventory=InventoryManager(config_manager=config_manager))
    templar = Templar(loader=None, variable_manager=variable_manager)

    test = [1, 2, 3]
    assert listify_lookup_plugin_terms(test, templar, None) == [1, 2, 3]

    test = "{{ ansible_hostname }}"
    assert listify_lookup_plugin_terms(test, templar, None, fail_on_undefined=False) == [u'localhost']


# Generated at 2022-06-23 14:22:28.332781
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    mock_loader = object()
    terms = 'foo'
    templar = Templar(mock_loader, variables={'bar': 'foo'})
    results = listify_lookup_plugin_terms(terms, templar, mock_loader)

    assert results == ['foo']

    terms = ['foo', 'bar']
    templar = Templar(mock_loader, variables={'bar': 'foo'})
    results = listify_lookup_plugin_terms(terms, templar, mock_loader)

    assert results == ['foo', 'bar']

    terms = ['bar', '{{bar}}']
    templar = Templar(mock_loader, variables={'bar': 'foo'})

# Generated at 2022-06-23 14:22:39.422296
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Test that a single string is converted to a list
    templar = Templar(loader=DataLoader())
    term = "my_var"
    result = listify_lookup_plugin_terms(term, templar, DataLoader())
    assert len(result) == 1
    assert result[0] == 'my_var'

    # Test that a single string is converted to a list
    term = "{{ my_var }}"
    result = listify_lookup_plugin_terms(term, templar, DataLoader())
    assert len(result) == 1
    assert result[0] == 'my_var'

    # Test that a single string is converted to a list

# Generated at 2022-06-23 14:22:39.964863
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:22:50.963886
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    my_vars = dict(s='string_thing', d='default_thing')
    my_loader = DataLoader()
    my_var_manager = VariableManager()
    my_var_manager.set_inventory(my_loader.load_from_file('tests/inventory'))
    my_var_manager.set_vars(my_loader.load_from_file('tests/vars/vars_file.yml'))
    my_var_manager.set_nonpersistent_facts(my_vars)
    my_templar = Templar(loader=my_loader, variables=my_var_manager)


# Generated at 2022-06-23 14:22:57.975313
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Configure templar and loader
    templar = dict()
    templar.template = lambda x, convert_bare=False, fail_on_undefined=False: x
    loader = dict()

    # test listify_lookup_plugin_terms
    assert listify_lookup_plugin_terms('first', templar, loader) == ['first']
    assert listify_lookup_plugin_terms(['first'], templar, loader) == ['first']
    assert listify_lookup_plugin_terms([' first '], templar, loader) == [' first ']
    assert listify_lookup_plugin_terms([' first ', ' second '], templar, loader) == [' first ', ' second ']


# Test listify_lookup_plugin_terms directly with pytest

# Generated at 2022-06-23 14:23:09.274631
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 14:23:20.398196
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = '1 2 3'
    templar = Templar()
    result = listify_lookup_plugin_terms(terms, templar)
    assert result == ['1', '2', '3']

    terms = [1, 2, 3]
    result = listify_lookup_plugin_terms(terms, templar)
    assert result == [1, 2, 3]

    terms = ['1', '2', '3']
    result = listify_lookup_plugin_terms(terms, templar)
    assert result == ['1', '2', '3']

    # Test bare string conversion
    terms = "{{ '1' }}"
    result = listify_lookup_plugin_terms(terms, templar, convert_bare=True)

# Generated at 2022-06-23 14:23:28.608683
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = listify_lookup_plugin_terms([u'{{ [ foo, bar ] }}'],
                                        Templar(loader=None, variables={'foo': u'fooval', 'bar': u'barval'}),
                                        loader=None, fail_on_undefined=True)
    assert type(terms) == list, "terms should now be a list object"
    assert terms == [u'fooval', u'barval'], \
        "terms should now be a list with two items"


# Generated at 2022-06-23 14:23:37.071403
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class test_class_template:
        def template(self, value, fail_on_undefined=True, convert_bare=False):
            return [value, value * 2]

    class test_class_loader:
        pass

    templar = test_class_template()
    loader = test_class_loader()

    value = 42

    assert listify_lookup_plugin_terms(value, templar, loader) == [value, value * 2]
    assert listify_lookup_plugin_terms([value], templar, loader) == [value, value * 2]
    assert listify_lookup_plugin_terms([value, value * 2], templar, loader) == [value, value * 2, value * 4]


# Ignore PyFlakesBear
del test_listify_lookup_plugin_terms

# Generated at 2022-06-23 14:23:45.464549
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # setup
    terms = ['item1', 'item2', '{{item3}}', '{{ item4 }}', ['item5', 'item6', '{{item7}}', '{{ item8 }}']]
    templar = Templar()

    # invoke
    result = listify_lookup_plugin_terms(terms, templar, None)

    # assert
    assert result == ['item1', 'item2', '{{item3}}', '{{ item4 }}', 'item5', 'item6', '{{item7}}', '{{ item8 }}']


# Generated at 2022-06-23 14:23:56.381365
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.module_utils.common.removed
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.template import Jinja2TemplateModule
    from ansible.parsing.dataloader import DataLoader

    # These have to be loaded the same way as the main ansible process
    # so that the jinjatemplate is in the same state.
    jinja_templar = Templar(loader=DataLoader(), variables={})
    jinja_templar.set_available_variables({'var': 'string'})

    tm = Jinja2TemplateModule()
    tm.environment = jinja_templar._available_variables

    templar = Templar(loader=DataLoader(), variables={})
    templar._available_variables

# Generated at 2022-06-23 14:24:06.168936
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms('one', Templar(variables={}), None, fail_on_undefined=False) == ['one']
    assert listify_lookup_plugin_terms(['one', 'two'], Templar(variables={}), None, fail_on_undefined=False) == ['one', 'two']

    assert listify_lookup_plugin_terms('{{ one }}', Templar(variables={'one': 'two'}), None, fail_on_undefined=False) == ['two']
    assert listify_lookup_plugin_terms('{{ one }}', Templar(variables={'one': ['two', 'three']}), None, fail_on_undefined=False) == ['two', 'three']

# Generated at 2022-06-23 14:24:14.026021
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml.add_constructor(u'tag:yaml.org,2002:str', str)
    class TestTemplar(Templar):
        def __init__(self, variables=None, loader=None):
            self._available_variables = variables or dict()
            self._loader = loader

        def available_variables(self):
            return self._available_variables

        def set_available_variables(self, variables):
            self._available_variables = variables

    class TestLoader(AnsibleLoader):
        def __init__(self, base_class):
            self._base_class = base_class


# Generated at 2022-06-23 14:24:24.679302
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert listify_lookup_plugin_terms("item1", None, None) == ['item1']
    assert listify_lookup_plugin_terms("item1,item2", None, None) == ['item1', 'item2']
    assert listify_lookup_plugin_terms(["item1", "item2"], None, None) == ['item1', 'item2']
    assert listify_lookup_plugin_terms("item1|item2", None, None) == ['item1', 'item2']

    assert listify_lookup_plugin_terms("{{ item }}", None, None) == ['{{ item }}']

# Generated at 2022-06-23 14:24:33.774860
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Treat the below ``_`` variables as the results of calls to templar.template()
    #
    # _.__class__ represents the type of the expected results, so the following
    # three lines mean that the test expects templar.template() to return a list.
    _ = None
    _.__class__ = list
    _._type_name = "list"

    # The below tests mirror the assertions in the function listify_lookup_plugin_terms.
    #
    # The tests are organized in three columns:
    # 1. The input argument that is given to listify_lookup_plugin_terms()
    # 2. The expected results from templar.template()
    # 3. The expected results from listify_lookup_plugin_terms()
    #
    # Please note that the expected results in column 2 can be fals

# Generated at 2022-06-23 14:24:45.018022
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test listify_lookup_plugin_terms with bare=False
    import os
    import tempfile
    from ansible.module_utils.six import StringIO
    from ansible.utils.display import Display
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory, Host, Group
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    templar = Templar(loader=DataLoader(), variables=VariableManager(), shared_loader_obj=None)
    variable_manager = VariableManager()
    loader = DataLoader()

    # create a test inventory
    test_inventory_file = tempfile.NamedTemporaryFile(mode='r', delete=False)

# Generated at 2022-06-23 14:24:53.814645
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DictDataLoader({})
    variables = VariableManager()
    templar = Templar(loader=loader, variables=variables)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']

    # Test list with template
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, loader) == ['bar']

    # Test dict with template
    assert listify_lookup_plugin_terms({'key': '{{ foo }}'}, templar, loader) == [{'key': 'bar'}]

   

# Generated at 2022-06-23 14:25:03.617541
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Replacements to use in tests
    sandbox = dict(a='alpha', b='bravo', c='charlie',
                   list_a='a,b,c', list_b='a, b, c', list_c='[a,b,c]',
                   list_d='[a, b, c]', list_e='a,b,c', list_f='[ a, b, c ]')
    # Create the templar so we can use it
    from ansible.template import Templar
    templar = Templar(loader=None, variables=sandbox)

    # Cases that should return a list of strings

# Generated at 2022-06-23 14:25:15.345912
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    loader = None
    templar = None

    # single term string
    assert listify_lookup_plugin_terms('item', templar, loader) == ['item']
    assert listify_lookup_plugin_terms('item\n', templar, loader) == ['item']

    # multi term string
    assert listify_lookup_plugin_terms('item1\nitem2', templar, loader) == ['item1', 'item2']
    assert listify_lookup_plugin_terms('item1\nitem2\n', templar, loader) == ['item1', 'item2']

    # list terms
    assert listify_lookup_plugin_terms(['item1', 'item2'], templar, loader) == ['item1', 'item2']
    assert listify_lookup_plugin

# Generated at 2022-06-23 14:25:25.117454
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    terms = ['{{ blah }}', '{{ foo }}']
    variables = MutableMapping()
    variables.update({'blah': 'one', 'foo': 'two'})

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = variables
    variable_manager.options_vars = variables
    variable_manager.set_available_variables(loader=loader, play=MutableMapping())

    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-23 14:25:37.205126
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.module_utils.six import iteritems as items
    else:
        from ansible.module_utils.six import items

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    from ansible.playbook.play_context import PlayContext

    # Create an empty play context
    context = PlayContext()
    context._vault = VaultLib([])

    # Create an empty templar
    templar = Templar(loader=None, variables={}, fail_on_undefined=True, vault_secrets=context._vault.secrets)

    # Test the various term formats
    from ansible.module_utils._text import to_native


# Generated at 2022-06-23 14:25:43.997045
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import lookup_loader

    # Dummy class to test the function using it's public methods
    class DummyLookupPlugin:

        def __init__(self, basedir, runner):
            self.basedir = basedir
            self.runner = runner
            self.vars = self.runner.vars
            self.templar = Templar(loader=self.runner.loader, variables=self.vars)

    # Initialize objects
    vault_secret = 'dont_want_to_commit_this'
    vault_password = VaultLib(vault_secret)

# Generated at 2022-06-23 14:25:51.833710
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 1, 'b': 2, 'c': 'a string', 'd': [1, 2, 3]}
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{a}}', templar, loader) == [1]
    assert listify_lookup_plugin_terms([1, 2], templar, loader) == [1, 2]

# Generated at 2022-06-23 14:26:02.530871
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader

    from ansible.plugins.lookup import LookupBase
    lu = LookupBase()
    lu.set_loader(DataLoader())

    t = lu._templar

    assert listify_lookup_plugin_terms('1', t, lu.loader, convert_bare=True) == [u'1']
    assert listify_lookup_plugin_terms(['1', '2'], t, lu.loader) == [u'1', u'2']
    assert listify_lookup_plugin_terms(3, t, lu.loader) == [3]
    assert listify_lookup_plugin_terms(u'{{foo}}', t, lu.loader, convert_bare=True) == [u'{{foo}}']


# Generated at 2022-06-23 14:26:12.735477
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Tests with no templar
    assert(listify_lookup_plugin_terms('one', None, None) == ['one'])
    assert(listify_lookup_plugin_terms('one two', None, None) == ['one two'])
    assert(listify_lookup_plugin_terms('one two three', None, None) == ['one two three'])

    # Tests with templar
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts({'foo': 'bar'})
    templar = Templar(loader=None, variables=variable_manager)

    assert(listify_lookup_plugin_terms('one', templar, None) == ['one'])

# Generated at 2022-06-23 14:26:20.225651
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Empty term
    assert listify_lookup_plugin_terms(None, Templar({}, {}, {})) == list()

    # Single term
    assert listify_lookup_plugin_terms("", Templar({}, {}, {})) == [""]

    # Multiple temrs in a list
    assert listify_lookup_plugin_terms(["a", "b"], Templar({}, {}, {})) == ["a", "b"]


if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-23 14:26:20.862316
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:26:28.827541
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    # Dummy vars
    variables = dict(
        foo='bar',
        baz=42,
        a_list=[1, 2, 3],
        a_dict={
            'foo': 'bar'
        }
    )

    # Test vaults

# Generated at 2022-06-23 14:26:40.306614
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = [ 'foo', [ 'bar', 'baz' ] ]
    templar = Templar(loader=None)
    results = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=False, convert_bare=False)
    assert results[0] == 'foo'
    assert results[1][0] == 'bar'

    terms = [ 'foo', '{{ bar }}' ]
    templar = Templar(loader=None, variables={'bar': 'baz'})
    results = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=False, convert_bare=False)
    assert results[0] == 'foo'
    assert results[1] == 'baz'

# Generated at 2022-06-23 14:26:52.086564
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    def strip_prefixes(s):
        if s.startswith('u"') or s.startswith("u'"):
            s = s[1:]
        return s

    assert strip_prefixes(str(listify_lookup_plugin_terms('string', Templar(VariableManager())))) == u'["string"]'
    assert strip_prefixes(str(listify_lookup_plugin_terms(['string', 'other'], Templar(VariableManager())))) == u'["string", "other"]'

# Generated at 2022-06-23 14:27:03.658233
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_inventory('localhost,'))
    templar = Templar(loader=loader, variables=variable_manager)

    # test with bare string
    assert listify_lookup_plugin_terms('foo', templar, loader, fail_on_undefined=True) == ['foo']

    # test with quoted string with no quotes
    assert listify_lookup_plugin_terms('"foo"', templar, loader, fail_on_undefined=True) == ["foo"]

    # test with quoted string with quotes

# Generated at 2022-06-23 14:27:10.603234
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Test the listify_lookup_plugin_terms function (that is only used by lookup plugins)
    with, string, list and dict.
    '''

    import yaml
    from ansible.parsing.vault import VaultLib

    from ansible.errors import AnsibleParserError
    from ansible.template import Templar

    from ansible.template.template import AnsibleTemplate
    from ansible.template.safe_eval import safe_eval
    from ansible.plugins import vars_loader

    from units.mock.vault import mock_vault_secret

    class TestVaultSecret(object):
        def __init__(self):
            self.vault_secret = mock_vault_secret()


# Generated at 2022-06-23 14:27:18.036593
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    class FakeVarsModule:
        def __init__(self, foo, test=None):
            self.foo = foo
            self.test = test

        def get_vars(self, loader, play, host=None, task=None, include_deps=True):
            return self.foo if host is None else self.test if task is None else {}

    # No templating, no conversion
    t = Templar(loader=loader)


# Generated at 2022-06-23 14:27:26.418861
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager

    # test bare strings
    terms = "{{ 'item1', 'item2' }}"

    templar = Templar(loader=None, variables=VariableManager())
    res = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert res == [u'item1', u'item2']

    # test bare strings
    terms = "{{ item1 }}"

    templar = Templar(loader=None, variables=VariableManager())
    res = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert res == [u'item1']

    # test list
    terms = ['item1', 'item2']
