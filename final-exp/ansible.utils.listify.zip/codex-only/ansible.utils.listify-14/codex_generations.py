

# Generated at 2022-06-23 14:17:31.900937
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # Test a plain string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, Templar(loader=DataLoader()), DataLoader()) == ['foo']

    # Test a string that has a comma separated list
    terms = 'foo, bar'
    assert listify_lookup_plugin_terms(terms, Templar(loader=DataLoader()), DataLoader()) == ['foo', 'bar']

    # Test a python list
    terms = ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms, Templar(loader=DataLoader()), DataLoader()) == ['foo', 'bar']

    # Test a variable string
    terms = '{{ foo }}'
    assert listify_lookup_plugin

# Generated at 2022-06-23 14:17:40.143313
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Test for a string with no commas
    Test for a string with a comma
    Test for a string with mixed commas and colon
    Test for a list with no commas
    Test for a list with a comma
    Test for a list with mixed commas and colon
    '''

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common._collections_compat import Set
    from ansible.parsing import vault
    from ansible.template import Templar

    v = vault.VaultLib(None, None)


# Generated at 2022-06-23 14:17:47.543846
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms('/tmp/{{ foo }}', templar, None) == ['/tmp/{{ foo }}']
    assert listify_lookup_plugin_terms(42, templar, None) == [42]
    assert listify_lookup_plugin_terms([42], templar, None) == [42]
    assert listify_lookup_plugin_terms(['42'], templar, None) == ['42']

# Generated at 2022-06-23 14:17:56.215725
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = ['a', 'b', 'c']
    templar = Templar(loader=None, variables={})
    listify_lookup_plugin_terms(terms, templar)

    terms = """\
        {%- if foo %}
            {{ foo }}
        {%- else %}
            d
        {%- endif %}
        """

    templar = Templar(loader=None, variables={})
    listify_lookup_plugin_terms(terms, templar)

    terms = "a"
    templar = Templar(loader=None, variables={})
    assert isinstance(listify_lookup_plugin_terms(terms, templar), list)

# Generated at 2022-06-23 14:18:07.589477
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    # Setup vault secret to decrypt stuff
    vault_secret = VaultLib([])
    vault_secret.read_vault_secret_file('ansible-vault-password')

    # Test a simple string
    template = "{{ var }}"
    myvar = "my-value"
    templar = Templar(loader=None,shared_loader_obj=None, variables={'var': myvar}, vault_secrets=[vault_secret])
    out = listify_lookup_plugin_terms(template, templar=templar, loader=None)
    assert isinstance(out, list), "Should be a list: %s" % out

# Generated at 2022-06-23 14:18:19.677754
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import template
    from ansible.template import Templar

    terms0 = ['a', 'b', 'c']
    terms1 = """
    {{ myvar }}
    """
    terms2 = """
    {{ myvar | join(' ') }}
    """
    terms3 = """
    {{ myvar | join(' ') }}
    """
    terms4 = '{{ myvar }}'

    env = template.Environment(loader=template.AnsibleFileSystemLoader('.'))
    loader = env.loader
    templar = Templar(loader=loader, variables={'myvar': ['a', 'b', 'c']})

    assert listify_lookup_plugin_terms(terms0, templar, loader) == ['a', 'b', 'c'], 'with list'
    assert listify_lookup_plugin_

# Generated at 2022-06-23 14:18:29.753461
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # import needed objects
    from ansible.template import Templar
    from ansible.template.vars import VarsModule
    from ansible.template.safe_eval import safe_eval
    from ansible.module_utils.facts import Facts

    # create needed objects
    templar = Templar(loader=None, variables={})
    vars_m = VarsModule(loader=templar)

    # set a fact
    v = vars_m._fact_cache = Facts({"foo": "bar"})

    # assert correct handling for string terms
    terms = listify_lookup_plugin_terms('{{foo}}', templar, loader=None)
    assert (terms == ['bar'])

    # assert correct handling for string terms with convert_bare=True

# Generated at 2022-06-23 14:18:38.386091
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    import jinja2
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a fake task object to pass as a lookup plugin param
    class Task(object):
        pass

    # Create a fake loader object to pass as a lookup plugin param
    class FakeLoader(object):
        pass

    # Create a fake play context object to pass as a lookup plugin param
    class PlayContext(object):
        pass

    # Create a fake inventory object to pass as a lookup plugin param
    class Inventory(object):
        pass

    # Create a real templar that we can use to test listify_lookup_plugin_terms

# Generated at 2022-06-23 14:18:45.651386
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert listify_lookup_plugin_terms('hello', None, None, False) == ['hello']
    assert listify_lookup_plugin_terms(['hello', 'world'], None, None, False) == ['hello', 'world']
    assert listify_lookup_plugin_terms(
        [u'hello', u'world'], None, None, False
    ) == [u'hello', u'world']
    assert listify_lookup_plugin_terms(
        [AnsibleUnsafeText(u'hello'), AnsibleUnsafeText(u'world')],
        None, None, False
    ) == [AnsibleUnsafeText(u'hello'), AnsibleUnsafeText(u'world')]

# Generated at 2022-06-23 14:18:52.462355
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test string input
    terms = 'foo'
    templar = AnsibleUnsafeText('foo')

    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo']

    # Test list input
    terms = ['foo', 'bar']
    templar = ['foo', 'bar']

    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo', 'bar']

    # Test input that is neither string nor list
    terms = AnsibleUnsafeText('foo')
    templar = 'foo'

    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo']

# Generated at 2022-06-23 14:19:02.675482
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class DummyVarsModule:
        ''' Dummy vars module for unit testing '''

        class DummyVars:
            def __init__(self, vars):
                self.vars = vars

            def get(self, key):
                return self.vars[key]

    class DummyTemplar:
        ''' Dummy Templar for unit testing '''

        def __init__(self):
            self.vars = DummyVarsModule.DummyVars({})

        def set_available_variables(self, vars):
            ''' Update available template variables '''
            self.vars = DummyVarsModule.DummyVars(vars)


# Generated at 2022-06-23 14:19:11.633723
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources='localhost,'))
    variable_manager.extra_vars = {'test_var': 'bar'}
    variable_manager.options_vars = {'nocows': True}

# Generated at 2022-06-23 14:19:14.323583
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    (failed, total) = doctest.testmod()
    if failed > 0:
        module.fail_json(msg='Failed %s tests' % failed, changed=False)

# Generated at 2022-06-23 14:19:24.813009
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ lookup_terms }}')))
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 14:19:33.181630
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    class FakeVarsModule(object):
        def __init__(self):
            self.vars = {'fruit': 'banana', 'list1': ['one', 'two', 'three']}

    class FakeLoader(object):
        def __init__(self):
            self.vars = {}

        def get_basedir(self, play=None):
            return "/dev/null"

    class FakeInventory(object):
        def __init__(self):
            self.hosts = {}
            self.groups = {}
            self.get_host = None
            self.get_group = None
            self.get_host_vars = None
            self.get_group_vars = None

    t

# Generated at 2022-06-23 14:19:44.708076
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.config.manager import ConfigManager
    from ansible.plugins.loader import lookup_loader, module_loader

    config_mgr = ConfigManager(
        vault_password_files=['vault_passwords.yml'],
        loader=loader,
    )

    templar = Templar(
        vault_secrets=VaultLib(password_files=['vault_passwords.yml'],
                               config_mgr=config_mgr),
        config_mgr=config_mgr,
        loader=loader,
    )

    terms = '{{items}}'
    #template output is a string
    expected_value = {u"one", "two", "three"}
    result = listify_

# Generated at 2022-06-23 14:19:51.328543
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms('abc', templar=Templar(), loader=None) == ['abc']
    assert listify_lookup_plugin_terms(['abc'], templar=Templar(), loader=None) == ['abc']
    assert listify_lookup_plugin_terms(1, templar=Templar(), loader=None) == [1]
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], templar=Templar(), loader=None) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:20:02.920910
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class FakeTemplar(object):
        def __init__(self, val):
            self.val = val

        def template(self, *args, **kwargs):
            return self.val

        def is_fail_on_undefined_error(self):
            return True

    class FakeLoader(object):
        pass


# Generated at 2022-06-23 14:20:13.854415
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        hostvars=dict(
            host0=dict(
                ansible_host='host0',
                foo='foo',
                n=0,
            ),
            host1=dict(
                ansible_host='host1',
                bar='bar',
                n=1,
            ),
        )
    )
    variable_manager.set_inventory(inventory=variable_manager.get_inventory())

    templar = Templar(loader=None, variables=variable_manager)


# Generated at 2022-06-23 14:20:23.695873
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    data = {
        "acme_var": "acme_value",
        "acme_list": ["acme_list1", "acme_list2"],
        "acme_dict": {"acme_key": "acme_dict_val"},
        "acme_none": None,
    }
    variable_manager = VariableManager()
    variable_manager.extra_vars = data
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)
    assert listify_lookup_plugin_terms("{{ acme_var }}", templar, loader) == ["acme_value"]

# Generated at 2022-06-23 14:20:35.345069
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar

    class DummyVarsModule:
        def __init__(self, data):
            self.vars = data

    data = """
    foo:
      - 1
      - 2
      - 3
    bar:
      - 4
      - 5
      - 6
    baz:
      - 7
      - 8
      - 9
    """

    fake_loader = AnsibleLoader(None, {}, StringIO(data))

    terms = '{{ foo }}'
    templar = Templar(loader=fake_loader, variables=DummyVarsModule(fake_loader.get_single_data()))
    result = listify_lookup_plugin_terms

# Generated at 2022-06-23 14:20:43.802576
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    vm = VariableManager()
    vm.extra_vars = {'a': 'foo'}
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=vm,host_list=[])
    play_context = PlayContext()

    from ansible.template import Templar
    templar = Templar(loader=loader, inventory=inventory, variable_manager=vm)

    terms = '{{a}}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo']

    terms = [ 'a', 'b' ]
    result = list

# Generated at 2022-06-23 14:20:51.898374
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import jinja2
    from ansible.template import Templar
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    # Setup simple jinja2 environment and templar
    jenv = jinja2.Environment(undefined=jinja2.StrictUndefined)
    jenv.filters['to_json'] = lambda v: v
    jenv.filters['from_yaml'] = lambda v: v
    jenv.filters['to_yaml'] = lambda v: v
    jenv.filters['to_nice_yaml'] = lambda v: v
    templar = Templar(loader=None, shared_loader_obj=None, variables={})

    # Create test cases for listify_look

# Generated at 2022-06-23 14:21:01.810027
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    lookup_loader = DataLoader()
    templar = Templar(loader=lookup_loader)

    # test string to list conversion
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', templar, None) == ['foo', 'bar']

    # test template rendering on a string
    assert listify_lookup_plugin_terms('{{foo}} bar', templar, None, convert_bare=True) == ['{{foo}}', 'bar']

    # test list untouched
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']

# Generated at 2022-06-23 14:21:11.640719
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Note: In this test case we are only testing the listify_lookup_plugin_terms function
    #       and not the Jinja2 templating.  The Jinja2 templating is already fully tested
    #       in other unit tests.

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'key2': ['item3', 'item4']}
    variables = variable_manager.get_vars(loader=loader, play=None)
    templar = Templar(loader=loader, variables=variables)


# Generated at 2022-06-23 14:21:22.454015
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.parsing.yaml.objects
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    terms = []
    templar = DummyVarsModule()
    loader = DummyVarsModule()

    # Test with string argument
    terms = 'foo'
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert results == ['foo']
    results = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)
    assert isinstance(results[0], AnsibleUnsafeText)

    # Test with list argument
    terms = ['{{ foo }}', '{{ bar }}']

# Generated at 2022-06-23 14:21:28.797338
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import os
    import random

    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    test_dir = os.path.dirname(os.path.realpath(__file__))
    fixture_path = os.path.join(test_dir, 'unit', 'utils', 'lookup_fixtures', 'listify_lookup_plugin_terms')
    lookup_terms = open(os.path.join(fixture_path, 'test_code.py')).read()

    test_vars = dict(
        randint=random.randint(1,1000000),
        lookup_terms=lookup_terms,
    )
    templar = Templar(loader=None, variables=test_vars)
    templar._basedir = fixture_path

    terms = listify

# Generated at 2022-06-23 14:21:38.943936
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test that a string is converted to a list
    assert listify_lookup_plugin_terms("foo", templar, loader) == ['foo']

    # Test that a list is passed through unchanged
    assert listify_lookup_plugin_terms(["foo", "bar"], templar, loader) == ['foo', 'bar']

    # Test that a template string is converted to a

# Generated at 2022-06-23 14:21:45.557029
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    vault_pass = 'anyvaultpass'
    vault_secret = 'anysecret'
    loader = DataLoader()

    v = VaultLib([])
    t = Templar(loader=loader, variables={'foo': 'bara'}, vault_secrets=[v], converters={'regexp': regexp})

    test_terms = '{{foo}}'
    result = listify_lookup_plugin_terms(test_terms, t, loader)
    assert result == ['bara'], result

    test_terms = ['{{foo}}']
    result = listify_lookup_plugin_terms(test_terms, t, loader)

# Generated at 2022-06-23 14:21:56.131675
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())

    terms = ['foo', 'bar', 'baz']
    assert(listify_lookup_plugin_terms(terms, templar, None) == ['foo', 'bar', 'baz'])

    terms = ['foo', 'bar', 'baz', ['qux']]
    assert(listify_lookup_plugin_terms(terms, templar, None) == ['foo', 'bar', 'baz', ['qux']])

    terms = ['foo', 'bar', 'baz', {'qux': 'quux'}]

# Generated at 2022-06-23 14:22:04.898046
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Single items are converted to a list
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    # Already a list is not altered
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    # Playbook templating is applied
    assert list

# Generated at 2022-06-23 14:22:16.224037
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import safe_eval
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    # Loader is required for the Templar class
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)
    templar.environment.globals['AnsibleUnsafeText'] = AnsibleUnsafeText

    assert listify_lookup_plugin_terms(None, templar, loader) == [None]
    assert listify_lookup_plugin_terms([1, 2, 3], templar, loader) == [1, 2, 3]
    assert listify_lookup_plugin_terms("1", templar, loader) == ['1']

# Generated at 2022-06-23 14:22:28.163095
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    import sys

    # get a mocked variables object
    test_vars = AnsibleMapping({'test':42, 'test_array': [1,2,3], 'test_array_2':[{'test_key':42}, {'test_key_2':'{{test}}'}]})
    templar = Templar(loader=AnsibleLoader(None, variable_manager=None, loader_class=None))
    templar._available_variables = test_vars

    # test a single term

# Generated at 2022-06-23 14:22:39.261231
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    t = Templar()
    assert listify_lookup_plugin_terms(["a", "b", "c"], t, None) == ["a", "b", "c"]
    assert listify_lookup_plugin_terms(iter(["a", "b", "c"]), t, None) == ["a", "b", "c"]
    assert listify_lookup_plugin_terms((["a", "b", "c"]), t, None) == ["a", "b", "c"]
    assert listify_lookup_plugin_terms(AnsibleUnsafeText("a\nb\nc"), t, None) == ["a", "b", "c"]

# Generated at 2022-06-23 14:22:50.250180
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(None, loader=None)

    my_list = listify_lookup_plugin_terms(u'{{ my_var }}', templar, loader=None)
    assert my_list == [u'{{ my_var }}']

    my_list = listify_lookup_plugin_terms(u'{{ my_var }}', templar, loader=None, convert_bare=True)
    assert my_list == [u'{{ my_var }}']

    my_list = listify_lookup_plugin_terms([u'element1', u'element2'], templar, loader=None)
    assert my_list == [u'element1', u'element2']


# Generated at 2022-06-23 14:22:56.554757
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class DummyVarsModule:
        def __init__(self, a=1, b=2, c=3, d=4):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    terms = [1, "{{ a }}", [3, "{{ b }}"]]

    templar = Templar(loader=None, variables=DummyVarsModule())
    new_terms = listify_lookup_plugin_terms(terms=terms, templar=templar, loader=None)

    assert new_terms == [1, 1, [3, 2]]

# Generated at 2022-06-23 14:23:01.825659
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # Check that both string and list of strings input results in list of strings output
    assert listify_lookup_plugin_terms('default', Templar(loader=None)) == ['default']
    assert listify_lookup_plugin_terms(['default1', 'default2'], Templar(loader=None)) == ['default1', 'default2']

    # Check that both string and list of strings input returns a list of strings that has been templated
    assert listify_lookup_plugin_terms('{{ lookup("env", "HOME") }}', Templar(loader=None)) == ['{{ lookup("env", "HOME") }}']
    assert listify_lookup_plugin_terms(['{{ lookup("env", "HOME") }}'], Templar(loader=None)) == ['{{ lookup("env", "HOME") }}']

    # Check

# Generated at 2022-06-23 14:23:08.332633
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible import context

    t = Templar(variables={'a': 'foo',
                           'b': 'bar',
                           'c': ['one', 'two', 'three'],},
                loader=None)

    assert listify_lookup_plugin_terms('{{a}}', t, None) == ['foo']
    assert listify_lookup_plugin_terms('{{a}}/{{b}}', t, None) == ['foo/bar']
    assert listify_lookup_plugin_terms('foo/{{a}}/{{b}}', t, None) == ['foo/foo/bar']
    assert listify_lookup_plugin_terms('{{c}}', t, None) == ['one', 'two', 'three']

# Generated at 2022-06-23 14:23:19.057161
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.module_utils.common.collections as collections_compat
    import ansible.template.safe_eval

    class MockTemplate:
        def __init__(self):
            self.template_data = {
                'Foo': 'BAR'
            }

        def template(self, data, convert_bare=False, fail_on_undefined=True):
            if isinstance(data, collections_compat.Mapping):
                for item in data.keys():
                    data[item] = self.template(data[item], convert_bare=convert_bare, fail_on_undefined=fail_on_undefined)
                return data

# Generated at 2022-06-23 14:23:27.648833
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar

    test_vars = dict(a=dict(b=dict(c='x', d='y')))
    templar = Templar(loader=None, variables=test_vars)
    assert isinstance(listify_lookup_plugin_terms(['{{ a.b.c }}', '{{ a.b.d }}'], templar=templar, loader=None), Sequence)
    assert isinstance(listify_lookup_plugin_terms('{{ a.b.c }}, {{ a.b.d }}', templar=templar, loader=None), Sequence)

# Generated at 2022-06-23 14:23:36.814139
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.vars import VariableManager

    display = Display()
    loader = None
    variable_manager = VariableManager()
    variable_manager.extra_vars = combine_vars(loader=loader, variables=dict())

    data = 'foo bar baz'

# Generated at 2022-06-23 14:23:47.005737
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vlt = VaultLib([])
    templar = Templar(loader=loader, variables={}, vault_secrets=vlt)

    assert listify_lookup_plugin_terms('hello', templar, loader) == ['hello']
    assert listify_lookup_plugin_terms(['hello'], templar, loader) == ['hello']
    assert listify_lookup_plugin_terms(['hello', 'world'], templar, loader) == ['hello', 'world']


# Generated at 2022-06-23 14:23:57.251015
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    def get_basedir(self, vars):
        return '/'

    variable_manager.get_basedir = get_basedir.__get__(variable_manager)
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}

    templar = Templar(loader=loader, variable_manager=variable_manager)
    terms = '{{gimme_a_list}}'

    variable_manager.set_nonpersistent_facts(dict(gimme_a_list=[1, 2, 3]))
    result = listify_lookup_plugin_terms

# Generated at 2022-06-23 14:24:07.528806
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts({'test_fact': "test_value"})
    templar = Templar(loader=None, variables=variable_manager)
    terms = u'{{ "test_value" }}'
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['test_value']
    terms = [u'{{ "test_value" }}', u'{{ test_fact }}']
    result = listify_lookup_plugin_terms(terms, templar, None)

# Generated at 2022-06-23 14:24:17.878138
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.template import Jinja2TemplateModule, AnsibleJ2TemplateModule

    class FakeVarsModule:
        def get_vars(inner_self, loader, path, entities):
            return entities

    class FakeHost:
        vars = FakeVarsModule()

        def get_name(self):
            return "foonode"

    terms = "[ u'first', u'second', 'third', '{\"fourth\": true}' ]"
    terms_unquoted = "[ 'first', 'second', 'third', '{\"fourth\": true}' ]"
    terms_dict = "{ 'key1': 'val1', 'key2': [ u'val2', 'val3' ] }"


# Generated at 2022-06-23 14:24:29.153676
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars
    import sys

    if sys.version_info[0] > 2:
        unicode = str

    class VariableManagerHack(VariableManager):
        def __init__(self):
            self.vars = dict()

    loader = AnsibleLoader(None)

    variable_manager = VariableManagerHack()

    variable_manager.set_nonpersistent_facts(variable_manager.get_vars(loader, play=dict(vars=dict()), include_hostvars=False, include_delegate_to=False))



# Generated at 2022-06-23 14:24:35.476903
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from jinja2 import Environment


# Generated at 2022-06-23 14:24:47.116540
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    vault_password = 'myvaultpassword'
    encrypt_vars = False
    encrypt_vault_id = None

    v = VaultLib([])
    context = PlayContext()
    vars_mgr = VariableManager()
    t = Templar(loader=None, variables=vars_mgr, fail_on_undefined=False, vault_password=vault_password,
                encrypt_vars=encrypt_vars, encrypt_vault_id=encrypt_vault_id)

# Generated at 2022-06-23 14:24:55.394760
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    # Single string
    assert listify_lookup_plugin_terms(terms='test', templar=templar, loader=None) == ['test']

    # Single string, stripped
    assert listify_lookup_plugin_terms(terms=' test ', templar=templar, loader=None) == ['test']

    # Single Terraform-generated string
    assert listify_lookup_plugin_terms(terms='[ "test" ]', templar=templar, loader=None) == ['test']

    # List of strings
    assert listify_lookup_plugin_terms(terms=['test1', 'test2'], templar=templar, loader=None) == ['test1', 'test2']

    # List

# Generated at 2022-06-23 14:25:05.273068
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Warning: This uses a lot of internal ansible module_utils functions and objects.
    This is only a unit test function and not a testcase.
    '''
    from ansible.module_utils._text import to_text, to_native
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    class DummyVarsModule(object):
        def __init__(self, name, args):
            self.name = name
            self.args = args

    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.args = {}
            self.ansible_version = (2, 0)

    myarg = D

# Generated at 2022-06-23 14:25:16.493568
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import os
    import tempfile

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()

    basedir = tempfile.mkdtemp()
    templar = Templar(loader=loader, variables=dict(foo='bar', baz='meow'))
    assert templar._available_variables == dict(foo='bar', baz='meow')

    # Bare strings are handled as bare string
    args = ['foo', templar, loader]
    kwargs = {'fail_on_undefined': True}
    assert listify_lookup_plugin_terms(*args, **kwargs) == ['foo']

    # Non

# Generated at 2022-06-23 14:25:25.976247
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar

    class FakeVarsModule:
        def __init__(self, value):
            self.value = value

    templar = Templar(loader=None, variables={'var1': FakeVarsModule([1,2,3])})

    # Test string in scalar variable
    terms = listify_lookup_plugin_terms('{{var1}}', templar, loader=None, convert_bare=True)
    assert terms == [1,2,3]

    # Test integer in scalar variable
    terms = listify_lookup_plugin_terms('{{var1}}', templar, loader=None, convert_bare=True)
    assert terms == [1,2,3]

    # Test list in scalar variable
    terms

# Generated at 2022-06-23 14:25:37.904590
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class FakeLookupModule:
        def get_basedir(self, terms):
            return '.'

        def run(self, terms, inject=None, **kwargs):
            return listify_lookup_plugin_terms(terms, self._templar, self._loader)

        def __init__(self):

            from ansible.parsing.dataloader import DataLoader
            from ansible.vars.manager import VariableManager
            from ansible.template import Templar

            self._loader = DataLoader()
            self._variable_manager = VariableManager()
            self._templar = Templar(loader=self._loader, variables=self._variable_manager)

    import pytest
    from ansible.errors import AnsibleUndefinedVariable

    # We need to transform the dict into a list of (key,value) pairs
    # in

# Generated at 2022-06-23 14:25:47.210916
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader, fail_on_undefined=True, convert_bare=False) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo', templar, loader, fail_on_undefined=True, convert_bare=False) == ['foo']
    assert listify_lookup_plugin_terms(None, templar, loader, fail_on_undefined=True, convert_bare=False) == [None]

# Generated at 2022-06-23 14:25:53.381229
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    # Setup test-cases

# Generated at 2022-06-23 14:26:03.602085
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    class AnsibleVars(object):
        pass

    fake_vars = AnsibleVars()
    fake_vars.hostvars = dict()
    fake_vars.hostvars['127.0.0.1'] = {'ansible_facts': {}}
    fake_vars.hostvars['127.0.0.1']['ansible_facts'] = {'os_version': '1.2.3'}
    fake_vars.hostvars['127.0.0.1']['ansible_facts']['os_family'] = 'FooOS'

    fake_vars.host

# Generated at 2022-06-23 14:26:14.026621
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence
    import ansible.parsing.yaml.objects
    from ansible.template import Templar
    from ansible.template.vars import VarsModule
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins import LookupModule
    import unittest
    import six

    # Mock data for the unit test
    class DummyVarsModule(VarsModule):
        def __init__(self):
            super(DummyVarsModule, self).__init__()
            self._vars = {'my_var': 'my_value'}

    class DummyLookupModule(LookupModule):
        pass


# Generated at 2022-06-23 14:26:19.705132
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Listify valid terms
    new_terms = listify_lookup_plugin_terms(['a', 'b', 'c'], None, None)
    assert isinstance(new_terms, list)
    assert len(new_terms) == 3
    assert new_terms == ['a', 'b', 'c']

    # Stringify valid terms
    new_terms = listify_lookup_plugin_terms('a b c', None, None)
    assert isinstance(new_terms, list)
    assert len(new_terms) == 3
    assert new_terms == ['a', 'b', 'c']

    # Raise exception for invalid terms
    try:
        new_terms = listify_lookup_plugin_terms('a b c d e', None, None)
        assert False
    except:
        pass

    # Return list

# Generated at 2022-06-23 14:26:28.418863
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variable_manager=variable_manager)

    assert listify_lookup_plugin_terms("foo", templar, loader) == ['foo']
    assert listify_lookup_plugin_terms("foo bar", templar, loader) == ['foo bar']
    assert listify_lookup_plugin_terms("foo {{foo}}", templar, loader)

# Generated at 2022-06-23 14:26:40.037728
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-23 14:26:46.050483
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    module = None
    terms = ["{{ item }}", "{{ item2 }}"]
    templar = None
    loader = None

    # TODO: test with actual values
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ["{{ item }}", "{{ item2 }}"]

# Generated at 2022-06-23 14:26:54.759748
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    class FakeLoader:
        def path_dwim(self, a):
            return [a]

    p = PlayContext()
    m = VariableManager()
    templar = Templar(loader=FakeLoader(), variables=m, playcontext=p)

    assert listify_lookup_plugin_terms([True, False], templar, FakeLoader(), False) == [True, False]
    assert listify_lookup_plugin_terms(1, templar, FakeLoader(), False) == [1]
    assert listify_lookup_plugin_terms([1, 2], templar, FakeLoader(), False) == [1, 2]
    assert listify_lookup_plugin_terms

# Generated at 2022-06-23 14:27:05.262615
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # initialize needed objects
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)

    # test function
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=None, host=None))
    terms = [ '{{ foo }}', '{{ foo }}', "{{ bar }}" ]
    result = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-23 14:27:14.920728
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    play_context = dict()
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    templar = Templar(loader=None, variables=variable_manager, play_context=play_context)

    # Test the function with a string paramter
    test_term = '{{ hostvars[play_hosts[0]][\'ansible_eth0\'][\'ipv4\'][\'address\'] }}'
    test_result = listify_lookup_plugin_terms(test_term, templar, loader=None)

# Generated at 2022-06-23 14:27:24.479987
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # test with convert_bare=False
    terms = "a {{ var1 }}"
    templar = Templar(loader=None, variables=dict(var1="b"))
    assert ["a", "b"] == listify_lookup_plugin_terms(terms, templar, None)

    # test with convert_bare=True
    terms = "a {{ var1 }}"
    templar = Templar(loader=None, variables=dict(var1="b"))
    assert ["a", "b"] == listify_lookup_plugin_terms(terms, templar, None, convert_bare=True)

    terms = ["a {{ var1 }}", "c {{ var2 }}"]
    templar = Templar(loader=None, variables=dict(var1="b", var2="d"))
