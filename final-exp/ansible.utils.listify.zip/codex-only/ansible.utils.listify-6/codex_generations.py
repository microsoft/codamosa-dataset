

# Generated at 2022-06-23 14:17:33.893458
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars

    test_templar = Templar(None, variables=AnsibleVars(dict()))
    assert listify_lookup_plugin_terms('a', test_templar, None) == ['a']
    assert listify_lookup_plugin_terms(['a','b'], test_templar, None) == ['a','b']
    assert listify_lookup_plugin_terms(['a','b',{'c':'d'}], test_templar, None) == ['a','b',{'c':'d'}]

# Generated at 2022-06-23 14:17:44.665558
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader
    from units.mock.path import unfrackpath

    from jinja2 import Environment
    from jinja2.exceptions import UndefinedError

    plain_term = 'test'
    list_term = ['foo', 'bar', 'baz']
    tpl_term = '{{ foo }}'
    list_tpl_term = ['{{foo}}', ['{{bar}}'], '{{baz}}']

    templar = Templar(loader=DictDataLoader(dict()), variables={})
    print(type(templar))

    # first test that the plain term works
    result = listify_lookup

# Generated at 2022-06-23 14:17:54.712499
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.taggable import Taggable

    from ansible.template import Templar

    from ansible.vars import VariableManager

    from ansible.parsing.dataloader import DataLoader

    # Create a Taggable object as hostvars is a property of Taggable objects
    # therefore the templar object must be able to interact with the object
    class MockTaggable(Taggable):
        def __init__(self):
            self.vars = VariableManager()

    t = MockTaggable()

    # Create a Templar object to template variables
    templar = Templar(loader=DataLoader(), variables=t.vars)

    # Create a variable

# Generated at 2022-06-23 14:18:06.273174
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Test the listify_lookup_plugin_terms function'''

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = variable_manager.loader

    def get_vault_text(vaulttext):
        vault = VaultLib(password='password')
        unenc_text = vault.decrypt(vaulttext)
        unenc_text = AnsibleVaultEncryptedUnicode(unenc_text.strip())
        return unenc_text

    # Test a single string
    t = Templar(loader=loader, variables=dict(var1='test'))
    assert listify_

# Generated at 2022-06-23 14:18:17.478481
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.template import Templar

    class LookupModule(object):
        def __init__(self, basedir=None, runner=None, var_manager=None):
            self.basedir = basedir

    class RunnerMock(object):
        def __init__(self, basedir=None):
            self.basedir = basedir
            self.inventory = Inventory(host_list=[])
            self.inventory.basedir = basedir

    class VarManagerMock(object):
        def __init__(self, basedir=None, inventory=None):
            self.basedir = basedir
            self.inventory = inventory

    class Inventory(object):
        def __init__(self, host_list=None):
            self.host_list = host_list

    C.DEFAULT_

# Generated at 2022-06-23 14:18:28.059947
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from units.mock.loader import DictDataLoader

    from ansible.template import Templar

    from ansible.vars import VariableManager

    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=[]))
    variable_manager.extra_vars = {'item': 'test'}
    my_vars = variable_manager.get_vars(play=dict(hosts='all', name='test'))
    templar = Templar(loader=loader, variables=my_vars)
    templar._available_variables = my_vars


# Generated at 2022-06-23 14:18:36.960818
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Check that various types of terms return a list of items
    import random
    import string
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    for _ in range(0, 10):
        term = ''.join(random.choice(string.ascii_letters) for _ in range(0, random.randint(1, 10)))
        variable_manager = VariableManager()
        loader = DataLoader()
        inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list='localhost')
        variable_manager.set_inventory(inventory)
        play_context = PlayContext()
        variable_manager

# Generated at 2022-06-23 14:18:44.044844
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-23 14:18:54.455612
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Function under test is listify_lookup_plugin_terms
    '''

    from ansible.template import Template
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    # mock variable manager to return a template
    def get_vars(*args, **kwargs):
       return "template"

    variable_manager.get_vars = get_vars

    play_context = PlayContext()
    template_class = Template(loader=loader, variable_manager=variable_manager, play_context=play_context)

    out = listify_lookup_plugin_terms(template_class, template_class, loader)



# Generated at 2022-06-23 14:19:03.958799
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    results = {
        'foo': ['bar'],
        'baz': 'qux',
        'qux': ['quux', 'quuz'],
        # This term is not a string or an Iterable, but it is a valid lookup plugin term
        'quuz': 42,
        'gruz': ['groo'],
        'groo': 'groovy',
        'groovy': ['groovy1', 'groovy2'],
        'groovy1': 1,
        'groovy2': 2,
        'boo': None,
        'bloo': [],
    }


# Generated at 2022-06-23 14:19:15.198623
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    # Test string that needs no templating
    list_terms = ['one', 'two', '{{not_a_variable}}']
    list_terms = listify_lookup_plugin_terms(list_terms, templar, False)
    assert list_terms == ['one', 'two', '{{not_a_variable}}']

    # Test template that needs templating
    list_terms = '{{one_var}}'
    list_terms = listify_lookup_plugin_terms(list_terms, templar, False)
    assert list_terms == ['{{one_var}}']

    # Test list of templated strings
    list_terms = ['{{one_var}}', '{{two_var}}']

# Generated at 2022-06-23 14:19:25.522511
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    # test with None
    assert listify_lookup_plugin_terms(None, templar, None) == [None]

    # test with a simple string
    assert listify_lookup_plugin_terms("foo", templar, None) == ["foo"]
    # check that non-strings are converted to strings
    assert listify_lookup_plugin_terms([1,2,3], templar, None) == ['1', '2', '3']

    # test with a complex string
    assert listify_lookup_plugin_terms("foo {{bar}}", templar, None, fail_on_undefined=False) == ["foo {{bar}}"]

# Generated at 2022-06-23 14:19:33.716848
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=None, include_hostvars=False),
                      shared_loader_obj=loader, inventory=inventory)

    variables = {"foo": "bar"}
    variable_manager.set_nonpersistent_facts(variables)

    # Test with a string

# Generated at 2022-06-23 14:19:44.898877
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Run the listify_lookup_plugin_terms logic in test mode

    This function is not an actual test and does not assert anything other
    than returning the results of the function. We call it from the
    validate-modules, validate-docs and code-smell commands for testing and
    reporting purposes.

    :return: dictionary containing results of the listify_lookup_plugin_terms
    """
    result = dict()

    test_string = '{{ foo }}'
    test_list = ['{{ foo }}']
    test_tuple = ('foo', ['{{ foo }}'])
    test_dict = dict(foo='{{ foo }}')


# Generated at 2022-06-23 14:19:52.907281
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None, variables={'a': 'foo', 'b': 'bar'})

    assert listify_lookup_plugin_terms('{{a}}', templar, None) == ['foo']
    assert listify_lookup_plugin_terms('{{a}}', templar, None, convert_bare=True) == ['foo']

    assert listify_lookup_plugin_terms(['{{a}}', '{{b}}'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['{{a}}', u'{{b}}'], templar, None) == ['foo', 'bar']

    assert listify_lookup_

# Generated at 2022-06-23 14:19:58.169584
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.utils.jinja import AnsibleUnsafeText

    from ansible.template import Templar

    class FakeVarsModule(object):
        def __init__(self):
            self._templates = {}

    class FakeHost():
        def __init__(self, vars):
            self.vars = vars
            self.name = 'fake_host'

        def get_vars(self):
            return self.vars

    class FakeTask():
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self, play=None):
            return self.vars

    class FakePlay():
        def __init__(self, vars):
            self.vars = vars

    vars_module = FakeVarsModule()
   

# Generated at 2022-06-23 14:20:07.602581
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict

    class TestVarsModule:
        def __init__(self):
            self.vars = OrderedDict()
            self.vars['foo'] = 'bar'

        def get_vars(self, loader=None, play=None, host=None, task=None, include_dependencies=True):
            return self.vars

    class Templated(object):
        def __init__(self, var):
            self.var = var

    class AnsibleMockTemplar(object):
        def __init__(self, vars_module):
            self.vars_module = vars_module

        def set_available_variables(self, variables):
            pass


# Generated at 2022-06-23 14:20:20.233799
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    terms = ['{{ foo }}', '{{ bar }}']
    templar = Templar(loader=None, variables=VariableManager())
    loader = None
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['', '']

    terms = '{{ foo }} {{ bar }}'
    templar = Templar(loader=None, variables=VariableManager())
    loader = None
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['', '']

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager())
    loader = None
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['']

   

# Generated at 2022-06-23 14:20:24.631600
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import yaml

    tests = [
        [
            u'this',
            [u'this']
        ],
        [
            100,
            [100]
        ],
        [
            u'"this"',
            [u'this']
        ],
        [
            yaml.safe_load(u'"this"'),
            [u'this']
        ],
        [
            [u'this', u'that'],
            [u'this', u'that']
        ],
        [
            yaml.safe_load(u'[this, that]'),
            [u'this', u'that']
        ]
    ]

    # Create the objects

# Generated at 2022-06-23 14:20:36.234690
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    terms = '{{ hostvars[inventory_hostname]["foo"] }}'
    templar = DummyVarsTemplate()
    loader = DummyDataLoader()
    templar._available_variables = dict()
    templar._vars = dict()
    templar._host = Host('dummy')
    templar._host.get_variables = lambda: dict()
    var_mgr = VariableManager()
    templar._add_host_variables = lambda host, add_vars: add_vars
    templar._add_host_group_vars = lambda group, add_vars: add_vars


# Generated at 2022-06-23 14:20:47.104934
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.vars.manager import DataLoader

    class TestVars(object):
        pass

    class TestTask(object):
        def __init__(self, ds):
            self.ds = ds

        def args_patch(self, keys):
            if not isinstance(keys, dict):
                return keys

    class TestDS(AnsibleBaseYAMLObject):
        def __init__(self, args):
            self.args = args


# Generated at 2022-06-23 14:20:48.242940
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-23 14:20:58.201330
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    t = Templar(variables=VariableManager(loader=DataLoader()),
                loader=DataLoader(),
                inventory=InventoryManager(loader=DataLoader()),
                shared_loader_obj=None,
                fail_on_undefined_errors=False,
                disable_lookups=False)


# Generated at 2022-06-23 14:21:03.002280
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['bar'], templar, None) == ['bar']
    assert listify_lookup_plugin_terms(5, templar, None) == [5]

# Generated at 2022-06-23 14:21:10.354768
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'var': [1, 2, 'a', 'b']})

    assert listify_lookup_plugin_terms(['{{ var }}'], templar, None) == ['{{ var }}']
    assert listify_lookup_plugin_terms('{{ var }}', templar, None) == [1, 2, 'a', 'b']
    assert listify_lookup_plugin_terms('1 2 {{ var }}', templar, None) == ['1', '2', 1, 2, 'a', 'b']



# Generated at 2022-06-23 14:21:18.163519
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.context import context
    from ansible.template import Templar

    terms = AnsibleMapping()

    terms['a'] = 'foo'
    terms['b'] = ['bar1', 'bar2']
    terms['c'] = '{{j}}'
    terms['d'] = '{{a}}'
    terms['j'] = ['j1', 'j2']

    ds = DataLoader()
    context._init_global_context(ds)
    t = Templar(loader=ds)


# Generated at 2022-06-23 14:21:26.837641
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variable_manager=variable_manager)

    terms = [
        ('a', [1, 2, 3]),
        ('b', [4, 5, 6]),
        ('c', [7, 8, 9]),
    ]

    bad_terms = [1, 2, 3, 4]

    passed = True
    for _terms, _result in terms:
        try:
            assert _result == listify_lookup_plugin_terms(_terms, templar)
        except:
            passed = False


# Generated at 2022-06-23 14:21:37.341125
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Dummy vars (using a dict)
    v = {'var1': 'value1', 'var2': 'value2'}
    vars_m = VariableManager(loader=None)
    vars_m._vars = v
    templar = Templar(loader=AnsibleLoader(None), variables=vars_m)

    # Dummy inventory
    inv = [None, None]
    inv_m = InventoryManager(loader=None, sources=inv)

    # Dummy templar
    templar._available_variables = v

# Generated at 2022-06-23 14:21:44.446667
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class OptionsModule(object):
        def __init__(self):
            self.tags = None
            self.skip_tags = None
            self.extra_vars = []
            self.any_errors_fatal = None
            self.private_key_file = None
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self.syntax = None
            self.connection = None
            self.module_path = None
            self.forks = None
            self.check = None
            self.remote_user = None
            self.sudo = None
            self.sudo_user = None
            self.become_method = None
            self.become_user = None

# Generated at 2022-06-23 14:21:51.797852
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from collections import namedtuple

    class FakeVarsModule(object):
        def __init__(self):
            vars = {
                'foo': 'bar',
                'a': [1,2,3],
                'x': [
                    {'z':1},
                    {'z':2},
                    {'z':3, 'y':5},
                    {'z':4}
                ],
                'w': [
                    'a', 'b', 'c'
                ],
                'ansible_hostname': 'host'
            }

# Generated at 2022-06-23 14:22:01.845760
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={
        'a': 'A',
        'b': 'B',
        'c': ['C1', 'C2'],
        'd': ['D1', 'D2'],
    })


# Generated at 2022-06-23 14:22:13.440533
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    mock_loader = AnsibleLoader(None, dict())


# Generated at 2022-06-23 14:22:24.903003
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.errors import AnsibleError
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    variable_manager = VariableManager()
    loader = DictDataLoader({})
    variable_manager.set_loader(loader)
    variable_manager.set_inventory(variable_manager.empty_inventory)

    templar = Templar(loader=loader, variable_manager=variable_manager)

    # Test string which should return a list with one item

# Generated at 2022-06-23 14:22:36.782864
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text

    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    templar = Templar(loader=loader)

    test_terms = "['a', 'b']"
    assert listify_lookup_plugin_terms(test_terms, templar, loader) == ['a', 'b']

    test_terms = "['a', 'b', '{{ c }}']"
    results = listify_lookup_plugin_terms(test_terms, templar, loader, fail_on_undefined=True, convert_bare=False)
    assert results == ['a', 'b', '{{ c }}']

    test_terms = "['a', 'b', '{{ c }}']"
    results

# Generated at 2022-06-23 14:22:47.971135
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Assert simple string turns into list of one element
    templar = Templar(loader=None)
    x = listify_lookup_plugin_terms('foo', templar, loader=None)
    assert x == ['foo']

    # Assert simple list stays a list
    templar = Templar(loader=None)
    x = listify_lookup_plugin_terms(['foo'], templar, loader=None)
    assert x == ['foo']

    # Assert list of list is flattened
    templar = Templar(loader=None)
    x = listify_lookup_plugin_terms([['foo']], templar, loader=None)
    assert x == ['foo']

    # Assert list of strings stays a list

# Generated at 2022-06-23 14:22:58.656581
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    templar = Templar(loader=None)

    terms = '1,2,3'
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == [1, 2, 3]

    terms = '1, 2, 3'
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == [1, 2, 3]

    terms = AnsibleVaultEncryptedUnicode('1,2,3')
    result = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=False)
    assert result == [1, 2, 3]

   

# Generated at 2022-06-23 14:23:10.008718
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar

    # global templar
    globals_dict = dict()
    play_context = PlayContext()
    templar = Templar(loader=None, variables=play_context.variables,
                          shared_loader_obj=None,
                          **globals_dict)
    templar._available_variables = dict()

    # list
    result = listify_lookup_plugin_terms(['a', 'b'], templar, None)
    assert result == ['a', 'b']

    # string
    result = listify_lookup_plugin_terms('a', templar, None)
    assert result == ['a']

    # template

# Generated at 2022-06-23 14:23:16.345295
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # With fail_on_undefined=False, return a list even if the term is not a iterable
    assert [u'myfile'] == listify_lookup_plugin_terms(u'myfile', {}, {}, fail_on_undefined=False)
    # With fail_on_undefined=True, throw exception if term is not a iterable or string
    try:
        listify_lookup_plugin_terms(None, {}, {}, fail_on_undefined=True)
    except exceptions.AnsibleError:
        pass
    else:
        assert False, 'Should have raised an exception'

# Generated at 2022-06-23 14:23:25.768892
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    print('Testing listify_lookup_plugin_terms')
    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms(['foo'], templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader=None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo', templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader=None, convert_bare=True) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo', templar, loader=None, convert_bare=True)

# Generated at 2022-06-23 14:23:35.902906
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    templar = Templar(vault_secrets=dict(vault_password='password'),
                      variables=dict(name='harry'))

    # test string -> list conversion
    assert listify_lookup_plugin_terms('{{ name }}', templar, None) == ['harry']
    assert listify_lookup_plugin_terms(['{{ name }}'], templar, None) == ['harry']
    assert listify_lookup_plugin_terms(dict(key='{{ name }}'), templar, None) == dict(key='harry')

    # not crypted, so just test string->list conversion

# Generated at 2022-06-23 14:23:46.331229
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    listify_lookup_plugin_terms: return a list of variables split on commas
    """
    from ansible.templating import Template
    loader = {}
    templar = Template(loader=loader)

    terms = listify_lookup_plugin_terms("{{foo}},{{bar}},{{baz}}", templar, loader)
    assert terms == ['{{foo}}', '{{bar}}', '{{baz}}']

    terms = listify_lookup_plugin_terms(["{{foo}}", "{{bar}}", "{{baz}}"], templar, loader)
    assert terms == ['{{foo}}', '{{bar}}', '{{baz}}']

    terms = listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader)

# Generated at 2022-06-23 14:23:56.999234
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    import pytest

    terms = ['{{ terms }}']
    templar = Templar(None)
    with pytest.raises(AnsibleUndefinedVariable):
        listify_lookup_plugin_terms(terms, templar, None)

    # test with a string as input
    terms = '{{ terms }}'
    templar = Templar(None, variables={'terms': 'a'})
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(result, list)
    assert result == ['a']

    # test with a list as input
    terms = ['{{ terms }}']
    templar = Templar(None, variables={'terms': 'a'})

# Generated at 2022-06-23 14:24:04.055421
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    my_vars = dict(
        o=dict(
            a=1,
            b=2,
            c=3
        ),
        l=[1,2,3],
        d=dict(
            a=1,
            b=dict(
                d=1
            )
        ),
        s='hello',
        v=42,
        v1="{{ '42' }}"
    )

    my_loader = DictDataLoader({})


# Generated at 2022-06-23 14:24:14.293040
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Test listify_lookup_plugin_terms function from file lookup_plugins/__init__.py.
    This function tests by using assertEqual.
    """
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.utils.yaml import from_yaml
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    yaml_data = """
    - '{{ test | default("test") }}'
    - '{{ test }}'
    - test
    - 1
    - [test, 1]
    - test:1
    - [test,test_1]
    """

# Generated at 2022-06-23 14:24:24.956015
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # The _init_global_context method was removed in Ansible 2.6, so we need to
    # use a different approach to instantiating the templar if we want to test
    # versions older than 2.6.
    if hasattr(Templar, '_init_global_context'):
        templar = Templar(loader=DataLoader(), variables=VariableManager())
    else:
        templar = Templar(loader=DataLoader())

    # Test a single string
    string = 'a string'
    expected = ['a string']
    result = listify_lookup_plugin_terms(string, templar, DataLoader())
    assert expected == result

    # Test

# Generated at 2022-06-23 14:24:33.942021
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.config.manager import ConfigManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    import ansible.template

    config_manager = ConfigManager()
    config_manager.set_inventory_sources()
    config_manager.update_vars_files()
    config_manager.update_inventory(config_manager.get_inventory())

    loader = DataLoader()

    play = Play.load(dict(hosts='localhost', gather_facts='no'), loader=loader, variable_manager=config_manager.get_variable_manager(), loader_cache=config_manager.get_loader_cache())
    templar = ansible.template.Templar(loader=loader, variables=play.get_variable_manager().get_vars(play=play))



# Generated at 2022-06-23 14:24:45.313183
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Load module_utils/basic.py to get the template function
    import ansible.module_utils.basic
    templar = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    # Test various failure modes
    assert listify_lookup_plugin_terms(None, templar, None) == [None]
    assert listify_lookup_plugin_terms('', templar, None) == ['']
    assert listify_lookup_plugin_terms({}, templar, None) == [{}]
    assert listify_lookup_plugin_terms(5, templar, None) == [5]

    # Test standard lists (including single-element ones)
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], templar, None)

# Generated at 2022-06-23 14:24:53.987903
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    # test with a list containing a list
    assert listify_lookup_plugin_terms(['hello', ['world', 'test']], templar) == ['hello', 'world', 'test']
    # test with a list
    assert listify_lookup_plugin_terms(['hello', 'world'], templar) == ['hello', 'world']
    # test with a string
    assert listify_lookup_plugin_terms('hello world', templar) == ['hello world']
    # test with a string containing a list

# Generated at 2022-06-23 14:25:03.685685
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class Templar:
        def __init__(self, result):
            self.result = result

        def template(self, term, convert_bare=False, preserve_trailing_newlines=False, fail_on_undefined=False, override_vars=None):
            return self.result

    class MyLoader():
        def get_basedir(self, hostname):
            return '.'

    # Terminator is a string
    terms = '{{var1}}'
    templar = Templar(result='spam')
    result = listify_lookup_plugin_terms(terms, templar, MyLoader())
    assert result == ['spam']

    # Terminator is a list
    terms = ['{{var1}}', '{{var2}}']
    templar = Templar(result=['spam', 'eggs'])
   

# Generated at 2022-06-23 14:25:15.434626
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    from ansible.module_utils._text import to_bytes

    vm = VariableManager()
    vm.set_variable("name", "world")

    templar = Templar(loader=None, variables=vm)

    data = listify_lookup_plugin_terms('{{name}}', templar, None, fail_on_undefined=True)
    assert data == ['world']

    data = listify_lookup_plugin_terms(['{{name}}'], templar, None, fail_on_undefined=True)
    assert data == ['world']


# Generated at 2022-06-23 14:25:25.265937
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variables = VariableManager()

    # test for string term
    templar = Templar(loader=loader, variables=variables)
    terms = listify_lookup_plugin_terms(" {{ foo }} ", templar, loader, fail_on_undefined=True)
    assert(terms == ['{{ foo }}'])

    # test for list term
    templar = Templar(loader=loader, variables=variables)
    variables.set_variable('foo', ['a', 'b', 'c'])
    terms = listify_lookup_plugin_terms(" {{ foo }} ", templar, loader, fail_on_undefined=True)


# Generated at 2022-06-23 14:25:37.330852
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    terms_tests = namedtuple('Test', ['test_input', 'test_output'])

    tests = list()
    tests.append(terms_tests(test_input=terms_tests([], True), test_output=[]))
    tests.append(terms_tests(test_input=terms_tests(['foo'], True), test_output=['foo']))
    tests.append(terms_tests(test_input=terms_tests(['foo', '{{bar}}'], True), test_output=['foo', '{{bar}}']))

# Generated at 2022-06-23 14:25:46.613735
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variable_manager=variable_manager)
    variable_manager.set_fail_on_undefined(False)

    assert listify_lookup_plugin_terms('foo', templar, loader, fail_on_undefined=False) == ['foo']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader, fail_on_undefined=False) == ['{{ foo }}']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader, fail_on_undefined=False, convert_bare=True)

# Generated at 2022-06-23 14:25:50.024673
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # If it's a single string return a list of that single string
    assert listify_lookup_plugin_terms('hello', None, None) == ['hello']

    # If it's a list of string(s) don't change it
    assert listify_lookup_plugin_terms(['hello', 'world'], None, None) == ['hello', 'world']

# Generated at 2022-06-23 14:26:00.717828
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    # Templar requires a Variables object
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    import ansible.parsing.dataloader
    import ansible.playbook.play
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    play_context = ansible.playbook.play.PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)


# Generated at 2022-06-23 14:26:11.075285
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.template.safe_eval import SafeEval, unsafe_eval

    templar = Templar(loader=None, variables={'foo': 'bar'})

    # Test string, non-iterable non-string
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None, fail_on_undefined=True, convert_bare=False) == ['bar']

    # Test string, non-iterable non-string
    assert listify_lookup_plugin_terms(10, templar, None, fail_on_undefined=True, convert_bare=False) == [10]

    # Test list, non-iterable non-string
    assert listify_lookup_plugin_terms

# Generated at 2022-06-23 14:26:22.050075
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    if not listify_lookup_plugin_terms('test', templar) == ['test']:
        raise AssertionError('Unexpected result from listify_lookup_plugin_terms')

    if not listify_lookup_plugin_terms(['test1', 'test2'], templar) == ['test1', 'test2']:
        raise AssertionError('Unexpected result from listify_lookup_plugin_terms')

    loader.set_basedir("tests/listify/")
    if not listify_lookup_plugin_terms('{{ test1 }}', templar) == ['test1val']:
        raise Ass

# Generated at 2022-06-23 14:26:27.824526
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # assert only accepts string, int, long, list, tuple, dict, set, frozenset
    # as expected output.
    # So, It is ok to convert int, long, list, tuple to string
    # but dictionary, set and frozenset can not be converted to string.
    # So, I am converting the dictionary, set and frozenset to list by sorting.
    assert listify_lookup_plugin_terms(set([1,2,3]), "mock templar", "mock loader", False, False) == [1,2,3]
    assert listify_lookup_plugin_terms(dict([("a", 1), ("b", 2), ("c", 3)]), "mock templar", "mock loader", False, False) == ["a", "b", "c"]
    assert listify_lookup_plugin

# Generated at 2022-06-23 14:26:39.781976
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    blank_vars = dict(
        foo='foo file', bar='bar file', bam='bam file',
        bat='bat file', baz='baz_file',
        one='', two='', three='', four='',
        none='', empty='',
        this_host='', other_host=''
    )

    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=[]))

    loader = DataLoader()

# Generated at 2022-06-23 14:26:48.234034
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('1', None) == ['1']
    assert listify_lookup_plugin_terms('1,2,3', None) == ['1', '2', '3']
    assert listify_lookup_plugin_terms(['1'], None) == ['1']
    assert listify_lookup_plugin_terms(['1,2,3'], None) == ['1,2,3']

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-23 14:26:55.688495
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class load:
        _basedir = "foo/bar"

    class fail:
        _basedir = "foo/bar"
        msg = "something failed"

    class t:
        class ds:
            class _templar:
                class _loader:
                    class _basedir:
                        pass

                def set_available_variables(self, variables):
                    pass

                def template(self, data, *args, **kwargs):
                    if type(data) is fail:
                        raise ValueError("failed")
                    elif type(data) is load:
                        return 'loaded'
                    else:
                        return data

        class ds2:
            class _templar:
                class _loader:
                    class _basedir:
                        pass

                def set_available_variables(self, variables):
                    pass



# Generated at 2022-06-23 14:27:00.986901
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms(['a', 'b'], Templar(loader=None), None) == ['a', 'b']
    assert listify_lookup_plugin_terms(['a', 'b', '{{foo}}'], Templar(loader=None, variables={'foo':'c'}), None) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:27:08.434829
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(None, templar, loader) == [None]
    assert listify_lookup_plugin_terms('', templar, loader) == ['']
    assert listify_lookup_plugin_terms([], templar, loader) == []
    assert listify_lookup_plugin_terms({}, templar, loader) == [{}]
    assert listify_lookup_plugin_terms([''], templar, loader) == ['']
    assert listify_lookup_plugin_terms(['', ''], templar, loader) == ['', '']
    assert listify_

# Generated at 2022-06-23 14:27:16.570945
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    v1 = dict(a=dict(b=dict(c=1)))
    v2 = dict(a=dict(b=dict(c=2)))

    variable_manager = VariableManager()
    variable_manager.set_inventory(variable_manager.get_inventory(host_list=[v1, v2]))

    loader = None # not used
    fail_on_undefined = True
    convert_bare = False

    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=fail_on_undefined)


# Generated at 2022-06-23 14:27:25.691380
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class FakeVarsModule:
        pass

    class FakeLoader:
        def get_basedir(*args, **kwargs):
            return '/path/to/role/vars'

    variables = FakeVarsModule()
    variables.a = 'b'
    templar = Templar(variables=variables, loader=FakeLoader())
    play_context = PlayContext()
    terms = '{{ a }}'
    ret = listify_lookup_plugin_terms(terms, templar, FakeLoader())
    assert ret == [u'b']

    terms = 'foo'
    ret = listify_lookup_plugin_terms(terms, templar, FakeLoader())
    assert ret == [u'foo']
