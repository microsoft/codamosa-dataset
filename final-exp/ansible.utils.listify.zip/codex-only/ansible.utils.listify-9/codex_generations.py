

# Generated at 2022-06-23 14:17:31.121412
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    with pytest.raises(ValueError):
        listify_lookup_plugin_terms(None, object(), object())
    assert listify_lookup_plugin_terms('', object(), object()) == ['']
    assert listify_lookup_plugin_terms(42, object(), object()) == [42]
    assert listify_lookup_plugin_terms(['abc', {'a': 'b'}], object(), object()) == ['abc', {'a': 'b'}]
    assert listify_lookup_plugin_terms(('abc', {'a': 'b'}), object(), object()) == ['abc', {'a': 'b'}]

# Generated at 2022-06-23 14:17:39.726487
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test with multiple terms
    terms = ['{{ foo }}', '{{ bar }}']
    templar = FakeTemplar()
    templar.vars['foo'] = 'foo'
    templar.vars['bar'] = 'bar'
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo', 'bar']

    # Test with a single term only
    terms = '{{ foo }}'
    templar = FakeTemplar()
    templar.vars['foo'] = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo']

    # Test with a single term that is a number
    terms = '123'
    templar = FakeTemplar()
    assert listify_lookup_plugin_

# Generated at 2022-06-23 14:17:50.073029
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    def testit(terms, expected_terms, vars_, convert_bare=False, fail_on_undefined=True, expected_exception=None, expected_exception_regex=None):
        terms = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=convert_bare, fail_on_undefined=fail_on_undefined)
        assert terms == expected_terms, "Expected\n%s\nto be\n%s" % (to_text(terms), to_text(expected_terms))

    from ansible.vars.manager import VariableManager

# Generated at 2022-06-23 14:17:58.404049
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    __import__('sys').modules['ansible'] = object()

    from ansible.plugins.lookup import template
    from jinja2.exceptions import UndefinedError

    # test string
    terms = '{{ test }}'

    loader = None
    templar = template.LookupModule()
    templar._available_variables = dict(test='myvar')

    ret = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(ret, list), 'Expected %s to become instance of list' % ret
    assert ret == ['myvar']

    # test list
    terms = ['{{ test }}', '{{ test1 }}']
    templar._available_variables = dict(test='myvar', test1='myvar1')

    ret = listify_lookup_

# Generated at 2022-06-23 14:18:06.415551
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test default behavior
    result = listify_lookup_plugin_terms('foo', 'foo', {}, True)
    assert isinstance(result, list)
    assert result == ['foo']

    # Test list as input
    result = listify_lookup_plugin_terms(['foo', 'bar'], 'foo', {}, True)
    assert isinstance(result, list)
    assert result == ['foo', 'bar']

# Test listify_lookup_plugin_terms with 'convert_bare'=True

# Generated at 2022-06-23 14:18:13.073024
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test empty terms
    terms = []
    assert isinstance(listify_lookup_plugin_terms(terms), list)

    # Test string term
    terms = "test"
    assert isinstance(listify_lookup_plugin_terms(terms), list)

    # Test list term
    terms = ["test1", "test2"]
    assert isinstance(listify_lookup_plugin_terms(terms), list)

# Generated at 2022-06-23 14:18:24.496309
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DictDataLoader({})
    shared_loader_obj = DictDataLoader({})
    templar = Templar(loader=loader, variables={}, shared_loader_obj=shared_loader_obj)

    # Test that an empty terms param is replaced with a list containing an empty string
    terms = listify_lookup_plugin_terms('', templar, loader)
    assert isinstance(terms, list) and len(terms) == 1 and terms[0] == ''

    # Test that a list of terms is preserved, except for adding a new empty string to the end
    terms = listify_lookup_plugin_terms(['one', 'two', 'three'], templar, loader)

# Generated at 2022-06-23 14:18:32.086559
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import BytesIO
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    b_vault_password = None
    vault = VaultLib(b_vault_password)
    templar = Templar(loader=None, variables={}, vault_secrets=vault)

    terms = "{{ foo }}"
    listified_terms = listify_lookup_plugin_terms(terms, templar, None, convert_bare=True)
    assert listified_terms == ['{{ foo }}']

    terms = "{% if foo %} {{ foo }} {% else %} {{ bar }} {% endif %}"
    listified_terms = listify_lookup_plugin_terms(terms, templar, None, convert_bare=True)
    assert list

# Generated at 2022-06-23 14:18:40.788498
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-23 14:18:50.651285
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class MyVarsModule(object):
        def __init__(self, basedir):
            pass
        def get_vars(self, loader, path, entities, cache=True):
            return {
                'foo': 'bar',
                'bar': ['baz', 'bam'],
                'baz': {'bat': 'bat'},
                'bat': ['bat'],
            }
        def get_basedir(self):
            return '/'

    templar = Templar(loader=None, variables={})

    # test conversion of a string
    assert listify_lookup_plugin_terms("{{foo}}", templar, None) == ["bar"]

    # test conversion of a string that should be left as a string

# Generated at 2022-06-23 14:19:01.097118
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = None
    assert listify_lookup_plugin_terms("a", Templar(loader=loader), loader) == ["a"]
    assert listify_lookup_plugin_terms(["a"], Templar(loader=loader), loader) == ["a"]
    assert listify_lookup_plugin_terms("{{ foo }}", Templar(loader=loader, variables={'foo': '1'}), loader) == ["1"]
    assert listify_lookup_plugin_terms(["{{ foo }}"], Templar(loader=loader, variables={'foo': '1'}), loader) == ["1"]
    assert listify_lookup_plugin_terms(["{{ foo }}"], Templar(loader=loader, variables={'foo': ['1', '2']}), loader) == ["[u'1', u'2']"]


# Generated at 2022-06-23 14:19:10.199581
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    fake_loader = DictDataLoader({})
    templar = Templar(loader=fake_loader)

    input_terms = "foo"
    actual_terms = listify_lookup_plugin_terms(input_terms, templar, fake_loader, fail_on_undefined=True, convert_bare=False)
    assert actual_terms == ['foo']

    input_terms = ["foo"]
    actual_terms = listify_lookup_plugin_terms(input_terms, templar, fake_loader, fail_on_undefined=True, convert_bare=False)
    assert actual_terms == ['foo']


# Generated at 2022-06-23 14:19:21.825632
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    listify_lookup_plugin_terms unit test function
    '''

    # Try listify_lookup_plugin_terms on an empty list
    def ensure_list(a_list):
        return listify_lookup_plugin_terms(a_list, templar=None, loader=None, fail_on_undefined=False, convert_bare=False)

    assert ensure_list([]) == []

    # Try listify_lookup_plugin_terms on a non-empty list
    class DummyTemplar:
        def template(self, terms, fail_on_undefined=False):
            return terms
    templar = DummyTemplar()

# Generated at 2022-06-23 14:19:30.544232
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import sys

    if sys.version_info[0] < 3:
        # Python2
        from StringIO import StringIO
    else:
        # Python3
        from io import StringIO

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    def _get_loader():
        loader = DataLoader()
        loader.set_basedir('tests/test_data/inventory')
        return loader

    def _get_templar(loader):
        add_dirs = {'vars': 'tests/test_data/templates'}
        return Templar(loader=loader, variables={}, add_dirs=add_dirs)

    # Test with a string
    loader = _get_loader()
    templar = _get_templar(loader)
    terms

# Generated at 2022-06-23 14:19:37.418221
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.dataloader import DataLoader

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    import os
    import json

    # Setup
    loader = DataLoader()

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["localhost,"])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variable_manager=variable_manager, play_context=play_context)

    # Test

# Generated at 2022-06-23 14:19:47.740895
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import wrap_var

    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import lookup_loader

    # Dummy class for unit testing
    class DummyVarsModule(object):
        def get_vars(self, loader, path, entities, cache=True):
            return dict()

    # Create Templar object with dummy VaultLib and DummyVarsModule
    templar = Templar(loader=AnsibleLoader(), variables={},
                      vault_secrets=VaultLib(),
                      env_vars={},
                      run_additional_vars_plugins=False)

    # Test valid cases
    assert listify_lookup_plugin_

# Generated at 2022-06-23 14:19:58.953602
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    assert listify_lookup_plugin_terms(['{{ item }}', '{{ 2*item }}'], Templar(loader=loader, variables=variable_manager), loader) == ['{{ item }}', '{{ 2*item }}']
    assert listify_lookup_plugin_terms('{{ item }}', Templar(loader=loader, variables=variable_manager), loader) == ['{{ item }}']
    assert listify_lookup_plugin_terms('{{ item }}', Templar(loader=loader, variables=variable_manager), loader) == ['{{ item }}']

# Generated at 2022-06-23 14:20:08.153377
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms_list = ["item_1", "item_2"]
    templar = Templar(loader=None, shared_loader_obj=None)
    assert terms_list == listify_lookup_plugin_terms(terms_list, templar, loader=None)
    terms_string = "item_1,item_2"
    terms_list = ["item_1", "item_2"]
    assert terms_list == listify_lookup_plugin_terms(terms_string, templar, loader=None)

    terms_string = "{{ a_var }}"
    templar._available_variables['a_var'] = "item_1,item_2"
    terms_list = ["item_1", "item_2"]
    assert terms_list == listify_lookup

# Generated at 2022-06-23 14:20:20.609130
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    # Init variables
    loader.set_basedir('/foo')
    context = PlayContext()

# Generated at 2022-06-23 14:20:31.290653
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms1 = '{{ lookup_terms1 }}'
    terms2 = ['{{ lookup_terms2_0 }}', '{{ lookup_terms2_1 }}']
    terms3 = ['{{ lookup_terms3_0 }}']
    terms4 = '{{ lookup_terms4 }}'
    terms5 = 'not_a_template_var'
    terms6 = '{{ lookup_terms6 }}'

    class FakeVars:
        lookup_terms1 = 'ivar1'
        lookup_terms2_0 = 'ivar2_0'
        lookup_terms2_1 = 'ivar2_1'
        lookup_terms3_0 = 'ivar3_0'
        lookup_terms4 = '{{ lookup_terms4_1 }}'

# Generated at 2022-06-23 14:20:40.904087
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar

    terms = '"{{ lookup("pipe", "echo {{ item1 }} {{ item2 }}") }}"'
    my_vars = dict(item1="foo", item2="bar")

    templar = Templar(loader=None, variables=my_vars)
    results = listify_lookup_plugin_terms(terms, templar=templar, loader=None, fail_on_undefined=True, convert_bare=False)

    assert isinstance(results, list)
    assert "foo bar" in results

    terms = ['"{{ lookup("pipe", "echo {{ item1 }} {{ item2 }}") }}"', "a", "b"]

# Generated at 2022-06-23 14:20:49.784359
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.templar import Templar
    fake_loader = None
    templar = Templar(loader=fake_loader, variables={
        "foo": "bar",
        "a_list": ["1", "2", "3"],
        "string_with_vars": "the {{foo}}"
    })
    # Test string
    assert listify_lookup_plugin_terms('{{ foo }}', templar, fake_loader) == ['bar']
    # Test list
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, fake_loader) == ['bar']
    # Test list with multiple elements, each of which is a string or a list
    list_with_lists = ['{{ string_with_vars }}', '{{ a_list }}']
    assert listify_look

# Generated at 2022-06-23 14:20:59.121770
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' test_listify_lookup_plugin_terms '''
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    # Test when terms is a non-iterable object
    terms = 'some_string'
    templar = Templar(loader=DataLoader(), variables={})
    assert(isinstance(listify_lookup_plugin_terms(terms, templar, loader=DataLoader()), list))
    # Test when terms is an iterable object
    terms = ['some_string1', 'some_string2']
    templar = Templar(loader=DataLoader(), variables={})
    assert(isinstance(listify_lookup_plugin_terms(terms, templar, loader=DataLoader()), list))
    # Test when terms is an empty iterable object
   

# Generated at 2022-06-23 14:21:09.496451
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    (templar, loader, fail_on_undefined=True, convert_bare=False)
    :return:
    """

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    templar = Templar(loader=DataLoader(), variables=VariableManager())


# Generated at 2022-06-23 14:21:17.546828
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(None, True)
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(["a"], templar, loader) == ["a"]

    assert listify_lookup_plugin_terms("a", templar, loader) == ["a"]

    assert listify_lookup_plugin_terms(
        "{{ 'a' }}", templar, loader, convert_bare=True
    ) == ["a"]

    assert listify_lookup_plugin_terms(
        "{{ ['a'] }}", templar, loader, convert_bare=True
    ) == ["a"]


# Generated at 2022-06-23 14:21:26.450623
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    my_dict = {'a': 1, 'b': 2, 'c': 3}
    my_list = [1,2,3]

    # Make list of things that should be lists.
    # VarManager and loader are not used here, so pass None.
    items = [
        '1',
        ['1'],
        [1,2],
        my_dict,
        my_dict['a'],
        my_list,
        my_list[0],
    ]

    for terms in items:
        result = listify_lookup_plugin_terms(terms, Templar(VariableManager(), loader=DataLoader()))

# Generated at 2022-06-23 14:21:37.276172
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    terms = 'https://github.com/ansible/ansible/blob/devel/CHANGELOG-v1.md'
    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)
    terms = listify_lookup_plugin_terms(terms, templar, loader)

    assert terms == ['https://github.com/ansible/ansible/blob/devel/CHANGELOG-v1.md']

    # test with a list in a template

# Generated at 2022-06-23 14:21:47.166998
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    templar = Templar(loader=None)
    terms = "{{ foo }}"
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(terms, list)
    terms = "{{ foo }} {{ bar }}"
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(terms, list)
    terms = "{{ foo }},{{ bar }}"
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(terms, list)
    terms = "{{ foo }}:{{ bar }}"
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(terms, list)

# Generated at 2022-06-23 14:21:58.383769
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import StringIO
    from ansible.template import Templar

    test = "{{ lookup('pipe', 'echo foo') }}"
    test2 = ["{{ lookup('pipe', 'echo foo') }}", "{{ lookup('pipe', 'echo foo') }}"]

    test_result1 = ['foo']
    test_result2 = [[u'foo'], [u'foo']]

    buf = StringIO()
    buf.name = '<template>'
    templar = Templar(loader=None, variables={}, shared_loader_obj=None)
    t = listify_lookup_plugin_terms(terms=test, templar=templar, loader=None)
    t2 = listify_lookup_plugin_terms(terms=test2, templar=templar, loader=None)

# Generated at 2022-06-23 14:22:02.871165
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    templar = Templar()
    terms = '{{ foo }}'
    tlist = listify_lookup_plugin_terms(terms, templar, {}, True, True)
    assert tlist == ['{{ foo }}']
    tlist = listify_lookup_plugin_terms('foo', templar, {}, True, True)
    assert tlist == ['foo']
    tlist = listify_lookup_plugin_terms('foo', templar, {}, True, True)
    assert tlist == ['foo']
    tlist = listify_lookup_plugin_terms(['foo'], templar, {}, True, True)
    assert tlist == ['foo']
    tlist = listify_

# Generated at 2022-06-23 14:22:14.345843
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible import variables
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from units.mock.loader import DictDataLoader


# Generated at 2022-06-23 14:22:21.854310
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.module_utils.six import PY2
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    if PY2:
        str_class = unicode  # noqa: F821
    else:
        str_class = str

    lookups = lookup_loader.all(class_only=True)
    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test 1: terms is a string.
    terms = '{{ [1,2,3] }}'
   

# Generated at 2022-06-23 14:22:32.551409
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    templar = Templar(loader=DataLoader(), variables={})
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert listify_lookup_plugin_terms(["test1", "test2", AnsibleUnsafeText("test3")], templar, templar.loader) == ["test1", "test2", "test3"]
    assert listify_lookup_plugin_terms(["test1", {"a": "test2"}, "{{ test3 }}"], templar, templar.loader) == ["test1", {"a": "test2"}, "{{ test3 }}"]
    assert listify_loo

# Generated at 2022-06-23 14:22:42.571385
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    mock_templar = Templar(loader=None)
    #
    assert listify_lookup_plugin_terms('foo', mock_templar, None) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', mock_templar, None) == ['foo bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], mock_templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{ a }}'], mock_templar, None) == ['foo', 'bar', '{{ a }}']

# Generated at 2022-06-23 14:22:53.024666
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    def _test_template(template, **kwargs):
        return template

    def _test_loader(template):
        return {}

    # test 1
    terms_arg = ['1', '2']
    templar, loader = _test_template, _test_loader
    assert listify_lookup_plugin_terms(terms_arg, templar, loader) == terms_arg

    # test 2
    terms_arg = '1 2'
    templar, loader = _test_template, _test_loader
    assert listify_lookup_plugin_terms(terms_arg, templar, loader) == terms_arg.split()

    # test 3
    terms_arg = '1 2'
    templar, loader = _test_template, _test_loader

# Generated at 2022-06-23 14:22:59.303991
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.template.template import AnsibleTemplate
    from ansible.parsing.dataloader import DataLoader

    variable_manager = DictDataManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    result = listify_lookup_plugin_terms(['1.1.1.1', 'foo', '{{ prefix }}'], templar, loader, fail_on_undefined=False, convert_bare=True)
    assert result == ['1.1.1.1', 'foo', 'bar']

    result = listify_lookup_plugin_terms('1.1.1.1', templar, loader, fail_on_undefined=False, convert_bare=True)

# Generated at 2022-06-23 14:23:06.467359
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    test_data = [
        (['1', '2', '3'], ['1', '2', '3']),
        (['a', 'b', 'c'], ['a', 'b', 'c']),
        (1, [1]),
        (True, [True]),
        (False, [False]),
        (['1', 'a'], ['1', 'a']),
        ('foo', ['foo']),
        (['1', 'a', 1, True, False], ['1', 'a', 1, True, False]),
        (['1', [1, 2]], ['1', [1, 2]]),
    ]

    variable_manager = VariableManager()

# Generated at 2022-06-23 14:23:15.187804
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar()
    loader = object()

    # ansible.cfg sets ANSIBLE_JINJA2_NATIVE = False and we don't want to override that
    # and trigger native jinja2 for this test
    assert listify_lookup_plugin_terms(u'string', templar, loader, fail_on_undefined=True, convert_bare=False) == [u'string']
    assert listify_lookup_plugin_terms([u'string'], templar, loader, fail_on_undefined=True, convert_bare=False) == [u'string']

# Generated at 2022-06-23 14:23:25.061269
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        import jinja2
        from ansible.template import Templar
        from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    except ImportError as e:
        print('Skipping listify_lookup_plugin_terms unit tests, missing dependencies: %s' % e)
        return
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    j2_env = jinja2.Environment(loader=jinja2.DictLoader({}))


# Generated at 2022-06-23 14:23:33.195909
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, shared_loader_obj=loader, variables=variable_manager)
    return_value = listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], templar, loader)

    assert return_value == ['{{ foo }}', '{{ bar }}']

# Generated at 2022-06-23 14:23:44.689293
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    vm = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    vm.set_inventory(inventory)
    templar = Templar(loader=loader, variables=vm)

    terms = listify_lookup_plugin_terms('item1 ,  item2     ,item 3 ', templar, loader)
    assert terms == ['item1', 'item2', 'item 3']

    terms = listify_lookup_plugin_terms('item1', templar, loader)
    assert terms == ['item1']


# Generated at 2022-06-23 14:23:55.879065
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from units.mock.vault import mock_vault

    mocker, mock_vault_inst = mock_vault()

    data = '''
    foo:
      - test1
      - test2
    '''

    loader = AnsibleLoader(data, mock_vault_inst)
    templar = Templar(loader=loader, variables=VariableManager())

    result = listify_lookup_plugin_terms(terms=['foo'], templar=templar, loader=loader, fail_on_undefined=False)
    assert result == ['foo']

    result = listify

# Generated at 2022-06-23 14:24:06.446751
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    class DummyVarsModule(object):
        def __init__(self, loader, vault_secrets=None):
            self._templar = Templar(loader=loader, variables=dict())

        def template(self, data, fail_on_undefined=True):
            return self._templar.template(data=data, fail_on_undefined=fail_on_undefined)

    vault_secrets = [{'secret': 'secret string'}]
    loader = lookup_loader
    templar = DummyVarsModule(loader=loader, vault_secrets=vault_secrets)._templar

# Generated at 2022-06-23 14:24:17.410612
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text

    templar = FakeTemplar()
    assert listify_lookup_plugin_terms("hello", templar, "") == ['hello']
    assert listify_lookup_plugin_terms("{{foo}}", templar, "") == ['hello']
    assert listify_lookup_plugin_terms("{{foo}}", templar, "", convert_bare=True) == ['hello']
    assert listify_lookup_plugin_terms("{{foo}}", templar, "", convert_bare=False) == ['{{foo}}']
    assert listify_lookup_plugin_terms("{{foo}}, bar", templar, "") == ['hello', 'bar']


# Generated at 2022-06-23 14:24:28.666728
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import sys
    import os.path

    if not os.path.exists("test/test_utils.py"):
        print("No test/test_utils.py file.  Must be run from root dir")
        sys.exit(1)

    from test.test_utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    module = AnsibleExitJson()
    set_module_args(
        dict(
            _ansible_no_log=True,
            terms=[
                {'a': [['b']]},
                '{{not_a_var}}',
                'a',
            ],
        )
    )
    module.params['_ansible_verbosity'] = 0

    from ansible.playbook.templar import Templar

# Generated at 2022-06-23 14:24:35.370349
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    templar = Templar(loader=None, variables={})


# Generated at 2022-06-23 14:24:46.969958
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy

    terms = '{{ foo }}'
    templar = Templar(loader=AnsibleLoader(None), variables=VariableManager())

    # Test with a variable that is known to templar (w/ and w/o convert_bare)
    templar._available_variables = dict(foo='bar')
    assert listify_lookup_plugin_terms(terms, templar, {}, True, False) == ['bar']
    assert listify_lookup_plugin_terms(terms, templar, {}, True, True) == ['bar']

    # Test with a variable that is known to tem

# Generated at 2022-06-23 14:24:55.298242
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.vars import combine_vars
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.template import Templar

    from ansible.playbook.play_context import PlayContext

    from ansible.plugins.lookup import LookupBase


# Generated at 2022-06-23 14:25:04.966253
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeVarsModule(object):

        def __init__(self):
            class VarManager(object):
                def __init__(self):
                    self.vars = {
                        'role_name': 'fake_role',
                    }
            self.vars = VarManager()

    class FakeTemplar(Templar):
        def __init__(self):
            self.vars = FakeVarsModule()

        def template(self, data, fail_on_undefined=False, convert_bare=False):
            return data

    templar = FakeTemplar()

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

# Generated at 2022-06-23 14:25:16.295767
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.parsing.yaml.objects

    terms1 = ['a string', 'of', 'lists', 'and', 'strings']
    terms2 = 'a string of lists and strings'
    terms3 = '{{ foo }}'
    terms4 = ['a string', '{{ foo }}']
    terms5 = ansible.parsing.yaml.objects.AnsibleUnicode('{{ foo }}')

    # expected output for listify_lookup_plugin_terms(terms1, templar, loader)
    output1 = ['a string', 'of', 'lists', 'and', 'strings']

    # expected output for listify_lookup_plugin_terms(terms2, templar, loader)
    output2 = ['a string of lists and strings']

    # expected output for listify_lookup_plugin_terms(

# Generated at 2022-06-23 14:25:25.905036
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This should return a list of 1 item
    loader, templar = None, None
    terms = listify_lookup_plugin_terms("one term", templar, loader)
    assert len(terms) == 1
    assert terms == ["one term"]

    # This should return a list of 1 item
    terms = listify_lookup_plugin_terms("  one term  ", templar, loader)
    assert len(terms) == 1
    assert terms == ["one term"]

    # This should return a list of 1 item
    terms = listify_lookup_plugin_terms(["one term"], templar, loader)
    assert len(terms) == 1
    assert terms == ["one term"]

    # This should return a list of 1 item

# Generated at 2022-06-23 14:25:37.867442
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    v = VariableManager()
    t = Templar(loader=None, variables=v)

    assert ['var'] == listify_lookup_plugin_terms('var', t)
    assert ['var'] == listify_lookup_plugin_terms(['var'], t)
    assert ['var', 'var2'] == listify_lookup_plugin_terms(['var', 'var2'], t)

    assert ['var'] == listify_lookup_plugin_terms(['var', '{{ var2 }}'], t)
    v.set_variable('var2', 'var2')
    assert ['var', 'var2'] == listify_lookup_plugin_terms(['var', '{{ var2 }}'], t)


# Generated at 2022-06-23 14:25:47.175210
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    This unit test will check the listify_lookup_plugin_terms function
    '''

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader
    import os
    import pytest
    import json


# Generated at 2022-06-23 14:25:50.932371
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms([None, "one", ["two", "three"]], Templar(None), False) == [None, 'one', ['two', 'three']]
    assert listify_lookup_plugin_terms([None, "one", ["two", "three"]], Templar(None), True) == [None, 'one', 'two', 'three']

# Generated at 2022-06-23 14:26:01.638772
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test 1: Empty terms
    terms = ''
    result = listify_lookup_plugin_terms(terms)
    assert result == [], result

    # Test 2: Single term
    terms = 'myname'
    result = listify_lookup_plugin_terms(terms)
    assert result == ['myname'], result

    # Test 3: Multiple terms
    terms = 'myname, yourname'
    result = listify_lookup_plugin_terms(terms)
    assert result == ['myname', 'yourname'], result

    # Test 4: List of single term
    terms = ['myname']
    result = listify_lookup_plugin_terms(terms)
    assert result == ['myname'], result

    # Test 5: List of multiple terms
    terms = ['myname', 'yourname']


# Generated at 2022-06-23 14:26:11.004510
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = 'fake'
    ctx = PlayContext()
    templar = Templar(loader=loader, variables={'foo': 'bar'})

    assert listify_lookup_plugin_terms('blah', templar, loader) == ['blah']
    assert listify_lookup_plugin_terms('{{foo}}', templar, loader) == ['bar']
    assert listify_lookup_plugin_terms(['blah'], templar, loader) == ['blah']
    assert listify_lookup_plugin_terms(['{{foo}}'], templar, loader) == ['bar']

# Generated at 2022-06-23 14:26:22.048013
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar

    loader = None
    templar = Templar(loader=loader, vault_secrets=dict(vault_pass='foo'))

    # test noop
    assert listify_lookup_plugin_terms([1,2,3], templar, loader) == [1,2,3]

    # test string
    field_list = 'a, b, c'
    assert listify_lookup_plugin_terms(field_list, templar, loader) == ['a', 'b', 'c']

    # test string with spaces
    field_list = 'a, b , c'
    assert listify_lookup_plugin

# Generated at 2022-06-23 14:26:29.559111
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestVars(object):
        def __init__(self):
            self.a = 'hello'
            self.b = 'world'

    loader = DataLoader()
    context = PlayContext()
    templar = Templar(loader=loader, variables=VariableManager(), shared_loader_obj=None)

    # List of strings
    test_list = [
        '{{ a }}',
        '{{ b }}'
    ]
    # make sure no values are templated

# Generated at 2022-06-23 14:26:40.649203
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class DummyTemplar(object):

        def __init__(self, fail_on_undefined=True, convert_bare=False):
            self._fail_on_undefined = fail_on_undefined
            self._convert_bare = convert_bare

        def template(self, template, fail_on_undefined=None, convert_bare=None):
            assert not (fail_on_undefined is not None and self._fail_on_undefined != fail_on_undefined)
            assert not (convert_bare is not None and self._convert_bare != convert_bare)
            return template

    class DummyLoader(object):
        pass

    # Test string
    assert listify_lookup_plugin_terms('foo', DummyTemplar(), DummyLoader()) == ['foo']

    # Test list
   

# Generated at 2022-06-23 14:26:52.374194
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from jinja2 import Environment

    # Test use case of a single term that is a string
    templar = Environment()
    terms = '1'
    result = listify_lookup_plugin_terms(terms, templar)
    assert result == ['1']

    # Test use case of a single term that is a list
    templar = Environment()
    terms = ['1']
    result = listify_lookup_plugin_terms(terms, templar)
    assert result == ['1']

    # Test use case of a single term that is a dict
    templar = Environment()
    terms = {'a': '1'}
    result = listify_lookup_plugin_terms(terms, templar)
    assert result == [{'a': '1'}]

    # Test use case of a

# Generated at 2022-06-23 14:27:03.719479
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader=loader)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms(terms={}, templar=templar, loader=loader, fail_on_undefined=True, convert_bare=False) == [{}]
    assert listify_lookup_plugin_terms(terms="default", templar=templar, loader=loader, fail_on_undefined=True, convert_bare=False) == ["default"]

# Generated at 2022-06-23 14:27:10.648643
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test with None
    terms = None
    templar = None
    loader = None

    expected_value = []
    value = listify_lookup_plugin_terms(terms, templar, loader)

    assert value == expected_value, 'Failure - {} != {}'.format(value, expected_value)

    # test with string
    terms = 'test'
    templar = None
    loader = None

    expected_value = ['test']
    value = listify_lookup_plugin_terms(terms, templar, loader)

    assert value == expected_value, 'Failure - {} != {}'.format(value, expected_value)

    # test with list
    terms = ['test', 'test2']
    templar = None
    loader = None

    expected_value = ['test', 'test2']
   

# Generated at 2022-06-23 14:27:18.066632
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()
    t = Templar(loader=dl)

    assert listify_lookup_plugin_terms('foo', t, dl, convert_bare=True) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], t, dl, convert_bare=True) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], t, dl, convert_bare=False, fail_on_undefined=False) == ['foo', '{{ bar }}']

# Generated at 2022-06-23 14:27:26.445195
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeTemplar(object):
        def __init__(self, val):
            self.val = val

        def template(self, x, **kwargs):
            return self.val

    assert listify_lookup_plugin_terms(['a', 'b', 'c'], FakeTemplar('d'), None) == ['d', 'd', 'd']
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], FakeTemplar({'a':1}), None) == [{'a':1}, {'a':1}, {'a':1}]
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], FakeTemplar(None), None) == [None, None, None]