

# Generated at 2022-06-23 14:17:30.845840
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from jinja2 import Template
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    assert listify_lookup_plugin_terms('foobar', Templar(PlayContext(loader=DataLoader()), None), None) == ['foobar']
    assert listify_lookup_plugin_terms(['foobar'], Templar(PlayContext(loader=DataLoader()), None), None) == ['foobar']
    assert listify_lookup_plugin_terms(Template('{{ ansible_os_family }}'), Templar(PlayContext(loader=DataLoader()), None), None) == ['Darwin']

# Generated at 2022-06-23 14:17:39.565020
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    class FakeVarsModule(object):
        def __init__(self, results):
            self.results = results

        def get_vars(self, loader, path, entities):
            if len(entities) == 1 and entities[0] == 'foo':
                return self.results

    class FakeInventory(object):
        def __init__(self):
            self.basedir = 'path/to/somewhere'

    loader = DataLoader()
    templar = Templar(loader=loader, variables={})

    # should return an empty list on empty string
    assert not listify_lookup_plugin_terms('', templar, loader)

    # should return a list with empty string
    assert listify_look

# Generated at 2022-06-23 14:17:46.592178
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader, play_context, variable_manager)
    listify_lookup_plugin_terms(['{{ var }}/foo', '{{ other_var }}/bar'], templar, loader)

# Generated at 2022-06-23 14:17:56.061550
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    lookup_loader = DataLoader()
    lookup_templar = Templar(loader=lookup_loader, variables=VariableManager(), shared_loader_obj=lookup_loader)

    # Test scalar variable with string
    result = listify_lookup_plugin_terms('{{ variable }}', lookup_templar, lookup_loader)
    assert isinstance(result, list)
    assert len(result) == 1

    # Test scalar variable with list
    result = listify_lookup_plugin_terms(['{{ variable }}'], lookup_templar, lookup_loader)
    assert isinstance(result, list)
    assert le

# Generated at 2022-06-23 14:18:07.399387
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variable_manager=variable_manager)

    variable_manager.set_nonpersistent_facts(dict(a=1,b=2))
    variable_manager.set_host_variable("testhost", dict(c=3,d=4))
    variable_manager.set_host_variable("otherhost", dict(c=5,d=6))

    # Test various non-templates
    terms = listify_lookup_plugin_terms("string", templar, loader, convert_bare=True)
    assert terms == ["string"]
    terms = listify_look

# Generated at 2022-06-23 14:18:19.462691
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    terms = AnsibleUnicode('[ "{{ value }}", value2 ]')

    variable_manager = VariableManager()
    loader = variable_manager._loader
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['./test/units/modules/inventory']))

    play_context = Play().set_loader(loader)
    play_context.variable_manager = variable_manager
    templar = Templar(loader=loader, variable_manager=variable_manager)

   

# Generated at 2022-06-23 14:18:29.575205
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' test_listify_lookup_plugin_terms '''

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.errors import AnsibleError

    def get_loader(vault_secrets=None):
        if vault_secrets:
            vault_secrets = [('default', VaultLib(password='secret'))]
        else:
            vault_secrets = []
        return DataLoader(vault_secrets=vault_secrets)

    def get_variable_manager(path=None):
        return VariableManager(loader=get_loader(), inventory=get_inventory(path))


# Generated at 2022-06-23 14:18:38.270976
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Add try/except to make sure this unit test will not fail
    # and to make it work under Travis CI.
    try:
        from __main__ import display
    except:
        from ansible.utils.display import Display
        display = Display()
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from jinja2 import DictLoader

    loader = DataLoader()
    templar = Templar(loader=loader, variables={})
    test_string = "{{ var1 }} {{ var2 }}"
    result = listify_lookup_plugin_terms(test_string, templar, loader, convert_bare=False,
            fail_on_undefined=False)
    assert len(result) == 1

# Generated at 2022-06-23 14:18:45.786363
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    terms = [1, 'a', 2]
    args = ['a', 'b', 'c', 'd']
    play_context = PlayContext()
    templar = Templar(loader=DataLoader(), variables=dict(zip(
        ["item.%s" % idx for idx in range(1, len(args) + 1)], args)))
    result = listify_lookup_plugin_terms(terms, templar, play_context.loader)
    assert result == [1, 'a', 2]

    terms = ['{{ item.2 }}', '{{ item.3 }}']

# Generated at 2022-06-23 14:18:53.064729
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import ansible.constants as C

    loader = DataLoader()
    templar = Templar(loader=loader, variables={'a': 'foo', 'b': 'bar', 'c': [1, 2, 3], 'd': {'a':1}})

    listify_lookup_plugin_terms('A', templar, loader)
    listify_lookup_plugin_terms(['A B', 'C D'], templar, loader)
    listify_lookup_plugin_terms('{{a}} {{b}}', templar, loader)
    listify_lookup_plugin_terms(['{{a}} {{b}}', '{{c}}'], templar, loader)
    listify_lookup

# Generated at 2022-06-23 14:19:03.154890
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class FakeTemplar:
        def __init__(self):
            pass

        def template(self, terms, convert_bare=False, fail_on_undefined=True):
            return terms

    class FakeLoader:
        def __init__(self):
            pass

    def assert_listify(input, expected_output):
        output = listify_lookup_plugin_terms(input, FakeTemplar(), FakeLoader())
        assert expected_output == output, \
            "Expected %s got %s" % (expected_output, output)

    assert_listify('foo.conf',
                   ['foo.conf'])
    assert_listify(['foo', 'bar', 'baz'],
                   ['foo', 'bar', 'baz'])
    assert_listify(u'foo',
                   ['foo'])

# Generated at 2022-06-23 14:19:13.838302
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    def test_term(term, expected, data, **kwargs):
        # Create a templar object that we can use
        from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
        from ansible.template import Templar
        from ansible.vars import VariableManager
        vars_mgr = VariableManager()
        templar = Templar(loader=None, variables=vars_mgr)
        results = listify_lookup_plugin_terms(term, templar, loader='dummy', **kwargs)
        assert results == expected

    # Make a fake vaulted string to use for testing:
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

# Generated at 2022-06-23 14:19:24.531107
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variables = VariableManager()
    templar = Templar(loader=loader, variables=variables)

    assert listify_lookup_plugin_terms([1, 2, 3], templar, loader) == [1, 2, 3]
    assert listify_lookup_plugin_terms([1, '{{foo}}', 3], templar, loader) == [1, '{{foo}}', 3]
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-23 14:19:31.251705
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Import needed modules
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Initialize objects
    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Run tests
    assert listify_lookup_plugin_terms("{{ foo }}", templar, loader, True, False) == ["{{ foo }}"]
    assert listify_lookup_plugin_terms("{{ foo }}", templar, loader, False, False) == []
    assert listify_lookup_plugin_terms("{{ foo }}", templar, loader, True, True) == ["{{ foo }}"]

# Generated at 2022-06-23 14:19:37.926797
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Import needed modules here, because test_sanity checks that ansible.module_utils.* modules are not used
    # Can not find more suitable module, as this is pretty much testing code
    import ansible.module_utils.common.collections
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    # This is not a real unit test, this is just a sanity check,
    # but put it here to make it easy to run from IDE

    # This is list of lists, that contains pairs of input and expected output
    # First item in pair is input for lookup, second item is expected output
    # If lookup should fail, second item should be None

# Generated at 2022-06-23 14:19:48.211358
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible import variables

    v = variables.VariableManager()
    t = Templar(vars=v)
    b_vars = dict(
        one='uno',
        two='dos'
    )
    v.set_fact(b_vars)
    b_vars['this'] = 'that'
    v.set_fact(b_vars)
    v.set_fact({'oops': 'nope'})

    assert listify_lookup_plugin_terms(['{{one}}', '{{two}}'], t, None) == ['uno', 'dos']
    assert listify_lookup_plugin_terms('{{one}}', t, None) == ['uno']
    assert listify_lookup_plugin_terms('this', t, None, convert_bare=True)

# Generated at 2022-06-23 14:19:59.101926
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variables = {'var1': 'foo'}
    variable_manager.extra_vars = variables
    variable_manager.set_available_variables(loader.load_from_file('/dev/null'))

    templar = Templar(loader=loader,
        variables=variable_manager)

    assert listify_lookup_plugin_terms([], templar, loader) == []
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)

# Generated at 2022-06-23 14:20:08.250209
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Load modules needed for this unit test
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    # Setup templar for use in this test
    class Host:
        vars = dict(
            var_a='a',
            var_b='b',
            var_c='c',
            var_d='d',
            var_list=['a', 'b', 'c', 'd']
        )
    templar = Templar(loader=lookup_loader, variables=Host())
    templar._available_variables = templar.available_variables

    # Test with a simple string
    result = listify_lookup_plugin_terms('foo', templar, lookup_loader, fail_on_undefined=False)
    assert result == ['foo']

    # Test

# Generated at 2022-06-23 14:20:20.652896
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import jinja2
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    results = listify_lookup_plugin_terms('foo', variable_manager.get_vars(), loader)
    assert isinstance(results, list)
    assert results[0]

# Generated at 2022-06-23 14:20:31.376890
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Import Ansible modules
    from ansible.template import Templar

    # Import Ansible internal modules
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.loader import lookup_loader

    # Create plugin loader
    lookup_loader.add_directory(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'lookup_plugins'))

    # Initialize Ansible modules
    vault_secret = 'secret'
    vault_password_file = '/tmp/ansible-vault-pwfile'
    vault_password_file_obj = open(os.path.join(vault_password_file), 'w')
    vault_password_file_obj.write

# Generated at 2022-06-23 14:20:41.011023
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    terms_list = ["item1", "item2", "item3"]
    terms_list_result = [u'item1', u'item2', u'item3']

    terms_string = "item1 item2 item3"
    terms_string_result = [u'item1', u'item2', u'item3']

    terms_list_with_vars = ["item1", "{{ var }}", "item3"]
    terms_list_with_vars_result = [u'item1', u'var_value', u'item3']

    terms_string_with_vars = "item1 {{ var }} item3"

# Generated at 2022-06-23 14:20:49.888869
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # works with string
    plugin_parameter = '{{ foo }}'
    templar = 'magic string'
    loader = None
    fail_on_undefined = True
    convert_bare = False
    expected_return = 'magic string'
    assert listify_lookup_plugin_terms(plugin_parameter, templar, loader, fail_on_undefined, convert_bare) == expected_return
    # works with list
    plugin_parameter = [1, 2, 3]
    templar = 'magic string'
    loader = None
    fail_on_undefined = True
    convert_bare = False
    expected_return = [1, 2, 3]

# Generated at 2022-06-23 14:20:59.225464
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Import needed functions and classes
    import sys
    import os
    import unittest
    from ansible.playbook.play_context import PlayContext

    module_loader, lookup_loader, loader, tests_path, data_path = (None, None, None, None, None)

    # Setup a dummy class to serve as the loader
    class DummyLoader():
        def __init__(self, play_context):
            self._play_context = play_context

        def get_basedir(self, path):
            return os.path.normpath(os.path.join(data_path, '..', path))

    # Create the test case
    class TestListifyLookupPluginTerms(unittest.TestCase):

        def setUp(self):
            # Setup the test environment
            self.test_dir = os.path

# Generated at 2022-06-23 14:21:09.668667
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeTemplar(object):
        def __init__(self):
            self.calls = []

        def template(self, terms, fail_on_undefined):
            self.calls.append(terms)
            if isinstance(terms, list):
                return [t for t in terms if t != 'fail']
            else:
                return terms

    class FakeLoader(object):
        pass

    # trivial test
    terms = 'foo'
    expected = ['foo']
    actual = listify_lookup_plugin_terms(terms, FakeTemplar(), FakeLoader())
    assert expected == actual

    # single quoted strings should be preserved
    terms = "'foo'"
    expected = ["'foo'"]
    actual = listify_lookup_plugin_terms(terms, FakeTemplar(), FakeLoader())
    assert expected

# Generated at 2022-06-23 14:21:17.673443
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    empty_inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=empty_inventory)
    templar = Templar(loader=DataLoader(), variables=variable_manager)

    assert listify_lookup_plugin_terms('str', templar, loader=DataLoader()) == ['str']
    assert listify_lookup_plugin_terms(['str'], templar, loader=DataLoader()) == ['str']

# Generated at 2022-06-23 14:21:23.099383
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    myvault = VaultLib([])
    templar = Templar(loader=None, variables={})
    convert_bare = True
    convert_bare_failed = None
    convert_bare_failed_ok = []

    # test legacy behavior
    legacy_terms = templar.template("{{ item }}", convert_bare=False, fail_on_undefined=True)
    assert isinstance(legacy_terms, str)
    assert legacy_terms == '{{ item }}'

    # test default behavior
    default_terms = templar.template("{{ item }}", convert_bare=True, fail_on_undefined=True)
    assert isinstance(default_terms, str)
    assert default_terms

# Generated at 2022-06-23 14:21:33.382421
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
   
    loader = DataLoader()
    
    from ansible.template import Templar
    from ansible.vars import VariableManager
   
    variable_manager = VariableManager()
    variable_manager._extra_vars = {'foo': 'bar'}
    variable_manager._options_vars = []
   
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string input
    #
    # not a list
    assert ['bar'] == listify_lookup_plugin_terms('{{ foo }}', templar, loader)

    # not a list with a templateable string
    assert ['bar_foo'] == listify_lookup_plugin_terms('{{ foo }}_foo', templar, loader)

    # list with a

# Generated at 2022-06-23 14:21:42.212182
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    import pytest
    import sys

    # Input data for the test
    my_terms = {
        'terms': [
            'a', 'b'
        ],
        'convert_bare': False,
        'fail_on_undefined': True
    }

    my_play = Play()
    my_play.set_loader(None)
    my_play.set_basedir("/tmp")

    my_inventory = InventoryManager(loader=None, sources='')

# Generated at 2022-06-23 14:21:50.323095
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys
    sys.modules['ansible'] = type('module', (), {})
    sys.modules['ansible.template'] = type('module', (), {})
    sys.modules['ansible.template.Template'] = type('module', (), {})
    sys.modules['ansible.template'].Template = type('Template', (), {})
    t = sys.modules['ansible'].template.Template()
    t.template = lambda value: value
    t.template.__name__ = 't.template'

    assert ['foo'] == listify_lookup_plugin_terms('foo', templar=t, loader=None)
    assert ['foo'] == listify_lookup_plugin_terms(['foo', 'bar'], templar=t, loader=None)
    assert ['foo'] == listify_lookup_plugin

# Generated at 2022-06-23 14:22:00.675752
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    class MockVarsModule(object):
        def get_vars(self, loader, play, host, task):
            vars = combine_vars(loader=loader, play=play, host=host, task=task)
            return vars

    class MockPlay(object):
        name = 'test'
        hosts = ['test']
        roles = []

    class MockHost(object):
        name = 'test'

    class MockTask(object):
        name = 'test'

    class MockLoader(DataLoader):
        def get_basedir(self, host=None):
            return '/'

    loader = MockLoader

# Generated at 2022-06-23 14:22:07.579328
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.plugins.loader import lookup_loader

    loader.add_directory('./lib')

    templar = Templar(loader=loader, variables={'item': 'foobar'})

    assert listify_lookup_plugin_terms('test1', templar, loader, convert_bare=True) == ['test1']
    assert listify_lookup_plugin_terms(['test1'], templar, loader, convert_bare=True) == ['test1']
    assert listify_lookup_plugin_terms(['test1', 'test2'], templar, loader, convert_bare=True) == ['test1', 'test2']

# Generated at 2022-06-23 14:22:18.393940
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variable_manager=variable_manager)

    # test with a string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_fact('foo', 'bar')
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert results == ['bar'], results

    # test with a list
    terms = ['baz', 'bar']
    variable_manager.set_nonpersistent_fact('foo', 'bar')
    results = listify_lookup_plugin_terms(terms, templar, loader)


# Generated at 2022-06-23 14:22:29.077018
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    except ImportError:
        AnsibleUnsafeText = None

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    # The password should be the existing vault password in the tests directory
    vault_password = '$ANSIBLE_VAULT;1.1;AES256\n306136623334396165633433663562363130633934643034316138336238626430383336336332386\n34333666356437353332656335313163653266643832337a\n'

    vault = VaultLib([])
    loader

# Generated at 2022-06-23 14:22:38.358743
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # Empty string
    templar = Templar(loader=None)
    ret = listify_lookup_plugin_terms('', templar)
    assert ret == ['']

    # Strings
    ret = listify_lookup_plugin_terms('foo', templar)
    assert ret == ['foo']
    ret = listify_lookup_plugin_terms('foo bar', templar)
    assert ret == ['foo bar']

    # List
    ret = listify_lookup_plugin_terms(['foo','bar'], templar)
    assert ret == ['foo','bar']

# Generated at 2022-06-23 14:22:49.303868
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Use a dummy variable manager and templar to avoid deps on real data
    # since this is just a test
    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms({'foo': 'bar'}, templar, loader) == [{'foo': 'bar'}]

# Hide these tests from the regular unit

# Generated at 2022-06-23 14:22:54.560629
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string and return as list
    assert listify_lookup_plugin_terms('sometest', templar, loader) == ['sometest']

    # Test list and return list
    assert listify_lookup_plugin_terms(['sometest'], templar, loader) == ['sometest']

# Generated at 2022-06-23 14:23:05.721247
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DictDataLoader({
        'somestr': '{{ some_string }}',
        'someent': '{{ some_entity }}',
        'sometuple': '{{ some_tuple }}',
        'somevar': '{{ some_var }}'
    })

    myvars = {
        'some_string': 'a string',
        'some_entity': 'a "string" with "quotes"',
        'some_tuple': ['one', 'two'],
        'some_list': ['one', 'two'],
        'some_var': 'item'
    }

    # Test string
    templar = Templar(loader=loader, variables=myvars)

# Generated at 2022-06-23 14:23:14.540397
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeVarsModule():
        def __init__(self):
            self._AnsibleVars__data = {
                "a": "something",
                "b": ["something", "something else"],
                "c": {
                    "d": "thing one",
                    "e": "thing two",
                }
            }

        def get_vars(self):
            return self._AnsibleVars__data

    vars_module = FakeVarsModule()
    templar = Templar(loader=None, variables=vars_module)

    assert listify_lookup_plugin_terms("{{ a }}", templar, None) == ["something"]
    assert listify_lookup_plugin_terms("{{ b }}", templar, None) == ["something", "something else"]

# Generated at 2022-06-23 14:23:24.488669
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms(['a', 'b'], templar, None) == ['a', 'b']
    assert listify_lookup_plugin_terms(['a'], templar, None) == ['a']
    assert listify_lookup_plugin_terms('a', templar, None) == ['a']
    assert listify_lookup_plugin_terms(['{{a}}', 'b'], templar, None, fail_on_undefined=False) == ['{{a}}', 'b']
    assert listify_lookup_plugin_terms('{{a}}', templar, None, fail_on_undefined=False) == ['{{a}}']
    assert listify_lookup_plugin

# Generated at 2022-06-23 14:23:35.072103
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    test_strings = ['item1',
                    'item1,item2',
                    ['item3'],
                    ['item3', 'item4'],
                    ['item5', ['item6']],
                    {'item7': 'item8'}]

    expected_results = [['item1'],
                        ['item1', 'item2'],
                        ['item3'],
                        ['item3', 'item4'],
                        ['item5', ['item6']],
                        {'item7': 'item8'}]

    for test_string, expected_result in zip(test_strings, expected_results):
        result = listify_look

# Generated at 2022-06-23 14:23:45.908016
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # When terms is a string, it should be wrapped in a list
    assert listify_lookup_plugin_terms('hello', None, None) == ['hello']
    assert listify_lookup_plugin_terms('hello', None, None, None, True) == ['hello']

    # When terms is a list, it should be returned as is
    assert listify_lookup_plugin_terms(['hello', 'world'], None, None) == ['hello', 'world']
    assert listify_lookup_plugin_terms(['hello', 'world'], None, None, None, True) == ['hello', 'world']

    # When term is a non empty dictionary, it should be returned as is
    assert listify_lookup_plugin_terms({'hello': 'world'}, None, None) == {'hello': 'world'}

# Generated at 2022-06-23 14:23:56.624167
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar  # module under test, so import is here to avoid import loop
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar()

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']

    a_unicode = AnsibleUnicode('foo')
    assert listify_lookup_plugin_terms(a_unicode, templar, None) == [a_unicode]

    assert listify_lookup_plugin_terms(a_unicode, templar, None, convert_bare=True) == ['foo']

    assert listify_lookup_plugin_

# Generated at 2022-06-23 14:24:06.794928
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeTemplar(object):
        def __init__(self, content):
            self.content = content

        def template(self, content, **kwargs):
            return self.content

    class FakeLoader(object):
        def __init__(self, path):
            self.path = path

        def path_dwim(self, path):
            return self.path

    # Test when terms is None
    templar = FakeTemplar(None)
    loader = FakeLoader(None)
    actual_terms = listify_lookup_plugin_terms(None, templar, loader, convert_bare=False)
    assert actual_terms == [], "listify_lookup_plugin_terms should be [] when terms is None"

    # Test when terms is a string

# Generated at 2022-06-23 14:24:17.751666
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar, DictData
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars import VariableManager

    data = DictData({
        'foo': [
            'a',
            'b',
            'c',
        ],
    })

    module_args_parser = ModuleArgsParser(dict(), [], False, False, False)
    variable_manager = VariableManager()
    variable_manager.set_available_variables(data)
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)
    templar.set_available_variables(data)

    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader=None) == data['foo']
    assert listify_look

# Generated at 2022-06-23 14:24:29.023069
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    mock_vars = dict(
        key_single="value_single",
        list_var=[1, 2, 3],
        dict_var=dict(a=1, b=2),
    )
    loader = None
    templar = Templar(loader=loader, variables=mock_vars)

    # Single Strings
    assert listify_lookup_plugin_terms("{{ key_single }}", templar, loader) == [u'value_single']
    assert listify_lookup_plugin_terms(u"{{ key_single }}", templar, loader) == [u'value_single']
    assert listify_lookup_plugin_terms("{{ key_single.upper() }}", templar, loader) == [u'VALUE_SINGLE']
    assert list

# Generated at 2022-06-23 14:24:35.826940
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = """
        - {{ var1 }}
        - {{ var2 }}
    """

    templar = Templar(None, loader=None)

    terms = listify_lookup_plugin_terms(terms, templar, loader=None, convert_bare=True)
    assert terms == [u'{{ var1 }}', u'{{ var2 }}']

    terms = listify_lookup_plugin_terms(terms, templar, loader=None, convert_bare=True)
    assert terms == [u'{{ var1 }}', u'{{ var2 }}']

    terms = listify_lookup_plugin_terms(terms, templar, loader=None, convert_bare=False)
    assert terms == [u'{{ var1 }}', u'{{ var2 }}']

    templar

# Generated at 2022-06-23 14:24:47.526541
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    import ansible.constants as C
    import sys

    class VarManager:
        def __init__(self):
            self._fact_cache = dict()
            self._fail_on_undefined = False
            self._use_fact_cache = True
            self._vars = None

        def get_vars(self, loader, play, host, task):
            if self._vars is None:
                self._vars = dict()
                if self._use_fact_cache:
                    self._vars = self._fact_cache.get(host.name, dict())

# Generated at 2022-06-23 14:24:55.792062
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    class MockVarsModule(object):
        pass

    class MockLoaderModule(object):
        def __init__(self, vars_module):
            self.vars_module = vars_module

    vars_module = MockVarsModule()
    vars_module. AnsibleUnsafeText = AnsibleUnsafeText
    loader_module = MockLoaderModule(vars_module)
    templar = Templar(loader=loader_module, variables={})

    # Test recursive templating
    # Simple recursive templating
    data = '{{ item }}'

# Generated at 2022-06-23 14:25:03.695090
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Test a string
    templar = Templar("")
    assert listify_lookup_plugin_terms("foo", templar, "", False) == ['foo']

    # Test a list
    assert listify_lookup_plugin_terms(["foo", "bar"], templar, "", False) == ['foo', 'bar']

    # Test an integer
    assert listify_lookup_plugin_terms(42, templar, "", False) == [42]

    # Test a Python expression
    assert listify_lookup_plugin_terms("{{ 42 + 42 }}", templar, "", False) == [84]

    # Test a Jinja2 expression

# Generated at 2022-06-23 14:25:11.282431
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    lookup = dict(
        name = 'foo',
        terms = ['a', 'b', 'c']
    )
    templar = None
    loader = None
    fail_on_undefined = False
    convert_bare = True
    test = listify_lookup_plugin_terms(lookup['terms'], templar, loader, fail_on_undefined, convert_bare)
    assert test == ['a', 'b', 'c']



# Generated at 2022-06-23 14:25:21.170264
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    if not isinstance(listify_lookup_plugin_terms(['list'], [], []), list):
        raise AssertionError('input of a list should return a list')

    if not isinstance(listify_lookup_plugin_terms('string', [], []), list):
        raise AssertionError('input of a string should return a list')

    if isinstance(listify_lookup_plugin_terms(['list'], [], []), string_types):
        raise AssertionError('input of a list should not return a string')

    if isinstance(listify_lookup_plugin_terms('string', [], []), list):
        raise AssertionError('input of a string should not return a list')


# Generated at 2022-06-23 14:25:28.634974
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible import context
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution

    class MockVarsModule(object):
        def get_vars(self, loader, path, entities, cache=True):
            return {}

    context._init_global_context(MockVarsModule())
    templar = Templar(loader=None, variables={'foo': 'bar', 'dictvar': {'a': 'b'}})
    templar._available_variables = {'foo': 'bar', 'dictvar': {'a': 'b'}}

# Generated at 2022-06-23 14:25:39.530802
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import AttributeDict
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    facts = dict(
        foo='bar',
        biz='baz',
        nested=dict(
            alist=['foo', 'bar', 'baz'],
            adict=dict(
                one='foo',
                two='bar',
                three='baz'
            )
        )
    )

    variables = combine_vars(loader=None, variables=facts)
    templar = Templar(loader=None, variables=variables)


# Generated at 2022-06-23 14:25:48.703716
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Mock the Ansible module and Ansible template
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    # Mock the AnsibleTemplate
    from ansible.template import AnsibleTemplate
    templar = AnsibleTemplate(module, disable_lookups=False)

    # Mock the AnsibleDict
    from ansible.module_utils.six import iteritems
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    class AnsibleVarsModule():

        def __init__(self, fail_on_undefined):
            self.fail_on_undefined = fail_on_undefined

        def get_vars(self):
            return {'foo': 'bar'}


# Generated at 2022-06-23 14:25:59.804967
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms('1', templar, None) == ['1']
    assert listify_lookup_plugin_terms(['1'], templar, None) == ['1']
    assert listify_lookup_plugin_terms([['1']], templar, None) == [['1']]
    assert listify_lookup_plugin_terms([['1', '2']], templar, None) == [['1', '2']]
    assert listify_lookup_plugin_terms([1, '2'], templar, None) == [1, '2']
    assert listify_lookup_plugin_

# Generated at 2022-06-23 14:26:10.908913
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Test listify_lookup_plugin_terms returns a list of terms

    :return:
    """
    from collections import namedtuple
    from ansible.module_utils.six import BytesIO

    import ansible.module_utils.common.json
    import ansible.module_utils.common.yaml
    import ansible.template
    import ansible.vars

    Templar = namedtuple('Templar', ['template'])
    Vars    = namedtuple('Vars', ['template'])
    Vars.get_vars         = lambda self, loader, play, host=None, task=None, include_hostvars=True: {}
    Vars.extract_facts    = lambda self, new_facts, variable_manager, loader=None: {}
    Vars.add_host_vars

# Generated at 2022-06-23 14:26:22.048010
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys
    import os
    # Supply a dummy return value
    def load_return_value(x):
        return x
    # Mock templar
    class Templar:
        def __init__(self, *args):
            self.loader = loader
        # Mock the templar.template function
        def template(self, x, fail_on_undefined=True, convert_bare=False):
            # Test fail_on_undefined argument
            if fail_on_undefined == True:
                return x
            # Test convert_bare argument
            elif convert_bare == True:
                if isinstance(x, string_types):
                    return repr(x)
                else:
                    return x
            else:
                if isinstance(x, string_types):
                    return os.path.basename(x)

# Generated at 2022-06-23 14:26:29.563021
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    terms = '''{{lookup('file', '/tmp/file')}}'''
    terms2 = '''{{lookup('file', '/tmp/file') | string }}'''
    terms3 = '''{{lookup('file', '/tmp/file') | to_json }}'''
    terms4 = '''{{lookup('file', '/tmp/file') | to_yaml }}'''
    terms5 = '''{{lookup('file', '/tmp/file') + [1,2] }}'''
    terms6 = '''{{lookup('file', '/tmp/file') | map('int') | list }}'''

# Generated at 2022-06-23 14:26:40.649504
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    import pytest

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = {'var1': 'ansible'}
    variable_manager.options_vars = {'var2': 'ansible'}

    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ var1 }}', templar, loader) == ['ansible']
    assert listify_look

# Generated at 2022-06-23 14:26:52.373672
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Test: function does not change list input
    terms = ['foo', 'bar']
    listified_terms = listify_lookup_plugin_terms(terms, Templar(loader=None), None)
    assert terms == listified_terms

    # Test: function converts string to single item list
    terms = 'foo'
    listified_terms = listify_lookup_plugin_terms(terms, Templar(loader=None), None)
    assert isinstance(listified_terms, list)
    assert len(listified_terms) == 1
    assert listified_terms[0] == 'foo'

    # Test: function converts tuple to single item list
    terms = ('foo',)
    listified_terms = listify_lookup_plugin_terms(terms, Templar(loader=None), None)
   

# Generated at 2022-06-23 14:27:03.719795
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        from ansible.template import Templar
    except ImportError:
        return False

    terms = ["a", "b", "c"]
    templar = Templar(loader=None, variables={})

    actual = listify_lookup_plugin_terms(terms, templar)
    assert actual == ["a", "b", "c"]

    terms = ["a", ["b","c"]]
    actual = listify_lookup_plugin_terms(terms, templar)
    assert actual == ["a", "b", "c"]

    terms = "a"
    actual = listify_lookup_plugin_terms(terms, templar)
    assert actual == ["a"]

    terms = ["a", "b{{ foo }}c"]

# Generated at 2022-06-23 14:27:10.648210
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import OrderedDict

    class FakeTemplar(object):
        def __init__(self):
            self._data = OrderedDict()

        def template(self, terms, fail_on_undefined=True, convert_bare=False):
            if fail_on_undefined:
                self._data['fail_on_undefined'] = fail_on_undefined
            if convert_bare:
                self._data['convert_bare'] = convert_bare

            if isinstance(terms, string_types):
                terms = terms.strip()
            else:
                terms = '|'.join(terms)

            if terms == 'foo':
                terms = 'FOO'
            if terms == 'bar':
                terms = 'BAR'


# Generated at 2022-06-23 14:27:18.067233
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar()

    # Test the string input variants
    assert listify_lookup_plugin_terms('1', templar, None) == ['1']
    assert listify_lookup_plugin_terms("['1']", templar, None) == ['1']
    assert listify_lookup_plugin_terms("['1', '2']", templar, None) == ['1', '2']

    # Test the list input variants
    assert listify_lookup_plugin_terms(['1'], templar, None) == ['1']
    assert listify_lookup_plugin_terms(['1', '2'], templar, None) == ['1', '2']

# Generated at 2022-06-23 14:27:26.486606
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    fake_loader = object()
    templar = Templar(loader=fake_loader)

    # test a single term
    terms = 'foo'
    res = listify_lookup_plugin_terms(terms, templar, fake_loader)
    assert(isinstance(res, list))
    assert(len(res) == 1)
    assert(res[0] == 'foo')

    terms = 'foo,bar'
    res = listify_lookup_plugin_terms(terms, templar, fake_loader)
    assert(isinstance(res, list))
    assert(len(res) == 1)
    assert(res[0] == 'foo,bar')

    terms = ['foo', 'bar']