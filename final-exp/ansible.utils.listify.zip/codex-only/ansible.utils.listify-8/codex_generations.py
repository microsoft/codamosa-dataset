

# Generated at 2022-06-23 14:17:35.315243
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    my_data = 'n1=v1'
    updated_data = listify_lookup_plugin_terms(my_data, templar, loader=None)
    assert isinstance(updated_data, list)
    assert isinstance(updated_data[0], string_types)

    my_data = ['n1=v1']
    updated_data = listify_lookup_plugin_terms(my_data, templar, loader=None)
    for term in updated_data:
        assert isinstance(term, string_types)


# Generated at 2022-06-23 14:17:45.578784
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert listify_lookup_plugin_terms(None, Templar(None, loader=AnsibleLoader), AnsibleLoader()) == [None]
    assert listify_lookup_plugin_terms('', Templar(None, loader=AnsibleLoader), AnsibleLoader()) == ['']
    assert listify_lookup_plugin_terms([], Templar(None, loader=AnsibleLoader), AnsibleLoader()) == [[]]
    assert listify_lookup_plugin_terms(0, Templar(None, loader=AnsibleLoader), AnsibleLoader()) == [0]


# Generated at 2022-06-23 14:17:55.552151
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludeFile
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible import context
    from ansible.utils.vars import combine_vars
    from ansible.errors import Ans

# Generated at 2022-06-23 14:18:03.671366
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms(1, Templar(loader=None), None) == [1]
    assert listify_lookup_plugin_terms([1,2], Templar(loader=None), None) == [1, 2]
    assert listify_lookup_plugin_terms('1', Templar(loader=None), None) == ["1"]
    assert listify_lookup_plugin_terms('[1, 2]', Templar(loader=None), None) == [1, 2]

# Generated at 2022-06-23 14:18:11.039571
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from collections import namedtuple
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    tmplar = Templar(loader=None, shared_loader_obj=None, variables={})
    TestVars = namedtuple('TestVars', ('value', 'expected'))

# Generated at 2022-06-23 14:18:22.172000
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping
    from units.mock.loader import DictDataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    loader = DictDataLoader({'test_listify_lookup_plugin_terms.yml': ''})
    vault_secrets = Mapping()
    templar = Templar(loader=loader, variables={}, vault_secrets=vault_secrets)

    # test listify_lookup_plugin_terms returns a list of string items, even
    # if they are passed in as a single string
    terms = '{{ lookup("pipe", "echo foo") }}'
    results = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-23 14:18:31.143438
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    terms = "{{ _terms }}"
    templar = Templar(loader=AnsibleLoader(), variables=VariableManager())

    # test simple list
    _terms = ["1", "2", "3"]
    assert(listify_lookup_plugin_terms(terms, templar, AnsibleLoader(), convert_bare=True) == _terms)

    # test simple string
    _terms = "test"
    assert(listify_lookup_plugin_terms(terms, templar, AnsibleLoader(), convert_bare=True) == [_terms])

    # test failure

# Generated at 2022-06-23 14:18:40.029761
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    env = dict(basedir='/home/user/ansible')
    templar = Templar(loader=None, variables=env)

    terms = u"{{ lookup('env', 'basedir') }}/foo"
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['/home/user/ansible/foo']

    terms = "{{ lookup('env', 'basedir') }}/foo"
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['/home/user/ansible/foo']

    terms = [u"/foo", "{{ lookup('env', 'basedir') }}/bar"]

# Generated at 2022-06-23 14:18:49.929992
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping, AnsibleSequence

    fake_loader = namedtuple("FakeLoader", ["path_dwim"])(".")

    assert listify_lookup_plugin_terms("item1", Templar(loader=fake_loader), fake_loader) == ['item1']
    assert listify_lookup_plugin_terms(["item1", "item2"], Templar(loader=fake_loader), fake_loader) == ['item1', 'item2']

    terms = AnsibleBaseYAMLObject()
    terms.value = ["item1", "item2"]


# Generated at 2022-06-23 14:18:55.804693
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    templar = Templar(loader=None, variables={})
    terms = listify_lookup_plugin_terms(["{{ item }}", "foo", "bar", "{{ baz }}"], templar, None, False)
    assert terms == ["{{ item }}", "foo", "bar", "{{ baz }}"]

# Generated at 2022-06-23 14:19:02.932763
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    loader = 'foobar'


# Generated at 2022-06-23 14:19:13.548856
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib

    terms_str = '{{ var_str }}'
    terms_list = [ '{{ var_str }}' ]
    terms_tuple = ( '{{ var_str }}', )
    terms_dict = dict(var_str='{{ var_str }}')
    var_str = 'var_str'

    def run_test(terms):
        templar = Templar(loader=None, shared_loader_obj=None, vault_secrets=VaultLib(), environment=dict())
        terms = listify_lookup_plugin_terms(terms, templar, loader=None)

        assert isinstance(terms, list)
        assert isinstance

# Generated at 2022-06-23 14:19:24.400413
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = None
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '1 2 3'
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert (results == ['1', '2', '3'])

    # Test string with spaces
    terms = '1 2      3 '
    results = listify_lookup_plugin_

# Generated at 2022-06-23 14:19:32.866745
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.module_utils.common.collections import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()

    my_vars = AnsibleMapping({'omg': ['hi', 'hi2']})
    templar = Templar(loader=dataloader, variables=my_vars)

    # Simple test, should return as a list
    assert listify_lookup_plugin_terms('{{omg}}', templar, dataloader) == ['hi', 'hi2']

    # Check that we can still use convert_bare

# Generated at 2022-06-23 14:19:44.610935
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from units.compat.builtins import str

    context = PlayContext()
    templar = Templar(loader=DictDataLoader({}), variables=VariableManager(), all_vars={'foo': 'bar', 'bar': 'baz'})
    data = { 'ansible_facts': { 'foo': 'bar' } }

    # "py3" (or "python3") is not a valid string for a lookup plugin term so
    # we provide a special handling in lookup plugins to convert it to a list

# Generated at 2022-06-23 14:19:52.756996
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    loader = DataLoader()
    templar = Templar(loader=loader)
    # Basic test for single value for terms
    terms = listify_lookup_plugin_terms('val1', templar, loader)
    assert terms == ['val1']
    # Basic test for list of values for terms
    terms = listify_lookup_plugin_terms(['val1', 'val2'], templar, loader)
    assert terms == ['val1', 'val2']
    # Test templating
    terms = listify_lookup_plugin_terms(['val1', '{{val2}}', '{{val3}}'], templar, loader)

# Generated at 2022-06-23 14:20:03.725634
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # Params for function listify_lookup_plugin_terms

# Generated at 2022-06-23 14:20:15.159812
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ foo }},{{ bar }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}', '{{ bar }}']

    # Test list of strings

# Generated at 2022-06-23 14:20:24.583690
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Data
    tests = [
        # terms, expected result
        (None,                                 []),
        ({'a': 10},                            [{'a': 10}]),
        ((1, 2, 3),                            [1, 2, 3]),
        ([4, 5, 6],                            [4, 5, 6]),
        ('1',                                  ['1']),
        ('12',                                 ['12']),
        ('this is a string',                   ['this is a string']),
    ]

    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))
    for terms, expected_result in tests:
        assert listify_lookup_plugin_terms(terms, templar, None) == expected_result

# Generated at 2022-06-23 14:20:36.190834
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    test_listify_lookup_plugin_terms: listify_lookup_plugin_terms unit test
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables={'a': '1', 'b': '2', 'c': '3'})

    # Should return a list of strings
    result = listify_lookup_plugin_terms('{{a}}', templar, loader)
    assert isinstance(result, list)
    assert len(result) == 1
    assert isinstance(result[0], string_types)
    assert result[0] == '1'

   

# Generated at 2022-06-23 14:20:47.065980
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import PY2
    from ansible.module_utils.ansible_modlib import Runner
    import sys

    if PY2:
        import imp
        imp.find_module('ansible.module_utils.common._collections_compat')
        loader = imp.load_module('ansible.module_utils.common._collections_compat', *imp.find_module('ansible.module_utils.common._collections_compat'))
    else:
        import importlib
        importlib.import_module('ansible.module_utils.common._collections_compat')
        loader = sys.modules['ansible.module_utils.common._collections_compat']


# Generated at 2022-06-23 14:20:57.170678
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableSet
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar

    vault_password = 'CHANGEME'

    templar = Templar(loader=None, variables={})

    # test list
    terms = ['one', 'two', 'three']
    terms = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert terms == ['one', 'two', 'three']

    # test string with no jinja2
    terms = 'one two three'
    terms = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert terms

# Generated at 2022-06-23 14:21:00.738990
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('this is a string', None, None) == ['this is a string']
    assert listify_lookup_plugin_terms(['a', 'b'], None, None) == ['a', 'b']

# Generated at 2022-06-23 14:21:08.571054
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import os
    import sys
    import tempfile
    sys.path.insert(1, os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins'))
    from lookups import zypper
    from jinja2 import Template

    templar = Template('')

    class FakeLoader(object):
        def __init__(self):
            self.name = 'fake_loader'
            self.path_cache = dict()

        def path_dwim(self, name):
            return self.path_cache.get(name, None)

        def get_basedir(self, task_name):
            return 'fake_path'

    loader = FakeLoader()
    loader.path_cache[os.path.abspath('./repos.yml')] = os

# Generated at 2022-06-23 14:21:16.872693
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    from ansible.playbook.play_context import PlayContext

    class TestClass(object):
        def __init__(self):
            self.vars = {}

    templar = ansible.template.AnsibleTemplate(loader=None, variables=TestClass())
    terms = listify_lookup_plugin_terms('{{ foo[0].bar }}', templar, loader=None)
    assert terms == ['{{ foo[0].bar }}']

    templar = ansible.template.AnsibleTemplate(loader=None, variables=PlayContext())
    templar.set_available_variables(dict(foo=[dict(bar='baz')]))
    terms = listify_lookup_plugin_terms('{{ foo[0].bar }}', templar, loader=None)

# Generated at 2022-06-23 14:21:26.026037
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from sys import version_info
    if version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    from ansible.module_utils._text import to_text
    from ansible.module_utils.yaml.constructor import AnsibleConstructor
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    text = u'''
    - foo
    - bar
    - baz
    '''
    input_data = AnsibleLoader(StringIO(text), None, AnsibleConstructor).get_single_data()
    templar = Templar(loader=dir())
    output = listify_lookup_plugin_terms(input_data, templar, loader=dir())

# Generated at 2022-06-23 14:21:37.240710
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar, _get_filenames, _unfrack_path
    import os

    class Options:
        _basedir = '.'
        _fqcn = True

    f, d = _get_filenames(Options(), '.')
    templar = Templar(loader, variables={}, fail_on_undefined=True, convert_bare=False)
    # 1. test string variable
    variables = { "str": "str test" }
    terms = listify_lookup_plugin_terms("{{str}}", templar, loader, fail_on_undefined=True, convert_bare=False)
    assert terms == ['str test']
    # 2. test list variable
    variables = { "list": [1, 2, 3] }
    terms = listify_lookup_plugin_terms

# Generated at 2022-06-23 14:21:47.164931
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.module_utils._text import to_text

    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables={})

    # tests the listify_lookup_plugin_terms function to
    # handle the case when templar.template fails
    terms = "{{ value }}"
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert to_text(results) == "{{ value }}"

    # tests the listify_lookup_plugin_terms function to handle case
    # when templar.template passes
    terms = "{{ key }}"
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert to_text(results) == "{{ key }}"

   

# Generated at 2022-06-23 14:21:51.444347
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.module_utils.common._collections_compat.tests.unit.test_listify_lookup_plugin_terms as test_listify_lookup_plugin_terms
    test_listify_lookup_plugin_terms.test_listify_lookup_plugin_terms()

# Generated at 2022-06-23 14:22:01.566840
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    context = PlayContext()
    templar = Templar(loader=loader, variables=dict())
    terms = ['1', '2', '3', '4']
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['1', '2', '3', '4']

    terms = '1,2,3,4'
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['1', '2', '3', '4']

    terms = '{{ test_var }}'
    templar._available_

# Generated at 2022-06-23 14:22:13.107714
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms(
        'a string', templar, None, False, False
    ) == ['a string']

    assert listify_lookup_plugin_terms(
        ['a list'], templar, None, False, False
    ) == ['a list']

    assert listify_lookup_plugin_terms(
        dict(a=1, b=2, c=3), templar, None, False, False
    ) == [dict(a=1, b=2, c=3)]


# Generated at 2022-06-23 14:22:21.005581
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    dl = DataLoader()
    inv_mgr = InventoryManager(loader=dl)

    vm = VariableManager(loader=dl, inventory=inv_mgr)

    terms = ["{{ 'foo' | string }}", "{{ ['bar'] | string }}", "baz"]
    templar = Templar(loader=dl, variables=vm)
    result = listify_lookup_plugin_terms(terms, templar, dl, convert_bare=True)

    assert isinstance(result, list)
    assert result == ['foo', 'bar', 'baz']

# Generated at 2022-06-23 14:22:31.962587
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict

    terms = OrderedDict()
    terms["list_1"] = ["value_1", "value_2", "value_3"]
    terms["list_2"] = "value_4"
    terms["list_3"] = "{{ value_5 }}"
    terms["list_4"] = ["{{ value_6 }}", "value_7", 1234]

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    templar = Templar(loader=None)

    new_terms = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=True)

    assert new_

# Generated at 2022-06-23 14:22:42.255847
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    templar = Templar(loader=None, variables=dict(foo='bar'), vault_secrets=VaultLib())

    assert ['a', 'b', 'c'] == listify_lookup_plugin_terms('a, b, c', templar, fail_on_undefined=False)
    assert ['a, b', 'c'] == listify_lookup_plugin_terms('a\\, b , c', templar, fail_on_undefined=False)
    assert ['a, b', 'c'] == listify_lookup_plugin_terms('"a, b", c', templar, fail_on_undefined=False)
    assert ['a', 'b', 'c'] == listify_lookup_plugin_

# Generated at 2022-06-23 14:22:52.667890
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    arguments = dict(
        terms='foo, bar',
        templar=Templar(),
        loader=None,
        fail_on_undefined=False,
        convert_bare=False,
    )

    assert listify_lookup_plugin_terms(**arguments) == ['foo', 'bar']

    arguments = dict(
        terms='foo',
        templar=Templar(),
        loader=None,
        fail_on_undefined=False,
        convert_bare=False,
    )

    assert listify_lookup_plugin_terms(**arguments) == ['foo']


# Generated at 2022-06-23 14:22:59.103070
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('1,2,3', templar=None, loader=None, fail_on_undefined=False, convert_bare=True) == [1, 2, 3]
    assert listify_lookup_plugin_terms('1,2,3', templar=None, loader=None, fail_on_undefined=False, convert_bare=False) == ['1,2,3']
    assert listify_lookup_plugin_terms('1,2,{{a}},4', templar=None, loader=None, fail_on_undefined=False, convert_bare=True) == [1, 2, '{{a}}', 4]

# Generated at 2022-06-23 14:23:10.196933
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    arguments = dict(
        foo='bar',
        bar='baz',
        path=['/etc/path', '/usr']
    )
    templar = DummyVars(arguments)
    loader = DummyLoader()

    result = listify_lookup_plugin_terms(['/etc/{{ foo }}', '/usr/{{ bar }}'], templar, loader)
    assert result == ['/etc/bar', '/usr/baz']

    result = listify_lookup_plugin_terms('/{{ path }}/{{ foo }}', templar, loader)
    assert result == ['/etc/path/bar', '/usr/bar']

    result = listify_lookup_plugin_terms(['/etc/{{ foo }}', '/usr/{{ path }}'], templar, loader)

# Generated at 2022-06-23 14:23:20.633131
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # FIXME: add test that converts bare vars with convert_bare=True
    # FIXME: add test that fails with fail_on_undefined=True
    # FIXME: add test that converts template with ansible vars in it

    # FIXME: create class that mocks Templar, and create instance in all the
    # test cases below

    # returns a single value when given a string
    assert listify_lookup_plugin_terms('string', None, None) == ['string']

    # returns a single value when given a number
    assert listify_lookup_plugin_terms(42, None, None) == [42]

    # returns a single value when given a boolean
    assert listify_lookup_plugin_terms(True, None, None) == [True]

    # returns a list of values when given a list
    assert list

# Generated at 2022-06-23 14:23:29.643091
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    # Simple
    terms = listify_lookup_plugin_terms('foo', templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert terms == ['foo']

    # Simple with convert bare
    terms = listify_lookup_plugin_terms('{{ foo }}', templar, loader=None, fail_on_undefined=True, convert_bare=True)
    assert terms == ['{{ foo }}']

    # Simple with convert bare and variable
    terms = listify_lookup_plugin_terms('{{ foo }}', templar, loader=None, fail_on_undefined=True, convert_bare=True)
    assert terms == ['{{ foo }}']

    # Simple with variable


# Generated at 2022-06-23 14:23:37.315977
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeTemplar(object):
        def template(self, terms, convert_bare=False, fail_on_undefined=True):
            return terms
    class FakeLoader(object):
        def get_basedir(self, terms):
            return ""
    fake_loader=FakeLoader()
    fake_templar=FakeTemplar()
    temp_list=listify_lookup_plugin_terms(["1", "2", "3"], fake_templar, fake_loader)
    print(temp_list)
    assert temp_list == ["1","2","3"]
    temp_list=listify_lookup_plugin_terms({"a":1,"b":2,"c":3}, fake_templar, fake_loader)
    print(temp_list)

# Generated at 2022-06-23 14:23:47.137973
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    results = []
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=loader)

    assert listify_lookup_plugin_terms(terms="foo", templar=templar, loader=loader) == ['foo']

# Generated at 2022-06-23 14:23:57.333367
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    my_vars = dict(
        foo='bar',
        baz=[1, 2, 3],
        qux=dict(
            ansible='cool',
            python='3',
        ),
    )

    loader = DictDataLoader({'whatever': ''})
    templar = Templar(loader=loader, variables=my_vars)

    lookup_terms = [
        '{{ foo }}',
        ['{{ baz }}', '{{ qux.ansible }}'],
        ['{{ qux.python }}', 'more'],
    ]

    expected = ['bar', ['1', '2', '3', 'cool'], ['3', 'more']]
    result = listify_lookup_plugin_terms(lookup_terms, templar, loader)

# Generated at 2022-06-23 14:24:07.567679
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    loader = DataLoader()
    templar = Templar(loader=loader)

    assert ['foo', 'bar', 'baz'] == listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader, fail_on_undefined=True)
    assert ['foo', 'bar', 'baz'] == listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader, convert_bare=True)
    assert ['foo', 'bar', 'baz'] == listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader, convert_bare=False)

# Generated at 2022-06-23 14:24:17.877452
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Setup
    fake_loader = dict(paths=['/fake/path'])
    templar = Templar(loader=fake_loader, shared_loader_obj=fake_loader)

    # Assert simple string
    assert listify_lookup_plugin_terms('simple', templar, fake_loader) == ['simple']

    # Assert simple list
    assert listify_lookup_plugin_terms(['simple'], templar, fake_loader) == ['simple']

    # Assert simple dict
    assert listify_lookup_plugin_terms({'simple': 'dict'}, templar, fake_loader) == [{'simple': 'dict'}]

    # Assert simple Jinja2 string

# Generated at 2022-06-23 14:24:29.154011
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # initialize needed objects
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 14:24:35.471280
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing import vault
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    # simple string
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    # simple string with vars
    assert listify_lookup_plugin_terms('foo {{bar}}', templar, None, True) == ['foo {{bar}}']
    # list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    # list with vars
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{baz}}'], templar, None, True) == ['foo', 'bar', '{{baz}}']
    #

# Generated at 2022-06-23 14:24:47.116743
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    terms = ["{{a}}", "{{b}}"]
    vars = VariableManager()
    vars.add_host_vars_from_inventory({"hostvars": {
        "host1": {
            "a": "outer_a",
            "b": "outer_b",
            "inner": {
                "a": "inner_a",
                "b": "inner_b",
            },
        }
    }})
    templar = Templar(loader=AnsibleLoader(None), variables=vars)

# Generated at 2022-06-23 14:24:55.399879
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class DummyAnsibleModule():
        def __init__(self):
            self.fail_json = lambda *x, **y: x[0]
    class DummyAnsibleModuleArgs():
        def __init__(self, args):
            self.args = args
    class DummyAnsibleModule():
        def __init__(self, module_args=None):
            self.params = module_args
    import ansible.utils.template as templar
    class DummyVars(dict):
        def __getattr__(self, name):
            return self[name]
        def __setattr__(self, name, val):
            self[name] = val
    dummy = DummyVars()
    dummy.foo = "bar"
    def dummy_get_vars(loader, path):
        return

# Generated at 2022-06-23 14:25:05.267903
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variables = VariableManager()
    templar = Templar(loader=loader, variables=variables)

    terms = 'foo'
    results1 = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False)
    results2 = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True)
    assert( results1 == ['foo'] )
    assert( results2 == ['foo'] )

    terms = 'foo,bar'

# Generated at 2022-06-23 14:25:12.462741
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar

    terms = ['a', 'b']
    assert isinstance(listify_lookup_plugin_terms(terms, ""), Sequence)

    assert isinstance(listify_lookup_plugin_terms("a, b", ""), Sequence)

    single_item = listify_lookup_plugin_terms("a", Templar(""), None, True)
    assert isinstance(single_item, Sequence)
    assert len(single_item) == 1
    assert single_item[0] == 'a'

    templar = Templar("")
    terms = ['a', 'b']
    items = listify_lookup_plugin_terms(terms, templar, None)
    assert items == terms


# Generated at 2022-06-23 14:25:22.269850
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Checks whether function listify_lookup_plugin_terms
    # works properly or not by running unit test.
    # This runs only if __name__ == '__main__'
    # as it is a unit test for this module

    import ansible.constants as C
    from ansible.galaxy import Galaxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.template import Templar

    terms = "{{lookup_file}}"

    loader = DataLoader()
    galaxy = Galaxy(loader=loader)

    variable_manager = VariableManager()
    variable_manager.set_inventory(galaxy.get_inventory("localhost"))

    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-23 14:25:33.446704
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars

    t = Templar(loader=None, variables=VariableManager())
    terms = {'name': 'n1', 'nested': {'foo': 'bar'}}
    assert terms == listify_lookup_plugin_terms(terms, t, None, fail_on_undefined=True, convert_bare=False)
    assert terms == listify_lookup_plugin_terms(terms, t, None, fail_on_undefined=True, convert_bare=True)
    assert terms == listify_lookup_plugin_terms(terms, t, None, fail_on_undefined=False, convert_bare=False)

# Generated at 2022-06-23 14:25:42.736621
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    tester = Templar(None, None, loader=None, variables=VariableManager(inventory=Inventory(None)))
    result = listify_lookup_plugin_terms('string', tester)
    assert isinstance(result, list)
    assert result == ['string']
    result = listify_lookup_plugin_terms(['string'], tester)
    assert isinstance(result, list)
    assert result == ['string']
    result = listify_lookup_plugin_terms(['many', 'strings'], tester)
    assert isinstance(result, list)
    assert result == ['many', 'strings']
    result = listify

# Generated at 2022-06-23 14:25:51.541190
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Using the test password from ansible/test/utils/vault/test_vault.py
    vault_pass = '$ANSIBLE_VAULT;1.1;AES256\n363033356466316339623132316263343930333830643934376231633465386266323337686566\n356630393963376262316532643063653166366164323532666263376131623239663635376235\n3833343461663264\n'
    vault_secret = 'secret'

# Generated at 2022-06-23 14:26:02.248561
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    class TestVarsModule:
        def __init__(self, hostname):
            self.hostname = hostname

        def get_vars(self):
            return dict(hostname=self.hostname)

    loader = DataLoader()
    def test_vars(self, hostname, *args, **kwargs):
        return TestVarsModule(hostname)

    loader.set_vars_cache(test_vars)

    templar = Templar(loader=loader)
    templar.environment.loader = loader
    templar.ENABLE_JINJA2_EXTENSIONS = C.DEFAULT_JINJA2_EXTENSIONS
    templar

# Generated at 2022-06-23 14:26:12.418182
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-23 14:26:22.102690
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Set up fixtures
    class TestVarsModule:
        def get_vars(self, loader, path, entities):
            return {}

    # Set up fixtures
    class Options:
        def __init__(self):
            self.vault_password_file = None
            self.ask_vault_pass = False
            self.new_vault_password_file = None
            self.vault_ids = []

    class Play:
        def __init__(self):
            self

# Generated at 2022-06-23 14:26:27.692294
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Load up the basic test environment
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    try:
        from ansible.module_utils._text import to_bytes
    except ImportError:
        # Ansible < 2.6
        to_bytes = str
    import ansible.module_utils.urls
    import ansible.module_utils.json_utils

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    loader = DictDataLoader({
        'test.yml': """
    key:
      - val1
      - val2
    """,
    })
    basic._ANSIBLE_ARGS = None
    ansible.module_utils.urls.HAS_SS

# Generated at 2022-06-23 14:26:39.606201
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import BytesIO
    from ansible.template import Templar

    def get_vars(args):
        return dict(a=args[0])

    templar = Templar(loader=None, variables=get_vars)

# Generated at 2022-06-23 14:26:51.744427
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = ['{{ [1,2,3] }}']
    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms(terms, templar, None) == [1,2,3]

    terms = '{{ "abc" }}'
    assert listify_lookup_plugin_terms(terms, templar, None) == ['abc']

    terms = '{{ 123 }}'
    assert listify_lookup_plugin_terms(terms, templar, None) == ['123']

    terms = 123
    assert listify_lookup_plugin_terms(terms, templar, None) == [123]

    terms = [123, '{{ "abc" }}']

# Generated at 2022-06-23 14:27:02.872380
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    vars_manager = VariableManager()
    vars_manager.set_host_variable("hostvars", dict(a='a', b='b'))
    loader = None
    templar = Templar(loader=loader, variables=vars_manager)


# Generated at 2022-06-23 14:27:13.563735
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Import is here to avoid import loop
    import ansible.playbook.play_context
    import ansible.template.template

    loader = DictDataLoader({})
    variable_manager = ansible.vars.VariableManager()
    variable_manager.extra_vars = {'test': 'foo'}
    variable_manager.options_vars = {'test': 'foo'}
    variable_manager.set_inventory(ansible.inventory.Inventory(loader=loader))
    variable_manager._fact_cache = dict()
    play_context = ansible.playbook.play_context.PlayContext()
    templar = ansible.template.template.Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))

    # String with no template tags
    terms = listify_

# Generated at 2022-06-23 14:27:23.567085
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor import task_queue_manager
    from ansible.plugins.loader import lookup_loader, module_loader

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 14:27:32.610335
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar

    # Note: add_jinja2_extensions(self) must be called in order to access jinja2 filters from the Templar
    t = Templar(loader=None)
    t.add_jinja2_extensions()
    terms = "string"
    results = listify_lookup_plugin_terms(terms, t, None)
    assert isinstance(results, Sequence)
    assert len(results) == 1
    assert results[0] == "string"

    terms = [ "string1", "string2" ]
    results = listify_lookup_plugin_terms(terms, t, None)
    assert isinstance(results, Sequence)
    assert len(results) == 2