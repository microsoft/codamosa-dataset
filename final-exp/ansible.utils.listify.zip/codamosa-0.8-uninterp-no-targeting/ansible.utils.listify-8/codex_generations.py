

# Generated at 2022-06-21 08:45:37.934188
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader, variables={'a': 1, 'b': 2})
    C.DEFAULT_HASH_BEHAVIOUR = 'replace'

    # Ensure that with a list, we still have a list
    terms = ['{{ a }}', '{{ b }}']
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)
    assert isinstance(result, Iterable)

    # Ensure that with a string, we convert it to a list
    terms = '{{ a }}'

# Generated at 2022-06-21 08:45:45.864083
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode

    var_manager = VariableManager()
    var_manager.extra_vars = {'to_be_templated': '{{ foo }}'}

    play_context = PlayContext()
    play_context.variable_manager = var_manager

    templar = Templar(loader=None, variables=var_manager, templar_implementation='Jinja2')

    assert listify_lookup_plugin_terms('{{ foo }}', templar, play_context.loader, fail_on_undefined=True, convert_bare=False) == ['{{ foo }}']
    assert listify_lookup_

# Generated at 2022-06-21 08:45:55.109611
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    templar = Templar(loader=None, shared_loader_obj=None)

    # listify_lookup_plugin_terms should return a list when given an AnsibleUnicode object.
    assert isinstance(listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, loader=None, fail_on_undefined=True, convert_bare=False), list)

    # listify_lookup_plugin_terms should return a list of AnsibleUnicode objects when given a list of AnsibleUnicode objects.
    test_list = [AnsibleUnicode('foo'), AnsibleUnicode('bar')]

# Generated at 2022-06-21 08:46:04.439704
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    # Setup Templar
    t = Templar(loader=None, variables=combine_vars(dict()))

    # Test for listify_lookup_plugin_terms function
    list = listify_lookup_plugin_terms("{{test_string}}", t, None, True)
    assert(len(list) == 1)
    assert(isinstance(list[0], string_types))
    assert(list[0] == "{{test_string}}")
    list = listify_lookup_plugin_terms(["{{test_string}}", "{{test_string}}"], t, None, True)
    assert(len(list) == 2)
    assert(isinstance(list[0], string_types))

# Generated at 2022-06-21 08:46:15.668800
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This is a horrible mock, but in the spirit of not writing new code
    class Templar:
        def template(self, terms, fail_on_undefined=True, convert_bare=False):
            return terms
    # Test case 1: terms as string
    terms = "test"
    templar = Templar()
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert list == type(result)
    assert 1 == len(result)
    assert terms == result[0]
    # Test case 2: terms as list
    terms = ["test1", "test2"]
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert list == type(result)
    assert 2 == len(result)
    assert "test1" == result[0]


# Generated at 2022-06-21 08:46:25.049588
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3 as _PY3

    loader = AnsibleLoader(None, None)

    if _PY3:
        unicode = str
        string_type = str
    else:
        unicode = unicode
        string_type = basestring

    mytemplar = Templar(loader=loader, shared_loader_obj=loader)

    result = listify_lookup_plugin_terms("{{ 'foo' }}", mytemplar, loader)
    assert result == ['foo']


# Generated at 2022-06-21 08:46:30.493023
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)
    test1 = '{{ ansible_distribution }}'
    test2 = ['{{ ansible_distribution }}']
    test3 = ('{{ ansible_distribution }}', '{{ ansible_distribution }}')
    test4 = "{{ ansible_distribution }}"
    test5 = "{{ ansible_distribution }},{{ ansible_distribution }}"
    test6 = ["{{ ansible_distribution }}", "{{ ansible_distribution }}"]

# Generated at 2022-06-21 08:46:42.174848
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class fake_templar():
        def template(self, terms, **kwargs):
            return terms

    class fake_loader():
        def get_basedir(self):
            return 'a/b'

    # Already a list - returns the same
    x = [1, 2]
    y = listify_lookup_plugin_terms(x, fake_templar(), fake_loader())
    assert x == y

    # A string - converts to a list
    x = 'a'
    y = listify_lookup_plugin_terms(x, fake_templar(), fake_loader())
    assert isinstance(y, list)
    assert x == y[0]

    # An int - converts to a list
    x = 1

# Generated at 2022-06-21 08:46:52.245031
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = listify_lookup_plugin_terms("{{ 'foo' }}", Templar({}), None, fail_on_undefined=False)
    assert terms == ['foo']

    terms = listify_lookup_plugin_terms("foo", Templar({}), None, fail_on_undefined=False)
    assert terms == 'foo'

    terms = listify_lookup_plugin_terms([1, 2, 3], Templar({}), None, fail_on_undefined=False)
    assert terms == [1, 2, 3]

    terms = listify_lookup_plugin_terms([1, 2, 3], Templar({}), None, fail_on_undefined=False, convert_bare=True)
    assert terms == [1, 2, 3]

    terms = listify_lookup

# Generated at 2022-06-21 08:46:59.271145
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = u'{{a}}'
    templar = type('Templar', (), { "template": lambda self, args, fail_on_undefined=True: [unicode(args)] })
    loader = None
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == [u'{{a}}']
    terms = [u'{{a}}', u'{{b}}']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == [u'{{a}}', u'{{b}}']

# Generated at 2022-06-21 08:47:12.178170
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar

    loader = DummyLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(['a', 'b'], templar) == ['a', 'b']
    assert listify_lookup_plugin_terms('c', templar) == ['c']
    assert listify_lookup_plugin_terms(u'â', templar) == ['â']
    assert listify_lookup_plugin_terms(to_text(u'â'), templar) == ['â']
    assert listify_lookup_plugin_terms(u'â', templar, fail_on_undefined=False) == [u'â']


# Generated at 2022-06-21 08:47:18.120556
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import json

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    my_vars = json.loads('{"hello": "world"}')
    variable_manager.extra_vars = my_vars

    my_inventory = json.loads('{"_meta": {"hostvars": {"foo": {"var": "val"}}}}')
    variable_manager.inventory = my_inventory

    templar = Templar(loader, variable_manager)

    assert listify_lookup_plugin_terms(['one','two','{{ hello }}','three','four'], templar, loader)==['one','two','world','three','four']

# Generated at 2022-06-21 08:47:29.307313
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import unittest

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestListifyLookupPluginTerms(unittest.TestCase):
        def setUp(self):
            self.play_context = PlayContext()
            self.variable_manager = VariableManager()
            self.loader = None
            self.templar = Templar(loader=self.loader,
                                   variables=self.variable_manager,
                                   shared_loader_obj=False)

        def tearDown(self):
            pass

        def test_listify_lookup_plugin_terms_input_str(self):
            input_str = "['a', 'b', 'c']"

# Generated at 2022-06-21 08:47:42.150473
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils import context_objects as co
    from ansible.template import Templar

    names = ['foo', 'bar', 'baz', 'qux']

    # Env var foo=bar
    loader = DictDataLoader({})
    variables = VariableManager()

    # Test for list/string
    for test_term in names:
        terms = listify_lookup_plugin_terms(test_term, Templar(variables, loader), loader)
        assert isinstance(terms, list)
        assert len(terms) == 1
        assert test_term in terms

    # Test for list of strings
    terms = listify_lookup_plugin_terms(names, Templar(variables, loader), loader)
    assert isinstance(terms, list)
    assert len(terms) == len(names)

# Generated at 2022-06-21 08:47:51.819453
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(basedir='.'))
    assert listify_lookup_plugin_terms(to_bytes("{{ 'a' }}"), templar, AnsibleLoader(basedir='.')) == ['a']
    assert listify_lookup_plugin_terms([to_bytes("{{ 'a' }}"), to_bytes("{{ 'b' }}")], templar, AnsibleLoader(basedir='.')) == ['a', 'b']

# Generated at 2022-06-21 08:47:59.339238
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    # ensure expected inputs are unmodified
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']

    # ensure string inputs are converted
    assert listify_lookup_plugin_terms('foo,bar', templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(' foo,bar ', templar, None) == ['foo', 'bar']

    # ensure that variables and Jinja template rendering is supported
    assert listify_lookup_plugin_terms('foo, {{ "bar" }}', templar, None) == ['foo', 'bar']

# Generated at 2022-06-21 08:48:09.387640
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = DataLoader()

    templar = Templar(loader=loader, variables=variable_manager)

    results = listify_lookup_plugin_terms('foo', templar, loader)
    assert results == ['foo']

    results = listify_lookup_plugin_terms(['foo'], templar, loader)
    assert results == ['foo']

    results = listify_lookup_plugin_terms(['foo','bar'], templar, loader)
    assert results == ['foo','bar']


# Generated at 2022-06-21 08:48:20.063441
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeLoader:
        pass

    lp_terms = ['foo', 'bar', 'baz']

    templar = Templar(loader=FakeLoader())
    lp_terms_templated = listify_lookup_plugin_terms(lp_terms, templar, FakeLoader())
    assert lp_terms_templated == lp_terms

    lp_terms_templated = listify_lookup_plugin_terms(lp_terms[0], templar, FakeLoader())
    assert lp_terms_templated == lp_terms[0:1]

    lp_terms_templated = listify_lookup_plugin_terms(lp_terms[1], templar, FakeLoader())
    assert lp_terms_templated == lp_

# Generated at 2022-06-21 08:48:30.722038
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.loader import lookup_loader

    assert listify_lookup_plugin_terms(
        AnsibleUnicode("{{ foo }}"),
        Templar(loader=lookup_loader, variables=dict(foo=['bar', 'baz'])),
        lookup_loader
    ) == [u'bar', u'baz']

    assert listify_lookup_plugin_terms(
        AnsibleUnicode("{{ foo }}"),
        Templar(loader=lookup_loader, variables=dict(foo=[1, 2])),
        lookup_loader
    ) == [1, 2]


# Generated at 2022-06-21 08:48:40.843261
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    p = PlayContext()
    t = Templar(loader=None, variables=dict(foo='bar'))

    # Basic string
    terms = listify_lookup_plugin_terms('{{ foo }}', t, None)
    assert terms == ['bar'], terms

    # Basic list
    terms = listify_lookup_plugin_terms(['one', 'two', 'three'], t, None)
    assert terms == ['one', 'two', 'three'], terms

    # Basic list with template
    terms = listify_lookup_plugin_terms(['one', '{{ foo }}', 'three'], t, None)
    assert terms == ['one', 'bar', 'three'], terms

# Generated at 2022-06-21 08:48:54.886279
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    assert listify_lookup_plugin_terms('var', None, None) == ['var']
    assert listify_lookup_plugin_terms(u'var', None, None) == ['var']
    assert listify_lookup_plugin_terms(u'var,other', None, None) == ['var', 'other']
    assert listify_lookup_plugin_terms(['var'], None, None) == ['var']
    assert listify_lookup_plugin_terms(['var', 'other'], None, None) == ['var', 'other']
    assert listify_lookup_plugin_terms(AnsibleUnicode('var'), None, None) == ['var']

# Generated at 2022-06-21 08:49:02.636408
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # empty vars and no args
    result = listify_lookup_plugin_terms(None, None, None)
    assert result == []

    # empty vars, but with a term list
    result = listify_lookup_plugin_terms([], None, None)
    assert result == []

    # empty vars, with a string
    result = listify_lookup_plugin_terms('', None, None)
    assert result == ['']

    # no templar, with a string
    result = listify_lookup_plugin_terms('', Templar, None)
    assert result == ['']

    # a vars but not a templar, with a string

# Generated at 2022-06-21 08:49:14.956809
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    def templar_helper(terms, convert_bare=False, fail_on_undefined=False):
        return terms

    templar = Templar(loader=None, variables={})
    templar.template = templar_helper

    # Test string
    terms = listify_lookup_plugin_terms('test', templar)
    assert terms == ['test']

    # Test list
    terms = listify_lookup_plugin_terms(['test1', 'test2'], templar)
    assert terms == ['test1', 'test2']

    # Test list with list deeper
    terms = listify_lookup_plugin_terms(['test1', ['test2', 'test3']], templar)

# Generated at 2022-06-21 08:49:24.077340
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class HostVars(object):
        def __init__(self, **kwargs):
            self.vars = kwargs

    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    templar = Templar(VariableManager(), play_context=PlayContext(), loader=None)

    hostvars = HostVars(item1=1, list1=[1,2,3], dict1={'i':1})
    templar._available_variables = hostvars.vars
    templar._templar__aliases = hostvars.vars

    terms = listify_lookup_plugin_terms("{{ item1 }}", templar, loader=None)
    assert isinstance(terms, list)
    assert len

# Generated at 2022-06-21 08:49:33.924215
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    variable_manager.extra_vars = {'a':1, 'b':2}

    template_args = {'loader': loader, 'templar': Templar(loader=loader, variable_manager=variable_manager)}

    terms_list = ['{{ a }}','{{ b }}','3','4','5','{{ c }}']
    ret = listify_lookup_plugin_terms(terms_list, **template_args)
    ans = ['1','2','3','4','5','{{ c }}']
    assert ret == ans

# Generated at 2022-06-21 08:49:44.289118
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.template import Templar

    from ansible.plugins.loader import lookup_loader

    from ansible.vars import VariableManager

    results = []

    for item in (
            '{{ a }}',
            ['{{ a }}'],
            ['{{ a }}', '{{ b }}'],
            ['{{ a }}', '{{ b }}', '{{ c }}'],
    ):
        templar = Templar(loader=lookup_loader, variable_manager=VariableManager())
        terms = listify_lookup_plugin_terms(item, templar, loader=lookup_loader)
        assert isinstance(terms, Iterable)
        results.append(terms)


# Generated at 2022-06-21 08:49:54.636477
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    test_template = "{{ '1' }} {{ '2' }} {{ '3' }}"
    test_dict = {'1': 'a', '2': 'b', '3': 'c'}
    test_terms = ['a', 'b', 'c']
    test_fail_template = "{{ 1 }} {{ 2 }} {{ 3 }}"

    templar = Templar(loader=None, variables=test_dict)

    assert type(templar.template(test_template)) is str
    assert listify_lookup_plugin_terms(test_template, templar, loader=None) == test_terms
    assert listify_lookup_plugin_terms(test_template, templar, loader=None, fail_on_undefined=False) == test_terms

# Generated at 2022-06-21 08:50:05.439739
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Using the --extra-vars argument to pass in a value in different formats
    import ansible.constants
    ansible.constants.DEFAULT_DEBUG_MSG_FORMAT = u'%(asctime)s %(name)s %(message)s'
    ansible.constants.DEFAULT_STDOUT_CALLBACK = u'test_listify_lookup_plugin_terms'

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import lookup_loader


# Generated at 2022-06-21 08:50:13.049090
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    try:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    except ImportError:
        # Ansible < 2.3
        from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes as AnsibleUnsafeText

    class FakeTemplate(object):
        def __init__(self, content):
            self.content = content

        def __str__(self):
            return self.content

    templar = Templar(loader=None, shared_loader_obj=None, variables={})

    # Test 1
    listify_lookup_plugin_terms(u'not a list', templar, loader=None, fail_on_undefined=True, convert_bare=False) == [u'not a list']

# Generated at 2022-06-21 08:50:19.170664
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.module_utils.facts import ansible_local

    templar = Templar(loader=None, variables={'ansible_local': ansible_local})

    # test with a string,
    result = listify_lookup_plugin_terms('foo', templar, loader=None)
    assert result == ['foo']

    # with a list,
    result = listify_lookup_plugin_terms(['foo'], templar, loader=None)
    assert result == ['foo']

    # and with a tuple
    result = listify_lookup_plugin_terms(('foo',), templar, loader=None)
    assert result == ['foo']

    # on the other hand, we will

# Generated at 2022-06-21 08:50:32.497694
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    module_args = dict(
        variable_manager=dict(
            host_vars=dict(),
            group_vars=dict(),
            all_vars=dict()
        ),
        loader=None
    )

    class FakeContext(object):
        def __init__(self, var_manager, loader):
            # this is where the _* attributes get assigned
            self._setup_vars(var_manager, loader)

    context = FakeContext(module_args['variable_manager'], module_args['loader'])

    templar = Templar(loader=module_args['loader'], variable_manager=module_args['variable_manager'], shared_loader_obj=context)

    # Set up a template, variable and expected result to use in all tests
    template = "{{ variable }}"

# Generated at 2022-06-21 08:50:38.717209
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    data = '''
    foo:
    - 1
    - 2
    - 3
    - baz
    - "{{qaz}}"
    - "{{qaz}}"
    - bar
    '''
    class FakeVarsModule(object):
        def __init__(self):
            self.qaz = 'qaz'

    class FakeLoader(object):
        def get_basedir(self, *args):
            return '/nonexistent'

    my_vars = FakeVarsModule()
    my_loader = FakeLoader()

# Generated at 2022-06-21 08:50:43.152194
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    # Setup
    loader = AnsibleLoader(None, 'dummy_loader')
    templar = Templar(loader=loader, variables=VariableManager())

    # Expected result
    expected = ['some_file.txt', 'other_file.txt']

    # Test with simple string
    result = listify_lookup_plugin_terms('some_file.txt', templar, loader)
    assert result == expected

    # Test with list
    result = listify_lookup_plugin_terms(['some_file.txt'], templar, loader)
    assert result == expected

    # Test with tuple

# Generated at 2022-06-21 08:50:52.397676
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=False)

    terms = ['one', 'two', '{{value}}']
    variables = {'value': 'three'}
    expected = ['one', 'two', 'three']

# Generated at 2022-06-21 08:51:03.352659
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.module_utils.basic import AnsibleModule
    from ansible.template import Templar

    module = AnsibleModule(
        argument_spec = dict(
            terms = dict(required=True, type='list'),
        ),
    )

    module._socket_path = '/does/not/matter/to/this/test'

    templar = Templar(loader=module._loader)
    terms = module.params['terms']

    results = listify_lookup_plugin_terms(terms, templar, module._loader)

    assert isinstance(results, Sequence), "The function 'listify_lookup_plugin_terms' should always return a sequence"

# Generated at 2022-06-21 08:51:14.821472
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    terms1 = [ 'foo', 'bar' ]
    terms2 = '{{ foo }}'
    terms3 = '{{ bar }}'

    templar = Templar(loader=None, variables=VariableManager())

    assert(listify_lookup_plugin_terms( terms1, templar, loader=None) == terms1)
    assert(listify_lookup_plugin_terms( terms2, templar, loader=None) == [terms2])
    assert(listify_lookup_plugin_terms( terms3, templar, loader=None) == [terms3])

# Generated at 2022-06-21 08:51:26.419793
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_from_file('/dev/null'))
    variable_manager.extra_vars = dict(
        var1="{{ var2 }}",
        var2="Now is the time",
        var3="{{ var4 }}",
        var4="{{ var5 }}",
        var5="  some spaces  ",
    )
    context = PlayContext()
    context._variable_manager = variable_manager

# Generated at 2022-06-21 08:51:27.062111
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-21 08:51:32.163284
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('', templar, loader) == []
    assert listify_lookup_plugin_terms(['a'], templar, loader) == ['a']
    assert listify_lookup_plugin_terms('a', templar, loader) == ['a']

# Generated at 2022-06-21 08:51:44.068676
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    def check(terms, expected, convert_bare=False, fail_on_undefined=False):
        variable_manager = VariableManager()
        loader = variable_manager.set_loader()
        templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=None)
        result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
        assert result == expected, "%s != %s" % (result, expected)

    check(None, [])
    check('', [])
    check(u'', [])
    check(u' ', [])
    check(('a', 'b', 'c'), ['a', 'b', 'c'])


# Generated at 2022-06-21 08:51:57.976179
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # This shouldn't be called outside of unit tests
    class Test_Templar():
        def __init__(self):
            pass

        def template(self, data, **kwargs):
            return data

    templar = Test_Templar()

    # Tests
    assert listify_lookup_plugin_terms('str1', templar, None) == ['str1']
    assert listify_lookup_plugin_terms(['str1', 'str2'], templar, None) == ['str1', 'str2']
    assert listify_lookup_plugin_terms('', templar, None) == ['']
    assert listify_lookup_plugin_terms([''], templar, None) == ['']
    assert listify_lookup_plugin_terms(None, templar, None)

# Generated at 2022-06-21 08:52:09.527120
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    class FakeVarsModule(object):
        def get_vars(self, loader, path, entities, cache=True):
            return {}
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 'b'}
    variable_manager.vars_cache = {}
    variable_manager.vars_plugins = [FakeVarsModule()]

    loader = DataLoader()

    assert listify_lookup_plugin_terms('{{a}}', Templar(loader=loader, variable_manager=variable_manager), loader) == ['b']

    variable_manager.extra_vars = {'a': ['b', 'c']}

# Generated at 2022-06-21 08:52:15.981755
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class FakeTemplar(object):
        def __init__(self, fail_on_undefined=True, convert_bare=False):
            self._fail_on_undefined = fail_on_undefined
            self._convert_bare = convert_bare

        def template(self, terms, *args, **kwargs):
            if self._fail_on_undefined:
                kwargs['fail_on_undefined'] = self._fail_on_undefined
            if self._convert_bare and isinstance(terms, string_types):
                # considered a raw string, so convert to AnsibleUnsafeText
                kwargs['convert_bare'] = self._convert_bare
            return terms

    class FakeLoader(object):
        pass



# Generated at 2022-06-21 08:52:27.451231
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.template import Templar

    terms = ['fileName', 'fileName2']

# Generated at 2022-06-21 08:52:29.526298
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # FIXME: in order to unit test this, we need to mock the templar
    pass

# Generated at 2022-06-21 08:52:40.336309
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variables = VariableManager()
    templar = Templar(loader=loader, variables=variables)

    result = listify_lookup_plugin_terms('foo', templar, loader)
    assert result == ['foo']

    result = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)
    assert result == ['foo', 'bar']

    result = listify_lookup_plugin_terms('[\'foo\', \'bar\']', templar, loader, convert_bare=True)
    assert result == ['foo', 'bar']

# Generated at 2022-06-21 08:52:49.839393
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.templating.templar import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    play_context = dict(
        ansible_ssh_host='hostname',
        ansible_ssh_user='testuser',
        ansible_ssh_port=22,
        ansible_ssh_pass='testpassword',
        ansible_ssh_private_key_file='testprivatekeyfile',
        connection='ssh',
    )
    templ

# Generated at 2022-06-21 08:53:01.627959
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping, AnsibleSequence
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(a='b', c='d', e='f')
    variable_manager.host_vars = dict(localhost=dict(g='h', i='j', k='l'))
    variable_manager.group_vars = dict(group1=dict(m='n', o='p', q='r'))


# Generated at 2022-06-21 08:53:09.815080
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Called with a single value it should return a list
    '''
    import jinja2
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.parsing.vault import VaultLib

    # set up jinja2 environment
    vault_password = 'vault_password'
    vault = VaultLib([vault_password])
    env = jinja2.Environment(undefined=jinja2.StrictUndefined)
    templar = CipherJinja2Environment(env, vault).from_module()

    single_term = 'single_term'
    terms = listify_lookup_plugin_terms(single_term, templar)
    assert( isinstance(terms, list) )
    assert( len(terms) == 1 )

# Generated at 2022-06-21 08:53:20.836967
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():


    mock_loader = 'bar'
    mock_templar = 'foo'
    
    assert(listify_lookup_plugin_terms(terms=1, templar=mock_templar, loader=mock_loader) == [ 1 ])
    assert(listify_lookup_plugin_terms(terms=1, templar=mock_templar, loader=mock_loader, fail_on_undefined=False) == [ 1 ])
    assert(listify_lookup_plugin_terms(terms=[1], templar=mock_templar, loader=mock_loader) == [ 1 ])
    assert(listify_lookup_plugin_terms(terms=[1, 2], templar=mock_templar, loader=mock_loader) == [ 1, 2 ])

# Generated at 2022-06-21 08:53:29.871934
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('1,2', None, None) == ['1,2']
    assert listify_lookup_plugin_terms('1', None, None) == ['1']
    assert listify_lookup_plugin_terms(['1', '2'], None, None) == ['1', '2']
    assert listify_lookup_plugin_terms(['1', '2'], None, None, convert_bare=True) == ['1', '2']
    assert listify_lookup_plugin_terms({'a': 'b'}, None, None) == [{'a': 'b'}]

# Generated at 2022-06-21 08:53:41.776128
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping

    templar = Templar(loader=None)
    result = listify_lookup_plugin_terms("{{ var1 }},{{ var2 }}", templar, None)
    assert isinstance(result, list)
    assert result[0] == "{{ var1 }}"
    assert result[1] == "{{ var2 }}"

    result = listify_lookup_plugin_terms(["{{ var1 }}", "{{ var2 }}"], templar, None)
    assert isinstance(result, list)
    assert result[0] == "{{ var1 }}"
    assert result[1] == "{{ var2 }}"


# Generated at 2022-06-21 08:53:52.078855
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    import pytest
    from units.mock.loader import DictDataLoader

    class TestTemplar(Templar):
        def __init__(self, loader, variables):
            super(TestTemplar, self).__init__(loader, variables)

        def template(self, data, preserve_trailing_newlines=True, convert_bare=False, fail_on_undefined=True, override_vars=None):
            return data

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = TestTemplar(loader=loader, variables=variable_manager)

    pass


# Generated at 2022-06-21 08:54:03.737500
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.config.manager import ConfigManager
    from ansible.vars.manager import VariableManager

    config_manager = ConfigManager()
    variable_manager = VariableManager(loader=None, inventory=None)
    variable_manager.set_inventory(None)
    variable_manager._extra_vars = {'a': 1}
    variable_manager._task_vars = {'b': 2}
    play_context = PlayContext(variable_manager=variable_manager, loader=None)
    templar = Templar(loader=None, variables=variable_manager, play_context=play_context)


# Generated at 2022-06-21 08:54:11.894703
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Test listify_lookup_plugin_terms

    """
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.parsing.dataloader import DataLoader

    # Create aliases for casting
    s = string_types

    # Create a simple class for the templar
    class Templar(object):
        def template(self, terms, fail_on_undefined=True, convert_bare=False):
            if isinstance(terms, s):
                terms = terms.rstrip()
                return terms
            else:
                return terms

    # Create a simple class for the loader
    class Loader(DataLoader):
        pass

    # Create a dictionary to mimic the vars_plugin

# Generated at 2022-06-21 08:54:22.498654
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.utils.display import Display

    display = Display()

    source = '{{ foo }}{{ bar }}'
    templar = Templar(loader=DataLoader(), variables=VariableManager(), 
                      shared_loader_obj=None, display=display)
    templar.set_available_variables({'foo': 'a', 'bar': 'b'})
    terms = listify_lookup_plugin_terms(source, templar, DataLoader())
    assert terms == ['ab']

    source = ['{{ foo }}{{ bar }}']

# Generated at 2022-06-21 08:54:31.734404
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('localhost', templar, loader, fail_on_undefined=False) == ['localhost']
    assert listify_lookup_plugin_terms(['localhost'], templar, loader, fail_on_undefined=False) == ['localhost']
    assert listify_lookup_plugin_terms(['localhost', '192.168.2.3'], templar, loader, fail_on_undefined=False) == ['localhost', '192.168.2.3']

# Generated at 2022-06-21 08:54:41.887365
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('1, 2', templar=None, loader=None) == ['1', '2']
    assert listify_lookup_plugin_terms(['1',2], templar=None, loader=None) == ['1', 2]
    assert listify_lookup_plugin_terms(('1','2'), templar=None, loader=None) == ['1', '2']
    assert listify_lookup_plugin_terms((x for x in ['1','2']), templar=None, loader=None) == ['1', '2']
    assert listify_lookup_plugin_terms(['1',['2',3]], templar=None, loader=None) == ['1', ['2', 3]]

# Generated at 2022-06-21 08:54:49.909882
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class MyVarsModule(object):
        def __init__(self, loader, path_connection):
            self.data = {
                'a': 'AAA',
                'b': 'BBB',
                'c': 'CCC',
                'd': 'DDD',
                'alice': ['alice1', 'alice2'],
                'bob': ['bob1', 'bob2'],
                'carol': ['carol1', 'carol2'],
            }

        def get_vars(self, loader, path_connection, namespaces, variables):
            return self.data

    templar = Templar(loader=None, variables={})
    templar._available_variables = MyVarsModule(loader=None, path_connection=None)

    my

# Generated at 2022-06-21 08:54:57.569225
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)


# Generated at 2022-06-21 08:55:15.310124
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    dl = DataLoader()
    vm = VariableManager()
    vm.extra_vars = {'var1': 'hello', 'var2': 'world', 'var3': '!'}
    templar = Templar(loader=dl, variables=vm)

    # test simple string
    assert listify_lookup_plugin_terms('hello', templar, dl) == ['hello']

    # test simple var
    assert listify_lookup_plugin_terms('{{var1}}', templar, dl) == ['hello']

    # test simple list

# Generated at 2022-06-21 08:55:26.727157
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    class FakeVaultSecret:
        def __init__(self, value):
            self.vault_secret = value

    class FakeVault(VaultLib):
        def lookup(self, template):
            return FakeVaultSecret(template)

    class FakeLoader(DataLoader):
        pass

    fake_loader = FakeLoader()
    templar = Templar(loader=fake_loader, vault_secrets=[])
    templar._vault = FakeVault()

    # One term, in unicode, which is not a list
    terms = u'abc'
    assert listify_lookup