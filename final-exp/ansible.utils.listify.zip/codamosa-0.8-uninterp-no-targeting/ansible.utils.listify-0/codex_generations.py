

# Generated at 2022-06-21 08:45:37.343121
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Dict
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    mock_loader = DictDataLoader({
        "file": "{{ foo.bar }}",
        "list": ["{{ foo.bar }}"],
        "dict": {"bar": "baz"},
        "var": "var",
    })

    mock_var = safe_eval("{\"foo\": {\"bar\": \"value\"}}")

# Generated at 2022-06-21 08:45:48.124030
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible import constants as C
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())
    # basic tests
    assert listify_lookup_plugin_terms('str', templar, None) == ['str']
    assert listify_lookup_plugin_terms(['str'], templar, None) == ['str']
    assert listify_lookup_plugin_terms(['str', 'er'], templar, None) == ['str', 'er']
    # test with undefined variable, ensure disable of jinja2 template
    assert listify_lookup_plugin_terms(['str', '{{xxx}}'], templar, None) == ['str', '{{xxx}}']
    assert listify_lookup_

# Generated at 2022-06-21 08:45:56.253391
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template.safe_eval import safe_eval

    templar = None # not needed
    loader = None # not needed

    # test simple term
    result = listify_lookup_plugin_terms(['foo'], templar, loader)
    assert result == ['foo'], result

    # test single complex term
    result = listify_lookup_plugin_terms(['http://{{ hostvars[inventory_hostname]["ansible_" + ansible_eth0]["ipv4"]["address"] }}/index.html'], templar, loader, convert_bare=True)
    expected = ['http://{{ hostvars[inventory_hostname]["ansible_" + ansible_eth0]["ipv4"]["address"] }}/index.html']
    assert result == expected, result



# Generated at 2022-06-21 08:46:02.188510
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import wrap_var

    t = Templar(loader=None, variables={'var1': wrap_var(['one', 'two'])})

    assert listify_lookup_plugin_terms(['{{var1}}'], t, None) == ['one', 'two']

    assert listify_lookup_plugin_terms(['{{var1}}'], t, None, convert_bare=True) == ['one', 'two']

# Generated at 2022-06-21 08:46:08.125781
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from jinja2 import Template
    templar = Template("{{ term }}")
    assert listify_lookup_plugin_terms("{{ name }}", templar, ansible_loader) == ["{{ name }}"]
    assert listify_lookup_plugin_terms([["{{ name }}"]], templar, ansible_loader) == [["{{ name }}"]]

# Generated at 2022-06-21 08:46:18.518292
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string input
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list input
    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader) == ['a', 'b']

    # Test list templating
    assert listify_lookup_plugin_terms(['a', '{{a}}', ['b', 'c']], templar, loader, convert_bare=True) == ['a', 'b', ['b', 'c']]

    # Test unicode templating

# Generated at 2022-06-21 08:46:30.327042
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    def _templar_and_loader(value):
        from ansible.template import Templar
        from ansible.parsing.yaml.loader import AnsibleLoader
        t = Templar()
        l = AnsibleLoader(value, t)
        return t, l
    t, l = _templar_and_loader([1, 2, 3])
    assert len(listify_lookup_plugin_terms(t, l)) == 3
    assert len(listify_lookup_plugin_terms('1', t, l)) == 1
    assert len(listify_lookup_plugin_terms(['1'], t, l)) == 1
    assert len(listify_lookup_plugin_terms(['1', '2'], t, l)) == 2

# Generated at 2022-06-21 08:46:36.742799
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms(['a', 'b', 'c'], templar, loader) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms('a,b,c', templar, loader) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms(['a,b,c'], templar, loader) == ['a,b,c']

# Generated at 2022-06-21 08:46:48.336815
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)
    value = templar.template("{{ ['a','b','c'] }}", convert_bare=True, fail_on_undefined=True)
    assert value == ['a', 'b', 'c']
    value = templar.template("a b c", fail_on_undefined=True)
    assert value == 'a b c'
    value = templar.template(['a', 'b', 'c'], fail_on_undefined=True)
    assert value == ['a', 'b', 'c']

# Generated at 2022-06-21 08:46:57.281291
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import ansible.variables.manager
    import ansible.playbook.play

    templar = Templar(variables=ansible.variables.manager.VariableManager(), loader=None)
    terms = listify_lookup_plugin_terms('{{ foo }}', templar, loader=None, fail_on_undefined=False)
    assert len(terms) == 1
    assert terms == [templar.template('{{ foo }}', fail_on_undefined=False)]

    templar = Templar(variables=ansible.variables.manager.VariableManager(), hostvars=dict(testhost=dict(foo='foo')), loader=None)
    terms = listify_lookup_

# Generated at 2022-06-21 08:47:12.178067
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.template import Templar

    class TestVarsModule(object):
        def __init__(self, *args, **kwargs):
            self.params = dict()
            self.params['a'] = [1, 2, 3]
            self.params['b'] = dict(one=1, two=2)
            self.params['c'] = 'c'
            self.params['d'] = None

    def test_template_data(self, data, **kwargs):
        return data

    parser = ModuleArgsParser(vars_loader=TestVarsModule())
    templar = Templar(loader=None, variables=parser.params)
    templar.template = test_template_data
    test_vars = TestVarsModule()



# Generated at 2022-06-21 08:47:20.937124
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible import constants as C
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None, convert_bare=True) == ['foo', 'bar']

    C.DEFAULT_BARE_VARIABLE_ERROR_FORMAT = 'custom_error_format'

# Generated at 2022-06-21 08:47:30.904450
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.plugins.loader import lookup_loader

    # Loader creates inventory, so Templates can access variables
    l = lookup_loader.LookupModule()
    l._setup_plugins()

    # Create the templar object
    templar = Templar(loader=l._loader, variables={'foo': 'bar'})

    # test string
    string = '{{ foo }}'
    result = listify_lookup_plugin_terms(string, templar, l, fail_on_undefined=True, convert_bare=False)
    assert result == ['bar']

    # test unicode
    string = u'{{ foo }}'

# Generated at 2022-06-21 08:47:42.522454
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import context
    from ansible.config.manager import ConfigManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    config_manager = ConfigManager()
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    context.CLIARGS = {}
    c = context.CLIARGS
    c['lookup_plugin_terms'] = ['foo']
    variable_manager.set_mock_lookup_plugin_terms(c)

    from ansible.template import Templar

    templar = Templar(loader=loader, variable_manager=variable_manager, shared_loader_obj=loader)

    # test string
    tst_string = '{{ foo}}'
    result = listify_lookup_plugin_terms

# Generated at 2022-06-21 08:47:54.379772
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.errors import AnsibleUndefinedVariable, AnsibleAssertionError
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['localhost'])
    variable_manager = inventory.get_variable_manager()
    play_context = PlayContext()

    # Initialize needed objects

    # Create a task so we can test the Templar class

# Generated at 2022-06-21 08:48:06.373616
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    def do(terms, templar, loader, fail_on_undefined=True, convert_bare=False, res=None):
        ret = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
        assert ret == res

    # Basic test
    from ansible.template import Templar
    t = Templar(loader=None)
    do("foo,bar", templar=t, loader=None, res=['foo', 'bar'])

    # Basic test with undef
    from ansible.template import Templar
    t = Templar(loader=None)
    do("foo{{undef}},bar", templar=t, loader=None, res=['foo', 'bar'])

# Generated at 2022-06-21 08:48:17.936351
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    my_vars = dict(a='foo', b='bar', c=['1', '2', '3'])
    my_loader = 'dummy_loader'
    my_fail_on_undefined = False

    # Valid input: list with one element
    terms = '{{ a }}'
    templar = Templar(loader=my_loader, variables=my_vars)
    res = listify_lookup_plugin_terms(terms, templar, my_loader, my_fail_on_undefined)
    assert res == my_vars['a']

    # Valid input: list with one element
    terms = ['{{ a }}']
    templar = Templar(loader=my_loader, variables=my_vars)
    res = listify_lookup_plugin_terms

# Generated at 2022-06-21 08:48:23.541165
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    vars_manager = VariableManager()  # dummy vars
    loader = DataLoader()  # dummy loader

    t = loader.load('./tests/data/templates/expand_list.j2', 'j2')

    assert listify_lookup_plugin_terms(t.render(vars_manager, loader), vars_manager, loader) == ['foo', 'bar']

# Generated at 2022-06-21 08:48:34.136402
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible import context
    try:
        context.CLIARGS = {'ansible_managed': False}
        loader = None
        templar = Templar(loader=loader)
        assert listify_lookup_plugin_terms('a', templar, loader) == ['a']
        assert listify_lookup_plugin_terms('a,b', templar, loader) == ['a', 'b']
        assert listify_lookup_plugin_terms('{{ test }}', templar, loader) == [u'{{ test }}']
        assert listify_lookup_plugin_terms(['a', 'b'], templar, loader) == ['a', 'b']
    finally:
        context.CLIARGS = None

# Generated at 2022-06-21 08:48:43.656941
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Simulate an AnsibleModule to get a valid templar object
    class AnsibleModule:
        def __init__(self, argument_spec=dict(), supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode

        def fail_json(self, **kwargs):
            raise Exception(kwargs)
    module = AnsibleModule()

    # Set up a valid Templar object to use
    templar = Templar(loader=None, variables={})

    # Test that a string returns a list of one element
    assert(len(listify_lookup_plugin_terms('whee', templar, None)) == 1)

    # Test that a list is returned unchanged

# Generated at 2022-06-21 08:48:57.237615
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms(terms='1', templar=templar, loader=None) == ['1']
    assert listify_lookup_plugin_terms(terms=2, templar=templar, loader=None) == [2]
    assert listify_lookup_plugin_terms(terms=[3], templar=templar, loader=None) == [3]
    assert listify_lookup_plugin_terms(terms=['4'], templar=templar, loader=None) == ['4']

# Generated at 2022-06-21 08:49:07.164032
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar

    terms = [
        'joe:young:fred',
        ['joe', 'young', 'fred'],
        ['joe', ['young', ['fred']]],
    ]
    templar = Templar(loader=None, variables={})

    for term in terms:
        terms_template = listify_lookup_plugin_terms(term, templar, None)
        assert terms_template == ['joe', 'young', 'fred']

    templar = Templar(loader=None, variables={'joe': 'jim', 'fred': ['jack', 'jeff']})
    terms = ['{{ joe }}:young:{{ fred }}']

# Generated at 2022-06-21 08:49:19.564282
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.playbook.play_context
    import ansible.template

    real_init = ansible.playbook.play_context.PlayContext.__init__

    class FakeVars(object):
        pass

    class FakePlayContext(object):
        def __init__(self):
            self.vars = FakeVars()

    def init(self):
        real_init(self)
        self.connection = 'local'

    # to catch unwanted side effects
    old_fake_vars = FakeVars()
    old_fake_vars.__dict__ = FakeVars.__dict__.copy()

    ansible.playbook.play_context.PlayContext.__init__ = init

# Generated at 2022-06-21 08:49:30.222711
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = '{{ foo }}, {{ bar }}'
    templar = Templar(loader=None, variables=dict(foo='foo', bar='bar'))
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo','bar']

    terms = ['{{ foo }}','{{ bar }}']
    templar = Templar(loader=None, variables=dict(foo='foo', bar='bar'))
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo','bar']

# Generated at 2022-06-21 08:49:40.617281
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts({'bla': "foo"})
    templar = Templar(loader=loader, variables=variable_manager)

    assert(listify_lookup_plugin_terms('foo', templar, loader) == ['foo'])
    assert(listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo'])

# Generated at 2022-06-21 08:49:50.053777
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys
    import os

    # Change the path to the lookup_plugin dir
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Iterable
    from .lookup_plugin import LookupModule as lookup_module
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Setup fake data
    results = {}
    results['lookup_plugin'] = lookup_module()

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # Test that the templating of the string works
    test_string = "{{ hello }}"
    test_

# Generated at 2022-06-21 08:49:59.686163
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # setup args
    class DummyVarsModule():
        def __init__(self):
            self.params = {
                'names': ['jim', 'harry', 'john'],
                'foo': 'bar',
                'number_var': 3
            }

    class DummyVarsModule2():
        def __init__(self):
            self.params = {
                'names': ['jim', 'harry', 'john'],
                'foo': ['bar', 2],
                'number_var': 3
            }


# Generated at 2022-06-21 08:50:09.698227
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    class TestLookupModule:
        def __init__(self, basedir=None, runner=None, variables=dict()):
            self.templar = Templar(loader=AnsibleLoader(basedir=basedir), shared_loader_obj=runner.loader, variables=variables)

        def listify_lookup_plugin_terms(self, terms, fail_on_undefined=False, convert_bare=False):
            return listify_lookup_plugin_terms(terms, self.templar, self.templar._loader, fail_on_undefined, convert_bare)

    assert TestLookupModule(basedir='/').listify_lookup_plugin_terms('1') == ['1']

# Generated at 2022-06-21 08:50:15.531941
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY3
    from ansible.template import Templar

    class TestVarsModule(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    if PY3:
        long = int

        class TestUndefined(object):
            pass
    else:
        TestUndefined = None

    class TestTemplar(Templar):
        def __init__(self):
            pass

        def available_variables(self, *args, **kwargs):
            return TestVarsModule(*args, **kwargs)

        def template(self, data, *args, **kwargs):
            if data == '1':
                return [[1, 2], 3]

# Generated at 2022-06-21 08:50:23.007900
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import BytesIO
    from ansible.parsing.yaml.objects import AnsibleUnicode

    from ansible.module_utils.common._collections_compat import Dict

    from ansible.template import Templar

    from ansible.vars.manager import VarManager

    from ansible.parsing.yaml.loader import YamlLoader

    from ansible.vars.hostvars import HostVars

    # data = """
    # foo:
    #   - name: one
    #     attr: value
    #   - name: two
    #     attr: value
    # bar:
    #   - name: three
    #     attr: value
    #   - name: four
    #     attr: value
    # """

    # data =

# Generated at 2022-06-21 08:50:35.064082
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, to_unsafe_text
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import os

    x = '''
        "{{ n }}"
        [1, 2, 3]
        "foo"
        bar
        "{{ n }} {{ m }}"
        foo
        [4, 5, 6]
        '''

    class DummyVarsModule(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_vars(self, *args, **kwargs):
            return dict(
                n=1,
                m=2,
            )


# Generated at 2022-06-21 08:50:46.878699
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    loader = []
    templar = Templar(loader=loader)
    result = listify_lookup_plugin_terms(terms=["{{ foo }}"], templar=templar, loader=loader, fail_on_undefined=True, convert_bare=False)
    assert result == ["{{ foo }}"]
    result = listify_lookup_plugin_terms(terms="{{ foo }}", templar=templar, loader=loader, fail_on_undefined=True, convert_bare=True)
    assert result == ["{{ foo }}"]

# C0111: Missing docstring
# C0103: Invalid name, this is a function not a variable
# W0201: Attribute defined outside __init__
# pylint: disable=C0111,C0103,W0201


# Generated at 2022-06-21 08:50:55.070054
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    my_vars = dict(
        some_string='www.example.com',
        some_list=['www.example.com', 'michael.example.com']
    )

    vars_mgr = VariableManager()
    vars_mgr.set_vars(my_vars)

    templar = Templar(loader=None, variables=vars_mgr)

    # Testing the cases where the terms argument is a string
    terms = '{{some_string}}'
    # When string, the returned value is always a list
    list_returned = listify_lookup_plugin_terms(terms, templar, loader=None)

# Generated at 2022-06-21 08:51:05.310798
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    t = Templar(loader=None, variables={'var1': 'foo', 'var2': 'bar'})

    terms = 'foo'
    res = listify_lookup_plugin_terms(terms, templar=t, loader=None, fail_on_undefined=False, convert_bare=False)
    assert isinstance(res, list)
    assert len(res) == 1
    assert res[0] == 'foo'

    terms = '{{ var1 }}'
    res = listify_lookup_plugin_terms(terms, templar=t, loader=None, fail_on_undefined=False, convert_bare=False)
    assert isinstance(res, list)
    assert len(res) == 1
    assert res[0] == 'foo'


# Generated at 2022-06-21 08:51:16.520494
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # TODO: Add more tests

    import sys
    import os
    import json

    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext

    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.module_utils.parsing.convert_bool import boolean

    loader = DataLoader()
    context = PlayContext()
    context._vars = VariableManager()

# Generated at 2022-06-21 08:51:28.520899
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    yaml_value1 = AnsibleUnsafeText('value1')
    yaml_value2 = AnsibleUnsafeText('value2')
    yaml_value3 = AnsibleUnsafeText('value3')
    yaml_value4= AnsibleUnsafeText('value4')

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'a': yaml_value1, 'b': yaml_value2}

# Generated at 2022-06-21 08:51:41.054016
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """ Make sure we listify lookup_plugin terms properly """
    from ansible.template import Templar

    loader = DictDataLoader({})
    templar = Templar(loader=loader)

    # Test strings
    assert listify_lookup_plugin_terms("one", templar, loader) == ["one"]
    assert listify_lookup_plugin_terms("one two", templar, loader) == ["one", "two"]
    assert listify_lookup_plugin_terms("one {{ two }}", templar, loader, convert_bare=True) == ["one", "two"]

    # Test list of strings
    assert listify_lookup_plugin_terms(["one"], templar, loader) == ["one"]

# Generated at 2022-06-21 08:51:55.167896
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create a mock inventory and a mock variable manager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory.ini'])
    variable_manager.set_inventory(inventory)

    # Create a mock playbook executor
    playbook = PlaybookExecutor(playbooks=['tests/test.yml'], inventory=inventory, variable_manager=variable_manager, loader=loader,
                                passwords={})

# Generated at 2022-06-21 08:52:05.931907
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class TestTemplar:

        def __init__(self):
            pass

        def template(self, terms, convert_bare=False, fail_on_undefined=True):
            return terms

    class TestLoader:

        def __init__(self):
            pass

    templar = TestTemplar()
    loader = TestLoader()

    assert [['a', 'b']] == listify_lookup_plugin_terms([['a', 'b']], templar, loader, True, False)
    assert ['a', 'b'] == listify_lookup_plugin_terms(['a', 'b'], templar, loader, True, False)
    assert ['c', 'd'] == listify_lookup_plugin_terms('c,d', templar, loader, True, False)

# Generated at 2022-06-21 08:52:14.135463
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Test setup
    loader = DictDataLoader({})
    env = Environment(loader=loader, variable_manager=VariableManager())
    templar = Templar(loader=loader, variables=env.get_vars())

    # begin tests

    # Convert a list of strings
    assert listify_lookup_plugin_terms(["a", "b", "c"], templar, loader) == ['a', 'b', 'c']

    # Convert bare variable
    assert listify_lookup_plugin_terms("{{ foo }}", templar, loader) == ['bar']

    # Convert a string
    assert listify_lookup_plugin_terms("a", templar, loader) == ['a']

    # Convert a list of bare variables

# Generated at 2022-06-21 08:52:26.536442
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader

    #Setup a fake env to test template
    fake_env = dict(
        basedir='/home/user/ansible',
        tempdir='/home/user/ansible/tmp',
        env=dict(
            HOME='/home/user',
            PATH='/bin:/usr/bin:/usr/local/bin:/home/user',
            PYTHONPATH='/home/user/ansible',
        ),
    )

    # create a dummy list of terms to test against
    terms = ['{{ test_list }}', 'list_item', '{{ test_list[0] }}']

# Generated at 2022-06-21 08:52:36.536263
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables=dict(foo='baz'))

    terms = listify_lookup_plugin_terms('{{ foo }}', templar, loader=None, fail_on_undefined=True)
    assert terms == ['baz']

    terms = listify_lookup_plugin_terms(['{{ foo }}'], templar, loader=None, fail_on_undefined=True)
    assert terms == ['baz']

    terms = listify_lookup_plugin_terms(['bar', '{{ foo }}'], templar, loader=None, fail_on_undefined=True)
    assert terms == ['bar', 'baz']

# Generated at 2022-06-21 08:52:47.267360
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import pytest

    templar = Templar(loader=DataLoader())

    assert listify_lookup_plugin_terms('file_name', templar) == ['file_name']
    assert listify_lookup_plugin_terms(['/a/{{b}}', '{{c}}'], templar) == ['/a/{{b}}', '{{c}}']
    assert listify_lookup_plugin_terms(['/a/{{b}}', '{{c}}'], templar, fail_on_undefined=False) == ['/a/', '']

# Generated at 2022-06-21 08:52:58.650450
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict
    #################################################################
    # setup for all test cases
    #################################################################
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import ansible.parsing.yaml.objects
    import os
    import sys
    import yaml

    class Options(object):

        def __init__(self, connection='smart', module_path=None, forks=5, become=None,
                     become_method=None, become_user=None, check=False, diff=False):
            self.connection = connection
            self.module_path = module_path
            self.forks = forks
            self.become = become
            self.become_method = become_method

# Generated at 2022-06-21 08:53:08.031367
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' unit testing for listify_lookup_plugins_terms'''
    from ansible.playbook.template import Templar
    from ansible.template import Jinja2Template
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=None, sources=None)
    variable_manager.set_inventory(inventory)

    j2t = Jinja2Template(loader=None, variables=variable_manager, shared_loader_obj=None)
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)
    templar._jinja2_env = j2t._jinja2_env

    test_dict1 = ['key1', 'key2', 'key3']
   

# Generated at 2022-06-21 08:53:18.751084
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext

    base_vars = {
        'foo': 'bar',
        'a': 'A',
        'b': 'B',
        'c': 'C',
        'd': 'D',
        'e': 'E',
        'f': 'F',
        'g': 'G',
        'h': 'H',
        'i': 'I',
        'j': 'J',
    }


# Generated at 2022-06-21 08:53:28.189824
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.set_vault_secrets(
        [('default', VaultLib([('vault_password', None)]))])
    templar = Templar(loader=loader, variables=variable_manager)

    # Single value
    assert (listify_lookup_plugin_terms('foo', templar, loader) == ['foo'])

    # Single value template
    assert (listify_lookup_plugin_terms('{{foo}}', templar, loader) == ['{{foo}}'])

    # List of values

# Generated at 2022-06-21 08:53:34.358611
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    my_loader = DataLoader()
    my_inv = InventoryManager(loader=my_loader, sources=['/dev/null'])
    my_vars = VariableManager(loader=my_loader, inventory=my_inv)

    # Make a various terms
    terms = [ u'first', u'second', [u'foo', u'bar'], {u'a': u'b'} ]

    results = listify_lookup_plugin_terms(terms, Templar(loader=my_loader, variables=my_vars))


# Generated at 2022-06-21 08:53:42.931226
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    terms = '{{ foo }}'

    loader = DataLoader()
    vault_secrets = VaultLib({})
    templar = Templar(loader=loader, variables={'foo': 'bar'}, vault_secrets=vault_secrets)

    result = listify_lookup_plugin_terms(terms, templar, loader)

    assert result == ['bar']

# Generated at 2022-06-21 08:53:53.685711
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    tmplar = Templar(loader=DataLoader())
    terms = "{{ foo }}"
    facts = {"foo": "bar"}
    ret = listify_lookup_plugin_terms(terms, tmplar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert ret == ["bar"]

    terms = "['foo', 'bar']"
    ret = listify_lookup_plugin_terms(terms, tmplar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert ret == ["foo", "bar"]

    terms = ['foo', 'bar']

# Generated at 2022-06-21 08:54:20.101133
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar

    # Create a simple mock for the templar's environment.
    class Environment:
        vars = {'test_var_1': 'FOO'}
        def get_basedir(self):
            return None

    # Create a simple mock for the templar's loader.
    class Loader:
        pass

    # Create a templar with the mock environment and loader.
    templar = Templar(loader=Loader(), variables=Environment())

    # Test 'var' term.
    term1 = '{{ test_var_1 }}'
    result1 = listify_lookup_plugin_terms(term1, templar, templar.loader)
    assert result1 == ['FOO']

    #

# Generated at 2022-06-21 08:54:30.055295
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    class TestVarsModule:
        def __init__(self):
            self.vars = dict(
                var_one='var one',
                var_two='var two',
                iterable=['var one', 'var two']
            )
    test_vars_module = TestVarsModule()
    loader = 'fake loader'
    templar = Templar(loader=loader, variables=test_vars_module)
    terms_list = listify_lookup_plugin_terms(terms=['{{ var_one }}', '{{ var_two }}', '{{ iterable }}'], templar=templar, loader=loader, fail_on_undefined=False, convert_bare=False)
    assert len(terms_list) == 5
    assert 'var one' in terms_list

# Generated at 2022-06-21 08:54:40.479905
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.vault import VaultLib

    terms1 = 'first'
    terms2 = ['second', 'third']
    terms3 = AnsibleBaseYAMLObject('fourth')

    # Templating must take plain values, not datatypes, so convert the YAML object to a string
    templar = Templar(None, vault_password=VaultLib()._get_vault_password(), convert_data=False)
    templar._available_variables = dict(test="test")

    # Test 1: string
    result = listify_lookup_plugin_terms(terms1, templar, None)
    assert result == ['first']

    # Test 2: list


# Generated at 2022-06-21 08:54:48.216522
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)
    terms = [1,2,3]
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == [1,2,3]
    terms = [1,2,3,'{{foo}}']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == [1,2,3,'{{foo}}']
    terms = '{{foo}}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{foo}}']
    terms = '{{ [1,2,3] }}'


# Generated at 2022-06-21 08:54:57.413689
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'item': 'foobar'}
    loader = variable_manager.get_vars_loader()
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    # input: a string
    s = '{{ item }}'
    assert listify_lookup_plugin_terms(s, templar, loader, False, False) == ['foobar']

    # input: a list
    s = ['{{ item }}']

# Generated at 2022-06-21 08:55:06.187919
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' listify_lookup_plugin_terms should return a list '''
    templar = None
    loader = None
    test_subjects = [
        ('abc', ['abc']),
        (' abc ', ['abc']),
        (' 1 2 3 ', ['1', '2', '3']),
        (['a','b','c'], ['a','b','c']),
        ({'a':'b'}, ['{"a": "b"}']),
        (1, ['1']),
        ]

    for terms, expected in test_subjects:
        result = listify_lookup_plugin_terms(terms, templar, loader)
        assert result == expected, "'%s' failed, expected: %s, result: %s" % (terms, expected, result)


# Generated at 2022-06-21 08:55:16.337029
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Set up
    terms = '{{q_c_p}}'
    templar = Templar(loader=DataLoader())
    templar._available_variables = dict(q_c_p=['foo', 'bar'])
    templar.environment = dict(q_c_p=23)

    # Assertions
    assert(listify_lookup_plugin_terms(terms, templar, templar._loader) == ['foo', 'bar'])

    terms = ['{{q_c_p}}', '{{test}}']
    templar.environment = dict(q_c_p=23, test='baz')

# Generated at 2022-06-21 08:55:27.343056
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=False, playcontext=play_context)

    def _assert_result(input, result):
        assert listify_lookup_plugin_terms(terms=input, templar=templar, loader=loader) == result

    # Strings