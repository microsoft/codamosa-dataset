

# Generated at 2022-06-21 08:45:37.435008
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.template import Templar

    # Test string
    templar = Templar(loader=None, shared_loader_obj=None)
    result = listify_lookup_plugin_terms('hello', templar, None, fail_on_undefined=True, convert_bare=False)
    assert(result == ['hello'])

    # Test list
    result = listify_lookup_plugin_terms(['hello'], templar, None, fail_on_undefined=True, convert_bare=False)
    assert(result == ['hello'])

    # Test dict

# Generated at 2022-06-21 08:45:42.538694
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    terms = "{{ salt['pillar.get']('foo','bar') }}"
    templar = Templar(loader=None, variables=dict(salt=dict(pillar=dict(get=dict(foo=1, bar=2)))))
    assert listify_lookup_plugin_terms(terms, templar, None) == [1]

    terms = ["{{ salt['pillar.get']('foo','bar') }}", "{{ salt['pillar.get']('foo','bar') }}"]
    templar = Templar(loader=None, variables=dict(salt=dict(pillar=dict(get=dict(foo=1, bar=2)))))

# Generated at 2022-06-21 08:45:51.668811
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms(['foo', 'bar'], Templar(loader=None), None) == [u'foo', u'bar']
    assert listify_lookup_plugin_terms(u'foo', Templar(loader=None), None) == [u'foo']
    assert listify_lookup_plugin_terms(u'foo', Templar(loader=None, variables={'foo': 'bar'}), None) == [u'bar']
    assert listify_lookup_plugin_terms(u'foo', Templar(loader=None, variables={'foo': False}), None) == [False]
    assert listify_lookup_plugin_terms('foo', Templar(loader=None, variables={'foo': True}), None) == [True]

# Generated at 2022-06-21 08:46:02.080171
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    dataloader = DataLoader()
    templar = Templar(loader=dataloader)

    myarg = '{{foo}}'
    assert ['{{foo}}'] == listify_lookup_plugin_terms(myarg, templar, dataloader)

    myarg = ['{{foo}}']
    assert ['{{foo}}'] == listify_lookup_plugin_terms(myarg, templar, dataloader)

    myarg = '{{ foo }}'
    assert ['{{ foo }}'] == listify_lookup_plugin_terms(myarg, templar, dataloader, convert_bare=True)

    myarg = '{{foo}}'
    dataloader.set_based

# Generated at 2022-06-21 08:46:13.965261
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    v = VaultLib([])
    t = Templar(loader=None, variables={'ec2_region': 'sa-east-1'}, vault_secrets=v)

    expected = [u'foo', u'bar', u"{{ ec2_region }}"]
    result = listify_lookup_plugin_terms(u"foo,bar,{{ ec2_region }}", t, None)
    assert result == expected


# Generated at 2022-06-21 08:46:22.252930
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()

    variable_manager.set_host_variable('foo', 'bar')
    variable_manager.set_host_variable('s', ['a', 'b', 'c'])
    variable_manager.set_host_variable('n', [1, 2, 3])

    jinja2_env_vars = variable_manager.get_vars(loader=loader, play=None)


# Generated at 2022-06-21 08:46:32.283067
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)
    assert listify_lookup_plugin_terms(templar.template("{{ '1' }}", convert_bare=True), templar, loader) == ['1']
    assert listify_lookup_plugin_terms(templar.template("{{ '1' }}", convert_bare=False), templar, loader) == ['1']
    assert listify_lookup_plugin_terms("{{ '1' }}", templar, loader) == ['1']

# Generated at 2022-06-21 08:46:43.325189
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    fake_loader = None
    templar = Templar(loader=fake_loader, variables={})
    assert listify_lookup_plugin_terms(42, templar, fake_loader, True) == [42]
    assert listify_lookup_plugin_terms('42', templar, fake_loader, True) == [u'42']
    assert listify_lookup_plugin_terms('-foo', templar, fake_loader, convert_bare=True) == [u'-foo']
    assert listify_lookup_plugin_terms('-42', templar, fake_loader, convert_bare=True) == [-42]

# vim: set ts=4 sw=4 expandtab

# Generated at 2022-06-21 08:46:53.346897
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.template

    try:
        from unittest import mock
    except:
        import mock

    # setup mock results


# Generated at 2022-06-21 08:46:59.739716
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar', 'whoo': ['aa', 'bb', 'cc']}
    loader = None
    myvault_secret = VaultLib([])
    templar = Templar(loader=loader, variable_manager=variable_manager, vault_secrets=[myvault_secret])
    # test a string that does not need templating
    r = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)
    assert r == ['foo', 'bar']
    # test a list that needs templating

# Generated at 2022-06-21 08:47:12.867739
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    ansible.utils.listify_lookup_plugin_terms test cases
    '''
    import sys

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # Setup: mock modules outside from this file
    sys.modules['ansible.parsing.dataloader'] = None
    sys.modules['ansible.vars.manager'] = None
    sys.modules['ansible.template'] = None
    sys.modules['ansible.parsing.yaml.objects'] = None
    sys.modules['ansible.module_utils._text'] = None


# Generated at 2022-06-21 08:47:21.343038
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Test ``listify_lookup_plugin_terms`` function.
    :return:
    '''
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar, TemplarError
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import get_vault_secret

    # Make sure the function returns a list for a string
    string = 'some-string'
    terms = listify_lookup_plugin_terms(string, Templar(loader=None), None)
    assert isinstance(terms, list) and len(terms) == 1 and isinstance(terms[0], string_types)

    # Make sure the function returns a

# Generated at 2022-06-21 08:47:31.129955
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test loop with None, only one value
    result = listify_lookup_plugin_terms(None, templar=None, loader=None, fail_on_undefined=True, convert_bare=False)
    assert result == [None]

    # Test loop with string, only one value
    result = listify_lookup_plugin_terms("test", templar=None, loader=None, fail_on_undefined=True, convert_bare=False)
    assert result == ["test"]

    # Test loop with a list, only one value
    result = listify_lookup_plugin_terms(["test"], templar=None, loader=None, fail_on_undefined=True, convert_bare=False)
    assert result == ["test"]

    # Test loop with a list, two values
    result = listify_

# Generated at 2022-06-21 08:47:41.620886
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class MockTemplar():
        def __init__(self, var):
            self.var = var

        def template(self, template, fail_on_undefined=True, convert_bare=False):
            return self.var

    def check_template(var, expected_result):
        mock_templar = MockTemplar(var)
        result = listify_lookup_plugin_terms(var, mock_templar, None)
        assert result == expected_result

    check_template(['a', 'b'], ['a', 'b'])
    check_template(['a'], ['a'])
    check_template('a', ['a'])
    check_template(None, None)

# Generated at 2022-06-21 08:47:52.969019
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # namedtuples are not hashable, so we make some mock objects:
    class MockTemplateVars(object):
        def __init__(self, vars):
            self.vars = vars
        def get(self):
            return self.vars

    class MockTemplar(object):
        def __init__(self, vars):
            self.tloader = self
            self.vars = vars
        def set_available_variables(self, variables):
            self.vars = variables

# Generated at 2022-06-21 08:48:04.932641
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    loader = AnsibleLoader(None, None, variable_manager=VariableManager())

    templar = Templar(loader=loader, variables=dict(foo='bar'))
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['bar']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['bar']
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, loader) == ['bar']

# Generated at 2022-06-21 08:48:15.255867
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.listify import listify_lookup_plugin_terms

    fake_loader = None          # We don't use this, so we pass None
    templar = Templar(loader=fake_loader)
    templar.set_available_variables(dict(foo=6,bar='some_string',baz=[7,8,9]))

    # Test string
    term = '{{foo}}'
    result = listify_lookup_plugin_terms(terms=term, templar=templar, loader=fake_loader)
    assert result == [6]

    # Test list
    term = ['{{foo}}','{{bar}}','{{baz}}']

# Generated at 2022-06-21 08:48:23.716705
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    lookup_loader = DummyLoader()
    lookup_filter = 'default'
    templar = Templar(loader=lookup_loader, variables={}, fail_on_undefined=False)

    # test string
    res = listify_lookup_plugin_terms('"{{ foo }}"', templar, lookup_loader, False)
    assert res == ['{{ foo }}']

    # test string (with convert_bare)
    res = listify_lookup_plugin_terms('"{{ foo }}"', templar, lookup_loader, False, True)
    assert res == ['foo']

    # test list of string
    res = listify_lookup_plugin_terms(['"{{ foo }}"', '"{{ bar }}"'], templar, lookup_loader, False)
    assert res

# Generated at 2022-06-21 08:48:34.735306
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class MockSetLoader:
        def __init__(self):
            pass

        def get_basedir(self, filename):
            return '.'

    class MockVars:
        def __init__(self):
            pass

    loader = MockSetLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=MockVars())

    assert listify_lookup_plugin_terms(' foo bar bax ', templar, loader) == ['foo', 'bar', 'bax']
    assert listify_lookup_plugin_terms([' foo ', 'bar', ' bax '], templar, loader) == ['foo', 'bar', 'bax']
    assert listify_lookup_

# Generated at 2022-06-21 08:48:43.945040
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    terms = listify_lookup_plugin_terms('{{ lookup("file", "/tmp/foo") }}', {}, {})
    assert isinstance(terms, list)
    assert terms == ["the contents of the file /tmp/foo"]

    terms = listify_lookup_plugin_terms('{{ lookup("file", "/tmp/foo") }},{{ lookup("file", "/tmp/bar") }}', {}, {})
    assert isinstance(terms, list)
    assert terms == ["the contents of the file /tmp/foo", "the contents of the file /tmp/bar"]

    terms = listify_lookup_plugin_terms(['{{ lookup("file", "/tmp/foo") }}', '{{ lookup("file", "/tmp/bar") }}'], {}, {})
    assert isinstance(terms, list)

# Generated at 2022-06-21 08:48:58.798317
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())

    def assertSame(a, b):
        assert a == b, '%r != %r' % (a, b)

    assertSame([], listify_lookup_plugin_terms(None, templar))
    assertSame([], listify_lookup_plugin_terms([], templar))
    assertSame([], listify_lookup_plugin_terms(set(), templar))
    assertSame([], listify_lookup_plugin_terms((), templar))

    assertSame(['a', 'b', 'c'], listify_lookup_plugin_terms(['a', 'b', 'c'], templar))

# Generated at 2022-06-21 08:49:10.889017
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    templar = Templar(loader=DataLoader(), variables={})
    assert ['file1.yml'] == listify_lookup_plugin_terms("file1.yml", templar, '/path/to/vars')
    assert ['file1.yml', 'file2.yml'] == listify_lookup_plugin_terms(['file1.yml', 'file2.yml'], templar, '/path/to/vars')
    assert ['file1.yml'] == listify_lookup_plugin_terms({'file1.yml'}, templar, '/path/to/vars')
    assert ['file1.yml', 'default.yml'] == listify_lookup_

# Generated at 2022-06-21 08:49:23.676226
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.template import Templar

    # Simple tests

# Generated at 2022-06-21 08:49:32.199912
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms('1', Templar(Loader()), Loader(), False) == ['1']
    assert listify_lookup_plugin_terms([1, 2], Templar(Loader()), Loader(), False) == [1, 2]
    assert listify_lookup_plugin_terms(['{{n}}', '2', 3], Templar(Loader({'n': 1})), Loader(), False) == [1, '2', 3]
    assert listify_lookup_plugin_terms('{{n}}', Templar(Loader({'n': 1})), Loader(), False) == [1]

# Generated at 2022-06-21 08:49:43.234780
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # test string
    result = listify_lookup_plugin_terms(u'foo', templar, loader)
    assert result == [u'foo']
    result = listify_lookup_plugin_terms(u'{{foo}}', templar, loader)
    assert result == [u'bar']

    # test string-conversion of AnsibleUnicode
    result = listify_lookup_plugin_terms(AnsibleUnicode(u'foo'), templar, loader)
    assert result == [u'foo']
    result = list

# Generated at 2022-06-21 08:49:53.399522
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert isinstance(listify_lookup_plugin_terms('a', templar, loader), list)
    assert isinstance(listify_lookup_plugin_terms(['a'], templar, loader), list)
    assert isinstance(listify_lookup_plugin_terms(('a',), templar, loader), list)
    assert isinstance(listify_lookup_plugin_terms('{{ foo }}', templar, loader), list)
    assert isinstance(listify_lookup_plugin_terms(['{{ foo }}'], templar, loader), list)

# Generated at 2022-06-21 08:50:01.813229
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible import constants as C

    templar = Templar(loader=None, variables={'foo': 'bar'})

    # test that a string becomes a list
    assert listify_lookup_plugin_terms('asdf', templar, loader=None) == ['asdf']

    # test that a list with an item gets converted to a list
    assert listify_lookup_plugin_terms(['asdf'], templar, loader=None) == ['asdf']

    # test that a list with two items gets converted to a list
    assert sorted(listify_lookup_plugin_terms(['asdf', 'jkl;'], templar, loader=None)) == ['asdf', 'jkl;']

    # test that a list with a list as an item gets converted to a list

# Generated at 2022-06-21 08:50:11.298379
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    import ansible.constants as C
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{item}}')))
             ]
        )

# Generated at 2022-06-21 08:50:20.677752
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common.collections import is_sequence
    from ansible.template import Templar

    terms1 = [1, 2, 3]
    terms2 = {'one': 1, 'two': 2, 'three': '{{hello}}'}
    vars1 = {'hello': 'world'}

    t = Templar(loader=None, variables=vars1)
    results = listify_lookup_plugin_terms(terms1, t, None)
    assert results == terms1, results
    assert is_sequence(results)

    results = listify_lookup_plugin_terms(terms2, t, None)
    assert results == ['world', 2, 'world'], results
    assert is_sequence(results)



# Generated at 2022-06-21 08:50:32.111485
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)
    MockVars = namedtuple('MockVars', ['foo', 'bar', 'baz'])
    variable_manager._vars = MockVars(foo=['a', 'b', 'c'], bar='d', baz=[1,2,3])

    # test a simple string

# Generated at 2022-06-21 08:50:48.674100
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeVarsModule:
        pass

    variables = FakeVarsModule()
    loader = None

    templar = Templar(loader=loader, variables=variables)
    assert listify_lookup_plugin_terms('{{ lookup("pipe", "ls /tmp") }}', templar, loader) == ['ansible_facts']
    assert listify_lookup_plugin_terms(['{{ lookup("pipe", "ls /tmp") }}'], templar, loader) == ['ansible_facts']

# Generated at 2022-06-21 08:50:56.501353
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    m_templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms([1,2,3], m_templar, None) == [1, 2, 3]
    assert listify_lookup_plugin_terms("foo", m_templar, None) == ["foo"]
    assert listify_lookup_plugin_terms("{{ foo }}", m_templar, None) == ["{{ foo }}"]
    assert listify_lookup_plugin_terms("{{ foo }}", m_templar, None, convert_bare=True) == [u'foo']
    assert listify_lookup_plugin_terms("{{ foo }}", m_templar, None, convert_bare=False) == [u'{{ foo }}']
    m_tem

# Generated at 2022-06-21 08:51:02.030753
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    my_vars = dict(
        foo='bar',
        bam='boom',
        qux=['a', 'b', 'c'],
    )

    terms = [
        '{{ foo }}',
        '{{ qux }}',
    ]

    templar = Templar(loader=None, variables=my_vars)
    result = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)

    assert result == ['bar', ['a', 'b', 'c']]


# Generated at 2022-06-21 08:51:07.136199
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms([1,2,3], templar, loader) == ['1', '2', '3'], 'Should return a list of strings'
    assert listify_lookup_plugin_terms('{{foo}}', templar, loader) == ["{{foo}}"], 'Should return the term if it is not a string'

# Generated at 2022-06-21 08:51:12.908867
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class FakeVarsModule:
        def __init__(self, value):
            self.value = value

        def get_vars(self, loader, play, host):
            return dict(value=self.value)

    class FakeLoader(object):
        def __init__(self):
            self.vars = dict()

    class FakeVarManager:
        def __init__(self):
            self.vars = dict()

    class FakePlayContext:
        def __init__(self):
            self.vars = FakeVarManager()

    class FakeHost:
        def __init__(self):
            self.name = "localhost"

    play = FakePlayContext()
    host = FakeHost()
    loader = FakeLoader()

    # test string value

# Generated at 2022-06-21 08:51:15.236666
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms("foo", None, None) == ['foo']
    assert listify_lookup_plugin_terms(["foo", "bar"], None, None) == ['foo', 'bar']

# Generated at 2022-06-21 08:51:27.004488
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeTemplar():
        def __init__(self, value):
            self.value = value
        def template(self, data, **kwargs):
            return self.value

    # test string
    data = listify_lookup_plugin_terms("test", FakeTemplar("test1"), None)
    assert data == ["test1"]

    # test with templated string
    data = listify_lookup_plugin_terms("test", FakeTemplar("yes"), None)
    assert data == ["yes"]

    # test with list
    data = listify_lookup_plugin_terms("test", FakeTemplar(["no", "yes"]), None)
    assert data == ["no", "yes"]

    # test with templated list

# Generated at 2022-06-21 08:51:36.792438
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # Test obj type string
    test_obj = 'test.file'
    assert listify_lookup_plugin_terms(test_obj, None, None) == [test_obj]

    # Test obj type list of string
    test_obj = ['test.file1', 'test.file2']
    assert listify_lookup_plugin_terms(test_obj, None, None) == test_obj

    # Test obj type list of string and dict
    test_obj = [
        'test.file1',
        {'key': 'var', 'val': 'test.file2'}
    ]
    assert listify_lookup_plugin_terms(test_obj, None, None) == test_obj


# Generated at 2022-06-21 08:51:48.465660
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    m_templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms("1", m_templar, None) == ["1"]
    assert listify_lookup_plugin_terms(" ", m_templar, None) == [" "]
    assert listify_lookup_plugin_terms("a b", m_templar, None) == ["a b"]
    assert listify_lookup_plugin_terms("a   b", m_templar, None) == ["a   b"]
    assert listify_lookup_plugin_terms("a,b", m_templar, None) == ["a,b"]

# Generated at 2022-06-21 08:51:59.225331
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var

    t1 = Templar(loader=None, variables={'a': wrap_var([1])})
    assert(listify_lookup_plugin_terms(1, t1, None) == [1])
    assert(listify_lookup_plugin_terms('1', t1, None) == ['1'])
    assert(listify_lookup_plugin_terms([1], t1, None) == [1])
    assert(listify_lookup_plugin_terms([1,2], t1, None) == [1,2])
    assert(listify_lookup_plugin_terms('{{a}}', t1, None) == [1])

# Generated at 2022-06-21 08:52:23.949141
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    terms_1  = "{{ ['a', 'b'] }}"
    terms_2  = "{{ ['a', 'b'] | map('quote') | list }}"
    terms_3  = "{{ 'a' }}"
    terms_4  = ["{{ 'a' }}", "{{ 'b' }}"]
    terms_5  = "{{ ['a', 'b'] | map('quote') | list }}"
    terms_6  = ["{{ 'a' }}", "{{ ['b', 'c'] | map('quote') | list }}"]
    terms_7  = ["a", "b"]
    terms_8  = "spam"

# Generated at 2022-06-21 08:52:32.993278
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # FIXME: this is not a valid unit test, it doesn't actually test anything
    #        as far as I can tell, as it uses the templar directly and
    #        completely ignores the templar's input and output, so I don't
    #        know what the expected output is.
    import ansible.template
    templar = ansible.template.Templar()
    terms = '{{ a }}'
    terms = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=True, convert_bare=False)
    assert isinstance(terms, list)

# Generated at 2022-06-21 08:52:43.509910
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # import unit test modules
    from ansible.module_utils.facts.utils.timeout import TimeoutError
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.network import NetworkCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector

    # setup mock classes and objects

# Generated at 2022-06-21 08:52:51.682547
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import utils
    from ansible.template import Templar
    loader, inventory, variable_manager = utils.get_example_vars()
    templar = Templar(loader=loader, variables=variable_manager)
    terms = listify_lookup_plugin_terms(terms = '{{ foo }}', templar = templar, loader = loader)
    assert terms == [ 'test' ]

    templar = Templar(loader=loader, variables=variable_manager)
    terms = listify_lookup_plugin_terms(terms = {'foo': '{{ foo }}'}, templar = templar, loader = loader)
    assert terms == {'foo': 'test'}

    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-21 08:53:03.349381
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.template import AnsibleTemplar
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(None, {}, 'Foo.Bar')
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    templar = AnsibleTemplar(loader=loader)
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader, convert_bare=True) == ['{{ foo }}']

    templar._available_variables = dict(foo='baz')

# Generated at 2022-06-21 08:53:13.021669
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.yaml.objects import AnsibleUnicode

    from ansible.template import Templar

    from ansible.vars import VariableManager

    from ansible.utils.vars import combine_vars

    from ansible.utils.display import Display

    ############################################################################
    #
    # Test valid term types
    #
    ############################################################################

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(a="a_value", b="b_value", c="c_value", d="d_value")

    loader = variable_manager.get_vars_loader()

    display = Display()

    templar = Templar(loader=loader, variables=variable_manager, display=display)

    # string type
    terms = listify_lookup_plugin_terms

# Generated at 2022-06-21 08:53:19.550673
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import ansible_safe_eval
    assert listify_lookup_plugin_terms("{{ var1 }}", ansible_safe_eval, None) == ["{{ var1 }}"]
    assert listify_lookup_plugin_terms("var1", ansible_safe_eval, None) == ["var1"]
    assert listify_lookup_plugin_terms("{{ var1 }}:{{ var2 }}", ansible_safe_eval, None) == ["{{ var1 }}:{{ var2 }}"]
    assert listify_lookup_plugin_terms("{{ var1 }}:{{ var2 }}", ansible_safe_eval, None) == ["{{ var1 }}:{{ var2 }}"]

# Generated at 2022-06-21 08:53:28.088103
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    # test case for bare variables
    loader = DataLoader()
    templar = Templar(loader=loader)
    assert listify_lookup_plugin_terms("{{ a }}", templar, loader, convert_bare=True) == [AnsibleUnsafeText("{{ a }}")]
    assert listify_lookup_plugin_terms("{{ a }}", templar, loader, convert_bare=False) == [AnsibleUnsafeText("{{ a }}")]

# Generated at 2022-06-21 08:53:40.171399
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.template import Templar

    mock_vardir = "/no/such/dir"
    mock_loader = "a mock loader"
    templar = Templar(loader=mock_loader, variables={}, fail_on_undefined=True)
    templar.environment = "a mock environment"

    def _to_text(input, errors='strict'):
        if input is None:
            input = ''
        if isinstance(input, bytes):
            input = input.decode(errors)
        return to_text(input)

    def _to_bytes(input, errors='strict'):
        if input is None:
            input = ''

# Generated at 2022-06-21 08:53:50.851613
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils import context_objects as co

    templar = Templar(co.VariableManager())
    terms = listify_lookup_plugin_terms(["{{ test }}", "{{ test2 }}"], templar, co.AnsibleLoader())
    assert terms == ["{{ test }}", "{{ test2 }}"]
    templar._available_variables = dict(test='one', test2='two')
    terms = listify_lookup_plugin_terms(["{{ test }}", "{{ test2 }}"], templar, co.AnsibleLoader())
    assert terms == ['one', 'two']
    terms = listify_lookup_plugin_terms("{{ test }}{{ test2 }}", templar, co.AnsibleLoader())
    assert terms == ['onetwo']


# Generated at 2022-06-21 08:54:29.421172
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Testing failure when using str type
    # This should return a list with the original string
    string = "test_string"
    result = listify_lookup_plugin_terms(string, None, None, False, False)
    assert isinstance(result, list)
    assert string in result

    # Testing failure when using int type
    # This should return a list with the original int
    int = 1
    result = listify_lookup_plugin_terms(int, None, None, False, False)
    assert isinstance(result, list)
    assert 1 in result

    # Testing failure when using list type
    # This should return the original list
    list = [1,2]
    result = listify_lookup_plugin_terms(list, None, None, False, False)
    assert isinstance(result, list)

# Generated at 2022-06-21 08:54:39.525656
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError

    test_variable_manager = VariableManager()
    test_loader = 'test_loader'
    test_inventory = InventoryManager(loader=test_loader, sources=['localhost,'])
    test_play_context = PlayContext()
    test_vault_secrets = {'secret': 'secret'}
    test_vault_password = VaultLib(secrets=test_vault_secrets)

# Generated at 2022-06-21 08:54:49.064022
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    test_template = '{{ foo }}'
    templar = Templar(loader=loader, variables=variable_manager)

    # test non-iterable types
    test_inputs = [None, True, 1, 1.1]

# Generated at 2022-06-21 08:54:58.210735
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    terms = u"""{{ foo }}"""
    assert listify_lookup_plugin_terms(terms, None, None, fail_on_undefined=True) == [u'{{ foo }}']

    terms = u'{{ foo }}'
    assert listify_lookup_plugin_terms(terms, None, None, fail_on_undefined=True) == [u'{{ foo }}']

    terms = AnsibleUnsafeText(u'''{{ foo }}''')
    assert listify_lookup_plugin_terms(terms, None, None, fail_on_undefined=True) == [u'{{ foo }}']

    terms = [u'''{{ foo }}''', u'''{{ bar }}''']

# Generated at 2022-06-21 08:55:06.860503
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from ansible.template import Templar

    # templar will use loader.get_basedir()
    # we need to set that basedir to *something* or it will die
    loader.set_basedir({'basedir': '.'})

    class MockPlayContext(object):
        def __init__(self):
            self.shell = None
            self.command_uuid = None
            self.prompt = None
            self.terminal = None
            self.connection = None
            self.remote_addr = None
            self.remote_user = None
            self.password = None
            self.port = None
            self.private_key_file = None
            self.timeout = None
            self.shell_type

# Generated at 2022-06-21 08:55:16.828842
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.utils.hashing import md5s, checksum_s

    # Mock up a called class to reproduce a AnsibleModule object
    class CalledClass:
        def __init__(self, name=None, fail_on_undefined=True, convert_bare=False):
            self.name = name
            self.fail_on_undefined = fail_on_undefined
            self.convert_bare = convert_bare

    # Mock up a templar class to be used by the test function
    class TemplarClass:
        def __init__(self):
            self.fail_on_undefined = True
            self.name = 'TemplarClass'


# Generated at 2022-06-21 08:55:27.972772
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text

    assert listify_lookup_plugin_terms("value1", FakeTemplar(), FakeLoader()) == ["value1"]
    assert listify_lookup_plugin_terms(["value1", "value2"], FakeTemplar(), FakeLoader()) == ["value1", "value2"]
    assert listify_lookup_plugin_terms(["value1", ["value2", "value3"]], FakeTemplar(), FakeLoader()) == ["value1", "value2", "value3"]
    assert listify_lookup_plugin_terms("{{ value }}", FakeTemplar(), FakeLoader()) == [u'value']
    assert listify_lookup_plugin_terms("{{ value }}", FakeTemplar(), FakeLoader(), convert_bare=True) == [u'"value"']
   