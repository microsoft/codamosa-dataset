

# Generated at 2022-06-21 08:45:40.013588
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template

    terms1 = 'host1,host2'
    terms2 = ['host1', 'host2']
    terms3 = ['host1,host2']
    terms4 = 'host1'
    expected = ['host1', 'host2']

    loader = DummyLoader()
    templar = ansible.template.Templar(loader=loader)

    assert expected == listify_lookup_plugin_terms(terms1, templar, loader, fail_on_undefined=True,
                                                   convert_bare=False)
    assert expected == listify_lookup_plugin_terms(terms1, templar, loader, fail_on_undefined=True,
                                                   convert_bare=True)

# Generated at 2022-06-21 08:45:49.436086
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    mystr   = u'foo'
    mylist  = [u'foo', u'bar']
    mybad   = u'{{foo}}'
    myvars  = dict(foo='bar')

    result = listify_lookup_plugin_terms('{{foo}}', templar, loader, fail_on_undefined=True)
    assert result == mybad
    result = listify_lookup_plugin_terms('{{foo}}', templar, loader, fail_on_undefined=False)
    assert result == mybad
    result = list

# Generated at 2022-06-21 08:46:00.430235
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    plugin_loader = DataLoader()

    templar = Templar(loader=plugin_loader, variables={'a': '1', 'b': '2'})

    # 1. Single string
    assert listify_lookup_plugin_terms('{{ a }}', templar, plugin_loader) == ['1']
    assert listify_lookup_plugin_terms('{{ a }}', templar, plugin_loader, convert_bare=True) == [1]

    # 2. List of strings
    assert listify_lookup_plugin_terms(['{{ a }}', '{{ b }}'], templar, plugin_loader) == ['1', '2']

# Generated at 2022-06-21 08:46:08.945785
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test for inline templates
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    v = VariableManager()
    d = DataLoader()
    p = PlayContext()

    s = "{{ 'foo,bar' | split(',', True) }}"
    ret = listify_lookup_plugin_terms(s, Templar(loader=d, variables=v), d)
    assert ret == ['foo', 'bar']

# Generated at 2022-06-21 08:46:19.153747
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    templar = Templar(loader=None, variables=VariableManager(),
                      shared_loader_obj=None, disable_lookups=True)
    play_context = PlayContext()

    assert listify_lookup_plugin_terms(1, templar, loader=None) == [1]
    assert listify_lookup_plugin_terms('1', templar, loader=None) == [1]
    assert listify_lookup_plugin_terms(1, templar, loader=None, convert_bare=True) == [1]
    assert listify_lookup_

# Generated at 2022-06-21 08:46:30.856940
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        from ansible.template import Templar
        from ansible.parsing.dataloader import DataLoader
        import json
        import yaml
        loader = DataLoader()
        templar = Templar(loader=loader, variables={})
    except ImportError:
        # we're running from source, so this module isn't installed
        # yet and that's fine
        return

    template = templar.template

    assert template("{{ ['a','b','c'] }}", fail_on_undefined=False) == ['a','b','c']
    assert template("{{ ['a','b','c'] | to_json }}", fail_on_undefined=False) == "['a', 'b', 'c']"

# Generated at 2022-06-21 08:46:42.795702
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.module_utils.common.collections
    import ansible.parsing.yaml.objects
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    variable_manager.set_host_variable('host1', 'host1_value')
    variable_manager.set_host_variable('host2', 'host2_value')

    variable_manager.set_host_variable('host1', dict(a=1,b=2,c=3))

    variable_manager.set_nonpersistent_facts(dict(a=1,b=2))
    variable_manager.set_nonpersistent_facts(dict(d=4,e=5))

# Generated at 2022-06-21 08:46:49.338684
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    class mock_vars(object):
        def __init__(self, myvar):
            self.myvar = myvar

    source = mock_vars('hello')

    templar = Templar(loader=DataLoader())
    new_terms = listify_lookup_plugin_terms(terms=source.myvar, templar=templar, loader=DataLoader(), fail_on_undefined=True, convert_bare=False)
    assert new_terms == ['hello']


# Generated at 2022-06-21 08:46:57.696970
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    #############################################################
    # test_function: Test function for unit test for
    # pipeline unit testing.
    #############################################################
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    templar = Templar(loader=loader, inventory=inventory, shared_loader_obj=None)

    assert listify_lookup_plugin_terms('test string', templar, loader) == ['test string']
    assert listify_lookup_plugin_terms(['test string'], templar, loader) == ['test string']
    assert listify_lookup_plugin_

# Generated at 2022-06-21 08:47:09.168656
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Import module to be tested
    from ansible.utils.vars import listify_lookup_plugin_terms

    # Create data loader
    loader = DataLoader()

    # Create variable manager
    variable_manager = VariableManager()

# Generated at 2022-06-21 08:47:20.273977
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    env = {'ansible_vimvar_foo': 'foobar'}
    templar = Templar(loader=None, variables=env)

    assert listify_lookup_plugin_terms('{{ ansible_vimvar_foo }}', templar, None) == ['foobar']
    assert listify_lookup_plugin_terms('{{ ansible_vimvar_foo }}', templar, None) == ['foobar']
    assert listify_lookup_plugin_terms(['{{ ansible_vimvar_foo }}'], templar, None) == ['foobar']
    assert listify_lookup_plugin_terms(['{{ ansible_vimvar_foo }}', 123], templar, None) == ['foobar', 123]

# Generated at 2022-06-21 08:47:26.261719
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)
    assert listify_lookup_plugin_terms(['foo', '{{', 'BAR'], templar, loader) == ['foo', '{{', 'BAR']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('{{ foo }},{{ bar }}', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('[1, 2, 3]', templar, loader) == [1, 2, 3]

# Generated at 2022-06-21 08:47:34.245621
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    ds = DataLoader()
    inv_manager = InventoryManager(loader=ds, sources=['localhost,'])
    variable_manager = VariableManager(loader=ds, inventory=inv_manager)
    templar = Templar(loader=ds, variables=variable_manager)

    result = listify_lookup_plugin_terms('1', templar, ds)
    assert result == ['1']
    result = listify_lookup_plugin_terms(['1','2','3'], templar, ds)
    assert result == ['1','2','3']
    result = listify_lookup_plugin_terms

# Generated at 2022-06-21 08:47:43.724915
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import inspect
    import sys
    import os
    test_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parent_dir = os.path.dirname(test_dir)
    sys.path.insert(0, parent_dir)
    from units.compat.mock import patch, MagicMock
    from units.modules.utils import set_module_args

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_

# Generated at 2022-06-21 08:47:52.643766
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = FakeLoader()
    context = PlayContext()
    templar = Templar(loader=loader, variables=VariableManager())

    assert listify_lookup_plugin_terms('["a", "b"]', templar, loader) == ['a', 'b']
    assert listify_lookup_plugin_terms('[a, b]', templar, loader) == ['a', 'b']



# Generated at 2022-06-21 08:47:59.827276
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml import DataLoader
    terms = ["{{ item }}" for item in [1, 2, 3]]
    loader = DataLoader()
    shared_terms = listify_lookup_plugin_terms(
        terms, Templar(loader=loader), loader)
    for term1, term2 in zip(terms, shared_terms):
        assert term1 == term2
    terms = {'items': ['{{ item }}' for item in [1, 2, 3]]}
    shared_terms = listify_lookup_plugin_terms(
        terms, Templar(loader=loader), loader)
    assert terms.items() == shared_terms.items()
    terms = ["{{ item }}" for item in [1, 2, 3]]
    shared_terms = listify_lookup_

# Generated at 2022-06-21 08:48:09.584825
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    fake_loader = DictDataLoader({})

    variable_manager = VariableManager()
    templar = Templar(loader=fake_loader, variables=variable_manager, fail_on_undefined=False)
    templar._available_variables = dict(a='foo', b='bar')

    if sys.version_info[0] >= 3:
        unicode = str


# Generated at 2022-06-21 08:48:20.181709
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # Assumes test is being run from ansible/plugins/lookup
    # so that we can test loading of parent template
    lookup_file = u'test/files/parent.template'
    loader = None
    variables = dict(
        foo=u'bar',
        baz=[u'qux', u'quux'],
    )

    # Simple templating of a string
    terms = u'{{ foo }}'
    assert listify_lookup_plugin_terms(terms, Templar(loader=loader, variables=variables), loader) == [u'bar']

    # Templating of a list with a single string
    terms = [u'{{ foo }}']

# Generated at 2022-06-21 08:48:30.818933
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    fact_vars = dict(
        ec2_placement_availability_zone=AnsibleUnsafeText(u'us-east-1b'),
        ec2_placement_region=AnsibleUnsafeText(u'us-east-1'),
    )
    var_vars = dict()

    myvars = combine_vars(var_vars, fact_vars)

    myloader = DataLoader()
    mylookup = lookup_loader.get('file')

# Generated at 2022-06-21 08:48:41.248628
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms(terms=['foo', 'bar'], templar=templar) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms='foo', templar=templar) == ['foo']
    assert listify_lookup_plugin_terms(terms='[foo]', templar=templar) == ['foo']
    assert listify_lookup_plugin_terms(terms='foo,bar', templar=templar) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms='foo, bar', templar=templar) == ['foo', 'bar']

# Generated at 2022-06-21 08:48:55.333072
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.template import Templar

    assert listify_lookup_plugin_terms([1, 2, 3], Templar(), []) == [1, 2, 3]
    assert listify_lookup_plugin_terms([1, 2, 3], Templar(), []) != [2, 3, 1]
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], Templar(), []) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms(('a', 'b', 'c'), Templar(), []) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms((1, 2, 3), Templar(), []) == [1, 2, 3]
    assert listify

# Generated at 2022-06-21 08:49:02.906915
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import lookup_loader

    my_terms = "{{ '1' + ':' + '2' }}:3:{{ '4:5' }}"
    hostvars = HostVars(dict())
    vault = AnsibleVaultEncryptedUnicode('supersecret')
    playcontext = PlayContext()
    loader = lookup_loader

# Generated at 2022-06-21 08:49:15.098098
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # For the moment this function is only called by the file lookup plugin.
    # We will add unit tests to the file lookup plugin until this function
    # is used somewhere else and then move the tests to the general test file
    # for this module.
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    loader = AnsibleLoader(None, True)
    inventory = InventoryManager(loader, variables=VariableManager(loader=loader), host_list=[])
    play_context = PlayContext()
    templar = Templar(loader=loader, inventory=inventory, play_context=play_context)
    result = listify_look

# Generated at 2022-06-21 08:49:25.072635
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_pass = 'dummy'
    vault_text = VaultLib(vault_pass).encrypt('test')
    secret_vault = VaultSecret(vault_pass, vault_text.decode('utf-8'))


# Generated at 2022-06-21 08:49:34.510128
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    # Strings:
    terms = "{{ foo }} {{ bar }}"
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == [u"{{ foo }} {{ bar }}"]

    # List:
    terms = ["foo", "bar"]
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == [u"foo", u"bar"]

    # List with vars:
    terms = ["{{ foo }}", u"{{ bar }}"]
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == [u"{{ foo }}", u"{{ bar }}"]

    # Bare

# Generated at 2022-06-21 08:49:44.630041
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import sys

    class FakeVarsModule():
        def __init__(self):
            self.ansible_env = None

    class FakeVarsPlugin():
        def get_vars(self, loader, path, entities, cache=True):
            return FakeVarsModule()

    class FakeInventory():
        def __init__(self):
            self.loader = DataLoader()
            self.vars_plugins = [FakeVarsPlugin()]

    loader = DataLoader()
    inventory = FakeInventory()
    templar = Templar(loader=loader, variables=inventory.get_vars(loader=loader, path=["playbook_dir"]))

    # Expected to fail
    res = listify_lookup_

# Generated at 2022-06-21 08:49:54.952563
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.unsafe_proxy import AnsibleVars

    data = '''
    var1:
      - item1
      - item2
    var2:
      - item3
      - item4
    '''

    # Create AnsibleVars
    avars = AnsibleVars(loader=None, variables=AnsibleMapping(loader=None, data=data))

    # Create Templar object
    templar = Templar(loader=None, variables=avars)
    templar._available_variables = avars

    terms = [ "{{ var1 | to_json }}", "{{ var2 | to_json }}" ]

# Generated at 2022-06-21 08:50:06.127349
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-21 08:50:13.324119
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.splitter import parse_kv
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types

    # Note: The templar needs a valid PlayContext so that the var lookup works
    display = Display()
    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play = Play()
    play_context = PlayContext()

# Generated at 2022-06-21 08:50:21.703000
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables={})

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, loader, convert_bare=True) == ['foo', '{{ bar }}']
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, loader, convert_bare=False) == ['foo', 'bar']



# Generated at 2022-06-21 08:50:34.439934
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence

    # Note, this function is not used anywhere outside of test_lookup_plugin_terms.py, so
    # this test must be run alone to avoid import errors

    # Bare integer
    terms = '1'
    terms = listify_lookup_plugin_terms(terms, templar=None, loader=None)
    assert isinstance(terms, Sequence)
    assert len(terms) == 1
    assert isinstance(terms[0], int)

    # Integer in a string
    terms = '"1"'
    terms = listify_lookup_plugin_terms(terms, templar=None, loader=None)
    assert isinstance(terms, Sequence)
    assert len(terms) == 1
    assert isinstance(terms[0], string_types)

# Generated at 2022-06-21 08:50:46.446763
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeVarsModule(object):
        def __init__(self):
            self.vars = dict(
                foo='bar',
                nested_foo=dict(
                    bar='baz',
                ),
            )

        def get_vars(self, play, task, host, vault_password=None):
            return self.vars

    class FakeTemplar(Templar):
        def __init__(self):
            self._available_variables = FakeVarsModule().vars

    templar = FakeTemplar()

    assert listify_lookup_plugin_terms("{{ foo }} and {{nested_foo.bar}}", templar, None) == ['bar and baz']

# Generated at 2022-06-21 08:50:54.790528
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.loader import AnsibleLoader

    load = AnsibleLoader(None, variable_manager=VariableManager(), basedir="../../")

    # templates are loaded as AnsibleUnsafeText, so convert
    term1 = load("{{test_var}}", from_str=True)
    term2 = load("{{test_var2}}", from_str=True)
    term3 = load("{{test_var3}}", from_str=True)
    single_string_term = load("{{test_var}} - {{test_var2}} - {{test_var3}}", from_str=True)

    terms = [term1, term2, term3]


# Generated at 2022-06-21 08:51:05.090688
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()

    # test empty terms
    assert listify_lookup_plugin_terms(None, Templar(loader=loader), loader) == []

    # test string terms
    assert listify_lookup_plugin_terms('foo', Templar(loader=loader), loader) == ['foo']

    # test list terms
    assert listify_lookup_plugin_terms(['localhost', '127.0.0.1'], Templar(loader=loader), loader) == ['localhost', '127.0.0.1']

    # test templating

# Generated at 2022-06-21 08:51:16.441914
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.module_utils.common.json_dict
    import ansible.template

    j = ansible.module_utils.common.json_dict.AnsibleJSONEncoder()

    terms = "an apple a day"
    templar = ansible.template.Templar()
    assert listify_lookup_plugin_terms([terms], templar, None) == [terms]

    terms = ["an apple a day", "keeps the doctor away"]
    templar = ansible.template.Templar()
    assert listify_lookup_plugin_terms(terms, templar, None) == terms

    terms = ("an apple a day", "keeps the doctor away")
    templar = ansible.template.Templar()

# Generated at 2022-06-21 08:51:26.561941
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = None
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('one two three', templar, loader) == ['one two three']
    assert listify_lookup_plugin_terms(['one two three'], templar, loader) == ['one two three']
    assert listify_lookup_plugin_terms(['one', 'two', 'three'], templar, loader) == ['one', 'two', 'three']
    assert listify_lookup_plugin_terms(['one', ['two', ['three']]], templar, loader) == ['one', ['two', ['three']]]

# Generated at 2022-06-21 08:51:34.285900
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    for x in [
        'a',
        ['a','b'],
        [1,2,3],
        [True, False],
        ['{{a}}', 'b'],
        ['a', 'b', '{{c}}'],
        ['a', 'b', '{{c}}', 'd'],
    ]:
        for convert_bare in [True, False]:
            for fail_on_undefined in [True, False]:
                templar = Templar(loader=None, variables={'a':1, 'b':2, 'c':3}, convert_bare=convert_bare)

# Generated at 2022-06-21 08:51:45.631062
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.errors import AnsibleError
    from ansible.template import Templar

    templar = Templar(loader=None)
    terms = listify_lookup_plugin_terms(terms=[AnsibleUnicode('{{ terms }}'), AnsibleUnicode('{{ terms2 }}'), AnsibleUnicode('{{ terms3 }}')], templar=templar, loader=None, fail_on_undefined=True)
    assert isinstance(terms, list) and len(terms) == 3 and isinstance(terms[0], string_types) and isinstance(terms[1], string_types) and isinstance(terms[2], string_types)


# Generated at 2022-06-21 08:51:57.772856
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager

    # Set up class instances we need for the tests
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=''))

    templar = Templar(loader=loader, variables=variable_manager)

    # Test that listify_lookup_plugin_terms returns a list when given a string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-21 08:52:06.461795
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import wrap_var

    t = Templar(loader=None)

    assert listify_lookup_plugin_terms('foo', t, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], t, None) == ['foo']
    assert listify_lookup_plugin_terms(wrap_var('foo'), t, None) == ['foo']
    assert listify_lookup_plugin_terms(wrap_var(['foo']), t, None) == ['foo']

# Generated at 2022-06-21 08:52:26.266172
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar

    # Loader that converts to unicode
    class UnicodeLoader(AnsibleLoader):
        def compose_node(self, parent, index):
            # the line number where the previous token has ended (plus empty lines)
            line = self.line
            node = AnsibleMapping()
            self.flatten_mapping(node)
            return node


# Generated at 2022-06-21 08:52:37.803042
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    listify_lookup_plugin_terms tests
    """
    import ansible.template
    import ansible.constants as C
    import ansible.parsing.vault

    # Make sure that a string is returned as a list
    assert listify_lookup_plugin_terms('string', None, None) == ['string']

    # Make sure that None is returned as []
    assert listify_lookup_plugin_terms(None, None, None) == []

    # Make sure that an int is returned as a list
    assert listify_lookup_plugin_terms(42, None, None) == [42]

    # Make sure that a list is returned as is
    assert listify_lookup_plugin_terms(['list'], None, None) == ['list']

    # Make sure that a dict is returned as a

# Generated at 2022-06-21 08:52:44.096445
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)
    terms   = listify_lookup_plugin_terms("{{ [1,2,3] }}", templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert isinstance(terms, list)
    assert terms == [1,2,3]

    terms   = listify_lookup_plugin_terms("{{ 'low' | quote }}:{{ 'high' | quote }}", templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert isinstance(terms, list)
    assert terms == ['low', 'high']


# Generated at 2022-06-21 08:52:51.837937
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(a=dict(b=dict(c=dict(d=3))))
    my_vars = variable_manager.get_vars(loader=None, play=None)
    templar = Templar(loader=None, variables=my_vars)

    val = listify_lookup_plugin_terms('{{ a }}', templar, None, fail_on_undefined=False)
    assert isinstance(val, list)
    assert len(val) == 1
    assert val[0] == dict(b=dict(c=dict(d=3)))


# Generated at 2022-06-21 08:53:03.477883
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.utils.display import Display
    from ansible.playbook.template import Templar
    from ansible.vars import VariableManager

    display = Display()
    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader)

    # strings
    assert listify_lookup_plugin_terms('a', templar, loader) == ['a']
    assert listify_lookup_plugin_terms('a,b,c', templar, loader) == ['a','b','c']
    assert listify_lookup_plugin_terms('"a"', templar, loader) == ['a']
    assert listify_lookup_plugin

# Generated at 2022-06-21 08:53:10.810165
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 08:53:21.431625
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    listify_lookup_plugin_terms unit test
    '''
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    import ansible.playbook.play_context

    terms_none = None
    terms_string = 'test'
    terms_list = ['test1', 'test2', 'test3']
    terms_list_nested = [
        ['test1a', 'test1b'],
        ['test2a', 'test2b'],
        ['test3a', 'test3b'],
    ]

# Generated at 2022-06-21 08:53:33.478983
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class FakeLoader:
        pass

    class FakeTemplar:
        def template(self, terms, **kwargs):
            return terms

    loader = FakeLoader()
    templar = FakeTemplar()

    assert isinstance(listify_lookup_plugin_terms(["a", "b", "c"], templar, loader), list)
    assert listify_lookup_plugin_terms(["a", "b", "c"], templar, loader) == ["a", "b", "c"]

    assert isinstance(listify_lookup_plugin_terms("a", templar, loader), list)
    assert listify_lookup_plugin_terms("a", templar, loader) == ["a"]


# Generated at 2022-06-21 08:53:45.801502
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms('foo bar', templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', "{{ somevar }}"], templar, None) == ['foo', 'bar', "{{ somevar }}"]
    assert listify_lookup_plugin_terms(['foo', 'bar', u"{{ somevar }}"], templar, None) == ['foo', 'bar', "{{ somevar }}"]
    assert listify_lookup_plugin_terms('foo {{ somevar }}', templar, None)

# Generated at 2022-06-21 08:53:54.434022
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    def assert_listify_lookup_plugin_terms_returns(terms, expected, convert_bare=False):
        context = dict()
        templar = Templar(loader=None, variables=context)
        terms = listify_lookup_plugin_terms(terms, templar, loader=None)
        assert terms == expected

    string_terms = ['string1', 'string2', 'string3']
    list_terms = ['string1', 'string2', 'string3']
    dict_terms = {'name': 'string1', 'name': 'string2'}
    single_string_terms = 'single_string'

    assert_listify_lookup_plugin_terms_returns(string_terms, string_terms)
    assert_listify_lookup_plugin_terms_return

# Generated at 2022-06-21 08:54:10.976598
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms(['blah'], templar, None) == ['blah']
    assert listify_lookup_plugin_terms('blah', templar, None) == ['blah']
    assert listify_lookup_plugin_terms('[1,2,3]', templar, None) == [1,2,3]

# this is in a try/except to support Ansible <= 2.4, which does not
# import things from __main__
try:
    from __main__ import display
except ImportError:
    from ansible.utils.display import Display
    display = Display()


# Generated at 2022-06-21 08:54:22.115486
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.templar import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    test_strings = [
        "{{ var1 }}",
        "{{ var2[0] }}",
        "{{ [var3, var4] | join(',') }}",
        "{{ var5[1] }}",
        "{{ var6[var7][var8] }}",
        "var9",
        [
            "var10",
            "var11",
        ],
        "{{ var12 }}",
        "{{ var13 }}",
    ]

# Generated at 2022-06-21 08:54:31.416477
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar

    class VarsModule:
        def __init__(self, loader):
            pass

        def __getitem__(self, key):
            return "bar"

        def get(self, key, *args, **kwargs):
            value = "foo"
            if key == "qux":
                value = "qux_value"
            return value

    class LoaderModule:
        def get_basedir(self, *args, **kwargs):
            return "/some/path"

        def path_dwim(self, basedir, *args, **kwargs):
            return "/some/path/dwim"

    class TestTemplar(Templar):
        def __init__(self, loader, variables):
            self._available_vari

# Generated at 2022-06-21 08:54:41.660251
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, None)

    class mystr(str, AnsibleBaseYAMLObject):
        pass

    class myunicode(unicode, AnsibleBaseYAMLObject):
        pass

    class mylist(list, AnsibleBaseYAMLObject):
        pass

    templar = Templar(loader=loader)

    # Test with a single str
    terms = 'a'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert type(terms) is list
    assert terms == ['a']

    # Test with a single unicode
    terms = u

# Generated at 2022-06-21 08:54:49.682196
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    t = Templar(loader=None)
    res = listify_lookup_plugin_terms(terms=['{{ foo }}'], templar=t, loader=None)
    assert res == ['{{ foo }}'], res
    res = listify_lookup_plugin_terms(terms='{{ foo }}', templar=t, loader=None)
    assert res == ['{{ foo }}'], res
    res = listify_lookup_plugin_terms(terms=['{{ foo }}', '{{ bar }}'], templar=t, loader=None)
    assert res == ['{{ foo }}', '{{ bar }}'], res

# Generated at 2022-06-21 08:54:57.407633
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import MockLoader
    from units.mock.env import MockEnvironment

    env = MockEnvironment()
    loader = MockLoader()

    # test list conversion
    assert listify_lookup_plugin_terms([1, 2, 3], loader.get_basedir(), loader) == [1, 2, 3]
    assert listify_lookup_plugin_terms('1, 2, 3', loader.get_basedir(), loader) == '1, 2, 3'
    assert listify_lookup_plugin_terms('{{ [1, 2, 3] }}', loader.get_basedir(), loader) == [1, 2, 3]

    # test single item conversion
    assert listify_lookup_plugin_terms('1', loader.get_basedir(), loader) == ['1']
    assert listify_lookup_

# Generated at 2022-06-21 08:55:06.190078
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    class FakeVarManager():
        def __init__(self):
            self.vars = {}

    class FakeLoader():
        pass

    class FakeVaultSecret():
        def __init__(self):
            self.vault_password = 'vault_password'

    def fake_get_vault_secret(self):
        return self.vault_secret

    vars = FakeVarManager()

    loader = FakeLoader()

    templar = Templar(loader=loader, variables=vars)

    # Using setUp and tearDown would run into problems
    # with the templar object not being pickleable
    # so just do this with a fake class
    vault_secret = FakeVaultSecret()

# Generated at 2022-06-21 08:55:16.337302
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    results = listify_lookup_plugin_terms('foo', Templar(VariableManager(), PlayContext()), None)
    assert isinstance(results, list)
    assert len(results) == 1
    assert results[0] == 'foo'

    results = listify_lookup_plugin_terms(['foo'], Templar(VariableManager(), PlayContext()), None)
    assert isinstance(results, list)
    assert len(results) == 1
    assert results[0] == 'foo'


# Generated at 2022-06-21 08:55:27.301189
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()

    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, loader) == ['{{ foo }}']
    assert listify_lookup_plugin_terms('', templar, loader) == ['']
    assert listify_lookup_plugin_terms(['  foo  '], templar, loader) == ['  foo  ']
    variable_manager.set_nonpersistent_fact

# Generated at 2022-06-21 08:55:38.387746
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import os
    import tempfile
    import pytest
    import ansible.utils.template as template

    utils = pytest.importorskip("ansible.plugins.lookup.utils")

    testvars = {'a': 'b c', 'b': 'd', 'c': 'e'}

    testenv = dict(ANSIBLE_LOOKUP_PLUGINS=os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins'))
    testenv.update(dict(os.environ))

    def runtest(teststr, testenv, templar=None, expect=None):
        if templar is None:
            templar = template.Templar(loader=template.AnsibleLoader(None))
        res = utils.listify_lookup