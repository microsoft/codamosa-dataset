

# Generated at 2022-06-21 08:45:43.453323
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms("{{ ['a','b','c']}}",
                                       templar=None, loader=None) == ['a','b','c']
    assert listify_lookup_plugin_terms(['a','b','c'],
                                       templar=None, loader=None) == ['a','b','c']
    assert listify_lookup_plugin_terms("{{ 'a'}}",
                                       templar=None, loader=None) == ['a']
    assert listify_lookup_plugin_terms("a",
                                       templar=None, loader=None) == ['a']
    assert listify_lookup_plugin_terms(["a"],
                                       templar=None, loader=None) == ["a"]

# Generated at 2022-06-21 08:45:53.147510
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import os

    class VarManager:
        def __init__(self):
            pass

        def get_vars(self, play=None, host=None, task=None, include_hostvars=True):
            return dict(test_var='test_value')

    basedir = os.path.dirname(__file__)
    loader = DataLoader()
    templar = Templar(loader=loader, variables=VarManager())

    # Case: terms is empty string
    terms = listify_lookup_plugin_terms('', templar, loader=loader)
    assert terms == ['']

    # Case: terms is string
    terms = listify_lookup_plugin_

# Generated at 2022-06-21 08:46:03.084896
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms("{{ a }} {{ b }}", templar, loader, convert_bare=True) == ['{{ a }}', '{{ b }}']
    assert listify_lookup_plugin_terms("{{ a }} {{ b }}", templar, loader, convert_bare=False) == ['', '']
    assert listify_lookup_plugin_terms

# Generated at 2022-06-21 08:46:14.631161
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert listify_lookup_plugin_terms('foo', Templar({'bar': 'baz'}), None) == ['foo']
    assert listify_lookup_plugin_terms(42, Templar({'bar': 'baz'}), None) == [42]
    assert listify_lookup_plugin_terms([42], Templar({'bar': 'baz'}), None) == [42]
    assert listify_lookup_plugin_terms(['foo', 'bar'], Templar({'bar': 'baz'}), None) == ['foo', 'bar']

# Generated at 2022-06-21 08:46:22.189966
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DictDataLoader({})
    mytemplar = Templar(loader=loader, variables={})

    assert listify_lookup_plugin_terms(['three', 'four'], mytemplar, loader) == ['three', 'four']
    assert listify_lookup_plugin_terms('three', mytemplar, loader) == ['three']
    assert listify_lookup_plugin_terms(['three', 'four'], mytemplar, loader, fail_on_undefined=False) == ['three', 'four']
    assert listify_lookup_plugin_terms('"{{foo}}"', mytemplar, loader, fail_on_undefined=False) == ['{{foo}}']



# Generated at 2022-06-21 08:46:27.585238
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    my_loader = DataLoader()
    inventory = InventoryManager(loader=my_loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=my_loader, inventory=inventory)
    templar = Templar(loader=my_loader, variables=variable_manager)

    terms = ['foo1', 'foo2', 'foo3']
    result = listify_lookup_plugin_terms(terms, templar)
    assert result == ['foo1', 'foo2', 'foo3']

    terms = '{{ foo1 }}, {{ foo2 }}, {{ foo3 }}'
    result = listify_

# Generated at 2022-06-21 08:46:35.596070
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, shared_loader_obj=None, variables={})

    assert listify_lookup_plugin_terms(['a', 'b'], templar, None) == ['a', 'b']
    assert listify_lookup_plugin_terms(['a', 'b'], templar, None, convert_bare=True) == ['a', 'b']

    assert listify_lookup_plugin_terms('a, b', templar, None) == ['a', 'b']
    assert listify_lookup_plugin_terms('a, b', templar, None, convert_bare=True) == ['a', 'b']


# Generated at 2022-06-21 08:46:47.437471
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # base case, listify_lookup_plugin_terms should return a list of one
    result = listify_lookup_plugin_terms("5", Templar(DataLoader()), DataLoader())
    assert isinstance(result, MutableSequence)
    assert len(result) == 1
    assert result[0] == 5

    # string with spaces and tabs, should return a list of one
    result = listify_lookup_plugin_terms(" 7  ", Templar(DataLoader()), DataLoader())
    assert isinstance(result, MutableSequence)


# Generated at 2022-06-21 08:46:56.656465
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    template_data = dict(k1='var1', k2='var2')
    loader = None
    templar = Templar(loader=loader, variables=template_data)

    # tests for templating
    assert listify_lookup_plugin_terms('{{ k1 }}', templar, loader) == ['var1']
    assert listify_lookup_plugin_terms([' {{ k1 }}', '{{ k2 }} '], templar, loader) == ['var1', 'var2']
    assert listify_lookup_plugin_terms(['{{ k1 }}', '{{ k2 }}'], templar, loader) == ['var1', 'var2']

# Generated at 2022-06-21 08:47:07.061551
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Here we use raw strings, as this is what would come from the yaml parser
    assert listify_lookup_plugin_terms(r'one', None, None) == ['one']
    assert listify_lookup_plugin_terms(r'one two', None, None) == ['one two']
    assert listify_lookup_plugin_terms([r'one', r'two'], None, None) == ['one', 'two']
    assert listify_lookup_plugin_terms([r'one', r'two three'], None, None) == ['one', 'two three']

    # Handle the case of a single item in a list
    assert listify_lookup_plugin_terms([r'one'], None, None) == ['one']

# Generated at 2022-06-21 08:47:09.361939
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-21 08:47:19.215149
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import jinja2
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils._text import to_bytes, to_text

    class TestVarsModule:
        def __init__(self, basedir, vars):
            self._basedir = basedir
            self._data = {"vars": vars}

        def get_vars(self, loader, path, entities):
            basedir = self._basedir

            for entity in entities:
                if entity == "vars":
                    return self._data["vars"]

            raise Exception("unknown entity requested in test vars plugin")

    class TestTemplar(jinja2.Environment):
        def __init__(self):
            self._basedir = None
            self._vars_loader = None
            super

# Generated at 2022-06-21 08:47:25.289303
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = listify_lookup_plugin_terms(['localhost', ['127.0.0.1', '::1']], Templar({}, {}), None)
    assert terms == ['localhost', ['127.0.0.1', '::1']]

# Generated at 2022-06-21 08:47:33.791724
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableSequence

    from ansible.template import Templar

    terms = "{{ lookup('foo') }}"
    templar = Templar(loader=None)
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert isinstance(result, MutableSequence)
    assert len(result) == 1
    assert result[0] == '{{ lookup(foo) }}'

    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert isinstance(result, MutableSequence)
    assert len(result) == 1
    assert result[0] == 'foo'

    terms = ['foo', '{{ lookup("bar") }}', 'baz']

# Generated at 2022-06-21 08:47:43.534493
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    try:
        from ansible.parsing.vault import VaultEditor
    except ImportError:
        from ansible.parsing.vault import VaultAES256 as VaultEditor
    from ansible.template import Templar

    from ansible.parsing.meta import UnsafeLoader

# Generated at 2022-06-21 08:47:55.058901
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import const
    import ansible.template
    from ansible.template import Templar
    from ansible.templating import TemplateError

    terms = "{{ lookup('template', 'template_name') }}"
    templar = Templar(loader=None)
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert isinstance(result, list)
    assert result == ['{{ lookup(\'template\', \'template_name\') }}']

    terms = ["{{ lookup('template', 'template_name1') }}", "{{ lookup('template', 'template_name2') }}"]
    templar = Templar(loader=None)
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert isinstance(result, list)

# Generated at 2022-06-21 08:48:07.221557
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Dummy imports for test
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # Dummy configuration for code
    test_vars = dict(
        ansible_default_variable_precedence=['hostvar', 'groupvar', 'playvar', 'vars', 'defaults'],
        ansible_managed='Ansible managed',
        inventory_hostname='localhost',
        vault_password='vaultpass',
    )
    templar = Templar(loader=None, variables=test_vars, shared_loader_object=VaultLib())

    # Test with string
    test_string1 = '{{ list_var }}'
    test_string2 = '{{ list_var | string }}'
    test_string3 = '{{ list_var | first }}'

   

# Generated at 2022-06-21 08:48:15.610231
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert listify_lookup_plugin_terms('1', Templar({}, {}), None) == ['1']
    assert listify_lookup_plugin_terms(['1'], Templar({}, {}), None) == ['1']
    assert listify_lookup_plugin_terms(['1', '2', '3'], Templar({}, {}), None) == ['1', '2', '3']
    assert listify_lookup_plugin_terms(['1', 'a', ['2', 'b'], '3', ['c', 'd']], Templar({}, {}), None) == ['1', 'a', ['2', 'b'], '3', ['c', 'd']]


# Generated at 2022-06-21 08:48:23.963895
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    loader = None
    templar = Templar(loader=loader, variables={})

    # Test string
    s = u'value'
    assert listify_lookup_plugin_terms(s, templar, loader) == [s]
    assert listify_lookup_plugin_terms(s, templar, loader, convert_bare=True) == [s]

    # Test string template
    s = u'{{ value }}'
    assert listify_lookup_plugin_terms(s, templar, loader) == [s]
    assert listify_lookup_plugin_terms(s, templar, loader, convert_bare=True) == [s]

    # Test list

# Generated at 2022-06-21 08:48:35.163064
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class TestTemplar:
        def template(self, data, **kwargs):
            ret = data
            if not isinstance(data, list) and 'create_list' in kwargs and kwargs['create_list']:
                ret = [data]

            return ret

    terms = listify_lookup_plugin_terms('{{ var1 }},{{ var2 }}', TestTemplar(), None, fail_on_undefined=True)
    assert terms == ['var1', 'var2']

    terms = listify_lookup_plugin_terms('{{ var1 }}', TestTemplar(), None, fail_on_undefined=True)
    assert terms == ['var1']


# Generated at 2022-06-21 08:48:41.479739
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms([1,2,3], None, None) == [1,2,3]
    assert listify_lookup_plugin_terms([1,2,3], None, None, convert_bare=True) == [1,2,3]
    assert listify_lookup_plugin_terms(1, None, None) == [1]

# Generated at 2022-06-21 08:48:47.090900
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    # Fixtures
    class FakeVaultSecret(object):
        def __init__(self, data):
            self.vault_data = {'data': data}
        def load(self):
            return self.vault_data['data']

    class FakeVaultSecretCopy(FakeVaultSecret):
        def __init__(self, *args):
            self.vault_data = {'data': list(args)}
        def load(self):
            return self.vault_data['data']


# Generated at 2022-06-21 08:48:58.873854
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.template import Templar
    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables={})

    # Test with a string
    assert listify_lookup_plugin_terms('hi', templar, loader) == ['hi']
    assert listify_lookup_plugin_terms('fi', templar, loader) == ['fi']

    # Test with a list of strings
    assert listify_lookup_plugin_terms(['hi', 'fi'], templar, loader) == ['hi', 'fi']

    # Test with a AnsibleUnsafe object
    assert listify

# Generated at 2022-06-21 08:49:10.893650
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(
        foo='foo',
        foo_file='/tmp/foo_file',
        foo_dict={'bar': 'baz'},
        foo_list=['a', 'b'],
        foo_list2=[1, 2],
    ))
    templar = Templar(loader=None, variables=variable_manager)

    # simple string
    assert listify_lookup_plugin_terms('{{foo}}', templar, loader=None) == ['foo']

    # multiple strings

# Generated at 2022-06-21 08:49:21.875162
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode

    def _unicode_constructor(self, node):
        # This is required for the ansible.template.Templar class to be able to
        # handle unicode objects in the data
        return node.value

    AnsibleUnicode.__init__ = _unicode_constructor

    terms = AnsibleMapping()
    terms.yaml_set_line_col(0, 0)
    terms[AnsibleUnicode('key1')] = 1
    terms[AnsibleUnicode('key2')] = 2
    terms[AnsibleUnicode('key3')] = 3
    templar = Templar(loader=None)
    assert listify_lookup

# Generated at 2022-06-21 08:49:32.875332
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test simple strings
    assert listify_lookup_plugin_terms('simple string', None, None, fail_on_undefined=False) == ['simple string']

    # Test generic iterables with string content
    assert listify_lookup_plugin_terms(('simple', 'strings'), None, None, fail_on_undefined=False) == ['simple', 'strings']
    assert listify_lookup_plugin_terms(['simpler', 'strings'], None, None, fail_on_undefined=False) == ['simpler', 'strings']

    # Test generic iterables with iterable content

# Generated at 2022-06-21 08:49:43.542729
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.template import Templar

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    class Options(object):
        def __init__(self, connection, remote_user, timeout=10, private_key_file=None, ssh_common_args=None,
                     ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None, become=False, become_method=None,
                     become_user=None, verbosity=None, check=False, diff=False):
            self.connection = connection
            self.remote_user = remote_user
            self.timeout = timeout
            self.private_key_file

# Generated at 2022-06-21 08:49:53.760990
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar

    templar = Templar(variables={'foo': 'hello world', 'bar': ['a', 'b', 'c'], 'xyz': {'x': 123, 'y': 456, 'z': 789}}, loader=None)
    result = listify_lookup_plugin_terms(["{{ foo }}"], templar, None)
    assert result == ['hello world'], result
    result = listify_lookup_plugin_terms(["{{ foo }} {{ bar }}"], templar, None)
    assert result == ['hello world [u\'a\', u\'b\', u\'c\']'], result
    result = listify_lookup_plugin_terms(["{{ foo[0] }}"], templar, None)

# Generated at 2022-06-21 08:50:02.000178
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(foo='bar', bar='{{ foo }}')
    my_vars = variable_manager.get_vars(loader=loader, play=dict(name='fake', variables=dict()))
    my_vars['ansible_os_family'] = 'Darwin'
    templar = Templar(loader=loader, variables=my_vars)

    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], templar, loader) == ['bar', '{{ foo }}']
    assert listify_lookup_plugin_terms

# Generated at 2022-06-21 08:50:09.550641
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    templar = object
    templar.template = lambda s, **kwargs: s

    class DummyLoader:
        path_dwim = lambda s, x: None

    loader = DummyLoader()

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-21 08:50:21.589747
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import lookup_loader, module_loader

    args = dict(
        variable_manager={'_fact_cache': {}, '_extra_vars': {}},
        loader=module_loader,
    )

    templar = Templar(VaultLib(), **args)

    # Test string term
    assert listify_lookup_plugin_terms('foo', templar, module_loader) == ['foo']

    # Test list term
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, module_loader) == ['foo', 'bar']

    # Test dict term

# Generated at 2022-06-21 08:50:32.899136
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils._text import to_bytes

    terms = to_bytes("{{ lookup('env', 'HOME') }}")
    loader = None
    passwords = dict(vault_pass='secret')

    vault_secrets = dict(vault_password='secret')
    inventory = InventoryManager(loader=loader, sources=[])
    play_context = PlayContext()
    play_context._vault_secrets = vault_secrets

# Generated at 2022-06-21 08:50:44.910535
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext

    class Templar():
        def __init__(self):
            self._available_variables = dict(
                x = ["a", "b", "c"],
                y = ["a", "b", "c"],
            )
            self.loader = None
            self.no_log_strings = []
        def set_available_variables(self, variables):
            self._available_variables = variables
        def template(self, template_string, convert_bare=False, fail_on_undefined=False, override_vars=None):
            return template_string
        def _get_final_vars(self, loader=None, variables=None, convert_bare=False, fail_on_undefined=False):
            return self._available_variables


# Generated at 2022-06-21 08:50:46.380945
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert(listify_lookup_plugin_terms("{{ foo }}") == ['{{ foo }}'])

# Generated at 2022-06-21 08:50:54.756283
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.errors import AnsibleUndefinedVariable, AnsibleParserError
    from ansible.template import Templar


# Generated at 2022-06-21 08:51:05.053511
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Single value string
    assert listify_lookup_plugin_terms('a', None, None) == ['a']

    # Single value int
    assert listify_lookup_plugin_terms(1, None, None) == [1]

    # List of values
    assert listify_lookup_plugin_terms([1, 2, 3], None, None) == [1, 2, 3]

    # Json string
    assert listify_lookup_plugin_terms('["a", "b", "c"]', None, None) == ['a', 'b', 'c']

    # Single value string with spaces
    assert listify_lookup_plugin_terms(' a ', None, None) == ['a']

    # List of values with spaces

# Generated at 2022-06-21 08:51:16.443947
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms([], templar, None) == []
    assert listify_lookup_plugin_terms(["a", "b"], templar, None) == ["a", "b"]
    assert listify_lookup_plugin_terms("a", templar, None) == ["a"]
    assert listify_lookup_plugin_terms("a b", templar, None) == ["a", "b"]
    assert listify_lookup_plugin_terms(" a b ", templar, None) == ["a", "b"]
    assert listify_lookup_plugin_terms(["a", "b"], templar, None, False) == ["a", "b"]
    assert listify

# Generated at 2022-06-21 08:51:28.431477
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    def get_loader():
        return DataLoader()

    loader = get_loader()
    vault_secrets = {}
    vault_password = None
    vault = VaultLib(vault_secrets, loader=loader, vault_password=vault_password)
    templar = Templar(loader=loader, variables={}, vault_secrets=vault_secrets)
    # string should be converted to list
    assert listify_lookup_plugin_terms("a,b,c", templar, loader) == ["a", "b", "c"]
    # List should be left alone

# Generated at 2022-06-21 08:51:40.906697
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    templar = Templar(loader=None)
    test_string = 'item1, item2, item3'
    test_unicode = AnsibleUnicode('item1, item2, item3')
    test_list = ['item1', 'item2', 'item3']

    # test string -> list conversion
    terms_list = listify_lookup_plugin_terms(test_string, templar, None)
    assert terms_list == test_list

    # test unicode -> list conversion
    terms_list = listify_lookup_plugin_terms(test_unicode, templar, None)
    assert terms_list == test_list

    # test list
    terms_list = listify

# Generated at 2022-06-21 08:51:53.430948
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook import PlayContext
    from ansible.template import Templar

    context = PlayContext()
    templar = Templar(loader=None, variables={'aaa': '111', 'bbb': '222'})

    assert listify_lookup_plugin_terms('aaa', templar, None, True, False) == ['111']
    assert listify_lookup_plugin_terms('{{aaa}}', templar, None, True, False) == ['111']
    assert listify_lookup_plugin_terms(['aaa', 'bbb'], templar, None, True, False) == ['111', '222']
    assert listify_lookup_plugin_terms(['{{aaa}}', 'bbb'], templar, None, True, False) == ['111', '222']
    assert listify_look

# Generated at 2022-06-21 08:52:10.963282
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    terms = ["{{ _terms }}", "{{ _terms[0] }}", "{{ _terms[-1] }}", "{{ _terms[1] }}"]
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_vault_secrets(dict(vault_password='secret'))
    vault_secrets = [('default', VaultLib([('default', 'secret')], ['default'], 'secret'))]

    templar = Templar(loader=loader, variables=variable_manager, vault_secrets=vault_secrets)
    result = listify_lookup_plugin

# Generated at 2022-06-21 08:52:22.555936
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    import ansible.utils.unsafe_proxy

    templar = ansible.template.Templar(loader=None)

    # Test string is returned as a list of strings
    assert listify_lookup_plugin_terms('test', templar, loader=None) == ['test']

    # Test list is returned as itself
    assert listify_lookup_plugin_terms(['test'], templar, loader=None) == ['test']

    # Test list is returned as a list of strings
    assert listify_lookup_plugin_terms(['test', 'test2'], templar, loader=None) == ['test', 'test2']

    # Test that dictionary terms fail with an exception

# Generated at 2022-06-21 08:52:33.828263
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultEditor
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    vault_pass = 'ansible'
    loader = None

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    vault_secrets = dict(vault_password='testpass')
    vault_editor = VaultEditor(vault_pass, loader=loader, vault_secrets=vault_secrets)

# Generated at 2022-06-21 08:52:44.630391
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.template import Templar

    env_vars = dict(
        ansible_lookup_file_vars=OrderedDict([('one', '1'), ('two', '2'), ('three', '3')]),
        ansible_lookup_file_one='1',
        ansible_lookup_file_two='2',
        ansible_lookup_file_three='3',
        ansible_lookup_file_bar='bar',
        ansible_lookup_file_foo='foo',
        ansible_lookup_file_groot='I am groot.',
    )
    templar = Templar(None, loader=None, variables=env_vars)

    # Test input as a single string


# Generated at 2022-06-21 08:52:53.666072
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    def _get_loader():
        return DataLoader()

    def _get_vault_secrets(path):
        return {}

    def _get_vars():
        return {}

    templar = Templar(loader=_get_loader(), variables=VariableManager(_get_vars()), vault_secrets=_get_vault_secrets('test'))

    # test string
    assert listify_lookup_plugin_terms('ansible', templar) == ['ansible']

    # test list
    assert listify_lookup_plugin_terms(['ansible', 'ansible'], templar) == ['ansible', 'ansible']

    #

# Generated at 2022-06-21 08:53:04.705089
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    v = VariableManager()
    v.set_available_variables([{"somevar": "somevalue"}])
    d = DataLoader()
    t = Templar(loader=d, variables=v)
    assert listify_lookup_plugin_terms("${somevar}", t, d) == ['somevalue']
    assert listify_lookup_plugin_terms("${somevar}", t, d, convert_bare=True) == ['somevalue']
    assert listify_lookup_plugin_terms("${somevar}", t, d, convert_bare=False) == ['somevalue']

# Generated at 2022-06-21 08:53:11.974219
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: Move test to test/unit/module_utils/common/collections.py
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class FakeTemplar(object):
        def template(self, data, fail_on_undefined=True, convert_bare=False):
            if isinstance(data, string_types):
                return "TEMPLATED({0})".format(data)
            elif isinstance(data, list) or isinstance(data, Sequence):
                return [self.template(item, fail_on_undefined=fail_on_undefined, convert_bare=convert_bare) for item in data]
            else:
                return data
    

# Generated at 2022-06-21 08:53:22.246912
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class DataLoader():
        def __init__(self):
            pass
    data_loader = DataLoader()

    templar = Templar(loader=data_loader)

    # test flat list:
    terms_1 = ['foo', 'bar', 'baz']
    terms_1_result = listify_lookup_plugin_terms(terms_1, templar, data_loader)
    assert terms_1_result == ['foo', 'bar', 'baz'], "Returned '%s' instead of '[foo', 'bar', 'baz]' when passed a flat list" % terms_1_result

    # test nested list:
    terms_2 = ['foo', ['bar', 'baz'], 'foobar']

# Generated at 2022-06-21 08:53:33.098211
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # input:
    terms = "[ 'a' , 'b', '1', '2', { key : value }, 'd' ]"

    # output:
    # ['a', 'b', '1', '2', {'key': 'value'}, 'd']

    # code:
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    output = listify_lookup_plugin_terms(terms, templar, None)
    assert output == ['a', 'b', '1', '2', {'key': 'value'}, 'd']
    assert isinstance(output[-1], MutableMapping)

# Generated at 2022-06-21 08:53:45.139283
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    def test_shared(terms, tmpl, var_manager, resolve_bare=False):
        templar = Templar(loader=None, variables=var_manager)
        result = listify_lookup_plugin_terms(terms, templar, convert_bare=resolve_bare)
        assert result == tmpl, "%s != %s" % (result, tmpl)

    # Simple case, no jinja2
    test_shared("foobar", ["foobar"], {}, False)

    # Jinja2 template with simple value
    test_shared("{{ lookup('env','HOME') }}", ["/home/foo"], { "lookup_env_HOME":"/home/foo" }, False)

    # Bare jinja2 template with simple value

# Generated at 2022-06-21 08:54:09.258911
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.parsing.yaml.objects
    from ansible.template import Templar
    from ansible.vars import VariableManager

    v = VariableManager()
    templar = Templar(loader=None, variables=v)

    assert listify_lookup_plugin_terms('string', templar, loader=None) == ['string']
    assert listify_lookup_plugin_terms(['string'], templar, loader=None) == ['string']
    assert listify_lookup_plugin_terms(['string', 'list'], templar, loader=None) == ['string', 'list']
    assert listify_lookup_plugin_terms([u'unicode', 'string'], templar, loader=None) == [u'unicode', u'string']
    assert listify_lookup_plugin

# Generated at 2022-06-21 08:54:20.603012
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.module_utils._text import to_text

    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms('1', templar, loader=None) == ['1']
    assert listify_lookup_plugin_terms('1, 2', templar, loader=None) == ['1', '2']
    assert listify_lookup_plugin_terms('1, 2, 3', templar, loader=None) == ['1', '2', '3']
    assert listify_lookup_plugin_terms(['1', '2', '3'], templar, loader=None) == ['1', '2', '3']

# Generated at 2022-06-21 08:54:30.405976
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = ''
    templar = Templar(loader=None, variables={})
    terms = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert isinstance(terms, list) == True
    assert isinstance(terms[0], string_types) == True

    terms = 'a'
    templar = Templar(loader=None, variables={})
    terms = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert isinstance(terms, list) == True
    assert isinstance(terms[0], string_types) == True

    terms = u'a'
    templar = Templar

# Generated at 2022-06-21 08:54:40.800822
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Using nose.tools with assert_*
    from ansible.module_utils import basic

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = basic.AnsibleTemplar()

    # single terms
    terms = listify_lookup_plugin_terms('foo', templar, None)
    assert 'foo' in terms

    # bare string as term
    terms = listify_lookup_plugin_terms('{{ foo }}', templar, None)
    assert '{{ foo }}' in terms

    # unsafe text as term
    terms = listify_lookup_plugin_terms(AnsibleUnsafeText('{{ foo }}'), templar, None)
    assert '{{ foo }}' in terms

    # list as term

# Generated at 2022-06-21 08:54:46.940110
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader

    terms = [
        'foo',
        'bar',
        'baz',
        '{{ foo }}',
    ]

    templar = Templar(loader=DataLoader())
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True) == [
        'foo',
        'bar',
        'baz',
        '{{ foo }}',
    ]

# Generated at 2022-06-21 08:54:55.181253
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import os
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    # Create minimal objects for templar
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = { "foo": "bar", "baz": "faz" }
    variable_manager.options_vars = { "foo": "yup", "baz": "nope" }
    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-21 08:55:04.321997
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.template import Templar
    templar = Templar()

    # ansible_loose_bool is True by default
    # string conversion
    result = listify_lookup_plugin_terms(AnsibleUnicode(u'foo'), templar, None)
    assert isinstance(result, list) and result[0] == 'foo'

    result = listify_lookup_plugin_terms(AnsibleUnicode(u'bar'), templar, None, convert_bare=True)
    assert isinstance(result, list) and result[0] == 'bar'


# Generated at 2022-06-21 08:55:15.310807
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(None, None)

    assert listify_lookup_plugin_terms(terms="{{ 'string_single' }}", templar=templar) == 'string_single'
    assert listify_lookup_plugin_terms(terms=['{{ foo }}', '{{ bar }}'], templar=templar) == ['', '']
    assert listify_lookup_plugin_terms(terms=["{{ 'string_single' }}"], templar=templar) == ['string_single']
    assert listify_lookup_plugin_terms(terms="{{ 'string_single' }}", templar=templar) == "string_single"

# Generated at 2022-06-21 08:55:26.727296
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # FIXME: use proper unittest framework and create proper cases
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', ['bar', 'baz']], templar, None) == ['foo', ['bar', 'baz']]

    # from github issue: ansible/ansible#63883

# Generated at 2022-06-21 08:55:37.852287
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=Play().load(None, loader=loader)), inventory=inventory)

    single_terms = ['a','b','1',1]
    multiple_terms = ['a,b','c,d','1,2',[1,2]]
