

# Generated at 2022-06-21 08:45:37.436853
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import os
    import sys
    import tempfile
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    test_templar = Templar(
        loader=DataLoader(),
        variables={
            'item1': 'value1',
            'item2': [ 'value2a', 'value2b' ],
            'item3': { 'key3': 'value3' },
        },
    )

    # Test single term
    assert listify_lookup_plugin_terms('{{ item1 }}', test_templar, DataLoader()) == ['value1']

    # Test list term
    assert listify_lookup_plugin_terms('{{ item2 }}', test_templar, DataLoader()) == ['value2a', 'value2b']

    # Test dict term
   

# Generated at 2022-06-21 08:45:45.183689
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.parsing.yaml.objects
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    terms1 = ansible.parsing.yaml.objects.AnsibleUnicode('test_name')
    templar = Templar(loader=None, variables={'inventory_hostname': 'test_host'})
    result1 = listify_lookup_plugin_terms(terms1, templar, None, fail_on_undefined=True, convert_bare=False)
    assert result1 == ['test_name']

    terms2 = ansible.parsing.yaml.objects.AnsibleUnicode('{{ inventory_hostname }}')

# Generated at 2022-06-21 08:45:55.582898
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.vars import combine_vars

    class DummyVarsModule:
        pass

    class DummyLoaderModule:
        pass

    vars_mock = DummyVarsModule()
    vars_mock.vars = combine_vars(loader=None, variables=dict())
    loader_mock = DummyLoaderModule()

    test_templar = Templar(loader=loader_mock, variables=vars_mock)

    assert listify_lookup_plugin_terms([], test_templar, loader_mock, False) == []
    assert listify_lookup_plugin_terms([], test_templar, loader_mock) == []


# Generated at 2022-06-21 08:46:04.057536
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))

    # test with a string
    result = listify_lookup_plugin_terms("foo:{{bar}}", templar, None, fail_on_undefined=False)
    assert result == ['foo:{{bar}}'], "String should be returned as a list"

    # test with a list
    result = listify_lookup_plugin_terms(["foo:{{bar}}", "baz"], templar, None, fail_on_undefined=False)
    assert result == ['foo:{{bar}}', 'baz'], "List should be returned as is"

    # test with a dict
    result = listify_lookup_plugin_terms

# Generated at 2022-06-21 08:46:13.021782
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = None
    templar = Templar(loader=loader, variables={'var': 'foo'})

    terms_list = listify_lookup_plugin_terms(['ansible', 'is', '{{var}}'], templar, loader)
    assert terms_list == ['ansible', 'is', 'foo']

    terms_string = listify_lookup_plugin_terms('ansible', templar, loader)
    assert terms_string == ['ansible']

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-21 08:46:21.619959
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variable_manager=variable_manager)

    def check(terms, expected):
        assert listify_lookup_plugin_terms(terms, templar) == expected

    # Test string case
    check('foo', ['foo'])
    check(' foo ', ['foo'])
    check(' foo,bar ', ['foo', 'bar'])
    check(' foo, bar ', ['foo', 'bar'])

    # Test multiple strings
    check(['foo'], ['foo'])
    check([' foo '], ['foo'])

# Generated at 2022-06-21 08:46:31.742944
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_vars(dict(a="a_value", b="b_value", c="c_value"))
    templar = Templar(loader=loader, variables=variable_manager)

    # List values are returned as they are
    assert listify_lookup_plugin_terms([1, 2, 3], templar, loader) == [1, 2, 3]

    # String values are returned as lists
    assert listify_lookup_plugin_terms("str", templar, loader) == ["str"]

# Generated at 2022-06-21 08:46:43.765550
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = "{{ item }}"
    assert(listify_lookup_plugin_terms(terms, None, None) == [terms])

    terms = "{{ item }}"
    assert(listify_lookup_plugin_terms(terms, None, None) == [terms])

    terms = "{{ item }}"
    assert(listify_lookup_plugin_terms(terms, None, None) == [terms])

    terms = ["{{ item1 }}", "{{ item2 }}"]
    assert(listify_lookup_plugin_terms(terms, None, None) == terms)

    # Though, technically, this is not a valid test, since we don't have templar, we are just
    # making sure the results are returned as a list.
    terms = ["{{ item1 }}", "{{ item2 }}"]

# Generated at 2022-06-21 08:46:53.724373
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    results = []


# Generated at 2022-06-21 08:47:03.932994
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    terms = AnsibleUnicode('{{ var1 }}')
    templar = Templar(loader=None)
    results = listify_lookup_plugin_terms(terms, templar, loader=None)

    assert isinstance(results, list)
    assert len(results) == 1

    templar._available_variables['var1'] = ['a','b','c']
    results = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert isinstance(results, list)
    assert len(results) == 3
    assert results == ['a','b','c']

# Generated at 2022-06-21 08:47:16.382574
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        from ansible.template import Templar
        templar = Templar(loader=None)
    except ImportError:
        class MockTemplar(object):
            def __init__(self, loader):
                pass
            def template(self, terms):
                return terms

        templar = MockTemplar(loader=None)

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms('', templar, None) == ['']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo,bar', templar, None) == ['foo', 'bar']
    assert listify

# Generated at 2022-06-21 08:47:23.074145
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys, os.path
    sys.path.append(os.path.join(os.path.dirname(__file__), '../'))
    import test
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleParserError

    loader = test.TestDataLoader()

    vault_secret = VaultLib('VaultSecret', None)
    vault_secret.parse(b'VaultSecret', None)

    env = dict()
    templar = Templar(loader=loader, shared_loader_obj=loader, vault_secrets=[vault_secret],
                      variables=dict(a=1))

    # Test with bare string
    assert listify_lookup_plugin_terms("{{ 5 }}", templar, loader, convert_bare=True)

# Generated at 2022-06-21 08:47:32.365551
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    from ansible.vars import Templar
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(a=[1,2,3], b=dict(c=1))
    variable_manager.options_vars = dict(a=1)

    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-21 08:47:42.882701
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    import ansible.constants as C
    import ansible.config.loader

    templar = Templar(loader=ansible.config.loader.ConfigLoader())

    # Simple test to pass a string to function
    # and get back a list with string inside
    assert listify_lookup_plugin_terms('Some text', templar, ansible.config.loader.ConfigLoader()) == ['Some text']

    # Simple test to pass a list to the function
    # and get back a list
    assert listify_lookup_plugin_terms(['Some text'], templar, ansible.config.loader.ConfigLoader()) == ['Some text']

#    # Test with existing variable
#    # ansible.constants.DEFAULT_VAULT_PASSWORD_FILE
#    assert listify_look

# Generated at 2022-06-21 08:47:54.537700
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    terms1 = 'item1 item2 item3'
    terms2 = ['item1', 'item2', 'item3']
    terms2b = ['item1', '{{ item2 }}', 'item3']
    terms3 = {'item1': 'value1', 'item2': 'value2', 'item3': 'value3'}
    terms4 = ('item1', 'item2', 'item3')
    terms5 = 'item1'
    terms6 = '{{ item1 }}'

    template_vars = dict()
    template_vars['item2'] = 'item2'

    # Templating not needed (terms is a list)

# Generated at 2022-06-21 08:48:06.695358
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())
    test_cases = [
        ('spam', ['spam']),
        (' spam ', ['spam']),
        ('spam & eggs', ['spam', 'eggs']),
        ('spam & eggs & spam', ['spam', 'eggs', 'spam']),
        ('{{ ansible_env.HOME }}', [os.path.expanduser("~")]),
        ('{{ ansible_env.HOME }}/{{ ansible_env.HOME }}',
         [os.path.expanduser("~"), os.path.expanduser("~")]),
    ]



# Generated at 2022-06-21 08:48:18.153761
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.module_utils.basic import AnsibleModule
        import ansible.module_utils.common.collections as collections_compat
    else:
        from ansible.module_utils.basic import AnsibleModule
        import ansible.module_utils.common._collections_compat as collections_compat

    import ansible.parsing.dataloader
    import ansible.template
    import ansible.vars


# Generated at 2022-06-21 08:48:24.295840
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test with a simple string
    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']

    # Test with a simple list
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None) == ['foo', 'bar']

    # Test with a bare variable
    assert listify_lookup_plugin_terms('{{ foo }}', None, None, convert_bare=True) == ['{{ foo }}']

    # Test with a list of items with a bare variable
    assert listify_lookup_plugin_terms(['{{ foo }}', 'bar'], None, None, convert_bare=True) == ['{{ foo }}', 'bar']

# Generated at 2022-06-21 08:48:30.077495
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    s = AnsibleUnicode("{{a}}")
    t = listify_lookup_plugin_terms(s, Templar({}), None)
    assert t == [s]
    t = listify_lookup_plugin_terms([s], Templar({}), None)
    assert t == [s]

# Generated at 2022-06-21 08:48:40.883509
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    my_vars = dict(my_var='foobar')
    my_loader = None

    templar = Templar(loader=my_loader, variables=my_vars)


# Generated at 2022-06-21 08:48:54.886002
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # generate a templar with things we need
    vars = ImmutableDict(dict(
        b='blue',
        c='cyan',
        d='dark',
        n='nested',
        # make sure deeply nested dicts and lists work too
        deep=[
            [
                [
                    dict(a='aaa', b='bbb', c='ccc')
                ]
            ]
        ]
    ))
    templar = Templar(loader=loader, variables=vars)

    # basic case
    terms

# Generated at 2022-06-21 08:49:02.636336
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    vault_pass = 'passw0rd'
    variable_manager = 'variable_manager'
    loader = DataLoader()
    variable_manager = 'variable_manager'

    templar = Templar(loader=loader, variables=variable_manager)
    terms = listify_lookup_plugin_terms('hello', templar, loader)
    assert terms == ['hello']

    terms = listify_lookup_plugin_terms(['hello', 'world'], templar, loader)
    assert terms == ['hello', 'world']


# Generated at 2022-06-21 08:49:14.956734
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    from io import StringIO

    # Test single string
    b_vars = dict(a='a')
    b_loader = DummyLoader()
    b_vault_secrets = {}
    b_templar = Templar(loader=b_loader, variables=b_vars, vault_secrets=b_vault_secrets)

    assert listify_lookup_plugin_terms('foo', b_templar, b_loader) == ['foo']

    # Test single variable value
    c_vars = dict(a='a')
    c_loader = DummyLoader()
    c_vault_secrets = {}

# Generated at 2022-06-21 08:49:24.102565
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class DummyVars(object):
        def __init__(self):
            self.ansible_facts = dict()
            self.vars = dict(foo='foo', bar='bar', baz='baz', bof='bof')
        def get_vars(self):
            return self.vars

    class DummyVarsOne(object):
        def __init__(self):
            self.ansible_facts = dict()
            self.vars = dict(foo='foo', bar='bar', baz='baz', bof='bof',
                             dict_var={'a': 'b', 'c': 'd'})
        def get_vars(self):
            return self.vars


# Generated at 2022-06-21 08:49:33.921672
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # test valid input types
    t = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms('1', t, None) == ['1']
    assert listify_lookup_plugin_terms([1, 2], t, None) == [1, 2]

    # test invalid input types
    try:
        listify_lookup_plugin_terms(1, t, None)
        assert False
    except Exception as e:
        assert isinstance(e, TypeError)
        assert str(e) == "listify_lookup_plugin_terms expects a list or string"

    # test templating

# Generated at 2022-06-21 08:49:44.290053
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved
    from ansible.vars.manager import VariableManager

    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template.safe_eval import SafeEval

    templar = Templar(loader=None, variables=dict(foo='bar'))
    #          terms, templar, loader, fail_on_undefined=True, convert_bare=False

# Generated at 2022-06-21 08:49:54.624598
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.yaml import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(a=1, b=2, c=3, d=4))

    # Test 1: Bare string
    terms = '{{ c }}'
    expected = ['3']
    actual = listify_lookup_plugin_terms(terms, Templar(variable_manager, loader), loader)
    assert actual == expected

    # Test 2: List
    terms = ['{{ a }}', '=', '{{ b }}']
    expected = ['1', '=', '2']

# Generated at 2022-06-21 08:50:05.446651
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms(
        terms='{{ foo }}', templar=templar, loader=None, fail_on_undefined=True, convert_bare=False
    ) == '{{ foo }}'


    assert listify_lookup_plugin_terms(
        terms='bar', templar=templar, loader=None, fail_on_undefined=True, convert_bare=False
    ) == ['bar']

    assert listify_lookup_plugin_terms(
        terms=['foo', '{{ bar }}'], templar=templar, loader=None, fail_on_undefined=True, convert_bare=False
    ) == ['foo', '{{ bar }}']

# Generated at 2022-06-21 08:50:15.281179
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert(listify_lookup_plugin_terms(10, Templar(loader=None, variables={})) == [10])
    assert(listify_lookup_plugin_terms('10', Templar(loader=None, variables={})) == ['10'])
    assert(listify_lookup_plugin_terms(None, Templar(loader=None, variables={})) == [])
    assert(listify_lookup_plugin_terms([10], Templar(loader=None, variables={})) == [10])
    assert(listify_lookup_plugin_terms([10, 11], Templar(loader=None, variables={})) == [10, 11])

# Generated at 2022-06-21 08:50:22.895730
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import lookup_loader, callback_loader

    # vault_pass = 'secret'
    # loader = DataLoader()
    # inventory = InventoryManager(loader=loader, sources=['localhost,'])
    # variable_manager = VariableManager(loader=loader, inventory=inventory)
    # variable_manager.extra_vars = {'my_var': 'my_value'}
    # playbook = Playbook

# Generated at 2022-06-21 08:50:35.033382
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=dict(foo=42, foo_list=[1, 2, 3]))

    assert listify_lookup_plugin_terms([], templar, loader) == []
    assert listify_lookup_plugin_terms('', templar, loader) == ['']
    assert listify_lookup_plugin_terms('{foo}', templar, loader) == [42]

# Generated at 2022-06-21 08:50:46.837837
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible import errors

    templar = Templar(loader=None, variables={})

    # Test with a single term
    assert listify_lookup_plugin_terms('1', templar, None) == ['1']
    assert listify_lookup_plugin_terms('1.1', templar, None) == ['1.1']
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # Test with a list of terms
    assert listify_lookup_plugin_terms(['1', '2', '3', '4'], templar, None) == ['1', '2', '3', '4']

    # Test an auto type conversion

# Generated at 2022-06-21 08:50:52.942785
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('1 2 3', None, None) == ['1', '2', '3']
    assert listify_lookup_plugin_terms('1 2 3', None, None, fail_on_undefined=False) == ['1', '2', '3']
    assert listify_lookup_plugin_terms([1, 2, 3], None, None, fail_on_undefined=False) == [1, 2, 3]
    assert listify_lookup_plugin_terms(1, None, None, fail_on_undefined=False) == [1]

# Generated at 2022-06-21 08:51:03.780984
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Use json as template language to allow quoting of strings
    class TestTemplar(object):
        TEMPLATE_REGEX = None
        def __init__(self, loader):
            pass
        def template(self, expression, convert_bare=False, fail_on_undefined=True):
            if not isinstance(expression, list):
                expression = [expression]
            return ['%s' % x for x in expression]

    from ansible.module_utils.common._collections_compat import SimpleLoader
    templar = TestTemplar(SimpleLoader(base_dict={}))

    terms = listify_lookup_plugin_terms('foo', templar, templar._loader)
    assert terms == ['foo']


# Generated at 2022-06-21 08:51:16.274377
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Load class and generate template instance
    from ansible.template import Templar
    t = Templar(None,
                loader=None,
                shared_loader_obj=None)

    # Test with a string
    result = listify_lookup_plugin_terms("mystring", templar=t, loader=None)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == "mystring"

    # Test with a list
    result = listify_lookup_plugin_terms(["mystring"], templar=t, loader=None)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == "mystring"

    # Test with a dict

# Generated at 2022-06-21 08:51:28.246411
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    foo:
      bar:
        - 1
        - 3
        - 5
        - 8
    """

    loader = AnsibleLoader(data, '<string>')
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('{{foo.bar}}', templar=templar, loader=loader) == [1, 3, 5, 8]
    assert listify_lookup_plugin_terms('{{foo.baz}}', templar=templar, loader=loader) == [None]

# Generated at 2022-06-21 08:51:35.040264
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms('hello', templar, None) == ['hello']
    assert listify_lookup_plugin_terms(['hello'], templar, None) == ['hello']
    assert listify_lookup_plugin_terms(['hello', 'world'], templar, None) == ['hello', 'world']
    assert listify_lookup_plugin_terms(('hello', 'world'), templar, None) == ['hello', 'world']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None, fail_on_undefined=False) == ['{{ foo }}']

# Generated at 2022-06-21 08:51:46.106777
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # In general, we need to test:
    #   that terms which are scalar, or which are lists or tuples are
    #     correctly passed through (no change
    #   that string terms which are comma-separated lists are correctly
    #     split into lists
    #   that string terms which have embedded commas are correctly
    #     escaped
    #   that string terms which are JSON-encoded lists are correctly
    #     parsed
    from ansible.template.templar import Templar

    def test_template(template, expect_list=True, **kwargs):
        terms = template
        templar = Templar(None, loader=None)

        terms = listify_lookup_plugin_terms(terms, templar, None, **kwargs)
        assert isinstance(terms, list), "terms: %s, expected %s"

# Generated at 2022-06-21 08:51:50.091489
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
   from ansible.template import Templar
   from ansible.parsing.dataloader import DataLoader

   terms = listify_lookup_plugin_terms('{{foo}}', Templar(DataLoader()), DataLoader(), fail_on_undefined=False, convert_bare=True)
   assert(terms == [u'{{foo}}'])

   terms = listify_lookup_plugin_terms(['{{foo}}'], Templar(DataLoader()), DataLoader(), fail_on_undefined=False, convert_bare=True)
   assert(terms == [u'{{foo}}'])

   terms = listify_lookup_plugin_terms(['{{foo}}', '{{bar}}'], Templar(DataLoader()), DataLoader(), fail_on_undefined=False, convert_bare=True)

# Generated at 2022-06-21 08:52:00.140327
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager(loader=None, inventories=None))

    # simple tests
    assert listify_lookup_plugin_terms([1, 2, 3], templar, None) == [1, 2, 3]
    assert listify_lookup_plugin_terms(1, templar, None) == [1]
    assert listify_lookup_plugin_terms([], templar, None) == []

    # test iteration
    assert listify_lookup_plugin_terms(range(3), templar, None) == [0, 1, 2]
    assert listify_lookup_

# Generated at 2022-06-21 08:52:14.570473
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = DummyLoader()
    templar = Templar(loader=loader)


# Generated at 2022-06-21 08:52:25.787953
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.compat.six as six
    from ansible.templating import Templar

    # The jinja2 env is tsuonly so it can't load any plugins
    # but we don't need that anyway.
    from ansible.template import TemplarEnvironment

    templar = Templar(TemplarEnvironment())

    # Template a string
    terms = listify_lookup_plugin_terms("{{ var }}", templar, loader, fail_on_undefined=True, convert_bare=True)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert terms[0] == "{{ var }}"

    # Template a list
    terms = listify_lookup_plugin_terms(["{{ var }}"], templar, loader, fail_on_undefined=True, convert_bare=True)

# Generated at 2022-06-21 08:52:37.419895
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test for string_types - string and unicode
    # Test for list - list and tuple
    # Test for bare words - and, or, not
    from ansible.module_utils.basic import AnsibleModule
    from ansible.templating import Templar
    from ansible.parsing.vault import VaultLib
    from ansible import context, errors
    from ansible.plugins.lookup import LookupBase


    class TestLookupModule(LookupBase):

        import_module = staticmethod(__import__)


# Generated at 2022-06-21 08:52:46.951656
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('hello', templar, loader) == ['hello']
    assert listify_lookup_plugin_terms(['hello', 'world'], templar, loader) == ['hello', 'world']
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], templar, loader, convert_bare=True) == ['{{ foo }}', '{{ bar }}']

# Generated at 2022-06-21 08:52:58.554642
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import jinja2

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible import context
    from ansible.module_utils.common._collections_compat import OrderedDict

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = dict(
        basedir='./',
        no_log=True,
        verbosity=10,
        check_mode=False,
        diff=False,
    )
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 08:53:07.995220
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    def test_assert(terms, result, msg):
        value = listify_lookup_plugin_terms(terms, templar, loader)
        if value != result:
            raise AssertionError("{0} != {1}: {2}".format(value, result, msg))

    class DummyVarsModule:
        def __init__(self):
            self.VarsModule = DummyVarsModule.DummyVarsClass()

        def get_vars(self, loader, path, entities, cache=True):
            return {'a': 'A', 'b': 'B'}

        class DummyVarsClass:
            def __init__(self):
                self.basedir = 'basedir'
                self.roles = 'roles'


# Generated at 2022-06-21 08:53:18.706888
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    import ansible.parsing.yaml.objects

    env = dict(
        ansible_user_vars=dict(),
        ansible_host_vars=dict(),
        ansible_group_vars=dict(),
        ansible_inventory_hostname='localhost'
    )
    templar = Templar(loader=None, variables=env)

    # test string
    assert listify_lookup_plugin_terms('str1', templar, None) == ['str1']

    # test unicode
    assert listify_lookup_plugin_terms(u'str2', templar, None) == [u'str2']

    # test list
    assert listify_lookup_plugin_terms(['str3a', 'str3b'], templar, None)

# Generated at 2022-06-21 08:53:27.514689
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    import pytest

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    inventory.set_variable_manager(VariableManager())
    templar = Templar(loader=loader, variables=inventory.get_vars())

    orig = '{{ foo }}'
    exp = ['bar']
    result = listify_lookup_plugin_terms(orig, templar, loader, fail_on_undefined=False)
    assert result == exp

    orig = ['{{ foo }}']
    exp = ['bar']

# Generated at 2022-06-21 08:53:39.609096
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import lookup_loader

    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    templar = Templar(loader=DataLoader(), variables=variable_manager)

    lookup_loader.set_inventory(inventory)

    terms = '{{ ansible_play_hosts_all }}'

    # test handling multiple hosts
    inventory.clear_pattern_cache()
    inventory.add_host(host='foo')
    inventory.add_host(host='bar')
   

# Generated at 2022-06-21 08:53:50.425683
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    t = Templar(None, loader=None)

    # string
    s = 'foo'
    e = listify_lookup_plugin_terms(s, t, None, fail_on_undefined=True, convert_bare=False)
    assert isinstance(e, list)
    assert len(e) == 1
    assert e[0] == 'foo'

    # quoted string
    s = '"foo"'
    e = listify_lookup_plugin_terms(s, t, None, fail_on_undefined=True, convert_bare=False)
    assert isinstance(e, list)
    assert len(e) == 1
    assert e[0] == 'foo'

    # list

# Generated at 2022-06-21 08:54:12.296783
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys
    from ansible.utils.template import Templar
    from ansible.parsing.dataloader import DataLoader

    class Options(object):
        def __init__(self, variables=None):
            self.connection = 'local'
            self.module_name = 'template'
            self.forks = 1
            self.become = False
            self.become_method = None
            self.become_user = None
            self.remote_user = 'test_user'
            self.private_key_file = None
            self.async_timeout = 30
            self.verbosity = 0
            self.check = False
            self.diff = False
            self.inventory = None
            self.subset = None
            self.extra_vars = variables or []
            self.tags = ['all']

# Generated at 2022-06-21 08:54:12.934427
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-21 08:54:24.048881
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.parsing.yaml.objects

    terms1 = 'foo'
    terms2 = [ 'foo', 'bar', 'baz' ]
    terms3 = ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode.from_plaintext('foo')

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    t = Templar(loader=None, variable_manager=VariableManager())

    test1 = listify_lookup_plugin_terms(terms1, t, None)
    print(test1)
    test2 = listify_lookup_plugin_terms(terms2, t, None)
    print(test2)
    test3 = listify_lookup_plugin_terms(terms3, t, None)
    print(test3)

# Generated at 2022-06-21 08:54:30.709902
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    terms = """
    foo
    bar
    """
    assert listify_lookup_plugin_terms(terms, templar) == ['foo', 'bar']

    assert listify_lookup_plugin_terms('foo', templar) == ['foo']

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar) == ['foo', 'bar']

    assert listify_lookup_plugin_terms(5, templar) == [5]

# Generated at 2022-06-21 08:54:41.121120
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms(AnsibleUnicode("1"), templar, loader=None) == ['1']
    assert listify_lookup_plugin_terms("1", templar, loader=None) == ['1']
    assert listify_lookup_plugin_terms([1], templar, loader=None) == [1]
    assert listify_lookup_plugin_terms(['1', '2'], templar, loader=None) == ['1', '2']
    assert listify_lookup_plugin_terms(1, templar, loader=None) == [1]

# Generated at 2022-06-21 08:54:51.340251
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import sys

    # Make sure our imports worked
    assert Templar
    assert VariableManager
    assert DataLoader
    assert os.path.exists
    assert sys.version_info

    templar = Templar(loader=DataLoader(), variables=VariableManager(), shared_loader_obj=None)

    assert isinstance(listify_lookup_plugin_terms('foo', templar, None), list)
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']
    assert listify_lookup_plugin

# Generated at 2022-06-21 08:54:58.660147
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import template
    from ansible.utils.unsafe_proxy import wrap_var

    fake_loader = None
    fake_vars = {'var': 'test'}
    templar = template.AnsibleTemplar(loader=fake_loader, variables=fake_vars)

    # Test string without vars
    terms = "some string"
    result = listify_lookup_plugin_terms(terms, templar, fake_loader)
    assert result == ['some string']

    # Test string with vars
    terms = "{{ var }}"
    result = listify_lookup_plugin_terms(terms, templar, fake_loader)
    assert result == ['test']

    # Test list of strings without vars
    terms = ['some string', ['another', 'string']]

# Generated at 2022-06-21 08:55:07.254891
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # A few imports needed for the test_listify_lookup_plugin_terms
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager, add_builtin_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    add_builtin_vars(variable_manager)
    templar = Templar(loader=loader, variables=variable_manager)

    # Using the templar object above we'll test the function in question
    assert listify_lookup_plugin_terms([1, 2, 3], templar, loader) == [1, 2, 3]

# Generated at 2022-06-21 08:55:17.067614
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Mock AnsibleModule
    module = MockAnsibleModule()
    templar = module.ansible_template

    # Mock a string
    s = 'a string'
    result = listify_lookup_plugin_terms(s, templar)
    assert result == ['a string']

    # Mock a list of strings
    l = ['string1', 'string2']
    result = listify_lookup_plugin_terms(l, templar)
    assert result == ['string1', 'string2']

    # Mock a list of mixed string and list
    l = ['string1', ['string2', 'string3']]
    result = listify_lookup_plugin_terms(l, templar)
    assert result == ['string1', ['string2', 'string3']]

    # Mock a string template
   

# Generated at 2022-06-21 08:55:28.184985
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    my_vars = dict(
        foo='bar',
        list_one=[1,2,3],
        list_two=[4,5,6],
    )
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = my_vars
    templar = Templar(loader=loader, variables=variable_manager)
