

# Generated at 2022-06-21 08:45:37.896499
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import _UNSET

    from ansible.module_utils.facts import cached_facts_finder
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader

    class FakeVarsModule(object):

        def __init__(self, var):
            self.var = var

        def run(self, terms, inject=None, **kwargs):
            return terms

    terms = "{{ lookup('vars', 'test') }}"
    templar = Templar(loader=DataLoader(), variables=dict(test='var'))
    templar.environment.loader.set_basedir('/')

    # simple
    assert listify_lookup_plugin_terms(terms, templar) == ["var"]

    # list


# Generated at 2022-06-21 08:45:45.841027
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # function to mock the template class
    def template_function(arg,  **kwargs):
        if isinstance(arg, string_types):
            from ansible.template import Templar
            templar = Templar(loader=None)
            return templar.template(arg, **kwargs)
        else:
            return arg

    # function to mock the template class
    def template_generator(arg,  **kwargs):
        if isinstance(arg, string_types):
            from ansible.template import Templar
            templar = Templar(loader=None)
            return templar.template(arg, **kwargs)
        else:
            return arg

    def mock_loader(arg, **kwargs):
        return arg

    def template(arg, **kwargs):
        return arg


# Generated at 2022-06-21 08:45:55.086125
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import safe_eval
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    data = dict(a=dict(b=dict(c=[1,2,3])))
    templar = Templar(loader=None, variables=data)

    # test ansible_unicode
    result = listify_lookup_plugin_terms(AnsibleUnicode('a.b.c'), templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert result == [[1, 2, 3]]

    # test string

# Generated at 2022-06-21 08:46:03.808735
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.template import Templar

    class MyVarsModule(object):
        def __init__(self, basedir=None, **kwargs):
            self.basedir = basedir
            self.data = None
            self.vars = dict(
                list=dict(
                    bare=['one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen']
                )
            )
        def get_basedir(self):
            return self.basedir

# Generated at 2022-06-21 08:46:15.159672
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar

    from ansible.module_utils.common._collections_compat import ConanFileReference

    # Terms is a string, templar should return a list of one string.
    terms = 'string1'
    templar = Templar(loader=None, variables={})
    terms_list = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert len(terms_list) == 1
    assert isinstance(terms_list[0], string_types)
    assert terms_list[0] == 'string1'

    # Terms is a list, templar should return the same list.
    terms = [ 'string2' ]
    templar = Templar(loader=None, variables={})

# Generated at 2022-06-21 08:46:23.012504
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from units.mock.path import mock_unfrackpath_noop

    def _unsafe_proxy(text):
        return AnsibleUnsafeText(text)

    text = '{{path}}'
    assert isinstance(listify_lookup_plugin_terms(text, Templar(loader=DictDataLoader()), _unsafe_proxy, None), list)
    assert listify_lookup_plugin_terms(text, Templar(loader=DictDataLoader()), _unsafe_proxy, None) == [text]
    text = '{{ path }}'
   

# Generated at 2022-06-21 08:46:32.831893
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']
    assert listify_lookup_plugin_terms('["foo","bar"]', None, None) == ['foo','bar']
    assert listify_lookup_plugin_terms(['foo','bar'], None, None) == ['foo','bar']
    assert listify_lookup_plugin_terms(['foo','{{bar}}'], None, None) == ['foo','{{bar}}']
    assert listify_lookup_plugin_terms(['foo','{{bar}}'], None, None) == ['foo','{{bar}}']
    assert listify_lookup_plugin_terms('["{{foo}}","{{bar}}"]', None, None) == ['{{foo}}','{{bar}}']

# Generated at 2022-06-21 08:46:45.099978
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    loader.get_all_plugin_loaders()

    failing_terms = [
        '{{ foo }}',
        {'foo': '{{ foo }}'},
        ['{{ foo }}', '{{ bar }}'],
        ['foo', '{{ bar }}', '{{ baz }}']
    ]
    non_failing_terms = [
        'foo',
        {},
        [],
        [123],
        [False],
        [True],
        ['foo'],
        ['f o o'],
        {'foo': True},
    ]


# Generated at 2022-06-21 08:46:52.166972
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('{{ foo }}', FakeTemplar(), FakeLoader()) == ['foo']
    assert listify_lookup_plugin_terms('foo', FakeTemplar(), FakeLoader()) == ['foo']
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], FakeTemplar(), FakeLoader()) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], FakeTemplar(), FakeLoader()) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], FakeTemplar(), FakeLoader()) == ['foo', 'bar']

# Generated at 2022-06-21 08:46:59.240838
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableSequence

    class DummyVarsModule(object):
        def __init__(self, var_foo=11, var_bar=22, var_baz=33):
            self.var_foo = var_foo
            self.var_bar = var_bar
            self.var_baz = var_baz

    assert listify_lookup_plugin_terms("var_foo", DummyVarsModule(), None) == ["var_foo"]
    assert listify_lookup_plugin_terms("var_foo, var_bar, var_baz", DummyVarsModule(), None) == ["var_foo", "var_bar", "var_baz"]

# Generated at 2022-06-21 08:47:12.527743
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Note: We don't actually assert anything here, because all we care about
    # is that listify_lookup_plugin_terms() doesn't crash when passed the input
    # below.  It's the unit tests for the modules that listify that input that
    # assert specific results.
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    mytemplar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-21 08:47:21.143132
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, vault_password_file=None)

    templar = Templar(loader=loader, variables={})

    # string -> array
    terms = listify_lookup_plugin_terms('foo', templar, loader)
    assert terms == ['foo']

    # unicode -> array
    terms = listify_lookup_plugin_terms(u'foo', templar, loader)
    assert terms == [u'foo']

    # list -> array
    terms = listify_lookup_plugin_terms(['foo'], templar, loader)
    assert terms == ['foo']

    # single item array -> array
   

# Generated at 2022-06-21 08:47:31.001123
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    vault_password = 'secret'
    vault = VaultLib([vault_password])

    loader = DictDataLoader(dict())
    va = VariableManager()
    va.extra_vars = {'vault_password': vault_password}
    ih = InventoryManager(loader=loader)
    ih.add_group('test')
    ih.add_host(Host(name='localhost', groups=ih.groups))


# Generated at 2022-06-21 08:47:42.532658
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.template import Templar
    from ansible.template import vault
    from ansible.parsing.vault import VaultLib

    v = VaultLib(password_file='ansible/test/utils/vault/testvault.txt')
    t = Templar(loader=None, variables=dict(a=1, b=2), shared_loader_obj=None, vault_secrets=v)

    # Test string conversion
    inp = '{{ a }}'
    out = listify_lookup_plugin_terms(inp, t, False)
    assert out == ['1'], 'Expected ["1"] but got %s' % out

    # Test list conversion
    inp = ['{{ a }}', '{{ b }}']
    out = listify_lookup_plugin_terms(inp, t, False)

# Generated at 2022-06-21 08:47:54.385328
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import sys
    import os

    # FIXME: try to remove this, but for the moment these are needed
    # for the template.  This needs to be reworked to use the vars
    # from the lookup plugin's templar object.
    loader, basedir, vault_password = VaultLib().setup_loader(None)
    templar = Templar(loader=loader, variables={})

    # test a simple string
    foo = 'foo'
    result = listify_lookup_plugin_terms(foo, templar, loader)
    assert result == ['foo']

    # test a simple list
    foo = ['foo']


# Generated at 2022-06-21 08:48:06.334071
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml import DataLoader
    from ansible.template import Templar

    vault_secret = b'vault_password'
    vault_password_file = BytesIO(vault_secret)
    loader = DataLoader()
    vault = VaultLib(password_files=[vault_password_file])

    template = 'test'
    value = to_bytes(template)
    templar = Templar(loader=loader, variables={})
    result = listify_lookup_plugin_terms(value, templar, loader)
    assert result == [template]

    template = [template]
    value = to_bytes

# Generated at 2022-06-21 08:48:14.440634
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    data = 'a\nb\nc'
    # TODO: Fail on undefined should not be hardcoded here.
    result = listify_lookup_plugin_terms(data, Templar(loader=DataLoader(), variable_manager=VariableManager()), DataLoader(), True)
    assert result == ['a', 'b', 'c']

    data = '{{a}} {{b}} {{c}}'
    a = 'a'
    b = 'b'
    c = 'c'
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(a=a, b=b, c=c))
    # TODO: Fail on undefined should not be hard

# Generated at 2022-06-21 08:48:23.475905
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from collections import namedtuple
    import ansible.module_utils.template as template

    DummyVar = namedtuple('DummyVar', ('value',))
    class DummyVarsModule:
        def __init__(self):
            self.dummy_vars = {
                'var1': 'foo',
                'var2': 'bar',
            }
        def __getitem__(self, k):
            return DummyVar(self.dummy_vars[k])

    class DummyLoader:
        def __init__(self, vars_module):
            self.vars_module = vars_module

    class DummyPlayContext:
        pass

    templar = template.Template(loader=DummyLoader(vars_module=DummyVarsModule()), play_context=DummyPlayContext())

# Generated at 2022-06-21 08:48:33.396898
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.template import Jinja2TemplateModule
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template.safe_eval import safe_eval
    import ansible.constants as C
    from ansible.utils.vars import combine_vars

    class TestTemplar(Templar):

        def __init__(self, loader, variables=None):
            self._available_variables = variables
            super(TestTemplar, self).__init__(loader)

        def set_available_variables(self, variables):
            self._available_variables = variables


# Generated at 2022-06-21 08:48:43.067384
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import merge_hash

    fake_loader = DictDataLoader({})
    var_manager = VariableManager()
    var_manager.extra_vars = merge_hash({}, vault_password='secret')
    var_manager.options_vars = merge_hash({}, vault_password='secret')
    vault = VaultLib(['secret'])

    templar = Templar(loader=fake_loader, variables=var_manager, vault_secrets=[vault])

# Generated at 2022-06-21 08:48:54.538908
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = listify_lookup_plugin_terms('1 2 3', templar=None, loader=None)
    assert isinstance(terms, list)
    assert terms == ['1', '2', '3']

    terms = listify_lookup_plugin_terms(['1', '2', '3'], templar=None, loader=None)
    assert isinstance(terms, list)
    assert terms == ['1', '2', '3']

# Generated at 2022-06-21 08:49:02.406261
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager

    terms = "{{test_var}}"

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 'TestValue'}

    vault_secrets = dict()

    class BasicModule(object):
        def __init__(self):
            self.params = dict()
            self.params['_ansible_vault'] = None
            self.params['_ansible_no_log'] = False
            self.params['_ansible_debug'] = False
            self.params['_ansible_check_mode'] = False


# Generated at 2022-06-21 08:49:14.706860
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class TestTemplar(object):
        def template(self, terms, convert_bare=False, fail_on_undefined=True):
            if not isinstance(terms, string_types):
                return terms
            elif terms.startswith(">>>"):
                raise Exception("string expansion error")
            elif terms == "{{ a }}" and not fail_on_undefined:
                return ""
            elif terms == "{{ a }}" and fail_on_undefined:
                raise Exception("string expansion error")
            elif terms == "{{ b }}":
                return "b"
            return terms.replace("{{","").replace("}}","")

    templar = TestTemplar()
    result = listify_lookup_plugin_terms("{{ a }}", templar, None)

# Generated at 2022-06-21 08:49:23.953214
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # loaders and variable manager aren't actually used, so we can leave them empty
    loader = DataLoader()
    variable_manager = None

    # create a template class to use for template processing, then test with multiple inputs
    templar = Templar(loader=loader, variable_manager=variable_manager)

    # test with a string input
    assert listify_lookup_plugin_terms('1', templar, loader, convert_bare=True) == ['1']
    assert listify_lookup_plugin_terms('1,2,3', templar, loader, convert_bare=True) == ['1', '2', '3']

# Generated at 2022-06-21 08:49:33.857928
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    my_vars = dict(
        cust1='foo',
        cust2='bar',
        cust3=['cust1', 'cust2'],
        cust4=['cust3', 'baz'],
    )
    var_manager = VariableManager()
    var_manager.set_inventory(my_vars)
    templar = Templar(loader=None, variables=var_manager)

    assert(listify_lookup_plugin_terms('{{cust1}}', templar) == ['foo'])
    assert(listify_lookup_plugin_terms('{{ cust1 }}', templar) == ['foo'])

# Generated at 2022-06-21 08:49:44.254498
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import errors
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from units.mock.vars import mock_variable_manager

    loader = DataLoader()
    variable_manager = mock_variable_manager()

    templar_args = dict(loader=loader, variable_manager=variable_manager)

    lookup_term = "{{ foo }}"
    templar = Templar(**templar_args)

    variable_manager.set_variable("foo", "bar")
    variable_manager.set_variable("baz", "foobarbaz")

    # Test empty variable
    variable_manager.set_variable("empty", None)

# Generated at 2022-06-21 08:49:54.579899
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    t = Templar(VariableManager())
    assert listify_lookup_plugin_terms("{{ foo }}", t, AnsibleLoader()) == ['{{ foo }}']
    assert listify_lookup_plugin_terms(["{{ foo }}", "{{ bar }}"], t, AnsibleLoader()) == ['{{ foo }}', '{{ bar }}']
    assert listify_lookup_plugin_terms(True, t, AnsibleLoader()) == [True]
    assert listify_lookup_plugin_terms(123, t, AnsibleLoader()) == [123]

# Generated at 2022-06-21 08:50:05.342982
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms(None, templar, None) == []
    assert listify_lookup_plugin_terms(dict(), templar, None) == []
    assert listify_lookup_plugin_terms([], templar, None) == []
    assert listify_lookup_plugin_terms([1], templar, None) == [1]
    assert listify_lookup_plugin_terms(['1'], templar, None) == ['1']
    assert listify_lookup_plugin_terms([1.0], templar, None) == [1.0]

# Generated at 2022-06-21 08:50:12.992109
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager)
    variable_manager._extra_vars = dict(baz=['foo', 'bar'])

    assert listify_lookup_plugin_terms('{{ baz }}', templar, loader=None, convert_bare=True) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(dict(key='{{ baz }}'), templar, loader=None, convert_bare=True) == dict(key=['foo', 'bar'])
    assert listify_lookup_plugin_terms(('{{ baz }}',), templar, loader=None, convert_bare=True) == ['foo', 'bar']

# Generated at 2022-06-21 08:50:21.743948
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    fake_loader = None
    fake_vars = {}
    t = Templar(loader=fake_loader, variables=fake_vars)

    # tests to confirm the function always returns a list
    assert listify_lookup_plugin_terms('simple string', templar=t, loader=fake_loader) == ['simple string']
    assert listify_lookup_plugin_terms(['a single item'], templar=t, loader=fake_loader) == ['a single item']
    assert listify_lookup_plugin_terms([1, 2, 3], templar=t, loader=fake_loader) == [1, 2, 3]

    # tests to confirm the function returns a list with non-string items up front.

# Generated at 2022-06-21 08:50:40.367011
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=AnsibleLoader(None))
    result = listify_lookup_plugin_terms(["foo", "bar"], templar, None)
    assert isinstance(result, list)
    assert len(result) == 2
    assert result == ["foo", "bar"]

    result = listify_lookup_plugin_terms("foo", templar, None)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result == ["foo"]

    result = listify_lookup_plugin_terms(["{{ foo }}"], templar, None)

# Generated at 2022-06-21 08:50:50.117136
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.parsing.yaml.loader

    templar = ansible.playbook.play_context.PlayContext()

    # characters
    assert(listify_lookup_plugin_terms('some', templar, None) == ['some'])

    # unicode characters
    assert(listify_lookup_plugin_terms(u'some', templar, None) == ['some'])

    # list
    assert(listify_lookup_plugin_terms(['some', 'thing'], templar, None) == ['some', 'thing'])

    # string
    assert(listify_lookup_plugin_terms('some,thing', templar, None) == ['some,thing'])

    # unicode string

# Generated at 2022-06-21 08:50:57.414925
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible import constants as C
    C.DEFAULT_HASH_BEHAVIOUR = "merge"
    templar = Templar(loader=None, variables={
        'bar': 'baz',
        'foo': ['test1', 'test2', 'test3'],
    })

    # -- test string input
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader=None) == ['test1', 'test2', 'test3']
    assert listify_lookup_plugin_terms('{{ foo | list }}', templar, loader=None) == ['test1', 'test2', 'test3']

# Generated at 2022-06-21 08:51:06.085064
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from jinja2 import Template
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test a simple string
    test_string = 'string'
    res = listify_lookup_plugin_terms(test_string, templar, loader)
    assert(res == ['string'])

    # test a simple jinja2 string
    test_string = "{{ 'string' }}"
    res = listify_lookup_plugin_terms(test_string, templar, loader)
    assert(res == ['string'])

    # test a jinja2 string with whites

# Generated at 2022-06-21 08:51:16.816773
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    # Make sure we take lists and don't break them
    assert listify_lookup_plugin_terms(['foo', 'bar'], Templar({}), None) == ['foo', 'bar']

    # Make sure we take a string and convert it to a list
    assert listify_lookup_plugin_terms('foo', Templar({}), None) == ['foo']

    # Make sure we take integers and convert them to strings
    assert listify_lookup_plugin_terms(5, Templar({}), None) == ['5']

    # Make sure we take an encrypted value and pass it through

# Generated at 2022-06-21 08:51:28.772138
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars

    vault_pass = VaultLib([])
    vault_pass.read_vault_password_file()
    vars_manager = combine_vars(loader=None, variables=dict(foo='bar'))
    vars_manager.extra_vars = dict(foo='bar')
    vars_manager.options_vars = dict(foo='bar')

# Generated at 2022-06-21 08:51:39.228861
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.utils.yaml import from_yaml
    from ansible.template import Templar

    def run_listify(v1):

        v2 = listify_lookup_plugin_terms(v1, templar, loader)

        assert v1 == v2, "%s != %s" % (type(v1), type(v2))

    loader = DummyVars()
    templar = Templar(loader=loader)

    for t in (1, '1', 'Number one', [1, 2, 3], ['Number one', 'Number two', 'Number three']):
        yield run_listify, t



# Generated at 2022-06-21 08:51:50.899338
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory import Inventory
    import ansible.constants as C
    import os

    # some tests require a temporary directory to write files to
    tmpdir = C.DEFAULT_LOCAL_TMP

    class FakePlayContext:
        def __init__(self, tmpdir):
            self.basedir = tmpdir

    # need to create a loader that will read the test vars file
    test_loader = DataLoader()
    # test_loader._vault_password = 'secret'

    basedir = os.path.dirname(os.path.dirname(__file__))

# Generated at 2022-06-21 08:52:00.715176
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    import unittest

    class TestModule(unittest.TestCase):

        def setUp(self):
            self.variable_manager = VariableManager()
            self.loader = self.variable_manager.loader
            self.inventory = InventoryManager(loader=self.loader, sources=['localhost,'])
            self.variable_manager.set_inventory(self.inventory)

        def tearDown(self):
            self.variable_manager.extra_vars = {}


# Generated at 2022-06-21 08:52:11.370649
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class TestVarsModule:
        def __init__(self, k=None, v=None):
            self.facts = dict()
            if k and v:
                self.facts[k] = v

        def get_vars(self, loader, path, entities):
            return self.facts

    # Check the function with basic types
    templar = Templar(loader=None, variables={})
    terms = listify_lookup_plugin_terms(['one', 2, [3], {'four': 4}], templar, loader=None)
    assert isinstance(terms, list)
    assert terms == ['one', 2, [3], {'four': 4}]

    # Check the function with a templateable string

# Generated at 2022-06-21 08:52:36.258521
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars
    from ansible.vars.manager import VariableManager

    # test with a string
    terms = "localhost"
    templar = Templar(
        loader=None,
        shared_loader_obj=None,
        variables=VariableManager(loader=None, inventory=None),
    )
    templar._available_variables = AnsibleVars(loader=None, variables={}, include_cache={})
    templar._fail_on_undefined = True
    listified = listify_lookup_plugin_terms(terms, templar, None)
    assert listified == [to_bytes(terms)]
    listified = listify_lookup

# Generated at 2022-06-21 08:52:46.903257
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    terms=[
        '{{ [1] }}',
        1,
        ['a'],
        ['{{ hostvars["localhost"].ansible_hostname }}'],
        '{{ "localhost" if ansible_hostname == "localhost" else "" }}',
        'localhost'
    ]

    templar = Templar(loader=DataLoader(), variables={'ansible_hostname': 'localhost'})
    result = listify_lookup_plugin_terms(terms, templar, templar._loader)

    assert result == [
        1,
        1,
        ['a'],
        ['localhost'],
        'localhost',
        'localhost'
    ], result

# Generated at 2022-06-21 08:52:58.552857
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    class TestVarsModule(object):
        def __init__(self):
            self.vars = dict()
        def vars_from_file(self, path):
            if path == 'foo':
                return dict(bar='baz')
        def get_vars(self, play, host, task, include_hostvars=True, include_delegate_to=True):
            return dict(foo='bar')
    templar = Templar(loader=None, variables=TestVarsModule())
    assert listify_lookup_plugin_terms('foo.txt', templar, loader=None) == ['baz']
    assert listify_lookup_plugin_terms(['foo.txt', '{{foo}}'], templar, loader=None) == ['baz', 'bar']

# Generated at 2022-06-21 08:53:07.957230
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    my_loader = DictDataLoader({})

    # create vault secret
    vault_secret = VaultLib(password_file=os.path.expanduser("~/.vault_pass.txt"))

    # create templar with vault secret
    mytemplar = Templar(loader=my_loader, variables={}, vault_secrets=[vault_secret])

    # test conversion of string to list with single item
    terms = "foo"
    expected_result = [ 'foo' ]
    result = listify_lookup_plugin_terms(terms, mytemplar, my_loader)
    assert expected_result == result

    # test conversion of template string to list with single item

# Generated at 2022-06-21 08:53:18.657245
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.plugins import AnsiblePlugin
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    class StubVarsModule(object):
        pass

    loader = DataLoader()
    templar = Templar(loader=loader, variables=StubVarsModule())

    # Test listify_lookup_plugin_terms with a simple string
    terms = listify_lookup_plugin_terms("foo", templar, loader)
    if terms != ["foo"]:
        raise AssertionError("listify_lookup_plugin_terms should convert a simple string to a list")

    # Test listify_lookup_plugin_terms with a list of strings
    terms = listify_lookup_plugin_terms(["foo", "bar"], templar, loader)

# Generated at 2022-06-21 08:53:27.443084
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    ansible.module_utils.common.listify_lookup_plugin_terms test cases
    """
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    from ansible.template import Templar

    from ansible.vars import VariableManager

    class FakeVarsModule(MutableMapping):
        """
        A fake vars module
        """
        def __init__(self):
            self.data = {}

        def __getitem__(self, key):
            return self.data[key]


# Generated at 2022-06-21 08:53:39.561200
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import jinja2
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # variable_manager._extra_vars = {'param_type': 'var'}
    parameters = {}
    play_context = None

# Generated at 2022-06-21 08:53:50.378298
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = variable_manager.get_inventory(loader=loader)
    variable_manager.set_inventory(inventory)
    context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=inventory._loader,
                      template_class=None, cache=None)

    terms = "{{ lookup('env', 'HOME') }}/{{ lookup('env', 'USER') }}"

# Generated at 2022-06-21 08:54:01.495235
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    If Ansible had a test suite this would be part of it
    '''

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=None)

    tests = [
        dict(
            terms = dict(
                var = '{{ foo }}',
                baz = '{{ moose }}',
            ),
            template_vars = dict(
                foo='foo',
                moose='cow',
            ),
            result = ['foo', 'cow'],
        )
    ]

    for n, t in enumerate(tests):
        terms = t['terms']
        template_vars = t['template_vars']
        expected_result

# Generated at 2022-06-21 08:54:10.833689
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_vars({'a_list': [1,2], 'b_list': ['a','b'], 'a_str': 'a_str', 'a_int': 1})
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string should be templated as a string
    result = listify_lookup_plugin_terms('{{ a_str }}', templar, loader)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result == ['a_str']

    # Test integer should be templated as a

# Generated at 2022-06-21 08:54:40.004944
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-21 08:54:49.588419
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    module_data = dict(
        one=1,
        two=2,
        three=3,
    )

    vm = VariableManager()
    vm.set_host_variable('test.example.com', 'foo', 'bar')
    vm.set_host_variable('test.example.com', 'one', 1)
    vm.set_host_variable('test.example.com', 'two', 2)
    vm.set_host_variable('test.example.com', 'three', 3)

    vm.set_host_variable('test2.example.com', 'foo', 'bar')

# Generated at 2022-06-21 08:54:56.199217
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_string = '{{ item.bla }}'
    test_list = ['{{ item.bla }}', '{{ item.blah }}']
    fail_on_undefined = True
    convert_bare = True   # it tests with and without convert_bare due to the recursion

    # NOTE: we need the mock templar to return the input for the test to be complete
    mock_templar = MockTemplar(test_string)

    # NOTE: we don't care about the loader here so passing in None
    test_string_listified = listify_lookup_plugin_terms(test_string, mock_templar, loader=None,
                                                        fail_on_undefined=fail_on_undefined, convert_bare=convert_bare)

    assert isinstance(test_string_listified, list)


# Generated at 2022-06-21 08:55:05.213294
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Setup fixture
    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with single string term
    result = listify_lookup_plugin_terms("1st term", templar, loader)
    assert isinstance(result, list)
    assert len(result) == 1

    # Test with multiple string terms
    result = listify_lookup_plugin_terms("1st term, 2nd term", templar, loader)
    assert isinstance(result, list)
    assert len(result) == 2

    # Test with single string term, but is already a list

# Generated at 2022-06-21 08:55:15.612159
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.template import Templar

    class FakeVarsModule(object):

        def __init__(self):
            self._data = {}

        def add_with_vars(self, data):
            self._data.update(data)

        def _get_vars(self):
            return self._data

        def _get_main(self):
            return self._data

        def _get_main_vars(self):
            return self._data

    class FakeLoader(object):

        def get_basedir(self, path):
            return path

    class FakeVariableManager(object):

        def __init__(self):
            self.vars_cache = FakeVarsModule()

    class FakeOptions(object):
        extra_vars = {}
        vars = {}
       

# Generated at 2022-06-21 08:55:21.463019
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # String argument with no templating
    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']

    # List argument with no templating
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None) == ['foo', 'bar']


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-21 08:55:32.729985
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Definition of the test_variable_manager and the test_loader
    class TestVariableManager(object):

        def template(self, source, fail_on_undefined=True, convert_bare=False):
            return source

    class TestLoader(object):
        pass

    # Creation of the templar and the terms
    templar = TestVariableManager()
    terms = "test_listify_lookup_plugin_terms"

    # Test the function
    result = listify_lookup_plugin_terms(terms, templar, TestLoader())
    assert result == [terms.strip()], "%s is not %s" % (result, [terms.strip()])

    # Test the function with a list
    terms = ["test_listify_lookup_plugin_terms"]