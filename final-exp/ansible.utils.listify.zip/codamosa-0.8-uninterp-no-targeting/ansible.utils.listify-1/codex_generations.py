

# Generated at 2022-06-21 08:45:37.785937
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.plugins.loader import lookup_loader

    # test strings
    terms = 'test'
    new_terms = listify_lookup_plugin_terms(terms, Templar(loader=lookup_loader), loader=lookup_loader)
    assert isinstance(new_terms, list)
    assert new_terms[0] == 'test'

    # test lists
    terms = ['test1', 'test2', 'test3']
    new_terms = listify_lookup_plugin_terms(terms, Templar(loader=lookup_loader), loader=lookup_loader)
    assert isinstance(new_terms, list)
    assert new_terms == terms

# Generated at 2022-06-21 08:45:45.700421
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert listify_lookup_plugin_terms(['a', 'b'], Templar(loader=AnsibleLoader), loader=AnsibleLoader()) == ['a', 'b']
    assert listify_lookup_plugin_terms(1, Templar(loader=AnsibleLoader), loader=AnsibleLoader()) == [1]
    assert listify_lookup_plugin_terms('a', Templar(loader=AnsibleLoader), loader=AnsibleLoader()) == ['a']

# Generated at 2022-06-21 08:45:54.985295
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.plugins.lookup import LookupBase

    import ansible.template.template as template

    class TestLookupModule(LookupBase):

        def run(self, terms, variables=None, **kwargs):
            return listify_lookup_plugin_terms(terms, self._templar, self._loader, fail_on_undefined=True, convert_bare=False)

    templar = template.AnsibleTemplate(variables=dict(a='a', b=dict(ba='ba')))
    lookup_plugin = TestLookupModule()

    assert lookup_plugin.run([u'{{a}}', u'{{b.ba}}'], templar=templar) == [u'a', u'ba']

# Generated at 2022-06-21 08:46:03.752772
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    templar = Templar(loader=None)

    class FakeVar:
        def __init__(self, value=None):
            self.name = 'test'
            self.value = value

    assert listify_lookup_plugin_terms("foo", templar, None) == ["foo"]
    assert listify_lookup_plugin_terms("{{ foo }}", templar, None) == [None]
    assert listify_lookup_plugin_terms("{{ foo }}", templar, None, fail_on_undefined=False) == ['None']
    assert listify_lookup_plugin_terms(["{{ foo }}"], templar, None) == [None]
    assert listify_lookup_plugin

# Generated at 2022-06-21 08:46:15.026166
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    t = Templar(loader=None, variables={'item': 'foo'})

    # Look a little like a lookup module but don't be one
    class FakeLookupModule:

        def __init__(self, basedir=None, runner_basedir=None, **kwargs):
            self.basedir = basedir
            self.runner_basedir = runner_basedir

        def run(self, terms, **kwargs):
            return [terms]

    assert listify_lookup_plugin_terms('{{item}}', t, FakeLookupModule()) == ['foo']
    assert listify_lookup_plugin_terms(['{{item}}', '{{item}}'], t, FakeLookupModule()) == ['foo', 'foo']

# Generated at 2022-06-21 08:46:22.932301
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # the 'vars' dict is required to handle variable lookups in the context
    # of the templating engine
    vars = dict(some_var='some_value')

    # initialize a new template engine, using the vault key if provided
    templar = Templar(loader=None, variables=vars)
    templar.set_available_variables(vars)

    # setup templating defaults
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    templar._add_tasks_vars = True
    templar._block = Block()
    templar._play_context = PlayContext()
    tem

# Generated at 2022-06-21 08:46:28.368760
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class FakeVarsModule(object):
        def get_vars(self, loader, play, host, task):
            return dict(omg=dict(first="hello", second="world"), lol="{{ omg.first }} {{ omg.second }}")

    t = Templar(loader=None, variables=FakeVarsModule())

    # Test list conversion
    assert listify_lookup_plugin_terms([1,2,3,4], t, None) == [1,2,3,4]

    # Test string conversion
    assert listify_lookup_plugin_terms("hello", t, None) == ["hello"]

    #

# Generated at 2022-06-21 08:46:36.050382
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # this would normally be a vars/facts managed object
    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    # Basic test
    ret = listify_lookup_plugin_terms(
        [1, "{{foo}}", "{{bar}}", 3]
    )
    assert isinstance(ret, list)
    assert len(ret) == 4
    assert [1, '{{foo}}', '{{bar}}', 3] == ret

    # Test with a string

# Generated at 2022-06-21 08:46:37.634445
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: add this test once we have a module_utils/testing framework
    pass

# Generated at 2022-06-21 08:46:49.098873
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    #from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import lookup_loader

    terms = { "a": "b" }

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)

    lookup = lookup_loader.get("file")

    templar = Templar(loader=loader, variable_manager=variable_manager, templar=None)

# Generated at 2022-06-21 08:46:58.516944
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Set-up objects needed for templar.template
    mock_loader = None
    mock_variable_manager = None
    mock_options = {'vault_password': None}
    mock_extra_vars = {}
    mock_inventory = {}

    from ansible.playbook import templar
    templar = templar.Templar(loader=mock_loader, variable_manager=mock_variable_manager,
                              options=mock_options, **mock_extra_vars)

    assert listify_lookup_plugin_terms(terms='foo', templar=templar, loader=mock_loader) == ['foo']

# Generated at 2022-06-21 08:47:10.110923
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from jinja2 import Template
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    loader = DictDataLoader({
        "myvars": "{% raw %}{{ foo }},{{ bar }},{{ baz }}{% endraw %}",
    })

    ansibles = {'foo': 'Foo', 'bar': 'Bar', 'baz': 'Baz'}

    templar = Template(loader=loader, variables=ansibles, searchpath=['.'],
                       convert_bare=False, fail_on_undefined=True,
                       unfrackpath=mock_unfrackpath_noop)

    # Test when terms is a string
    terms = "{{ foo }}"
    results = listify_lookup_plugin_

# Generated at 2022-06-21 08:47:19.055887
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DictDataLoader({})
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'foo': 'bar', 'baz': 'qux'}
    templar = Templar(loader=loader, variables=variable_manager)
    assert listify_lookup_plugin_terms('{{foo}}', templar, loader) == ['bar']
    assert listify_lookup_plugin_terms(['{{foo}}', '{{baz}}'], templar, loader) == ['bar', 'qux']

# Generated at 2022-06-21 08:47:30.026465
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.template
    import ansible.parsing.yaml.objects

    templar = ansible.template.Templar(loader=None)

    class VarsModule:
        def __init__(self):
            self.ansible_facts = dict(
                nickname = "Curious George",
                age = 5,
            )


# Generated at 2022-06-21 08:47:42.269761
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class DummyVarManager():
        def __init__(self):
            pass

    class DummyVarsModule():
        def __init__(self, manager):
            pass

        def set_available_variables(self, variables):
            self.vars = variables

    def test_template(self, data, convert_bare=False, preserve_trailing_newlines=True, fail_on_undefined=True):
        return data

    class DummyTemplar(Templar):

        def __init__(self, loader, variables):
            pass

        def set_available_variables(self, variables):
            self.v

# Generated at 2022-06-21 08:47:49.527016
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(terms="{{ lookup_terms }}", templar=None, loader=None, fail_on_undefined=True, convert_bare=False) == "{{ lookup_terms }}"
    assert listify_lookup_plugin_terms(terms=["{{ lookup_terms }}"], templar=None, loader=None, fail_on_undefined=True, convert_bare=False) == ["{{ lookup_terms }}"]

# Generated at 2022-06-21 08:47:58.088040
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Test 1
    # Setup fixture
    templar = Templar([], [], [], [])
    loader = None
    terms = "{{ lookup('foo') }}"
    fail_on_undefined = True
    convert_bare = False
    expected = templar.template(terms.strip(), convert_bare=convert_bare, fail_on_undefined=fail_on_undefined)
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    assert expected == result

    # Test 2
    # Setup fixture
    terms = ["{{ lookup('foo') }}"]
    expected = templar.template(terms, fail_on_undefined=fail_on_undefined)
    result = listify_look

# Generated at 2022-06-21 08:48:08.614171
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Unit test for function listify_lookup_plugin_terms
    """
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.platform import Platform

    # for the 'convert_bare=False' case
    terms = '{{ foo }}:{{ bar }}'
    templar = Templar(loader=None, variables={'foo': 1, 'bar': 2})
    result = listify_lookup_plugin_terms(terms, templar, None, convert_bare=False)
    assert result == [terms]

    # for the 'convert_bare=True'

# Generated at 2022-06-21 08:48:13.474102
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = '{{ lookup("pipe", "true") }}'
    templar = None
    try:
        listify_lookup_plugin_terms(terms, templar, None)
        assert False
    except:
        assert True

# Generated at 2022-06-21 08:48:22.601845
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-21 08:48:37.287884
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = {
        'dict': {'a': 'b', 'c': 'd'},
        'list': [ 1, 2, 3 ],
        'bare string': '  foo  ',
        'string': '  {{ foo }}  ',
        'none': None,
        'int': 1,
        #'variable': '{{ foo }}',
    }

    assert listify_lookup_plugin_terms(terms['dict'], Templar({'foo': 'bar'}), None) == [ terms['dict'] ]
    assert listify_lookup_plugin_terms(terms['dict'], Templar({'foo': ['bar']}), None) == [ terms['dict'] ]
    assert listify_lookup_plugin_terms(terms['list'], Templar({'foo': 'bar'}), None)

# Generated at 2022-06-21 08:48:45.061698
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    my_vars = dict(hello='world', happy='sad')
    loader = DataLoader()
    templar = Templar(loader=loader, variables=my_vars)

    # unquoted string should be split on commas
    terms = listify_lookup_plugin_terms('a,b,c', templar, loader)
    assert terms == ['a', 'b', 'c']

    # a quoted string should be treated as a single term
    terms = listify_lookup_plugin_terms('"a,b,c"', templar, loader)
    assert terms == ['a,b,c']

    # a list should be converted to a string of comma separated values
    terms = listify_lookup

# Generated at 2022-06-21 08:48:57.511464
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # imports for this test
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # generate test data
    variables = dict(
        some_var1='foo',
        some_var2='bar'
    )
    variable_manager = VariableManager()
    variable_manager.extra_vars = variables

    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)
    assert listify_lookup_plugin_terms('blah', templar, loader, convert_bare=False, fail_on_undefined=True) == ['blah']

# Generated at 2022-06-21 08:49:07.572432
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variables = VariableManager()
    templar = Templar(loader=loader, variables=variables)

    assert listify_lookup_plugin_terms(
        terms=42,
        templar=templar,
        loader=loader
    ) == [42]

    assert listify_lookup_plugin_terms(
        terms=["{{ lookup('env','HOME') }}"],
        templar=templar,
        loader=loader
    ) == ["/Users/lars"]

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-21 08:49:19.789565
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # if terms is a string, it is templated and split at newlines, then returned as a list
    terms = '{{foo}}\n{{bar}}\n{{baz}}'
    templar = DummyTemplar()
    templar.template_data['foo'] = 'Foo'
    templar.template_data['bar'] = 'Bar'
    templar.template_data['baz'] = 'Baz'
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert terms == ['Foo', 'Bar', 'Baz']

    # if terms is a list or tuple, it is returned as a list
    assert listify_lookup_plugin_terms([1, 2, 3], None, None) == [1, 2, 3]
    assert listify_

# Generated at 2022-06-21 08:49:32.354925
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import safe_eval
    from ansible.module_utils.six import string_types

    terms = '{{ value }}'

    result = listify_lookup_plugin_terms(terms, safe_eval, None, fail_on_undefined=True)

    assert isinstance(terms, string_types)
    assert isinstance(result, list)

    terms = '{{ value }} {{ value2 }}'

    result = listify_lookup_plugin_terms(terms, safe_eval, None, fail_on_undefined=True)

    assert isinstance(terms, string_types)
    assert isinstance(result, list)
    assert result == ['{{ value }}', '{{ value2 }}']

    terms = ['{{ value }}', '{{ value2 }}']

    result = listify_lookup_plugin

# Generated at 2022-06-21 08:49:43.275713
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar_noop
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    templar = Templar_noop()
    loader = templar._loader

    # Test a string
    terms = '{{ var }}'
    terms = listify_lookup_plugin_terms(terms=terms, templar=templar, loader=loader)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert terms[0] == '{{ var }}'

    # Test a list
    terms = ['{{ var }}', '{{ foo }}']
    terms = listify_lookup_plugin

# Generated at 2022-06-21 08:49:55.101343
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    import os
    from ansible.parsing.dataloader import DataLoader

    class TestVaultSecret:
        def __init__(self, secret):
            self.secret = secret

        def decrypt(self, data):
            return data.replace('$ANSIBLE_VAULT$', self.secret)

    class TestTemplar(Templar):
        def __init__(self, loader, shared_loader_obj=None, variables=None, vault_secrets=None):
            super(TestTemplar, self).__init__(loader, shared_loader_obj, variables)
            self._available_variables = variables
            self.vault_secrets = [TestVaultSecret('secret')]


# Generated at 2022-06-21 08:50:06.306283
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.loader import lookup_loader

    templar = Templar(
        variables={u'a': u'a', u'b': u'b'},
        loader=lookup_loader,
        shared_loader_obj=lookup_loader,
        disable_lookups=C.DISABLE_LOOKUPS,
    )
    assert sorted(listify_lookup_plugin_terms(['1', '2'], templar, lookup_loader, convert_bare=False)) == sorted(['1', '2'])

# Generated at 2022-06-21 08:50:16.623897
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())

    def test(terms, converted_terms):
        assert listify_lookup_plugin_terms(terms, templar, templar._loader, fail_on_undefined=False) == converted_terms

    test('foo', ['foo'])
    test(['foo', 'bar'], ['foo', 'bar'])
    test(['foo', '{{bar}}'], ['foo', '{{bar}}'])
    test([u'foo', u'{{bar}}'], ['foo', '{{bar}}'])

# Generated at 2022-06-21 08:50:33.566853
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    terms = u'test1, test2'

    fake_vars = dict(
        test_var=u'test_var_value'
    )

    templar = Templar(loader=None, variables=VariableManager(loader=None, variables=fake_vars))

    assert type(listify_lookup_plugin_terms(terms, templar, loader=None)) is list
    assert listify_lookup_plugin_terms(terms, templar, loader=None)[0] == u'test1'
    assert listify_lookup_plugin_terms(terms, templar, loader=None)[1] == u'test2'

    terms = u'test1,{{ test_var }}'


# Generated at 2022-06-21 08:50:40.916688
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms(terms='foo', templar=templar) == ['foo']
    assert listify_lookup_plugin_terms(terms=['foo'], templar=templar) == ['foo']
    assert listify_lookup_plugin_terms(terms=['foo','bar'], templar=templar) == ['foo','bar']

# Generated at 2022-06-21 08:50:50.595663
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert_equal = lambda x, y: x == y, 'Expected %s, got %s'

    # String
    terms = listify_lookup_plugin_terms('{{ foo }}', dict(foo=1))
    assert_equal(terms, ['1'])

    # List
    terms = listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], dict(foo=1, bar=2))
    assert_equal(terms, ['1', '2'])

    # List with a dict inside
    terms = listify_lookup_plugin_terms(['{{ foo }}', {'bar': '{{ bar }}'}], dict(foo=1, bar=2))
    assert_equal(terms, ['1', {'bar': '2'}])

    # Both string and list
    terms = listify

# Generated at 2022-06-21 08:51:01.709238
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.display import Display
    from ansible.template import Templar
    from ansible.parsing import DataLoader

    display = Display()
    loader = DataLoader()
    templar = Templar(loader=loader, variables={})
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms([['foo', 'bar']], templar, loader) == [['foo', 'bar']]

# Generated at 2022-06-21 08:51:06.966340
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert listify_lookup_plugin_terms('1', None, None) == ['1']
    assert listify_lookup_plugin_terms(['1'], None, None) == ['1']
    assert listify_lookup_plugin_terms(['1', '2'], None, None) == ['1', '2']
    assert listify_lookup_plugin_terms([1, 2], None, None) == [1, 2]

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-21 08:51:17.140060
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    #
    # Module functions
    #

    def template(data, src_vars=dict(), fail_on_undefined=False, convert_bare=False, **_):
        if data in ('f1', 'f2'):
            return 'f3'
        else:
            return data

    #
    # Tests
    #

    class TestModule(object):
        pass

    test_module = TestModule()
    test_module._templar = test_module
    test_module.template = template


    assert listify_lookup_plugin_terms('f1', test_module, None) == ['f3']
    assert listify_lookup_plugin_terms(['f1', 'f2'], test_module, None) == ['f3', 'f3']
    assert listify_lookup_plugin_

# Generated at 2022-06-21 08:51:29.013445
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    data = dict(a=1, b=2, c=3, d=4, e=5)
    loader = DataLoader()
    templar = Templar(loader=loader, variables=data)
    assert listify_lookup_plugin_terms(['a', 'b'], templar=templar, loader=loader, convert_bare=True) == ['a', 'b']
    assert listify_lookup_plugin_terms('asd', templar=templar, loader=loader) == ['asd']
    assert listify_lookup_plugin_terms('asd', templar=templar, loader=loader, convert_bare=True) == ['asd']
    assert listify_lookup

# Generated at 2022-06-21 08:51:41.640573
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.loader import lookup_loader

    # Test with a string and a list
    string_terms = "test"
    list_terms = ["test"]

    # Construct a dummy templar object
    templar = lookup_loader.get("file", loader=None, templar=None)

    # Construct a dummy loader object
    loader = lookup_loader.get("file", loader=None, templar=None)

    # Test that the two are equivalent when templated
    assert listify_lookup_plugin_terms(string_terms, templar, loader) == listify_lookup_plugin_terms(list_terms, templar, loader)

    # Test that both are converted to lists
    assert isinstance(listify_lookup_plugin_terms(string_terms, templar, loader), list)

# Generated at 2022-06-21 08:51:50.742082
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms(terms=[1, 2, 3], templar=templar, loader=None) == [1, 2, 3]
    assert listify_lookup_plugin_terms(terms=42, templar=templar, loader=None) == [42]
    assert listify_lookup_plugin_terms(terms="42", templar=templar, loader=None) == [42]

# Generated at 2022-06-21 08:52:00.572626
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class MyLookupModule(object):

        def __init__(self, basedir=None, **kwargs):
            pass

        def get_basedir(self, variables):
            return variables['playbook_dir']

        def run(self, terms, inject=None, **kwargs):
            terms = listify_lookup_plugin_terms(terms, MyTemplar(), MyLoader(), fail_on_undefined=False)
            assert terms == result, "%s != %s" % (terms, result)
            print("OK: %s" % result)

    class MyTemplar(object):

        def __init__(self):
            pass

        def template(self, data, fail_on_undefined=True, convert_bare=False):
            return data


# Generated at 2022-06-21 08:52:24.873920
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    FUT = listify_lookup_plugin_terms

    # test: list of strings
    S1 = [ 'A', 'B', 'C' ]
    assert FUT(S1, templar=None, loader=None, fail_on_undefined=False, convert_bare=False) == S1

    # test: string value
    S2 = ['A']
    assert FUT('A', templar=None, loader=None, fail_on_undefined=False, convert_bare=False) == S2

    # test: value is None
    S3 = None
    assert FUT(S3, templar=None, loader=None, fail_on_undefined=False, convert_bare=False) == []

# Generated at 2022-06-21 08:52:34.019660
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Tests correct conversion of terms to list of string
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    templar = Templar(loader=AnsibleLoader(None))
    terms = '{{ lookup("community.general.aws_ec2_facts", "instance_type={{ instance_type }}") }}'
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(terms, list)
    assert terms == [u'{{ lookup("community.general.aws_ec2_facts", "instance_type={{ instance_type }}") }}']

# Generated at 2022-06-21 08:52:44.870420
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

# Generated at 2022-06-21 08:52:53.852695
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager

    v = VariableManager()
    v.extra_vars = {'foo': 'bar'}
    v.vault_password = 'foo'
    t = Templar(loader=None, variables=v)

    terms = '{{ foo }}'
    terms = listify_lookup_plugin_terms(terms, t, loader=None)
    assert terms == ['bar']

    terms = ['{{ foo }}', 'baz']
    terms = listify_lookup_plugin_terms(terms, t, loader=None)
    assert terms == ['bar', 'baz']

    terms = ['{{ foo }}', ['baz']]
    terms = listify

# Generated at 2022-06-21 08:53:04.842516
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # FIXME
    # pytest.importorskip('ansible.utils.template')
    # pytest.importorskip('ansible.parsing.yaml.objects')

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.six import string_types
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars
    from ansible.utils.vars import combine_vars

    terms = 'foo'
    templar = Templar(loader=None, shared_loader_obj=None, variables=AnsibleVars(combine_vars(loader=None, variables=None)))
    assert terms == 'foo'
    assert isinstance(terms, string_types)

# Generated at 2022-06-21 08:53:13.291117
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # This test requires a loader
    loader = DummyLoader()

    templar = Templar(loader=loader)

    # Check that it always returns a list
    terms = None
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert(isinstance(result, list))
    assert(result == [])

    terms = 5
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert(isinstance(result, list))
    assert(result == [5])

    # Check string -> list conversion behavior
    terms = "foo,bar,baz"
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert(isinstance(result, list))

# Generated at 2022-06-21 08:53:19.767362
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    t = Templar(loader=DataLoader(), variables=VariableManager())

# Generated at 2022-06-21 08:53:28.246947
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib

    # Setup templar
    variable_manager = VariableManager()
    loader = None
    vault_secrets = VaultLib([])
    templar = Templar(loader=loader, variables=variable_manager, vault_secrets=vault_secrets)

    # Test function with a string
    assert listify_lookup_plugin_terms("{{ 'foo' }}", templar, loader) == ['foo']
    # Test function with a list
    assert listify_lookup_plugin_terms(["{{ 'foo' }}"], templar, loader) == ['foo']
    # Test function with an escaped list

# Generated at 2022-06-21 08:53:40.331591
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = "{{ 'a,b'|path_has }}"
    terms = listify_lookup_plugin_terms(terms, Templar(loader=None), None)
    assert terms == ['a,b']

    terms = ["{{ foo }},{{ bar }}", "{{ bam }}"]
    terms = listify_lookup_plugin_terms(terms, Templar(loader=None), None)
    assert terms == [u"{{ foo }},{{ bar }}", u"{{ bam }}"]


    class MockVarsModule:
        def __init__(self):
            self.ns = {}
            self.ns['foo'] = 'f'
            self.ns['bar'] = 'b'
            self.ns['bam'] = 'm'

    from ansible.context import CLIContext

# Generated at 2022-06-21 08:53:50.976620
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import utils
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    my_vars = dict(
        foo="bar",
        alpha="a list",
        beta=["first element"],
        gamma="{{ foo }}",
        delta=["a", "b", "c"],
        epsilon=["{{ alpha }}"],
        zeta=["{{ gamma }}"],
        eta=["1", "{{ foo }}", "3"],
        theta=["{{ missing_var }}"]
    )

    variable_manager = VariableManager()
    variable_manager.extra_vars = my_vars

    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)



# Generated at 2022-06-21 08:54:30.785141
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']
    assert listify_lookup_plugin_terms(('foo',), templar, None) == ['foo']
    assert listify_lookup_plugin_terms(('foo','bar'), templar, None) == ['foo','bar']
    assert listify_lookup_plugin_terms(['foo','bar'], templar, None) == ['foo','bar']

# Generated at 2022-06-21 08:54:41.198783
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common._collections_compat import list

    dummy_var_manager = dict(foo=5)
    dummy_loader = AnsibleLoader(None)
    dummy_templar = Templar(loader=dummy_loader, variables=dummy_var_manager)

    # basic test
    result = listify_lookup_plugin_terms('foo', dummy_templar, dummy_loader)
    assert isinstance(result, list)
    assert result == ['foo']

    # test for failure case
    result = listify_lookup_plugin_terms('foo{{ bar }}', dummy_templar, dummy_loader)
    assert isinstance(result, string_types)

# Generated at 2022-06-21 08:54:51.460345
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = '{{ foo }}'
    templar = Templar([], loader=None)
    templar._available_variables = dict(foo=['one', 'two', 'three'])

    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['one', 'two', 'three']

    terms = '{{ foo }}'
    templar = Templar([], loader=None)
    templar._available_variables = dict(foo='1')

    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['1']

    terms = ['{{ foo.0 }}', '{{ foo.1 }}', '{{ foo.2 }}']
    templar = Templar([], loader=None)


# Generated at 2022-06-21 08:54:58.747759
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    lookup_term = '{{ lookup_var }}'
    lookup_var = 'first_val'

    # the `convert_bare` parameter is set False because we want to test the
    # lookup plugin's specific use of `convert_bare`.  It is enabled/

# Generated at 2022-06-21 08:55:07.313159
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.templar import Templar

    class Dummy:
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return self.value

        def template(self, value, fail_on_undefined=True):
            return value

    class DummyData:
        def __init__(self, value):
            self.value = value

    assert listify_lookup_plugin_terms('foo', Templar(DummyData(None)), None) == ['foo']
    assert listify_lookup_plugin_terms('foo', Templar(DummyData(None)), None, convert_bare=True) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], Templar(DummyData(None)), None) == ['foo']
    assert list

# Generated at 2022-06-21 08:55:16.218070
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class FakeTemplar(object):

        def __init__(self, string_value):
            self.string_value = string_value

        def template(self, terms, fail_on_undefined=False, convert_bare=False):
            if isinstance(terms, string_types):
                return self.string_value
            else:
                return terms

    assert listify_lookup_plugin_terms(['foo'], FakeTemplar('bar'), None) == ['foo']
    assert listify_lookup_plugin_terms('foo', FakeTemplar('bar'), None) == ['bar']
    assert listify_lookup_plugin_terms('[foo]', FakeTemplar('bar'), None) == ['bar']

# Generated at 2022-06-21 08:55:26.196945
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib

    terms = '{{ item }}'
    templar = Templar(loader=None, variables=VariableManager(), vault_secrets=VaultLib())
    results = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert results == ['item']

    terms = ['test_listify_lookup_plugin_terms', '{{ item }}']
    results = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert results == ['test_listify_lookup_plugin_terms', '{{ item }}']

# Generated at 2022-06-21 08:55:34.608914
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext

    templar = Templar(loader=None, variables={}, vault_secrets=VaultLib(),
                      loader_basedir=".", context=PlayContext(), shared_loader_obj=None)

    # test string_types input
    assert listify_lookup_plugin_terms("foo", templar, None) == ["foo"]
    # test non-string_types input
    assert listify_lookup_plugin_terms(["foo"], templar, None) == ["foo"]