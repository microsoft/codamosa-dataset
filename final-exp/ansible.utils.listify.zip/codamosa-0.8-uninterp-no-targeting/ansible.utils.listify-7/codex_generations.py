

# Generated at 2022-06-21 08:45:40.013522
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, None, None, False, False) == ['foo']
    assert listify_lookup_plugin_terms(terms, None, None, False, True) == ['foo']
    assert listify_lookup_plugin_terms('{{ foo }}', 'foo', None, False, False) == ['foo']
    assert listify_lookup_plugin_terms('{{ foo }}', 'foo', None, False, True) == ['{{ foo }}']
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None, False, False) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None, False, True) == ['foo', 'bar']

# Generated at 2022-06-21 08:45:49.436480
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager

    # This is what an actual lookup.py plugin sees as the last parameter to its execute function (the parameter name
    #  is actually 'variables', not 'var')
    #    var = dict(
    #        hostvars=dict(testhost = dict(ansible_ssh_host='192.168.1.99', ansible_ssh_pass='admin')),
    #        group_names=dict(group1=['testhost'])
    #    )

    var = dict()

# Generated at 2022-06-21 08:45:56.594306
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.errors as errors
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence

    def my_fail_on_undefined(self, what, fail_on_undefined, **kwargs):
        raise errors.AnsibleUndefinedVariable('test')

    templar = Templar()
    templar._fail_on_undefined = my_fail_on_undefined.__get__(templar)

    class MyLoader(object):
        def get_basedir(self, *args, **kwargs):
            return '/'

    # Test string input with extra whitespace

# Generated at 2022-06-21 08:46:04.603752
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import AnsibleTemplar
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    variables = dict(
        a = 'alpha',
        b = dict(
            ba = 'bravo',
            bb = dict(
                bba = 'charlie',
            )
        )
    )
    templar = AnsibleTemplar(loader=None, variables=variables)

    assert listify_lookup_plugin_terms(None, templar) == []
    assert listify_lookup_plugin_terms(5, templar) == [5]
    assert listify_lookup_plugin_terms('foo', templar) == ['foo']
    assert listify_

# Generated at 2022-06-21 08:46:09.321324
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    templar = Templar(loader=loader, variable_manager=variable_manager, fail_on_undefined=True, convert_bare=False)

    # Test listify_lookup_plugin_terms with empty string
    my_list = listify

# Generated at 2022-06-21 08:46:19.298444
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.template import Templar
    from ansible import errors
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class FakeVarsModule(object):
        def __init__(self):
            self.data = dict(
                testvar1=123,
                testvar2='hello',
                testvar3=AnsibleMapping(dict(subvar1='subval1')),
                testvar4=AnsibleSequence(['seq 1', 'seq 2']),
            )

    class FakeLoaderModule(object):
        def __init__(self):
            self.path_dwim = lambda x: x

    # simple string
    s = 'testvar1'
   

# Generated at 2022-06-21 08:46:30.850455
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None)
    fd = StringIO(u"foo: '{{ lookup('pipe','echo foo') }}'\n")
    results = templar.template_from_file(fd)

    assert isinstance(results, dict)
    assert isinstance(results['foo'], AnsibleUnicode)
    assert results['foo'] == u'foo'

    # Now testing if we get a list of unicode strings
    results = templar.template("{{ lookup('pipe','echo foo') }}")

    assert isinstance(results, list)
    assert isinstance(results[0], AnsibleUnicode)


# Generated at 2022-06-21 08:46:31.477565
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-21 08:46:43.420116
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        foo='1',
        bar='2',
        bam='3',
        baz='4',
    )

    templar = Templar(loader=None, variables=variable_manager)

    # test string
    assert listify_lookup_plugin_terms('{{ foo }}', templar=templar) == ['1']
    assert listify_lookup_plugin_terms('{{ foo }},{{ bar }}', templar=templar) == ['1', '2']

    # test iterable

# Generated at 2022-06-21 08:46:53.495901
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    passwords = dict(vault_pass='secret')

    vault = VaultLib(passwords)
    results = listify_lookup_plugin_terms(
        terms='http://127.0.0.1/',
        templar=None,
        loader=loader,
        fail_on_undefined=True,
        convert_bare=False)

# Generated at 2022-06-21 08:47:06.532919
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeTemplar(object):
        def template(self, data, convert_bare=False, fail_on_undefined=True):
            return data

    fake_templar = FakeTemplar()

    # We expect to get back a list of variables or a list of one list
    assert listify_lookup_plugin_terms('a', fake_templar, None, True) == ['a']
    assert listify_lookup_plugin_terms(['a', 'b'], fake_templar, None, True) == [['a', 'b']]

    # We expect to get back a list of one list
    assert listify_lookup_plugin_terms(['a'], fake_templar, None, True) == [['a']]

# Generated at 2022-06-21 08:47:17.070960
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    terms = '{{ "a" + "b" | string }}'
    templar = ansible.template.Templar(loader=None)
    assert ['ab'] == listify_lookup_plugin_terms(terms, templar, None)

    terms = '{{ ["a", "b"] | join(" ") }}'
    assert ['a b'] == listify_lookup_plugin_terms(terms, templar, None)

    terms = '{{ ["a", ["b", "c"], "d"] | join(" ") }}'
    assert ['a b c d'] == listify_lookup_plugin_terms(terms, templar, None)

    terms = '{{ ["a", ["b", "c"], "d"] | flatten | list | join(" ") }}'

# Generated at 2022-06-21 08:47:28.457323
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.template

    class FakeVarsModule:
        def __init__(self):
            self.ansible_facts = dict(a='b')

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    factory = ansible.template.J2Template.factory
    loader = ansible.template.AnsibleLoader(fake_vars_module=FakeVarsModule(), vault_secrets=VaultLib())
    templar = ansible.template.Templar(loader=loader, variables=dict(a=1), fail_on_undefined=True)

    # test single string
    assert listify_lookup_plugin_terms('{{ a }}', templar, loader) == ['b']

    # test single list


# Generated at 2022-06-21 08:47:35.132254
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    result = listify_lookup_plugin_terms('test', templar=templar, loader=loader)
    assert result == ['test']

    result = listify_lookup_plugin_terms(u'test', templar=templar, loader=loader)
    assert result == ['test']

    result = listify_lookup_plugin_terms(['test'], templar=templar, loader=loader)
    assert result == ['test']

    result = listify_lookup_plugin_terms('{{foo}}', templar=templar, loader=loader)
    assert result == ['fail_on_undefined']

# Generated at 2022-06-21 08:47:44.027549
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible import variables

    # Dummy class for testing Templar
    class Dummy:
        pass

    # Init
    set_var = dict(a='a', b='b', c='c')
    templar = Templar(loader=Dummy(), variables=variables.VariableManager(loader=Dummy(), inventory=Dummy()))
    templar.set_available_variables(set_var)
    fail_on_undefined = False
    convert_bare = True

    # Setting up a few cases
    cases = dict()
    cases['simple'] = dict(expected=['a'], args=['a'])
    cases['complex'] = dict(expected=['a', 'a'], args=['{{ a }}', '{{ a }}'])

# Generated at 2022-06-21 08:47:55.353176
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test for string object
    assert listify_lookup_plugin_terms('string') == ['string']
    assert listify_lookup_plugin_terms('  string   ') == ['string']

    # test for iterable object
    assert listify_lookup_plugin_terms(['string1', 'string2']) == ['string1', 'string2']
    assert listify_lookup_plugin_terms([['string1', 'string2']]) == [['string1', 'string2']]
    assert listify_lookup_plugin_terms([['string1', 'string2'], ['string3', 'string4']]) == [['string1', 'string2'], ['string3', 'string4']]

    # test for empty object
    assert listify_lookup_plugin_terms(None) is None

# Generated at 2022-06-21 08:48:07.497675
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    # Setup data
    var_manager = VariableManager()
    loader = None
    vault_secrets = [{'some_secret_key': 'my_secret_value'}]
    vault_password = VaultLib([VaultLib.AES256]).encrypt(vault_secrets)
    vault_secret = AnsibleVaultEncryptedUnicode(vault_password)
    var_manager._extra_vars = dict(vault_secret=vault_secret)

    # Create templar for testing

# Generated at 2022-06-21 08:48:18.653958
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.template
    import ansible.utils
    import ansible.utils.template
    import ansible.parsing.plugin_docs

    def is_string(s):
        return isinstance(s, string_types)

    templar = ansible.template.AnsibleTemplar(loader=ansible.parsing.dataloader.DataLoader())

    assert all(is_string(term) for term in listify_lookup_plugin_terms('foo', templar))
    assert all(is_string(term) for term in listify_lookup_plugin_terms('foo,bar', templar))
    assert all(is_string(term) for term in listify_lookup_plugin_terms(['foo','bar'], templar))

# Generated at 2022-06-21 08:48:27.796158
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DictDataLoader({})
    templar = Templar(loader=loader)

    # Test string value
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo.bar', templar, loader, convert_bare=True) == ['foo.bar']

    # Test list and tuple values
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(('foo', 'bar'), templar, loader) == ['foo', 'bar']

# Generated at 2022-06-21 08:48:38.963855
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.template import template_module_style
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    templar = Templar(loader=None, variables={}, shared_loader_obj=None, disable_lookups=False)
    templar._templar = template_module_style

    assert listify_lookup_plugin_terms(terms=u'one', templar=templar, loader=None) == [u'one']
    assert listify_lookup_plugin_terms(terms=AnsibleUnicode(u'one'), templar=templar, loader=None) == [u'one']
    assert listify_lookup

# Generated at 2022-06-21 08:48:54.090734
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.encrypt import do_encrypt
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Empty
    templar = Templar(loader=None, variables=VariableManager())
    assert [] == listify_lookup_plugin_terms([], templar, None)


    # Single string
    assert ['foo'] == listify_lookup_plugin_terms('foo', templar, None)

    # Multiple strings

# Generated at 2022-06-21 08:49:02.232991
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms(terms='{{ [1, 2, 3] }}', templar=templar) == [1, 2, 3]
    assert listify_lookup_plugin_terms(terms='{{ "a" }}', templar=templar) == ['a']
    assert listify_lookup_plugin_terms(terms=[1, 2, 3], templar=templar) == [1, 2, 3]

    # Test when the term is a dict, it should remain as is
    test_dict = dict()
    test_dict['foo'] = 'bar'
    assert listify_lookup_plugin_terms(terms=test_dict, templar=templar) == test_dict

# Generated at 2022-06-21 08:49:14.513396
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' listify_lookup_plugin_terms should return the same input
    if the input is a string, a list, or a tuple '''

    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    data_loader = DataLoader()
    collection_loader = AnsibleCollectionLoader(data_loader)

    templar = Templar(
        loader=data_loader,
        variables={},
    )

    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Iterable

    # list
    terms = ['foo', 'bar']

# Generated at 2022-06-21 08:49:23.870272
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 'foo'}
    templar = Templar(loader=loader, variables=variable_manager)

    # Test 1
    test_string = '/test/test/test'
    assert listify_lookup_plugin_terms(test_string, templar, loader) == test_string

    # Test 2
    test_string = '[1, 2, 3]'
    assert listify_lookup_plugin_terms(test_string, templar, loader) == [1, 2, 3]

    # Test 3

# Generated at 2022-06-21 08:49:33.791535
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # create fake templar
    templar = Templar(loader=None, variables={})

    # create fake loader
    class FakeLoader:
        def get_basedir(self, hostname):
            return '.'

    # test function
    test_output = listify_lookup_plugin_terms("{{ foo }}", templar, FakeLoader(), True, True)
    assert test_output == ["{{ foo }}"]

    test_output = listify_lookup_plugin_terms("{{ foo }}", templar, FakeLoader(), True, False)
    assert test_output == [None]

    test_output = listify_lookup_plugin_terms("{{ foo }}", templar, FakeLoader(), False, False)
    assert test_output == ["{{ foo }}"]


# Generated at 2022-06-21 08:49:44.177861
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.vars import combine_vars

    class DummyVars(dict):
        def __init__(self, args):
            self['a'] = 'foo'
            self['b'] = AnsibleUnsafeText(u"'hello'")
            self['c'] = AnsibleVaultEncryptedUnicode(u"secret", None)

    hosts = InventoryManager(loader=None, sources="localhost")

    vars_manager = VariableManager(loader=None, inventory=hosts)
   

# Generated at 2022-06-21 08:49:52.028796
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    terms = '{{ var1 }}:{{ val2 }}'
    terms_expected_result = ['foo:baz']

    class DummyTemplar():

        def template(self, source, **kwargs):
            if source == ['{{ var1 }}:{{ val2 }}'] :
                return ['foo:baz']
            else:
                raise Exception('Bad source')

    class DummyLoader():
        pass

    t = DummyTemplar()
    l = DummyLoader()

    result = listify_lookup_plugin_terms(terms, t, l)

    assert result == terms_expected_result

# Generated at 2022-06-21 08:50:00.879382
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    assert listify_lookup_plugin_terms('1', Templar(loader=AnsibleLoader(VaultLib()))) == ['1']
    assert listify_lookup_plugin_terms('1 2', Templar(loader=AnsibleLoader(VaultLib()))) == ['1', '2']
    assert listify_lookup_plugin_terms('1 2 3', Templar(loader=AnsibleLoader(VaultLib()))) == ['1', '2', '3']
    assert listify_lookup_plugin_terms(['1', '2', '3'], Templar(loader=AnsibleLoader(VaultLib()))) == ['1', '2', '3']

# Generated at 2022-06-21 08:50:10.633254
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    from ansible.vars.manager import ensure_type

    v = VariableManager()
    t = Templar(vars=v)

    assert listify_lookup_plugin_terms('a', t, None) == ['a']
    assert listify_lookup_plugin_terms(['a'], t, None) == ['a']
    assert listify_lookup_plugin_terms(['a', 'b'], t, None) == ['a', 'b']

    # Also test if source YAML object is preserved

# Generated at 2022-06-21 08:50:16.102702
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = '''
    - 123
    - "{{ my_list }}"
    '''
    loader = AnsibleLoader(yaml_str)

    my_list = [1, 2, 3]
    t = Templar(loader=loader)
    terms = t.template(loader.get_single_data(), fail_on_undefined=False, convert_bare=False)

    assert terms == [123, my_list], terms
    assert type(terms) is list, type(terms)

    yaml_str = '''
    - 123
    - "{{ my_list }}"
    - some_value
    '''
    loader = AnsibleLoader(yaml_str)


# Generated at 2022-06-21 08:50:33.376618
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test with a string
    from ansible.vars.manager import VariableManager
    from ansible.template.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {}
    templar = Templar(loader=loader, variables=variable_manager)
    results = listify_lookup_plugin_terms("{{ lookup('foo', 'bar') }}", templar, loader, fail_on_undefined=True, convert_bare=False)
    assert len(results) == 1
    assert results[0] == "{{ lookup('foo', 'bar') }}"

    # test with a list

# Generated at 2022-06-21 08:50:41.532932
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('1', templar, loader) == ['1']
    assert listify_lookup_plugin_terms(['1'], templar, loader) == ['1']
    assert listify_lookup_plugin_terms(['1', '2'], templar, loader) == ['1', '2']

# Generated at 2022-06-21 08:50:50.824609
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        foo={'a': 1, 'b': 'two'},
        bar='hello world',
        baz=[1, 2, 3],
    )

    templar = Templar(loader=None, variables=variable_manager)

    assert listify_lookup_plugin_terms(['{{foo.a}}', '{{foo.b}}'], templar, loader=None) == [1, 'two']
    assert listify_lookup_plugin_terms(123, templar, loader=None) == [123]

# Generated at 2022-06-21 08:51:02.010119
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    mock_loader = None
    templar = Templar(loader=mock_loader)

    # convert a bare var to a list of one element
    assert listify_lookup_plugin_terms("{{ foo }}", templar, mock_loader, convert_bare=True) == ["{{ foo }}"]
    assert listify_lookup_plugin_terms("{{ foo }}", templar, mock_loader) == ["{{ foo }}"]

    # do not convert a jinja2 var to a list of one element
    assert listify_lookup_plugin_terms("{% foo %}", templar, mock_loader, convert_bare=True) == ["{% foo %}"]

# Generated at 2022-06-21 08:51:08.483943
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.inventory.host import Host
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from io import StringIO

    # some basic data to use for lookups
    vars = VariableManager()
    vars.set_host_variable(Host(name='testhost'), 'testvar', 'testvalue')
    vars.set_host_variable(Host(name='testhost'), 'testvar2', ['testvalue1', 'testvalue2'])
    vars.set_host_variable(Host(name='testhost'), 'testvar3', 'testvalue1:testvalue2')
    loader = DataLoader()

    # create a Templar that will use this data

# Generated at 2022-06-21 08:51:17.775178
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert listify_lookup_plugin_terms('1', Templar({}, {}, loader=None), None) == ['1']
    assert listify_lookup_plugin_terms(['1'], Templar({}, {}, loader=None), None) == ['1']
    assert listify_lookup_plugin_terms(['1', '2'], Templar({}, {}, loader=None), None) == ['1', '2']
    assert listify_lookup_plugin_terms('[1, 2]', Templar({}, {}, loader=None), None) ==  ['[1, 2]']
    assert listify_lookup_plugin_terms('{{ myvar }}', Templar(dict(myvar='[1, 2]'), {}, loader=None), None) ==  ['[1, 2]']
    assert list

# Generated at 2022-06-21 08:51:29.440740
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(None, 'dummy', True)
    from ansible.template import Templar
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('a string', templar, loader) == ['a string']
    assert listify_lookup_plugin_terms(['a', 'list'], templar, loader) == ['a', 'list']
    assert listify_lookup_plugin_terms(1234, templar, loader) == [1234]

    assert listify_lookup_plugin_terms(['a', 'string', ['with', 'list'], 1234], templar, loader) == ['a', 'string', ['with', 'list'], 1234]

# Generated at 2022-06-21 08:51:38.675638
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(1, None, None) == [1]
    assert listify_lookup_plugin_terms([1], None, None) == [1]
    assert listify_lookup_plugin_terms('{{ lookup("vars", "var_name") }}', None, None) == ['{{ lookup("vars", "var_name") }}']
    assert listify_lookup_plugin_terms([{'k': 'v'}], None, None) == [{'k': 'v'}]



# Generated at 2022-06-21 08:51:50.377843
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # test 1
    terms = listify_lookup_plugin_terms('foo', Templar(VariableManager()), None)
    assert terms == ['foo']

    # test 2
    terms = listify_lookup_plugin_terms(1, Templar(VariableManager()), None)
    assert terms == [1]

    # test 3
    terms = listify_lookup_plugin_terms(['foo'], Templar(VariableManager()), None)
    assert terms == ['foo']

    # test 4

# Generated at 2022-06-21 08:52:00.318491
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    vault_password = 'vault_password'

    loader = DataLoader()
    templar = Templar(loader=loader, vault_passwords=[vault_password])
    vl = VaultLib(password_files=[vault_password])

    assert listify_lookup_plugin_terms("a", templar, loader) == ["a"]
    assert listify_lookup_plugin_terms(["a", "b", "c"], templar, loader) == ["a", "b", "c"]
    assert listify_lookup_plugin_terms("{{ d }}", templar, loader) == ["d"]
    assert listify_lookup_plugin_

# Generated at 2022-06-21 08:52:25.280893
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib

    templar = Templar(loader=None, shared_loader_obj=None, variables={})

    data = dict(
        a1=dict(
            b1=dict(
                c1=[1, 3, 7]
            )
        )
    )

    def assert_result(terms, expected):
        terms = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
        assert terms == expected

    # Test strings
    assert_result('a', ['a'])

# Generated at 2022-06-21 08:52:36.585160
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    test_list = [u'one', u'two', u'three', [u'four', u'five']]
    assert listify_lookup_plugin_terms(test_list, None, None)==test_list

    test_string = u'one, two, three, "four, five"'
    assert listify_lookup_plugin_terms(test_string, None, None)==[u'one', u'two', u'three', u'four, five']

    test_string = u'one, two, three, "four five"'
    assert listify_lookup_plugin_terms(test_string, None, None)==[u'one', u'two', u'three', u'four five']

    test_string = u'one two three "four five"'
    assert listify_lookup_plugin

# Generated at 2022-06-21 08:52:47.268989
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms(templar, loader=None, terms=['a', 'b', 'c']) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms(templar, loader=None, terms='d') == ['d']
    assert listify_lookup_plugin_terms(templar, loader=None, terms='a,b,c') == ['a,b,c']
    assert listify_lookup_plugin_terms(templar, loader=None, terms=['a,b,c']) == ['a,b,c']

# Generated at 2022-06-21 08:52:53.037435
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager._extra_vars = {'a': 'b'}

    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('a', templar, loader, fail_on_undefined=False) == ['b']
    assert listify_lookup_plugin_terms('a', templar, loader, fail_on_undefined=True) == ['b']
    assert listify_lookup_plugin_terms('c', templar, loader, fail_on_undefined=False) == ['c']

# Generated at 2022-06-21 08:53:04.108777
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars import VariableManager

    terms = [
        dict(
            terms=dict(
                one=['one', '1'],
                two=[2],
                three=['3', 'three'],
            ),
            results=[
                'one',
                '1',
                '2',
                '3',
                'three',
            ],
        ),
        dict(
            terms=['one', ['one', '1'], ['2'], ['3', 'three']],
            results=[
                'one',
                'one',
                '1',
                '2',
                '3',
                'three',
            ],
        ),
    ]


# Generated at 2022-06-21 08:53:11.147857
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    #from ansible.utils.display import Display

    #args = {'connection': 'local', 'module_name': None, 'module_args': '', 'module_path': None, '_ansible_socket_path': None, 'forks': 5, 'remote_user': None, 'private_key_file': None, 'ssh_common_args': '', 'ssh_extra_args': '', 'sftp_extra_args': '', 'scp_extra_args': '', 'become': True, 'become_method': None, 'become_user': None, 'verbosity': False, 'check': 'False',

# Generated at 2022-06-21 08:53:21.608139
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    def _do_test(terms, templar, desired):
        assert listify_lookup_plugin_terms(terms, templar) == desired

    templar = Templar(loader=None)

    _do_test('foo', templar, ['foo'])
    _do_test(['foo'], templar, ['foo'])
    _do_test(('foo',  'bar'), templar, ['foo', 'bar'])
    _do_test({'foo': 'bar'}, templar, [{'foo': 'bar'}])
    _do_test('    foo    ', templar, ['foo'])

    result = _do_test('{{ foo }}', templar, ['{{ foo }}'])
    assert result != '{{ foo }}'

# Generated at 2022-06-21 08:53:30.385069
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Make sure the function can convert a string to a list
    assert listify_lookup_plugin_terms('{{var}}', object(), object()) == ['{{var}}']

    # Make sure the function can convert an iterable to a list
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], object(), object()) == ['a', 'b', 'c']

    # Make sure the function can convert a non iterable to a list
    assert listify_lookup_plugin_terms('a', object(), object()) == ['a']

# Generated at 2022-06-21 08:53:42.256386
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Before any class are initialized, we need to setup a few things
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../test/runner/'))
    from jinja2 import DictLoader, Environment

    loader = DictLoader({
                    'test.j2': '{{a}},{{b}}'
                })
    env = Environment(loader=loader)
    env.filters['quote'] = lambda x: '"%s"' % x
    env.filters['to_yaml'] = lambda data: '\n'.join(data)

    from ansible import constants as C
    C.DEFAULT_HASH_BEHAVIOUR = 'merge'

    from ansible.vars import VariableManager


# Generated at 2022-06-21 08:53:45.866335
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # Imports needed for the vault examples below
    from ansible.errors import AnsibleError
    from ansible.parsing.vault import VaultSecret

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Test simple string value
    terms = "example"
    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['example']

    # Test simple string value with extra whitespace, also tests trimming of whitespace
    terms = "  example  "
    templar = Templar(loader=None, variables={})

# Generated at 2022-06-21 08:54:24.006853
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # Needed for templating
    fake_loader = DictDataLoader({})
    fake_loader.set_basedir('/')
    fake_vars = dict(a='foo.bar', b='{{ a }}')

    vault = VaultLib([])
    templar = Templar(loader=fake_loader, variables=fake_vars, vault_secrets=dict(vault_password='foobar'))

    # If a bare string is passed, it should be converted to a list
    # and templated
    facts = DistributionFactCollector()

# Generated at 2022-06-21 08:54:32.468835
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.utils.yaml import from_yaml
    from ansible.utils.template import Templar
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    base_dir = '/home/juan/ansible/lookup_plugins'

    terms = '''
        {{ var1 }}
        {{ [var2] }}
        {{ [ var3, var4 ] }}
        {{ 'var5' }}
        {{ ['var6', 'var7'] }}
    '''


# Generated at 2022-06-21 08:54:42.396708
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = u'{{var1}}'
    templar = Templar(loader=None, variables=dict(var1='foo'))
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo']

    terms = [u'{{var1}}']
    templar = Templar(loader=None, variables=dict(var1='foo'))
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo']

    terms = [u'{{var1}}', u'{{var2}}']
    templar = Templar(loader=None, variables=dict(var1='foo', var2='bar'))
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo', 'bar']

# Generated at 2022-06-21 08:54:52.569815
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Ensure that listify_lookup_plugin_terms returns a list of one or
    # more strings, when the term(s) are already string(s).

    # single term, already string
    assert listify_lookup_plugin_terms('term', None, None) == ['term']

    # multiple terms, already strings
    assert listify_lookup_plugin_terms(['term1','term2','term3'], None, None) == ['term1','term2','term3']

    # multiple terms, first term is not string
    assert lisify_lookup_plugin_terms([['term1'],'term2','term3'], None, None) == [['term1'],'term2','term3']


    # Ensure that listify_lookup_plugin_terms returns a list of one or
    # more strings, when the term

# Generated at 2022-06-21 08:55:01.707193
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      fail_on_undefined=True)

    assert listify_lookup_plugin_terms([1,2,3], templar, loader) == [1,2,3]

# Generated at 2022-06-21 08:55:12.883998
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test that passing a string value in with a trailing newline will
    # return a query list with a stripped string
    terms = "some/query/with/a/newline\n"
    terms_list = listify_lookup_plugin_terms(terms, templar, loader)
    if len(terms_list) != 1 or terms_list[0] != 'some/query/with/a/newline':
        raise AssertionError("listify_lookup_plugin_terms(string) failed")

    # Test that passing a list of strings returns the same list

# Generated at 2022-06-21 08:55:24.763928
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    facts = dict(
        foo='baz',
        bar=None,
        foobar_list=['foo', 'bar', 'baz'],
        foobar_list_item='baz',
    )

    assert listify_lookup_plugin_terms('foo', templar, loader=None, fail_on_undefined=False) == ['baz']
    assert listify_lookup_plugin_terms('bar', templar, loader=None, fail_on_undefined=False) == [None]
    assert listify_lookup_plugin_terms('bar', templar, loader=None, fail_on_undefined=True) == ['bar']

# Generated at 2022-06-21 08:55:36.156994
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    # make sure we can handle a string
    terms = listify_lookup_plugin_terms('foo', 'bar')

    # Make sure a list is returned
    assert isinstance(terms, list)

    # Make sure the list doesn't have the 'bar' variable
    # and that it has our variable 'foo'
    assert not 'bar' in terms
    assert 'foo' in terms

    # Make sure we can join a list together
    terms = listify_lookup_plugin_terms(['foo','bar'], 'baz')

    # Make sure a list is returned
    assert isinstance(terms, list)

    # Make sure the list doesn't have the 'bar' variable
    # and that it has our variable 'foo'
    assert not 'baz' in terms
    assert 'foo' in terms