

# Generated at 2022-06-21 08:45:39.938905
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = lookup_loader
    templar = Templar(loader=loader)
    variable_manager = VariableManager()


# Generated at 2022-06-21 08:45:49.400784
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VarsModule

    # FIXME: Add tests for fail_on_undefined=True
    # FIXME: Add test for convert_bare=True

    templar = Templar(loader=DataLoader())

    def _test(terms):
        terms_1 = listify_lookup_plugin_terms(terms, templar, loader)
        terms_2 = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False)
        assert terms_1 == terms_2


# Generated at 2022-06-21 08:46:00.337922
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    my_vars = combine_vars(loader=None, variables=dict(a=1, b=2))
    templar = Templar(loader=None, variables=my_vars)

    terms = '{{a}} {{c}}'
    terms = templar.template(terms, fail_on_undefined=True)
    assert terms == {'a': 1, 'c': None}, terms

    terms = '{{a}} {{c}}'

# Generated at 2022-06-21 08:46:12.117503
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 08:46:21.132351
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    ansible.utils.listify_lookup_plugin_terms test cases
    '''
    # Test with string
    assert listify_lookup_plugin_terms('str', None, None) == ['str']

    # Testing with list of string
    assert listify_lookup_plugin_terms(['str1','str2'], None, None) == ['str1','str2']

    # Test with list containing int
    assert listify_lookup_plugin_terms(['str1', 2, 'str3'], None, None) == ['str1', 2, 'str3']

    # Test with dict
    assert listify_lookup_plugin_terms({'key': 'value'}, None, None) == [{'key': 'value'}]

    # Test with int
    assert listify_lookup_plugin

# Generated at 2022-06-21 08:46:31.544783
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-21 08:46:43.530239
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.parsing.utils.addresses import parse_address
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    host = Host(name='test host name', port=9876, variables={'testVarName': ['testVarValue']})
    group = Group('test group name')
    group.add_host(host)

    loader = None
    templar = Templar(loader=loader)
    inventory = InventoryManager(loader=loader, sources=[])
    inventory.add_group(group)
    templar._inventory = inventory


# Generated at 2022-06-21 08:46:53.543382
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    tdict = {'a': '1', 'b': '2', 'c': '3'}
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSensitive
    from ansible.template.template import Templar
    templar = Templar(loader=None)

    # simple string
    terms = listify_lookup_plugin_terms('[1]', templar)
    assert(terms == ['1'])

    # simple list
    terms = listify_lookup_plugin_terms(['1'], templar)
    assert(terms == ['1'])

    # simple dict
    terms = listify_lookup_plugin_terms({'1': '2'}, templar)

# Generated at 2022-06-21 08:47:04.581385
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-21 08:47:15.619306
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # When value is non-string
    # When value is list
    # When value is comma-separated string
    # When value is comma-separated string with spaces
    # When value is comma-separated string with one item
    # When value is comma-separated string with nested commas
    # When value is comma-separated string with spaces and nested commas

    # When value is AnsibleUnsafeText
    # When value is list
    # When value is comma-separated string
    # When value is comma-separated string with spaces
    # When value is comma-separated string with one item
    # When value is comma-separated string with nested commas
    # When value is comma-separated string with spaces and nested commas
    pass

# Generated at 2022-06-21 08:47:28.702260
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import string_types

    vars = {'a': 'b', 'c': [1,2,3]}
    templar = Templar(loader=None, variables=vars)

    result = listify_lookup_plugin_terms('{{a}}', templar, None)
    assert isinstance(result, list)
    result = result[0]
    assert isinstance(result, string_types)
    assert result == 'b'

    result = listify_lookup_plugin_terms(['{{a}}', '{{c}}'], templar, None)
    assert isinstance(result, list)

# Generated at 2022-06-21 08:47:41.119079
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    class DummyVarsModule:
        def __init__(self, value):
            self.value = value

        def vars(self):
            return [self.value]

    # use a dummy variable manager that just returns the variable
    # passed in to its constructor (as a list)
    variable_manager = DummyVarsModule

    loader = DataLoader()
    var_manager = variable_manager(42)
    templar = Templar(loader=loader, variables=var_manager)

    assert listify_lookup_plugin_terms(1, templar, loader, fail_on_undefined=True, convert_bare=False) == [1]

# Generated at 2022-06-21 08:47:52.258212
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import pytest
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.module_utils._text import to_text

    def _get_templar(inventory):
        variable_manager = VariableManager()
        variable_manager.set_inventory(inventory)
        loader = None
        play_context = PlayContext()

        return Templar(loader=loader, variables=variable_manager, play_context=play_context)


# Generated at 2022-06-21 08:47:59.586926
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_text

    class DummyVaultSecret:
        def __init__(self, password):
            self.password = password

        def decrypt(self, b_data):
            return self.password.encode('utf-8')

    loader = AnsibleLoader(None, vault_secret=DummyVaultSecret('secret'))
    templar = Templar(loader=loader, shared_loader_obj=loader, vault_secrets=['secret'])

    # Basic test where terms are only a string
    terms = 'foo'

# Generated at 2022-06-21 08:48:04.377559
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar, DictData
    templar = Templar(loader=None, variables=DictData({'x': [1, 2, 3]}))
    results = listify_lookup_plugin_terms('foo', templar)
    assert results == ['foo'], results

    results = listify_lookup_plugin_terms(['foo'], templar)
    assert results == ['foo'], results

    results = listify_lookup_plugin_terms('{{ x }}', templar)
    assert results == [1, 2, 3], results

    results = templar.template({'a': 5, 'b': '{{ x }}'}, fail_on_undefined=False)
    assert results == {'a': 5, 'b': [1, 2, 3]}, res

# Generated at 2022-06-21 08:48:12.294805
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'my_var': 'a'})

    # Input is a string, ansible.template.Templar.template should be called and return an array.
    # The string is a valid template.
    terms = '{{ my_var }}'
    assert listify_lookup_plugin_terms(terms, templar, None, True, False) == ['a']

    # Input is a string, ansible.template.Templar.template should be called and return an array.
    # The string is not a template.
    terms = 'a'
    assert listify_lookup_plugin_terms(terms, templar, None, True, False) == ['a']

    # Input is a list, ansible.template.Templar.template should be

# Generated at 2022-06-21 08:48:21.568296
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class DummyVars(object):
        def __init__(self):
            self.hostvars = dict()

    vars = DummyVars()
    loader = None
    templar = Templar(loader=loader, variables=vars)

    assert listify_lookup_plugin_terms(dict(), templar, loader) == [{}]
    assert listify_lookup_plugin_terms(None, templar, loader) == [None]
    assert listify_lookup_plugin_terms([None], templar, loader) == [None]
    assert listify_lookup_plugin_terms([10, 20], templar, loader) == [10, 20]

# Generated at 2022-06-21 08:48:32.856710
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    try:
        from ansible.template import Templar
        from ansible.utils.template import combine_vars
        _ = Templar(loader=None, variables=combine_vars(dict(), {}))
    except ImportError:
        # Older versions of Ansible (< 2.5) do not have the combine_vars function, so just don't run the test
        return

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    assert listify_lookup_plugin_terms('', _, loader) == []
    assert listify_lookup_plugin_terms(42, _, loader) == [42]
    assert listify_lookup_plugin_terms('{{ foo }}', _, loader) == []

# Generated at 2022-06-21 08:48:42.673169
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms_list = ('{{ foo }}',
                  ['{{ foo }}', '{{ bar }}'],
                  [('{{ foo }}', '{{ bar }}'), ('{{ baz }}', '{{ meow }}')],
                  [('{{ foo }}', '{{ bar }}'), ['{{ baz }}', '{{ meow }}']],
                  ['{{ foo }}', ('{{ bar }}', '{{ baz }}')])

    def _is_result_valid(template_result, template_result_flat):

        # Result types
        result_type_list = isinstance(template_result, (list, tuple))
        result_type_flat = isinstance(template_result_flat, (list, tuple))

        # Test if result types are valid
        if not (result_type_list or result_type_flat):
            return

# Generated at 2022-06-21 08:48:55.371703
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import PY2
    from ansible.template import Templar
    from ansible.template import AnsibleEnvironment

    env = AnsibleEnvironment([], None)
    t = Templar(loader=env)

    # Boolean
    assert listify_lookup_plugin_terms([True], templar=t, loader=env) == [True]
    assert listify_lookup_plugin_terms(True, templar=t, loader=env) == [True]

    # Builtins
    assert listify_lookup_plugin_terms(None, templar=t, loader=env) == ['None']
    assert listify_lookup_plugin_terms([None], templar=t, loader=env) == ['None']

    # Bytes

# Generated at 2022-06-21 08:49:06.910227
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # test basic list
    assert(listify_lookup_plugin_terms(['a', 'b', 'c'], None, None) == ['a', 'b', 'c'])

    # test string
    assert(listify_lookup_plugin_terms("a", None, None) == ['a'])
    assert(listify_lookup_plugin_terms("a,b,c", None, None) == ['a,b,c'])

    # test no args
    assert(listify_lookup_plugin_terms(None, None, None) == [])

# Generated at 2022-06-21 08:49:18.784527
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeVarsModule:
        pass
    class Faketemplar:
        def __init__(self):
            self.vars_module = FakeVarsModule()

        def template(self, terms, fail_on_undefined=True):
            self.vars_module.ansible_version = '2.0'
            return terms

    fake_terms = Faketemplar()
    loader = 'foobar'

    # Test 1: string
    result = listify_lookup_plugin_terms('foo', fake_terms, loader)
    assert isinstance(result, list)
    assert result == ['foo']

    # Test 2: list
    result = listify_lookup_plugin_terms(['foo', 'bar'], fake_terms, loader)
    assert isinstance(result, list)

# Generated at 2022-06-21 08:49:31.624422
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({
        "/tmp/listify_this_single.yml": """
- one
- two
- three
"""
    })

    vault_secrets = {'vault_password': 'secret'}
    variables = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["/tmp/test_inventory"])
    play_context = PlayContext(vault_password=VaultLib(vault_secrets))

# Generated at 2022-06-21 08:49:42.567474
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import tempfile
    from jinja2 import DictLoader
    from ansible.template import Templar
    ds = DictLoader({'test_template': '{{ ",".join(terms) }}'})
    templar = Templar(ds)
    terms = ['one','two','three','four','five','six','seven','eight','nine','ten']
    #Test string
    assert listify_lookup_plugin_terms('one,two,three', templar, ds) == terms
    #Test boolean
    assert listify_lookup_plugin_terms(True, templar, ds) == ['True']
    #Test list
    assert listify_lookup_plugin_terms(terms, templar, ds) == terms


# Generated at 2022-06-21 08:49:52.722262
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    role = Role()
    task = Block()
    task.role = role

    # u''
    templar = Templar(loader=loader, variables={'var': u'foo'})
    terms = listify_lookup_plugin_terms(u'{{var}}', templar, loader)
    assert terms == ['foo']

    # u'string'
    templar = Templar(loader=loader, variables={'var': u'foo'})
    terms = listify_lookup_plugin_terms(u'foo', templar, loader)
    assert terms == ['foo']



# Generated at 2022-06-21 08:50:01.648392
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = DictDataLoader({'pass_through': '{{test.val}}'})
    templar = Templar(loader=loader)

    # Test listify_lookup_plugin_terms with bare strings (example: for lookup('env','HOME') )
    # Test listify_lookup_plugin_terms with bare strings (example: for lookup('env','HOME') )
    # Test listify_lookup_plugin_terms with non-bare strings that contain jinja2 templating
    # Test listify_lookup_plugin_terms with non-bare strings that contain jinja2 templating
    # Test listify_lookup_plugin_terms with lists (example: for lookup('file', '/path/to/some/file') )
    # Test listify_lookup_plugin_terms with lists (

# Generated at 2022-06-21 08:50:06.389611
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = "{{ hostvars['localhost']['version'] }} {{ lookup('env','HOME') }}"

    templar = Templar(loader=None)
    result = listify_lookup_plugin_terms(terms, templar, loader=None)

# Generated at 2022-06-21 08:50:18.181660
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)


    ################################################################################
    # single element list

    assert ['foo'] == listify_lookup_plugin_terms(['foo'], templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert ['foo'] == listify_lookup_plugin_terms('foo', templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert ['foo'] == listify_lookup_plugin_terms('foo ', templar, loader=None, fail_on_undefined=True, convert_bare=False)

# Generated at 2022-06-21 08:50:28.923453
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms(42, templar, None) == [42]
    assert listify_lookup_plugin_terms([42], templar, None) == [42]
    assert listify_lookup_plugin_terms('42', templar, None) == ['42']
    assert listify_lookup_plugin_terms('42', templar, None, convert_bare=True) == [42]
    assert listify_lookup_plugin_terms([42, '42'], templar, None) == [42, '42']
    assert listify_lookup_plugin_terms([42, '42'], templar, None, convert_bare=True) == [42, 42]


# Generated at 2022-06-21 08:50:41.011815
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    my_vars = dict(
        a=['x', 'y', 'z']
    )

    loader = DataLoader()
    templar = Templar(loader=loader, variables=my_vars)
    # Test with list.
    terms = [1, 2, 3]
    assert [1, 2, 3] == listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)
    # Test with dict.
    terms = dict(a=1, b=2)
    assert terms == listify_lookup_plugin_terms(terms, templar, loader)
    # Test with string.
    terms = 'hello world'
    assert ['hello world'] == listify_

# Generated at 2022-06-21 08:50:55.302387
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms(['a', 'b'], Templar({}, 'file.txt'), None) == ['a', 'b']
    assert listify_lookup_plugin_terms(['a', '{{b}}'], Templar({'b': 'X'}, 'file.txt'), None) == ['a', 'X']
    assert listify_lookup_plugin_terms(' {{ a }}, {{b}} ', Templar({'a': 'A', 'b': 'B'}, 'file.txt'), None) == ['A', 'B']
    assert listify_lookup_plugin_terms(' {{ a }}', Templar({'a': 'A'}, 'file.txt'), None) == ['A']

# Generated at 2022-06-21 08:51:05.484926
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = ansible.template.Templar(loader=AnsibleLoader(None))

    # test string
    terms = "{{ foo }}"
    terms = listify_lookup_plugin_terms(terms, templar, AnsibleLoader(None))
    assert terms == ['{{ foo }}'], terms

    # test list
    terms = ['one', 'two', 'three']
    terms = listify_lookup_plugin_terms(terms, templar, AnsibleLoader(None))
    assert terms == ['one', 'two', 'three'], terms

    # test dict

# Generated at 2022-06-21 08:51:16.597941
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class DummyVarsModule:
        def __init__(self, data):
            self.data = data
        def get_vars(self, loader, path, entities):
            return self.data

    # the default jinja2 / ansible configuration
    #  ansible.constants.DEFAULT_JINJA2_NATIVE = False
    templar = Templar(loader=None, variables=DummyVarsModule({}))

    # bare strings are untouched, even if they contain commas
    assert listify_lookup_plugin_terms("abc,def", templar, None, convert_bare=False) == ['abc,def']

    # bare strings are split if convert_bare=True

# Generated at 2022-06-21 08:51:28.562301
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.set_fact_cache({})
    templar = Templar(loader=loader, variables=variable_manager)

    # string case, no templating
    terms = listify_lookup_plugin_terms('localhost', templar, loader)
    assert terms == ['localhost'], terms

    # string case, templating
    terms = listify_lookup_plugin_terms('localhost', templar, loader, convert_bare=True)
    assert terms == ['localhost'], terms

    # list case, no templating
    terms = listify_lookup_plugin_terms(['localhost', '127.0.0.1'], templar, loader)

# Generated at 2022-06-21 08:51:41.152986
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    terms = AnsibleUnicode('BEGIN\n'
                           '- foo\n'
                           '- bar\n'
                           '- baz\n'
                           'END')

    templar = Templar(loader=AnsibleLoader(None))
    assert(listify_lookup_plugin_terms(terms, templar, None) == ['foo', 'bar', 'baz'])

    terms = AnsibleUnicode('- foo\n'
                           '- bar\n'
                           '- baz\n')

    templar = Templar(loader=AnsibleLoader(None))

# Generated at 2022-06-21 08:51:53.639144
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.template import Templar

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars

    from ansible.vars import VariableManager

    from ansible.parsing.dataloader import DataLoader

    yaml_str = """
    foo:
     - bar
     - bam
     - baz
    """

    loader = DataLoader()
    loader.set_vault_secrets(dict(vault_password='vault_password'))

    templar = Templar(loader=loader)

    import sys


# Generated at 2022-06-21 08:51:55.006284
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-21 08:52:02.564614
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    terms1 = ['a', 'b', 'c']
    terms2 = '{{ item }}'

    templar = Templar(loader=None, variables={'item': ['d', 'e', 'f']})
    templar2 = Templar(loader=None, variables={'item': ['g'], 'other': 'thing'})

    assert listify_lookup_plugin_terms(terms1, templar, [], True) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms(terms2, templar, [], True) == ['d', 'e', 'f']

# Generated at 2022-06-21 08:52:02.910710
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-21 08:52:06.378695
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.listify import listify_lookup_plugin_terms
    assert [u"1", u"2", u"3"] == listify_lookup_plugin_terms(["{{ 1|int }}", "{{ 2 }}", u"3"], templar=None, loader=None, fail_on_undefined=True, convert_bare=False)
    assert u"1" == listify_lookup_plugin_terms(u"{{ 1|int }}", templar=None, loader=None, fail_on_undefined=True, convert_bare=False)

# Generated at 2022-06-21 08:52:31.696726
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.common._collections_compat import AreaDataDict

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    loader = DictDataLoader({
        'group_vars/my_group/foo': 'hi',
    })

    templar = Templar(loader=loader, variables={}, shared_loader_obj=None)


# Generated at 2022-06-21 08:52:42.401444
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(None, ':memory:')
    templar = Templar(loader=loader, variables={'foo': 'bar'})

    assert listify_lookup_plugin_terms([1, 2, 'baz', {'bat': 'batman'}], templar, loader) == [1, 2, 'baz', {'bat': 'batman'}]
    assert listify_lookup_plugin_terms([1, 2, '{{foo}}'], templar, loader) == [1, 2, 'bar']
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

# Generated at 2022-06-21 08:52:51.169181
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating.template import Templar

    class FakeVarsModule(object):
        def get_vars(self, loader, play=None, include_hostvars=False):
            return dict()

    class FakeLoader(object):
        def __init__(self):
            self.vars = FakeVarsModule()

    templar = Templar(loader=FakeLoader(), variables={})

    items = listify_lookup_plugin_terms('item1', templar, FakeLoader(), True)
    assert(isinstance(items, list))
    assert(len(items) == 1)
    assert(items[0] == 'item1')
    items = listify_lookup_plugin_terms(['item2'], templar, FakeLoader(), True)
    assert(isinstance(items, list))

# Generated at 2022-06-21 08:53:02.888603
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from pprint import pprint

    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    terms = '{{ [ "bar", 1 ] }}'
    pprint(listify_lookup_plugin_terms(terms, templar, loader))

    terms = [ 'foo', '{{ [ "bar", 1 ] }}', 'foobar' ]

# Generated at 2022-06-21 08:53:12.991161
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec=dict(test=dict()))

    # Currently this test is doing a lot of things, but it would be
    # nice to break each of these tests out into their own individual
    # test cases
    assert listify_lookup_plugin_terms('foo', m.params['test'], dict(convert_bare=True, fail_on_undefined=False), [m.params['test']]) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'hello'], m.params['test'], dict(convert_bare=True, fail_on_undefined=False), [m.params['test']]) == ['foo', 'hello']

# Generated at 2022-06-21 08:53:19.552953
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager

    # Initialize Templar
    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()

    # This is a list of input values and their corresponding expected results for the test.

# Generated at 2022-06-21 08:53:25.838162
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Basic test
    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']

    # Test with an empty string
    assert listify_lookup_plugin_terms('', None, None) == ['']

    # Test with a list
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None) == ['foo', 'bar']

    # Test with an integer
    assert listify_lookup_plugin_terms(1, None, None) == [1]

# Generated at 2022-06-21 08:53:31.776491
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    tests = [
        ('foo', "foo"),
        (["foo","bar"], ["foo","bar"]),
        ('{{ foo }}', {"foo": "bar"}, ["bar"]),
        ('{{ item }}', {"item": "one"}, ["one"]),
        ('{{ item }}', [{"item": "one"}, {"item": "two"}], ["one", "two"]),
        ('{{ item }}', ['one', 'two'], ['one', 'two']),
        ('{{ item }}', {'one': 'two'}, ['one']),
    ]

    t = Templar()
    for (test, vars, expected) in tests:
        assert expected == listify_lookup_plugin_terms(test, t, None, convert_bare=True)


# Generated at 2022-06-21 08:53:43.724979
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = DictDataLoader({
        'unittest.j2': """
{% if 'a' in test_list -%}
test_list is a list
{% else -%}
test_list is not a list
{% endif -%}
""",
    })
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('a', templar) == ['a']
    assert listify_lookup_plugin_terms(['a'], templar) == ['a']
    assert listify_lookup_plugin_terms(templar.template('a', convert_bare=True), templar) == ['a']

# Generated at 2022-06-21 08:53:53.266374
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Can be removed when Ansible 2.9 becomes the minimum version
    class FakeVaultSecret:
        def __init__(self, contents):
            self.contents = contents

    class FakeVaultApi:
        def read(self, path):
            return FakeVaultSecret(path)

    def fake_load_vault_file(loader, filename):
        return {
            'password': 'hunter2',
            'secret_file': 'some.txt',
        }

    class FakeLoader:
        class FakeVarsModule:
            def __init__(self):
                 self.host_vars = {}
                 self.group_vars = {}


# Generated at 2022-06-21 08:54:28.024979
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    vm = VariableManager()
    loader = AnsibleLoader(OrderedDict())
    terms = listify_lookup_plugin_terms(loader.load("""
        - /path/to/file1
        - /path/to/file2
    """)[0], Templar(loader=loader, variables=vm), loader)
    assert terms == ['/path/to/file1', '/path/to/file2']

    terms = listify_lookup_plugin_terms("/path/to/file", Templar(loader=loader, variables=vm), loader)

# Generated at 2022-06-21 08:54:35.102226
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    class MockOptions(object):
        def __init__(self):
            self.private_key_file = None
            self.connection_user = ''
            self.remote_user = ''
            self.inventory = None
            self.local_tmp = '/tmp'
            self.module_name = None
            self.module_paths = None
            self.timeout = 10

    class MockTemplar(Templar):
        def __init__(self, loader, variables):
            self._loader = loader
            self.variables = variables
            self._fail_on_undefined = True


# Generated at 2022-06-21 08:54:43.613715
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # need a mock class that contains the basic methods of a Template() object in order to
    # get this unit test to work.  I'm not sure what the right way to mock this class is
    # so there may be a better way
    class MockTemplate:
        def __init__(self):
            self.convert_bare_variable = None
            self.fail_on_undefined = True

        def template(self, terms, **kwargs):
            self.convert_bare_variable = kwargs.get('convert_bare', False)
            self.fail_on_undefined = kwargs.get('fail_on_undefined', True)
            return terms

    # initialize a mock Template object
    templar = MockTemplate()

    # test that string type terms get returned as a list
    terms = 'test1'
   

# Generated at 2022-06-21 08:54:53.719417
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = dict(
        a_string="a_string",
        a_list=[1, 2, 3],
    )

    def test_template(template, fail_on_undefined=True, convert_bare=False):
        # these args are not used, so we stub them out
        if isinstance(template, list):
            template = template[0]
        return template

    t = Templar(loader=None, variables=data)
    t.template = test_template

    assert listify_lookup_plugin_terms("a_string", t, None) == ["a_string"]
    assert listify_lookup_plugin_terms("a_string", t, None, fail_on_undefined=False)

# Generated at 2022-06-21 08:55:03.002801
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    h = Host('foobar')
    g = Group('foobar')

    t = Templar(loader=None, variables={'name': 'one'})

    # Verify it only accepts other iterable types
    assert listify_lookup_plugin_terms(h, t, None) == [h]
    assert listify_lookup_plugin_terms(g, t, None) == [g]
    assert listify_lookup_plugin_terms(1, t, None) == [1]
    assert listify_lookup_plugin_terms(['one'], t, None) == ['one']
    assert listify

# Generated at 2022-06-21 08:55:14.241036
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import ansible.template
    templar = ansible.template.Templar()
    terms = ['{{ var1 }}', '{{ var2 }}']
    templar.set_available_variables(dict(var1='foo', var2='bar'))
    assert listify_lookup_plugin_terms(terms, templar) == ['foo', 'bar']

    terms = '{{ var1 }},{{ var2 }}'
    templar.set_available_variables(dict(var1='foo', var2='bar'))
    assert listify_lookup

# Generated at 2022-06-21 08:55:26.094866
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class DummyVars(object):
        def get(self, key, default=None):
            return default

    class DummyLoader(object):
        def get_basedir(self, path):
            return "/path/to/file"

    class DummyTemplar(object):
        def __init__(self, basedir, vars):
            self._basedir = basedir
            self._available_variables = vars

        def template(self, terms, fail_on_undefined=True, convert_bare=False):
            return terms

    terms = '{{ terms }}'
    templar = DummyTemplar("/path/to/file", DummyVars())
    loader = DummyLoader()


# Generated at 2022-06-21 08:55:31.286207
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.module_utils.common.collections import is_iterable

    import ansible.template

    terms = listify_lookup_plugin_terms(
        terms="{{foo[0]}} {{bar}} {{item.x}} {{item.y}}",
        templar=ansible.template.AnsibleSafeTemplate,
        loader=ansible.template.AnsibleTemplateError
    )

    assert isinstance(terms, list)