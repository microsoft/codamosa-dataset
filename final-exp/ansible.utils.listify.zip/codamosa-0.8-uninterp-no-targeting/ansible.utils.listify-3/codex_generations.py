

# Generated at 2022-06-21 08:45:37.598321
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    import ansible.template.template
    t = Templar(None, variables={})

    assert listify_lookup_plugin_terms(['a', 'b', 'c'], t, None) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms(['a', 'b', 5], t, None) == ['a', 'b', 5]
    assert listify_lookup_plugin_terms('a', t, None) == ['a']
    assert listify_lookup_plugin_terms(5, t, None) == [5]
    assert listify_lookup_plugin_terms(None, t, None) == [None]

# Generated at 2022-06-21 08:45:45.243465
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())

    # string_type
    assert listify_lookup_plugin_terms('foo', templar=templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms('foo, bar', templar=templar, loader=None) == ['foo, bar']

    # list type
    assert listify_lookup_plugin_terms(['foo'], templar=templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar=templar, loader=None) == ['foo', 'bar']

    # templated
    assert listify_

# Generated at 2022-06-21 08:45:55.680807
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string case
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list case
    terms = ['foo', 'bar', 'baz']
    assert listify_lookup_plugin_terms(terms, templar, loader) == terms

    # Test list and return value types
    terms = ['foo', 'bar', 'baz']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert len(terms) == len(result)

    for term, result_term in zip(terms, result):
        assert type(term) == type

# Generated at 2022-06-21 08:46:04.112342
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    templar = DummyVars({"bar":"foo", "baz":"xyz"})
    terms = listify_lookup_plugin_terms(["{{bar}}", "{{baz}}"], templar, None)
    assert terms == ["foo", "xyz"]

    templar = DummyVars({"foo":"bar"})
    terms = listify_lookup_plugin_terms(terms="{{foo}}", templar=templar, loader=None)
    assert terms == ['bar']

    templar = DummyVars({"foo":"bar"})
    terms = listify_lookup_plugin_terms(terms="{{foo}}", templar=templar, loader=None, convert_bare=True)
    assert terms == ['bar']

    # FIXME: I don't think this behavior is

# Generated at 2022-06-21 08:46:15.369273
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar, DictData
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.vars import combine_vars

    templar = Templar(loader=None)

    # Dummy class for testing purposes
    class MyVars(AnsibleBaseYAMLObject):
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

    my_vars = MyVars("MyVars")

    class FakeVarsModule:
        def get_vars(self, loader, path, entities):
            return my_vars

    class FakeLoader:
        def get_basedir(self):
            return "/basedir"

    # Terms should

# Generated at 2022-06-21 08:46:23.104845
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import os

    current_dir = os.path.dirname(os.path.abspath(__file__))

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test the various ways we can specify the terms argument
    actual_output = listify_lookup_plugin_terms([u'{ "one": 1, "two": 2 }'], templar, loader, convert_bare=True)
    assert isinstance(actual_output, list)
    assert len(actual_output) == 1
    assert isinstance(actual_output[0], dict)
    assert actual_output[0][u'one'] == 1
    assert actual_output[0][u'two'] == 2

    actual

# Generated at 2022-06-21 08:46:32.866401
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']
    assert listify_lookup_plugin_terms(' foo', None, None) == ['foo']
    assert listify_lookup_plugin_terms('foo ', None, None) == ['foo']
    assert listify_lookup_plugin_terms(' foo ', None, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], None, None) == ['foo']
    assert listify_lookup_plugin_terms([' foo'], None, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo '], None, None) == ['foo']
    assert listify_lookup_plugin_terms([' foo '], None, None) == ['foo']
    assert listify_lookup

# Generated at 2022-06-21 08:46:45.165208
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.community.general.tests.unit.compat import unittest

    class TestListifyLookupPluginTerms(unittest.TestCase):
        def test_listify_lookup_plugin_terms_string(self):
            terms = '{{ my_test_var }}'
            templar = AnsibleModule(argument_spec={})._load_params()
            templar.available_variables = dict(my_test_var='my_test_val')
            result = listify_lookup_plugin_terms(terms, templar, None)
            self.assertEqual(result, ['my_test_val'])


# Generated at 2022-06-21 08:46:52.167097
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    print("listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True)")
    print("-----------------------------------------------------------------------")


# Generated at 2022-06-21 08:47:01.883679
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.template import Templar

    terms_new = listify_lookup_plugin_terms(['{{ testvar }}'], Templar(loader=DictDataLoader({'testvar.j2': 'foo'}), variables={'testvar': 'bar'}), loader=None)
    assert terms_new == ['bar']

    terms_old = listify_lookup_plugin_terms(['{{ testvar_old }}'], Templar(loader=DictDataLoader({'testvar_old.j2': 'foo'}), variables={'testvar_old': 'bar'}), loader=None, convert_bare=True)
    assert terms_old == ['bar']

    # ensure that we only get

# Generated at 2022-06-21 08:47:14.589188
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    class VarsModule():
        def __init__(self, load_list):
            self.LOAD_LIST = load_list

    class PlayContext():
        def __init__(self):
            self.vars = VarsModule([])

    def get_basedir_loader():
        return DataLoader()

    class MockTemplar(Templar):
        def __init__(self):
            self._available_variables = dict()

        def set_available_variables(self, variables):
            self._available_variables = variables


# Generated at 2022-06-21 08:47:23.967758
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    templar = Templar(loader=None, variables={'var': 'one'})

    terms = '{{ var }}'
    try:
        results = listify_lookup_plugin_terms(terms, templar, loader)
        assert results == ['one']
    except Exception:
        raise AssertionError("listify_lookup_plugin_terms should return a list when a template is provided.")

    terms = AnsibleUnicode('{{ var }}')

# Generated at 2022-06-21 08:47:32.990127
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.template import Templar

    loader = DictDataLoader({})

    templar = Templar(loader=loader, variables={})

    assert listify_lookup_plugin_terms(["a", "b"], templar, loader) == ["a", "b"]
    assert listify_lookup_plugin_terms("a", templar, loader) == ["a"]
    assert listify_lookup_plugin_terms("a, b", templar, loader) == ["a, b"]
    assert listify_lookup_plugin_terms("a,b", templar, loader) == ["a,b"]
    assert listify_lookup_plugin_terms("a, b", templar, loader, convert_bare=True) == ["a", "b"]
    assert listify_

# Generated at 2022-06-21 08:47:43.151999
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
  from ansible.template import Templar
  from ansible.vars import VariableManager
  from ansible import context
  from ansible.parsing.dataloader import DataLoader
  variable_manager = VariableManager()
  loader = DataLoader()
  variable_manager.set_inventory(loader.load_inventory('tests/inventory/hosts'))
  templar = Templar(loader=loader, variable_manager=variable_manager)
  assert(listify_lookup_plugin_terms(['{{ item }}', {'a': 'b'}], templar, loader) == ['{{ item }}', {'a': 'b'}])
  assert(listify_lookup_plugin_terms((1, 2, 3), templar, loader) == [1, 2, 3])

# Generated at 2022-06-21 08:47:54.686705
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping

    m = AnsibleMapping()
    m['x'] = '1'
    templar = Templar(loader=None, variables=m)

    terms = ["{{ x }}"]
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert terms == ['1']

    terms = [" {{ x }} "]
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert terms == ['1']

    terms = '{{ x }}'
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert terms == ['1']

    terms = ['{{ x }}']
    terms = listify_lookup_

# Generated at 2022-06-21 08:48:06.855538
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Function to test function listify_lookup_plugin_terms
    '''
    terms = ["one","two"]
    expected_result = [ "one", "two" ]
    input_string = "{{ terms }}"
    templar = DummyTemplar()
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == expected_result

    input_string = "{{ terms }}"
    templar = DummyTemplar(input_string)
    result = listify_lookup_plugin_terms(input_string, templar, loader)
    assert result == expected_result

    terms = "{{ terms }}"
    input_string = "{{ terms }}"
    templar = DummyTemplar(input_string)
    result = listify

# Generated at 2022-06-21 08:48:18.298683
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    vars = dict(
        key1='value1',
        key2=['value2a', 'value2b'],
        key3='{{ key1 }}',
        key4=dict(
            key41=dict(
                key411=[dict(foo='bar')],
            )
        ),
    )
    templar = Templar(loader=None, variables=vars)
    assert listify_lookup_plugin_terms('key1', templar, loader=None) == ['value1']
    assert listify_lookup_plugin_terms(['key1'], templar, loader=None) == ['value1']
    assert listify_lookup_plugin_terms('key2', templar, loader=None) == ['value2a', 'value2b']

# Generated at 2022-06-21 08:48:28.554001
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    myvars = dict(
        foo='foo',
        bar='bar',
        baz='baz',
        one=1,
        two=2,
        three=3,
        mylist=[1,2,3,4],
    )
    myargs = {}
    t = Templar(loader=loader, variables=myvars)

    terms = listify_lookup_plugin_terms('{{ foo }}', t, loader)
    assert terms == ['foo']

    terms = listify_lookup_plugin_terms('{{ foo }},{{ bar }}', t, loader)
    assert terms == ['foo', 'bar']


# Generated at 2022-06-21 08:48:39.650855
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' test listify_lookup_plugin_terms'''

    from ansible.template import Templar
    from ansible.parsing.mod_args import ModuleArgsParser

    parser = ModuleArgsParser()
    templar = Templar(loader=None, variables={})
    convert_bare = False
    fail_on_undefined = True

    string_terms = 'string terms'
    new_terms = listify_lookup_plugin_terms(string_terms, templar, None, fail_on_undefined, convert_bare)
    print(new_terms)
    assert(new_terms == ['string terms'])

    terms = (1, 2)
    new_terms = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined, convert_bare)

# Generated at 2022-06-21 08:48:48.579815
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # test_string
    test_string = "{{ lookup('pipe', 'echo hello world') }}"
    terms = listify_lookup_plugin_terms(test_string, Templar({}), None)
    assert (terms[0] == 'hello world')

    # test_string_bare
    test_string_bare = "{{ 'hello world' }}"
    terms = listify_lookup_plugin_terms(test_string_bare, Templar({}), None, convert_bare=True)
    assert (terms[0] == 'hello world')

    # test_string with fail_on_undefined=False
    test_string_fail_on_undefined = "{{ 'hello' }} {{ world }}"
   

# Generated at 2022-06-21 08:49:00.266217
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import ansible.vars.unsafe_proxy
    import sys

    class VarModule(object):
        """
        Used to replace the AnsibleModule in the Templar for unit testing purposes
        """
        def __init__(self):
            self.params = dict()

        def fail_json(self, *args, **kwargs):
            module = AnsibleModule(argument_spec={})
            module.fail_json(*args, **kwargs)

    class TestTemplar(Templar):
        """
        Subclass Templar for use in unit tests, to prevent it from accessing
        actual data on the disk
        """
        def __init__(self, variables=dict()):
            self._available_vari

# Generated at 2022-06-21 08:49:12.387315
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    v = VariableManager()
    l = DataLoader()
    t = Templar(loader=l, variables=v)

    # terms is a string
    assert listify_lookup_plugin_terms('1', templar=t, loader=l, fail_on_undefined=True, convert_bare=False) == ['1']

    # terms is a list
    assert listify_lookup_plugin_terms(['1'], templar=t, loader=l, fail_on_undefined=True, convert_bare=False) == ['1']

    # terms is not a string nor a list

# Generated at 2022-06-21 08:49:23.677248
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # test passing a string to listify_lookup_plugin_terms()
    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms('"foobar"', templar, None) == ["foobar"]

    # test passing an array of strings to listify_lookup_plugin_terms()
    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms(['"foobar"', '"roobar"'], templar, None) == ["foobar", "roobar"]

    # test passing an array with a string to listify_lookup_plugin_terms()
    templar = Templar(loader=None)

# Generated at 2022-06-21 08:49:31.586639
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    test_cases = [
        (
            {'params': {'terms': 'foo'}},
            [u'foo'],
        ),
        (
            {'params': {'terms': [u'foo']}},
            [u'foo'],
        ),
    ]

    for args, expected in test_cases:
        params = args['params']
        templar = Templar(loader=None)
        result = listify_lookup_plugin_terms(params['terms'], templar, None)
        assert result == expected

# Generated at 2022-06-21 08:49:42.910728
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # import module snippets
    from ansible.module_utils.facts.virtual.base import get_file_content
    from ansible.module_utils.facts import cache

    # initialize needed objects
    module_args = { 'path': 'tests/unit/module_utils/virtual/ansible_module_facts' }
    from ansible.module_utils.facts.virtual.ansible_module_facts import AnsibleModule
    module = AnsibleModule(
        argument_spec = module_args,
        supports_check_mode = True
    )
    # get module specific facts
    facts_dict = cache.get_facts(module, source_file=module._name)

    # import needed function
    from ansible.module_utils.common.collections import listify_lookup_plugin_terms

# Generated at 2022-06-21 08:49:53.019951
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import StringIO

    from ansible.utils.template import Templar
    from ansible.template import Templar, Jinja2Template
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_bytes

    vaults = VaultLib({}, None, None)
    vaults.read_vault_file(None)

    data = '''
    foo:
     - bar
     - baz

    bam:
     - a
     - b
     - c
    '''


# Generated at 2022-06-21 08:50:01.586000
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    var_mgr = VariableManager()

    templar = Templar(loader=loader, variables=var_mgr)

    test_list = ['foo', 'bar', 'baz']
    test_string = 'foo'
    test_separator = ','
    test_dict = {"test_dict": {
        "hosts": ['foo', 'bar', 'baz']
    }}

    var_mgr.set_inventory(test_dict)

    assert listify_lookup_plugin_terms(test_list, templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-21 08:50:11.169143
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Make sure that list is not altered if a list
    terms = [
        'foo',
        'bar',
        'baz',
    ]

    templar = Templar(loader=None)
    result = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=True, convert_bare=False)
    assert result == terms

    # Make sure that a single string item is not converted to a list either
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=True, convert_bare=False)
    assert result == [terms]

    # Make sure that a string with comma-separated items is converted to a list

# Generated at 2022-06-21 08:50:18.391621
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # the mock module can't be imported until after importing common
    from ansible.module_utils import basic
    from ansible.template import Templar
    from ansible import constants as C

    terms = "a | b {{ c }}"
    templar = Templar(loader=basic.AnsibleLoader(None))

    listified = listify_lookup_plugin_terms(terms, templar, basic.AnsibleLoader(None))
    assert listified == ['a', 'b c']


# Generated at 2022-06-21 08:50:29.657416
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import os
    import sys
    import tempfile
    import shutil
    import yaml

    from ansible.module_utils.six import PY3

    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.errors import AnsibleParserError


# Generated at 2022-06-21 08:50:38.866192
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    import ansible.utils.unsafe_proxy
    import ansible.vars

    m_unsafe_proxy = ansible.utils.unsafe_proxy.AnsibleUnsafeText
    m_vars = ansible.vars.VariableManager()
    m_template = ansible.template.Templar(loader=None, variables=m_vars)

    assert listify_lookup_plugin_terms("{{ foo }}", m_template, loader=None) == [m_unsafe_proxy("{{ foo }}")]
    assert listify_lookup_plugin_terms("{{ foo }}", m_template, loader=None, convert_bare=True) == [m_unsafe_proxy("foo")]

    # The assert has to be nested because the ansible.vars.VariableManager()
    # will

# Generated at 2022-06-21 08:50:49.305517
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    from ansible.module_utils.common._collections_compat import Mapping

    from units.mock.loader import DictDataLoader

    # test when terms is a AnsibleUnicode
    terms = AnsibleUnicode(u'["abc"]')
    templar = DictDataLoader(None, {'_original_file': '<string>'}).get_basedir()
    templar = Templar(loader=templar)
    ret = listify_lookup_plugin_terms(terms, templar, templar, convert_bare=False)
    assert isinstance(ret, list)
    assert len(ret) == 1
    assert ret[0] == 'abc'

    # test when terms

# Generated at 2022-06-21 08:50:56.966705
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # Helper function to test a templar template expression
    def test_expr(expr, expected):
        value = listify_lookup_plugin_terms(expr, templar, loader)
        assert value == expected

    # Create a test template environment
    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test a simple string
    test_expr('foo.txt', ['foo.txt'])

    # Test a simple list
    test_expr(['foo.txt', 'bar'], ['foo.txt', 'bar'])

    # Test a template string that resolves to a string
   

# Generated at 2022-06-21 08:51:05.521262
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = DataLoader()

    variable_manager.set_known_hosts_files([])
    variable_manager.extra_vars = {'ansible_check_mode': False, 'ansible_diff_mode': False}

    templar = Templar(loader=loader, variable_manager=variable_manager, shared_loader_obj=loader)

    ##################################################
    # String
    ##################################################
    term = 'foobar'
    listified_term = listify_lookup_plugin_terms(term, templar, loader, convert_bare=True)

# Generated at 2022-06-21 08:51:16.598575
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    terms='{{ foo }}'
    my_vars = dict(foo='FOO')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = my_vars
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)
    new_terms = listify_lookup

# Generated at 2022-06-21 08:51:28.566515
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test 1: AnsibleModule.params
    from ansible.module_utils.basic import AnsibleModule
    dummy_module = AnsibleModule(
        argument_spec=dict(
            param=dict(type='str', default='foo'),
        ),
    )

    # Test 1.1: test a scalar value
    ret = listify_lookup_plugin_terms(
        terms='{{ param }}',
        templar=dummy_module.params,
        loader=None,
        fail_on_undefined=True,
        convert_bare=False,
    )
    assert ret == ['foo']

    # Test 1.2: test a list value

# Generated at 2022-06-21 08:51:41.152908
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    data = {
        'foo': 'foo',
        'bar': 'bar',
        'baz': 'baz',
    }
    templar = Templar(loader=None, variables=data)

    # Basic strings
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']

    # List of strings
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo,bar', templar, None) == ['foo', 'bar']

    # template substitutions
    assert listify_lookup_

# Generated at 2022-06-21 08:51:53.638984
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader     = DataLoader()
    variable_manager = VariableManager()
    variables  = VariableManager()
    templar    = Templar(loader=loader, variables=variables)

    test_data = OrderedDict()

    test_data["invalid_inputs"] = [
        '{{ foo }}',
        '{{ foo }}',
        ['{{ foo }}'],
        ['{{ foo }}', '{{ bar }}'],
        1,
        [1, 2]
    ]


# Generated at 2022-06-21 08:52:01.869577
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject as YAML
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    t = Templar(loader=None, variables=combine_vars(None, dict()))

    listify_lookup_plugin_terms(terms=u'{{ [ 1, 2, 3 ] }}', templar=t, loader=None)
    listify_lookup_plugin_terms(terms=YAML("{{ [ 1, 2, 3 ] }}"), templar=t, loader=None)
    listify_lookup_plugin_terms(terms=[1, 2, 3], templar=t, loader=None)

# Generated at 2022-06-21 08:52:06.365074
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # FIXME : this test is not implemented correctly because of the
    # dependency of templar and loader.  This at least verifies the
    # function can be found.

    terms = listify_lookup_plugin_terms('foo', 'foo', 'foo')
    assert terms == ['foo']

# Generated at 2022-06-21 08:52:22.667943
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('a', None, None) == ['a']
    assert listify_lookup_plugin_terms(['a', 'b'], None, None) == ['a', 'b']
    assert listify_lookup_plugin_terms('a', None, None, convert_bare=True) == ['a']
    assert listify_lookup_plugin_terms('a b', None, None, convert_bare=True) == ['a', 'b']
    assert listify_lookup_plugin_terms('a b', None, None, convert_bare=False) == 'a b'

# Generated at 2022-06-21 08:52:33.925661
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.module_utils.common.collections
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    #####################
    # class fake_host:
    #     def __init__(self, *args, **kwargs):
    #         pass
    #     def get_vars(self):
    #         return {"var_ansible_host": "localhost"}
    #     def get_name(self):
    #         return "localhost"
    #
    # class common_tests:
    #     def __init__(self, *args, **kwargs):
    #         self.host = fake_host()
   

# Generated at 2022-06-21 08:52:44.725124
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo','bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-21 08:52:53.411204
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    term_1 = ['a', 'b', 'c']
    term_2 = AnsibleUnsafeText('d')
    term_3 = 'e'
    term_4 = '"f"'

    templar = Templar(loader=None, variables={})

    terms = listify_lookup_plugin_terms(term_1, templar, loader=None)
    assert (isinstance(terms, list))
    assert (terms == term_1)

    terms = listify_lookup_plugin_terms(term_2, templar, loader=None)
    assert (isinstance(terms, list))
    assert (terms == [term_2])


# Generated at 2022-06-21 08:53:04.430352
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import jinja2
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_text

    terms = u"{{ [ 'i am', 'a list' ] }}"
    templar = jinja2.Environment()
    result = listify_lookup_plugin_terms(terms, templar)
    assert isinstance(result, list)
    assert isinstance(result[0], string_types)
    assert isinstance(result[1], string_types)
    assert to_text(result[0]) == u'i am'
    assert to_text(result[1]) == u'a list'

    terms = u"{{ 'i am a string' }}"
    templar = jinja2.Environment()
    result = listify

# Generated at 2022-06-21 08:53:11.512846
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six.moves import StringIO
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    terms = [
        '- {{ lookup("file", "../test_data/test.txt") }}',
        '"{{ test_var }}"',
        '"{{ test_var2 }}"',
        '"{{ test_var3 }}"',
        '"{{ lookup("file", "../test_data/test.txt") }}"',
        '- "{{ lookup("file", "../test_data/test.txt") }}"',
    ]


# Generated at 2022-06-21 08:53:21.865599
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class FakeLoader(object):
        pass

    loader = FakeLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms([1, 2, 3], templar, loader) == [1, 2, 3]
    assert listify_lookup_plugin_terms([1, 2, 3], templar, loader, convert_bare=True) == [1, 2, 3]
    assert listify_lookup_plugin_terms(['{{foo}}', '{{bar}}'], templar, loader) == ['{{foo}}', '{{bar}}']
    assert listify_lookup_plugin_terms(['{{foo}}', '{{bar}}'], templar, loader, convert_bare=True) == ['foo', 'bar']

# Generated at 2022-06-21 08:53:33.822384
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import os
    import sys
    from ansible.template import Templar

    # Test string - same result for convert_bare=True and convert_bare=False
    terms = sys.version_info

    result = listify_lookup_plugin_terms(terms, Templar(loader=None), None, fail_on_undefined=True, convert_bare=True)
    assert terms == result

    result = listify_lookup_plugin_terms(terms, Templar(loader=None), None, fail_on_undefined=True, convert_bare=False)
    assert terms == result

    # Test list - same result for convert_bare=True and convert_bare=False
    terms = [sys.version_info, os.path.expanduser('~')]


# Generated at 2022-06-21 08:53:46.222469
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    function listify_lookup_plugin_terms
    '''
    from ansible.module_utils.six.moves import StringIO
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms('1', templar, None) == ['1']
    assert listify_lookup_plugin_terms('1\n2\n3', templar, None) == ['1', '2', '3']
    assert listify_lookup_plugin_terms('1,2,3', templar, None) == ['1,2,3']
    assert listify_lookup_plugin_terms(['1', '2', '3'], templar, None)

# Generated at 2022-06-21 08:53:54.670056
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar

    myvar = dict(a=1, b=2, c=3)
    templar = Templar(loader=None, variables=dict(omg=myvar))
    assert listify_lookup_plugin_terms(['a'], templar, None) == ['a']
    assert listify_lookup_plugin_terms('a', templar, None) == ['a']
    assert listify_lookup_plugin_terms(['a', 'b'], templar, None) == ['a', 'b']
    assert listify_lookup_plugin_terms(u'a', templar, None) == ['a']

# Generated at 2022-06-21 08:54:20.930803
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test string_types
    assert ['hello'] == listify_lookup_plugin_terms('hello', None, None)
    assert ['hello world'] == listify_lookup_plugin_terms('hello world', None, None)

    # test tuples
    assert ["hello"] == listify_lookup_plugin_terms(("hello",), None, None)
    assert ["hello", "world"] == listify_lookup_plugin_terms(("hello world",), None, None)
    assert ["hello", "world"] == listify_lookup_plugin_terms(("hello", "world"), None, None)

    # test lists
    assert ["hello"] == listify_lookup_plugin_terms(["hello"], None, None)

# Generated at 2022-06-21 08:54:29.095485
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vault_secrets = VaultLib([], None, loader=loader)
    terms = """{{ somevar }}"""

    templar = Templar(loader=loader, variables={'somevar': 'somevar_value'}, vault_secrets=vault_secrets)
    result = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)

    assert result[0] == 'somevar_value'

# Generated at 2022-06-21 08:54:38.968393
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    from ansible.parsing.yaml.objects import AnsibleUnicode

    assert [u'foo'] == listify_lookup_plugin_terms(u'foo', Templar({}, {}), None)
    assert [u'foo'] == listify_lookup_plugin_terms(u'foo', Templar({}, {}), None)
    assert [u'foo', u'bar'] == listify_lookup_plugin_terms([u'foo', u'bar'], Templar({}, {}), None)
    assert [u'foo', u'bar'] == listify_lookup_plugin_terms([u'foo', u'bar'], Templar({}, {}), None)


# Generated at 2022-06-21 08:54:46.785194
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # test string
    terms = 'foo'
    converted = listify_lookup_plugin_terms(terms, Templar(VariableManager(), loader=DataLoader()), loader=DataLoader())
    assert converted == ['foo']

    # test list
    terms = ['foo']
    converted = listify_lookup_plugin_terms(terms, Templar(VariableManager(), loader=DataLoader()), loader=DataLoader())
    assert converted == ['foo']

    # test multiple elements in list
    terms = ['foo', 'bar']
    converted = listify_lookup_plugin_terms(terms, Templar(VariableManager(), loader=DataLoader()), loader=DataLoader())
    assert converted

# Generated at 2022-06-21 08:54:55.039029
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    # test string
    assert listify_lookup_plugin_terms("{{ foo }}", templar, loader=None) == ["{{ foo }}"]
    assert listify_lookup_plugin_terms("{{ foo }}", templar, loader=None, convert_bare=True) == ["{{ foo }}"]

    # template string
    assert listify_lookup_plugin_terms("{{ item }}", templar, loader=None) == ["{{ item }}"]
    assert listify_lookup_plugin_terms("{{ item }}", templar, loader=None, convert_bare=True) == ["{{ item }}"]

    # list

# Generated at 2022-06-21 08:55:00.918474
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    import os

    # test vars
    variables = dict(
        testvar='testval',
        testpath=os.path.dirname(os.path.abspath(__file__)),
        testpath2='/path/to/some/file.txt',
        testlist=['testlistitem'],
        nestedlist=[['nestedlistitem']],
        nested_var='nested var'
    )
    # initialize templar
    vault_pass = os.environ.get('VAULT_PASS', None)
    loader = DictDataLoader({})
    vault_secrets = VaultLib([])

# Generated at 2022-06-21 08:55:11.854813
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # test that listify_lookup_plugin_terms returns a list containing the only the specified term, even if the term is a list
    def test(term, templar=None, loader=None, fail_on_undefined=True, convert_bare=False):

        if templar is None:
            templar = Templar(loader=loader, variables={})

        terms = listify_lookup_plugin_terms(term, templar, loader, fail_on_undefined, convert_bare)

        assert len(terms) == 1, "expected one term, but got %d: %s" % (len(terms), terms)
        return terms[0]

    # ...

    name = 'foo'

    assert test(name) == name
    assert test(name, convert_bare=True)

# Generated at 2022-06-21 08:55:19.561039
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    templar = Templar(loader=None)
    # test list
    terms = listify_lookup_plugin_terms(['1', '2', '3'], templar, None)
    assert terms == [1, 2, 3], terms
    terms = listify_lookup_plugin_terms([1, 2, 3], templar, None)
    assert terms == [1, 2, 3], terms

    # test string
    terms = listify_lookup_plugin_terms('foo', templar, None)
    assert terms == ['foo'], terms

    # test integer
    terms = listify_lookup_plugin_terms(123, templar, None)

# Generated at 2022-06-21 08:55:30.595279
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        from ansible.template import Templar
    except ImportError:
        # older ansible, just skip these tests
        return

    terms = ['one', 2, 'three', u'four']
    t = Templar(loader=None, variables={'foo': terms})

    assert terms == listify_lookup_plugin_terms(terms, t, None)
    assert terms == listify_lookup_plugin_terms(terms, t, None, fail_on_undefined=False)

    templated_terms = ['one', 2, 'three', u'four']
    assert templated_terms == listify_lookup_plugin_terms('{{ foo }}', t, None)
    assert templated_terms == listify_lookup_plugin_terms('{{ foo }}', t, None, fail_on_undefined=False)