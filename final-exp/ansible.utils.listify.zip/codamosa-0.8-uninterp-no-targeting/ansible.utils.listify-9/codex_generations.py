

# Generated at 2022-06-21 08:45:31.468095
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-21 08:45:39.770407
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    m = AnsibleMapping()
    m.ansible_pos = (0,0,'<string>')
    m['foo'] = 'bar'
    t = Templar(loader=AnsibleLoader(m))
    assert listify_lookup_plugin_terms('foo', t, loader=None) == ['bar']
    assert listify_lookup_plugin_terms('{{foo}}', t, loader=None) == ['bar']
    assert listify_lookup_plugin_terms('{{foo}}', t, loader=None, convert_bare=True) == ['bar']

# Generated at 2022-06-21 08:45:49.257223
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeLoader:
        pass

    loader = FakeLoader()

    templar = Templar(loader)


# Generated at 2022-06-21 08:46:00.152310
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, dict())
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms("{{ lookup('pipe', 'echo 1') }}", templar, loader) == ['1']
    assert listify_lookup_plugin_terms("{{ lookup('pipe', 'echo 1') }},{{ lookup('pipe', 'echo 2') }}", templar, loader) == ['1', '2']
    assert listify_lookup_plugin_terms('["{{ lookup("pipe", "echo 1") }}", "{{ lookup("pipe", "echo 2") }}"]', templar, loader) == ['1', '2']


# Generated at 2022-06-21 08:46:06.475492
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_vault_password('dummy')

    templar = Templar(loader=loader, variables=variable_manager)

    # Test 1: string
    terms = listify_lookup_plugin_terms('goob', templar, loader, fail_on_undefined=True, convert_bare=False)
    assert terms == ['goob']

    # Test 2: dict
    terms = listify_lookup_plugin_terms({'a':'b'}, templar, loader, fail_on_undefined=True, convert_bare=False)

# Generated at 2022-06-21 08:46:17.448332
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.template import Templar

    class ToyModule:
        def __init__(self, params):
            self.params = params

    class ToyLoader:
        def __init__(self):
            self.paths = ['/path/to/somewhere', '/path/to/somewhere/else']

    class ToyInventory:
        def __init__(self):
            pass

    class ToyTemplar(Templar):
        def __init__(self, loader, variables):
            self._loader = loader
            self._available_variables = variables

    # test with an actual variable
    module = ToyModule({'something': 'somevalue'})
    loader = ToyLoader()
    templar = ToyTemplar(loader, module.params)
    terms = "{{ something }}"

# Generated at 2022-06-21 08:46:26.322784
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(['a','b','c'], 'templar', 'loader') == ['a','b','c']
    assert listify_lookup_plugin_terms('a', 'templar', 'loader') == ['a']
    assert listify_lookup_plugin_terms(' [\'{{a}}\',\'{{b}}\',\'{{c}}\'] ', 'templar', 'loader') == ['a','b','c']
    assert listify_lookup_plugin_terms('{{ a }}', 'templar', 'loader') == ['a']

# Generated at 2022-06-21 08:46:34.873874
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    playbook_vars = dict(foo='bar')
    inventory = dict()
    templar = Templar(loader=None, variables=playbook_vars, inventory=inventory)

    assert listify_lookup_plugin_terms('foo', templar, None) == ['bar']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None) == ['bar']
    assert listify_lookup_plugin_terms('{{ foo }', templar, None) == ['bar']
    assert listify_lookup_plugin_terms('foo }', templar, None) == ['bar']

# Generated at 2022-06-21 08:46:46.774861
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import os
    import sys

    from collections import namedtuple
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    from units.loader_module import CommandLoader

    # Setup dummy objects
    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.module_name = None
            self.forks = 1
            self.become = False
            self.become_method = None
            self.become_user = None
            self.check = False
            self.remote_user = 'remote_user'
            self.private_key

# Generated at 2022-06-21 08:46:56.168198
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    my_var = dict(
        a_string='foo',
        a_list=['bar', 'baz'],
        a_dict=dict(
            key_one='val_one',
            key_two='val_two',
        ),
    )

    variable_manager = VariableManager()
    variable_manager.extra_vars = my_var

    loader = DataLoader()

    templar = Templar(loader=loader, variables=variable_manager)

    # Single string gets wrapped in a list, but not templated
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Single string that is templatable

# Generated at 2022-06-21 08:47:09.457253
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    test_terms = {
        'when templating a string': [
            {'terms': 'a string', 'expected': ['a string']},
            {'terms': '', 'expected': ['']},
        ],
        'when templating iterables': [
            {'terms': [], 'expected': [None]},
        ],
        'when templating strings which are lists in YAML': [
            {'terms': '[a string]', 'expected': ['[a string]']},
        ],
        'when templating lists in YAML': [
            {'terms': ['a string'], 'expected': ['a string']},
            {'terms': ['a string', 'another string'], 'expected': ['a string', 'another string']},
        ],
    }



# Generated at 2022-06-21 08:47:19.249555
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Test function setup
    loader = DictDataLoader({})
    templar = Templar(loader=loader)

    # Test 1: A string that has no jinja2 template, should be returned as a one-element list
    no_jinja2_in_string = "no jinja2 in str"
    ret = listify_lookup_plugin_terms(no_jinja2_in_string, templar, loader, convert_bare=True)
    assert isinstance(ret, list) and ret == [no_jinja2_in_string]

    # Test 2: A string that contains jinja2 template, should be rendered and returned as a one-element list
    jinja2_in_string = "jinja2 in str: {{ test }}"
    ret = listify_

# Generated at 2022-06-21 08:47:30.175203
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.mod_args import ModuleArgsParser

    m = ModuleArgsParser(dict(basedir='/'))
    templar = Templar(loader=None, variables=dict(a=5))

    # Compound string test
    ret = listify_lookup_plugin_terms(terms='{{a}}', templar=templar)
    assert ret == [5], ret

    # Multiple string test
    ret = listify_lookup_plugin_terms(terms=['{{a}}','{{a}}'], templar=templar)
    assert ret == [5,5], ret

    # String test
    ret = listify_lookup_plugin_terms(terms='file', templar=templar)
    assert ret == ['file'], ret

   

# Generated at 2022-06-21 08:47:42.345629
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    terms = "foo"
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert type(terms) is list
    assert terms == ["foo"]

    terms = ["foo"]
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert type(terms) is list
    assert terms == ["foo"]

    terms = ["foo", "bar"]
    terms = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-21 08:47:54.177708
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext

    from ansible.template import Templar

    class TestVarsModule(object):

        def __init__(self, hostvars=None):
            if not hostvars:
                hostvars = {}
            self.hostvars = hostvars

        def get_vars(self, loader, path, entities):
            if entities is None:
                return self.hostvars

            results = {}
            for entity in entities:
                try:
                    results.update(self.hostvars[entity])
                except KeyError:
                    pass
            return results

    p = PlayContext()

# Generated at 2022-06-21 08:48:06.135356
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    # Empty term
    terms = ''
    templar = Templar(loader=AnsibleLoader(None), variables=VariableManager())
    result = listify_lookup_plugin_terms(terms, templar, loader=AnsibleLoader(None), fail_on_undefined=True)
    assert result == ['']

    # One term
    terms = 'string'
    templar = Templar(loader=AnsibleLoader(None), variables=VariableManager())
    result = listify_lookup_plugin_terms(terms, templar, loader=AnsibleLoader(None), fail_on_undefined=True)
    assert result == ['string']

   

# Generated at 2022-06-21 08:48:14.301624
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeVarManager:
        def __init__(self):
            self.templates = dict()
        def template(self, template, fail_on_undefined=True, convert_bare=False):
            if template not in self.templates:
                # do nothing
                return template
            else:
                return self.templates[template]

    class FakeTemplar:
        def __init__(self, var_manager):
            self.var_manager = var_manager

    var_manager = FakeVarManager()
    templar = FakeTemplar(var_manager)
    from ansible.plugins.loader import lookup_loader
    loader = lookup_loader

    # Empty string returns empty list
    assert listify_lookup_plugin_terms('', templar, loader) == []

    # String with one term returns list with

# Generated at 2022-06-21 08:48:23.344175
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import sys
    import io
    import ansible.module_utils.common.json_utils as json_utils
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import lookup_loader

    class Options(object):
        def __init__(self, _search_paths, _variable_manager=None, _loader=None):
            self.basedir = None
            self.convert_bare = False
            self.fail_on_undefined = False
            self.newvars = None
            self.no_log = False
            self.search_paths = _search_paths
            self.verbosity = 0
            self.variable_manager = _variable_manager
            self._lookup_loader = _loader


# Generated at 2022-06-21 08:48:34.486811
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class DummyVarsModule:
        def __init__(self):
            self.params = {'test': [1, 2, 3]}

    class DummyLoaderModule:
        @staticmethod
        def get_basedir(path):
            return '/'

    class DummyRunner:
        def __init__(self):
            self._no_log = False

    loader = DummyLoaderModule()
    runner = DummyRunner()
    vars_module = DummyVarsModule()
    templar_obj = Templar(loader=loader, variables=vars_module, runner=runner)

    terms = '{{ test }}'
    terms = listify_lookup_plugin_terms(terms, templar_obj, loader)
    assert terms == [1, 2, 3]

    terms

# Generated at 2022-06-21 08:48:43.825567
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.template import Templar
    import json

    loader = DummyLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms("foo", templar, loader) == ["foo"]
    assert listify_lookup_plugin_terms("foo,bar", templar, loader) == ["foo", "bar"]
    assert listify_lookup_plugin_terms("{{foo}},{{bar}}", templar, loader) == ["{{foo}}", "{{bar}}"]
    assert listify_lookup_plugin_terms("{{foo}},{{bar}}", templar, loader, convert_bare=True) == ["foo", "bar"]

# Generated at 2022-06-21 08:48:59.022407
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_inventory(
        variable_manager.loader.inventory_manager.get_inventory(
            variable_manager,
            play_context.vars,
        )
    )
    vault_secrets = VaultLib(play_context, variable_manager)
    templar = Templar(loader=None, variables=variable_manager, vault_secrets=vault_secrets)

    assert listify_lookup_

# Generated at 2022-06-21 08:49:11.043517
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    my_loader = DataLoader()
    loader = AnsibleLoader(my_loader)

    templar = Templar(loader=loader)

    # testing listify_lookup_plugin_terms(terms, templar, loader)

    terms = 'test'
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(results, list)
    assert results == ['test']

    terms = ['test']
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(results, list)
    assert results == ['test']


# Generated at 2022-06-21 08:49:23.676720
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class FakeLoader(object):
        def get_basedir(self, path):
            return "/tmp"

    class FakeTemplar(object):

        def __init__(self):
            self._data = {}

        def set_available_variables(self, variables):
            self._data.update(variables)

        def template(self, terms, fail_on_undefined=True, convert_bare=False):
            res = []
            for term in terms:
                if isinstance(term, dict):
                    for key, value in term.iteritems():
                        res.append(key)
                elif isinstance(term, string_types):
                    if term.startswith('$'):
                        res.append(self._data[term[1:]])
                    else:
                        res.append(term)

# Generated at 2022-06-21 08:49:33.694554
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # Use the VaultLib to decrypt the vault content
    vault_pass = 'secret'
    vault = VaultLib([])
    vault.read_vault_password_file(vault_pass)

    # Variable manager takes vault as an argument to enable its usage
    variable_manager = VariableManager()

# Generated at 2022-06-21 08:49:44.137732
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Mapping

    assert listify_lookup_plugin_terms(123, object(), object()) == [123]
    assert listify_lookup_plugin_terms('123', object(), object()) == ['123']
    assert listify_lookup_plugin_terms('123 456', object(), object()) == ['123', '456']
    assert listify_lookup_plugin_terms(['123', '456'], object(), object()) == ['123', '456']
    assert listify_lookup_plugin_terms([u'123', u'456'], object(), object()) == [u'123', u'456']
    assert listify_lookup_plugin_terms({'k': 'v'}, object(), object()) == [{'k': 'v'}]
    assert list

# Generated at 2022-06-21 08:49:55.101259
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-21 08:50:06.305867
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test case 1
    # Check that an empty string is converted to a list with an empty string
    terms = ''
    result = listify_lookup_plugin_terms(terms, None, None)
    assert result == [''], \
        "Failed to convert empty string to a list with an empty string"

    # Test case 2
    # Check that a string is converted to a list with that string
    terms = 'a string'
    result = listify_lookup_plugin_terms(terms, None, None)
    assert result == ['a string'], \
        "Failed to convert string to a list with that string"

    # Test case 3
    # Check that an integer is converted to a list with that integer
    terms = 1
    result = listify_lookup_plugin_terms(terms, None, None)

# Generated at 2022-06-21 08:50:17.712172
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = ['a','b','c']
    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms(terms, templar) == ['a','b','c']

    terms = '{{ a }}'
    assert listify_lookup_plugin_terms(terms, templar) == ['{{ a }}']

    terms = ['a','b','{{ c }}']
    assert listify_lookup_plugin_terms(terms, templar) == ['a','b','{{ c }}']

    terms = '{{ a }},{{ b }},{{ c }}'
    assert listify_lookup_plugin_terms(terms, templar) == ['{{ a }},{{ b }},{{ c }}']

# Generated at 2022-06-21 08:50:28.443453
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import AnsibleMapping
    import jinja2

    class TestClass(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return '{0}({1})'.format(self.__class__.__name__, self.value)

        def __str__(self):
            return '{0}'.format(self.value)

    class TestLoader(AnsibleMapping):
        def __init__(self, **kwargs):
            for k,v in list(kwargs.items()):
                setattr(self, k, v)


# Generated at 2022-06-21 08:50:40.478373
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class Templar:

        def __init__(self, loader):
            self.loader = loader

        def template(self, terms, convert_bare=False, fail_on_undefined=True):
            if isinstance(terms, string_types):
                terms = terms.strip()
            return terms

    loader = None

    # Test with invalid objects
    test_terms = None
    assert [] == listify_lookup_plugin_terms(test_terms, Templar(loader), loader)

    # Test with invalid strings
    test_terms = "   "
    assert [] == listify_lookup_plugin_terms(test_terms, Templar(loader), loader)

    # Test with valid strings
    test_terms = "  test_terms  "

# Generated at 2022-06-21 08:50:55.203444
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    class DummyVarsModule(object):
        def __init__(self, varname, value):
            self.varname = varname
            self.value = value

        def vars(self):
            return {self.varname: self.value}

    listterms = [
        "a",
        "b",
        "c",
    ]

    # Terms are a list
    results = listify_lookup_plugin_terms(listterms, Templar(loader=DataLoader()), DummyVarsModule('var', 12))
    assert is_sequence(results)
    assert results == listterms

    # Terms are a string
    results

# Generated at 2022-06-21 08:50:56.120840
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-21 08:51:05.810291
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables={})

    assert listify_lookup_plugin_terms(["1","2","3"], templar, loader) == ["1","2","3"]
    assert listify_lookup_plugin_terms([1,2,3], templar, loader) == [1,2,3]
    assert listify_lookup_plugin_terms({"a":"1","b":"2"}, templar, loader) == [{"a":"1","b":"2"}]
    assert listify_lookup_plugin_terms(43, templar, loader) == [43]
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_

# Generated at 2022-06-21 08:51:16.744454
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    vm = VariableManager()
    vm.set_host_variable('host_var', 'host_var')
    vm.set_fact_cache('172.31.14.133', 'fact_var', 'fact_var')
    vm.set_group_variable('group_name', 'group_var', 'group_var')

    # 'a', 'b', 'c'
    templar = Templar(loader=loader, variables=variable_manager)
    terms = 'a, b, c'
    terms = listify_lookup_plugin_terms(terms, templar, loader, True, False)
   

# Generated at 2022-06-21 08:51:28.730981
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test1_terms = 'abc def,ghi'
    test1_expected = [ u'abc', u'def', u'ghi' ]

    test2_terms = ['abc', 'def,ghi']
    test2_expected = [ u'abc', u'def,ghi' ]

    test3_terms = ['abc', ['def', 'ghi']]
    test3_expected = [ u'abc', [u'def', u'ghi'] ]

    test4_terms = [u'abc', [u'def', [u'abc', u'ghi']], u'jkl', u'mno']
    test4_expected = [ u'abc', [u'def', [u'abc', u'ghi']], u'jkl', u'mno' ]

    # To be used with the templar parameter

# Generated at 2022-06-21 08:51:41.394427
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader(), variables={'foo': 'bar'})
    terms = '{{ foo }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)

    templar = Templar(loader=DataLoader(), variables={'foo': 'bar'})
    terms = '{{ foo }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False)
    assert isinstance(terms, list)

    templar = Templar(loader=DataLoader())

# Generated at 2022-06-21 08:51:53.884340
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    t = Templar(loader=None)
    f = lambda x: t.template(x, fail_on_undefined=False)

    assert listify_lookup_plugin_terms(1, t, None, fail_on_undefined=False, convert_bare=False) == [1]
    assert listify_lookup_plugin_terms(range(1), t, None, fail_on_undefined=False, convert_bare=False) == [range(1)]
    assert listify_lookup_plugin_terms("a,b", t, None, fail_on_undefined=False, convert_bare=False) == ['a,b']

# Generated at 2022-06-21 08:52:01.953794
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    class DummyVaultSecret:
        '''
        Dummy class that doesnt do anything that a real
        VaultSecret would do
        '''
        def __init__(self):
            self._contents = None

        def load(self, data):
            self._contents = data
            return self

        def __str__(self):
            return self._contents

        def __add__(self, other):
            return self._contents + other

        def __radd__(self, other):
            return other + self._contents

    vault_secret = DummyVaultSecret()


# Generated at 2022-06-21 08:52:12.083388
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # import for testing
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    v = VariableManager()
    l = DataLoader()
    i = InventoryManager()
    t = Templar(vars=v, loader=l, inventory=i)

    terms = listify_lookup_plugin_terms(terms=['a','b','c'], templar=t, loader=l, fail_on_undefined=True, convert_bare=False)
    assert terms == ['a', 'b', 'c']

# Generated at 2022-06-21 08:52:23.393101
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible import context
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    loader = context.CLIARGS._loader
    variable_manager.extra_vars = combine_vars(loader=loader, variables=context.CLIARGS.extra_vars)
    templar = Templar(loader=loader, variables=variable_manager)

    terms1 = "foo"
    terms2 = ["foo"]
    terms3 = AnsibleUnicode("foo")
    terms4 = AnsibleUnicode("{{ foo }}")

# Generated at 2022-06-21 08:52:47.267350
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    loader = None
    inventory = Inventory(loader=loader, variable_manager=None, host_list=None)
    templar = Templar(loader=loader, variables=variable_manager, inventory=inventory)

    assert listify_lookup_plugin_terms(terms=[1,2,3], templar=templar, loader=loader) == [1,2,3]
    assert listify_lookup_plugin_terms(terms=1, templar=templar, loader=loader) == [1]

# Generated at 2022-06-21 08:52:58.649866
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.lookup import LookupBase
    from ansible.parsing.mod_args import ModuleArgsParser
    C.DEFAULT_HASH_BEHAVIOUR = 'replace'
    lookup = LookupBase()
    lookup.basedir = './test_lookup'
    loader = AnsibleLoader(None, 'test_lookup', 'test_lookup', True)
    templar = Templar(loader=loader, variables={'inventory_hostname': 'test'})
    module_args_parser = ModuleArgsParser(template_class=templar)

# Generated at 2022-06-21 08:53:08.031080
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_bytes

    def assert_lists(before, after):
        assert listify_lookup_plugin_terms(before, None, None, True) == after

    assert_lists(["a", "b", "c"], ["a", "b", "c"])
    assert_lists("a b c", ["a", "b", "c"])
    assert_lists("a\nb\nc", ["a", "b", "c"])
    assert_lists("a\nb c", ["a", "b c"])
    assert_lists("a\nb \"c d\"", ["a", "b \"c d\""])
    assert_lists(["a", "b", ["c", "d"]], ["a", "b", ["c", "d"]])

# Generated at 2022-06-21 08:53:11.691458
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert listify_lookup_plugin_terms('foo', Templar(), object()) == ['foo']
    assert listify_lookup_plugin_terms(['foo','bar'], Templar(), object()) == ['foo', 'bar']

# Generated at 2022-06-21 08:53:21.993562
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    # Test: [ A,B,C ] # should return A,B,C as a list
    terms = [ u"A", u"B", u"C" ]
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == terms

    # Test: [ A ] # should return A as a list
    terms = [ u"A" ]
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == terms

    # Test: A # should return A (as a list)
    terms = u"A"
    result = listify_lookup_plugin_terms(terms, templar, None)

# Generated at 2022-06-21 08:53:33.884343
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Convert terms=None to terms=[]
    templar = DummyTemplar()
    loader = DummyLoader()
    terms = listify_lookup_plugin_terms(templar=templar, loader=loader)
    assert terms == []

    # Convert terms='foo' to terms=['foo']
    templar = DummyTemplar()
    loader = DummyLoader()
    terms = listify_lookup_plugin_terms(terms='foo', templar=templar, loader=loader)
    assert terms == ['foo']

    # Convert terms=['foo', 'bar'] to terms=['foo', 'bar']
    templar = DummyTemplar()
    loader = DummyLoader()

# Generated at 2022-06-21 08:53:46.222679
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template.safe_eval import safe_eval
    from ansible.template.template import Templar

    terms = '[{"foo": "bar"}, "myvar"]'
    vars = {"myvar": "myvalue"}
    loader = None

    # Note: convert_bare=True is needed in two places to handle this properly.
    templar = Templar(loader=loader, variables=vars, convert_bare=True)
    result = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)
    assert result == [{'foo': 'bar'}, 'myvalue']
    result = listify_lookup_plugin_terms(safe_eval(terms), templar, loader, convert_bare=True)
    assert result == [{'foo': 'bar'}, 'myvalue']

# Generated at 2022-06-21 08:53:54.669720
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import ansible.parsing.yaml.loader

    class TestVarsModule(object):
        def get_vars(self, loader, path, entities):
            return dict()

    class TestRunner(object):
        def __init__(self, module_name, module_args, module_vars=None, module_path=None):
            self._result = dict(invocation=dict(module_args=module_args))

        def run(self, task_vars=None):
            return self._result

        def get_result(self):
            return self._result

        def get_task_result(self, task_vars):
            return self._result


# Generated at 2022-06-21 08:54:07.034606
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.templating import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.module_utils._text import to_text

    assert listify_lookup_plugin_terms([1, 2], Templar(VariableManager()), None, True) == [1, 2]
    wrapped_str = AnsibleUnsafeText('foo')
    assert isinstance(wrapped_str, AnsibleUnsafeText)
    assert listify_lookup_plugin_terms(wrapped_str, Templar(VariableManager()), None, True) == ['foo']

# Generated at 2022-06-21 08:54:17.915306
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.errors import AnsibleUndefinedVariable

    templar = Templar(loader=AnsibleLoader(None))


# Generated at 2022-06-21 08:54:55.542423
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar


# Generated at 2022-06-21 08:55:04.674928
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    x = PlayContext()
    t = Templar(loader=None, variables=dict(foo='bar'), shared_loader_obj=None)

    assert listify_lookup_plugin_terms("{{ foo }}", templar=t, loader=None, fail_on_undefined=True, convert_bare=False) == ["bar"]
    assert listify_lookup_plugin_terms("{{ foo }}", templar=t, loader=None, fail_on_undefined=True, convert_bare=True) == ["bar"]
    assert listify_lookup_plugin_terms("'{{ foo }}'", templar=t, loader=None, fail_on_undefined=True, convert_bare=True) == ["bar"]

# Generated at 2022-06-21 08:55:15.485307
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    templar = Templar(loader=loader, variables=variable_manager)

    class FakePlayContext:
        def __init__(self):
            self.accelerate = False
            self.accelerate_ipv6 = False

    fake_play_context = FakePlayContext()
    templar._available_variables = variable_manager
    templar.set_available_variables(fake_play_context)

    # simple tests
    assert listify_lookup_plugin_terms('localhost', templar, loader) == ['localhost']

# Generated at 2022-06-21 08:55:26.148323
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    terms = 'foo {{ var }}'
    templar = Templar(loader=DataLoader(), variables={'var': 'bar'})
    t = listify_lookup_plugin_terms(terms, templar, templar._loader)
    assert isinstance(t, list)
    assert len(t) == 1
    assert t[0] == 'foo bar'
    terms = ['foo {{ var }}']
    t = listify_lookup_plugin_terms(terms, templar, templar._loader)
    assert isinstance(t, list)
    assert len(t) == 1
    assert t[0] == 'foo bar'

# Generated at 2022-06-21 08:55:32.305217
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms("a,b,c", templar=None, loader=None) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms("a,b,c".split(','), templar=None, loader=None) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms("a", templar=None, loader=None) == ['a']