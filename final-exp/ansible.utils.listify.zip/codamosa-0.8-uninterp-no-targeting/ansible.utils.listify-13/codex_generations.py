

# Generated at 2022-06-21 08:45:42.819041
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    terms = '{{ foo }}'
    templar = Templar(loader=DataLoader(), variables=VariableManager(loader=DataLoader(), inventory=InventoryManager(loader=DataLoader())))
    templar._available_variables = dict(foo='bar')

    result = listify_lookup_plugin_terms(terms, templar, templar._loader)
    assert result == ['bar']

    terms = None
    result = listify_lookup_plugin_terms(terms, templar, templar._loader)
    assert result is None

# Generated at 2022-06-21 08:45:53.612859
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    # Check when terms is string
    terms = "{{ foo }}"
    templar = Templar(loader=loader, variables=variable_manager)
    variable_manager.set_nonpersistent_facts({"foo": "bar"})
    assert listify_lookup_plugin_terms(terms, templar, loader) == ["bar"]

    # Check when terms is list
    terms = ["{{ foo1 }}", "{{ foo2 }}"]
    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-21 08:46:03.385594
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    terms = [
        ['a'],
        'b',
        'c',
        {'foo': 'bar'},
        'd'
    ]

    expected_terms = [
            'a',
            'b',
            'c',
            'd'
    ]

    from ansible import constants as C
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.play_context import PlayContext

    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash


    # initialize needed objects
    loader = DataLoader()

# Generated at 2022-06-21 08:46:14.972816
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dictionary import AnsibleDict
    from ansible.module_utils._text import to_text
    from ansible.plugins.lookup.pipe import LookupModule
    from ansible.template import Jinja2Environment
    import jinja2
    import os

    pipe_lookup = LookupModule()

    jenv = Jinja2Environment(undefined=jinja2.StrictUndefined)
    templar = Templar(loader=os.getcwd(), variables={}, environment=jenv)

    # test single element list


# Generated at 2022-06-21 08:46:22.878571
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)
    result = listify_lookup_plugin_terms(['a', 'b', 'c'], templar, loader)
    assert result == ['a', 'b', 'c']
    result = listify_lookup_plugin_terms('a,b,c', templar, loader)
    assert result == ['a', 'b', 'c']
    result = listify_lookup_plugin_terms('{{ test }}', templar, loader)
    assert result == ['{{ test }}']
    result = listify_lookup_plugin

# Generated at 2022-06-21 08:46:32.763582
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeVarsModule:
        def __init__(self):
            self.fake_var = "red"

        def __getattr__(self, name):
            if name == 'fake_var':
                return self.fake_var
            else:
                raise AttributeError

    class FakeTemplarModule:
        def __init__(self):
            self.vars = FakeVarsModule()

        def template(self, terms, fail_on_undefined=True):
            if isinstance(terms, string_types):
                if terms == '{{fake_var}}':
                    return self.vars.fake_var
                else:
                    return terms
            else:
                return terms

    class FakeLoaderModule:
        pass

    templar = FakeTemplarModule()
    loader = FakeLoaderModule()


# Generated at 2022-06-21 08:46:44.770761
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext

    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    from units.mock.loader import DictDataLoader
    from units.mock.vars import mock_vars_dict

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.inventory)
    variable_manager.extra_vars = mock_vars_dict

    templar = Templar(loader=loader, variables=variable_manager)

    pc = PlayContext()
    templar._available_variables = variable_manager
    templar.set_available_variables(variable_manager)

    terms = '''
      {{ foo.bar }}
    '''
    assert listify_lookup_

# Generated at 2022-06-21 08:46:54.636710
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    my_vault_secret = VaultLib({'password': 'secret'})

    my_loader = DictDataLoader({
        'vars': {
            'foo': 'bar',
            'baz': True
        },
        'vault': {
            'secret': my_vault_secret
        }
    })

    my_templar = Templar(loader=my_loader, vault_secrets=[my_vault_secret])

    terms = listify_lookup_plugin_terms('{{foo}}', templar=my_templar, loader=my_loader)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert terms[0] == 'bar'

    terms = list

# Generated at 2022-06-21 08:47:06.231467
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleError

    fldr = os.path.dirname(__file__)
    vars_dir = os.path.join(fldr, 'vars')

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inv=inv)
    templar = Templar(loader=loader, variables=variable_manager)

    result = listify_lookup_plugin_terms("{{ [ 1, 2, 3] }}", templar, loader)

# Generated at 2022-06-21 08:47:16.819718
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    dummy_loader = DataLoader()
    dummy_var_manager = VariableManager()
    dummy_inventory = None


    def do_test(terms, result, convert_bare=False, fail_on_undefined=True):
        terms = listify_lookup_plugin_terms(terms, Templar(loader=dummy_loader,
                                                          variables=dummy_var_manager,
                                                          inventory=dummy_inventory),
                                            dummy_loader,
                                            convert_bare=convert_bare,
                                            fail_on_undefined=fail_on_undefined)
        assert terms == result

    # Test that non-string results are returned

# Generated at 2022-06-21 08:47:29.719701
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib

    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        "foo": ["one", "two", "three"],
        "bar": "baz",
        "bam": "boom",
        "ansible_password": "Vault password",
        "ansible_become_password": "Vault password",
        "ansible_vault_password": "Vault password"
    }
    vault_secrets = [('default', 'Vault password')]
    vault = VaultLib(vault_secrets)
    templar = Templar(loader=None, variables=variable_manager, vault_secrets=vault_secrets)

    # Test

# Generated at 2022-06-21 08:47:42.188469
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    fake_loader = DictDataLoader({})
    fake_variables = DictData({'a': 'A', 'b': 'B'})
    t = Templar(loader=fake_loader, variables=fake_variables)

    # listify a string
    #  * with one item
    assert listify_lookup_plugin_terms("A", t, fake_loader) == ['A']
    #  * with two items
    assert listify_lookup_plugin_terms("A, B", t, fake_loader) == ['A', 'B']
    assert listify_lookup_plugin_terms("A , B", t, fake_loader) == ['A', 'B']

# Generated at 2022-06-21 08:47:53.949699
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    from ansible.utils.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager

    from ansible.template.templar import Templar
    from ansible.inventory.host import Host

    t = Templar(variables={'a': 'foo', 'b': 'bar'}, fail_on_undefined=False)

    def u(x):
        return UnsafeProxy(x, needs_tmp_copy=False)

    assert listify_lookup_plugin_terms("{{a}}", t, None, convert_bare=True) == ['foo']

# Generated at 2022-06-21 08:48:05.915545
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys
    import json
    
    import datetime
    
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.urls import open_url

    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import lookup_loader
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars

    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.display import Display
    
    # Check that an empty variable will

# Generated at 2022-06-21 08:48:14.091899
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    template_data = 'spam'
    templar = Templar(variables=combine_vars(loader=None, variables=dict()))
    result = listify_lookup_plugin_terms(template_data, templar, loader=None, fail_on_undefined=True, convert_bare=False)

    assert isinstance(result, list), 'Result should be a list, is %s instead' % type(result)
    assert len(result) == 1, 'Result should be a list of length 1, is %s instead' % len(result)
    assert result[0] == template_data, 'Result list contents should be %s, is %s instead' % (template_data, result)


# Generated at 2022-06-21 08:48:23.123523
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict

    from ansible.template import Templar

    m_templar = Templar(loader=None)

    # Test the string case

# Generated at 2022-06-21 08:48:34.484208
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import os
    import sys

    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible import template
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']

# Generated at 2022-06-21 08:48:43.867342
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Verify listify_lookup_plugin_terms returns a list
    terms = [
        'string', '{{var}}',
        123, 456,
        {'a': 1, 'b': 2},
        ['x', 'y', 'z'],
    ]
    assert isinstance(listify_lookup_plugin_terms(terms, None, None), list)

    # Verify listify_lookup_plugin_terms will expand variables
    terms = [
        'string', '{{var}}',
        123, 456,
        {'a': 1, 'b': 2},
        ['x', 'y', 'z'],
    ]
    results = listify_lookup_plugin_terms(terms, None, None)
    assert results[1] == '{{var}}'

    # Verify listify_lookup_plugin

# Generated at 2022-06-21 08:48:56.041253
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.template import Templar
    from ansible.parsing.vault import VaultLib

    plaintext = """---
        foo: 1
        bar:
        - 2
        - 3"""

# Generated at 2022-06-21 08:49:03.078952
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    assert listify_lookup_plugin_terms(u'{{["a", "b"]}}',
                                       Templar(VariableManager(), loader=DataLoader()),
                                       loader=DataLoader()) == ['a', 'b']
    assert listify_lookup_plugin_terms([u'a', u'b'],
                                       Templar(VariableManager(), loader=DataLoader()),
                                       loader=DataLoader()) == ['a', 'b']
    assert listify_lookup_plugin_terms(u'a',
                                       Templar(VariableManager(), loader=DataLoader()),
                                       loader=DataLoader()) == ['a']

# Generated at 2022-06-21 08:49:09.946346
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # Load data
    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test simple string
    terms = "one"
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result[0] == "one"

    # Test string with eval
    terms = "{{ 1 + 1 }}"
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result[0] == 2

    # Test list
    terms = ["one", "two"]
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result[0] == "one"
    assert result[1]

# Generated at 2022-06-21 08:49:21.242023
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class FakeVarsModule(object):
        def __init__(self):
            self.DictType = dict
            self.list = list

    class FakeLoader(object):
        def __init__(self):
            self.vars = FakeVarsModule()

    def _test(terms, expected):
        templar = Templar(loader=loader)
        assert expected == listify_lookup_plugin_terms(terms, templar, loader)

    loader = FakeLoader()

    _test([u'foo', u'bar'], [u'foo', u'bar'])
    _test('foo, bar', [u'foo, bar'])
    _test('{{foo}}', [u'{{foo}}'])

# Generated at 2022-06-21 08:49:32.728988
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    class FakeModule(object):
        def __init__(self):
            self.params = {}

    module = FakeModule()

    assert listify_lookup_plugin_terms(' ', templar=None, loader=None) == [' ']
    assert listify_lookup_plugin_terms('\n', templar=None, loader=None) == ['\n']
    assert listify_lookup_plugin_terms('', templar=None, loader=None) == ['']

# Generated at 2022-06-21 08:49:41.345521
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Test look up plugin terms'''

    from ansible.template import Templar

    assert listify_lookup_plugin_terms('1', Templar({}, loader=None)) == [1]
    assert listify_lookup_plugin_terms('1 2', Templar({}, loader=None)) == [1, 2]
    assert listify_lookup_plugin_terms('a', Templar(dict(a=1), loader=None)) == [1]
    assert listify_lookup_plugin_terms('a b', Templar(dict(b=2,a=1), loader=None)) == [1, 2]

# Generated at 2022-06-21 08:49:51.253229
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(['a', 1, 2], templar, loader) == ['a', 1, 2]
    assert listify_lookup_plugin_terms(1, templar, loader) == [1]
    assert listify_lookup_plugin_terms([], templar, loader) == []
    
    assert listify_lookup_plugin_terms('a', templar, loader) == ['a']
    assert listify_lookup_plugin_terms('a,b', templar, loader) == ['a', 'b']

# Generated at 2022-06-21 08:50:00.318899
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.template import Templar
    from ansible.vars.manager import VariableManager

    new_vm = VariableManager()

    class MyLookupModule(LookupBase):

        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_cls = MyLookupModule()

    templar = Templar(loader=None, variables=new_vm)

    assert lookup_cls._listify_lookup_plugin_terms(templar, [1, 2, 3]) == [1, 2, 3]
    assert lookup_cls._listify_lookup_plugin_terms(templar, '1,2,3') == ['1,2,3']
    assert lookup_cls._listify_lookup_plugin_

# Generated at 2022-06-21 08:50:09.550753
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # Sample data
    my_terms = dict(key1='value1')
    templar = Templar(loader=None, variables=dict())

    # Test first branch
    assert listify_lookup_plugin_terms(my_terms, templar, None) == [dict(key1='value1')]

    # Test second branch
    assert listify_lookup_plugin_terms('string', templar, None) == ['string']

    # Test third branch
    assert listify_lookup_plugin_terms(['string1', 'string2'], templar, None) == ['string1', 'string2']

# Generated at 2022-06-21 08:50:15.442335
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    vars = VariableManager()
    vars.extra_vars = dict(
        # Use this to prove that this test runs in a sane environment
        hostvars = dict(
            foo = dict(
                name = 'foo',
                ha_enabled = 'yes',
            ),
            bar = dict(
                name = 'bar',
                ha_enabled = 'no',
            ),
            nyan = dict(
                name = 'nyan',
                ha_enabled = 'maybe',
            ),
        ),
        # For undefined lookup testing
        test_undefined = dict(
            hostvars_does_not_exist = dict(
                name = 'baz',
                ha_enabled = 'yes',
            ),
        ),
    )



# Generated at 2022-06-21 08:50:22.985233
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-21 08:50:33.520807
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    loader = 'dummy_loader'
    play_context = PlayContext()
    variable_manager = VariableManager()

    # Test with a string value
    templar = variable_manager.set_and_templarize(loader=loader, play_context=play_context)
    test_terms = ['{ "test1": "test2" }', 'test3']
    for term in test_terms:
        assert listify_lookup_plugin_terms(term, templar, loader) == ['{ "test1": "test2" }', 'test3']

    # Test with a dict value

# Generated at 2022-06-21 08:50:48.315143
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()

    vault_secrets = VaultLib([])
    t = Templar(loader=loader, shared_loader_obj=loader, vault_secrets=vault_secrets,
                variables={'a': 'foo', 'b': ['a', 'b', 'c'], 'r': '%', 'rb': '%', 't': '~'})

    pc = PlayContext()

    # Test with a string
    terms = listify_lookup_plugin_terms("{{ a }}", t, loader)
    assert terms == ['foo']

    # Test with a list

# Generated at 2022-06-21 08:50:56.237048
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    import ansible.parsing.yaml.objects

    templar = Templar(loader=None)

    # An ordinary string
    terms = 'string'
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert(terms == ['string'])

    # Pre-defined yaml value

# Generated at 2022-06-21 08:51:05.885716
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' test_listify_lookup_plugin_terms '''
    from ansible.template import Templar

    loader = FakeLoader()
    templar = Templar(loader=loader, variables={})
    test_terms = [
        "{{ foo }}",
        "{{ foo }}",
        1,
        2,
        3,
        [
            "{{ bar }}",
            "{{ bar }}",
            4,
            5,
            6,
            [
                "{{ bax }}",
                "{{ baz }}",
                7,
                8,
                9,
                [
                    "{{ qux }}",
                    "{{ qux }}",
                    10,
                    11,
                    12,
                ]
            ]
        ]
    ]


# Generated at 2022-06-21 08:51:16.780284
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    inventory = dict(
        hostvars = dict(
            foo = dict(
                ansible_ssh_user = 'test_user'
            )
        )
    )
    loader = DictDataLoader(dict(vars=dict(z='foo')))
    inventory.set_variable_manager(VariableManager(loader=loader, inventory=inventory))
    inventory.add_host(host='foo')
    templar = Templar(loader=loader, variables=inventory.get_vars(host='foo'))

    # Test with a single string term
    terms = listify_lookup_plugin_terms('{{z}}', templar, loader)
    assert isinstance(terms, list)

# Generated at 2022-06-21 08:51:28.731001
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar

    templar = Templar(loader=None)

    expected = ["a", "b", "c"]
    result = listify_lookup_plugin_terms(terms="a, b, c", templar=templar, loader=None)
    assert result == expected, "%s != %s" % (result, expected)

    expected = ["x", "y", "z"]
    result = listify_lookup_plugin_terms(terms=["x,y", "z"], templar=templar, loader=None)
    assert result == expected, "%s != %s" % (result, expected)

    expected = ["x", "y", "z"]

# Generated at 2022-06-21 08:51:41.397010
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import jinja2.exceptions
    import ansible.parsing.dataloader
    import ansible.vars.unsafe_proxy

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    variable_manager._extra_vars = {}
    variable_manager._options = {}
    variable_manager.load_extra_vars(loader=loader)
    variable_manager.set_inventory(ansible.inventory.manager.Inventory(loader=loader))

    variable_manager._vault = None

    variable_manager._fact_cache = {}
    variable_manager._valid_cache = {}

    templar = ansible.parsing.templar.Templar(loader=loader, variables=variable_manager)

   

# Generated at 2022-06-21 08:51:48.950691
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    terms = "{{ lookup('file', '/etc/resolv.conf') }}"

    loader = DataLoader()
    templar = Templar(loader=loader)

    results = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=True)

    assert results[0].startswith('# Generated by NetworkManager')

# Generated at 2022-06-21 08:51:52.341153
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C

    from ansible.template import Templar

    from ansible.plugins.loader import lookup_loader

    class TestTemplar(Templar):
        def __init__(self, variables):
            self._available_variables = variables

    variables = dict(
        foo='bar',
        one=1,
        two=2,
        three=3,
        four=4.0,
        list=["a",",","b",2],
        dictdict={'a': {'c': "d"}, 'b': {'c': "d"}, 'c': {'c': "d"}},
        file='/etc/passwd',
    )

    # Test strings as input:
    templar = TestTemplar(variables)

# Generated at 2022-06-21 08:52:01.294300
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.playbook.play
    import ansible.playbook.includer
    import ansible.template.template

    loader = ansible.playbook.play_context.Loader()
    variable_manager = ansible.playbook.play_context.VariableManager()
    variable_manager._extra_vars={}
    variable_manager._options=dict(connection='local')
    variable_manager._vault_password=None
    variable_manager.options_vars=[]
    variable_manager._original_vars=dict()
    variable_manager._all_vars=dict()
    variable_manager._fact_cache=dict()
    variable_manager._templar = ansible.template.template.Template(loader=loader, variables=variable_manager.get_vars())
    assert listify_lookup_plugin_terms

# Generated at 2022-06-21 08:52:11.697352
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # setup test objects
    class TestVarsModule:
        def __init__(self, loader):
            self.data = {'a': 'b', 'c': [1, 2, 3]}

        def vars(self, loader):
            return self.data

    class TestLoaderModule(object):
        def __init__(self):
            self.vars = TestVarsModule(self)

    # setup context
    C.DEFAULT_HASH_BEHAVIOUR = 'merge'
    context = PlayContext()
    templar = Templar(loader=TestLoaderModule(), variables=context.get_all_vars())

    # test different types of input
    # test type int


# Generated at 2022-06-21 08:52:25.402020
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import PY3
    from ansible.template import Templar

    my_vars = dict(
        string1='foo',
        list1=['foo', 'bar'],
        list2=['foo', 'bar'],
        list3=['foo', 'bar'],
    )

    my_loader = 'fake_loader'
    my_fail_on_undefined = False
    my_convert_bare = False

    if PY3:
        my_templar = Templar(loader=my_loader, variables=my_vars)
    else:
        my_templar = Templar(loader=my_loader, variables=my_vars, fail_on_undefined=my_fail_on_undefined, convert_bare=my_convert_bare)

    my_

# Generated at 2022-06-21 08:52:36.860796
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    vault_secrets = VaultLib([], {'password_file':None, 'vault_password_file':None})
    templar = Templar(loader=None, variables={}, vault_secrets=vault_secrets)
    assert listify_lookup_plugin_terms('file', templar, None) == ['file']

    templar = Templar(loader=None, variables={'files': ['file1', 'file2']})
    assert listify_lookup_plugin_terms('{{ files }}', templar, None) == ['file1', 'file2']
    assert listify_lookup_plugin_terms(['{{ files }}'], templar, None) == ['file1', 'file2']
    assert list

# Generated at 2022-06-21 08:52:46.625551
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # pylint: disable=import-error
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # pylint: enable=import-error

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(test='test')

    templar = Templar(loader=None, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ test }}', templar, None) == ['test']
    assert listify_lookup_plugin_terms(['{{ test }}'], templar, None) == ['test']
    assert listify_lookup_plugin_terms(['1', '2'], templar, None) == ['1', '2']

# Generated at 2022-06-21 08:52:52.836104
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.playbook.templar

    templar = ansible.playbook.templar.Templar(loader=None)
    # test that a bare string is returned unmodified
    terms = 'test'
    terms_result = listify_lookup_plugin_terms(terms, templar)
    assert terms == terms_result, "%s != %s" % (terms, terms_result)
    # test that a list is returned unmodified
    terms = ['test']
    terms_result = listify_lookup_plugin_terms(terms, templar)
    assert terms == terms_result, "%s != %s" % (terms, terms_result)
    # test that a comma-separated string is split into a list
    terms = 'test1,test2'
    terms_result = listify_look

# Generated at 2022-06-21 08:53:03.923465
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Test 1
    args = [ '{{ var }}' ]
    terms = listify_lookup_plugin_terms(args, Templar(loader=None, variables={'var': 'one'}), None)
    assert terms == ['one'], terms

    # Test 2
    args = [ '{{ var }}', 'two' ]
    terms = listify_lookup_plugin_terms(args, Templar(loader=None, variables={'var': 'one'}), None)
    assert terms == ['one', 'two'], terms

    # Test 3
    args = [ ' {{ var }} ' ]
    terms = listify_lookup_plugin_terms(args, Templar(loader=None, variables={'var': 'one'}), None)
    assert terms == ['one'], terms

    # Test 4

# Generated at 2022-06-21 08:53:07.604287
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms("foo,bar", None, None) == ["foo", "bar"]
    assert listify_lookup_plugin_terms("foo", None, None) == ["foo"]

# Generated at 2022-06-21 08:53:15.332818
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils import plugin_docs

    module_name = 'test_custom.py'
    module = plugin_docs.get_docstring(module_name)
    args = module['options']
    choices = args['choices']['choices']

    # Test1: call listify_lookup_plugin_terms with a string
    terms = 'foobar'
    results = listify_lookup_plugin_terms('{{ choices.0 }}', choices, None)
    assert(terms == results[0])

    # Test2: call listify_lookup_plugin_terms with a list
    terms = ['foobar']
    results = listify_lookup_plugin_terms(terms, choices, None)
    assert(terms == results)

    # Test3: call listify_lookup_plugin_terms with a string and a

# Generated at 2022-06-21 08:53:25.082705
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    myvars = dict(
        foo='bar',
        baz=[1, 2],
        my_list=[1, 2, '{{foo}}']
    )
    variable_manager = VariableManager()
    variable_manager.set_vars(myvars)
    templar = Templar(loader=loader, variable_manager=variable_manager)

    # Test with string that should get templated
    assert listify_lookup_plugin_terms('{{foo}}', templar, loader) == ['bar']

    # Test with a list that should get templated

# Generated at 2022-06-21 08:53:31.346735
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    terms = '{{ item }}'
    templar = Templar(loader=AnsibleLoader(terms))

    assert listify_lookup_plugin_terms([], templar) == []
    assert listify_lookup_plugin_terms("", templar) == ['']
    assert listify_lookup_plugin_terms("    ", templar) == ['']
    assert listify_lookup_plugin_terms("    x    ", templar) == ['x']
    assert listify_lookup_plugin_terms("    x y    ", templar) == ['x y']

# Generated at 2022-06-21 08:53:36.389136
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    t = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms("a b c", t, None) == ['a b c']
    assert listify_lookup_plugin_terms("a,b,c", t, None) == ['a,b,c']
    assert listify_lookup_plugin_terms("a", t, None) == ['a']
    assert listify_lookup_plugin_terms("a\nb\nc", t, None) == ['a\nb\nc']
    assert listify_lookup_plugin_terms("a\nb,c", t, None) == ['a\nb,c']

# Generated at 2022-06-21 08:53:56.142525
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This function needs access to an initialized templar
    # Create a pretend AnsibleOptions() object which will do
    # not fully initialized but as far as this function is
    # concerned that doesn't matter
    from ansible.utils import plugin_docs

    opts = plugin_docs.AnsibleOptions()

    # Create a pretend module. This is required by AnsibleTemplar to
    # allow loading jinja2 filters
    import ansible.module_utils
    class Module(object):
        def __init__(self, module_name):
            self.module_name = module_name
    module = Module("")

    from ansible.template import Templar
    templar = Templar(loader=None, variables={}, shared_loader_obj=None,
                      options=opts, **module.__dict__)

    # a python list

# Generated at 2022-06-21 08:54:07.985180
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    templar = Templar(loader=loader, variable_manager=variable_manager)

    # test on strings
    assert listify_lookup_plugin_terms("{{var1}}", templar, loader) == ["somevar"]
    assert listify_lookup_plugin_terms("{{var1}} {{var2}}", templar, loader) == ["somevar", "anothervar"]

# Generated at 2022-06-21 08:54:19.063823
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    from ansible.template import Templar

    terms = range(0,10)
    templar = Templar()

    # Already a list, should stay that way
    new_terms = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert isinstance(new_terms, list)

    # Bare strings get templated (with convert_bare=False)
    new_terms = listify_lookup_plugin_terms('{{foo}}', templar, loader=None, fail_on_undefined=True, convert_bare=False)

# Generated at 2022-06-21 08:54:29.178049
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    terms = '{{ var1 }},{{ var2 }}'
    var1 = 'val1'
    var2 = ['val2','val3']
    var3 = 'val4'
    inventory = Inventory(VariableManager())
    vars = {'var1': var1, 'var2': var2, 'var3': var3 }
    inventory.set_variable_manager(VariableManager(loader=None, host_list=None, inventory=inventory, variables=vars))
    templar = Templar(loader=None, variables=vars, inventory=inventory)
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['val1', 'val2', 'val3']

# Generated at 2022-06-21 08:54:39.157797
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = dict(
        magic_variables=dict(),
    )

    inventory = dict(
        host_list=[],
        group_list=[],
        groups=dict(),
    )

    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=inventory))

    assert listify_lookup_plugin_terms(terms="{{ foo.bar.baz }}", templar=templar, loader=None) == ["{{ foo.bar.baz }}"]
    assert listify_lookup_plugin_terms(terms="foo.bar.baz", templar=templar, loader=None) == ["foo.bar.baz"]


# Generated at 2022-06-21 08:54:48.506727
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext

    v = VaultLib([])
    context = PlayContext()
    templar = Templar(loader=None, variables=VariableManager(), vault_secrets=['vault_secret'],
                      convert_bare=True, fail_on_undefined=False, disable_lookups=False,
                      context=context)

    terms = 'some_value'
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['some_value']

    terms = ['{{ some_var }}']
    result = list

# Generated at 2022-06-21 08:54:57.658272
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    # test string
    terms = "{{ test_var }}"
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(result, list)
    assert result[0] == "{{ test_var }}"
    # test list
    terms = ["{{ test_var }}", "{{ test_var_2 }}"]
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(result, list)
    assert [0] == "{{ test_var }}"
    assert [1] == "{{ test_var_2 }}"
    # test non string, non list
    terms = 1
    result = listify_lookup_plugin_

# Generated at 2022-06-21 08:55:06.405026
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.display import Display
    from ansible.parsing.yaml.loader import AnsibleLoader

    d = Display()
    d.verbosity = 3

    templar = Templar(loader=None, variables={})


# Generated at 2022-06-21 08:55:16.528285
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import context
    import ansible.template
    import ansible.parsing.yaml
    import ansible.parsing.dataloader

    assert listify_lookup_plugin_terms("foo", ansible.template.Templar(loader=ansible.parsing.dataloader.DataLoader()), ansible.parsing.dataloader.DataLoader()) == ['foo']
    assert listify_lookup_plugin_terms(["foo"], ansible.template.Templar(loader=ansible.parsing.dataloader.DataLoader()), ansible.parsing.dataloader.DataLoader()) == ['foo']

# Generated at 2022-06-21 08:55:25.502154
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    class TestVars(object):
        def __init__(self):
            self.test_1_var = "foo"
            self.test_2_var = "bar"
    test_vars = TestVars()
    templar = Templar(loader=None, variables=test_vars)
    assert listify_lookup_plugin_terms("{{test_1_var}}", templar, None) == ["foo"]
    assert listify_lookup_plugin_terms(["{{test_1_var}}", "{{test_2_var}}"], templar, None) == ["foo", "bar"]