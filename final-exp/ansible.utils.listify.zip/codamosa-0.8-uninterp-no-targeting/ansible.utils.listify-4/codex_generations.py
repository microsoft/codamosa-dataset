

# Generated at 2022-06-21 08:45:38.035347
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    vault_pass = 'secret'
    loader = None
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play()
    tqm = None
    templar = Templar(loader=loader, variables=variable_manager, vault_passwords=[vault_pass])

    terms = templar.template("{{ ['foo', 'bar', 'baz'] }}", fail_on_undefined=True)

# Generated at 2022-06-21 08:45:45.892694
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import pytest

    class TestVars(object):
        def __init__(self, a):
            self.a = a

    dataloader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host=None, varname='a', value=TestVars('A'))
    templar = Templar(loader=dataloader, variable_manager=variable_manager)

    # test that listify_lookup_plugin_terms accepts dict
    t = dict(a=42)
    assert listify_lookup_plugin_terms(t, templar, dataloader) == [t]

    #

# Generated at 2022-06-21 08:45:55.111054
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts({'a': '1', 'b': '2', 'c': '3', 'd': '4', 'e': '5'})
    templar = Templar(loader=loader, variables=variable_manager)
    assert listify_lookup_plugin_terms(['a', 'c-', 'abc'], templar, loader) == ['1', 'c-', 'abc']

# Generated at 2022-06-21 08:46:04.491177
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # test for the conversion of a non-list to one
    assert listify_lookup_plugin_terms('test', Templar({}), None) == ['test']

    # test for the conversion of a non-list to one
    assert listify_lookup_plugin_terms('test', Templar({}, 'hostvars/foo'), None) == ['test']

    # test for the conversion of a non-list to one
    assert listify_lookup_plugin_terms(['test'], Templar({}, 'hostvars/foo'), None) == ['test']

    # test for the conversion of a non-list to one
    assert listify_lookup_plugin_terms(['test', 'test2'], Templar({}, 'hostvars/foo'), None) == ['test', 'test2']

    # test for

# Generated at 2022-06-21 08:46:15.715990
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # Setup vault encryption
    vault_secret = 'secret'
    vault_password = VaultLib([])
    vault_password.update({'default': vault_secret}, 'secret string')
    play_context = PlayContext(vault_password=vault_password)

    # Setup Templar
    variable_manager = VariableManager()
    loader = None
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=[])

# Generated at 2022-06-21 08:46:23.292518
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    def _get_loader(data):
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager

        loader = DataLoader()
        loader.set_basedir('./')

        variable_manager = VariableManager()
        variable_manager.extra_vars = data
        variable_manager.options_vars = data

        return Templar(loader=loader, variables=variable_manager)

    templar = _get_loader({'a': 'b'})
    assert [u"b"] == listify_lookup_plugin_terms(u"{{ a }}", templar, None, convert_bare=True)

# Generated at 2022-06-21 08:46:30.469947
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('a', None) == ['a']
    assert listify_lookup_plugin_terms('a\nb', None) == ['a', 'b']
    assert listify_lookup_plugin_terms('a\nb', None) == ['a', 'b']
    assert listify_lookup_plugin_terms(['a', 'b'], None) == ['a', 'b']
    assert listify_lookup_plugin_terms('a'*100, None) == ['a'*100]

# Generated at 2022-06-21 08:46:36.790235
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class Templar:
        def template(self, value, fail_on_undefined=True, convert_bare=True):
            return value

    class Loader:
        def get_basedir(self, value):
            return value

    templar = Templar()
    loader = Loader()

    test_terms = [
        "foo",
        '{{ foo }}',
        ['foo', 'bar'],
        '{{ foo }}',
        ['foo', '{{ bar }}'],
        ['foo', ['bar', '{{ baz }}']]
    ]

    expected = [
        "foo",
        'bar',
        ["foo", "bar"],
        'bar',
        ["foo", "bar"],
        ["foo", ["bar", "baz"]]
    ]


# Generated at 2022-06-21 08:46:48.374851
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test that a simple string is returned as a list with one element
    terms = 'string'
    assert listify_lookup_plugin_terms(terms, None, None, fail_on_undefined=False) == ['string']

    # Test that a complex string is returned as a list with one element
    terms = 'complex string'
    assert listify_lookup_plugin_terms(terms, None, None, fail_on_undefined=False) == ['complex string']

    # Test that a non-string that is iterable is returned as a list with 
    # one element
    terms = ['iterable']
    assert listify_lookup_plugin_terms(terms, None, None, fail_on_undefined=False) == ['iterable']

    # Test that an integer is returned as a list with one element
    terms = 1
   

# Generated at 2022-06-21 08:46:52.231755
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.parsing.yaml.loader
    import ansible.template
    terms = ['a', 'b', 'c']
    templar = ansible.template.AnsibleTemplar(loader=ansible.parsing.yaml.loader.AnsibleLoader())
    terms = listify_lookup_plugin_terms(terms, templar)
    assert terms == ['a', 'b', 'c']

# Generated at 2022-06-21 08:47:06.966270
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.parsing.dataloader
    import ansible.template

    dl = ansible.parsing.dataloader.DataLoader()
    t = ansible.template.Template(dl)

    assert listify_lookup_plugin_terms(["a", "b", "c"], t, dl) == ["a", "b", "c"]
    assert listify_lookup_plugin_terms("{{ foo }}", t, dl, fail_on_undefined=False) == ["{{ foo }}"]
    assert listify_lookup_plugin_terms("{{ foo }}", t, dl, fail_on_undefined=False, convert_bare=True) == [""]

# Generated at 2022-06-21 08:47:17.395940
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six.moves import StringIO

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes

    raw_params = {
        'debug': False,
        '_ansible_no_log': False,
        '_ansible_debug': False,
        '_ansible_check_mode': False,
        '_ansible_diff': boolean(True),
    }


# Generated at 2022-06-21 08:47:28.848828
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys
    from ansible.module_utils.six import PY3

    if PY3:
        unicode_type = str
    else:
        unicode_type = unicode

    if sys.version_info[:2] == (2, 6):
        long_type = long
    else:
        long_type = int

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    loader = 'foo'
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)
    test_fail_on_undefined = False

    assert listify_lookup_plugin_terms(1, templar, loader, fail_on_undefined=test_fail_on_undefined) == [1]
    assert listify_lookup

# Generated at 2022-06-21 08:47:41.413315
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.parsing.yaml.objects
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar

    # Make AnsibleLoader return our fake literal 'foo' when it encounters 'bar'
    class FakeConstructor:
        def __init__(self, base):
            pass
        def construct_yaml_str(self,node):
            return 'foo'
    AnsibleLoader.add_constructor(u'tag:yaml.org,2002:str', FakeConstructor)

    loader = AnsibleLoader(None, None, None, None)
    templar = Templar(loader=loader)

    # Test: Convert to a list via templating when input is a list

# Generated at 2022-06-21 08:47:52.690652
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from units.mock.vars import MockVarsModule

    text_plain_vault_secret = VaultLib.encrypt(u'$ANSIBLE_VAULT;1.1;AES256\n35373333393761643233333363336616635313863663239633563343739656531366138373331623\n39613332396632353533303439326364333535633233393639333466363962326131613731316665\n3034363365393561\n', None)
    text_plain_vault_secret_2 = VaultLib

# Generated at 2022-06-21 08:47:59.852942
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class MyYAML(AnsibleBaseYAMLObject):
        pass

    class FakeVarManager(VariableManager):
        def __init__(self):
            self._my_vars = {}

        def clear_vars(self):
            self._my_vars = {}

        def set_host_variable(self, host, varname, value):
            self._my_vars[varname] = value

        def get_vars(self):
            return self._my_vars

    vm = FakeVarManager()
    vm.set_host_variable

# Generated at 2022-06-21 08:48:04.567821
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    def _vault_secrets(text, **kwargs):
        returntext = text
        return returntext

    vault = VaultLib([])
    vault.read_vault_secret = _vault_secrets
    templar = Templar(None, vault_secrets=vault)

    # check simple string
    terms = "string"
    terms_converted = listify_lookup_plugin_terms(terms, templar)
    assert isinstance(terms_converted, list)
    assert len(terms_converted) == 1
    assert terms_converted[0] == "string"

    # check convert_bare param
    terms = "{{ string }}"
    terms_converted = listify_lookup_plugin

# Generated at 2022-06-21 08:48:12.435507
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars

    template_vars = AnsibleVars(loader=None, variables=dict(
        foo="bar",
        biz=42
    ))

    templar = Templar(loader=None, variables=template_vars)
    terms = listify_lookup_plugin_terms(42, templar, loader)
    assert terms == [42]
    terms = listify_lookup_plugin_terms('{{foo}}', templar, loader)
    assert terms == ['bar']
    terms = listify_lookup_plugin_terms('{{biz}}', templar, loader)
    assert terms == [42]

# Generated at 2022-06-21 08:48:21.678482
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class Options(object):
        template = False

    class Templar(object):
        def __init__(self):
            self.options = Options()

        def template(self, x, *args):
            if isinstance(x, dict):
                return dict([(key, self.template(val)) for key, val in x.items()])
            elif isinstance(x, list):
                return [self.template(y) for y in x]
            else:
                return x

    class ModuleLoader(object):
        pass

    loader = ModuleLoader()
    templar = Templar()

    assert listify_lookup_plugin_terms(['a', 'b', 'c'], templar, loader, fail_on_undefined=True, convert_bare=False) == ['a', 'b', 'c']
    assert list

# Generated at 2022-06-21 08:48:32.993391
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # import modules needed for unit test
    import sys
    from collections import namedtuple
    from ansible.module_utils.templar import Templar

    # Create a dummy class that mimics the behavior of an AnsibleTask
    class AnsibleTask(object):
        def __init__(self):
            self.args = {
                '_ansible_no_log': False,
                '_ansible_verbosity': 3,
                '_ansible_version': '2.4.2',
                '_ansible_selinux_special_fs': [],
                '_ansible_builtin_fs': ['archive', 'copy', 'stat', 'tempfile', 'file', 'script', 'template'],
            }

    # Create a dummy class that mimics the behavior of an AnsibleModule

# Generated at 2022-06-21 08:48:44.751053
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Mock ansible.module_utils.common._collections_compat.Iterable
    class mock_Iterable(object):
        def __init__(self, obj):
            self.obj = obj
        def __iter__(self):
            return iter(self.obj)
    # Mock ansible.parsing.templating.AnsibleTemplate
    class mock_templar(object):
        def __init__(self, obj):
            self.obj = obj
        def template(self, terms, *args, **kwargs):
            return self.obj
    # Mock ansible.parsing.dataloader.DataLoader
    class mock_loader(object):
        def __init__(self, obj):
            self.obj = obj

# Generated at 2022-06-21 08:48:55.371093
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    
    from ansible.template import Templar
    
    script_args = dict(
        _raw_params = '{{ foo }}',
        _task_vars = dict(),
    )
    terms = listify_lookup_plugin_terms(script_args, Templar(loader=None, variables=dict()), loader=None, fail_on_undefined=False, convert_bare=False)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert terms[0] == '{{ foo }}'
    pass

# Generated at 2022-06-21 08:49:02.932788
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Initialize objects
    vault_password = 'secret'
    loader = DataLoader()
    templar = Templar(loader=loader, variables=VariableManager())
    vault = VaultLib(vault_password, loader=loader, templar=templar)

    # Try to decrypt an encrypted- once with the plain value and once with the encrypted value
    # Encrypted value (should be decrypted in both cases)

# Generated at 2022-06-21 08:49:13.541669
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms(terms="{{ [ 'a', 'b' ] }}", templar=templar, loader=None) == ['a','b']
    assert listify_lookup_plugin_terms(terms="{{ 'a' }}", templar=templar, loader=None) == ['a']
    assert listify_lookup_plugin_terms(terms=['a', 'b'], templar=templar, loader=None) == ['a','b']
    assert listify_lookup_plugin_terms(terms='a', templar=templar, loader=None) == ['a']

# Generated at 2022-06-21 08:49:23.534828
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook import Play
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = variable_manager.get_inventory("localhost")
    variable_manager.set_inventory(inventory)

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ templated_var }}')))
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    tqm = None
    # not using the playbook

# Generated at 2022-06-21 08:49:33.588572
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, None)

    templar = Templar(loader=loader)

    # Test bare values through the templar
    #test_str = "{{ item }}"

    # Test various iterables
    test_str = {'item1', 'item2'}
    test_dict = {'item1', 'item2'}
    test_list = {'item1', 'item2'}
    test_tuple = {'item1', 'item2'}

    result = listify_lookup_plugin_terms(test_str, templar, loader)
    assert isinstance(terms, string_types)


# Generated at 2022-06-21 08:49:44.060291
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    import ansible.parsing.yaml

    class DummyVarsModule:

        def __init__(self):
            self.vars = dict(abc=123, xyz=456)

        def get_vars(self, loader, play, host, task, include_deps):
            return self.vars

        def get_vars_files(self, play):
            return []

        def get_host_vars(self, loader, host, play):
            return self.vars

        def get_host_vars_from_group(self, loader, host, groupname, play):
            return self.vars

        def add_host_vars(self, host, vars, _add_host=True):
            self.vars.update(vars)


# Generated at 2022-06-21 08:49:54.340871
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms("{{ test1 }}", templar, loader) == [u'test1']
    assert listify_lookup_plugin_terms("{{ test1 }}", templar, loader, convert_bare=True) == [u'test1']

    assert listify_lookup_plugin_terms("{{ test2 }}", templar, loader) == [u'test2']
    assert listify_lookup_plugin_terms("{{ test2 }}", templar, loader, convert_bare=True) == [u'test2']


# Generated at 2022-06-21 08:50:02.201969
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    def _get_var(name):
        return name

    def _get_vars(names):
        return names

    class MockVars(object):
        def __init__(self, vars):
            self._vars = vars

        def get_vars(self, loader, play, host, task):
            return self._vars

    variable_manager = VariableManager()
    variable_manager.get_vars = _get_vars
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.host_vars = {'localhost': {'ansible_connection': 'local'}}

    loader = DataLoader()

   

# Generated at 2022-06-21 08:50:11.518731
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    def _get_terms(terms, undefined='missing', bare=False):
        templar = Templar(loader=None, variables={})
        return listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=undefined=='missing', convert_bare=bare)

    loader = DataLoader()

    # empty terms (should return [])
    assert _get_terms(None) == []
    assert _get_terms('') == []
    assert _get_terms([]) == []

    # raw terms (should return terms without change)
    assert _get_terms(42) == [42]
    assert _get_terms(42.5) == [42.5]
    assert _get

# Generated at 2022-06-21 08:50:28.765668
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from units.mock.loader import DictDataLoader

    templar = DictDataLoader({}).get_basedir() # use empty env

    assert listify_lookup_plugin_terms([1,2,3], templar, loader=None) == [1, 2, 3]
    assert listify_lookup_plugin_terms({'foo': 'bar'}, templar, loader=None) == [{'foo': 'bar'}]
    assert listify_lookup_plugin_terms('foobar', templar, loader=None) == ['foobar']
    assert listify_lookup_plugin_terms(b'foobar', templar, loader=None) == ['foobar']
    assert listify_lookup_plugin_terms

# Generated at 2022-06-21 08:50:40.869661
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.listify import listify_lookup_plugin_terms

    templar = Templar(loader=None, variables=VariableManager(), fail_on_undefined=True)

    def assert_is_iterable(terms, message=None):
        if message is None:
            message = "Expected terms to be an iterable object."
        assert isinstance(terms, Iterable), message

    def assert_is_term_list(terms, expected, message=None):
        assert_is_iterable(terms, message)

# Generated at 2022-06-21 08:50:50.554091
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Strings are cast to lists if not already lists
    assert listify_lookup_plugin_terms("foo", Templar({}), None) == ["foo"]
    assert listify_lookup_plugin_terms("foo,bar", Templar({}), None) == ["foo,bar"]

    assert listify_lookup_plugin_terms(["foo", "bar"], Templar({}), None) == ["foo", "bar"]
    assert listify_lookup_plugin_terms(["foo, bar", "baz"], Templar({}), None) == ["foo, bar", "baz"]

    # Templates are evaluated
    assert listify_lookup_plugin_terms("{{ foo }}", Templar({'foo': 'foo'}), None) == ["foo"]

# Generated at 2022-06-21 08:50:59.419026
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('index.yml', {}, {}, False, False) == ['index.yml']
    assert listify_lookup_plugin_terms(['index.yml'], {}, {}, False, False) == ['index.yml']
    assert listify_lookup_plugin_terms('index.yml', {'item': 'index.yml'}, {}, False, False) == ['index.yml']
    assert listify_lookup_plugin_terms(['index.yml'], {'item': 'index.yml'}, {}, False, False) == ['index.yml']

# Generated at 2022-06-21 08:51:07.489486
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    import pytest

    fake_loader = DictDataLoader({})
    var_manager = VariableManager()

    templar = Templar(loader=fake_loader, variables=var_manager)

    # test string
    terms = 'string'
    results = listify_lookup_plugin_terms(terms, templar, fake_loader)
    assert isinstance(results, list)
    assert len(results) == 1
    assert results[0] == terms

    # test list
    terms = ['one', 'two', 'three']
    results = listify_lookup_plugin_terms(terms, templar, fake_loader)
    assert isinstance(results, list)
    assert len(results) == 3
    assert results[0]

# Generated at 2022-06-21 08:51:17.297252
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar, DictData

    lookup_list = listify_lookup_plugin_terms('{{["a", "b", "c"]}}', Templar(loader=None, variables=DictData()), loader=None)
    assert lookup_list == ["a", "b", "c"], \
        "listify_lookup_plugin_terms returned: %s instead of: %s" % (lookup_list, ["a", "b", "c"])

    lookup_list = listify_lookup_plugin_terms(['a', 'b', 'c'], Templar(loader=None, variables=DictData()), loader=None)

# Generated at 2022-06-21 08:51:29.132561
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    import os

    context = PlayContext()
    context._vars = dict()
    context._vars['inventory_dir'] = os.path.expanduser('~')
    # context._loader = DataLoader()

    tmplar = Templar(loader=None, variables=context._vars)

    assert listify_lookup_plugin_terms(None, tmplar, None, fail_on_undefined=True, convert_bare=False) == []
    assert listify_lookup_plugin_terms('', tmplar, None, fail_on_undefined=True, convert_bare=False) == ['']

# Generated at 2022-06-21 08:51:41.735681
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    loader = DataLoader()
    var_mgr = VariableManager()
    inv_mgr = InventoryManager(loader=loader, sources=['localhost,'])
    var_mgr.set_inventory(inv_mgr)
    templar = Templar(loader=loader, variable_manager=var_mgr)

    result = listify_lookup_plugin_terms('foo', templar, loader)
    assert result == ['foo']

    result = listify_lookup_plugin_terms('foo,bar', templar, loader)
    assert result == ['foo', 'bar']

    result = listify_lookup_

# Generated at 2022-06-21 08:51:54.221968
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'item': 'testval'}
    variable_manager.options_vars = {'a': 'testopt', 'b': '{{ item }}'}
    templar = Templar(loader, variable_manager)

    results = [['testopt', 'testval'], ['testopt', 'testval'], ['testopt', 'testval']]
    assert results[0] == listify_lookup_plugin_terms([['a', 'b']], templar, loader)

# Generated at 2022-06-21 08:52:02.154232
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    mock_vault_password = VaultLib('secret')

    # create mock templar
    templar = Templar(loader=None, variables={})
    templar._available_variables = {
        'omg': "bbq",
        'nested': {
            'omg': "bbq",
            'list': [
                "item0",
                "item1",
                "item2",
            ],
            'dict': {
                'item1': "value1",
            },
            'is_undefined': None,
        },
        'is_undefined': None,
    }
    templar._vault = mock_vault_password._vault
    templar._fail_on_

# Generated at 2022-06-21 08:52:28.622793
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Unit test for listify_lookup_plugin_terms'''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    # DataLoader and variable manager for testing only
    loader = DataLoader()
    variable_manager = VariableManager()

    # Initialize Item class for test
    class Item(object):
        '''Class to represent items from an inventory'''
        def __init__(self, name, hostvars=None, groups=None):
            self.name = name
            self.hostvars = hostvars
            self.groups = groups

    # Create some items
    item1 = Item('localhost')
    item2 = Item('otherhost')

    # Add hostvars to items
    item1.hostv

# Generated at 2022-06-21 08:52:39.911496
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    assert not listify_lookup_plugin_terms(1, templar) or type(listify_lookup_plugin_terms(1, templar)) == list
    assert listify_lookup_plugin_terms('1', templar) == ['1']
    assert listify_lookup_plugin_terms('1, 2', templar) == ['1', '2']
    assert listify_lookup_plugin_terms('1, 2', templar, convert_bare=True) == [1, 2]
    assert listify_lookup_plugin_terms(['1', '2'], templar) == ['1', '2']

# Generated at 2022-06-21 08:52:49.508658
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, play_context=context)

    # Test with a list
    terms = ['{{ x }}', '{{ y }}']
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['', '']

    # Test with a str
    terms = '{{ x }} {{ y }}'
    variable_manager.extra_vars['x'] = 'foo'


# Generated at 2022-06-21 08:53:01.319032
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeLoader:
        def get_basedir(self, path):
            return os.path.dirname(path)

    class FakeVars:
        def get_vars(self, play, host):
            return dict(foo='bar')

    class FakeRunner:
        def __init__(self):
            self._loader = FakeLoader()
            self._variable_manager = FakeVars()

    fakerunner = FakeRunner()
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    templar = Templar(loader=fakerunner._loader, variables=fakerunner._variable_manager)
    play_context = PlayContext(variable_manager=fakerunner._variable_manager, loader=fakerunner._loader)

# Generated at 2022-06-21 08:53:09.645688
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Mock up AnsibleOptions, since we don't have actual options
    def get_option(name):
        if name == 'basedir':
            return './'
        else:
            raise AssertionError('Invalid option name: %s' % name)

    data = {'test': 'success'}

    # We only need to mock up partial functionality here; we only need
    # enough to make this function work.
    class MockInventory:
        def get_hosts(self, pattern):
            return ['']

    class MockLoader:
        def get_basedir(self):
            return './'

        def load_from_file(self, path):
            return data

    var_

# Generated at 2022-06-21 08:53:20.639072
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    from ansible.errors import AnsibleUndefinedVariable

    # Empty string case
    assert listify_lookup_plugin_terms(
        '',
        Templar({}, None, None, {}, loader=None),
        None,
        False
    ) == [None]

    # Return string as-is
    assert listify_lookup_plugin_terms(
        '{{ foo }}',
        Templar(dict(foo='bar'), None, None, {}, loader=None),
        None,
        False
    ) == ['bar']

    # Return list as-is

# Generated at 2022-06-21 08:53:28.706324
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template.safe_eval import unsafe_eval

    assert not isinstance(listify_lookup_plugin_terms(1, None, None), string_types)
    assert isinstance(listify_lookup_plugin_terms("1", None, None), list)
    assert not isinstance(listify_lookup_plugin_terms(['1','2'], None, None), string_types)
    assert isinstance(listify_lookup_plugin_terms("1", None, None), list)
    assert listify_lookup_plugin_terms("1", None, None)[0] == 1

    # Test string template

# Generated at 2022-06-21 08:53:40.804074
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert listify_lookup_plugin_terms(['{{foo}}', '{{bar}}'], {'foo': '1', 'bar': ['a', 'b', 'c']}, loader=None, fail_on_undefined=False, convert_bare=False) == ['1', ['a', 'b', 'c']]
    assert listify_lookup_plugin_terms('{{foo}}', {'foo': '1'}, loader=None, fail_on_undefined=False, convert_bare=False) == ['1']
    assert listify_lookup_plugin_terms('{{foo}}', {'foo': '{{bar}}'}, {'bar': '1'}, fail_on_undefined=False, convert_bare=False) == ['1']

# Generated at 2022-06-21 08:53:51.341831
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-21 08:54:02.949804
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('test', templar, loader) == ['test']
    assert listify_lookup_plugin_terms([u'test'], templar, loader) == [u'test']
    assert listify_lookup_plugin_terms(['test', 'test2'], templar, loader) == ['test', 'test2']
    assert listify_lookup_plugin_terms('test{{foo}}', templar, loader, convert_bare=True) == ['test{{foo}}']
   

# Generated at 2022-06-21 08:54:43.412987
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    import ansible.parsing.yaml
    import ansible.module_utils.six as six

    yaml_str = """
- string_val
- int_val: 1
- list_val:
  - foo
  - bar
- dict_val:
    foo: bar
    baz: 1
"""

    terms = ansible.parsing.yaml.safe_load(yaml_str)

    t = ansible.template.AnsibleTemplate(terms, config=ansible.template.TemplarConfig())
    t.template
    l = listify_lookup_plugin_terms(terms, t, None)

    assert isinstance(l, list), "Listify didn't return a list"


# Generated at 2022-06-21 08:54:53.720111
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = ['a', 'b', 'c']
    templar = Templar([], [], {})

    data = listify_lookup_plugin_terms('a', templar, [])
    assert len(data) == 1
    assert isinstance(data, list)

    data = listify_lookup_plugin_terms('a,b,c', templar, [])
    assert len(data) == 1
    assert isinstance(data, list)

    data = listify_lookup_plugin_terms('{{ a }}', templar, [])
    assert len(data) == 1
    assert isinstance(data, list)

    data = listify_lookup_plugin_terms(terms, templar, [])
    assert len(data) == 3

# Generated at 2022-06-21 08:55:02.362033
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    tests = [
        {'terms': 'foo',
         'expected': ['foo']
        },
        {'terms': ['foo', 'bar'],
         'expected': ['foo', 'bar']
        },
        {'terms': 'foo {{bar}}',
         'expected': ['foo {{bar}}']
        },
        {'terms': ['foo {{bar}}'],
         'expected': ['foo {{bar}}']
        },
    ]

    for test in tests:
        result = listify_lookup_plugin_terms(test['terms'], Templar(loader=lookup_loader), lookup_loader)
        assert result == test['expected']

# Generated at 2022-06-21 08:55:13.651281
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    templar = Templar(loader=None, boolean_runtime=True, variables=combine_vars(dict()))
    terms = [
        AnsibleUnicode('{{ foo }}'),
        {'key': '{{ bar }}'},
        'baz'
    ]

    # Assert we get back a list of strings
    terms_list = listify_lookup_plugin_terms(terms, templar, loader=None)

    assert isinstance(terms_list, list)
    assert isinstance(terms_list[0], string_types)
    assert isinstance(terms_list[1], string_types)

# Generated at 2022-06-21 08:55:25.352628
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''test_listify_lookup_plugin_terms'''
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    passwords = {'vault_password': None}
    templar = Templar(loader=None, variables={}, vault_secrets=passwords)
    to_text(None)
    teststr = "{{mystring}}"
    teststr2 = "{{mystring}}{{mystring}}"
    teststr3 = "{{mystring}} and {{mystring}}"
    testlist = "{{mylist}}"
    testdict = '{{mydict}}'

# Generated at 2022-06-21 08:55:36.621669
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    if PY2:
        from ansible.utils import unicode

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 'alpha', 'l': ['beta', 'gamma']}
    variable_manager.set_nonpersistent_facts(variable_manager.extra_vars)
    vault_secrets = ['SECRET_A', 'SECRET_B']
    vault_passwords = {'vault_password_file': 'mypasswords.txt'}