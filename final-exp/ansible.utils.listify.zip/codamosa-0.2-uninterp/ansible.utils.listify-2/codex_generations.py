

# Generated at 2022-06-17 15:14:29.269225
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_vault_secrets(['secret'])
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ var }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['{{ var }}']

    # Test list
    terms = ['{{ var }}', '{{ var2 }}']
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['{{ var }}', '{{ var2 }}']

    # Test dict
   

# Generated at 2022-06-17 15:14:37.076585
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test string
    terms = '{{ foo }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)

# Generated at 2022-06-17 15:14:48.204369
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ baz }}',
    ]

    templar = Templar(loader=None, variables=dict(foo='foo', bar='bar', baz='baz'))

    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['foo', 'bar', 'baz']
    assert listify_lookup

# Generated at 2022-06-17 15:14:58.417629
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    terms = listify_lookup_plugin_terms('foo', templar, loader)
    assert terms == ['foo']

    terms = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)


# Generated at 2022-06-17 15:15:08.603374
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{baz}}'], templar, loader) == ['foo', 'bar', '{{baz}}']

# Generated at 2022-06-17 15:15:14.256759
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    # Setup
    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = Play().set_loader(loader)
    tqm = None
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test string


# Generated at 2022-06-17 15:15:24.214284
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    loader = AnsibleLoader(None, variable_manager=VariableManager())
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader) == ['a', 'b']
    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader, convert_bare=True) == ['a', 'b']
    assert listify_lookup_plugin_terms('a', templar, loader) == ['a']
    assert listify_lookup_plugin_terms('a', templar, loader, convert_bare=True) == ['a']

# Generated at 2022-06-17 15:15:29.565072
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ bam }}',
    ]

    variables = dict(
        foo='foo',
        bar='bar',
        bam='bam',
    )

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = variables
    play_context = PlayContext()


# Generated at 2022-06-17 15:15:37.865596
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    terms = [u'foo', u'bar', u'baz']
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None)))
    assert listify_lookup_plugin_terms(terms, templar, None) == [u'foo', u'bar', u'baz']

    terms = u'foo'
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None)))

# Generated at 2022-06-17 15:15:44.101064
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    # Create a fake inventory
    inventory = InventoryManager(loader=None, sources='')

    # Create a fake variable manager
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Create a fake loader
    loader = 'fake loader'

    # Create a fake play context
    play_context = PlayContext()

    # Create a fake templar

# Generated at 2022-06-17 15:15:53.159180
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(a=1, b=2, c=3))
    templar = Templar(loader=None, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{a}}', templar, None) == [1]
    assert listify_lookup_plugin_terms(['{{a}}', '{{b}}'], templar, None) == [1, 2]

# Generated at 2022-06-17 15:15:59.664621
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    loader = None
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string input
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo, bar', templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:16:08.988574
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # Test list
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']

    # Test list of lists
    assert listify_lookup_plugin_terms([['foo']], templar, None) == [['foo']]

    # Test list of lists with string
    assert listify_lookup_plugin_terms(['foo', ['bar']], templar, None) == ['foo', ['bar']]

    # Test list of lists with string

# Generated at 2022-06-17 15:16:20.255080
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test with a string
    terms = '{{ foo }}'

# Generated at 2022-06-17 15:16:32.371530
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    # Test with a string
    terms = '{{ foo }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert terms == ['{{ foo }}']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    terms = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert terms == ['{{ foo }}', '{{ bar }}']

    # Test with a dict
    terms = {'foo': '{{ foo }}', 'bar': '{{ bar }}'}
    terms = listify_lookup_

# Generated at 2022-06-17 15:16:45.165527
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    loader = AnsibleLoader(None, variable_manager=VariableManager())
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(['a', 'b', 'c'], templar, loader) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms('a', templar, loader) == ['a']
    assert listify_lookup_plugin_terms('a,b,c', templar, loader) == ['a', 'b', 'c']

# Generated at 2022-06-17 15:16:57.165884
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo, bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo,bar, baz', templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:17:04.967389
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = 'dummy_loader'
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
   

# Generated at 2022-06-17 15:17:13.225491
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{ baz }}'], templar, loader) == ['foo', 'bar', '{{ baz }}']

# Generated at 2022-06-17 15:17:17.993867
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test with a list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test with a dict
    assert listify_lookup_plugin_terms({'foo': 'bar'}, templar, loader) == [{'foo': 'bar'}]

    # Test with a template
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

    #

# Generated at 2022-06-17 15:17:27.281676
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    loader = None
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a string
    terms = "{{ foo }}"
    variable_manager.set_nonpersistent_facts({"foo": "bar"})
    result = listify_lookup_plugin_terms(terms, templar, loader)


# Generated at 2022-06-17 15:17:32.673761
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test with a list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test with a dict
    assert listify_lookup_plugin_terms({'foo': 'bar'}, templar, loader) == [{'foo': 'bar'}]

    # Test with a template
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

# Generated at 2022-06-17 15:17:46.389052
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', templar, loader) == ['foo bar']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo,bar']
    assert listify_lookup_plugin_terms('foo, bar', templar, loader) == ['foo, bar']
    assert listify_lookup_plugin_terms

# Generated at 2022-06-17 15:17:56.406398
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{baz}}'], templar, None) == ['foo', 'bar', '{{baz}}']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{baz}}'], templar, None, convert_bare=True)

# Generated at 2022-06-17 15:18:03.714750
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string
    terms = 'foo'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert terms == ['foo']

    # Test list
    terms = ['foo', 'bar']
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert terms == ['foo', 'bar']

    # Test list with templating
    terms = ['{{ foo }}', '{{ bar }}']
    terms = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-17 15:18:14.144718
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    loader = None
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test string
    terms = '{{ foo }}'
    variable_manager.extra_vars = {'foo': 'bar'}
    result = list

# Generated at 2022-06-17 15:18:25.440162
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test a string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts({'foo': 'bar'})
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # Test a list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set_nonpersistent_facts({'foo': 'bar', 'bar': 'baz'})

# Generated at 2022-06-17 15:18:35.451944
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=True)

    # test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))

# Generated at 2022-06-17 15:18:46.665119
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts({'env': 'prod'})
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ env }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['prod']

    # Test list
    terms = ['{{ env }}', '{{ env }}']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['prod', 'prod']

    # Test list with bare variables

# Generated at 2022-06-17 15:18:54.696229
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      disable_lookups=False,
                      play_context=play_context)

    # Test with a string
    terms = '{{ foo }}'

# Generated at 2022-06-17 15:19:08.696741
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:19:15.375357
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    terms = '{{ foo }}'
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['{{ foo }}']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['{{ foo }}', '{{ bar }}']

    # Test with a list of lists
    terms = [['{{ foo }}', '{{ bar }}'], ['{{ baz }}', '{{ qux }}']]
    assert listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-17 15:19:21.345713
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    # test string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo']

    # test list
    terms = ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo', 'bar']

    # test list with jinja2 template
    terms = ['{{ foo }}', '{{ bar }}']
    assert listify_lookup_plugin_terms(terms, templar, None) == ['{{ foo }}', '{{ bar }}']

    # test list with jinja2 template and convert_bare=True
    terms = ['{{ foo }}', '{{ bar }}']
    assert listify_lookup_plugin_

# Generated at 2022-06-17 15:19:31.276773
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    terms = 'foo'
    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo']

    terms = AnsibleUnicode('foo')
    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo']

    terms = ['foo', 'bar']
    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo', 'bar']

    terms = ['foo', 'bar', AnsibleUnicode('baz')]

# Generated at 2022-06-17 15:19:41.757794
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    templar = Templar(loader=None, variables=VariableManager())
    lookup = lookup_loader.get('file')

    # test string
    assert listify_lookup_plugin_terms('foo', templar, loader=None) == ['foo']

    # test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader=None) == ['foo', 'bar']

    # test dict
    assert listify_lookup_plugin_terms

# Generated at 2022-06-17 15:19:52.860813
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo']

    # test list

# Generated at 2022-06-17 15:19:59.348283
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    terms = listify_lookup_plugin_terms('foo', templar, loader)
    assert terms == ['foo']

    # Test with a list
    terms = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)
    assert terms == ['foo', 'bar']

    # Test with a dict
    terms = listify_lookup_plugin_terms({'foo': 'bar'}, templar, loader)
    assert terms == [{'foo': 'bar'}]

    # Test with a list of dicts

# Generated at 2022-06-17 15:20:07.265148
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:20:17.647439
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    # Create a dummy lookup plugin
    class DummyLookupModule(object):
        def __init__(self, basedir=None, runner=None, **kwargs):
            pass

        def run(self, terms, variables=None, **kwargs):
            return terms

    # Register the dummy lookup plugin
    lookup_loader.add_directory(os.path.join(os.path.dirname(__file__), 'lookup_plugins'))
    lookup_loader.set_default_class

# Generated at 2022-06-17 15:20:29.934117
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:20:44.032076
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    terms = [u'foo', u'bar', u'{{baz}}']
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(baz=AnsibleUnicode('baz'))
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == [u'foo', u'bar', u'baz']


# Generated at 2022-06-17 15:20:52.788131
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vault_secrets = VaultLib([])
    templar = Templar(loader=loader, vault_secrets=vault_secrets)

    # Test with a string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test with a list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test with a dict
    assert listify_lookup_plugin_terms({'foo': 'bar'}, templar, loader) == [{'foo': 'bar'}]

   

# Generated at 2022-06-17 15:21:03.401002
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup

# Generated at 2022-06-17 15:21:14.475048
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)


# Generated at 2022-06-17 15:21:24.722446
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 15:21:37.084655
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
   

# Generated at 2022-06-17 15:21:48.709639
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 15:21:57.352421
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=None, cache=None,
                      fail_on_undefined=True, convert_bare=False)

    # test string
    terms = '{{ foo }}'
    result = listify

# Generated at 2022-06-17 15:22:03.669256
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']


# Generated at 2022-06-17 15:22:11.626362
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = '{{ foo }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == [AnsibleUnicode('{{ foo }}')]

    # test list


# Generated at 2022-06-17 15:22:25.935747
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(foo='bar')
    assert listify_lookup_plugin_terms(terms, templar, loader=lookup_loader) == ['bar']

    terms = AnsibleUnicode('{{ foo }}')

# Generated at 2022-06-17 15:22:33.924735
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = listify_lookup_plugin_terms('foo', templar, loader)
    assert terms == ['foo']

    # Test list
    terms = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)
    assert terms == ['foo', 'bar']

    # Test dict
    terms = listify_lookup_plugin_terms({'foo': 'bar'}, templar, loader)
    assert terms == [{'foo': 'bar'}]

    # Test

# Generated at 2022-06-17 15:22:46.888708
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test template
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

    # Test template with convert_

# Generated at 2022-06-17 15:22:56.325343
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None)

    # test string
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']

    # test AnsibleUnicode
    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, None) == ['foo']

    # test AnsibleUnicode list

# Generated at 2022-06-17 15:23:07.508692
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    # test string
    terms = '{{ foo }}'
    variable_manager.extra_vars = {'foo': 'bar'}
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # test list

# Generated at 2022-06-17 15:23:20.301485
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', templar, loader) == ['foo bar']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo,bar']
    assert listify_lookup_plugin_terms('foo, bar', templar, loader) == ['foo, bar']
    assert listify_lookup_plugin_terms('foo,bar, baz', templar, loader) == ['foo,bar, baz']
    assert listify

# Generated at 2022-06-17 15:23:32.351566
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test list with template
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], templar, loader) == ['{{ foo }}', '{{ bar }}']

    # Test list with template and convert_bare

# Generated at 2022-06-17 15:23:38.640842
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:23:48.275224
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_bytes

    # create a dummy inventory
    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create a dummy play context
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    # create a dummy templar
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))

    # test

# Generated at 2022-06-17 15:23:59.433808
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, loader)

# Generated at 2022-06-17 15:24:22.919313
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{baz}}'], templar, loader) == ['foo', 'bar', '{{baz}}']