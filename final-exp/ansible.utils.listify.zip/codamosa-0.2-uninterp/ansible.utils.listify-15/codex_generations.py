

# Generated at 2022-06-17 15:14:30.876412
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = None
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a string
    terms = "{{ foo }}"
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    result = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-17 15:14:38.792820
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts({"foo": "bar"})
    result = listify_lookup

# Generated at 2022-06-17 15:14:49.859192
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    # Create a fake inventory
    fake_loader = lookup_loader._create_loader()
    inventory = InventoryManager(loader=fake_loader, sources='')
    variable_manager = VariableManager(loader=fake_loader, inventory=inventory)

    # Create a fake play context
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play

# Generated at 2022-06-17 15:14:59.211356
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    templar = Templar(loader=None, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ foo }}', templar, None) == ['bar']
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ foo }}'], templar, None) == ['bar', 'bar']
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ foo }}'], templar, None, convert_bare=True) == ['bar', 'bar']

# Generated at 2022-06-17 15:15:09.350990
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo']

    # Test list
    terms = ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo', 'bar']

    # Test tuple
    terms = ('foo', 'bar')
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo', 'bar']

    # Test dict
    terms = {'foo': 'bar'}

# Generated at 2022-06-17 15:15:17.038669
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    terms = AnsibleUnicode('{{ lookup("pipe", "echo foo") }}')
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    assert listify_lookup_plugin_terms(terms, templar, loader=lookup_loader) == ['foo']

    terms = AnsibleUnicode('{{ lookup("pipe", "echo foo") }}')

# Generated at 2022-06-17 15:15:26.859686
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        foo='bar',
        baz=['one', 'two', 'three'],
        qux=dict(
            one=1,
            two=2,
            three=3,
        ),
    )
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['bar']
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, loader) == ['bar']
    assert listify_lookup

# Generated at 2022-06-17 15:15:35.933770
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))

    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, loader) == ['foo']
    assert listify_lookup_plugin

# Generated at 2022-06-17 15:15:47.841425
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=loader, play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

# Generated at 2022-06-17 15:16:00.339755
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('1', templar, loader) == ['1']
    assert listify_lookup_plugin_terms(['1'], templar, loader) == ['1']
    assert listify_lookup_plugin_terms(['1', '2'], templar, loader) == ['1', '2']

# Generated at 2022-06-17 15:16:06.171826
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # test list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set_nonpersistent_facts

# Generated at 2022-06-17 15:16:17.957542
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))

# Generated at 2022-06-17 15:16:21.744569
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ foo }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert isinstance(terms[0], AnsibleUnicode)

# Generated at 2022-06-17 15:16:33.106725
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a string
    terms = '{{ foo }}'
    variable_manager.extra_vars = {'foo': 'bar'}
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_

# Generated at 2022-06-17 15:16:45.481284
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string input
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list input
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']

    # Test list input with templating
    variable_manager.set_nonpersistent_facts({'foo': 'bar'})
    assert listify_lookup_plugin_terms(['{{foo}}'], templar, loader) == ['bar']

    # Test string

# Generated at 2022-06-17 15:16:57.170364
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar,baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:17:08.409577
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # Test list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set_nonpersistent_facts(dict(foo='bar', bar='baz'))

# Generated at 2022-06-17 15:17:18.861676
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 15:17:24.225467
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    terms = '{{ foo }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}', '{{ bar }}']

    # Test with a dict
    terms = {'foo': '{{ foo }}', 'bar': '{{ bar }}'}

# Generated at 2022-06-17 15:17:35.361467
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']


# Generated at 2022-06-17 15:17:46.095560
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = 'foo'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert terms == ['foo']

    # test list
   

# Generated at 2022-06-17 15:17:56.376617
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager,
                      fail_on_undefined=True)

    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, loader) == ['foo']

# Generated at 2022-06-17 15:18:03.686891
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=None,
                      disable_lookups=False,
                      fail_on_undefined=True,
                      play_context=play_context)

    # Test with a string

# Generated at 2022-06-17 15:18:08.331318
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    terms = listify_lookup_plugin_terms("{{ foo }}", templar, loader)
    assert terms == [AnsibleUnicode('{{ foo }}')]


# Generated at 2022-06-17 15:18:15.951038
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, loader) == ['foo', '{{ bar }}']
    assert listify_look

# Generated at 2022-06-17 15:18:28.181181
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager())
    assert listify_lookup_plugin_terms(terms, templar, None) == [terms]

    terms = ['{{ foo }}', '{{ bar }}']
    templar = Templar(loader=None, variables=VariableManager())
    assert listify_lookup_plugin_terms(terms, templar, None) == terms

    terms = ['{{ foo }}', '{{ bar }}']
    templar = Templar(loader=None, variables=VariableManager())

# Generated at 2022-06-17 15:18:36.067391
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    terms = '{{ foo }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}', '{{ bar }}']

    # Test with a list of lists
    terms = [['{{ foo }}', '{{ bar }}'], '{{ baz }}']

# Generated at 2022-06-17 15:18:47.125483
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', ['bar', 'baz']], templar, loader) == ['foo', ['bar', 'baz']]
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

# Generated at 2022-06-17 15:18:54.815174
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 15:19:05.679733
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = '{{ foo }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)

# Generated at 2022-06-17 15:19:19.879912
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))

    # Test string
    terms = '{{ foo }}'
    variable_manager.extra_vars = {'foo': 'bar'}
    assert listify_lookup_

# Generated at 2022-06-17 15:19:25.891931
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{foo}}')))
        ]
    )

# Generated at 2022-06-17 15:19:33.307634
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    # Test with a string
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # Test with a list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']

    # Test with a list of AnsibleUnicode
    assert listify_lookup_plugin_terms([AnsibleUnicode('foo'), AnsibleUnicode('bar')], templar, None) == ['foo', 'bar']

    # Test with a list of AnsibleUnic

# Generated at 2022-06-17 15:19:46.459187
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(foo=AnsibleUnicode('bar'))
    assert listify_lookup_plugin_terms(terms, templar, None) == ['bar']

    terms = ['{{ foo }}', '{{ bar }}']

# Generated at 2022-06-17 15:19:57.946787
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']

# Generated at 2022-06-17 15:20:10.549020
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    templar = Templar(loader=loader, variables=variable_manager)

    # test string
    terms = '{{ foo }}'
    variable_manager.set_variable('foo', 'bar')
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # test list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set_variable('bar', 'baz')
    assert listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-17 15:20:20.511093
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))

    # Test with a string
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # Test with a list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']

    # Test with a dict
    assert listify_lookup_plugin_terms({'foo': 'bar'}, templar, None) == [{'foo': 'bar'}]

    # Test with a template string
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None) == ['{{ foo }}']

    #

# Generated at 2022-06-17 15:20:28.695137
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ baz }}',
    ]

    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))

# Generated at 2022-06-17 15:20:37.470931
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    variable_manager = VariableManager()
    loader = variable_manager.get_vault_secrets = lambda: dict(vault_pass='secret')

# Generated at 2022-06-17 15:20:50.766914
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    templar = Templar(loader=None, variables=VariableManager())

    # test string
    assert listify_lookup_plugin_terms('foo', templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms('foo', templar, loader=None, convert_bare=True) == ['foo']
    assert listify_lookup_plugin_terms('foo', templar, loader=None, fail_on_undefined=False) == ['foo']

# Generated at 2022-06-17 15:21:08.252709
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    # test string
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']

    # test unicode
    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, None) == ['foo']

    # test unicode list

# Generated at 2022-06-17 15:21:19.667044
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    result

# Generated at 2022-06-17 15:21:24.597686
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

# Generated at 2022-06-17 15:21:37.033332
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:21:48.429716
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test dict
    assert listify_lookup_plugin_terms({'foo': 'bar'}, templar, loader) == [{'foo': 'bar'}]

    # Test template
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

# Generated at 2022-06-17 15:21:55.916943
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader)

# Generated at 2022-06-17 15:22:03.095052
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:22:11.838592
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ baz }}',
    ]

    vars_manager = VariableManager()
    vars_manager.set_nonpersistent_facts(dict(foo='foo', bar='bar', baz='baz'))
    templar = Templar(loader=None, variables=vars_manager)

    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['foo', 'bar', 'baz']


# Generated at 2022-06-17 15:22:21.305330
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      disable_lookups=False,
                      play_context=play_context)

    # test string

# Generated at 2022-06-17 15:22:33.098543
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{foo}}')))
             ]
        )
    play = Play

# Generated at 2022-06-17 15:22:55.989138
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None)))
    templar._available_variables = dict(foo='bar')
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None)))
    templar._available_variables = dict(foo='bar')

# Generated at 2022-06-17 15:23:07.201609
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup

# Generated at 2022-06-17 15:23:20.264282
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None)

    # Test string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['foo']

    # Test list
    terms = ['foo', 'bar']
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['foo', 'bar']

    # Test AnsibleUnicode
    terms = AnsibleUnicode('foo')
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['foo']

    # Test AnsibleUnicode list

# Generated at 2022-06-17 15:23:30.224942
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', AnsibleUnicode('baz')], templar, None) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:23:37.071207
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    # Create a fake lookup plugin
    class FakeLookupModule(object):
        def __init__(self, basedir=None, runner=None, **kwargs):
            pass

        def run(self, terms, variables=None, **kwargs):
            return terms

    # Create a fake inventory
    inventory = InventoryManager(loader=None, sources='')

    # Create a fake variable manager
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Create a fake loader

# Generated at 2022-06-17 15:23:47.399330
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager())
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == [terms]

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager())
    result = listify_lookup_plugin_terms(terms, templar, loader=None, convert_bare=True)
    assert result == [terms]

    terms = AnsibleUnicode('{{ foo }}')

# Generated at 2022-06-17 15:23:59.327461
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # Test list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set_nonpersistent_facts(dict(foo='bar', bar='baz'))

# Generated at 2022-06-17 15:24:10.148980
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test string
    terms = listify_lookup_plugin_terms('foo', templar, loader)
    assert terms == ['foo']

    # test list
    terms = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)
    assert terms == ['foo', 'bar']

    # test list with templating
    terms = listify_lookup_plugin_terms(['foo', '{{ testvar }}'], templar, loader)

# Generated at 2022-06-17 15:24:22.343157
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=None,
                      disable_lookups=False,
                      fail_on_undefined=True,
                      lookups=None,
                      environment=None,
                      play_context=play_context)

    # Test string
    assert list

# Generated at 2022-06-17 15:24:30.080854
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']