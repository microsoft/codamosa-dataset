

# Generated at 2022-06-17 15:14:27.666607
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string
    terms = 'foo'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['foo']

    # Test list
    terms = ['foo', 'bar']
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['foo', 'bar']

    # Test dict
    terms = {'foo': 'bar'}
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == [{'foo': 'bar'}]

    # Test tuple

# Generated at 2022-06-17 15:14:36.361975
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    templar = Templar(loader=loader, variables=variable_manager)

    # test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['bar']

    # test list
    terms = ['{{ foo }}', '{{ bar }}']

# Generated at 2022-06-17 15:14:47.403285
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager())
    assert listify_lookup_plugin_terms(terms, templar, None) == ['{{ foo }}']

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(foo='bar')
    assert listify_lookup_plugin_terms(terms, templar, None) == ['bar']

    terms = AnsibleUnicode('{{ foo }}')

# Generated at 2022-06-17 15:14:58.382688
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{lookup_plugin_terms}}')))
        ]
    )

# Generated at 2022-06-17 15:15:08.602812
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=None,
                      disable_lookups=False,
                      fail_on_undefined=True,
                      play_context=play_context)

    # Test string
    terms = 'foo'


# Generated at 2022-06-17 15:15:14.261564
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo']

    # Test list
    terms = ['foo', 'bar']
   

# Generated at 2022-06-17 15:15:24.213090
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ lookup("pipe", "echo foo") }}')))
        ]
    )

# Generated at 2022-06-17 15:15:33.702325
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:15:47.221882
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['bar']
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, loader) == ['bar']
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ foo }}'], templar, loader) == ['bar', 'bar']

# Generated at 2022-06-17 15:15:52.897984
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    terms = '{{ foo }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}', '{{ bar }}']

    # Test with a list of strings
    terms = ['foo', 'bar']
    result = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-17 15:16:03.869105
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ var1 }}'
    variable_manager.set_nonpersistent_facts(dict(var1='test'))
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['test']

    # Test list
    terms = ['{{ var1 }}', '{{ var2 }}']
    variable_manager.set_nonpersistent_facts(dict(var1='test', var2='test2'))

# Generated at 2022-06-17 15:16:12.039726
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a string
    terms = '{{ foo }}'
    variable_manager.set_variable('foo', 'bar')
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set_variable('foo', 'bar')
    variable_manager.set_variable('bar', 'baz')

# Generated at 2022-06-17 15:16:21.372945
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))


# Generated at 2022-06-17 15:16:32.867161
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = [AnsibleUnicode('{{foo}}'), AnsibleUnicode('{{bar}}')]
    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(foo='foo', bar='bar')
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['foo', 'bar']

    terms = AnsibleUnicode('{{foo}}')
    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(foo='foo')
    result = listify_lookup_

# Generated at 2022-06-17 15:16:45.399635
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:16:57.137330
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins'))
    lookup_plugin = lookup_loader.get('fileglob')

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 15:17:08.373977
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      inventory=inventory,
                      play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin

# Generated at 2022-06-17 15:17:18.828158
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    # Create a temporary lookup plugin
    class TestLookupModule(object):
        def __init__(self, basedir=None, runner=None, **kwargs):
            pass

        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_loader.add('test_lookup_plugin', TestLookupModule)

    # Create a temporary inventory
    inventory = InventoryManager(loader=None, sources=None)

# Generated at 2022-06-17 15:17:27.144001
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(foo='bar')
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

    terms = AnsibleUnicode('{{ foo }}')

# Generated at 2022-06-17 15:17:37.090165
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo']

    # Test list
    terms = ['foo', 'bar']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo', 'bar']

    # Test list with a string
    terms = ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:17:48.456365
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    terms = '{{ foo }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}', '{{ bar }}']

    # Test with a list of lists
    terms = [['{{ foo }}', '{{ bar }}'], ['{{ baz }}', '{{ qux }}']]
    result = listify_lookup_plugin

# Generated at 2022-06-17 15:17:54.680614
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    # Setup
    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test
    assert listify_lookup_plugin_terms(None, templar, loader) == [None]
    assert listify

# Generated at 2022-06-17 15:18:05.533653
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    vault_pass = 'secret'
    loader = DataLoader()
    vault = VaultLib(vault_pass)

    templar = Templar(loader=loader, variables={}, vault_secrets=[vault])

    # Test with string
    terms = '{{ foo }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}']

    # Test with list
    terms = ['{{ foo }}', '{{ bar }}']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}', '{{ bar }}']

    # Test

# Generated at 2022-06-17 15:18:14.833446
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert list

# Generated at 2022-06-17 15:18:27.312470
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    # test string
    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(foo='bar')
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

    # test list
    terms = ['{{ foo }}', '{{ bar }}']
    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(foo='bar', bar='baz')

# Generated at 2022-06-17 15:18:36.981684
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(foo='bar')
    assert listify_lookup_plugin_terms(terms, templar, None) == ['bar']

    terms = '{{ foo }}'

# Generated at 2022-06-17 15:18:48.561273
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    terms = "{{ test_var }}"
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['test_value']

    # Test with a list
    terms = ["{{ test_var }}", "{{ test_var2 }}"]
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['test_value', 'test_value2']

    # Test with a list of lists
    terms = [["{{ test_var }}", "{{ test_var2 }}"], "{{ test_var3 }}"]

# Generated at 2022-06-17 15:18:58.264087
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set_nonpersistent_facts(dict(foo='bar', bar='baz'))

# Generated at 2022-06-17 15:19:07.336047
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=None,
                      template_class=None,
                      exclude_parent_vars=False)

    # Test with a string
    terms = '{{ foo }}'

# Generated at 2022-06-17 15:19:19.351106
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:19:31.483513
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = AnsibleLoader(None, variable_manager=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar = Templar(loader=loader, variables=loader.get_vars(play=dict(name='test_listify_lookup_plugin_terms')))

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', templar, loader) == ['foo bar']

# Generated at 2022-06-17 15:19:41.843133
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test with string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo']

    # test with list
    terms = ['foo', 'bar']
    assert listify_

# Generated at 2022-06-17 15:19:52.898760
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', templar, loader) == ['foo bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:20:03.614745
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{baz}}'], templar, loader, convert_bare=True) == ['foo', 'bar', '{{baz}}']

# Generated at 2022-06-17 15:20:14.266554
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo']

    # Test list
    terms = ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo', 'bar']

    # Test tuple
    terms = ('foo', 'bar')
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo', 'bar']

    # Test dict
    terms = {'foo': 'bar'}

# Generated at 2022-06-17 15:20:22.826630
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # Test list

# Generated at 2022-06-17 15:20:29.740873
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    terms = '{{ foo }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}', '{{ bar }}']

    # Test with a list of lists
    terms = [['{{ foo }}', '{{ bar }}'], ['{{ baz }}']]

# Generated at 2022-06-17 15:20:38.346236
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    # test string
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # test unicode
    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, None) == ['foo']

    # test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']

    # test list with unicode

# Generated at 2022-06-17 15:20:50.806076
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test dict
    assert listify_lookup_plugin_terms({'foo': 'bar'}, templar, loader) == [{'foo': 'bar'}]

    # Test template
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

    # Test template with convert_bare
   

# Generated at 2022-06-17 15:21:01.471217
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    assert listify_lookup_plugin_terms(terms=None, templar=templar, loader=None) == [None]
    assert listify_lookup_plugin_terms(terms='', templar=templar, loader=None) == ['']
    assert listify_lookup_plugin_terms(terms='foo', templar=templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(terms=['foo', 'bar'], templar=templar, loader=None) == ['foo', 'bar']
   

# Generated at 2022-06-17 15:21:16.301129
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    # Setup
    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test 1: string
    terms = '{{ foo }}'

# Generated at 2022-06-17 15:21:25.736506
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      disable_lookups=False,
                      play_context=play_context)

    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, loader) == ['foo']


# Generated at 2022-06-17 15:21:38.180646
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_available_variables(loader.load_from_file('tests/test_listify_lookup_plugin_terms.yml'))
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['bar']
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, loader) == ['bar']

# Generated at 2022-06-17 15:21:45.712585
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    loader = lookup_loader._create_loader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      disable_lookups=False,
                      play_context=play_context)

    # Test with a string
    assert listify_look

# Generated at 2022-06-17 15:21:55.234035
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=None,
                      disable_lookups=False,
                      fail_on_undefined=True,
                      play_context=play_context)

    # test string
    assert listify_

# Generated at 2022-06-17 15:22:05.632250
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms(terms=AnsibleUnicode('foo'), templar=templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(terms=['foo'], templar=templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(terms=['foo', 'bar'], templar=templar, loader=None) == ['foo', 'bar']

# Generated at 2022-06-17 15:22:13.262424
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', ['bar', 'baz']], templar, loader) == ['foo', ['bar', 'baz']]
   

# Generated at 2022-06-17 15:22:22.305836
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None)))
    templar._available_variables = dict(foo=AnsibleUnicode('bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

    terms = ['{{ foo }}']
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None)))

# Generated at 2022-06-17 15:22:28.706508
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))

    # Test with a string
    terms = '{{ foo }}'

# Generated at 2022-06-17 15:22:41.562884
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, None) == ['foo', 'bar', 'baz']
    assert listify_lookup_plugin_terms('foo,bar', templar, None) == ['foo', 'bar']

# Generated at 2022-06-17 15:22:55.840056
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      disable_lookups=False,
                      fail_on_undefined=True,
                      available_variables=variable_manager.get_vars(play=play_context))

    # Test string
    assert listify_

# Generated at 2022-06-17 15:23:07.025913
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    loader = AnsibleLoader(None, variable_manager=VariableManager())
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

# Generated at 2022-06-17 15:23:15.161006
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ baz }}',
    ]

    variables = dict(
        foo='foo',
        bar='bar',
        baz='baz',
    )

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = variables
    play_context = PlayContext()


# Generated at 2022-06-17 15:23:23.254804
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test with a string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts({"foo": "bar"})

# Generated at 2022-06-17 15:23:35.250805
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:23:45.950802
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ baz }}',
    ]

    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(
        foo='foo',
        bar='bar',
        baz='baz',
    )

    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['foo', 'bar', 'baz']


# Generated at 2022-06-17 15:23:53.088328
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    # Test with a string
    terms = '{{ test_var }}'
    templar._available_variables = dict(test_var='foo')
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo']

    # Test with a list
    terms = ['{{ test_var }}', 'bar']
    templar._available_variables = dict(test_var='foo')
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo', 'bar']

    # Test with a list of AnsibleUn

# Generated at 2022-06-17 15:24:02.115224
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))

    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, loader) == ['foo']
    assert listify_lookup_plugin

# Generated at 2022-06-17 15:24:11.724202
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    vault_secrets = VaultLib([])
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager, vault_secrets=vault_secrets)

    # Test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # Test list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set_nonpersistent

# Generated at 2022-06-17 15:24:22.723136
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, playcontext=play_context)

    # Test string
    terms = '{{ foo }}'