

# Generated at 2022-06-17 15:14:28.528451
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('{{ foo }},{{ bar }}', templar, loader) == ['{{ foo }}', '{{ bar }}']

# Generated at 2022-06-17 15:14:36.611634
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # test string
    terms = '{{ foo }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False)
    assert terms == ['{{ foo }}']

    # test list
    terms = ['{{ foo }}', '{{ bar }}']
    terms = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False)
    assert terms == ['{{ foo }}', '{{ bar }}']

    # test list with bare vars
    terms = ['{{ foo }}', 'bar']

# Generated at 2022-06-17 15:14:47.503332
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'a': 'foo', 'b': 'bar'}
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    assert listify_lookup_plugin_terms('{{a}}', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('{{a}}', templar, loader, convert_bare=True) == ['foo']

# Generated at 2022-06-17 15:14:56.329768
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    terms = '{{ foo }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}', '{{ bar }}']

    # Test with a list of strings and lists
    terms = ['{{ foo }}', ['{{ bar }}', '{{ baz }}']]

# Generated at 2022-06-17 15:15:06.794247
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    templar = Templar(loader=loader, variables=VariableManager())

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test dict
    assert listify_lookup_plugin_terms({'foo': 'bar'}, templar, loader) == [{'foo': 'bar'}]

    # Test template string

# Generated at 2022-06-17 15:15:15.317536
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test with a list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test with a dict
    assert listify_lookup_plugin_terms({'foo': 'bar'}, templar, loader) == [{'foo': 'bar'}]

    # Test with a template
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

    #

# Generated at 2022-06-17 15:15:25.359255
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:15:34.641602
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))

    assert listify_lookup_plugin_terms(terms=None, templar=templar, loader=loader) == [None]
    assert listify_look

# Generated at 2022-06-17 15:15:47.448620
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']


# Generated at 2022-06-17 15:15:54.347396
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    class TestLookupModule(object):
        def __init__(self, basedir=None, runner=None, **kwargs):
            self.basedir = basedir

    class TestRunner(object):
        def __init__(self, inventory=None, variable_manager=None, loader=None):
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader


# Generated at 2022-06-17 15:16:05.151545
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    # Test with a string
    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(foo=AnsibleUnicode('bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    templar = Templar(loader=None, variables=VariableManager())

# Generated at 2022-06-17 15:16:13.134929
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a string
    terms = "{{ foo }}"
    variable_manager.set_nonpersistent_facts({"foo": "bar"})

# Generated at 2022-06-17 15:16:22.121023
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, None) == ['foo', 'bar', 'baz']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, None, convert_bare=True) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:16:34.244533
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      disable_lookups=False,
                      play_context=play_context)

    # Test with a string

# Generated at 2022-06-17 15:16:46.050989
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      disable_lookups=False)

    # test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert listify_lookup

# Generated at 2022-06-17 15:16:54.028050
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:17:02.912548
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = AnsibleLoader(None, variable_manager=VariableManager(), loader=None)
    templar = Templar(loader=loader, variables=VariableManager())

    # test string
    terms = '{{ foo }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}']

    # test list
    terms = ['{{ foo }}', '{{ bar }}']
    result = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-17 15:17:12.050367
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None)))
    templar._available_variables = dict(foo='bar')
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None)))
    templar._available_variables = dict(foo='bar')

# Generated at 2022-06-17 15:17:20.779416
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo,bar'], templar, loader) == ['foo,bar']
    assert listify_lookup_

# Generated at 2022-06-17 15:17:28.288609
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      disable_lookups=False,
                      play_context=play_context)

    # test string

# Generated at 2022-06-17 15:17:39.411360
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(foo='bar')
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(foo=['bar', 'baz'])

# Generated at 2022-06-17 15:17:48.433070
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    templar = Templar(loader=None, variables={})

    # test string
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']

    # test list with unicode
    assert listify_lookup_plugin_terms([u'foo', u'bar'], templar, None) == ['foo', 'bar']

    # test list with unicode and templating

# Generated at 2022-06-17 15:17:54.693572
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']

# Generated at 2022-06-17 15:18:05.534061
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo bar', templar, loader) == ['foo bar']

# Generated at 2022-06-17 15:18:14.832923
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms(['a', 'b'], templar, None) == ['a', 'b']
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], templar, None) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms(['a', 'b', 'c', 'd'], templar, None) == ['a', 'b', 'c', 'd']
    assert listify_lookup_plugin_terms(['a', 'b', 'c', 'd', 'e'], templar, None) == ['a', 'b', 'c', 'd', 'e']
    assert listify_lookup

# Generated at 2022-06-17 15:18:27.311388
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test string
    terms = '{{ foo }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)

# Generated at 2022-06-17 15:18:36.981086
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{baz}}'], templar, loader) == ['foo', 'bar', '{{baz}}']

# Generated at 2022-06-17 15:18:48.559894
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, loader) == ['{{ foo }}']
    assert listify_lookup_plugin

# Generated at 2022-06-17 15:18:58.263123
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    # Test with a string
    terms = '{{ var1 }}'
    templar._available_variables = dict(var1='foo')
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['foo']

    # Test with a list of strings
    terms = ['{{ var1 }}', '{{ var2 }}']
    templar._available_variables = dict(var1='foo', var2='bar')
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
   

# Generated at 2022-06-17 15:19:07.350772
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader, convert_bare=True) == ['{{ foo }}']

# Generated at 2022-06-17 15:19:21.236907
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', templar, loader=None) == ['foo bar']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader=None) == ['foo,bar']
    assert list

# Generated at 2022-06-17 15:19:31.202507
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', templar, loader) == ['foo bar']

    # Test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test template
    variable_manager.set_nonpersistent_facts({'foo': 'bar'})
    assert listify_

# Generated at 2022-06-17 15:19:41.728735
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(result, list)
    assert result == ['foo']

   

# Generated at 2022-06-17 15:19:52.861238
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vault_secrets = VaultLib([])
    templar = Templar(loader=loader, variables={}, vault_secrets=vault_secrets)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test list with template

# Generated at 2022-06-17 15:20:03.578111
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', ['bar', 'baz']], templar, None) == ['foo', ['bar', 'baz']]

# Generated at 2022-06-17 15:20:14.222224
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']


# Generated at 2022-06-17 15:20:22.799700
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

# Generated at 2022-06-17 15:20:31.164006
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = AnsibleLoader(None, variable_manager=variable_manager)
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)

# Generated at 2022-06-17 15:20:41.047099
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 'foo', 'b': 'bar'}
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ a }}', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['{{ a }}', '{{ b }}'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:20:51.251863
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    templar = Templar(loader=None, variables=variable_manager)

    # Test with string
    terms = '{{ foo }}'
    assert listify_lookup_plugin_terms(terms, templar, None) == ['bar']

    # Test with list
    terms = ['{{ foo }}']
    assert listify_lookup_plugin_terms(terms, templar, None) == ['bar']

    # Test with list of lists
    terms = [['{{ foo }}']]

# Generated at 2022-06-17 15:21:14.475388
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager())
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == [AnsibleUnicode('{{ foo }}')]

    terms = ['{{ foo }}', '{{ bar }}']
    templar = Templar(loader=None, variables=VariableManager())
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == [AnsibleUnicode('{{ foo }}'), AnsibleUnicode('{{ bar }}')]


# Generated at 2022-06-17 15:21:24.722123
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    assert listify_lookup_plugin_terms('foo', templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader=None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader=None) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:21:37.086708
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo']

    # Test list
    terms = ['foo', 'bar']
   

# Generated at 2022-06-17 15:21:48.712828
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = '{{ foo }}'
    variable_manager.extra_vars = {'foo': 'bar'}
    assert listify_lookup_plugin_

# Generated at 2022-06-17 15:21:56.281893
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['{{ foo }}']

    terms = AnsibleUnicode('{{ foo }}')

# Generated at 2022-06-17 15:22:06.514262
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test dict
    assert listify_lookup_plugin_terms({'foo': 'bar'}, templar, loader) == [{'foo': 'bar'}]

    # Test template
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']
    assert listify_lookup_plugin_

# Generated at 2022-06-17 15:22:13.197771
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None)

    # Test string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['foo']

    # Test list
    terms = ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['foo', 'bar']

    # Test AnsibleUnicode
    terms = AnsibleUnicode('foo')
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['foo']

# Generated at 2022-06-17 15:22:22.256786
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == [terms]

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    assert listify_lookup_plugin_

# Generated at 2022-06-17 15:22:33.127510
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ baz }}',
    ]

    templar = Templar(loader=None, variables=dict(foo='one', bar='two', baz='three'))
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['one', 'two', 'three']


# Generated at 2022-06-17 15:22:46.577677
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ lookup_plugin_terms }}')))
        ]
    )


# Generated at 2022-06-17 15:23:21.291371
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts({'foo': 'bar'})
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # Test list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set_nonpersistent_facts({'foo': 'bar', 'bar': 'baz'})


# Generated at 2022-06-17 15:23:32.960401
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{ baz }}'], templar, loader) == ['foo', 'bar', '{{ baz }}']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{ baz }}'], templar, loader, convert_bare=True) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:23:46.625927
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vault_secrets = VaultLib([])
    templar = Templar(loader=loader, variables={}, vault_secrets=vault_secrets)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', ['bar', 'baz']], templar, loader) == ['foo', ['bar', 'baz']]

# Generated at 2022-06-17 15:23:51.758099
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # test list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set_nonpersistent_facts(dict(foo='bar', bar='baz'))

# Generated at 2022-06-17 15:24:01.393234
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, None) == ['foo', 'bar', 'baz']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz', 'qux'], templar, None) == ['foo', 'bar', 'baz', 'qux']


# Generated at 2022-06-17 15:24:11.257359
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:24:22.629816
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # test string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo']

    # test list
    terms = ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo', 'bar']

    # test dict
