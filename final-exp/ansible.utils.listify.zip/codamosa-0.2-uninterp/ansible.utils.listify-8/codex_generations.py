

# Generated at 2022-06-17 15:14:34.087019
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, loader) == ['foo', '{{ bar }}']
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, loader, convert_bare=True) == ['foo', 'bar']

# Generated at 2022-06-17 15:14:46.816448
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_variable('foo', 'bar')
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['bar']
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, loader) == ['bar']
    assert listify_lookup_plugin_terms(['{{ foo }}', 'baz'], templar, loader) == ['bar', 'baz']

# Generated at 2022-06-17 15:14:58.382261
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', ['bar', 'baz']], templar, loader) == ['foo', ['bar', 'baz']]
   

# Generated at 2022-06-17 15:15:08.565794
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # Test list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set

# Generated at 2022-06-17 15:15:16.566551
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    terms = listify_lookup_plugin_terms('foo', templar, loader)
    assert terms == ['foo']

    # Test with a list
    terms = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)
    assert terms == ['foo', 'bar']

    # Test with a list of lists
    terms = listify_lookup_plugin_terms([['foo', 'bar'], ['baz', 'qux']], templar, loader)
    assert terms == [['foo', 'bar'], ['baz', 'qux']]

    # Test with a

# Generated at 2022-06-17 15:15:26.538940
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts({"foo": "bar"})
    result = listify_

# Generated at 2022-06-17 15:15:35.686432
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, loader) == ['foo']

# Generated at 2022-06-17 15:15:47.753263
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:16:00.298912
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:16:09.808525
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:16:23.875273
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 15:16:35.570388
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    # Create a temporary lookup plugin
    class TestLookupModule(object):
        def __init__(self, basedir=None, runner=None, **kwargs):
            pass

        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_loader.add('test_lookup_plugin', TestLookupModule)

    # Create a temporary inventory
    inventory = InventoryManager(loader=None, sources=None)

    # Create a temporary variable manager
    variable_

# Generated at 2022-06-17 15:16:46.254467
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:16:54.263088
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      disable_lookups=False,
                      fail_on_undefined=True,
                      play_context=play_context)

    # Test string
    assert listify_

# Generated at 2022-06-17 15:17:03.019759
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ lookup_plugin_terms }}')))
        ]
    )
    play

# Generated at 2022-06-17 15:17:12.114481
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string input
    terms = listify_lookup_plugin_terms('foo', templar, loader)
    assert terms == ['foo']

    # Test list input
    terms = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)
    assert terms == ['foo', 'bar']

    # Test list input with templating
    terms = listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, loader)

# Generated at 2022-06-17 15:17:20.807923
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager())

    assert listify_lookup_plugin_terms(terms, templar, None) == [u'{{ foo }}']

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager())

    assert listify_lookup_plugin_terms(terms, templar, None, convert_bare=True) == [u'{{ foo }}']

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager())



# Generated at 2022-06-17 15:17:28.318749
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, loader) == ['foo']

# Generated at 2022-06-17 15:17:37.862685
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', ['bar', 'baz']], templar, loader) == ['foo', ['bar', 'baz']]
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, loader)

# Generated at 2022-06-17 15:17:48.130641
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', templar, loader) == ['foo bar']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo,bar']
    assert listify_lookup_plugin_terms('foo, bar', templar, loader) == ['foo, bar']
    assert listify_lookup_plugin_terms

# Generated at 2022-06-17 15:17:57.647470
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', ['bar', 'baz']], templar, loader) == ['foo', ['bar', 'baz']]

# Generated at 2022-06-17 15:18:04.390820
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ baz }}',
    ]

    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(
        foo='foo',
        bar='bar',
        baz='baz',
    )


# Generated at 2022-06-17 15:18:14.399440
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = AnsibleUnicode('{{ foo }}')
    templar = Templar(loader=None, variables=VariableManager())
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['{{ foo }}']

    terms = ['{{ foo }}', '{{ bar }}']
    templar = Templar(loader=None, variables=VariableManager())
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['{{ foo }}', '{{ bar }}']

    terms = ['{{ foo }}', '{{ bar }}']
    templar = Templar(loader=None, variables=VariableManager())
   

# Generated at 2022-06-17 15:18:27.067464
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', templar, loader) == ['foo bar']


# Generated at 2022-06-17 15:18:36.840301
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, None) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:18:48.447289
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader) == ['a', 'b']
    assert listify_lookup_plugin_terms('a', templar, loader) == ['a']
    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader, convert_bare=True) == ['a', 'b']

# Generated at 2022-06-17 15:18:58.225730
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    templar = Templar(loader=None, variables=variable_manager)

    # Test with a string
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None) == ['bar']

    # Test with a list
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, None) == ['bar']

    # Test with a list of lists
    assert listify_lookup_plugin_terms([['{{ foo }}']], templar, None) == [['bar']]

# Generated at 2022-06-17 15:19:07.350081
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a string
    terms = "{{ foo }}"
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['bar']

    # Test with a list
    terms = ["{{ foo }}", "{{ bar }}"]
    variable_manager.set_nonpersistent_facts(dict(foo='bar', bar='baz'))
    result = listify_lookup_plugin_terms

# Generated at 2022-06-17 15:19:19.352118
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None)

    # Test string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['foo']

    # Test list
    terms = ['foo', 'bar']
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['foo', 'bar']

    # Test AnsibleUnicode
    terms = AnsibleUnicode('foo')
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['foo']

    # Test AnsibleUnicode list

# Generated at 2022-06-17 15:19:30.829548
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:19:46.666940
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, None) == ['foo', 'bar', 'baz']
    assert listify_lookup_plugin_terms('foo,bar', templar, None) == ['foo', 'bar']

# Generated at 2022-06-17 15:19:54.129952
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader) == ['a', 'b']
    assert listify_lookup_plugin_terms('a', templar, loader) == ['a']
    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader, convert_bare=True) == ['a', 'b']
    assert listify_lookup_plugin_terms('a', templar, loader, convert_bare=True) == ['a']

# Generated at 2022-06-17 15:20:03.759052
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVars
   

# Generated at 2022-06-17 15:20:14.395176
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test string
    terms = '{{ foo }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(result, list)
    assert len(result) == 1

# Generated at 2022-06-17 15:20:22.917251
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string
    terms = '{{ foo }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert terms[0] == '{{ foo }}'

    # Test list
    terms = ['{{ foo }}', '{{ bar }}']
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert len(terms) == 2
    assert terms[0] == '{{ foo }}'
    assert terms[1] == '{{ bar }}'



# Generated at 2022-06-17 15:20:31.244381
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{lookup_file}}')))
        ]
    )

# Generated at 2022-06-17 15:20:41.073653
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    # Test string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo']

    # Test list
    terms = ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo', 'bar']

    # Test unicode
    terms = AnsibleUnicode('foo')
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo']

    # Test unicode list

# Generated at 2022-06-17 15:20:51.534905
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert listify_lookup_

# Generated at 2022-06-17 15:21:02.274225
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    # Setup
    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test string
    terms = '{{ foo }}'

# Generated at 2022-06-17 15:21:12.107554
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    # Test with a string
    terms = listify_lookup_plugin_terms('foo', templar, None)
    assert terms == ['foo']

    # Test with a list
    terms = listify_lookup_plugin_terms(['foo', 'bar'], templar, None)
    assert terms == ['foo', 'bar']

    # Test with a list of unicode
    terms = listify_lookup_plugin_terms([AnsibleUnicode('foo'), AnsibleUnicode('bar')], templar, None)
    assert terms == ['foo', 'bar']

# Generated at 2022-06-17 15:21:24.923216
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ baz }}',
    ]

    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(
        foo='foo',
        bar=['bar1', 'bar2'],
        baz=AnsibleUnicode('baz'),
    )

    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['foo', 'bar1', 'bar2', 'baz']

# Generated at 2022-06-17 15:21:33.247222
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      disable_lookups=False,
                      play_context=play_context)

    # test string
    terms = '{{ foo }}'
    variable_manager.set_

# Generated at 2022-06-17 15:21:45.730549
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    loader = AnsibleLoader(None, variable_manager=VariableManager())
    templar = Templar(loader=loader)

    # Test with a string
    terms = '{{ var1 }}'
    templar._available_variables = dict(var1='foo')
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo']

    # Test with a list
    terms = ['{{ var1 }}', '{{ var2 }}']
    templar._available_variables = dict(var1='foo', var2='bar')

# Generated at 2022-06-17 15:21:55.274703
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo']

    # Test list
    terms = ['foo', 'bar']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo', 'bar']

    # Test list with a string
    terms = ['foo', 'bar', '{{ baz }}']

# Generated at 2022-06-17 15:22:05.669206
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:22:13.262046
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader


# Generated at 2022-06-17 15:22:22.308739
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ baz }}',
    ]

    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(
        foo='foo',
        bar='bar',
        baz='baz',
    )


# Generated at 2022-06-17 15:22:28.737012
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    terms = '{{ foo }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['{{ foo }}']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['{{ foo }}', '{{ bar }}']

    # Test with a dict
    terms = {'foo': '{{ foo }}', 'bar': '{{ bar }}'}

# Generated at 2022-06-17 15:22:41.563136
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    class TestLookupModule(object):
        def __init__(self, basedir=None, runner=None, **kwargs):
            self.basedir = basedir
            self.runner = runner
            self.vars = {}

    class TestRunner(object):
        def __init__(self, inventory=None, variable_manager=None, loader=None, **kwargs):
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader

   

# Generated at 2022-06-17 15:22:52.062308
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ baz }}',
    ]

    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(
        foo=AnsibleUnicode('foo'),
        bar=AnsibleUnicode('bar'),
        baz=AnsibleUnicode('baz'),
    )

    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['foo', 'bar', 'baz']

    terms = '{{ foo }}'
    result = listify

# Generated at 2022-06-17 15:23:04.626946
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = AnsibleLoader(None, variable_manager=VariableManager(), inventory=InventoryManager(loader=loader))
    templar = Templar(loader=loader, variables=dict())

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:23:14.840059
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo bar', templar, None) == ['foo bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None, convert_bare=True) == ['foo', 'bar']
    assert listify_lookup_plugin

# Generated at 2022-06-17 15:23:26.127780
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ lookup("pipe", "echo foo") }}')))
        ]
    )

# Generated at 2022-06-17 15:23:35.560950
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager,
                      fail_on_undefined=True)

    # test string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo']

    # test list
    terms = ['foo', 'bar']

# Generated at 2022-06-17 15:23:46.167768
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None)

    # test string
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # test list
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']

    # test unicode
    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, None) == ['foo']

    # test list of unicode
    assert listify_lookup_plugin_terms([AnsibleUnicode('foo')], templar, None) == ['foo']

    # test list of unicode and string
    assert listify_lookup

# Generated at 2022-06-17 15:23:53.217837
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    loader = lookup_loader

    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      template_class=AnsibleUnicode)

    # Test string
    terms = '{{ foo }}'

# Generated at 2022-06-17 15:24:02.155535
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, loader) == ['foo', '{{ bar }}']
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, loader, convert_bare=True) == ['foo', 'bar']

# Generated at 2022-06-17 15:24:14.106369
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(foo='bar')
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

    terms = '{{ foo }}'

# Generated at 2022-06-17 15:24:25.065254
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.vars.manager import VariableManager

    # Setup
    variable_manager = VariableManager()
    loader = variable_manager._loader
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts({'foo': 'bar'})
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['bar']

    # Test AnsibleUnicode
    terms = AnsibleUnicode('{{ foo }}')
    variable_manager.set_nonpersistent_facts({'foo': 'bar'})