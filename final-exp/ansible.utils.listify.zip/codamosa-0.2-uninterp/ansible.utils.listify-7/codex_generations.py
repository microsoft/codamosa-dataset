

# Generated at 2022-06-17 15:14:34.592450
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string
    terms = '{{ var }}'
    result = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)
    assert result == ['{{ var }}']

    # Test list
    terms = ['{{ var }}', '{{ var2 }}']
    result = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)
    assert result == ['{{ var }}', '{{ var2 }}']

    # Test list with string
    terms = ['{{ var }}', '{{ var2 }}', '{{ var3 }}']
    result = listify_lookup_plugin

# Generated at 2022-06-17 15:14:46.913078
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, None) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:14:58.381340
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test with a string
    terms = '{{ foo }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert terms[0] == '{{ foo }}'

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert len(terms) == 2
    assert terms[0] == '{{ foo }}'

# Generated at 2022-06-17 15:15:08.602557
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ var1 }}'
    variable_manager.set_nonpersistent_facts(dict(var1='foo'))
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo']

    # Test list
    terms = ['{{ var1 }}', '{{ var2 }}']
    variable_manager.set_nonpersistent_facts(dict(var1='foo', var2='bar'))

# Generated at 2022-06-17 15:15:14.236398
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test 1: string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['bar']

    # Test 2: list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set_nonpersistent_facts(dict(foo='bar', bar='baz'))

# Generated at 2022-06-17 15:15:24.214047
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = '{{ var }}'
    variable_manager.set_nonpersistent_facts(dict(var='foo'))

# Generated at 2022-06-17 15:15:33.743537
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_vault_secrets(['secret'])
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['bar']

    # Test list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.set_nonpersistent_facts(dict(foo='bar', bar='baz'))


# Generated at 2022-06-17 15:15:47.222433
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test with a list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test with

# Generated at 2022-06-17 15:15:52.898075
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))

    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, loader) == ['foo']
    assert listify_lookup_plugin

# Generated at 2022-06-17 15:15:58.382992
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(result, list)

# Generated at 2022-06-17 15:16:09.403152
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      disable_lookups=True)

    # test string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo']

   

# Generated at 2022-06-17 15:16:15.510912
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo']

    # Test list
    terms = ['foo', 'bar']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo', 'bar']

    # Test string with jinja2 template
    terms = '{{ foo }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ foo }}']

    # Test list with jinja2 template
   

# Generated at 2022-06-17 15:16:23.568956
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a string
    terms = '{{ foo }}'
    variable_manager.extra_vars = {'foo': 'bar'}
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['bar']

    # Test with a list
    terms = ['{{ foo }}', '{{ bar }}']
    variable_manager.extra

# Generated at 2022-06-17 15:16:35.535927
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, loader) == ['{{ foo }}']
    assert listify_lookup_plugin

# Generated at 2022-06-17 15:16:46.233446
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    loader = AnsibleLoader(None, variable_manager=VariableManager())
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{baz}}'], templar, loader) == ['foo', 'bar', '{{baz}}']


# Generated at 2022-06-17 15:16:57.166617
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
   

# Generated at 2022-06-17 15:17:08.408146
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(foo=AnsibleUnicode('bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

    terms = ['{{ foo }}', '{{ bar }}']
    templar = Templar(loader=None, variables=VariableManager())
    templar._available_variables = dict(foo=AnsibleUnicode('bar'), bar=AnsibleUnicode('baz'))
    assert listify_lookup_plugin_terms

# Generated at 2022-06-17 15:17:18.863616
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
   

# Generated at 2022-06-17 15:17:24.225069
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo,bar, baz', templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:17:30.674155
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager._loader

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, play_context=play_context)

    # Test string
    terms = '{{ foo }}'
    result = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-17 15:17:43.001190
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    lookup_loader.add_directory('./lib/ansible/plugins/lookup')

    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = '{{ foo }}'

# Generated at 2022-06-17 15:17:49.331467
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_look

# Generated at 2022-06-17 15:17:57.432755
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

# Generated at 2022-06-17 15:18:06.798382
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    class DummyVarsModule(object):
        def __init__(self, data):
            self.vars = data


# Generated at 2022-06-17 15:18:15.173788
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo']

    # test list
    terms = ['foo', 'bar']
   

# Generated at 2022-06-17 15:18:27.580955
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ bam }}',
    ]

    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(
        foo='foo',
        bar='bar',
        bam='bam',
    )


# Generated at 2022-06-17 15:18:37.116834
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', templar, loader) == ['foo bar']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo,bar']

    # Test list
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_

# Generated at 2022-06-17 15:18:48.604706
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      disable_lookups=False,
                      play_context=play_context)

    # test string
    terms = 'foo'

# Generated at 2022-06-17 15:18:58.262582
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo']

    # Test list
    terms = ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo', 'bar']

    # Test list with template
    terms = ['foo', '{{ bar }}']
    variable_manager.set_nonpersistent_facts(dict(bar='bar'))
    assert listify_lookup_

# Generated at 2022-06-17 15:19:07.335995
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=None, variables=variable_manager, play_context=play_context)

    # Test string
    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

   

# Generated at 2022-06-17 15:19:11.272146
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 15:19:17.801856
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(foo='bar')
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

    terms = AnsibleUnicode('{{ foo }}')

# Generated at 2022-06-17 15:19:29.854918
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test string
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test dict

# Generated at 2022-06-17 15:19:40.576406
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, None)
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, loader) == ['foo', '{{ bar }}']
    assert listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, loader, convert_bare=True) == ['foo', 'bar']

# Generated at 2022-06-17 15:19:51.838129
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, loader) == ['{{ foo }}']
    assert listify_lookup_plugin

# Generated at 2022-06-17 15:19:58.698385
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader, convert_bare=True) == ['foo', 'bar', 'baz']
    assert listify_lookup_

# Generated at 2022-06-17 15:20:10.785066
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['bar']
    assert listify_lookup_plugin_terms(['{{ foo }}'], templar, loader) == ['bar']
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ foo }}'], templar, loader) == ['bar', 'bar']

# Generated at 2022-06-17 15:20:20.661081
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']


# Generated at 2022-06-17 15:20:28.773638
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo']

    # Test list
    terms = ['foo', 'bar']
   

# Generated at 2022-06-17 15:20:37.544732
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', AnsibleUnicode('baz')], templar, loader) == ['foo', 'bar', 'baz']
    assert listify_

# Generated at 2022-06-17 15:20:50.950746
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    # Create a dummy inventory
    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)

# Generated at 2022-06-17 15:21:00.306071
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    terms = [
        '{{ foo }}',
        '{{ bar }}',
        '{{ bam }}',
    ]

    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(
        foo='foo',
        bar='bar',
        bam='bam',
    )


# Generated at 2022-06-17 15:21:10.595427
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, loader) == ['foo']

# Generated at 2022-06-17 15:21:18.827915
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-17 15:21:26.901528
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    # Setup
    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))

    # Test
    # Test with a string
    test_string = '{{ test_var }}'
    variable

# Generated at 2022-06-17 15:21:38.816731
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test with a string
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo']

    # test with a list
    terms

# Generated at 2022-06-17 15:21:50.201115
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    assert listify_lookup_plugin_terms(terms=AnsibleUnicode('foo'), templar=templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(terms=['foo'], templar=templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(terms=['foo', 'bar'], templar=templar, loader=None) == ['foo', 'bar']

# Generated at 2022-06-17 15:22:01.306703
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    # Setup
    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test string
    terms = '{{ foo }}'
    variable_manager.extra_vars = {'foo': 'bar'}


# Generated at 2022-06-17 15:22:10.893425
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test string
    terms = '{{ foo }}'

# Generated at 2022-06-17 15:22:20.694991
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(foo=AnsibleUnicode('bar'))
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

    terms = ['{{ foo }}', '{{ bar }}']

# Generated at 2022-06-17 15:22:34.158448
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    terms = [
        'foo',
        'bar',
        '{{ baz }}',
        '{{ qux }}',
        ['{{ quux }}', '{{ corge }}'],
        ['{{ grault }}', '{{ garply }}'],
        ['{{ waldo }}', '{{ fred }}'],
        '{{ plugh }}',
        '{{ xyzzy }}',
        '{{ thud }}',
    ]


# Generated at 2022-06-17 15:22:46.889074
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader) == ['a', 'b']

# Generated at 2022-06-17 15:22:56.325548
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=None, variables=variable_manager,
                      shared_loader_obj=None, playcontext=play_context)

    # Test string
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['foo']

    # Test list
    terms = ['foo', 'bar']


# Generated at 2022-06-17 15:23:07.508404
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    loader = AnsibleLoader(None, variable_manager=VariableManager())
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader) == ['foo', 'bar', 'baz']
    assert listify

# Generated at 2022-06-17 15:23:20.301882
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', '{{baz}}'], templar, loader, convert_bare=True) == ['foo', 'bar', '{{baz}}']

# Generated at 2022-06-17 15:23:32.350458
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources='')))
    templar._available_variables = dict(foo='bar')
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['bar']

    terms = AnsibleUnicode('{{ foo }}')

# Generated at 2022-06-17 15:23:37.424181
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    assert listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, loader) == ['foo']
    assert listify_lookup_plugin_

# Generated at 2022-06-17 15:23:47.440925
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

# Generated at 2022-06-17 15:23:59.329861
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-17 15:24:10.140187
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = None
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a string
    terms = "{{ foo }}"
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))