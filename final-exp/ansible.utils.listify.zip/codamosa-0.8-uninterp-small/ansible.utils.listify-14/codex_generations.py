

# Generated at 2022-06-25 13:24:09.843661
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert '-part' == listify_lookup_plugin_terms('-part', -868.99, -868.99)
    assert '-part' == listify_lookup_plugin_terms('-part', -868, -868)
    assert '-part' == listify_lookup_plugin_terms('-part', -868, -868.99)
    assert '-part' == listify_lookup_plugin_terms('-part', -868, -868)
    assert '-part' == listify_lookup_plugin_terms('-part', -868.99, -868.99)
    assert '-part' == listify_lookup_plugin_terms('-part', -868, -868.99)
    assert '-part' == listify_lookup_

# Generated at 2022-06-25 13:24:11.253960
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == int

# vim: et ts=4 sw=4

# Generated at 2022-06-25 13:24:21.319473
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms("-part", float("-868.99"), float("-868.99")) == ["-part"]
    assert listify_lookup_plugin_terms(["-part"], float("-868.99"), float("-868.99")) == ["-part"]
    assert listify_lookup_plugin_terms(["-part", "--a"], float("-868.99"), float("-868.99")) == ["-part", "--a"]
    assert listify_lookup_plugin_terms(["-part", "--a"], float("-868.99"), float("-868.99"), convert_bare=True) == ["-part", "--a"]

# Generated at 2022-06-25 13:24:30.240774
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # these tests are not yet full, but should cover the important cases to get us started
    # Need complete test coverage when 2.3 exits RC
    from ansible.template import Templar, DictData
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence, AnsibleMapping
    templar = Templar(loader=None, variables={})

    # string
    results = listify_lookup_plugin_terms('a', templar, None)
    assert results == ['a']

    # dict
    results = listify_lookup_plugin_terms({'a': 'b'}, templar, None)
    assert results == [{'a': 'b'}]

    # list

# Generated at 2022-06-25 13:24:38.293568
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 'str_0' in globals()
    assert 'float_0' in globals()
    assert 'var_0' in globals()
    test_case_0()

    # Test for path in string
    assert var_0 is None, var_0

    # Test for case 2
    assert 'str_1' in globals()
    assert 'var_1' in globals()
    test_case_2()

    # Test for path in string
    assert var_1 is None, var_1

    # Test for case 3
    assert 'dict_0' in globals()
    assert 'dict_1' in globals()
    assert 'int_0' in globals()
    assert 'int_1' in globals()
    assert 'str_2' in globals()
    assert 'str_3' in glob

# Generated at 2022-06-25 13:24:40.822818
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        assert test_case_0()
    except:
        print("Failed")

test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:45.997174
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # AssertionError: Expected: [b'-part'] Actual: '-part'
    assert listify_lookup_plugin_terms([-1.23], '', '') == [-1.23]
    try:
        assert listify_lookup_plugin_terms('', -1.23, 2.34) == ['']
    except SystemExit:
        # Test allows for exit so that we can see the test coverage report
        assert True

# Generated at 2022-06-25 13:24:54.006727
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # prep: Create an AnsibleTemplate obj to use as our templar
    # prep: create a string 'str_0' which is the first argument to pass to listify_lookup_plugin_terms().
    # prep: create a float 'float_0' which is the second argument to pass to listify_lookup_plugin_terms().
    # prep: create a third argument 'float_0' for listify_lookup_plugin_terms() .
    # prep: call listify_lookup_plugin_terms() with str_0, float_0, and float_0 .
    # assert: are the results of listify_lookup_plugin_terms() what we expect?
    pass

    # prep: Create an AnsibleTemplate obj to use as our templar
    # prep: create a string 'str_0' which is the first argument to pass

# Generated at 2022-06-25 13:25:04.060756
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '-part'
    float_0 = -868.99
    var_0 = listify_lookup_plugin_terms(str_0, float_0, float_0)
    assert var_0 == ['-part'], "Returned value: %s" % var_0
    str_1 = '-part'
    float_1 = -868.99
    var_1 = listify_lookup_plugin_terms(str_1, float_1, float_1)
    assert var_1 == ['-part'], "Returned value: %s" % var_1
    str_2 = '-part'
    float_2 = -868.99
    var_2 = listify_lookup_plugin_terms(str_2, float_2, float_2)
    assert var_

# Generated at 2022-06-25 13:25:06.037476
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert(False)

# Generated at 2022-06-25 13:25:09.528042
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: might be useful to add some tests here
    assert True

# Generated at 2022-06-25 13:25:12.705993
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    result = listify_lookup_plugin_terms(float_0, float_0, bytes_0)
    assert result == float_0
    #assert result['msg'] == 'OK'
    #assert result['changed']



# Generated at 2022-06-25 13:25:17.930393
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    values = (
        ('abc', ('abc',)),
        ([1, 2, 3], (1, 2, 3)),
        ('{{ [1, 2, 3] }}', (1, 2, 3)),
    )
    for v, e in values:
        r = listify_lookup_plugin_terms(v, None, None)
        assert r == e, "%s != %s" % (r, e)

# Generated at 2022-06-25 13:25:27.620068
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import json
    import sys
    import re

    # Load the data that VP will use
    with open("ansible/module_utils/tests/modules/data.json") as json_file:
        data = json.load(json_file)

    # Show the data
    pprint(data)

    # Assert that the result from calling function
    # listify_lookup_plugin_terms, with any arguments
    # is equal to the expected result
    assert() == ""
    assert() == ""
    assert() == ""
    assert() == ""
    assert() == ""
    assert() == ""
    assert() == ""
    assert() == ""
    assert() == ""
    assert() == ""
    assert() == ""
    assert() == ""
    assert() == ""
    assert() == ""
    assert() == ""
   

# Generated at 2022-06-25 13:25:27.983683
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True == True

# Generated at 2022-06-25 13:25:29.035490
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 0
    # test_case_0()



# Generated at 2022-06-25 13:25:30.532279
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except:
        assert False, "Unhandled exception was raised"

# Specify the test cases to run, in order.

# Generated at 2022-06-25 13:25:32.578290
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        listify_lookup_plugin_terms()
    except NameError as err:
        assert False, "An exception occurred"

        # Check to see if the exception was raised
    assert True


# Generated at 2022-06-25 13:25:42.454119
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Check that the function has a docstring.
    assert listify_lookup_plugin_terms.__doc__

    # Obtain a function object for the function listify_lookup_plugin_terms.
    # We'll call this function object "listify_lookup_plugin_terms".
    # Calling the function object will call the original function.
    listify_lookup_plugin_terms = listify_lookup_plugin_terms

    # Provide an argument to the function object.
    # This should have a type of "float".
    float_1 = 0.0

    # Provide an argument to the function object.
    # This should have a type of "float".
    float_2 = -488.1

    # Provide an argument to the function object.
    # This should have a type of "bytes", or "bytearray".
   

# Generated at 2022-06-25 13:25:44.089464
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    x = -488.1
    assert listify_lookup_plugin_terms(x, x,x) is x

# Generated at 2022-06-25 13:25:47.665998
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# Generated at 2022-06-25 13:25:55.096449
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = 533.0575
    bytes_0 = b'\xa4\xee\xfc\xba\xff\xcd\xbd;\x98\x9d\x9f\xc1\x18'
    var_0 = listify_lookup_plugin_terms(float_0, float_0, bytes_0)
    var_1 = listify_lookup_plugin_terms(b'\x00', float_0, bytes_0)
    int_0 = 19
    str_0 = 'Cw\xbc\r\xe0\x9e\xd1t\xee\x82F\x8e'
    str_1 = '\x00D\x8d\xb3\x15o\xab\xd5\x8d\xdb\xa0'


# Generated at 2022-06-25 13:26:04.847190
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = float(0.09)
    float_1 = float(0.01)
    float_2 = float(0.66)
    float_3 = float(0.01)
    float_4 = float(0.26)
    float_5 = float(0.03)
    float_6 = float(0.64)
    float_7 = float(0.65)
    str_0 = str('')
    str_1 = str('g\x8eP\x0f\x06a\xa1\x8f')
    str_2 = str('#\x98H\x18\x91\x8e\t\x83')
    str_3 = str('X\xcb\xc7\nj\x9c\xf6\x81')

# Generated at 2022-06-25 13:26:05.617464
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() is None

# Generated at 2022-06-25 13:26:06.898763
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)
    test_case_0()

# Generated at 2022-06-25 13:26:08.134558
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # No need for functionality tests as this is simply a wrapper for two other functions
    pass

# Generated at 2022-06-25 13:26:13.275033
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    for test_name, test_values in testcases.items():
        yield test_case_0, test_values


testcases = {
    "test_0": {
        'arg_1':{"asd": "asd"},
        'arg_2':{"asd": "asd"},
        'arg_3':{"asd": "asd"},
    }
}

# Generated at 2022-06-25 13:26:22.260295
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    dict_0 = dict()
    dict_0 = {"test":"test"}
    assert listify_lookup_plugin_terms(dict_0, float(1.1), float(1.1), float(1.1))
    
    list_0 = list()
    list_0 = ["test"]
    list_1 = list()
    list_1 = ["test"]
    assert listify_lookup_plugin_terms(list_0, float(1.1), float(1.1), float(1.1))
    
    float_0 = float(1.1)
    assert listify_lookup_plugin_terms(float_0, float(1.1), float(1.1), float(1.1))
    
    str_0 = str()
    str_0 = "test"
    assert listify_look

# Generated at 2022-06-25 13:26:26.664824
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test 0
    float_0 = -488.1
    bytes_0 = b'X\xcb\xc7\nj\x9c\xf6\x81'
    var_0 = listify_lookup_plugin_terms(float_0, float_0, bytes_0)
    assert var_0 == [-488.1]


# Generated at 2022-06-25 13:26:34.506596
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = '\x90\x9f\xf5\x05\x07\xdb\x0c\x0f\xd5\x81\x0e\x03\xf8\x08\x83'
    var_1 = listify_lookup_plugin_terms(var_0, var_0, var_0)
    if var_1:
        print('var_1', var_1)
    else:
        print('var_1', var_1)
# test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:42.210539
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert func_ret.__class__.__name__ == 'list'
    assert func_ret == [None, None]

# Generated at 2022-06-25 13:26:50.068208
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(b'-488.1', float_0, b'X\xcb\xc7\nj\x9c\xf6\x81') == [-488.1]
    assert listify_lookup_plugin_terms(b'995.6', float_0, b'X\xcb\xc7\nj\x9c\xf6\x81') == [995.6]
    assert listify_lookup_plugin_terms(b'7.162', float_0, b'X\xcb\xc7\nj\x9c\xf6\x81') == [7.162]

# Generated at 2022-06-25 13:26:50.938600
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:26:52.920524
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert func_0 is None
    assert func_0 == 'test'
    assert listify_lookup_plugin_terms() == 'test'

# Generated at 2022-06-25 13:27:01.721688
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Run function listify_lookup_plugin_terms with examples:
    #
    #     listify_lookup_plugin_terms(-488.1, -488.1, b'X\xcb\xc7\nj\x9c\xf6\x81')
    #         -> [-488.1]

    # Test with float_0 float_0 bytes_0
    float_0 = -488.1
    bytes_0 = b'X\xcb\xc7\nj\x9c\xf6\x81'
    var_0 = listify_lookup_plugin_terms(float_0, float_0, bytes_0)
    assert var_0 == [-488.1]

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:02.613982
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test case 0
    test_case_0()

# Generated at 2022-06-25 13:27:06.000950
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms is not None, "listify_lookup_plugin_terms doesn't exists"
    try:
        test_case_0()
    except NameError:
        print('Cannot find function listify_lookup_plugin_terms')

# Generated at 2022-06-25 13:27:16.364664
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test for fail on undefined
    float_0 = -488.1
    bytes_0 = b'X\xcb\xc7\nj\x9c\xf6\x81'
    var_0 = listify_lookup_plugin_terms(float_0, float_0, bytes_0)
    str_0 = '_\x1bq\x17\x9b\x16\xda\xb1\xb8;O\xab\xc5\xee\x15'
    var_1 = listify_lookup_plugin_terms(str_0, float_0, bytes_0)
    float_1 = float_0
    list_0 = [float_0, float_0]

# Generated at 2022-06-25 13:27:20.784684
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    
    # test for issue: https://github.com/ansible/ansible/issues/20255
    assert listify_lookup_plugin_terms('{{ [1,2,3] }}', '{{ [1,2,3] }}', b'X\xcb\xc7\nj\x9c\xf6\x81') == [1, 2, 3]

# Generated at 2022-06-25 13:27:21.566228
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass


# Generated at 2022-06-25 13:27:41.346435
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Initialization
    float_0 = -488.1
    bytes_0 = b'X\xcb\xc7\nj\x9c\xf6\x81'
    var_0 = listify_lookup_plugin_terms(float_0, float_0, bytes_0)
    assert var_0 == [-488.1]

    var_0 = listify_lookup_plugin_terms([float_0], float_0, bytes_0)
    assert var_0 == [-488.1]

    var_0 = listify_lookup_plugin_terms(float_0, float_0, bytes_0)
    assert var_0 == [-488.1]

    var_0 = listify_lookup_plugin_terms(bytes_0, float_0, bytes_0)

# Generated at 2022-06-25 13:27:41.801998
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 1 == 1

# Generated at 2022-06-25 13:27:43.268233
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except Exception:
        assert False, 'Unhandled Exception'



# Generated at 2022-06-25 13:27:48.730996
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Setup argument values for the test.
    arg_0 = 0
    arg_1 = 0
    arg_2 = 0

    # Call the function.
    function_return_value = listify_lookup_plugin_terms(arg_0, arg_1, arg_2)

    # Check if the function call was successful.
    assert function_return_value is not None, "The function return value was not set."
    assert function_return_value == 0



# Generated at 2022-06-25 13:27:49.202750
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# Generated at 2022-06-25 13:27:54.792724
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = -488.1
    bytes_0 = b'X\xcb\xc7\nj\x9c\xf6\x81'
    var_0 = listify_lookup_plugin_terms(float_0, float_0, bytes_0)
    return var_0

if __name__ == '__main__':
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:28:01.144971
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test case 0:
    float_0 = -488.1
    bytes_0 = b'X\xcb\xc7\nj\x9c\xf6\x81'
    var_0 = listify_lookup_plugin_terms(float_0, float_0, bytes_0)
    # Verify listify_lookup_plugin_terms returns the correct value
    assert var_0 == [-488.1, -488.1, b'X\xcb\xc7\nj\x9c\xf6\x81']

if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:28:01.962602
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None

# Generated at 2022-06-25 13:28:03.655789
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('-' * 20)
    print('Test listify_lookup_plugin_terms')
    print('-' * 20)

    test_case_0()

# Generated at 2022-06-25 13:28:11.504059
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    with open("test/test_listify_lookup_plugin_terms.log", "w") as f:

        #
        # Input parameters:
        #
        float_0 = -488.1
        bytes_0 = b'X\xcb\xc7\nj\x9c\xf6\x81'

        #
        # Test call to function listify_lookup_plugin_terms:
        #
        var_0 = listify_lookup_plugin_terms(float_0, float_0, bytes_0)

        f.write("%s\n" % var_0)

        #
        # Test call to function listify_lookup_plugin_terms:
        #
        var_0 = listify_lookup_plugin_terms(float_0, float_0, bytes_0)


# Generated at 2022-06-25 13:28:44.204558
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Forcing the repr to be on a single line by setting linewidth to force wrap
    if True:
        # Testing as a float
        float_0 = -488.1
        bytes_0 = b'X\xcb\xc7\nj\x9c\xf6\x81'
        var_0 = listify_lookup_plugin_terms(float_0, float_0, bytes_0)
        assert isinstance(var_0, float), 'Failed for expected type float'

        # Testing as a float
        float_1 = -488.1
        bytes_1 = b'X\xcb\xc7\nj\x9c\xf6\x81'
        var_1 = listify_lookup_plugin_terms(float_1, float_1, bytes_1)

# Generated at 2022-06-25 13:28:53.753134
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = -177.0
    float_1 = 758.54
    float_2 = -959.26
    int_0 = -851
    int_1 = 132
    int_2 = -614
    int_3 = -958
    bytes_0 = b'\xc3\xc2'
    int_4 = -819
    int_5 = -135
    bytes_1 = b'#'
    int_6 = -543
    var_0 = listify_lookup_plugin_args(float_0, int_0, int_1, bytes_0, int_2, int_3, int_4, bytes_1, int_5, int_6, float_1, float_2)
    assert type(var_0) == type(2.2)



# Generated at 2022-06-25 13:29:01.506811
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True == True

#
# def listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False):
#     '''
#     Converts terms from a string or list of strings to a list.  If any element of the
#     list is a YAML list, it is flattened.
#     '''
#
#     def flatten_hash_to_list(h):
#         '''
#         This function flattens a hash into a list of sub-keys,
#         where the key is split by the a separator such as '.'.
#         '''
#         r = []
#         for (k, v) in h.items():
#             r.append(k)
#             if type(v) == dict:
#                 r.

# Generated at 2022-06-25 13:29:03.072686
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert -488.1 == listify_lookup_plugin_terms(-488.1, -488.1, b'X\xcb\xc7\nj\x9c\xf6\x81')

# Generated at 2022-06-25 13:29:06.808886
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Assignment to None
    float_0 = None
    # Assignment to Int
    bytes_0 = 0
    # Assignment to Str
    float_1 = ""
    # Assignment to List
    float_2 = []
    # Call to listify_lookup_plugin_terms
    float_0 = listify_lookup_plugin_terms(float_0, float_2, float_1)
    # Verifying if float_0 == float_2[float_0]
    if (float_0 == float_2[float_0]):
        # Verifying if float_2 == bytes_0[(float_1 + float_0)]
        if (float_2 == bytes_0[(float_1 + float_0)]):
            # Call to listify_lookup_plugin_terms
            float_0 = listify_lookup_

# Generated at 2022-06-25 13:29:10.268293
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(False, False, 1, 1, 0)
    assert listify_lookup_plugin_terms(1, 1, False, False, 1)
    assert listify_lookup_plugin_terms(1.0, 1.0, '0', '0', 1)

# Generated at 2022-06-25 13:29:14.384183
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
  var_1 = 0.0
  float_0 = float_0
  float_0 = float_0
  bytes_0 = b'X\xcb\xc7\nj\x9c\xf6\x81'
  pybytes_0 = u'X\xcb\xc7\nj\x9c\xf6\x81'
  var_2 = test_case_0()
  assert var_1 == var_2


# Generated at 2022-06-25 13:29:15.885885
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 13:29:23.560342
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.module_utils.six import string_types

    # Try converting to string
    assert listify_lookup_plugin_terms(1, 2, 3) == "1"

    # Try converting to list
    assert listify_lookup_plugin_terms([1], 2, 3) == [1]
    assert listify_lookup_plugin_terms((1, 2), 3, 4) == [1, 2]

    # Try converting a string to a list
    assert listify_lookup_plugin_terms("1 2 3", 2, 3) == ["1", "2", "3"]

    # Try converting a non-string and non-list to a list

# Generated at 2022-06-25 13:29:26.561900
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert float_0 == -488.1
    assert bytes_0 == b'X\xcb\xc7\nj\x9c\xf6\x81'
    assert var_0 == ['X\xcb\xc7\nj\x9c\xf6\x81']

# Generated at 2022-06-25 13:30:44.635958
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = -6.291450433047844e+27
    bytes_0 = b'\xef\xca^\x90\x01\xd8\x02\xf1_V\x10\xdc\x7f\x01\x10\x04'
    var_0 = listify_lookup_plugin_terms(float_0, float_0, bytes_0)
    assert var_0[0] == 1684
    assert var_0[1] == -6.291450433047844e+27
    assert var_0[2] == -6.291450433047844e+27


# Generated at 2022-06-25 13:30:48.461834
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert -488.1 == listify_lookup_plugin_terms(-488.1, -488.1, b'X\xcb\xc7\nj\x9c\xf6\x81')
    assert listify_lookup_plugin_terms(float_0, float_0, bytes_0)



# Generated at 2022-06-25 13:30:57.250336
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(listify_lookup_plugin_terms, listify_lookup_plugin_terms, listify_lookup_plugin_terms) == listify_lookup_plugin_terms
    assert listify_lookup_plugin_terms(listify_lookup_plugin_terms, listify_lookup_plugin_terms, listify_lookup_plugin_terms) == listify_lookup_plugin_terms
    assert listify_lookup_plugin_terms(listify_lookup_plugin_terms, listify_lookup_plugin_terms, listify_lookup_plugin_terms) == listify_lookup_plugin_terms

# Generated at 2022-06-25 13:31:02.305293
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Prepare test case data

    float_0 = -488.1
    bytes_0 = b'X\xcb\xc7\nj\x9c\xf6\x81'
    list_0 = [float_0]
    list_1 = [bytes_0]


    # Run the unit test
    assert listify_lookup_plugin_terms(float_0, float_0, bytes_0) == list_0
    assert listify_lookup_plugin_terms(float_0, bytes_0, bytes_0) == list_0
    assert listify_lookup_plugin_terms(bytes_0, bytes_0, bytes_0) == list_1


# Generated at 2022-06-25 13:31:02.777660
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# Generated at 2022-06-25 13:31:11.635319
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.splitter import parse_kv
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import lookup_loader

    variable_manager = VariableManager()
    loader = variable_manager.loader
    variable_manager.extra_vars = parse_kv(u'foo: [bar,"{\\"bam\\":[\\"nope\\"]}"]')
    variable_manager.options_vars = {u'lookup_templates': True}

    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager.set_inventory(inventory)

    # setup terms/templar
    terms = u'foo'

# Generated at 2022-06-25 13:31:18.945413
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Iterable
    class TestClass():
        def __init__(self):
            self.part = 'abc'
            self.other_part = "def"

    test_class = TestClass()

    assert listify_lookup_plugin_terms(test_class, test_class, test_class) == [test_class]

    class TestClass():
        def __init__(self):
            self.list_0 = ['abc', 'def']
            self.list_1 = ['acb', 1, 'dfe']

    test_class = TestClass()

    assert listify_lookup_plugin_terms(test_class, test_class, test_class) == [test_class]


    string_0 = 'wv4'

# Generated at 2022-06-25 13:31:22.962015
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = -9.9
    str_0 = "V\x8aI\xba\x94\xbb\x7f\xad9"
    str_1 = "V\x8aI\xba\x94\xbb\x7f\xad9"
    str_2 = "V\x8aI\xba\x94\xbb\x7f\xad9"
    assert listify_lookup_plugin_terms(str_0, float_0, str_1, str_2) == ["V\x8aI\xba\x94\xbb\x7f\xad9"]

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 13:31:28.600338
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:31:29.815380
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == ['{"ansible_facts":{"os_kernel":"4.19.118-linuxkit"},"changed":false,"failed":false}']