

# Generated at 2022-06-25 13:24:00.755488
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-25 13:24:03.243588
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:04.898362
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == True

test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:05.804186
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:24:07.744776
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    args = []
    if test_case_0(args) != expected_0:
        fail(0)


# Test cases that are expected to fail

# Generated at 2022-06-25 13:24:09.742581
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test function parameter types
    float_0 = None
    var_0 = listify_lookup_plugin_terms(float_0, float_0, float_0)

# Generated at 2022-06-25 13:24:11.498407
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print(listify_lookup_plugin_terms(float_0, float_0, float_0))



# Generated at 2022-06-25 13:24:14.805129
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        x = listify_lookup_plugin_terms()
    except:
        print ('Unit Test Failed : test_listify_lookup_plugin_terms')

test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:24.718357
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('Test: test_listify_lookup_plugin_terms')

    # No parameters passed
    with pytest.raises(Exception):
        listify_lookup_plugin_terms()

    # One parameter passed
    with pytest.raises(Exception):
        listify_lookup_plugin_terms(1)

    # Two parameters passed
    with pytest.raises(Exception):
        listify_lookup_plugin_terms(1, 2)

    # Three parameters passed
    with pytest.raises(Exception):
        listify_lookup_plugin_terms(1, 2, 3)

    # Four parameters passed
    with pytest.raises(Exception):
        listify_lookup_plugin_terms(1, 2, 3, 4)

    # Five parameters passed but fail_on_undefined is not boolean type

# Generated at 2022-06-25 13:24:28.076942
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:24:31.377707
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    var_0 = listify_lookup_plugin_terms(float_0, float_0, float_0)



# Generated at 2022-06-25 13:24:33.218648
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # test function
    float_0 = None
    var_0 = listify_lookup_plugin_terms(float_0, float_0, float_0)


# Generated at 2022-06-25 13:24:36.378809
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = None
    templar = None
    loader = None
    fail_on_undefined = True
    convert_bare = False
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare) == None

# Generated at 2022-06-25 13:24:38.329170
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # print(listify_lookup_plugin_terms())
    assert True == False # TODO: implement your test here


# Generated at 2022-06-25 13:24:39.354366
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None

# Generated at 2022-06-25 13:24:41.423909
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except TypeError as e:
        print(e)



# Generated at 2022-06-25 13:24:42.605706
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None

# Asserts for coverage reporting

# Generated at 2022-06-25 13:24:48.440416
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Mock out template class
    class MockTemplate(object):
        def __init__(self, name):
            self.name = name

        def template(self, filename=None, fail_on_undefined=False, convert_bare=False):
            return self.name

    terms = 'dummy'
    templar = MockTemplate('templar')
    loader = MockTemplate('loader')

    assert listify_lookup_plugin_terms(terms, templar, loader) == ['templar']



# Generated at 2022-06-25 13:24:49.394186
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert(test_case_0())

# Generated at 2022-06-25 13:24:56.435938
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    templar = Templar(loader=None, variables=None, vault_secrets=VaultLib())
    test_cases = [
        (0, {'expression': 0, 'variables': 0, 'loader': 0}),
        (0, {'expression': 0, 'variables': 0, 'loader': 0}),
        (0, {'expression': 0, 'variables': 0, 'loader': 0}),
        (0, {'expression': 0, 'variables': 0, 'loader': 0}),
        (0, {'expression': 0, 'variables': 0, 'loader': 0}),
    ]

# Generated at 2022-06-25 13:25:00.297480
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True == True


# tests for listify_lookup_plugin_terms

# Generated at 2022-06-25 13:25:02.432381
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print("=======\nRunning test_listify_lookup_plugin_terms")
    test_case_0()

# Generated at 2022-06-25 13:25:09.577665
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Use into() to make a list from a str, tuple, set or other iterable
    testdata = into(['t1', 't2'])

    # Check if testdata is a list
    assert isinstance(testdata, list)

    # Check if testdata has two elements
    assert len(testdata) == 2

    # Check if the first element is 't1'
    assert testdata[0] == 't1'

    # Check if the second element is 't2'
    assert testdata[1] == 't2'

# Generated at 2022-06-25 13:25:15.347813
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # module is imported
    from ansible.utils.listify import listify_lookup_plugin_terms

    # Two string arguments are given.
    assert_equals(listify_lookup_plugin_terms("text1","text2"), ["text1", "text2"])

    # None as argument is given.
    assert_equals(listify_lookup_plugin_terms(None), [])


# Generated at 2022-06-25 13:25:16.825647
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_0_0 = None
    assert test_case_0() == test_0_0



# Generated at 2022-06-25 13:25:20.917838
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = None
    templar = None
    loader = None
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == []



# Generated at 2022-06-25 13:25:24.438241
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    # float_1 = None
    # float_2 = None

    res = listify_lookup_plugin_terms(float_0)
    print(res)


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:28.081034
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = None
    int_1 = 0
    assert listify_lookup_plugin_terms(None, None, None) == int_0
    assert listify_lookup_plugin_terms(int_1, int_1, int_1) == int_0


# Generated at 2022-06-25 13:25:28.948701
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:25:31.356343
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # float_0 (float) => None
    float_0 = None


    # call function with arguments
    # assert return type
    # assert return value
    # assert return type
    # assert return value
    # assert return type
    # assert return value
    print ('Hello')

# Main function for testing

# Generated at 2022-06-25 13:25:45.679516
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    thisdict = {}
    thatdict = {}
    for k,v in thisdict.items():
        thatdict[k] = v

    thisdict = []
    thatdict = list(thisdict)

    thisdict = ()
    thatdict = tuple(thisdict)

    thisdict = set()
    thatdict = set(thisdict)

    thisdict = float()
    thatdict = '{0:f}'.format(thisdict)

    thisdict = str()
    thatdict = str(thisdict)

    thisdict = bool()
    thatdict = str(thisdict)

    thisdict = int()
    thatdict = str(thisdict)

# Generated at 2022-06-25 13:25:46.215671
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# Generated at 2022-06-25 13:25:47.060918
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True, "Test not implemented."

# Generated at 2022-06-25 13:25:47.909508
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(1)

# Generated at 2022-06-25 13:25:55.268246
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    input_1 = ['Hello world!', 'test_case_0', 'test_case_1', 'test_case_3', 'test_case_4']
    output_1 = ['Hello world!', 'test_case_0', 'test_case_1', 'test_case_3', 'test_case_4']
    assert listify_lookup_plugin_terms(input_1[0], input_1[1], input_1[2]) == output_1[0]
    assert listify_lookup_plugin_terms(input_1[1], input_1[2], input_1[3]) == output_1[1]
    assert listify_lookup_plugin_terms(input_1[2], input_1[3], input_1[4]) == output_1[2]
    assert listify_lookup

# Generated at 2022-06-25 13:25:57.002952
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # assert listify_lookup_plugin_terms() == 'foo'
    assert test_case_0() == 'foo'

# Generated at 2022-06-25 13:25:59.712891
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    var_0 = listify_lookup_plugin_terms(float_0, float_0, float_0)
    print(var_0)


# Generated at 2022-06-25 13:26:02.229789
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(float_0, float_0, float_0)



# Generated at 2022-06-25 13:26:05.429579
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    global float_0
    float_0 = None
    result = listify_lookup_plugin_terms(float_0, float_0, float_0)

    # assert result == float_1


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:09.802471
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # get current function code
    test_case_0_code =  str(test_case_0.__code__)

    # find number of occurrences of "var_0"
    return_var_occurrences = test_case_0_code.count('var_0')

    # if we have more than 2 occurrences, raise error
    if return_var_occurrences > 2:
        raise ValueError('Function "listify_lookup_plugin_terms" returns more than one variable.')

# Generated at 2022-06-25 13:26:23.126049
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() is None

# Generated at 2022-06-25 13:26:26.334753
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Example code for listify_lookup_plugin_terms
    float_0 = None
    var_0 = listify_lookup_plugin_terms(float_0, float_0, float_0)
    assert type(var_0) == list

# Generated at 2022-06-25 13:26:36.925202
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    var_0 = None
    var_1 = []
    var_2 = [1, 'first', 2, 'second']
    var_3 = 'unquoted'
    var_4 = '"quoted"'

    var_5 = 1
    var_6 = [var_3]
    var_7 = [var_4]
    var_8 = [var_3, var_4]
    var_9 = [var_5, var_6, var_7, var_8, var_9]
    var_10 = []
    var_11 = []
    var_12 = []
    var_13 = []
    var_14 = []
    var_15 = []
    var_16 = []
    var_17 = []
    var_18 = []
    var_19 = []

# Generated at 2022-06-25 13:26:39.289410
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    var_0 = listify_lookup_plugin_terms(float_0, float_0, float_0)
    assert var_0[0] is None

# Generated at 2022-06-25 13:26:43.349439
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    template_file_name = 'template_file_name'
    templar = None
    loader = None
    fail_on_undefined=True
    convert_bare=False
    assert_listify_lookup_plugin_terms(template_file_name, templar, loader, fail_on_undefined, convert_bare)


# Generated at 2022-06-25 13:26:46.797335
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:26:52.086372
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:27:00.997553
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # mock function call
    class MockFunctionCall():
        def __init__(self, name):
            self.name = name

    # mock function object
    class MockFunction():
        def __init__(self, function_name, return_value):
            self.name = function_name
            self.return_value = return_value

        def __call__(self, *args, **kwargs):
            return self.return_value

    # mock class
    class MockClass():
        def __init__(self, function_list=[]):
            self.function_list = function_list

    # create mock objects and mocks methods
    mock_instance = MockClass([MockFunction('template', 'mock_return_value')])
    MockClass.template = MockFunction('template', 'mock_return_value')

    # call the

# Generated at 2022-06-25 13:27:09.754397
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test no args case
    assert listify_lookup_plugin_terms() == [], "No args case should return [], however it did not"
    # Test one arg case
    assert listify_lookup_plugin_terms(float_0) == float_0, "One arg case should return float_0, however it did not"
    # Test two arg case
    assert listify_lookup_plugin_terms(float_0, float_0) == float_0, "Two arg case should return float_0, however it did not"
    # Test three arg case
    assert listify_lookup_plugin_terms(float_0, float_0, float_0) == [], "Three arg case should return [], however it did not"

# Generated at 2022-06-25 13:27:15.457965
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # These tests are not meant to actually run, just typecheck
    float_0 = None
    assert isinstance(listify_lookup_plugin_terms(float_0, float_0, float_0), list)
    assert isinstance(listify_lookup_plugin_terms(float_0, float_0, float_0, fail_on_undefined=True, convert_bare=True), list)

# Generated at 2022-06-25 13:27:43.781889
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Find the type of variable
    var = listify_lookup_plugin_terms(float_0, float_0, float_0)
    assert type(var) == list

# To check whether the function returns the desired output.

# Generated at 2022-06-25 13:27:53.508186
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Run with this test-set:
    #
    #   {
    #     'float_0': None,
    #   }

    test_set_0 = [
        (
            {
                'float_0': None,
            },
            [

            ],
        ),
    ]

    # Run the tests
    for test_input, expected_output in test_set_0:
        with testlib.captured_stdout('ansible_lookup_plugins.json_file_lookup.listify_lookup_plugin_terms', test_input, expected_output):
            result = listify_lookup_plugin_terms(test_input['float_0'], test_input['float_0'], test_input['float_0'])

        # Unit test for return value
        assert result == expected_output

# Generated at 2022-06-25 13:27:54.865127
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(float_0, float_0, float_0) == [float_0]

# Generated at 2022-06-25 13:27:58.550763
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = 1
    templar = 1
    loader = 1
    fail_on_undefined = False
    expected_result = [1, 1]
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined)
    print(result)
    assert result == expected_result

# Generated at 2022-06-25 13:28:06.338038
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import re

    # Test with the following mock
    # function definitions:
    def _template(param0, param1=True, param2=None):
        print(str(param0) + str(param1) + str(param2))
        return None

    def _isinstance(param0, param1):
        if isinstance(param0, param1): return True
        else: return False

    # Setup mock objects
    float_0 = None
    float_0 = _template
    float_1 = None
    float_1 = float_0
    float_2 = None
    float_2 = float_1
    float_3 = None
    float_3 = 'test_string'
    float_4 = None
    float_4 = []
    for i_4 in range(0, 20, 3):
        float_4

# Generated at 2022-06-25 13:28:08.391686
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    var_0 = listify_lookup_plugin_terms(float_0, float_0, float_0)
    assert var_0 == [None]

# Generated at 2022-06-25 13:28:12.650668
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print("\n\n Testing function: listify_lookup_plugin_terms")

    try:
        test_case_0()
        print(test_case_0.__name__)
    except AssertionError as e:
        print(test_case_0.__name__, "failed - ", e)


# main()
if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:28:18.160651
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
  float_0 = None
  int_0 = 1
  var_0 = listify_lookup_plugin_terms(float_0, float_0, float_0)
  float_0 = float(3.1)
  float_1 = None
  boolean_0 = False
  int_1 = 1
  list_0 = [float_0]
  boolean_1 = False
  var_1 = listify_lookup_plugin_terms(int_1, list_0, boolean_0, boolean_1)
  int_2 = 1
  test_case_0()

# Generated at 2022-06-25 13:28:25.504620
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.module_utils.common.collections
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import os
    options = None
    loader = None
    passwords = None
    inventory = None
    variable_manager = None
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    terms = 'test'
    templar = 'test'

    # Pass in a

# Generated at 2022-06-25 13:28:27.278934
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_0 = None
    var_0 = listify_lookup_plugin_terms(test_0, float_0, float_0)

# Generated at 2022-06-25 13:29:28.372558
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This function is not implemented, so just call it with dummy arguments
    test_case_0()

test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:29:34.612112
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = [42, 'foo', 'bar', 'a', 'b']
    actual = listify_lookup_plugin_terms(terms, None, None)
    assert actual == terms

    actual = listify_lookup_plugin_terms(terms, None, None, fail_on_undefined=False)
    assert actual == terms

    terms = ['{{ a }}', 'b', 'c', 'd']
    actual = listify_lookup_plugin_terms(terms, None, None, fail_on_undefined=True)
    assert actual == ['', 'b', 'c', 'd']

    actual = listify_lookup_plugin_terms(terms, None, None, fail_on_undefined=False)
    assert actual == terms

    terms = ['a', '{{ b }}', 'c', 'd']

# Generated at 2022-06-25 13:29:39.444600
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:29:41.068627
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bool_0 = listify_lookup_plugin_terms(float_0, float_0, float_0)
    assert bool_0 is False


# Generated at 2022-06-25 13:29:42.372899
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # AssertionError: expected [('vault_password', None)]
    assert listify_lookup_plugin_terms(None, None, None) == None

# Generated at 2022-06-25 13:29:48.916709
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:29:51.468493
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        assert True
    except AssertionError as e:
        print('AssertionError: ',e)
        assert False
    return

# Local Variables:
# outline-regexp: "### @function"
# End:

# Generated at 2022-06-25 13:29:57.588856
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Unit test for function listify_lookup_plugin_terms
    # Listify of a string
    result = listify_lookup_plugin_terms('foo', None, None)
    assert result == ['foo']

    # Listify of a list
    result = listify_lookup_plugin_terms(['foo'], None, None)
    assert result == ['foo']

    # Listify of a tuple
    result = listify_lookup_plugin_terms(('foo',), None, None)
    assert result == ['foo']

    # Listify of a set
    result = listify_lookup_plugin_terms(set(['foo']), None, None)
    assert result == ['foo']

    # Listify of a generator

# Generated at 2022-06-25 13:29:58.090517
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert 1 == 1
    assert 1 == 2

# Generated at 2022-06-25 13:30:01.026055
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        assert test_case_0() == 'expect error here'
    except (AssertionError, TypeError) as e:
        print("Testcase 0 failed: " + str(e))
        raise e
    print("Testcase 0 passed")

if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:32:34.498776
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    var_0 = listify_lookup_plugin_terms(float_0, float_0, float_0)
    assert var_0 is None

# Generated at 2022-06-25 13:32:42.211768
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        from ansible.module_utils.common._collections_compat import Iterable
    except ImportError:
        print('SKIP: unable to import ansible.module_utils')
        return

    assert callable(listify_lookup_plugin_terms)
    assert callable(listify_lookup_plugin_terms.__annotations__['templar'])
    assert callable(listify_lookup_plugin_terms.__annotations__['terms'])
    assert callable(listify_lookup_plugin_terms.__annotations__['fail_on_undefined'])
    assert callable(listify_lookup_plugin_terms.__annotations__['convert_bare'])
    assert callable(listify_lookup_plugin_terms.__annotations__['loader'])



# Generated at 2022-06-25 13:32:43.083278
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # assert test_case_0() == 0
    pass


# Generated at 2022-06-25 13:32:44.318011
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Assert if the function returns the correct result
    assert isinstance(test_case_0(), list)

# Generated at 2022-06-25 13:32:51.415822
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = '  plain-string  '
    templar = 'templar'
    loader = 'loader'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['  plain-string  ']

    terms = '  plain-string  '
    templar = 'templar'
    loader = 'loader'
    result = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)
    assert result == ['  plain-string  ']

    terms = ['  first-elem  ', '  second-elem  ']
    templar = 'templar'
    loader = 'loader'
    result = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-25 13:32:57.575161
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test function for listify_lookup_plugin_terms that returns a list of strings
    # based on the terms provided.  This converts scalars to a list as well
    # as performs templates on the terms.

    float_0 = None
    str_0 = 'head -1'
    var_0 = listify_lookup_plugin_terms(str_0, float_0, float_0)

    assert var_0 == ['head', '-1']



# Generated at 2022-06-25 13:32:59.104651
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('Hooray!')

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:33:02.717810
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = "value"
    templar = "value"
    loader = "value"
    fail_on_undefined = False
    convert_bare = True
    var_0 = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    assert var_0 is None

if __name__ == '__main__':
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:33:04.848404
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except:
        print ('Exception caught')

if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:33:06.690574
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    var_0 = listify_lookup_plugin_terms(float_0, float_0, float_0)
    assert var_0 is float_0

