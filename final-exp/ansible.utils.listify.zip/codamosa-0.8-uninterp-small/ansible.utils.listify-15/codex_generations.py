

# Generated at 2022-06-25 13:24:03.337526
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)

# Generated at 2022-06-25 13:24:04.310717
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True


# Generated at 2022-06-25 13:24:06.260297
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0()

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:07.184935
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert not test_case_0()

# Generated at 2022-06-25 13:24:08.355155
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print("This function is not supported on Windows")


# Generated at 2022-06-25 13:24:09.428256
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0


test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:17.448662
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(
       str_0, bytes_0, set_0, fail_on_undefined=True, convert_bare=False) == var_0
    assert listify_lookup_plugin_terms(
       str_0, bytes_0, set_0, fail_on_undefined=True, convert_bare=False) == var_0
    assert listify_lookup_plugin_terms(
       str_0, bytes_0, set_0, fail_on_undefined=True, convert_bare=False) == var_0
    # TODO: Assert the result

# Generated at 2022-06-25 13:24:20.149013
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '"\x0b=eo1MtW\tOI,'
    bytes_0 = None
    set_0 = set()
    assert test_case_0()

# Generated at 2022-06-25 13:24:21.799534
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Test for function listify_lookup_plugin_terms
    """
    assert test_case_0() == None

# Generated at 2022-06-25 13:24:25.356201
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Run function with arguments
    assert test_case_0() == ('"\x0b=eo1MtW\tOI,')


# test for module import
if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:31.501266
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = listify_lookup_plugin_terms('b', 'b', 'z')
    assert var_0 == ['b']
    var_1 = listify_lookup_plugin_terms([-36.0], 'A', 'J')
    assert var_1 == [-36.0]
    var_2 = listify_lookup_plugin_terms(['qE5l'], 'g', 'F')
    assert var_2 == ['qE5l']
    var_3 = listify_lookup_plugin_terms('Y', 'e', 'j')
    assert var_3 == ['Y']
    var_4 = listify_lookup_plugin_terms('i', 'W', 'S')
    assert var_4 == ['i']

# Generated at 2022-06-25 13:24:32.186284
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == 'Z6;'

# Generated at 2022-06-25 13:24:33.369874
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print("In test_listify_lookup_plugin_terms")



# Generated at 2022-06-25 13:24:34.191479
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Place your code here
    assert True

# Generated at 2022-06-25 13:24:36.822366
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Unit test for function listify_lookup_plugin_terms

    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 13:24:46.445690
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(162, False, 'Z6;') == [162]
    assert listify_lookup_plugin_terms(117, False, 'oy') == [117]
    assert listify_lookup_plugin_terms(162, False, 'oy') == [162]
    assert listify_lookup_plugin_terms(149, False, 'Z6;') == [149]
    assert listify_lookup_plugin_terms(91, False, 'oy') == [91]
    assert listify_lookup_plugin_terms(143, False, 'oy') == [143]
    assert listify_lookup_plugin_terms(148, False, 'Z6;') == [148]
    assert listify_lookup_plugin_terms(199, False, 'oy') == [199]
   

# Generated at 2022-06-25 13:24:48.754427
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    func_0 = listify_lookup_plugin_terms(var_0, var_1, var_2)
    assert func_0 == 'Z6;'


# Generated at 2022-06-25 13:24:50.547010
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('Running unit tests')
    test_case_0()

# Run unit tests
test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:57.188486
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    null_0 = None
    null_1 = None
    int_1 = 11
    dict_0 = dict()
    set_0 = set()
    list_0 = [null_1, int_1, dict_0, set_0]
    assert list_0 == listify_lookup_plugin_terms(int_0, bool_0, str_0)
    dict_0 = dict()
    dict_0 = dict()
    dict_0['bool_0'] = bool_0
    dict_0['dict_0'] = dict_0
    dict_0['int_0'] = int_0
    dict_0['str_0'] = str_0
    dict_0['null_0'] = null_0

# Generated at 2022-06-25 13:25:07.061943
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_1 = [2, 3, 4]
    var_2 = listify_lookup_plugin_terms(var_1)
    assert var_2 == [2, 3, 4]

# Generated at 2022-06-25 13:25:16.041661
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 129
    bool_0 = True
    str_0 = 'tGv'
    var_0 = listify_lookup_plugin_terms(str_0, int_0, bool_0)
    assert var_0 == str_0
    var_1 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    assert var_1 == int_0

# Generated at 2022-06-25 13:25:19.470963
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Print statements in the function
    print(var_0)

# This is how to use the above function.
test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:21.100443
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)

# Generated at 2022-06-25 13:25:30.041904
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    assert var_0 is None, "Expected return value to be: None"
    str_1 = 'DpV7'
    int_1 = 169
    bool_1 = True
    var_1 = listify_lookup_plugin_terms(str_1, int_1, bool_1)
    assert var_1 is None, "Expected return value to be: None"
    str_2 = '?$M'
    int_2 = -38
    bool_2 = True
    var_2 = listify_lookup_plugin_terms(str_2, int_2, bool_2)


# Generated at 2022-06-25 13:25:31.581453
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print("test_listify_lookup_plugin_terms passed")


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:25:40.684650
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    #  Ensure the function returns a list
    assert isinstance(listify_lookup_plugin_terms(terms=None, templar=None, loader=None), list)
#  Ensure the function returns a list of 1 elements
    assert len(listify_lookup_plugin_terms(terms=None, templar=None, loader=None)) == 1
#  Ensure given an int, the function returns a list of 1 element
    assert isinstance(listify_lookup_plugin_terms(terms=162, templar=False, loader='Z6;'), list)
#  Ensure given an int and bool, the function returns a list of 1 element
    assert len(listify_lookup_plugin_terms(terms=162, templar=False, loader='Z6;')) == 1
#  Ensure given an int, bool and str, the

# Generated at 2022-06-25 13:25:42.911526
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except Exception:
        assert False
# END of test_listify_lookup_plugin_terms

# Generated at 2022-06-25 13:25:45.928439
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: ' + str(e))

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:50.332440
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Test for listify_lookup_plugin_terms
    '''
    # Set up mock
    global int_0
    global bool_0
    global str_0
    global var_0
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = None

    try:
        test_case_0()
    except Exception:
        pass

# Generated at 2022-06-25 13:25:58.373997
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    assert not var_0
    str_1 = '8_IW'
    var_1 = listify_lookup_plugin_terms(int_0, bool_0, str_1, False)
    assert var_1
    str_2 = '8_IW'
    var_2 = listify_lookup_plugin_terms(int_0, bool_0, str_2, True, False)
    assert not var_2
    str_3 = '8_IW'

# Generated at 2022-06-25 13:26:05.944360
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print("Test case 0:")
    test_case_0()

# Generated at 2022-06-25 13:26:13.486609
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    var_1 = listify_lookup_plugin_terms(False, bool_0, str_0)
    var_2 = listify_lookup_plugin_terms(str_0, bool_0, str_0)
    var_3 = listify_lookup_plugin_terms(var_0, var_1, var_2)
    print(var_3)


# Tests the new function
test_case_0()


# Generated at 2022-06-25 13:26:15.417356
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Remove the comma at the end of the next line
    assert listify_lookup_plugin_terms(passed_in) == expected_result

# Generated at 2022-06-25 13:26:24.195054
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test example 1
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    #assert var_0 == "expected output"
    
    # Test example 2
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    #assert var_0 == "expected output"
    
    # Test example 3
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'

# Generated at 2022-06-25 13:26:28.030933
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print(listify_lookup_plugin_terms.__doc__)
    try:
        test_case_0()
    except:
        print ("Failed")

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:34.277763
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        int_0 = 162
        bool_0 = False
        str_0 = 'Z6;'
        var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    except Exception as exception:
        print(exception)

if __name__ == '__main__':
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:36.924003
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Check correct function return for examples in module documentation
    # Check correct function return for example 'test_case_0'
    assert test_case_0() == 'expected result'

# Generated at 2022-06-25 13:26:45.797494
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(162, False, 'Z6;') == [162]
    assert listify_lookup_plugin_terms('Z6;', 'Z6;', None) == ['Z6;']
    assert listify_lookup_plugin_terms('Z6;', 162, 'Z6;') == ['Z6;']
    assert listify_lookup_plugin_terms(0, 'Z6;', 'Z6;') == [0]
    assert listify_lookup_plugin_terms('Z6;', 0, False) == ['Z6;']
    assert listify_lookup_plugin_terms(162, 'Z6;', 0) == [162]
    assert listify_lookup_plugin_terms(162, 'Z6;', True) == [162]
    assert listify_

# Generated at 2022-06-25 13:26:49.397527
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 10
    str_0 = 'i41x;zG'
    int_1 = 8
    var_0 = listify_lookup_plugin_terms(int_0, str_0, int_1)
    # Verify we want to return None
    assert var_0 is None



# Generated at 2022-06-25 13:26:53.405982
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('42', 'bar', 'foo') == ["42"]
    assert listify_lookup_plugin_terms(123, 'bar', 'foo') == [123]
    assert listify_lookup_plugin_terms([4, 5, 6], 'bar', 'foo') == [4, 5, 6]

# Generated at 2022-06-25 13:27:16.604011
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    int_1 = -31
    bool_1 = True
    str_1 = '.*'
    var_1 = listify_lookup_plugin_terms(int_1, bool_1, str_1)
    int_2 = -47
    bool_2 = False
    str_2 = '*'
    var_2 = listify_lookup_plugin_terms(int_2, bool_2, str_2)
    int_3 = -77
    bool_3 = False
    str_3 = 'a1tJ%'
    var_3 = listify_lookup_plugin_terms

# Generated at 2022-06-25 13:27:23.368516
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    arr_0 = []
    arr_1 = []
    arr_2 = []
    arr_0.append('')
    arr_0.append('')
    arr_0.append('')
    arr_1.append(False)
    arr_1.append(False)
    arr_1.append(False)
    arr_2.append('V7_')
    arr_2.append('V7_')
    arr_2.append('V7_')
    var_0 = listify_lookup_plugin_terms(arr_0, arr_1, arr_2)
    assert var_0 == ['', '', '']

# Generated at 2022-06-25 13:27:30.901121
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '3n^6F&I}k/'
    str_1 = '{C,<'
    assert listify_lookup_plugin_terms(str_0, str_1) == '3n^6F&I}k/{C,<'
    assert listify_lookup_plugin_terms(str_1, str_0) == '{C,<3n^6F&I}k/', "listify_lookup_plugin_terms() returned value does not match the expected value"
    assert listify_lookup_plugin_terms(str_0, str_0) == '3n^6F&I}k/3n^6F&I}k/', "listify_lookup_plugin_terms() returned value does not match the expected value"

# Generated at 2022-06-25 13:27:36.350440
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    assert var_0 == [int_0], "var_0: Expected {}, but got {}".format([int_0], var_0)

if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:37.922830
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)

# Generated at 2022-06-25 13:27:40.714284
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    assert var_0 == 162


# Generated at 2022-06-25 13:27:46.184769
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    file_loader_0 = open('/etc/passwd')
    str_0 = 'x;+jK'
    dict_0 = {'key_0':'value_0', 'key_1':'value_1', 'key_2':'value_2'}
    int_0 = 233
    str_1 = 'PZp'
    int_1 = 275
    int_2 = -164

# Generated at 2022-06-25 13:27:48.588497
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    print('\nUnit test for function listify_lookup_plugin_terms\n')

    # Test cases
    test_case_0()

    print('\n')

# Generated at 2022-06-25 13:27:49.644236
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This code is deprecated and has been replaced by a normal unit test
    pass

# Generated at 2022-06-25 13:27:52.686458
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == True

if __name__ == "__main__":
    print(test_case_0())

# Generated at 2022-06-25 13:28:30.054437
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = 1
    str_0 = 'a'
    assert listify_lookup_plugin_terms(var_0, str_0) == [1], "listify_lookup_plugin_terms(var_0, str_0) == [1]"
    var_0 = 1
    str_0 = 'a'
    assert listify_lookup_plugin_terms(var_0, str_0) == [1], "listify_lookup_plugin_terms(var_0, str_0) == [1]"
    var_0 = ['1', '2']
    str_0 = 'a'

# Generated at 2022-06-25 13:28:38.293048
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Fill in the input values
    int_2 = 162
    bool_2 = False
    str_1 = 'Z6;'

    # Perform the operation
    var_0 = listify_lookup_plugin_terms(int_2, bool_2, str_1)

    # Check for an error
    assert not var_0.is_error()

    # Check the expected result
    assert var_0.result == [162]

    # Fill in the input values
    int_3 = 162
    bool_3 = False
    str_2 = 'Z6;'

    # Perform the operation
    var_0 = listify_lookup_plugin_terms(int_3, bool_3, str_2)

    # Check for an error
    assert not var_0.is_error()

    # Check the expected result
   

# Generated at 2022-06-25 13:28:39.027193
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert not test_case_0()

# Generated at 2022-06-25 13:28:42.492395
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(1, False, "test_string") == [1]
    assert listify_lookup_plugin_terms(1, True, "test_string") == [1]
    assert listify_lookup_plugin_terms(1, True, "test_string") == [1]
    assert listify_lookup_plugin_terms(1, False, "test_string") == [1]

# Generated at 2022-06-25 13:28:51.684835
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = listify_lookup_plugin_terms(True, False, False, False)
    assert var_0 == True
    var_1 = listify_lookup_plugin_terms(True, True, False, True)
    assert var_1 == True
    var_2 = listify_lookup_plugin_terms(False, True, True, True)
    assert var_2 == False
    var_3 = listify_lookup_plugin_terms(True, False, False, False)
    assert var_3 == True
    var_4 = listify_lookup_plugin_terms('&*', False, False, False)
    assert var_4 == '&*'
    var_5 = listify_lookup_plugin_terms(False, True, False, False)
    assert var_5 == False
    var_

# Generated at 2022-06-25 13:28:58.227784
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True == (listify_lookup_plugin_terms(1, 1, 1) == [1])
    assert True == (listify_lookup_plugin_terms('1', 1, 1) == ['1'])
    assert True == (listify_lookup_plugin_terms(['1'], 1, 1) == ['1'])
    assert True == (listify_lookup_plugin_terms('{{ test }}', 1, 1) == ['{{ test }}'])
    assert True == (listify_lookup_plugin_terms(['{{ test }}'], 1, 1) == ['{{ test }}'])

# Generated at 2022-06-25 13:28:59.582736
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        listify_lookup_plugin_terms('b')
    except NameError as e:
        assert type(e) == NameError
    except Exception as e:
        assert type(e) != NameError

# Generated at 2022-06-25 13:29:00.553824
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # No raises exception outside of function
    assert test_case_0 != None

# Case 1

# Generated at 2022-06-25 13:29:02.411687
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 5
    bool_0 = True
    str_0 = 'f]P'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    print(var_0)


# Generated at 2022-06-25 13:29:03.931615
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)

    assert var_0 == 162


# Generated at 2022-06-25 13:30:24.541424
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    print(var_0) # returns [162]

    int_0 = 162
    list_0 = [int_0, int_0]
    bool_0 = False
    str_0 = 'H'
    var_0 = listify_lookup_plugin_terms(list_0, bool_0, str_0)
    print(var_0) # returns [162, 162]

    int_0 = 162
    list_0 = [int_0, int_0]
    bool_0 = False
    str_0 = 'H'
    var_0 = listify_lookup_plugin_terms

# Generated at 2022-06-25 13:30:30.943460
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = 162
    templar = False
    loader = 'Z6;'
    fail_on_undefined = None
    convert_bare = None
    try:
        listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    except SystemExit as e:
        print(e)
    try:
        listify_lookup_plugin_terms(terms, templar, loader)
    except SystemExit as e:
        print(e)

if __name__ == "__main__":
    test_case_0();

# Generated at 2022-06-25 13:30:31.981327
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == True



# Generated at 2022-06-25 13:30:33.613761
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    
    try:
        test_case_0()
    except:
        print("Test Case 0 Failed")


# Generated at 2022-06-25 13:30:40.057588
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test inline code for variable int_0 (162)
    int_0 = 162
    # Test inline code for variable bool_0 (False)
    bool_0 = False
    # Test inline code for variable str_0 ('Z6;')
    str_0 = 'Z6;'
    # Test function call for listify_lookup_plugin_terms
    var_0 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    # Test inline code for variable int_1 (311)
    int_1 = 311
    # Test inline code for variable str_1 ('l&')
    str_1 = 'l&'
    # Test function call for listify_lookup_plugin_terms

# Generated at 2022-06-25 13:30:42.730231
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    assert listify_lookup_plugin_terms(int_0, bool_0, str_0) == 162



# Generated at 2022-06-25 13:30:52.328156
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(162, False, 'Z6;') == []
    assert listify_lookup_plugin_terms(76, True, ':') == []
    assert listify_lookup_plugin_terms(59, True, '=>') == []
    assert listify_lookup_plugin_terms(52, True, '}') == []
    assert listify_lookup_plugin_terms(92, False, 'w') == []
    assert listify_lookup_plugin_terms(76, False, '}') == []
    assert listify_lookup_plugin_terms(41, False, '+') == []
    assert listify_lookup_plugin_terms(47, True, '=>') == []
    assert listify_lookup_plugin_terms(72, True, '>') == []

# Generated at 2022-06-25 13:30:59.925131
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = True
    str_0 = 'Z6;'
    int_1 = 104
    str_1 = 'U\u25d6\u25d6\u25d6\u25d6\u25d6'
    int_2 = 4
    str_2 = '-2'
    bool_1 = False
    str_3 = 'as\u25d7\u25d7\u25d7\u25d7\u25d7'
    bool_2 = True

# Generated at 2022-06-25 13:31:08.185835
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = listify_lookup_plugin_terms('var_0', 'var_0', 'var_0')
    var_1 = listify_lookup_plugin_terms('var_0', 'var_0', 'var_1')
    var_2 = listify_lookup_plugin_terms('var_0', 'var_0', 'var_2')
    var_3 = listify_lookup_plugin_terms('var_0', 'var_0', 'var_3')
    var_4 = listify_lookup_plugin_terms('var_0', 'var_0', 'var_4')
    var_5 = listify_lookup_plugin_terms('var_0', 'var_0', 'var_5')

# Generated at 2022-06-25 13:31:11.738578
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 162
    bool_0 = False
    str_0 = 'Z6;'
    var_1 = listify_lookup_plugin_terms(int_0, bool_0, str_0)
    assert var_1.pop() == 'Z6;'
    assert var_1.pop() == 162