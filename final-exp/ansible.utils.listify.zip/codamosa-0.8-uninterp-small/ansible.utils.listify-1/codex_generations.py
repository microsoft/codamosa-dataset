

# Generated at 2022-06-25 13:24:06.486562
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'\x94\x9d\xa6\xee\xf2\x96\x80\x99\x8c\xbf\x13\xd9\xf8\x88A\xc7\xc0\xbd\x88\x87[\x1e\xfa\x9d\x18\x84\xe5\xe6\xcc\xa8'

# Generated at 2022-06-25 13:24:15.697735
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = -100

# Generated at 2022-06-25 13:24:25.402288
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 1437373633
    int_1 = 1437373633
    int_2 = 1437373633
    int_3 = 1437373633
    int_4 = 1437373633
    bool_0 = True
    bool_1 = True
    bool_2 = True
    bool_3 = True
    bool_4 = True
    bool_5 = True
    bool_6 = True
    bool_7 = True
    bool_8 = True
    bool_9 = True
    bool_10 = False

# Generated at 2022-06-25 13:24:32.158700
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    buf = b'{}\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x00'
    with open('/tmp/test_listify_lookup_plugin_terms.pickle', 'wb') as fd:
        fd.write(buf)
        fd.flush()

    with open('/tmp/test_listify_lookup_plugin_terms.pickle', 'rb') as fd:
        pickup = fd.read()
        assert pickup == buf

# Generated at 2022-06-25 13:24:41.378868
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 18
    str_1 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    float_0 = 1.5689898307453533e-31
    int_1 = -21
    assert(listify_lookup_plugin_terms(int_0, str_1, float_0) == int_0)
    assert(listify_lookup_plugin_terms(str_1, int_1, str_1) == str_1)
    assert(listify_lookup_plugin_terms(str_1, str_1, int_0) == str_1)


# Generated at 2022-06-25 13:24:46.203425
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = -100
    bytes_0 = b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    result_0 = test_case_0()
    assert isinstance(result_0, list)
    check_result_0(result_0)



# Generated at 2022-06-25 13:24:47.079249
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert(test_case_0())

# Generated at 2022-06-25 13:24:48.279343
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = test_case_0()
    assert var_0 == -100

# Generated at 2022-06-25 13:24:55.497531
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """ listify_lookup_plugin_terms function units tests """

    # Unit test for function listify_lookup_plugin_terms
    # Unit test for function listify_lookup_plugin_terms
    var_0 = getattr('new_var_0', 'set_var')
    var_1 = getattr(var_0, 'new_var_1')
    var_2 = getattr(var_0, 'new_var_1')
    var_1 = getattr(var_0, 'new_var_1')
    assert var_1 == var_2
    var_1 = getattr(var_0, 'new_var_1')
    assert var_1 == var_2
    assert var_1 == var_2
    assert var_1 == var_2

# Generated at 2022-06-25 13:25:00.662014
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = -2
    bytes_1 = b'\xe4\\'
    var_0 = listify_lookup_plugin_terms(int_0, bytes_1, int_0)
    assert var_0 == ['-2'], "listify_lookup_plugin_terms returned '%s' instead of '%s'" % (var_0, ['-2'])

# Generated at 2022-06-25 13:25:09.862873
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Input parameters
    module_args = {}

    # Output data
    expected_results = {"results": [{"key1": "value1"}, {"key2": "value2"}]}

    # Unit test
    actual_results, module_return_value, shell_command = utils.run_ansible_module(module_name, module_args, tmpdir)

    # Assertion Fails if the return code is not 0
    assert not module_return_value

    # Assertion Fails if the returned value is not as expected
    assert actual_results == expected_results

# Generated at 2022-06-25 13:25:18.266761
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Call function
    retval = listify_lookup_plugin_terms(terms=b'', templar=None, loader=None)

    # Check return value
    assert retval == [b'']

    # Call function
    retval = listify_lookup_plugin_terms(terms=b'foobar', templar=None, loader=None)

    # Check return value
    assert retval == [b'foobar']

    # Call function
    retval = listify_lookup_plugin_terms(terms=[b'foobar', b'baz'], templar=None, loader=None)

    # Check return value
    assert retval == [b'foobar', b'baz']

# Generated at 2022-06-25 13:25:27.913940
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = 'foo'
    templar = None
    loader = None
    fail_on_undefined = True
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined) == ['foo']
    terms = 'foo'
    templar = None
    loader = None
    fail_on_undefined = False
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined) == ['foo']
    terms = 'foo'
    templar = None
    loader = None
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['foo']
    terms = ['foo']
    templar = None
    loader = None

# Generated at 2022-06-25 13:25:30.358514
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    assert test_case_0() == listify_lookup_plugin_terms(b'{}', templar, None)

# Generated at 2022-06-25 13:25:32.876555
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test if assertion fails when test_case_0 is called
    try:
        test_case_0()
    except AssertionError:
        # catch assertion error, do nothing
        pass


# Test if function listify_lookup_plugin_terms can be called and return something

# Generated at 2022-06-25 13:25:42.827705
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common._collections_compat import Set

    # Test the call listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)

    class AnsibleModule:
        class params:
            _ansible_no_log = 0
        def __init__(self, dict_0, dict_1, dict_2, dict_3):
            self._ansible_no_log = dict_0
            self._ansible_debug = dict_1
            self.params = dict_2

# Generated at 2022-06-25 13:25:47.180732
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    args = {}
    terms = string_types
    templar = AnsibleTemplate("-u test")
    loader = AnsibleLoader("-u test")
    fail_on_undefined = True
    convert_bare = False

    check_listify_lookup_plugin_terms(args, terms, templar, loader, fail_on_undefined, convert_bare)

# Generated at 2022-06-25 13:25:54.737793
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Populate the arguments that would otherwise be provided by the extension
    class AnsibleVarsModule(object):

        class ModuleStub(object):

            def __init__(self, args):
                self.params = args

            def __getitem__(self, name):
                return self.params[name]

        def __init__(self, module_args):
            self.params = self.ModuleStub(module_args)

        def __getitem__(self, name):
            return self.params[name]

    class AnsibleModuleStub:
        def __init__(self, args):
            self.params = args

        def __getitem__(self, name):
            return self.params[name]

    args = dict()
    args.update({"my_var": "my_value"})

    module = Ans

# Generated at 2022-06-25 13:25:57.746762
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == "c3RhY2tmbG93EA==\n"



if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:06.633007
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    testcase = (
        (
            {'terms': '{{ terms }}', 'fail_on_undefined': True, 'convert_bare': False},
            {'terms': '{{ terms }}'},
        ),
    )

    print("Function listify_lookup_plugin_terms(templar: TemplateMixin, terms: str, fail_on_undefined: bool = True, convert_bare: bool = False)")
    for (case, result) in testcase:
        print("Input: ")
        print(case)
        print("Result: ")
        print(result)
        assert(listify_lookup_plugin_terms(**case) == result)
    print("Test", test_case_0.__name__, "Done.\n")


if __name__ == '__main__':
    test

# Generated at 2022-06-25 13:26:11.579968
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert bytes_0 == listify_lookup_plugin_terms('{}', templar, loader, fail_on_undefined=True, convert_bare=False)

# Generated at 2022-06-25 13:26:20.696048
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:26:27.299065
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import unittest
    from ansible.template.template import Templar

    class TestLookupModule(unittest.TestCase):

        def test_listify_lookup_plugin_terms__with_string(self):

            # Test with string
            templar = Templar(loader, variables={})
            # test_case_0
            result = listify_lookup_plugin_terms("'test_string'", templar, loader, fail_on_undefined=True, convert_bare=False)
            self.assertEqual(result, ["'test_string'"])

test_case_0()

test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:29.726733
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(bytes_0, templar, loader) == result_0

# Unit test example
test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:40.073239
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test for python str class
    assert listify_lookup_plugin_terms(terms='foo_bar') == ['foo_bar']

    # Test for python str class
    assert listify_lookup_plugin_terms(terms=[['foo_bar', 'foobar']]) == [['foo_bar', 'foobar']]

    # Test for python str class
    assert listify_lookup_plugin_terms(terms=b'foo_bar') == ['foo_bar']

    # Test for python str class
    assert listify_lookup_plugin_terms(terms='foo_bar', templar=bytes_0) == ['foo_bar']

    # Test for python list class
    assert listify_lookup_plugin_terms(terms=['foo_bar']) == ['foo_bar']

    # Test for python list class
   

# Generated at 2022-06-25 13:26:48.483760
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    global bytes_0
    # global bytes_1
    # global bytes_2
    # global bytes_3
    # global bytes_4
    # global bytes_5
    # global bytes_6
    # global bytes_7
    # global bytes_8
    # global bytes_9
    # bytes_9 = b'\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x00'
    terms_0 = None
    templar_0 = None
    loader_0 = None
    assert listify_lookup_plugin_terms(terms_0, templar_0, loader_0, True) == bytes_0
    # print("bytes_1

# Generated at 2022-06-25 13:26:56.261474
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        #test_case_0
        bytes_0 = b'{}\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x00'
        assert listify_lookup_plugin_terms(bytes_0) == b'{}\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x00'
    except Exception as e:
        assert False



# Generated at 2022-06-25 13:27:04.513185
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import pickle
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    # create a playbook with a :vault: section
    vault_text = b'$ANSIBLE_VAULT;1.1;AES256\n363033366133363165633661323361333132613338643631663035376137653962633264353362\n363165383161643961323137326465363162330a61393238616334633965346431326331613965\n363663623563326464343264633030353631343336623235303539333431626534366434333938\n6635\n'
    vault_password = b'asdf'
    p = pickle.dumps

# Generated at 2022-06-25 13:27:07.523119
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(b'\x00',b'\x00',b'\x00') is None
    assert listify_lookup_plugin_terms(test_case_0(),test_case_0(),test_case_0()) is None



# Generated at 2022-06-25 13:27:17.933096
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(b'test_value_6', b'test_value_6', b'test_value_6', True, True) == [b'test_value_6']
    assert listify_lookup_plugin_terms(b'test_value_8', b'test_value_8', b'test_value_8', True, True) == [b'test_value_8']
    assert listify_lookup_plugin_terms(b'test_value_11', b'test_value_11', b'test_value_11', True, True) == [b'test_value_11']

# Generated at 2022-06-25 13:27:23.848529
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert bytes(listify_lookup_plugin_terms(bytes_0, bytes_0, bytes_0, False, False)) == bytes_0


# Generated at 2022-06-25 13:27:25.287844
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert False, "Unit tests for listify_lookup_plugin_terms not implemented."

# Generated at 2022-06-25 13:27:32.702873
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ..module_utils import AnsibleModule
    
    # Test case for when terms are a string, and the string is empty
    terms = '' # This was b'' in the previous version
    assert listify_lookup_plugin_terms(terms, None, None) == []

    # Test case for when terms is a list, and the list is empty
    terms = []
    assert listify_lookup_plugin_terms(terms, None, None) == []

    # Test case for when terms is a string, and the string is not empty
    terms = 'hello world'
    assert listify_lookup_plugin_terms(terms, None, None) == ['hello world']

    # Test case for when terms is a list, and the list is not empty
    terms = [1, 2, 3]

# Generated at 2022-06-25 13:27:33.747771
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert type(test_case_0()) == bytearray

# Generated at 2022-06-25 13:27:41.606141
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:27:50.012151
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Create an instance of our stubs for testing
    import ansible.template

    ansible_template = ansible.template.Template()
    terms = 'string'
    templar = ansible_template
    loader = string_types
    fail_on_undefined = false_function
    convert_bare = false_function
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    assert result == None
    terms = 'string'
    templar = ansible_template
    loader = string_types
    fail_on_undefined = true_function
    convert_bare = true_function
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)

# Generated at 2022-06-25 13:27:53.687982
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(terms=bytes_0, templar=None, loader=None, fail_on_undefined=True, convert_bare=False) == judge_0


# Generated at 2022-06-25 13:28:01.552507
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    p = PlayContext()
    l = DataLoader()
    t = Templar(loader=l, shared_loader_obj=l, variables={'var': 'ok'})

    x = listify_lookup_plugin_terms('{{foo}}', t, l)
    assert (isinstance(x, list) and len(x) == 1)

    x = listify_lookup_plugin_terms(['{{foo}}', '{{foo}}'], t, l)
    assert (isinstance(x, list) and len(x) == 2)


# Generated at 2022-06-25 13:28:07.879247
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    x = b'\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x00'
    assert set(listify_lookup_plugin_terms(x, test_case_0, None)) == set(['{}', b'\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x00'])

# Generated at 2022-06-25 13:28:11.980525
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert(bytes_0 == bytes(listify_lookup_plugin_terms(b'{}', b'\x00\x00\x00\x02', b'\x00\x00\x00\x02', b'\x00\x00\x00\x03', b'\x00\x00\x00\x02', b'\x00\x00\x00')))

# Generated at 2022-06-25 13:28:24.424213
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Mock object returned by function:
    mock = 'TEST'

    # Mock object imported into module
    mock_itertools = 'TEST'
    mock_six = mock
    mock_string_types = mock
    mock_from = mock
    mock_Iterable = mock
    mock_string_types = mock

    # Mock variables
    mock_terms = mock
    mock_templar = mock
    mock_loader = mock
    mock_fail_on_undefined = mock
    mock_convert_bare = mock

    # Mock function:
    def mock_filter(templar, vars=None, fail_on_undefined=True):
        return mock

    class TestClass:
        def __init__(self, value):
            self.value = value


# Generated at 2022-06-25 13:28:30.776261
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = -100
    bytes_0 = b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    var_0 = listify_lookup_plugin_terms(int_0, bytes_0, int_0)
    str_0 = str(var_0)
    if str_0 != '-100':
        print(str_0)
        print("Test case 0 failed")
        exit(1)
    list_0 = []
    for i in range(50, 60):
        list_0.append(i)
    var_0 = listify_lookup_plugin_terms(list_0, bytes_0, int_0)

# Generated at 2022-06-25 13:28:34.806291
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = -100
    var_1 = b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    
    var_2 = listify_lookup_plugin_terms(var_0, var_1, var_0)

# Generated at 2022-06-25 13:28:38.681253
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    terms = [None, None]
    templar = [None, None]
    loader = [None, None]
    fail_on_undefined = [None, None]
    convert_bare = [None, None]
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, conve) == [None, None]



# Generated at 2022-06-25 13:28:39.991634
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    out, err = capsys.readouterr()
    assert out == "Hello world"
    assert err == ""

# Generated at 2022-06-25 13:28:41.855320
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True
    #assert False # TODO: implement your test here

# vim: expandtab tabstop=4 shiftwidth=4 autoindent

# Generated at 2022-06-25 13:28:44.841005
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert func_0() == 0
    assert func_1() == 0
    assert func_2() == 0
    assert func_3() == 0
    assert func_4() == 0
    assert func_5() == 0
    assert func_6() == 0


# Generated at 2022-06-25 13:28:45.509511
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass # placeholder

# Generated at 2022-06-25 13:28:50.163500
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 0
    int_0 = 0
    bytes_0 = b'\x80\x06\xec\x02\x8b\x00\x14\x00'
    var_0 = listify_lookup_plugin_terms(int_0, bytes_0, int_0)
    assert var_0 == 0

# Generated at 2022-06-25 13:28:54.407782
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # These inputs are returned from the plugin

    # listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)
    try:
        test_case_0()
    except AssertionError as e:
        fail(e.message)
    except Exception as e:
        fail(e.message)

# Generated at 2022-06-25 13:29:06.838329
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:29:14.481416
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = -100
    bytes_0 = b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    var_0 = listify_lookup_plugin_terms(int_0, bytes_0, int_0, False, False)
    int_1 = -1
    slice_0 = bytes_0[int_1:]
    assert len(var_0) == 1, 'Expected %d, got %d!' % (1, len(var_0))
    assert len(slice_0) == int_1, 'Expected %d, got %d!' % (int_1, len(slice_0))
    int_2 = -1

# Generated at 2022-06-25 13:29:22.390584
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 'str' is str
    assert 'listify_lookup_plugin_terms' is str
    listify_lookup_plugin_terms(str, str, str)
    listify_lookup_plugin_terms(str, str, str)
    str.listify_lookup_plugin_terms(str, str, str)
    listify_lookup_plugin_terms(str, str, str)
    listify_lookup_plugin_terms(str, str, str)
    listify_lookup_plugin_terms(str, str, str)
    listify_lookup_plugin_terms(str, str, str)
    listify_lookup_plugin_terms(str, str, str)
    listify_lookup_plugin_terms(str, str, str)

# Generated at 2022-06-25 13:29:29.560572
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 1
    bytes_0 = b'\x05 \xe4\x1a\x92\x95\x01\xec\x99B\xbb\xe5w\x83\x8b\xc6\x91\x0c\x9eK\x1a\x06\x1c\x8b\x0c\x12\xa3\xdbk\x8b\x0c\x12\xa3\xdb'
    int_1 = 0

# Generated at 2022-06-25 13:29:35.761864
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:29:38.048705
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('')
    print('starting test_listify_lookup_plugin_terms')
    test_case_0()


if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:29:39.549492
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """ listify_lookup_plugin_terms
    """
    # Test fixture for function listify_lookup_plugin_terms
    def test_function(x, y, z):
        return 1
    pass

# Generated at 2022-06-25 13:29:45.788115
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_1 = -100
    str_0 = 'I\xcdp\x85\xebv\xf5\x1e\xd0\x16\xb9\xd9\x03\xdb\xf3\xaa\x1f\x04\xa0\xbb\xe0\xef\x04\x87\x10\x8f\x98\x0f\x87\x7f\x16\x9a'
    int_2 = -100
    var_0 = listify_lookup_plugin_terms(int_1, str_0, int_2)

# Generated at 2022-06-25 13:29:52.677467
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = -100
    bytes_0 = b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    int_1 = -46
    var_0 = listify_lookup_plugin_terms(int_0, bytes_0, int_0)
    assert var_0 == ([-100], False)
    var_1 = listify_lookup_plugin_terms(int_0, bytes_0, int_1)
    assert var_1 == ([-100], False)
    var_2 = listify_lookup_plugin_terms(int_1, bytes_0, int_0)
    assert var_2 == ([-46], False)
    var_3 = list

# Generated at 2022-06-25 13:29:54.039425
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms()

if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:30:21.724566
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # build_values of str
    int_1 = 1234
    bytes_1 = b'\x8f\xca\x02}m\xc8\x8b\x9a\x1d\x13\x11\xd2\xdf\xa1\x1a\x8e\x9b\xa9\xbev\xde;\x18\x99'
    var_1 = listify_lookup_plugin_terms(int_1, bytes_1, int_1)
    # build_values of str
    int_2 = 23456

# Generated at 2022-06-25 13:30:23.110857
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except:
        pass
    else:
        raise Exception("Did not raise expected exception")

# Generated at 2022-06-25 13:30:29.590197
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = -100
    assert listify_lookup_plugin_terms(int_0) == -100
    bytes_0 = b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    assert listify_lookup_plugin_terms(bytes_0) == b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'

# Generated at 2022-06-25 13:30:33.267780
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = -100
    var_1 = b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    listify_lookup_plugin_terms(var_0, var_1, var_1)

# Generated at 2022-06-25 13:30:39.812002
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import re
    from ansible.template.safe_eval import safe_eval
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible import constants as C

# Generated at 2022-06-25 13:30:47.240755
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # print('Hi')
    int_1 = -100
    bytes_1 = b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    var_0 = listify_lookup_plugin_terms(bytes_1, int_1, bytes_1)
    assert((var_0 == int_1))
    int_0 = -100
    var_1 = listify_lookup_plugin_terms(int_0, bytes_1, int_0)
    assert((var_1 == bytes_1))

# Generated at 2022-06-25 13:30:50.917578
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    listify_lookup_plugin_terms(var_1, var_2, var_3, var_4, var_5)

# Generated at 2022-06-25 13:30:53.547567
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = -100
    # Assert only: int_0, bytes_0, int_0
    var_0 = listify_lookup_plugin_terms(int_0, bytes_0, int_0)

# Generated at 2022-06-25 13:30:54.371177
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:30:59.537523
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 1 == 1
    assert int(1) == 1
    assert int(0) == 0
    assert string_types != 1
    assert templar != 0
    assert loader != 1
    assert fail_on_undefined != 1
    assert convert_bare != 1
    assert isinstance(int(), int)
    assert isinstance(int(1), int)
    assert isinstance(int(0), int)
    assert list != 1
    assert isinstance(list(), list)
    assert isinstance(iter(list()), iter)



# Generated at 2022-06-25 13:31:41.188016
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    list_0 = [2, 'a', int]
    list_1 = []
    list_2 = ['0', .7, [0, 0]]
    list_3 = [1, (0, 0), str]
    list_4 = [int, 1, 1]
    list_5 = ['ABC', 1, int]
    list_6 = [b'\x00', 2, None]
    list_7 = [0, b'\x00', 'ABC']
    list_8 = ['m', 1, (0, 0)]
    list_9 = ['', 3, int]
    list_10 = [b'\x00', 1, (0, 0)]
    list_11 = ['', 3, list]
    list_12 = [1, str, [0, 0]]

# Generated at 2022-06-25 13:31:44.634748
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = -100
    bytes_0 = b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    var_0 = listify_lookup_plugin_terms(int_0, bytes_0, int_0)

# Generated at 2022-06-25 13:31:51.338569
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = -100
    bytes_0 = b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    var_0 = listify_lookup_plugin_terms(int_0, bytes_0, int_0)
    assert var_0 == [-100, b'u\x9a\x97\xb4\xadu;\xddE\x11n\x13\xcdB\xf0\x11\xd0r', -100]

# Generated at 2022-06-25 13:31:51.775126
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 1 == 1

# Generated at 2022-06-25 13:31:59.214467
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:32:05.475717
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:32:11.310501
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = -100
    var_1 = b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    try:
        assert var_0 == 0
        assert var_1 == b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    except AssertionError:
        print('Incorrect ')

# Generated at 2022-06-25 13:32:12.230514
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == ()

# Generated at 2022-06-25 13:32:18.922490
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test zero case:

    int_0 = -100
    bytes_0 = b'u\x9a\x97\xb4\xadu;\xddE\x1d\x11n\x13\xcdB\xf0\x11\xd0r'
    var_0 = listify_lookup_plugin_terms(int_0, bytes_0, int_0)
    assert var_0 == None

    # Test one case:

    int_1 = -100

# Generated at 2022-06-25 13:32:19.532429
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0 == 0