

# Generated at 2022-06-25 13:24:04.528239
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = '-r +{delay_sec}s "{message}"'
    templar = templar = '-r +{delay_sec}s "{message}"'
    loader = ()
    fail_on_undefined = True
    convert_bare = False
    var = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    assert(var == ['{delay_sec}', '{message}'])

# Generated at 2022-06-25 13:24:07.873834
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    sentence_0 = 'this is a sentence'
    words_0 = sentence_0.split()
    result_0 = listify_lookup_plugin_terms(words_0, sentence_0, words_0)
    assert result_0 == list(words_0)



# Generated at 2022-06-25 13:24:10.403357
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == True

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:19.072956
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    str_0 = '-r +{delay_sec}s "{message}"'
    str_1 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    var_0 = isinstance(str_0, string_types)
    var_1 = isinstance(str_1, string_types)
    var_2 = isinstance(tuple_0, Iterable)
    var_3 = listify_lookup_plugin_terms(str_0, str_1, tuple_0)
    print(var_0, var_1, var_2, var_3)

test_listify_lookup_plugin_terms()
test_case_0()

# Generated at 2022-06-25 13:24:25.449964
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # i_0 = ''
    # s_0 = ''
    # t_0 = (  )
    # r_0 = listify_lookup_plugin_terms(i_0, s_0, t_0)
    assert r_0

    # i_0 = ''
    # i_1 = ''
    # s_0 = ''
    # t_0 = (  )
    # r_0 = listify_lookup_plugin_terms(i_0, s_0, t_0)
    assert r_0

# Generated at 2022-06-25 13:24:29.983930
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

   # Example unit test
    assert listify_lookup_plugin_terms('-r +{delay_sec}s "{message}"', '-r +{delay_sec}s "{message}"', ()) == ['-r +{delay_sec}s "{message}"'], 'Example unit test'


if __name__ == '__main__':
    # run unit test
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:30.786424
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # print(listify_lookup_plugin_terms())
    assert 1 == 1

# Generated at 2022-06-25 13:24:31.680637
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:24:33.409857
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print("Test of function listify_lookup_plugin_terms")

    templar = None
    loader = None

    test_case_0()

# Generated at 2022-06-25 13:24:38.211324
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert getattr(listify_lookup_plugin_terms, "__doc__", None) is not None
    assert '-r +{delay_sec}s "{message}"' in listify_lookup_plugin_terms(getattr(listify_lookup_plugin_terms, "__doc__", None),
        getattr(listify_lookup_plugin_terms, "__doc__", None), getattr(listify_lookup_plugin_terms, "__doc__", None))
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    assert str_0 == listify_lookup_plugin_terms(str_0, str_0, tuple_0)

# Generated at 2022-06-25 13:24:41.293434
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # test_case_0()
    pass

# Generated at 2022-06-25 13:24:44.171491
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 'str' == type(listify_lookup_plugin_terms("../delay_sec}s \"{message\"}", "\"../delay_sec}s \\\"{message\\\"}\"", 'message')).__name__


# Generated at 2022-06-25 13:24:52.743442
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Try loading data from YAML file
    with open("listify_lookup_plugin_terms.yml", 'r') as stream:
        data_loaded = yaml.safe_load(stream)
    # Get data from the loaded YAML file
    (test_listify_lookup_plugin_terms_0, terms_0, templar_0, loader_0, fail_on_undefined_0, convert_bare_0) = data_loaded

    # Evaluate the function and get the return value
    var_0 = listify_lookup_plugin_terms(terms_0, templar_0, loader_0, fail_on_undefined_0, convert_bare_0)

    # Assert if the return value from function is equal to the expected value
    assert var_0 == test_listify_lookup

# Generated at 2022-06-25 13:24:57.839284
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Try to catch the exception for a known type
    try:
        assert isinstance(listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False), basestring)
    except:
        assert isinstance(listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False), Iterable)

    # Ensure that a known bad input returns the correct exception type
    with pytest.raises(TypeError):
        listify_lookup_plugin_terms(terms, loader, templar, fail_on_undefined=True, convert_bare=False)

# Generated at 2022-06-25 13:25:07.708113
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Dummy `ansible.module_utils.common._collections_compat.Iterable` class. 
    # This is a non-Pythonic class only used for testing purposes.
    class Iterable():
        def __init__(self, *args, **kwargs):
            pass
    # Save original values of global variables
    ansible_module_utils_common__collections_compat_Iterable = Iterable
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)
    assert var_0 == '-r +{delay_sec}s "{message}"'
    assert not var_0 is str_0
    # Revert global variables to their original values
   

# Generated at 2022-06-25 13:25:11.963565
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assertion_flag = 0
    test_case_0()
    if assertion_flag == 0 :
        print("Test Case Passed.")
    else:
        print("Test Case Failed.")

# Calling the main function
test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:16.082284
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    
    # Assigning value of function return to the test variable
    test = listify_lookup_plugin_terms()

    
    # Asserting value is equal to expected value
    assert test is True, 'Value: {} != True'.format(test)


# Generated at 2022-06-25 13:25:26.654859
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)
    assert var_0 == ['-r +{delay_sec}s "{message}"'], "listify_lookup_plugin_terms should return ['-r +{delay_sec}s \"{message}\"'], got " + str(var_0)

    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)

# Generated at 2022-06-25 13:25:27.574206
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print(test_case_0())



# Generated at 2022-06-25 13:25:30.358796
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == ("-r +{delay_sec}s \"{message}\"", [])


# This is main variable.
if __name__ == '__main__':
    #call the function
    test_case_0()

# Generated at 2022-06-25 13:25:34.459413
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:25:35.707270
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True
#
# test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:39.448592
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # ASSERT: '-r +{delay_sec}s "{message}"' == '-r +{delay_sec}s "{message}"'
    assert '-r +{delay_sec}s "{message}"' == '-r +{delay_sec}s "{message}"'

# Generated at 2022-06-25 13:25:47.949895
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    args = {}
    command = '-r +{delay_sec}s "{message}"'
    args['command'] = command
    args['fail_on_undefined'] = True
    # Return value type test
    # We are using basic test(assertEqual) for test
    # You can use your own test
    # str_0 type test
    assert isinstance(command, str)
    # tuple_0 type test
    assert isinstance((), tuple)
    # Return value type test
    assert isinstance(listify_lookup_plugin_terms(command, command, ()), list)

# Testing function listify_lookup_plugin_terms
test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:51.284059
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Setup
    terms = 1
    templar = 1
    loader = 1

    # Assumptions
    assert True == True

    # Test
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == True

    # Teardown
    # (nothing to do)

# Generated at 2022-06-25 13:25:57.297542
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    fail_on_undefined = True
    convert_bare = False
    str_0 = """  {{"-r +{delay_sec}s \"{message}\""|
  - [1,2,3,4]|
  - {'one': 1, 'two': 2, 'three': 3}|
  - {'one': '1', 'two': '2', 'three': '3'}
}}
"""
    tuple_0 = ()
    tuple_1 = (None,)
    tuple_2 = (None,)
    # str_1 = """  {{"-r +{delay_sec}s \"{message}\""|
  # - [1,2,3,4]|
  # - {'one': 1, 'two': 2, 'three': 3}|
  # - {'one': '1

# Generated at 2022-06-25 13:26:06.373447
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:26:07.649155
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert isinstance(listify_lookup_plugin_terms(), list)
    assert True


# Generated at 2022-06-25 13:26:11.952994
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    args = '{{var_0}}', '{{var_1}}', '{{var_2}}'
    ans = ['{{var_0}}', '{{var_1}}', '{{var_2}}']
    assert listify_lookup_plugin_terms(*args) == ans



# Generated at 2022-06-25 13:26:14.614021
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert False, "Test Todo - verify if listify_lookup_plugin_terms is used"
    # if you want to test the code, comment in the following lines
    # test_case_0()

# Generated at 2022-06-25 13:26:29.117594
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = '/etc/ansible/hosts'
    var_1 = b'/etc/ansible/hosts'
    var_2 = {'file': '/etc/ansible/hosts'}
    var_3 = u'file.txt'
    var_4 = {'file': 'file.txt'}
    var_5 = '(l)'
    var_6 = 'file.txt'
    var_7 = 'file'
    var_8 = ['/etc/ansible/hosts', 'file.txt', '(l)']
    var_9 = ['/etc/ansible/hosts', 'file.txt', ['(', 'l', ')']]
    var_10 = ['/etc/ansible/hosts', 'file.txt', b'file']

# Generated at 2022-06-25 13:26:30.036031
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:26:31.184168
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert True



# Generated at 2022-06-25 13:26:32.358732
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert type(test_case_0()) is list

# Generated at 2022-06-25 13:26:33.664011
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)

# Generated at 2022-06-25 13:26:43.046197
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test when there is only one element in the terms
    terms = 'ranger'
    template = 'ranger'
    ans = [template]
    assert listify_lookup_plugin_terms(terms, template, None) == ans
    assert listify_lookup_plugin_terms(template, template, None) == ans

    # Test with an empty list
    terms = []
    template = 'ranger'
    ans = []
    assert listify_lookup_plugin_terms(terms, template, None) == ans

    # Test with a list with one element
    terms = ['ranger']
    template = 'ranger'
    ans = ['ranger']
    assert listify_lookup_plugin_terms(terms, template, None) == ans

    # Test with a repeated element
    terms = ['ranger', 'ranger']

# Generated at 2022-06-25 13:26:44.078588
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 1 == 1


if __name__ == '__main__':
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:46.589288
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(None, None, None)

# DEV: Code to run if calling library directly
if __name__ == '__main__':
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:47.330813
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms

# Generated at 2022-06-25 13:26:51.659697
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
        print("Unit test for function listify_lookup_plugin_terms successful")
    except:
        print("Unit test for function listify_lookup_plugin_terms failed")

# Main entry point for program.
if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:12.539025
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms("", "", tuple()) == [""], "Expected true but found false"
    assert listify_lookup_plugin_terms("", "", tuple()) == [""], "Expected true but found false"
    assert listify_lookup_plugin_terms("a", "a", tuple()) == ["a"], "Expected true but found false"
    assert listify_lookup_plugin_terms("b", "b", tuple()) == ["b"], "Expected true but found false"
    assert listify_lookup_plugin_terms("c", "c", tuple()) == ["c"], "Expected true but found false"
    assert listify_lookup_plugin_terms("d", "d", tuple()) == ["d"], "Expected true but found false"

# Generated at 2022-06-25 13:27:14.195048
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    #return_value_0 = listify_lookup_plugin_terms()
    assert True # TODO: implement your test here

# Generated at 2022-06-25 13:27:21.678470
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    try:
        from ansible.template import Templar
        from ansible.playbook.play_context import PlayContext
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars import VariableManager
    except ImportError:
        print('ansible modules could not be imported')
        return

    test_cases = [
        case_0,
    ]

    for test_case in test_cases:
        test_case()

    print('All tests completed successfully')


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:23.042798
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms), "Function does not exist"



# Generated at 2022-06-25 13:27:25.109925
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms == '-r +{delay_sec}s "{message}"'
    assert test_case_0 == ()

# Generated at 2022-06-25 13:27:26.859381
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(str_0, str_0, tuple_0) == var_0


# Generated at 2022-06-25 13:27:29.551739
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test no.1 - assert function returns string
    test_case = '{ "a": 123, "b": "abc" }'
    assert type(listify_lookup_plugin_terms(test_case, str(test_case), tuple())) is str


# Generated at 2022-06-25 13:27:36.032992
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_cases = [
        # (input_args, expected_output)
        ((str_0, str_0, tuple_0), var_0),
    ]
    for case_input, expected_output in test_cases:
        cur_output = listify_lookup_plugin_terms(*case_input)
        try:
            assert cur_output == expected_output
            print('case 0 passed!')
        except AssertionError:
            for i in range(len(cur_output)):
                print('item %d:' % i)
                print(cur_output[i])
                print('---')
            print('case 0 failed!')
            raise

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:37.689229
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-25 13:27:42.719638
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = 'ansible'
    tuple_0 = ('')
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)
    assert var_0 == ['ansible']
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0, False)
    assert var_0 == ['ansible']
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0, False, True)
    assert var_0 == ['ansible']

# Generated at 2022-06-25 13:28:13.712992
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)

if __name__ == "__main__":
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:28:20.232918
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert not listify_lookup_plugin_terms('10', '10', ()), 'Empty assert listify_lookup_plugin_terms'
    assert '', 'Empty assert listify_lookup_plugin_terms'
    assert not listify_lookup_plugin_terms('10', '10', ()), 'Empty assert listify_lookup_plugin_terms'
    assert '', 'Empty assert listify_lookup_plugin_terms'
    assert not listify_lookup_plugin_terms('10', '10', ()), 'Empty assert listify_lookup_plugin_terms'
    assert '', 'Empty assert listify_lookup_plugin_terms'



# Generated at 2022-06-25 13:28:27.184709
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # 1
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)

    # 2
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)

    # 3
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)

    # 4

# Generated at 2022-06-25 13:28:33.298306
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert ('An error occurred while parsing the task '
            "'listify_lookup_plugin_terms': section is not a string", (
            '{"_ansible_no_log": false, "_ansible_verbose_always": true, '
            '"ansible_loop_var": "item", "item": {"_ansible_parsed": true}}',
            '{"_ansible_no_log": false, "changed": false, '
            '"invocation": {"module_args": {"a": "b"}}, "item": {}, '
            '"warnings": []}'), var_0)



# Generated at 2022-06-25 13:28:38.092221
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Setup
    terms = '/path/and/filename'
    templar = '/path/and/filename'
    loader = ()
    fail_on_undefined = True
    convert_bare = False

    # Exercise
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)

    # Verify
    assert result is not None
    expected = ['/path/and/filename']
    assert result == expected

    return

# Generated at 2022-06-25 13:28:39.685287
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True is test_case_0()

# vim: ff=unix:ts=4:sw=4:tw=78:noai:expandtab

# Generated at 2022-06-25 13:28:44.506923
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # See https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/common/test/unit/test_collections_compat.py for examples
    str1 = 'localhost'
    str2 = 'localhost'
    tuple1 = ()
    tuple2 = ()
    var1 = listify_lookup_plugin_terms(str1, str1, tuple1)
    var2 = ['localhost']
    assert var1 == var2

# Generated at 2022-06-25 13:28:54.024166
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert(listify_lookup_plugin_terms(terms='-r +{delay_sec}s "{message}"', templar='-r +{delay_sec}s "{message}"', loader=()) == ['+0s "{{message}}"'])
    assert(listify_lookup_plugin_terms(terms='-r +{delay_sec}s "{message}"', templar='-r +{delay_sec}s "{message}"', loader=(), fail_on_undefined=False) == ['+0s "{{message}}"'])
    assert(listify_lookup_plugin_terms(terms='-r +{delay_sec}s "{message}"', templar='-r +{delay_sec}s "{message}"', loader=(), fail_on_undefined=True) == ['+0s "{{message}}"'])
   

# Generated at 2022-06-25 13:28:55.658378
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms), "listify_lookup_plugin_terms is not callable"

# Generated at 2022-06-25 13:29:01.371529
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)
    str_1 = '-r +{delay_sec}s "{message}"'
    tuple_1 = ()
    var_1 = listify_lookup_plugin_terms(str_1, str_1, tuple_1)


if __name__ == '__main__':
    # Unit test for function listify_lookup_plugin_terms
    print(test_case_0())

# Generated at 2022-06-25 13:30:11.834053
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    listify_lookup_plugin_terms("static string", "static string", ())
    listify_lookup_plugin_terms("static string", "static string", ())

# Generated at 2022-06-25 13:30:17.167720
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    list_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)
    assert list_0[0] == '-r +{delay_sec}s "{message}"'
    str_1 = '{{ item }}'
    tuple_1 = ()
    str_2 = '"{{ item }}"'
    #assert listify_lookup_plugin_terms(str_1, str_2, tuple_1) == '"{{ item }}"'


# Generated at 2022-06-25 13:30:20.105324
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Make sure that it returns a list of strings
    assert len(test_case_0()) == 2

    # Make sure it has the correct values
    assert test_case_0()[0] == '-r +{delay_sec}s "{message}"'
    assert test_case_0()[1] == '-r +{delay_sec}s "{message}"'

# Generated at 2022-06-25 13:30:22.529139
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_1 = '-r +{delay_sec}s "{message}"'
    var_2 = ()
    res_0 = listify_lookup_plugin_terms(var_1, var_1, var_2)
    assert res_0 == ('-r +{delay_sec}s "{message}"',)

# Generated at 2022-06-25 13:30:30.640703
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    list_0 = []
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)
    assert var_0 == list_0
    str_1 = '-r +{delay_sec}s "{message}"'
    tuple_1 = ()
    list_1 = []
    var_1 = listify_lookup_plugin_terms(str_1, str_1, tuple_1)
    assert var_1 == list_1
    str_2 = '-r +{delay_sec}s "{message}"'
    tuple_2 = ()
    list_2 = []

# Generated at 2022-06-25 13:30:34.177594
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)
    assert var_0 == ['--reboot +{delay_sec}s "{message}"']


# Generated at 2022-06-25 13:30:35.128831
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:30:40.743857
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    mock_gather_subset = patch('ansible.module_utils.common.json_dict').start()

    mock_gather_subset.gather_subset.return_value = {'_ansible_no_log': False, u'_ansible_verbose_always': True, u'_ansible_version': u'2.7.2', u'delay_sec': 5, u'msg': u'{}'}
    mock_gather_subset.gather_subset.return_value = {'_ansible_no_log': False, u'_ansible_verbose_always': True, u'_ansible_version': u'2.7.2', u'delay_sec': 5, u'msg': u'{}'}
    mock_gather_subset.gather_

# Generated at 2022-06-25 13:30:41.237882
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-25 13:30:50.954175
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test for string input
    string_arg = "test_string"
    assert listify_lookup_plugin_terms(string_arg, string_arg, "test_string") == ["test_string"] 
    
    # Test for int input
    int_arg = 1
    assert listify_lookup_plugin_terms(int_arg, int_arg, int_arg) == [1]
    
    # Test for tuple input
    tuple_arg = (1, 2, 3)
    assert listify_lookup_plugin_terms(tuple_arg, tuple_arg, tuple_arg) == [(1, 2, 3)]
    
    # Test for list input
    list_arg = [1, 2, 3]

# Generated at 2022-06-25 13:33:21.620923
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)

# testing for correct output in case 0

# Generated at 2022-06-25 13:33:27.690374
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Create test case 1
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    res = listify_lookup_plugin_terms(str_0, str_0, tuple_0)

    # Create test case 2
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    res = listify_lookup_plugin_terms(str_0, str_0, tuple_0)

    # Create test case 3
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    res = listify_lookup_plugin_terms(str_0, str_0, tuple_0)

    # Create test case 4

# Generated at 2022-06-25 13:33:31.151683
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Print statement is needed to cause output on Travis-CI, else the test
    # passes with no output
    print("TEST: %s" % test_case_0)
    test_case_0()


if __name__ == '__main__':
    # Test by running: python -m ansible.module_utils.listify_lookup_plugin_terms
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:33:33.982407
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    ##############################################################################
    # str_0 = '-r +{delay_sec}s "{message}"'
    # tuple_0 = ()
    # var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)
    # result = var_0
    # assert '{"message"}' == result
    pass



# Generated at 2022-06-25 13:33:35.376537
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)



# Generated at 2022-06-25 13:33:36.609668
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert(listify_lookup_plugin_terms(str_0, str_0, tuple_0))

# end of test_listify_lookup_plugin_terms

# Generated at 2022-06-25 13:33:41.094785
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    args = [
        '-r +{delay_sec}s "{message}"',
        '-r +{delay_sec}s "{message}"',
        (),
    ]
    exp_args_0 = [
        '-r +{delay_sec}s "{message}"',
        '-r +0s "{message}"',
    ]
    exp_args_1 = [
        '-r +0s "{message}"',
        '-r +0s "{message}"',
    ]
    with pytest.raises(Exception):
        result_args_0 = listify_lookup_plugin_terms(*args)
        if result_args_0 != exp_args_0:
            raise AssertionError('Assertion failed.')
    with pytest.raises(Exception):
        result_args_1 = listify

# Generated at 2022-06-25 13:33:48.459093
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test with string as argument #1
    str_0 = '-r +{delay_sec}s "{message}"'
    tuple_0 = ()
    var_0 = listify_lookup_plugin_terms(str_0, str_0, tuple_0)
    assert '-r +{delay_sec}s "{message}"' == var_0
    str_1 = '/{z}/'
    tuple_1 = ()
    var_1 = listify_lookup_plugin_terms(str_1, str_1, tuple_1)
    assert '/{z}/' == var_1
    # Test with iterable as argument #1
    list_0 = [1, 2, 3, 4]
    tuple_2 = ()

# Generated at 2022-06-25 13:33:55.219815
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    ## test_0
    test_case_0()

    ####################################
    # test_1
    str_1 = '-r +{delay_sec}s "{message}"'
    str_2 = '-r +{delay_sec}s "{message}"'
    tuple_1 = ()
    tuple_2 = ()
    var_1 = listify_lookup_plugin_terms(str_1, str_2, tuple_1)
    test_1 = (var_1, tuple_2)
    assert test_1[0] == test_1[1]
    ####################################
    ## test_2
    str_3 = '-r +{{delay_sec}}s "{{message}}"'
    tuple_3 = ()

# Generated at 2022-06-25 13:33:59.766214
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # First test
    assert test_case_0() == ""
    # Second test
    assert test_case_0() == ""
    # Third test
    assert test_case_0() == ""
    # Fourth test
    assert test_case_0() == ""
    # Fifth test
    assert test_case_0() == ""


if __name__ == "__main__":
    print(test_listify_lookup_plugin_terms())