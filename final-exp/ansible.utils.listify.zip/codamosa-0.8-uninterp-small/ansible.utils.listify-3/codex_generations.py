

# Generated at 2022-06-25 13:24:00.477284
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert True == True

if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:09.810041
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(b'\xfa\x94\x1d\xc9\x0e\x8c\x08\xe1\x1b\xf0\xb2\x93\x9e\x9a\x8b\x81') == [b'\xfa\x94\x1d\xc9\x0e\x8c\x08\xe1\x1b\xf0\xb2\x93\x9e\x9a\x8b\x81']

# Generated at 2022-06-25 13:24:10.861333
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None

# Generated at 2022-06-25 13:24:13.288982
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'\x00'
    float_0 = float_()
    str_0 = '1' # array

    assert var_0 == str_0

# Generated at 2022-06-25 13:24:19.730536
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('\nTesting string: "\\w\xfcF&\x882\xf8\x01\xe9?\xa1xz".\n')
    test_case_0()
    print('\nFinished testing string: "\\w\xfcF&\x882\xf8\x01\xe9?\xa1xz".\n')

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:28.795458
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('test_listify_lookup_plugin_terms:', end='')
    assert listify_lookup_plugin_terms('test', 'test', 'test') == ['test']
    assert listify_lookup_plugin_terms('test', 'test', 'test', convert_bare=True) == ['test']
    assert listify_lookup_plugin_terms(['test'], 'test', 'test') == ['test']
    assert listify_lookup_plugin_terms([['test']], 'test', 'test') == [['test']]
    assert listify_lookup_plugin_terms([[['test']]], 'test', 'test') == [[['test']]]
    assert listify_lookup_plugin_terms(['test'], 'test', 'test', convert_bare=True) == ['test']
   

# Generated at 2022-06-25 13:24:30.968736
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    templar = bytes
    loader = None
    fail_on_undefined = True
    convert_bare = True
    terms = '654'

    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare) == ['654']

# Generated at 2022-06-25 13:24:39.437744
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:24:41.833936
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 0 == test_case_0(), 'test_case_0() fail'

test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:47.673426
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # bytes0 = b'\\w\xfcF&\x882\xf8\x01\xe9?\xa1xz'
    bytes1 = b'jM\x0c\xad\'\xb3\xee\x9f\x8e_5\xd2\x1e'
    # assert listify_lookup_plugin_terms(bytes1, bytes1, bytes1) == bytes1
    # assert listify_lookup_plugin_terms(bytes1, bytes1, bytes1) == bytes1

# Generated at 2022-06-25 13:24:52.779130
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # bytes_0 = b'\\w\xfcF&\x882\xf8\x01\xe9?\xa1xz'
    # float_0 = None
    # var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0)
    assert True

# -----------------


# Generated at 2022-06-25 13:24:59.074330
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # bytes_0 = b'\\w\xfcF&\x882\xf8\x01\xe9?\xa1xz'
    # float_0 = None
    # var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0)
    # assert var_0 == [
    #   '\\w\xfcF&\x882\xf8\x01\xe9?\xa1xz'
    # ]
    assert 1 == 1

# Generated at 2022-06-25 13:25:03.786731
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(None, None, None) == [None]
    assert listify_lookup_plugin_terms("a", None, None) == ["a"]
    assert listify_lookup_plugin_terms(["a", "b", "c"], None, None) == ["a", "b", "c"]

# Generated at 2022-06-25 13:25:13.854725
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True


# from a.ansible.plugins.lookup import listify_lookup_plugin_terms
# from ansible.module_utils import six
# from ansible.module_utils.common._collections_compat import Iterable
# from ansible.module_utils._text import to_bytes
# from ansible.template import Templar
#
# plain_text_0 = b'\x80\xb7\x14\x00\x1d\x00\x00\x00\xfc\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00

# Generated at 2022-06-25 13:25:19.706706
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_1 = None
    int_0 = listify_lookup_plugin_terms(int_1, int_1, int_1, int_1)
    int_2 = bytes_0 = b'\\w\xfcF&\x882\xf8\x01\xe9?\xa1xz'
    float_0 = int_3 = None
    int_4 = listify_lookup_plugin_terms(int_2, float_0, int_3)
    assert int_0 is int_4


test_case_0()

# Generated at 2022-06-25 13:25:21.866953
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == ()

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:30.671323
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Remove the next line to run this test
    return

    if not os.path.exists('/opt/pynsible/cache/tests/ansible/'):
        os.makedirs('/opt/pynsible/cache/tests/ansible/')


    # Generate the test data

    # function-name-under-test
    # TEST: listify_lookup_plugin_terms

    # test case 0
    testdata_in = """\\w\xfcF&\x882\xf8\x01\xe9?\xa1xz"""
    expected_out = b'\\w\xfcF&\x882\xf8\x01\xe9?\xa1xz'
    expected_err = None  # None or empty string for no error


# Generated at 2022-06-25 13:25:32.208936
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('started testing listify_lookup_plugin_terms')
    assert test_case_0() == None
    print('done testing listify_lookup_plugin_terms')

# Generated at 2022-06-25 13:25:36.393621
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'03&%o\x9c\x06\xc3\xac;\x01\x96\x0f\xcb'
    set_0 = {bytes_0}
    float_0 = None
    #assert listify_lookup_plugin_terms(bytes_0, set_0, float_0) == float_0


# Generated at 2022-06-25 13:25:45.981685
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleSequence

    templar = Templar(vault_secrets=dict(vault_password='asdf'), loader=None)
    t_list = AnsibleSequence(
        ['localhost', 'alpha', 'beta', 'gamma', 'delta'],
        hostvars=dict(
            alpha='red',
            beta='blue',
            gamma='yellow',
            delta='green'
        )
    )

    result = listify_lookup_plugin_terms(t_list, templar, None)
    assert result == ['localhost', 'alpha', 'beta', 'gamma', 'delta']

# Generated at 2022-06-25 13:25:56.637079
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(b'\xe4\x96\x8b\xe4\xbd\x9c', b'', 1.0) == [b'\xe4\x96\x8b\xe4\xbd\x9c']
    assert listify_lookup_plugin_terms(None, b'', b'\xe4\x96\x8b\xe4\xbd\x9c') == [None]
    assert listify_lookup_plugin_terms(b'\xe4\x96\x8b\xe4\xbd\x9c', b'', b'\xe4\x96\x8b\xe4\xbd\x9c') == [None]

# Generated at 2022-06-25 13:26:00.923799
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Make sure we are testing the right thing
    assert listify_lookup_plugin_terms is not None

    # Test #0 - normalized test
    try:
        test_case_0()
    except NameError:
        assert False

    # Test #1 - normalized test
    try:
        assert False
    except NameError:
        assert True

# Generated at 2022-06-25 13:26:02.619475
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert False, "Test not implemented"


# Generated at 2022-06-25 13:26:03.554056
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True == True


if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:11.996533
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    string_0 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bool_0 = bool()
    bool_1 = bool(0)
    int_0 = int()
    int_1 = int(0)

# Generated at 2022-06-25 13:26:21.033291
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils import listify_lookup_plugin_terms
    from ansible.template import Templar

    templar = Templar(None, loader=None)
    # Templated: a, b, c => [a, b, c]
    res = listify_lookup_plugin_terms('{{ [a, b, c] }}', templar, None)
    assert res == [u'a', u'b', u'c']
    res = listify_lookup_plugin_terms('a, b, c', templar, None)
    assert res == [u'a', u'b', u'c']
    # Templated: ['a', 'b', 'c'] => [a, b, c]

# Generated at 2022-06-25 13:26:21.967693
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == bytes_0


# Generated at 2022-06-25 13:26:29.291931
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:26:36.356929
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'\x87\xec\x07\x03}\x1e\x9e\x11\x0e\x8d\xfb\x1c\x95\x1f\x7f\xdf\x80\x1c'
    float_0 = None
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0)

    # listify_lookup_plugin_terms has no return value


# Generated at 2022-06-25 13:26:45.314310
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'\xf1\x07\x82\x0e\x82\x10\x81\xcf\xcb\x08\xc6\x1b\x8d\x94\xb3\x9e\xdf\x1e\x89\x08\\Le\x99\x06\xbb\xe3\x9a\x92\x8b\xbd\xfd\x99\xd6\xb8'
    float_0 = None
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0)
    # assert var_0 == var_0

# Generated at 2022-06-25 13:26:54.684449
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Verify we return a list in all cases, even when passed a raw string
    """
    assert listify_lookup_plugin_terms("foo") == ["foo"]
    assert listify_lookup_plugin_terms(["foo"]) == ["foo"]

# Generated at 2022-06-25 13:27:03.265777
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'\x1b\xcf\xdd\x06\x13\x8b\xf7Gm\x1e\x1cU6\xc9\xd9\xaa\x16\x8cS\x93\x98\x01\x0e\x99\xed\x0e\x90\xaa\x8b\xda\xa1\x1el\xc2\x9b\xb6'
    float_0 = 54614103987.871795
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0)
    # assert that var_0 is equal to 576788395010, or else fail the test case
    assert var_0 == 576788395010


# Generated at 2022-06-25 13:27:12.538662
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:27:17.932591
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(b'\\w\xfcF&\x882\xf8\x01\xe9?\xa1xz', b'\\w\xfcF&\x882\xf8\x01\xe9?\xa1xz', None) == b'\\w\xfcF&\x882\xf8\x01\xe9?\xa1xz'

# Generated at 2022-06-25 13:27:26.556668
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test with valid inputs
    # Test 001 conditions
    bytes_0 = b'\x1f'
    float_0 = 1.0
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0)

    assert var_0 == 0.0

    # Test 002 conditions
    bytes_0 = b'\x15\xc8\x1c2\x96\x9e'
    float_0 = 0.0
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0)

    assert var_0 == 0.0

    # Test 003 conditions
    bytes_0 = b'\xf5\x9c\x12\xe5\x02\x83'
    float_0 = 6.0


# Generated at 2022-06-25 13:27:33.496179
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'\x01\xc0\xaf\xb8\x04\x9b\xce\x86\xa8\x16\xfeK\x1d\x89\xb8\x0f\xab\xee'
    int_0 = 85
    str_0 = 'hello'
    assert listify_lookup_plugin_terms(int_0, str_0, int_0) == 85
    assert listify_lookup_plugin_terms(int_0, True, int_0) == 85

# Generated at 2022-06-25 13:27:41.383536
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert isinstance(listify_lookup_plugin_terms(b'\x82\x01\xc0\xd5', b'\x0b\xfc\x9f.E', True), list)
    assert isinstance(listify_lookup_plugin_terms(b'\xed\x9d\x01\xc3o\x99\xde\x1a\xa7\x8a\xd6', b'\xb9\x7f\x82\x01\xc0\xd5', True), list)

# Generated at 2022-06-25 13:27:49.778514
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Testing for failure cases (exceptions)
    bytes_0 = b'U\x08\xd9\x18\xdd\x83.\x0f\xad\xfb\xb1\x8f\x9c\x05'
    float_0 = float('1.0')
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0)
    assert var_0 == bytes_0

    # Testing for failure cases (exceptions)
    bytes_1 = b'\x0f\xb2\xaf\x84&\xaf\x14S\xc0\xef\xd4\xa6\xa4\xf4'
    int_0 = int('0')

# Generated at 2022-06-25 13:27:58.914051
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Try lists, tuples, and strings as input
    assert listify_lookup_plugin_terms([1, 2, 3, 4], None, None) == [1, 2, 3, 4]
    assert listify_lookup_plugin_terms((1, 2, 3, 4), None, None) == [1, 2, 3, 4]
    assert listify_lookup_plugin_terms('1 2 3 4', None, None) == ['1', '2', '3', '4']

    # Try both tuple and list together
    assert listify_lookup_plugin_terms(('1', '2', '3', '4'), None, None) == ['1', '2', '3', '4']

# Generated at 2022-06-25 13:27:59.996452
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_listify_lookup_plugin_terms()


# Generated at 2022-06-25 13:28:21.022488
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert listify_lookup_plugin_terms('./test_data', '', '') == ['./test_data']
    assert listify_lookup_plugin_terms('./test_data', '', '', False) == ['./test_data']
    assert listify_lookup_plugin_terms('./test_data', '', '', True, True) == ['./test_data']

    assert listify_lookup_plugin_terms([], '', '') == []
    assert listify_lookup_plugin_terms('', '', '') == []

# Generated at 2022-06-25 13:28:27.126165
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'\x1c\x05\xa0e\x13\x11\x1f\x16"\x8d\x97\x03\x0e3\x8a4\x1f\x9c9\x10\xb8'
    float_0 = None
    assert listify_lookup_plugin_terms(bytes_0, bytes_0, float_0) == [b'\x1c\x05\xa0e\x13\x11\x1f\x16"\x8d\x97\x03\x0e3\x8a4\x1f\x9c9\x10\xb8']


# Generated at 2022-06-25 13:28:28.740951
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:28:36.898713
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(1, 1, 1) == [1]
    assert listify_lookup_plugin_terms(1, 1, 1) != [2]
    assert listify_lookup_plugin_terms(1, 1, 1) != [1, 2]
    assert listify_lookup_plugin_terms([1], 1, 1) == [1]
    assert listify_lookup_plugin_terms([1], 1, 1) != [2]
    assert listify_lookup_plugin_terms([1], 1, 1) != [1, 2]
    assert listify_lookup_plugin_terms('1', 1, 1) == [1]
    assert listify_lookup_plugin_terms('1', 1, 1) != [2]
    assert listify_lookup_plugin_terms

# Generated at 2022-06-25 13:28:37.643202
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True, "Please write a test case for this function"

# Generated at 2022-06-25 13:28:43.639991
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Try with a string
    terms = "abc"
    terms = listify_lookup_plugin_terms(terms, terms, terms)
    assert terms == ['abc']

    # Try with a list
    terms = ["abc", "def"]
    terms = listify_lookup_plugin_terms(terms, terms, terms)
    assert terms == ['abc', 'def']

    # Try with an int
    terms = 123
    terms = listify_lookup_plugin_terms(terms, terms, terms)
    assert terms == [123]

    # Try with an empty list
    terms = []
    terms = listify_lookup_plugin_terms(terms, terms, terms)
    assert terms == []

    # Try with an empty dictionary
    terms = {}

# Generated at 2022-06-25 13:28:53.062105
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = "foo.txt"
    templar = ""
    loader = ""
    fail_on_undefined = True
    convert_bare = False
    expected_result = ""
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    assert result == expected_result
    terms = ""
    templar = ""
    loader = ""
    fail_on_undefined = False
    convert_bare = False
    expected_result = ""
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    assert result == expected_result
    terms = ""
    templar = ""
    loader = ""
    fail_on_undefined = False
    convert_bare

# Generated at 2022-06-25 13:28:54.896057
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert '\xf8\x01\xe9?\xa1xz' == test_case_0()

# Generated at 2022-06-25 13:29:02.282617
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:29:03.293145
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """ listify_lookup_plugin_terms() implementation tests """
    # Unit test for function listify_lookup_plugin_terms

    test_case_0()

# Generated at 2022-06-25 13:29:39.781423
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(bytes_0, bytes_0, float_0) == var_0

# Test for checking undefined variables in the listify_lookup_plugin_terms

# Generated at 2022-06-25 13:29:44.175852
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 'ansible_facts' == listify_lookup_plugin_terms('ansible_facts', 'ansible_facts', 1.0)

    assert 'ansible_facts' == listify_lookup_plugin_terms('ansible_facts', 'ansible_facts', 'ansible_facts')

    assert 'ansible_facts' == listify_lookup_plugin_terms('ansible_facts', 'ansible_facts', 1)

    assert 'ansible_facts' == listify_lookup_plugin_terms('ansible_facts', 'ansible_facts', b'ansible_facts')

# Generated at 2022-06-25 13:29:45.040135
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True, 'test should pass'

# Generated at 2022-06-25 13:29:51.926107
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Make sure that we are able to pass a TestTemplar object to listify_lookup_plugin_terms
    # This test object emulates the Ansible Templar, but is much simpler to work with
    # in isolated unit tests.

    # Create a TestTemplar object to emulate the Ansible Templar
    class TestTemplar(object):
        def __init__(self, value):
            self.value = value
        def template(self, terms, convert_bare=False, fail_on_undefined=True):
            return self.value

    # Verify that a single string is converted to a list
    tt = TestTemplar('abc')
    assert listify_lookup_plugin_terms('xyz', tt, None) == ['abc']

    # Verify that a list is not touched by listify_lookup_plugin_terms


# Generated at 2022-06-25 13:29:58.013879
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'\x9c\x99\xc1\x0b\xce\x18/\x18\x0e\x9aN\xf9\xad\x16\xca\x84\x1d\x1b\xd5\x90\x16\x9f\xc0\xba\xba\x1f\x88\x15\x92\x1f\xa3\xde\x96m\x1d\xef\xee\x19\xa0\x9a\x1a'

# Generated at 2022-06-25 13:29:58.702420
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)


# Generated at 2022-06-25 13:30:03.782794
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    my_int_0 = listify_lookup_plugin_terms(int_0, str_1, int_1)
    assert my_int_0 == int_2
    str_0 = listify_lookup_plugin_terms(str_1, int_1, int_0)
    assert str_0 == str_2
    str_0 = listify_lookup_plugin_terms(int_2, int_0, float_1)
    assert str_0 == str_2
    str_0 = listify_lookup_plugin_terms(float_1, float_0, int_1)
    assert str_0 == str_2
    str_0 = listify_lookup_plugin_terms(list_0, list_1, str_2)
    assert str_0 == str_2

# Generated at 2022-06-25 13:30:08.720057
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'E\x05\xfd\xf7\xfd\xd2\xf5\x1f?k\x80\x8d\xfe'
    float_0 = None
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0)
    assert var_0 == ['E\x05\xfd\xf7\xfd\xd2\xf5\x1f?k\x80\x8d\xfe'], 'Failed to create variable for unit test'


# Generated at 2022-06-25 13:30:15.776993
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:30:16.802066
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass


# Generated at 2022-06-25 13:31:21.477779
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:31:22.647891
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print(test_case_0())


test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:31:24.910890
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test cases from module checks
    test_case_0()


# Unit tests for module
if __name__ == '__main__':
    # Unit test for function listify_lookup_plugin_terms
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:31:28.927809
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = listify_lookup_plugin_terms(var_0)
    assert var_0 == list_0
    assert var_0[0] == str_0
    list_0 = [var_0]
    assert var_0[1] == list_0
    var_0 = [list_0, var_0]
    assert var_0 == list_0
    var_0 = [var_0, var_0]
    assert var_0 == list_0
    assert var_0[0] == list_0
    assert var_0[1] == list_0

# Generated at 2022-06-25 13:31:31.842418
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test the function's output when inputting a string, a non-iterable non-string, and an iterable non-string
    parameters = ['', None, [],[1,2,3]]
    result_lists = [[], [None], [], [1,2,3]]
    results = []

    for param in parameters:
        results.append(listify_lookup_plugin_terms(param, '', '',))

    assert results == result_lists

# Generated at 2022-06-25 13:31:35.133652
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(None, None, None) == None

    assert listify_lookup_plugin_terms(None, None, None) == None

    assert listify_lookup_plugin_terms(None, None, None) == None

    assert listify_lookup_plugin_terms(None, None, None) == None

    assert listify_lookup_plugin_terms(None, None, None) == None

# Generated at 2022-06-25 13:31:36.532393
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    print("listify_lookup_plugin_terms")
    test_case_0()

test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:31:41.342738
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Set up test values
    bytes_0 = b'\xba\xa2\x83\x8a\xb9\x065\x1c%\xe1\x11\x88\x89*\xf4\x1b=c\xdd'
    float_0 = 9.253255785508373e-07
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0)

    # Perform the tested function
    test_val = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0)

    # Check for state changes
    assert var_0 == test_val

    # Assert the expected results

# Generated at 2022-06-25 13:31:42.326704
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True , 'Test failed'


# Generated at 2022-06-25 13:31:48.298058
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'\x0f\xee\x91\xc5\x8c'
    str_0 = '\x1cu\xea\xa2P!\x83'
    int_0 = -1347389205
    dict_0 = dict()
    dict_0['\x1cu\xea\xa2P!\x83'] = -1029732376
    dict_0['\x0f\xee\x91\xc5\x8c'] = 567303226
    dict_0['_\x9f\xc9\xac\xb6\xd5'] = 252204870
    var_0 = listify_lookup_plugin_terms(dict_0, int_0, str_0)