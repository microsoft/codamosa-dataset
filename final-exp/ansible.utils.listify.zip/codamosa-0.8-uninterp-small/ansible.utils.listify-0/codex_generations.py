

# Generated at 2022-06-25 13:24:07.626599
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # If a method or function is called, parameters are match based on their position
    # This function has 5 parameters
    for x in range(2):
        int_0 = 79
        bytes_0 = b''
        var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
        assert var_0 is True

    # If a method or function is called, parameters are match based on their position
    # This function has 5 parameters
    for x in range(2):
        int_0 = 79
        bytes_0 = b''
        var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
        assert var_0 is True

    # If a method or function is called, parameters are match based on their position
    # This function has 5 parameters
   

# Generated at 2022-06-25 13:24:12.896090
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Check that must be defined
    assert 'must_be_defined' not in globals()
    # Make the call
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    # Check the output
    assert var_0 == [79]


# Generated at 2022-06-25 13:24:22.814940
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # From /usr/lib/ansible/config_template.py:
    assert listify_lookup_plugin_terms( int(79), int(79), b'', bool(True), bool(False) ) == []

    # From /usr/lib/ansible/config_template.py:
    assert listify_lookup_plugin_terms( b'79', int(79), b'', bool(True), bool(False) ) == [ b'79' ]

    # From /usr/lib/ansible/config_template.py:
    assert listify_lookup_plugin_terms( [b'79'], int(79), b'', bool(True), bool(False) ) == [ [b'79'] ]

    # From /usr/lib/ansible/config_template.py:
    assert listify_lookup_plugin

# Generated at 2022-06-25 13:24:25.977990
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    assert type(var_0) == list


# Generated at 2022-06-25 13:24:30.774421
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    arg_0 = 79
    arg_1 = 79
    arg_2 = b''
    arg_3 = True
    arg_4 = True
    func_0 = listify_lookup_plugin_terms(arg_0, arg_1, arg_2, arg_3, arg_4)
    assert func_0 is not None

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:31.895821
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test cases
    test_case_0()



# Generated at 2022-06-25 13:24:33.044703
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert test_case_0() is None


# Generated at 2022-06-25 13:24:42.238537
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This function tests that we handle it when path is a string,
    # and path is a list of strings.

    # First test: path is a string.
    assert listify_lookup_plugin_terms("/etc",
                                "blah",
                                "/dev/null",
                                fail_on_undefined=True,
                                convert_bare=False) == ["/etc"]

    assert listify_lookup_plugin_terms("/etc",
                                "blah",
                                "/dev/null",
                                fail_on_undefined=True,
                                convert_bare=True) == ["/etc"]


# Generated at 2022-06-25 13:24:44.451622
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)

# Generated at 2022-06-25 13:24:53.000029
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.template import Templar

    template = '{{hi}}'
    variables = dict(hi='hi there')
    templar = Templar(loader=None, variables=variables)
    terms = listify_lookup_plugin_terms(template, templar, None)
    assert terms == [to_text('hi there')]
    assert isinstance(terms, list)

    template = '{{hi}} {{there}}'
    variables = dict(hi='hi', there='there')
    templar = Templar(loader=None, variables=variables)
    terms = listify_lookup_plugin_terms(template, templar, None)

# Generated at 2022-06-25 13:24:57.420142
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """Test case for function listify_lookup_plugin_terms"""
    assert True



# Generated at 2022-06-25 13:25:00.497476
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Assign params
    #int_0 = 79
    #bytes_0 = b''
    # Run the test
    try:
        #test_case_0()
        pass
    except:
        print("Unhandled exception in testcase")
        raise

# Generated at 2022-06-25 13:25:10.996837
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = 79
    templar = 79
    loader = b''
    fail_on_undefined = True
    convert_bare = False

    assert isinstance(listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=fail_on_undefined), list)
    assert isinstance(listify_lookup_plugin_terms(terms, templar, loader, convert_bare=convert_bare), list)
    assert isinstance(listify_lookup_plugin_terms(terms, templar, loader), list)
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=fail_on_undefined, convert_bare=convert_bare) == [79]

# Generated at 2022-06-25 13:25:13.063197
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # get the first element of the returned list
    assert test_case_0()[0] == 79
    print('Success!')


# Generated at 2022-06-25 13:25:15.562294
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)

test_case_0()

# Generated at 2022-06-25 13:25:21.581760
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        assert(listify_lookup_plugin_terms(79, 79, b'', fail_on_undefined=True, convert_bare=False))
        test_case_0()
    except AssertionError as e:
        print("Assertion error raised in test_case_0")

# Generated at 2022-06-25 13:25:23.504588
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:26.665055
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping

    int_0 = 79
    bytes_0 = b''
    iterable_0 = [int_0, int_0]
    iterable_1 = [(int_0, int_0, bytes_0)]

    listify_lookup_plugin_terms(int_0, int_0, bytes_0)



# Generated at 2022-06-25 13:25:33.917721
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_2 = 3
    str_0 = 'simple_term'
    tuple_0 = ()
    tuple_1 = (1, 2, 3)
    list_0 = [True, False]
    list_1 = [1, 2, 3, 4, 5]
    list_2 = [list_1, tuple_0, list_0, tuple_1]
    list_3 = ['simple_term', 'simple_term']
    list_4 = ['complex_term', 2, 3, 'foo']
    list_5 = ['complex_term', int_2, str_0, tuple_1]
    list_6 = ['complex_term', int_2, str_0, list_1]
    list_7 = ['complex_term', int_2, tuple_1, list_0]

# Generated at 2022-06-25 13:25:34.686946
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# Generated at 2022-06-25 13:25:42.078854
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = 79
    templar = 79
    loader = b''
    fail_on_undefined = True
    convert_bare = False
    var_0 = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    assert var_0


# Generated at 2022-06-25 13:25:44.389718
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)

# Generated at 2022-06-25 13:25:47.300278
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    assert var_0 is not None


# Generated at 2022-06-25 13:25:54.829260
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: Make sure to provide test cases
    # Test cases
    test_case_0()
    test_case_1()

#     def _listify_lookup_plugin_terms(self, terms, templar, loader, fail_on_undefined=True, convert_bare=False):
#         '''
#         make each term a list if it is not already, and then return a list
#         of lists, each a single element.
#         '''
#
#         if isinstance(terms, string_types):
#             terms = templar.template(terms.strip(), convert_bare=convert_bare, fail_on_undefined=fail_on_undefined)
#         else:
#             terms = templar.template(terms, fail_on_undefined=fail_on_undefined)


# Generated at 2022-06-25 13:25:59.552199
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Setup mock arguments
    terms = str()
    templar = str()
    loader = str()
    fail_on_undefined = str()
    convert_bare = str()

    # Call the function
    actual = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)

    assert isinstance(actual, list)

# Generated at 2022-06-25 13:26:07.663012
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 79
    int_1 = 28
    str_0 = 'V'
    str_1 = 'a'
    str_2 = 'r'
    str_3 = 'i'
    str_4 = 'a'
    str_5 = 'b'
    str_6 = 'l'
    str_7 = 'e'
    str_8 = ' '
    str_9 = 'i'
    str_10 = 's'
    str_11 = ' '
    str_12 = 'n'
    str_13 = 'o'
    str_14 = 't'
    str_15 = ' '
    str_16 = 'd'
    str_17 = 'e'
    str_18 = 'f'
    str_19 = 'i'
    str_20 = 'n'

# Generated at 2022-06-25 13:26:08.636229
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert len(test_case_0()) != 0


# Generated at 2022-06-25 13:26:18.640644
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common._collections_compat import Set
    from ansible.module_utils.common._collections_compat import MappingView
    from ansible.module_utils.common._collections_compat import KeysView
    from ansible.module_utils.common._collections_compat import ItemsView

# Generated at 2022-06-25 13:26:22.865943
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_arg_0 = ''
    bool_arg_0 = True

    # Call function
    results = listify_lookup_plugin_terms(str_arg_0, bool_arg_0)

    # Check for correct result
    assert 'List' == type(results).__name__

    # Check for correct result
    assert [''] == results



# Generated at 2022-06-25 13:26:27.998080
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    #assert var_0 == expected_0, "Expected: %s, Actual: %s" % (expected_0, var_0)



if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:26:42.039496
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(79, 79, b'') == [79]
    assert listify_lookup_plugin_terms(79, 79, b'', False) == [79]
    assert listify_lookup_plugin_terms(79, 79, b'', True) == [79]
    assert listify_lookup_plugin_terms(79, 79, b'', False, False) == [79]
    assert listify_lookup_plugin_terms(79, 79, b'', True, False) == [79]
    assert listify_lookup_plugin_terms(b'79', 79, b'', True) == [b'79']
    assert listify_lookup_plugin_terms(b'79', 79, b'', False) == [b'79']
    assert listify_lookup

# Generated at 2022-06-25 13:26:43.304954
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:26:44.194390
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == 79



# Generated at 2022-06-25 13:26:45.069987
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert not test_case_0()

# Generated at 2022-06-25 13:26:49.916459
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    tests = [
        # Each list item is a set of paramaters for test_listify_lookup_plugin_terms,
        # followed by the expected result.
        [(79, 79, b''), True],
        [(79, 79, b''), True],
        [(79, 79, b''), False],
        [(79, 79, b''), True],
    ]
    for params, expected in tests:
        result = listify_lookup_plugin_terms(*params)
        assert result == expected

# Generated at 2022-06-25 13:26:51.447717
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True == True

# vim: expandtab tabstop=4 shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 13:26:54.859365
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert 1==1 # TODO: implement your test here


# Put your actual test cases here.
# Each one should be an assert statement with the expected, actual
# as arguments.
#
# e.g.
#   assert unicode(expected_result) == actual_result

# Generated at 2022-06-25 13:26:58.569646
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():


    # This will fail because we should receive a list of terms. However, C function fails to properly check argument type.
    #In the future, this should be a TypeError.
    #assert_raises(Exception, listify_lookup_plugin_terms('this', 'that', 'the other thing'))
    pass

# Generated at 2022-06-25 13:27:06.141599
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Save the current environment
    orig_env = dict()
    if os.environ.get('ANSIBLE_LOOKUP_PLUGINS_CONVERT_BARE'):
        orig_env['ANSIBLE_LOOKUP_PLUGINS_CONVERT_BARE'] = os.environ.get('ANSIBLE_LOOKUP_PLUGINS_CONVERT_BARE')
    if os.environ.get('ANSIBLE_LOOKUP_PLUGINS_FAIL_ON_UNDEFINED'):
        orig_env['ANSIBLE_LOOKUP_PLUGINS_FAIL_ON_UNDEFINED'] = os.environ.get('ANSIBLE_LOOKUP_PLUGINS_FAIL_ON_UNDEFINED')

    # Set the arguments used to call the module
    module_args = dict()

   

# Generated at 2022-06-25 13:27:16.485968
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 62
    int_1 = 51
    list_0 = [True, True, True]
    list_1 = [False, True, False]
    list_2 = []
    bytes_0 = b'\x00\x07.'
    id_0 = id
    len_0 = len
    bytes_1 = b'\xa1\x11\xeb\xcd(3\xff\x1e'
    int_2 = 30
    int_3 = 74
    str_0 = str
    str_1 = str
    list_3 = [int_0, int_1]
    var_0 = listify_lookup_plugin_terms(list_0, int_0, int_1)
    assert var_0 == list_0

# Generated at 2022-06-25 13:27:32.024805
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test for raising TypeError
    if False:
        raise TypeError('Dummy type error')
    if True:
        int_0 = 79
        bytes_0 = b''
        var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)

        var_0_0 = var_0[0]
        if int_0 == var_0_0:
            raise AssertionError('"%s" not equal to "%s"!' % (int_0, var_0_0))


# BOILERPLATE
################################################################################


# Generated at 2022-06-25 13:27:35.657682
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Iterable
    int_0 = 79
    bytes_0 = b''
    for int_1 in range(0,10):
        var_0 = listify_lookup_plugin_terms(int_0, int_1, bytes_0)
        assert isinstance(var_0, Iterable) == True

# Generated at 2022-06-25 13:27:37.262252
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert func_0() == 1
# ################# END BACKPORTED CODE #####################

# Generated at 2022-06-25 13:27:43.915245
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(21, 62, b'', True, True) == [21]
    assert listify_lookup_plugin_terms(b'\x00\x00\x00\x00', b'\x00\x00\x00\x00', b'\x00\x00\x00\x00', True, False) == [b'\x00\x00\x00\x00']
    assert listify_lookup_plugin_terms(b'\x00\x00\x00\x00', b'\x00\x00\x00\x00', b'', True, True) == [b'\x00\x00\x00\x00']

# Generated at 2022-06-25 13:27:45.611589
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 79
    bytes_0 = b''
    assert var_0 != [79]

# Generated at 2022-06-25 13:27:48.872511
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('In test_listify_lookup_plugin_terms')

    test_case_0()
    test_case_1()


# Unit test runner
if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:54.194238
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = 'this is a test'
    templar = 't'
    loader = 'l'
    fail_on_undefined = 'f'
    convert_bare = 'c'
    var_0 = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    assert var_0 == list('this is a test')


# Generated at 2022-06-25 13:27:58.732103
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Tests for function listify_lookup_plugin_terms
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    int_1 = 79
    bytes_1 = b''
    var_1 = listify_lookup_plugin_terms(int_1, int_1, bytes_0)
    assert var_1 == var_0

# Generated at 2022-06-25 13:28:00.436932
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY3, b
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 13:28:08.258479
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = listify_lookup_plugin_terms(79, 79, b'')
    assert isinstance(var_0, list)
    assert len(var_0) == 1
    assert var_0[0] == 79
    assert var_0[0].__class__ == int
    var_1 = listify_lookup_plugin_terms(79, 79, b'')
    assert isinstance(var_1, list)
    assert len(var_1) == 1
    assert var_1[0] == 79
    assert var_1[0].__class__ == int
    var_2 = listify_lookup_plugin_terms(79, 79, b'')
    assert isinstance(var_2, list)
    assert len(var_2) == 1
    assert var_2[0] == 79


# Generated at 2022-06-25 13:28:39.410505
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms([], '', '', True, False) == []
    assert listify_lookup_plugin_terms('', '', '', True, False) == []
    assert listify_lookup_plugin_terms({}, '', '', True, False) == []
    assert listify_lookup_plugin_terms('   ', '', '', True, False) == []
    assert listify_lookup_plugin_terms([1,2,3], '', '', True, False) == [1,2,3]
    assert listify_lookup_plugin_terms(1, '', '', True, False) == [1]
    assert listify_lookup_plugin_terms('1', '', '', True, False) == [1]

# Generated at 2022-06-25 13:28:41.752089
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    assert(var_0 == [79])

# Generated at 2022-06-25 13:28:44.713964
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    assert len(var_0) == 1
    assert var_0[0] == 79


# Generated at 2022-06-25 13:28:49.709385
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = int(79)
    var_1 = b''
    var_2 = listify_lookup_plugin_terms(var_0, var_0, var_1)
    assert var_2 == 79

    assert var_0 == 79
    assert var_1 == ''

# Run pytest without the '-s' option to ensure nothing is printed to stdout

# Generated at 2022-06-25 13:28:58.228006
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test with int arg
    int_0 = 79
    int_1 = 79
    bytes_0 = b''
    
    # Test with str arg
    str_0 = 'This is a string'
    str_1 = 'This is a string'
    assert len(str_0) == 18
    bytes_1 = b'This is a string'
    
    # Test with Iterable arg
    list_0 = [79]
    int_2 = 79
    bytes_2 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_1, bytes_0)
    var_1 = listify_lookup_plugin_terms(str_0, str_1, bytes_1)

# Generated at 2022-06-25 13:29:02.974874
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = ['foo', 'bar', 'bam']
    templar = type('templar', (object,), {'template': lambda x: x})()
    loader = type('loader', (object,), {'get_basedir': lambda x: '/tmp'})()
    # A success
    assert listify_lookup_plugin_terms(terms, templar, loader) == terms
    # A success
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    # A success
    assert listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True) == terms
    # A success
    assert listify_lookup_plugin_terms('foo', templar, loader, convert_bare=True) == ['foo']

# Generated at 2022-06-25 13:29:07.854801
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.network.common.utils import to_text
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Run tests on Python 2.6, 2.7, and 3.x
    if PY3:
        unicode_type = str
    else:
        unicode_type = unicode

    # Get a template class with the needed parameters
    loader = DataLoader()
    play_context = PlayContext()

# Generated at 2022-06-25 13:29:10.269167
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except Exception as e:
        print("Exception in test case: " + str(e))


test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:29:11.815839
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except Exception as e:
        print('Exception')
    
    
    
# MAIN

# Generated at 2022-06-25 13:29:18.487031
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    #Initialize variables
    # initialize a compare list for the function
    ans_list = ['a', 'b', 'c']
    other_list = ['a', 'b', 'd']

    # test the case that it is an iterable
    if ans_list == listify_lookup_plugin_terms(ans_list, ans_list, ans_list):
        pass
    # test the case that it is not an iterable
    elif other_list == listify_lookup_plugin_terms('ab', 'ab', 'ab'):
        pass
    else:
        raise ValueError("listify_lookup_plugin_terms did not work")


# Generated at 2022-06-25 13:30:22.421604
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():


    # first test case with param int_0 = 79 and param bytes_0 = b''
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)

    if not isinstance(var_0, list):
        assert False

    # second test case with param str_0 = 'p*' and param bool_0 = True
    str_0 = 'p*'
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(str_0, str_0, bool_0)

    if not isinstance(var_0, list):
        assert False

    # third test case with param bytes_0 = b'e\x1e\xc2\xb9\x9dg\x1

# Generated at 2022-06-25 13:30:25.852729
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        int_0 = 79
        bytes_0 = b''
        var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    except Exception as e:
        assert False, "unexpected failure: {}".format(e)

    assert type(var_0) == list



# Generated at 2022-06-25 13:30:28.399837
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_1 = listify_lookup_plugin_terms(int_1, list_1, int_1)
    if var_1 != [dict_2]:
        raise Exception('Assertion failed')


# Generated at 2022-06-25 13:30:31.244846
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var = {'endswith': 'e', 'items': 'foobar', 'startswith': 'f'}
    var = listify_lookup_plugin_terms(var, int_0, bytes_0)
    assert 'foobar' == var

# Generated at 2022-06-25 13:30:33.422261
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    args_0 = []
    var_0 = listify_lookup_plugin_terms(args_0, args_0, args_0)
    assert var_0 == []

# Generated at 2022-06-25 13:30:39.928320
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Make little helpers

    class templar:
        def template(self, a, **kwargs):
            return a

    class loader:
        pass

    # set up some inputs
    terms = list("abcdef")
    templar = templar()
    loader = loader()
    fail_on_undefined = True
    convert_bare = False

    # run the code to test
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)

    # make assertions
    assert result == ["a", "b", "c", "d", "e", "f"]

    # set up some inputs
    terms = list("abcdef")
    templar = templar()
    loader = loader()
    fail_on_undefined = True
   

# Generated at 2022-06-25 13:30:46.799576
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Initializing class variables
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    try:
        assert var_0 == b'79'
        print("Test for function listify_lookup_plugin_terms function passed.")
    except AssertionError as e:
        print("Test for function listify_lookup_plugin_terms function failed.")

if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:30:49.915470
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 79
    bytes_0 = b''
    listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    listify_lookup_plugin_terms(bytes_0, int_0, bytes_0)

# Generated at 2022-06-25 13:30:52.086581
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert False


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()
    test_case_0()

# Generated at 2022-06-25 13:30:52.942161
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test case 0
    test_case_0()

# Generated at 2022-06-25 13:32:58.662024
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b''
    assert True == isinstance(listify_lookup_plugin_terms(bytes_0, bytes_0, bytes_0), list)


# Generated at 2022-06-25 13:33:01.147480
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test function parameters
    # int_0 = 79
    # bytes_0 = b''
    # var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    var_0 = test_case_0()
    assert var_0 == 79

# Generated at 2022-06-25 13:33:07.528602
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    
    # Test 1
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    assert var_0 == [79]

    # Test 2
    list_0 = [7, 6, 8, 9]
    list_1 = [7, 6, 8, 9]
    list_2 = [7, 6, 8, 9]
    var_0 = listify_lookup_plugin_terms(list_0, list_1, list_2)
    assert var_0 == [7, 6, 8, 9]

    # Test 3
    list_0 = ['a', 'b', 'c', 'd']
    list_1 = ['a', 'b', 'c', 'd']
    list_2

# Generated at 2022-06-25 13:33:13.302136
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = listify_lookup_plugin_terms(79, 79, b'')
    # The result of the function should be equivalent to the following list
    assert var_0 == [79]
    # The first parameter passed to the function was incorrect
    with pytest.raises(TypeError):
        listify_lookup_plugin_terms(79, 79, b'')(79)
    var_1 = listify_lookup_plugin_terms([79], 79, b'')
    assert var_1 == [79]
    # The first parameter passed to the function was incorrect
    with pytest.raises(TypeError):
        listify_lookup_plugin_terms([79], 79, b'')(79)

# Generated at 2022-06-25 13:33:14.890359
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Try to create a dict with the args.
    # Return values are ignored.
    # There should be no exceptions.
    test_case_0()



# Generated at 2022-06-25 13:33:20.723164
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 79
    bytes_0 = b''
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bytes_0)
    assert len(var_0) == 1
    assert var_0[0] == 79
    assert type(var_0[0]) == int

    str_0 = 'foo'
    str_1 = 'bar'
    bytes_0 = b'foo, bar'
    var_1 = listify_lookup_plugin_terms(str_1, str_0, bytes_0)
    assert len(var_1) == 2
    assert 'foo' in var_1
    assert 'bar' in var_1
    assert type(var_1[0]) == str
    assert type(var_1[1]) == str


# Generated at 2022-06-25 13:33:22.327606
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('UNIT_TEST START for function listify_lookup_plugin_terms')
    test_case_0()
    print('UNIT_TEST END for function listify_lookup_plugin_terms')

# Generated at 2022-06-25 13:33:22.896533
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Case 0:
    test_case_0()

# Generated at 2022-06-25 13:33:27.980223
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms((79,), (79,), b'', convert_bare=False, fail_on_undefined=True) == [b'79']
    assert listify_lookup_plugin_terms((79,), (79,), b'', fail_on_undefined=True) == [b'79']
    assert listify_lookup_plugin_terms((79,), (79,), b'', fail_on_undefined=False) == [b'79']
    assert listify_lookup_plugin_terms(79, 79, b'', convert_bare=False, fail_on_undefined=True) == [b'79']
    assert listify_lookup_plugin_terms(79, 79, b'', fail_on_undefined=True) == [b'79']
    assert list

# Generated at 2022-06-25 13:33:31.197313
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    
    # set up test variables
    mandatory_var = ""
    str_var = "eGlhbmdocGhwIHNvY2tldC4="
    var_list = ["", "eGlhbmdocGhwIHNvY2tldC4="]
    
    
    # run test case
    test_case_0()

