

# Generated at 2022-06-25 13:24:05.764661
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test for a string, since this will pass the error check
    stringTest = "Hello World"
    result = listify_lookup_plugin_terms(stringTest, stringTest, stringTest, stringTest)
    assert type(result) is list, "Error in test_listify_lookup_plugin_terms"
    # Test for a dictionary, since this will fail to pass the error check
    dictionaryTest = {"dictionary" : "test"}
    result = listify_lookup_plugin_terms(dictionaryTest, dictionaryTest, dictionaryTest, dictionaryTest)
    assert type(result) is not dict, "Error in test_listify_lookup_plugin_terms"

# Generated at 2022-06-25 13:24:12.214624
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '1'
    str_1 = '2'
    assert listify_lookup_plugin_terms(str_0, str_0, str_0, str_0, str_0) == ['1']
    assert listify_lookup_plugin_terms(str_0, str_1, str_0, str_0, str_0) == ['2']
    assert listify_lookup_plugin_terms(str_0, str_0, str_1, str_0, str_0) == ['1']
    assert listify_lookup_plugin_terms(str_0, str_0, str_0, str_1, str_0) == ['1']

# Generated at 2022-06-25 13:24:22.170459
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = 'i'
    str_1 = 'n'
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int_6 = 6
    int_7 = 7
    int_8 = 8
    int_9 = 9
    int_10 = 10
    int_11 = 11
    temp_tuple_0 = (int_0, int_1, int_2)
    temp_tuple_1 = (int_0, int_1, int_2, int_3, int_4, int_5)
    temp_tuple_2 = (int_0, int_1)

# Generated at 2022-06-25 13:24:25.401685
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test cases for function listify_lookup_plugin_terms
    test_case_0()


# Invoke test_listify_lookup_plugin_terms to invoke test cases
test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:33.472018
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)

    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0, str_0, str_0)
    assert var_0 is var_0

    var_1 = listify_lookup_plugin_terms(var_0, str_0, str_0, str_0, str_0)
    assert var_0 == var_1

    var_2 = listify_lookup_plugin_terms(var_1, str_0, str_0, str_0, str_0)
    assert var_1 == var_2

    var_3 = listify_lookup_plugin_terms(var_2, str_0, str_0, str_0, str_0)
    assert var_2 == var_3

# Generated at 2022-06-25 13:24:42.731168
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = 'v'
    str_1 = 't[e?us__d-s=J'
    str_2 = 'N'
    str_3 = ';'
    str_4 = 'y'
    str_5 = 'l'
    str_6 = 'T'
    str_7 = 'Y'
    str_8 = 'h'
    str_9 = 'H'
    str_10 = 'C'
    str_11 = '-'
    str_12 = 'Q'
    str_13 = 'u'
    str_14 = 'V'
    str_15 = 'o'
    str_16 = 'd'
    str_17 = '.'
    str_18 = 'j'
    str_19 = '4'
    str_20 = '0'
    str

# Generated at 2022-06-25 13:24:51.503482
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = 'p_s_s'
    var_1 = 's_s'
    var_2 = 'd_s'
    var_3 = 's_s'
    var_4 = 'p_s_s'


# Generated at 2022-06-25 13:25:01.030799
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = 'J'
    var_1 = 's'
    var_2 = 'd'
    var_3 = 's'
    var_4 = 'T'
    var_5 = 's'
    var_6 = 'J'
    var_7 = 's'
    str_0 = 'J'
    str_1 = 's'
    str_2 = 'd'
    str_3 = 's'
    str_4 = 'T'
    str_5 = 's'
    str_6 = 'J'
    str_7 = 's'
    var_8 = listify_lookup_plugin_terms(var_0, var_1, var_2, var_3, var_4)

# Generated at 2022-06-25 13:25:01.863395
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True == True

# Generated at 2022-06-25 13:25:05.904022
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = 'Z'
    str_1 = 'D'
    str_2 = '*'
    str_3 = 't[e?us__d-s=J'
    bool_0 = False
    bool_1 = True


    # Call function
    # Output:
    test_case_0()

# Generated at 2022-06-25 13:25:11.508749
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # AssertionError: <function listify_lookup_plugin_terms at 0x7f8add7c9320>() takes exactly 5 arguments (6 given)
    # assert_equal(TestCase_0, 'var_0')
    pass

# Generated at 2022-06-25 13:25:13.021649
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:20.263267
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert listify_lookup_plugin_terms('foo,bar', 1, 2, 3, 4) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], 1, 2, 3, 4) == ['foo', 'bar']
    assert listify_lookup_plugin_terms({'a': 1}, 1, 2, 3, 4) == [{'a': 1}]
    assert listify_lookup_plugin_terms(['foo', 'bar'], 1, 2, 3, 4) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], 1, 2, 3, 4) == ['foo', 'bar']

# Generated at 2022-06-25 13:25:21.570170
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# TESTCASE: test_case_0

# Generated at 2022-06-25 13:25:22.468307
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    if test_case_0():
        pass
    else:
        assert False



# Generated at 2022-06-25 13:25:27.701652
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test with str, str, str, str, str
    listify_lookup_plugin_terms('t[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J')

test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:34.512699
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        from ansible.utils.pycompat24 import get_exception
    except ImportError:
        from ansible.utils.pycompat import get_exception

    import __builtin__

    try:
        __builtin__.__dict__['get_exception']
    except KeyError:
        __builtin__.__dict__['get_exception'] = get_exception

    try:
        import ansible.module_utils.basic
    except ImportError:
        pass

    try:
        import ansible.module_utils.common.common
    except ImportError:
        pass

    try:
        import ansible.module_utils.splitter
    except ImportError:
        pass

    try:
        import ansible.module_utils.six
    except ImportError:
        pass


# Generated at 2022-06-25 13:25:35.334416
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:25:40.684456
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Set up test data
    str_0 = 't[e?us__d-s=J'

    # Invoke actual test function
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0, str_0, str_0)

    # Validate test data
    assert var_0 == [str_0]

# Generated at 2022-06-25 13:25:49.672510
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert False


# xtdocs, title: listify_lookup_plugin_terms - make sure terms are a list and run through templating
# xtphase: early
# xtstep: parse=true
# xtremotestep: parse=true
# xtsubtasks: template
# xtsubtasks: parse=true
# xtsubtasks: metadata
# xtsubtasks: validate
# xtsubtasks: templar
# xtsubtasks: convert_bare
# xtsubtasks: fail_on_undefined
# xtsubtasks: ignore_errors
# xtsubtasks: terms
# xtsubtasks: var_0
# xtoutput:
# xtoutput: parse=true
# xtoutput: convert_bare
# xtoutput: fail_

# Generated at 2022-06-25 13:26:02.868450
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test that the docker_image_facts module returns a dictionary
    assert listify_lookup_plugin_terms('t[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J') == ['t[e?us__d-s=J']

    assert listify_lookup_plugin_terms(['t[e?us__d-s=J'], 't[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J') == ['t[e?us__d-s=J']



# Generated at 2022-06-25 13:26:09.553321
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert (listify_lookup_plugin_terms([1, [2,3], 'string'],'','') == [1, [2,3], 'string'])
    assert (listify_lookup_plugin_terms(['{{ foo.bar }}', ['{{ foo.baz }}']],'','') == ['{{ foo.bar }}', ['{{ foo.baz }}']])
    assert (listify_lookup_plugin_terms([1], '', '') == [1])
    assert (listify_lookup_plugin_terms([''], '', '') == [''])
    assert (listify_lookup_plugin_terms(['foo', 'bar', 'baz'], '', '') == ['foo', 'bar', 'baz'])

# Generated at 2022-06-25 13:26:17.691638
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    a_str = 'oh'
    b_str = 't[e?us__d-s=J'
    answer = listify_lookup_plugin_terms(a_str, b_str, a_str, b_str, a_str)
    assert answer[0] == 'oh'
    assert answer[1] == 't[e?us__d-s=J'
    assert answer[2] == 'oh'
    assert answer[3] == 't[e?us__d-s=J'
    assert answer[4] == 'oh'


# Testing function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:26:26.180477
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:26:36.745003
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Mock argument for listify_lookup_plugin_terms
    class MockClass():

        def __init__(self, arg):
            self.arg = arg
            self.is_dir = False
            self.when_was_checked = arg
            self.stat = None

# Generated at 2022-06-25 13:26:38.759771
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == "t[e?us__d-s=J"

# Test for load function

# Generated at 2022-06-25 13:26:47.400163
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:26:51.660742
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert type(test_case_0()) == {0 : type(str_0), 1 : type(str_0), 2 : type(str_0), 3 : type(str_0), 4 : type(str_0)}
    assert test_case_0() == {0 : str_0, 1 : str_0, 2 : str_0, 3 : str_0, 4 : str_0}

# Generated at 2022-06-25 13:26:57.541447
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_cases = [
        {
            "terms": "t[e?us__d-s=J",
            "results": [
                "t[e?us__d-s=J"
            ]
        }
    ]

    for test_case in test_cases:
        terms = test_case.get("terms", None)
        results = test_case.get("results", [])

        assert listify_lookup_plugin_terms(terms, terms, terms, terms, terms) == results

# Generated at 2022-06-25 13:26:58.137813
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    #assert test_case_0() == 'hello world'
    assert 1 == 1

# Generated at 2022-06-25 13:27:06.070057
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert isinstance(listify_lookup_plugin_terms(str_0, str_0, str_0, str_0, str_0), list)

# Generated at 2022-06-25 13:27:06.882049
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:27:17.275486
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    str_0 = 'VU1R6D1x'
    set_0 = set()
    str_1 = 'C0fmaJYWz3AGEc'
    set_1 = set()
    var_0 = set()
    var_1 = set()
    var_2 = set()

    byte_0 = bytes()
    byte_1 = bytes()
    var_0 = bytes()
    var_1 = bytes()
    var_2 = bytes()
    var_3 = bytes()
    var_4 = bytes()

    str_2 = 'GQKn'
    str_3 = 'pC8R'
    str_4 = 'u-EK'
    str_5 = 'I6xA'
    str_6 = 'TW5'
    str_7 = 'C1Y'



# Generated at 2022-06-25 13:27:22.267772
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    if not os.path.exists("test/results/test_listify_lookup_plugin_terms"):
        os.makedirs("test/results/test_listify_lookup_plugin_terms")
    with open("test/results/test_listify_lookup_plugin_terms/input", "w") as f:
        result = test_case_0()
        f.write("%s\n" % result)


# Generated at 2022-06-25 13:27:26.096556
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    in_str = 't[e?us__d-s=J'
    out_str = 't[e?us__d-s=J'
    terms = listify_lookup_plugin_terms(in_str, out_str, out_str, out_str, out_str)
    assert isinstance(terms, list)

# Generated at 2022-06-25 13:27:28.660193
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert listify_lookup_plugin_terms(string_types)
    assert listify_lookup_plugin_terms(templar)
    assert listify_lookup_plugin_terms(loader)
    assert listify_lookup_plugin_terms(fail_on_undefined)
    assert listify_lookup_plugin_terms(convert_bare)

# Generated at 2022-06-25 13:27:29.298348
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:27:36.007820
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Verify the correct return for each arg combination for listify_lookup_plugin_terms()
    """
    func_obj = listify_lookup_plugin_terms
    # Verify that we are in fact a function
    assert callable(func_obj)

    # Verify that by passing in an integer, we get an exception
    with pytest.raises(Exception):
        func_obj(1, 1, 1, 1, 1)

    # Verify that by passing in a string, we get an exception
    with pytest.raises(Exception):
        func_obj('a', 'a', 'a', 'a', 'a')

    # Verify that by passing in a list, we get an exception
    with pytest.raises(Exception):
        func_obj([], [], [], [], [])

    # Verify that by passing in

# Generated at 2022-06-25 13:27:38.269201
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == 't[e?us__d-s=J', 'Test case did not return the expected result'
    return True

# Generated at 2022-06-25 13:27:44.739352
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    correct_results = [
        ['t[e?us__d-s=J'],
        ['t[e?us__d-s=J'],
        ['t[e?us__d-s=J'],
        ['t[e?us__d-s=J'],
        ['t[e?us__d-s=J'],
        ['t[e?us__d-s=J']
    ]

    args = [
        ['t[e?us__d-s=J']
    ]

    for index, term in enumerate(args):
        result = listify_lookup_plugin_terms(term, term, term, term, term)
        assert result == correct_results[index], "Expected {0}, but got: {1}".format(correct_results[index], result)

# Generated at 2022-06-25 13:28:06.198788
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    context = PlayContext()
    template_dir = None
    templar = Templar(loader=None, variables=None, shared_loader_obj=None)

    assert listify_lookup_plugin_terms('bar', templar, template_dir) == ['bar']
    assert listify_lookup_plugin_terms('foo,bar', templar, template_dir) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, template_dir) == ['foo', 'bar']
    assert listify_lookup_plugin_terms([], templar, template_dir) == []

# Generated at 2022-06-25 13:28:13.779743
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:28:19.432202
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = 't[e?us__d-s=J'
    var_1 = var_0
    var_2 = var_0
    var_3 = var_0
    var_4 = var_0
    var_5 = listify_lookup_plugin_terms(var_0, var_1, var_2, var_3, var_4)
    assert var_5 == ['t[e?us__d-s=J'], 'var_5: ' + var_5 + ' should be t[e?us__d-s=J'


# Generated at 2022-06-25 13:28:21.349806
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # get the result from the function
    result = listify_lookup_plugin_terms()
    # assert on the result
    assert(result == 'Hello World')

# Generated at 2022-06-25 13:28:24.933557
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert (test_case_0() == ('t[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J', ['t[e?us__d-s=J'])
        ), 'listify_lookup_plugin_terms failed'



# Generated at 2022-06-25 13:28:30.952769
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(1, 1, 1, 1, 1) == [1]
    assert listify_lookup_plugin_terms([1], 1, 1, 1, 1) == [1]
    assert listify_lookup_plugin_terms('1', 1, 1, 1, 1) == ['1']
    assert listify_lookup_plugin_terms(['1', '2'], 1, 1, 1, 1) == ['1', '2']
    assert listify_lookup_plugin_terms(['{{ foo }}', '2'], 1, 1, 1, 1) == ['{{ foo }}', '2']
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], 1, 1, 1, 1) == ['{{ foo }}', '{{ bar }}']
   

# Generated at 2022-06-25 13:28:32.630578
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print(test_case_0())


test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:28:40.212895
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)
    assert listify_lookup_plugin_terms(str, str, str, str, str) == str
    assert listify_lookup_plugin_terms(str, str, str, str, str) == str
    assert listify_lookup_plugin_terms(str, str, str, str, str) == str
    assert listify_lookup_plugin_terms(str, str, str, str, str) == str
    assert listify_lookup_plugin_terms(str, str, str, str, str) == str
    assert listify_lookup_plugin_terms(str, str, str, str, str) == str
    assert listify_lookup_plugin_terms(str, str, str, str, str) == str



# Generated at 2022-06-25 13:28:49.279231
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('t[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J', 't[e?us__d-s=J') == ['t[e?us__d-s=J']
    assert listify_lookup_plugin_terms('lua', 'lua', 'lua', 'lua', 'lua') == ['lua']
    assert listify_lookup_plugin_terms('h', 'h', 'h', 'h', 'h') == ['h']
    assert listify_lookup_plugin_terms('Lb', 'Lb', 'Lb', 'Lb', 'Lb') == ['Lb']
    assert listify_lookup_plugin

# Generated at 2022-06-25 13:28:56.081630
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print()
    term_0 = 'ter0'
    templar_0 = 'templar'
    loader_0 = 'loader'
    fail_on_undefined_0 = 'False'
    convert_bare_0 = 'False'
    try:
        assert listify_lookup_plugin_terms(term_0, templar_0, loader_0, fail_on_undefined_0, convert_bare_0) == ['ter0', 'templar', 'loader', 'False', 'False']
        print("Test passed")
    except Exception as e:
        print("Test failed")

# Generated at 2022-06-25 13:29:28.403217
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('Test Listify')


# Generated at 2022-06-25 13:29:31.222424
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Make sure the function correctly coerces single strings to a list
    assert 'foo' in listify_lookup_plugin_terms('foo', '', '', '', '')

    # Make sure the function correctly coerces lists
    assert 'foo' in listify_lookup_plugin_terms(['foo', 'bar'], '', '', '', '')

# Generated at 2022-06-25 13:29:31.845225
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0()

# Generated at 2022-06-25 13:29:38.627343
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:29:41.294378
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    #var_0 = listify_lookup_plugin_terms(var_0, var_1, var_2, var_3, var_4)
    assert var_0 == 't[e?us__d-s=J', "Variable 'var_0' should contain the correct value."

# Generated at 2022-06-25 13:29:43.957777
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = 't[e?us__d-s=J'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0, str_0, str_0)
    assert var_0 == ['t[e?us__d-s=J'], "Return does not match expected"

# Generated at 2022-06-25 13:29:44.803818
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# test_case_0()

# Generated at 2022-06-25 13:29:51.650306
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # prepare
    str_0 = 'R0_j;k'
    str_1 = 's`#:$'
    # assert
    assert listify_lookup_plugin_terms(str_0, str_0, str_0, str_0, str_0) == [str_0]
    assert listify_lookup_plugin_terms(str_1, str_1, str_1, str_1, str_1) == [str_1]
    assert listify_lookup_plugin_terms(str_0, str_1, str_1, str_1, str_1) == [str_0]
    assert listify_lookup_plugin_terms(str_1, str_0, str_1, str_1, str_1) == [str_1]
    assert listify_lookup_

# Generated at 2022-06-25 13:29:57.751867
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils import basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{lookup("pipe", "echo \'value1,value2,value3\'")}}')))
        ]
    ), loader=loader, variable_manager=VariableManager())

    tqm = None
    results = basic.run_play(play, tqm, loader, variable_manager=VariableManager())
    results_raw = results._result


# Generated at 2022-06-25 13:29:58.431294
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # example of a test case
    test_case_0()

# Generated at 2022-06-25 13:31:15.671779
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.module_utils.common.collections
    import ansible.playbook
    import ansible.template
    import ansible.parsing.yaml.objects
    import ansible.vars
    input0 = 't[e?us__d-s=J'
    input1 = 't[e?us__d-s=J'
    input2 = 't[e?us__d-s=J'
    input3 = 't[e?us__d-s=J'
    input4 = 't[e?us__d-s=J'
    expected_0 = 't[e?us__d-s=J'
    expected_1 = 't[e?us__d-s=J'
    expected_2 = 't[e?us__d-s=J'

   

# Generated at 2022-06-25 13:31:22.585992
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = [ 'a', 'b', 'c', 'd' ]
    templar = 'templar'
    loader = 'loader'
    fail_on_undefined = True
    convert_bare = False
    assert terms == listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    templar = None
    loader = None
    terms = 'a'
    assert [terms] == listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    terms = '1 with spaces'
    templar = 'templar'
    assert [terms] == listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)

# Generated at 2022-06-25 13:31:24.882625
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = 't[e?us__d-s=J'
    var_1 = listify_lookup_plugin_terms(str_0, str_0, str_0, str_0, str_0)
    assert var_1


# Generated at 2022-06-25 13:31:26.403048
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(str_0, str_0, str_0, str_0, str_0) == ['t[e?us__d-s=J']

# Generated at 2022-06-25 13:31:27.026386
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    listify_lookup_plugin_terms()


# Generated at 2022-06-25 13:31:28.853109
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    if not isinstance(test_case_0(), list):
        raise Exception('Test case 0 failed :(')

if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:31:30.075566
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    for str_0 in range(10):
        for var_0 in range(10):
            assert test_case_0() == str_0

# Generated at 2022-06-25 13:31:34.654634
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_1 = '  t[e?us__d-s=J '
    var_1 = listify_lookup_plugin_terms(str_1, str_1, str_1, str_1, str_1)
    assert var_1 == ['  t[e?us__d-s=J ']

    list_0 = ['k1', 'k2', 'k3', 'k4']
    var_2 = listify_lookup_plugin_terms(list_0, list_0, list_0, list_0, list_0)
    assert var_2 == ['k1', 'k2', 'k3', 'k4']

    set_0 = {'t1', 't2', 't3'}

# Generated at 2022-06-25 13:31:39.161205
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = 'hello'
    templar = 'world'
    loader = 'hihihi'
    fail_on_undefined = 'hello'
    convert_bare = 'world'
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)

    terms = 'hello'
    templar = 'world'
    loader = 'hihihi'
    fail_on_undefined = 'hello'
    convert_bare = 'world'
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)


# Generated at 2022-06-25 13:31:39.536099
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True
