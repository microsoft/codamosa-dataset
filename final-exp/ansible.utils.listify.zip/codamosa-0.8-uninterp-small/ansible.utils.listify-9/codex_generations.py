

# Generated at 2022-06-25 13:23:58.700846
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 13:24:08.126618
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Call function listify_lookup_plugin_terms with arguments:
    # int_1 = 479
    # int_0 = 479
    # int_2 = 479
    # str_1 = 'Z71\t2LG)\\\tl~ZgaO\t'
    int_1 = 479
    int_0 = 479
    int_2 = 479
    str_1 = 'Z71\t2LG)\\\tl~ZgaO\t'
    # self.assertEqual(actual, expected, msg='The returned value did not match the expected value.')

# Generated at 2022-06-25 13:24:11.145517
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)

# Generated at 2022-06-25 13:24:18.412614
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Arguments
    int_0 = 79
    int_1 = 462
    str_0 = '$Dqk3q6*i]O)&eR\t>|'
    str_1 = '8W?cp_ZHd1q3]^v'
    bool_0 = False
    bool_1 = True

    # Call unit test function
    listify_lookup_plugin_terms(int_0, int_1, str_0, str_1, bool_0, bool_1)


# Generated at 2022-06-25 13:24:27.591826
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Runs unit tests on listify_lookup_plugin_terms
    """
    import sys

    # Set up the test values
    int_0 = 3794873213
    str_0 = '\x1d\x1ac\x0c\x12J\x0e\x15Z'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)

    # Perform the test
    try:
        test_case_0()
    except:
        var_0 = False

    # Check if the test failed or not
    if var_0 is True:
        print('Test passed!')
        sys.exit(0)
    else:
        print('Test failed!')
        sys.exit(1)



# Generated at 2022-06-25 13:24:31.369023
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    with pytest.raises(Exception):
        listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)

if __name__ == '__main__':
    print(listify_lookup_plugin_terms(int_0, int_0, int_0, str_0))

# Generated at 2022-06-25 13:24:31.803824
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    pass

# Generated at 2022-06-25 13:24:35.438060
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    wait_times = [1.8, 4.2, 3.7, 1.9]
    overall_max = 5.0
    rate_max = 0.5
    for wait_time in wait_times:
        assert wait_time <= overall_max
        assert rate_max <= wait_time
        rate_max = rate_max * 2

# Generated at 2022-06-25 13:24:36.681804
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert_raises(TypeError, test_case_0)

# Generated at 2022-06-25 13:24:37.486316
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:24:43.826518
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Set up test values
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)

    # Perform the test
    assert var_0 == 479


# Generated at 2022-06-25 13:24:52.457465
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Strings
    assert listify_lookup_plugin_terms('', {}, {}) == ['']
    assert listify_lookup_plugin_terms('a', {}, {}) == ['a']
    assert listify_lookup_plugin_terms('a b', {}, {}) == ['a b']
    assert listify_lookup_plugin_terms(['a', 'b'], {}, {}) == ['a', 'b']
    assert listify_lookup_plugin_terms(['a b', 'c d'], {}, {}) == ['a b', 'c d']

    # Lists
    assert listify_lookup_plugin_terms(['', ''], {}, {}) == ['', '']

# Generated at 2022-06-25 13:24:56.397118
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)

    assert(var_0 == [479])

test_case_0()

# Generated at 2022-06-25 13:25:00.417141
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 92
    str_0 = ':zqi5C`\t`-'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert (var_0 == 92)

# Generated at 2022-06-25 13:25:10.954588
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Start of test 1
    int_1 = 1776
    float_1 = 1.33e+22
    float_2 = 1.41e+18
    float_3 = 1.58e+18
    float_4 = 1.17e+22
    float_5 = 1.74e+18
    float_list_1 = [float_1, float_4, float_3, float_2, float_5]

# Generated at 2022-06-25 13:25:11.751169
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 1 == 1

# Generated at 2022-06-25 13:25:20.090693
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = listify_lookup_plugin_terms(False, True, True, True, True)
    assert var_0 == True
    var_1 = listify_lookup_plugin_terms(False, True, True, True, True)
    assert var_1 == True
    var_2 = listify_lookup_plugin_terms(False, True, True, True, True)
    assert var_2 == True
    var_3 = listify_lookup_plugin_terms(False, True, True, True, True)
    assert var_3 == True
    var_4 = listify_lookup_plugin_terms(False, True, True, True, True)
    assert var_4 == True
    var_5 = listify_lookup_plugin_terms(False, True, True, True, True)
    assert var

# Generated at 2022-06-25 13:25:23.488646
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = 0
    int_0 = 479
    str_0 = ''
    func_return = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert func_return is not None
    assert func_return is True

# Generated at 2022-06-25 13:25:24.007918
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 0 == 0

# Generated at 2022-06-25 13:25:29.188257
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils import basic
    from ansible.module_utils.common.text.template import Template
    from ansible.module_utils.common.text.template import Templar

    # this is the data that will be passed into the templated file
    data = {
        'my_host': '1.2.3.4'
    }

    # this is the file we expect to be loaded into the template
    template_file = '../../templates/h.j2'

    # load the template
    t = Template(filename=template_file)

    # create the templar
    templar = Templar(loader=basic.AnsibleModuleLoader(), variables=data)

    terms = t.template(templar)

    print(terms)

# Generated at 2022-06-25 13:25:34.055621
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(int_0, int_0, int_0, str_0) == var_0

# Put the unit tests into a main function

# Generated at 2022-06-25 13:25:38.904252
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = 479
    templar = 479
    loader = 479
    fail_on_undefined = 'Z71\t2LG)\\\tl~ZgaO\t'
    convert_bare = False
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare) == 479


# Generated at 2022-06-25 13:25:43.755835
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test with good input
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    print(var_0)



# Generated at 2022-06-25 13:25:44.967982
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Dummy assert just to mark the unit test as passed
    assert True

# Generated at 2022-06-25 13:25:48.484652
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert isinstance(var_0, list)

# Generated at 2022-06-25 13:25:51.709001
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
	int_0 = 479
	str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
	var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
	assert var_0 == [479, 479, 479, 'Z71\t2LG)\\\tl~ZgaO\t'], 'This code did not perform the expected actions'

# Generated at 2022-06-25 13:25:52.346363
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert not listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:53.290610
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms() == None

# Generated at 2022-06-25 13:26:03.428844
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = 'T'
    var_1 = '4\tb\t'
    var_2 = listify_lookup_plugin_terms(var_0, var_0, var_0, var_1)
    assert var_2 == ['T'], 'Expected ["T"], but got: %s' % var_2
    var_3 = '\\'
    var_4 = "\t"
    var_5 = listify_lookup_plugin_terms(var_3, var_3, var_3, var_4)
    assert var_5 == ['\\'], 'Expected ["\\\\"], but got: %s' % var_5
    var_6 = '\\'
    var_7 = "U3)"

# Generated at 2022-06-25 13:26:05.521752
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print("unit test for function listify_lookup_plugin_terms")
    test_case_0()
    print("end test_listify_lookup_plugin_terms")

# Unit test entry point

# Generated at 2022-06-25 13:26:15.671628
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert var_0 == 479


# Generated at 2022-06-25 13:26:24.419214
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Input parameters
    int_0 = 'SJ=Y0\t}"\n@ja"O'  # Int 0
    str_0 = '~Xm1\r5=eo)%'  # String 0

# Generated at 2022-06-25 13:26:29.551490
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Set up test inputs
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'

    # Perform the test
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)

    # Verify the results
    assert var_0 == [479]


# Generated at 2022-06-25 13:26:36.267199
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test no arguments
    assert listify_lookup_plugin_terms()

    # Test one argument
    assert listify_lookup_plugin_terms(9)

    # Test two arguments
    assert listify_lookup_plugin_terms(0, 89)

    # Test three arguments
    assert listify_lookup_plugin_terms(4, 1, 0)

    # Test four arguments
    assert listify_lookup_plugin_terms(1, 1, 0, 69)

# Generated at 2022-06-25 13:26:39.770742
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)


# Generated at 2022-06-25 13:26:40.336432
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# Generated at 2022-06-25 13:26:48.684231
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():


    assert listify_lookup_plugin_terms((1,2), (1,2), (1,2), (1,2), str_0) == listify_lookup_plugin_terms((1,3), (1,3), (1,3), (1,3), str_0)
    assert listify_lookup_plugin_terms((1.2,2), (1.2,2), (1.2,2), (1.2,2), str_0) == listify_lookup_plugin_terms((1.2,3), (1.2,3), (1.2,3), (1.2,3), str_0)

# Generated at 2022-06-25 13:26:57.584622
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(str_0, int_0, int_0, int_0)
    str_4 = 'P P\n'

# Generated at 2022-06-25 13:27:05.454531
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Example of possible dictionary that can be used for input
    example_input_dictionary = {"arg1": "hello world",
                                "arg2": "another string"}

    # We can pass fixed values to the function
    result = listify_lookup_plugin_terms("hello world", "another string", "yet another string")

    # alternatively, we can create the dictionary first,
    # and then pass the dictionary to the function
    dictionary_for_function = {'arg1': "hello world", 'arg2': "another string", 'arg3': "yet another string"}
    result = listify_lookup_plugin_terms(**dictionary_for_function)

    # Passing integers
    int_arg1 = 434
    int_arg2 = 1585

# Generated at 2022-06-25 13:27:06.328101
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert False


# Generated at 2022-06-25 13:27:19.182777
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == '72L'

# Generated at 2022-06-25 13:27:27.753077
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(4.0, 4.0, 4.0, False) == 4.0
    assert listify_lookup_plugin_terms(('_vN', 'Z71\t2LG)\\\tl~ZgaO\t', 't', 5), ('_vN', 'Z71\t2LG)\\\tl~ZgaO\t', 't', 5), ('_vN', 'Z71\t2LG)\\\tl~ZgaO\t', 't', 5), True) == ('_vN', 'Z71\t2LG)\\\tl~ZgaO\t', 't', 5)

# Generated at 2022-06-25 13:27:33.851889
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Mock function calls
    class MockFunctionCalls:
        def __init__(self):
            self.int_0 = 479
            self.str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
            self.var_0 = listify_lookup_plugin_terms(self.int_0, self.int_0, self.int_0, self.str_0)

    mockFunctionCalls = MockFunctionCalls()

    assert mockFunctionCalls.var_0 == mockFunctionCalls.int_0

    print('unit tests pass')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:27:41.695865
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    hash_0 = {'a': 'Z71\t2LG)\\\tl~ZgaO\t'}
    list_0 = [1, hash_0]
    list_1 = [{'a': 'Z71\t2LG)\\\tl~ZgaO\t'}, 0]
    list_2 = [1, hash_0]


    # Call listify_lookup_plugin_terms() with arguments:
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    # Verify the contents of var_0
    assert isinstance(var_0, list)

# Generated at 2022-06-25 13:27:45.312339
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert var_0 == [479]

# Generated at 2022-06-25 13:27:48.873465
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Assertions
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert True

# Generated at 2022-06-25 13:27:53.936097
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    tmpl_str_0 = '~B?\tJE-4_pq3'
    tmpl_data_0 = {}
    testcase_0 = listify_lookup_plugin_terms(tmpl_str_0, tmpl_data_0, tmpl_data_0)
    print(testcase_0)


# Generated at 2022-06-25 13:27:58.443986
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert var_0 == [(479, 479, 479, 'Z71\t2LG)\\\tl~ZgaO\t')]


# Generated at 2022-06-25 13:27:59.793991
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:28:06.456452
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

if __name__ == '__main__':
    # Run the test cases
    test_case_0()
    test_listify_lookup_plugin_terms()

    # Run the profiling
    # Functions to profile:
    profile_tests = [
        test_case_0,
        test_listify_lookup_plugin_terms
    ]
    import cProfile
    for test in profile_tests:
        print("Profiling function: {}()".format(test.__name__))
        cProfile.runctx("test()", None, locals(), filename=test.__name__)
        print("Finished profiling function: {}()".format(test.__name__))

# Generated at 2022-06-25 13:28:37.956235
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = random_0()
    str_0 = random_str()
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)


# Generated at 2022-06-25 13:28:41.481244
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert var_0 == (479, 479,479, 'Z71\t2LG)\\\tl~ZgaO\t')


# Generated at 2022-06-25 13:28:50.582371
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    int_1 = 74
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    str_1 = '-/\t_+/ls\te{twbM1\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert var_0 == [[479]], 'Expected ["[479]"], but got: %s' % var_0
    var_1 = listify_lookup_plugin_terms(str_1, int_0, int_1, str_0)
    assert var_1 == [['[479]']], 'Expected ["[[479]]"], but got: %s' % var_1


# Generated at 2022-06-25 13:28:58.911248
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    assert listify_lookup_plugin_terms(int_0, int_0, int_0, str_0) == {
        'val_0': [479],
        'val_1': [479],
        'val_2': [479],
        'val_3': [479],
        'val_4': [479],
        'val_5': [479],
        'val_6': [479],
        'val_7': [479],
        'val_8': [479],
        'val_9': [479],
    }
    str_1 = 'KfJZMt[,~o\\+LF{J'
    int_1 = 284

# Generated at 2022-06-25 13:29:01.939499
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert var_0 == [479]

# Generated at 2022-06-25 13:29:04.285301
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Get parameters from module
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)

    assert var_0 == [479]

# Generated at 2022-06-25 13:29:07.868262
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert var_0 == 479


# Generated at 2022-06-25 13:29:09.994445
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print()
    print('TEST: listify_lookup_plugin_terms()')
    test_case_0()


test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:29:12.752599
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    assert listify_lookup_plugin_terms(int_0, int_0, int_0, str_0) == var_0, 'Failed'

# Generated at 2022-06-25 13:29:19.830774
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 320
    str_0 = 'A6|Gw>'
    int_1 = 60
    str_1 = '6U\x0c'
    int_2 = 578
    str_2 = 'bY(P"W3'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    var_1 = listify_lookup_plugin_terms(int_1, int_1, int_1, str_1)
    var_2 = listify_lookup_plugin_terms(int_2, int_2, int_2, str_2)

    test_case_0()

# Generated at 2022-06-25 13:30:34.605689
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('arg_0', 'arg_1', 'arg_2', 'arg_3') == 'arg_0'


if __name__ == "__main__":
    # Unit test
    test_listify_lookup_plugin_terms()

    print("Done")

# Generated at 2022-06-25 13:30:36.743240
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    output_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)

    assert output_0 == list_0

# Generated at 2022-06-25 13:30:40.582081
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)

# Generated at 2022-06-25 13:30:44.783820
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert listify_lookup_plugin_terms(int_0, int_0, int_0, str_0) == var_0


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        if sys.argv[1] == "0":
            test_case_0()

# Generated at 2022-06-25 13:30:52.534612
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Input parameters
    terms = 479
    templar = 479
    loader = 479
    fail_on_undefined = 'Z71\t2LG)\\\tl~ZgaO\t'
    convert_bare = True

    # Output parameters
    # Return type
    try:
        var_0 = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    except (TypeError, ValueError):
        print('Error encountered.')


if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:30:57.726257
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # variables
    int_0 = 12
    str_0 = 'BCn?D\x7fP4Czt'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert var_0 == 12
    pass
# end of test-case

if __name__ == "__main__":
    # execute only if run as a script
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:31:04.817666
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Tests that the value of the argument terms passed in to the function listify_lookup_plugin_terms is correct, as detected by the function
    def test_value_of_argument_terms_passed_in_to_listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False):
        if not callable(listify_lookup_plugin_terms):
            raise AssertionError("Expected function, got {0}".format(type(listify_lookup_plugin_terms)))
        if not callable(terms):
            raise AssertionError("Expected function, got {0}".format(type(terms)))

# Generated at 2022-06-25 13:31:07.965056
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'Z71\t2LG)\\\tl~ZgaO\t'
    # Test for when len(int_0) == 0
    test_case_0()



# Generated at 2022-06-25 13:31:15.977090
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 479
    str_0 = 'UnNK0~cB3'
    var_0 = listify_lookup_plugin_terms(str_0, int_0, int_0, str_0)
    assert var_0 == 'UnNK0~cB3'
    int_0 = -36
    str_0 = 'Dv,p%M'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, int_0, str_0)
    assert var_0 == [479]
    int_0 = 1
    str_0 = 'Dv,p%M'
    var_0 = listify_lookup_plugin_terms(int_0, int_0, str_0, str_0)
    assert var_0 == [479]
   

# Generated at 2022-06-25 13:31:17.278429
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)

# Test with a non-iterable string