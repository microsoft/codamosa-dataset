

# Generated at 2022-06-25 13:24:03.660014
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Call function listify_lookup_plugin_terms
    # with arguments
    #   bytes_0  :  P\n\xe4J
    #   dict_0  :  {}
    #   dict_0  :  {}
    #
    # Print the result
    # print(var_0)
    bytes_0 = b'P\n\xe4J'
    dict_0 = {}
    var_0 = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)
    print(var_0)

# Generated at 2022-06-25 13:24:06.016423
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(b'P\n\xe4J', dict_0, dict_0) == 'P\n\xe4J'

# Generated at 2022-06-25 13:24:07.970087
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test case 0
    try:
        test_case_0()
    except:
        print("Exception caught in test case 0")

# Generated at 2022-06-25 13:24:08.776804
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert b"\xcc" == '\xcc'

# Generated at 2022-06-25 13:24:18.907673
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = 'file'
    var_1 = 'file'
    var_2 = 'file'
    var_3 = 'file'
    var_4 = 'file'
    var_5 = 'file'
    var_6 = 'file'
    var_7 = 'file'
    var_8 = 'file'
    var_9 = 'file'
    var_10 = 'file'
    var_11 = 'file'
    var_12 = 'file'
    var_13 = 'file'
    var_14 = 'file'
    var_15 = 'file'
    list_0 = ['file', 'file', 'file', 'file', 'file', 'file', 'file', 'file']

# Generated at 2022-06-25 13:24:22.606631
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    global bytes_0
    dict_0 = {}
    var_0 = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)
    assert (var_0 == [b'P\n\xe4J'])


bytes_0 = b'P\n\xe4J'

# Generated at 2022-06-25 13:24:27.265008
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Setup Mock Modules and Test Scripts
    import ansible.module_utils.module_args
    m = ansible.module_utils.module_args.AnsibleModuleArgs
    m.load_params = load_params
    m.fail_json = fail_json
    m.exit_json = exit_json
    # Test Scripts
    result = test_case_0()

# Generated at 2022-06-25 13:24:30.660721
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert isinstance(listify_lookup_plugin_terms('foo'), list)
    assert isinstance(listify_lookup_plugin_terms(['foo', 'bar']), list)
    assert isinstance(listify_lookup_plugin_terms(('foo', 'bar')), list)

# Generated at 2022-06-25 13:24:33.442188
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    global dict_0
    global bytes_0
    global var_0
    bytes_0 = b'P\n\xe4J'
    dict_0 = {}
    var_0 = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)

# Generated at 2022-06-25 13:24:40.176178
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('-----------------')
    print('Testing function:')
    print('listify_lookup_plugin_terms')
    test_case_0()
    print('Done.')


print('Testing:')
print('Expected name: test_listify_lookup_plugin_terms')
print('Actual name: ' + __name__)

if __name__ == '__main__':
    print('Executing:')
    print(__file__)
    print('Main:')
    test_listify_lookup_plugin_terms()
else:
    print('Module imported:')
    print(__name__)

# Generated at 2022-06-25 13:24:42.935171
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == ['P\ntäJ']

# Generated at 2022-06-25 13:24:46.445628
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Calling function with arguments
    # (string_types, dict, dict, boolean, boolean)
    b'P\n\xe4J', dict_1, dict_0, True, True
    # Expecting List: [b'\xc3\xa4J']

# Generated at 2022-06-25 13:24:51.577358
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Setup args
    bytes_0 = b'P\n\xe4J'
    dict_0 = {}
    listify_lookup_plugin_terms_retval = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)
    print(listify_lookup_plugin_terms_retval)

# MCFG: create a main for unit testing
if __name__ == "_main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:57.999367
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    def get_string(str):
        return str.rstrip('\r\n')
    def equal(str_0, str_1):
        return get_string(str_0).lower() == get_string(str_1).lower()

    assert equal(test_case_0('grep'), 'grep')
    assert equal(test_case_0('grep'), 'grep')
    assert equal(test_case_0('grep'), 'grep')
    assert equal(test_case_0('grep'), 'grep')

# Generated at 2022-06-25 13:25:01.570519
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)
    try:
        test_case_0()
    except:
        assert False


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:04.553137
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms([0, 2, 4, 6, 8], {1: 2, 3: 4, 5: 6}, {1: 2, 3: 4, 5: 6}) == [0, 2, 4, 6, 8]

# Generated at 2022-06-25 13:25:10.664589
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('P\n\xe4J', {}, {})
    assert listify_lookup_plugin_terms('P\n\xe4J', {}, {}, True, True)
    assert listify_lookup_plugin_terms('P\n\xe4J', {}, {}, True)
    assert listify_lookup_plugin_terms('P\n\xe4J', {}, {}, False)

# Generated at 2022-06-25 13:25:12.131496
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 1 == 1

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 13:25:20.313330
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test with string bytes_0
    bytes_0 = b'P\n\xe4J'
    dict_0 = {}
    var_0 = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)
    assert var_0 == ['P\n\xe4J'], 'Expected ["P\\n\\xe4J"], but got {0}'.format(var_0)
    # Test with string bytes_1
    bytes_1 = b'n\x8d3o\xbc\x1a\x1d!\x17\xc9'
    dict_1 = {}
    var_1 = listify_lookup_plugin_terms(bytes_1, dict_1, dict_1)

# Generated at 2022-06-25 13:25:28.415577
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test with valid data
    from ansible.module_utils._text import to_native
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    module_name = 'include_vars'
    loader = DataLoader()
    templar = Templar(loader=loader, variables={'foo': 'bar'})
    terms_input_data = {'this': 'is', 'a': 'test'}
    expected_output = ['is', 'a', 'test']
    actual_output = listify_lookup_plugin_terms(terms_input_data, templar, loader)

    # Verify the expected and actual output are the same
    assert actual_output == expected_output

# Generated at 2022-06-25 13:25:35.748479
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # unit tests for listify_lookup_plugin_terms

    #   listify a string or list of strings
    #   Test case #0
    if True:
        bytes_0 = b'P\n\xe4J'
        dict_0 = {}
        var_0 = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)
        print(var_0)

# Generated at 2022-06-25 13:25:36.817050
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:25:46.698860
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(b'P\n\xe4J') == [b'P\n\xe4J'], "%s failed" % 'listify_lookup_plugin_terms'
    assert listify_lookup_plugin_terms(b'PB\xed\xfc\x0c\xad') == [b'PB\xed\xfc\x0c\xad'], "%s failed" % 'listify_lookup_plugin_terms'
    assert listify_lookup_plugin_terms(b'\xda\x9a\x1a') == [b'\xda\x9a\x1a'], "%s failed" % 'listify_lookup_plugin_terms'
    assert listify_lookup_plugin_terms(b'\xeb\x11')

# Generated at 2022-06-25 13:25:54.341085
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('In test_listify_lookup_plugin_terms()')
    #print '    terms = %s' % terms
    #print '    templar = %s' % templar
    #print '    loader = %s' % loader
    #print '    fail_on_undefined = %s' % fail_on_undefined
    #print '    convert_bare = %s' % convert_bare
    assert True # TODO: implement your test here


# Generated from 'test/test_listify_lookup_plugin_terms.py' on Sun, 16 Sep 2018 18:39:42 -0700
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.15 (default, Jul 31 2018, 09:41:29) 
# [GCC 4.2.1

# Generated at 2022-06-25 13:25:59.021904
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Example usage
    # mock_0 = patch('ansible.module_utils.common.collections.Iterable')
    # bytes_0 = b'P\n\xe4J'
    # dict_0 = {}
    # var_0 = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)
    pass

# Generated at 2022-06-25 13:26:00.798918
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(bytes_0, dict_0, dict_0) == var_0

# Generated at 2022-06-25 13:26:08.165875
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'n\xf4\x80\x0f \xc7\x15t'
    bool_0 = bool_1 = bool_2 = bool_3 = bool_4 = bool_5 = bool_6 = bool_7 = bool_8 = bool_9 = bool_10 = False
    int_0 = int_1 = int_2 = int_3 = int_4 = int_5 = 0
    int_6 = 1
    list_0 = [bytes_0, int_0]
    list_1 = [list_0, bool_0]
    list_2 = [bytes_0, bool_1]
    list_3 = [list_2, bool_2]
    list_4 = [list_3, bytes_0]
    list_5 = [list_4, bytes_0]
   

# Generated at 2022-06-25 13:26:09.872624
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms is not None, "Cannot find function listify_lookup_plugin_terms"


# Generated at 2022-06-25 13:26:14.571318
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ##################################################################################
    # Tests of the function for listify_lookup_plugin_terms
    ##################################################################################

    # Test #0 - bytes input, 1st argument
    test_case_0()


if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:16.832754
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Testing function listify_lookup_plugin_terms

    assert True

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:23.620463
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None

# Generated at 2022-06-25 13:26:25.560104
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()
    test_case_1()

# Test case 1

# Generated at 2022-06-25 13:26:30.213643
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Setup
    terms = []
    templar = dict()
    loader = dict()

    # Generate expected result
    expected_result = [terms]

    # Run method with parameters and observe results
    actual_result = listify_lookup_plugin_terms(terms, templar, loader)

    # Verify expectations
    assert actual_result == expected_result



# Generated at 2022-06-25 13:26:35.448838
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'P\n\xe4J'
    dict_0 = {}
    var_0 = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)
    assert isinstance(var_0, list)
    assert var_0 == ['P\n\xe4J']



# Generated at 2022-06-25 13:26:44.531907
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    test_0_0()
    test_1_0()
    test_1_1()
    test_1_2()
    test_2_0()
    test_2_1()
    test_2_2()
    test_2_3()
    test_2_4()
    test_2_5()
    test_2_6()
    test_3_0()
    test_3_1()
    test_3_2()
    test_3_3()
    test_3_4()
    test_3_5()
    test_3_6()
    test_3_7()
    test_3_8()
    test_4_0()
    test_4_1()
    test_4_2()
    test_4_3()
    test_4_4()

# Generated at 2022-06-25 13:26:52.788558
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:26:57.585458
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    result = listify_lookup_plugin_terms('P\n\xe4J', dict_0, dict_0)
    result = listify_lookup_plugin_terms(['P\n\xe4J', 'P\n\xe4J'], dict_0, dict_0)

    assert(result == ['P\n\xe4J', 'P\n\xe4J'])

# Generated at 2022-06-25 13:27:04.412352
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import StringIO


# Generated at 2022-06-25 13:27:07.706040
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.module_utils.common._collections_compat import Iterator
    from ansible.module_utils.common._collections_compat import List
    # TODO: Add more tests here
    assert True == True


# Generated at 2022-06-25 13:27:18.160225
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
	from ansible.module_utils.common._collections_compat import Mapping
	assert callable(listify_lookup_plugin_terms)
	terms = 'inventory_hostname'
	templar = {}
	loader = {}
	fail_on_undefined = None
	convert_bare = None
	ret_5 = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
	assert isinstance(ret_5, list)
	assert len(ret_5) == 1
	assert isinstance(ret_5[0], str)
	assert ret_5[0] == 'inventory_hostname'
	terms = b'P\n\xe4J'

# Generated at 2022-06-25 13:27:31.852483
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print(test_case_0())

# Generated at 2022-06-25 13:27:39.942168
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.parsing.dataloader
    from ansible.template import Templar

    loader = ansible.parsing.dataloader.DataLoader()

    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('joe', templar, loader) == ['joe']
    assert listify_lookup_plugin_terms('joe,jane', templar, loader) == ['joe','jane']
    assert listify_lookup_plugin_terms(['joe','jane'], templar, loader) == ['joe','jane']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']

# Generated at 2022-06-25 13:27:47.548978
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'P\n\xe4J'
    dict_0 = {}
    var_0 = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)
    if (var_0 == 'P\n\xe4J'.split(" ")):
        assert True
    else:
        assert False
        
    bytes_1 = b'P\n\xe4J'
    dict_1 = {}
    var_1 = listify_lookup_plugin_terms(bytes_1, dict_1, dict_1)
    if (var_1 == 'P\n\xe4J'.split(" ")):
        assert True
    else:
        assert False
        
    bytes_2 = b'P\n\xe4J'
    dict_2 = {}
    var

# Generated at 2022-06-25 13:27:49.129743
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = test_case_0()
    assert var_0 == [b'P\n\xe4J']

# Generated at 2022-06-25 13:27:57.010141
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import json

    test_cases = [
        {
            "input": b'P\n\xe4J',
            "answer": None
        },
    ]

    template = '{{ lookup("dummy") }}'

    for tc in test_cases:
        template_copy = template
        result = listify_lookup_plugin_terms(template, tc["input"], tc["answer"])
        assert result == None


if __name__ == '__main__':
    import sys
    import os
    sys.path.append(os.path.dirname(__file__) + "/..")


    (good, ret) = test_listify_lookup_plugin_terms()

    test_case_0()

# Generated at 2022-06-25 13:27:58.732165
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True
    assert listify_lookup_plugin_terms(arg0, arg1, arg2) == expected_result

# Generated at 2022-06-25 13:28:06.576589
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var0 = ''
    var1 = None
    var2 = {
        'a': 'a',
        'b': 'b',
        'c': 'c',
        'd': 'd'
    }
    var3 = {
        'a': [
            'a',
            'b',
            'c',
            'd'
        ]
    }
    var4 = {
        'a': 'a',
        'b': 'b',
        'c': 'c',
        'd': 'd'
    }
    var5 = {
        'a': [
            'a',
            'b',
            'c',
            'd'
        ]
    }

# Generated at 2022-06-25 13:28:07.986385
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert type(test_case_0()) == list
    assert type(test_case_0()[0]) == bytes

# Generated at 2022-06-25 13:28:15.433301
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_vault_password(b'V\xa1\xc1\x8a\x9e\xab\x0c\xad\xeb\xaa\x13\xae\xf1\x06\xe9\xdd\xf5\x1b\xa0\xf5\xd7\xbb')
    variable_manager.extra_vars = {u'inventory_hostname': u'monkey'}

# Generated at 2022-06-25 13:28:17.358245
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert('listify_lookup_plugin_terms' in globals())
    assert(listify_lookup_plugin_terms.__name__ == 'listify_lookup_plugin_terms')

# Generated at 2022-06-25 13:28:47.533114
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test cases to test the function
    # Call the function with args
    test_case_0()

# Generated at 2022-06-25 13:28:51.083801
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'P\n\xe4J'
    assert test_case_0() == [b'P\n\xe4J'], "Expected [b'P\n\xe4J'], got {}".format(test_case_0())

# Generated at 2022-06-25 13:28:55.237916
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Case 0
    bytes_0 = b'P\n\xe4J'
    dict_0 = {}
    var_0 = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:28:57.821675
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'P\n\xe4J'
    dict_0 = {}
    var_0 = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)
    assert var_0 == []

# Generated at 2022-06-25 13:29:04.389691
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    dict_0 = {}
    dict_0 = {}
    var_0 = listify_lookup_plugin_terms(dict_0, dict_0, dict_0)
    assert type(var_0) == list
    assert var_0 == []

    list_0 = ['P\n\xe4J']
    dict_1 = {}
    dict_1 = {}
    var_1 = listify_lookup_plugin_terms(list_0, dict_1, dict_1)
    assert type(var_1) == list
    assert var_1 == list_0

    bytes_0 = b'P\n\xe4J'
    dict_2 = {}
    dict_2 = {}
    var_2 = listify_lookup_plugin_terms(bytes_0, dict_2, dict_2)

# Generated at 2022-06-25 13:29:06.129288
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # this test requires a running system and should be run manually when needed.
    #assert False
    #assert False, bytes_0
    pass


# Generated at 2022-06-25 13:29:10.128820
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'P\n\xe4J'
    dict_0 = {}
    var_0 = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)
    var_1 = b'P\n\xe4J'
    assert var_0 == var_1


# Generated at 2022-06-25 13:29:14.251137
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Setup

    # Execution
    bytes_0 = b'P\n\xe4J'
    dict_0 = {}
    actual = listify_lookup_plugin_terms(bytes_0, dict_0, dict_0)
    assert actual == var_0

    # Teardown
    del bytes_0, dict_0, actual, var_0
    # Expected result
    #assert actual == expected
    #assert expected == actual

# Generated at 2022-06-25 13:29:22.178478
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # From /etc/ansible/roles/test_role/tasks/main.yml #9

    test_var_0 = None
    test_var_1 = [
        '0',
        '1',
    ]
    test_var_2 = '2'
    test_var_3 = [
        '3',
    ]

    test_var_4 = [
        '4',
    ]

    test_var_5 = '5'
    test_var_6 = [
        '6',
        '7',
    ]
    test_var_7 = [
        '8',
    ]

    test_var_8 = '9'
    test_var_9 = '10'
    test_var_10 = [
        '11',
    ]

# Generated at 2022-06-25 13:29:23.069003
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None, "Failed to return 0"

# Generated at 2022-06-25 13:30:40.726061
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    src = b"P\n\xe4J"
    var_0 = listify_lookup_plugin_terms(src)
    assert isinstance(var_0, list)

if __name__ == '__main__':
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:30:43.394811
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    string_0 = ':@'
    expected = ['', '@']
    result = listify_lookup_plugin_terms(string_0, {}, {})
    assert result == expected


# Generated at 2022-06-25 13:30:44.822205
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == 'P\n\xc3\xa4J'

# Generated at 2022-06-25 13:30:54.126864
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert isinstance(listify_lookup_plugin_terms(None, None, None), list)
    assert isinstance(listify_lookup_plugin_terms(42, None, None), list)
    assert isinstance(listify_lookup_plugin_terms(object(), None, None), list)
    assert isinstance(listify_lookup_plugin_terms(3.1415, None, None), list)
    assert isinstance(listify_lookup_plugin_terms(u'0711556970', None, None), list)
    assert isinstance(listify_lookup_plugin_terms(u'978-1-4302-2473-4', None, None), list)
    assert isinstance(listify_lookup_plugin_terms(u'9781430224734', None, None), list)
    assert isinstance

# Generated at 2022-06-25 13:31:01.292228
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ret_0 = listify_lookup_plugin_terms(0,0,0)
    assert ret_0 == [0]
    ret_1 = listify_lookup_plugin_terms('',0,0)
    assert ret_1 == ['']
    ret_2 = listify_lookup_plugin_terms('',0,0)
    assert ret_2 == ['']
    ret_3 = listify_lookup_plugin_terms(0,0,0)
    assert ret_3 == [0]
    ret_4 = listify_lookup_plugin_terms('string',0,0)
    assert ret_4 == ['string']
    ret_5 = listify_lookup_plugin_terms(0,0,0)
    assert ret_5 == [0]
    ret_6 = listify_look

# Generated at 2022-06-25 13:31:06.240552
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test_values: [val]
    test_values = [
        ('PäJ', ),
    ]

    # Allowed values for param
    bytes_0 = b'P\n'
    dict_0 = {}
    bool_0 = False

    for test_value in test_values:
        # Test function
        assert listify_lookup_plugin_terms(
            bytes_0, dict_0, dict_0, param=bool_0
        ) == test_value

# Generated at 2022-06-25 13:31:07.459115
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None

# Generated at 2022-06-25 13:31:08.864776
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test cases
    var_0 = test_case_0()
    assert True



# Generated at 2022-06-25 13:31:12.111795
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        import __main__
    except ImportError:
        import sys
        __main__ = sys.modules[__name__]


    test_case_0()


if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:31:14.521989
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # No args for function test_listify_lookup_plugin_terms
    test_case_0()

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()