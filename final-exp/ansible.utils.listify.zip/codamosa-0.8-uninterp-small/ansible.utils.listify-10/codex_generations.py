

# Generated at 2022-06-25 13:24:01.052042
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == True

# Generated at 2022-06-25 13:24:05.079187
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # assert listify_lookup_plugin_terms(('foo', 'bar'), cat_1, int_0, str_0) == None
    print('Test:', 'listify_lookup_plugin_terms', 'for function', 'listify_lookup_plugin_terms', 'ran successfully')

# Generated at 2022-06-25 13:24:11.961216
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test with invalid input
    try:
        listify_lookup_plugin_terms()
    except TypeError as error:
        assert 'Argument 1 of listify_lookup_plugin_terms is not defined.' in str(error)

    # Test with invalid input
    try:
        listify_lookup_plugin_terms(int_0, int_0, bool_0)
    except TypeError as error:
        assert 'Argument 2 of listify_lookup_plugin_terms is not defined.' in str(error)

    # Test with invalid input
    try:
        listify_lookup_plugin_terms(int_0, int_0, bool_0)
    except TypeError as error:
        assert 'Argument 3 of listify_lookup_plugin_terms is not defined.' in str(error)

    # Test with

# Generated at 2022-06-25 13:24:21.965791
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # I had to manually edit out the "from ansible.module_utils.common._collections_compat import Iterable" that is found in the real test, but is not imported for usage.
    temp_dict = dict()

    # I also had to use my own custom templar() function to replace the "from ansible.parsing.ajson import AnsibleJSONEncoder" functionality.
    def templar(obj, convert_bare=False, fail_on_undefined=True):
        if isinstance(obj, dict) or isinstance(obj, list) or isinstance(obj, tuple):
            return obj
        elif isinstance(obj, str):
            return obj + 'x'
    
    var_0 = listify_lookup_plugin_terms(None, templar, temp_dict)

# Generated at 2022-06-25 13:24:24.797900
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    assert var_0 == "437"

# Generated at 2022-06-25 13:24:33.016923
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = False
    bool_0 = False
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    assert var_0 == 1
    assert type(var_0) is int
    bool_0 = True
    int_1 = 437
    var_1 = listify_lookup_plugin_terms(int_0, int_1, bool_0)
    assert var_1 == 1
    assert type(var_1) is int
    int_1 = False
    bool_0 = False
    var_2 = listify_lookup_plugin_terms(int_1, int_1, bool_0)
    assert var_2 == True
    assert type(var_2) is bool
    int_1 = True
    var_3 = listify_

# Generated at 2022-06-25 13:24:34.117525
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert not test_case_0()
# END of generated test code

# Generated at 2022-06-25 13:24:35.274767
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)
    test_case_0()

# Generated at 2022-06-25 13:24:37.449366
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 'ansible.module_utils.common._collections_compat.Iterable' in globals()
    assert 'ansible.module_utils.six.string_types' in globals()

# Generated at 2022-06-25 13:24:39.280531
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms.func_name == 'listify_lookup_plugin_terms'

# Generated at 2022-06-25 13:24:49.634331
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass


# Generated at 2022-06-25 13:24:51.955987
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    str_0 = "437"
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    print(var_0)
    var_1 = listify_lookup_plugin_terms(str_0, int_0, bool_0)
    print(var_1)

test_case_0()

# Generated at 2022-06-25 13:24:54.837443
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Attempt to call the function
    try:
        listify_lookup_plugin_terms(int_0, int_0, bool_0)
    except:
        assert True, "Unhandled exception was raised"


# Generated at 2022-06-25 13:24:58.455555
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 1 == 1 # TODO: implement your test here

# -------------------------------------------------------------------------------------------------
#    MAIN
# -------------------------------------------------------------------------------------------------
if __name__ == "__main__":
    test_listify_lookup_plugin_terms()
    test_case_0()

# Generated at 2022-06-25 13:25:08.621048
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Setup mock
    loaded_mock = {'foo': 'bar'}

    # Setup templar
    templar = ansible.vars.templar.Templar(loader=ansible.vars.loader.DataLoader())

    # Setup arguments
    terms = b'baz'
    templar = templar
    loader = ansible.vars.loader.DataLoader()

    # Test function
    ansible.module_utils.common.listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)
    ansible.module_utils.common.listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=True)

# Generated at 2022-06-25 13:25:12.866063
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    arg0 = 'hello'
    arg1 = 'world'
    arg2 = 'foo'
    arg3 = True
    arg4 = False
    out = listify_lookup_plugin_terms(arg0, arg1, arg2, arg3, arg4)
    assert out == 'hello'

# Generated at 2022-06-25 13:25:16.630947
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    assert var_0 == 437


# Generated at 2022-06-25 13:25:27.280875
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    templar = '{"name": "bobby", "groups": ["wheel", "dev"], "dictionary": {"John": "Example 1", "Joe": "Example 2"}}'
    loader = '{"name": "sammy", "groups": ["wheel", "dev"], "dictionary": {"John": "Example 1", "Joe": "Example 2"}}'
    fail_on_undefined=True
    convert_bare=False
    var_0 = listify_lookup_plugin_terms(templar, templar, loader, fail_on_undefined, convert_bare)
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(var_0, int_0, bool_0)

# Generated at 2022-06-25 13:25:30.111055
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(int_0, int_0, bool_0) == 437
assert listify_lookup_plugin_terms(bool_0, int_0, bool_0) == True

# Generated at 2022-06-25 13:25:31.411717
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    checkvar = test_listify_lookup_plugin_terms
    checkvar = test_case_0

    print(checkvar)

# Generated at 2022-06-25 13:25:37.689731
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bool_0 = True
    int_0 = 524
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    assert var_0 == True



# Generated at 2022-06-25 13:25:47.343343
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = listify_lookup_plugin_terms(123, 123, False)
    var_1 = listify_lookup_plugin_terms(456, 456, True)
    var_2 = listify_lookup_plugin_terms(789, 789, False)
    var_3 = listify_lookup_plugin_terms(False, False, False)
    var_4 = listify_lookup_plugin_terms(True, True, True)
    var_5 = listify_lookup_plugin_terms(True, True, False)
    var_6 = listify_lookup_plugin_terms(0, 0, True)
    var_7 = listify_lookup_plugin_terms(0, 0, False)
    var_8 = listify_lookup_plugin_terms(123, 123, True)

# Generated at 2022-06-25 13:25:51.890514
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    assert var_0 == [437]
    int_1 = -618
    bool_1 = False
    var_1 = listify_lookup_plugin_terms(int_1, int_1, bool_1)
    assert var_1 == [-618]

# Generated at 2022-06-25 13:25:52.562053
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == True

# Generated at 2022-06-25 13:25:55.536176
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    assert var_0 == 437


# Generated at 2022-06-25 13:25:56.964058
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    parts_0 = test_case_0()
    assert parts_0 == None



# Generated at 2022-06-25 13:26:00.587992
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Call listify_lookup_plugin_terms with appropriate arguments
    temp_0 = listify_lookup_plugin_terms(temp_0, temp_0, temp_0)

    # Check if the return value is as expected
    assert temp_0 == temp_0


# Generated at 2022-06-25 13:26:03.271356
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(test_case_0()) == 1

test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:03.805135
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    pass

# Generated at 2022-06-25 13:26:05.363206
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == 0

# Usage example
listify_lookup_plugin_terms(var, int, bool_0)

# Generated at 2022-06-25 13:26:13.189070
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True is True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:26:18.813134
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    assert var_0 == 437

if __name__ == "__main__":
    import sys
    import pytest

    # print((pytest.main(["-v", __file__])))
    sys.exit(pytest.main(["-v", "-s", __file__]))

# Generated at 2022-06-25 13:26:20.735402
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 13:26:27.333910
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    int_1 = 478
    var_0 = listify_lookup_plugin_terms(int_1, int_1, bool_0)
    str_0 = "abc"
    var_0 = listify_lookup_plugin_terms(str_0, int_1, bool_0)
    str_1 = "listify_lookup_plugin_terms"
    var_0 = listify_lookup_plugin_terms(str_1, int_1, bool_0)


# Generated at 2022-06-25 13:26:29.774283
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    def __init__(self):
        pass
    __file__ = "test_listify_lookup_plugin_terms.py"
    test_case_0()
    pass

# Generated at 2022-06-25 13:26:30.624191
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-25 13:26:37.054559
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    assert type(var_0) == list or isinstance(var_0, list)
    assert var_0[0] == int_0
# Function: listify_lookup_plugin_terms
# Revision: 5
# Unit tests: yes
# Coverage  : no
# Complexity: no
# Notes     : no

# Generated at 2022-06-25 13:26:39.769762
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    return var_0


# Generated at 2022-06-25 13:26:46.747214
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)


if __name__ == "__main__":
    print(test_listify_lookup_plugin_terms())

# # Unit test for function listify_lookup_plugin_terms
# def test_listify_lookup_plugin_terms():
#     int_0 = 437
#     bool_0 = True
#     var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
#     assert var_0 ==

# Generated at 2022-06-25 13:26:55.599040
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(int_0, int_0, bool_0) == var_0

if __name__ == "__main__":
    import sys
    from imp import load_source
    from ansible.module_utils.common._collections_compat import Iterable

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    def mock_open(mock=None, data=None):
        if mock is None:
            mock = Mock()

        handle = Mock()
        handle.write = Mock()
        handle.__enter__ = Mock(return_value=handle)
        handle.__exit__ = Mock()

        mock.return_value = handle
        return mock

    def test_case_0():
        int_0 = 437
        bool

# Generated at 2022-06-25 13:27:17.625276
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    string_0 = "ma"
    string_0 = string_0 * 2
    int_0 = 437
    string_1 = "FUnK"
    string_1 = string_1 * 2
    int_1 = 574
    bool_0 = True
    string_2 = "ma"
    string_2 = string_2 * 3
    string_3 = "FUnK"
    string_3 = string_3 * 4
    int_2 = 975
    int_3 = 918
    int_4 = 940
    string_4 = "ma"
    string_4 = string_4 * 3
    string_5 = "FUnK"
    string_5 = string_5 * 3
    string_6 = "ma"
    string_6 = string_6 * 4
    int_5 = 5

# Generated at 2022-06-25 13:27:21.093896
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = 'var_0'
    bool_0 = True
    int_0 = 943
    var_0 = listify_lookup_plugin_terms(str_0, int_0, bool_0)
    assert var_0 is not False


# Generated at 2022-06-25 13:27:28.987239
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    var_1 = listify_lookup_plugin_terms(int_0, int_0, bool_0, fail_on_undefined=False, convert_bare=False)
    var_2 = listify_lookup_plugin_terms(int_0, int_0, bool_0, fail_on_undefined=True, convert_bare=False)
    var_3 = listify_lookup_plugin_terms(int_0, int_0, bool_0, fail_on_undefined=False, convert_bare=True)

# Generated at 2022-06-25 13:27:29.632871
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0()

# Generated at 2022-06-25 13:27:31.391165
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(int_0, int_0, bool_0) == var_0

# Generated at 2022-06-25 13:27:35.977795
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert False, "No tests in TestModule"
    # assert not hasattr(listify_lookup_plugin_terms, '__call__'), \
    #     'is function'
    # assert hasattr(listify_lookup_plugin_terms, '__call__'), \
    #     'is not function'


if __name__ == '__main__':
    test_case_0()
    # test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:38.819341
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    assert listify_lookup_plugin_terms(int_0, int_0, bool_0) is not None


# Generated at 2022-06-25 13:27:44.972534
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    assert var_0 != 437
    assert var_0 == 437
    assert var_0 is not 437
    assert var_0 != 437
    assert var_0 == 437
    int_0 = 437
    assert var_0 != int_0
    assert var_0 != int_0
    assert var_0 is not int_0
    assert var_0 is not int_0
    assert var_0 != int_0
    assert var_0 == int_0
    int_0 = 437
    assert var_0 != int_0
    assert var_0 == int_0
    assert var_0 is not int_0
   

# Generated at 2022-06-25 13:27:47.477148
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Place your code here
    assert test_case_0() == 'Success'


# Generated using a template - edit template and rerun
# pylint: disable=line-too-long,missing-docstring

# Generated at 2022-06-25 13:27:48.433417
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert False, 'Test not implemented'

# Generated at 2022-06-25 13:28:18.159385
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert isinstance(test_case_0.var_0, list) == True


if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:28:24.933526
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0, True, True)
    assert var_0 == 437
    var_1 = listify_lookup_plugin_terms(int_0, int_0, bool_0, True, False)
    assert var_1 == 437
    var_2 = listify_lookup_plugin_terms(int_0, int_0, bool_0, False, True)
    assert var_2 == 437
    var_3 = listify_lookup_plugin_terms(int_0, int_0, bool_0, False, False)
    assert var_3 == 437

# Generated at 2022-06-25 13:28:25.366565
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-25 13:28:26.652692
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert(test_case_0()[0] == True)

# Generated at 2022-06-25 13:28:28.781128
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    assert var_0 == 437


# Generated at 2022-06-25 13:28:36.973274
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 681
    bool_0 = False
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    # Evaluate assertion
    assert var_0 == int_0

    str_0 = "&"
    str_1 = "#dP+Aqn"

    float_0 = 12.0

    list_0 = [str_1, float_0]

    tuple_0 = (float_0, str_1)
    # Check for unittest Single instance
    assert listify_lookup_plugin_terms(list_0, list_0, float_0) == list_0
    assert listify_lookup_plugin_terms(tuple_0, tuple_0, float_0) == tuple_0

    # Evaluate assertion
    assert list

# Generated at 2022-06-25 13:28:39.686022
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 480
    bool_0 = False
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:28:41.821067
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)

# Generated at 2022-06-25 13:28:44.094951
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)

    assert var_0 == 43



# Generated at 2022-06-25 13:28:45.848449
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == (
        437,
        437,
        True
    )

# Generated at 2022-06-25 13:29:48.209361
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None


# Generated at 2022-06-25 13:29:51.260825
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    in_0 = 'Foo  '
    in_1 = 'Foo  '
    in_2 = True
    out = listify_lookup_plugin_terms(in_0, in_1, in_2)
    result = ['Foo']
   # assert out == result



# Generated at 2022-06-25 13:29:57.424431
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(801, 801, True)
    assert listify_lookup_plugin_terms('str_0', 801, True)
    assert listify_lookup_plugin_terms(True, 801, True)
    assert listify_lookup_plugin_terms(False, 801, True)
    assert listify_lookup_plugin_terms(801, 801, True)
    assert listify_lookup_plugin_terms(801, 801, True)
    assert listify_lookup_plugin_terms(801, 801, True)
    assert listify_lookup_plugin_terms(801, 801, True)
    assert listify_lookup_plugin_terms(801, 801, True)

# Generated at 2022-06-25 13:29:58.005931
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True, "test 0"

# Generated at 2022-06-25 13:29:58.536842
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 0 == 0
#     test_case_0()

# Generated at 2022-06-25 13:29:59.045667
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert(42 == 42)

# Generated at 2022-06-25 13:29:59.817291
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:30:05.454159
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Set up test case
    int_0 = 2012
    str_0 = '{{'
    str_1 = '}}'
    str_2 = 'str_0'
    str_3 = 'value'
    str_4 = 'item'
    str_5 = 'str_2'
    str_6 = 'str_1'
    str_7 = 'str_0'
    str_8 = 'str_1'
    str_9 = 'str_1'
    str_10 = ' str_3  '
    str_11 = 'str_1'
    str_12 = 'str_0'
    str_13 = 'str_1'
    str_14 = 'str_4'
    str_15 = ' str_4'
    str_16 = ' str_4  '
    str_17

# Generated at 2022-06-25 13:30:05.923343
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True == True

# Generated at 2022-06-25 13:30:13.358457
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    assert var_0 == 437
    int_0 = 535
    int_1 = 535
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_1, int_0, bool_0)
    assert var_0 == 535
    int_0 = 906
    int_1 = 906
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_1, int_0, bool_0)
    assert var_0 == 906

main()

# Generated at 2022-06-25 13:32:37.336144
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == True

# Generated at 2022-06-25 13:32:44.383159
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test template with static values
    string_0 = 'asdf'
    int_0 = 437
    list_0 = ['asdf', 437]
    assert listify_lookup_plugin_terms(string_0, string_0, int_0) == list_0
    # Test template with a variable
    string_0 = '{{ int_0 }}'
    int_0 = 437
    list_0 = [437]
    assert listify_lookup_plugin_terms(string_0, string_0, int_0) == list_0
    # Test template with a variable and a static value in a list
    string_0 = ['{{ int_0 }}', 437]
    int_0 = 437
    list_0 = [437, 437]

# Generated at 2022-06-25 13:32:47.032483
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    assert var_0 == 437, ''


# Generated at 2022-06-25 13:32:49.145225
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print("TEST_FOR listify_lookup_plugin_terms function")
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-25 13:32:57.574895
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import assertEqual

    int_0 = 436
    ____ = assertEqual(listify_lookup_plugin_terms(int_0, int_0, int_0), int_0)
    bool_0 = False
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    int_1 = 126
    ____ = assertEqual(listify_lookup_plugin_terms(int_0, int_1, var_0), int_1)
    int_2 = 395
    ____ = assertEqual(listify_lookup_plugin_terms(int_0, int_2, ____), int_2)
    int_3 = 611

# Generated at 2022-06-25 13:33:03.952690
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # func_0
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    # func_1
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    # func_2
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    # func_3
    int_0 = 437
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, int_0, bool_0)
    # func

# Generated at 2022-06-25 13:33:04.637680
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:33:05.295495
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    if test_case_0():
        pass

# Generated at 2022-06-25 13:33:09.035396
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = 'this_is_a_test'
    templar = 'this_is_a_test'
    loader = True
    fail_on_undefined = False
    convert_bare = True
    expected = ['this_is_a_test']

    actual = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)

    assert [expected[0]] == actual



# Generated at 2022-06-25 13:33:14.046327
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var = listify_lookup_plugin_terms('Testing', 'Testing', 'Testing')
    assert isinstance(var, list)
    assert var == ['Testing']
    var = listify_lookup_plugin_terms(['Testing', ('Testing',), ('Testing', 'Testing')], 'Testing', 'Testing')
    assert isinstance(var, list)
    assert var == ['Testing', ('Testing',), ('Testing', 'Testing')]
    var = listify_lookup_plugin_terms((None, 'Testing', ['Testing', ()]), 'Testing', 'Testing')
    assert isinstance(var, list)
    assert var == [None, 'Testing', ['Testing', ()]]