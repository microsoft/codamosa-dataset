

# Generated at 2022-06-25 13:24:00.153278
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(str_0, str_0, str_0) == var_0


if __name__ == "__main__":
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:01.829637
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    result_0 = test_case_0()
    assert result_0 == [], "case 0"

# Generated at 2022-06-25 13:24:10.644754
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = 'foo'
    str_0_0 = 'bar'
    str_0_1 = 'baz'
    dict_0_0 = {str_0: str_0_0, str_0_0: str_0_1}
    list_0_0 = [str_0, str_0_0, str_0_1]
    dict_0_0_0 = {str_0: dict_0_0, str_0_0: list_0_0, str_0_1: dict_0_0}
    list_0_0_0 = [str_0, dict_0_0, list_0_0, dict_0_0_0]
    str_0_0_0 = 'foo'
    str_0_1_0 = 'foo'
    dict_0_

# Generated at 2022-06-25 13:24:13.471167
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('!Ga', object(), object()) == ['!Ga']
    assert listify_lookup_plugin_terms(5, object(), object()) == 5

# Generated at 2022-06-25 13:24:23.235532
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test case 0
    try:
        test_case_0()
    except Exception:
        assert False, 'Uncaught exception raised'

    # Test case 1
    try:
        test_case_1()
    except Exception:
        assert False, 'Uncaught exception raised'

    # Test case 2
    try:
        test_case_2()
    except Exception:
        assert False, 'Uncaught exception raised'

    # Test case 3
    try:
        test_case_3()
    except Exception:
        assert False, 'Uncaught exception raised'

    # Test case 4
    try:
        test_case_4()
    except Exception:
        assert False, 'Uncaught exception raised'

# This function is called by the module import script

# Generated at 2022-06-25 13:24:23.797670
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert False

# Generated at 2022-06-25 13:24:32.020944
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True


# class TestListifyLookupPluginTermsMethods(unittest.TestCase):
#     def test_listify_lookup_plugin_terms(self):
#         self.assertEqual(listify_lookup_plugin_terms, True)

#     def test_listify_lookup_plugin_terms(self):
#         self.assertEqual(listify_lookup_plugin_terms, True)

#     def test_listify_lookup_plugin_terms(self):
#         self.assertEqual(listify_lookup_plugin_terms, True)

#     def test_listify_lookup_plugin_terms(self):
#         self.assertEqual(listify_lookup_plugin_terms, True)

# Generated at 2022-06-25 13:24:32.765476
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:24:34.813683
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    with pytest.raises(TypeError) as excinfo:
        print(test_case_0())
    assert "takes exactly 3 arguments (4 given)" in str(excinfo.value)

# Generated at 2022-06-25 13:24:44.251544
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = '!Ga'
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = '!Ga'
    str_9 = ''
    str_10 = ''
    str_11 = ''
    str_12 = ''
    str_13 = ''
    str_14 = ''
    str_15 = '!Ga'
    str_16 = ''
    str_17 = ''
    str_18 = ''
    str_19 = ''
    str_20 = ''
    str_21 = '!Ga'
    str_22 = ''
    str_23 = ''
    str_24 = ''


# Generated at 2022-06-25 13:24:50.428722
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    assert var_0 == ['!Ga']
    str_0 = 'B*!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    assert var_0 == ['B*!Ga']

# Generated at 2022-06-25 13:24:50.938986
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert False == False

# Generated at 2022-06-25 13:24:52.462459
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:02.473555
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_var_0 = "a, b, c"
    str_var_1 = "]"
    str_var_2 = "dict"
    str_var_3 = "tuple"
    str_var_4 = "list"
    str_var_5 = "set"
    str_var_6 = "["
    str_var_7 = "("
    str_var_8 = ")"
    int_var_0 = -1
    int_var_1 = 0
    int_var_2 = 1

    var_0 = [str_var_6, str_var_5, str_var_1]
    var_1 = [str_var_6, str_var_5, str_var_0, str_var_1]

# Generated at 2022-06-25 13:25:04.775527
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # test case 0
    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)

# Generated at 2022-06-25 13:25:15.724502
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    src = ['a', 'b', 'c']
    dest = listify_lookup_plugin_terms(src, '', '')
    assert src == dest
    src = 'a,b,c'
    dest = listify_lookup_plugin_terms(src, '', '')
    assert dest == src.split(',')
    src = ['a', 'b', 'c']
    dest = listify_lookup_plugin_terms(src, '', '')
    assert src == dest
    src = 'a,b,c'
    dest = listify_lookup_plugin_terms(src, '', '')
    assert dest == src.split(',')
    src = 'a'
    dest = listify_lookup_plugin_terms(src, '', '')
    assert dest == [src]


# Generated at 2022-06-25 13:25:22.560377
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_cases = [
        # About: Test case 0
        {
            "input": {
                "terms": '!Ga',
                "templar": '!Ga',
                "loader": '!Ga'
            },
            "answer": None
        }
    ]
    for case in test_cases:
        output = listify_lookup_plugin_terms(**case["input"])
        print(output)
        #assert output == case["answer"]



# Generated at 2022-06-25 13:25:28.793048
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # All None parameters
    assert listify_lookup_plugin_terms(None, None, None) is None

    # All real parameters
    assert listify_lookup_plugin_terms('', '', '') == ['']
    assert listify_lookup_plugin_terms('', '', '') == ['']
    assert listify_lookup_plugin_terms('', '', '') == ['']

    # Parameters having default value
    assert listify_lookup_plugin_terms('', '', '') == ['']

# Generated at 2022-06-25 13:25:35.101882
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_a = 'str_a'
    str_b = 'str_b'
    str_c = 'str_c'
    str_d = 'str_d'
    str_e = 'str_e'
    str_f = 'str_f'
    str_g = 'str_g'
    str_h = 'str_h'
    str_i = 'str_i'

    # Test 0
    list_0 = []
    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_a, str_b, convert_bare=True)
    assert var_0 == list_0

    # Test 1
    list_1 = []
    str_1 = '!Ga'
    var_1 = listify_lookup_plugin

# Generated at 2022-06-25 13:25:45.288195
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test using 
    assert(listify_lookup_plugin_terms('!Ga', str_0, str_0) == var_0)

# Usage
# python3 -m doctest -v ansible/module_utils/lookup.py
#    - or -
# pip2 install pytest
# pytest --doctest-modules --collect-only -v  ansible/module_utils/lookup.py
#    - or -
# bash
# cd ansible/module_utils
# python2 -m pytest --doctest-modules --collect-only -v .
#    - or -
# python2 -m pytest -v --junitxml results.xml --doctest-modules --collect-only .
#
# coverage run -a --source=ansible/module_utils -m pytest --doctest

# Generated at 2022-06-25 13:25:48.940392
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None

# Generated at 2022-06-25 13:25:55.939444
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 'Ga' in listify_lookup_plugin_terms('!Ga', 'Ga', 'Ga')
    assert 'Ga' in listify_lookup_plugin_terms('"Ga"', 'Ga', 'Ga')
    assert 'Ga' in listify_lookup_plugin_terms('"Ga"', 'Ga', 'Ga')
    assert 'Ga' in listify_lookup_plugin_terms('"Ga"', 'Ga', 'Ga')
    assert 'Ga' in listify_lookup_plugin_terms('"Ga"', '"Ga"', 'Ga')
    assert 'Ga' in listify_lookup_plugin_terms('"Ga"', 'Ga', '"Ga"')
    assert 'Ga' in listify_lookup_plugin_terms('"Ga"', '"Ga"', '"Ga"')

# Generated at 2022-06-25 13:26:00.463408
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test case 0
    str_0 = '!Ga'
    try:
        test_case_0()
        test_case_0_result = True
    except:
        test_case_0_result = False
    assert test_case_0_result == True

# Unit tests for listify_lookup_plugin_terms

# Generated at 2022-06-25 13:26:08.014459
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Testing with a string
    str_0 = 'Something'
    listify_lookup_plugin_terms(str_0, str_0, str_0)

    # Testing with an empty string
    str_1 = ''
    listify_lookup_plugin_terms(str_1, str_1, str_1)

    # Testing with the character 'None'
    str_2 = 'os.path'
    listify_lookup_plugin_terms(str_2, str_2, str_2)

    # Testing with a list of strings
    str_3 = ['f', 'b', 'd']
    listify_lookup_plugin_terms(str_3, str_3, str_3)

    # Testing with an integer
    str_4 = 5

# Generated at 2022-06-25 13:26:12.081153
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    assert var_0 == ['!Ga']


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 13:26:21.117886
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms("{{ 'a' }},{{ 'b' }}") == ['a', 'b']
    assert listify_lookup_plugin_terms("{{ ['a','b'] }}") == ['a', 'b']
    assert listify_lookup_plugin_terms("{{ 'a' }}") == ['a']
    assert listify_lookup_plugin_terms("{{ foo }}", dict(foo=['a', 'b'])) == ['a', 'b']
    assert listify_lookup_plugin_terms("{{ foo }}", dict(foo='a')) == ['a']
    assert listify_lookup_plugin_terms("no_template") == ['no_template']
    assert listify_lookup_plugin_terms("unmatched{{ 'a' }}") == ['unmatcheda']

# Generated at 2022-06-25 13:26:22.287913
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(str_0, str_0, str_0) == var_0

# Generated at 2022-06-25 13:26:23.049316
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
   assert test_case_0() == 0

# Generated at 2022-06-25 13:26:31.960872
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('!Ga', '!Ga', '!Ga') == ['!Ga']
    # assert listify_lookup_plugin_terms(3.4, '!Ga', '!Ga') is NotImplemented
    # assert listify_lookup_plugin_terms(('3.4', '3.4'), '!Ga', '!Ga') is NotImplemented
    # assert listify_lookup_plugin_terms({'a': 3.4, 'b': '3.4'}, '!Ga', '!Ga') is NotImplemented


if __name__ == '__main__':
    print(test_case_0())

# Generated at 2022-06-25 13:26:41.430642
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})
    templar.set_available_variables({'HOSTNAME': 'localhost'})

    assert listify_lookup_plugin_terms('%HOSTNAME', templar, None) == [u'localhost']
    assert listify_lookup_plugin_terms('[%HOSTNAME]', templar, None) == [u'localhost']
    assert listify_lookup_plugin_terms('[%HOSTNAME, %HOSTNAME]', templar, None) == [u'localhost']

# Generated at 2022-06-25 13:26:50.559559
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    assert var_0 == '!Ga' or var_0 == ['!Ga']

# Generated at 2022-06-25 13:26:52.128592
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Check the results of listify_lookup_plugin_terms
    assert listify_lookup_plugin_terms() == True

# Generated at 2022-06-25 13:27:01.037593
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    assert var_0 == ['!Ga']

    # In fact this test case is wrong, because ansible module_utils.six doesn't support 'import unicode_literals', but I use python3 to test it.
    #str_0 = '!Ga'
    #str_1 = 'abc'
    #var_0 = listify_lookup_plugin_terms(str_0, str_0, str_1)
    #assert var_0 == ['!Ga']
    #str_0 = '!Ga'
    #var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    #assert var_0 == ['!

# Generated at 2022-06-25 13:27:01.889542
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert False
#     test_case_0()

# Generated at 2022-06-25 13:27:04.442575
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Put the code you want to test in the function, define a method in the class named test_function_name, and
    # add a call to that method here.
    test_case_0()

# Generated at 2022-06-25 13:27:13.321319
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Case 0:
    # The variable 'str_0' is an str literal that is parsed and passed as a value to the argument 'terms' of the function listify_lookup_plugin_terms
    # and the variable 'arg_0' is an str literal that is parsed and passed as a value to the argument 'templar' of the function listify_lookup_plugin_terms
    # and the variable 'arg_1' is an str literal that is parsed and passed as a value to the argument 'loader' of the function listify_lookup_plugin_terms
    # This test case is expected to be executed without exceptions.
    test_case_0()


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:18.800405
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Input parameters
    str_0 = '!Ga'
    str_1 = '!Ga'
    str_2 = '!Ga'
    # Output parameters
    var_0 = ['!Ga']
    # Call the function
    var_1 = listify_lookup_plugin_terms(str_0, str_1, str_2)
    # Assertion (testing of the function output)
    assert var_0 == var_1



# Generated at 2022-06-25 13:27:26.479613
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var = listify_lookup_plugin_terms('test', 'test', 'test')
    assert var == ['test']
    var = listify_lookup_plugin_terms(['test', 'test'], 'test', 'test')
    assert var[0] == 'test'
    assert var[1] == 'test'

    var = listify_lookup_plugin_terms('test', 'test', 'test', True, True)
    assert var == ['test']
    var = listify_lookup_plugin_terms(['test', 'test'], 'test', 'test', True, True)
    assert var[0] == 'test'
    assert var[1] == 'test'


# Generated at 2022-06-25 13:27:26.882980
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# Generated at 2022-06-25 13:27:33.860004
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('!Ga', '!Ga', '!Ga') == ['!Ga']
    assert listify_lookup_plugin_terms('!Ga', '!Ga', '!Ga', False) == ['!Ga']
    assert listify_lookup_plugin_terms('!Ga', '!Ga', '!Ga', False, True) == ['!Ga']
    assert listify_lookup_plugin_terms('!Ga', '!Ga', '!Ga', True, False) == ['!Ga']
    assert listify_lookup_plugin_terms('!Ga', '!Ga', '!Ga', True, True) == ['!Ga']
    assert listify_lookup_plugin_terms([1, 2, 3], [1, 2, 3], [1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-25 13:27:52.913601
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    #assert listify_lookup_plugin_terms() == 'main-function-return-value', 'Return value expected to be <main-function-return-value>, was <{0}>'.format(listify_lookup_plugin_terms())
    #assert listify_lookup_plugin_terms() == 'main-function-return-value', 'Return value expected to be <main-function-return-value>, was <{0}>'.format(listify_lookup_plugin_terms())
    pass

# Generated at 2022-06-25 13:28:00.673986
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils import ansible_module_common; import ansible.module_utils.common.collections

    assert True == isinstance(ansible.module_utils.common.collections.Iterable, object)

    assert False == isinstance(ansible_module_common.AnsibleModule, string_types)

    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, ansible_module_common.AnsibleModule, str_0)
    var_1 = listify_lookup_plugin_terms(str_0, ansible_module_common.AnsibleModule, ansible_module_common.AnsibleModule)
    assert True == isinstance(var_0, list)
    assert True == isinstance(var_1, list)

    # assert

# Generated at 2022-06-25 13:28:01.497083
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert not False or test_case_0()

# Generated at 2022-06-25 13:28:03.996258
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # assert listify_lookup_plugin_terms(<input_param>, <input_param>, <input_param>, <input_param>, <input_param>) == <output_param>
    pass

# Generated at 2022-06-25 13:28:05.328385
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # No throw tests
    test_case_0()

# vim: expandtab:ts=4:sw=4

# Generated at 2022-06-25 13:28:06.729699
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Test function calls
test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:28:14.153343
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Case 0: no template, single value string in
    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    assert isinstance(var_0, list)
    assert var_0[0] == '!Ga'

    # Case 1: no templates, single value non-string in
    int_0 = 0
    var_1 = listify_lookup_plugin_terms(int_0, str_0, str_0)
    assert isinstance(var_1, list)
    assert var_1[0] == 0

    # Case 2: no templates, multiple value non-string in
    list_0 = [1, 2, 3]

# Generated at 2022-06-25 13:28:15.297116
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Do nothing if the test fails
    assert test_case_0() == None

# Generated at 2022-06-25 13:28:22.969840
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '!Ga'
    str_1 = 'L'
    str_2 = 'e'
    str_3 = 'S'
    str_4 = '%'
    str_5 = 'v'
    str_6 = 'b'
    str_7 = 'T'
    str_8 = '#'
    str_9 = 'U'
    str_10 = 'J'
    str_11 = 'M'
    str_12 = 'P'
    var_0 = listify_lookup_plugin_terms(str_0, str_1, str_2)
    var_1 = listify_lookup_plugin_terms(str_3, str_4, str_5)

# Generated at 2022-06-25 13:28:29.403168
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    str_1 = 'ks'
    var_1 = listify_lookup_plugin_terms(str_1, str_1, str_1)
    str_2 = 'Fi'
    var_2 = listify_lookup_plugin_terms(str_2, str_2, str_2)
    str_3 = 'm'
    var_3 = listify_lookup_plugin_terms(str_3, str_3, str_3)
    str_4 = '~'
    var_4 = listify_lookup_plugin_terms(str_4, str_4, str_4)
    str_5 = 'UT'
    var_5

# Generated at 2022-06-25 13:28:58.190994
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True == True
# end of test.py

# Generated at 2022-06-25 13:29:04.630940
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('in func: ' + __name__)

    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    print('%s should be %s' % (var_0, ['!Ga']))
    assert var_0 == ['!Ga']

    str_0 = '!Ga, !Gb'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    print('%s should be %s' % (var_0, ['!Ga', '!Gb']))
    assert var_0 == ['!Ga', '!Gb']

    str_0 = '!Ga, !Gb, !Gc'

# Generated at 2022-06-25 13:29:05.550126
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:29:13.380509
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test for 'listify_lookup_plugin_terms' function
    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    str_1 = '!Ga'
    var_1 = listify_lookup_plugin_terms(str_1, str_1, str_1)
    str_2 = '!Ga'
    var_2 = listify_lookup_plugin_terms(str_2, str_2, str_2)
    str_3 = '!Ga'
    var_3 = listify_lookup_plugin_terms(str_3, str_3, str_3)
    str_4 = '!Ga'

# Generated at 2022-06-25 13:29:18.825694
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # From test case 0
    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    assert var_0 == ['!Ga']

    # From test case 1
    str_1 = '!Ga'
    var_1 = listify_lookup_plugin_terms(str_1, str_1, str_1, fail_on_undefined=True, convert_bare=False)
    assert var_1 == ['!Ga']

# Generated at 2022-06-25 13:29:21.546167
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Unit test for function listify_lookup_plugin_terms
    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    # assert listify_lookup_plugin_terms() ==

# Generated at 2022-06-25 13:29:22.479986
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms() == 'FAIL'


# Generated at 2022-06-25 13:29:25.289117
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = 'Ga'
    str_1 = 'Fs'
    str_2 = '!N.|.vxd;i'
    assert listify_lookup_plugin_terms(str_0, str_1, str_2)



# Generated at 2022-06-25 13:29:31.365757
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = 'a!G'
    # Call listify_lookup_plugin_terms and pass in the arguments
    result = listify_lookup_plugin_terms(str_0, str_0, str_0, True, True)

    print(result)
    # Assert the result
    assert "!Ga" == result.strip()
    str_0 = '!Ga'
    # Call listify_lookup_plugin_terms and pass in the arguments
    result = listify_lookup_plugin_terms(str_0, str_0, str_0, True, True)

    print(result)
    # Assert the result
    assert "!Ga" == result.strip()


# Generated at 2022-06-25 13:29:32.612069
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Assert if the function return value matches the expected result
    assert True == isinstance(test_case_0(), list)

# Generated at 2022-06-25 13:30:47.708672
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-25 13:30:56.543953
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)
    assert var_0 == [str_0]
    str_0 = '!Ga'
    # var_1 = [(str_0,str_0,str_0)]
    # var_0 = listify_lookup_plugin_terms(var_1, str_0, str_0)
    # assert var_0 == [(str_0,str_0,str_0)]
    str_0 = '!Ga'
    var_1 = [('!Ga','!Ga','!Ga')]
    var_0 = listify_lookup_plugin_terms(var_1, str_0, str_0)

# Generated at 2022-06-25 13:30:58.429008
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Tuple with no elements
    test_case_0()

# Run test function
if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:30:59.148713
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:31:00.609955
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    #assert False # TODO: implement your test here
    assert True # TODO: implement your test here

test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:31:01.047373
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True == True

# Generated at 2022-06-25 13:31:04.105157
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('Test: listify_lookup_plugin_terms')

    str_0 = '!Ga'
    var_0 = listify_lookup_plugin_terms(str_0, str_0, str_0)

    print(var_0)
    print(type(var_0))

    if var_0 == '!Ga':
        print('success')
    else:
        print('failure')

    print('')


# Generated at 2022-06-25 13:31:12.632303
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test when no args are passed
    try:
        listify_lookup_plugin_terms()
    except TypeError as e:
        assert(e.args[0] == "takes at least 3 arguments (0 given)")

    # Test with correct args
    terms = ['file2']
    templar = 'file2'
    loader = 'file2'
    try:
        assert(listify_lookup_plugin_terms(terms, templar, loader) == terms)
    except AssertionError:
        print("Expecting:", terms)

    # Test with incorrect args - mapping value
    # Function returned wrong value

# Generated at 2022-06-25 13:31:19.830399
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:31:23.730783
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('str_var', 
        'str_var', 
        'str_var') == ['str_var']

    assert listify_lookup_plugin_terms(['str_var', 's'], 
        'str_var', 
        'str_var') == ['str_var', 's']

    assert listify_lookup_plugin_terms(['str_var', 's'], 
        'str_var', 
        'str_var') == ['str_var', 's']

    assert listify_lookup_plugin_terms([1, 's'], 
        'str_var', 
        'str_var') == [1, 's']