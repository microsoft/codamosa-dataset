

# Generated at 2022-06-25 13:24:00.314457
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == -340


# Generated at 2022-06-25 13:24:01.637836
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except:
        assert(False)

# Generated at 2022-06-25 13:24:03.478710
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 1 == 1, "Failed to assert that ListifyLookupPluginTerms()"

# Generated at 2022-06-25 13:24:07.587009
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    my_list = ['apple', 'banana', 'apple']
    assert listify_lookup_plugin_terms(my_list, 'templar', 'loader') == ['apple', 'banana', 'apple']
    assert listify_lookup_plugin_terms('my_list', 'templar', 'loader') == ['my_list']

# Generated at 2022-06-25 13:24:12.893169
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # args
    terms = None
    templar = None
    loader = None
    fail_on_undefined = True
    convert_bare = False

    # function
    # test cases
    test_case_0()

    # returns
    return True

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:22.815298
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = -7863
    var_1 = listify_lookup_plugin_terms(var_0, float, -7778)
    assert var_1 == None

    var_0 = False
    var_1 = listify_lookup_plugin_terms(var_0, float, False)
    assert var_1 == None

    var_0 = -8.747
    var_1 = listify_lookup_plugin_terms(var_0, float, False)
    assert var_1 == None

    var_0 = -4
    var_1 = listify_lookup_plugin_terms(var_0, float, float)
    assert var_1 == None

    var_0 = -3.3
    var_1 = listify_lookup_plugin_terms(var_0, float, float)
   

# Generated at 2022-06-25 13:24:26.714467
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_1 = -201
    var_2 = -90.00233480427
    var_3 = False
    var_4 = listify_lookup_plugin_terms(var_3, var_1, var_2)
    assert var_4 is False

# Test for non-numeric str value

# Generated at 2022-06-25 13:24:34.360682
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test for fixture selection
    fixture_0 = TestFixtures.fixture_3()
    fixture_1 = TestFixtures.fixture_1()
    fixture_2 = TestFixtures.fixture_2()
    fixture_3 = TestFixtures.fixture_0()
    fixture_4 = TestFixtures.fixture_4()
    fixture_5 = TestFixtures.fixture_5()

    templar_0 = fixture_5.get("templar")
    loader_0 = fixture_5.get("loader")
    bool_0 = fixture_5.get("fail_on_undefined")

    # Call function with args
    int_0 = fixture_3.get("int_0")
    float_0 = fixture_0.get("float_0")
    result = listify_lookup_plugin_terms

# Generated at 2022-06-25 13:24:39.287018
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = listify_lookup_plugin_terms(1, 1, 1)
    assert isinstance(var_0, list), 'Return type should be list'

    var_1 = listify_lookup_plugin_terms('1', 1, 1)
    assert isinstance(var_1, list), 'Return type should be list'

    var_2 = listify_lookup_plugin_terms(1, 1, 1, True)
    assert isinstance(var_2, list), 'Return type should be list'

    var_3 = listify_lookup_plugin_terms('1', 1, 1, True)
    assert isinstance(var_3, list), 'Return type should be list'

    var_4 = listify_lookup_plugin_terms(1, 1, 1, True, True)

# Generated at 2022-06-25 13:24:44.865737
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Check truth value of assert statements
    # Bool value
    assert isinstance(test_case_0(), bool)
    # Boolean value
    assert isinstance(test_case_0(), bool)
    # Float value
    assert isinstance(test_case_0(), float)
    # Integer value
    assert isinstance(test_case_0(), int)
    # Str value
    assert isinstance(test_case_0(), str)

# Generated at 2022-06-25 13:24:49.116425
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('Testing function listify_lookup_plugin_terms')
    test_case_0()

# Unit test main
if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:49.636041
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert False


# Generated at 2022-06-25 13:24:50.781523
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test for listify_lookup_plugin_terms
    test_case_0()

# Generated at 2022-06-25 13:24:59.585975
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # int() and str() for tests that require it
    import sys
    int("66")
    str("23.0")

    float("-1")
    # Test when function's return type is none
    assert type(test_case_0()) is None

    # Test with bool args
    bool_0 = True
    float_0 = 3.95
    int_0 = -1
    bool_1 = False
    bool_2 = True
    bool_3 = False
    int_1 = -0
    bool_4 = True
    bool_5 = True
    bool_6 = False
    bool_7 = True
    bool_8 = True
    int_2 = -2
    bool_9 = True
    bool_10 = True
    bool_11 = True
    bool_12 = True

# Generated at 2022-06-25 13:25:00.982476
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True
#     assert test_case_0()


# Generated at 2022-06-25 13:25:05.000032
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Testing for function listify_lookup_plugin_terms
    bool_0 = True
    float_0 = -5283.648917952431
    int_0 = -340
    var_0 = listify_lookup_plugin_terms(int_0, float_0, bool_0)

# Generated at 2022-06-25 13:25:07.507045
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == -340


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 13:25:15.724454
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    templar = {
    }
    loader = {
    }
    bool_0 = True
    float_0 = -5283.648917952431
    int_0 = -340
    var_0 = listify_lookup_plugin_terms(int_0, templar, loader)
# verify variable exists
    assert var_0 is not None
# verify variable type
    assert isinstance(var_0, list)
# verify variable length
    assert len(var_0) == 1
# verify variable value
    assert any((item == -340 for item in var_0))

# Generated at 2022-06-25 13:25:17.163262
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = listify_lookup_plugin_terms('var_0', var_0, var_0)

# Generated at 2022-06-25 13:25:19.591429
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(int_0, float_0, bool_0) == var_0

# Generated at 2022-06-25 13:25:26.665713
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import re
    int_0 = -3184
    bool_0 = True
    int_1 = -340
    float_0 = -5283.648917952431
    var_0 = listify_lookup_plugin_terms(int_1, float_0, bool_0)
    assert re.match("^(-3184)+$", str(int_0))
    assert bool_0 is True
    assert int_1 == -340
    assert re.match("^(-5283\\.64891795)+$", str(float_0))
    assert var_0 == [int_1]

# Generated at 2022-06-25 13:25:28.247135
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == " -340.0-5283.648917952431True"

# Generated at 2022-06-25 13:25:30.358680
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)
    assert isinstance(listify_lookup_plugin_terms, types.FunctionType)


# Generated at 2022-06-25 13:25:30.755609
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# Generated at 2022-06-25 13:25:31.609339
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)

# Generated at 2022-06-25 13:25:33.542792
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(int_0, float_0, bool_0) == listify_lookup_plugin_terms(int_0, float_0, bool_0)

# Generated at 2022-06-25 13:25:43.755125
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    str_0 = "fopi(543261.951907)(@b:=^(@b+1)%c0;@z:=0;@i:=0;@c:=^(@m:=8)/2;@x:=0;@y:=0;@d:=0;@a:=^(^(@m*2)*@i+@m)/2;@e:=@a;@d<@m&@i<@c0:=@e+1<@c&@x*@x+@y*@y<4?:@e+1,@d+1:";

# Generated at 2022-06-25 13:25:51.713678
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # get the function to test
    func = listify_lookup_plugin_terms
    # Test the types of the args
    arg1 =  None
    arg2 =  None
    arg3 =  None
    arg4 =  None
    arg5 =  None
    arg6 =  None
    arg7 =  None
    arg8 =  None
    arg9 =  None
    arg10 =  None
    arg11 =  None
    arg12 =  None
    arg13 =  None
    arg14 =  None
    arg15 =  None
    print(func(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15))

# Generated at 2022-06-25 13:25:52.847207
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == -340

print(test_case_0())

# Generated at 2022-06-25 13:26:02.909455
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_1 = [18, 58, 43, 25, -44]
    float_1 = -8.56
    str_0 = 'Hi'
    assert listify_lookup_plugin_terms(int_1, float_1, str_0) == [-8.56, 'Hi']

    int_2 = [5, -84, 61, -20, -70]
    float_2 = -65.07
    str_1 = 'Hello'
    assert listify_lookup_plugin_terms(int_2, float_2, str_1) == [-65.07, 'Hello']

    bool_1 = True
    float_3 = -5283.648917952431
    int_3 = -340

# Generated at 2022-06-25 13:26:19.331504
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bool_0 = True
    float_0 = -5283.648917952431
    int_0 = -340
    str_0 = "e5ahZqH|>pzUg_n9:brz('y(2eP8R)"
    var_0 = listify_lookup_plugin_terms(str_0, int_0, float_0, bool_0)
    assert var_0 == ["e5ahZqH|>pzUg_n9:brz('y(2eP8R)"]
    float_1 = -14076.838256741306
    int_1 = -83
    str_1 = "NDwJ]YhFG2#P(R]{_X:)%cq3h7p$"
    var_1 = listify

# Generated at 2022-06-25 13:26:22.543840
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Print statements for debugging
    # print('Argument 0: ' + str(arg_0))
    # print('Argument 1: ' + str(arg_1))
    # print('Argument 2: ' + str(arg_2))

    test_case_0()

# Generated at 2022-06-25 13:26:32.813640
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert isinstance(listify_lookup_plugin_terms(None, None, None), list)
    assert isinstance(listify_lookup_plugin_terms(None, None, None, fail_on_undefined=True), list)
    assert isinstance(listify_lookup_plugin_terms(None, None, None, fail_on_undefined=False), list)
    assert isinstance(listify_lookup_plugin_terms(None, None, None, fail_on_undefined=True, convert_bare=True), list)
    assert isinstance(listify_lookup_plugin_terms(None, None, None, fail_on_undefined=False, convert_bare=True), list)

# Generated at 2022-06-25 13:26:39.422601
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bool_0 = True
    float_0 = -5283.648917952431
    int_0 = -340
    var_0 = listify_lookup_plugin_terms(int_0, float_0, bool_0)
    print(var_0)
    var_1 = listify_lookup_plugin_terms(int_0, float_0, bool_0)
    print(var_1)


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:40.333565
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == 0

# Generated at 2022-06-25 13:26:41.955258
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None

# Test case for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:26:42.869011
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None

# Generated at 2022-06-25 13:26:44.445833
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert True

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:51.546474
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Setting up test values
    bool_0 = True
    bool_1 = False
    float_0 = -5283.648917952431
    float_1 = -642.415088611929
    float_2 = -6529.756616351317
    float_3 = -5790.659442474416
    float_4 = -3896.113559016012
    int_0 = -340
    int_1 = -276
    int_2 = -932
    int_3 = -359
    list_0 = [int_1, bool_1, bool_0, int_3, bool_0, bool_0, bool_1, int_2, bool_1, bool_1]

# Generated at 2022-06-25 13:27:00.456536
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = 0.9392752264847561
    str_0 = '{'
    bool_0 = True
    float_1 = 0.9392752264847561
    float_2 = 0.9392752264847561
    str_1 = '{'
    bool_1 = True
    int_0 = -137
    list_0 = listify_lookup_plugin_terms('T', str_0, float_1)
    list_1 = listify_lookup_plugin_terms(list_0, float_0, float_1)
    list_2 = listify_lookup_plugin_terms(str_1, float_2, bool_0)
    list_3 = listify_lookup_plugin_terms(['{'], float_0, bool_1)
   

# Generated at 2022-06-25 13:27:13.850087
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:27:17.469800
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))
        assert False


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:18.890050
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(int_0, float_0, bool_0) == [int_0]
# Test the module
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:27:21.753278
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test Case 0
    # Assert test case 0
    assert test_case_0()


if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:24.946406
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()
    print("tests complete")
    #print("%s %s %s %d" % (var_0, float_0, float_1, float_1))

# Generated at 2022-06-25 13:27:26.056830
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert(test_case_0() == 'fail')

# Generated at 2022-06-25 13:27:33.398453
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Assigning a Call to a Name (line 257):
    
    # Call to listify_lookup_plugin_terms(...): (line 257)
    # Processing the call arguments (line 257)
    int_1 = get_builtin_python_type_instance(stypy.reporting.localization.Localization(__file__, 257, 44), 'int')
    int_2 = get_builtin_python_type_instance(stypy.reporting.localization.Localization(__file__, 257, 47), 'int')
    # Processing the call keyword arguments (line 257)
    kwargs_3 = {}
    # Getting the type of 'listify_lookup_plugin_terms' (line 257)

# Generated at 2022-06-25 13:27:34.133923
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()



# Generated at 2022-06-25 13:27:35.764759
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('listify_lookup_plugin_terms')
    listify_lookup_plugin_terms(int_0, float_0, bool_0)

# Generated at 2022-06-25 13:27:39.477309
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        assert listify_lookup_plugin_terms.__name__ == 'listify_lookup_plugin_terms'
    except:
        print('AssertionError raised in {}'.format(__file__))
    else:
        print('Test passed in {}'.format(__file__))

# Generated at 2022-06-25 13:28:07.390017
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:28:11.259666
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except:
        print("Error!")
        raise

# Script to test all cases for functions in module
if __name__ == '__main__':
    try:
        test_listify_lookup_plugin_terms()
    except SystemExit:
        pass
    except:
        print("Unexpected error:")
        raise

# Generated at 2022-06-25 13:28:14.754808
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Make sure that the resulting value is a list
    assert isinstance(test_case_0(), list)
    assert isinstance(test_case_0(), Iterable)

    # Make sure that the resulting value is the correct size
    assert len(test_case_0()) == 1

    # Ensure the resulting value is what we expected
    assert test_case_0()[0] == -340

# Generated at 2022-06-25 13:28:22.396973
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import sys
    import inspect

    #from ansible.module_utils.six import string_types
    #from ansible.module_utils.common._collections_compat import Iterable

    # FIXME: AnsibleModule is not defined
    #module = AnsibleModule(
    #    argument_spec=dict(),
    #    supports_check_mode=False
    #)

    # FIXME: these imports don't seem to be used
    #from ansible.module_utils.facts.virtual import Virtual, virtual_facts
    #from ansible.module_utils.facts.system import System, system_facts
    #from ansible.module_utils.facts.distribution import Distribution, distribution_facts
    #from ansible.module_utils.facts.network import Network, network_facts
    #from ansible.module_utils.facts.processor

# Generated at 2022-06-25 13:28:22.940646
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == -340



# Generated at 2022-06-25 13:28:23.514024
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == True

# Generated at 2022-06-25 13:28:23.979206
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# Generated at 2022-06-25 13:28:25.543448
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)
    listify_lookup_plugin_terms()


# End generated code

# Generated at 2022-06-25 13:28:27.532385
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test the function
    test_case_0()


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:28:30.269067
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Assertions
    test_case_0()
    assert True

# Generated from test/unit/lookup/test_lookup_util.py at 2019-06-12 20:45:44.127854
# pylint: enable=line-too-long

# Generated at 2022-06-25 13:29:33.062900
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = -2.9265035281900436
    templar = -1.457959255021485
    loader = -2.4353338931964734
    fail_on_undefined = -1.9345396434632364
    convert_bare = -1.9337491524251954
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare) == [-2.9265035281900436]
test_listify_lookup_plugin_terms()

if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:29:34.158384
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == 5

test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:29:36.709949
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        assert True
    except AssertionError as e:
        print(e)
        assert False
    finally:
        print('Test executed successfully')

if __name__ == "__main__":
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:29:38.548161
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True
    # values are Boolean, float, int, string

    # Run test case
    test_case_0()

    assert True

# Generated at 2022-06-25 13:29:39.682121
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == True, "test_case_0() returned False"

# Generated at 2022-06-25 13:29:41.003378
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Unit test for listify_lookup_plugin_terms
    assert test_case_0() == False


# Generated at 2022-06-25 13:29:44.066979
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
        print('PASS: {}'.format('listify_lookup_plugin_terms'))
    except Exception as e:
        print('FAIL: {}'.format('listify_lookup_plugin_terms'))
        print(e)

# Test run
if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:29:47.239588
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = -944
    float_0 = -6339.160718775368
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(bool_0, float_0, int_0)


if __name__ == '__main__':
    test_listify_lookup_plugin_terms()
    test_case_0()

# Generated at 2022-06-25 13:29:48.182422
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() is None

# Generated at 2022-06-25 13:29:54.870202
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test case 0
    test_case_0()
    # Test case 1
    bool_0 = True
    float_0 = 0.59
    float_1 = 0.28
    int_0 = 775
    var_0 = listify_lookup_plugin_terms(float_1, int_0, float_0)
    if (((float_1 < var_0) and (var_0 <= float_0)) and (not bool_0)):
        print("Condition is True")
    else:
        print("Condition is False")
    # Output: Condition is False
    # Test case 2
    bool_0 = True
    float_0 = -1720.3392
    int_0 = -2847

# Generated at 2022-06-25 13:32:20.120466
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: Write assertion
    assert(True)

# A class for collecting functions and methods to be used as mocks
# during unittesting

# Generated at 2022-06-25 13:32:25.533324
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(bool_0, float_0, int_0) == {'int_0': 345, 'float_0': -9689.7922391157}
    assert listify_lookup_plugin_terms(var_0, float_0, bool_0) == {'bool_0': False, 'int_0': 6853, 'float_0': -1667.61914036724}
    assert listify_lookup_plugin_terms(float_0, var_0, bool_0) == {'int_0': -887, 'bool_0': False, 'float_0': 3839.81911737062}

# Generated at 2022-06-25 13:32:32.922252
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:32:39.802458
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test for function listify_lookup_plugin_terms - Example 1:
    #
    # No output specified in example so we will pass a boolean
    bool_0 = False
    #
    # Test for function listify_lookup_plugin_terms - Example 2:
    #
    # No output specified in example so we will pass a boolean
    bool_0 = False
    #
    # Test for function listify_lookup_plugin_terms - Example 3:
    #
    # No output specified in example so we will pass a boolean
    bool_0 = False
    #
    # Test for function listify_lookup_plugin_terms - Example 4:
    #
    # No output specified in example so we will pass a boolean
    bool_0 = False

# Generated at 2022-06-25 13:32:41.202604
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()
    # Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:32:42.114386
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == -340

# Generated at 2022-06-25 13:32:45.047752
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = 'cBbI'
    var_1 = True
    var_2 = 5.173905854381575
    var_3 = 85
    var_4 = listify_lookup_plugin_terms(var_0, var_3, var_2, var_1)

    assert var_4 == ['cBbI'], 'assertions failed'


# Generated at 2022-06-25 13:32:46.556325
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(int_0, float_0, bool_0) == ["-340"]

# Generated at 2022-06-25 13:32:47.703407
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)


# Generated at 2022-06-25 13:32:51.574106
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test the functional code
    test_case_0()

    # Test the type-conversion code
    int_0 = -340
    float_0 = -5283.648917952431
    bool_0 = True
    var_0 = listify_lookup_plugin_terms(int_0, float_0, bool_0)
    assert(var_0 == [-340, -5283.648917952431, True])
