

# Generated at 2022-06-25 13:24:00.937530
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert "bytes" in repr(type(test_case_0()))


if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:06.735344
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()


# Generated from the following key:
#   None;b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4';None;b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'


# Generated at 2022-06-25 13:24:07.584831
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert isinstance(test_case_0(), list)

# Generated at 2022-06-25 13:24:08.737127
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Assert if the expected result and actual result are equal
    assert test_case_0()

# Generated at 2022-06-25 13:24:18.137570
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    bytes_0 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    float_0 = None
    bytes_1 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    var_0 = listify_lookup_plugin_terms(bytes_1, bytes_0, float_0, bytes_0)
    assert var_0 == b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'

# Generated at 2022-06-25 13:24:20.440479
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test #0
    test_case_0()


if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:24:20.967680
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-25 13:24:24.142207
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Input parameters:
    #   terms:
    #   templar:
    #   loader:
    #   fail_on_undefined:
    #   convert_bare:

    # Return type:
    #   A String

    return None

# Generated at 2022-06-25 13:24:26.156823
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Assert argument types for function listify_lookup_plugin_terms
    assert isinstance(test_case_0(), list)

# Generated at 2022-06-25 13:24:30.922739
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Try function with float parameter b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4' and float parameter None and float parameter b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    test_case_0()


# Generated at 2022-06-25 13:24:37.368778
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    bytes_0 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0, bytes_0)
    assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:24:42.403315
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:24:51.203065
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    string_0 = '\x98\x95\xba\xb3\x88\x19\x14j\x85\t'
    var_0 = listify_lookup_plugin_terms(string_0, string_0, float_0, string_0)
    assert isinstance(var_0, list)
    bytes_0 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    var_1 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0, bytes_0)
    assert isinstance(var_1, list)
    list_0 = []

# Generated at 2022-06-25 13:25:00.377645
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert '\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4' == listify_lookup_plugin_terms('\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4', '\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4', None, '\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4')

# Generated at 2022-06-25 13:25:10.876937
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    int_0 = 0
    str_0 = '\x97\x97n\x9c\x19\x94.\xfc\xab\x8d\xe1\xbdg\xc7\x9b\xc5h\x81\xef\x12\xbe\x0c\xb3'
    float_0 = 0.908161891058
    bytearray_0 = bytearray(b'\x04\xea\x9e\x03\xe6\x02\x18\x90')

# Generated at 2022-06-25 13:25:12.058381
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None

# Generated at 2022-06-25 13:25:19.866332
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(None, None, None, None) == None
    assert listify_lookup_plugin_terms(None) == None
    assert listify_lookup_plugin_terms(None, None) == None
    assert listify_lookup_plugin_terms(None, None, None) == None
    assert listify_lookup_plugin_terms(None, None, None, None) == None
    assert listify_lookup_plugin_terms(None, None, None, None, None) == None
    assert listify_lookup_plugin_terms(None, None, None, None, None, None) == None
    assert listify_lookup_plugin_terms(None, None, None, None, None, None) == None

# Generated at 2022-06-25 13:25:22.681504
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:23.528956
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # noop
    pass

# Generated at 2022-06-25 13:25:31.972784
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    m_templar = Templar(loader=DataLoader(), variables=VariableManager())
    m_loader = DataLoader()

    # Test with correct arguments
    # Return value test
    assert listify_lookup_plugin_terms("", m_templar, m_loader) == []
    # Return value test
    assert listify_lookup_plugin_terms([""], m_templar, m_loader) == [""]
    # Return value test
    assert listify_lookup_plugin_terms(" ", m_templar, m_loader) == []
    # Return value test

# Generated at 2022-06-25 13:25:36.519685
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True == True
    assert True == True



# Generated at 2022-06-25 13:25:43.667533
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print('Testing function listify_lookup_plugin_terms')

    test_case_0()
    print ('\tLines executed: %d' % test_listify_lookup_plugin_terms.__dict__['line_number'])
    print ('\tCumulative tests: %d' % test_listify_lookup_plugin_terms.__dict__['total_tests'])
    print ('\tTotal lines executed: %d' % test_listify_lookup_plugin_terms.__dict__['cumulative_lines'])

# Generated at 2022-06-25 13:25:51.356966
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    bytes_0 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0, bytes_0)
    assert isinstance(var_0, list)
    assert var_0[0] == b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'


if __name__ == "__main__":
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:52.501971
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(None, None, None, None) == None



# Generated at 2022-06-25 13:25:53.108333
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-25 13:25:54.095841
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True
    # assert False, "Test failing condition"


# Generated at 2022-06-25 13:25:55.967428
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except Exception:
        assert False, 'Unhandled Exception'

# Generated at 2022-06-25 13:26:05.594716
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test the case where the first argument is None
    float_0 = None
    assert listify_lookup_plugin_terms(None, float_0, float_0, float_0) == [None]

    # Test when a list of strings is passed in
    assert listify_lookup_plugin_terms(['abc', 'def', 'ghi'], float_0, float_0, float_0) == ['abc', 'def', 'ghi']

    # Test when a list of numbers is passed in
    assert listify_lookup_plugin_terms([123, 456, 789], float_0, float_0, float_0) == [123, 456, 789]

    # Test when a string is passed in

# Generated at 2022-06-25 13:26:14.182991
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print()
    print('CODE TO TEST:')
    print('listify_lookup_plugin_terms(bytes_0, bytes_0, float_0, bytes_0)')

    print()
    print('PARAMS FROM FUNCTION CALL:')
    print('bytes_0 = ', bytes_0)
    print('bytes_0 = ', bytes_0)
    print('float_0 = ', float_0)
    print('bytes_0 = ', bytes_0)

    print()
    print('EXPECTED RESULTS:')
    print('var_0 = ', var_0)

    print()
    print('RETURNED RESULTS:')
    print('var_0 = ', var_0)
    print('Test case 0 passed:')


# Generated at 2022-06-25 13:26:15.078791
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert test_case_0() == 'PASS'

# Generated at 2022-06-25 13:26:22.487581
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:29.650918
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = '0'
    var_1 = True
    var_2 = '0'
    var_3 = '0'
    var_4 = True
    var_5 = '0'
    var_6 = '0'
    var_7 = True
    var_8 = '0'
    var_9 = True
    var_10 = '0'
    var_11 = True
    var_12 = '0'
    var_13 = True
    var_14 = '0'
    var_15 = True
    var_16 = '0'
    var_17 = True
    var_18 = '0'
    var_19 = True
    var_20 = '0'
    var_21 = True
    var_22 = '0'
    var_23 = True

# Generated at 2022-06-25 13:26:39.987171
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Function listify_lookup_plugin_terms, line 18, for 9
    float_1 = None
    var_1 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    var_2 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    var_3 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    var_4 = listify_lookup_plugin_terms(var_1, var_2, float_1, var_3)



# Generated at 2022-06-25 13:26:48.416191
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # These examples should pass with the above implemenation of listify_lookup_plugin_terms
    assert listify_lookup_plugin_terms('172.16.42.42', None, None) == ['172.16.42.42']
    assert listify_lookup_plugin_terms('{{172.16.42.42}}', None, None) == ['172.16.42.42']
    assert listify_lookup_plugin_terms(['172.16.42.42','172.16.42.43'], None, None) == ['172.16.42.42','172.16.42.43']

# Generated at 2022-06-25 13:26:50.270490
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except:
        assert False, "Unhandled exception was raised"

    assert True

# Generated at 2022-06-25 13:26:56.434435
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    bytes_0 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0, bytes_0)
    assert var_0 == [b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4']

# Generated at 2022-06-25 13:26:58.740475
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    func = listify_lookup_plugin_terms

    if isinstance(func, string_types):
        func = lambda: None

    assert func()



# Generated at 2022-06-25 13:27:02.952129
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        mutually_exclusive=[],
        required_together=[],
        required_one_of=[],
        add_file_common_args=True,
    )

    # fail the module without this test
    assert(False)


if __name__ == '__main__':
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:11.220683
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    bytes_0 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0, bytes_0)
    # assert var_0 == '1/2/3.txt'

if __name__ == '__main__':
    # print(listify_lookup_plugin_terms('{{inventory_hostname}}'))
    test_case_0()
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:12.066929
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
	test_case_0()

# Generated at 2022-06-25 13:27:27.383315
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
 
   assert test_case_0() == 'YXNpdmU6QDEyNy4wLjAuMTo2Nzgy'

# Generated at 2022-06-25 13:27:29.270692
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except NameError:
        assert False, "Unable to find a definition for 'test_case_0'"



# Generated at 2022-06-25 13:27:32.862973
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    args = [None, None, None, None]
    if test_listify_lookup_plugin_terms(*args) != 'Require 3 args ':
        print('Failed')
    else:
        print('Passed')

if __name__ == '__main__':
    import sys
    sys.exit(main())

# Generated at 2022-06-25 13:27:40.784579
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    bytes_0 = b'[\x82\xe3\xa3\xbc\xb3\xbc\xc7\x94\x9f\xd2\x9e\xe2\x15\x1b\xeb\x90\xc0\x16'
    dict_0 = dict()
    dict_0['style'] = bytes_0
    bytes_0 = b'\x1c\xee'
    dict_0['optimize'] = bytes_0
    bytes_0 = b'\x8e\x9cx\xaf\xef\xe1Y\xb2\xac\xb6&'
    dict_0['tab_width'] = bytes_0

# Generated at 2022-06-25 13:27:41.165724
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# Generated at 2022-06-25 13:27:42.388367
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert type(listify_lookup_plugin_terms(int, float, float, float)) == list

# Generated at 2022-06-25 13:27:51.930320
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    
    # Input parameters
    float_0 = None
    bytes_0 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    int_0 = 0
    list_0 = []
    bool_0 = False
    
    # Output parameters
    result_0 = listify_lookup_plugin_terms(int_0, bool_0, list_0, bool_0)
    assert result_0 == [0]
    
    # Output parameters
    result_1 = listify_lookup_plugin_terms(bool_0, bytes_0, list_0, bool_0)
    assert result_1 == [b'false']
    
    # Output parameters
    result_2 = listify_lookup

# Generated at 2022-06-25 13:27:59.830147
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    check_0 = None
    check_1 = '\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    check_2 = None
    check_3 = False
    check_var_0 = listify_lookup_plugin_terms(check_0, check_1, check_2, check_3)
    assert check_var_0 is None, "{} != {}".format(check_var_0, None)

    check_0 = None
    check_1 = '\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    check_2 = None
    check_3 = False
    check_var_

# Generated at 2022-06-25 13:28:07.735104
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Assigning arguments
    float_0 = None
    bytes_0 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0, bytes_0)

    # Getting the type of 'var_0' (line 80)
    var_0_type_1 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 80, 7), 'var_0')

    @norecursion
    def function_1(localization, *varargs, **kwargs):
        global module_type_store
        # Assign values to the parameters with defaults


# Generated at 2022-06-25 13:28:11.330798
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    bytes_0 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    var_0 = listify_lookup_plugin_terms(bytes_0, bytes_0, float_0, bytes_0)

# Generated at 2022-06-25 13:28:41.999861
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# Generated at 2022-06-25 13:28:46.703733
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test cases
    assert test_case_0() == (b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4', None, None, b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4')

# Generated at 2022-06-25 13:28:55.930902
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Input parameters tests
    assert test_listify_lookup_plugin_terms.func_code.co_argcount == 4

    # Define args and kwargs
    p1 = None
    p2 = None
    p3 = None
    p4 = None

    kwargs = {}
    kwargs['p1'] = p1
    kwargs['p2'] = p2
    kwargs['p3'] = p3
    kwargs['p4'] = p4

    # Call the actual function
    listify_lookup_plugin_terms(**kwargs)

    # Test output
    assert var_0 == b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'



# Generated at 2022-06-25 13:29:03.083694
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test when first argument is None
    float_0 = None

# Generated at 2022-06-25 13:29:06.781815
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping

    host = basic.AnsibleHost()
    conn = host.get_connection("local")
    loader = None
    templar = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        bypass_checks=False,
        no_log=False,
    )

    # test case 0
    result = listify_lookup_plugin_terms(
        terms=None,
        templar=templar,
        loader=loader,
        fail_on_undefined=True,
        convert_bare=False
    )
    assert isinstance(result, list)
    assert result == ["None"]

    # test case 1
    result = list

# Generated at 2022-06-25 13:29:11.584324
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    arg0 = b'[\x1a\xe2\xde\xd8]'
    arg1 = b'\x1f\xe5\x11\x04'
    arg2 = True
    arg3 = b'\xb9\x0f\x99\x8d\x1c'
    out = listify_lookup_plugin_terms(arg0, arg1, arg2, arg3)
    assert out is None



# Generated at 2022-06-25 13:29:19.644210
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = None
    int_0 = 0x8e
    bytes_0 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    str_0 = 'test_value'

# Generated at 2022-06-25 13:29:20.514876
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() is None

# Generated at 2022-06-25 13:29:27.782948
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # AssertionError: expected type is <type 'basestring'> but got <type 'float'>
    #  b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    #  b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    #  None
    #  b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
    # assert listify_lookup_plugin_terms(bytes_0, bytes_0, float_0, bytes_0)
    test_case

# Generated at 2022-06-25 13:29:28.978180
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Zero-argument test cases
    assert True == listify_lookup_plugin_terms()



# Generated at 2022-06-25 13:30:48.734846
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test for case 0
    test_case_0()
    # Test for case 1
    # test__case_0(terms, templar)



# Generated at 2022-06-25 13:30:50.072187
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
  assert(False)


# ---------------------------------------------------------

# Generated at 2022-06-25 13:30:50.750941
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-25 13:30:53.396898
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        test_case_0()
    except:
        assert False, 'Exception thrown'

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:30:54.825065
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert isinstance(listify_lookup_plugin_terms, object)

# Testing with actual and expected values

# Generated at 2022-06-25 13:31:01.776895
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    for i_0 in range(100):
        float_0 = None
        int_0 = None
        long_0 = None
        str_0 = None
        bytes_0 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
        var_0 = listify_lookup_plugin_terms(long_0, float_0, bytes_0, int_0)
        float_0 = None
        int_0 = None
        long_0 = None
        str_0 = None
        bytes_0 = b'\x9e:\x9c\xb7t4\x19\xf1\xd5\x01\x85\x94\x95s\xa4'
        var_0 = list

# Generated at 2022-06-25 13:31:10.302795
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert(listify_lookup_plugin_terms(False, False, False, False) == [False])
    assert(listify_lookup_plugin_terms('', False, False, False) == [''])
    assert(listify_lookup_plugin_terms('n2JgvN+eSVN', False, False, False) == ['n2JgvN+eSVN'])
    assert(listify_lookup_plugin_terms(u'7E<+M', False, False, False) == [u'7E<+M'])
    assert(listify_lookup_plugin_terms({}, False, False, False) == [{}])
    assert(listify_lookup_plugin_terms([], False, False, False) == [])

# Generated at 2022-06-25 13:31:12.529267
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Tests
    assert test_case_0() == None

# Unit test execution
if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:31:18.179940
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Input parameters:
    var_0 = [
        {
            'key': 'key_a',
            'value': 'value_a'
        },
        {
            'key': 'key_b',
            'value': 'value_b'
        }
    ]

    # Output:
    # expected_0 = None

    # Unit under test:

    # This is a test for #21002
    try:
        listify_lookup_plugin_terms(var_0)
    except (Exception) as e:
        raise AssertionError("Unexpected Exception: %s" % e.message)



# Generated at 2022-06-25 13:31:18.909449
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()