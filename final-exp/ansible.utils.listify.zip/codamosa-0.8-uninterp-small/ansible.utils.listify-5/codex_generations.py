

# Generated at 2022-06-25 13:24:10.417110
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    list_0 = [1333.882, 1333.882]
    float_0 = 1333.882
    var_0 = listify_lookup_plugin_terms(list_0, float_0, float_0, False)
    assert var_0 == list_0
    # AssertionError: List mismatch: expected: [1333.882, 1333.882], actual: [1333.882, 1333.882]
    list_1 = [1333.882, 1333.882]
    float_1 = 1333.882
    var_1 = listify_lookup_plugin_terms(list_1, float_1, float_1)
    assert var_1 == list_1
    # AssertionError: List mismatch: expected: [1333.882, 1333.882], actual: [1333.882

# Generated at 2022-06-25 13:24:13.203181
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Unit test for function listify_lookup_plugin_terms
    assert callable(listify_lookup_plugin_terms), "Function 'listify_lookup_plugin_terms' not found"

# Generated at 2022-06-25 13:24:19.986690
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    listify_lookup_plugin_terms(1333.882)
    listify_lookup_plugin_terms("1333.882")
    listify_lookup_plugin_terms("1333.882", "1333.882", "1333.882")
    listify_lookup_plugin_terms("1333.882", "1333.882", "1333.882", False)
    listify_lookup_plugin_terms("1333.882", "1333.882", "1333.882", False, False)

# Generated at 2022-06-25 13:24:20.841440
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None

# Generated at 2022-06-25 13:24:26.977774
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_1 = listify_lookup_plugin_terms('::', '::', '::')
    assert var_1 == ["::"]
    var_2 = listify_lookup_plugin_terms(['::'], '::', '::')
    assert var_2 == ["::"]
    var_3 = listify_lookup_plugin_terms([1, 2, 3], '::', '::')
    assert var_3 == [1, 2, 3]
    test_case_0()

# Generated at 2022-06-25 13:24:29.433347
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == {'list_0': [1333.882, 1333.882], 'float_0': 1333.882, 'var_0': [1333.882, 1333.882]}

# Generated at 2022-06-25 13:24:29.945785
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 1 == 1

# Generated at 2022-06-25 13:24:31.770357
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms("blah blah blah", 'blah blah blah', 'blah blah blah') == ['blah blah blah']

# Generated at 2022-06-25 13:24:40.866399
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test case 0 - try float
    float_0 = 1333.882
    list_0 = [float_0, float_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)
    assert var_0 == [1333.882, 1333.882]
    assert float_0 == 1333.882
    assert list_0 == [1333.882, 1333.882]
    # Test case 1 - try str
    var_1 = "Double 0"
    str_0 = "Quit 0"
    var_2 = listify_lookup_plugin_terms(var_1, var_1, var_1)
    assert var_2 == ["Double 0"]
    assert var_1 == "Double 0"

# Generated at 2022-06-25 13:24:43.726605
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Make sure that we get the expected result with the given
    # inputs
    assert listify_lookup_plugin_terms(["foo", "bar"], ["foo", "bar"], ["foo", "bar"]) == ["foo", "bar"]

# Generated at 2022-06-25 13:24:53.475505
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = listify_lookup_plugin_terms('SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS', 'SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS')
    print("var_0 = ",var_0)
    var_1 = listify_lookup_plugin_terms('SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS', 'SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS', 'SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS', 'SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS')
    print("var_1 = ",var_1)

# Generated at 2022-06-25 13:25:01.786476
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = 1635.4823
    dict_0 = {}
    dict_0['key'] = float_0
    list_0 = [dict_0, dict_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)
    assert var_0 == list_0

    dict_0 = {}
    dict_0['key'] = float_0
    list_0 = [dict_0, dict_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)
    assert var_0 == list_0


# Generated at 2022-06-25 13:25:02.662058
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() is not None

# Generated at 2022-06-25 13:25:06.395148
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = 1333.882
    list_0 = [float_0, float_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)
    assert var_0 == [float_0, float_0]

# Generated at 2022-06-25 13:25:10.056144
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(list_0, list_0, float_0) == [list_0, list_0]

# Test function call to listify_lookup_plugin_terms with the following params

# Generated at 2022-06-25 13:25:19.170782
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Testing with values
    assert listify_lookup_plugin_terms("test_string") == ['test_string']
    assert listify_lookup_plugin_terms("test_string") == ['test_string']
    assert listify_lookup_plugin_terms("test_string") == None
    assert listify_lookup_plugin_terms("test_string") == ['test_string']
    assert listify_lookup_plugin_terms("test_string") == ['test_string']
    assert listify_lookup_plugin_terms("test_string") == ['test_string']
    assert listify_lookup_plugin_terms("test_string") == ['test_string']
    assert listify_lookup_plugin_terms("test_string") == None
    # Testing with values and named arguments
    assert listify_lookup_

# Generated at 2022-06-25 13:25:19.989454
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert True

# Generated at 2022-06-25 13:25:23.728459
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = 1333.882
    list_0 = [float_0, float_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)
    assert var_0 == [1333.882, 1333.882] 



# Generated at 2022-06-25 13:25:29.320877
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print("")
    print("##### In test_listify_lookup_plugin_terms #####")

    float_0 = 1333.882
    list_0 = [float_0, float_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)

    print("type(var_0): {}".format(type(var_0)))

    assert var_0 == [1333.882, 1333.882]

# Generated at 2022-06-25 13:25:31.037452
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = 1333.882
    list_0 = [float_0, float_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)

# Generated at 2022-06-25 13:25:38.904352
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        assert(test_case_0() == None)
    except AssertionError as e:
        print('\nAssertionError:', e)
        print('[FAILED]')
    else:
        print('[PASSED]')
# ----------------------------------------------------------------------------------------------

## UnitTest
### Tests
# test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:25:42.330289
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = listify_lookup_plugin_terms("foo", "foo", "foo")
    assert isinstance(var_0, list)
    assert var_0 == ['foo']


# Generated at 2022-06-25 13:25:47.991099
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Testing with a float

    # Testing with a string
    base_string = 'i am a string'
    test_string = listify_lookup_plugin_terms(base_string, base_string, base_string)
    assert test_string == base_string

    # Testing with a list
    base_list = [1,2,3]
    test_list = listify_lookup_plugin_terms(base_list, base_list, base_list)
    assert base_list == test_list

# Generated at 2022-06-25 13:25:50.146273
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == False, "Function 'test_case_0' failed"
    #Place your functionality here, to test if function works as expected
    pass

# Generated at 2022-06-25 13:25:52.636662
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Input parameters
    #   terms
    #   templar
    #   loader
    #   fail_on_undefined=True
    #   convert_bare=False

    # Output returns
    #   terms

    # Return value

    return None

# Generated at 2022-06-25 13:25:55.535972
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    print("Test listify_lookup_plugin_terms")

    # Test cases

    # Test case 0
    test_case_0()


if __name__ == "__main__":
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:05.228738
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import random
    import ansible.module_utils.common.collections as collections

    # Testing if
    # The function listify_lookup_plugin_terms, when called with < terms >, < templar >, < loader >, < fail_on_undefined >, < convert_bare > as arguments, returns a list
    test_0 = lambda: listify_lookup_plugin_terms(collections.set("str"), collections.set("str"), collections.set("str"), True, bool("str"))

    # Testing if
    # The function listify_lookup_plugin_terms, when called with < terms >, < templar >, < loader >, < fail_on_undefined >, < convert_bare > as arguments, returns a list

# Generated at 2022-06-25 13:26:07.326501
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
   """
   Test listify_lookup_plugin_terms with param =list_0
   """
   assert listify_lookup_plugin_terms(list_0, list_0, float_0) == list_0

# Generated at 2022-06-25 13:26:08.569103
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()


if __name__ == "__main__":
    __main__()

# Generated at 2022-06-25 13:26:15.928808
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This sample data was obtained by recording the execution of the function
    # and replaying it in a test harness.
    # The harness was then modified to add test assertions.
    terms = 1333.882
    templar = 1333.882
    loader = 1333.882
    fail_on_undefined = True
    convert_bare = False

    expected_result = [ 1333.882 ]

    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)

    assert result == expected_result


# Generated at 2022-06-25 13:26:31.963928
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(['string_0'], 'string_1', 'string_2') == ['string_0']
    assert listify_lookup_plugin_terms(['string_0', 'string_1'], 'string_2', 'string_3') == ['string_0', 'string_1']
    assert listify_lookup_plugin_terms('string_4', 'string_5', 'string_6') == ['string_4']
    assert listify_lookup_plugin_terms(['string_7', 'string_8'], 'string_9', 'string_10') == ['string_7', 'string_8']

# Generated at 2022-06-25 13:26:34.021913
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0()

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:26:43.349818
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    args_list = [
        ((1333.882, 1333.882), False),
        ((1333.882, 1333.882), False),
        ((1333.882, 1333.882), False),
        ((1333.882, 1333.882), False),
        ((1333.882, 1333.882), False),
        ((1333.882, 1333.882), False),
        ((1333.882, 1333.882), False),
        ((1333.882, 1333.882), False),
        ((1333.882, 1333.882), False),
        ((1333.882, 1333.882), False),
        ((1333.882, 1333.882), False),
        ((1333.882, 1333.882), False),
    ]


# Generated at 2022-06-25 13:26:43.670199
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 0 == 0

# Generated at 2022-06-25 13:26:51.022612
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    dict_0 = {"abc": "string", "def": 123, "ghi": 4.56}
    list_0 = [1, 2, 3, [dict_0]]
    list_1 = [list_0, dict_0]
    assert listify_lookup_plugin_terms(list_1, list_0, list_0) == [list_0, dict_0]
    list_2 = []
    list_3 = [list_2, dict_0]
    assert listify_lookup_plugin_terms(list_3, list_0, list_0) == [list_2, dict_0]
    ansible_string_0 = "foobar"
    dict_1 = {"ansible_facts": {"ansible_all_ipv4_addresses": list_3}}

# Generated at 2022-06-25 13:26:54.774203
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    list_0 = [0, 0]
    float_0 = 11.0
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)
    assert float_0 in var_0
    assert not list_0 in var_0
    assert float_0 in var_0

# Generated at 2022-06-25 13:26:57.451253
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    for i in range(10):
        float_0 = listify_lookup_plugin_terms(i, i, i)
        assert float_0 == i
        assert type(float_0) is int

# Generated at 2022-06-25 13:26:58.697281
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Unit test function for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:27:03.117706
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Just a simple unit test to check the created method object
    import sys
    method_name = sys._getframe().f_code.co_name
    assert(method_name == 'listify_lookup_plugin_terms')
    assert(callable(globals()[method_name]))
    # Call the method under test and assert the results
    test_case_0()

# Base class for LookupBase

# Generated at 2022-06-25 13:27:04.146532
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:27:18.498820
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    list_0 = [None, None]
    float_0 = -650.621
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)
    assert var_0 == [None, None]

# Generated at 2022-06-25 13:27:27.085017
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common.collections import listify_lookup_plugin_terms

    # Test with float
    float_0 = 1333.882
    list_0 = [float_0, float_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)
    assert(var_0 == [1333.882, 1333.882])

    # Test with int
    int_0 = 1478
    list_0 = [int_0, int_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, int_0)
    assert(var_0 == [1478, 1478])

    # Test with string
    str_0 = "string"
    list_0 = [str_0]

# Generated at 2022-06-25 13:27:29.326856
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    var_0 = listify_lookup_plugin_terms(list_0, list_0, list_0)
    assert var_0 == list_0
    var_1 = listify_lookup_plugin_terms()
    assert var_1 is None

# Generated at 2022-06-25 13:27:31.887218
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    list_0 = [  ]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, list_0)
    assert (var_0 == list_0)


# Generated at 2022-06-25 13:27:33.363098
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # this test is not implemented as such for now, would
    # require stubbing a lot of other objects to work
    pass

# Generated at 2022-06-25 13:27:41.247939
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test with a float (should not be templated)
    # This test is okay because the float is not templated and therefore
    # is 'left alone' as a list.
    # The list is also not templated either, so that is why this is okay.
    float_0 = 1333.882
    list_0 = [float_0, float_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)

    # Test with None (should be templated)
    # This test is okay because
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)

    # Test with a string (should be templated)
    # This test is okay because
    var_0 = listify_lookup

# Generated at 2022-06-25 13:27:43.803100
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils._text import to_text
    if test_case_0():
        print("ok")


test_listify_lookup_plugin_terms()

# Generated at 2022-06-25 13:27:44.386334
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    test_case_0()

# Generated at 2022-06-25 13:27:49.444467
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test for float transition data
    float_0 = 1333.882
    list_0 = [float_0, float_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)

    # Test for list transition data
    list_0 = [list_0, list_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, list_0)

# Generated at 2022-06-25 13:27:55.651846
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Example 0
    float_0 = 1333.882
    list_0 = [float_0, float_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)
    # Example 1
    float_0 = 1333.882
    list_0 = [float_0, float_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)


# Generated at 2022-06-25 13:28:29.932455
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = 1333.882
    list_0 = [float_0, float_0]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, float_0)
    assert var_0 == [1333.882, 1333.882]
    list_1 = [2433.0, '1.025']
    var_1 = listify_lookup_plugin_terms(list_1, list_1, float_0)
    assert var_1 == [2433.0, '1.025']

# Generated at 2022-06-25 13:28:32.701902
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert [1333.882, 1333.882] == listify_lookup_plugin_terms([1333.882, 1333.882], [1333.882, 1333.882], 1333.882)

# Generated at 2022-06-25 13:28:40.303426
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test for case where terms is a string
    list_0 = ['asdf']
    var_0 = listify_lookup_plugin_terms(list_0, 'asdf', float_0)
    assert var_0 == ['asdf']

    # Test for case where terms is a string
    list_0 = ['asdf']
    var_0 = listify_lookup_plugin_terms(list_0, 'asdf', float_0)
    assert var_0 == ['asdf']

    list_0 = ['asdf']
    var_0 = listify_lookup_plugin_terms(list_0, 'asdf', float_0)
    assert var_0 == ['asdf']

    # Test for case where terms is a list
    list_0 = ['asdf', 'fdsa']
    var_0

# Generated at 2022-06-25 13:28:46.268651
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    float_0 = 1333.882
    str_0 = 'Os'
    list_0 = [float_0, float_0]
    list_1 = [float_0, float_0]
    list_2 = [float_0, float_0]
    var_1 = listify_lookup_plugin_terms(str_0, list_0, float_0)
    var_2 = listify_lookup_plugin_terms(str_0, list_1, list_2)

    assert(var_1 == var_2)

# Generated at 2022-06-25 13:28:54.935057
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Verify that the function returns the expected output
    var_0 = listify_lookup_plugin_terms(True, True, list)
    assert var_0 == [True], "The return value of listify_lookup_plugin_terms() is incorrect"

    var_1 = listify_lookup_plugin_terms('foo', ["bar", "baz"], float)
    assert var_1 == ['foo', 'foo'], "The return value of listify_lookup_plugin_terms() is incorrect"

    var_2 = listify_lookup_plugin_terms('foo', ['foo', 'foo'], list)
    assert var_2 == ['foo', 'foo'], "The return value of listify_lookup_plugin_terms() is incorrect"

# Generated at 2022-06-25 13:29:02.312705
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-25 13:29:07.206575
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    # input in the form of a list (a single value)
    terms = ["a"]
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['a']

    # input in the form of a scalar (non list)
    terms = "b"
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['b']

    # input in the form of a list of lists
    terms = "['c', 'd']"
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['c', 'd']

    # input in the form of a list of scal

# Generated at 2022-06-25 13:29:14.707524
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    var_0 = None
    var_1 = None
    def func_0():
        var_2 = None
        str_0 = 'str'

# Calling function func_0
    func_0()

# Assigning function listify_lookup_plugin_terms to 'var_1'
    var_1 = listify_lookup_plugin_terms
    str_1 = 'str'

# Call to listify_lookup_plugin_terms(...):
    var_0 = var_1(var_0, var_0, var_0, None, None)

# Assigning to 'var_0'
    var_0 = str_1

# Getting the type of 'var_0' (line 26)

# Generated at 2022-06-25 13:29:16.714530
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 1333.882 == float(listify_lookup_plugin_terms(list_0, list_0, float_0))

# Generated at 2022-06-25 13:29:23.895470
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class UnitTestTemplar(object):
        def __init__(self):
            self.test_value = None
        def template(self, terms, fail_on_undefined = True, convert_bare = False):
            if 'failing_term' in terms:
                raise Exception('failed while templating')
            return self.test_value
    class UnitTestLoader(object):
        pass
    ut_templar = UnitTestTemplar()
    ut_loader = UnitTestLoader()
    assert listify_lookup_plugin_terms(None, ut_templar, ut_loader) == None, 'Expected \'None\' but got \'%s\'' % listify_lookup_plugin_terms(None, ut_templar, ut_loader)

# Generated at 2022-06-25 13:30:41.052170
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = [1, 2, 3]
    templar = False
    loader = False
    assert listify_lookup_plugin_terms(terms, templar, loader) == [1, 2, 3]
    test_case_0()

# Generated at 2022-06-25 13:30:49.337121
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(string_types, Iterable, string_types, convert_bare=False) == string_types
    assert listify_lookup_plugin_terms(Iterable, string_types, Iterable, convert_bare=False) == Iterable
    assert listify_lookup_plugin_terms(string_types, string_types, Iterable, convert_bare=False) == string_types
    assert listify_lookup_plugin_terms(Iterable, Iterable, string_types, convert_bare=False) == Iterable
    assert listify_lookup_plugin_terms(Iterable, string_types, string_types, convert_bare=False) == Iterable

# Generated at 2022-06-25 13:30:50.620901
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert test_case_0() == None
    assert 'C' == []

# Generated at 2022-06-25 13:30:53.285200
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = "{{ item }}"
    templar = "{{ item }}"
    loader = 1333.882
    assert listify_lookup_plugin_terms(terms, templar, loader)



# Generated at 2022-06-25 13:31:00.672901
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert callable(listify_lookup_plugin_terms)
    list_0 = listify_lookup_plugin_terms(list_0, list_0, list_0)
    list_1 = listify_lookup_plugin_terms(list_0, list_0, list_0)
    list_2 = listify_lookup_plugin_terms(list_0, list_0, list_0)
    list_3 = listify_lookup_plugin_terms(list_0, list_0, list_0)
    list_4 = listify_lookup_plugin_terms(list_0, list_0, list_0)
    list_5 = listify_lookup_plugin_terms(list_0, list_0, list_0)

# Generated at 2022-06-25 13:31:09.576400
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    list_1 = [1, 2]
    var_1 = listify_lookup_plugin_terms(list_1, list_1, 1)
    assert var_1 == list_1

    str_0 = "str"
    list_2 = [str_0]
    var_2 = listify_lookup_plugin_terms(list_2, list_2, str_0)
    assert var_2 == list_2

    str_1 = "str_1"
    var_3 = listify_lookup_plugin_terms(str_1, str_1, 1)
    assert isinstance(var_3, list)
    assert var_3[0] == str_1

    list_3 = [1, 2, 3]

# Generated at 2022-06-25 13:31:12.114221
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    list_0 = [1333.882, 1333.882]
    var_0 = listify_lookup_plugin_terms(list_0, list_0, 1333.882)



# Generated at 2022-06-25 13:31:19.362635
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    list_0 = ['str_0', 'str_0']
    var_0 = listify_lookup_plugin_terms(list_0, list_0, list_0)
    assert len(var_0) == 2
    assert var_0[0] == 'str_0'
    assert var_0[1] == 'str_0'
    list_1 = [1333.882, 1333.882]
    var_1 = listify_lookup_plugin_terms(list_1, list_1, list_1)
    assert len(var_1) == 2
    assert var_1[0] == 1333.882
    assert var_1[1] == 1333.882
    list_2 = ['str_0']

# Generated at 2022-06-25 13:31:22.032194
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert 1333.882 == listify_lookup_plugin_terms(1333.882, 1333.882, 1333.882)
    assert ['foo', 'bar'] == listify_lookup_plugin_terms('foo,bar', 'foo,bar', 'foo,bar')
    assert ['foo', 'bar'] == listify_lookup_plugin_terms(['foo', 'bar'], ['foo', 'bar'], ['foo', 'bar'])

# Generated at 2022-06-25 13:31:23.443513
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(list_0,list_0,float_0) == var_0