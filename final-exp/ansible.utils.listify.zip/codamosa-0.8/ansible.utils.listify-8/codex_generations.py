

# Generated at 2022-06-11 18:10:37.937219
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms("{{ var }}", lambda x,y: 'a') == ['a']
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], lambda x,y: ['a', 'b', 'c']) == [['a', 'b', 'c']]
    assert listify_lookup_plugin_terms("{{ var }}", lambda x,y: ['a']) == ['a']
    assert listify_lookup_plugin_terms('a', lambda x,y: 'a', None) == ['a']
    assert listify_lookup_plugin_terms('a', lambda x,y: ['a'], None) == ['a']

# Generated at 2022-06-11 18:10:45.635099
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms1 = 'a'
    terms2 = [1, 2, 3]
    terms3 = ['a', 'b', 'c']
    terms4 = {'a': 1, 'b': 2, 'c': 3}

    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms(terms1, templar) == ['a']
    assert listify_lookup_plugin_terms(terms2, templar) == [1, 2, 3]
    assert listify_lookup_plugin_terms(terms3, templar) == ['a', 'b', 'c']

# Generated at 2022-06-11 18:10:52.693164
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.parsing.yaml.objects
    from ansible.template import Templar

    facts = dict(
        ansible_ssh_host='example.com'
    )

    variable_manager = ansible.parsing.yaml.objects.AnsibleVars(loader=None, variables=facts)
    templar = Templar(loader=None, variables=variable_manager)
    assert listify_lookup_plugin_terms("{{ ansible_ssh_host }}", templar, None) == ['example.com']

# Generated at 2022-06-11 18:10:58.885515
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from jinja2 import Template
    templar = Template("{{ value }}")
    assert listify_lookup_plugin_terms("a", templar, {}) == ['a']
    assert listify_lookup_plugin_terms(['a'], templar, {}) == ['a']
    assert listify_lookup_plugin_terms(['a','b'], templar, {}) == ['a','b']

# Generated at 2022-06-11 18:11:09.006177
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.errors import AnsibleError, AnsibleUndefinedVariable, AnsibleUndefinedVariable
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    host = Host(name='fake')
    templar = Templar(loader=DataLoader(), variables={'hostvars': {'fake': {'a': 1, 'b': 2}}})

    # string_type
    for term in ['a', '10', '"a"', '"10"', 'a.b', 'a.b.c']:
        assert listify_lookup_plugin_terms(term, templar, DataLoader()) == templar.template(term)

    # int_type

# Generated at 2022-06-11 18:11:16.651057
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Tests for simple string values
    assert(listify_lookup_plugin_terms("string", Templar({})) == ["string"])
    assert(listify_lookup_plugin_terms("CSV:one,two,three", Templar({})) == ["one", "two", "three"])

    # Tests for lists, dicts, and other iterables
    assert(listify_lookup_plugin_terms([0, 1, 2], Templar({})) == [0, 1, 2])
    assert(listify_lookup_plugin_terms({"key": "value"}, Templar({})) == [{"key": "value"}])
    assert(listify_lookup_plugin_terms((0, 1, 2), Templar({})) == [0, 1, 2])

# Generated at 2022-06-11 18:11:27.780761
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    test_string = '''{{ lookup('template', 'test_templates/lookup_plugin_test1.j2') }}'''
    test_list = '''[{{ lookup('template', 'test_templates/lookup_plugin_test1.j2') }}]'''
    test_dict = '''{ "key": "{{ lookup('template', 'test_templates/lookup_plugin_test1.j2') }}"}'''
    test_list_of_dicts = '''[ { "key1": "{{ lookup('template', 'test_templates/lookup_plugin_test1.j2') }}" }, { "key2": "{{ lookup('template', 'test_templates/lookup_plugin_test1.j2') }}" } ]'''
    test_string

# Generated at 2022-06-11 18:11:38.345409
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Basic unit test for string and list
    assert listify_lookup_plugin_terms('str', None) == ['str']
    assert listify_lookup_plugin_terms(['list'], None) == ['list']

    # Unit test for string and list with templar
    assert listify_lookup_plugin_terms('{{var}}', Templar,
                                       VariableManager(loader=None, variables={'var':'templar'}),
                                       fail_on_undefined=True) == ['templar']

# Generated at 2022-06-11 18:11:48.675966
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms(1, templar, None) == [1]
    assert listify_lookup_plugin_terms([1, 2], templar, None) == [1, 2]
    assert listify_lookup_plugin_terms((1, 2), templar, None) == [1, 2]
    assert listify_lookup_plugin_terms('stuff', templar, None) == ['stuff']
    assert listify_lookup_plugin_terms('{{ a }}', templar, None, fail_on_undefined=False) == ['{{ a }}']
    assert listify_lookup_plugin_terms('{{ a }}', templar, None) == ['{{ a }}']



# Generated at 2022-06-11 18:11:54.700652
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This should be removed when we have automated tests.
    import os
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # test for simple list with string
    terms = "1, 2, 3"
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['1', '2', '3']

    # test for simple list with integer
    terms = 1, 2, 3
    assert listify_lookup_plugin_terms(terms, templar, loader) == [1, 2, 3]

    # test for unicode in list with string
    terms = "1, ä, 3"

# Generated at 2022-06-11 18:12:06.260769
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    templar = Templar(loader=None)

    # We don't have a real loader so we have to hack in the vars ourselves.
    templar._available_variables = dict(foo='bar', password=AnsibleVaultEncryptedUnicode('foo'))


    assert listify_lookup_plugin_terms('foo', templar, loader=None, convert_bare=False) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader=None, convert_bare=False) == ['foo']

# Generated at 2022-06-11 18:12:14.067949
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test single string
    # test dictionary
    # test list
    # test bare yaml
    # test literal
    # fail on undefined

    assert listify_lookup_plugin_terms('an_item', templar, loader) == ['an_item']
    assert listify_lookup_plugin_terms({'a': 'b'}, templar, loader) == [{'a': 'b'}]

# Generated at 2022-06-11 18:12:21.944892
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    vault = VaultLib([])
    templar = Templar(loader=None, variables={}, vault_secrets=vault)

    assert listify_lookup_plugin_terms(terms=['foo'], templar=templar) == ['foo']
    assert listify_lookup_plugin_terms(terms='{{ foo }}', templar=templar) == [UnsafeProxy('foo')]
    assert listify_lookup_plugin_terms(terms=42, templar=templar) == [42]

# Generated at 2022-06-11 18:12:33.774631
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'a': '1', 'b':'2'})
    assert listify_lookup_plugin_terms(terms=[1,2,'a', 'b', '{{a}}', '{{b}}'], templar=templar, loader=None) == [1,2,'a', 'b', '1', '2']
    assert listify_lookup_plugin_terms(terms=[1,2,'a', 'b', '{{a}}', '{{b}}'], templar=templar, loader=None, convert_bare=True) == [1,2,'a', 'b', 1, 2]

# Generated at 2022-06-11 18:12:41.586366
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import yaml

    loader = DataLoader()
    vault_pass = 'secret'
    vault_secret_file = os.path.realpath(os.path.join(os.path.dirname(__file__), 'vault_password.py'))
    vault_secrets = {'password': vault_pass, 'secret_file': vault_secret_file}


# Generated at 2022-06-11 18:12:51.673645
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
  from ansible.module_utils.template import Templar
  from ansible.parsing.dataloader import DataLoader

  string = '{{foo}}, {{bar}}'
  string2 = '{{foo}}'

  templar = Templar(DataLoader())

  # assert fail_on_undefined
  # assert convert_bare
  assert [{u'bar': u'Bar', u'foo': u'Foo'}] == listify_lookup_plugin_terms(string, templar, DataLoader(), convert_bare=True)
  assert [u'{{foo}}'] == listify_lookup_plugin_terms(string2, templar, DataLoader(), convert_bare=True)

  assert [{u'bar': u'Bar', u'foo': u'Foo'}] == listify_lookup_plugin

# Generated at 2022-06-11 18:13:02.237198
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.lookup.plugins.template import listify_lookup_plugin_terms
    assert listify_lookup_plugin_terms('foo', None, None, fail_on_undefined=True, convert_bare=False) == ['foo']
    assert listify_lookup_plugin_terms('foo, bar', None, None, fail_on_undefined=True) == ['foo, bar']
    assert listify_lookup_plugin_terms(['foo'], None, None, fail_on_undefined=True) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None, fail_on_undefined=True) == ['foo', 'bar']

# Generated at 2022-06-11 18:13:12.633192
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    class FakeVarManager(object):
        def __init__(self, var=None):
            self.vars = var

    class FakeLoader(object):
        def __init__(self, path_collection=None):
            self.path_collection = path_collection

    class FakeDefs(object):
        def __init__(self, vars=None):
            self.vars = vars

    import os
    import sys
    import json
    fake_vardir  = os.path.join(os.path.dirname(sys.modules[__name__].__file__), 'fixtures')
    fake_pathdir = os.path.join(os.path.dirname(sys.modules[__name__].__file__), 'fixtures', 'file')

    fake_var = Fake

# Generated at 2022-06-11 18:13:22.786373
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.template
    import ansible.playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class TestTemplar(object):
        def __init__(self):
            self.available_variables = {}
            self.template_ds = None

        def set_available_variables(self, variables):
            self.available_variables = variables

        def template(self, data, convert_bare=False, fail_on_undefined=True):
            return ansible.template.template_from_string(self, data, self.available_variables)

    class TestLoader(object):
        def __init__(self):
            self.basedir = None


# Generated at 2022-06-11 18:13:34.452559
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' Unit test for function listify_lookup_plugin_terms '''

    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    test = 'foo'
    terms = listify_lookup_plugin_terms(test, Templar({},None), None, fail_on_undefined=False, convert_bare=False)
    assert terms == [test]

    test = 1
    terms = listify_lookup_plugin_terms(test, Templar({},None), None, fail_on_undefined=False, convert_bare=False)
    assert terms == [test]

    test = 1.0
    terms = listify_lookup_plugin_terms(test, Templar({},None), None, fail_on_undefined=False, convert_bare=False)

# Generated at 2022-06-11 18:13:46.800107
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # setup
    import ansible.template
    templar = ansible.template.Templar(loader=None)

    # tests
    assert listify_lookup_plugin_terms('a', templar, None) == ['a']
    assert listify_lookup_plugin_terms(['a'], templar, None) == ['a']
    assert listify_lookup_plugin_terms('{{foo}}', templar, None) == ['{{foo}}']
    assert listify_lookup_plugin_terms(['{{foo}}'], templar, None) == ['{{foo}}']
    assert listify_lookup_plugin_terms(['{{foo}}', '{{bar}}'], templar, None) == ['{{foo}}', '{{bar}}']

# Generated at 2022-06-11 18:13:55.630421
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.loader import lookup_loader
    from jinja2 import Template
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dataloader import DataLoader

    v = VaultLib(password_file='test/ansible-vault/test.vault-password')
    t = Templar(loader=DataLoader(), variables={})

    test_terms =[
        '{{ var }}',
        ['{{ var }}', '{{ var2 }}'],
        'foo',
        ['foo', 'bar']
    ]


# Generated at 2022-06-11 18:14:05.434809
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.loader import lookup_loader

    fake_loader = DictDataLoader({})
    my_vars = DictData({u'foo': u'bar'})
    fake_templar = Templar(loader=fake_loader, variables=my_vars)

    assert listify_lookup_plugin_terms([u'foo'], fake_templar, fake_loader) == [u'foo']
    assert listify_lookup_plugin_terms([AnsibleUnicode(u'foo')], fake_templar, fake_loader) == [u'foo']

# Generated at 2022-06-11 18:14:17.413756
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    vault_pass = 'dummy'
    vault_secrets = {'vault_password_file': vault_pass }
    loader, inventory, variable_manager = FakeAnsibleModule.setup()
    variable_manager.extra_vars = { 'vault_password': vault_pass }
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=None, include_deprecated=True), vault_secrets=vault_secrets)

    # string_types
    test_str = '/file/{{ var1 }}/{{ var2 }}/file'
    test_vars = {'var1': 'test1', 'var2': 'test1'}
    variable_manager.extra_v

# Generated at 2022-06-11 18:14:25.373264
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    variable_manager = VariableManager()

    t = variable_manager.get_vars(loader=dataloader, cache=False, include_cache=False)
    t = variable_manager.template_class(source='{{ [1, 2] + [3] | list }}',
        variables=t,
        loader=dataloader,
        fail_on_undefined=True)
    assert listify_lookup_plugin_terms(t.template(), variable_manager) == [1,2,3]
    assert listify_lookup_plugin_terms(t.template()[0], variable_manager) == 1

    t = variable_manager.get_vars

# Generated at 2022-06-11 18:14:33.571369
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from jinja2 import Template

    class DummyTemplar():
        def template(self, data, convert_bare=False, fail_on_undefined=True):
            return Template(data).render(myvar='hello world')

    class DummyLoader():
        def path_dwim(self, data):
            return '/home/mdehaan/repos/ansible/plugins/lookup/%s' % str(data)

    templar = DummyTemplar()
    loader = DummyLoader()

    # Test that terms are returned as a list if they're a string
    terms = '{{ foo }}'
    assert isinstance(listify_lookup_plugin_terms(terms, templar, loader), list)

    # Test that terms are returned as a list if they're a string and templated
   

# Generated at 2022-06-11 18:14:42.299324
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence

    # FIXME: this test is broken a value of 1 is currently being passed to templates.template to
    # avoid crashing, due to the below bugs.  The function should be taking a variable and not a raw 1
    # 1 is an invalid fail_on_undefined for string's ansible.module_utils.common.is_unicode_string

    class TestVarsModule:
        def __init__(self, vars_dict):
            self.vars_dict = vars_dict

        def __getattr__(self, name):
            return self.vars_dict[name]

    class TestMockTemplar:
        def __init__(self, lookup_vars):
            self.lookup_vars = lookup

# Generated at 2022-06-11 18:14:42.938957
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-11 18:14:54.134596
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    def run(terms, result):
        assert lu.listify_lookup_plugin_terms(terms, fake_templar, fake_loader) == result

    # Tests for string template
    fake_templar = FakeTemplar()
    fake_loader = FakeLoader()
    lu = LookupModule()

    run(terms=None, result=['None'])
    run(terms='', result=[''])
    run(terms='a', result=['a'])
    run(terms='{{ a }}', result=['a'])
    run(terms='{{ a.b }}', result=['a'])
    # FIXME: the following test should fail; see also #23367
    run(terms='{{ a.b }}', result=['a'])

# Generated at 2022-06-11 18:15:05.813258
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play

    host = Host(name="127.0.0.1")
    group = host.get_group('all')
    play = Play().load({}, variable_manager=VariableManager(), loader=None)
    templar = Templar(loader=None, vault_secrets=VaultLib(), variables=VariableManager(loader=None, hosts=host))

    value = ['item1', 'item2', 'item3']
    assert listify_lookup_plugin_terms(value, templar, None) == value

    value = 'item1 item2 item3'
    assert listify_lookup_

# Generated at 2022-06-11 18:15:21.960921
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # test with always_run enabled
    assert listify_lookup_plugin_terms('foo', templar, loader, fail_on_undefined=False) == ['foo']
    assert listify_lookup_plugin_terms('foo', templar, loader, fail_on_undefined=False, convert_bare=True) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader, fail_on_undefined=False) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader, fail_on_undefined=False, convert_bare=True) == ['foo']

# Generated at 2022-06-11 18:15:26.896569
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Example with Iterable and string_types
    obj1 = ['item1', 'item2', 'item3']
    obj2 = 'item1'
    assert listify_lookup_plugin_terms(obj1,None,None) == obj1
    assert listify_lookup_plugin_terms(obj2,None,None) == [obj2]

# Generated at 2022-06-11 18:15:37.601863
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_inventory('localhost,'))
    templar = Templar(loader=loader, variables=variable_manager)

    mystring = '{{ lookup("foo") }}'
    mylistofstrings = ['{{ lookup("foo") }}', '{{ lookup("bar") }}']
    mydict = {'a': '{{ lookup("foo") }}', 'b': '{{ lookup("bar") }}'}
    mylistofdicts = [{'a': '{{ lookup("foo") }}'}, {'b': '{{ lookup("bar") }}'}]
    myinteger = 42


# Generated at 2022-06-11 18:15:47.825685
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.template.safe_eval as safe_eval
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    templar = Templar(loader=None, variables=dict(foo='bar'))
    pc = PlayContext()
    templar._add_host_vars_from_cache(pc)

    def _do_test(terms, safe=True, expected_1=None, expected_2=None):
        try:
            results = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
            assert len(results) == 2
            assert results[0] == expected_1
            assert results[1] == expected_2
        except Exception as e:
            assert not safe, to

# Generated at 2022-06-11 18:15:59.063705
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.play import PlayContext

    parser = ModuleArgsParser(dict(), play=PlayContext())

    # Test recursive conversion
    test_terms = [1, 'a', ['b', ['c', [2, 3]], 4]]
    converted_terms = listify_lookup_plugin_terms(test_terms, Templar(loader=None, variables={}), parser)
    assert converted_terms == test_terms

    # Test conversion with templar
    test_terms = [1, 'a', ['b', ['c', [2, 3]], 4]]

# Generated at 2022-06-11 18:16:10.744007
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar

    # Setup the test
    class FakeVarsModule:

        def __init__(self, var_list):
            self.__dict__ = var_list

    class FakeTask:
        def __init__(self):
            self.environment = None

        def set_loader(self, var_manager):
            pass

        def set_environment(self, env):
            pass

    try:
        from ansible.vars import VariableManager
    except ImportError:
        from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    fake_task = FakeTask()

    # first test: both values are strings
    templar

# Generated at 2022-06-11 18:16:22.644649
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    class FakeVarsModule(object):

        def __init__(self):
            self.hostvars = dict(
                host1=dict(
                    foo="bar"
                ),
                host2=dict(
                    baz="bat"
                )
            )

    templar.set_available_variables(FakeVarsModule())

    assert listify_lookup_plugin_terms('{{ hostvars["host1"]["foo"] }}', templar, None) == ['bar']
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

# Generated at 2022-06-11 18:16:30.455565
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        ansible_vault='password',
        ansible_default_vault_password_file='/etc/ansible/vaultpass',
    )

    container1 = 'path/to/a/file'
    container2 = 'path/to/a/directory/'
    container3 = dict(
        foo=dict(
            bar='baz',
        ),
    )
    container4 = [
        'path/to/a/file',
        'path/to/a/directory/',
    ]
    container5 = [
        dict(
            foo=dict(
                bar='baz',
            ),
        ),
    ]

# Generated at 2022-06-11 18:16:40.678774
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms(): 
    from ansible.template import Templar
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes, to_text
    terms = "'this is a string'"
    templar = Templar(loader=None, variables={})
    list_terms = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=True, convert_bare=False)
  
    assert isinstance(list_terms, list), "Expect result to be a list but got: %s" % type(list_terms)
    assert len(list_terms) == 1
    assert list_terms[0] == 'this is a string' 

    terms = ['this is a string', 'another one', 'last']
    list_terms = list

# Generated at 2022-06-11 18:16:47.726987
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test list of strings, different forms
    terms = [
        'a, b, c',
        'a , b , c',
        'a, b ,c',
        'a ,b ,c',
    ]
    for t in listify_lookup_plugin_terms(terms):
        assert(t == u'a, b, c')
    # Test list of lists, different forms
    terms = [
        ['a', 'b', 'c'],
        ['a', 'b', 'c'],
        ['a', 'b', 'c'],
        ['a', 'b', 'c'],
    ]
    for t in listify_lookup_plugin_terms(terms):
        assert(t == u'a, b, c')

# Generated at 2022-06-11 18:17:11.983477
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar, DictData

    def term_raise_undefined(*args, **kwargs):
        raise AnsibleUndefinedVariable('')

    # no conversion, no undefined
    templar = Templar(DictData({}), fail_on_undefined=True)
    templar._available_variables = {}
    result = listify_lookup_plugin_terms('one', templar, None)
    assert result == ['one']

    # conversion, no undefined
    templar._templar__lookup_loader = None
    result = listify_lookup_plugin_terms('one', templar, None, fail_on_undefined=False, convert_bare=True)
    assert result == ['one']

    # conversion, undefined

# Generated at 2022-06-11 18:17:17.016055
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Setup
    fake_loader = DataLoader()
    fake_templar = Templar(loader=fake_loader)
    var1 = '{{ foo }}'
    var2 = '{{ foo.bar }}'
    var3 = '{{ foo["bar"]["baz"] }}'
    var4 = '{{ bar }}'
    var5 = '{{ baz }}'
    var6 = '{{ bam }}'
    var7 = '{{ bim }}'
    var8 = '{{ boom }}'
    var9 = '{{ bip }}'
    vari = '{{ bop }}'

    # Test single string in

# Generated at 2022-06-11 18:17:28.572846
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeTemplar():

        def __init__(self):
            self.loader = None
            self.fail_on_undefined = True
            self.convert_bare = False

        def template(self, terms, convert_bare=None, fail_on_undefined=None):
            return terms

    templar = FakeTemplar()

    # Test strings
    #  1. Single terms
    terms = listify_lookup_plugin_terms("abc", templar, None)
    assert terms == 'abc'
    #  2. Multiple terms
    terms = listify_lookup_plugin_terms("aaa,bbb,ccc", templar, None)
    assert terms == 'aaa,bbb,ccc'
    #  3. Multiple terms and spaces
    terms

# Generated at 2022-06-11 18:17:40.768109
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    lookup_loader = None

    templar = Templar(loader=lookup_loader, variables={})


# Generated at 2022-06-11 18:17:49.414663
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.splitter import parse_kv
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import pytest

    templar = Templar(loader=None)

    # For test_json_query
    terms = '{{ hostvar + [item1, item2] }}'
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == [('hostvar', '+'), 'item1', 'item2']

    terms = '{{ [item1, item2] }}'
    result = listify_lookup_plugin_terms(terms, templar, loader=None)

# Generated at 2022-06-11 18:18:00.283702
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader

    ds = namedtuple('ds', ('basedir',))
    ds.basedir = 'fake_dir'
    m = namedtuple('m', ('name', 'basedir'))
    m.name = 'fake'
    m.basedir = 'fake_dir'
    t = Templar(loader=DataLoader(), variables={'name': 'brad'})

    assert listify_lookup_plugin_terms([1], t, ds) == [1]
    assert listify_

# Generated at 2022-06-11 18:18:07.332719
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.set_host_variable(host='localhost', varname='var1', value='foo')
    variable_manager.set_host_variable(host='localhost', varname='var2', value='bar')
    variable_manager.set_host_variable(host='localhost', varname='var3', value=42)
    variable_manager

# Generated at 2022-06-11 18:18:15.802123
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    TEST_TEMPLATE = u"""
        {% for host in groups['some_group'] %}
            {{ hostvars[host]['some_var'] }} {{ hostvars[host]['some_other_var'] }}
        {% endfor %}"""

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(
        groups=dict(
            some_group=['foo', 'bar', 'baz']
        )
    ))
    variable_manager.set_host_variable("foo", dict(
        some_var=123
    ))
    variable_manager.set_host_variable("bar", dict(
        some_var=456
    ))
    variable_manager.set_

# Generated at 2022-06-11 18:18:25.941494
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.template import become_loader
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    templar = Templar(loader=become_loader(dataloader))

    assert listify_lookup_plugin_terms(None, templar, become_loader(dataloader)) == [None]
    assert listify_lookup_plugin_terms("a", templar, become_loader(dataloader)) == ["a"]
    assert listify_lookup_plugin_terms("a b", templar, become_loader(dataloader)) == ["a b"]

# Generated at 2022-06-11 18:18:35.834580
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test a string input and make sure it is converted to a list
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert isinstance(listify_lookup_plugin_terms('foo', templar, loader), list)

    # Test a list input and make sure it is passed through as a list

# Generated at 2022-06-11 18:19:15.233257
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(DataLoader())
    terms = '{{ foo }}'
    test_data = {
        'foo': 'bar',
        'bar': 'bam',
    }
    expected = ['bar']
    actual = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert expected == actual

# vim: set expandtab shiftwidth=4:

# Generated at 2022-06-11 18:19:24.930416
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    templar = Templar(loader=DataLoader())

    # Input: '{{ var }}'
    # Output: ['a', 'b']
    var = ['a','b']
    terms = listify_lookup_plugin_terms('{{ var }}', templar, None)
    assert terms == var

    # Input: ['a', 'b']
    # Output: ['a', 'b']
    var = ['a','b']
    terms = listify_lookup_plugin_terms(var, templar, None)
    assert terms == var

    # Input: '{{ var }}'
    # Output: ['a']
    var = 'a'

# Generated at 2022-06-11 18:19:25.695118
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-11 18:19:32.399702
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' test_listify_lookup_plugin_terms() '''
    import ansible.module_utils.common._collections_compat as collections_compat
    from ansible.parsing import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    my_vars = VariableManager()
    my_vars.extra_vars = { 'foo': 'bar' }
    loader = DataLoader()
    my_vars.loader = loader
    templar = Templar(loader=loader, variables=my_vars)

    # test: string
    terms = listify_lookup_plugin_terms('{{foo}}', templar, loader)
    assert isinstance(terms, collections_compat.list_types)
    assert len(terms) == 1
    assert terms

# Generated at 2022-06-11 18:19:43.164874
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template.template import Templar

    env = {
        'key1': ['a', 'b', 'c']
    }

    loader = DummyLoader()
    templar = Templar(loader=loader, variables=env)

    assert listify_lookup_plugin_terms('{{ key1 }}', templar, loader) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms(['{{ key1 }}'], templar, loader) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms(['{{ key1 }}', 'x', 'y'], templar, loader) == ['a', 'b', 'c', 'x', 'y']

# Generated at 2022-06-11 18:19:47.505972
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class FakeTemplar(object):
        def __init__(self, fail_on_undefined=True, convert_bare=False, variables=None):
            self._fail_on_undefined = fail_on_undefined
  

# Generated at 2022-06-11 18:19:56.639887
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    fail_on_undefined = False
    convert_bare      = False

    templar = Templar(loader=None, variables={})

    terms = 'string'
    new_terms = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    assert new_terms == ['string']
    terms = 'string'
    new_terms = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, False)
    assert new_terms == ['string']

    terms = ['item1', 'item2', 'item3']
    new_terms = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)
    assert new_

# Generated at 2022-06-11 18:20:07.019988
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''make sure listify_lookup_plugin_terms works as expected'''

    # initialize needed objects
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    t = Templar(None, loader=None)

    # test with string
    assert listify_lookup_plugin_terms('hey', t, None, True, False) == ['hey']

    # test with templatable string
    assert listify_lookup_plugin_terms('{{hey}}', t, None, True, False) == ['bar']
    assert listify_lookup_plugin_terms('{{hey}}', t, None, True, True) == ['{{hey}}']

    # test with invalid templatable string

# Generated at 2022-06-11 18:20:17.169251
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template

    templar = ansible.template.Templar()
    assert(listify_lookup_plugin_terms('hey', templar, None) == ['hey'])
    assert(listify_lookup_plugin_terms(['hey','there'], templar, None) == ['hey','there'])
    assert(listify_lookup_plugin_terms(123, templar, None) == [123])
    assert(listify_lookup_plugin_terms('{{test}}', templar, None, fail_on_undefined=False) == ['{{test}}'])
    assert(listify_lookup_plugin_terms('{{test}}', templar, None, fail_on_undefined=False) == ['{{test}}'])

# Generated at 2022-06-11 18:20:27.668864
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('tests/inventory'))
    variable_manager.extra_vars = {'foo': 'bar'}

    # Expected outputs
    expected_output_1 = ['Test1', 'Test2', 'Test3']

    # Test cases
    tests_1 = ['Test1', 'Test2', 'Test3']

    tests_2 = ['Test1', '{{ foo }}', 'Test3']

    tests_3 = ['Test1', {'var': 'Test2'}, 'Test3']
