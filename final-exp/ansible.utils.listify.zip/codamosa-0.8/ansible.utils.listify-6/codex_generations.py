

# Generated at 2022-06-11 18:10:40.408629
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.parsing.yaml

    # Test 1
    # input - string
    # output - list of strings
    templar = ansible.parsing.yaml.AnsibleTemplar()
    terms = [ 'test1', 'test2', 'test3' ]
    test1 = 'test1'
    result = listify_lookup_plugin_terms(test1, templar, None)

    success = True
    i = 0
    for term in result:
        if term != terms[i]:
            success = False
        i += 1

    if not success:
        print("ERROR: Test 1")
        print("input: " + str(test1))
        print("expected return: " + str(terms))
        print("returned: " + str(result))

    # Test 2


# Generated at 2022-06-11 18:10:51.571613
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())
    results = listify_lookup_plugin_terms(['{{item}}', 'item2'], templar=templar, loader=None, fail_on_undefined=False, convert_bare=False)
    assert results == ['foo', 'item2']
    results = listify_lookup_plugin_terms(['{{item}}', 'item2'], templar=templar, loader=None, fail_on_undefined=False, convert_bare=True)
    assert results == ['foo', 'item2']

# Generated at 2022-06-11 18:11:01.947748
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class Term:
        def __init__(self, term):
            self.term = term

        def __str__(self):
            return self.term

    class Templar:
        def template(self, data, fail_on_undefined=True, convert_bare=False):
            if isinstance(data, string_types) and data[0] == '$':
                return Term(data[1:])
            if isinstance(data, Iterable):
                new = []
                for item in data:
                    new.append(self.template(item, fail_on_undefined=fail_on_undefined, convert_bare=convert_bare))
                return new
            return data

    class Loader:
        def get_basedir(self, *args, **kwargs):
            return ''

    templar = Templar()



# Generated at 2022-06-11 18:11:12.835748
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleUndefinedVariable, AnsibleError

    loader = DataLoader()
    loader.set_basedir("/")
    templar = Templar(loader=loader, variables={})

    terms = "a"
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True)
    assert terms == result

    terms = '{{ file_name }}'
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True)
    assert terms == result

    terms = '{{ file_name }}'
    loader.set_basedir("/")

# Generated at 2022-06-11 18:11:22.704304
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.getcwd())))))))
    import ansible.utils as utils
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Declare some vars
    templar = utils.template.AnsibleTemplate(loader=utils.plugins.loader.PluginLoader())
    fail_on_undefined = True
    convert_bare = False

    # Empty lookup_plugin_terms should return empty list
    lookup_plugin_terms = ''


# Generated at 2022-06-11 18:11:29.886956
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.facts.system import Distribution
    import pytest

    terms_list_string = [
        "{{ test_var }}",
        "{{ test_var }}",
        [ "{{ test_var }}", "{{ test_var }}"]
    ]
    terms_list_list = [
        [ "{{ test_var }}", "{{ test_var }}"],
        "{{ test_var }}",
        [ "{{ test_var }}", "{{ test_var }}", "{{ test_var }}"]
    ]

# Generated at 2022-06-11 18:11:30.523087
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-11 18:11:41.533695
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    #
    # Unit test for function listify_lookup_plugin_terms
    #

    import ansible.template
    import ansible.utils.unsafe_proxy
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    from ansible.vars.unsafe_proxy import ProxyTypeError

    #
    # Test simple string inputs
    #

    templar = ansible.template. Templar(loader=None)

    assert [ "abc" ] == listify_lookup_plugin_terms("abc", templar)
    assert [ "abc" ] == listify_lookup_plugin_terms(" abc\t", templar)

# Generated at 2022-06-11 18:11:51.267730
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    variable_manager.set_inventory_variable(host=variable_manager.get_inventory_host('localhost'), varname='foo', value='bar')

    # test string term
    result = listify_lookup_plugin_terms('{{ foo }}', Templar(loader=loader, variables=variable_manager), loader)
    assert result == ['bar']

    # test non-string term

# Generated at 2022-06-11 18:11:52.173312
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO
    pass

# Generated at 2022-06-11 18:12:03.876261
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()

    assert listify_lookup_plugin_terms(
        'foo', Templar(loader=loader), loader) == ['foo']
    assert listify_lookup_plugin_terms(
        ['foo'], Templar(loader=loader), loader) == ['foo']
    assert listify_lookup_plugin_terms(
        ['foo', 'bar'], Templar(loader=loader), loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(
        {'foo', 'bar'}, Templar(loader=loader), loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(
        {'foo': 'bar'}, Templar(loader=loader), loader)

# Generated at 2022-06-11 18:12:12.877801
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        test_var=dict(a=1, b=2),
        test_list=['foo', 'bar', 'baz'],
        test_dict=dict(c=3, d=4),
    )


# Generated at 2022-06-11 18:12:21.913592
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # Create basic template with single item list
    templar = Templar(loader=None, variables={})
    terms = '{{ foobar }}'
    expected = ['foo']
    actual = listify_lookup_plugin_terms(terms, templar, loader=None, convert_bare=True)
    assert expected == actual

    # Create basic template with single string
    templar = Templar(loader=None, variables={})
    terms = '"{{ foobar }}"'
    expected = ['foo']
    actual = listify_lookup_plugin_terms(terms, templar, loader=None, convert_bare=True)
    assert expected == actual

    # Create basic template with multiple strings
    templar = Templar(loader=None, variables={})

# Generated at 2022-06-11 18:12:33.727233
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = AnsibleLoader(None, variable_manager=variable_manager)

    # make sure we can take a single string and expand it
    templar = Templar(loader=loader, variables=variable_manager.get_vars(loader=loader, play=None))
    template_expand = templar.template(u'{{ foo }}', fail_on_undefined=True)

    assert '{{ foo }}' != template_expand
    assert isinstance(template_expand, string_types)

# Generated at 2022-06-11 18:12:42.070919
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test 1: listify_lookup_plugin_terms('Hello World') should return ['Hello World']
    from ansible.template import Templar
    from ansible.module_utils.facts import get_module_facts
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    from ansible.parsing.vault import VaultLib
    vault_password = VaultLib(password='secret')
    templar = Templar(loader=None, variables={}, shared_loader_obj=None, basedir=None, vault_secrets=None)

# Generated at 2022-06-11 18:12:52.081839
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms("hello", templar, loader) == ['hello']
    assert listify_lookup_plugin_terms(["hello"], templar, loader) == ['hello']
    assert listify_lookup_plugin_terms(["hello", "world"], templar, loader) == ['hello', 'world']
    assert listify_lookup_plugin_terms("hello world", templar, loader) == ['hello world']

    assert listify_lookup_plugin_terms("{{ 'hello' }}", templar, loader) == ['hello']

# Generated at 2022-06-11 18:13:03.361405
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Make sure we have the right import paths
    import ansible.module_utils.common._collections_compat
    import ansible.module_utils.six
    import ansible.template

    # Assemble some test data
    terms = ['item1', 'item2', 'item3']
    terms_undefined = ['{{ item1 }}', '{{ item2 }}', '{{ item3 }}']
    terms_string = 'item1,item2,item3'
    templar = ansible.template.Template()

    # Test with a list of strings, which should return a list of strings
    result = listify_lookup_plugin_terms(terms, templar, False, False, False)
    # If the returned result is not a list, fail the test
    assert isinstance(result, list), "Result should be a list"


# Generated at 2022-06-11 18:13:13.130316
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.templar import MockTemplar

    terms = listify_lookup_plugin_terms(
        terms=[u'{{ foo }}', u'{{ baz }}'],
        templar=MockTemplar(loader=DictDataLoader({u'foo': u'bar', u'baz': u'{{ qux }}'})),
        loader=DictDataLoader({u'qux': u'quux'}),
        fail_on_undefined=True,
        convert_bare=False,
    )
    assert terms == [u'bar', u'quux']

# Generated at 2022-06-11 18:13:23.192406
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar

    templar = Templar()

    # Test value to be returned when input is a list
    list_input = ['one', 'two', 'three']
    list_output = listify_lookup_plugin_terms(list_input, templar, None)
    assert list_output == ['one', 'two', 'three']

    # Test value to be returned when input is a string
    str_input = 'one'
    str_output = listify_lookup_plugin_terms(str_input, templar, None)
    assert str_output == ['one']

    # Test value to be returned when input is a dict
    dict_input = {'key': 'value', 'key2': 'value2'}

# Generated at 2022-06-11 18:13:35.112025
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar()

    assert listify_lookup_plugin_terms('1', templar) == ['1']
    assert listify_lookup_plugin_terms(['1', '2'], templar) == ['1', '2']
    assert listify_lookup_plugin_terms('[1, 2]', templar) == ['1', '2']
    assert listify_lookup_plugin_terms('[1, 2]', templar, convert_bare=True) == [1, 2]
    assert listify_lookup_plugin_terms('{{ test_var }}', templar, convert_bare=True, fail_on_undefined=False) == '{{ test_var }}'

# Generated at 2022-06-11 18:13:46.721618
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    my_vars = dict(
        one=1,
        two=2,
        three=3,
        foo="bar",
        foobar="barfoo",
        dictionary=dict(
            key='value',
            list=['foobar', 'barfoo'],
            integer=42,
            boolean=False,
        )
    )

    my_loader = DictDataLoader({
        'lookup_plugins/test.tmp': '{{ dictionary.list }}'
    })

    templar = Templar(loader=my_loader, variables=my_vars)

    tests = dict(
        integer=1,
        float=2.0,
        boolean=True,
        string='string',
        list=['item1', 'item2', 'item3'],
    )



# Generated at 2022-06-11 18:13:55.604704
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    dummy_loader = None
    dummy_templar = None
    assert listify_lookup_plugin_terms(['a','b','c'],dummy_templar,dummy_loader) == ['a','b','c']
    assert listify_lookup_plugin_terms('[a,b,c]',dummy_templar,dummy_loader) == ['a','b','c']
    assert listify_lookup_plugin_terms('a,b,c',dummy_templar,dummy_loader) == ['a','b','c']
    assert listify_lookup_plugin_terms('a',dummy_templar,dummy_loader) == ['a']
    assert listify_lookup_plugin_terms([],dummy_templar,dummy_loader) == []
    assert list

# Generated at 2022-06-11 18:14:05.446058
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from units.mock.loader import DictDataLoader

    def my_template(data, fail_on_undefined=True, convert_bare=False, escape_backslashes=True, **kwargs):
        if isinstance(data, string_types):
            return data
        else:
            return data.pop()

    class MyTemplar:
        def __init__(self, loader):
            self._loader = loader
            self.template = my_template

    class MyLoader(DictDataLoader):
        def get_basedir(self, path):
            return "/"

    options = dict()

    templar = MyTemplar(MyLoader({}))

    # Return a list of strings when a string is given

# Generated at 2022-06-11 18:14:17.458692
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import os

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=InventoryManager(loader=loader, sources='localhost,'))

    variable_manager.set_inventory_sources('localhost,')
    variable_manager.extra_vars = {}

    play_context = PlayContext()

    # test with string_types
    terms = '10.1.1.1'
    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=True)
    assert listify_lookup_plugin

# Generated at 2022-06-11 18:14:25.413042
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils._text import to_native
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class UnitTestVaultAwareDumper(AnsibleDumper):
        """
        A Dumper which will avoid dumping items which include Vault secrets.
        """
        def increase_indent(self, flow=False, indentless=False):
            return super(UnitTestVaultAwareDumper, self).increase_ind

# Generated at 2022-06-11 18:14:33.574719
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    from ansible.vars.unsafe_proxy import AnsibleUnsafeVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)
    my_vars = AnsibleUnsafeVars({"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10})
    inventory = InventoryManager(loader=loader, sources='')

# Generated at 2022-06-11 18:14:42.300418
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'a': 'hello'})

    # Test simple string input
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # Test simple list input
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']

    # Test templates in list input
    assert listify_lookup_plugin_terms(['foo', '{{a}}'], templar, None) == ['foo', 'hello']

    # Test list template

# Generated at 2022-06-11 18:14:53.658029
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.module_utils._text import to_bytes

    variable_manager = VariableManager()
    terms = u"{{ foo }}"

    templar = Templar(loader=None, variables=variable_manager)

    # Check that str input returns a list
    assert isinstance(listify_lookup_plugin_terms(terms, templar, loader=None), list)

    # Check that unicode input returns a list
    assert isinstance(listify_lookup_plugin_terms(terms, templar, loader=None), list)

    # Check that list input returns a list

# Generated at 2022-06-11 18:15:05.190722
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar

    mock_loader = 'loader'
    templar = Templar(mock_loader, variables={})

    # Test string conversion
    expected = ['foo', 'bar']
    test = listify_lookup_plugin_terms('foo,bar', templar, mock_loader)
    assert test == expected

    # Test list conversion
    expected = ['foo', 'bar']
    test = listify_lookup_plugin_terms(['foo', 'bar'], templar, mock_loader)
    assert test == expected

    # Test dict conversion
    expected = [{'a': 'b'}]
    test = listify_lookup_plugin_terms({'a': 'b'}, templar, mock_loader)
    assert test == expected

# Generated at 2022-06-11 18:15:15.380897
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import pytest
    from ansible import constants as C
    from ansible.module_utils.six import text_type
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.template import Templar

    template = '{{foo}}'
    expected_results = ['bar']

    results = listify_lookup_plugin_terms(template, Templar(None, variables={'foo': 'bar'}))
    assert results == expected_results

    template = ['{{foo}}']
    expected_results = ['bar']

    results = listify_lookup_plugin_terms(template, Templar(None, variables={'foo': 'bar'}))
    assert results == expected_results


# Generated at 2022-06-11 18:15:30.480870
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = DictDataLoader({})
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(('foo',), templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms([('foo', 'bar')], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('{{["foo", "bar"]}}', templar, loader) == ['foo', 'bar']

# Generated at 2022-06-11 18:15:38.225130
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from io import StringIO
    from ansible.plugins.loader import lookup_loader

    env = {'basedir': './',
           'vars': {'var_in_vars': 'val_in_vars'},
           'tmpdir': './'}

    vars_file = StringIO('''
        ---
        var_file: val_file
        var_lookup: val_lookup
        var_in_play: val_in_play
    ''')

    # Ensure that jinja2 doesn't try to open included templates from the current working directory
    # This could happen if lookup plugins use relative paths


# Generated at 2022-06-11 18:15:48.391378
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text

    class DummyVarsModule:
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self):
            return self.vars

    class DummyTemplate:
        _available_variables = set()

        def __init__(self, module_vars):
            self._module_vars = module_vars

        def set_available_variables(self, variables):
            self._available_variables = variables

        def _templar__get_vars(self, include_hostvars=True):
            return self._available_variables


# Generated at 2022-06-11 18:15:59.315844
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import BytesIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    tests = [
        (dict(terms='foo'), ['foo']),
        (dict(terms=[1,2,3]), [1,2,3]),

        # test convert_bare
        (dict(terms='{{ foo }}', convert_bare=True), ['1']),
        (dict(terms=[1,2,3], convert_bare=True), [1,2,3]),
    ]

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': '1'}
    loader = DataLoader()

# Generated at 2022-06-11 18:16:11.023926
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.template import Templar

    terms = [u'foo', u'bar', u'baz']
    templar = Templar(loader=None)
    template_result = [u'foo', u'bar', u'baz']
    assert listify_lookup_plugin_terms(terms, templar, None) == template_result

    terms = u'foo, bar, baz'
    templar = Templar(loader=None)
    template_result = [u'foo', u'bar', u'baz']
    assert listify_lookup_plugin_terms(terms, templar, None) == template_result

    terms = [u'foo', u'{{a}}', u'baz']
    templ

# Generated at 2022-06-11 18:16:22.857004
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    loader = None
    templar = FakeTemplar()
    assert listify_lookup_plugin_terms(None, templar, loader) == [None]
    assert listify_lookup_plugin_terms('', templar, loader) == [None]
    assert listify_lookup_plugin_terms(1, templar, loader) == [1]
    assert listify_lookup_plugin_terms(['a', 1], templar, loader) == ['a', 1]
    assert listify_lookup_plugin_terms(['', 'a', 1], templar, loader) == [None, 'a', 1]

# Generated at 2022-06-11 18:16:30.567495
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # Dummy class to substitute for Runner()
    class DummyRunner:
        def __init__(self):
            pass
        def get_basedir(self, *args):
            return 'test/test_templates'

    templar = Templar(DummyRunner())

    assert listify_lookup_plugin_terms('1', templar, None) == ['1']
    assert listify_lookup_plugin_terms('1 2', templar, None) == ['1 2']
    assert listify_lookup_plugin_terms('1 2 3', templar, None) == ['1 2 3']
    assert listify_lookup_plugin_terms('1,2', templar, None) == ['1,2']

# Generated at 2022-06-11 18:16:40.894927
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # This only tests the basic functionality of this routine.
    # In particular, it does not test the templating functionality

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    terms = "foo,bar"
    context = PlayContext()
    vars = VariableManager()
    loader = None
    templar = Templar(loader=loader, variables=vars, shared_loader_obj=False)

    # test a string
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo', 'bar']

    # test a list
    terms = ['foo', 'bar']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result

# Generated at 2022-06-11 18:16:52.040733
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.template import AnsibleEnvironment
    import sys

    for terms in ['string', [1, 2, 3], 42, ['a', 'b', 'c'], [['foo', 'bar']]]:
        env = AnsibleEnvironment([], None, None)
        templar = Templar(loader=None, variables={}, environment=env)
        terms = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True)
        assert isinstance(terms, list)
        if sys.version_info < (2, 7):
            assert isinstance(iter(terms), list)
        else:
            assert isinstance(iter(terms), list)

# Generated at 2022-06-11 18:17:03.862657
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())

    assert listify_lookup_plugin_terms(terms=['foo', '{{ bar }}'], templar=templar, loader=None,
                                       fail_on_undefined=True) == ['foo', '{{ bar }}']

    assert listify_lookup_plugin_terms(terms='foo', templar=templar, loader=None, fail_on_undefined=True) == ['foo']


# Generated at 2022-06-11 18:17:27.980227
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    my_vars = dict(foo='foo', bar='bar')
    loader = DictDataLoader({'vars': my_vars})
    templar = Templar(loader=loader)

    to_list = ['foo', 'bar', '{{foo}} {{bar}}']
    expected = ['foo', 'bar', 'foo bar']
    assert listify_lookup_plugin_terms(to_list, templar) == expected

    # a non-iterable value should be wrapped in a list
    to_list = 'foo'
    expected = ['foo']
    assert listify_lookup_plugin_terms(to_list, templar) == expected

    # a non-iterable value inside a list should not be wrapped

# Generated at 2022-06-11 18:17:40.059331
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # mock jinja2 env
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader, variables=dict())

    # test non iterable item
    assert listify_lookup_plugin_terms('test', templar, loader) == ['test']

    # test iterable item
    assert listify_lookup_plugin_terms(['test', 'test2'], templar, loader) == ['test', 'test2']

    # test string with comma
    assert listify_lookup_plugin_terms('test,test2', templar, loader) == ['test', 'test2']

    # test empty string
    assert listify_look

# Generated at 2022-06-11 18:17:49.077463
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-11 18:17:59.860447
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys
    import imp
    from ansible.template import Templar

    test_dict = dict(
        ansible_system_capabilities=dict(
            network={
                "ipv4": {
                    "address": [
                        {
                            "address": "10.0.0.115",
                            "subnet": "255.255.255.0",
                        }
                    ]
                }
            }
        )
    )

    def get_terms(terms):
        templar = Templar(loader=None, variables=test_dict)
        return listify_lookup_plugin_terms(terms, templar, loader=None)

    # var is a string
    assert get_terms('ansible_system_capabilities') == get_terms(['ansible_system_capabilities'])
    # var is a

# Generated at 2022-06-11 18:18:07.224115
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # create pseudo objects to test listify_lookup_plugin_terms
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=None), shared_loader_obj=None)

    # test input(str)
    result = listify_lookup_

# Generated at 2022-06-11 18:18:15.801843
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    class DummyVaultSecret:
        def __init__(self):
            pass

        def get_decrypted_contents(self):
            return 'mysecret'

    from ansible.template.safe_eval import flags

    terms = "{{ myvar }}"
    templar = Templar(loader=None, shared_loader_obj=None, variables={'myvar':'foo'}, vault_secrets={'vault_abc': DummyVaultSecret()})
    templar._available_variables = {'myvar':'foo'}
    converted_terms = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert converted_terms == ['foo']


# Generated at 2022-06-11 18:18:25.940716
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import PY3
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    my_vars = [
        "a",
        "b",
        "c",
    ]

    variable_manager.set_available_variables(my_vars)

    templar = Templar(loader=loader, variable_manager=variable_manager)

    terms = ['{{a}}', '{{b}}', '{{c}}']
    # Test with a

# Generated at 2022-06-11 18:18:35.836184
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))

    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms([1], templar, loader) == [1]
    assert listify_lookup_plugin_terms(1, templar, loader) == [1]
    assert listify_lookup_plugin_terms('string', templar, loader) == ['string']
    assert listify_lookup_plugin_terms('string two', templar, loader) == ['string two']
    assert listify_

# Generated at 2022-06-11 18:18:47.074224
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    def assert_terms_list(terms, expected_list, templar=None, loader=None, fail_on_undefined=True, convert_bare=False):
        assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare) == expected_list

    fixture_data = {
        'a_simple_variable': "a_simple_value",
        'nested_var': {'a': 1, 'b': 2},
        'list_var': [1, 2, 3]
    }
    templar = Templar(loader=DataLoader(), variables=fixture_data)

    # input is a string

# Generated at 2022-06-11 18:18:51.361145
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert listify_lookup_plugin_terms('foo', Templar(loader=None), loader=None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], Templar(loader=None), loader=None) == ['foo', 'bar']

# Generated at 2022-06-11 18:19:26.392670
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.template.vars import VarsModule
    from ansible.module_utils._text import to_text

    templar = Templar(loader=None, variables={})
    assert to_text(listify_lookup_plugin_terms(terms='foo', templar=templar, loader=None, fail_on_undefined=True, convert_bare=False)) == ['foo']
    assert to_text(listify_lookup_plugin_terms(terms=['foo', 'bar'], templar=templar, loader=None, fail_on_undefined=True, convert_bare=False)) == ['foo', 'bar']

# Generated at 2022-06-11 18:19:36.657165
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=True)
    terms = 'foo'
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)
    assert isinstance(result, list)
    assert result == ['foo']

    terms = ['foo', 'bar', 'baz']

# Generated at 2022-06-11 18:19:46.201382
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    terms = "{{ foo }}"
    my_vars = dict(foo="one")
    templar = Templar(loader=None, variables=my_vars)
    terms = listify_lookup_plugin_terms(terms=terms, templar=templar, loader=None, fail_on_undefined=False, convert_bare=True)
    assert terms == ['one']

    terms = [ "{{ foo }}", "{{ bar }}" ]
    my_vars = dict(foo="one", bar="two")
    templar = Templar(loader=None, variables=my_vars)
    terms = listify_lookup_plugin_terms(terms=terms, templar=templar, loader=None, fail_on_undefined=False, convert_bare=True)

# Generated at 2022-06-11 18:19:55.638710
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = dict(hostvars={'host1': {'ansible_host': '127.0.0.1'}})
    variable_manager._vars_cache = variable_manager._extra_vars
    templar = Templar(loader=loader, variables=variable_manager)

    # Basic tests
    assert listify_lookup_plugin_terms('{{ a }}', templar, loader) == ["{{ a }}"]
    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader) == ["a", "b"]

    # Test

# Generated at 2022-06-11 18:20:05.053553
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    terms = 'foo'
    templar = Templar(DataLoader())
    result = listify_lookup_plugin_terms(terms, templar, DataLoader())
    assert result == ['foo']

    terms = 'foo,bar'
    templar = Templar(DataLoader())
    result = listify_lookup_plugin_terms(terms, templar, DataLoader())
    assert result == ['foo', 'bar']

    terms = ['foo', 'bar']
    templar = Templar(DataLoader())
    result = listify_lookup_plugin_terms(terms, templar, DataLoader())

# Generated at 2022-06-11 18:20:16.235870
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variable_manager=variable_manager)

    # test string with outer whitespace
    terms = 'one two    three'
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['one', 'two', 'three']

    # test string with no outer whitespace
    terms = 'one two    three'
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['one', 'two', 'three']

    # test list
    terms = ['one', 'two', 'three']
    assert listify_lookup

# Generated at 2022-06-11 18:20:21.776517
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import os

    class VarManager(object):
        def __init__(self):
            self.hostvars = dict()

    loader = DataLoader()
    templar = Templar(loader=loader, variables=dict(foo='bar'), shared_loader_obj=loader, variable_manager=VarManager())

    test_string = 'this is a string'
    assert (listify_lookup_plugin_terms(test_string, templar, loader, fail_on_undefined=True, convert_bare=False) == ['this is a string'])

# Generated at 2022-06-11 18:20:32.662359
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    class MockTemplar(Templar):
        def __init__(self, loader, variables):
            super(MockTemplar, self).__init__(loader, variables)

        def template(self, *args, **kwargs):
            return args[0]

    loader = DictDataLoader({
        "/path/to/my/file": "{foo}",
        "/other/file": "/other/file",
    })
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # tests go here
    plugin_args = '{{ foo }}'