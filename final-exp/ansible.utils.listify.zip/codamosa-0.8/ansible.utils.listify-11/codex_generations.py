

# Generated at 2022-06-11 18:10:40.481869
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.vars import VarsModule
    from ansible.errors import AnsibleError
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    templar = Templar(loader=None, variables=combine_vars(variable_manager=VariableManager(), loader=None), vault_secrets=None)
    templar._available_variables = {'x': '1', 'y': '2', 'z': '3'}
    templar.set_available_

# Generated at 2022-06-11 18:10:51.583796
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.plugins import lookup_loader

    vault_secret = VaultLib([])
    templar = Templar(loader=lookup_loader, vault_secrets=vault_secret)

    input_data = [b'a', u'b', 3, AnsibleUnicode(u'c')]
    expected_output = ['a', 'b', '3', u'c']
    actual_output = listify_lookup_plugin_terms(input_data, templar, lookup_loader)
    assert actual_output == expected_output

    input_data = 'a'
    expected_output = ['a']
    actual_output = list

# Generated at 2022-06-11 18:11:01.949577
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms(['one', 'two', 'three'], Templar(loader=None), None) == ['one', 'two', 'three']
    assert listify_lookup_plugin_terms(['one', '{{foo}}', '{{bar}}'], Templar(loader=None), None, False) == ['one', '{{foo}}', '{{bar}}']
    assert listify_lookup_plugin_terms(['one', '{{foo}}', '{{bar}}'], Templar(loader=None), None) == ['one', 'foo', 'bar']
    assert listify_lookup_plugin_terms('{{foo}}', Templar(loader=None), None) == ['foo']

# Generated at 2022-06-11 18:11:12.835872
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()

    variable_manager.set_variable('foo', u'bar')
    variable_manager.set_variable('bar', u'baz')

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test basic string
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['bar']

# Generated at 2022-06-11 18:11:22.705546
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    groups = Group()
    groups.add_host(Host(name='baz'))
    groups.add_host(Host(name='foo'))
    groups.add_host(Host(name='bar'))
    groups.add_host(Host(name='qux'))
    groups.add_host(Host(name='corge'))
    hosts = groups.get_hosts()

    vault_secrets = {}
    defaults = {}
    facts = {}
    for host in hosts:
        facts[host.name] = {}

   

# Generated at 2022-06-11 18:11:29.913010
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vault_secrets = VaultLib([])
    templar = Templar(loader=loader, shared_loader_obj=loader, vault_secrets=vault_secrets)
    def run(terms, fail_on_undefined=True, convert_bare=False):
        return listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare)

    # test strings
    assert run('foo') == ['foo']
    assert run('foo  bar baz') == ['foo  bar baz']
    assert run(' foo  bar baz ') == [' foo  bar baz ']

# Generated at 2022-06-11 18:11:40.819276
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    my_vars = dict(
        foo='bar',
        baz=[ 'qux', 'quux' ],
    )
    variable_manager.set_host_variable(host='localhost', varname='my_vars', value=my_vars)

    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-11 18:11:50.870537
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.module_utils.common._collections_compat import Mapping
    ds = {'a':'A', 'a1':'A1', 'a2':'A2', 'b':'B', 'b1':'B1', 'b2':'B2'}
    def ds_load(var_name, var_path=''):
        return ds.get(var_name)
    t = Templar(loader=None, variables=ds)
    t.set_available_variables(loader=None)
    t._ds = ds_load
    t._load_vars = ds_load
    t._ds_cache = {}
    t._ds_cache.update(ds)


# Generated at 2022-06-11 18:12:01.765218
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.templating import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Template raw string

    lookup_loader = DataLoader()
    playbook_vars = VariableManager()
    templar = Templar(loader=lookup_loader, variables=playbook_vars)
    templar._available_variables = dict(foo=1, bar=2)

    # Basics
    assert listify_lookup_plugin_terms('{{foo}}', templar, lookup_loader) == [1]
    assert listify_lookup_plugin_terms(['{{foo}}', '{{bar}}'], templar, lookup_loader) == [1, 2]

# Generated at 2022-06-11 18:12:11.777541
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from ansible.module_utils.six import StringIO

    vault_pass = StringIO("vaultpass")

    data = '''
        ---
        myvar: "hello"
    '''

# Generated at 2022-06-11 18:12:22.205173
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader, cache_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext(variables=variable_manager)
    play_context.network_os = 'ios'

    # ini_base_loader = BaseLoader(loader)

    # pretend to load the cache
    # cache_loader

# Generated at 2022-06-11 18:12:34.057700
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    templar = Templar(loader=None, shared_loader_obj=None, vault_secrets=VaultLib())

    # String
    input_terms = '1'
    expected_terms = ['1']
    actual_terms = listify_lookup_plugin_terms(input_terms, templar, loader=None)
    assert(expected_terms == actual_terms)

    # List
    input_terms = ['1','2','3','4','5','6','7','8','9','10']
    expected_terms = ['1','2','3','4','5','6','7','8','9','10']

# Generated at 2022-06-11 18:12:42.265006
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # This will be used to load templates relative to the test directory
    loader = DataLoader()

    # Setup the variable manager to load variables from the play and inventory
    variable_manager = VariableManager()

    # Initialize the templar with the variable manager
    templar = Templar(loader=loader, variables=variable_manager)

    # test listify_lookup_plugin_terms when terms is a string
    string_terms = """
        {{ item1 }}
        {{ item2 }}
    """

# Generated at 2022-06-11 18:12:49.160153
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Test with a list
    terms = [ 'a', 'b' ]
    templar = Templar(loader=None)
    result = listify_lookup_plugin_terms(terms, templar, loader=None)

    assert result == terms

    # Test with a string
    terms = 'a,b'
    result = listify_lookup_plugin_terms(terms, templar, loader=None)

    assert result == [ 'a', 'b' ]

# Generated at 2022-06-11 18:12:56.362523
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None, variables=combine_vars(loader=None, variables=None))

    terms = '{{ val1 }}'
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(terms[0], AnsibleUnicode)

    terms = '{{ val1 }}{{ val2 }}'
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(terms[0], AnsibleUnicode)

    terms = ['{{ val1 }}', '{{ val2 }}']
    terms = listify_lookup_plugin

# Generated at 2022-06-11 18:13:05.315660
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    # Setup for the tests
    templar = Templar(loader=None)

    # Test string value
    term = "{{ inventory_hostname }}"
    assert templar.template(term) == AnsibleUnsafeText(u"{{ inventory_hostname }}")

    # String to list
    assert templar.template(term, convert_bare=True) == AnsibleUnsafeText(u"{{ inventory_hostname }}")
    assert listify_lookup_plugin_terms(term, templar, None, convert_bare=True) == [AnsibleUnsafeText(u'{{ inventory_hostname }}')]

    # Template list value
    term = "{{ my_var }}"
    templar._available

# Generated at 2022-06-11 18:13:15.973398
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.errors import AnsibleError

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    from ansible.plugins import lookup_loader

    loader = lookup_loader.get(None)

    p = PlayContext()

    # empty
    assert listify_lookup_plugin_terms(None, Templar(play_context=p, loader=loader, vault_secrets=VaultLib()), loader) == [None]

    # convert_bare not set, should fail

# Generated at 2022-06-11 18:13:25.142679
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import os
    import yaml
    from collections import namedtuple

    DummyVaultSecret = namedtuple('DummyVaultSecret', ['id', 'password'])
    vault_secrets = [DummyVaultSecret(1, 'vault_password')]
    vault_password_files = [os.path.join(os.path.dirname(__file__), 'vault_password.txt')]

    # a non-iterable term should be made iterable
    term = '{{ foo }}'
    templar = Templar(loader=None, variables={'foo': 'bar'})

# Generated at 2022-06-11 18:13:35.735777
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    templar = Templar(None, None)

    # the only thing that can cause failures are strings, so not much to test here
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo'], 'failed with string'
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo'], 'failed with list'
    assert listify_lookup_plugin_terms(AnsibleUnicode(u'foo'), templar, None) == ['foo'], 'failed with unicode'

# Generated at 2022-06-11 18:13:41.150962
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Pass a list to listify_lookup_plugin_terms
    assert listify_lookup_plugin_terms(['one', 'two', 'three'], None, None) == \
        ['one', 'two', 'three']
    # Pass a string to listify_lookup_plugin_terms
    assert listify_lookup_plugin_terms('one,two,three', None, None) == \
        ['one', 'two', 'three']
    # Pass a string with spaces to listify_lookup_plugin_terms
    assert listify_lookup_plugin_terms('one two three', None, None) == \
        ['one two three']

# Generated at 2022-06-11 18:13:53.089186
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.module_utils.common.lookup_plugins_common

    loader = ansible.module_utils.common.lookup_plugins_common.LookupModule({}, basedir='.')
    templar = loader.environment.loader.get_basedir()
    terms = [
        ('foo', ['foo']),
        (['foo'], ['foo']),
        ({'foo': 'bar'}, ['{foo=bar}']),
        (1, ['1'])]

    for string, result in terms:
        if listify_lookup_plugin_terms(string, templar, loader) != result:
            raise AssertionError("Failed to assert that %s yields %s." % (string, result))

# Generated at 2022-06-11 18:14:03.325645
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # has to be a function so that the import can be mocked
    import ansible.utils.plugin_docs
    from ansible.template import Templar

    # this needs to be mocked as it is an external import
    ansible.utils.plugin_docs.get_docstring = lambda self: "dummy"

    templar = Templar(loader=None)
    terms = ['foo', 'bar', 'baz']

    # test with ansible templar
    # we do not test the content, because the templar is mocked and thus the results are not valid
    terms_templated1 = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert isinstance(terms_templated1, list)
    assert len(terms_templated1) == 3

    # test with ansible template and convert

# Generated at 2022-06-11 18:14:10.726450
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'inventory_hostname': 'foo'}
    variable_manager.set_inventory(loader.load_from_source("""
        [test_group]
        foo
        [test_host]
        foo
    """))
    templar = Templar(loader=loader, variable_manager=variable_manager)

    assert listify_lookup_plugin_terms("{{inventory_hostname}}", templar, loader) == ['foo']
    assert listify_lookup_plugin_terms("{{inventory_hostname}}", templar, loader, convert_bare=True)

# Generated at 2022-06-11 18:14:17.545372
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = [
        "a",
        "b",
        "{{ x }}",
        "{{ y }}",
        "{{ z }}",
    ]

    templar = Templar(loader=None, variables=dict(x=1, y=2))

    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == [ 'a', 'b', 1, 2, '{{ z }}' ]

# Generated at 2022-06-11 18:14:26.427446
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    vars = {
        'a': 'a',
        'b': 'b',
        'c': 'c',
    }

    class TestVarsModule(object):
        def vars(self):
            return vars

    loader = DictDataLoader()
    templar = Templar(loader=loader, variables=vars)

    terms = "{{a}} {{b}}"
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['a', 'b']

    terms = "{{a}} {{b}}|int"
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['a', 'b']

    terms = ["{{a}}", "{{b}}"]
    terms

# Generated at 2022-06-11 18:14:35.489207
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    templar = Templar(None, None, loader=None, variable_manager=VariableManager())
    assert listify_lookup_plugin_terms(['1','2','3'], templar, None) == ['1','2','3']
    # failing variable lookup
    assert listify_lookup_plugin_terms(['{{ foo }}','{{ bar }}'], templar, None) == ['{{ foo }}','{{ bar }}']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None) == ['{{ foo }}']
    # string with given separator
    assert listify_lookup_plugin_terms('1,2,3', templar, None) == ['1','2','3']
    assert listify_look

# Generated at 2022-06-11 18:14:43.566442
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # simple string term
    term = "abc123"

    templar = Templar(loader=None)

    # simple string term
    result = listify_lookup_plugin_terms(term, templar, None)
    assert result == ["abc123"]

    # simple unicode term
    term = AnsibleUnicode("あいうえお")

    # simple unicode term
    result = listify_lookup_plugin_terms(term, templar, None)
    assert [item for item in result] == [AnsibleUnicode("あいうえお")]

    # unicode templated string

# Generated at 2022-06-11 18:14:53.178620
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    templar = FakeTemplar()
    args = ['{{foo}}', '{{bar}}']
    terms = listify_lookup_plugin_terms(args, templar, FakeLoader())
    assert(terms == ['cat', 'dog'])
    args = ['foo', 'bar']
    terms = listify_lookup_plugin_terms(args, templar, FakeLoader(), convert_bare=True)
    assert(terms == ['cat', 'dog'])
    args = 'foo'
    terms = listify_lookup_plugin_terms(args, templar, FakeLoader(), convert_bare=True)
    assert(terms == ['cat'])



# Generated at 2022-06-11 18:15:05.215348
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    t = Templar(None, loader=None)

    # Test a non-templated string
    assert listify_lookup_plugin_terms("foo", t, None) == ["foo"]

    # Test a templated string
    assert listify_lookup_plugin_terms("{{var1}}", t, None, convert_bare=True) == ["{{var1}}"]
    t.vars = dict(var1="bar")
    assert listify_lookup_plugin_terms("{{var1}}", t, None, convert_bare=True) == ["bar"]

    # Test a non-templated list

# Generated at 2022-06-11 18:15:15.417972
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.module_utils.common._collections_compat import Mapping

    templar = Templar(None, loader=None)
    # test string
    assert listify_lookup_plugin_terms('"a"', templar) == ['a']
    assert listify_lookup_plugin_terms("'b'", templar) == ['b']
    assert listify_lookup_plugin_terms("'c,d,e'", templar) == ['c,d,e']
    assert listify_lookup_plugin_terms('"abc"  "def"', templar) == ['abc', 'def']

# Generated at 2022-06-11 18:15:28.862587
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    terms = "{{ 'item1' }}"
    fail_on_undefined = True
    expected = ['item1']
    actual = listify_lookup_plugin_terms(terms, Mapping(), Mapping(), fail_on_undefined=fail_on_undefined)
    assert actual == expected
    terms = ['{{ item1 }}', '{{ item2 }}']
    expected = ['item1', 'item2']
    actual = listify_lookup_plugin_terms(terms, Mapping(), Mapping(), fail_on_undefined=fail_on_undefined)
    assert actual == expected
    terms = {'{{ item1 }}': '{{ item2 }}'}
    expected = [{'item1': 'item2'}]

# Generated at 2022-06-11 18:15:38.019252
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # List
    terms = [1, 2, 3]
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == [1, 2, 3]

    # String
    terms = "amg"
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ["amg"]

    # Bare String
    terms = "{{ amg }}"
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ["amg"]

    # Template

# Generated at 2022-06-11 18:15:48.353094
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib
    import yaml

    yaml_str = """
key1: '{{ foo }}'
key2: '{{ item }}'
    """

    my_vars = {'foo': 'bar', 'item': 'baz'}

    # Initialize templar
    loader = None
    my_vars = combine_vars(loader=loader, variables=my_vars)
    vault_secrets = dict(vault_pass='secret')
    vault = VaultLib(vault_secrets)
    templar = Templar(loader=loader, variables=my_vars, vault_secrets=vault_secrets)


# Generated at 2022-06-11 18:15:50.143291
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: unit test for function listify_lookup_plugin_terms
    pass

# Generated at 2022-06-11 18:16:00.338625
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class DummyVars(dict):
        def get_vars(self, loader, play, include_hostvars=False):
            return self

    templar = Templar(loader, variable_manager=VariableManager(loader=loader, variables=DummyVars({'foo': 'bar'})))
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['bar']
    assert listify_lookup_plugin_terms(['foo', '{{ foo }}'], templar, loader) == ['foo', 'bar']

# Generated at 2022-06-11 18:16:11.750957
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Dummy vars and context for unit test
    templar = Templar(loader=None, variables={'test_var': 'test_value'})

    # Test a simple string list
    test_list = listify_lookup_plugin_terms(terms=["1", "2", "3", ""], templar=templar, loader=None)
    assert len(test_list) == 4
    assert "1" in test_list
    assert "2" in test_list
    assert "3" in test_list
    assert "" in test_list

    # Test a simple int list

# Generated at 2022-06-11 18:16:23.668469
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.templar import Templar
    results = listify_lookup_plugin_terms(['one', 'two'], Templar(loader=DataLoader()), DataLoader())
    assert len(results) == 2
    assert results[0] == 'one'
    assert results[1] == 'two'

    results = listify_lookup_plugin_terms('one', Templar(loader=DataLoader()), DataLoader())
    assert len(results) == 1
    assert results[0] == 'one'

    results = listify_lookup_plugin_terms('one\ntwo', Templar(loader=DataLoader()), DataLoader())
    assert len(results) == 2
   

# Generated at 2022-06-11 18:16:33.497416
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.utils.vars import merge_hash

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_vault_secrets(dict(vault_secret_1='secret 1',
                                            vault_secret_2='secret 2',
                                            vault_secret_3='secret 3'))
    variables = variable_manager.get_vars(loader=loader, play=dict(vars=dict(a='a', b='b')))

    # Test string
    terms = listify_lookup_plugin_terms('{{ missing_var }}', Templar(loader=loader, variables=variables), loader)

# Generated at 2022-06-11 18:16:40.372907
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    assert listify_lookup_plugin_terms(['a', 'b'], Templar(loader=loader, variable_manager=variable_manager), loader) == ['a', 'b']
    assert listify_lookup_plugin_terms('a b', Templar(loader=loader, variable_manager=variable_manager), loader) == ['a', 'b']

# Generated at 2022-06-11 18:16:47.960986
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    fake_loader = DictDataLoader({})
    t = Templar(loader=fake_loader)

    assert listify_lookup_plugin_terms('hello', t, fake_loader) == ['hello']
    assert listify_lookup_plugin_terms(['hello', 'world'], t, fake_loader) == ['hello', 'world']

    assert listify_lookup_plugin_terms('hello', t, fake_loader, convert_bare=True) == ['hello', 'world']
    assert listify_lookup_plugin_terms('hello', t, fake_loader, convert_bare=True, fail_on_undefined=False) == ['hello', 'world']


# Generated at 2022-06-11 18:17:03.127174
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class FakeVarsModule:
        def __init__(self):
            self.ANSIBLE_VAULT = None
            self.ansible_vault = None

        def get_vault_password(self):
            return None

    class FakeVaultSecretsLookupPlugin:
        def __init__(self):
            pass

        def run(self, terms, inject=None, **kwargs):
            return terms[0]

    class FakeRunner:
        def __init__(self, loader):
            self._loader = loader
            self._variable_manager = None


# Generated at 2022-06-11 18:17:11.608633
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible import context
    from ansible.parsing.dataloader import DataLoader

    data = u''
    terms = u'{{ foo }}'

    # setup required objects
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_from_file('lib/ansible/inventory/hosts.yml'))
    context._init_global_context(None)

    # test first use case as described in docstring
    # a string is returned (not an iterable)
    # function returns a list and the item is a unicode string

# Generated at 2022-06-11 18:17:19.765023
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class TestLookupModule(object):

        def __init__(self, basedir, **kwargs):
            self.basedir = basedir
            self.templar = Templar(loader=None, variables={})

    lookup_plugin = TestLookupModule(None)

    # Test different values of terms
    terms = 'test1, test2'
    assert listify_lookup_plugin_terms(terms, lookup_plugin.templar, None) == ['test1', 'test2']

    terms = ['test1', 'test2']
    assert listify_lookup_plugin_terms(terms, lookup_plugin.templar, None) == ['test1', 'test2']

    terms = '{{foo}}, {{bar}}'

# Generated at 2022-06-11 18:17:29.877535
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test to make sure string is converted to list
    args = listify_lookup_plugin_terms('test', None, None)
    assert isinstance(args, list) == True

    # Test to make sure undefined variables can be ignored
    args = listify_lookup_plugin_terms('{{ test_var }}', None, None, fail_on_undefined = False)
    assert isinstance(args, list) == True

    # Test to make sure list is returned if list is passed in
    args = listify_lookup_plugin_terms(['test1', 'test2'], None, None)
    assert isinstance(args, list) == True

    # Test to make sure list is returned if list is passed in
    args = listify_lookup_plugin_terms(5, None, None)
    assert isinstance(args, list)

# Generated at 2022-06-11 18:17:41.952513
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test string terms
    terms = 'foo'
    assert listify_lookup_plugin_terms(terms, None, None) == ['foo']

    terms = 'foo bar'
    assert listify_lookup_plugin_terms(terms, None, None) == ['foo bar']

    terms = 'foo bar baz'
    assert listify_lookup_plugin_terms(terms, None, None) == ['foo bar baz']

    # Test list of string terms
    terms = ['foo']
    assert listify_lookup_plugin_terms(terms, None, None) == ['foo']

    terms = ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms, None, None) == ['foo', 'bar']

    terms = ['foo', 'bar', 'baz']
    assert listify_lookup

# Generated at 2022-06-11 18:17:49.995993
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    terms = [
        'foo',
        ['bar', 'bazz'],
        {'foo': 'bar', 'bazz': 'fazz'},
        [1, 2, 3],
        10,
        safe_eval("['foo', ['bar', 'bazz'], {'foo': 'bar', 'bazz': 'fazz'}, [1, 2, 3]]"),
    ]


# Generated at 2022-06-11 18:18:00.754821
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Iterable

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test single string value
    test_string = 'single-string'
    test_result = listify_lookup_plugin_terms(test_string, templar, loader)
    assert len(test_result) == 1 and isinstance(test_result[0], string_types) and test_result[0] == test_string

    # Test single non-string value
    test_string

# Generated at 2022-06-11 18:18:12.632320
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from ansible.module_utils._text import to_bytes

    lookup_plugin = lookup_loader.get('listify')
    loader = DataLoader()
    variable_manager = VariableManager()

    # testing bare variable
    templar = Templar(loader=loader, variables=variable_manager)
    terms = '{{ barevar }}'
    terms_out = ['Hello']
    terms_result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=True)
    assert terms_result == terms_out

    # testing undefined variable with fail_on

# Generated at 2022-06-11 18:18:23.741631
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Test lookup plugin term listification
    """

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.vault import VaultLib

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 18:18:34.062291
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    #from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    #from ansible.parsing.dataloader import DataLoader
    #from ansible.vars.manager import VariableManager
    #from ansible.inventory.manager import InventoryManager

    #vault_pass = 'testpass'
    #loader = DataLoader()
    #vault = VaultLib(vault_pass)
    #vars_manager = VariableManager()
    #inventory = InventoryManager(loader, vars_manager, vault)

# Generated at 2022-06-11 18:18:49.825178
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    m_templar = MagicMock()
    m_loader = MagicMock()

    with pytest.raises(AnsibleUndefinedVariable):
        listify_lookup_plugin_terms('{{ foo }}', m_templar, m_loader)
    with pytest.raises(AnsibleUndefinedVariable):
        listify_lookup_plugin_terms(['{{ foo }}'], m_templar, m_loader)
    with pytest.raises(AnsibleUndefinedVariable):
        listify_lookup_plugin_terms(['{{ foo }}', 'debug: var={{ foo }}'], m_templar, m_loader)

    listify_lookup_plugin_terms('{{ foo }}', m_templar, m_loader, fail_on_undefined=False)
    listify

# Generated at 2022-06-11 18:19:00.629250
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar


# Generated at 2022-06-11 18:19:10.933458
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    terms1 = AnsibleUnicode('foo,bar')
    terms2 = ['foo', 'bar']
    terms3 = 'foo,bar'
    terms4 = 'foo'
    terms5 = AnsibleUnicode('foo')
    terms6 = ['foo']
    terms7 = '{{ foo }}'
    terms8 = AnsibleUnicode('{{ foo }}')

    loader = DummyLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(terms1, templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(terms2, templar, loader) == ['foo', 'bar']

# Generated at 2022-06-11 18:19:19.285817
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()

    # ugh, sorry for this
    data = {
        'a': {
            'b': 'c'
        },
        'd': [
            'e',
            {
                'f': [1, 2, '3']
            },
            '{{g}}',
        ]
    }

    variable_manager.set_nonpersistent_facts(data)

    variable_manager.set_nonpersistent_fact(u'g', u'h')

# Generated at 2022-06-11 18:19:27.622833
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    import pytest

    variable_manager = VariableManager()
    inventory = Inventory(variable_manager, host_list=['fake_host'])

    play_context = PlayContext()
    templar = Templar(loader=None, inventory=inventory, variable_manager=variable_manager, loader_basedir_name='/fake/path', play_context=play_context)

    bare_term = listify_lookup_plugin_terms('foo', templar, loader=None)
    assert bare_term == ['foo']

    bare_term = listify_

# Generated at 2022-06-11 18:19:37.285630
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    #
    # Note: mock.MagicMock does not have __iter__ ...
    #
    from ansible.module_utils.six import text_type
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Because we're not actually running anything
    # we do not need valid data, just consistent
    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader, variable_manager, None)

# Generated at 2022-06-11 18:19:46.522911
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Test listify_lookup_plugin_terms'''
    from ansible.template import Templar, loader
    from ansible.utils.unsafe_proxy import create_unsafe_proxy

    lst1 = listify_lookup_plugin_terms(
        '{{ range(0, 10) }}{{ . }}{{ end }}',
        Templar(loader=loader), loader,
    )

    assert len(lst1) == 1
    assert isinstance(lst1[0], string_types)
    assert lst1[0] == '0123456789'

    lst2 = listify_lookup_plugin_terms(
        '{{ range(0, 10) }}{{ . }}\n{{ end }}',
        Templar(loader=loader), loader,
    )

    assert len(lst2) == 10

# Generated at 2022-06-11 18:19:55.723321
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    tmp = Templar(loader=loader, variables=VariableManager())
    # Single values
    assert listify_lookup_plugin_terms(1, tmp, loader) == [1]
    assert listify_lookup_plugin_terms('2', tmp, loader) == ['2']
    assert listify_lookup_plugin_terms('{{ foo }}', tmp, loader) == ['{{ foo }}']
    assert listify_lookup_plugin_terms('foo', tmp, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo', tmp, loader, convert_bare=True) == ['foo']
    # List of values
    assert listify

# Generated at 2022-06-11 18:20:05.182836
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test strings
    assert listify_lookup_plugin_terms(
        templar.template('{{ "foo" }}', convert_bare=True),
        templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(
        templar.template('{{ "foo bar baz" }}', convert_bare=True),
        templar, loader) == ['foo bar baz']

    # Test lists

# Generated at 2022-06-11 18:20:14.586648
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert listify_lookup_plugin_terms(['1','2'], None, None) == ['1','2']             # list, no templating
    assert listify_lookup_plugin_terms('1', None, None) == ['1']                       # str, no templating
    assert listify_lookup_plugin_terms(1, None, None) == [1]                           # int, no templating
    assert listify_lookup_plugin_terms(None, None, None) == [None]                     # None, no templating
    assert listify_lookup_plugin_terms({'a':'b'}, None, None) == [{'a':'b'}]           # dict, no templating