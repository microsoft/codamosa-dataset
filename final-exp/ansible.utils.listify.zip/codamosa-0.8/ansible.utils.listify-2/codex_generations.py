

# Generated at 2022-06-11 18:10:39.206247
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'ansible_user': 'foo'}
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader, True) == ['foo']
    assert listify_lookup_plugin_terms('foo, bar', templar, loader, True) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader, True) == ['foo', 'bar']

# Generated at 2022-06-11 18:10:48.958688
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This is only used in unit tests at the moment so pass None for the
    # templar and loader objects.
    terms = [1, '1', 2, '2']
    assert listify_lookup_plugin_terms(terms, None, None) == terms

    terms = '{{ [1, 2, 3] + [4, 5, 6] }}'
    assert listify_lookup_plugin_terms(terms, None, None) == [1, 2, 3, 4, 5, 6]

    terms = '{{ [1, 2, 3] }}'
    assert listify_lookup_plugin_terms(terms, None, None) == [1, 2, 3]

# Generated at 2022-06-11 18:10:56.700483
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import utils
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.playbook import Playbook

    class FakeVars:
        def __init__(self):
            self._params = {}

    params = FakeVars()

    extra_vars = {
        'item': 'bar',
        'key': 'val',
        'key2': 'val2',
        'key3': 'val3',
        'key4': '',
        'key5': None,
        'key6': '',
    }

    # test string

# Generated at 2022-06-11 18:11:04.093599
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeVarsModule:
        pass

    class FakeLoaderModule:
        pass

    setattr(FakeVarsModule, 'get_vars', lambda self, load_params: dict())

    setattr(FakeLoaderModule, 'get_basedir', lambda self, task: '.')

    fields = {'vars': FakeVarsModule()}
    templar = Templar(loader=FakeLoaderModule(), variables=fields)

    assert listify_lookup_plugin_terms('a', templar, FakeLoaderModule()) == ['a']
    assert listify_lookup_plugin_terms(['a', 'b'], templar, FakeLoaderModule()) == ['a', 'b']

# Generated at 2022-06-11 18:11:14.496517
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    dl = DataLoader()
    vm = VariableManager()
    t = Templar(loader=dl, variables=vm)
    data = '{{ [foo, bar] }}'
    assert listify_lookup_plugin_terms(data, t, dl, fail_on_undefined=True) == [u'foo', u'bar']
    data = '{{{ foo: bar }}}'
    assert listify_lookup_plugin_terms(data, t, dl, fail_on_undefined=True) == {u'foo': u'bar'}

# Generated at 2022-06-11 18:11:25.401274
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils._text import to_text
    from ansible.template import Templar

    class DummyVarsModule(object):
        def __call__(self, *args, **kwargs):
            return {}

    vars_mock = DummyVarsModule()

    class DummyVarManager(object):
        def __init__(self):
            self.vars_cache = dict()
            self.searchpath = list()

        def add_cache(self, host, cache):
            self.vars_cache[host] = cache

        def get_vars(self, loader=None, play=None, host=None, task=None, include_hostvars=True):
            return self.vars_cache.get(host) or dict()

    var_manager_mock = DummyVarManager()



# Generated at 2022-06-11 18:11:32.452930
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    t = Templar(loader=None)
    assert listify_lookup_plugin_terms('a', templar=t) == ['a']
    assert listify_lookup_plugin_terms(['a'], templar=t) == ['a']
    assert listify_lookup_plugin_terms(['a', 'b'], templar=t) == ['a', 'b']
    assert listify_lookup_plugin_terms(u'a', templar=t) == [u'a']
    assert listify_lookup_plugin_terms(['a', u'b'], templar=t) == ['a', u'b']
    assert listify_lookup_plugin_terms

# Generated at 2022-06-11 18:11:43.139528
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)

    x = listify_lookup_plugin_terms('foo', templar, loader)
    assert x == ['foo']

    x = listify_lookup_plugin_terms('foo bar', templar, loader)
    assert x == ['foo bar']

    x = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)
    assert x == ['foo', 'bar']

    x = listify_lookup_plugin_terms(123, templar, loader)
    assert x == [123]

    assert listify_lookup_plugin_terms(None, templar, loader) == [None]

# Generated at 2022-06-11 18:11:49.717762
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    terms = [
        "{{ lookup('foo', 'stuff') }}",
        ["{{ lookup('foo', 'a') }}",
         "{{ lookup('foo', 'b') }}"],
        "{{ lookup('foo', '{{ c }}') }}",
        "{{ lookup('foo', d) }}",
        "{{ lookup('foo', [{'i': 'c'}]) }}",
        [{"i": "{{ lookup('foo', 'c') }}"}]
    ]

    context = PlayContext()
    templar = Templar(loader=None, variables=dict(c='c', d='d'))

# Generated at 2022-06-11 18:12:00.503159
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.vars import merge_hash
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()
    context._loader = loader

# Generated at 2022-06-11 18:12:12.011428
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Make sure we return a list when given a list, a string or a template'''
    # unit test requires Ansible core libs
    import ansible.parsing.dataloader
    import ansible.vars

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.VariableManager()
    variable_manager.set_available_variables(loader.load_from_file('test/ansible/vars/test.yml'))
    templar = ansible.parsing.vars.VariableTemplate(loader=loader, variable_manager=variable_manager)

    assert listify_lookup_plugin_terms('a', templar, loader) == ['a']

# Generated at 2022-06-11 18:12:21.516745
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = 'dummy'
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        x=1,
        y=2,
        v=[7,8,9],
    )

    templar = Templar(loader=loader, variable_manager=variable_manager)

    terms = listify_lookup_plugin_terms(['A','B','C','{{ x }}','{{ y }}','{{ v }}'], templar, loader)
    assert terms == ['A','B','C','1','2','[7, 8, 9]'], repr(terms)


# Generated at 2022-06-11 18:12:33.294707
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None)

    # Test 1 - Convert a bare string
    terms = AnsibleUnicode("{{ foo }}")
    terms_list = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert isinstance(terms_list, list)
    assert len(terms_list) == 1
    assert terms_list[0] == "{{ foo }}"

    # Test 2 - Convert a non-bare string
    terms = "{{ foo }}"
    terms_list = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert isinstance(terms_list, list)
    assert len(terms_list) == 1


# Generated at 2022-06-11 18:12:39.877828
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.ansible_lookup_plugin import AnsibleLookupPlugin

    lookup_plugin = AnsibleLookupPlugin()


# Generated at 2022-06-11 18:12:51.078142
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.template import Templar

    class TestVarsModule:
        def get_vars(self, loader, path, entities):
            return {'a': 1, 'b': 2}

    def test_fail_on_undefined(loader, templar):
        # Test string with undefined template
        terms = "{{ c }}"
        try:
            terms = templar.template(terms)
        except errors.AnsibleError:
            pass
        else:
            assert False, "AnsibleError expected"

        # Test list with undefined template
        terms = ["1", "2", "{{ c }}", "4"]
        try:
             terms = templar.template(terms)
        except errors.AnsibleError:
            pass

# Generated at 2022-06-11 18:13:02.670017
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader(), variables=combine_vars(dict(), dict()))
    test_list = ["item1", "item2", "item3"]
    # test with a list (which shouldn't change)
    assert(listify_lookup_plugin_terms(test_list, templar, DataLoader()) == test_list)
    # test with a comma separated string
    assert(listify_lookup_plugin_terms("item1,item2,item3", templar, DataLoader()) == test_list)
    # test with a list in

# Generated at 2022-06-11 18:13:06.279602
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    lookup_loader = DictDataLoader({})
    lookup_inventory = Inventory(loader=lookup_loader, variable_manager=VariableManager(), host_list=[])
    lookup_variable_manager = VariableManager()
    lookup_variable_manager.set_inventory(lookup_inventory)
    lookup_templar = Templar(loader=lookup_loader, variables=lookup_variable_manager)

    assert listify_lookup_plugin_terms("{{foo}}", lookup_templar, lookup_loader) == ['{{foo}}']

    # FIXME: we should test this with a real inventory and vars_manager to ensure that the template actually works

# Generated at 2022-06-11 18:13:17.093895
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test strings
    assert sorted(listify_lookup_plugin_terms('a', templar, loader)) == ['a']
    assert sorted(listify_lookup_plugin_terms('["a"]', templar, loader)) == ['a']
    assert sorted(listify_lookup_plugin_terms('"a b c"', templar, loader)) == ['a b c']
    assert sorted(listify_lookup_plugin_terms('a,b', templar, loader)) == ['a', 'b']
    assert sorted(listify_lookup_plugin_terms('a, b', templar, loader)) == ['a', 'b']
   

# Generated at 2022-06-11 18:13:25.652772
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    """
    listify_lookup_plugin_terms returns:
     - a list if the input is an iterable
     - an empty list if the input is a string, but the empty string
     - a list with the input if the input is a string with a non-empty value
     - an empty list if the input evaluates to None
    """

    import os
    from ansible.utils.template import Template

    # We want the function to return a LIST, not a generator
    fake_vars = dict(lookup_plugin_generator='bad')
    fake_basedir = '%s/lib/ansible/modules/extras' % os.path.realpath(os.path.dirname(os.path.realpath(__file__))).split('lib')[0]


# Generated at 2022-06-11 18:13:37.527260
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class DummyVarsModule():

        def __init__(self, dummy_vars):
            self.params = dummy_vars

    # Create fake templar
    fake_loader = DummyVarsModule(dummy_vars={
        "item1": "value1",
        "item2": "value2"
    })
    fake_vault_secrets = DummyVarsModule(dummy_vars={})

# Generated at 2022-06-11 18:13:47.099451
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    A small unit test to verify that listify_lookup_plugin_terms returns the expected values.
    """
    from ansible.template import Templar

    templar = Templar(loader=None, variables={}, fail_on_undefined=True, convert_bare=False)

    # Test term is a string and returns a list. Verify that the list is a list and contains the string passed
    terms = "foo"
    assert isinstance(listify_lookup_plugin_terms(terms, templar, "", fail_on_undefined=True, convert_bare=False), list)
    assert isinstance(listify_lookup_plugin_terms(terms, templar, "", fail_on_undefined=True, convert_bare=False)[0], string_types)

# Generated at 2022-06-11 18:13:53.708277
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms('test', Templar(), None) == ['test']
    assert listify_lookup_plugin_terms(['test1', 'test2'], Templar(), None) == ['test1', 'test2']
    assert listify_lookup_plugin_terms(u'test', Templar(), None) == [u'test']
    assert listify_lookup_plugin_terms([u'test1', u'test2'], Templar(), None) == [u'test1', u'test2']

# Generated at 2022-06-11 18:14:03.882894
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping

    import ansible.module_utils.template as template
    import ansible.module_utils.basic as basic

    terms   = ['httpd', 'nginx']
    varname = 'service'
    templar = template.Templar(loader=basic.AnsibleLoader())
    templar._available_variables['hostvars'] = {'localhost': {varname: terms}}

    terms_result = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(terms_result, list), 'listify_lookup_plugin_terms returned an unexpected type: %s' % type(terms_result)

# Generated at 2022-06-11 18:14:10.975038
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    # Test with single item string
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']

    # Test with single item template string
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None) == ['bar']

    # Test with multiple item template string
    assert listify_lookup_plugin_terms('{{ foo }},{{ bar }}', templar, None) == ['bar', 'baz']

    # Test with single item iterable
    assert listify_lookup_plugin_terms(['foo'], templar, None) == ['foo']

    # Test with multiple item iterable

# Generated at 2022-06-11 18:14:19.287026
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing import DataLoader
    templar = Templar(DataLoader())
    assert not isinstance(u'foo', Iterable)
    assert isinstance('foo', string_types)
    assert listify_lookup_plugin_terms(u'foo', templar, DataLoader()) == [u'foo']
    assert listify_lookup_plugin_terms(42, templar, DataLoader()) == [42]
    assert listify_lookup_plugin_terms([21, 42], templar, DataLoader()) == [21, 42]

# Generated at 2022-06-11 18:14:28.929334
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This is just a simple test. More complex tests are found in the other
    # tests for the lookup plugins.
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    vault_secrets = {'gid': 0, 'group': 'root', 'mode': None, 'owner': 'root', 'password': 'VaultPasswordHere', 'path': '/etc/ansible/roles/test_role/vars/vault.yml', 'uid': 0}
    vault = VaultLib(vault_secrets)
    loader = DataLoader()
    templar = Templar(loader=loader, variables={'vault_password': vault}, vault_ids=[])

    # test string
    ret = listify_lookup_

# Generated at 2022-06-11 18:14:36.075550
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    # test with object, string and unicode object
    test_object = dict(key1='value1', key2='value2')
    test_unicode = u'value1,value2'
    test_string = 'value3,value4'

    results_object = listify_lookup_plugin_terms(test_object, templar, loader)
    results_string = listify_lookup_plugin_terms(test_string, templar, loader)

# Generated at 2022-06-11 18:14:43.935690
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, C.DEFAULT_VAULTPASS)
    templar = Templar(loader=loader, variables={'x': 'y'})

    term = '{{x}}'
    assert listify_lookup_plugin_terms(term, templar, loader) == ['y']

    term = ['{{x}}']
    assert listify_lookup_plugin_terms(term, templar, loader) == ['y']

    term = '{{x}} {{x}}'
    assert listify_lookup_plugin_terms(term, templar, loader) == ['y y']

    term = '{{x}} {{x}}'

# Generated at 2022-06-11 18:14:53.179342
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template

    t = ansible.template.Template({})

    # Test that empty string returns empty list
    assert listify_lookup_plugin_terms('', t) == []

    # Test that list is preserved
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], t) == ['a', 'b', 'c']

    # Test that dict returns empty list
    assert listify_lookup_plugin_terms({'a': 'b'}, t) == []

    # Test that non-iterable returns list with one element
    assert listify_lookup_plugin_terms(5, t) == [5]

# Generated at 2022-06-11 18:15:05.214956
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import context
    from ansible.template import Templar, DictData

    inventory = DictData(dict())
    variable_manager = DictData(dict())
    loader = DictData(dict())
    templar = Templar(loader=loader, inventory=inventory, variables=variable_manager)

    assert listify_lookup_plugin_terms([], templar=templar, loader=loader, fail_on_undefined=True, convert_bare=False) == []
    assert listify_lookup_plugin_terms(dict(), templar=templar, loader=loader, fail_on_undefined=True, convert_bare=False) == [dict()]

# Generated at 2022-06-11 18:15:17.878713
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager

    terms = [ 'a', 'b' ]
    templar = Templar(loader=AnsibleLoader(None), variables=VariableManager(), vault_secrets=VaultLib())
    assert listify_lookup_plugin_terms(terms, templar, AnsibleLoader(None)) == terms

    terms = '''a
b'''
    assert listify_lookup_plugin_terms(terms, templar, AnsibleLoader(None)) == terms.split()

    terms = 'a'
    assert listify_lookup_plugin_terms(terms, templar, AnsibleLoader(None)) == [terms]

# Generated at 2022-06-11 18:15:27.826790
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager

    inv_data = '''
    all:
      hosts:
        test1:
          ansible_host: 127.0.0.1
    '''
    inv_data2 = '''
    all:
      hosts:
        test1:
          ansible_host: 127.0.0.1
        test2:
          ansible_host: 127.0.0.2
    '''
    inv_source = InventoryManager(loader=None, sources=inv_data)

# Generated at 2022-06-11 18:15:37.937963
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from jinja2 import Template

    assert listify_lookup_plugin_terms(AnsibleUnicode('{{v}}'), Template('{{ a }}'), Template('{{ b }}'), convert_bare=True) == ['a']
    assert listify_lookup_plugin_terms(AnsibleUnicode('{{v}}'), Template('{{ a }}'), Template('{{ b }}'), convert_bare=False) == ['b']
    assert listify_lookup_plugin_terms(AnsibleUnicode('{{v}}'), Template('{{ a }}'), Template('{{ b }}')) == ['b']


# Generated at 2022-06-11 18:15:48.274276
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = FakeLoader()
    templar = Templar(loader=loader)

    items = "{{ [1,2,3] }}"
    result = listify_lookup_plugin_terms(items, templar, loader)
    assert result == [1,2,3]

    items = [1,2,3]
    result = listify_lookup_plugin_terms(items, templar, loader)
    assert result == [1,2,3]

    items = " 1,2,3 "
    result = listify_lookup_plugin_terms(items, templar, loader, convert_bare=True)
    assert result == [1,2,3]

    items = "{{ foo }}"

# Generated at 2022-06-11 18:15:59.234481
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class DummyVar(object):
        pass

    var = DummyVar()
    var.vars = {'a': 'b'}
    var.hostvars = dict()
    var.hostvars[var] = dict(c='d')

    var_manager = VariableManager()
    var_manager.set_inventory(var)
    loader = DataLoader()
    templar = Templar(loader=loader, variables=var_manager)

    # case 1 : flatten

# Generated at 2022-06-11 18:16:11.036541
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' Test that listify_lookup_plugin_terms() will convert a string to a list of words '''
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    vault_pass = 'testpass'
    new_vault_secret = 'newpassword'

    # Create a vault secret
    vault = VaultLib(vault_pass)
    encrypt = vault.encrypt(new_vault_secret)
    encrypt = vault.encrypt(new_vault_secret)

    # Instantiate ansible objects
    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = InventoryManager(loader=loader, sources=[])
    all_vars

# Generated at 2022-06-11 18:16:22.856278
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    lookup_loader = None
    play_context = VariableManager()

    # Simple case
    templar = Templar(loader=lookup_loader, variables=play_context)
    terms = listify_lookup_plugin_terms(terms='foo', templar=templar, loader=lookup_loader)
    assert terms == ['foo']

    # Vault encrypted term
    play_context._extra_vars = combine_vars(play_context._extra_vars, {'vault_foo': 'bar'})

# Generated at 2022-06-11 18:16:30.567429
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test single string that is an integer
    terms = listify_lookup_plugin_terms('1', templar, loader, fail_on_undefined=False)
    assert terms == ['1']

    # Test single integer
    terms = listify_lookup_plugin_terms(1, templar, loader, fail_on_undefined=False)
    assert terms == [1]

    # Test a list of strings

# Generated at 2022-06-11 18:16:40.899094
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # Create a very simple ansible context
    class AnsibleContext(object):
        def __init__(self):
            self.basedir = './'
            self.vars = {
                'bar': 'BAR',
                'baz': 'BAZ',
                'quux': 'QUUX',
            }

    context = AnsibleContext()
    templar = Templar(loader=None, variables=context.vars)

    # Test a simple string
    terms = 'foo'
    actual = listify_lookup_plugin_terms(terms, templar, context)
    assert actual == ['foo']

    # Test a list of strings
    terms = ['foo', 'bar']
    actual = listify_lookup_plugin_terms(terms, templar, context)
   

# Generated at 2022-06-11 18:16:52.634667
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.templating.template import Templar

    terms = ["{{ foo }} and {{ bar }}", "{{ baz }}"]
    templar = Templar(loader=None, variables={'foo': 'Foo!', 'bar': 'Bar!', 'baz': 'Baz!'})
    new_terms = listify_lookup_plugin_terms(terms, templar, None)
    assert terms == new_terms

    terms = "{{ foo }} and {{ bar }}"
    new_terms = listify_lookup_plugin_terms(terms, templar, None)
    assert new_terms == ["Foo! and Bar!"]

    terms = ["{{ foo }} and {{ bar }}"]
    new_terms = listify_lookup_plugin_terms(terms, templar, None)

# Generated at 2022-06-11 18:17:11.000888
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)
    my_vars = variable_manager.get_vars(play=dict(vars={'a': 'foo', 'b': 'bar'}))
    templar = Templar(loader=loader, variables=my_vars)


# Generated at 2022-06-11 18:17:19.509331
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import os.path

    loader = DataLoader()
    basedir = os.path.join(os.path.dirname(__file__), 'templates')
    loader.set_basedir(basedir)
    templar = Templar(loader=loader, variables={'a': 5, 'b': 7, 'foo': 'bar'})

    # str
    terms = '{{foo}}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['bar']

    # list of str
    terms = ['{{foo}}']
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['bar']

    # list

# Generated at 2022-06-11 18:17:29.679085
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert listify_lookup_plugin_terms([u'{{foo}}', u'{{bar}}'], dict(foo=u'foo', bar=u'bar'), None, fail_on_undefined=True, convert_bare=False) == [u'foo', u'bar']
    assert listify_lookup_plugin_terms(['{{foo}}', '{{bar}}'], dict(foo=u'foo', bar=u'bar'), None, fail_on_undefined=True, convert_bare=False) == [u'foo', u'bar']
    assert listify_lookup_plugin_terms(u'{{foo}}', dict(foo=u'foo', bar=u'bar'), None, fail_on_undefined=True, convert_bare=True)

# Generated at 2022-06-11 18:17:41.812818
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible import inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv = inventory.Inventory(loader=loader, variable_manager=VariableManager(loader=loader), host_list=[])
    templar = Templar(loader=loader, variables=inv.get_vars())
    test1 = 1
    test2 = [1,2,3]
    test3 = 'this, that, other'
    test4 = '{{ test2 }}'
    test5 = None
    test6 = '{{ test5 }}'

    assert listify_lookup_plugin_terms(test1, templar, loader) == [1]

# Generated at 2022-06-11 18:17:49.958074
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar

    loader = DictDataLoader({
        "/etc/ansible/hosts": "%YAML 1.1\n---\nlocalhost",
    })
    inventory = Inventory(loader=loader)
    templar = Templar(loader=None, variables=inventory.get_vars(Host("localhost"), vault_password=None))

    assert(listify_lookup_plugin_terms("{{ foo }}", templar, loader) == [u'{{ foo }}'] )
    assert(listify_lookup_plugin_terms("{{ hostvars['localhost']['foo'] }}", templar, loader) == [u'{{ hostvars[\'localhost\'][\'foo\'] }}'] )

# Generated at 2022-06-11 18:18:00.754023
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Just making sure this function exists
    listify_lookup_plugin_terms(None, None, None)

    # Test possible inputs for the terms argument
    assert listify_lookup_plugin_terms(None, None, None) == []
    assert listify_lookup_plugin_terms('', None, None) == []
    assert listify_lookup_plugin_terms('one', None, None) == ['one']
    assert listify_lookup_plugin_terms(['one'], None, None) == ['one']
    assert listify_lookup_plugin_terms(['one', 'two'], None, None) == ['one', 'two']

    # Test possible inputs for the terms argument

# Generated at 2022-06-11 18:18:12.632590
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    vault_secrets = VaultLib(None, pwd=None)
    variable_manager = VariableManager()
    variable_manager.set_play_context(PlayContext())

# Generated at 2022-06-11 18:18:23.738883
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable
    source = dict(a='a', b='a b', d=dict(a='a', b='a|b'))
    templar = Templar(loader=None, variables=source)

    # Test simple string
    data = dict(a='a')
    result = ['a']
    assert listify_lookup_plugin_terms(data, templar) == result

    # Test list string
    data = dict(a='a b')
    result = ['a', 'b']
    assert listify_lookup_plugin_terms(data, templar) == result

    # Test list of strings
    data = dict(a=['a', 'b'])

# Generated at 2022-06-11 18:18:34.026371
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables={'foo': 'bar'})
    terms = listify_lookup_plugin_terms(terms, templar, None)
    assert terms == ['bar']

    # test with bare strings
    terms = '{{ foo }}'
    templar = Templar(loader=None, variables={'foo': 'bar'})
    c = PlayContext()
    c.convert_bare = True
    terms = listify_lookup_plugin_terms(terms, templar, None, convert_bare=True)
    assert terms == 'bar'

    terms = ['{{ foo }}']

# Generated at 2022-06-11 18:18:45.501585
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # TODO: test undefined variables that should or shouldn't be ignored
    # TODO: test convert_bare
    # TODO: test when terms is already a list

    loader = DictDataLoader({})
    variables = DictLookup()

    # simple string
    templar = Templar(loader=loader, variables=variables)
    terms = listify_lookup_plugin_terms('foo', templar, loader)
    assert terms == ['foo']

    # list of strings
    templar = Templar(loader=loader, variables=variables)
    terms = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)

# Generated at 2022-06-11 18:18:56.144546
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO:
    assert False

# Generated at 2022-06-11 18:19:04.295023
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys
    if sys.version_info[0] == 2 and sys.version_info[1] <= 6:
        import unittest2 as unittest
    else:
        import unittest
    from ansible.template import Templar

    class TestTemplar(Templar):
        def __init__(self):
            self._available_variables = dict()

        def set_available_variables(self, variables):
            self._available_variables = variables


# Generated at 2022-06-11 18:19:12.249678
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class DummyVarsModule(object):
        def __init__(self, foo):
            self.foo = foo

        def get_vars(self):
            return dict(foo=self.foo)

    vars_obj = DummyVarsModule(foo=('one', 'two', 'three'))

    t = Templar(loader=None, variables=vars_obj)

    # Test with a string that can be template-expanded into a list
    listified = listify_lookup_plugin_terms('{{foo}}', templar=t, loader=None)
    assert isinstance(listified, list)

    # Test with a string that cannot be template-expanded

# Generated at 2022-06-11 18:19:22.575686
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_vault_secrets(dict(vault_password='secret'))
    variable_manager.extra_vars = {'some_var': 'hello world'}

    templar = Templar(loader=loader, variables=variable_manager)

    # test a dictionary with a single item
    args = dict(
        terms   = { "a": 1 },
        templar = templar,
        loader  = loader,
    )

    assert listify_lookup_plugin_terms(**args) == [ { "a": 1 } ]

    # test a dictionary with multiple items
   

# Generated at 2022-06-11 18:19:28.924430
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.template.vars import VarsModule
    from ansible.vars.manager import VariableManager

    vars_dict = { "myvar": "myvalue" }
    vars_manager = VariableManager()
    vars_manager.vars_loader = VarsModule()
    vars_manager.vars_loader.set_vars(vars_dict)
    templar = Templar(loader=None, variables=vars_manager)

    terms = "{{ myvar }}"
    results = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=False)
    assert results == ["myvalue"]

    terms = ["{{ myvar }}"]

# Generated at 2022-06-11 18:19:37.668810
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.parsing.yaml.objects
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.module_utils.six import PY3

    # Create a templar that can be used for testing
    result = ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode.load('foo')
    variable_manager = VariableManager()
    variable_manager.set_vault_secrets([result])
    loader = variable_manager.get_vars_loader()

    templar = Templar(loader=loader, variables=variable_manager)

    # This is really just to get the test to run under py3
    if PY3:
        str = str
    else:
        str = unicode

    # Make sure simple strings work
   

# Generated at 2022-06-11 18:19:46.544002
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.template import Templar

    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables={})
    templar.basedir = None
    templar.unfrackpath = mock_unfrackpath_noop

    # Basic string test
    terms = "test"
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ["test"]

    # List test
    terms = ["test1", "test2"]
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ["test1", "test2"]

    # Tuple test
   

# Generated at 2022-06-11 18:19:53.339469
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.plugins.loader
    import ansible.template

    # setup
    ansible.plugins.loader.add_directory('./lib/ansible/plugins/lookup')
    templar = ansible.template.AnsibleJ2Template("", {}, '.', False)

    # test string value
    terms = 'first'
    terms = listify_lookup_plugin_terms(terms, templar)
    assert terms == ['first']

    # test single value
    terms = ['second']
    terms = listify_lookup_plugin_terms(terms, templar)
    assert terms == ['second']

# Generated at 2022-06-11 18:20:01.439856
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms(terms='{{ foo }}', templar=templar, loader=None, fail_on_undefined=False, convert_bare=True) == [{'foo': 'bar'}]
    assert listify_lookup_plugin_terms(terms='{{ foo }}', templar=templar, loader=None, fail_on_undefined=False, convert_bare=False) == ['{{ foo }}']

# Generated at 2022-06-11 18:20:13.120090
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None, variables={u'var': u'value'})
    assert listify_lookup_plugin_terms(u'{{ var }}', templar, None) == [u'value']
    assert listify_lookup_plugin_terms([u'{{ var }}'], templar, None) == [u'value']
    assert listify_lookup_plugin_terms([u'{{ var }}', u'bar'], templar, None) == [u'value', u'bar']
    assert listify_lookup_plugin_terms(u'foo', templar, None) == [u'foo']

# Generated at 2022-06-11 18:20:22.714513
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO
    pass


# Generated at 2022-06-11 18:20:33.367582
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import sys
    import os
    import tempfile
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    lookup_file = tempfile.NamedTemporaryFile()
    lookup_file.write('''
[{ "name": "param1", "value": "file1" }
,{ "name": "param2", "value": "file2" }]
    ''')
    lookup_file.flush()

    variable_manager = VariableManager()
    variable_manager.set_inventory(DataLoader())
    templar = Templar(loader=None, variables=variable_manager)

    test_terms = ['{{ lookup_file_content("%s") }}' % lookup_file.name, '{{ param3 }}']

    variable