

# Generated at 2022-06-11 18:10:28.881787
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-11 18:10:39.782858
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar, Jinja2Templar
    from ansible.vars.manager import VariableManager

    def _varname(k):
        return 'foo_%s' % k

    terms = [
        ['one',
         'two',
         'three'],
        ['', 'four', '', 'five'],
        [],
        'Hello, world!'
    ]

    variables = {_varname(k): v for k, v in enumerate(terms)}
    loader = DictDataLoader(variables)
    vars_mgr = VariableManager(loader=loader)
    templar = Jinja2Templar(loader=loader, variables=vars_mgr)


# Generated at 2022-06-11 18:10:51.094140
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 18:10:55.749511
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.common._collections_compat import OrderedDict

    fake_loader = None
    terms = '{ key0: val0, key1: val1 }'
    templar = Templar(loader=fake_loader)

    assert isinstance(listify_lookup_plugin_terms(terms, templar, fake_loader), list)
    assert isinstance(listify_lookup_plugin_terms(terms, templar, fake_loader)[0], OrderedDict)
    assert isinstance(listify_lookup_plugin_terms(terms, templar, fake_loader)[0], Iterable)

# Generated at 2022-06-11 18:11:04.220042
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    import pytest

    def test_terms_type(terms, expect_type, expect_len=None, expect_value=None):
        loader = DataLoader()
        templar = Templar(loader=loader)
        result = listify_lookup_plugin_terms(terms, templar, loader)
        assert isinstance(result, expect_type), 'return value is not a %s: %s' % (expect_type, terms)
        if expect_len is not None:
            assert len(result) == expect_len, 'return value does not contain %d items: %s' % (expect_len, result)

# Generated at 2022-06-11 18:11:13.698750
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    tests = [
        ("{{ test }}", "single", ["single"]),
        ("single", "single", ["single"]),
        (["first", "second"], "", ["first", "second"]),
        ("{{ test }}", ["single"], ["single"]),
        (["{{ test }}"], "single", ["single"]),
        ([], "single", [])
    ]

    for (arg, value, expected_results) in tests:
        templar = Templar(loader=None, variables={'test': value})
        actual_results = listify_lookup_plugin_terms(arg, templar, loader=None)
        assert actual_results == expected_results

# Generated at 2022-06-11 18:11:23.711396
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleMapping

    data = dict(a=1, b=2, c=3, d=4, e=5)
    t = Templar(loader=None, variables=data)
    vault_pass = VaultLib(password="abc123")
    plaintext_terms = ['a', 'b', 'c']
    templated_terms = [u'{{a}}', u'{{b}}', u'{{c}}']
    bare_terms = [u'a', u'b', u'c']
   

# Generated at 2022-06-11 18:11:30.462832
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import AnsibleMapping

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # test case 1
    # test_str: bare string
    test_str = "test"
    # test_var: safe string
    test_var = AnsibleUnsafeText('test')
    # test_data: list of safe strings
    test_data = [test_var, test_var]
    # test_dict: dictionary of safe strings
    test_dict = {'k1': test_var, 'k2': test_var}

    # The string should be a list
    result = listify_lookup_plugin_terms(test_str, Templar(loader=None), None)

# Generated at 2022-06-11 18:11:41.486126
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean

    assert listify_lookup_plugin_terms([], None, None) == []
    assert listify_lookup_plugin_terms({}, None, None) == []
    assert listify_lookup_plugin_terms('', None, None) == []
    assert listify_lookup_plugin_terms(1, None, None) == [1]
    assert listify_lookup_plugin_terms(True, None, None) == [True]
    assert listify_lookup_plugin_terms(False, None, None) == [False]
    assert listify_lookup_plugin_terms(None, None, None) == []
    assert listify_lookup_plugin

# Generated at 2022-06-11 18:11:51.235088
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a string
    val = 'some string'
    templar = Templar(VariableManager())
    res = listify_lookup_plugin_terms(val, templar, None, False, False)
    assert(isinstance(res, list))
    assert(len(res) == 1)
    assert(res[0] == val)

    # Test with a list
    val = ['some string', 'other string']
    templar = Templar(VariableManager())
    res = listify_lookup_plugin_terms(val, templar, None, False, False)
    assert(isinstance(res, list))

# Generated at 2022-06-11 18:12:03.350459
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager

    terms = '{{ lookup_var("foo", "bar") }}'
    fail_on_undefined = True
    convert_bare = False
    test_term = 'test'

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar', 'test':'testy'}
    variable_manager.set_available_variables(loader=None, variables=variable_manager.get_vars(loader=None, play=None, include_hostvars=False))
    templar = Templar(loader=None, variables=variable_manager)


# Generated at 2022-06-11 18:12:12.571194
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.template import DynamicLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import os

    test_loader = DynamicLoader()

    def test_templar_lookup_plugin(self, term):
        if term == 'password':
            return AnsibleVaultEncryptedUnicode(value='my_secret_password', is_encrypted=True, vault_id='test_lookup_plugin', vault_password=None, loader=None)
        elif term == 'foo':
            return 'bar'
        else:
            return term

    listify_lookup_plugin_terms_old = Templar._lookup_plugin
    listify_lookup_plugin_terms_old_os_path_exists = os.path.exists

# Generated at 2022-06-11 18:12:21.716895
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager

    fake_loader = DictDataLoader({})
    variable_manager = VariableManager()
    vars_dict = dict(
        foo=dict(
            a=1,
            b="hello",
        ),
        zoo="zab",
        a=dict(
            b=dict(
                c="deep",
                d=[1,2,3],
                e=dict(f=100),
            )
        )
    )
    variable_manager.extra_vars = combine_vars(vars_dict)


# Generated at 2022-06-11 18:12:33.540472
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variables = VariableManager(loader=loader)

    templar = Templar(loader=loader, variables=variables)

    assert listify_lookup_plugin_terms('a b c', templar, loader) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms('a,b,c', templar, loader) == ['a,b,c']
    assert listify_lookup_plugin_terms(['1', '2', '3'], templar, loader) == ['1', '2', '3']

# Generated at 2022-06-11 18:12:41.925054
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'var1': "value1", 'var2': "value2", 'var3': "value3", 'var4': "value4"})

    assert listify_lookup_plugin_terms('{{var1}}', templar, loader=None, fail_on_undefined=True, convert_bare=False) == ['value1']
    assert listify_lookup_plugin_terms('{{var1}}', templar, loader=None, fail_on_undefined=False, convert_bare=False) == ['value1']
    assert listify_lookup_plugin_terms('{{var1}}', templar, loader=None, fail_on_undefined=False, convert_bare=True) == ['value1']
    assert listify_

# Generated at 2022-06-11 18:12:51.960311
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    assert listify_lookup_plugin_terms('a/b/c', None, None) == ['a/b/c']
    assert listify_lookup_plugin_terms('a,b,c', None, None) == ['a,b,c']
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], None, None) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms({'var': ['a', 'b', 'c']}, None, None) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms({'var': 'a,b,c'}, None, None) == ['a,b,c']

# Generated at 2022-06-11 18:13:03.322505
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    class TestTemplar(Templar):
        def __init__(self, loader, variables):
            super(TestTemplar,self).__init__(loader, variables)
        def template(self, data, fail_on_undefined=True, convert_bare=False, preserve_trailing_newlines=True):
            return 'test_template'

    class TestVars(VariableManager):
        def __init__(self):
            self._vars = dict()

    top_level_vars = TestVars()

# Generated at 2022-06-11 18:13:13.956229
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars import VariableManager
        from ansible.template import Templar

    except ImportError:
        raise AssertionError("Unable to import ansible modules - please install ansible")

    def get_loader():
        ''' Create a new DataLoader '''
        loader = DataLoader()
        return loader

    def get_variable_manager(loader, inventory):
        ''' Create a new VariableManager '''
        variable_manager = VariableManager()
        variable_manager.set_inventory(inventory)
        return variable_manager

    inventory = None
    loader = get_loader()
    variable_manager = get_variable_manager(loader, inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test conversion

# Generated at 2022-06-11 18:13:20.841599
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    ds = [ u'value1', u'value2', u'value3' ]

    templar = Templar(loader=DataLoader())
    assert(ds == listify_lookup_plugin_terms(ds, templar, templar._loader))
    assert(ds == listify_lookup_plugin_terms(u'{{ ds }}', templar, templar._loader))

# Generated at 2022-06-11 18:13:24.575429
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables=dict(key="value"))
    assert listify_lookup_plugin_terms("key", templar, None) == ['value']
    assert listify_lookup_plugin_terms(["key"], templar, None) == ['value']

# Generated at 2022-06-11 18:13:38.478388
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.utils.template as template
    from ansible.template import Templar

    class TestVarsModule:
        def __init__(self):
            self.argument_spec = {}
            self.params = {
                'test_var': '{{ test_var }}',
                'test_var_with_trim': '{{ test_var_with_trim }}  '
            }

    # Create dummy vars module
    dummy_vars_module = TestVarsModule()

    # Create templar from dummy vars module
    templar = Templar(loader=None, variables=dummy_vars_module.params)

    # Test with string
    terms_as_string = 'test_var'
    terms = listify_lookup_plugin_terms(terms_as_string, templar, loader=None)

# Generated at 2022-06-11 18:13:46.833895
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader),  host_list=[])
    templar = Templar(loader=loader, variables=inventory.get_vars())

    # test with a non-list:
    result = listify_lookup_plugin_terms('blah.txt', templar, loader)
    assert isinstance(result, Sequence)
    assert len(result) == 1
    assert result[0] == 'blah.txt'

    # test with a non-list:
   

# Generated at 2022-06-11 18:13:47.463889
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-11 18:13:55.947086
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars import VariableManager

    var_manager = VariableManager()
    loader = AnsibleLoader(None, var_manager)
    templar = Templar(loader=loader, variables=var_manager)

    # test 1
    terms = 'test'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['test']

    # test 2
    terms = ['test1', u'test2', '{{test3}}']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['test1', 'test2', '{{test3}}']

    # test 3

# Generated at 2022-06-11 18:14:05.614744
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    loader = AnsibleLoader(None, yaml_dumper=AnsibleDumper)

    # test with single term
    templar = Templar(loader=loader)
    terms = 'foo'
    expected = ['foo']
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert(results == expected)

    # test with list
    templar = Templar(loader=loader)
    terms = ['foo', 'bar']
    expected = ['foo', 'bar']
    results = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-11 18:14:17.675930
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # ansible.parsing.yaml.objects.AnsibleUnicode  # python2
    # ansible.parsing.yaml.objects.AnsibleUnicode = str  # python3
    # ansible.parsing.yaml.objects.AnsibleSequence
    # ansible.parsing.yaml.objects.AnsibleMapping

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 18:14:26.508811
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader

    my_vars = dict(
        foo=dict(
            bar=['a', 'b', 'c'],
            baz=dict(
                qux=['one', 'two', 'three']
            )
        ),
        two=2,
        three=3
    )
    loader = DictDataLoader({
        None: '',
    })
    templar = Templar(loader=loader, variables=my_vars)

    # test terms as a list
    terms = listify_lookup_plugin_terms(['one', '{{ two }}', 'three'], templar, loader)
    assert terms == ['one', '2', 'three']

    # test terms as a comma-separated list

# Generated at 2022-06-11 18:14:35.558578
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from units.mock.lookup import TestTemplar

    # Setup
    templar = TestTemplar(loader=DictDataLoader())

    # No quotes
    assert listify_lookup_plugin_terms('test', templar, loader=None) == ['test']

    # Single quotes (unescaped)
    assert listify_lookup_plugin_terms("'test'", templar, loader=None) == ['test']

    # Double quotes (unescaped)
    assert listify_lookup_plugin_terms('"test"', templar, loader=None) == ['test']

    # Single quotes (escaped)

# Generated at 2022-06-11 18:14:39.979873
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # GIVEN a function listify_lookup_plugin_terms
    from ansible.utils.listify import listify_lookup_plugin_terms

    # WHEN a term is a string containing a list and is templated
    # THEN the template should return a list
    assert listify_lookup_plugin_terms('{{ [1, 2, 3] }}') == [1, 2, 3]

# Generated at 2022-06-11 18:14:40.717238
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO
    pass

# Generated at 2022-06-11 18:14:56.328639
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(' [ foo , bar ] ', templar, None) == ['foo', 'bar']

    result = listify_lookup_plugin_terms(' [ foo , {{ bar }} ] ', templar, None)
    assert result == ['foo', '{{ bar }}']

    result = listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, None)
    assert result == ['foo', '{{ bar }}']

    result = listify_lookup_plugin_terms(['foo', '{{ bar }}'], templar, None, fail_on_undefined=False)


# Generated at 2022-06-11 18:15:06.909435
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.template import Templar

    # Setup Templar
    dummy_loader = DummyLoader()
    templar = Templar(loader=dummy_loader)

    # test strings
    assert listify_lookup_plugin_terms('String', templar, dummy_loader) == ['String']
    assert listify_lookup_plugin_terms(['String'], templar, dummy_loader) == ['String']

    # test variable substitution (of single item)
    assert listify_lookup_plugin_terms('{{var}}', templar, dummy_loader, fail_on_undefined=False) == ['var_value']

    # test variable substitution (of multiple items)

# Generated at 2022-06-11 18:15:16.714349
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms('foo', templar, None, fail_on_undefined=True) == ['foo']

    assert listify_lookup_plugin_terms(['foo'], templar, None, fail_on_undefined=True) == ['foo']

    assert listify_lookup_plugin_terms(
        {'a':'b'}, templar, None, fail_on_undefined=True
    ) == {'a': 'b'}

    assert listify_lookup_plugin_terms(
        '{{ items }}', templar, None, fail_on_undefined=True
    ) == ['{{ items }}']


# Generated at 2022-06-11 18:15:23.838079
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    vars = {'item': 'value', 'item2': 'value2'}
    templar = Templar(None, loader=None, variables=vars)

    # The function should return a list containing the one var
    test = listify_lookup_plugin_terms('{{item}}', templar, None)
    assert isinstance(test, list)
    assert len(test) == 1
    assert test[0] == 'value'

    # If the var evaluates to a list, the function should return the list
    test = listify_lookup_plugin_terms(['{{item}}', '{{item2}}'], templar, None)
    assert isinstance(test, list)
    assert len(test) == 2
    assert test[0] == 'value'

# Generated at 2022-06-11 18:15:32.268843
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.template import Templar

    test_loader = None
    test_options = namedtuple('Options', ('convert_bare','listtify','listify_errors','fail_on_undefined'))
    test_options.convert_bare = False
    test_options.listtify = False
    test_options.listify_errors = False
    test_options.fail_on_undefined = True
    test_templar = Templar(loader=test_loader, variables={}, options=test_options)

    assert listify_lookup_plugin_terms('foo', test_templar, loader=test_loader) == 'foo'

# Generated at 2022-06-11 18:15:44.268279
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    my_vars = dict(name='bob',
                   letter='a')

    # templar doesn't work without loader
    templar = Templar(loader, variables=my_vars)

    terms = '{{ letter }}'
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert results == ['a']

    terms = ['{{ letter }}']
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert results == ['a']

    terms = ['a', '{{ letter }}']
    results = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-11 18:15:56.212392
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultSecret
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    vault_secret = VaultSecret(VaultLib('foo'))
    loader = AnsibleLoader(vault_secret)
    templar = Templar(loader=loader, vault_secrets=[vault_secret])

    terms = ['some', 'strings']
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=True) == ['some', 'strings']

    terms = '  some '

# Generated at 2022-06-11 18:16:03.840456
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test case imports
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Playbook
    from ansible.template import Templar

    # Test case setup
    loader = DataLoader()
    pb = Playbook()

    # Test variables
    terms = ['/tmp/{{variable1}}/{{variable2}}/{{variable3}}/{{variable4}}', '{{variable5}}', '{{variable6}}']
    variables = {}
    convert_bare = False

    # Test that it works with no variables
    print('Testing with no variables')
    templar = Templar(loader=loader, variables=variables)
    result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=convert_bare)
    print

# Generated at 2022-06-11 18:16:13.985856
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(
        foo='bar',
        baz='foo',
    ))

    variable_manager.set_facts(dict(
        ansible_system_capabilities_enforced=False,
    ))

    loader = variable_manager.get_vars_loader()

    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['bar']

# Generated at 2022-06-11 18:16:25.824648
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # setup templar
    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    # setup tests

# Generated at 2022-06-11 18:16:46.770606
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('foo', {}, {}, False) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', {}, {}, False) == ['foo,bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], {}, {}, False) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], {'foo':'1', 'bar':'2'}, {}, False) == ['1', '2']
    assert listify_lookup_plugin_terms(['foo', 'bar'], {}, {'foo':'1', 'bar':'2'}, False) == ['1', '2']

# Generated at 2022-06-11 18:16:55.271876
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars

    vars = AnsibleVars(loader=None, variables={'x': wrap_var(1)})
    templar = Templar(loader=None, variables=vars)
    import os, sys
    sys.modules['ansible'].utils.path = os.path

    assert listify_lookup_plugin_terms(to_unicode("{{ x }}"), templar, loader=None) == [1]
    assert listify_lookup_plugin_terms("{{ x }}", templar, loader=None) == [1]

# Generated at 2022-06-11 18:17:06.469590
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    terms = ['a', '{{foo}}', '{{bar}}', '{{baz}}']
    templar = dict(foo='f', bar='b', baz='baz')

    results = listify_lookup_plugin_terms(terms, templar)
    assert results == ['a', 'f', 'b', 'baz']

    terms = ['a', '{{foo}}', '{{bar}}', '{{baz}}']
    templar = dict(foo='f', bar='b')
    results = listify_lookup_plugin_terms(terms, templar, fail_on_undefined=False)
    assert results == ['a', 'f', 'b', '{{baz}}']

    terms = { 'a': 'foo', 'b': 'bar'}
    templar = dict()
    results

# Generated at 2022-06-11 18:17:13.760926
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create Ansible objects to pass to listify_lookup_plugin_terms
    loader = DataLoader()
    variable_manager = VariableManager()

    def _find_vars(variables, name, **kwargs):
        results = []
        for var in variables:
            if var['name'] == name:
                results.append(var)
        return results

    variable_manager._find_vars = _find_vars

    # Create some variables

# Generated at 2022-06-11 18:17:24.562445
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    terms = ['foo', 'bar', 'baz']
    templar = Templar(loader=None, vault_secrets=None)

    assert listify_lookup_plugin_terms(terms, templar) == ['foo', 'bar', 'baz']

    terms = ['foo', '"{bar}"', 'baz']
    templar = Templar(loader=None, vault_secrets=None)

    assert listify_lookup_plugin_terms(terms, templar) == ['foo', '{bar}', 'baz']

    terms = 'foo bar baz'
    templar = Templar(loader=None, vault_secrets=None)


# Generated at 2022-06-11 18:17:32.098488
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # need to mock some objects
    class FakeModule(object):
        def __init__(self):
            self.params = {}
    fake_module = FakeModule()
    fake_basedir = None
    class FakeLoader(object):
        def __init__(self, basedir=None, module_name=None, module_args=None, template=None):
            self.basedir = basedir
            self.module_name = module_name
            self.module_args = module_args
            self.template = template
            self.templar = FakeTemplar()
        def __getattr__(self, name):
            if name != 'templar':
                raise AttributeError
            return FakeTemplar()
    class FakeTemplar(object):
        def __init__(self):
            self.variable_manager

# Generated at 2022-06-11 18:17:44.510072
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms(['foo'], Templar({}), None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], Templar({}), None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms({'a': 'foo', 'b': 'bar'}, Templar({}), None) == [{'a': 'foo', 'b': 'bar'}]
    assert listify_lookup_plugin_terms('foo', Templar({}), None) == ['foo']
    assert listify_lookup_plugin_terms(u'foo', Templar({}), None) == ['foo']
    assert listify_lookup_plugin_terms(42, Templar({}), None) == [42]
    assert listify

# Generated at 2022-06-11 18:17:54.193795
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class Test(unittest.TestCase):
        templar = Templar(None, loader=None, shared_loader_obj=None)

        def _test(self, terms, result):
            self.assertEqual(listify_lookup_plugin_terms(terms, self.templar, loader=None), result)

    t = Test()

    # test for string conversion
    t._test(None, [None])
    t._test([], [])
    t._test('', [''])
    t._test('one', ['one'])
    t._test(['one'], ['one'])
    t._test('one,two', ['one,two'])

# Generated at 2022-06-11 18:18:04.790039
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.template.vars import VariableManager

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    variable_manager._extra_vars = OrderedDict()

    templar = Templar(loader=loader, variable_manager=variable_manager,
                      vault_password=VaultLib().read_vault_password_file('./test_vault_password'))


# Generated at 2022-06-11 18:18:14.788442
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    myvars = dict(
        one=1,
        two=2,
        three=3,
        four="{{one}} + {{two}}",
        five="{{four}} + {{three}}",
        six="{{six}}",
        seven="{{one}} secret",
        eight={'a': 'b'},
        nine=9
    )
    templar = Templar(loader=loader, variables=myvars)

    # standard string
    assert listify_lookup_plugin_terms('{{one}}', templar, loader) == ['1']
    # single-item list of string

# Generated at 2022-06-11 18:18:48.951892
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """Test we get the expected data structure for different things"""
    from ansible.template import Templar

    test1 = "some string"
    test2 = [ "first", "second", "third" ]
    test3 = [ test1, test2 ]
    test4 = "{{ ['first', 'second', 'third' ] }}"

    env = {}
    loader = None
    templar = Templar(loader=loader, variables=env)

    def _run_test(item):
        return listify_lookup_plugin_terms(item, templar, loader)

    assert _run_test(test1) == ['some string']
    assert _run_test(test2) == ['first', 'second', 'third']
    assert _run_test(test3) == ['some string', ['first', 'second', 'third']]


# Generated at 2022-06-11 18:19:00.147976
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    cases = [
        ("{{ '^.*' }}", ['^.*']),
        (["{{ '^.*' }}"], ['^.*']),
        ("^.*", ['^.*']),
        (["^.*"], ['^.*']),
        (["^.*", "{{ '.*$' }}"], ['^.*', '.*$']),
        (["^.*", ".*$"], ['^.*', '.*$']),
    ]


# Generated at 2022-06-11 18:19:09.592255
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    terms = "{{ foo }}"
    templar = Templar(loader=DataLoader(), variables=VariableManager(), inventory=InventoryManager())

    terms = templar.template(terms, convert_bare=False, fail_on_undefined=True)
    assert terms == "{{ foo }}"

    templar._available_variables = dict(foo="bar")
    terms = templar.template(terms, convert_bare=False, fail_on_undefined=False)
    assert terms == "bar"

# Generated at 2022-06-11 18:19:18.056163
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from jinja2 import Template
    from ansible import template

    def __tmpl(value, fail_on_undefined=True, convert_bare=False):
        t = Template(value)
        return template.template(t, fail_on_undefined=fail_on_undefined, convert_bare=convert_bare)

    assert __tmpl('foo') == 'foo'
    assert __tmpl('{{ foo }}') == 'foo'
    assert __tmpl('{{ foo }}', False) == '{{ foo }}'
    assert __tmpl('{{ foo }}', True, False) == '{{ foo }}'

    assert listify_lookup_plugin_terms('foo', __tmpl) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', __tmpl) == ['foo', 'bar']
   

# Generated at 2022-06-11 18:19:26.837012
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = ['{{ hostvars[inventory_hostname]["test_foo"] }}', ['{{ test_bar }}', '{{ test_baz }}']]
    templar = Templar(loader=None, variables={'test_bar': 'test1', 'test_baz': 'test2',
                                               'hostvars': {'inventory_hostname': {'test_foo': 'test3'}}})
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert result == ['test3', ['test1', 'test2']]

    terms = '{{ test_foo }}'
    templar = Templar(loader=None, variables={'test_foo': ['test1', 'test2']})
    result = listify_lookup_plugin

# Generated at 2022-06-11 18:19:36.790156
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, dict(), variable_manager=None)
    templar = Templar(loader=loader)

    assert len(listify_lookup_plugin_terms([], templar, loader)) == 0
    assert len(listify_lookup_plugin_terms([], templar, loader)) == 0
    assert len(listify_lookup_plugin_terms(['hello', 'there'], templar, loader)) == 2
    assert len(listify_lookup_plugin_terms('hello', templar, loader)) == 1
    assert len(listify_lookup_plugin_terms(['hello'], templar, loader)) == 1

# Generated at 2022-06-11 18:19:46.293485
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(None)
    templar = Templar(loader=None, variables={}, vault_secrets=vault)

    # Test 1: None
    result1 = listify_lookup_plugin_terms(terms=None, templar=templar)
    assert result1 == [None]

    # Test 2: not a list
    result2 = listify_lookup_plugin_terms(terms='test', templar=templar)
    assert result2 == ['test']

    # Test 3: list
    result3 = listify_lookup_plugin_terms(terms=['test1', 'test2'], templar=templar)
    assert result3 == ['test1', 'test2']



# Generated at 2022-06-11 18:19:55.683376
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()

    templar = Templar(loader=loader, variables=variable_manager)

    # test a valid string
    string = 'lookup'
    result = listify_lookup_plugin_terms(string, templar, loader)
    assert result == ['lookup']

    # test a valid list
    terms = ['lookup', 'plugin', 'terms']
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['lookup', 'plugin', 'terms']

    # test a valid list with string

# Generated at 2022-06-11 18:20:05.087154
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = {'foo': 'bar'}
    templar = Templar(loader=loader, variable_manager=variable_manager)

    terms = '{{ foo }}/baz'
    test = listify_lookup_plugin_terms(terms, templar, loader)
    assert test == ['bar/baz']
    terms = ['{{ foo }}/baz']
    test = listify_lookup_plugin_terms(terms, templar, loader)
    assert test == ['bar/baz']
    terms = ['{{ foo }}/baz', 'spam']

# Generated at 2022-06-11 18:20:16.235228
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # FIXME: need better unit tests for this
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_from_file('test/inventory'))

    templar = Templar(loader=loader, variable_manager=variable_manager)

    terms = 'test/lookup_plugins'
    results = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False)
    assert results == ['test/lookup_plugins']

    terms = ['test/lookup_plugins']