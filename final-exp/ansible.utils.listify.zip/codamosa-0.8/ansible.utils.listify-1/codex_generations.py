

# Generated at 2022-06-11 18:10:40.667157
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils import module_docs
    from ansible.templating import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar as LegacyTemplar

    import pytest


# Generated at 2022-06-11 18:10:51.771561
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import TemplateV2
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    templar = TemplateV2()
    assert len(listify_lookup_plugin_terms('hello', templar, None)) == 1
    assert listify_lookup_plugin_terms('hello', templar, None)[0] == 'hello'
    assert listify_lookup_plugin_terms(['hello'], templar, None)[0] == 'hello'
    assert listify_lookup_plugin_terms(['hello', 'world'], templar, None)[1] == 'world'
    assert isinstance(listify_lookup_plugin_terms(AnsibleUnsafeText('{{hello}}'), templar, None), list)

# Generated at 2022-06-11 18:11:02.022249
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Simulate AnsibleContext
    class Context:
        def __init__(self):
            self.variable_manager = None

    c = Context()
    ld = DataLoader()
    ld.set_basedir(".")
    t = Templar(loader=ld, variables=combine_vars(loader=ld, playcontext=c))

    # First test a simple template, that can be cast to a string
    terms = "[u'{{foo}}']"
    context_variable_manager = dict(foo=['foo'])


# Generated at 2022-06-11 18:11:12.919457
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(dict(a='foo'), None, None) == [{'a': 'foo'}]
    assert listify_lookup_plugin_terms('{{ foo }}', None, None) == ['{{ foo }}']
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], None, None) == ['{{ foo }}', '{{ bar }}']
    assert listify_lookup_plugin_terms(dict(a='{{ foo }}'), None, None) == [{'a': '{{ foo }}'}]

# Generated at 2022-06-11 18:11:22.417094
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms("test", None, None) == ["test"]
    assert listify_lookup_plugin_terms(" test1 test2 ", None, None) == ["test1 test2"]
    assert listify_lookup_plugin_terms(" test1 test2 ", None, None, convert_bare=True) == ["test1", "test2"]
    assert listify_lookup_plugin_terms(["test"], None, None) == ["test"]
    assert listify_lookup_plugin_terms([" test1", "test2 "], None, None) == ["test1", "test2"]
    assert listify_lookup_plugin_terms([" test1", "test2 "], None, None, convert_bare=True) == ["test1", "test2"]

# Generated at 2022-06-11 18:11:29.637627
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.template import Templar
    from ansible.vars import VariableManager

    varmgr = VariableManager()
    varmgr.set_available_variables({})

    templar = Templar(loader=None, variables=varmgr)

    assert isinstance(listify_lookup_plugin_terms(AnsibleUnicode('foo'), templar, None), list)
    assert isinstance(listify_lookup_plugin_terms('foo', templar, None), list)
    assert isinstance(listify_lookup_plugin_terms(['foo', 'bar'], templar, None), list)

# Generated at 2022-06-11 18:11:40.436201
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.manager import InventoryManager
    from  ansible.playbook.play import Play
    from ansible.plugins import loader as plugin_loader

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 'foo'}

    inventory = InventoryManager(loader=None, sources='')
    loader = DataLoader()

    play_context = PlayContext()

    templar = Templar(loader, variable_manager, play_context)

    result = listify_lookup_plugin_terms([1, 2, 3], templar, loader)
    assert result == [1, 2, 3]

    result = listify_look

# Generated at 2022-06-11 18:11:50.560335
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import ansible.plugins.loader as plugins_loader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(1, templar, loader) == [1]
    assert listify_lookup_plugin_terms('1', templar, loader) == ['1']
    assert listify_lookup_plugin_terms(['1', '2', '3'], templar, loader) == ['1', '2', '3']


# Generated at 2022-06-11 18:12:01.489403
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_from_file("tests/inventory"))
    templar = Templar(loader=loader, variables=variable_manager)

    terms = templar.template(u'{{ foo }}', convert_bare=True)
    assert terms == u'bar', terms

    terms = templar.template(u'wrong_value', convert_bare=True)
    assert terms == u'wrong_value', terms

    terms = templar.template(u'wrong_value', convert_bare=False)
    assert terms == u'wrong_value', terms

    terms = templar

# Generated at 2022-06-11 18:12:11.527524
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import merge_hash
    from ansible.module_utils._text import to_bytes

    vault_secret = 'VaultSecret'
    templar = Templar(loader=None, variables={'v': vault_secret})


# Generated at 2022-06-11 18:12:22.010633
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: Mock templar and fix test
    pass
    # def test_listify_lookup_plugin_terms(monkeypatch):

    #     import ansible
    #     import ansible.utils
    #     import ansible.errors
    #     import ansible.template
    #     import ansible.parsing.dataloader

    #     from ansible.playbook.play import Play

    #     from ansible.modules.test.test_utils import set_module_args

    #     from ansible.utils.vars import AnsibleVars

    #     class TestPlay(Play):

    #         def __init__(self, variables=None, loader=None, templar=None, shared_loader_obj=None, use_handlers=False):
    #             super(TestPlay, self).__init

# Generated at 2022-06-11 18:12:22.599458
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-11 18:12:29.723625
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)
    templar.available_variables = dict()

    assert listify_lookup_plugin_terms(["http://test.host/banana/", "{{ foo }}"], templar, loader) == \
        ['http://test.host/banana/', '{{ foo }}']

# Generated at 2022-06-11 18:12:39.669611
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_native
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    from ansible.module_utils.common._collections_compat import UnsafeText
    from ansible.plugins.lookup import LookupBase

    templar = Templar(loader=None, variables={'foo': 'test value'})

    # test with a string, not a list
    assert listify_lookup_plugin_terms('foo', templar, loader=None) == ['test value']

    # test with a string and a template
    assert listify_lookup_plugin_terms('{{foo}}', templar, loader=None) == ['test value']

    # test with a complex object

# Generated at 2022-06-11 18:12:50.782420
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = 'hello world'
    vault_text = VaultLib.encrypt(secret)
    assert isinstance(vault_text, AnsibleVaultEncryptedUnicode)
    vault_str = "%s" % vault_text
    assert isinstance(vault_str, string_types)

    templar = Templar(loader=None, variables={'secret': secret})
    assert templar.template(vault_str) == secret
    assert templar.template(vault_str, convert_bare=False) == secret
    assert templar.template(vault_str, convert_bare=True) == secret
   

# Generated at 2022-06-11 18:12:58.227460
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar, Dictifier
    terms = "{{ one }}, {{ two }}, {{ three }}"
    templar = Templar(loader=None, variables=dict(one="foo", two=dict(a="b"), three="baz"))
    terms = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=True, convert_bare=False)
    assert terms == ["foo", dict(a="b"), "baz"]

# Generated at 2022-06-11 18:13:05.946700
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Check a single string variablized term
    assert listify_lookup_plugin_terms([{'my_var': 'my_val'}, 'my_var'], {}, {}, fail_on_undefined=True) == ['my_val']
    # Check a single string variablized term
    assert listify_lookup_plugin_terms('my_var', {}, {}, fail_on_undefined=True) == ['my_var']
    # Check multiple string variablized terms
    assert listify_lookup_plugin_terms('my_var_1,my_var_2', {}, {}, fail_on_undefined=True) == ['my_var_1', 'my_var_2']
    # Check a single non-variablized term

# Generated at 2022-06-11 18:13:16.771751
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DictDataLoader({
        "test.j2": "{{ var }}"
    })

    variable_manager = VariableManager()

    my_vars = dict(var='hello')
    variable_manager.set_host_variable(host=None, varname='var', value=my_vars['var'])

    templar = Templar(loader=loader, variables=variable_manager)

    # test string
    lookup_terms = 'test.j2'
    listified_terms = listify_lookup_plugin_terms(lookup_terms, templar, loader)
    assert isinstance(listified_terms, list)
    assert listified_terms == ['hello']



# Generated at 2022-06-11 18:13:25.487196
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.loader import lookup_loader

    lp = lookup_loader.get("list")
    assert lp is not None

    # Check that string is transformed to list
    result = listify_lookup_plugin_terms("{ 'foo': 'bar' }", lp._templar, lp._loader)
    assert isinstance(result, list)
    assert result[0] == {'foo': 'bar'}

    # Check that non-iterables are transformed to list
    result = listify_lookup_plugin_terms("foo", lp._templar, lp._loader)
    assert isinstance(result, list)
    assert result[0] == 'foo'

    # Check that list is not changed

# Generated at 2022-06-11 18:13:37.376728
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DictDataLoader({})

    templar = Templar(loader=loader, variables={})

    # string that looks like a list
    terms = 'foo,bar,baz'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['foo', 'bar', 'baz'], terms

    # list that looks like a list
    terms = ['foo', 'bar', 'baz']
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == ['foo', 'bar', 'baz'], terms

    # string that looks like a string
    terms = 'foo'
    terms = listify_lookup_plugin_terms(terms, templar, loader)

# Generated at 2022-06-11 18:13:51.662042
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible import constants as C

    loader = DummyLoader()

    # We don't want to use a real templar() here because that would mean
    # pulling in all of Jinja, which we don't need for testing this function.
    templar = Templar(loader=loader)

    # Basic test of function
    assert listify_lookup_plugin_terms(['/var/log/', '/var/logs/'], templar, loader) == ['/var/log/', '/var/logs/']

    # Test passing a string that is valid YAML.  The listify_lookup_plugin_terms
    # function should not convert it to a list.

# Generated at 2022-06-11 18:14:02.258537
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    sample1 = 'just_a_string'
    sample2 = [8, 9, 10]
    sample3 = '''["{{a_var_i_used_to_know}}", "{{another_var}}"]'''
    sample4 = '''{{a_var_i_used_to_know}}'''
    sample5 = "{% if foo == 'bar' %}{{ baz }} {% else %} {{zap}} {% endif %}"

    # Templating is going to be done by the lookup plugin, not the action plugin.
    # So these return values need to be tweaked a bit before being used.
    # Everything should end up as a list
    expected1

# Generated at 2022-06-11 18:14:09.980666
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # basic setup
    from ansible import constants as C
    from ansible.vars import VariableManager

    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = None
    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=C.DEFAULT_UNDEFINED_VAR_BEHAVIOR)

    assert listify_lookup_plugin_terms("test_item", templar, loader) == ["test_item"]
    assert listify_lookup_plugin_terms("{{test_var}}", templar, loader) == ["{{test_var}}"]
    assert listify_lookup_plugin_terms("{{test_var}}", templar, loader, convert_bare=True) == ["{{test_var}}"]
    assert listify_lookup

# Generated at 2022-06-11 18:14:20.727509
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six.moves import StringIO

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence


    buf = StringIO()
    buf.write(u"{{ foo }},{{ bar }}")
    buf.seek(0)
    loader = DictDataLoader({u"/test": buf})
    templar = Templar(loader=loader)
    templar._add_vars({u'foo': 'foo', u'bar': 'bar'})


    def assert_items_equal(expected, actual):
        for e in expected:
            assert(e in actual)


    terms = listify_lookup_plugin_terms(u'foo', templar, loader)

# Generated at 2022-06-11 18:14:30.322570
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(None, loader=None)

    list = listify_lookup_plugin_terms([1, 2, 3], templar, None)
    assert list == [1, 2, 3]

    list = listify_lookup_plugin_terms("{{ 1 }},{{ 2 }},{{ 3 }}", templar, None)
    assert list == ['1', '2', '3']

    list = listify_lookup_plugin_terms("{{ 1 }},{{ 2 }},{{ 3 }}", templar, None, convert_bare=True)
    assert list == [1, 2, 3]


# Generated at 2022-06-11 18:14:36.607069
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    import copy

    lookup_variables = {
        'myvar': 'myvalue',
        'myothervar': 'myothervalue',
        'emptylist': [],
        'dictvar': {
            'k': 'v',
            'k2': [1, 2, 3],
            'k3': {
                'k4': 'v4'
            }
        }
    }


# Generated at 2022-06-11 18:14:44.248364
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    fake_loader = DictDataLoader({})
    fake_inventory = InventoryManager(loader=fake_loader, sources='')

    variable_manager = VariableManager()
    variable_manager.set_inventory(fake_inventory)
    templar = Templar(loader=fake_loader, variables=variable_manager)

    test_w_junk = listify_lookup_plugin_terms("{{ foo }}\n{{ bar }}", templar, fake_loader, convert_bare=True)
    assert test_w_junk == [AnsibleUnicode('{{ foo }}\n{{ bar }}')]

    test_

# Generated at 2022-06-11 18:14:55.032816
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader

    v = VaultLib(password_files=["test/testvault.txt"])
    dl = DataLoader()
    t = Templar(dl, vault_secrets=v.secrets)

    # case1: 'a, b, c'
    assert listify_lookup_plugin_terms('a, b, c', t, dl) == ['a', 'b', 'c']

    # case2: 'a, b, c' with convert_bare=True

# Generated at 2022-06-11 18:15:06.306548
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.vars import AnsibleVars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = AnsibleVars(loader=None, variables=dict(a=dict(b=1, c=2)))

    terms = "{{a}}"
    assert listify_lookup_plugin_terms(terms, templar, None) == [dict(b=1, c=2)]

    terms = "{{a}}"
    assert listify_lookup_plugin_terms(terms, templar, None,
                                       convert_bare=True) == [AnsibleUnsafeText(u"{'b': 1, 'c': 2}", encoding=None)]

    terms = AnsibleUnsafeText("{{a}}", encoding=None)
    assert listify_lookup_plugin

# Generated at 2022-06-11 18:15:13.481752
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader

    from ansible.vars import VariableManager

    loader = DataLoader()
    vars_mgr = VariableManager()
    templar = Templar(loader=loader, variables=vars_mgr)

    terms = '{{ lookup("env", "HOME") }}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)

# Generated at 2022-06-11 18:15:29.365193
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class templar:
        def __init__(self):
            pass
        def template(self, term, *args, **kwargs):
            return term


# Generated at 2022-06-11 18:15:38.065168
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()

    # Sample input that would be passed to the lookup plugin from a template
    # The values here are expected to be in YAML
    sample_input = '''
    - foo
    - bar
    - baz
    '''

    # Expected output from this should be a list of strings
    expected_output = ['foo', 'bar', 'baz']

    vault_secrets = dict(vault_password='secret')

# Generated at 2022-06-11 18:15:48.391038
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.parsing.yaml.objects

    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleError
    from ansible.template import Templar

    from StringIO import StringIO

    vault_password_file = StringIO("bar")

    t = Templar(
        vault_secrets=[('default', VaultLib([('default', vault_password_file)]))],
        loader=None,
    )

    # Test listify_lookup_plugin_terms with a string containing a list
    terms = listify_lookup_plugin_terms('["foo","bar"]', templar=t, loader=None)
    assert isinstance(terms, list)
    assert isinstance(terms[0], string_types)
    assert isinstance(terms[1], string_types)
    assert terms

# Generated at 2022-06-11 18:15:59.315740
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from ansible.template import Templar

    # String input
    terms = u'one'
    templar = Templar(None, loader=DictDataLoader({}))
    values = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert ['one'] == values

    terms = u' one ,two , three'
    templar = Templar(None, loader=DictDataLoader({}))
    values = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert ['one', 'two', 'three'] == values

    terms = [u'one', u'two', u'three']
    templar = Templar(None, loader=DictDataLoader({}))
    values = listify_

# Generated at 2022-06-11 18:16:11.022472
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.template

    class Foo(object):
        pass

    test = """{
        "{% if (omit == 'no') and (action == 'show') %}show {% else %} {{ omit }} {{ action }} {% endif %} {{ omit }} {{ action }}": value,
        "key": "{{ omit }} {{ action }}"
    }"""

    test_bare = "'1 2 3 4 5'"
    test_dict = {'foo': 'bar'}
    test_list = ['1 2 3 4 5']

    templar = ansible.template.Templar(loader=None)

    for t in test_list:
        assert templar.template(t) == ['1 2 3 4 5']


# Generated at 2022-06-11 18:16:17.163168
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    terms = '{{ item }}'
    templar = Templar(loader=DataLoader(), variables=VariableManager(), shared_loader_obj=None)
    assert listify_lookup_plugin_terms(terms, templar, None) == ['{{ item }}']

# Generated at 2022-06-11 18:16:27.703100
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Tests if listify_lookup_plugin_terms creates a list from a string, a list or both
    '''
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    templar = Templar(variables={'test':['a','b','c']})
    assert listify_lookup_plugin_terms('a', templar, None) == ['a']
    assert listify_lookup_plugin_terms(['a'], templar, None) == ['a']
    assert listify_lookup_plugin_terms(['a', 'b'], templar, None) == ['a', 'b']
    assert listify_lookup_plugin_terms('{{ test }}', templar, None) == ['a', 'b', 'c']
    assert list

# Generated at 2022-06-11 18:16:37.521107
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import unittest

    class TestListifyLookupPluginTerms(unittest.TestCase):

        def setUp(self):
            import ansible.parsing.vault
            from ansible.parsing.vault import VaultLib
            from ansible.template import Templar

            self.v = VaultLib([])
            self.t = Templar(None, None, loader=None)
            self.t._vault = self.v

        def tearDown(self):
            pass

        def test_listify_lookup_plugin_terms_string_input(self):
            """
            Tests the listify_lookup_plugin_terms function for a single string input of ``'{{foo}}'``.
            """

            terms = '{{foo}}'
            expected_result = 'bar'
            result = listify_lookup

# Generated at 2022-06-11 18:16:46.737431
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    # test the function with a string
    templar = Templar(loader=loader, variables=variable_manager)
    terms = 'foo'
    expected = ['foo']
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert results == expected

    # test the function with a list
    templar = Templar(loader=loader, variables=variable_manager)
    terms = ['foo']
    expected = ['foo']
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert results == expected

    # test the function with

# Generated at 2022-06-11 18:16:55.271521
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=vars_manager)
    variable_manager.set_inventory(inventory)

    vars = {'a': 'b'}
    variable_manager.set_host_variable(Host('localhost'), 'a', 'b')

    templar = Templar(loader=loader, variables=vars, shared_loader_obj=inventory)
    templar._available_variables = combine_vars(vars, variable_manager.get_vars(host=None))

    assert listify_lookup

# Generated at 2022-06-11 18:17:18.222806
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins import loader as plugin_loader

    vault_pass = 'secret'

    # Create a temporary directory and make it the CWD
    import shutil, tempfile
    tmpdir = tempfile.mkdtemp()
    source_dir = os.path.dirname(os.path.realpath(__file__))

    data_dir = os.path.join(source_dir, '..', '..', '..', '..', 'data')
    test_dir = os.path.join

# Generated at 2022-06-11 18:17:28.917084
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=None, sources=None)
    variable_manager.set_inventory(inventory)

    terms = '{{ foo }}'

    my_vars = dict(
        foo = ['a', 'b', 'c'],
        bar = 'hi mom',
    )
    variable_manager.set_host_variable('host1', my_vars)

    templar = Templar(loader=None, variables=variable_manager)

    # Test a

# Generated at 2022-06-11 18:17:41.088403
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-11 18:17:48.449269
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test for string, no iteration, just a string
    assert listify_lookup_plugin_terms("hello", None,  None) == ['hello']

    # Test for string, iteration, but only one item
    assert listify_lookup_plugin_terms("hello", None,  None) == ['hello']

    # Test for list, iteration of one item
    assert listify_lookup_plugin_terms(["hello"], None,  None) == ['hello']

    # Test for list, iteration of two items
    assert listify_lookup_plugin_terms(["hello", "world"], None,  None) == ['hello', 'world']

# Generated at 2022-06-11 18:17:52.813319
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test when term is a string
    term = '{{ hostvars[inventory_hostname]["foo"] }}'
    assert listify_lookup_plugin_terms(term, None, None) == [term]

    # test when term is a list
    term = ['a', 'b', 'c']
    assert listify_lookup_plugin_terms(term, None, None) == ['a', 'b', 'c']

# Generated at 2022-06-11 18:18:02.124928
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class FakeTemplar(object):
        string_val = 'string'
        list_val = ['list']
        int_val = 1
        dict_val = {'a': 1}
        none_val = None
        bool_true = True
        bool_false = False
        from_yaml = YAML().load('---\nfoo')

        def template(self, terms, convert_bare=False, fail_on_undefined=False, escape_backslashes=False,
                     convert_data=False, template_class=None, only_if_contains=None):

            if isinstance(terms, string_types):
                return getattr(self, terms)

            ret = []
            for term in terms:
                ret.append(getattr(self, term))

            return ret


# Generated at 2022-06-11 18:18:13.633912
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)


# Generated at 2022-06-11 18:18:20.479919
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    loader = DictDataLoader({})

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    mgr = VariableManager()
    templar = Templar(loader=loader, variables=mgr)

    # test that a simple string becomes an array as a single element
    assert listify_lookup_plugin_terms("simple", templar, loader) == ["simple"]
    assert listify_lookup_plugin_terms("simple\n", templar, loader) == ["simple"]

    # test that a simple array works
    assert listify_lookup_plugin_terms(["one", "two", "three"], templar, loader) == ["one", "two", "three"]

    # test that an empty string becomes an empty array
   

# Generated at 2022-06-11 18:18:27.579525
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    import os
    import sys

    # Very simple test
    data = '''
    ---
    foo: bar
    baz: foo
    '''

    t = Templar(loader=None, variables={'bar': 'baz'})
    assert listify_lookup_plugin_terms('{{ foo }}', t, None) == ['baz']

    # Test tuple, list, and string
    assert listify_lookup_plugin_terms([1, 2, 3], t, None) == [1, 2, 3]
    assert listify_lookup_plugin_terms((1, 2, 3), t, None) == [1, 2, 3]

# Generated at 2022-06-11 18:18:36.339269
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_native

    # Create a templar
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    vault = VaultLib([])
    t = Templar(loader=None, variables={}, fail_on_undefined=True, vault_secrets=vault)

    # Test string terms
    terms = 'company'
    assert isinstance(listify_lookup_plugin_terms(terms, templar=t), list)
    assert len(listify_lookup_plugin_terms(terms, templar=t)) == 1
    assert listify_lookup_plugin_terms(terms, templar=t)[0] == 'company'

# Generated at 2022-06-11 18:19:11.233145
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    assert listify_lookup_plugin_terms('   foo bar  ', Templar({}), {}) == ['foo bar']
    assert listify_lookup_plugin_terms(['   foo bar  '], Templar({}), {}) == ['   foo bar  ']
    assert listify_lookup_plugin_terms(['   foo bar  '], Templar({}), {}, convert_bare=True) == ['foo bar']
    assert listify_lookup_plugin_terms(['   foo bar  '], Templar({}), {}, convert_bare=False) == ['   foo bar  ']

# Generated at 2022-06-11 18:19:19.458611
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)

    templar = Templar(loader=loader, variables=variable_manager)

    # Test single-element list input
    args = ['{{ "1" }}']
    result = listify_lookup_plugin_terms(args, templar, loader)
    assert result == ['1']

    # Test multi-element list input
    args = ['{{ "1" }},{{ "2" }}']
    result = listify_lookup_plugin_terms(args, templar, loader)
    assert result == ['1', '2']

    # Test string input
   

# Generated at 2022-06-11 18:19:27.730904
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.utils
    import ansible.template
    import ansible.parsing.yaml.objects
    import ansible.module_utils.six

    terms = "{{ lookup('file', '/tmp/hello') }}"
    templar = ansible.template.Templar(loader=None, variables=ansible.vars.VariableManager())
    loader = ansible.parsing.dataloader.DataLoader()
    result = listify_lookup_plugin_terms(terms, templar=templar, loader=loader)
    assert isinstance(result, ansible.module_utils.six.string_types)

    terms = ansible.utils.listify_lookup_plugin_terms([['a', 'b'], 'c'], templar, loader)

# Generated at 2022-06-11 18:19:35.711286
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    templar = Templar(loader=None)
    terms0 = listify_lookup_plugin_terms('foo', templar, loader=None)
    assert terms0 == ['foo']
    terms1 = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader=None)
    assert terms1 == ['foo', 'bar']
    terms2 = listify_lookup_plugin_terms(['foo', ['bar', 'bam']], templar, loader=None)
    assert terms2 == ['foo', ['bar', 'bam']]

# Generated at 2022-06-11 18:19:45.484538
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = FakeLoader()

    # Simple list, should return list
    terms = [1, 2, 3]
    templar = Templar(loader=loader, variables={})
    new_terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert terms == new_terms, "List should be identical"

    # Single string, should return string in list
    str_term = 'string'
    templar = Templar(loader=loader, variables={})
    new_terms = listify_lookup_plugin_terms(str_term, templar, loader)
    assert [str_term] == new_terms, "String should be in list"

    # String with commas, split and return list of strings
    str_term = '1, 2, 3'
   

# Generated at 2022-06-11 18:19:55.242918
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib

    terms = '{{ var }}'
    templar = Templar(variables=VariableManager(), vault_secrets=VaultLib())
    templar.set_available_variables({'var': u'foobar'})
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert to_text(result) == to_text(u'foobar')


    terms = AnsibleMapping()
    terms['key'] = '{{ var }}'

# Generated at 2022-06-11 18:20:02.073344
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    loader = AnsibleLoader(DataLoader())

    # from ansible/lib/ansible/parsing/dataloader.py
    loader.set_basedir('/path/to')
    template_data = '''
    {%- for i in [1, 2, 3] -%}
        foo{{ i }}
    {%- endfor -%}
    '''
    t = Templar(loader=loader, variables={'foo': 'bar', 'list': ['a', 'b', 'c']})
    results = listify_lookup_plugin_

# Generated at 2022-06-11 18:20:12.391083
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # test some transforms
    fail_on_undefined = True
    convert_bare = True
    templar = Templar(loader=None, variables={})

    # transform string
    terms = "{{ item }}"
    terms = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined, convert_bare)
    assert terms == [u'{{ item }}']

    # transform list
    terms = ["{{ item }}"]
    terms = listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined, convert_bare)
    assert terms == [u'{{ item }}']

# Generated at 2022-06-11 18:20:20.377965
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-11 18:20:32.015102
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = listify_lookup_plugin_terms(["{{ a }}", "{{ b }}"], Templar({}, None), None, convert_bare=False)
    assert terms == ["{{ a }}", "{{ b }}"]

    terms = listify_lookup_plugin_terms(["{{ a }}", "{{ b }}"], Templar({}, None), None, convert_bare=True)
    assert terms == ["{{ a }}", "{{ b }}"]

    terms = listify_lookup_plugin_terms(["{{ bare }}"], Templar({ "bare": "{{ a }}" }, None), None, convert_bare=True)
    assert terms == ["{{ a }}"]
