

# Generated at 2022-06-11 18:10:29.027284
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: Add unit test
    pass

# Generated at 2022-06-11 18:10:40.023142
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.unsafe_proxy import UnsafeProxy

    #setup
    my_vars = dict(
        test_var="the value",
        test_list=["1", "2", "3"],
        test_dict=dict(
            var1="1",
            var2="2",
            var3=dict(
                var4="4"
            )
        )
    )
    templar = Templar(loader=None, variables=my_vars)

    # test raw string
    assert listify_lookup_plugin_terms("{{ test_var }}", templar, None) == ["the value"]

    # test list of strings
    assert listify_lookup_plugin

# Generated at 2022-06-11 18:10:51.328940
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    terms = "{{ test_var }}"
    variable_manager = VariableManager()
    loader = None
    templar = Templar(loader=loader, variables=variable_manager)
    variable_manager.set_nonpersistent_facts(dict(test_var="foo"))
    assert listify_lookup_plugin_terms(terms, templar, loader) == ["foo"]

    terms = "{{ test_list | join(',') }}"
    variable_manager = VariableManager()
    loader = None
    templar = Templar(loader=loader, variables=variable_manager)
    variable_manager.set_nonpersistent_facts(dict(test_list=["foo", "bar"]))

# Generated at 2022-06-11 18:11:01.908804
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    v = VariableManager()
    i = Inventory(v)
    p = PlayContext(variable_manager=v, loader=None)
    t = Templar(loader=None, variables=v, playcontext=p)

    assert listify_lookup_plugin_terms("{{ [1,2,3] }}", t, None) == [1,2,3]
    assert listify_lookup_plugin_terms("  1,2,3", t, None) == [u'1,2,3']

# Generated at 2022-06-11 18:11:12.791223
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.utils.template as template
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager.set_inventory(inventory)

    templar = template.Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader) == ['{{ foo }}']
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

# Generated at 2022-06-11 18:11:22.608053
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # single string
    terms = 'foo'
    templar = Templar()
    loader = None
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert type(terms) == list
    assert terms == ['foo']

    # quoted string
    terms = '"foo"'
    templar = Templar()
    loader = None
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert type(terms) == list
    assert terms == ['foo']

    # single quoted string
    terms = "'foo'"
    templar = Templar()
    loader = None
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert type(terms) == list

# Generated at 2022-06-11 18:11:29.804067
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    my_vars = dict(
        one = 'foo',
        two = 'bar',
        three = 'baz',
        four = [ 'qux', 'quux' ],
        five = 'quuux',
    )

    templar = Templar(loader=None, variables=my_vars)

    assert listify_lookup_plugin_terms('{{one}}', templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(['{{one}}'], templar, loader=None) == ['foo']

    assert listify_lookup_plugin_terms(['{{one}}','{{two}}'], templar, loader=None) == ['foo','bar']

# Generated at 2022-06-11 18:11:40.674666
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('foo', None, None, True, False) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], None, None, True, False) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None, True, False) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo bar baz', None, None, True, False) == ['foo bar baz']
    assert listify_lookup_plugin_terms(['foo bar', 'baz'], None, None, True, False) == ['foo bar', 'baz']

# Generated at 2022-06-11 18:11:50.717578
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms([1, 2, 3], 'ctx', None) == [1, 2, 3]
    assert listify_lookup_plugin_terms([1, 2, 3], {'ctx':True}, None) == [1, 2, 3]

    try:
        listify_lookup_plugin_terms([1, 2, 3], {'ctx':False}, None) == [1, 2, 3]
        assert False, 'should have raised an exception'
    except UnsafeVariableError:
        pass

    assert listify_lookup_plugin_terms('foo', Templar({'ctx': {'bar': 'baz'}}, variables={'foo': '{{bar}}'}), None) == ['baz']

# Generated at 2022-06-11 18:12:01.608448
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar

    templar = Templar(loader, vault_password='secret', fail_on_lookup_errors=True)

    assert listify_lookup_plugin_terms([1, 2, 3], templar, loader) == [1, 2, 3]
    assert listify_lookup_plugin_terms('[1,2,3]', templar, loader) == [1, 2, 3]

    assert listify_lookup_plugin_terms([], templar, loader) == []
   

# Generated at 2022-06-11 18:12:03.583895
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-11 18:12:12.696038
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo,bar'], templar, loader) == ['foo,bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_

# Generated at 2022-06-11 18:12:21.784033
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.template import Templar
    from ansible.parsing.yaml.dumper import AnsibleDumper

    loader = DictDataLoader({'some': {'nested': {'dict': 'hello world'}}})
    templar = Templar(loader=loader, variables={}, fail_on_undefined=True)
    yaml_dict = {'in': 'yaml'}
    template_data = {
        'in': 'template',
        'is': ['a', 'list'],
    }
    yaml_str = AnsibleDumper(None, width=1000).dump(yaml_dict, Dumper=AnsibleDumper)
    template_str = Ans

# Generated at 2022-06-11 18:12:33.636067
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = '{{ foo }}, {{ bar }}'

    # unit test function listify_lookup_plugin_terms with args: terms, templar, loader, fail_on_undefined=True, convert_bare=False
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.module_utils.six import string_types
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    ansible_vars = dict(foo=1, bar=2)

    templar = Templar(loader=DataLoader(), variables=ansible_vars)
    terms = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)

    # test return values

# Generated at 2022-06-11 18:12:42.012622
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template.safe_eval import safe_eval
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicodeList

    from ansible.template import Templar

    from ansible.playbook.play_context import PlayContext

    # simple string
    terms = 'foo'
    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo']

    # single quoted string list
    terms = "['foo', 'bar']"
    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms(terms, templar, None) == ['foo', 'bar']

    # single quoted string list with spaces
    terms

# Generated at 2022-06-11 18:12:52.030674
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()

    from ansible.template import Templar
    templar = Templar(loader=loader, variables=variable_manager)

    in1 = [ ['a', 'b'], 'c']
    out1 = listify_lookup_plugin_terms(in1, templar, loader)
    assert out1 == ['a', 'b', 'c'], out1

    variable_manager.set_host_variable('host1', dict(var1='1st_host_var'))
    variable_manager.set_host_variable('host2', dict(var1='2nd_host_var'))

# Generated at 2022-06-11 18:13:02.114041
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeTemplar(object):
        def template(self, terms, fail_on_undefined=False, convert_bare=False):
            return terms

    class FakeLoader(object):
        pass

    templar = FakeTemplar()
    loader = FakeLoader()
    result = listify_lookup_plugin_terms(1, templar, loader)
    assert result == [1]

    result = listify_lookup_plugin_terms([1, 2], templar, loader)
    assert result == [1, 2]

    result = listify_lookup_plugin_terms('1', templar, loader)
    assert result == ['1']

# Generated at 2022-06-11 18:13:03.318704
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # You can't test this module locally, it requires a templar object
    pass

# Generated at 2022-06-11 18:13:13.945979
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    templar = Templar(loader, variable_manager)

    terms = ['file1', 'file2']

    # result = listify_lookup_plugin_terms(terms, templar)
    result = listify_lookup_plugin_terms('file1', templar)

    assert isinstance(result, list)
    assert len(result) == 1

    result = listify_lookup_plugin_terms(['file1'], templar)

    assert isinstance(result, list)
    assert len(result) == 1


# Generated at 2022-06-11 18:13:23.813914
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host

    # Dummy data structures for testing
    class DummyVars(object):
        pass

    # Dummy loader with some example inventory vars
    loader = DataLoader()
    host = Host()

    # Invenetory vars for testing
    vars = DummyVars()
    vars.example = "example"
    vars.example_list = [1,2,3]
    host.set_variable('inventory_vars', vars)

    # Variable manager
    variable_manager = VariableManager(loader=loader)
    variable_manager.set_inventory(host)

    # Test templar
    templar

# Generated at 2022-06-11 18:13:38.283980
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # FIXME: This tests basic string conversion into list
    #        We still need to add tests for all the complex logic below.

    # Test with a list of strings
    term = ['one,two,three']
    ret = listify_lookup_plugin_terms(term, None, None)
    assert ret == ['one,two,three']

    # Test with a string with commas
    term = 'one,two,three'
    ret = listify_lookup_plugin_terms(term, None, None)
    assert ret == ['one', 'two', 'three']

    # Test with a string with commas, spaces and quotes
    term = 'one,two,three "four five" six'
    ret = listify_lookup_plugin_terms(term, None, None)

# Generated at 2022-06-11 18:13:46.748398
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    terms = '{{ [1, 2, 3, 4] | map("int") | list }}'
    templar = Templar(loader=None, variables={})
    res = listify_lookup_plugin_terms(terms, templar, loader)
    assert res == [1, 2, 3, 4]

    terms = to_text('[u"{{ [1, 2, 3, 4] | map(\\"int\\") | list }}"]')
    templar = Templar(loader=None, variables={})
    res = listify_lookup_plugin_terms(terms, templar, loader)
    assert res == [1, 2, 3, 4]



# Generated at 2022-06-11 18:13:55.604478
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    terms = "{{ foo }}" # Must be quoted string in Jinja2 3.2+
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None)))
    templar._available_variables = dict(foo=["a", "b", "c"])
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ["a", "b", "c"]

    terms = ["{{ foo }}"]
    templar._available_variables = dict(foo=["a", "b", "c"])
   

# Generated at 2022-06-11 18:14:05.437004
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Import only here, so we can do it in the correct order
    import ansible.template

    # Setup a fake templar
    class FakeTemplar:
        def __init__(self):
            self.template_data = dict(
                foo='foo', bar=dict(baz='baz', p1='p1'), p2='p2'
            )
        def template(self, terms, fail_on_undefined=True, convert_bare=False):
            return ansible.template.do_template(str(terms), self.template_data, convert_bare=convert_bare)

    templar = FakeTemplar()

    # Test converting a string to a list
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None) == ['foo']
    assert listify_look

# Generated at 2022-06-11 18:14:17.413333
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    import ansible.constants as C

    # Create a dummy var manager and plugin loader
    dummy_var_manager = VariableManager()
    dummy_var_manager._vault = VaultLib(password_files=[])
    dummy_plugin_loader = LookupBase()

    # Skip this test if we cannot preprocess templates
    if not C.DEFAULT_HASH_BEHAVIOUR == "replace":
        return

    # Test simple string
    template = "{{ foo }}"

# Generated at 2022-06-11 18:14:27.662858
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Test that function listify_lookup_plugin_terms produces
    the correct output for the different possible input types
    """

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.module_utils._text import to_bytes

    #  Setup the required objects
    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = """
        [local]
        localhost ansible_connection=local
    """
    variable_manager.set_inventory(loader.load_inventory_from_string(inventory))

    templar = Templar(loader=loader, variables=variable_manager)

    # Test a string input

# Generated at 2022-06-11 18:14:36.404356
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' test listify_lookup_plugin_terms()'''

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display

    results = []
    variable_manager = VariableManager()
    loader = DataLoader()
    display = Display()
    templar = Templar(loader=loader, variables=variable_manager, display=display)

    results.append(listify_lookup_plugin_terms(["a", "b"]) == ["a", "b"])
    results.append(listify_lookup_plugin_terms({"a":"b"}) == [{"a": "b"}])
    results.append(listify_lookup_plugin_terms('foo') == ['foo'])


# Generated at 2022-06-11 18:14:44.137001
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-11 18:14:54.922263
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DictDataLoader({
        "testdata": """
            {
              "a": "{{ testvar }}",
              "b": "{{ testvar }}",
              "c": "{{ testvar }}",
              "d": [ { "key1": "{{ testvar }}", "key2": "{{ testvar }}" }, "{{ testvar }}" ]
            }
        """
    })

    variable_manager = VariableManager()

    variable_manager.extra_vars = {
        "testvar": "testvalue"
    }

    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-11 18:15:06.267587
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 18:15:19.946993
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.templating.jinja2.environment import Environment
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    env = Environment(loader=loader)
    var_mgr = VariableManager(loader=loader)


# Generated at 2022-06-11 18:15:29.809246
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeLoader(object):
        def get_basedir(self, given_basedir):
            return '/foo'

    class FakeTemplar(object):

        def __init__(self):
            self.loader = FakeLoader()

        def template(self, terms, fail_on_undefined=True, convert_bare=False):
            if isinstance(terms, list):
                return ['bar', 'baz']
            return 'bar'

    assert listify_lookup_plugin_terms(['foo', 'bar'], FakeTemplar(), FakeLoader()) == ['bar', 'baz']
    assert listify_lookup_plugin_terms('foo', FakeTemplar(), FakeLoader()) == 'bar'
    assert listify_lookup_plugin_terms([], FakeTemplar(), FakeLoader()) == []

# Generated at 2022-06-11 18:15:35.097941
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    terms1 = 'a,b,c'
    terms2 = ['a','b','c' ]
    terms3 = ['{{a}}','{{b}}','{{c}}' ]
    terms4 = '{{a}},{{b}},{{c}}'
    terms5 = '{{[a, b, c]}}'

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=dict(a='a', b='b', c='c'), fail_on_undefined=True)


# Generated at 2022-06-11 18:15:46.200808
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    templar = Templar(loader=AnsibleLoader(None))
    facts = dict(omg='yes', lol=dict(this='worked'))
    assert listify_lookup_plugin_terms(['localhost', '{{ omg }}', '{{ lol.this }}'], templar, AnsibleLoader(None), fail_on_undefined=False) == ['localhost', 'yes', 'worked']
    assert listify_lookup_plugin_terms({'localhost', '{{ omg }}', '{{ lol.this }}'}, templar, AnsibleLoader(None), fail_on_undefined=False) == ['localhost', 'yes', 'worked']
    templar._available_variables = facts
    assert listify_

# Generated at 2022-06-11 18:15:57.847161
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from jinja2 import DictLoader

    templar = DictLoader(dict(
        val1='{{ ["foo", "bar"] }}',
        val2='["foo", "bar"]',
        val3='{{ foo }}',
        val4=[1, 2, 3],
    ))

    assert listify_lookup_plugin_terms('val1', templar, {}) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('val2', templar, {}) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('val3', templar, {}) == ['val3']
    assert listify_lookup_plugin_terms('val4', templar, {}) == [1, 2, 3]

# Generated at 2022-06-11 18:16:09.257970
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes, to_text

    class AnsibleMock:
        class AnsibleModuleMock:
            class params:
                _ansible_no_log = False

        def __init__(self, argument_spec, bypass_checks=False, no_log=False, check_invalid_arguments=True, mutually_exclusive=None, required_together=None, required_one_of=None, add_file_common_args=False, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.bypass_checks = bypass_checks
            self.no_log = no_log
            self.check_

# Generated at 2022-06-11 18:16:16.557804
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = DictDataLoader({})
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('boo', templar, loader) == ['boo']
    assert listify_lookup_plugin_terms('boo boo', templar, loader) == ['boo boo']
    assert listify_lookup_plugin_terms(['boo'], templar, loader) == ['boo']
    assert listify_lookup_plugin_terms(['boo', 'boo'], templar, loader) == ['boo', 'boo']
    assert listify_lookup_plugin_terms(('boo', 'boo'), templar, loader) == ['boo', 'boo']
    assert listify_lookup_plugin_

# Generated at 2022-06-11 18:16:27.300710
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Get the templar and loader objects
    (loader, inventory, variable_manager) = ansible.utils.plugins.loader.load_extra_vars('localhost')
    templar = ansible.template.AnsibleTemplar(loader=loader)

    # The tests

# Generated at 2022-06-11 18:16:37.294907
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import string_types

    template_class = None

    class test_template_class:
        def __init__(self, fail_on_undefined, convert_bare):
            self.fail_on_undefined = fail_on_undefined
            self.convert_bare = convert_bare

        def template(self, value, notify=None):
            if isinstance(value, string_types):
                return "TEMPLATED: " + value
            else:
                return value

    template_class = test_template_class


    templar = template_class(True, True)
    loader = None

    # Test with a single string with quotes
    result = listify_lookup_plugin_terms('"this"', templar, loader)
    assert isinstance(result, list)

# Generated at 2022-06-11 18:16:46.535658
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(sys.argv[0])))

    from ansible.template import Templar

    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultSecret

    from ansible.config.manager import ConfigManager
    cm = ConfigManager(os.path.expanduser("~/.ansible.cfg"))

    vault_secret = VaultSecret(password='Test123', vault_id='test')
    vault_secrets = {'vault_password': vault_secret}

    vl = VaultLib(cm)

    templar = Templar(loader=None, shared_loader_obj=None, variables=dict(), vault_secrets=vault_secrets, vault_version=1)
   

# Generated at 2022-06-11 18:17:08.391329
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert ['foo'] == listify_lookup_plugin_terms('foo', None)
    assert ['foo'] == listify_lookup_plugin_terms(['foo', 'bar'], None)
    assert ['foo'] == listify_lookup_plugin_terms('foo bar', None)
    assert ['foo'] == listify_lookup_plugin_terms({'a':'b'}, None)
    assert ['foo'] == listify_lookup_plugin_terms(['foo'], None)
    assert None == listify_lookup_plugin_terms(None, None)
    assert [] == listify_lookup_plugin_terms('', None)
    assert [] == listify_lookup_plugin_terms([], None)

# Generated at 2022-06-11 18:17:18.543959
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.errors import AnsibleUndefinedVariable, AnsibleError
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    def test(terms, fail_on_undefined, convert_bare, expected, expected_exception=None, bare_template=False, convert_data=False):

        loader = DummyLoader()
        templar = Templar(loader=loader, variables=combine_vars(loader.get_vars()), fail_on_undefined=True)
        templar._available_variables = combine_v

# Generated at 2022-06-11 18:17:27.441950
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)
    # Test function with str input
    s = "one"
    assert listify_lookup_plugin_terms(s, templar, None) == ["one"]
    # Test function with list input
    s = ["one", "two"]
    assert listify_lookup_plugin_terms(s, templar, None) == ["one", "two"]
    # Test function with templating
    s = "{{ var1 }}"
    assert listify_lookup_plugin_terms(s, templar, None, convert_bare=True) == ["var1"]

# Generated at 2022-06-11 18:17:39.513960
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # Setup
    terms = ["{{ foo }}", "bar", AnsibleBaseYAMLObject("{{ baz }}")]
    templar = Templar(VariableManager(), PlayContext(variable_manager=VariableManager(), loader=None))

    # Execute
    actual = listify_lookup_plugin_terms(terms, templar, None)

    # Assert
    assert isinstance(actual, list)
    assert len(actual) == 3
    assert actual[0] == "1"
    assert actual[1] == "bar"

# Generated at 2022-06-11 18:17:48.758849
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader

    # test string
    data = 'one, two, three'
    loader = DataLoader()
    templar = DummyTemplar()
    result = listify_lookup_plugin_terms(data, templar, loader)
    assert isinstance(result, list)
    assert result == ['one', 'two', 'three']

    # test list
    data = ['one', 'two', 'three']
    result = listify_lookup_plugin_terms(data, templar, loader)
    assert isinstance(result, list)
    assert result == ['one', 'two', 'three']

    # test empty string
    data = ''
    result = listify_lookup_plugin_terms(data, templar, loader)
    assert isinstance

# Generated at 2022-06-11 18:17:56.488507
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # setup results that would come from a real ansible run
    loader = DictDataLoader({
        "/playbook_dir/group_vars/all.yml": u"""
            foo:
                bar: bar
                baz: baz
            tasks:
                - debug:
                    msg: "{{ item }}"
                with_items: "{{ foo.bar }}"
            """,

        "/playbook_dir/roles/common/vars/main.yml": u"""
            foo:
                baz: baz
                qux: qux
                fuz: fuz
            """,
        })

    templar = Templar(loader=loader, variables={})

    # test string term

# Generated at 2022-06-11 18:18:04.121984
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ct = type('TestClass', (), {})
    templar = ct()
    templar.template = lambda x: x
    terms = listify_lookup_plugin_terms(['{{', 'hello', '}}'], templar, None)
    assert terms == ['{{', 'hello', '}}']
    # only works with string and iterable types, raises exception otherwise
    try:
        listify_lookup_plugin_terms(4, templar, None)
    except TypeError as e:
        print(e)
        assert True

# Generated at 2022-06-11 18:18:14.374429
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    templar = Templar(loader=DataLoader(), variables=VariableManager(), shared_loader_obj=None)
    assert listify_lookup_plugin_terms([u'foo', u'bar'], templar, None) == [u'foo', u'bar']
    assert listify_lookup_plugin_terms([u'foo', u'bar'], templar, None, convert_bare=True) == [u'foo', u'bar']
    assert listify_lookup_plugin_terms(u'foo', templar, None) == [u'foo']
    assert listify_lookup_plugin_terms(u'foo \n bar', templar, None)

# Generated at 2022-06-11 18:18:24.995030
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager.extend_vars({'var1': 'str1', 'var2': 'str2', 'var3': 'str3', 'var4': 'str4'})
    variable_manager.set_host_variable('host1', 'hostv1', 'host1')
    variable_manager.set_host_variable('host2', 'hostv2', 'host2')
    templar = Templar(loader=loader, variable_manager=variable_manager)

    # case 01, test convert_bare
    # templar is not enabled bare: True
    # string

# Generated at 2022-06-11 18:18:35.147751
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    t = Templar(loader=loader)
    assert listify_lookup_plugin_terms(['a','b'], t, loader) == ['a','b']
    assert listify_lookup_plugin_terms('a', t, loader) == ['a']
    assert listify_lookup_plugin_terms('a b', t, loader) == ['a', 'b']
    assert listify_lookup_plugin_terms('a b', t, loader, convert_bare=True) == ['a b']
    assert listify_lookup_plugin_terms(['a','b'], t, loader) == ['a','b']

# Generated at 2022-06-11 18:19:10.221104
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    dl = DataLoader()
    tmplr = Templar(dl, variables={}, loader=dl)

    assert listify_lookup_plugin_terms(AnsibleUnicode('a'), tmplr, dl, convert_bare=False) == ['a']
    assert listify_lookup_plugin_terms(AnsibleUnicode('a'), tmplr, dl, convert_bare=True) == ['a']

# Generated at 2022-06-11 18:19:18.663022
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    #import sys
    #sys.path.append('../../lib/ansible')
    #from ansible.template import Templar
    #from ansible.module_utils._text import to_text
    #from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.module_utils import lookup_common
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils import six
    from ansible.module_utils import common_test_data

    #test_data = common_test_data.test_data_from_json_file('/Users/lihot/dev/ansible/test/unit/module_utils/test_templar.json')
    test

# Generated at 2022-06-11 18:19:27.165995
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    yaml = '''
---
foo: "{{ item }}"
bar: "{{ 'ansible' | b64encode }}"
baz: "{{ 'ansible' | to_json }}"
zoo: "{{ 'ansible' | password_hash('sha512', 'whatever') }}"
boo: "{{ 'ansible' | password_hash('sha256', 'whatever') }}"
goo: "some encrypted text"
'''
    # Setup a fake templar and loader to use for testing
    my_vars = dict(
        item='bar',
        ansible='ansible'
    )
    templar = Templar(loader=None, variables=my_vars)


# Generated at 2022-06-11 18:19:37.045346
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.errors import AnsibleError
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    # Single string
    args = listify_lookup_plugin_terms("foo", templar, loader=None)
    assert args == ['foo']

    # String list
    args = listify_lookup_plugin_terms(["foo", "bar"], templar, loader=None)
    assert args == ['foo', 'bar']

    # Without templating
    args = listify_lookup_plugin_terms(["foo", "{{bar}}"], templar, loader=None, convert_bare=False)
    assert args == ['foo', '{{bar}}']

    # With templating

# Generated at 2022-06-11 18:19:46.493071
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template

    assert listify_lookup_plugin_terms(terms='{{ lookup }}', templar=ansible.template.Templar(), loader=None) == ['lookup']
    assert listify_lookup_plugin_terms(terms=[1,2,3,4], templar=ansible.template.Templar(), loader=None) == [1,2,3,4]
    assert listify_lookup_plugin_terms(terms=['a','b','c'], templar=ansible.template.Templar(), loader=None) == ['a','b','c']

# Generated at 2022-06-11 18:19:55.722019
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.plugins.loader import lookup_loader

    # If a token is not found and is required raise an error
    lookup_terms = 'my_lookup_file.txt'
    templar = Templar(loader=None, variables={})
    terms = listify_lookup_plugin_terms(lookup_terms, templar, loader, fail_on_undefined=True)
    assert terms == ['my_lookup_file.txt']

    # If a token is not found and is required raise an error
    lookup_terms = ['my_lookup_file.txt']
    templar = Templar(loader=None, variables={})

# Generated at 2022-06-11 18:20:05.120655
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class DummyClass(object):
        pass
    args = DummyClass()
    args.templar = DummyClass()
    args.templar.template = lambda x, fail_on_undefined=True: x
    args.templar.template = lambda x, fail_on_undefined=True: x
    args.loader = DummyClass()
    t = listify_lookup_plugin_terms([1,2,3,4], args.templar, args.loader)
    assert t == [1,2,3,4]
    t = listify_lookup_plugin_terms([1,'{{foo}}','{{bar}}',4], args.templar, args.loader)
    assert t == [1,'{{foo}}','{{bar}}',4]
    t = listify_lookup_plugin_

# Generated at 2022-06-11 18:20:14.526693
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # TODO: this should be a special subclass that can be easily mocked
    templar = Templar(loader=None, variables={'a': "{{ b }}", 'b': "{{ c }}", 'c': "hello"})

    # For these tests, fail_on_undefined should have no effect, since all variables are defined
    fail_on_undefined_tests = [True, False]
    bare_var_tests = [True, False]

    # Test a string
    for fail_on_undefined in fail_on_undefined_tests:
        for convert_bare in bare_var_tests:
            terms = listify_lookup_plugin_terms("{{ a }}", templar, None, fail_on_undefined=fail_on_undefined, convert_bare=convert_bare)

# Generated at 2022-06-11 18:20:21.030235
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    part1 = {'_ansible_tmpdir': '/tmp',
             'templar': None}
    part2 = {'asdf': 'asdf',
             'ansible_ssh_host': 'example.org',
             'foo': 'bar'}
    fake_loader = {'_basedir': '/path/to/ansible/',
                   'get_basedir': lambda: '/path/to/ansible/'}
    templar = Dictable()
    templar.environment = Dictable()
    templar.environment.loader = fake_loader
    templar.basedir = '/path/to/ansible/'
    templar.set_available_variables(part1)
    templar.set_available_variables(part2)
    templar.set_available_

# Generated at 2022-06-11 18:20:32.212409
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils import plugin_docs
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode

    terms = [u'{{ foo }}', u'{{ bar }}']
    templar = Templar(loader=None, variables=dict(foo='val1', bar='val2'), vault_secrets=VaultLib())
    result = listify_lookup_plugin_terms(terms, templar, loader=None)
    assert isinstance(result, list)
    assert result == [u'val1', u'val2']

    terms = u'{{ foo }}'