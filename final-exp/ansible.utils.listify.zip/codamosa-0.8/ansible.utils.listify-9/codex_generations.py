

# Generated at 2022-06-11 18:10:40.063055
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # String, no templating
    assert listify_lookup_plugin_terms('hello', Templar(loader=None), loaders=None, fail_on_undefined=False) == ['hello']
    assert listify_lookup_plugin_terms('hello', Templar(loader=None), loaders=None, fail_on_undefined=False, convert_bare=True) == ['hello']

    # String, templating
    assert listify_lookup_plugin_terms('hello {{ "world" }}', Templar(loader=None), loaders=None, fail_on_undefined=False, convert_bare=True) == ['hello world']

    # List, templating

# Generated at 2022-06-11 18:10:51.370782
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None, variables={})
    def run(terms, result, expectation, msg="", convert_bare=False):
        r = listify_lookup_plugin_terms(terms, templar, None, convert_bare=convert_bare)
        assert len(r) == result, msg + ": expected listify_lookup_plugin_terms to return %s and got %s" % (result, r)
        for idx,item in enumerate(r):
            assert item == expectation[idx], msg + ": expected listify_lookup_plugin_terms to return %s and got %s" % (expectation[idx], item)


# Generated at 2022-06-11 18:10:52.460773
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-11 18:11:02.389439
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 'foo', 'b': ['bar', 'bas']}
    variable_manager.options_vars = {'a': '%%foo'}

    templar = Templar(loader=loader, variable_manager=variable_manager)

    # single term
    assert listify_lookup_plugin_terms('{{ a }}', templar=templar) == ['foo']
    assert listify_lookup_plugin_terms(['{{ a }}'], templar=templar) == ['foo']
    assert listify_lookup_plugin_terms

# Generated at 2022-06-11 18:11:13.236006
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        # Ansible 2.9 or earlier (ansible.module_utils.common._collections_compat not available)
        import collections as collections_compat
    except ImportError:
        # Ansible 2.10 or later
        import ansible.module_utils.common._collections_compat as collections_compat
    from ansible.module_utils.six import string_types
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # ANSIBLE_JINJA2_NATIVE=True is required for Ansible 2.9
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms('foo', templar, loader=None) == ['foo']
    assert listify_lookup_plugin_

# Generated at 2022-06-11 18:11:23.216503
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Import here to avoid import loops
    from ansible.template import Templar

    # Test string argument conversion to list
    templar = Templar(None, loader=None)
    terms = listify_lookup_plugin_terms("item1,item2", templar, None)
    assert isinstance(terms, list)
    assert terms == ["item1,item2"]

    # Test list without templating
    templar = Templar(None, loader=None)
    terms = listify_lookup_plugin_terms(["item1", "item2"], templar, None)
    assert isinstance(terms, list)
    assert terms == ["item1", "item2"]

    # Test list with templating
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-11 18:11:28.515412
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    tests = ['foo', ['foo'], '{{ foo }}', ['{{ foo }}'], ['foo', '{{ bar }}'], 'foo,bar']
    for test in tests:
        result = listify_lookup_plugin_terms(test, templar, loader=None)
        assert isinstance(result, list)
        assert test in result

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-11 18:11:39.132035
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    class FakeVarsModule(): pass
    class FakeLoader():
        def get_basedir(self, path):
            return "/d"
    fvars = FakeVarsModule()
    fvars.vars = dict(
        foo = 'bar'
    )
    templar = Templar(loader=FakeLoader(), variables=fvars)
    # ensure a bare string is converted first
    assert(listify_lookup_plugin_terms('{{ foo }},{{ foo }}', templar, FakeLoader(), convert_bare=True) == ['bar,bar'])
    assert(listify_lookup_plugin_terms('{{ foo }},{{ foo }}', templar, FakeLoader(), convert_bare=False) == ['{{ foo }},{{ foo }}'])

    # ensure we can pass a bare

# Generated at 2022-06-11 18:11:49.442478
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleUnicode
    class DataLoader:
        class VariableManager:
            class HostVars:
                def __getitem__(self, hostname):
                    return {}
            hostvars = HostVars()
    class Play:
        connection = "local"

    loader = DataLoader()
    templar = Templar(loader=loader, play=Play())
    play_context = PlayContext()
    loader.variable_manager = templar.variable_manager
    loader.variable_manager.set_nonpersistent_facts(dict(one='1'))
    templar.set_

# Generated at 2022-06-11 18:12:00.163762
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test with dict
    terms = dict(a=1, b=2)
    result = listify_lookup_plugin_terms(terms, None, None)
    assert result == [
        dict(a=1, b=2)
    ]

    # Test with dict containing a string
    terms = dict(a=1, b="2")
    result = listify_lookup_plugin_terms(terms, None, None)
    assert result == [
        dict(a=1, b="2")
    ]

    # Test with dict containing a dict
    terms = dict(a=1, b=dict(c=3, d=4))
    result = listify_lookup_plugin_terms(terms, None, None)

# Generated at 2022-06-11 18:12:11.843843
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'a': 'foo', 'b': 'bar'})
    assert(listify_lookup_plugin_terms(['a', 'b'], templar, loader=None) == ['foo', 'bar'])
    assert(listify_lookup_plugin_terms(['a', 'b'], templar, loader=None, fail_on_undefined=False) == ['foo', 'bar'])
    assert(listify_lookup_plugin_terms(['a', '{{b}}'], templar, loader=None) == ['foo', 'bar'])
    assert(listify_lookup_plugin_terms('{{a}}', templar, loader=None) == ['foo'])

# Generated at 2022-06-11 18:12:21.481353
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.plugins import loader as plugin_loader

    variable_manager = VariableManager()
    loader = DataLoader()
    options = lambda x: None
    options.connection = 'local'
    options.module_paths = None
    options.forks = 1
    options.become = False
    options.become_method = None
    options.become_user = None
    options.check = False
    options.listhosts = None
    options.listtasks = None

# Generated at 2022-06-11 18:12:33.245371
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    def check(terms, expected, convert_bare=False, fail_on_undefined=True):
        if convert_bare:
            # if converting to bare variables, the input value is a string
            assert isinstance(terms, string_types)
        else:
            # otherwise, the input value is a list
            assert isinstance(terms, list)
        templar = DummyTemplar()
        loader = DummyLoader()
        result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=fail_on_undefined, convert_bare=convert_bare)
        assert result == expected, result

    check([['a'], ['b']], [['a'], ['b']])
    check('{{a}} {{b}}', [['x'], ['y']])


# Generated at 2022-06-11 18:12:41.735684
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    from ansible_collections.ansible.my_collection.plugins.module_utils import listify_lookup_plugin_terms

    terms = "{{ lookup('env', 'USER') }}"
    t = Templar(loader=DataLoader())
    result = listify_lookup_plugin_terms(terms, t, t._loader)
    assert isinstance(result, list)
    assert len(result) == 1
    assert isinstance(result[0], string_types)

    terms = ["{{ lookup('env', 'USER') }}", "{{ lookup('pipe', 'whoami') }}"]
    t = Templar(loader=DataLoader())
    result = listify_lookup_plugin_terms(terms, t, t._loader)
   

# Generated at 2022-06-11 18:12:51.783684
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test simple lists
    test_terms = ["foo", "bar"]
    assert listify_lookup_plugin_terms(test_terms, templar, loader) == test_terms

    # Test simple string
    test_terms = "foo"
    assert listify_lookup_plugin_terms(test_terms, templar, loader) == [test_terms]

    # Test string with embedded newline
    test_terms = "foo\nbar"

# Generated at 2022-06-11 18:13:03.248601
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import combine_vars

    templar = Templar(loader=None, shared_loader_obj=None, variables=combine_vars(loader=None, variables=None))

    # test a string
    result = listify_lookup_plugin_terms('{{ foo }}', templar, loader=None)
    assert result == [u'{{ foo }}']

    # test a list of strings
    result = listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], templar, loader=None)

# Generated at 2022-06-11 18:13:13.901130
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # Some limits of the string-only behavior:
    # 1. Don't let something turn into a list
    assert 'foo' == listify_lookup_plugin_terms('foo', templar, loader)
    assert 'foo' == listify_lookup_plugin_terms(['foo'], templar, loader)

    # 2. Don't let something turn into a string
    assert ['foo', 'bar'] == listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)

    # 3. If we're passed a string, template it

# Generated at 2022-06-11 18:13:23.778147
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.plugins.loader import lookup_loader

    # Make sure the lookup_loader is initialized
    lookup_loader._create_lookup_plugins()

    v = VariableManager()
    c = PlayContext()
    t = Templar(loader=None, variables=v, conext=c)

    assert listify_lookup_plugin_terms(['foo', 'bar'], t, None, fail_on_undefined=False) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('foo, bar', t, None, fail_on_undefined=False) == ['foo, bar']

# Generated at 2022-06-11 18:13:35.861260
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = DictDataLoader({})
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('a', templar, loader, convert_bare=False) == ['a']
    assert listify_lookup_plugin_terms('a b', templar, loader, convert_bare=False) == ['a', 'b']
    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader, convert_bare=False) == ['a', 'b']
    assert listify_lookup_plugin_terms('{{a}} {{b}}', templar, loader, convert_bare=False) == ['{{a}}', '{{b}}']

# Generated at 2022-06-11 18:13:44.929155
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader, filter_loader
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Setup
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    hostvars = variable_manager.get_vars(play=None, host=inventory.get_host("localhost"))
    jinja_context

# Generated at 2022-06-11 18:13:56.313710
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # for this test, we need a templar that returns what was passed
    # in with no actual templating
    from ansible.template import Templar

    class TestTemplar(Templar):
        def __init__(self):
            self._basedir = '.'
            self._available_variables = dict()
            pass

        def set_available_variables(self, variables):
            self._available_variables = variables
            pass

        def template(self, data, preserve_trailing_newlines=True, convert_bare=True, escape_backslashes=True, fail_on_undefined=True):
            return data
            pass

    # create the test object
    tt = TestTemplar()

    # test non-list that is a string
    data = "foo"
    res = listify_look

# Generated at 2022-06-11 18:14:05.850356
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None, variables={'x' : 'foo'})
    assert listify_lookup_plugin_terms('{{x}}', templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms('{{x}}', templar, loader=None, convert_bare=True) == ['foo']
    assert listify_lookup_plugin_terms(['{{x}}'], templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms(['{{x}}'], templar, loader=None, convert_bare=True) == ['foo']

# Generated at 2022-06-11 18:14:06.995822
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: add tests
    pass

# Generated at 2022-06-11 18:14:18.952153
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    my_vars = dict(
        simple_string='hello world',
        list_of_strings=['hello', 'world', '!'],
        dict_of_strings=dict(some='value', other='value2')
    )

# Generated at 2022-06-11 18:14:27.968328
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DictDataLoader({})
    vars_mgr = VariableManager()
    vars_mgr.set_known_hosts_files([])
    inventory = Inventory(loader=loader, variable_manager=vars_mgr)
    templar = Templar(loader=loader, variables=vars_mgr, inventory=inventory)
    # test listify_lookup_plugin_terms
    result = listify_lookup_plugin_terms(['a', 'b'], templar, loader)
    assert to_text(result) == 'a, b'

    result = listify_lookup_plugin_terms('a, b', templar, loader)

# Generated at 2022-06-11 18:14:36.654749
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    t = MyTemplar()

    terms = listify_lookup_plugin_terms(
            ['{{ foo }}', '{{ bar }}'],
            t,
            None,
            fail_on_undefined=True,
            convert_bare=False)
    assert terms == ["A", "B"]

    terms = listify_lookup_plugin_terms(
            ['{{ foo }}', '{{ bar }}'],
            t,
            None,
            fail_on_undefined=True,
            convert_bare=True)
    assert terms == ["A", "B"]

    terms = listify_lookup_plugin_terms(
            '{{ foo }},{{ bar }}',
            t,
            None,
            fail_on_undefined=True,
            convert_bare=False)

# Generated at 2022-06-11 18:14:44.265945
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    terms = u'{{ var1 }},{{ var2 }}\n{{ var3 }}'
    bare_terms = u'{{ var1 }},{{ var2 }},{{ var3 }}'

    assert ['1', '2', '3'] == listify_lookup_plugin_terms(terms, None, None)
    assert ['1', '2', '3'] == listify_lookup_plugin_terms(bare_terms, None, None, convert_bare=True)

    terms = '{{ var1 }},{{ var2 }}'

# Generated at 2022-06-11 18:14:55.019982
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    terms = []


    tests = [
        (
            dict(
                # Test that a string can be converted to a list and
                # that bare strings have curly braces added to them.
                terms='hello',
                convert_bare=True
            ),
            ['{{hello}}']
        ),
        (
            dict(
                terms=["hello", "world"],
            ),
            ["hello", "world"]
        ),
        (
            dict(
                terms="{'foo': 'bar'}",
            ),
            [{'foo': 'bar'}]
        ),
    ]

    for test in tests:

        templar = Templar(loader=DataLoader())

        output = listify_lookup_plugin

# Generated at 2022-06-11 18:15:06.301084
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    assert listify_lookup_plugin_terms(terms=['1', '2'], templar=templar, loader=None) == ['1', '2']
    assert listify_lookup_plugin_terms(terms=AnsibleUnicode('[1, 2]'), templar=templar, loader=None) == ['1', '2']

# Generated at 2022-06-11 18:15:16.322879
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping

    test_vars = {'lookup_var': ['var1', 'var2', 'var3']}

    variable_manager = VariableManager()
    variable_manager.extra_vars = test_vars
    loader = DataLoader()

    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-11 18:15:23.379676
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass  # TODO

# Generated at 2022-06-11 18:15:32.028631
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # Define fixtures
    test_data = {
        'value': '1',
        'value_list': [1, 2, 3],
        'value_dict': {'value': '1'},
    }

    # Create data loader, templar and add fixtures to data loader
    loader = DataLoader()
    loader.set_vars(ImmutableDict(value=test_data['value']))
    loader.set_vars(ImmutableDict(value_list=test_data['value_list']))
    loader.set_vars(ImmutableDict(value_dict=test_data['value_dict']))
   

# Generated at 2022-06-11 18:15:44.063764
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.errors import AnsibleUndefinedVariable

    # Wont work in terms of loading the test file but will make sure the templar works for this test
    loader = None
    templar = Templar(loader=loader)

    # For test we will just use set_fact for our vars and then call lookup with a list and string
    # so that we can test what happens in listify
    templar._available_variables = dict(a='b', c='d')

    terms = []
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['a', 'c'], result

    terms = 'a'
    result = listify_lookup_

# Generated at 2022-06-11 18:15:53.996872
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    try:
        # Fails when listify_lookup_plugin_terms() is absent or broken.
        from ansible.plugins.lookup import ListifyLookupString
    except ImportError:
        # Can't look up the module without this function.
        return
    assert listify_lookup_plugin_terms('string', None, None) == ['string']
    assert listify_lookup_plugin_terms([ 'string' ], None, None) == ['string']
    assert listify_lookup_plugin_terms(123, None, None) == [123]
    assert listify_lookup_plugin_terms([ 123 ], None, None) == [123]

# Generated at 2022-06-11 18:16:02.822349
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    #from ansible.module_utils.common._collections_compat import Sequence

    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], None, None) == ['foo']
    assert listify_lookup_plugin_terms('foo,bar', None, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None) == ['foo', 'bar']
    #assert isinstance(listify_lookup_plugin_terms(('foo', 'bar'), None, None), Sequence)

    # Check that adding an extra string to the end of a sequence doesn't cause
    # any problems.

# Generated at 2022-06-11 18:16:13.299811
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    # call the function
    templar = Templar()
    assert listify_lookup_plugin_terms('a', templar, None, False, False) == ['a']
    assert listify_lookup_plugin_terms('a,b', templar, None, False, False) == ['a', 'b']
    assert listify_lookup_plugin_terms('a, b', templar, None, False, False) == ['a', 'b']
    assert listify_lookup_plugin_terms(['a', 'b'], templar, None, False, False) == ['a', 'b']
    assert listify_lookup_plugin_terms('{{ a }}', templar, None, True, False) == ['{{ a }}']
    assert listify_lookup_plugin

# Generated at 2022-06-11 18:16:25.458913
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.template import Templar, Jinja2TemplateError
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    class Options(object):
        _variable_manager = None

    class Play(object):
        context = PlayContext()
        variable_manager = VariableManager()
        templar = None

    class Host(object):
        pass

    class Task(object):
        pass

    task = Task()
    task._role = None
    task._role_context = None
    task._task = task
    task._block = None
    task._play = Play()
    task.loader = None
    task.host = Host()
    task.host.get_vars = lambda: {}
    task._host = task.host
    task

# Generated at 2022-06-11 18:16:34.607862
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test is a bit of a misnomer as it tests multiple things
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_inventory('localhost'))

    test_data = OrderedDict()
    test_data['simple_string'] = 'foo'
    test_data['simple_list'] = ['foo', 'bar', 'baz']
    test_data['variable_string'] = '{{ foo }}'
    test_data['variable_list'] = ['{{ foo }}', '{{ bar }}', '{{ baz }}']

# Generated at 2022-06-11 18:16:44.913783
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.compat import unittest
    from units.compat.mock import Mock, patch

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.utils.unicode import to_unicode
    from ansible.plugins.lookup import LookupBase

    class TestLookup(LookupBase):

        def run(self, terms, inject=None, **kwargs):
            return []

    class TestVars(unittest.TestCase):

        def setUp(self):
            self._variable_manager = VariableManager()
            self._loader = Mock()

            self._v

# Generated at 2022-06-11 18:16:54.490403
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms(["a", "b", "c"], templar, loader) == ["a", "b", "c"]
    assert listify_lookup_plugin_terms(["a", "b", "{{c}}"], templar, loader, fail_on_undefined=False) == ["a", "b", "{{c}}"]

# Generated at 2022-06-11 18:17:18.191048
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variables = VariableManager()

    templar = Templar(loader=loader, variables=variables)

    inputs = [
        [1],
        ["1", "2", "3", "4"],
        ["foo"],
        "foo",
    ]

    for term in inputs:
        result = listify_lookup_plugin_terms(term, templar, loader)
        assert isinstance(result, list)

    assert result == ['1', '2', '3', '4']
    assert len(result) == 4

    result = listify_lookup_plugin_terms('{{ foo }}', templar, loader)

# Generated at 2022-06-11 18:17:28.915618
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # run some tests
    class Fake(object):
        def __init__(self, result):
            self._result = result

        def template(self, *args, **kwargs):
            return self._result

    def _test(terms):
        templar = Fake(terms)
        loader = Fake(None)
        return listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False, convert_bare=False)

    assert _test('test') == ['test']
    assert _test(u'test') == ['test']
    assert _test([u'test1', u'test2']) == [u'test1', u'test2']
    assert _test(['test1', 'test2']) == ['test1', 'test2']

# Generated at 2022-06-11 18:17:35.221182
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # check that string is converted to list
    assert listify_lookup_plugin_terms('dummy_string', None, None) == ['dummy_string']
    # check that list of strings is unchanged
    assert listify_lookup_plugin_terms(['dummy_string', 'dummy_string2'], None, None) == ['dummy_string', 'dummy_string2']

# Generated at 2022-06-11 18:17:46.268458
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variable_manager=variable_manager)

    def ternary_undefined_vars(a, b, c):
        '''Return a if defined, else b if defined, else return c'''

        return a if variable_manager.get_vars().get(a, None) else (
            b if variable_manager.get_vars().get(b, None) else c
        )

    variable_manager.set_available_variables(
        hostvars = dict(
            host = dict(
                t = 'template',
            ),
        ),
    )

# Generated at 2022-06-11 18:17:54.406032
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """This is not a 'real' unit test but it allows you to test this
    function as a stand-alone program.
    """
    import sys

    from ansible.utils.display import Display
    from ansible.template import Templar

    display = Display()
    templar = Templar(loader=None, variables={'test': 42, 'string': 'hello'})

    print("Input:")
    print(sys.argv[1:])

    print("Output:")
    print(listify_lookup_plugin_terms(sys.argv[1:], templar, None, fail_on_undefined=True))

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-11 18:18:02.267408
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_id = VaultSecret("vault_id", "vault_secret")
    loader = DictDataLoader({
        "vars": {"password": "MySecretPassword"},
        "identities": [vault_id]
    })
    all_vars = {"my_custom_var": "foo"}
    templar = Templar(loader, variables=all_vars)

    # Asserts on empty terms
    assert listify_lookup_plugin_terms("", templar, loader) == []
    assert listify_lookup_plugin_terms(None, templar, loader) == []

# Generated at 2022-06-11 18:18:13.759219
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    from ansible.template import Templar

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    from ansible.module_utils._text import to_bytes

    # to load plugins
    from ansible.plugins.loader import lookup_loader

    # Test 1: convert to list of strings

    # Setup template args

# Generated at 2022-06-11 18:18:22.682626
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from jinja2 import Environment, DictLoader
    env = Environment(loader=DictLoader({}))

    # test stringify
    assert(listify_lookup_plugin_terms('item1', env, None) == ['item1'])

    # test pass through
    assert(listify_lookup_plugin_terms(['item1', 'item2'], env, None) == ['item1', 'item2'])

    # test stringify with templating
    assert(listify_lookup_plugin_terms('{{ item }}', env, None, convert_bare=True) == ['item'])

# Generated at 2022-06-11 18:18:32.725285
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    class MockVarsModule(object):
        def get_vars(self, loader, play, host, task):
            return dict(a=1)
    def test(terms, template, templated):
        args = {}
        args['templar'] = Templar(loader=DataLoader(), variables=dict(a=1))
        args['terms'] = terms
        assert listify_lookup_plugin_terms(**args) == templated
        args['convert_bare'] = True
        assert listify_lookup_plugin_terms(**args) == [template]

    test("{{ a }}", "{{ a }}", [1])
    test("{{ a }}", "{{ a }}", [1])

# Generated at 2022-06-11 18:18:44.137164
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.module_utils.common._collections_compat import OrderedDict
    class FakeVars(object):
        def __init__(self, data):
            self.data = data
        def get_vars(self):
            return self.data
    class Fake(object):
        _templar = None
        _loader = None
        def __init__(self):
            self._templar = Fake()
            self._loader = Fake()

# Generated at 2022-06-11 18:19:19.526079
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables=dict(foo='bar'))

    # Invalid inputs
    assert listify_lookup_plugin_terms(None, templar, None) == [None]
    assert listify_lookup_plugin_terms(False, templar, None) == [False]

    # Valid inputs
    assert listify_lookup_plugin_terms(['hello', 'world'], templar, None) == ['hello', 'world']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, None) == ['bar']

# Generated at 2022-06-11 18:19:27.783104
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    templar = FakeTemplar()
    loader = FakeLoader()
    assert listify_lookup_plugin_terms(['one', 'two'], templar, loader) == ['one', 'two']
    assert listify_lookup_plugin_terms(['one', '{{two}}'], templar, loader) == ['one', 'two']
    assert listify_lookup_plugin_terms([1, 2], templar, loader) == [1, 2]
    assert listify_lookup_plugin_terms('one', templar, loader) == ['one']
    assert listify_lookup_plugin_terms('{{one}}', templar, loader) == ['one']
    assert listify_lookup_plugin_terms(None, templar, loader) == [None]
    assert listify_lookup

# Generated at 2022-06-11 18:19:37.287281
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    yaml_str = """
        foo:
          - bar: 1
          - bar: 2
          - bar: 3
    """

    my_vars = VariableManager()
    my_vars.extra_vars = {'foo': [{'bar': 1}, {'bar': 2}, {'bar': 3}]}

    data = AnsibleLoader(yaml_str, variable_manager=my_vars).get_single_data()

   

# Generated at 2022-06-11 18:19:46.520089
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import pytest

    # required for getting a proper PlayContext object
    fake_loader = DictDataLoader({})
    fake_inventory = Inventory(loader=fake_loader, variable_manager=VariableManager(), host_list=[])
    fake_variable_manager = VariableManager()
    fake_variable_manager.set_inventory(fake_inventory)
    play_context = PlayContext()
    play_context.network_os = 'default'
    play_context.remote_addr = 'default'
    play_context.port = 22
    option

# Generated at 2022-06-11 18:19:54.056752
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template.safe_eval import safe_eval

    from ansible.module_utils.common.collections import is_sequence

    # no change
    ret = listify_lookup_plugin_terms([1,2,3], safe_eval, {})
    assert is_sequence(ret)
    assert len(ret) is 3

    # convert bare string literal
    ret = listify_lookup_plugin_terms("1", safe_eval, {}, convert_bare=True)
    assert is_sequence(ret)
    assert len(ret) is 1
    assert ret[0] is 1

    # do not convert bare string literal
    ret = listify_lookup_plugin_terms("1", safe_eval, {}, convert_bare=False)
    assert is_sequence(ret)
    assert len(ret) is 1


# Generated at 2022-06-11 18:20:01.628123
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    v = VariableManager()
    t = Templar(loader=DataLoader(), variable_manager=v)

    # Test conversion of string to list
    assert listify_lookup_plugin_terms('foo', templar=t, loader=None) == ['foo']

    # Test conversion of scalar to list
    assert listify_lookup_plugin_terms(42, templar=t, loader=None) == [42]

    # Test conversion of list to list
    assert listify_lookup_plugin_terms([1, 2, 3], templar=t, loader=None) == [1, 2, 3]

# Generated at 2022-06-11 18:20:13.406229
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar(loader=None)

    # Test with a bare value
    new_terms = listify_lookup_plugin_terms('{{ hello }}', templar, loader=None, fail_on_undefined=False, convert_bare=True)
    assert len(new_terms) == 1
    assert isinstance(new_terms[0], UnsafeProxy)
    assert str(new_terms[0]) == "{{ hello }}"

    # Test with a jinja2 expression

# Generated at 2022-06-11 18:20:20.965522
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Add a unit test that shows that listify_lookup_plugin_terms() works for a comma separated list of hostnames and variables
    import os.path
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    cwd = os.path.dirname(os.path.realpath(__file__))
    loader = DataLoader()
    myvars = dict(
        host1 = "host1-name",
        host2 = "host2-name",
        host3 = "host3-name",
        hosts = "host1, host2, host3"
    )
    templar = Templar(loader=loader, variables=myvars)

    terms = listify_lookup_plugin_terms("{{hosts}}", templar, loader)

# Generated at 2022-06-11 18:20:31.078047
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # simple test that returns list of strings
    test_string = "one"
    assert type(listify_lookup_plugin_terms(test_string, None, None)) is list
    assert type(listify_lookup_plugin_terms(test_string, None, None)[0]) is str

    # simple test that returns list of strings
    test_list = ["one", "two", "three"]
    assert type(listify_lookup_plugin_terms(test_list, None, None)) is list
    assert type(listify_lookup_plugin_terms(test_list, None, None)[0]) is str


if __name__ == '__main__':
    import pytest
    pytest.main()