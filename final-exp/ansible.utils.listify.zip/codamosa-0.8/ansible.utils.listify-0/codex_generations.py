

# Generated at 2022-06-11 18:10:39.742208
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Define unit tests for the listify_lookup_plugin_terms function'''

    from ansible.module_utils.common._collections_compat import OrderedDict

    from ansible.template.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=combine_vars(play_context.var_manager, play_context.extra_vars),
                      fail_on_undefined=True)

    # listify_lookup_plugin_terms returns a list of all items when given a list
    assert listify_lookup_plugin_terms

# Generated at 2022-06-11 18:10:51.046841
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import merge_hash

    # Setup templar
    vault = VaultLib([])
    loader = lambda *args, **kwargs: None
    loader.path_dwim = lambda x: x
    templar = Templar(loader=loader, vault_secrets=vault)

    # Setup vars
    variables = dict(
        file=dict(
            name='surprise.txt',
            pkg=dict(
                desc='package description'
            )
        )
    )

    # String, no jinja2

# Generated at 2022-06-11 18:10:57.788023
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))
    assert listify_lookup_plugin_terms('foo', templar, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, None) == ['foo', 'bar']

    vm = VariableManager()
    vm.set_variable('cache_dir', '/var/tmp')
    templar._available_variables = vm
    assert listify_lookup_plugin_terms('{{cache_dir}}/foo', templar, None) == ['/var/tmp/foo']

# Generated at 2022-06-11 18:11:05.193844
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def test_data_types(terms, templar, assert_terms_type, assert_terms_amount, assert_terms_items):

        result = listify_lookup_plugin_terms(terms, templar, '')

        assert type(result) is assert_terms_type

        assert len(result) is assert_terms_amount

        assert result == assert_terms_items

    class TestTemplar():

        def template(self, terms, fail_on_undefined = True, convert_bare = False):

            return terms

    templar = TestTemplar()

    # Test list

# Generated at 2022-06-11 18:11:15.094770
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DictDataLoader()
    loader.set_basedir('')

    variable_manager = DictDataManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.options_vars = {}

    templar = Templar(loader=loader, variable_manager=variable_manager)

    # test scalar string
    data = "{{ foo }}"
    expected = ["bar"]
    actual = listify_lookup_plugin_terms(data, templar, loader)
    assert actual == expected

    # test scalar non-string
    data = 1
    expected = [1]
    actual = listify_lookup_plugin_terms(data, templar, loader)
    assert actual == expected

    # test list of scalars


# Generated at 2022-06-11 18:11:26.233849
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.template import Templar

    templar = Templar(loader=None, variables=None)

    assert listify_lookup_plugin_terms('hello', templar, None) == ['hello']
    assert listify_lookup_plugin_terms('hello, world', templar, None) == ['hello', 'world']
    assert listify_lookup_plugin_terms(['hello', 'world'], templar, None) == ['hello', 'world']

    # `convert_bare` affects whether the output is a string or list, so only test for list
    assert isinstance(listify_lookup_plugin_terms('hello, world', templar, None, convert_bare=True), list)

    # test failure on undefined

# Generated at 2022-06-11 18:11:32.709875
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()

    template_vars = {}
    templar = Templar(loader=loader, variables=template_vars)

    assert listify_lookup_plugin_terms(None, templar, loader) == []
    assert listify_lookup_plugin_terms("", templar, loader) == []

    assert listify_lookup_plugin_terms(["a", "b"], templar, loader) == ['a', 'b']
    assert listify_lookup_plugin_terms(["a", ["b", "c"]], templar, loader) == ['a', ['b', 'c']]


# Generated at 2022-06-11 18:11:43.378465
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    import sys
    if sys.version_info[0] == 3:
        string_types = (str, bytes)
        Iterable = (list, set, tuple, str)
    else:
        string_types = (str, unicode)
        Iterable = (list, set, tuple, str, unicode)

    class LookupModule(object):
        def __init__(self, basedir=None, **kwargs):
            pass

        def run(self, terms, inject=None, **kwargs):
            print('In run')

# Generated at 2022-06-11 18:11:48.403402
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms(terms='{{ foo }}', templar=None, loader=None) == "{{ foo }}"
    assert listify_lookup_plugin_terms(terms=['{{ foo }}', 'bar'], templar=None, loader=None) == ['{{ foo }}', 'bar']
    assert listify_lookup_plugin_terms(terms=['{{ foo }}'], templar=None, loader=None) == ['{{ foo }}']
    assert listify_lookup_plugin_terms(terms=['{{ foo }}', '{{ bar }}'], templar=None, loader=None) == ['{{ foo }}', '{{ bar }}']

# Generated at 2022-06-11 18:11:52.341836
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    templar = DummyVars()
    terms = listify_lookup_plugin_terms(
        ['{{foo}}', '{{bar}}', '{{bam}}'],
        templar,
        loader=None,
        fail_on_undefined=True,
        convert_bare=False,
    )
    assert terms == ['Chinese', 'say', 'ni']



# Generated at 2022-06-11 18:12:04.168570
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # pylint: disable=unused-variable,unused-import
    import ansible.module_utils.six as six
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # basic test
    templar = Templar(loader=DataLoader(), variables=VariableManager())
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader=DataLoader()) == ['{{ foo }}']
    assert listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], templar, loader=DataLoader()) == ['{{ foo }}', '{{ bar }}']

    # change to bare

# Generated at 2022-06-11 18:12:05.136853
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO
    pass

# Generated at 2022-06-11 18:12:13.625913
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY3
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    if PY3:
        unicode = str

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_available_variables({'food': 'stuff'})
    templar = Templar(loader=loader, variables=variable_manager)

    query = '{{ foo }}'
    result = listify_lookup_plugin_terms(query, templar, loader, False)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == query

    query = '{{ food }}'
    result = listify_lookup_plugin

# Generated at 2022-06-11 18:12:22.359679
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    loader = "foobar"

    assert listify_lookup_plugin_terms('foo', Templar(loader=loader), loader) == ['foo']
    assert listify_lookup_plugin_terms('foo:bar', Templar(loader=loader), loader) == ['foo:bar']
    assert listify_lookup_plugin_terms('[ foo, bar ]', Templar(loader=loader), loader) == ['[ foo, bar ]']
    assert listify_lookup_plugin_terms(['foo', 'bar'], Templar(loader=loader), loader) == ['foo', 'bar']

    assert listify_lookup_plugin_terms(1, Templar(loader=loader), loader) == [1]
    assert listify_lookup_plugin_terms({'key': 'value'}, Templar(loader=loader), loader)

# Generated at 2022-06-11 18:12:34.203365
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    from ansible.module_utils.common._collections_compat import Mapping

    # Dummy VariableManager that doesn't do templating
    class DummyVariableManager(VariableManager):
        def __init__(self):
            super(DummyVariableManager, self).__init__()
            self.vars = {}

        def __getitem__(self, varname):
            return self.vars[varname]

        def __setitem__(self, varname, value):
            self.vars[varname] = value


# Generated at 2022-06-11 18:12:42.339309
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # FIXME: convert to unit test format
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    t = Templar(loader=DataLoader(), variables=VariableManager())

    assert listify_lookup_plugin_terms("foo", t) == ["foo"]
    assert listify_lookup_plugin_terms("foo bar", t) == ["foo bar"]
    assert listify_lookup_plugin_terms("foo,bar", t) == ["foo,bar"]
    assert listify_lookup_plugin_terms("foo, bar", t) == ["foo, bar"]
    assert listify_lookup_plugin_terms

# Generated at 2022-06-11 18:12:46.735011
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import AnsibleModule
    from ansible.template import Templar

    module = AnsibleModule(argument_spec={
        'terms': dict(required=True, type='list'),
    })
    templar = Templar(loader=module._loader, variables=module.params)

    # Test string input, should return list
    assert type(listify_lookup_plugin_terms('foo', templar, module._loader)) is list
    assert len(listify_lookup_plugin_terms('foo', templar, module._loader)) is 1

    # Test list input, should return list
    assert type(listify_lookup_plugin_terms(['foo'], templar, module._loader)) is list

# Generated at 2022-06-11 18:12:54.820278
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    vars_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=vars_manager)

    # test that a single string becomes a list with a single element
    terms = 'string1'
    res = listify_lookup_plugin_terms(terms, templar, loader)
    assert len(res) == 1 and res[0] == 'string1'

    # test that a list is returned as is
    terms = ['string1', 'string2']
    res = listify_lookup_plugin_terms(terms, templar, loader)
    assert len(res) == 2 and res == terms

    # test that

# Generated at 2022-06-11 18:13:04.716224
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    lookup_dict = {
        'omg': 'wow'
    }

    mock_loader = MockLoader(lookup_dict)

    my_vars = {
        'omg': 'yes'
    }

    templar = Templar(loader=mock_loader, variables=my_vars)
    templar._available_variables = my_vars

    # Test case 1: Pass a string parameter
    terms = listify_lookup_plugin_terms('{{ omg }}', templar, mock_loader)
    assert terms == ['yes']

    terms = listify_lookup_plugin_terms('hello', templar, mock_loader)
    assert terms == ['hello']

    # Test case 2: Pass a list parameter
    terms = listify_lookup_plugin_

# Generated at 2022-06-11 18:13:15.554284
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class MockTemplar(object):
        def __init__(self, fail_on_undefined):
            self.fail_on_undefined = fail_on_undefined
        def template(self, terms, fail_on_undefined=None, convert_bare=False):
            return terms

    templar = MockTemplar(fail_on_undefined=True)

    # Test the string case
    lookup_plugin_terms = [
        ("string", ["string"]),
        ("    string    ", ["string"]),
        ("string1,string2", ["string1,string2"]),
        ("    string1,string2    ", ["string1,string2"]),
        ("string        ", ["string        "]),
    ]


# Generated at 2022-06-11 18:13:25.703078
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variables = VariableManager()

    def get(key, *args, **kwargs):
        return 'somehost'

    loader.get = get

    ds = 'somehost'
    templar = Templar(loader=loader, variables=variables)

    result = listify_lookup_plugin_terms(ds, templar, loader)

    assert isinstance(result, list)
    assert len(result) == 1
    assert result == ['somehost']

    ds = [ "somehost", "otherhost" ]

    result = listify_lookup_plugin_terms(ds, templar, loader)


# Generated at 2022-06-11 18:13:37.565573
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from jinja2 import Environment
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert listify_lookup_plugin_terms('123', Templar(None, {}), None) == ['123']
    assert listify_lookup_plugin_terms('123', Templar(None, {}), None) == ['123']
    assert listify_lookup_plugin_terms(['123'], Templar(None, {}), None) == ['123']
    assert listify_lookup_plugin_terms(123, Templar(None, {}), None) == [123]
    assert listify_lookup_plugin_terms([123], Templar(None, {}), None) == [123]
    assert listify_lookup_plugin

# Generated at 2022-06-11 18:13:46.284484
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import template
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms('foobar', templar, loader, convert_bare=False) == ['foobar']
    assert listify_lookup_plugin_terms('{{ foo }}', templar, loader, convert_bare=False) == ['{{ foo }}']
    assert listify_lookup_plugin_terms(u'{{ foo }}', templar, loader, convert_bare=False) == [u'{{ foo }}']
    assert listify_lookup_plugin_terms(['a', 'b'], templar, loader, convert_bare=False) == ['a', 'b']

# Generated at 2022-06-11 18:13:54.301263
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert listify_lookup_plugin_terms('1', Templar({}, {}), {}) == ['1']
    assert listify_lookup_plugin_terms('1,2', Templar({}, {}), {}) == ['1', '2']
    assert listify_lookup_plugin_terms([1,2], Templar({}, {}), {}) == [1, 2]
    assert listify_lookup_plugin_terms(['1', '2'], Templar({}, {}), {}) == ['1', '2']
    assert listify_lookup_plugin_terms('{{ var }}', Templar(dict(var=[1,2]), {}), {}) == [1, 2]

# Generated at 2022-06-11 18:14:04.281015
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import context
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader, variables={'foo': 'bar', 'a': ['b', 'c']})

    # string as term
    terms = listify_lookup_plugin_terms('foo', templar, loader, convert_bare=True)
    assert terms == ['bar']

    # list as term
    terms = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader, convert_bare=True)
    assert terms == ['foo', 'bar']

    # item in list is templated

# Generated at 2022-06-11 18:14:11.201330
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    templar = Templar(play_context=PlayContext(), variable_manager=VariableManager())

    def _tmpl(s, fail_on_undefined=False, convert_bare=True):
        return templar.template(s, fail_on_undefined=fail_on_undefined, convert_bare=convert_bare)

    # no string should return original value
    assert listify_lookup_plugin_terms([], templar) == []

    # string without ',' should return the same item in list
    s = 'foo'
    assert listify_lookup_plugin_terms(s, templar) == [s]

    # string with ',' should return list

# Generated at 2022-06-11 18:14:12.812633
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # NOTE: mocking Templar here is largely useless as Templa

# Generated at 2022-06-11 18:14:19.722844
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars import VariableManager

    templar = Templar(loader=AnsibleLoader(None))
    vm = VariableManager()
    vm.set_host_variable("localhost", "foo", "bar")
    templar._available_variables = vm
    terms = listify_lookup_plugin_terms("{{ foo }}", templar, None)
    assert terms == ["bar"]

# Generated at 2022-06-11 18:14:29.444743
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    terms = [['1', '2', '3'], dict(var='1')]
    templated = listify_lookup_plugin_terms(terms, templar, loader)
    assert templated == terms, templated

    terms = ['{{var}}', dict(var='1')]
    templated = listify_lookup

# Generated at 2022-06-11 18:14:36.353787
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))
    assert listify_lookup_plugin_terms('object', templar, None) == ['object']
    assert listify_lookup_plugin_terms([1, 2, 3], templar, None) == [1, 2, 3]

    assert listify_lookup_plugin_terms(u'object', templar, None) == ['object']
    assert listify_lookup_plugin_terms([1, 2, 3], templar, None) == [1, 2, 3]

    terms = (('name1', 'value1'), ('name2', 'value2'), ('name3', 'value3'))
    assert listify_lookup

# Generated at 2022-06-11 18:14:49.888449
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager(), vault_secrets=None)

    assert listify_lookup_plugin_terms('test', templar, None) == ['test']
    assert listify_lookup_plugin_terms(u'foo\u2019s bar', templar, None) == [u'foo\u2019s bar']
    assert listify_lookup_plugin_terms([u'foo\u2019s bar', 'test'], templar, None) == [u'foo\u2019s bar', 'test']

# Generated at 2022-06-11 18:14:57.931424
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test when terms is a string
    terms = "1, 2, 3,4, 5"
    expected = ["1", "2", "3", "4", "5"]
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(result, list)
    assert result == expected

    # Test when terms is a list
    terms = ["1", "2", "3", "4", "5"]
    expected = ["1", "2", "3", "4", "5"]
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance

# Generated at 2022-06-11 18:15:07.398723
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test quoted comma-separated list
    assert (listify_lookup_plugin_terms('i-1234, i-5678, i-4321', None, None) == ['i-1234', 'i-5678', 'i-4321'])
    assert (listify_lookup_plugin_terms('["i-1234", "i-5678", "i-4321"]', None, None) == ['i-1234', 'i-5678', 'i-4321'])
    assert (listify_lookup_plugin_terms(['i-1234', 'i-5678', 'i-4321'], None, None) == ['i-1234', 'i-5678', 'i-4321'])

    # test quoted comma-separated list inside variable

# Generated at 2022-06-11 18:15:16.741343
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    >>> listify_lookup_plugin_terms('one two',None,None)
    ['one two']
    >>> listify_lookup_plugin_terms(['one two'],None,None)
    ['one two']
    >>> listify_lookup_plugin_terms(['one','two'],None,None)
    ['one', 'two']
    >>> listify_lookup_plugin_terms(['{{ terms }}','three','four'],FakeTemplar(['one','two']),None)
    ['one', 'two', 'three', 'four']
    >>> listify_lookup_plugin_terms('{{ terms }}',FakeTemplar(['one','two']),None)
    ['one', 'two']
    '''
    pass


# Generated at 2022-06-11 18:15:23.838606
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # for testing we mock the templar object
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    terms = 'foo.txt'
    unsafe_proxy = templar.template(terms, fail_on_undefined=True)
    assert isinstance(unsafe_proxy, AnsibleUnsafeText)
    assert terms == unsafe_proxy.value
    terms = 'foo.txt, bar.txt'
    unsafe_proxy = templar.template(terms, fail_on_undefined=True)
    assert isinstance(unsafe_proxy, AnsibleUnsafeText)
    assert terms == unsafe_proxy.value
    terms = ['foo.txt', 'bar.txt']
    unsafe_proxy = templar

# Generated at 2022-06-11 18:15:32.269278
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_mgr = VariableManager()
    variable_mgr.set_inventory(loader.load_inventory('localhost,'))
    templar = Templar(loader=loader, variable_manager=variable_mgr)


# Generated at 2022-06-11 18:15:44.265930
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    loader = DataLoader()

    templar = Templar(loader=loader, variables=variable_manager)
    listify_lookup_plugin_terms([], templar)
    listify_lookup_plugin_terms("", templar)
    listify_lookup_plugin_terms("x", templar)
    listify_lookup_plugin_terms("x:y", templar)
    listify_lookup_plugin_terms("{{x}}", templar)
    listify_lookup_plugin_terms("{{x}}:y", templar)

# Generated at 2022-06-11 18:15:56.212473
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    fake_loader = DictDataLoader({})
    templar = Templar(loader=fake_loader)

    # Test 1: non-template, non-iterable -- returns list
    result = listify_lookup_plugin_terms('test', templar, fake_loader)
    assert isinstance(result, list)

    # Test 2: non-template, iterable -- returns list
    result = listify_lookup_plugin_terms(['test', 'test'], templar, fake_loader)
    assert isinstance(result, list)

    # Test 3: template, non-iterable -- returns list
    result = listify_lookup_plugin_terms('{{ test }}', templar, fake_loader)
    assert isinstance(result, list)

    # Test 4: template, iter

# Generated at 2022-06-11 18:16:03.840506
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.errors import AnsibleError

    VarsModule = namedtuple('VarsModule', ['vars'])
    MockVarsModule = namedtuple('MockVarsModule', ['vars'])
    MockLoader = namedtuple('LoaderModule', ['get_basedir'])

    templar = Templar(loader=MockLoader(get_basedir=lambda x:''))

    # In this test we are mocking Templar.template() to return a unicode
    # object, we will have to get it converted to a string before comparing
    # with the expected result

# Generated at 2022-06-11 18:16:13.986634
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.template as template
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = None
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    hostvars = inventory.get_host("localhost").get_vars()
    play_context = PlayContext()
    play_context.inventory = inventory
    play_context.variable_manager = variable_manager
    templar = template.Templar(loader=loader, variables=variable_manager.get_vars(host=hostvars, include_hostvars=False), shared_loader_obj=loader, cache=None)


# Generated at 2022-06-11 18:16:29.238892
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class TestTemplar(object):
        def __init__(self):
            self.fail_on_undefined_errors = []

        def template(self, data, convert_bare=False, fail_on_undefined=True, preserve_trailing_newlines=False, escape_backslashes=True, fail_on_undefined_errors=None):
            if fail_on_undefined:
                self.fail_on_undefined_errors.extend(fail_on_undefined_errors)

            return data

    class TestLoader(object):
        def get_basedir(self, *args, **kwargs):
            return '/'

    templar = TestTemplar()
    loader = TestLoader()


# Generated at 2022-06-11 18:16:39.314645
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DictDataLoader({
        "test_template.j2": "{% if True %}lorem ipsum{% endif%}"
    })
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(foo='lorem', bar='ipsum')
    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=loader)

    assert listify_lookup_plugin_terms(42, templar, loader) == [42]

# Generated at 2022-06-11 18:16:47.524130
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    terms = ["{{ item }}", "1", "2", "3", "{{ item }}"]
    templar = Templar(loader=loader, variables={'item': "{{ item }}-test",'list': [1, 2, 3]})
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['{{ item }}-test', '1', '2', '3', '{{ item }}-test']
    result = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=True)

# Generated at 2022-06-11 18:16:55.573767
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    terms_string = '{{ foo }}'
    terms_list = ['{{ foo }}', 'bar', 'baz']

    variable_manager = None
    loader = None
    passwords = {}
    # vault_password = os.environ.get('ANSIBLE_VAULT_PASSWORD_FILE', None)
    vault_password='${ANSIBLE_VAULT_PASSWORD}'
    if vault_password:
        passwords['vault'] = vault_password

    # ansible-vault doesn't initialize ansible.constants.DEFAULT_VAULT_ID_MATCH

# Generated at 2022-06-11 18:17:06.673792
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class DummyVarsModule(object):
        class DummyVars(object):
            def __init__(self):
                pass

            def get_vars(self, loader, play=None, host=None, task=None, include_hostvars=True):
                return {}

        def __init__(self):
            self.vars = self.DummyVars()

    class DummyLoaderModule(object):
        class DummyLoader(object):
            def __init__(self):
                pass

        def __init__(self):
            self.loader = self.DummyLoader()

    # Run the unit test
    templar = Templar(DummyVarsModule(), DummyLoaderModule())
    assert listify_lookup_plugin_terms('localhost', templar, None)

# Generated at 2022-06-11 18:17:13.899635
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    mock_loader = DataLoader()
    mocked_templar = Templar(loader=mock_loader)

    # Test string list, should return a list
    test = listify_lookup_plugin_terms(['a', 'b'], mocked_templar, mock_loader)
    assert test == ['a', 'b']

    # Test single string, should return a list
    test = listify_lookup_plugin_terms('a', mocked_templar, mock_loader)
    assert test == ['a']

    # Test int, should return a list
    test = listify_lookup_plugin_terms(5, mocked_templar, mock_loader)
    assert test == [5]

    # Test dict,

# Generated at 2022-06-11 18:17:24.801776
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager.get_vars())
    templar._available_variables = variable_manager.get_vars(loader=loader, inventory=inventory)


# Generated at 2022-06-11 18:17:25.439182
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-11 18:17:32.439246
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    play_context = PlayContext()
    inventory = VariableManager()

    def get_vars(loader, path, entities, cache=True):
        return dict(a='a', b='b')

    inventory.get_vars = get_vars
    templar = Templar(loader=loader, variables=inventory, play_context=play_context)

    assert listify_lookup_plugin_terms('1', templar, loader) == ['1']
    assert listify_lookup_plugin_terms(['1'], templar, loader) == ['1']

# Generated at 2022-06-11 18:17:40.486157
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('1', templar, loader) == ['1']
    assert listify_lookup_plugin_terms([1], templar, loader) == [1]
    assert listify_lookup_plugin_terms(['{{foo}}'], templar, loader) == ['{{foo}}']

# Generated at 2022-06-11 18:18:02.173281
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext

    vault_secret = 'foo'
    vault = VaultLib([])
    vault_password = vault.decrypt(vault_secret)
    loader = None
    variable_manager = VariableManager(loader=loader)
    variable_manager.extra_vars = {'test_string': 'foo', 'test_dict': {'key1': 'value1', 'key2': 'value2'}, 'test_list': ['a', 'b', 'c']}
    play_context = PlayContext()

# Generated at 2022-06-11 18:18:13.666266
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.listify import listify_lookup_plugin_terms

    args = [
        ('a',
"""
    a:
        - b
        - c
    """),
        ('1 2 3',
"""
    - 1
    - 2
    - 3
    """),
        ('a',
"""
    a: b
    """),
        ('d',
"""
    - a
    - b
    - c
    """),
        (['a','b','c'],
"""
    - a
    - b
    - c
    """),
        ('a',
"""
    a:
        - b
        - c
    """),
    ]

    # test listify_lookup_plugin_terms with the following variables
    #  - args[0][0] as 'terms' argument

# Generated at 2022-06-11 18:18:24.498933
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # The following test cases are from unit test file named 'test_lookup_plugin.py', method named 'test_listify_lookup_plugin_terms'

    # The test cases for 'terms' parameter are:
    # 1. string value
    # 2. list value
    # 3. tuple value
    # 4. number value
    # 5. boolean value
    # 6. None value
    # 7. variable value
    # 8. variable value in string
    # 9. variable value in list
    # 10. variable value in tuple
    # 11. variable value in number
    # 12. variable value in boolean
    # 13. variable value in None


# Generated at 2022-06-11 18:18:34.768681
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test all valid types of terms and skip templar.template()
    # to keep test simple.
    assert listify_lookup_plugin_terms(
        'a b', None, None, fail_on_undefined=False, convert_bare=False
    ) == ['a b']

    assert listify_lookup_plugin_terms(
        'a b', None, None, fail_on_undefined=False, convert_bare=True
    ) == ['a', 'b']

    assert listify_lookup_plugin_terms(
        'a,b', None, None, fail_on_undefined=False, convert_bare=True
    ) == ['a', 'b']


# Generated at 2022-06-11 18:18:46.130186
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    from ansible.vars.manager import VariableManager
    from ansible.vars.collection import VariableCollection
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.unicode import to_unicode

    loader = DataLoader()
    templar = Templar(loader=loader, variables=VariableManager(loader=loader, inventory=InventoryManager(loader=loader)))
    all_vars = dict(foo="bar")
    inv_vars = dict(baz="foo")
    result = listify_lookup_plugin_terms('{{foo}}', templar, loader, fail_on_undefined=True, convert_bare=False)
    assert result == ['bar'] and type(result) == list
   

# Generated at 2022-06-11 18:18:53.311298
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    def fail_on_undefined(self, msg):
        raise AssertionError(msg)

    terms = "{{ some_var }}"
    variables = dict(some_var="some_val")
    templar = Templar(loader=DataLoader(), variables=variables)
    templar._fail_on_undefined = fail_on_undefined

    assert listify_lookup_plugin_terms(terms, templar, loader=DataLoader()) == ["some_val"]
    assert listify_lookup_plugin_terms(terms, templar, loader=DataLoader(), convert_bare=True) == ["{{ some_var }}"]

# Generated at 2022-06-11 18:19:01.962983
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    templar = Templar(loader=DataLoader())

    assert listify_lookup_plugin_terms('1', templar, templar._loader) == ['1']
    assert listify_lookup_plugin_terms(['1'], templar, templar._loader) == ['1']
    assert listify_lookup_plugin_terms(u'1', templar, templar._loader) == [u'1']
    assert listify_lookup_plugin_terms([u'1'], templar, templar._loader) == [u'1']

# Generated at 2022-06-11 18:19:11.491996
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Unit test for function listify_lookup_plugin_terms'''

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    vault_secrets = VaultLib(None)
    variable_manager = VariableManager()

    templar = Templar(loader=loader, variables=variable_manager, vault_secrets=vault_secrets)

    # Test 1
    terms = '"{{ [1, 2, 3] }}"'
    results = listify_lookup_plugin_terms(terms, templar, loader)
    assert(results == [1,2,3])

    # Test 2

# Generated at 2022-06-11 18:19:19.594085
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Test Case: Unstringified list
    templar = Templar(loader=None, variables={'a': [1, 2, 3]})
    terms = listify_lookup_plugin_terms(terms=['{{ a }}'], templar=templar, loader=None)
    assert terms == [[1, 2, 3]]

    # Test Case: Stringified list
    templar = Templar(loader=None, variables={'a': [1, 2, 3]})
    terms = listify_lookup_plugin_terms(terms='{{ a }}', templar=templar, loader=None)
    assert terms == [[1, 2, 3]]

    # Test Case: Unstringified list

# Generated at 2022-06-11 18:19:27.831891
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.loader import lookup_loader

    templar = DummyTemplar(DummyVars())
    loader = DummyLoader('')
    lookup = DummyLookup()

    terms = listify_lookup_plugin_terms('1', templar, loader)
    assert terms == [1]

    terms = listify_lookup_plugin_terms(['1', '2'], templar, loader)
    assert terms == [1, 2]

    terms = listify_lookup_plugin_terms('{{var}}', templar, loader)
    assert terms == [1]

    terms = listify_lookup_plugin_terms(['{{var}}', '2'], templar, loader)
    assert terms == [1, 2]

# Stub function to mimic the behavior of AnsibleTem

# Generated at 2022-06-11 18:20:01.534370
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    t = Templar(loader=None)

    terms = 'test'
    terms = listify_lookup_plugin_terms(terms, t, None)
    assert type(terms) == list
    assert terms == ['test']

    terms = 'test_1'
    terms = listify_lookup_plugin_terms(terms, t, None, False)
    assert type(terms) == list
    assert terms == ['test_1']

    terms = ['test1', 'test2', 'test3']
    terms = listify_lookup_plugin_terms(terms, t, None)
    assert type(terms) == list
    assert terms == ['test1', 'test2', 'test3']

    terms = ['test1', 'test2', 'test3']
    terms = listify_lookup

# Generated at 2022-06-11 18:20:10.605040
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        foo='bar',
    )

    templar = Templar(loader=None, variable_manager=variable_manager)
    test_terms = dict(
        test1='foo',
        test2=['bar', 'baz'],
    )
    for test_term, result_term in test_terms.iteritems():
        assert listify_lookup_plugin_terms(test_term, templar, loader=None) == [result_term]

# Generated at 2022-06-11 18:20:19.593727
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    def setup():
        try:
            from __main__ import display
        except ImportError:
            display = None
        import ansible.template
        templar = ansible.template.Templar(loader=None, variables={}, shared_loader_obj=None)
        return templar

    from ansible.module_utils.common._collections_compat import MutableSequence

    templar = setup()
    assert isinstance(listify_lookup_plugin_terms('127.0.0.1', templar, None, True), MutableSequence)
    assert isinstance(listify_lookup_plugin_terms(['127.0.0.1', '127.0.0.2'], templar, None, True), MutableSequence)

# Generated at 2022-06-11 18:20:27.502837
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # When passed a single term, listify_lookup_plugin_terms returns a list
    listify_lookup_plugin_terms ('foo', None, None)
    assert isinstance(listify_lookup_plugin_terms ('foo', None, None), list)

    # When passed a list of terms, listify_lookup_plugin_terms returns a list
    listify_lookup_plugin_terms (['foo','bar'], None, None)
    assert isinstance(listify_lookup_plugin_terms (['foo','bar'], None, None), list)