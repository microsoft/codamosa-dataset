

# Generated at 2022-06-11 18:10:38.976977
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = None
    templar = Templar(loader=loader)

    # When given a string, convert it to a list of one string
    assert listify_lookup_plugin_terms("foo", templar, loader) == ["foo"]

    # When given a list, do nothing
    assert listify_lookup_plugin_terms(["foo"], templar, loader) == ["foo"]

    # When given a variable, template the variable and convert it to a list of one string
    assert listify_lookup_plugin_terms("{{ bar }}", templar, loader) == ["bar"]

    # When given a list of variables, template all the variables and leave the list untouched

# Generated at 2022-06-11 18:10:46.123355
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    tmpldir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpldir, 'templates'))
    with open(os.path.join(tmpldir, 'templates', 'test.j2'), 'w') as f:
        f.write('test')

    # Test string -> str
    vars_mgr = VariableManager()
    vars_mgr.set_inventory(Inventory(loader=DataLoader()))
    templar = Templar(loader=DataLoader(), variables=vars_mgr)
    terms = listify_lookup_

# Generated at 2022-06-11 18:10:55.191551
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # consts for use in test
    testval1 = '1'
    testval2 = '2'
    testval3 = '3'
    testlist = [testval1, testval2, testval3]
    testlist_str = ','.join(testlist)
    testlist_quoted_str = '"' + '","'.join(testlist) + '"'
    testdict = {'a': {'b': {'c': [testval1, testval2, testval3]}}}

    # TestCase Data class
    #  see: https://docs.python.org/2/library/unittest.html#unittest.TestCase.debug

# Generated at 2022-06-11 18:11:03.962287
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    from ansible.utils.vars import combine_vars

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Populate the variable manager
    variable_manager = VariableManager()
    variable_manager._extra_vars = {'ansible_ssh_pass': 'secret'}

    # Populate the inventory
    inventory = InventoryManager(loader=None, sources=None)
    host = inventory.get_host(hostname='testhost')

    # Create a Templar object
    vars_loader = False
    shared_loader = False

# Generated at 2022-06-11 18:11:14.429860
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import json

    ##############
    #Test listify_lookup_plugin_terms
    ##############

    #####
    #Test string
    #####

    # Test string -> string
    terms = [
                {
                    'test_string': '{{test_var}}'
                }
            ]
    test_loader = DictDataLoader({
        "test_var": [
            "test1",
            "test2"
        ]
    })
    test_vars = DictVars({
        "test_var": "test_var"
    })
    output = listify_lookup_plugin_terms(terms, test_loader, test_vars)
    output = json.dumps(output, sort_keys=True)
    expected = '["{{test_var}}"]'
    assert output == expected

# Generated at 2022-06-11 18:11:25.304891
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import os
    import sys
    import tempfile
    import yaml

    from ansible import constants
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    group = Group(name="testgroup")
    host = Host(name="testhost")
    group.add_host(host)

    inventory = InventoryManager(loader=loader, sources=None)
    inventory.add_group(group)

    variables = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variables)

    listify_look

# Generated at 2022-06-11 18:11:30.960718
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={'foo': ['bar','baz']})

    terms = "{{ foo }}"
    new_terms = listify_lookup_plugin_terms(terms, templar, None)
    assert sorted(new_terms) == sorted(['bar','baz'])

    terms = ['{{ foo }}', 'one']
    new_terms = listify_lookup_plugin_terms(terms, templar, None)
    assert sorted(new_terms) == sorted(['bar','baz','one'])

# Generated at 2022-06-11 18:11:41.965686
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import PY3
    from ansible.module_utils.parsing.convert_bool import boolean

    assert isinstance(listify_lookup_plugin_terms("{{ lookup('pipe', 'echo foo') }}", None, None, convert_bare=True), list)
    assert isinstance(listify_lookup_plugin_terms("foo", None, None, convert_bare=False), list)
    assert isinstance(listify_lookup_plugin_terms("foo {{ bar }}", None, None, convert_bare=True), list)
    if PY3:
        assert isinstance(listify_lookup_plugin_terms("[1,2,3]", None, None, convert_bare=True), list)

# Generated at 2022-06-11 18:11:51.570952
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    display = {'stderr': False, 'stdout': False, 'verbosity': 0}
    templar = Templar(loader=None, variables={}, shared_loader_obj=None, disable_lookups=True)

    assert listify_lookup_plugin_terms('1', templar, loader=None) == ['1']
    assert listify_lookup_plugin_terms([1], templar, loader=None) == [1]
    assert listify_lookup_plugin_terms(['a','b'], templar, loader=None) == ['a','b']
    assert listify_lookup_plugin_terms('{{a+b}}', templar, loader=None, convert_bare=True) == ['{{a+b}}']
    assert listify_lookup_

# Generated at 2022-06-11 18:12:02.322899
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inv)

    terms = "{{ ['foo', 'bar', 'baz'] }}"
    result = listify_lookup_plugin_terms(terms, Templar(loader=loader, variables=variable_manager))
    assert result == ['foo', 'bar', 'baz']

    terms = '{{ foo }}'
    variable_manager.set_nonpersistent_facts(dict(foo=['bip', 'bop']))
    result = listify_lookup_plugin_

# Generated at 2022-06-11 18:12:12.965717
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test function being tested
    from ansible.utils.listify_lookup_plugin_terms import listify_lookup_plugin_terms

    # Import necessary module code
    import ansible.module_utils.basic
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    # Mock necessary modules
    mock_loader = DataLoader()
    mock_vault = VaultLib()

    # Setup test inventory and config
    inventory = ansible.inventory.Inventory(loader=mock_loader, vault_password='test_vault')
    inventory.add_host(ansible.inventory.Host('test_host'))
    inventory.hosts['test_host'].set

# Generated at 2022-06-11 18:12:21.946485
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('foo  bar', templar, loader) == ['foo  bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_

# Generated at 2022-06-11 18:12:33.773078
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from jinja2 import UndefinedError
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())

    assert listify_lookup_plugin_terms(terms='foo', templar=templar) == ['foo']
    assert listify_lookup_plugin_terms(terms='foo,bar', templar=templar) == ['foo','bar']
    assert listify_lookup_plugin_terms(terms=['foo'], templar=templar) == ['foo']
    assert listify_lookup_plugin_terms(terms=['foo','bar'], templar=templar) == ['foo','bar']

# Generated at 2022-06-11 18:12:41.586532
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    templar = Templar(loader=None)

    # Test 1: An integer should return a list with the integer
    terms = listify_lookup_plugin_terms(1, templar, loader=None)
    assert terms == [1], terms

    # Test 2: A string should return a list with the string
    terms = listify_lookup_plugin_terms("1", templar, loader=None)
    assert terms == ["1"], terms

    # Test 3: A list of integers should return the same list
    terms = listify_lookup_plugin_terms([1, 2, 3], templar, loader=None)


# Generated at 2022-06-11 18:12:51.673648
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Function to test the different behaviors of listify_lookup_plugin_terms
    '''

    def create_mock_templar(return_value=None, side_effect=None):
        class mock_templar:
            def __init__(self):
                self.template_data = None
                self.convert_bare = None
                self.fail_on_undefined = None

            def template(self, template_data, convert_bare=None, fail_on_undefined=False):
                self.template_data = template_data
                self.convert_bare = convert_bare
                self.fail_on_undefined = fail_on_undefined
                if side_effect:
                    raise side_effect
                return return_value

        return mock_templar()

    # Test a single string

# Generated at 2022-06-11 18:13:03.210294
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    This is the unittest for listify_lookup_plugin_terms.
    It tests the following cases:
        - string
        - list
        - integer
        - boolean
        - empty string
        - missing var
    '''
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'test': 'value'})

    # Test for string
    assert listify_lookup_plugin_terms('value', templar, None) == ['value']

    # Test for list
    assert listify_lookup_plugin_terms(['value', 'value2'], templar, None) == ['value', 'value2']

    # Test for integer
    assert listify_lookup_plugin_terms(15, templar, None) == [15]

    # Test for boolean

# Generated at 2022-06-11 18:13:13.850576
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    hostvars = dict(omg_a_hostvar=42, lol=dict(another_hostvar=True))
    t = Templar(loader=loader, variables=VariableManager(loader=loader, host_vars=hostvars))

    assert listify_lookup_plugin_terms('this', t, loader) == ['this']
    assert listify_lookup_plugin_terms(['this', 'that'], t, loader) == ['this', 'that']

    assert listify_lookup_plugin_terms('{{lol.another_hostvar}}', t, loader, convert_bare=True) == [True]
    assert listify_look

# Generated at 2022-06-11 18:13:23.738964
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    loader = DictDataLoader({
        'foo.yml': 'bar',
        'bar.yml': 'baz',
        'baz.yml': 'foo',
        'true.yml': 'true',
        'false.yml': 'false',
    })

    inventory = DictDataLoader(dict(loader=loader, variable_manager=VariableManager()))

    templar = Templar(loader=loader, variables=inventory.get_vars(None))

    assert listify_lookup_plugin_terms('foo.yml', templar, loader) == ['bar']

# Generated at 2022-06-11 18:13:35.818592
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = None
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms([1, 2, 3], templar, loader) == [1, 2, 3]

    assert listify_lookup_plugin_terms([1, 2, 3, 4], templar, loader) == [1, 2, 3, 4]

    assert listify_lookup_plugin_terms('{{ "a" }}', templar, loader) == ['a']

    assert listify_lookup_plugin_terms('{{ "a" + "b" }}', templar, loader) == ['ab']

    assert listify_lookup_plugin_terms('a', templar, loader) == ['a']


# Generated at 2022-06-11 18:13:44.338053
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    mocked_loader = True
    templar = Templar(loader=mocked_loader)

    result = listify_lookup_plugin_terms('a', templar, mocked_loader)
    assert result == ['a']

    result = listify_lookup_plugin_terms(['a'], templar, mocked_loader)
    assert result == ['a']

    result = listify_lookup_plugin_terms('a,b,c', templar, mocked_loader)
    assert result == ['a','b','c']

    result = listify_lookup_plugin_terms(['a', 'b', 'c'], templar, mocked_loader)
    assert result == ['a','b','c']

# Generated at 2022-06-11 18:13:55.332461
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test empty term
    assert [] == listify_lookup_plugin_terms(None, None, None)

    # test string term
    assert ['foo'] == listify_lookup_plugin_terms('foo', None, None)
    assert ['foo', 'bar'] == listify_lookup_plugin_terms('foo,bar', None, None)
    assert ['foo', 'bar'] == listify_lookup_plugin_terms('foo, bar', None, None)

    # test list term
    assert ['foo'] == listify_lookup_plugin_terms(['foo'], None, None)
    assert ['foo', 'bar'] == listify_lookup_plugin_terms(['foo', 'bar'], None, None)

# Generated at 2022-06-11 18:13:59.646366
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible
    module = ansible.utils.module_docs.get_docstring(listify_lookup_plugin_terms)
    assert module is not None

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-11 18:14:05.456548
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    test_data = {'name': 'test_file'}
    test_vars = {'test_file': 'test_result'}

    templar = Templar(loader=None, variables=test_vars)

    test_values = listify_lookup_plugin_terms(test_data, templar, loader=None)
    assert test_values == ['test_result']

# Generated at 2022-06-11 18:14:17.460053
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.trusted_vars = {'user_param': 'foo'}
    templar = Templar(loader=loader, variables=variable_manager)

    def _compare(term, expected):
        result1 = listify_lookup_plugin_terms(term, templar=templar, loader=loader)
        result2 = listify_lookup_plugin_terms(term, templar=templar, loader=loader, convert_bare=True)
        assert result1 == expected
        assert result2 == expected

    _compare('{{ user_param }}', ['foo'])
   

# Generated at 2022-06-11 18:14:25.413330
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Iterable

    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variable_manager=variable_manager)
    variable_manager.set_available_variables(dict(var='foo'))

    # Test a string
    terms = '{{var}}'
    result = listify_lookup_plugin_terms(terms, templar, loader)
    assert result == ['foo']

    # Test a non-string
    terms = ['{{var}}']
    result = listify_look

# Generated at 2022-06-11 18:14:33.571055
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import wrap_var
    LPT = listify_lookup_plugin_terms
    assert LPT([1, 2, 3], templar=None, loader=None) == [1, 2, 3]
    assert LPT((1, 2, 3), templar=None, loader=None) == (1, 2, 3)
    assert LPT('xxx', templar=None, loader=None) == ['xxx']
    assert LPT(' 1 ', templar=None, loader=None) == [' 1 ']
    assert LPT(wrap_var(1), templar='templar', loader=None) == ['U(1)']

# Generated at 2022-06-11 18:14:42.300750
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' listify_lookup_plugin_terms should return a list '''
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    terms = AnsibleBaseYAMLObject('{{ foo }}')
    templar = Templar(loader=None)
    results = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False, convert_bare=False)
    assert results == [terms]

    templar.set_available_variables({'foo': 'bar'})
    results = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False, convert_bare=False)
    assert results == [terms]

    terms = '{{ foo }}'
    results

# Generated at 2022-06-11 18:14:53.656862
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar

    # This is a hack since the vault_password is not passed through
    v = VaultLib(password='password')
    terms = v.encrypt('foobar')
    terms = AnsibleVaultEncryptedUnicode.from_bytes(terms)
    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=True) == ["foobar"]
    assert listify_lookup_plugin_terms([terms, terms], templar, None, fail_on_undefined=True) == ["foobar", "foobar"]
   

# Generated at 2022-06-11 18:15:05.520074
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


    # setup needed objects for the test
    loader  = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 'b', 'c': [1, 2, 3]}
    variable_manager.options_vars = {}
    inventory = InventoryManager(loader=loader, sources=[])
    templar = Templar(loader=loader, variables=variable_manager)


    # run the tests
    terms = listify_lookup_plugin_terms(['{{a}}', '{{c}}'], templar, loader)

# Generated at 2022-06-11 18:15:15.682087
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    from io import StringIO

    test_data = StringIO("""
        ---
        my_dict:
            foo: bar
        my_list:
            - one
            - two
            - three
    """)

    vault_pass = StringIO("""
        ansible
    """)

    # Set up the class for parsing
    loader = TestLoader()
    loader.set_basedir('./')

    var_manager = VariableManager()
    var_manager.extra_vars = {}
    var_manager.options_vars = {}
    var_manager.vault_password = VaultLib(vault_pass)


# Generated at 2022-06-11 18:15:28.937751
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class DummyPlay(object):
        pass

    class DummyTask(object):
        pass

    class DummyLoader(object):
        pass

    #Dummy task for templar
    dummy_task = DummyTask()
    dummy_task._role = None

    #Dummy play context
    dummy_variable_manager = VariableManager()
    dummy_loader = DummyLoader()
    dummy_play = DummyPlay()
    dummy_options = dict(connection='local', module_path=None, forks=100, become=None,
                  become_method=None, become_user=None, check=False, diff=False)

# Generated at 2022-06-11 18:15:34.670584
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    vars = {}
    vars['firstvar'] = "I_AM_FIRST"
    vars['thirdvar'] = "I_AM_THIRD"
    variable_manager.set_vars(vars)

    templar = Templar(loader=loader, variables=variable_manager)

    listified = listify_lookup_plugin_terms("{{ firstvar }}:{{ thirdvar }}", templar, loader)
    assert len(listified) == 1
    assert listified[0] == "I_AM_FIRST:I_AM_THIRD"

    listified = listify_lookup

# Generated at 2022-06-11 18:15:45.847430
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    # Create a dummy lookup plugin
    class LookupModule(object):
        def __init__(self, basedir=None, runner=None, **kwargs):
            pass

        def run(self, terms, **kwargs):
            return terms

    lookup_loader.add('test_lookup', LookupModule)

    # Setup fake objects to test function
    templar = Templar(loader=None, variables=VariableManager())

# Generated at 2022-06-11 18:15:58.086318
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    cwd = os.getcwd()
    basedir = os.path.join(cwd, 'lib', 'ansible', 'plugins', 'lookup')
    loader = DictDataLoader({basedir: '.'})

    templar = Templar(loader=loader, variables={})
    assert listify_lookup_plugin_terms('{{ item }}', templar, loader, fail_on_undefined=True) == ['{{ item }}']


# Generated at 2022-06-11 18:16:09.484063
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.templating import Templar

    from ansible.playbook.play_context import PlayContext

    plain_text = 'foobar'

# Generated at 2022-06-11 18:16:16.669859
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.vars import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar

    loader = None
    vars_ = VariableManager()
    templar = Templar(loader=loader, variables=vars_)
    assert(listify_lookup_plugin_terms('[1]', templar, loader) == [1])
    assert(listify_lookup_plugin_terms('{1}', templar, loader) == [1])
    assert(listify_lookup_plugin_terms('1', templar, loader) == ['1'])
    assert('a' in set(listify_lookup_plugin_terms('[1,2,a]', templar, loader)))

# Generated at 2022-06-11 18:16:27.370000
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert listify_lookup_plugin_terms(["{{ foo }}"], Templar({}, {}, {}), {}) == ["{{ foo }}"]
    assert listify_lookup_plugin_terms("hello", Templar({}, {}, {}), {}) == ["hello"]
    assert listify_lookup_plugin_terms("hello world", Templar({}, {}, {}), {}) == ["hello world"]
    assert listify_lookup_plugin_terms("hel'lo world", Templar({}, {}, {}), {}) == ["hel'lo world"]
    assert listify_lookup_plugin_terms("hel\"lo world", Templar({}, {}, {}), {}) == ["hel\"lo world"]

# Generated at 2022-06-11 18:16:37.330976
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    kwargs = {'inventory': None}
    vm = VariableManager(loader=None, **kwargs)
    templar = Templar(loader=None, variables=vm)

    # test listify_lookup_plugin_terms on string
    terms = 'a'
    results = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert results == ['a']

    # test listify_lookup_plugin_terms on list
    terms = ['a', 'b']
    results = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
    assert results

# Generated at 2022-06-11 18:16:46.572276
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class MockVaultSecret:
        def __init__(self, val):
            self.vault_secret = val

    class MockPlayContext:
        def __init__(self, become_pass=None):
            self.become_pass = become_pass

    class MockLoader:
        def __init__(self, path):
            self.path = path

        def get_basedir(self):
            return self.path

    # create the templar
    loader = DataLoader()
    vault = VaultLib([])

# Generated at 2022-06-11 18:16:55.273532
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Insert modules import behind all other import lines
    import ansible.utils.listify_lookup_plugin as listify_lookup_plugin_mod

    import ansible.plugins.loader as plugin_loader
    import ansible.parsing.yaml.objects as yaml_object
    from ansible.template import Templar

    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # Create variable manager
    variable_manager = VariableManager()

    # Create loader
    loader = plugin_loader.PluginLoader(
        'lookup',
        'lookup',
        C.DEFAULT_LOOKUP_PLUGIN_SEARCH_PATH,
        '',
        '',
    )

    # Create data structure for variables

# Generated at 2022-06-11 18:17:09.578784
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_variable_manager(loader, 'foo', 'bar')
    variable_manager.set_variable_manager(loader, 'xyz', ['a', 'b', 'c'])

    templar = PlayContext(loader=loader, variable_manager=variable_manager)

    orig_terms = ['{{foo}}', '{{xyz}}']
    expected_terms = ['bar', ['a', 'b', 'c']]
    assert listify_lookup_plugin_terms(orig_terms, templar, loader) == expected_terms


# Generated at 2022-06-11 18:17:19.127559
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars

    vars = [
        ('a', 'first'),
        ('b', 'second'),
        ('n', 2),
        ('l', [1,2,3,4]),
        ('h', {'a':1, 'b':2, 'c':3})
    ]
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(vars)
    variable_manager.set_known_hosts_dynamic_variables(HostVars(variable_manager))
    loader = DataLoader()
   

# Generated at 2022-06-11 18:17:23.504960
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

# Generated at 2022-06-11 18:17:31.583203
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={'var': 'value'})

    for term in ('"{var}"', '{{ var }}', u'"{var}"', u'{{ var }}'):
        assert listify_lookup_plugin_terms(term, templar, None, fail_on_undefined=False) == ['value']
        assert listify_lookup_plugin_terms(term, templar, None, fail_on_undefined=True) == ['value']

    for term in (['1', '2', '3'], ['{{ var }}', '2', '3']):
        assert listify_lookup_plugin_terms(term, templar, None, fail_on_undefined=False) == ['1', '2', '3']
        assert listify

# Generated at 2022-06-11 18:17:44.102492
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    def make_template(str):
        return Templar(loader=None, variables=dict(a=1, b=2, c=3))

    # test undefined variable
    try:
        listify_lookup_plugin_terms(
            terms="{{ missing_var }}",
            templar=make_template("{{ missing_var }}"),
        )
    except:
        pass
    else:
        raise AssertionError("undefined variable failed to raise an error")

    # test string
    assert listify_lookup_plugin_terms(
        terms="{{ a }}",
        templar=make_template("{{ a }}"),
    ) == [1]

    # test variable

# Generated at 2022-06-11 18:17:54.026135
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    # default
    loader = DataLoader()
    variable_manager = VariableManager()

    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=True)

    result = listify_lookup_plugin_terms('foo', templar, loader)
    result = [x.strip() for x in result]
    assert result == ['foo']

    # now with a list
    result = listify_lookup_plugin_terms(['foo', 'bar', 'baz'], templar, loader)
    result = [x.strip() for x in result]
    assert result == ['foo', 'bar', 'baz']

    # with a

# Generated at 2022-06-11 18:18:02.198102
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    import jinja2
    m = jinja2.Environment()
    t = Templar(loader=None, variables={'a': 'test_a'})
    ret = listify_lookup_plugin_terms('{{a}}', t, None)
    assert ret == ['test_a'], ret
    ret = listify_lookup_plugin_terms(['{{a}}'], t, None)
    assert ret == ['test_a'], ret
    ret = listify_lookup_plugin_terms({'a': '{{a}}'}, t, None)
    assert ret == [{'a': 'test_a'}], ret
    ret = listify_lookup_plugin_terms('', t, None)
    assert ret == [''], ret
    ret = listify_lookup

# Generated at 2022-06-11 18:18:13.698824
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # The following is a direct copy of the unit test for listify

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    from ansible.template import Templar
    from ansible.vars import VariableManager

    vars_dict = dict(a=1, b=2, c="{{a}} + {{b}}")

    variable_manager = VariableManager()
    variable_manager.extra_vars = vars_dict

    templar = Templar(loader=None, variables=variable_manager)

    assert listify_lookup_plugin_terms(None, templar, None) == []

# Generated at 2022-06-11 18:18:24.535367
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    class VarManager:
        def __init__(self):
            self.vars = dict(
                a='1',
                b='2',
                c='3',
                d='4',
            )
        def get_vars(self, loader, play, host):
            return self.vars

        def set_host_variable(self, host, varname, value):
            self.vars[varname] = value

        def set_nonpersistent_facts(self, host, facts):
            self.vars.update(facts)

    data = dict(
        templar=Templar(loader=DataLoader()),
        loader=DataLoader(),
        var_manager=VarManager()
    )

# Generated at 2022-06-11 18:18:34.804542
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from jinja2 import Template
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    dataloader = DataLoader()
    templar = Template(loader=dataloader)
    vars = VariableManager()
    vars.set_variable('foo', 'bar')

    test_data = (
        ('foo', ['bar']),
        ('["foo"]', ['bar']),
        ('["foo", "bar"]', ['bar', 'bar']),
        ('{{ foo }}', ['bar']),
        ('["{{ foo }}"]', ['bar']),
        ('["{{ foo }}", "{{ foo }}"]', ['bar', 'bar']),
    )

    for test, val in test_data:
        res = listify_lookup_plugin

# Generated at 2022-06-11 18:18:44.461507
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test 1
    class TestTemplar(object):
        def template(self, data, **kw):
            return data

    loader = TestTemplar()

    templar = TestTemplar()

    assert listify_lookup_plugin_terms("abc", templar, loader) == ['abc']
    assert listify_lookup_plugin_terms(["abc", "def"], templar, loader) == ['abc', 'def']
    assert listify_lookup_plugin_terms(["abc", "def", "ghi"], templar, loader) == ['abc', 'def', 'ghi']

    # Test 2
    class TestTemplar2(object):
        def template(self, data, **kw):
            if isinstance(data, string_types):
                return data.lower()

# Generated at 2022-06-11 18:18:52.239750
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class LookupModuleMock:
        def __init__(self):
            self.params = {}
            self.basedir = None

    loader = C.get_config_loader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variable_manager=variable_manager)

    lookup_mod_mock = LookupModuleMock()
    variable_manager.set_globals(
        ansible_facts=dict(facts_per_host=dict(local=dict(a=1, b=2, c=3)))
    )

    # Test from static text, convert_bare and fail_on_undefined

# Generated at 2022-06-11 18:19:00.331209
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Without convert_bare, unsafe text is not templated
    assert listify_lookup_plugin_terms(["hello", "{{ safe }}"], None, None, convert_bare=False) == \
           [u'hello', u'{{ safe }}']
    assert listify_lookup_plugin_terms(["hello", "{{ safe }}"], None, None, convert_bare=True) == \
           [u'hello', u'the text is safe']


# @add_to_library

# Generated at 2022-06-11 18:19:10.652511
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    vm = VariableManager()
    templar = Templar(loader=None, variables=vm)

    # test a scalar string
    terms = listify_lookup_plugin_terms('"{{foo}}"', templar, None)
    assert terms == ['{{foo}}']

    # test a list
    terms = listify_lookup_plugin_terms(['"{{foo}}"', '"{{bar}}"'], templar, None)
    assert terms == ['{{foo}}', '{{bar}}']

    # test a dict, which should not be deeply converted
    terms = listify_lookup_plugin_terms({'foo': '"{{foo}}"', 'bar': '"{{bar}}"'}, templar, None)

# Generated at 2022-06-11 18:19:16.903771
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # can't test until we make the template plugin optional
    assert listify_lookup_plugin_terms(['blah', '{{foo}}'], None, None) == ['blah', '{{foo}}']
    assert listify_lookup_plugin_terms('blah', None, None) == ['blah']
    assert listify_lookup_plugin_terms(['blah', 'blah'], None, None) == ['blah', 'blah']

if __name__ == '__main__':
    test_listify_lookup_plugin_terms()

# Generated at 2022-06-11 18:19:26.125293
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.template import Templar

    # test string input
    terms = "{{ var1 }}{{ var2 }}{{ var3 }}"
    loader = DictDataLoader({
        "terms": terms,
        "vars": {
            "var1": "val1",
            "var2": "val2",
            "var3": "val3",
        }
    })
    templar = Templar(loader=loader)
    assert listify_lookup_plugin_terms(terms, templar, loader) == ["val1val2val3"]

    # test list input
    terms = ["{{ var1 }}", "{{ var2 }}", "{{ var3 }}", "{{ var4 }}"]

# Generated at 2022-06-11 18:19:32.650372
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 1, 'b': 2}

    my_loader = lambda *x: "foo"
    my_templar = Templar(loader=my_loader, variables=variable_manager)
    t = listify_lookup_plugin_terms('{{a}} {{b}} {{c}}', my_templar, my_loader, fail_on_undefined=True)
    assert t == ['1 2 foo']

    t = listify_lookup_plugin_terms(['{{a}}', '{{b}}', '{{c}}'], my_templar, my_loader, fail_on_undefined=True)

# Generated at 2022-06-11 18:19:43.467626
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    Testing the function listify_lookup_plugin_terms.

    This is an integration test as the function requires a playbook to run.
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader

    templar = Templar(loader=DictDataLoader({}))


# Generated at 2022-06-11 18:19:52.909982
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.parsing.vault import VaultLib

    templar = namedtuple('Templar', ['template'])
    templar.template = lambda self, x, convert_bare=False, fail_on_undefined=True: x

    loader = namedtuple('Loader', ['load_from_file'])
    loader.load_from_file = lambda self, x, _=None: x

    vault = VaultLib([])
    vault.decrypt = lambda x: x

    # Test when a single term is provided as a string, it returns a list
    assert listify_lookup_plugin_terms('some_value', templar, loader) == ['some_value']

    # Test when a single term is provided as a list

# Generated at 2022-06-11 18:20:01.262305
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DictDataLoader({'/etc/ansible/roles/foo/vars/main.yml': 'z: 1'})
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader, inventory=inventory))

    templar = Templar(loader=loader, variables=inventory.get_group_vars('all'))

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader, convert_bare=False) == ['foo', 'bar']
    assert listify_lookup_plugin_terms({'a': 'foo'}, templar, loader, convert_bare=False) == {'a': 'foo'}

# Generated at 2022-06-11 18:20:17.104519
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.module_utils.facts.system.distribution import Distribution as DistroFact
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib as VaultSecret

    vault_secret = VaultSecret(password='123')
    templar = Templar(loader=None, variables={u'foo': [u'one', u'two']}, shared_loader_obj=None, vault_secrets=[vault_secret],
                      convert_bare=C.DEFAULT_BARE_VARIABLE_START_CHAR,
                      fail_on_undefined=C.DEFAULT_UNDEFINED_VARIABLE_FAIL_ON_ANY_UNDEFINED_VARIABLE,
                      fact_cache=DistroFact().get_all_facts(None))

# Generated at 2022-06-11 18:20:27.631784
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.action import ActionBase
    test_action = ActionBase()
    # Load config and vars
    test_action._configure_module()
    loader = test_action._loader
    config = test_action._config
    templar = test_action._templar
    fail_on_undefined = test_action._shared_loader_obj.fail_on_undefined
    play_context = test_action._play_context

    # Expecting list
    result = listify_lookup_plugin_terms(
        terms=["first", "second"], templar=templar, loader=loader,
        fail_on_undefined=fail_on_undefined, convert_bare=False)
    assert result == ["first", "second"]

    # Expecting single item list
    result = listify_look