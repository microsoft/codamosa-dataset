

# Generated at 2022-06-11 18:10:41.177716
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    def test(terms, expected, convert_bare=False, fail_on_undefined=True):
        loader = DataLoader()
        variable_manager = dict()
        templar = Templar(loader=loader, variables=variable_manager)
        result = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=fail_on_undefined, convert_bare=convert_bare)
        assert result == expected

    # test with kv and dict
    test(terms='key1:value1 key2:{{value2}}', expected=['key1:value1', 'key2:value2'])

# Generated at 2022-06-11 18:10:51.888820
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    vault_secrets = VaultLib(password_files=['~/vault_pass.txt'])
    variables = VariableManager()
    context = PlayContext()
    templar = Templar(loader=loader, variables=variables, fail_on_undefined=True)

    assert listify_lookup_plugin_terms(terms='foo', templar=templar, loader=loader) == ['foo']

# Generated at 2022-06-11 18:11:02.071731
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.jinja import AnsibleJinja2 as j2
    env = j2.get_default()
    tmp = env.from_string('hi {{ foo }}')
    assert listify_lookup_plugin_terms(tmp.template.module._args.terms[0], tmp.template, None) == [{'foo': 'hi'}]
    tmp = env.from_string('{"foo": "bar"}')
    assert listify_lookup_plugin_terms(tmp.template.module._args.terms[0], tmp.template, None) == [{'foo': 'bar'}]
    tmp = env.from_string('hi {{ foo }}, "{{ bar }}"')

# Generated at 2022-06-11 18:11:12.961477
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-11 18:11:22.847111
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.plugins.lookup import LookupBase

    lookup = LookupBase()

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.templating.templar import Templar

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    result = listify_lookup_plugin_terms(
        '{{ foo }}', templar=templar, loader=loader, fail_on_undefined=False, convert_bare=True
    )

    assert result == ['{{ foo }}']

    variable_manager.set_nonpersistent_facts({'foo': [1,2,3,4]})

# Generated at 2022-06-11 18:11:30.014118
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class DummyVarsModule(object):
        def __init__(self, module_name, args, inject=None, bypass_checks=False, no_log=False,
                     run_once=False, complex_args=False, check_invalid_arguments=True,
                     mutually_exclusive=None, required_together=None, required_one_of=None,
                     add_file_common_args=False, supports_check_mode=False):
            self.params = {}

    class DummyTemplar(Templar, object):
        def __init__(self, loader, variables):
            self._available_variables = variables
            self._templates = []

        def available_variables(self):
            return self._available_variables

    # Dummy Template class, does no actual

# Generated at 2022-06-11 18:11:40.865503
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib

    templar = Templar(loader=None, variables=combine_vars(None, vault_password='vault'))
    templar.set_vault_secrets(VaultLib(['vault']))


# Generated at 2022-06-11 18:11:50.279056
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)

    # test to ensure an iterable isn't messed with
    terms = ['a','b','c']
    listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)
    assert terms == ['a','b','c']

    # convert a string to a list
    terms = 'a,b,c'
    listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)
    assert terms == ['a','b','c']

# Generated at 2022-06-11 18:12:01.127939
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    class Options(object):
        def __init__(self, connection, module_path, forks, become, become_method, become_user, check, diff):
            self.connection = connection
            self.module_path = module_path
            self.forks = forks
            self.become = become
            self.become_method = become_method
            self.become_user = become_user
            self.check = check
            self.diff = diff


# Generated at 2022-06-11 18:12:09.699352
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import constants as C
    from ansible.template import Templar

    # Terms is a single value
    assert listify_lookup_plugin_terms(1, Templar(None, loader=None), None) == [1]

    # Terms is a string value
    assert listify_lookup_plugin_terms('test', Templar(None, loader=None), None) == ['test']

    # Terms is a list of string values
    assert listify_lookup_plugin_terms(['test', 'test2'], Templar(None, loader=None), None) == ['test', 'test2']



# Generated at 2022-06-11 18:12:21.410634
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    template = '{{ value }}'
    vars = dict(value="hello world")

    assert listify_lookup_plugin_terms(template, Templar(loader=None, variables=vars)) == ['hello world']
    assert listify_lookup_plugin_terms(template, Templar(loader=None, variables=vars), fail_on_undefined=False) == ['hello world']
    assert listify_lookup_plugin_terms(template, Templar(loader=None, variables=vars), fail_on_undefined=False, convert_bare=True) == ['hello world']

# Generated at 2022-06-11 18:12:33.150934
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.errors import AnsibleError
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 'foo', 'b': 'bar'}

    templar = Templar(loader=loader, variables=variable_manager)
    my_list = [1,2,3]
    my_dict = {'foo': 'bar'}
    my_string = 'foo'

    assert listify_lookup_plugin_terms(my_list, templar, loader) == my_list

# Generated at 2022-06-11 18:12:41.701833
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Ensure that strings are turned into a list
    terms = 'foo'
    templar = Templar(lookup_loader, variables={})
    converted_terms = listify_lookup_plugin_terms(terms, templar, DataLoader())
    assert isinstance(converted_terms, list)
    assert list(converted_terms) == ['foo']

    # Ensure that a list is unchanged
    terms = ['foo', 'bar']
    templar = Templar(lookup_loader, variables={})
    converted_terms = listify_lookup_plugin_terms(terms, templar, DataLoader())
    assert isinstance(converted_terms, list)
   

# Generated at 2022-06-11 18:12:51.158291
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.errors import AnsibleError
    from ansible.template import Templar

    # Test a string
    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms("item1", templar, None) == ['item1']

    # Test a list
    assert listify_lookup_plugin_terms(["item1", "item2"], templar, None) == ["item1", "item2"]

    # Test a dict
    with pytest.raises(AnsibleError) as err:
        listify_lookup_plugin_terms({"item1": "value1"}, templar, None)
    assert "value (type=dict) is not valid for a lookup parameter" in str(err)

# Generated at 2022-06-11 18:13:02.749028
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class FakeLoader(object):
        def __init__(self):
            self.paths = []

    class FakeTemplar(object):
        def __init__(self, loader):
            self.loader = loader

        def template(self, stuff, fail_on_undefined=False, convert_bare=False, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined_vars=True):
            return stuff

    loader = FakeLoader()
    templar = FakeTemplar(loader)

# Generated at 2022-06-11 18:13:07.370901
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.parsing.templar as templar
    import ansible.parsing.yaml.loader as yaml_loader
    from ansible.errors import AnsibleUndefinedVariable

    from ansible.utils.display import Display

    class MyTemplar(templar.Templar):
        def __init__(self):
            pass

        def set_available_variables(self, variables):
            self._available_variables = variables

        def available_variables(self, add_ansible_facts=False):
            if add_ansible_facts:
                results = dict()
                results.update(self.module_vars)
                results.update(self._available_variables)
            else:
                results = self._available_variables
            return results


# Generated at 2022-06-11 18:13:18.402505
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    class DummyVarsModule:
        def __init__(self, value):
            self.params = {"a":value}

    class DummyVarsManager:
        def __init__(self, data):
            self.data = data

        def get_vars(self, loader, path, entities, cache=True, unsafe=True):
            if entities is None:
                return self.data.copy()
            ret = {}
            for entity in entities:
                ret.update(self.data.get(entity, {}))
            return ret


# Generated at 2022-06-11 18:13:25.889136
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils import module_docs
    import ansible.utils.module_docs as module_docs

    def run_module(self, tmp=None, task_vars=dict()):
        return dict(failed=False, msg="test")

    module_docs.run_module = run_module

    b_vars = dict(
        test=dict(
            a=1,
            b=2,
        ),
    )
    t = module_docs.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    t._templar.template_class = t.template_class
    t.template = t._templar.template

    def get_basedir(self, vars):
        return "/"

    t._loader.get_basedir = get

# Generated at 2022-06-11 18:13:37.716188
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    try:
        from ansible.template import Templar
    except ImportError:
        print('skipping unit tests due to ansible.template import error')
        return

    # This class is needed to handle testing of "fail_on_undefined"
    class DummyVarsModule(object):

        def __init__(self, **kwargs):
            for k,v in kwargs.items():
                setattr(self, k, v)

    # Templar function to_text must de used in this test
    # otherwise some characters get changed (e.g. \n)
    t = Templar(loader=None)

    # Use a copy of test_listify_lookup_plugin_terms.vars

# Generated at 2022-06-11 18:13:46.381903
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.irt import get_irt
    from ansible.template import Templar
    from ansible import context
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(get_irt())

    # test that it works with a string
    assert listify_lookup_plugin_terms('a', templar, None) == ['a']
    assert listify_lookup_plugin_terms(AnsibleUnicode('a'), templar, None) == ['a']

    assert listify_lookup_plugin_terms(u'a', templar, None) == ['a']

    # test that it works with a list
    assert listify_lookup_plugin_terms(['a'], templar, None) == ['a']
    assert listify_lookup

# Generated at 2022-06-11 18:13:56.735518
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template

    terms = [3, 4, 5]
    templar = ansible.template.AnsibleTemplar(loader=None)
    res = listify_lookup_plugin_terms(terms, templar, None)
    assert res == terms

    terms = '{{ lookup("noop", "this is a test") }}'
    res = listify_lookup_plugin_terms(terms, templar, None)
    assert res[0] == 'this is a test'

    terms = ' 3, 4, 5 '
    res = listify_lookup_plugin_terms(terms, templar, None)
    assert res[0] == '3'
    assert res[1] == '4'
    assert res[2] == '5'


# Generated at 2022-06-11 18:14:06.171070
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    assert listify_lookup_plugin_terms('test1, test2', None, None) == ['test1', 'test2']
    assert listify_lookup_plugin_terms(['test1', 'test2'], None, None) == ['test1', 'test2']
    assert listify_lookup_plugin_terms(['test1', 'test2', ['test3', ['test4']]], None, None) == ['test1', 'test2', ['test3', ['test4']]]
    assert listify_lookup_plugin_terms('{{ test_var1 }}, {{ test_var2 }}', Templar(PlayContext()), None, convert_bare=True), ['testing1', 'testing2']

# Generated at 2022-06-11 18:14:18.165738
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class TT:
        def __init__(self, loader, fail_on_undefined, convert_bare):
            self.loader = loader
            self.fail_on_undefined = fail_on_undefined
            self.convert_bare = convert_bare

        def template(self, terms, fail_on_undefined=None, convert_bare=None):
            if fail_on_undefined is None:
                fail_on_undefined = self.fail_on_undefined
            if convert_bare is None:
                convert_bare = self.convert_bare
            terms = terms if isinstance(terms, list) else [terms]

# Generated at 2022-06-11 18:14:27.025803
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    test_string = AnsibleUnsafeText("{{unused}}")
    test_string_complex = AnsibleUnsafeText("{{ unused_var.1.2 }} and {{ 'var2' }}")
    test_dict = {'first_key': test_string, 'second_key': test_string_complex}
    test_list = [test_string, test_string_complex]
    test_vault = VaultLib([])
    test_vault.password = 'vaultpassword'
    test_vault_text = test_vault.enc

# Generated at 2022-06-11 18:14:35.987054
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # test_listify_lookup_plugin_terms: tests the listify_lookup_plugin_terms function

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import pytest

    # create the templar and loader objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, inventory=inventory, variable_manager=variable_manager)

    # test the code with different kinds of input
    test_terms = ['first', 'second']

# Generated at 2022-06-11 18:14:43.873827
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    loader = DummyLoader()
    templar = Templar(loader=loader)

    # Test string input
    terms = "{{ test_var }}"
    assert listify_lookup_plugin_terms(terms, templar, loader) == 'test_value'

    # Test list input
    terms = ["{{ test_var }}"]
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['test_value']

    # Test case where handling is deferred until later
    terms = ["{{ missing_var }}"]
    assert listify_lookup_plugin_terms(terms, templar, loader) == ['{{ missing_var }}']

    # Test case where an error is raised
    terms = ["{{ missing_var }}"]
    assert listify_lookup_plugin_

# Generated at 2022-06-11 18:14:54.733397
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar', 'ansible_ssh_user':'bob'}
    templar = Templar(loader, variable_manager)

    # Test ansible_ssh_user is returned
    terms = [ 'FOO', '{{ ansible_ssh_user }}' ]
    terms = templar.template(terms)
    terms = listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False, convert_bare=False)
    assert isinstance(terms, list)
    assert len(terms) == 2
   

# Generated at 2022-06-11 18:15:06.269286
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    class DummyVarsModule:
        class HostVars:
            def __init__(self, value):
                self.value = value
            def get(self, key, default=None):
                #if key == 'name':
                #    return AnsibleUnsafeText(u'bar')
                if key == 'test':
                    return self.value
                return default

    class DummyTemplate(Templar):

        def __init__(self, variables):
            super(DummyTemplate, self).__init__(loader=None, variables=variables)


# Generated at 2022-06-11 18:15:15.456106
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('one', None, None) == ['one']
    assert listify_lookup_plugin_terms('one\ttwo', None, None) == ['one', 'two']
    assert listify_lookup_plugin_terms(['one'], None, None) == ['one']
    assert listify_lookup_plugin_terms(['one', 'two'], None, None) == ['one', 'two']
    assert listify_lookup_plugin_terms('["one", "two"]', None, None) == ['one', 'two']
    assert listify_lookup_plugin_terms(['["one", "two"]'], None, None) == ['["one", "two"]']

# Generated at 2022-06-11 18:15:23.193894
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import errors
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()
    variable_manager.options_vars = dict()

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager.set_inventory(inventory)

    loader = 'implicit'
    templar = Templar(loader=loader, variables=variable_manager)

    # Test a simple string
    s = 'abc'
    result = listify_lookup_plugin_terms(s, templar, loader)
    assert len(result) == 1
    assert result[0] == s

    # Test a string with embedded quotes

# Generated at 2022-06-11 18:15:35.003823
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()
    templar = Templar(loader=dl)
    assert ['foo', 'bar'] == listify_lookup_plugin_terms("foo:bar", templar, dl)
    assert ['foo', 'bar'] == listify_lookup_plugin_terms("foo: bar", templar, dl)
    assert ['foo', 'bar'] == listify_lookup_plugin_terms("foo:   bar", templar, dl)
    assert ['foo', 'bar'] == listify_lookup_plugin_terms("\tfoo:\tbar\t", templar, dl)

# Generated at 2022-06-11 18:15:38.538454
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This function is a no-op, so there is nothing we can test without
    # testing another function at the same time
    assert True

# Generated at 2022-06-11 18:15:48.614275
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.vars.templar import Templar

    mock_loader = "AnsibleMockLoader"

    templar = Templar(loader=mock_loader)

    # Test when terms is a string
    terms = "{{ lookup('template', '{{ foo }}/{{ bar }}.conf') }}"
    t = listify_lookup_plugin_terms(terms, templar, mock_loader)
    assert len(t) == 1
    assert t[0] == "{{ foo }}/{{ bar }}.conf"
    # Ensure idempotency of the function
    assert t == listify_lookup_plugin_terms(terms, templar, mock_loader)
    # For code coverage
    assert t != listify_lookup_plugin_terms(terms, templar, mock_loader, convert_bare=False)

# Generated at 2022-06-11 18:15:59.436976
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class VarsModule(object):
        ''' Ansible variables '''

        def __init__(self, runner):
            self.data = {'test_var': ['foo', 'bar', 'baz']}
            self.runner = runner

    class Runner(object):
        ''' Dummy Runner class '''
        def __init__(self, module_vars):
            self.module_vars = module_vars

        @property
        def vars(self):
            return self.module_vars

    loader = None
    templar = Templar(loader=loader, variables={}, shared_loader_obj=None)
    variables = VarsModule(Runner(templar))

    terms = list

# Generated at 2022-06-11 18:16:11.026677
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils import basic
    from ansible.parsing.vault import VaultLib
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    def vault_secrets(self, filename):
        # for tests, it's always the same
        return dict(password='password')

    class DummyVaultLib(VaultLib):
        """
        Class for unit testing to ensure vault secrets are always the same
        """
        def __init__(self, password_files, passwords=None):
            super(DummyVaultLib, self).__init

# Generated at 2022-06-11 18:16:22.856616
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader)


# Generated at 2022-06-11 18:16:30.566866
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.template
    import ansible.parsing.vault
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.play_context import PlayContext

    password = None
    loader = DataLoader()
    myvault = ansible.parsing.vault.VaultLib(password)
    templar = ansible.template.Templar(loader=loader, variables={}, vault_secrets=myvault.secrets)

    # These tests are not very good - they don't test the conversion to lists.
    assert listify_lookup_plugin_terms("foo", templar, loader) == "foo"
    assert listify_lookup_plugin_terms("foo bar", templar, loader) == "foo bar"
    assert listify_lookup_plugin

# Generated at 2022-06-11 18:16:40.894574
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    x = u'foo'
    assert listify_lookup_plugin_terms(x, templar, None) == ['foo']

    x = u'foo,bar'
    assert listify_lookup_plugin_terms(x, templar, None) == ['foo', 'bar']

    x = u'foo bar'
    assert listify_lookup_plugin_terms(x, templar, None) == ['foo', 'bar']

    x = u'foo, bar'
    assert listify_lookup_plugin_terms(x, templar, None) == ['foo', 'bar']

    x = [u'foo', u'bar']

# Generated at 2022-06-11 18:16:52.634389
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'n1': 1}
    variable_manager.set_available_variables({'n2': 2})
    variable_manager.set_variable_manager_scope(None)
    variable_manager.set_inventory(None)
    templar = Templar(loader=None, variable_manager=variable_manager)

    assert listify_lookup_plugin_terms([1], templar, loader=None) == [1]

# Generated at 2022-06-11 18:17:03.418870
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = 'dummy_loader'
    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms(1, templar, loader) == [1]
    assert listify_lookup_plugin_terms('1', templar, loader) == [1]
    assert listify_lookup_plugin_terms(['1', '2'], templar, loader) == [1, 2]
    assert listify_lookup_plugin_terms('1 2', templar, loader) == ['1', '2']
    assert listify_lookup_plugin_terms('1 2', templar, loader, convert_bare=True) == [1, 2]

# Generated at 2022-06-11 18:17:28.061066
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    vm = VariableManager()
    vault = VaultLib(password_file=None, vault_password_file=None)
    vm.set_vault_secrets([(vault, None)])
    templar = Templar(loader=None, variables=vm, vault_secrets=[(vault, None)])

    # Empty list
    assert listify_lookup_plugin_terms(None, templar) == []
    assert listify_lookup_plugin_terms([], templar) == []

    # Bare variables are not expanded
    assert listify_lookup_plugin_terms("{{ foo }}", templar, convert_bare=True) == ["{{ foo }}"]

    # Boolean is not expanded
    assert listify

# Generated at 2022-06-11 18:17:37.994169
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)
    tests = [
        u'foo',
        [u'foo'],
        [u'foo', u'bar'],
    ]
    expect = [
        [u'foo'],
        [u'foo'],
        [u'foo', u'bar'],
    ]
    for test, exp in zip(tests, expect):
        assert listify_lookup_plugin_terms(test, templar, loader) == exp



# Generated at 2022-06-11 18:17:47.891589
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_vault_secrets(loader=None, vault_ids=[])
    templar = Templar(loader=loader, variables=variable_manager)

    # test a string
    assert listify_lookup_plugin_terms('test', templar, loader) == ['test']

    # test a list
    assert listify_lookup_plugin_terms(['test'], templar, loader) == ['test']

    # test a list of lists
    assert listify_lookup_plugin_terms([['test']], templar, loader) == [['test']]

    # test a

# Generated at 2022-06-11 18:17:55.762977
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.vars import combine_vars
    templar = Templar(loader=None, variables=combine_vars(dict()))

    terms_string = "foo"
    terms_list = ["foo"]
    assert listify_lookup_plugin_terms(terms_string, templar=templar) == terms_list

    terms_ansible_unicode = AnsibleUnicode("foo")
    assert listify_lookup_plugin_terms(terms_ansible_unicode, templar=templar) == terms_list

    terms_list = ["foo", "bar"]

# Generated at 2022-06-11 18:18:06.236674
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    def run_module(name, *args):
        import ansible.modules.system as system
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils import basic
        from ansible.module_utils._text import to_bytes

        if name == 'template':
            module = system.TemplateModule(*args)
        elif name == 'getent':
            module = system.GetEnt(*args)

        basic._ANSIBLE_ARGS = None
        basic._ANSIBLE_ARGS = to_bytes(basic._ANSIBLE_ARGS)
        return AnsibleModule(
            argument_spec=module.argument_spec,
            bypass_checks=False,
        )

    # simulate the template

# Generated at 2022-06-11 18:18:15.543131
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    loader = 'loader here'

    # Single item (unicode is special case)
    mystring = u'{{ foo }}'
    mylist = listify_lookup_plugin_terms(mystring, Templar(loader=loader, variables=VariableManager()), loader)
    assert type(mylist) == list
    assert mylist == [AnsibleUnicode(u'{{ foo }}')]

    # Single item
    mystring = ['{{ foo }}']
    mylist = listify_lookup_plugin_terms(mystring, Templar(loader=loader, variables=VariableManager()), loader)
    assert type(mylist) == list
    assert mystring == my

# Generated at 2022-06-11 18:18:25.781368
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-11 18:18:35.782620
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({})
    variable_manager = VariableManager()

    # pylint: disable=protected-access

    # strings are listified into single-item lists
    templar = Templar(loader=loader, variables=variable_manager)
    result = listify_lookup_plugin_terms('foo', templar, loader)
    assert result == ['foo']

    # lists are turned into copies
    templar = Templar(loader=loader, variables=variable_manager)
    result = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)
    assert result == ['foo', 'bar']

    # if the value is not a string or an iterable, a list is returned with that value as

# Generated at 2022-06-11 18:18:44.908160
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # TEST: result is a list when lookup_plugin_terms is a list
    test_result = listify_lookup_plugin_terms(['first_term', 'second_term'], None, None)
    assert isinstance(test_result, list) == True
    assert test_result == ['first_term', 'second_term']

    # TEST: result is a list when lookup_plugin_terms is a string
    test_result = listify_lookup_plugin_terms('first_term', None, None)
    assert isinstance(test_result, list) == True
    assert test_result == ['first_term']

# Generated at 2022-06-11 18:18:52.543525
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test string
    assert listify_lookup_plugin_terms("{{ my_var }}", None, None, fail_on_undefined=False) == ['{{ my_var }}']
    assert listify_lookup_plugin_terms("{{ my_var }}", None, None, fail_on_undefined=True) == ['{{ my_var }}']
    assert listify_lookup_plugin_terms("my_var", None, None, fail_on_undefined=False) == ['my_var']
    assert listify_lookup_plugin_terms("my_var", None, None, fail_on_undefined=True) == ['my_var']

    # Test list

# Generated at 2022-06-11 18:19:27.677774
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing import vault
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import PY3
    from io import BytesIO
    from ansible.plugins.loader import lookup_loader

    import yaml
    y = yaml.YAML()
    y.default_flow_style = False

    class DummyVarsModule:
        def __init__(self, data):
            self.params = data

    class DummyVaultSecret:
        def __init__(self, val):
            self.value = val

    class DummyLoader:
        def get_basedir(self, *args, **kwargs):
            return '/'


# Generated at 2022-06-11 18:19:37.284620
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=False)

    #
    # Test valid terms.
    #
    terms = [
        '{{ foo }}',
        ['{{ foo }}', '{{ bar }}'],
        {'key': '{{ foo }}'},
        [{'key': '{{ foo }}'}, {'key': '{{ bar }}'}],
    ]


# Generated at 2022-06-11 18:19:42.652816
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], None, None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('[ "foo", "bar" ]', None, None) == ['foo', 'bar']

# Generated at 2022-06-11 18:19:50.364952
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader
    loader = DictDataLoader({'test.yml': "{ foo: bar }"})

    facts = dict(test=dict(foo="bar"))
    templar = Templar(loader=loader, variables=facts)
    word = '{{ test.foo }}'
    words = [ word ]
    terms = [words]

    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False) == [ [ 'bar' ] ]

# Generated at 2022-06-11 18:19:59.283880
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.objects import AnsibleUnicode

    from ansible.module_utils.common.collections import is_sequence
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    # Turn a bare string into a list
    assert is_sequence(listify_lookup_plugin_terms('hello', templar, None))

    # Convert a string into a list if convert_bare=True
    assert listify_lookup_plugin_terms('hello', templar, None, convert_bare=True) == ['hello']

    # If a variable isn't defined and fail_on_undefined=False, fall back to the variable name
    assert list

# Generated at 2022-06-11 18:20:09.333257
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins import lookup_loader

    loader = lookup_loader._create_loader()

    # Tests for function listify_lookup_plugin_terms:
    # string
    terms = listify_lookup_plugin_terms("string", None, loader)
    assert terms == ["string"]
    # int
    terms = listify_lookup_plugin_terms(42, None, loader)
    assert terms == [42]
    # list
    terms = listify_lookup_plugin_terms([42, "string"], None, loader)
    assert terms == [42, "string"]
    # nested list
    terms = listify_lookup_plugin_terms([[42, "string"], "one"], None, loader)

# Generated at 2022-06-11 18:20:18.854133
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    vault_password = 'secret'
    terms = '{{foo}}'
    templar = Templar(loader, variables={'foo': ['one','two']})
    terms_list = listify_lookup_plugin_terms(terms, templar)
    assert terms_list == ['one', 'two']

    templar = Templar(loader, vault_password=vault_password, variables={'foo': ['one','two']})
    terms_list = listify_lookup_plugin_terms(terms, templar)
    assert terms_list == ['one', 'two']


# Generated at 2022-06-11 18:20:26.178825
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    assert listify_lookup_plugin_terms('foo', Templar([], {}), None) == ['foo']
    assert listify_lookup_plugin_terms(['foo'], Templar([], {}), None) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], Templar([], {}), None) == ['foo', 'bar']
    assert listify_lookup_plugin_terms([], Templar([], {}), None) == []

# Generated at 2022-06-11 18:20:33.920709
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.template import Templar

    terms = 'a, b, c'
    env = []
    templar = Templar(loader=None, variables={}, shared_loader_obj=None, fail_on_undefined=C.DEFAULT_UNDEFINED_VARIABLE_FAILURE)
    assert listify_lookup_plugin_terms(terms, templar, None, fail_on_undefined=False) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms([terms], templar, None, fail_on_undefined=False) == ['a', 'b', 'c']