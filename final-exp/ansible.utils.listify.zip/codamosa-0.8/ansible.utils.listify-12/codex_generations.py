

# Generated at 2022-06-11 18:10:40.741029
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    class MockedTemplate(string_types):
        def __new__(self, foo, convert_bare=False, fail_on_undefined=True):
            if foo == 'foo':
                if convert_bare:
                    return '["foo"]'
                return ['foo']
            else:
                return foo
    templar = Templar(loader=None, variables={})
    templar.template = MockedTemplate

    # Test string type
    terms = listify_lookup_plugin_terms(' foo ', templar, None, False, False)
    assert isinstance(terms, list) and len(terms) == 1 and isinstance(terms[0], string_types)

    # Test list of string containing variables (listify with template)

# Generated at 2022-06-11 18:10:51.811285
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    def run_test(test_args, expected_result, test_name, fail_on_undefined=True, convert_bare=False):
        ''' utility function to run listify_lookup_plugin_terms tests '''
        from ansible.template import Templar
        from ansible.parsing.dataloader import DataLoader
        loader = DataLoader()
        test_templar = Templar(loader=loader)
        result = listify_lookup_plugin_terms(test_args, test_templar, loader, fail_on_undefined=fail_on_undefined, convert_bare=convert_bare)
        assert result == expected_result, "%s failed. result is '%s' instead of expected '%s'" % (test_name, result, expected_result)


# Generated at 2022-06-11 18:11:02.060266
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    mocked_loader = True
    templar = Templar(loader=mocked_loader, variables={'a': 'foo'})

    # expected_result must be a list
    test_template = "{{ a }}"
    expected_result = ['foo']

    result = listify_lookup_plugin_terms(test_template, templar, mocked_loader)
    assert result == expected_result

    # expected_result must be a list
    test_template = ["{{ a }}"]
    expected_result = ['foo']

    result = listify_lookup_plugin_terms(test_template, templar, mocked_loader)
    assert result == expected_result

    # expected_result must be a list
    test_template = "foo"
    expected_result = ['foo']


# Generated at 2022-06-11 18:11:12.960436
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.template import Templar
    from ansible.errors import AnsibleError
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    import ansible.constants as C
    import json


# Generated at 2022-06-11 18:11:22.847373
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'foo': 'world'}
    templar = Templar(loader=loader, variables=variable_manager)
    # test when terms is a string
    terms = '{{foo}}'
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert terms[0] == 'world'
    # test when terms is a

# Generated at 2022-06-11 18:11:30.014200
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template.template
    import ansible.template.vars
    import ansible.vars.manager

    templar = ansible.template.template.Templar(loader=None, variables=ansible.template.vars.VariableManager(loader=None))
    test_terms = "{{ lookup_var_foo }}"
    test_terms_output = templar.template(test_terms,
                                         fail_on_undefined=True,
                                         convert_bare=False)
    assert test_terms_output == u"lookup_var_foo"

    # Test for function handling single string variable.
    test_terms = "lookup_var_foo"

# Generated at 2022-06-11 18:11:40.864987
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    fixture = dict(
        a=1,
        b=2,
        c=3
    )


# Generated at 2022-06-11 18:11:50.908558
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    ''' test listify lookup plugin terms '''
    from ansible.template import Templar
    t = Templar(loader=None)

# Generated at 2022-06-11 18:12:01.765226
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.basic import AnsibleModule

    from ansible.errors import AnsibleError
    from ansible.template import Templar

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.vault import VaultAES256

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.plugins.loader import lookup_loader, action_loader

    from ansible.template import Templar


# Generated at 2022-06-11 18:12:11.777914
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    data1 = '{{ foo }}'
    data2 = '{{ bar }}'
    data3 = '{{ baz }}'

    my_vars = {'foo': 'bar', 'bar': 'baz', 'baz': 'quux'}

    my_loader = DataLoader()
    my_vars = VariableManager()
    my_vars.extra_vars = my_vars
    my_templar = Templar(loader=my_loader, variables=my_vars)

    data = [data1, data2, data3]

# Generated at 2022-06-11 18:12:22.204863
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combination


# Generated at 2022-06-11 18:12:33.294840
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    listify_lookup_plugin_terms() returns the value as is if it is a list
    '''
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    yamlobj = AnsibleBaseYAMLObject('foo', loader)
    assert listify_lookup_plugin_terms(yamlobj, yamlobj, loader) == yamlobj

    yamlobj = AnsibleBaseYAMLObject(['foo', 'bar', 'baz'], loader)
    assert listify_lookup_plugin_terms(yamlobj, yamlobj, loader) == yamlobj



# Generated at 2022-06-11 18:12:41.802449
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    lookup = lookup_loader.get('file')

    # Test a string
    templar = Templar(None)
    result = listify_lookup_plugin_terms('{{ [foo, bar] }}', templar, None)
    assert isinstance(result, list)
    assert result == ['foo', 'bar']

    # Test a list
    result = listify_lookup_plugin_terms(['foo', 'bar'], templar, None)
    assert isinstance(result, list)
    assert result == ['foo', 'bar']

    # Test a single term
    result = listify_lookup_plugin_terms('foo', templar, None)
    assert isinstance(result, list)
    assert result == ['foo']

# Generated at 2022-06-11 18:12:51.854182
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)

    # normal string
    # default convert_bare to False
    assert listify_lookup_plugin_terms("string", templar, loader) == ["string"]
    assert listify_lookup_plugin_terms("{{foo}}", templar, loader) == ["{{foo}}"]
    assert listify_lookup_plugin_terms("{{foo}}", templar, loader, convert_bare=True) == ["{{foo}}"]
    assert listify_lookup_plugin_terms("string with space", templar, loader) == ["string with space"]
    assert listify_lookup_plugin_terms("", templar, loader) == [""]

# Generated at 2022-06-11 18:13:00.706616
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class MockTemplar(object):
        pass

    # Test string
    terms = "string"
    templar = MockTemplar()
    terms = listify_lookup_plugin_terms(terms, templar, "", False)
    assert isinstance(terms, list)

    # Test list
    terms = ["string", 'string2']
    templar = MockTemplar()
    terms = listify_lookup_plugin_terms(terms, templar, "", False)
    assert isinstance(terms, list)

# Generated at 2022-06-11 18:13:10.168304
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    items = [ 'foo', 'bar' ]

    templar = Templar(loader=None, variables={})
    terms = listify_lookup_plugin_terms(items, templar, loader=None)
    assert terms == items

    templar = Templar(loader=None, variables={})
    terms = listify_lookup_plugin_terms(u'foo,bar', templar, loader=None)
    assert terms == items

    templar = Templar(loader=None, variables={'foo':'bar', 'bar':'baz'})
    terms = listify_lookup_plugin_terms(u'{{foo}},{{bar}}', templar, loader=None)
    assert terms == ['bar', 'baz']


# Generated at 2022-06-11 18:13:18.565139
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils import context_objects as co

    assert listify_lookup_plugin_terms([1,2,3], None, None) == [1,2,3]
    assert listify_lookup_plugin_terms('1,2,3', None, None) == ['1,2,3']

    tmplar = Templar(loader=co.AnsibleLoader())
    assert listify_lookup_plugin_terms('1,2,3', tmplar, None) == ['1', '2', '3']

# Generated at 2022-06-11 18:13:26.283942
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    import os

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 18:13:38.005976
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # test strings
    assert ['1','2','3','4','5','6','7','8','9'] == listify_lookup_plugin_terms('1 2 3 4 5 6 7 8 9', None, None)
    assert ['one','two','three','four','five','six','seven','eight','nine'] == listify_lookup_plugin_terms('one two three four five six seven eight nine', None, None)
    assert ['one.two','three.four','five.six'] == listify_lookup_plugin_terms('one.two three.four five.six', None, None)
    assert ['one_two','three_four','five_six'] == listify_lookup_plugin_terms('one_two three_four five_six', None, None)
    assert ['one,two','three,four','five,six'] == listify

# Generated at 2022-06-11 18:13:46.583175
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = combine_vars(loader=loader, variables=None, include_dependencies=True)
    templar = Templar(loader=loader, variables=variable_manager)

    # Return an empty list if the string passed in is empty
    assert listify_lookup_plugin_terms('', templar, loader) == []

    # Return a list object
    assert isinstance(listify_lookup_plugin_terms('foo', templar, loader), list)

    # Return the item in a list if that's what was

# Generated at 2022-06-11 18:13:50.628700
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: Unit test this function
    return

# Generated at 2022-06-11 18:14:01.147671
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestLookupModule():

        def __init__(self, basedir, **kwargs):
            self.basedir = basedir

    class TestVarsModule():

        def __init__(self, loader, invdata=None):
            self.data = {'testvar': 'testvalue'}

        def get_vars(self, loader, path, entities):
            if entities is None:
                return self.data

# Generated at 2022-06-11 18:14:09.096036
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    class TestClass(object):
        def __init__(self):
            self.basedir = './'
            self.vault_secret = None

    testobj = TestClass()
    templar = Templar(loader=None, variables={}, vault_secrets=[VaultLib(password=None)],
                      convert_data=True)

    ret = listify_lookup_plugin_terms('something', templar, testobj)
    assert ret == ['something']

    ret = listify_lookup_plugin_terms(['something'], templar, testobj)
    assert ret == ['something']

    ret = listify_lookup_plugin_terms(['{{ something }}', 'something'], templar, testobj)

# Generated at 2022-06-11 18:14:20.610672
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.template import Templar

    def _load_data(self, filepath):
        if filepath in self._data:
            data = self._data[filepath]
        else:
            data = self._data[filepath] = {"hosts": ["foo", "bar"]}
        return data

    DataLoader._load_data = _load_data

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader, variable_manager, None)
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variable_manager=variable_manager)


# Generated at 2022-06-11 18:14:30.194330
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class FakeVarsModule(object):
        def get_vars(self, loader, path, entities):
            return dict(spam=AnsibleUnicode('ham'))

    fake_loader = FakeVarsModule()
    variable_manager = VariableManager()
    variable_manager.set_loader(fake_loader)
    templar = Templar(loader=fake_loader, variable_manager=variable_manager)

    # test list handling
    assert (listify_lookup_plugin_terms(['foo', '{{ spam }}'], templar, fake_loader) == ['foo', 'ham'])

    # test string handling

# Generated at 2022-06-11 18:14:36.583444
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    from ansible.parsing.vault import VaultLib
    vault_password = 'vaultpassword'

    vault = VaultLib(password=vault_password)
    templar = Templar(loader=None, variables=VariableManager(loader=None, host_vars=HostVars(loader=None, vault_password=vault_password)))
    test_string = VaultLib.encrypt(vault_password, 'foo')
    templar.template(test_string, convert_bare=True)
    terms = [test_string, test_string, "{{ foo }}"]
    results = list

# Generated at 2022-06-11 18:14:44.228491
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    if not HAS_TEMPLATE:
        print("ERROR: template module is not installed")
        return False

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    class MyLookupModule(object):
        def __init__(self, basedir=None, runner=None, **kwargs):
            pass

        def run(self, terms, variables=None, **kwargs):
            if isinstance(terms, string_types):
                terms = [terms]

            return terms

    # This is a convenient way to inject a lookup plugin into the test function


# Generated at 2022-06-11 18:14:54.988400
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.templating import TaskVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.release import __version__ as version

    import os

    vault_password = os.environ.get('VAULT_PASSWORD')
    vault_password_file = os.environ.get('VAULT_PASSWORD_FILE')

    # Override Ansible 2.2.0.0's assumption that since we have a vault password
    # file, it must be Ansible

# Generated at 2022-06-11 18:15:06.299896
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible import context
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    variable_manager = VariableManager()
    loader = DataLoader()

    def _vars():
        return dict()

    variable_manager.set_vars(_vars())

    my_vars = variable_manager.get_vars()
    my_vars['var1'] = 'foo'
    my_vars['var2'] = 'bar'
    my_vars['var3'] = ['fee', 'fi', 'fo', 'fum']
    my_vars['var4'] = AnsibleUnsafeText('blah')

    templar

# Generated at 2022-06-11 18:15:16.321891
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class DummyLoader(object):
        def __init__(self):
            self.templates = {}
        def get_basedir(self, path):
            return os.path.dirname(path)
    class DummyTemplar:
        def __init__(self, loader):
            self._data = {}
            self._loader = loader
        def set_available_variables(self, variables):
            self._data = variables
        def template(self, value, *args, **kwargs):
            return value

    test_listify_lookup_plugin_terms.loader = DummyLoader()
    test_listify_lookup_plugin_terms.templar = DummyTemplar(test_listify_lookup_plugin_terms.loader)


# Generated at 2022-06-11 18:15:31.441157
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(None, loader=None)

    # Test that the terms are returned as a list
    terms = listify_lookup_plugin_terms(terms="hello", templar=templar, loader=None)
    assert len(terms) == 1
    assert terms[0] == "hello"

    terms = listify_lookup_plugin_terms(terms=["hello", "world"], templar=templar, loader=None)
    assert len(terms) == 2
    assert terms[0] == "hello"
    assert terms[1] == "world"

    # Test that all terms are templated

# Generated at 2022-06-11 18:15:43.563838
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(test=dict(foo=1))
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-11 18:15:55.368213
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class DummyVarsModule(object):
        def get_vars(self, loader, path, entities, cache=True):
            vars = {
                "test": "hello",
                "test1": "foo",
                "test2": "world",
                "test3": "bar",
                "test4": [1, 2],
                "test5": 42
            }
            return vars

        def get_vars_files(self, loader):
            return []

    templar = Templar(loader=None, variables=DummyVarsModule())
    assert listify_lookup_plugin_terms("42", templar, None) == [42]
    assert listify_lookup_plugin_terms(42, templar, None) == [42]
    assert listify

# Generated at 2022-06-11 18:16:03.352419
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variable_manager=variable_manager)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(42, templar, loader) == [42]
    assert listify_lookup_plugin_terms(1.1, templar, loader) == [1.1]

# Generated at 2022-06-11 18:16:13.692482
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.quoting import unquote
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': '5'}


# Generated at 2022-06-11 18:16:25.778933
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Imports required for this test only
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    # Needed to make AnsibleTemplar __init__ happy
    variable_manager.set_inventory(None)
    templar = Templar(loader=loader, variable_manager=variable_manager)

    assert listify_lookup_plugin_terms('one', templar, loader) == ['one']
    assert listify_lookup_plugin_terms(42, templar, loader) == [42]
   
    mylist = ['one', 'two', '{{foo}}']
    variable_manager.set_nonpersistent_facts(dict(foo='three'))

# Generated at 2022-06-11 18:16:35.168326
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    # Lookup with a single string
    assert listify_lookup_plugin_terms(terms='{{foo}}', templar=templar, loader=None) == ['foo']

    # Lookup with a list
    assert listify_lookup_plugin_terms(terms=['foo', 'bar'], templar=templar, loader=None) == ['foo', 'bar']

    # Lookup with a list in a variable
    assert listify_lookup_plugin_terms(terms='{{v}}', templar=templar, loader=None,
                                       variables={'v': ['foo', 'bar']}) == ['foo', 'bar']

    # Lookup with a string in a variable
    assert listify_lookup

# Generated at 2022-06-11 18:16:45.200792
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from jinja2 import Environment
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    env = Environment(loader=dataloader.load_from_file)

    templar = Templar(loader=dataloader, variables={'a': 'foo.bar'})

    # Test string
    s = listify_lookup_plugin_terms('{{ a }}', templar, loader=dataloader)
    assert s == ['foo.bar'], s

    # Test integer
    i = listify_lookup_plugin_terms(123, templar, loader=dataloader)
    assert i == [123], i

    # Test list

# Generated at 2022-06-11 18:16:54.591129
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.template import Templar
    from ansible.playbook.play import Play

    t = Templar(loader=None, variables=dict(my_var=42))

    results = listify_lookup_plugin_terms('{{ my_var }}', t, None)
    assert isinstance(results, list)
    assert results == [42]

    results = listify_lookup_plugin_terms(['one', 'two'], t, None)
    assert isinstance(results, list)
    assert results == ['one', 'two']

    results = listify_lookup_plugin_terms(dict(), t, None)
    assert isinstance(results, list)
    assert results == [dict()]

    results = listify_lookup_plugin_terms(42, t, None)
    assert isinstance(results, list)

# Generated at 2022-06-11 18:17:06.134352
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible import constants as C
    C.DEFAULT_HASH_BEHAVIOUR = 'merge'

    class TestVars(dict):
        vars = dict(
            var_a=['a', 'b', 'c'],
            var_b=['d', 'e'],
            var_c=['f', 'g'],
        )

        def __getitem__(self, key):
            return self.vars[key]

    templar = Templar(loader=None, variables=TestVars())


# Generated at 2022-06-11 18:17:28.990939
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    my_loader = None
    my_templar = Templar(loader=my_loader)

    # example of what a lookup plugin might get back as terms to use
    string_string_list_dict = {
        '_terms': [
            "{{foo}}",
            [ "{{bar}}", "{{baz}}" ],
            {'_terms': [ "{{bam}}", "{{boom}}" ]},
        ]
    }

    # the expected result of running listify_lookup_plugin_terms on the above example

# Generated at 2022-06-11 18:17:41.184235
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms("this", None, None) == ["this"]
    assert listify_lookup_plugin_terms("this", None, None, fail_on_undefined=False) == ["this"]
    assert listify_lookup_plugin_terms(["this"], None, None) == ["this"]
    assert listify_lookup_plugin_terms(["this", "that"], None, None) == ["this", "that"]
    assert listify_lookup_plugin_terms("", None, None) == [""]
    assert listify_lookup_plugin_terms("\t", None, None) == ["\t"]
    assert listify_lookup_plugin_terms("\n", None, None) == [""]


# Generated at 2022-06-11 18:17:49.612343
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = dict(
        foo='bar',
        baz=[1, 2, 3],
    )
    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-11 18:18:00.526919
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.templating import Templar

    loader = DataLoader()
    jinja2_env = Templar._init_global_environment()
    templar = Templar(loader=loader, variables={}, environment=jinja2_env)

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms(None, templar, loader) == [None]

    terms = tuple('bar')
    assert listify_lookup_plugin_terms(terms, templar, loader) == list(terms)
    terms = ['foo', '{{ bar }}', 'bar']

# Generated at 2022-06-11 18:18:12.476848
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    loader = DictDataLoader({
        "/a.yml": """
            - one
            - two
            - three
        """,
        "/b.yml": """
            - four
            - five
        """,
        "/c.yml": """
            - six
            - seven
            - eight
        """
    })

    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader, inventory=Inventory()))
    inventory._vars_per_host = {"localhost": {'a': 1, 'b': 2, 'c': 3}}
    templar = Templar(loader=loader, inventory=inventory)

    def assert_lists_equal(input, output):
        assert sorted(input) == sorted(output)


# Generated at 2022-06-11 18:18:23.582359
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.compat.mock import patch, MagicMock
    from ansible.template import Templar

    templar = Templar(loader=None)
    listify_lookup_plugin_terms(terms=['foo', 'bar', 'baz'], templar=templar, loader=None)

    with patch.object(templar, 'template') as template_mock:
        listify_lookup_plugin_terms(terms='{{ foo }}', templar=templar, loader=None)
        assert template_mock.call_count == 1
        template_mock.reset_mock()

        listify_lookup_plugin_terms(terms=['foo', '{{ bar }}', 'baz'], templar=templar, loader=None)

# Generated at 2022-06-11 18:18:33.872354
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    # test 1
    assert listify_lookup_plugin_terms('foo', templar, '') == ['foo']

    # test 2
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, '') == ['foo', 'bar']

    # test 3
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, '', convert_bare=True) == ['foo', 'bar']

    # test 4
    assert listify_lookup_plugin_terms(['foo', 'bar', 'baz baz'], templar, '') == ['foo', 'bar', 'baz baz']

    # test 5
    assert listify_lookup_plugin_terms

# Generated at 2022-06-11 18:18:45.408282
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    #
    # This is a bit of a boring test case because the majority of this is
    # really tested in test_list_of_all_the_things in ansible/test/unit/test_utils.py,
    # and the templating is tested in test_lookup_templating in ansible/test/unit/test_lookup.py
    #
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    dataloader = DataLoader()
    variable_manager = VariableManager()

    terms = ['{{ one }}', '{{ two }}', '{{ three }} four']
    variable_manager.set_nonpersistent_facts(dict(one=1, two=2, three=3, four=4))
    templ

# Generated at 2022-06-11 18:18:52.424336
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # test listify function is available
    from ansible.utils.listify import listify

    # input validation test (input is not list)
    assert listify('hi') == ['hi']

    # input validation test (input is already list)
    assert listify(['hi']) == ['hi']

    # input validation test (input is tuple)
    assert listify(('hi',)) == ['hi']

    # input validation test (input is empty list)
    assert listify([]) == []

    # input validation test (input is empty tuple)
    assert listify(()) == []

    # input validation test (input is empty string)
    assert listify('') == []

    # input validation test (input is None)
    assert listify(None) == []

# Generated at 2022-06-11 18:19:02.822913
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.lookup_plugins import listify_lookup_plugin_terms
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar

    data = '''
    foo:
      - 1
      - 2
      - 3
    '''


# Generated at 2022-06-11 18:19:36.855574
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    #from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    #from ansible.playbook.play_context import PlayContext

    import pytest

    def get_loader():
        return DataLoader()

    def get_inventory(loader):
        return InventoryManager(loader=loader, sources=['localhost,'])

    def get_variable_manager(loader, inventory):
        return VariableManager(loader=loader, inventory=inventory)

    # set up
    loader = get_loader()
    variable_manager = get_variable_manager(loader, get_inventory(loader))

# Generated at 2022-06-11 18:19:46.351021
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))

    data = {
        "foo": "123",
        "bar": 456,
        "bam": [1, 2, 3],
    }

    assert listify_lookup_plugin_terms(data, templar, None) == data
    assert listify_lookup_plugin_terms(data, templar, None, fail_on_undefined=False) == data
    assert listify_lookup_plugin_terms(data, templar, None, convert_bare=True) == data


# Generated at 2022-06-11 18:19:55.682063
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = [ "a", "{{ var1 }}", "{{ var2 }}", "{{ var2 }}", "{{ var3 }}" ]

    inventory_vars = dict(
        var1='b',
        var2=['c', 'd'],
        var3='e',
    )

    tmplar = Templar(loader=None, variables=inventory_vars)

    result = listify_lookup_plugin_terms(terms, tmplar, loader=None, fail_on_undefined=True)

    # The following asserts validate the result.
    # The result is a list, and has the right number of elements.
    assert isinstance(result, list)
    assert len(result) == 11

    # The items in the list are unique, and the right values.
    assert len

# Generated at 2022-06-11 18:20:05.086200
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    from ansible.errors import AnsibleUndefinedVariable

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    class DummyVars(object):

        def get_vars(self, loader, play, host):
            return dict(var1='val1', var2='val2', var3=5, var4=[1,2,3])


    terms = [ '{{ var1 }}', '{{ var2 }}', '{{ var3 }}', '{{ var4 }}', ]

    templar = Templar(loader=DataLoader(), variables=VariableManager(loader=DataLoader()))


# Generated at 2022-06-11 18:20:16.235145
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeModule:
        def __init__(self, args):
            self.args = args

    class FakePlayContext:
        def __init__(self):
            self.prompt = None
            self.connection = None

    class FakeLoader:
        pass

    class FakeVarManager:
        pass

    fake_module = FakeModule(dict(a=2, b=3))
    fake_pc = FakePlayContext()
    fake_tmplar = Templar(loader=FakeLoader(), variables=FakeVarManager())

    # Test list input
    terms = ['foo', 'bar', 'baz']
    assert listify_lookup_plugin_terms(terms, fake_tmplar, FakeLoader(), convert_bare=True) == terms

    # Test dict input

# Generated at 2022-06-11 18:20:21.777345
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 18:20:32.662501
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    import os

    variable_manager = VariableManager()

    terms = 'foo'
    templar = Templar(loader=None, variables=variable_manager, vault_secrets=[])
    terms = listify_lookup_plugin_terms(terms, templar=templar, loader=None, convert_bare=False)
    assert terms == ['foo']

    terms = ['foo', '{{x}}']
    templar = Templar(loader=None, variables=variable_manager, vault_secrets=[])
    terms = listify_lookup_plugin_terms(terms, templar=templar, loader=None, convert_bare=False)