

# Generated at 2022-06-11 18:10:37.319118
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """Unit tests for listify_lookup_plugin_terms
    """

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # test simple string input
    term = 'one'
    templar = Templar(loader=loader, variables=variable_manager)
    result = listify_lookup_plugin_terms(term, templar, loader)
    assert result == ['one'], 'expecting listified string'

    # test string with templating
    term = '{{ testvar }}'
    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-11 18:10:45.268887
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from . import module_utils
    from ansible.parsing.vault import VaultLib

    templar = module_utils.setup_template_environment()

    # Single value as string (will be converted to a list)
    assert listify_lookup_plugin_terms(terms='foo', templar=templar) == ['foo']
    assert listify_lookup_plugin_terms(terms='foo bar', templar=templar) == ['foo bar']
    assert listify_lookup_plugin_terms(terms='"foo bar"', templar=templar) == ['foo bar']

    # Single value as list (will be converted to a list)
    assert listify_lookup_plugin_terms(terms=['foo'], templar=templar) == ['foo']
    assert listify_look

# Generated at 2022-06-11 18:10:54.968798
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'listify_var': 'listified_value'}
    loader = None
    templar = Templar(loader=loader, variables=variable_manager)

    # Test a string term
    result = listify_lookup_plugin_terms('{{ listify_var }}', templar, loader)
    assert(result == ['listified_value'])

    # Test a list term
    result = listify_lookup_plugin_terms(['value-1', 'value-2'], templar, loader)
    assert(result == ['value-1', 'value-2'])

    # Test a list of terms including a template
    result = listify_look

# Generated at 2022-06-11 18:11:03.813883
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = 'foo'
    templar = Templar(loader=None, variables={})
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['foo']

    terms = ['foo', 'bar', b'baz']
    templar = Templar(loader=None, variables={})
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['foo', 'bar', 'baz']

    terms = ['foo', '{{hostvars.localhost.foo}}', 'baz.{{env.BAR}}']

# Generated at 2022-06-11 18:11:14.289148
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variables = {}
    templar = Templar(loader=loader, variables=variables)
    terms = listify_lookup_plugin_terms('test', templar, loader)
    assert terms == ['test']
    terms = listify_lookup_plugin_terms(['test'], templar, loader)
    assert terms == ['test']
    terms = listify_lookup_plugin_terms(('test', 'test2'), templar, loader)
    assert terms == ['test', 'test2']
    terms = listify_lookup_plugin_terms(['{{"test"}}', 'test2'], templar, loader, convert_bare=True)

# Generated at 2022-06-11 18:11:25.012343
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'var': 'value'})

    # string -> list of strings
    assert listify_lookup_plugin_terms('1 2 3', templar, fail_on_undefined=False) == ['1', '2', '3']

    # list -> list of strings
    assert listify_lookup_plugin_terms(['1', '2', '3'], templar, fail_on_undefined=False) == ['1', '2', '3']
    assert listify_lookup_plugin_terms([' dict key ', ' dict key2 '], templar, fail_on_undefined=False) == [' dict key ', ' dict key2 ']

    # list of lists -> list of strings
    assert listify_lookup_plugin_

# Generated at 2022-06-11 18:11:32.320797
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import os
    import sys
    import unittest

    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), os.path.pardir))

    from ansible.playbook.play_context import PlayContext

    from units.mock.loader import DictDataLoader
    from units.mock.lookup_plugin import TestLookupModule

    from units.mock.template import MockTemplate

    class TestListify(unittest.TestCase):

        def test_string_converted_to_list(self):
            terms = 'foo'
            loader = DictDataLoader({})
            inventory = PlayContext()
            t = MockTemplate(loader=loader, inventory=inventory)

# Generated at 2022-06-11 18:11:42.997272
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    loader = None
    variable_manager = VariableManager()
    inventory = None
    jinja2_env = None
    all_vars = dict()
    templar = Templar(loader=loader, variables=all_vars, shared_loader_obj=variable_manager)

    assert listify_lookup_plugin_terms('test', templar, loader) == ['test']
    assert listify_lookup_plugin_terms('"test"', templar, loader, convert_bare=True) == ['test']

# Generated at 2022-06-11 18:11:49.648590
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test when the variable is a string
    templar = Templar(loader=None)
    variable = "Hello World"
    actual_result = listify_lookup_plugin_terms(variable, templar, None)
    assert actual_result == ["Hello World"]

    # Test when the variable is a list
    templar = Templar(loader=None)
    variable = ["Hello", "World"]
    actual_result = listify_lookup_plugin_terms(variable, templar, None)
    assert actual_result == ["Hello", "World"]

    # Test when the variable is a dictionary
    templar = Templar(loader=None)
    variable = {"Hello":"World"}

# Generated at 2022-06-11 18:11:58.940549
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    templar = {
        'template': lambda x, y=None, z=None: x
    }

    loader = {
        'get_basedir': lambda: ''
    }

    assert listify_lookup_plugin_terms('a b c', templar, loader, convert_bare=False) == ['a b c']
    assert listify_lookup_plugin_terms('a b c', templar, loader, convert_bare=True) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], templar, loader, convert_bare=True) == ['a', 'b', 'c']

# Generated at 2022-06-11 18:12:11.230358
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar()
    terms = '{{ var1 }}'
    assert listify_lookup_plugin_terms(terms, templar, fail_on_undefined=True) == ['{{ var1 }}']

    terms = '{{ var1 }} {{ var2 }}'
    assert listify_lookup_plugin_terms(terms, templar, fail_on_undefined=True) == ['{{ var1 }}', '{{ var2 }}']

    terms = ['{{ var1 }}', '{{ var2 }}']
    assert listify_lookup_plugin_terms(terms, templar, fail_on_undefined=True) == ['{{ var1 }}', '{{ var2 }}']

    terms = '{{ var1 }},{{ var2 }}'
    assert listify_lookup_plugin_

# Generated at 2022-06-11 18:12:21.410743
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.inventory import Inventory
    import pytest

    inventory = Inventory(
        host_list=[
            'localhost',
        ],
        group_list=[
            'local:children',
        ],
        loader=None,
        variable_manager=None,
    )
    inventory.set_variable('local', 'localhost')
    inventory.set_variable('groups', ['local'])
    inventory.set_variable('group_names', ['local'])
    inventory.set_variable('omit', '__omit_place_holder__')

    # single string:
    # - no undefined variables
    # - with undefined variables

# Generated at 2022-06-11 18:12:33.151311
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Template for generating the 'terms' list by listify_lookup_plugin_terms()
    template_terms = Templar()

    # Test empty term
    term = listify_lookup_plugin_terms(None, template_terms)
    assert(len(term) == 0)

    term = listify_lookup_plugin_terms(False, template_terms)
    assert(len(term) == 0)

    term = listify_lookup_plugin_terms([], template_terms)
    assert(len(term) == 0)

    # Test term is string_types
    term = listify_lookup_plugin_terms('a', template_terms, None, True, True)
    assert(isinstance(term[0], string_types))
    assert(len(term) == 1)
   

# Generated at 2022-06-11 18:12:41.701957
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms('a', templar, None) == ['a']
    assert listify_lookup_plugin_terms(['a'], templar, None) == ['a']
    assert listify_lookup_plugin_terms(['a', 'b', 'c'], templar, None) == ['a', 'b', 'c']
    assert listify_lookup_plugin_terms(['a', 'b', ['c']], templar, None) == ['a', 'b', ['c']]

# Generated at 2022-06-11 18:12:47.716734
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']
    assert listify_lookup_plugin_terms(' foo  ', None, None) == ['foo']
    assert listify_lookup_plugin_terms('foo bar', None, None) == ['foo bar']
    assert listify_lookup_plugin_terms(['foo', 'bar', 1], None, None) == ['foo', 'bar', 1]

# Generated at 2022-06-11 18:12:55.498667
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    assert listify_lookup_plugin_terms('1,2', None, None) == ['1', '2']
    assert listify_lookup_plugin_terms(('1', '2'), None, None) == ['1', '2']
    assert listify_lookup_plugin_terms(['1', '2'], None, None) == ['1', '2']
    assert listify_lookup_plugin_terms("1", None, None) == ['1']
    assert listify_lookup_plugin_terms("1,2,", None, None) == ['1', '2']
    assert listify_lookup_plugin_terms("1,,2,", None, None) == ['1', '', '2']

# Generated at 2022-06-11 18:13:04.993690
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.hashing import md5s
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    if PY3:
        unicode_str = str
    else:
        unicode_str = unicode

    from ansible.template import Templar
    t = Templar(loader=None)
    # mimic defaults for test
    t.set_available_variables({})
    t.set_environment(None)

    # test strings
    for term in ['', 'one', 'one two']:
        terms = listify_lookup_plugin_terms(term, templar=t)
        assert term == terms[0]
        assert type(terms[0]) is str

    # test dict with one entry
    terms = listify_lookup_

# Generated at 2022-06-11 18:13:15.739288
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    test_vars = dict(
        a='foo',
        b='bar',
        c='baz',
        d='qux'
    )
    templar = Templar(loader=None, variables=test_vars)

    # Check that fail_on_undefined is False by default
    assert listify_lookup_plugin_terms('{{ a }}', templar, loader=None) == ['foo']
    assert listify_lookup_plugin_terms('{{ e }}', templar, loader=None) == [None]

    # Check that the templar is applied to the term
    assert listify_lookup_plugin_terms('{{ a }}', templar, loader=None, fail_on_undefined=True) == ['foo']
    assert listify_lookup_

# Generated at 2022-06-11 18:13:25.025123
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
   assert listify_lookup_plugin_terms(" test ",None,None) == [" test "]
   assert listify_lookup_plugin_terms(" test  ,  foo  ",None,None) == [" test  ", "  foo  "]
   assert listify_lookup_plugin_terms(" test , foo ",None,None) == [" test ", " foo "]
   assert listify_lookup_plugin_terms(" test , foo ",None,None) == [" test ", " foo "]
   assert listify_lookup_plugin_terms([" test "," foo "],None,None) == [" test ", " foo "]
   assert listify_lookup_plugin_terms([" [ test ] "," [ foo , bar ] "],None,None) == [[ 'test' ], ['foo', 'bar']]

# Generated at 2022-06-11 18:13:34.274177
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms('somestring', templar, None) == ['somestring']
    assert listify_lookup_plugin_terms('some string', templar, None) == ['some string']
    assert listify_lookup_plugin_terms(' some string ', templar, None) == [' some string ']
    assert listify_lookup_plugin_terms(['some string'], templar, None) == ['some string']

# Generated at 2022-06-11 18:13:45.955568
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    my_vars = dict(
        foo=['bar', 'baz'],
        bar=dict(
            baz=['qux', 'quux'],
            qux=[1, 2, 3],
            quux=dict(
                corge=3.14,
            ),
        ),
    )

    loader = DummyLoader(my_vars)

    templar = Templar(loader=loader)

    # Return value should always be a list
    assert isinstance(listify_lookup_plugin_terms(['foo', 'bar'], templar, loader, convert_bare=True), list)

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader, convert_bare=True) == ['foo', 'bar']

# Generated at 2022-06-11 18:13:55.267679
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import json
    from ansible.template import Templar

    class FakeVarsModule:
        pass

    data = dict(a=5, b=6, c=7)
    VarsModule = FakeVarsModule()
    setattr(VarsModule, "vars", lambda: data)
    templar = Templar(loader=None, variables=data)


# Generated at 2022-06-11 18:14:05.192204
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars.unsafe_proxy import UnsafeProxy

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    from ansible.utils.vars import combine_vars

    templar = Templar(loader=DataLoader(), variables=combine_vars(loader=DataLoader(), vault_secrets=VaultLib()))

    # empty
    assert listify_lookup_plugin_terms([], templar) == []

    # string
    assert listify_lookup_plugin_terms('one', templar) == ['one']

    # list
    assert listify_lookup_plugin_terms(['first', 'second'], templar) == ['first', 'second']

    # list with

# Generated at 2022-06-11 18:14:11.564436
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """ unit tests for legacy behavior of listify lookup plugin terms """

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    assert listify_lookup_plugin_terms(None, templar, loader=None, fail_on_undefined=True, convert_bare=False) == [None]
    assert listify_lookup_plugin_terms(None, templar, loader=None, fail_on_undefined=True, convert_bare=True) == ['']
    assert listify_lookup_plugin_terms([], templar, loader=None, fail_on_undefined=True, convert_bare=True) == []

# Generated at 2022-06-11 18:14:12.278012
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-11 18:14:22.042868
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test valid input
    terms = ['a','b','c','d']
    result = listify_lookup_plugin_terms(terms, None, None)
    assert result == terms

    terms = "abcd"
    result = listify_lookup_plugin_terms(terms, None, None)
    assert result == [terms]

    terms = ["{{a}}", 'b<{{c}}>d']
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-11 18:14:31.409796
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar

    templar = Templar()
    mylist = []
    mylist.append('cat.txt')
    mylist.append('dog.txt')
    assert mylist == listify_lookup_plugin_terms('cat.txt dog.txt', templar, None)
    assert mylist == listify_lookup_plugin_terms(['{{ ansible_user_dir }}/foo.txt', 'bar.txt'], templar, None)
    assert mylist == listify_lookup_plugin_terms('{{ ansible_user_dir }}/foo.txt bar.txt', templar, None)
    assert mylist == listify_lookup_plugin_terms(['cat.txt', 'dog.txt'], templar, None)
    assert mylist == listify_lookup

# Generated at 2022-06-11 18:14:40.489718
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.six import PY2

    if PY2:
        from ansible.module_utils.common._collections_compat import unicode
        unicode_class = unicode
    else:
        unicode_class = str

    from ansible.template import Templar

    class DummyVarsModule(object):
        def __init__(self):
            self.params = {'a': "a", 'b': 2}

    class DummyLoader(object):
        def __init__(self):
            self.path_dwim = lambda a: a

    dummy_vars = DummyVarsModule()
    dummy_loader = DummyLoader()
    templar = Templar(loader=dummy_loader, variables=dummy_vars)


# Generated at 2022-06-11 18:14:51.209662
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DictDataLoader({
        "somevars.yml" : """
            a: 1
            b: 2
        """,
        "someothervars.yml" : """
            c: 3
            d: 4
        """
    })
    var_manager = VariableManager()
    var_manager.extra_vars = {
        "alpha" : "a",
        "list1" : [1,2,3]
    }

# Generated at 2022-06-11 18:14:58.496651
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils import template

    t = template.AnsibleTemplate(
        None,
        None,
        template.AnsibleEnvironment([], None),
        None,
        None
    )

    test = listify_lookup_plugin_terms("hello", templar=t, loader=None)
    assert test == ["hello"]

    test = listify_lookup_plugin_terms([1], templar=t, loader=None)
    assert test == [1]

    test = listify_lookup_plugin_terms(1, templar=t, loader=None)
    assert test == [1]

    test = listify_lookup_plugin_terms("{{ ['hello','world'] }}", templar=t, loader=None)
    assert test == ["hello","world"]

# Generated at 2022-06-11 18:15:06.882682
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # test string
    result = listify_lookup_plugin_terms("one, two, three", None, None)
    assert isinstance(result, list)
    assert len(result) == 3
    assert result == ["one","two","three"]

    # test list
    result = listify_lookup_plugin_terms(["one", "two", "three"], None, None)
    assert isinstance(result, list)
    assert len(result) == 3
    assert result == ["one","two","three"]

# Generated at 2022-06-11 18:15:16.687895
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # pylint: disable=import-error,unused-import
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader(), vault_secrets=VaultLib(), variables={'var1': 'Hello', 'var2': 'World', 'var3': [1, 2, 3]})

    assert listify_lookup_plugin_terms('{{var1}}', templar, False) == ['Hello']
    assert listify_lookup_plugin_terms(['{{var1}}', '{{var2}}'], templar, False) == ['Hello', 'World']

# Generated at 2022-06-11 18:15:23.815755
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    assert listify_lookup_plugin_terms(['one', 'two', 'three'], Templar(), None) == ['one', 'two', 'three']
    assert listify_lookup_plugin_terms(('one', 'two', 'three'), Templar(), None) == ['one', 'two', 'three']
    assert listify_lookup_plugin_terms(('one', 'two', 'three'), Templar(), None, convert_bare=True) == ['one', 'two', 'three']
    assert listify_lookup_plugin_terms('four', Templar(), None) == ['four']
    assert listify_lookup_plugin_terms('{{foo}}', Templar(), None, convert_bare=True) == ['{{foo}}']

# Generated at 2022-06-11 18:15:31.105011
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms("1", templar, None) == ["1"]
    assert listify_lookup_plugin_terms(["1"], templar, None) == ["1"]
    assert listify_lookup_plugin_terms([1], templar, None) == [1]
    assert listify_lookup_plugin_terms([1, 2, 3], templar, None) == [1, 2, 3]
    assert listify_lookup_plugin_terms(1, templar, None) == [1]

# Generated at 2022-06-11 18:15:38.505095
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    var_mgr = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=var_mgr, host_list=['localhost'])
    var_mgr.set_inventory(inventory)
    templar = Templar(loader=loader, variables=var_mgr)


# Generated at 2022-06-11 18:15:48.621767
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.template import Templar

    templar = Templar(loader=None)

    # test both string and non-string iterables
    def do_test(terms, expected):
        result = listify_lookup_plugin_terms(terms, templar, loader=None)
        assert result == expected, "%s != %s (%s)" % (result, expected, terms)

    do_test('foo,bar', ['foo', 'bar'])
    do_test('foo, bar', ['foo', 'bar'])
    do_test('foo , bar', ['foo', 'bar'])
    do_test('foo , bar,baz', ['foo', 'bar', 'baz'])

    do_test(['foo', 'bar'], ['foo', 'bar'])
    do_test

# Generated at 2022-06-11 18:15:59.436416
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins'))
    my_vars = VariableManager()
    my_vars.extra_vars = {'var1': 'var1', 'var2': 'var2', 'var3': ['val31', 'val32']}
    my_inventory = InventoryManager(loader=loader, sources='')
    my_templar = Templar(loader=loader, variables=my_vars, inventory=my_inventory)

    # tests with use_single_value=True
    assert listify_lookup_plugin

# Generated at 2022-06-11 18:16:11.023624
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.utils
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.template

    terms = []
    templar = ansible.template.Templar(loader=ansible.parsing.dataloader.DataLoader(), variables=ansible.vars.manager.VariableManager())
    loader = ansible.parsing.dataloader.DataLoader()
    # Test passing a string for terms
    terms = listify_lookup_plugin_terms("test", templar, loader)
    assert isinstance(terms, list)
    assert terms[0] == "test"
    # Test passing an array for terms
    terms = listify_lookup_plugin_terms(["test","test2"], templar, loader)

# Generated at 2022-06-11 18:16:22.858149
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class DummyVarsModule(object):
        def get_vars(self, loader, play, host, task):
            return {}

    templar_args = (DummyVarsModule(), {})
    templar = Templar(loader=None, variables=dict(), *templar_args)

    assert listify_lookup_plugin_terms(None, templar, {}) == []
    assert listify_lookup_plugin_terms([None], templar, {}) == [None]
    assert listify_lookup_plugin_terms([None, 'foo'], templar, {}) == [None, 'foo']
    assert listify_lookup_plugin_terms('{{foo}}', templar, {}) == ['{{foo}}']
    assert listify_lookup_

# Generated at 2022-06-11 18:16:30.566894
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    # String input with comma-separated elements
    terms = 'a,b,c'
    listified_terms = listify_lookup_plugin_terms(terms, variable_manager, loader)
    assert(isinstance(listified_terms, list))
    assert(len(listified_terms) is 3)
    assert(listified_terms[0] is 'a')
    assert(listified_terms[1] is 'b')
    assert(listified_terms[2] is 'c')

    # List input
    terms = ['a', 'b', 'c']

# Generated at 2022-06-11 18:16:45.753762
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils._text import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    terms = [
        { "var": "foobar", "val": "blah" },
        { "var": "foobar", "val": {"a": "b"} },
        { "var": "foobar", "val": ["blah", "blah", "blah"] },
        { "var": "foobar", "val": "{{ foobar }}" },
        { "var": "foobar", "val": "{{ foobar }}", "boom": True},
    ]
    templar_source_data = dict(foobar="{{ test_variable }}")
    templar = Templar(loader=None, variables=templar_source_data)


# Generated at 2022-06-11 18:16:54.807234
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader)

    # test string input
    assert listify_lookup_plugin_terms("value", templar, loader, fail_on_undefined=True, convert_bare=False) == ["value"]
    assert listify_lookup_plugin_terms("value", templar, loader, fail_on_undefined=True, convert_bare=True) == ["value"]

    # test list input
    assert listify_lookup_plugin_terms(["value"], templar, loader, fail_on_undefined=True, convert_bare=False) == ["value"]

# Generated at 2022-06-11 18:17:01.660413
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms([1, 2], Templar(), None) == [1, 2]

    assert listify_lookup_plugin_terms('a/b/c', Templar(), None) == ['a', 'b', 'c']

    assert listify_lookup_plugin_terms(['a/b/c', 1, 2], Templar(), None) == ['a', 'b', 'c', 1, 2]

# Generated at 2022-06-11 18:17:02.857876
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # TODO: write unit test
    pass

# Generated at 2022-06-11 18:17:11.407911
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class FakeVars(AnsibleMapping):
        def __init__(self, items):
            super(FakeVars, self).__init__(items)

        def __getitem__(self, k):
            try:
                return getattr(self, k)
            except AttributeError:
                raise KeyError("%s not found" % k)

    loader = FakeVars({'get_basedir': lambda x: '/path/to/basedir'})

    var_manager = VariableManager()
    var_manager._fact_cache = dict()


# Generated at 2022-06-11 18:17:19.680858
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

# Generated at 2022-06-11 18:17:29.821205
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class TestTemplar(object):
        def __init__(self):
            self.available_variables = {
                "test_var": "bar",
                "test_list": ["bar", "baz"],
            }

        def template(self, terms, fail_on_undefined=True):
            assert isinstance(terms, (string_types, list))
            if isinstance(terms, string_types):
                return self.available_variables.get(terms, terms)
            elif isinstance(terms, list):
                return [self.available_variables.get(term, term) for term in terms]

    templar = TestTemplar()

    class TestLoader(object):
        def get_basedir(self, terms):
            return terms

    loader = TestLoader

# Generated at 2022-06-11 18:17:41.952078
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar


# Generated at 2022-06-11 18:17:49.854849
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    my_var = dict(a='bar')
    loader = None
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    variable_manager.set_host_variable('localhost', my_var)
    variables = variable_manager.get_vars(loader=loader, play=PlayContext())
    templar = Templar(loader=loader, variables=variables)

    results = listify_lookup_plugin_terms(['{{ foo }}', '{{ a }}'], templar=templar, loader=loader)
    assert results == ['bar', 'bar']

# Generated at 2022-06-11 18:18:00.660121
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    class DummyVars(object):
        _hostvars = 'hostvars'
        def get_vars(self, loader=None, play=None, host=None, task=None, include_hostvars=True):
            return dict(a=1, b=2, c=3)

    class DummyLoader(object):
        _vars_plugins = DummyVars()
        path_info = {}
        def get_basedir(self, host):
            return '/tmp'

    templar = Templar(loader=DummyLoader())

    assert listify_lookup_plugin_terms('1', templar, DummyLoader()) == ['1']
    assert listify_lookup_plugin_terms(['1'], templar, DummyLoader()) == ['1']


# Generated at 2022-06-11 18:18:23.462425
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    templar = Templar(vars={}, vault_secrets=dict(vault_password='vault_password'))

    # string type terms
    term_val = '{{ lookup_var }}'
    lookup_var = 'lookup_var_val'
    vars = dict(lookup_var=lookup_var)
    terms = listify_lookup_plugin_terms(term_val, templar, loader=None, vars=vars)
    assert terms == [lookup_var]

    # list type terms
    term_val = ['{{ lookup_var }}']
    lookup_var = 'lookup_var_val'
    vars = dict(lookup_var=lookup_var)
    terms

# Generated at 2022-06-11 18:18:33.790807
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    class Templer:
        def __init__(self, value):
            self.value = value
        def template(self, terms, **kwargs):
            return self.value

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    dl = DataLoader()
    vm = VariableManager()

    assert listify_lookup_plugin_terms('foo', Templer('foo'), dl, fail_on_undefined=True, convert_bare=False) == ['foo']
    assert listify_lookup_plugin_terms('foo', Templer('foo'), dl, fail_on_undefined=True, convert_bare=True) == ['foo']
    assert listify_lookup_

# Generated at 2022-06-11 18:18:45.249980
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.module_utils.common.collections

    # single value test
    assert listify_lookup_plugin_terms(5, None, None) == [5]

    # unicode test
    assert listify_lookup_plugin_terms(u'\u00c9glise Saint-Sulpice', None, None) == [u'\u00c9glise Saint-Sulpice']

    # empty string test
    assert listify_lookup_plugin_terms('', None, None) == ['']

    # string test
    assert listify_lookup_plugin_terms('one', None, None) == ['one']

    # comma separated string test
    assert listify_lookup_plugin_terms('one, two', None, None) == ['one', 'two']

    # trailing comma string test
    assert list

# Generated at 2022-06-11 18:18:52.774572
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_bytes, to_text

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    collection = [ {'name':'foo'}, {'name':'bar'}, {'name':'baz'}, {'name':'bat'} ]

    class TestModule:
        def __init__(self, collection):
            self.params = { 'collection': collection }

        def fail_json(self, *args, **kwargs):
            raise AssertionError('fail_json should not be called')

    spec = {
        u'name': u'test',
        u'args': {
            u'collection': u'collection',
        }
    }

    module = TestModule(collection)
    context = PlayContext()
    tem

# Generated at 2022-06-11 18:18:53.535258
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    pass

# Generated at 2022-06-11 18:19:03.344482
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    def _fake_loader(path):
        return path.replace('/', ' ')

    template_data = {
        'bare_string': 'value',
        'quoted_string': 'value',
        'variable_string': 'value',
        'none': None,
        'true': True,
        'false': False,
        'list': [1, 2, 3],
        'dict': {},
    }

    templar = Templar(loader=_fake_loader, variables=template_data, fail_on_undefined=False)

    # Test None, boolean and integer
    assert listify_lookup_plugin_terms(None, templar) == ['None']
    assert listify_lookup_plugin_terms(False, templar) == [False]

# Generated at 2022-06-11 18:19:11.928054
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # This is a basic set of tests and in no way comprehensive

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    vault_pass = 'dummypass'
    vault = VaultLib([vault_pass],'sha1')
    templar = Templar(loader=None, variables=combine_vars({'vault_pass': vault_pass}))

    # bare strings are assumed to be a single term
    assert 'foo' == listify_lookup_plugin_terms('foo', templar, None)

    # variables are assumed to refer to a single term
    assert '$foo' == listify_lookup_plugin

# Generated at 2022-06-11 18:19:19.850802
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test str variables
    assert listify_lookup_plugin_terms('foo', None, None) == ['foo']
    assert listify_lookup_plugin_terms('1', None, None) == ['1']
    assert listify_lookup_plugin_terms('foo,bar', None, None) == ['foo,bar']

    # Test str Jinja variables
    assert listify_lookup_plugin_terms('"{{ foo }}"', None, None) == ['{{ foo }}']
    assert listify_lookup_plugin_terms('"{{ foo }}{{ bar }}"', None, None) == ['{{ foo }}{{ bar }}']

    # Test Jinja variables
    assert listify_lookup_plugin_terms('{{ foo }}', None, None) == ['{{ foo }}']

# Generated at 2022-06-11 18:19:27.974682
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import AnsibleTemplar

    loader = None
    templar = AnsibleTemplar(loader=loader)

    terms = '${test_var}'
    vars = dict(test_var='value1')
    terms = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=False, fail_on_undefined=True)
    assert terms[0] == 'value1'

    terms = ['${test_var}']
    terms = listify_lookup_plugin_terms(terms, templar, loader, convert_bare=False, fail_on_undefined=True)
    assert terms[0] == 'value1'

    terms = '${test_var}'

# Generated at 2022-06-11 18:19:37.342005
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    listify_lookup_plugin_terms

    This is a test harness for listify_lookup_plugin_terms which is used to make
    sure that lookup plugins recieve a list of items
    '''

    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    context.vars = {'test_var': 'foobar'}
    context.basedir = '/'
    context.for_host = lambda host: '127.0.0.1'


# Generated at 2022-06-11 18:20:09.738757
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    import os

    ansible_module = AnsibleModule(
        argument_spec=dict(
            vars=dict(),
            var=dict(type='path'),
            files=dict(type='path'),
        )
    )

    class FakeTemplar(object):

        def __init__(self, loader=None, variables=dict(), fail_on_undefined=True):
            self._loader = loader
            self.variables = variables
            self._fail_on_undefined = fail_on_undefined


# Generated at 2022-06-11 18:20:18.503242
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    terms = [
        'value',
        ['value1', 'value2'],
        '{{ value1 }}',
        ['{{ value2 }}', '{{ value3 }}'],
    ]
    templar = DummyTemplar()
    assert listify_lookup_plugin_terms(terms[0], templar) == ['value']
    assert listify_lookup_plugin_terms(terms[1], templar) == ['value1', 'value2']
    assert listify_lookup_plugin_terms(terms[2], templar) == ['value']
    assert listify_lookup_plugin_terms(terms[3], templar) == ['value2', 'value']

# Unit test helper class

# Generated at 2022-06-11 18:20:29.136996
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    results = []
    results.append(listify_lookup_plugin_terms(['foo', '{{ bar }}'], Templar(PlayContext(variable_manager=VariableManager(loader=DataLoader()), loader=DataLoader()))))
    assert results[0] == ['foo', 'bar']
    results.append(listify_lookup_plugin_terms(['foo', {'foo': 'bar'}], Templar(PlayContext(variable_manager=VariableManager(loader=DataLoader()), loader=DataLoader()))))
    assert results[1] == ['foo', 'bar']
    results.append