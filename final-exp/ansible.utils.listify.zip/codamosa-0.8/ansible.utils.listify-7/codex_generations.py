

# Generated at 2022-06-11 18:10:41.631917
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    my_loader = object()
    my_templar = Templar(loader=my_loader)

    assert listify_lookup_plugin_terms(None, my_templar, my_loader) == [None]
    assert listify_lookup_plugin_terms('abc', my_templar, my_loader) == [u'abc']
    assert listify_lookup_plugin_terms('abc def', my_templar, my_loader) == [u'abc def']
    assert listify_lookup_plugin_terms('abc "def"', my_templar, my_loader) == [u'abc "def"']

# Generated at 2022-06-11 18:10:52.281028
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    assert listify_lookup_plugin_terms([1,2,3], Templar(), None) == [1,2,3]

    assert listify_lookup_plugin_terms("{{ myvar }}", Templar(), None) == "{{ myvar }}"

    assert listify_lookup_plugin_terms(["{{ myvar }}"], Templar(), None) == ["{{ myvar }}"]

    assert listify_lookup_plugin_terms(["/tmp/{{ myvar }}/logs"], Templar(), None) == ["/tmp/{{ myvar }}/logs"]

    assert listify_lookup_plugin_terms([1,"{{ myvar }}",3], Templar(), None) == [1,"{{ myvar }}",3]

    # listify should return a list in the same order, order should be preserved
    assert list

# Generated at 2022-06-11 18:11:02.281033
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    def get_loader_obj(template):
        class LookupModule:
            def __init__(self, basedir=None, **kwargs):
                self.basedir = basedir

        class Templar:
            loader = LookupModule()
            def template(self, template, convert_bare=False, fail_on_undefined=True):
                return template

        return Templar()

    # Return given string as list if it is a string
    assert listify_lookup_plugin_terms('foo', get_loader_obj('bar'), None) == ['foo']

    # Return given list if it is a list
    assert listify_lookup_plugin_terms(['foo'], get_loader_obj('bar'), None) == ['foo']

    # Return given list if it is a string but convert_bare is True
    assert listify_lookup

# Generated at 2022-06-11 18:11:13.159584
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    loader = DictDataLoader({
        'template': '{{var}}.txt'
    })

    templar = Templar(loader=loader)

    assert listify_lookup_plugin_terms('test.txt', templar, loader) == ['test.txt']
    assert listify_lookup_plugin_terms(['test.txt'], templar, loader) == ['test.txt']
    assert listify_lookup_plugin_terms('{{template}}', templar, loader) == ['test.txt']
    assert listify_lookup_plugin_terms(u'{{template}}', templar, loader) == ['test.txt']

# Generated at 2022-06-11 18:11:23.076824
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(
        a_var='var_value',
        a_list=[1,2,3],
        a_dict=dict(key1='val1', key2='val2'),
    ))
    variable_manager.extra_vars = dict(
        e_var='extra_var_value',
        e_list=[4,5,6],
        e_dict=dict(key1='val1', key2='val2'),
    )
    templar = Templar(loader=None, variables=variable_manager)

    assert listify_lookup

# Generated at 2022-06-11 18:11:30.161602
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    #
    # Test case 1
    #
    # do not fail if terms is iterable
    #

    def test_lookup_plugin(terms, variables=None, **kwargs):
        return "Test 1"

    assert test_lookup_plugin([]) == "Test 1"
    assert test_lookup_plugin(['foo']) == "Test 1"
    assert test_lookup_plugin(['foo:bar']) == "Test 1"

    #
    # Test case 2
    #
    # test that it converts a string to a list
    #

    def test_lookup_plugin(terms, variables=None, **kwargs):
        assert isinstance(terms, list)
        return "Test 2"

    assert test_lookup_plugin("") == "Test 2"

# Generated at 2022-06-11 18:11:40.958400
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.display import Display

    mod = AnsibleDumper()
    display = Display()
    display.verbosity = 2

    templar = Templar(basedir='/tmp', variables=ImmutableDict({}), loader=None, display=display)

    test0 = '[1,2,3]'
    assert listify_lookup_plugin_terms(test0, templar, None) == [1,2,3]
    test0 = '1'
    assert listify_lookup_plugin_terms(test0, templar, None) == ['1']

# Generated at 2022-06-11 18:11:50.944143
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    loader = None
    terms_orig = ['foo', 'bar']
    terms_templated = ['foo', 'bar']
    terms_templated_fail = ['foo', '{{ foo }}']
    templar = Templar(loader)

    assert listify_lookup_plugin_terms(terms_orig, templar, loader) == terms_templated
    assert listify_lookup_plugin_terms(terms_orig, templar, loader, fail_on_undefined=False) == terms_templated
    assert listify_lookup_plugin_terms(terms_orig, templar, loader, convert_bare=True) == terms_templated


# Generated at 2022-06-11 18:12:01.803444
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # simple string => [string]
    data = 'string'
    results = listify_lookup_plugin_terms(data, Templar(loader=DataLoader()), None)
    assert isinstance(results, list)
    assert len(results) == 1
    assert results[0] == 'string'

    # list of strings => [string]
    data = ['one', 'two']
    results = listify_lookup_plugin_terms(data, Templar(loader=DataLoader()), None)
    assert isinstance(results, list)
    assert len(results) == 2
    assert results == ['one', 'two']

    # quoted comma separated string => [string]
    data = '"red,green,blue"'
    results

# Generated at 2022-06-11 18:12:11.811783
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import ansible.module_utils.common.collections as collections
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Inputs
    called_var = collections.namedtuple('CalledVar', [])
    called_var.vars = {'var1': 'value1', 'var2': 'value2'}
    called_var.hostvars = {'host1': {'hostvar1': 'hostvalue1', 'hostvar2': 'hostvalue2'},
                           'host2': {'hostvar1': 'hostvalue1', 'hostvar2': 'hostvalue2'}}
    called_

# Generated at 2022-06-11 18:12:22.309310
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils import plugin_docs

    plugin_docs.HAS_JINJA2_NATIVE = False

    from ansible.template import Templar
    import jinja2

    class DummyVarsModule(object):
        def __init__(self, data):
            self.data = data

        def vars(self):
            return self.data

    # basic conversion of flat vars
    templar = Templar(loader=None, variables=DummyVarsModule({'a': 1, 'b': 2, 'c': 3}))

    # tests
    assert listify_lookup_plugin_terms('{{a}}', templar, loader=None) == [1]
    assert listify_lookup_plugin_terms(u'{{a}}', templar, loader=None) == [1]

# Generated at 2022-06-11 18:12:34.152844
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=AnsibleLoader(variable_manager=VariableManager()))

    assert listify_lookup_plugin_terms(
        ['{{ [ "first", "second" ] }}', '{{ "third" }}'], templar, templar._loader, convert_bare=True
    ) == ['first', 'second', 'third'], \
        'listify_lookup_plugin_terms failed to convert list of lists'


# Generated at 2022-06-11 18:12:42.290998
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping

    def test_template(*args, **kwargs):
        if len(args) > 1:
            return args[0]
        else:
            return args

    templar = Templar(loader=None, shared_loader_obj=None, variables={'x': "hello"})
    templar._fail_on_undefined = False
    templar._templar = test_template

    assert listify_lookup_plugin_terms(["foo", "bar", "baz"], templar, None) == ["foo", "bar", "baz"]

# Generated at 2022-06-11 18:12:46.719033
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import ansible.vars

    class TestVarsModule(object):

        def get_vars(self, loader, path, entities, cache=True):
            return {'a': 'b'}

    loader = DataLoader()
    templar = Templar(loader=loader, variables={})
    vars_mgr = ansible.vars.VarsModule()

    terms = '{{a}}'
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False) == ['b']

    terms = '[1, 2]'

# Generated at 2022-06-11 18:12:54.820327
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.template import Templar

    def return_raw_template(data, fail_on_undefined=False, convert_bare=False):
        return data

    def return_template(data, fail_on_undefined=False):
        return data

    templar = Templar(loader=None, variables={})
    templar.template = return_raw_template
    templar.template_ds = return_template

    ret = listify_lookup_plugin_terms('{{ foo }} {{ bar }}', templar, loader=None)
    assert ret == ['{{ foo }} {{ bar }}']

    ret = listify_lookup_plugin_terms(['{{ foo }}', '{{ bar }}'], templar, loader=None)
    assert ret == ['{{ foo }}', '{{ bar }}']

# Generated at 2022-06-11 18:13:04.715845
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms_data = {
        'foo': 'bar',
        'baz': 'qux',
        'nested': {'foonest': 'barnest'}
    }

    loader = DummyLoader()
    templar = Templar(loader=loader, variables=terms_data)

    # Test string
    result = listify_lookup_plugin_terms('foo', templar, loader)
    assert len(result) == 1
    assert result[0] == terms_data['foo']

    # Test multiple strings
    result = listify_lookup_plugin_terms('foo bar baz', templar, loader)
    assert len(result) == 3
    assert result[0] == terms_data['foo']
    assert result[1] == 'bar'
    assert result

# Generated at 2022-06-11 18:13:15.553357
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    vault_secret_path = 'test/units/plugins/vars/vault.yml'
    vault_password_path = 'test/units/plugins/vars/vault_pass.txt'

    vl = VaultLib(password_files=[vault_password_path])


# Generated at 2022-06-11 18:13:24.855973
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import os

    loader = DataLoader()
    vault_pass = os.environ.get('VAULT_PASS')
    v = VaultLib(password_files=[vault_pass]) if vault_pass else None
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'one': '1', 'two': ['2', 'two'], 'three': '3', 'four': ['4', 'four'], 'empty': ''}
    variable_manager.set_vault_secrets(v)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test tem

# Generated at 2022-06-11 18:13:36.867770
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    terms = [u'foo', u'{{ foo }}', [u'{{ foo }}', u'bar']]
    vars = {'foo': u'bar'}

    # These should all be correctly converted to a list
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=False, convert_bare=False) == [u'foo', u'bar', [u'{{ foo }}', u'bar']]

# Generated at 2022-06-11 18:13:45.749560
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.template import Templar

    loader = DictDataLoader({
        "test_var": "{{ test_dict }}",
        "test_dict": {'key1': 'foo', 'key2': 'bar'}
    })
    templar = Templar(loader=loader, variables=dict(test_dict=dict(key1="foo")), unfrackpath=mock_unfrackpath_noop)

    assert listify_lookup_plugin_terms("{{ test_var }}", templar, loader) == [dict(key1='foo', key2='bar')]

# Generated at 2022-06-11 18:13:56.583472
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import unsafe_eval

    from ansible.playbook.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleUndefinedVariable

    basedir = '/tmp'
    vars = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=vars)

    # Check for error when no terms parameter provided
    try:
        listify_lookup_plugin_terms(None, templar, loader)
    except Exception as e:
        assert isinstance(e, TypeError)

    # Check for error when terms parameters is not a string or iterable

# Generated at 2022-06-11 18:14:06.010856
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar

    class DummyVarsModule(object):
        def __init__(self):
            self.a_var = 42
            self.a_list = [1, 2, 3]
            self.a_string = 'string'
            self.a_dict = {'key': 'value'}

    dummy_vars = DummyVarsModule()

    templar = Templar(loader=None, variables=dummy_vars)

    # Test single term
    assert listify_lookup_plugin_terms('{{a_var}}', templar, None) == [42]
    assert listify_lookup_plugin_terms('{{a_list}}', templar, None) == [[1, 2, 3]]
   

# Generated at 2022-06-11 18:14:18.027798
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    class DummyLoader(object):
        pass
    class DummyTemplar(object):
        def __init__(self, templated_data):
            self.templated_data = templated_data
        def template(self, data, fail_on_undefined=True, convert_bare=False):
            return self.templated_data

    # Testing:
    # listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False):
    # with different values of terms

    # Test 1: terms is string
    terms = '{{string}}'
    templar = DummyTemplar(['x','y','z'])
    loader = DummyLoader()

# Generated at 2022-06-11 18:14:26.895804
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''
    listify_lookup_plugin_terms tests
    '''
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import lookup_loader

    # Input data

# Generated at 2022-06-11 18:14:35.869730
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    terms = dict(
        one = dict(
            a = dict(
                one = '1',
                two = '2',
            ),
            b = dict(
                one = '1',
                two = '2',
            ),
        ),
        two = dict(
            a = dict(
                one = '1',
                two = '2',
            ),
            b = dict(
                one = '1',
                two = '2',
            ),
        ),
    )

    assert listify_lookup_plugin_terms(terms, Templar(loader=None)) == terms
    assert listify_lookup_plugin_terms('1', Templar(loader=None)) == ['1']
    assert listify_lookup_plugin_terms('1\n2', Templar(loader=None))

# Generated at 2022-06-11 18:14:43.817751
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnsafeVaultSecret

    test_vars = {
        'list': ['one', 'two', 'three'],
        'var': 'ok',
        'password': UnsafeVaultSecret('list.yml', 'ansible', 'vaultpassword'),
        'vault_password': 'vaultpassword'
    }


# Generated at 2022-06-11 18:14:54.661760
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    terms_string = "{{var1}}"
    terms_string_with_vault = VaultLib().encrypt("plaintext")
    terms_list_with_vault = [VaultLib().encrypt("plaintext")]
    terms_dict_with_vault = {'vault_key': VaultLib().encrypt("plaintext")}
    terms_nonstring_list = [1, 2, 3]
    terms_nonstring_dict = {'a': 1, 'b': 2}

    templar = Templar(loader=None, variables=VariableManager())


# Generated at 2022-06-11 18:15:06.198836
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    val = "{{ [['a','b','c'], 'd', 'e' ] }}"
    loader = DummyLoader()
    templar = Templar(loader=loader, variables={})
    terms = listify_lookup_plugin_terms(val, templar, loader, fail_on_undefined=False, convert_bare=False)
    assert terms == [['a', 'b', 'c'], 'd', 'e']

    val = ['{{ a }}', '{{ b }}' ]
    templar = Templar(loader=loader, variables={'a':1, 'b':2})
    terms = listify_lookup_plugin_terms(val, templar, loader)
    assert terms == [1, 2]

    val = ['a', 'b']
    templ

# Generated at 2022-06-11 18:15:16.258503
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Just checking that we don't crash, as the function is pretty thin
    from ansible import constants as C
    from ansible.template import Templar

    loader = DummyLoader()
    templar = Templar(loader=loader, variables={'foo': 'bar'})

    assert listify_lookup_plugin_terms('hello', templar, loader) == ['hello']
    assert listify_lookup_plugin_terms(['hello', 'world'], templar, loader) == ['hello', 'world']
    assert listify_lookup_plugin_terms([1, 2, 3], templar, loader) == [1, 2, 3]

    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['bar', 'bar']
    assert listify_lookup_plugin_terms

# Generated at 2022-06-11 18:15:23.651290
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars import AnsibleVars
    from ansible.vars.manager import VariableManager

    # Ensure the function returns a list from a string entry
    terms = 'string'
    templar = Templar(loader=None, variables=AnsibleVars(variable_manager=VariableManager()))
    results = listify_lookup_plugin_terms(terms, templar, None)
    assert isinstance(results, list) and len(results) == 1 and results[0] == terms

    # Ensure the function returns a list from a int entry
    terms = 123
    results = listify_lookup_plugin_terms(terms, templar, None)

# Generated at 2022-06-11 18:15:34.849658
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms = 'foo,bar,{{ baz }}'
    variables = {'baz': 'qux'}
    templar = Templar(loader=None, variables=variables)

    results = listify_lookup_plugin_terms(terms, templar, loader=None)

    assert results == ['foo', 'bar', 'qux']


# Generated at 2022-06-11 18:15:46.013504
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import sys

    from ansible.template import Templar

    from ansible.errors import AnsibleUndefinedVariable

    from ansible.parsing.vault import VaultLib

    from ansible.parsing.dataloader import DataLoader

    from ansible.inventory.manager import InventoryManager

    terms1 = '{{ foo }}'
    terms2 = [ 'foo', 'bar' ]
    vars = dict(foo='foo', bar='bar')

    # init vault lib
    vault_secrets = dict()
    vault_password_files = [ ]
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    templar = Templar(loader=loader, vault_secrets=vault_secrets, vault_password_files=vault_password_files, inventory=inventory)

    # Listify lookup

# Generated at 2022-06-11 18:15:58.133414
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
        from ansible.template import Templar
        from ansible.parsing.yaml.objects import AnsibleUnicode
        class FakeVarsModule(object):
            def __init__(self):
                self.vars = dict(foo='bar', baz='qux')
            def __getattr__(self, what):
                return self.vars[what]
        templar = Templar(loader=None, variables=FakeVarsModule())
        assert listify_lookup_plugin_terms(terms='foo', templar=templar, loader=None) == ['foo']
        assert listify_lookup_plugin_terms(terms=['foo'], templar=templar, loader=None) == ['foo']

# Generated at 2022-06-11 18:16:09.531240
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # Test 1: Pass in a single string
    terms = '{{ items }}'
    templar = Templar({}, {}, {}, None, None)
    results = listify_lookup_plugin_terms(terms, templar, None)
    assert results == ['{{ items }}']

    # Test 2: Pass in a list of 1 item.
    terms = ['{{ items }}']
    templar = Templar({}, {}, {}, None, None)
    results = listify_lookup_plugin_terms(terms, templar, None)
    assert results == ['{{ items }}']

    # Test 3: Pass in a list of multiple items
    terms = ['{{ items }}', '{{ other_item }}']
    templar = Templar({}, {}, {}, None, None)

# Generated at 2022-06-11 18:16:16.693968
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    global templar
    names = ['Alice', 'Bob', 'Carol', 'Dave', 'Eve']
    templar = NamesTemplar(names)

    # Test case 1: mixed data types
    terms = listify_lookup_plugin_terms(['{{ item }}', 42, '{{ item + 1 }}'], templar, False)
    assert terms == ['Alice', 42, 'Bob', 'Alice', 42, 'Bob', 'Carol', 42, 'Dave', 'Carol', 42, 'Dave', 'Eve', 42]

    # Test case 2: list of lists
    terms = listify_lookup_plugin_terms([['Alice', 42, 'Bob'], ['Carol', 42, 'Dave'], ['Eve', 42]], templar, False)

# Generated at 2022-06-11 18:16:27.402729
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(os.path.join(os.path.dirname(__file__), 'test_listify_lookup_plugin_terms.yml')))

    templar = Templar(loader=loader, variables=variable_manager)

    # Tests for listify_lookup_plugin_terms with no undefined variables

    # Test when the input_data is an empty string ""
    assert listify_lookup_plugin_terms("", templar, loader) == ['']

    # Test when the input_data is a simple string with no variables


# Generated at 2022-06-11 18:16:37.370122
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    variable_manager.get_vars({'system_type': 'test'})
    loader = DataLoader()

    templar = Templar(loader=loader, variables=variable_manager)

    # templar.template will return a list if the terms are a list.
    a_list = ['foo', 'bar']
    assert a_list == listify_lookup_plugin_terms(a_list, templar, loader)

    # templar will return a string if the terms are a string.
    a_string = 'foo'

# Generated at 2022-06-11 18:16:46.604435
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.templating import Templar

    class VarManager(object):
        def __init__(self):
            pass

        def get_vars(self):
            return dict(a=1)

    loader = None
    variabes = VarManager()
    templar = Templar(loader=loader, variables=variabes)

    v1 = listify_lookup_plugin_terms("foo", templar, loader)
    v2 = listify_lookup_plugin_terms("foo,bar", templar, loader)
    v3 = listify_lookup_plugin_terms(["foo", "bar"], templar, loader)
    v4 = listify_lookup_plugin_terms([1, 2], templar, loader)

# Generated at 2022-06-11 18:16:55.272967
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible import context
    import pytest

    template_val = { "a": "{{ d.e.f }}", "b": "{{ c }}" }
    jinja_variables = { "c": "bar", "d": { "e": { "f": "baz" } } }

    templar = Templar(loader=None, variables=jinja_variables)
    result = listify_lookup_plugin_terms(template_val, templar, None)
    assert isinstance(result, list) and len(result) == 2

    with pytest.raises(Exception):
        listify_lookup_plugin_terms(template_val, templar, None, fail_on_undefined=True)


# Generated at 2022-06-11 18:17:06.468483
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    #
    # Arbitrary import.  It's ok if we use this here, but not in the actual
    # function, as the unit test doesn't do a full initialization.
    #
    from ansible.template import Templar

    terms = "{{ foo }}{{ bar }}"
    templar = Templar(None, None)
    loader = None
    fail_on_undefined = True
    convert_bare = False

    expected_result = ["{{ foo }}{{ bar }}"]
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined, convert_bare) == expected_result

    terms = ['{{ foo }}', None, '{{ bar }}', 'baz']
    expected_result = [['{{ foo }}', None, '{{ bar }}', 'baz']]
    assert listify

# Generated at 2022-06-11 18:17:24.610353
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class FakeVarsModule():
        def __getattr__(self, name):
            return name
    # Lookup plugins don't have access to inventory, so there is no real host object.
    # Need to create a fake host.
    class FakeHost():
        def __init__(self):
            self.vars = FakeVarsModule()

    # Lookup plugins don't have access to inventory, so there is no real host object.
    # Need to create a fake host.
    host = FakeHost()

    # Lookup plugins are called outside of the playbook context, so there is no real loader.
    # Need to create a fake loader.  Loader needs at least one attribute to pass the
    # isinstance check in listify_lookup_plugin_terms()

# Generated at 2022-06-11 18:17:32.118870
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
    import ansible.template
    import ansible.vars

    # setup mock objects

    info = {
        'count': 0
    }

    def mock_template(s, *args, **kwargs):
        if s == 'count':
            return info['count']
        return s

    def mock_fail_on_missing(*args, **kwargs):
        return False

    templar = ansible.template.Template(loader=None, variables=ansible.vars.VariableManager())
    templar.template = mock_template
    templar.fail_on_undefined = mock_fail_on_missing

    # test with string

    terms = '{{ count }}'
    info['count'] = 1

# Generated at 2022-06-11 18:17:44.508996
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader, variables={})

    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']
    assert listify_lookup_plugin_terms('["foo", "bar"]', templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms('["foo", "bar", baz]', templar, loader) == ['foo', 'bar', 'baz']

# Generated at 2022-06-11 18:17:54.193545
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Test imports
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Set up Test Templar
    loader = DataLoader()
    templar = Templar(loader=loader)

    # Test a string input
    result = listify_lookup_plugin_terms('foo', templar, loader)
    assert isinstance(result, list)
    assert result == ['foo']

    # Test an empty list input
    result = listify_lookup_plugin_terms([], templar, loader)
    assert isinstance(result, list)
    assert result == []

    # Test a list input
    result = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader)
    assert isinstance(result, list)

# Generated at 2022-06-11 18:18:04.789907
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils import plugin_docs
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'list_var': ['a', 'b', 'c']}
    variable_manager.set_nonpersistent_facts({'dict_var': {'key': 'value'}})

    loader = None
    context = PlayContext(variable_manager=variable_manager)
    templar = Templar(loader=loader, variables=variable_manager)

    # test string
    terms = '{{ list_var }}'
    result = listify_lookup_plugin_terms(terms=terms, templar=templar, loader=loader)

# Generated at 2022-06-11 18:18:14.787953
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars

    class TestVarsModule:
        def __init__(self, test_vars):
            self.vars = combine_vars(test_vars, {})

    class TestVaultSecret:
        def __init__(self, password):
            self.password = password

    class TestLoader:
        def __init__(self, base_path):
            self._basedir = base_path
            self._cached_result = {('', 'vars'): TestVarsModule({})}

        def get_basedir(self, path):
            return self._basedir

        def path_dwim(self, basedir, given):
            return given

       

# Generated at 2022-06-11 18:18:25.282831
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template.safe_eval import safe_eval

    terms = ['{{ [1, 2, 3] + [4, 5, 6] }}', 7, '{{ [8, 9, 10] }}', ['{{ [11, 12, 13] + [14, 15, 16] }}', '17']]
    expected_terms = [[1, 2, 3, 4, 5, 6], 7, [8, 9, 10], [11, 12, 13, 14, 15, 16], '17']
    expected_json_terms = '[[1, 2, 3, 4, 5, 6], 7, [8, 9, 10], [11, 12, 13, 14, 15, 16], "17"]'

    assert expected_terms == listify_lookup_plugin_terms(terms, safe_eval)
    assert expected_json_terms == listify

# Generated at 2022-06-11 18:18:35.385272
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Collect args and kwargs needed for function
    templar = None
    loader = None
    fail_on_undefined = True
    convert_bare = False

    # Test cases
    listify_lookup_plugin_terms_test_cases = (
        (
            [["alpha", "beta"]],
            [['alpha', 'beta']]
        ),
        (
            ["alpha", "beta"],
            [['alpha', 'beta']]
        ),
        (
            [['alpha', 'beta'], 'gamma'],
            [['alpha', 'beta', 'gamma']]
        ),
    )


# Generated at 2022-06-11 18:18:46.045835
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    terms_string = 'foo'
    terms_list = ['foo', 'bar']
    terms_dict = dict(foo='bar', bar='baz')

    assert(listify_lookup_plugin_terms(terms_string, Templar(loader=DataLoader()), DataLoader()) == ['foo'])
    assert(listify_lookup_plugin_terms(terms_list, Templar(loader=DataLoader()), DataLoader()) == ['foo', 'bar'])
    assert(listify_lookup_plugin_terms(terms_dict, Templar(loader=DataLoader()), DataLoader()) == [{'foo': 'bar', 'bar': 'baz'}])

# Generated at 2022-06-11 18:18:53.285323
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variables = VariableManager()
    templar = Templar(loader=loader, variables=variables)

    # Test a single string
    assert listify_lookup_plugin_terms('foobar', templar, loader) == ['foobar']

    # Test a list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']
    assert listify_lookup_plugin_terms(['bar', 'baz'], templar, loader) == ['bar', 'baz']

    # Test a list of lists

# Generated at 2022-06-11 18:19:11.203269
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = dict(
        my_name='Steve',
        my_compound_name=['Bob', 'Mary', 'John', 'Steve']
    )
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms(['{{ my_name }}', 'Jim', 'Andy'], templar, loader, fail_on_undefined=True,
                                       convert_bare=False) == ['Steve', 'Jim', 'Andy']

    assert listify_lookup_plugin_

# Generated at 2022-06-11 18:19:19.458815
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))

# Generated at 2022-06-11 18:19:25.184119
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils import template as template

    l = template.listify_lookup_plugin_terms

    assert l('foo') == ['foo']
    assert l(['foo','bar']) == ['foo','bar']
    assert l('foo,bar') == ['foo','bar']
    assert l(['foo','bar','baz']) == ['foo','bar','baz']
    assert l('foo,bar,baz') == ['foo','bar','baz']

# Generated at 2022-06-11 18:19:32.016225
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    vm = VariableManager(loader=None)
    vl = VaultLib(password_path='/tmp/.vault_pass', contexts=['dev'])
    context = PlayContext()
    templar = Templar(loader=None, variable_manager=vm, vault_secrets=vl, context=context)
    result = listify_lookup_plugin_terms('http://www.example.com', templar, None, convert_bare=False)
    assert isinstance(result, Sequence)
    assert len(result) == 1

# Generated at 2022-06-11 18:19:42.692980
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    def my_failer(msg, **kwargs):
        # Capture all failures for later checking
        self.failures.append(msg)
        raise AnsibleError(msg)

    # Create a Templar
    templar = Templar(loader=None, variables={})

    self.failures = []
    templar.fail_on_undefined = True
    templar.set_available_variables({'item': 'bogus'})
    templar._fail_function = my_failer

    # Test passing in a string
    test = '{{ item }}'
    result = listify_lookup_plugin_terms(test, templar, loader=None)
    expected = ['bogus']
    assert result == expected

# Generated at 2022-06-11 18:19:52.370670
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common.collections import listify_lookup_plugin_terms
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    vault_pass = 'secret'

# Generated at 2022-06-11 18:20:00.929919
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # FIXME - this test is not complete

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={'foo': 'foo', 'bar': 'bar'})

    terms_list = listify_lookup_plugin_terms('{{foo}}', templar, loader=None)
    assert terms_list == ['foo']

    terms_list = listify_lookup_plugin_terms(['foo', 'bar'], templar, loader=None)
    assert terms_list == ['foo', 'bar']

    terms_list = listify_lookup_plugin_terms(['foo', 'bar', '{{foo}}'], templar, loader=None)

# Generated at 2022-06-11 18:20:10.527243
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts({'z': 'Z'})

    terms = '{{a}} {{b}} {{c}} {{z}}'
    data = {
        'a': 'A',
        'b': 'B',
        'c': 'C'
    }

    templar = Templar(loader=None, shared_loader_obj=None, variables=data)
    result = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True)
    assert result == [u'A B C Z']


# Generated at 2022-06-11 18:20:17.280162
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.template import JinjaEnvironment
    from ansible.vars import VariableManager

    templar = Templar(loader=None, variables=VariableManager())
    terms = [ '{{ foo }}', '{{ bar }}' ]
    templar.set_available_variables(dict(foo="test1", bar="test2"))
    assert listify_lookup_plugin_terms(terms, templar, loader=None) == ['test1', 'test2' ]

# Generated at 2022-06-11 18:20:27.845193
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.vars import VariableManager
    from ansible.template import Templar

    vars_mgr = VariableManager()
    vars_mgr.set_inventory(Inventory(loader=None, variable_manager=vars_mgr, host_list=['hostname']))
    templar = Templar(loader=None, variables=vars_mgr)

    assert listify_lookup_plugin_terms('1', templar, loader=None) == ['1'], "basic string input"
    assert listify_lookup_plugin_terms([1], templar, loader=None) == [1], "basic list input"
    assert listify_lookup_plugin_terms([1, 2, [[3]]], templar, loader=None) == [1, 2, [[3]]], "deep list input"
   