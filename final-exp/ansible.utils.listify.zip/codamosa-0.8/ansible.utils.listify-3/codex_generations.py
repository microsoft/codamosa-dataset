

# Generated at 2022-06-11 18:10:37.635303
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml import DataLoader

    terms = '{{ foo }}'
    templar = Templar(loader=None, variables={'foo': 'bar'})
    assert listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False) == ['bar']

    terms = ['{{ foo }}', '{{ bar }}']
    templar = Templar(loader=None, variables={'foo': 'bar', 'bar': 'foo'})
    assert listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False) == ['bar', 'foo']

    terms = '{{ foo }}'

# Generated at 2022-06-11 18:10:45.482724
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    from units.mock.loader import DictDataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)

    templar = Templar(loader=loader, variables=variable_manager)

    # Test 1: convert single string scalar to list
    assert listify_lookup_plugin_terms('foo', templar, loader) == ['foo']

    # Test 2: convert list of strings to list
    assert listify_lookup_plugin_terms(['foo', 'bar'], templar, loader) == ['foo', 'bar']

    # Test 3: convert single dict to list of strings
    assert listify

# Generated at 2022-06-11 18:10:55.066278
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVars


# Generated at 2022-06-11 18:11:03.873277
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.templar import MockTemplar

    loader = DictDataLoader({})
    loader._collection_loaders = { 'mycollection': DictDataLoader({}) }
    templar = MockTemplar(loader=loader, variables={})
    templar._fail_on_undefined = False
    templar._available_variables = {}

    terms = listify_lookup_plugin_terms('foo', templar=templar, loader=loader, fail_on_undefined=False)
    assert terms == ['foo']


# Generated at 2022-06-11 18:11:14.362129
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class FakeTemplar(object):
        def __init__(self):
            self._converted_data = []

        def template(self, terms, convert_bare=False, fail_on_undefined=False):
            self._converted_data.append(terms)
            return terms

    # simple string to string
    templar = FakeTemplar()
    ret = listify_lookup_plugin_terms("test", templar)
    assert ret == ["test"]

    # string to list
    templar = FakeTemplar()
    ret = listify_lookup_plugin_terms("test", templar)
    assert ret == ["test"]

    # simple list to list
    templar = FakeTemplar()
    ret

# Generated at 2022-06-11 18:11:25.137601
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    terms_1 = '{{ hostvars[inventory_hostname].test }}'
    terms_2 = ['test1', 'test2', 'test3']
    terms_3 = 'test1'
    terms_4 = ['{{ hostvars[inventory_hostname].test1 }}', 'test2', 'test3']
    terms_5 = ['test1', 'test2', '{{ hostvars[inventory_hostname].test3 }}']
    terms_6 = []
    terms_7 = '{{ hostvars[inventory_hostname].test_embedded.list }}'
    terms_8 = '{{ hostvars[inventory_hostname].test_embedded.string }}'
    terms_9 = 'test_embedded.list'
    terms_10 = 'test_embedded.string'

    # FIXME: need to mock

# Generated at 2022-06-11 18:11:32.368236
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    assert listify_lookup_plugin_terms(terms="{{ test_var }}", templar=templar, loader=loader) == ['{{ test_var }}']
    assert listify_lookup_plugin_terms(terms='{{ test_var }}', templar=templar, loader=loader) == ['{{ test_var }}']

    variable_manager.set_nonpersistent_facts({"test_var": "foo"})

# Generated at 2022-06-11 18:11:42.634829
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None, variables=dict(a=1, b=2, c=3))

    assert listify_lookup_plugin_terms([1, 2, 3], templar) == [1, 2, 3]
    assert listify_lookup_plugin_terms("{{foo}}", templar) == [None]
    assert listify_lookup_plugin_terms("{{a}}", templar) == [1]
    assert listify_lookup_plugin_terms("{{a}} {{b}}", templar) == [1, 2]
    assert listify_lookup_plugin_terms("{{a}},{{b}},{{c}}", templar) == [1, 2, 3]

# Generated at 2022-06-11 18:11:51.977710
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    def assert_terms(terms, expected):
        # We're doing this to mimic a normal ansible Run, so we can get a proper templar
        options = namedtuple('Options', ['connection','module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
        options.connection = 'local'
        options.module_path = None
        options.forks=100
        options.become=None
       

# Generated at 2022-06-11 18:12:02.649659
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    terms_list = listify_lookup_plugin_terms(terms="{{ foo }} {{ bar.baz }}", templar=Templar(), loader=None, fail_on_undefined=True, convert_bare=False)
    assert terms_list == ['{{ foo }}', '{{ bar.baz }}']

    terms_list = listify_lookup_plugin_terms(terms=['{{ foo }}', '{{ bar.baz }}'], templar=Templar(), loader=None, fail_on_undefined=True, convert_bare=False)
    assert terms_list == ['{{ foo }}', '{{ bar.baz }}']


# Generated at 2022-06-11 18:12:13.077140
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class DummyVars(object):
        def __init__(self, foo=42):
            self.foo = foo

    # Test non-string type
    x = []
    t = Templar(loader=None, variables=DummyVars())
    y = listify_lookup_plugin_terms(terms=x, templar=t)
    assert y == [], "listify_lookup_plugin_terms() should return list"

    # Test non-string type
    x = 42
    t = Templar(loader=None, variables=DummyVars())
    y = listify_lookup_plugin_terms(terms=x, templar=t)
    assert y == [42], "listify_lookup_plugin_terms() should return 42 as list"

    # Test simple string

# Generated at 2022-06-11 18:12:22.010870
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    assert listify_lookup_plugin_terms(42, templar, None) == [42]

    assert listify_lookup_plugin_terms([42], templar, None) == [42]
    assert listify_lookup_plugin_terms([42], templar, None) != 42

    assert listify_lookup_plugin_terms(['42'], templar, None) == ['42']
    assert listify_lookup_plugin_terms(['42'], templar, None) != 42

    assert listify_lookup_plugin_terms([42,['{{test}}']], templar, None, convert_bare=True) == [42,[42]]

# Generated at 2022-06-11 18:12:33.822657
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import ansible.template
    class FakeVarManager:
        def __init__(self, loader):
            self._loader = loader
        def get_vars(self, play=None, host=None, task=None, include_hostvars=True):
            return {}
        def update_vars(self, vars):
            pass
        def push_vars(self, vars):
            pass
        def pop_vars(self):
            pass
    class FakePlay:
        def __init__(self):
            self.vars = FakeVarManager(None)
    class FakeTask:
        def __init__(self):
            self.play = FakePlay()
        def get_loader(self):
            return None

# Generated at 2022-06-11 18:12:42.099436
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    import jinja2
    from ansible.utils.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib

    class TestVarsModule(object):

        def get_vars(self, loader, path, entities):
            return {}

    vault_pass = 'secret'
    vault = VaultLib(vault_pass)
    variable_manager = VariableManager()
    variable_manager._vars_cache = {'vars': {}}
    variable_manager.set_vault_secrets([vault])
    variable_manager.extra_vars = {}
    variable_manager.options_vars = []

# Generated at 2022-06-11 18:12:52.099423
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.template import Templar

    class FakeVarsModule:
        def __init__(self, vars):
            self.vars = vars
        def get_vars(self, loader, play, host, task, include_deps):
            return self.vars
        def get_host_vars(self, host, include_deps):
            return self.get_vars(loader, None, host, None, include_deps)
        def get_hostgroup_vars(self, group, include_deps):
            return self.get_vars(loader, None, group, None, include_deps)


# Generated at 2022-06-11 18:13:03.395112
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    class TestVarManager(object):
        def __init__(self, variables):
            self.variables = variables

        def get_vars(self):
            return self.variables

    # Dummy template class
    class TestTemplate(Templar):
        def __init__(self, loader, variables=dict()):
            self.loader = None
            self.variable_manager = TestVarManager(variables)

        def get_loader(self, inc_loader=False):
            return self.loader

        def template(self, data, preserve_trailing_newlines=True, convert_bare=False, fail_on_undefined=False, overrides=None):
            return data

    templar = TestTemplate(None)

    # Create test data

# Generated at 2022-06-11 18:13:14.030616
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    '''Test ansible.utils.lookup_plugins.listify_lookup_plugin_terms'''

    from ansible.utils.lookup_plugins import listify_lookup_plugin_terms
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    loader = DictDataLoader({})
    vault_secrets = []
    t = Templar(loader=loader, vault_secrets=vault_secrets)

    # test bare value
    assert listify_lookup_plugin_terms(['foo', 'bar'], t, loader) == ['foo', 'bar']

    # test simple jinja2 template
    assert listify_lookup_plugin_terms(['{{foo}}', '{{bar}}'], t, loader) == ['{{foo}}', '{{bar}}']

    #

# Generated at 2022-06-11 18:13:23.889451
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))

    assert listify_lookup_plugin_terms(1, templar, None) == [1]
    assert listify_lookup_plugin_terms(['a'], templar, None) == ['a']
    assert listify_lookup_plugin_terms('a', templar, None) == ['a']
    assert listify_lookup_plugin_terms('a,b', templar, None) == ['a,b']
    assert listify_lookup_plugin_terms('a, b', templar, None) == ['a, b']

# Generated at 2022-06-11 18:13:35.942026
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    # terms is string
    terms = '{{ test_string }}'
    templar = Templar(loader=None, variables={'test_string': '12345'})
    assert(listify_lookup_plugin_terms(terms, templar, None) == ['12345'])

    # terms is string with comma
    terms = '{{ test_string }}'
    templar = Templar(loader=None, variables={'test_string': '12345,67890'})
    assert(listify_lookup_plugin_terms(terms, templar, None) == ['12345,67890'])

    # terms is list
    terms = ['{{ test_string }}']
    templar = Templar(loader=None, variables={'test_string': '12345'})

# Generated at 2022-06-11 18:13:45.003460
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    loader = 'foo'
    passwords = {}
    variable_manager.extra_vars = {'foo': 'one', 'bar': 'two'}
    variable_manager.vault_password = None
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager,
                      fail_on_undefined=True)

    # test string

# Generated at 2022-06-11 18:13:56.295559
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # class to test if function is called or not
    class LookupModule(object):
        def __init__(self, terms, variables=None, **kwargs):
            pass

        def run(self, **kwargs):
            return self._terms

    class LookupModuleFail(object):
        def __init__(self, terms, variables=None, **kwargs):
            pass

        def run(self, **kwargs):
            raise RuntimeError("Fail")

    # simple test
    templar = Templar(loader=None, variables={})
    assert listify_lookup_plugin_terms("Test", templar, loader=None) == ["Test"]
    # test with variables
    templar

# Generated at 2022-06-11 18:14:05.810120
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    loader = DummyLoader()
    templar = Templar(loader=loader, variables={'a': 'one', 'b': 'two'})

    def _test(terms, expected, templar=templar, loader=loader,
              fail_on_undefined=True, convert_bare=False):

        results = listify_lookup_plugin_terms(terms, templar, loader,
                                              fail_on_undefined=fail_on_undefined, convert_bare=convert_bare)

        assert results == expected

    assert listify_lookup_plugin_terms(None, templar, loader) == []

    _test('foo', ['foo'])

# Generated at 2022-06-11 18:14:16.277878
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils._text import to_text

    # make sure the function returns a list if given a string
    assert isinstance(listify_lookup_plugin_terms('hello', None, None, fail_on_undefined=True), list)

    # make sure the function returns a list if given a list
    assert isinstance(listify_lookup_plugin_terms(['hello', 'world'], None, None, fail_on_undefined=True), list)

    # make sure the function converts data to text
    assert isinstance(listify_lookup_plugin_terms(u'hello', None, None, fail_on_undefined=True)[0], string_types)

# Generated at 2022-06-11 18:14:24.404797
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY2
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    if PY2:
        from ansible.template import DictLookup
        templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=InventoryManager(loader=None)))
        templar.environment.globals['lookup'] = DictLookup()

        assert listify_lookup_plugin_terms('one', templar, loader=None) == ['one']

# Generated at 2022-06-11 18:14:34.453961
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    class FakeVaultSecret(object):
        def __init__(self, value):
            self.value = value

    class FakeVaultLookupPlugin(object):
        def __init__(self, vault_secrets):
            self.vault_secrets = vault_secrets

        def get_secret(self, secret_path):
            return self.vault_secrets[secret_path]

    # Normal test cases
    templar = Templar(loader=None, variables={'a': '1', 'b': '2'})

# Generated at 2022-06-11 18:14:42.763062
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Case 1: listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False)
    # Inputs:  terms: string value of 'key1 key2'
    #          templar: object
    #          loader: object
    # Outputs: list of string ['key1', 'key2']
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class MyTemplar:
        # The template function
        def template(self, terms, fail_on_undefined=True, convert_bare=False):
            return terms

    input_terms = AnsibleUnicode('key1 key2')

    # If (terms is a string): Return terms.split()
    # Else: Return terms

# Generated at 2022-06-11 18:14:54.017214
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    class MockLoader:
        def load(self, name, templar, **kwargs):
            return [ name.strip() ]

    v = VaultLib(password='Password')
    vm = VariableManager()
    vm.set_inventory(InventoryManager(loader=MockLoader()))

    template = Templar(loader=MockLoader(), variables=vm)

    assert listify_lookup_plugin_terms(123, template, MockLoader()) == listify_lookup_plugin_terms('123', template, MockLoader())
    assert listify_lookup_plugin_terms('foo', template, MockLoader()) == listify_lookup_plugin_terms

# Generated at 2022-06-11 18:15:01.072445
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    def assert_result(terms, expected):

        actual = listify_lookup_plugin_terms(terms, Templar(loader=None), None)

        assert actual == expected
        assert isinstance(actual, list)

    # assert string conversion
    assert_result('a', ['a'])

    # assert no conversion
    l = [1]
    assert_result(l, l)

# Generated at 2022-06-11 18:15:08.156931
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    v = VariableManager()
    v.set_variable("foo", "bar")
    t = Templar(loader=None, variables=v)
    assert listify_lookup_plugin_terms("{{foo}}", t, None) == ["bar"]
    assert listify_lookup_plugin_terms("{{foo}}", t, None, convert_bare=True) == ["bar"]
    assert listify_lookup_plugin_terms("{{foo}}", t, None, convert_bare=True) != ["{{foo}}"]
    assert listify_lookup_plugin_terms("{{foo}}", t, None) != ["{{foo}}"]


# Generated at 2022-06-11 18:15:17.317426
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 18:15:32.002033
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 'value'}
    loader = None
    inventory = InventoryManager(loader=loader, sources="localhost,")
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)


# Generated at 2022-06-11 18:15:44.021437
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    templar = Templar(loader=None)

    terms = "hello world"
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['hello world']

    terms = "hello to: {{ 'my test world' if True else 'oops' }}"
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['hello to: my test world']

    terms = ['hello', 'to: {{ "my test world" if False else "oops" }}']
    result = listify_lookup_plugin_terms(terms, templar, None)
    assert result == ['hello', 'to: oops']


# Generated at 2022-06-11 18:15:55.985972
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    def get_loader(dict):
        class TestVarsModule(object):
            def get_vars(self, loader, path, entities):
                return dict
        mock_loader = TestVarsModule()
        return mock_loader

    from ansible.template.safe_eval import safe_eval

    mock_loader = get_loader({'var':'success'})

    mock_templar = safe_eval.AnsibleTemplar(loader=mock_loader)

    assert listify_lookup_plugin_terms('{{var}}', mock_templar, mock_loader, convert_bare=True) == ['success']
    assert listify_lookup_plugin_terms(['{{var}}'], mock_templar, mock_loader, convert_bare=True) == ['success']
    assert listify_lookup_plugin

# Generated at 2022-06-11 18:16:00.363926
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar

    string_inputs = {
        None: None,
        '': [''],
        'a': ['a'],
        'a,b': ['a', 'b'],
        u'a,b,\u4f60\u597d': [u'a', u'b', u'\u4f60\u597d'],
        'a,b,{{ c }}': ['a', 'b', '{{ c }}'],
        1: [1],
        [1, 'a']: [1, 'a'],
        {'a': 1}: ['{', 'a', ':', 1, '}'],
    }

    fails = False

# Generated at 2022-06-11 18:16:11.750765
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar

    from ansible.plugins.lookup.listify_lookup_plugin import listify_lookup_plugin_terms

    terms_str_pre  = "this is a {{ str_var }}"
    terms_str_post = "this is a string"

    terms_list_pre  = [ "one", "two", "three" ]
    terms_list_post = [ "one", "two", "three" ]

    terms_list_of_list_pre  = [ "one", "{{ list_var_1 }}", "{{ list_var_2 }}" ]

# Generated at 2022-06-11 18:16:23.668709
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)
    assert listify_lookup_plugin_terms("1", templar, loader=None, fail_on_undefined=True, convert_bare=False) == ['1']
    assert listify_lookup_plugin_terms(["1"], templar, loader=None, fail_on_undefined=True, convert_bare=False) == ['1']
    assert listify_lookup_plugin_terms(u"1", templar, loader=None, fail_on_undefined=True, convert_bare=False) == ['1']
    assert listify_lookup_plugin_terms([u"1"], templar, loader=None, fail_on_undefined=True, convert_bare=False) == ['1']
    assert listify_

# Generated at 2022-06-11 18:16:33.498425
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    templar = Templar(loader=loader)

    ## string terms
    terms = "{{ var }}"
    var = "single_string"
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False) == [var]

    terms = "{{ list_var }}"
    list_var = ["list", "of", "strings"]
    assert listify_lookup_plugin_terms(terms, templar, loader, fail_on_undefined=True, convert_bare=False) == list_var

    terms = "{{ var }}"

# Generated at 2022-06-11 18:16:39.654535
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    results = listify_lookup_plugin_terms('foo', Templar({}), {}, True)

    assert(isinstance(results, list))
    assert(isinstance(results[0], string_types))
    assert(results[0] == 'foo')

    results = listify_lookup_plugin_terms(['foo','bar','baz'], Templar({}), {}, True)

    assert(isinstance(results, list))
    assert(isinstance(results[0], string_types))
    assert(results[0] == 'foo')

    for x in results:
        assert(isinstance(x, string_types))

# Generated at 2022-06-11 18:16:47.678517
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible import errors
    from ansible.template import Templar

    fake_loader = DictDataLoader({})

    templar = Templar(loader=fake_loader)

    # test string term
    term_list = listify_lookup_plugin_terms('{{ foo }}', templar, fake_loader, convert_bare=True)
    assert type(term_list) == list
    assert len(term_list) == 1
    assert term_list[0] == '{{ foo }}'

    # test list term
    term_list = listify_lookup_plugin_terms(['127.0.0.1', '{{ foo }}'], templar, fake_loader, convert_bare=True)
    assert type(term_list) == list
    assert len(term_list) == 2

# Generated at 2022-06-11 18:16:55.597738
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from units.mock.loader import DictDataLoader
    from units.mock.lookup import MockLookupModule
    from ansible.template import Templar

    mock_loader = DictDataLoader({})

    # Mock inventory, just to get plugins loaded
    mock_inventory = MockLookupModule().get_basedir(mock_loader)

    # Mock vars, just to get plugins loaded
    mock_vars = dict(basedir=mock_inventory)

    templar = Templar(loader=mock_loader, variables=mock_vars)

    # test None
    data = None
    yaml_data = []
    result = listify_lookup_plugin_terms(data, templar, mock_loader)

# Generated at 2022-06-11 18:17:18.416434
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    terms = '{{ item }}'
    templar = Templar(loader=DataLoader(), variables={'item': 'value'})
    terms = listify_lookup_plugin_terms(terms, templar, templar._loader)
    assert terms == ['value']

    terms = '{{ item }}'
    templar = Templar(loader=DataLoader(), variables={'item': ['value1', 'value2']})
    terms = listify_lookup_plugin_terms(terms, templar, templar._loader)
    assert terms == ['value1', 'value2']

    terms = ['{{ item1 }}', '{{ item2 }}']

# Generated at 2022-06-11 18:17:29.026407
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    def _test(terms, result):

        from ansible.module_utils.common._collections_compat import Sequence
        from ansible.template import Templar

        templar = Templar(loader=None)

        _result = listify_lookup_plugin_terms(terms, templar, loader=None, fail_on_undefined=True, convert_bare=False)
        assert isinstance(_result, Sequence)
        assert list(_result) == result

    assert 'listify_lookup_plugin_terms' in globals()
    terms = 'a'
    result = ['a']
    yield _test, terms, result

    terms = ['a', 'b']
    result = ['a', 'b']
    yield _test, terms, result

    terms = ['a', ['b', 'c']]

# Generated at 2022-06-11 18:17:41.229532
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    templar = Templar(loader=None)

    # test string without spaces
    assert listify_lookup_plugin_terms("foobar", templar, loader=None) == ['foobar']

    # test quoted string without spaces
    assert listify_lookup_plugin_terms("'foobar'", templar, loader=None) == ['foobar']

    # test quoted string with space
    assert listify_lookup_plugin_terms("'foo bar'", templar, loader=None) == ['foo bar']

    # test string with space
    assert listify_lookup_plugin_terms("foo bar", templar, loader=None) == ['foo bar']

    # test quoted string with comma but no spaces

# Generated at 2022-06-11 18:17:49.636007
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()

    variable_manager.set_host_variable('host1', 'key', 'value')
    variable_manager.set_host_variable('host2', 'key', 'value2')

    variable_manager.set_host_variable('host1', 'result_a', '1')
    variable_manager.set_host_variable('host2', 'result_a', '2')
    variable_manager.set_host_variable('host1', 'result_b', '2')
    variable_manager.set_host_variable('host2', 'result_b', '2')

    templar = Templar(loader=None, variables=variable_manager)


# Generated at 2022-06-11 18:18:00.528461
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Start from known terms
    terms = ['abc', 123, {'k1': 'v1'}]
    templar = None
    loader = None
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert len(terms) == 3
    assert terms == ['abc', 123, {'k1': 'v1'}]

    # Terms is string
    terms = 'abc'
    templar = None
    loader = None
    terms = listify_lookup_plugin_terms(terms, templar, loader)
    assert isinstance(terms, list)
    assert len(terms) == 1
    assert terms == ['abc']

    # Terms is tuple
    terms = ('abc', 123, {'k1': 'v1'})

# Generated at 2022-06-11 18:18:12.477865
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    import sys
    import ansible.module_utils.common._collections_compat
    import ansible.module_utils.common.text.converters
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    # Create a mock ansible.parsing.dataloader.DataLoader object
    class MockLoader:
        data = {
            'lookup_plugin_terms.yml': '''
            nospaces:
              - one
              - two
            allspaces:
              - " one "
              - "two"
            mixed:
              - one
              - "two"
            mixedlist:
              - one
              - " two,three "
              - four,five
            bare:
              - '{{var}}'
            '''
        }


# Generated at 2022-06-11 18:18:23.581958
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)

    # 1) check dict return value
    assert listify_lookup_plugin_terms(['blah', 'blah'], templar, loader) == ['blah', 'blah']

    # 2) check safe_text
    safe_term = AnsibleUnsafeText('blah')
    assert listify_lookup_plugin_terms(safe_term, templar, loader) == ['blah']

    # 3) check None return value
    assert listify_lookup_plugin_terms(None, templar, loader) == [None]

# Generated at 2022-06-11 18:18:33.872567
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    import pytest
    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test: single term, but not a list
    terms = 'foo'
    assert ['foo'] == listify_lookup_plugin_terms(terms, templar, loader)

    # Test: multiple terms, but not a list
    terms = 'foo,bar'
    assert ['foo', 'bar'] == listify_lookup_plugin_terms(terms, templar, loader)

    # Test: list with single term
    terms = ['foo']
    assert ['foo'] == listify_lookup_plugin_

# Generated at 2022-06-11 18:18:45.377005
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible.template import Templar

    myterms = 1
    mytemplar = Templar({})
    myloader = TemplerLoader()
    results = listify_lookup_plugin_terms(myterms,mytemplar,myloader)
    assert(results == [1])

    myterms = '{{ myvar }}'
    results = listify_lookup_plugin_terms(myterms,mytemplar,myloader)
    assert(results == ['{{ myvar }}'])

    myterms = ['{{ myvar.a }}', '{{ myvar.b }}']
    results = listify_lookup_plugin_terms(myterms,mytemplar,myloader)
    assert(results == ['{{ myvar.a }}', '{{ myvar.b }}'])


# Generated at 2022-06-11 18:18:52.859058
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    """
    Function listify_lookup_plugin_terms
    """

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import pytest

    variable_manager = VariableManager()
    loader = DataLoader()

    my_terms = '{{ value }}'
    my_terms_dict = dict(value='test')

    my_terms_dict_list = dict(value=['test', 'test2'])

    my_templar = Templar(loader=loader, variables=variable_manager)

    result = listify_lookup_plugin_terms(my_terms, my_templar, loader, fail_on_undefined=True, convert_bare=False)
    assert isinstance(result, list)

# Generated at 2022-06-11 18:19:26.899793
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    # Test invalid input
    assert listify_lookup_plugin_terms(None, None, None, False) == [None]
    assert listify_lookup_plugin_terms(False, None, None, False) == [False]
    assert listify_lookup_plugin_terms(42, None, None, False) == [42]
    assert listify_lookup_plugin_terms({}, None, None, False) == [{}]

    # Test string input
    assert listify_lookup_plugin_terms("test", None, None, False) == ["test"]

    # Test list input
    assert listify_lookup_plugin_terms(["test1", "test2"], None, None, False) == ["test1", "test2"]

    # Test string-list input

# Generated at 2022-06-11 18:19:36.856026
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    options = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, options=options)

    assert(listify_lookup_plugin_terms('Test', templar, loader) == ['Test'])
    assert(listify_lookup_plugin_terms(['Test'], templar, loader) == ['Test'])
    assert(listify_lookup_plugin_terms(['Test', 'Test2'], templar, loader) == ['Test', 'Test2'])

# Generated at 2022-06-11 18:19:46.350509
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    def run_test(terms, expected_terms):
        result_terms = listify_lookup_plugin_terms(terms, templar, loader)
        assert result_terms == expected_terms, result_terms

    # test string
    run_test('{{ foo }}', ['bar'])

    # test list

# Generated at 2022-06-11 18:19:55.681488
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    from ansible import constants as C
    from ansible.template import Templar

    # Setup template environment
    variables = dict(
        foo='foo_var_value',
        test=['test_val1', 'test_val2']
    )
    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables=variables)

    # Test single string term
    term = '{{foo}}'
    terms = listify_lookup_plugin_terms(term, templar, loader, fail_on_undefined=True, convert_bare=False)
    assert type(terms) == list
    assert len(terms) == 1
    assert terms[0] == 'foo_var_value'

    # Test list of string terms
    term = ['{{foo}}', '{{test}}']
    terms = listify

# Generated at 2022-06-11 18:20:05.086593
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    # Make a fake inventory
    inventory = InventoryManager(loader=DataLoader(), sources='')

    # Make a fake loader
    loader = DictDataLoader({
        "other.yml": """
        foo: "{{baz}}"
        """,
        "bar.yml": """
        baz: stuff
        """
    })

    # Make a fake VariableManager, pointing to the loader and inventory
    variable_manager = VariableManager(loader=loader, inventory=inventory)



# Generated at 2022-06-11 18:20:14.495157
# Unit test for function listify_lookup_plugin_terms

# Generated at 2022-06-11 18:20:21.012593
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    assertions = dict(
        # These are string tests to ensure it is a list
        test_template='{{ lookup_var }}',
        test_template_return='template_return',
        test_string='string',
        test_int=1,
        test_member_type_list=['template_return'],
        test_member_type_dict={'key': 'value'},
        test_member_type_string='string',
        test_member_type_int=1,
    )


# Generated at 2022-06-11 18:20:32.212878
# Unit test for function listify_lookup_plugin_terms
def test_listify_lookup_plugin_terms():

    # Stub functions to supress output and fail with returncode 1
    def fail_json(msg):
        exit(1)

    def display(msg, log_only=None, captured=None, verbosity=None):
        pass

    class AnsibleMock(object):

        class AnsibleModuleMock(object):
            class AnsibleModule(object):
                def __init__(self, argument_spec, supports_check_mode=False, bypass_checks=False, no_log=False, check_invalid_arguments=True, add_file_common_args=False, mutually_exclusive=None, required_together=None, required_one_of=None, add_ansible_module=True):
                    pass

        def get_bin_path(self, cmd, opt_dirs=None, required=False):
            return cmd

       