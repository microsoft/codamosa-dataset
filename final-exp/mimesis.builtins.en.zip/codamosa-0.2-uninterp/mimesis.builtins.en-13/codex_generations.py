

# Generated at 2022-06-17 21:41:44.888750
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:41:51.273520
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality(category='rheti') in range(1, 10)


# Generated at 2022-06-17 21:41:55.792828
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert isinstance(usa.personality(), str)
    assert isinstance(usa.personality('rheti'), int)
    assert isinstance(usa.personality('rheti'), int)

# Generated at 2022-06-17 21:42:04.198539
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality('rheti'), int)
    assert usa_provider.personality('rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:11.864880
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert 1 <= usa.personality(category='rheti') <= 10

# Generated at 2022-06-17 21:42:18.086619
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-17 21:42:25.686278
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality('rheti'), int)
    assert usa_provider.personality('rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:33.528977
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-17 21:42:40.123017
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:48.886291
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa.personality('rheti'), int)
    assert usa.personality('rheti') in range(1, 11)
