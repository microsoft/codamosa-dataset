

# Generated at 2022-06-17 21:41:48.191295
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:41:59.700382
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_spec_provider.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-17 21:42:03.257996
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.ssn() == '569-66-5801'


# Generated at 2022-06-17 21:42:08.110089
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    usa = USASpecProvider()
    assert len(usa.ssn()) == 11
    assert usa.ssn()[3] == '-'
    assert usa.ssn()[6] == '-'


# Generated at 2022-06-17 21:42:15.802959
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method ssn of class USASpecProvider."""
    usa = USASpecProvider()
    assert len(usa.ssn()) == 11
    assert usa.ssn()[3] == '-'
    assert usa.ssn()[6] == '-'
    assert usa.ssn()[0:3].isdigit()
    assert usa.ssn()[4:6].isdigit()
    assert usa.ssn()[7:11].isdigit()


# Generated at 2022-06-17 21:42:21.506816
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    ssn = usa.ssn()
    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'
    assert ssn[0:3].isdigit()
    assert ssn[4:6].isdigit()
    assert ssn[7:11].isdigit()


# Generated at 2022-06-17 21:42:27.959436
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-17 21:42:37.634583
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_spec_provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:46.080615
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-17 21:42:52.919389
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method ssn of class USASpecProvider."""
    usa = USASpecProvider()
    ssn = usa.ssn()
    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'
    assert ssn[0:3].isdigit()
    assert ssn[4:6].isdigit()
    assert ssn[7:11].isdigit()
    assert int(ssn[0:3]) != 666
