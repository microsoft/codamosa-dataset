

# Generated at 2022-06-17 21:41:44.363310
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality('rheti'), int)
    assert usa_provider.personality('rheti') in range(1, 11)


# Generated at 2022-06-17 21:41:50.202399
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality('rheti') in range(1, 11)


# Generated at 2022-06-17 21:41:59.190516
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:06.458347
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-17 21:42:14.228487
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:20.101921
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa.personality(category='rheti'), int)
    assert usa.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:25.689421
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:37.681721
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Test for method personality of class USASpecProvider
    # Create an instance of class USASpecProvider
    usa_provider = USASpecProvider()
    # Test for method personality of class USASpecProvider
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality(category='rheti'), int)
    assert usa_provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:48.672260
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='rheti') in range(1, 11)
    assert usa.personality(category='rheti') in range(1, 11)
    assert usa.personality(category='rheti') in range(1, 11)
    assert usa.personality(category='rheti') in range(1, 11)
    assert usa.personality(category='rheti')

# Generated at 2022-06-17 21:43:00.289218
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert 1 <= usa_provider.personality(category='rheti') <= 10
