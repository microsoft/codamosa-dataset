

# Generated at 2022-06-17 21:41:44.771699
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_spec_provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:41:50.963550
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-17 21:41:55.688841
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:03.831270
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality('rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:14.137684
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality(category='rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)


# Generated at 2022-06-17 21:42:20.667924
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert 1 <= provider.personality(category='rheti') <= 10

# Generated at 2022-06-17 21:42:28.332269
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality of class USASpecProvider."""
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa.personality(category='rheti'), int)
    assert 1 <= usa.personality(category='rheti') <= 10


# Generated at 2022-06-17 21:42:37.913689
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa.personality('rheti'), int)
    assert usa.personality('rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:46.590474
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert isinstance(usa.personality('rheti'), int)
    assert usa.personality('rheti') in range(1, 11)

# Generated at 2022-06-17 21:42:54.416639
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert provider.personality(category='rheti') in range(1, 11)