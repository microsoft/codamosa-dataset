

# Generated at 2022-06-17 21:41:50.844243
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality('rheti'), int)
    assert usa_provider.personality('rheti') in range(1, 11)


# Generated at 2022-06-17 21:41:56.798013
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_spec_provider.personality(category='rheti'), int)
    assert usa_spec_provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:04.245009
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:14.229713
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality(category='rheti'), int)
    assert usa_provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:20.128282
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality(category='rheti'), int)
    assert usa_provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:30.302984
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality(category='rheti'), int)
    assert usa_provider.personality(category='rheti') in range(1, 11)
    assert usa_provider.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-17 21:42:38.096913
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-17 21:42:43.143232
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality(category='rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)


# Generated at 2022-06-17 21:42:49.392528
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:59.150562
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='rheti') in range(1, 11)
