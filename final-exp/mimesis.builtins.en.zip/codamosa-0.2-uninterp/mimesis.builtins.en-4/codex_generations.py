

# Generated at 2022-06-17 21:41:44.800941
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality(category='rheti'), int)
    assert usa_provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:41:53.218441
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert provider.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-17 21:42:02.582512
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality(category='rheti'), int)
    assert usa_provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:13.247019
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality(category='rheti'), int)
    assert usa_provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:17.989575
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert type(usa.personality('rheti')) == int
    assert usa.personality('rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:24.514805
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:33.904087
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:40.955121
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-17 21:42:49.023914
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(provider.personality(category='rheti'), int)
    assert provider.personality(category='rheti') in range(1, 11)


# Generated at 2022-06-17 21:42:57.193566
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    )
