

# Generated at 2022-06-21 15:08:29.481020
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Function to test the unit test method ssn of class USASpecProvider."""
    try:
        seed = 1234567890
        us = USASpecProvider(seed)
        ssn = us.ssn()
    except Exception as e:
        print(e)



# Generated at 2022-06-21 15:08:32.647266
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """
    Unit test for method ssn of class USASpecProvider
    """

    # Test ssn returns a string of length 11
    test_ssn = USASpecProvider().ssn()
    assert type(test_ssn) == str
    assert len(test_ssn) == 11

# Generated at 2022-06-21 15:08:43.102472
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():

    obj = USASpecProvider()

    # Test for USPS Service
    tracking_number = obj.tracking_number('usps')
    assert len(tracking_number) == 22
    assert len(tracking_number.split(' ')) == 5

    # Test for FedEx Service
    tracking_number = obj.tracking_number('fedex')
    assert len(tracking_number) == 16
    assert len(tracking_number.split(' ')) == 3

    # Test for UPS Service
    tracking_number = obj.tracking_number('ups')
    assert len(tracking_number) == 18
    assert len(tracking_number.split('@')) == 3
    assert tracking_number.startswith('1Z')

    # Test with incorrect service

# Generated at 2022-06-21 15:08:45.736406
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_spec = USASpecProvider()
    assert us_spec.ssn() is not None
    assert us_spec.tracking_number() is not None
    assert us_spec.personality() is not None

# Generated at 2022-06-21 15:08:53.796073
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    assert USASpecProvider().personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                              'ISTP', 'ISFP', 'INFP', 'INTP',
                                                              'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                              'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert USASpecProvider().personality(category='rheti') in range(1, 11)

# Generated at 2022-06-21 15:08:59.265965
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Create the instance of USASpecProvider
    usa_spec_provider = USASpecProvider()

    # Generate a type of personality
    personality_type = usa_spec_provider.personality(category='MBTI')

    # If the generated personality type is not in the list of known personality types
    if personality_type not in usa_spec_provider.personality(category='MBTI'):
        # Throw an error
        raise ValueError("Unknown personality type: " + personality_type)



# Generated at 2022-06-21 15:09:08.611894
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usp = USASpecProvider()
    assert usp.personality(category='rheti') in range(1, 11)
    assert usp.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-21 15:09:12.300885
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    from mimesis.enums import Specialization

    usa = USASpecProvider(Specialization.SPORTS, Gender.MALE, seed=123)

    assert (usa.ssn() == '356-76-1958')

# Generated at 2022-06-21 15:09:13.966363
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert isinstance(provider.random, type(provider.random))

# Generated at 2022-06-21 15:09:16.562494
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)
