

# Generated at 2022-06-21 15:08:27.445172
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number()



# Generated at 2022-06-21 15:08:28.208032
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()


# Generated at 2022-06-21 15:08:30.513388
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Constructor test."""
    provider = USASpecProvider()
    assert provider._meta.name == "usa_provider"


# Generated at 2022-06-21 15:08:32.837093
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    a = USASpecProvider()
    i = 0
    while i < 100:
        i += 1
        if a.ssn() == "666-66-6666":
            print("error")

# Generated at 2022-06-21 15:08:39.464491
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-21 15:08:42.931217
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Generate a random tracking number."""
    from mimesis.enums import PostService

    usa = USASpecProvider()

    for service in PostService:
        tn = usa.tracking_number(service=service)
        assert isinstance(tn, str)
        assert len(tn) >= 6



# Generated at 2022-06-21 15:08:47.139114
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    print("TESTING : USASpecProvider_tracking_number")
    assert USASpecProvider().tracking_number(service = 'usps') != None
    assert USASpecProvider().tracking_number(service = 'fedex') != None
    assert USASpecProvider().tracking_number(service = 'ups') != None


# Generated at 2022-06-21 15:08:52.488733
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    sp = USASpecProvider()
    num = sp.ssn()
    assert len(num) == 11
    assert num[0:3].isdigit() and num[3] == '-'
    assert num[4:6].isdigit() and num[6] == '-'
    assert num[7:11].isdigit()


# Generated at 2022-06-21 15:08:58.154396
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # USPS
    assert USASpecProvider().tracking_number(service='usps') in ('#### #### #### #### ####',
                                                                 '@@ ### ### ### US')

    # FedEx
    assert USASpecProvider().tracking_number(service='fedex') in ('#### #### ####',
                                                                   '#### #### #### ###')

    # UPS
    assert USASpecProvider().tracking_number(service='ups') == '1Z@####@##########'



# Generated at 2022-06-21 15:09:00.037592
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert type(usa_provider) == USASpecProvider



# Generated at 2022-06-21 15:09:10.324224
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert isinstance(USASpecProvider().personality(), str)
    assert isinstance(USASpecProvider().personality('rheti'), int)
    assert isinstance(USASpecProvider().personality('Rheti'), int)
    assert isinstance(USASpecProvider().personality('MBTI'), str)


# Generated at 2022-06-21 15:09:15.836744
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa.provider_data, dict)
    assert isinstance(usa.pseudo_random, object)
    assert isinstance(usa.random, object)

# Unit tests for all methods of class USASpecProvider

# Generated at 2022-06-21 15:09:22.032466
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    usa = USASpecProvider()

    assert usa.tracking_number()
    assert usa.tracking_number(service='usps')
    assert usa.tracking_number(service='fedex')
    assert usa.tracking_number(service='ups')


# Generated at 2022-06-21 15:09:24.375055
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usaSpecProvider = USASpecProvider(seed=None)
    assert(len(usaSpecProvider.tracking_number()) == 18)


# Generated at 2022-06-21 15:09:27.858213
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Tests the USASpecProvider class by initializing it and creating
    a USASpecProvider object."""
    usa_provider = USASpecProvider()
    assert usa_provider is not None

# Generated at 2022-06-21 15:09:31.608216
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Tests for USASpecProvider"""
    from mimesis.providers.us_provider import USASpecProvider
    us = USASpecProvider()
    assert us.locale == 'en'


# Generated at 2022-06-21 15:09:40.457454
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Test for method personality of class USASpecProvider
    provider = USASpecProvider()
    assert provider.personality() in [
        'ISFJ',
        'ISTJ',
        'INFJ',
        'INTJ',
        'ISTP',
        'ISFP',
        'INFP',
        'INTP',
        'ESTP',
        'ESFP',
        'ENFP',
        'ENTP',
        'ESTJ',
        'ESFJ',
        'ENFJ',
        'ENTJ',
    ]
    assert provider.personality('rheti') in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-21 15:09:41.884862
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_spec_provider = USASpecProvider()
    #print(usa_spec_provider.ssn())

# Generated at 2022-06-21 15:09:45.998815
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test USASpecProvider.personality."""
    provider = USASpecProvider()

    assert isinstance(provider.personality('mbti'), str)
    assert isinstance(provider.personality('rheti'), int)

# Generated at 2022-06-21 15:09:53.804692
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider()
    assert p.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                               'ISTP', 'ISFP', 'INFP', 'INTP',
                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert type(p.personality('rheti')) == int