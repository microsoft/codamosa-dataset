

# Generated at 2022-06-21 15:08:37.699450
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()

    assert isinstance(provider.ssn(), str)
    assert provider.ssn() == '711-05-3420'


# Generated at 2022-06-21 15:08:40.809002
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn) == 11
    ssn_numbers = int(ssn.replace("-",''))
    assert ssn_numbers > 0


# Generated at 2022-06-21 15:08:42.020133
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality(category="") in mbtis

# Generated at 2022-06-21 15:08:50.304693
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    tracking_number1 = usa_spec_provider.tracking_number(service = 'USPS')
    tracking_number2 = usa_spec_provider.tracking_number(service = 'FedEx')
    tracking_number3 = usa_spec_provider.tracking_number(service = 'UPS')
    assert len(tracking_number1) == 22
    assert len(tracking_number2) == 20
    assert len(tracking_number3) == 18


# Generated at 2022-06-21 15:08:54.013976
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa = USASpecProvider()
    assert len(usa.personality()) == 4 or len(usa.personality()) == 2
    assert len(usa.personality('rheti')) == 1


# Generated at 2022-06-21 15:08:54.633740
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    USASpecProvider()

# Generated at 2022-06-21 15:08:56.553597
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    result = provider.ssn()
    assert len(result) == 11


# Generated at 2022-06-21 15:08:58.890160
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider"""
    result = USASpecProvider().ssn()
    print('ssn =', result)
    assert type(result) == str
    assert len(result) == 11

# Generated at 2022-06-21 15:09:01.964319
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usasp = USASpecProvider()
    try:
        usasp.ssn()
    except AssertionError:
        return False
    else:
        return True


# Generated at 2022-06-21 15:09:06.370906
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()

    assert usa_spec_provider
    assert usa_spec_provider.Meta.name == 'usa_provider'

