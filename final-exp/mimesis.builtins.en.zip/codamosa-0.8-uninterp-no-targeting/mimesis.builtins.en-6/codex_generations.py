

# Generated at 2022-06-21 15:08:40.475044
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test the function ssn of class USASpecProvider."""
    usa_provider = USASpecProvider(seed=12345678)
    assert usa_provider.ssn() == '012-46-9430'

# Generated at 2022-06-21 15:08:44.719205
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider(seed=123)
    assert us.tracking_number('usps') == '9355 0136 2033 0403 5387'
    assert us.tracking_number('fedex') == '4417 8201 7442'
    assert us.tracking_number('ups') == '1Z4UUEC4RU60181487'
    assert us.tracking_number('fedex') == '3196 4291 3277'
    assert us.tracking_number('ups') == '1Z7X9X9M15A7189106'


# Generated at 2022-06-21 15:08:48.374222
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    import re
    p = re.compile(r'[0-9]{3}-[0-9]{2}-[0-9]{4}')
    assert p.match(USASpecProvider().ssn()) != None


# Generated at 2022-06-21 15:08:53.706914
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Unit test for method ssn of class USASpecProvider
    x = USASpecProvider()
    assert len(list(map(int, x.ssn().split("-")))) == 3
    assert 665 not in list(map(int, x.ssn().split("-")))
    assert 666 in list(map(int, x.ssn().split("-")))

# Generated at 2022-06-21 15:08:56.042454
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    b = USASpecProvider()
    assert isinstance(b.personality(), str)
    assert isinstance(b.personality(category='rheti'), int)


# Generated at 2022-06-21 15:08:58.341745
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    provider = USASpecProvider()
    res = provider.ssn()
    assert len(res) == len('xxx-xx-xxxx')

# Generated at 2022-06-21 15:09:01.385469
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider(seed=12345)
    assert usa_provider.ssn() == "264-85-9514"

# Generated at 2022-06-21 15:09:03.445227
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test for USASpecProvider"""
    assert USASpecProvider()

# Generated at 2022-06-21 15:09:07.047146
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider('en')
    assert usa.tracking_number() == "7331 0339 2039 5799 6677"


# Generated at 2022-06-21 15:09:15.738535
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    area = int(ssn.split('-')[0])
    groups = ssn.split('-')
    assert len(groups) == 3
    assert len(groups[0]) == 3
    assert len(groups[1]) == 2
    assert len(groups[2]) == 4
    assert area > 0 and area < 900
    assert area != 666
    if str(area)[0] == '7':
        assert area != 733
        assert area != 734
        assert area != 736
        assert area != 742
        assert area != 744
        assert area != 749
        assert area != 764
        assert area != 765
    if str(area)[0] == '8':
        assert area != 888
        assert area != 889