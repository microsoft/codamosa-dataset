

# Generated at 2022-06-21 15:08:30.129018
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.providers.personality import Personality
    a = USASpecProvider()
    assert a.personality('mbti') in Personality.MBTI_TYPES
    assert 1 <= a.personality('rheti') <= 10

# Generated at 2022-06-21 15:08:31.542767
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == '660-01-1409'


# Generated at 2022-06-21 15:08:36.720075
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis import Person
    per = Person('en')
    ssn1 = per.ssn()
    ssn2 = per.ssn()
    assert ssn1 != ssn2


# Generated at 2022-06-21 15:08:44.362027
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider(seed=1234567890)
    assert usa_spec_provider.personality(category='mbti') in ('ISTJ', 'INFJ', 'INTJ',
                                                              'ISTP', 'ISFP', 'INFP', 'INTP',
                                                              'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                              'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_spec_provider.personality(category='rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-21 15:08:50.448814
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""

# Generated at 2022-06-21 15:08:55.539724
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider()
    res = p.personality()
    assert res in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                       'ISTP', 'ISFP', 'INFP', 'INTP',
                       'ESTP', 'ESFP', 'ENFP', 'ENTP',
                       'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-21 15:08:58.342615
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    # Create instance of USASpecProvider
    us = USASpecProvider()

    assert us.__init__() is None, \
        'Err: creating instance of USASpecProvider class.'


# Generated at 2022-06-21 15:09:00.035163
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert isinstance(USASpecProvider(), USASpecProvider)


# Generated at 2022-06-21 15:09:02.444444
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    print(usa.personality("mbti"))


# Generated at 2022-06-21 15:09:04.873673
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Test USASpecProvider.ssn()
    ssn = USASpecProvider().ssn()