

# Generated at 2022-06-21 15:08:30.167426
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert (USASpecProvider().personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'])

# Generated at 2022-06-21 15:08:33.426542
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa_provider = USASpecProvider()

    assert len(usa_provider.personality()) == 4
    assert usa_provider.personality(category='rheti') in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-21 15:08:38.699215
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test a constructor."""
    from mimesis.providers.usa import USASpecProvider

    provider = USASpecProvider(seed = "USASpecProvider")
    assert provider.__class__.__name__ == "USASpecProvider"



# Generated at 2022-06-21 15:08:43.257083
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    try:
        assert USASpecProvider().personality('rheti') in range(1,10)
        assert USASpecProvider().personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ','ISTP', 'ISFP', 'INFP', 'INTP','ESTP', 'ESFP', 'ENFP', 'ENTP','ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    except:
        assert False

# Generated at 2022-06-21 15:08:48.904432
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method of tracking_number."""
    usa = USASpecProvider()
    for i in range(1,4):
        service = 'usps'
        if i == 2:
            service = 'fedex'
        elif i == 3:
            service = 'ups'
        tracking_number = usa.tracking_number(service)
        assert tracking_number



# Generated at 2022-06-21 15:08:51.267255
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test for USASpecProvider"""
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)


# Generated at 2022-06-21 15:08:57.219229
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test function for method USASpecProvider.personality.

    """
    test_provider = USASpecProvider()
    assert test_provider.personality('mbti') in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP',
        'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    ]


# Generated at 2022-06-21 15:08:59.165674
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality(category="mbti")
    assert provider.personality(category="rheti")


# Generated at 2022-06-21 15:09:11.602919
# Unit test for method ssn of class USASpecProvider

# Generated at 2022-06-21 15:09:13.424468
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider, USASpecProvider)
