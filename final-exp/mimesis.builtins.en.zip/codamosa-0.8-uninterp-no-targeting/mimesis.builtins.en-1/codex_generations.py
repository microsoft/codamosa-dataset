

# Generated at 2022-06-21 15:08:29.210750
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    USASpecProvider()

# Generated at 2022-06-21 15:08:33.376387
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    result = provider.personality()
    assert result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                      'ISTP', 'ISFP', 'INFP', 'INTP',
                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-21 15:08:41.037579
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    uss = USASpecProvider()
    assert uss.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                   'ISTP', 'ISFP', 'INFP', 'INTP',
                                   'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                   'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert uss.personality('rheti') in range(1,11)

# Generated at 2022-06-21 15:08:45.416481
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-21 15:08:46.718479
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    instance = USASpecProvider()
    assert instance is not None


# Generated at 2022-06-21 15:08:50.676654
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    ssn = USASpecProvider().ssn()
    assert len(ssn) == 11
    assert '-' in ssn
    assert ssn[3] == '-'
    assert ssn[6] == '-'

# Generated at 2022-06-21 15:08:56.438548
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    from mimesis import usa_provider
    from mimesis.schema import Field, Schema

    schema = Schema(
        field=Field('ssn'),
        gender=Field('gender', gender=Gender.MALE)
    )

    data = schema.create(
        seed=42,
        quantity=10,
        provider=usa_provider.USASpecProvider(seed=42),
    )
    print(data)

# Generated at 2022-06-21 15:09:04.042232
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    ssn = USASpecProvider().ssn()
    assert isinstance(ssn, str)
    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'
    area = int(ssn[0:3])
    group = int(ssn[4:6])
    serial = int(ssn[7:11])
    assert 1 <= area <= 899
    assert area != 666
    assert 1 <= group <= 99
    assert 1 <= serial <= 9999


# Generated at 2022-06-21 15:09:09.744832
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert (USASpecProvider().tracking_number('usps') ==  "USPS TRACKING NUMBER")
    assert (USASpecProvider().tracking_number('fedex') ==  "FEDEX TRACKING NUMBER")
    assert (USASpecProvider().tracking_number('ups') ==  "UPS TRACKING NUMBER")
    

# Generated at 2022-06-21 15:09:11.092940
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert len(USASpecProvider().tracking_number()) == 27