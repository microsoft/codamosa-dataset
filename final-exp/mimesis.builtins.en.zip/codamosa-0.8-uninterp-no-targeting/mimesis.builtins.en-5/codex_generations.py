

# Generated at 2022-06-21 15:08:34.162464
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """_test_USASpecProvider_tracking_number."""
    usen = USASpecProvider()
    usen.random.seed(0)

    usps = usen.tracking_number()
    assert usps == 'LH92 9436 3555 7172 6047'

    fedex = usen.tracking_number(service='fedex')
    assert fedex == '7455 9253 5285'

    ups = usen.tracking_number(service='ups')
    assert ups == '1Z1A38A1F564295535'



# Generated at 2022-06-21 15:08:36.022055
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11


# Generated at 2022-06-21 15:08:44.104890
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person.en import Person
    from mimesis.providers.geo.en import Geo
    from mimesis.providers.address.en import Address
    from mimesis.providers.date_time.en import DateTime
    from mimesis.providers.phone_number.en import PhoneNumber
    from mimesis.providers.business.en import Business
    from mimesis.providers.internet.en import Internet
    from mimesis.providers.lorem.en import Lorem
    from mimesis.providers.misc import Mimesis
    from mimesis.providers.us_provider import USASpecProvider
    from mimesis.seed import Seed
    from mimesis.utils import lower

# Generated at 2022-06-21 15:08:48.712510
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    data_provider = USASpecProvider(seed=111)
    assert data_provider.tracking_number() == "9473 9494 6556 8971 0607"
    assert data_provider.ssn() == "219-14-1555"
    assert data_provider.personality() == "ISFJ"

# Generated at 2022-06-21 15:08:54.874031
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Given
    usa_provider = USASpecProvider()
    usa_provider.random

    # When
    result = usa_provider.tracking_number()
    result = usa_provider.personality()
    result = usa_provider.ssn()
    result = usa_provider.random

    # Then
    assert result is not None

if __name__ == '__main__':
    test_USASpecProvider()

# Generated at 2022-06-21 15:08:59.445230
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number(service = 'usps') == '1Z73A2380344033942'
    assert provider.tracking_number(service = 'fedex') == '78731848190'
    assert provider.tracking_number(service = 'ups') == '927496801213026'


# Generated at 2022-06-21 15:09:11.929567
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.name import Name
    from mimesis.providers.code import Code
    from mimesis.providers.person import Person
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    import mimesis.providers.en.us_provider as usa
    import mimesis.locales.en as locales

    seed = 'slfnadflk'
    post_service = 'usps'
    category = 'mbti'

    # Populate database
    person_data = Person(locales.en)
    person_data.seed(seed)


# Generated at 2022-06-21 15:09:13.887895
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usssn = USASpecProvider()
    usssn.seed(1)
    assert usssn.ssn() == '001-01-0001'

# Generated at 2022-06-21 15:09:22.506278
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Unit test for method ssn of class USASpecProvider
    test = USASpecProvider()
    test1 = test.ssn()
    test2 = test1.split('-')
    assert len(test2) == 3
    assert test2[0] != '000'
    assert test2[1] != '00'
    assert test2[2] != '0000'
    assert test1 != '000-00-0000'
    assert test2[0] != '666'

# Generated at 2022-06-21 15:09:24.781970
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() == '1ZR6A9XW0233979479'


# Generated at 2022-06-21 15:09:33.127470
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usps = USASpecProvider().tracking_number()
    fedex = USASpecProvider().tracking_number('fedex')
    ups = USASpecProvider().tracking_number('ups')
    assert(usps != fedex != ups)


# Generated at 2022-06-21 15:09:33.986833
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider(): pass

# Generated at 2022-06-21 15:09:37.562613
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for USASpecProvider."""
    usaspp = USASpecProvider()
    assert str(type(usaspp)) == "<class 'mimesis.providers.usa_provider.USASpecProvider'>"


# Generated at 2022-06-21 15:09:39.900678
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    answer = provider.personality(category='rheti')
    assert answer > 0
    assert answer <= 10


# Generated at 2022-06-21 15:09:41.687698
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert len(USASpecProvider().tracking_number()) > 0
    assert len(USASpecProvider().ssn()) > 0
    assert len(USASpecProvider().personality()) > 0

# Generated at 2022-06-21 15:09:47.390550
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """ssn method is valid or not."""
    usa_provider = USASpecProvider()
    for _ in range(10):
        ssn = usa_provider.ssn()
        assert isinstance(ssn, str)
        assert len(ssn) == 11


# Generated at 2022-06-21 15:09:49.502200
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() == '3158 4978 7596'


# Generated at 2022-06-21 15:09:51.723796
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    sp = USASpecProvider()
    assert sp.mbti == 'INFP'
    assert sp.rheti == '7'


# Generated at 2022-06-21 15:09:54.685871
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    res = usa.ssn()
    assert '-' in res
    assert len(res) == 11


# Generated at 2022-06-21 15:09:57.545523
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.providers.usa import USASpecProvider
    usa = USASpecProvider()
    assert usa.ssn() != usa.ssn()
