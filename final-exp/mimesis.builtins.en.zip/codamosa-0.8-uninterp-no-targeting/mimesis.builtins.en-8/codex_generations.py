

# Generated at 2022-06-21 15:08:33.351056
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    assert(us.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
    'ISTP', 'ISFP', 'INFP', 'INTP',
    'ESTP', 'ESFP', 'ENFP', 'ENTP',
    'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'))

# Generated at 2022-06-21 15:08:40.378374
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    mbti = usa.personality()
    assert mbti in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-21 15:08:42.374083
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    tracking_number = usa_spec_provider.tracking_number()
    assert tracking_number is not None



# Generated at 2022-06-21 15:08:51.037632
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()

    assert usa.tracking_number() != usa.tracking_number()
    assert usa.tracking_number(service='USPS') != usa.tracking_number(service='UPS')
    assert usa.tracking_number(service='FedEx') != usa.tracking_number(service='UPS')

    assert usa.ssn() != usa.ssn()

    assert usa.personality(category='MBTI') != usa.personality(category='Rheti')
    assert usa.personality(category='MBTI') != usa.personality(category='Rheti')

# Generated at 2022-06-21 15:08:52.795606
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test USASpecProvider()."""
    assert USASpecProvider()._data is not None


# Generated at 2022-06-21 15:08:54.874116
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test the constructor of class USASpecProvider."""
    spec = USASpecProvider()
    assert spec.tracking_number() != None


# Generated at 2022-06-21 15:09:00.558815
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    result = usa_spec_provider.personality('mbti')
    assert len(result) == 4
    assert result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(result, str)
    
    assert isinstance(usa_spec_provider.personality('rheti'), int)

# Generated at 2022-06-21 15:09:12.586171
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.providers.usa.usa_provider import USASpecProvider
    USA = USASpecProvider(seed='a')

    res = USA.tracking_number(service="usps")
    assert res
    assert isinstance(res, str)
    assert res == "7373 9083 5474 8862 4887"

    res = USA.tracking_number(service="fedex")
    assert res
    assert isinstance(res, str)
    assert res == "0085 6753 7073"

    res = USA.tracking_number(service="ups")
    assert res
    assert isinstance(res, str)
    assert res == "1ZC852T15337978652"

    res = USA.ssn()
    assert res
    assert isinstance(res, str)

# Generated at 2022-06-21 15:09:21.522759
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_provider = USASpecProvider()
    assert us_provider.tracking_number() != None
    assert us_provider.tracking_number("usps") != None
    assert us_provider.tracking_number("fedex") != None
    assert us_provider.tracking_number("ups") != None
    assert us_provider.ssn() != None
    assert us_provider.personality("mbti") != None
    assert us_provider.personality("rheti") != None

# Generated at 2022-06-21 15:09:24.273828
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    test = USASpecProvider(seed=847)
    assert test.tracking_number() == '4Z4 67401 546 63396 642'