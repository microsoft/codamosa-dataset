

# Generated at 2022-06-21 15:08:38.743080
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    up = USASpecProvider()
    # Asserts if the value generated is a string
    assert isinstance(up.personality(), str)


# Generated at 2022-06-21 15:08:44.235705
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():

    # Create object of class USASpecProvider, set random seed
    usa_spec_provider = USASpecProvider(seed=14)
    
    # Generate tracking number for post service USPS
    tracking_number_usps = usa_spec_provider.tracking_number(service = "USPS")
    
    # Print tracking number to terminal
    print("tracking number = " + tracking_number_usps)
    print("type of tracking number = ", type(tracking_number_usps))
    
    assert isinstance(tracking_number_usps, str)
    assert len(tracking_number_usps) == 22


# Generated at 2022-06-21 15:08:53.094043
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.tracking_number('usps') in ('#### #### #### #### ####', '@@ ### ### ### US')
    assert usa_spec_provider.tracking_number('fedex') in ('#### #### ####', '#### #### #### ###')
    assert usa_spec_provider.tracking_number('ups') in ('1Z@####@##########',)

    try:
        usa_spec_provider.tracking_number('parcelforce')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-21 15:08:54.753442
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    usa.tracking_number(service='usps')


# Generated at 2022-06-21 15:08:57.293777
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    usps = usa.tracking_number(service="usps")
    assert isinstance(usps,str)
    assert len(usps) > 0


# Generated at 2022-06-21 15:08:59.593665
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """test_USASpecProvider_ssn"""
    assert len(USASpecProvider().ssn()) == 11
    assert USASpecProvider().ssn() == '569-66-5801'

# Generated at 2022-06-21 15:09:11.748350
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.us import USASpecProvider
    seed = 'asdfasdf'
    us_provider = USASpecProvider(seed=seed)
    assert isinstance(us_provider, USASpecProvider)
    assert us_provider.__class__.__name__ == 'USASpecProvider'
    assert us_provider.__module__ == 'mimesis.providers.us'
    assert us_provider._seed is not None
    assert us_provider.get_seed() == seed
    assert us_provider.gender == Gender.MALE
    assert us_provider.locale == 'en'
    assert us_provider.Meta.name == 'usa_provider'


# Generated at 2022-06-21 15:09:14.817595
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()

    assert provider.tracking_number('usps')
    assert provider.tracking_number('fedex')
    assert provider.tracking_number('ups')


# Generated at 2022-06-21 15:09:20.931375
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number()
    assert usa.tracking_number('usps')
    assert usa.tracking_number('fedex')
    assert usa.tracking_number('ups')
#
# # Unit test for method ssn of class USASpecProvider

# Generated at 2022-06-21 15:09:24.310644
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert len(provider.ssn()) == 11
    assert provider.ssn().count('-') == 2
    assert provider.ssn()[0:3].isdigit()
    assert provider.ssn()[4:6].isdigit()
    assert provider.ssn()[7:11].isdigit()
    assert provider.ssn()[0] != 0
    assert provider.ssn()[4] != 0
    assert provider.ssn()[7] != 0
    assert provider.ssn()[3] == '-'
    assert provider.ssn()[6] == '-'


# Generated at 2022-06-21 15:09:35.762433
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
	assert(len(USASpecProvider().ssn()) == 11)
	assert(USASpecProvider().ssn().count('-') == 2)


# Generated at 2022-06-21 15:09:37.918745
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)


# Generated at 2022-06-21 15:09:40.188595
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    spec_provider = USASpecProvider(seed=123456789)
    assert spec_provider.personality(category='mbti') == 'ESTJ'

# Generated at 2022-06-21 15:09:41.430760
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn."""
    assert USASpecProvider().ssn() == '371-20-3585'

# Generated at 2022-06-21 15:09:43.426846
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    data = USASpecProvider()
    assert data.tracking_number() is not None


# Generated at 2022-06-21 15:09:45.553428
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == '814-20-4044'

# Generated at 2022-06-21 15:09:54.157151
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for method tracking_number of class USASpecProvider."""
    from mimesis.enums import PostService

    usa_provider = USASpecProvider()

    for _ in range(1000):
        usa_provider.tracking_number(service=PostService.USPS)

    for _ in range(1000):
        usa_provider.tracking_number(service=PostService.UPS)

    for _ in range(1000):
        usa_provider.tracking_number(service=PostService.FEDEX)



# Generated at 2022-06-21 15:10:00.092760
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us_en = USASpecProvider()
    assert us_en.personality('mbti') in (
       'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert us_en.personality('rheti') in range(1, 10)

# Generated at 2022-06-21 15:10:05.701449
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usaSpecProv = USASpecProvider()
    results = []
    for i in range(1, 10000):
        results.append(usaSpecProv.tracking_number(service='usps'))
    assert results[0] in results
    assert results[-1] in results
    assert len(results) == 9999





# Generated at 2022-06-21 15:10:13.846466
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    usa_spec_provider = USASpecProvider(seed=100)
    r = usa_spec_provider.ssn()
    assert r == '569-66-5801'
    r = usa_spec_provider.ssn()
    assert r == '886-24-1143'
    r = usa_spec_provider.ssn()
    assert r == '729-74-8963'
    r = usa_spec_provider.ssn()
    assert r == '871-03-6589'