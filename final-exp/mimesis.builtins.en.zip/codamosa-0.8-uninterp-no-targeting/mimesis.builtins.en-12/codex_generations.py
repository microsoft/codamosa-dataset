

# Generated at 2022-06-21 15:08:42.446389
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # USASpecProvider instance with default value
    spec_provider = USASpecProvider()
    assert spec_provider.ssn().isdigit()

    # USASpecProvider instance with specific value
    spec_provider = USASpecProvider(seed=1)
    assert spec_provider.ssn() == '823-98-7799'

    # USASpecProvider instance with default value
    spec_provider = USASpecProvider()
    assert spec_provider.ssn().isdigit()
    assert spec_provider.ssn() != '666-66-6666'


# Generated at 2022-06-21 15:08:47.865146
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usasp = USASpecProvider()
    assert usasp.tracking_number(service='usps') != usasp.tracking_number(service='usps')
    assert usasp.ssn() != usasp.ssn()
    assert usasp.personality() != usasp.personality()
    assert usasp.personality(category='rheti') != usasp.personality(category='rheti')

# Generated at 2022-06-21 15:08:52.118633
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == '869-59-9399'
    assert provider.ssn() == '123-50-5826'
    assert provider.ssn() == '766-84-2964'


# Generated at 2022-06-21 15:09:00.257864
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
	myusaspec = USASpecProvider(seed=1)
	mylist = []
	for x in range(0, 1000):
		mylist.append(myusaspec.personality())
	assert (1<= mylist.count("ISFJ") <= 300) #test for whether ISFJ is uniformly distributed
	assert (1<= mylist.count("ISTJ") <= 300) #test for whether ISTJ is uniformly distributed
	assert (1<= mylist.count("INFJ") <= 300) #test for whether INFJ is uniformly distributed
	assert (1<= mylist.count("INTJ") <= 300) #test for whether INTJ is uniformly distributed
	assert (1<= mylist.count("ISTP") <= 300) #test for whether ISTP is uniformly distributed

# Generated at 2022-06-21 15:09:03.630259
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number() in ['#### #### ####', '@@ ### ### ### US']

# Generated at 2022-06-21 15:09:06.579404
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category = 'mbti') != None
    assert USASpecProvider().personality(category = 'rheti') != None

# Generated at 2022-06-21 15:09:09.835324
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usaspec = USASpecProvider()
    assert usaspec.tracking_number(service='fedex') in ('#### #### ####', '#### #### #### ###')


# Generated at 2022-06-21 15:09:11.821450
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test to check if USASpecProvider is valid.
    """

    data = USASpecProvider()
    assert data
    assert type(data) is USASpecProvider


# Generated at 2022-06-21 15:09:12.927829
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()  # type: ignore
    assert usa is not None

# Generated at 2022-06-21 15:09:25.566751
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider(seed=12345)
    assert usa.tracking_number(service='usps') == 'EE0 727 002 US'
    assert usa.tracking_number(service='UPS') == '1Z6V7855YW48762976'
    assert usa.tracking_number(service='ups') == '1Z0 A10 344 2327 6779'
    assert usa.tracking_number(service='fedex') == '8090 0381 1869'
    assert usa.tracking_number(service='fedex') == '5794 5002'
    assert usa.tracking_number(service='fedex') == '4362 2515 894'
    assert usa.tracking_number(service='fedex') == '2065 8743'