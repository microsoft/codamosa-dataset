

# Generated at 2022-06-21 15:08:41.337264
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    usa.tracking_number()
    usa.tracking_number(service="fedex")
    usa.tracking_number(service="usps")
    usa.tracking_number(service="ups")
    usa.tracking_number("usps")
    usa.tracking_number("fedex")
    usa.tracking_number("ups")
    usa.ssn()
    usa.personality()
    usa.personality("rheti")

# Generated at 2022-06-21 15:08:44.750075
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for method tracking_number of class USASpecProvider."""
    spec = USASpecProvider()
    tracking_number = spec.tracking_number(service='usps')
    print(tracking_number)
    assert tracking_number is not None



# Generated at 2022-06-21 15:08:50.404430
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    result = provider.ssn()
    assert len(result) == 11
    assert result[3] == '-'
    assert result[6] == '-'
    first_three = result.split('-')[0]
    assert first_three[0] != '0'
    assert first_three != '666'


# Generated at 2022-06-21 15:08:53.366206
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec = USASpecProvider()
    print(usa_spec.ssn())
    print(usa_spec.tracking_number())
    print(usa_spec.personality())


# Generated at 2022-06-21 15:09:00.876199
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa = USASpecProvider()

    result_mbti = usa.personality(category="mbti")
    assert result_mbti in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                           'ISTP', 'ISFP', 'INFP', 'INTP',
                           'ESTP', 'ESFP', 'ENFP', 'ENTP',
                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    result_rheti = usa.personality(category="rheti")
    assert result_rheti in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    result_exception = usa.personality(category="wrong")
    assert result

# Generated at 2022-06-21 15:09:09.304706
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality("mbti") in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert USASpecProvider().personality("rheti") in range(1,10)

# Generated at 2022-06-21 15:09:12.506926
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert isinstance(provider, USASpecProvider)
    # Meta
    assert provider.Meta.name == 'usa_provider'
    assert provider.Meta.seed == None


# Generated at 2022-06-21 15:09:14.652132
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    data = USASpecProvider().ssn()
    assert(data  == "331-96-5199")

# Generated at 2022-06-21 15:09:20.736820
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    random = USASpecProvider()
    assert random.tracking_number()
    assert random.tracking_number()
    assert random.tracking_number('ups')
    assert random.tracking_number('upS')
    assert random.tracking_number('fedEx')
    assert random.tracking_number('uPs')


# Generated at 2022-06-21 15:09:24.423601
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number() not in (None, "", "  ")
    assert provider.tracking_number('usps') not in (None, "", "  ")
    assert provider.tracking_numbe