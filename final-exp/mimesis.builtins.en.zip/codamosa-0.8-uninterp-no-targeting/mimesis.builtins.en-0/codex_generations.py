

# Generated at 2022-06-21 15:08:36.909079
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usaspecprovider = USASpecProvider()
    assert isinstance(usaspecprovider, USASpecProvider)


# Generated at 2022-06-21 15:08:40.199813
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test case for ssn method of class USASpecProvider"""
    # init of USASpecProvider
    provider = USASpecProvider()
    
    assert len(provider.ssn()) == 11

    # assert len(provider.ssn()) == 11
    # assert isinstance(provider.ssn(), str)


# Generated at 2022-06-21 15:08:42.940583
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    print('Test method tracking_number of class USASpecProvider')
    usa_spec_provider = USASpecProvider()
    print(usa_spec_provider.tracking_number())



# Generated at 2022-06-21 15:08:49.593118
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    category = 'mbti'
    assert usa_provider.personality(category=category) in \
           ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
            'ISTP', 'ISFP', 'INFP', 'INTP',
            'ESTP', 'ESFP', 'ENFP', 'ENTP',
            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-21 15:08:58.608044
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert isinstance(usa.tracking_number(), str)
    assert len(usa.tracking_number()) > 0
    assert len(usa.tracking_number(service='usps')) == 27
    assert len(usa.tracking_number(service='fedex')) == 22
    assert len(usa.tracking_number(service='ups')) == 18

    with USASpecProvider(seed=123) as usa:
        assert usa.tracking_number() == 'E769 8162 5K53 7B10'
        assert usa.tracking_number(service='usps') == 'E769 8162 5K53 7B10'
        assert usa.tracking_number(service='fedex') == 'S412 6116 4K88'

# Generated at 2022-06-21 15:09:00.037015
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number(service='usps')



# Generated at 2022-06-21 15:09:06.843455
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn.split('-')) == 3
    assert ssn.split('-')[0].isdigit()
    assert ssn.split('-')[1].isdigit()
    assert ssn.split('-')[2].isdigit()

# Generated at 2022-06-21 15:09:11.141927
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    assert USASpecProvider().personality() == 'ISFJ'
    assert USASpecProvider().personality(category='rheti') in (1, 10)
    assert USASpecProvider().personality().startswith('IS')
    assert USASpecProvider().personality().endswith('J')

# Generated at 2022-06-21 15:09:15.490838
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert(USASpecProvider().personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'])


# Generated at 2022-06-21 15:09:18.315838
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert usa_provider.__class__.__name__ == 'USASpecProvider'