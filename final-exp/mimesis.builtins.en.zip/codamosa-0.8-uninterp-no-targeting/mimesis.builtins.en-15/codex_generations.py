

# Generated at 2022-06-21 15:08:27.255690
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    return USASpecProvider().ssn()


# Generated at 2022-06-21 15:08:29.515360
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.random_generator.seed == __name__


# Generated at 2022-06-21 15:08:32.682480
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """This test instantiates USASpecProvider class."""
    provider = USASpecProvider()
    provider.provider.__name__ == 'usaspecprovider'
    assert provider.provider.__name__ == 'usaspecprovider'


# Generated at 2022-06-21 15:08:35.790642
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    usa.tracking_number()
    

# Generated at 2022-06-21 15:08:38.067315
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    up = USASpecProvider()
    assert up._locale == 'en'


# Generated at 2022-06-21 15:08:40.080481
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Arrange
    # Create the target object
    usa_provider = USASpecProvider()

    # Act
    # Call the method

# Generated at 2022-06-21 15:08:42.018653
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec = USASpecProvider(seed=1)
    assert usa_spec.__class__.__name__ == "USASpecProvider"


# Generated at 2022-06-21 15:08:44.857339
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    result = provider.ssn()
    assert result.count('-') == 2
    assert result.count('0') <= 3
    assert result.count('9') <= 3

# Generated at 2022-06-21 15:08:45.817315
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider()


# Generated at 2022-06-21 15:08:47.964059
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number(service='USPS')


# Generated at 2022-06-21 15:09:04.553854
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
	assert str(USASpecProvider().personality()) in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
	assert type(USASpecProvider().personality(category='rheti')) == int
	assert USASpecProvider().personality(category='rheti') in [1,2,3,4,5,6,7,8,9,10]


# Generated at 2022-06-21 15:09:07.837987
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    test_USASpecProvider = USASpecProvider()
    assert test_USASpecProvider is not None
    return


# Generated at 2022-06-21 15:09:10.123306
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    ssn = USASpecProvider().ssn()

    print("Social Security Number: " + ssn)
    assert len(ssn) == 11

# Generated at 2022-06-21 15:09:15.129817
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    provider = USASpecProvider()
    tracking_number = provider.tracking_number()

    assert tracking_number.isspace() is False

    tracking_number = provider.tracking_number(service='Fedex')
    assert tracking_number.isspace() is False

    tracking_number = provider.tracking_number(service='ups')
    assert tracking_number.isspace() is False


# Generated at 2022-06-21 15:09:24.273931
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    provider = USASpecProvider()

    # Set seed
    provider.seed(0)

    # Test
    ssn = provider.ssn()
    ssn_2 = provider.ssn()
    assert isinstance(ssn, str)
    assert isinstance(ssn_2, str)
    print(ssn)
    print(ssn_2)
    assert ssn == '828-34-5721'
    assert ssn_2 == '828-34-5721'

# Generated at 2022-06-21 15:09:29.449810
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.builtins import USASpecProvider as usa
    assert len(usa().ssn()) == 11
    assert usa().ssn().replace('-', '').isdigit()
    assert usa().ssn()[3] == '-'
    assert usa().ssn()[6] == '-'

# Generated at 2022-06-21 15:09:39.012835
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa = USASpecProvider()
    assert usa.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                       'ISTP', 'ISFP', 'INFP', 'INTP',
                                       'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                       'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality('rheti') in (1,2,3,4,5,6,7,8,9,10)
    print("Test of method personality of class USASpecProvider is finished!")

# Generated at 2022-06-21 15:09:41.048099
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert ssn not in (None, '', '000-00-0000')


# Generated at 2022-06-21 15:09:45.314802
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
	provider = USASpecProvider()
	assert provider.tracking_number()
	assert provider.tracking_number(service='USPS')
	assert provider.tracking_number(service='FedEx')
	assert provider.tracking_number(service='UPS')


# Generated at 2022-06-21 15:09:53.953992
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.enums import PostService
    from csv import reader

    usa = USASpecProvider()
    with open ('test-data/test-data-tracking_number.csv', encoding = 'utf-8') as f:
        test_data = list(reader(f, delimiter = ','))

    for row in test_data:
        # row[0] - test name
        # row[1] - post service
        # row[2] - tracking number
        assert row[2] == usa.tracking_number(row[1])