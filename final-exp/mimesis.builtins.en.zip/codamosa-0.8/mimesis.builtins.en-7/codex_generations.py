

# Generated at 2022-06-12 00:58:54.534570
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    personality = USASpecProvider()
    assert personality.personality('mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert type(personality.personality('rheti')) == int
    assert 0 < personality.personality('rheti') <= 10
    assert personality.personality('enneagram') == None


# Generated at 2022-06-12 00:59:03.220837
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider() 
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality('Rheti'), int)
    assert usa_provider.personality('Rheti') in [x+1 for x in range(10)]

# Generated at 2022-06-12 00:59:06.106006
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    specProvider = USASpecProvider()
    personType = specProvider.personality()
    print(personType)


# Generated at 2022-06-12 00:59:13.686921
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    c = USASpecProvider()
    assert c.personality(category='mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(c.personality(category='rheti'), int) and 1 < c.personality(category='rheti') < 10


# Generated at 2022-06-12 00:59:23.849853
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality of class USASpecProvider."""
    usa = USASpecProvider()
    personality = usa.personality()
    assert len(personality) == 4
    assert personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP',
                           'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    personality = usa.personality(category='rheti')
    assert isinstance(personality, int)
    assert personality in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-12 00:59:27.615013
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaSpecProvider = USASpecProvider()
    assert type(usaSpecProvider.personality("mbti")) == str



# Generated at 2022-06-12 00:59:32.881481
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality(category='mbti') == 'ISFJ' or provider.personality(category='rheti') == 1

if __name__ == '__main__':
    # Test for method personality of class USASpecProvider
    test_USASpecProvider_personality()

# Generated at 2022-06-12 00:59:37.127805
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-12 00:59:44.308760
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider()
    assert p.personality() in range(1,10) or p.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-12 00:59:48.094933
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    int_value = 3
    str_value = 'INFJ'

    provider = USASpecProvider(seed=123)
    assert provider.personality() in int_value
    assert provider.personality('rheti') in int_value
    assert provider.personality('mbti') in str_value