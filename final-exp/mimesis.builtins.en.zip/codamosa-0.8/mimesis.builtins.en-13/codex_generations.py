

# Generated at 2022-06-12 00:58:52.681198
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert isinstance(usa_provider.personality(category='rheti'), int)

# Generated at 2022-06-12 00:59:01.770361
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    print('Method personality of class USASpecProvider test passed')
    for i in range(10000):
        if not USASpecProvider().personality() in mbtis:
            print('Failed')
            break
    if i == 9999:
        print('Passed')

# Generated at 2022-06-12 00:59:08.487103
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    en = USASpecProvider()
    assert len(en.personality(category='rheti')) <= 2
    assert en.personality() in \
               ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                'ISTP', 'ISFP', 'INFP', 'INTP',
                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')



# Generated at 2022-06-12 00:59:16.051789
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usp = USASpecProvider()
    assert usp.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usp.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-12 00:59:24.690407
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test USASpecProvider_personality."""
    usa = USASpecProvider()
    personality = usa.personality()
    assert personality in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                           'ISTP', 'ISFP', 'INFP', 'INTP',
                           'ESTP', 'ESFP', 'ENFP', 'ENTP',
                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

    personality = usa.personality(category='rheti')
    assert personality in list(range(1, 11))

# Generated at 2022-06-12 00:59:29.709805
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    result = usa.personality('mbti')
    assert type(result) == str
    result = usa.personality('rheti')
    assert type(result) == int


# Generated at 2022-06-12 00:59:31.961698
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()

    provider.personality()

    return True

# Generated at 2022-06-12 00:59:38.055936
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method .personality() of class USASpecProvider."""
    from mimesis.enums import Category
    from mimesis.providers.us import USASpecProvider as TestObj
    from mimesis.providers.us import MBTI

    provider = TestObj()
    result1 = provider.personality(Category.MBTI.value)
    result2 = provider.personality(Category.RHETI.value)
    assert result1 in MBTI
    assert isinstance(result2, int)
    assert result2 in range(1, 10)

# Generated at 2022-06-12 00:59:47.352823
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    sp = USASpecProvider()
    # print("Generate a type of personality :",sp.personality())
    # print("Generate a type of personality :",sp.personality(category = 'rheti'))
    # print("Generate a type of personality :",sp.personality(category = 'rheti'))
    # print("Generate a type of personality :",sp.personality(category = 'mbti'))
    # print("Generate a type of personality :",sp.personality(category = 'mbti'))
    # print("Generate a type of personality :",sp.personality(category = 'mbti'))


# Generated at 2022-06-12 00:59:53.687359
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    #create an object of class USASpecProvider to use later on
    u = USASpecProvider()

    #Generates a personality type of mbti
    mbti = u.personality()

    #Checks to see if the output is of type str.
    assert type(mbti) == str

    #Generates a personality type of rheti
    rheti = u.personality('rheti')
    assert type(rheti) == int
