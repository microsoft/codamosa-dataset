

# Generated at 2022-06-12 00:58:55.317384
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.personality("rheti") in range(1,11)
    assert usa_provider.personality("mbti") in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-12 00:59:02.269229
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality('rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-12 00:59:08.223277
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method USASpecProvider.personality()."""
    from mimesis import USASpecProvider
    from mimesis.enums import PersonalityCategory

    usa = USASpecProvider()
    for i in range(10):
        usa.personality(str(PersonalityCategory.MBTI))
    for i in range(10):
        usa.personality(str(PersonalityCategory.RHETI))

# Generated at 2022-06-12 00:59:10.904060
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider()

    assert p.personality() == 'ENTP'
    assert p.personality(category='rheti')  in range(1, 10)

# Generated at 2022-06-12 00:59:17.013481
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider.

    :return: None.
    :rtype: None
    """
    provider = USASpecProvider(seed=4747)
    assert provider.personality() == 'ISTJ'
    assert provider.personality() == 'ISFJ'
    assert provider.personality() == 'ISFP'
    assert provider.personality() == 'INTJ'
    assert provider.personality() == 'INFP'
    assert provider.personality() == 'INTP'
    assert provider.personality() == 'ISTP'
    assert provider.personality() == 'INFJ'
    assert provider.personality() == 'ESFP'
    assert provider.personality() == 'ENTP'
    assert provider.personality() == 'ENFP'

# Generated at 2022-06-12 00:59:24.258425
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    
    provider = USASpecProvider()
    assert (
        provider.personality()
        == provider.personality()
    )
    assert (
        provider.personality('mbti')
        == provider.personality('rheti')
    )
    assert (
        provider.personality('rheti')
        == provider.personality('mbti')
    )
    assert (
        provider.personality()
        != provider.personality()
    )


# Generated at 2022-06-12 00:59:27.707360
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='rheti')
    assert USASpecProvider().personality(category='mbti')

# Generated at 2022-06-12 00:59:29.144731
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert len(USASpecProvider().personality()) == 4

# Generated at 2022-06-12 00:59:34.170018
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider()
    # check if there is an error when the parameter is not given
    assert p.personality() != None
    assert p.personality('rheti') != None
    # check if the given parameter is a valid choice
    assert p.personality('mbti') != None
    assert p.personality('np') == None

# Generated at 2022-06-12 00:59:38.917803
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ',
                                      'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(provider.personality(category='rheti'), int)

