

# Generated at 2022-06-12 00:58:53.996409
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    import pytest

    provider = USASpecProvider()

    for x in range(1000):
        assert type(provider.personality()) == str

    assert provider.personality(category='MBTI') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                     'ISTP', 'ISFP', 'INFP', 'INTP',
                                                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert type(provider.personality(category='rheti')) == int
    assert 1 <= provider.personality(category='rheti') <= 10


# Generated at 2022-06-12 00:58:57.862337
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method for class USASpecProvider."""
    us = USASpecProvider()
    assert isinstance(us.personality(), str)
    assert isinstance(us.personality('rheti'), int)

# Generated at 2022-06-12 00:59:08.968923
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    import random as r
    import unittest.mock as mock
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    random_module = mock.MagicMock(spec_set=r)
    random_module.choice.return_value = 'ISFJ'
    random_module.randint.return_value = 8
    random_module.__name__ = 'random'

# Generated at 2022-06-12 00:59:12.467789
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test USASpecProvider.personality."""
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.personality('mbti'), str)

    assert isinstance(usa_provider.personality('rheti'), int)

# Generated at 2022-06-12 00:59:16.031706
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert (usa.personality() or 
            usa.personality(category='rheti'))
    # should not fail in any case
    return True

# Generated at 2022-06-12 00:59:18.099040
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    personality = USASpecProvider().personality()
    assert isinstance(personality, str)

# Generated at 2022-06-12 00:59:27.416726
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    
    # Values
    valores = []

    # Create an instance of class USASpecProvider
    usa_spec_provider = USASpecProvider()
    # Run the method personality of class USASpecProvider
    for i in range(1, 100):
        valor = usa_spec_provider.personality()
        valores.append(valor)

    print('Rheti test')
    print(valores)

    # Count the number of occurences of each value in the list
    unique_values, unique_counts = np.unique(valores, return_counts=True)
    print('Count of each value')
    print(unique_values)
    print(unique_counts)

    # Convert the list into a set
    valores_set = set(valores)

    # Run the method personality

# Generated at 2022-06-12 00:59:35.312169
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality(category="mbti") in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ') or\
           usa.personality(category="rheti") in range(1, 11)

# Generated at 2022-06-12 00:59:39.161283
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP',
                                          'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP',
                                          'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ',
                                          'ENTJ')

# Generated at 2022-06-12 00:59:46.503486
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality(category='Rheti') in range(1, 11)
    assert provider.personality(category='MBTI') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')