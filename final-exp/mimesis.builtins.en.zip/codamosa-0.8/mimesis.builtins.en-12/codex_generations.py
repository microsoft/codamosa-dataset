

# Generated at 2022-06-12 00:58:52.298409
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    person = USASpecProvider()

    assert person.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                   'ISTP', 'ISFP', 'INFP', 'INTP',
                                                   'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                   'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert person.personality(category='rheti') in range(1, 10)

    # Test default category

# Generated at 2022-06-12 00:58:56.832450
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    test_data = ['mbti', 'rheti']
    usp = USASpecProvider(seed=1)

    for test_cat in test_data:
        assert isinstance(usp.personality(category=test_cat), str)

# Generated at 2022-06-12 00:59:03.508765
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # dummy data
    assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert type(USASpecProvider().personality(category='rheti')) is int



# Generated at 2022-06-12 00:59:12.248157
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    usa_provider = USASpecProvider()
    mbti = usa_provider.personality(category='mbti')
    assert(mbti in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ',
    ])

    rh = usa_provider.personality(category='rheti')
    assert(rh in range(1, 11))



# Generated at 2022-06-12 00:59:18.983287
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-12 00:59:21.907209
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert isinstance(USASpecProvider().personality, str)
    assert len(USASpecProvider().personality) < 5


# Generated at 2022-06-12 00:59:26.013845
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    # Arrange
    provider = USASpecProvider()

    # Act
    result_mbti = provider.personality('mbti')

    # Assert
    assert result_mbti in (
        'INTJ', 'ISFJ', 'ISTJ', 'INFJ', 'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    )

    # Arrange
    provider = USASpecProvider()

    # Act
    result = provider.personality('rheti')

    # Assert
    assert isinstance(result, int) and (1 <= result <= 10)



# Generated at 2022-06-12 00:59:33.570632
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    assert USASpecProvider().personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                           'ISTP', 'ISFP', 'INFP', 'INTP',
                                                           'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-12 00:59:39.163205
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()

    assert us.personality('rheti') == 1
    assert isinstance(us.personality('rheti'), int)

    assert us.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(us.personality(), str)


# Generated at 2022-06-12 00:59:43.182620
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """
    Unit test for method personality of class USASpecProvider
    """
    assert len(USASpecProvider().personality()) >= 2
    assert USASpecProvider().personality(category='rheti') in range(1, 10)

