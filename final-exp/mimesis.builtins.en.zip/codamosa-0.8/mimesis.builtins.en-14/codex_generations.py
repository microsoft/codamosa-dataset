

# Generated at 2022-06-12 00:58:52.818129
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Tests personality method of USASpecProvider."""
    # USASpecProvider class doesn't have __init__ method
    # pylint: disable=no-value-for-parameter
    locale = 'en'
    usa_provider = USASpecProvider(locale)

    # ISFJ
    assert usa_provider.personality(category='mbti') == 'ISFJ'
    # 9
    assert usa_provider.personality(category='rheti') == 9
    assert isinstance(usa_provider.personality(category='rheti'), int)
    # ISFJ
    assert usa_provider.personality() == 'ISFJ'
    

# Generated at 2022-06-12 00:59:03.772193
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()

    # Test mbti personality
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    for i in range(100):
        assert provider.personality() in mbtis

    # Test rheti personality
    for i in range(100):
        assert type(provider.personality('Rheti')) is int
        assert provider.personality().lower() in ['rheti']
        assert 1 <= provider.personality('Rheti') <= 10

# Generated at 2022-06-12 00:59:09.908130
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-12 00:59:14.523482
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-12 00:59:25.608673
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    usa_personality_mbti = usa.personality(category='mbti')
    assert isinstance(usa_personality_mbti, str)

    usa_personality_rheti = usa.personality(category='rheti')
    assert isinstance(usa_personality_rheti, int)

    assert usa.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-12 00:59:36.653008
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    from mimesis.enums import Category
    from mimesis.builtins import USASpecProvider

    provider = USASpecProvider()

    result_1 = provider.personality(category=Category.WB.value)
    assert result_1 in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    result_2 = provider.personality(category=Category.MBTI.value)
    assert result_2 in \
        ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP',
         'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

    result

# Generated at 2022-06-12 00:59:48.122949
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider.

    Testing the following personality categories: mbti, RHETI.
    """
    # USASpecProvider.personality(category='mbti')
    for i in range(1,10):
        assert USASpecProvider().personality(category='mbti') in (
            'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
            'ISTP', 'ISFP', 'INFP', 'INTP',
            'ESTP', 'ESFP', 'ENFP', 'ENTP',
            'ESTJ', 'ESFJ', 'ENFP', 'ENTJ')

    # USASpecProvider.personality(category='rheti')

# Generated at 2022-06-12 00:59:58.631136
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    mbti_types = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                  'ISTP', 'ISFP', 'INFP', 'INTP',
                  'ESTP', 'ESFP', 'ENFP', 'ENTP',
                  'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.personality(), str)
    assert isinstance(usa_provider.personality(category='mbti'), str)
    assert isinstance(usa_provider.personality(category='rheti'), int)
    assert (usa_provider.personality() in mbti_types)
    assert (usa_provider.personality(category='mbti') in mbti_types)

# Generated at 2022-06-12 01:00:04.626006
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider()
    assert p.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                               'ISTP', 'ISFP', 'INFP', 'INTP',
                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')



# Generated at 2022-06-12 01:00:05.497626
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() != None