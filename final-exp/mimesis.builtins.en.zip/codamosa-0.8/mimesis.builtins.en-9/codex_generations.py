

# Generated at 2022-06-12 00:58:48.359329
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert 1 <= USASpecProvider().personality(category='rheti') <= 10



# Generated at 2022-06-12 00:58:53.526476
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-12 00:59:05.687416
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec = USASpecProvider(seed=4310)
    assert usa_spec.personality() == 'ENTJ'
    assert usa_spec.personality() == 'INTJ'
    assert usa_spec.personality('rheti') == 8
    assert usa_spec.personality('rheti') == 9
    assert usa_spec.personality('rheti') == 2
    assert usa_spec.personality('rheti') == 3
    assert usa_spec.personality('rheti') == 1
    assert usa_spec.personality('rheti') == 9
    assert usa_spec.personality('rheti') == 7
    assert usa_spec.personality('rheti') == 3

# Generated at 2022-06-12 00:59:11.040540
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    x = USASpecProvider()
    result = x.personality()
    assert result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-12 00:59:13.789441
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality('rheti') == (1, 10)
    assert usa_provider.personality('mbti') == 'ISFJ'


# Generated at 2022-06-12 00:59:16.031878
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    print(usa.personality())
    print(usa.personality())
    print(usa.personality())


# Generated at 2022-06-12 00:59:21.728020
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usas = USASpecProvider()
    assert isinstance(usas.rheti(), int)
    assert isinstance(usas.personality(), str)
    assert isinstance(usas.mbti(), str)


# Generated at 2022-06-12 00:59:23.658284
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider()
    print(p.personality())
    print(p.personality('rheti'))

# Generated at 2022-06-12 00:59:29.433373
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test the personality method of USASpecProvider."""
    provider = USASpecProvider('en')
    tests = (10)
    for _ in range(tests):
        result = provider.personality()
        assert len(result) == 4

# Generated at 2022-06-12 00:59:31.670372
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    rex = usa.personality()
    assert rex != None