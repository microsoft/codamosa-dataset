

# Generated at 2022-06-12 00:58:48.835792
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert(USASpecProvider().personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                     'ISTP', 'ISFP', 'INFP', 'INTP',
                                                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'))

# Generated at 2022-06-12 00:58:54.633179
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider(seed=None)
    assert p.personality(category='rheti') in range(1, 11)
    assert p.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                              'ISTP', 'ISFP', 'INFP', 'INTP',
                                              'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                              'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']


# Generated at 2022-06-12 00:59:05.986407
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from hypothesis import given, settings
    from hypothesis.strategies import text
    from .strategies import strategies

    settings.max_examples = 50

    @given(strategies.mbti_category_str)
    def test_mbti(category: str) -> None:
        provider = USASpecProvider()
        mbti = provider.personality(category=category)
        assert mbti in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                        'ISTP', 'ISFP', 'INFP', 'INTP',
                        'ESTP', 'ESFP', 'ENFP', 'ENTP',
                        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-12 00:59:12.709537
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    myprovider = USASpecProvider()
    assert myprovider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                        'ISTP', 'ISFP', 'INFP', 'INTP',
                                        'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert myprovider.personality('rheti') > 0
    assert myprovider.personality('rheti') < 11

# Generated at 2022-06-12 00:59:21.994365
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Method testing the personality."""
    us = USASpecProvider()
    mbti = us.personality()
    assert mbti in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    r = us.personality(category='rheti')
    assert 1 <= r <= 10



# Generated at 2022-06-12 00:59:25.690189
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test USASpecProvider.personality()."""
    usa_provider = USASpecProvider()

    assert usa_provider.personality() == 'ISFJ'
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_provider.personality(category='rheti') in range(1, 11)



# Generated at 2022-06-12 00:59:32.881106
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                       'ISTP', 'ISFP', 'INFP', 'INTP',
                                       'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                       'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-12 00:59:35.269684
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    result = provider.personality()
    print("Generate a type of personality: {}".format(result))
    assert result


# Generated at 2022-06-12 00:59:40.636452
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityType
    from mimesis.providers.usa.usa_provider import USASpecProvider

    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality(category=PersonalityType.MBTI) in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ',
    ]

    assert usa_spec_provider.personality(category=PersonalityType.RHETI) in range(1, 11)



# Generated at 2022-06-12 00:59:43.270272
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    prov = USASpecProvider(seed=123)
    print(prov.personality(category='rheti'))
    print(prov.personality(category='mbti'))