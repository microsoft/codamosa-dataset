

# Generated at 2022-06-12 00:58:44.354817
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert isinstance(provider.personality(), str)
    assert isinstance(provider.personality('rheti'), int)



# Generated at 2022-06-12 00:58:54.343491
# Unit test for method personality of class USASpecProvider

# Generated at 2022-06-12 00:58:57.908572
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    for i in range(10):
        assert len(USASpecProvider().personality(category='mbti')) in (2, 4)
        assert 1 <= USASpecProvider().personality(category='rheti') <= 10

# Generated at 2022-06-12 00:59:05.072631
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert type(usa.personality('rheti')) == int


# Generated at 2022-06-12 00:59:11.528191
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()

    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert 1 <= usa_provider.personality('rheti') <= 10

# Generated at 2022-06-12 00:59:16.083083
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    up = USASpecProvider()
    for i in range(0, 10):
        got = up.personality()
        assert (isinstance(got, str))
    for i in range(0, 10):
        got = up.personality('rheti')
        assert (isinstance(got, int))


# Generated at 2022-06-12 00:59:19.735619
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    value = USASpecProvider.personality()
    assert value != None
    assert value != ""
    assert isinstance(value, str) == True
    assert len(value) >= 3


# Generated at 2022-06-12 00:59:23.658836
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider"""
    p = USASpecProvider()
    assert p.personality() != None
    assert p.personality() != None
    assert p.personality() != None


# Generated at 2022-06-12 00:59:32.967983
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in "ISFJ ISTJ INFJ INTJ ISTP ISFP INFP INTP ESTP ESFP ENFP ENTP ESTJ ESFJ ENFJ ENTJ"
    assert provider.personality("rheti") in range(1,11)
    assert provider.personality("mbti") in "ISFJ ISTJ INFJ INTJ ISTP ISFP INFP INTP ESTP ESFP ENFP ENTP ESTJ ESFJ ENFJ ENTJ"

# Generated at 2022-06-12 00:59:36.391985
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
