

# Generated at 2022-06-12 00:58:52.716873
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    created_provider = USASpecProvider()
    assert created_provider.personality() in [1,2,3,4,5,6,7,8,9,10,
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-12 00:58:55.056196
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() == 'ISFJ'


# Generated at 2022-06-12 00:59:03.093196
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    result = usa_spec_provider.personality()
    assert result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    result = usa_spec_provider.personality('rheti')
    assert result in [i for i in range(1, 11)]



# Generated at 2022-06-12 00:59:05.693022
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert isinstance(provider.personality(), str)


# Generated at 2022-06-12 00:59:12.746453
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    pr=USASpecProvider()
    assert pr.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert pr.personality(category='rheti') in (1,2,3,4,5,6,7,8,9,10)
    
    

# Generated at 2022-06-12 00:59:21.993954
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    test_provider = USASpecProvider()
    assert test_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(test_provider.personality(category='rheti'), int)
    assert test_provider.personality(category='rheti') in range(1, 10)

# Generated at 2022-06-12 00:59:26.783372
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaspp = USASpecProvider()
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert usaspp.personality() in mbtis


# Generated at 2022-06-12 00:59:36.038411
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.builtins import USASpecProvider as USASpecProvider_
    from mimesis.enums import PersonalityType
    usa_spec_provider = USASpecProvider_()
    personality_type = usa_spec_provider.personality(category=PersonalityType.MBTI)
    assert personality_type in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']


# Generated at 2022-06-12 00:59:42.118796
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()

    assert provider.personality() == 'ISFJ'
    assert provider.personality('mbti') == 'ISFJ'
    assert provider.personality('MBTI') == 'ISFJ'
    assert provider.personality('rheti') in range(0, 10)

# Generated at 2022-06-12 00:59:47.481639
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    c = USASpecProvider()
    res = c.personality()
    assert res in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                   'ISTP', 'ISFP', 'INFP', 'INTP',
                   'ESTP', 'ESFP', 'ENFP', 'ENTP',
                   'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

