

# Generated at 2022-06-12 00:58:55.359955
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    '''
    Unit test for method personality of class USASpecProvider.

    :return:
    '''
    us_spec_provider = USASpecProvider()
    mbti_personality_type = us_spec_provider.personality()
    print("The MBTI Personality Type is : ", mbti_personality_type)
    print("Is the MBTI Personality Type a string? :", isinstance(mbti_personality_type, str))

# Generated at 2022-06-12 00:59:03.050841
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """
    Unit test for method personality of class USASpecProvider
    """
    usa_spec_provider = USASpecProvider()
    for i in range(10):
        assert usa_spec_provider.personality() in (
            'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
            'ISTP', 'ISFP', 'INFP', 'INTP',
            'ESTP', 'ESFP', 'ENFP', 'ENTP',
            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
        )

# Generated at 2022-06-12 00:59:06.647107
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    usa_spec_provider.personality(category='mbti')
    usa_spec_provider.personality(category='rheti')

# Generated at 2022-06-12 00:59:08.533907
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='rheti') in range(1, 10)



# Generated at 2022-06-12 00:59:16.113009
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p1 = USASpecProvider().personality('mbti')
    p2 = USASpecProvider().personality('rheti')
    assert p1 in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                  'ISTP', 'ISFP', 'INFP', 'INTP',
                  'ESTP', 'ESFP', 'ENFP', 'ENTP',
                  'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(p2, int)

# Generated at 2022-06-12 00:59:19.773620
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
   provider = USASpecProvider(seed=2)

   assert provider.personality(category='mbti') == 'INTJ'
   assert provider.personality(category='rheti') == 8


# Generated at 2022-06-12 00:59:26.644455
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality(category='rheti') in range(1, 11)
    assert usa_provider.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']


# Generated at 2022-06-12 00:59:33.237649
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Given
    provider = USASpecProvider()

    # When
    result = provider.personality()

    # Then
    assert result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-12 00:59:37.636435
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Testing for personnality by using doctest."""
    from mimesis.enums import Personality
    from mimesis.providers.usa import USASpecProvider

    usa_provider = USASpecProvider()
    usa_provider.personality(Personality.MBTI.value)
    usa_provider.personality(Personality.RHETI.value)


# Generated at 2022-06-12 00:59:47.099967
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa.personality(category='rheti'), int)
    assert usa.personality(category='rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)