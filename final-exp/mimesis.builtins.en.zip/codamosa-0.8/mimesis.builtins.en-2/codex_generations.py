

# Generated at 2022-06-12 00:58:52.003392
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    result = provider.personality(category='mbti')
    assert result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-12 00:58:55.301455
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    up = USASpecProvider()

    assert up.personality(category='mbti') in up._data['usa_provider']['mbtis']

# Generated at 2022-06-12 00:59:05.362283
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    
    usaspecprovider = USASpecProvider(seed=123)
    for i in range(100):
        assert usaspecprovider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    for i in range(100):
        assert usaspecprovider.personality(category='rheti') in (1,2,3,4,5,6,7,8,9,10)

# Generated at 2022-06-12 00:59:14.378251
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Check for a predicted results for method personality.
    """
    provider = USASpecProvider()
    # predict for mbti result
    assert provider.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                            'ISTP', 'ISFP', 'INFP', 'INTP',
                                            'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    # predict for mbti result in lowercase

# Generated at 2022-06-12 00:59:22.078542
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()

    assert us.personality("mbti") in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP',
        'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    ]
    assert isinstance(us.personality("rheti"), int)



# Generated at 2022-06-12 00:59:23.183393
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test the method personality of class USASpecProvider"""
    test = USASpecProvider()
    assert len(test.personality()) == 4
    assert isinstance(test.personality('rheti'), int)

# Generated at 2022-06-12 00:59:35.869800
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider(seed=123).personality(category='rheti') == 9
    assert USASpecProvider(seed=234).personality(category='rheti') == 7
    assert USASpecProvider(seed=345).personality(category='rheti') == 5
    assert USASpecProvider(seed=456).personality(category='rheti') == 7
    assert USASpecProvider(seed=567).personality(category='rheti') == 8
    assert USASpecProvider(seed=678).personality(category='rheti') == 1
    assert USASpecProvider(seed=789).personality(category='rheti') == 7
    assert USASpecProvider(seed=890).personality(category='rheti') == 7
    assert USASpecProvider(seed=901).personality

# Generated at 2022-06-12 00:59:47.659321
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()

    assert provider.personality('rheti') in range(1, 10)
    assert provider.personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert provider.personality('mbti') != provider.personality('mbti')
    assert provider.personality('mbti') != provider.personality('mbti')
    assert provider.personality('mbti') != provider.personality('mbti')
    assert provider.personality('mbti') != provider.personality('mbti')

# Generated at 2022-06-12 00:59:53.973783
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    # Test MBTI personality category.
    up = USASpecProvider()
    mbti = up.personality()
    assert mbti is not None
    assert isinstance(mbti, str)

    # Test Rheti personality category.
    up = USASpecProvider()
    rheti = up.personality(category='rheti')
    assert rheti is not None
    assert isinstance(rheti, int)

# Generated at 2022-06-12 01:00:00.437260
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality('whatever') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert provider.personality('rheti') in list(range(1,11))