

# Generated at 2022-06-12 00:58:44.356172
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    obj = USASpecProvider()
    result = obj.personality()
    print(result)


# Generated at 2022-06-12 00:58:54.313999
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    from mimesis.providers.personality import Personality
    from mimesis.providers.personality.en import PersonalityEn
    from mimesis.builtins.usa import USASpecProvider
    from mimesis.enums import Category

    us_provider_personality_mbti: Union[Personality, USASpecProvider] = USASpecProvider(seed=123456)

    assert us_provider_personality_mbti.personality(category='mbti') == 'ISTJ'
    assert us_provider_personality_mbti.personality(category=Category.MBTI) == 'ISTJ'
    assert us_provider_personality_mbti.personality(category='rheti') == 2

    us_provider_personality_rheti: Union[PersonalityEn, USASpecProvider] = US

# Generated at 2022-06-12 00:58:58.271487
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    result = provider.personality(category='mbti')
    assert isinstance(result, str)

    result = provider.personality(category='rheti')
    assert isinstance(result, int)

# Generated at 2022-06-12 00:59:00.013646
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
	uObj = USASpecProvider()
	uObj.personality('rheti')

# Generated at 2022-06-12 00:59:05.647009
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality("mbti") in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                     'ISTP', 'ISFP', 'INFP', 'INTP',
                                                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-12 00:59:09.464428
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    result = provider.personality()
    result1 = provider.personality('mbti')
    assert result == result1
    result = provider.personality('rheti')
    assert result >= 1 and result <= 10


# Generated at 2022-06-12 00:59:11.893033
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    print(us.personality('mbti'))

    print(us.personality('rheti'))


# Generated at 2022-06-12 00:59:15.262011
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider(seed=12345678)
    assert provider.personality(category='mbti') == 'ISFJ'
    assert provider.personality(category='rheti') == 7

# Generated at 2022-06-12 00:59:26.191493
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality."""
    usa = USASpecProvider()
    for i in range(100):
        mbti = usa.personality()
        if mbti not in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                        'ISTP', 'ISFP', 'INFP', 'INTP',
                        'ESTP', 'ESFP', 'ENFP', 'ENTP',
                        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'):
            raise AssertionError('Wrong result.')

    for i in range(100):
        retic = usa.personality(category='rheti')
        if not isinstance(retic, int):
            raise AssertionError('Wrong result.')


# Generated at 2022-06-12 00:59:29.665553
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality('mbti') != None or provider.personality('rheti') != None or None
