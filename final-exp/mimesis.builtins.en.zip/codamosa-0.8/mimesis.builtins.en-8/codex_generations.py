

# Generated at 2022-06-12 00:58:53.139629
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test: USASpecProvider.personality()"""
    provider = USASpecProvider()
    assert provider.personality() in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    ]
    assert provider.personality('rheti') in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


# Generated at 2022-06-12 00:59:02.969852
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    import pytest
    
    p = USASpecProvider()
    assert p.personality() in (
        "ISFJ", "ISTJ", "INFJ", "INTJ",
        "ISTP", "ISFP", "INFP", "INTP",
        "ESTP", "ESFP", "ENFP", "ENTP",
        "ESTJ", "ESFJ", "ENFJ", "ENTJ"
    )
    assert isinstance(p.personality("rheti"), int)
    with pytest.raises(ValueError) as exc:
        p.personality("unsupported_category")
    assert "Unsupported category" in str(exc)


# Generated at 2022-06-12 00:59:13.338382
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """
    This method tests if the method personality returns the
    personality index for `rheti` category, otherwise a
    valid MBTI personality type, ignoring the case.
    """
    spec_provider = USASpecProvider(seed=1234)
    assert(spec_provider.personality('rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
    assert(spec_provider.personality('MBTI') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'))

# Unit test

# Generated at 2022-06-12 00:59:21.148413
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    x = USASpecProvider(seed='apple')
    assert x.personality(category='rheti') > 0 and x.personality(category='rheti') < 11
    assert x.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-12 00:59:23.658905
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert type(USASpecProvider().personality()) == str
    assert type(USASpecProvider().personality('rheti')) == int



# Generated at 2022-06-12 00:59:29.800837
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider(seed=123)
    assert provider.personality() == 'ESFP'
    assert provider.personality(category='rheti') == 8
    assert provider.personality(category='mbti') == 'ESFP'


# Generated at 2022-06-12 00:59:36.692713
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    result_mbti = usa.personality()
    assert isinstance(result_mbti, str)
    assert len(result_mbti) == 4
    assert result_mbti in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-12 00:59:40.436715
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    assert us.personality('mbti') != None

# Generated at 2022-06-12 00:59:49.005757
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='rheti')
    assert USASpecProvider().personality(category='rheti')
    assert USASpecProvider().personality(category='rheti')
    assert USASpecProvider().personality(category='rheti')
    assert USASpecProvider().personality(category='rheti')
    assert USASpecProvider().personality(category='rheti')
    assert USASpecProvider().personality(category='rheti')
    assert USASpecProvider().personality(category='rheti')
    assert USASpecProvider().personality(category='rheti')
    assert USASpecProvider().personality(category='rheti')
    assert USASpecProvider().personality(category='rheti')

# Generated at 2022-06-12 00:59:56.554722
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider"""
    from mimesis.enums import Category
    provider = USASpecProvider()
    assert provider.personality(Category.MBTI) in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert 0 < provider.personality(Category.RHETI) < 11