

# Generated at 2022-06-25 19:42:40.581292
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider(seed=4060)
    assert str(u_s_a_spec_provider_0.personality()) == 'INFJ'
    assert str(u_s_a_spec_provider_0.personality('mbti')) == 'INFJ'
    assert str(u_s_a_spec_provider_0.personality('rheti')) == '3'


# Generated at 2022-06-25 19:42:42.726040
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider = USASpecProvider()
    assert len(u_s_a_spec_provider.personality()) == 4


# Generated at 2022-06-25 19:42:48.411963
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    category_0 = 'rheti'
    u_s_a_spec_provider_0.random.seed(0)
    assert u_s_a_spec_provider_0.personality(category_0) == 9
    category_1 = 'mbti'
    u_s_a_spec_provider_0.random.seed(0)
    assert u_s_a_spec_provider_0.personality(category_1) == 'ESTP'


# Generated at 2022-06-25 19:42:51.397839
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    personality_0 = u_s_a_spec_provider_0.personality(category = "")
    assert personality_0 in (int, str)


# Generated at 2022-06-25 19:42:57.036094
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_0 = u_s_a_spec_provider_0.personality()
    assert str_0 not in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']


# Generated at 2022-06-25 19:43:04.780380
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Setup input arguments for this unit test
    category_0: str = 'rheti'

    # Calculate expected result
    expected_result_0: int = u_s_a_spec_provider_0.random.randint(1, 10)

    # Calculate actual result
    actual_result_0: Union[str, int] = u_s_a_spec_provider_0.personality(category_0)

    # Compare actual result with expected result
    assert actual_result_0 == expected_result_0


# Generated at 2022-06-25 19:43:15.579381
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Create a list of expected outcomes.
    expected_outputs = [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ', 'ESTP', 'ESFP', 'ENFP', 'ENTP'
    ]
    # Create a generator for a set of 1000 inputs.
    inputs = (str(i % 8) for i in range(1000))
    # Create a list of outputs from a list of inputs.
    outputs = [USASpecProvider().personality(i) for i in inputs]
    # Assert that the all of the outputs are in the expected outputs.
    assert all([o in expected_outputs for o in outputs])

# Generated at 2022-06-25 19:43:20.095332
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert isinstance(u_s_a_spec_provider_0.personality(), str)


# Generated at 2022-06-25 19:43:23.285289
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider_0 = USASpecProvider(seed=0)
    assert isinstance(
        usa_spec_provider_0.personality(), str
    )


# Generated at 2022-06-25 19:43:29.343470
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    print("Testing method personality of class USASpecProvider")
    u_s_a_spec_provider_1 = USASpecProvider()
    # Test 1
    category = "rheti"
    personality = u_s_a_spec_provider_1.personality(category)
    print("The following personality is of type Rheti:", personality)
    assert(type(personality) == type(1))
    # Test 2
    category = "mbti"
    personality = u_s_a_spec_provider_1.personality(category)
    print("The following personality is of type MBTI:", personality)
    assert(type(personality) == type(""))
