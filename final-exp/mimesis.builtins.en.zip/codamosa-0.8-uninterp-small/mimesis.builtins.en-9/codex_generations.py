

# Generated at 2022-06-25 19:42:36.217435
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    for i in range(10):
        assert isinstance(u_s_a_spec_provider_0.personality(), str)
    for i in range(10):
        assert isinstance(u_s_a_spec_provider_0.personality(
            'rheti'), int)


# Generated at 2022-06-25 19:42:46.604212
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()

# Generated at 2022-06-25 19:42:51.646003
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ['ISTJ', 'ISFJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']



# Generated at 2022-06-25 19:42:59.230392
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    u_s_a_spec_provider_1 = USASpecProvider(seed=1)
    assert type(u_s_a_spec_provider_0.personality()) == str
    assert type(u_s_a_spec_provider_1.personality()) == str
    assert u_s_a_spec_provider_0.personality() == 'ESTJ'
    assert u_s_a_spec_provider_1.personality() == 'ISFP'
    assert type(u_s_a_spec_provider_0.personality(category='rheti')) == int
    assert type(u_s_a_spec_provider_1.personality(category='rheti')) == int
   

# Generated at 2022-06-25 19:43:02.242236
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider = USASpecProvider()
    assert len(u_s_a_spec_provider.personality()) > 2


# Generated at 2022-06-25 19:43:05.413550
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    # Test case with argument value:None.
    assert u_s_a_spec_provider_0.personality(category=None) in [4, 10, 14, 12, 15, 1, 5, 8, 9, 11, 6, 7, 13, 2, 16, 3]


# Generated at 2022-06-25 19:43:13.075609
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider(seed=42).personality('rheti') in [5, 1, 6, 9, 4, 10, 8, 7, 3, 2]
    assert USASpecProvider(seed=42).personality('mbti') in ['INTP', 'INFJ', 'ESTJ', 'ISTJ', 'ENTP', 'ESTP', 'ISFP', 'ENFP', 'ESFP', 'ESFJ']



# Generated at 2022-06-25 19:43:17.042752
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert u_s_a_spec_provider_0.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'], "Failed to unit test method personality of class USASpecProvider"


# Generated at 2022-06-25 19:43:19.897331
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider(seed=0)
    assert u_s_a_spec_provider_0.personality() in ('INFP', 'ENTP', 'INFJ', 'ESFJ', 'ISTJ', 'ESTJ', 'ISTP', 'ISFP', 'ENTJ', 'ENFJ', 'ESFP', 'ISFJ', 'INTJ', 'ENFP', 'ESTP', 'INTP')


# Generated at 2022-06-25 19:43:23.285314
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    actual_value_0 = u_s_a_spec_provider_0.personality()

