

# Generated at 2022-06-25 19:42:37.109051
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_0 = u_s_a_spec_provider_0.personality()


# Generated at 2022-06-25 19:42:41.421873
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider = USASpecProvider()
    str_0 = u_s_a_spec_provider.personality()


# Generated at 2022-06-25 19:42:47.393072
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    result = provider.personality(category='mbti')
    assert isinstance(result, str)  # make sure method returns a value of type string
    if result.lower() not in ('istp', 'istj', 'isfj', 'isfp', 'intp', 'intj',
                              'infp', 'infj', 'esfp', 'estp', 'estj', 'esfj',
                              'enfj', 'entj', 'enfp', 'entp'):
        raise AssertionError

# Generated at 2022-06-25 19:42:52.603380
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert(USASpecProvider().personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'])
    assert(USASpecProvider().personality(category='rheti') in range(1, 11))

# Generated at 2022-06-25 19:42:55.249027
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_1 = USASpecProvider()
    res_1 = u_s_a_spec_provider_1.personality()


# Generated at 2022-06-25 19:42:57.468913
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_0 = u_s_a_spec_provider_0.personality()
    print(str_0)


# Generated at 2022-06-25 19:43:00.869643
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider_1 = USASpecProvider()
    assert isinstance(usa_spec_provider_1.personality(), str)


# Generated at 2022-06-25 19:43:05.414354
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    u_s_a_spec_provider_0.random = RandGen(Int.random(1, 3))
    u_s_a_spec_provider_0.personality(u_s_a_spec_provider_0.random.choice(
        list_0))


# Generated at 2022-06-25 19:43:08.780795
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider_0 = USASpecProvider()
    str_0 = usa_spec_provider_0.personality()
    assert type(str_0) is str


# Generated at 2022-06-25 19:43:14.144668
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Set up objects for testing
    u_s_a_spec_provider_0 = USASpecProvider()
    str_0 = u_s_a_spec_provider_0.personality()
    # Assert that the generated personality is one of the 16 mbti types
    assert(str_0 in ["ISFJ", "ISTJ", "INFJ", "INTJ", "ISTP", "ISFP", "INFP", "INTP", "ESTP", "ESFP", "ENFP", "ENTP", "ESTJ", "ESFJ", "ENFJ", "ENTJ"])

