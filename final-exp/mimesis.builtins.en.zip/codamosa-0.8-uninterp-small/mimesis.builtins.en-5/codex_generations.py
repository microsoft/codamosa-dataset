

# Generated at 2022-06-25 19:42:42.559724
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    s = u_s_a_spec_provider_0.personality()
    assert isinstance(s, str)


# Generated at 2022-06-25 19:42:44.803453
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert isinstance(str(u_s_a_spec_provider_0.personality()), str)

# Generated at 2022-06-25 19:42:50.878616
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    personality_arguments = ['mbti', 'rheti']
    u_s_a_spec_provider_0 = USASpecProvider()
    integer_types = (int, long)
    try:
        to_test = u_s_a_spec_provider_0.personality(category='mbti')
        to_test_1 = u_s_a_spec_provider_0.personality(category='rheti')
    except:
        raise AssertionError("Did not pass for argument: " + "category = 'mbti'")

    try:
        assert isinstance(to_test, str) == True
    except:
        raise AssertionError("Did not pass for argument: " + "category = 'mbti'")


# Generated at 2022-06-25 19:42:53.545842
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert u_s_a_spec_provider_0.personality() == u_s_a_spec_provider_0.personality()


# Generated at 2022-06-25 19:43:00.159702
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    import inspect
    import random
    method_name = 'personality'
    method = eval('USASpecProvider().' + method_name)
    arg_count = len(inspect.getfullargspec(method).args)
    args = []
    if arg_count >= 1:
        args.append(random.choice(
            ['INFJ', 'ENTP', 'ISTP', 'ENTJ', 'ISFP', 'ENFJ', 'ESFJ',
             'INTP', 'ESTP', 'ESTJ', 'ISFJ', 'ESFP', 'ENFP', 'INTJ',
             'INFP', 'ISTJ']))
    ret = method(*args)
    assert ret is not None and len(ret) > 0


# Generated at 2022-06-25 19:43:04.093486
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_1 = USASpecProvider()
    param0 = 'rheti'
    result = u_s_a_spec_provider_1.personality(param0)
    assert result >= 1
    assert result <= 10


# Generated at 2022-06-25 19:43:10.505158
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    
    personality_types = ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

    type = USASpecProvider().personality()

    assert isinstance(type, str)

    assert type in personality_types


# Generated at 2022-06-25 19:43:13.153282
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    result = u_s_a_spec_provider_0.personality('rheti')
    assert result in range(1, 11)


# Generated at 2022-06-25 19:43:19.014303
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    u_s_a_spec_provider_0.seed(0)
    assert_match(u_s_a_spec_provider_0.personality(), "ENTJ")
    assert_match(u_s_a_spec_provider_0.personality(), "ENTJ")
    assert_match(u_s_a_spec_provider_0.personality(), "ENTJ")
    u_s_a_spec_provider_0.seed(1)
    assert_match(u_s_a_spec_provider_0.personality(), "ENFJ")
    assert_match(u_s_a_spec_provider_0.personality(), "ESFJ")

# Generated at 2022-06-25 19:43:27.915708
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider_0 = USASpecProvider()