

# Generated at 2022-06-25 19:42:35.373450
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_1 = USASpecProvider()
    s = u_s_a_spec_provider_1.personality()
    assert s



# Generated at 2022-06-25 19:42:42.595544
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert u_s_a_spec_provider_0.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                   'ISTP', 'ISFP', 'INFP', 'INTP',
                                                   'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                   'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-25 19:42:45.443666
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    result = u_s_a_spec_provider_0.personality()
    assert type(result) in (str, int)


# Generated at 2022-06-25 19:42:49.677292
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    try:
        assert USASpecProvider().personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    except AssertionError:
        raise AssertionError("Failed testing method personality")


# Generated at 2022-06-25 19:42:52.566839
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_0 = u_s_a_spec_provider_0.personality('rheti')


# Generated at 2022-06-25 19:42:57.503086
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import Personality
    from mimesis.providers.person import Person
    from mimesis.providers import Gender
    from mimesis.providers.person.en import USASpecProvider

    u_s_a_spec_provider_2 = USASpecProvider()
    assert u_s_a_spec_provider_2.personality(Personality.MBTI) in Person.MBTI.value


# Generated at 2022-06-25 19:43:02.082640
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    result = u_s_a_spec_provider_0.personality(category='rheti')
    assert type(result) == int and 1 <= result <= 10


# Generated at 2022-06-25 19:43:06.016524
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    personality_type_str_0 = u_s_a_spec_provider_0.personality('Rheti')
    personality_type_str_1 = u_s_a_spec_provider_0.personality()



# Generated at 2022-06-25 19:43:12.630722
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    types = ('mbti', 'rheti')
    assert u_s_a_spec_provider_0.personality(category=u_s_a_spec_provider_0.random.choice(types))


# Generated at 2022-06-25 19:43:17.482808
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Case 1
    personality_1 = USASpecProvider().personality(category="rheti")
    assert isinstance(personality_1, int)
    assert personality_1 in range (1, 11)

    # Case 2
    personality_2 = USASpecProvider().personality(category="mbti")
    assert isinstance(personality_2, str)
    assert personality_2 in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')