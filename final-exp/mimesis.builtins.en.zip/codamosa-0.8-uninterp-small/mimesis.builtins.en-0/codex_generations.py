

# Generated at 2022-06-25 19:42:44.435667
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_1 = USASpecProvider()
    u_s_a_spec_provider_1.random.seed(0)
    assert type(u_s_a_spec_provider_1.personality()) is str
    assert type(u_s_a_spec_provider_1.personality(category="rheti")) is int
    assert u_s_a_spec_provider_1.personality(category="rheti") in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-25 19:42:46.947155
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert u_s_a_spec_provider_0.personality().isalpha() == True


# Generated at 2022-06-25 19:42:56.465126
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider(seed=0)
    category_0 = 'mbti'
    value_0 = u_s_a_spec_provider_0.personality(category=category_0)

    category_1 = 'rheti'
    value_1 = u_s_a_spec_provider_0.personality(category=category_1)

    category_2 = 'mbti'
    value_2 = u_s_a_spec_provider_0.personality(category=category_2)

    category_3 = 'rheti'
    value_3 = u_s_a_spec_provider_0.personality(category=category_3)

    category_4 = 'mbti'
    value_4 = u_s_a_

# Generated at 2022-06-25 19:43:04.597900
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    # assert
    assert len(u_s_a_spec_provider_0.personality()) == 4
    assert len(u_s_a_spec_provider_0.personality("mbti")) == 4
    assert (isinstance(USASpecProvider().personality(), str))
    assert (isinstance(USASpecProvider().personality("rheti"), int))
    assert (isinstance(USASpecProvider().personality("mbti"), str))

# Generated at 2022-06-25 19:43:11.469827
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_ = USASpecProvider()
    assert isinstance(usa_.personality(), str)
    assert isinstance(usa_.personality('mbti'), str)
    assert isinstance(usa_.personality('rheti'), int)
    assert isinstance(usa_.personality('rheti'), int)


# Generated at 2022-06-25 19:43:17.758908
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    test_0 = USASpecProvider()

    true_result_0 = test_0.personality(category='rheti')
    true_result_1 = test_0.personality(category='rheti')
    true_result_2 = test_0.personality(category='rheti')
    true_result_3 = test_0.personality(category='mbti')
    true_result_4 = test_0.personality(category='mbti')

    assert true_result_0 in range(1, 10)
    assert true_result_1 in range(1, 10)
    assert true_result_2 in range(1, 10)

# Generated at 2022-06-25 19:43:23.313137
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    result = u_s_a_spec_provider_0.personality(category='rheti')
    assert isinstance(result, int)
    assert 1 <= result <= 10
    result = u_s_a_spec_provider_0.personality()
    assert isinstance(result, str)
    assert result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-25 19:43:30.421811
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    category_a = u_s_a_spec_provider_0.personality()
    assert category_a in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ') or 1 <= category_a <= 10


# Generated at 2022-06-25 19:43:40.934628
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    personality = ((None, 'None'), (None, 'None'), (None, 'None'))
    personality_0 = u_s_a_spec_provider_0.personality()
    personality_1 = u_s_a_spec_provider_0.personality('rheti')
    personality_2 = u_s_a_spec_provider_0.personality('Rheti')
    if personality_0 not in personality:
        raise Exception("Expected {}, got {}".format(personality, personality_0))

    if personality_1 not in range(1, 11):
        raise Exception("Expected {}, got {}".format(range(1, 11), personality_1))


# Generated at 2022-06-25 19:43:45.145707
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Mock
    u_s_a_spec_provider_0 = USASpecProvider()
    category = ''
    ret_val_0 = u_s_a_spec_provider_0.personality(category)
    assert isinstance(ret_val_0, str) or isinstance(ret_val_0, int)
