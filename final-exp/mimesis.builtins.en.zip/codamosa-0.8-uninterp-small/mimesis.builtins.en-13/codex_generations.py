

# Generated at 2022-06-25 19:42:40.225207
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # You can add your own tests here.
    # Code below will run unittest, which will print any errors.
    from mimesis.providers.usa.usa_provider import USASpecProvider
    u_s_a_spec_provider_0 = USASpecProvider()
    result = u_s_a_spec_provider_0.personality(category='rheti')
    # You can also add your own test cases here and they will be run
    # with unittest
    assert result >= 1


# Generated at 2022-06-25 19:42:43.773253
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider = USASpecProvider()
    assert isinstance(u_s_a_spec_provider.personality(), str) is True
    assert isinstance(u_s_a_spec_provider.personality('rheti'), int) is True


# Generated at 2022-06-25 19:42:50.464137
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_0 = u_s_a_spec_provider_0.personality(category='rheti')
    str_1 = u_s_a_spec_provider_0.personality(category='rheti')
    str_2 = u_s_a_spec_provider_0.personality(category='rheti')
    str_3 = u_s_a_spec_provider_0.personality(category='rheti')
    str_4 = u_s_a_spec_provider_0.personality(category='rheti')
    str_5 = u_s_a_spec_provider_0.personality(category='rheti')
    str_6 = u_s_a_

# Generated at 2022-06-25 19:42:53.063948
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert len(u_s_a_spec_provider_0.personality()) > 0


# Generated at 2022-06-25 19:42:54.082202
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert len(USASpecProvider().personality()) == 4


# Generated at 2022-06-25 19:42:57.237255
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_1 = USASpecProvider()
    assert isinstance(
        u_s_a_spec_provider_1.personality(), str
    )



# Generated at 2022-06-25 19:43:02.406528
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider = USASpecProvider(seed=12345)
    assert u_s_a_spec_provider.personality('rheti') == 1
    assert u_s_a_spec_provider.personality('mbti') == 'ENFJ'


# Generated at 2022-06-25 19:43:11.359939
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    for _ in range(10000):
        assert u_s_a_spec_provider_0.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    for _ in range(10000):
        assert isinstance(u_s_a_spec_provider_0.personality(category='rheti'), int)
    assert isinstance(USASpecProvider().personality(category='rheti'), int)
    assert USASpecProvider().personality(category='rheti')

# Generated at 2022-06-25 19:43:16.874195
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider = USASpecProvider()
    u_s_a_spec_provider_0 = USASpecProvider()
    u_s_a_spec_provider_0.seed(123)

    assert isinstance(u_s_a_spec_provider_0.personality(), str)
    u_s_a_spec_provider_0.personality('rheti')
    assert isinstance(u_s_a_spec_provider.personality(), str)
    assert isinstance(u_s_a_spec_provider_0.personality(), str)


# Generated at 2022-06-25 19:43:23.247775
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()