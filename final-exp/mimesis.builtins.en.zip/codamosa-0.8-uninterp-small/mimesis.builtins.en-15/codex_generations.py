

# Generated at 2022-06-25 19:42:42.823259
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    # Category: INFJ
    assert u_s_a_spec_provider_0.personality() == 'INFJ'
    # Category: ENTJ
    assert u_s_a_spec_provider_0.personality() == 'ENTJ'
    # Category: ISFP
    assert u_s_a_spec_provider_0.personality() == 'ISFP'
    # Category: ISTP
    assert u_s_a_spec_provider_0.personality() == 'ISTP'
    # Category: ENFJ
    assert u_s_a_spec_provider_0.personality() == 'ENFJ'
    # Category: ESTJ
    assert u_s_a_spec_provider_0

# Generated at 2022-06-25 19:42:45.862619
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    if u_s_a_spec_provider_0.personality() == u_s_a_spec_provider_0.personality():
        pass



# Generated at 2022-06-25 19:42:50.708541
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_result = u_s_a_spec_provider_0.personality()
    bool_result = isinstance(str_result, str)
    assert bool_result is True


# Generated at 2022-06-25 19:42:53.753870
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_0 = u_s_a_spec_provider_0.personality(category="rheti")
    assert get_types(str_0) == 0


# Generated at 2022-06-25 19:43:00.739342
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    # assert u_s_a_spec_provider_0.personality() in ('ESFJ', 'ISTP', 'ISFJ', 'ESTP', 'ENFJ', 'INFJ', 'ESTJ', 'ESFP', 'ISFP', 'ENFP', 'ENTP', 'ENTJ', 'INTP', 'INFP', 'ISTJ', 'INTJ')
    u_s_a_spec_provider_1 = USASpecProvider()
    # assert u_s_a_spec_provider_1.personality() in ('ESFJ', 'ISTP', 'ISFJ', 'ESTP', 'ENFJ', 'INFJ', 'ESTJ', 'ESFP', 'ISFP', 'ENFP', 'ENTP', 'ENT

# Generated at 2022-06-25 19:43:06.428350
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in [
        'ISFJ',
        'ISTJ',
        'INFJ',
        'INTJ',
        'ISTP',
        'ISFP',
        'INFP',
        'INTP',
        'ESTP',
        'ESFP',
        'ENFP',
        'ENTP',
        'ESTJ',
        'ESFJ',
        'ENFJ',
        'ENTJ',
    ]



# Generated at 2022-06-25 19:43:14.791310
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='rheti') in list(range(1, 10))
    assert USASpecProvider().personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                              'ISTP', 'ISFP', 'INFP', 'INTP',
                                                              'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                              'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-25 19:43:26.196717
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    mbti_result = u_s_a_spec_provider_0.personality('mbti')
    print (mbti_result)
    assert mbti_result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    rhte_result = u_s_a_spec_provider_0.personality('rhte')
    print(rhte_result)
    assert 0 < rhte_result <= 10


# Generated at 2022-06-25 19:43:31.342840
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_1 = u_s_a_spec_provider_0.personality(category='mbti')
    str_2 = u_s_a_spec_provider_0.personality(category='Rheti')


# Generated at 2022-06-25 19:43:34.794242
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    category = 'MBTI'
    value = u_s_a_spec_provider_0.personality(category)
    print(value)

