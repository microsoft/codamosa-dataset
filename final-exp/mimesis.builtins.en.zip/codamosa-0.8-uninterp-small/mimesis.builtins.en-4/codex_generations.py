

# Generated at 2022-06-25 19:42:48.543272
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    # Test case 0
    u_s_a_spec_provider_0 = USASpecProvider()
    assert isinstance(u_s_a_spec_provider_0.personality(), str)
    assert u_s_a_spec_provider_0.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(u_s_a_spec_provider_0.personality(category='rheti'), int)
    assert u_s_a_spec_provider_0.personality(category='rheti') in range(1,11)

# Generated at 2022-06-25 19:42:53.376975
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_0 = u_s_a_spec_provider_0.personality(category='rheti')
    str_1 = u_s_a_spec_provider_0.personality(category='rheti')
    assert str_0 == str_1
    assert not (str_0 != str_1)


# Generated at 2022-06-25 19:42:57.969873
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    obj = USASpecProvider()
    result = obj.personality()
    assert result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ') or (1 <= result <= 10)

# Generated at 2022-06-25 19:43:02.164277
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.personality(), str)
    assert isinstance(usa_provider.personality(category='rheti'), int)

# Generated at 2022-06-25 19:43:04.748190
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert u_s_a_spec_provider_0.personality(category='rheti') == 7


# Generated at 2022-06-25 19:43:15.795094
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    u_s_a_spec_provider_0_personality_0 = u_s_a_spec_provider_0.personality()
    assert type(u_s_a_spec_provider_0_personality_0) is str
    u_s_a_spec_provider_0_personality_1 = u_s_a_spec_provider_0.personality()
    assert type(u_s_a_spec_provider_0_personality_1) is str
    u_s_a_spec_provider_0_personality_2 = u_s_a_spec_provider_0.personality()

# Generated at 2022-06-25 19:43:19.206213
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    ssn = USASpecProvider().personality(category='rheti')
    assert ssn >= 1 and ssn <= 10


# Generated at 2022-06-25 19:43:23.590379
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    t_p_y_d_u_i_c_0 = u_s_a_spec_provider_0.personality()
    pass


# Generated at 2022-06-25 19:43:27.666438
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider = USASpecProvider()
    u_s_a_spec_provider_1 = USASpecProvider()
    assert isinstance(u_s_a_spec_provider.personality(), str)
    assert isinstance(u_s_a_spec_provider_1.personality('rheti'), int)


# Generated at 2022-06-25 19:43:34.114101
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert u_s_a_spec_provider_0.personality() in ['INTJ', 'ENTJ', 'INFJ', 'ENFJ', 'INTP', 'ENTP', 'INFP', 'ENFP', 'ISTJ', 'ESTJ', 'ISFJ', 'ESFJ', 'ISTP', 'ESTP', 'ISFP', 'ESFP']
