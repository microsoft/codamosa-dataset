

# Generated at 2022-06-25 19:42:42.693880
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider = USASpecProvider()  # type: USASpecProvider
    # Category
    assert isinstance(u_s_a_spec_provider.personality(category='mbti'), str)
    assert isinstance(u_s_a_spec_provider.personality(category='rheti'), int)


# Generated at 2022-06-25 19:42:49.799802
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    u_s_a_spec_provider_1 = USASpecProvider()
    assert (u_s_a_spec_provider_0.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')) == True

# Generated at 2022-06-25 19:42:53.753633
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    
    # Call method personality of u_s_a_spec_provider_0
    category = 'rheti'
    result = u_s_a_spec_provider_0.personality(category=category)
    assert isinstance(result, int)

# Generated at 2022-06-25 19:42:57.337545
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Arrange
    u_s_a_spec_provider_0 = USASpecProvider()

    # Act
    result_0 = u_s_a_spec_provider_0.personality()

    # Assert
    assert result_0 is not None


# Generated at 2022-06-25 19:43:01.526637
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_2 = USASpecProvider()
    result = u_s_a_spec_provider_2.personality()
    assert type(result) == str or int


# Generated at 2022-06-25 19:43:05.593702
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider_0 = USASpecProvider(seed=0)
    result = usa_spec_provider_0.personality(category='rheti')

    assert result == 10
    assert isinstance(result, int)

    usa_spec_provider_1 = USASpecProvider(seed=1)
    result = usa_spec_provider_1.personality()

    assert result == 'ISFP'
    assert isinstance(result, str)



# Generated at 2022-06-25 19:43:12.324694
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']


# Generated at 2022-06-25 19:43:14.666402
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert isinstance(u_s_a_spec_provider_0.personality(), str)


# Generated at 2022-06-25 19:43:16.386533
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_1 = USASpecProvider()
    category = 'mbti'
    personality = u_s_a_spec_provider_1.personality(category)


# Generated at 2022-06-25 19:43:22.431826
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP',
        'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
