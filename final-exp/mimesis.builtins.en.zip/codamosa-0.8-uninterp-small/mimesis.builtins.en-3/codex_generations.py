

# Generated at 2022-06-25 19:42:40.828625
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider(seed=174739)
    str_0 = 'mbti'
    str_1 = u_s_a_spec_provider_0.personality(category=str_0)
    assert type(str_1) == str
    assert str_1 == 'ENTJ'


# Generated at 2022-06-25 19:42:43.355155
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_0 = u_s_a_spec_provider_0.personality()
    assert str_0 == 'ESFJ'

# Generated at 2022-06-25 19:42:50.123293
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_0 = u_s_a_spec_provider_0.personality(
        u_s_a_spec_provider_0.random.choice(
            ('mbti', 'rheti', 'rheti', 'rheti', 'rheti', 'mbti'),
    ))

# Generated at 2022-06-25 19:42:55.293250
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_0 = u_s_a_spec_provider_0.personality()
    str_1 = u_s_a_spec_provider_0.personality(category="mbti")
    str_2 = u_s_a_spec_provider_0.personality(category="rheti")


# Generated at 2022-06-25 19:42:56.965466
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    personality_0 = USASpecProvider.personality(USASpecProvider())

    assert personality_0 != None


# Generated at 2022-06-25 19:43:08.497386
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    int_0 = 4
    int_1 = 68
    str_0 = u_s_a_spec_provider_0.personality()
    assert str_0 == 'ISFJ'
    int_2 = 9
    int_3 = 87
    str_1 = u_s_a_spec_provider_0.personality()
    assert str_1 == 'ISFJ'
    int_4 = 3
    int_5 = 90
    str_2 = u_s_a_spec_provider_0.personality()
    assert str_2 == 'ISFJ'
    int_6 = 2
    int_7 = 49
    str_3 = u_s_a_spec_provider_0.personality()

# Generated at 2022-06-25 19:43:16.540526
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()

# Generated at 2022-06-25 19:43:25.074380
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    u_s_a_spec_provider_0.random.seed(str(524))

    str_0 = u_s_a_spec_provider_0.personality(category="Rheti")
    assert str_0 == 8
    assert type(str_0) is int

    str_0 = u_s_a_spec_provider_0.personality(category="MBTI")
    assert str_0 == "INFP"
    assert type(str_0) is str


# Generated at 2022-06-25 19:43:30.356847
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_0 = 'INTJ'
    str_1 = u_s_a_spec_provider_0.personality()
    str_2 = 'ISTJ'
    str_3 = u_s_a_spec_provider_0.personality()
    str_4 = 'ISFJ'
    str_5 = u_s_a_spec_provider_0.personality()
    str_6 = 'INFJ'
    str_7 = u_s_a_spec_provider_0.personality()
    str_8 = 'ISTP'
    str_9 = u_s_a_spec_provider_0.personality()
    str_10 = 'ISFP'
    str_11 = u_

# Generated at 2022-06-25 19:43:32.926293
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider = USASpecProvider()
    str_0 = 'rheti'
