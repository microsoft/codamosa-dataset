

# Generated at 2022-06-25 19:42:36.407158
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']


# Generated at 2022-06-25 19:42:46.813910
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    # result_0 = u_s_a_spec_provider_0.personality()  # Should match: "ISFJ" or "ISTJ" or "INFJ" or "INTJ" or "ISTP" or "ISFP" or "INFP" or "INTP" or "ESTP" or "ESFP" or "ENFP" or "ENTP" or "ESTJ" or "ESFJ" or "ENFJ" or "ENTJ"

# Generated at 2022-06-25 19:42:53.649897
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    result = u_s_a_spec_provider_0.personality('mbti')
    assert result is not None
    assert isinstance(result, str)
    assert result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-25 19:42:59.429686
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_1 = USASpecProvider()
    assert u_s_a_spec_provider_1.personality() in [
        'ISFJ',
        'ISTJ',
        'INFJ',
        'INTJ',
        'ISTP',
        'ISFP',
        'INFP',
        'INTP',
        'ESTP',
        'ESFP',
        'ENFP',
        'ENTP',
        'ESTJ',
        'ESFJ',
        'ENFJ',
        'ENTJ'
    ]


# Generated at 2022-06-25 19:43:09.705034
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    u_s_a_spec_provider_0_personality_0 = u_s_a_spec_provider_0.personality()
    u_s_a_spec_provider_0_personality_1 = u_s_a_spec_provider_0.personality('mbti')
    assert (len(u_s_a_spec_provider_0_personality_0) >= 1)
    assert (len(u_s_a_spec_provider_0_personality_0) <= 5)
    assert (len(u_s_a_spec_provider_0_personality_0)) in (4, 5)

# Generated at 2022-06-25 19:43:14.536421
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider = USASpecProvider()
    result = u_s_a_spec_provider.personality()
    assert result in ('ISTJ', 'INTJ', 'INTP', 'ISFJ', 'INFJ', 'INFP', 'ISTJ', 'ISTP', 'ISFP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-25 19:43:17.094985
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Expected result:
    expected_0 = 'ESTJ'

    # Execution:
    u_s_a_spec_provider_0 = USASpecProvider()
    actual_0 = u_s_a_spec_provider_0.personality()

    # Verification:
    assert expected_0 == actual_0


# Generated at 2022-06-25 19:43:17.878395
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
  assert type(USASpecProvider().personality()) is str


# Generated at 2022-06-25 19:43:22.005071
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    # Unit test for method personality of class USASpecProvider
    # The category must be one of 'mbti' or 'rheti'.
    value_0 = u_s_a_spec_provider_0.personality(category='mbti')
    value_1 = u_s_a_spec_provider_0.personality(category='mbti')
    assert value_0 == value_1
    assert value_1 != u_s_a_spec_provider_0.personality(category='mbti')

# Generated at 2022-06-25 19:43:27.804067
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()

    # Check if method will return a personality type from list
    assert u_s_a_spec_provider_0.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-25 19:43:38.461117
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() == 'ISFJ' or 'INFP'
    assert USASpecProvider().personality() == 'ISFJ' or 'INFP'


# Generated at 2022-06-25 19:43:46.967899
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert u_s_a_spec_provider_0.personality(category='mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-25 19:43:51.002124
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider(seed=0)
    result = u_s_a_spec_provider_0.personality(category='rheti')
    assert result == 2


# Generated at 2022-06-25 19:44:00.320499
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    # Variable declaration
    mbtis: list[str]

    # Assign values
    mbtis = ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

    u_s_a_spec_provider_0 = USASpecProvider()
    result = u_s_a_spec_provider_0.personality()
    assert result in mbtis

    u_s_a_spec_provider_1 = USASpecProvider()
    result = u_s_a_spec_provider_1.personality()
    assert result in mbtis

    u_s_a_spec

# Generated at 2022-06-25 19:44:04.454903
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    k = USASpecProvider()
    assert k.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                       'ISTP', 'ISFP', 'INFP', 'INTP',
                                       'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                       'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']


# Generated at 2022-06-25 19:44:05.220167
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    test_case_0()


# Generated at 2022-06-25 19:44:12.069192
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import Category

    u_s_a_spec_provider_0 = USASpecProvider()
    u_s_a_spec_provider_1 = USASpecProvider(seed=12345)
    u_s_a_spec_provider_2 = USASpecProvider(seed=12345)
    assert isinstance(u_s_a_spec_provider_0.personality(
                        Category.PERSONALITY), str)
    assert isinstance(u_s_a_spec_provider_0.personality(), str)
    assert isinstance(u_s_a_spec_provider_1.personality(
                        Category.PERSONALITY), str)
    assert isinstance(u_s_a_spec_provider_1.personality(), str)
    assert isinstance

# Generated at 2022-06-25 19:44:15.750337
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    str_out_0 = u_s_a_spec_provider_0.personality(category='rheti')
    str_out_1 = u_s_a_spec_provider_0.personality(category='mbti')


# Generated at 2022-06-25 19:44:23.278309
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    result = u_s_a_spec_provider_0.personality()
    assert result == 'ISFJ' or result == 'ISTJ' or result == 'INFJ' or result == 'INTJ' or result == 'ISTP' or result == 'ISFP' or result == 'INFP' or result == 'INTP' or result == 'ESTP' or result == 'ESFP' or result == 'ENFP' or result == 'ENTP' or result == 'ESTJ' or result == 'ESFJ' or result == 'ENFJ' or result == 'ENTJ'


# Generated at 2022-06-25 19:44:29.265025
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    iters = [
        ('mbti',),
    ]
    for i in range(20000):
        for args in iters:
            result_0 = u_s_a_spec_provider_0.personality(*args)
            result_1 = u_s_a_spec_provider_0.personality(*args)
            assert isinstance(result_0, str) or isinstance(result_0, int)
            assert isinstance(result_1, str) or isinstance(result_1, int)
