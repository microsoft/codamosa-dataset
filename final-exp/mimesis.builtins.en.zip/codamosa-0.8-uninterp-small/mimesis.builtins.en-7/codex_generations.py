

# Generated at 2022-06-25 19:42:36.217461
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    for _ in range(100):
        assert len(USASpecProvider().personality('mbti')) == 4

    for _ in range(100):
        assert type(USASpecProvider().personality('rheti')) == int



# Generated at 2022-06-25 19:42:37.225718
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert type(USASpecProvider().personality()) is str


# Generated at 2022-06-25 19:42:42.597385
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0_0 = USASpecProvider()
    personality_0 = u_s_a_spec_provider_0_0.personality('rheti')
    assert personality_0 in range(1, 11)


# Generated at 2022-06-25 19:42:44.270383
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert isinstance(usa.personality(), str)


# Generated at 2022-06-25 19:42:46.813813
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert isinstance(u_s_a_spec_provider_0.personality(), str)


# Generated at 2022-06-25 19:42:50.772418
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    assert u_s_a_spec_provider_0.personality() == 'ISFJ' or u_s_a_spec_provider_0.personality() == 1


# Generated at 2022-06-25 19:42:58.769265
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    set_of_str_0 = set({})
    # Loop 1001 times
    for i in range(1001):
        # Init. random.randint to avoid duplication
        random.seed(i)
        str_0 = u_s_a_spec_provider_0.personality(category="")
        set_of_str_0.add(str_0)
    # Assert set size is 16, for ISFJ, ISTJ, INFJ, INTJ, ISTP, ISFP, INFP, INTP, ESTP, ESFP, ENFP, ENTP, ESTJ, ESFJ, ENFJ, ENTJ,
    assert 16 == len(set_of_str_0)


# Generated at 2022-06-25 19:43:04.022377
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()

    obj0 = 'mbti'
    obj1 = u_s_a_spec_provider_0.personality(obj0)

    obj2 = 'rheti'
    obj3 = u_s_a_spec_provider_0.personality(obj2)


# Generated at 2022-06-25 19:43:10.362736
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.typing import AnyStr
    from mimesis.enums import Gender
    from mimesis.builtins import USASpecProvider
    us_a_spec_provider = USASpecProvider()
    ed = us_a_spec_provider.personality("rheti")
    assert(isinstance(ed, int))
    ed = us_a_spec_provider.personality("mbti")
    assert(isinstance(ed, AnyStr))

# Generated at 2022-06-25 19:43:13.813474
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    print(u_s_a_spec_provider_0.personality())
    print(u_s_a_spec_provider_0.personality(category='rheti'))
