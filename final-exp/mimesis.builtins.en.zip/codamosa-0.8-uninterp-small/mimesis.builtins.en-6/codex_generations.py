

# Generated at 2022-06-25 19:42:44.578544
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'] or (1 <= USASpecProvider().personality() <= 10)


# Generated at 2022-06-25 19:42:50.741888
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    u_s_a_spec_provider_1 = USASpecProvider()
    u_s_a_spec_provider_2 = USASpecProvider()
    u_s_a_spec_provider_3 = USASpecProvider()
    u_s_a_spec_provider_4 = USASpecProvider()
    u_s_a_spec_provider_5 = USASpecProvider()
    u_s_a_spec_provider_6 = USASpecProvider()
    u_s_a_spec_provider_7 = USASpecProvider()
    u_s_a_spec_provider_8 = USASpecProvider()
    u_s_a_spec_provider_9 = USASpecProvider()

# Generated at 2022-06-25 19:42:57.680474
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    ret_9 = u_s_a_spec_provider_0.personality()
    ret_10 = u_s_a_spec_provider_0.personality()
    ret_11 = u_s_a_spec_provider_0.personality()
    assert type(ret_9) == str
    assert type(ret_10) == str
    assert type(ret_11) == str
    assert ret_9 != ret_10
    assert ret_10 != ret_11
    assert ret_9 != ret_11



# Generated at 2022-06-25 19:43:01.566030
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    # ISFJ
    assert u_s_a_spec_provider_0.personality() == "ISFJ"


# Generated at 2022-06-25 19:43:04.690033
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-25 19:43:09.814257
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    result_0 = u_s_a_spec_provider_0.personality(category="rheti")
    assert result_0 in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


# Generated at 2022-06-25 19:43:16.786969
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    u_s_a_spec_provider_1 = USASpecProvider()

    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    if u_s_a_spec_provider_0.personality(category='mbti') in mbtis and \
        u_s_a_spec_provider_0.personality(category='rheti') in range(1, 11):
        pass
    else:
        raise ValueError('ValueError raised')

   

# Generated at 2022-06-25 19:43:27.232799
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()
    
    # Test case 0

# Generated at 2022-06-25 19:43:32.747832
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.providers.personality import Personality
    personality = Personality('en')
    u_s_a_spec_provider_0 = USASpecProvider()
    it = list(set([u_s_a_spec_provider_0.personality() for _ in range(100)]))
    assert len(it) == len(personality.mbti())


# Generated at 2022-06-25 19:43:38.648734
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    u_s_a_spec_provider_0 = USASpecProvider()

    assert isinstance(u_s_a_spec_provider_0.personality('mbti'), str)
    assert isinstance(u_s_a_spec_provider_0.personality('rheti'), int)
