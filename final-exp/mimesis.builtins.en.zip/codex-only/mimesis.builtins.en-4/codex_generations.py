

# Generated at 2022-06-23 20:24:58.600852
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    import cl_dungeon.mimesis_ext.usa_provider
    usa_provider = cl_dungeon.mimesis_ext.usa_provider.USASpecProvider('test')
    assert usa_provider.tracking_number() == usa_provider.tracking_number()
    assert usa_provider.tracking_number('fedex') == usa_provider.tracking_number('fedex')
    assert usa_provider.tracking_number('ups') == usa_provider.tracking_number('ups')
    assert usa_provider.tracking_number() != usa_provider.tracking_number('fedex')
    assert usa_provider.tracking_number() != usa_provider.tracking_number('ups')

# Generated at 2022-06-23 20:25:02.596078
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    usa_provider = USASpecProvider()
    ssn = usa_provider.ssn()
    assert '-' in ssn and len(ssn) == 11


# Generated at 2022-06-23 20:25:07.370018
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number() == '1231 5294 5199 9556 6716'
    assert provider.tracking_number() == 'DG 557 687 650 US'
    assert provider.tracking_number() == '2713 8675 4392'
    assert provider.tracking_number() == '0497 8734 2349 985'
    # assert provider.tracking_number() == '1ZC726A63766046958'


# Generated at 2022-06-23 20:25:10.120877
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    result = usa.tracking_number('usps')
    assert result is not None


# Generated at 2022-06-23 20:25:12.570042
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()

    # Test class, size
    assert(provider.__class__.__name__ == 'USASpecProvider')
    assert(provider.size() == 656)


# Generated at 2022-06-23 20:25:14.774029
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method ssn of class USASpecProvider."""
    assert USASpecProvider().ssn()


# Generated at 2022-06-23 20:25:16.336791
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    name_of_class = 'USASpecProvider'
    obj = globals()[name_of_class]()
    assert obj.__class__.__name__ == name_of_class


# Generated at 2022-06-23 20:25:18.311661
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider, USASpecProvider)


# Generated at 2022-06-23 20:25:19.759981
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    test = USASpecProvider()
    assert isinstance(test.personality('MBTI'), str)

# Generated at 2022-06-23 20:25:20.979618
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa


# Generated at 2022-06-23 20:25:26.971244
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
	usas = USASpecProvider('zh-CN')
	para = usas.random.randint(1, 10)
	print(usas.tracking_number(para))
	print(usas.ssn())
	print(usas.personality())

# Generated at 2022-06-23 20:25:29.314875
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """This function is unit test for method ssn of class USASpecProvider."""
    test = USASpecProvider()
    # print(test.ssn())



# Generated at 2022-06-23 20:25:31.206337
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider('ru')
    x = us.ssn()
    assert isinstance(x, str)

# Generated at 2022-06-23 20:25:33.671460
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number(service='usps') == '0210 5407 9058 8460 4497'


# Generated at 2022-06-23 20:25:37.431998
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality('rheti') in range(1, 10)
    assert USASpecProvider().personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                     'ISTP', 'ISFP', 'INFP', 'INTP',
                                                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:25:39.552080
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider"""
    print("%s: Running unit test for class USASpecProvider" % __file__)

    sp = USASpecProvider()
    assert isinstance(sp, USASpecProvider)

    print("SUCCESS")


# Generated at 2022-06-23 20:25:45.731272
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality('mbti') in {
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    }

# Generated at 2022-06-23 20:25:49.316674
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_sp = USASpecProvider()
    assert usa_sp.tracking_number() is not None


# Generated at 2022-06-23 20:25:51.570762
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider()
    result = us.ssn()
    assert len(result) == 11
    assert result.find('-') != -1


# Generated at 2022-06-23 20:25:57.210011
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test the method ssn of class USASpecProvider."""
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn) == 11 and ssn[0:3].isdigit() and ssn[3] == '-' and \
           ssn[4:6].isdigit() and ssn[6] == '-' and \
           ssn[7:11].isdigit() and ssn[0:3] != '666'

# Generated at 2022-06-23 20:25:59.738913
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn) == 11
    assert isinstance(ssn, str)

# Generated at 2022-06-23 20:26:01.385467
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    assert isinstance(usa.ssn(), str)


# Generated at 2022-06-23 20:26:02.947530
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    ussp = USASpecProvider()
    ussp = USASpecProvider(seed='new seed')


# Generated at 2022-06-23 20:26:06.897287
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11
    assert len(USASpecProvider().ssn(seed=12).split('-')) == 3

# Generated at 2022-06-23 20:26:12.911201
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usp = USASpecProvider()
    ssn = usp.ssn()
    assert len(ssn) == 11
    first_part, second_part, third_part = ssn.split('-')
    assert len(first_part) == 3
    assert len(second_part) == 2
    assert len(third_part) == 4
    assert int(first_part) < 900
    assert int(first_part) != 666
    assert int(second_part) < 100
    assert int(third_part) < 10000


# Generated at 2022-06-23 20:26:16.563475
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert isinstance(provider.ssn(), str)
    assert len(provider.ssn()) == 11
    assert provider.ssn().count('-') == 2

# Generated at 2022-06-23 20:26:25.948478
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method tracking_number.

    Case 1: Default.
    Case 2: One of the supported services.
    Case 3: Not supported service.
    """
    test_cases = [
        ('', True),
        ('usps', True),
        ('fEDEx', True),
        ('UPS', True),
        ('post office', False),
    ]
    for case in test_cases:
        if case[1]:
            assert USASpecProvider().tracking_number(case[0]) != ''
        else:
            try:
                USASpecProvider().tracking_number(case[0])
            except ValueError:
                assert True
            else:
                assert False


# Generated at 2022-06-23 20:26:28.312159
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    provider = USASpecProvider(seed=10)
    assert provider.ssn() == '568-73-6024'


# Generated at 2022-06-23 20:26:30.378882
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test USASpecProvider."""
    assert USASpecProvider.Meta.name == 'usa_provider'
    assert isinstance(USASpecProvider(), USASpecProvider)


# Generated at 2022-06-23 20:26:36.404281
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() == 'ENTP' or 'ENTJ' or 'ENFJ' or 'ENFP' or 'ESFJ' or 'ESFP' or 'ESFJ' or 'ESTJ' or 'ISFJ' or 'ISFP' or 'INFP' or 'INFJ' or 'INTP' or 'INTJ'

# Generated at 2022-06-23 20:26:38.705255
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_p = USASpecProvider()
    assert usa_p() == ''


# Generated at 2022-06-23 20:26:40.599489
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider().__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:26:44.429271
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Tests for the constructor of class USASpecProvider"""

    provider = USASpecProvider()

    assert 'USA' in provider.__dict__['provider_name']
    assert 'en' == provider.__dict__['locale']


# Generated at 2022-06-23 20:26:46.214495
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method tracking_number of class USASpecProvider."""
    usa = USASpecProvider()
    tracking_number = usa.tracking_number()
    assert isinstance(tracking_number, str)



# Generated at 2022-06-23 20:26:48.373355
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    s = USASpecProvider(seed=1)

    assert s.ssn() == '282-14-3883'



# Generated at 2022-06-23 20:26:51.194576
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    a = USASpecProvider().ssn()  # => '363-19-9273'
    print(a)

if __name__ == "__main__":
    test_USASpecProvider_ssn()

# Generated at 2022-06-23 20:26:57.111143
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """istj, isfj, infj, intj, istp, isfp, infp, intp, estp, esfp, enfp, entp, estj, esfj, enfj, entj"""

    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:27:05.755665
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
  usa_provider = USASpecProvider()
  usa_provider.seed(0)

  assert usa_provider.tracking_number() == '3125 2682 5074'
  assert usa_provider.tracking_number() == '4371 7808 6237'
  assert usa_provider.tracking_number() == '9040 1136 9751'
  assert usa_provider.tracking_number() == '2278 4683 5809 3127'
  assert usa_provider.tracking_number() == '1Z016E0A0233503122'


# Generated at 2022-06-23 20:27:06.512729
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider() is not None


# Generated at 2022-06-23 20:27:07.720285
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider() is not None


# Generated at 2022-06-23 20:27:12.002378
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    
    usa = USASpecProvider()
    assert usa.ssn() != None, 'Method ssn of class USASpecProvider failed to return a value.'


# Generated at 2022-06-23 20:27:12.586642
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    pass

# Generated at 2022-06-23 20:27:16.930024
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    usa.seed(1)
    assert usa.personality('mbti') == 'INFJ'
    assert usa.personality('rheti') == 8
    assert usa.personality() == 'INFJ'
    assert usa.personality('mbti') == 'ENFJ'


# Generated at 2022-06-23 20:27:21.194958
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert isinstance(usa_spec_provider.personality(), str)
    assert len(usa_spec_provider.personality()) == 4
    assert isinstance(usa_spec_provider.personality(category='rheti'), int)
    assert usa_spec_provider.personality('rheti') in range(1, 11)


# Generated at 2022-06-23 20:27:24.737631
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking_number = provider.tracking_number(service='USPS')
    assert tracking_number is not None


# Generated at 2022-06-23 20:27:27.373799
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    for i in range(10):
        print(usa.tracking_number())


# Generated at 2022-06-23 20:27:30.987382
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method USASpecProvider.ssn."""
    provider = USASpecProvider(seed=12345)
    ssn = provider.ssn()
    assert ssn == '928-02-8674'



# Generated at 2022-06-23 20:27:37.105364
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider(seed=None)
    assert usa.ssn() == '982-24-7597'
    assert usa.tracking_number(service='usps') == '3238 7775 2770 3071 5938'
    assert usa.tracking_number(service='fedex') == '9483 9834 9868'
    assert usa.tracking_number(service='ups') == '1Z404056W133687370'
    assert usa.personality('mbti') == 'ESFP'
    assert usa.personality('rheti') == 7

# Generated at 2022-06-23 20:27:40.611986
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print('Testing USASpecProvider:')
    bs = USASpecProvider().provider
    assert bs is not None


# Generated at 2022-06-23 20:27:47.629802
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.name import Name
    from mimesis.providers.code import Code
    from mimesis.providers.internet import Internet
    from mimesis.providers.phone import Phone
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.text import Text
    from mimesis.providers.misc import Misc
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person

    ssn = USASpecProvider()

# Generated at 2022-06-23 20:27:49.097906
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider(seed=5)
    value = provider.ssn()
    assert str(value) == '881-73-1570'

# Generated at 2022-06-23 20:27:56.139335
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    p = USASpecProvider('en')
    assert p.tracking_number('usps') == '1Z03452Y8024886839'
    assert p.tracking_number('usps') == '910961420077907339'
    assert p.tracking_number('usps') == '910550193877052684'
    assert p.tracking_number('usps') == '940551089069597130'
    assert p.tracking_number('usps') == 'LN735235814US'
    assert p.tracking_number('usps') == '8409921263US'
    assert p.tracking_number('fedex') == '7787337618'
    assert p.tracking_number('fedex') == '1659453063'

# Generated at 2022-06-23 20:28:03.936972
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number(service = 'usps') == '5910 0203 1052 7705 4994'
    assert usa_provider.tracking_number(service = 'usps') == '12 394 061 016 US'
    assert usa_provider.tracking_number(service = 'fedex') == '8351 7398 1452'
    assert usa_provider.tracking_number(service = 'fedex') == '2405 2434 5640 703'
    assert usa_provider.tracking_number(service = 'ups') == '1Z0015A89697360249'


# Generated at 2022-06-23 20:28:07.533483
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    gen = USASpecProvider(seed=42)
    ssn = gen.ssn()
    assert ssn == '571-32-8268'

# Generated at 2022-06-23 20:28:17.672425
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method ssn of class USASpecProvider."""

    usssn = USASpecProvider()
    retrieved_ssn = usssn.ssn()
    assert isinstance(retrieved_ssn, str) and len(retrieved_ssn) == 11
    assert retrieved_ssn[0:3].isdigit() and retrieved_ssn[0:3] not in ['666']
    assert retrieved_ssn[4:5] == '-' and retrieved_ssn[4:6].isdigit()
    assert retrieved_ssn[7:9] == '-' and retrieved_ssn[7:11].isdigit()


# Generated at 2022-06-23 20:28:20.192072
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    '''
    Testing function ssn() of class USASpecProvider
    '''
    obj = USASpecProvider()
    assert len(obj.ssn()) == 11


# Generated at 2022-06-23 20:28:28.411261
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usasp = USASpecProvider()
    assert usasp.tracking_number('usps') == '0889 6159 8918 2385 8193', 'Wrong value'
    assert usasp.tracking_number('ups') == '1Z2850AW8254297435', 'Wrong value'
    assert usasp.tracking_number('fedex') == '1047 3453 6535', 'Wrong value'
    try:
        usasp.tracking_number('dhl')
    except ValueError:
        assert True
    else:
        assert False, "DHL should raise ValueError"


# Generated at 2022-06-23 20:28:29.394576
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    x = USASpecProvider()

    assert len(str(x.ssn())) == 11

# Generated at 2022-06-23 20:28:30.915961
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender

    p = USASpecProvider()
    assert p._gender == Gender.ALL
    assert p.__class__.__name__ == "USASpecProvider"


# Generated at 2022-06-23 20:28:33.765115
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number() != provider.tracking_number()



# Generated at 2022-06-23 20:28:38.976897
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test for constructor of class USASpecProvider"""
    with USASpecProvider.seed(42):
        usa_spec_provider = USASpecProvider()
        assert usa_spec_provider is not None
        assert usa_spec_provider._random_generator._seed == 42


# Generated at 2022-06-23 20:28:43.198192
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider(seed=12345)
    assert provider.provider == "usa_provider"
    assert provider.locale == "en"
    assert provider.locales == {
        'region': 'US',
        'language': 'en',
    }
    assert provider.random.seed == 12345



# Generated at 2022-06-23 20:28:45.863148
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()


    assert provider.tracking_number('usps')

    assert provider.tracking_number('fedex')

    assert provider.tracking_number('ups')

# Generated at 2022-06-23 20:28:50.926055
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for generation of social security number.

    :returns: void

    :Example:
        >>> from mimesis.enums import Gender
        >>> from mimesis.providers.us_providers import USASpecProvider
        >>> person = USASpecProvider(seed=12345)
        >>> person.ssn()
        '505-99-4276'
    """

# Generated at 2022-06-23 20:28:54.643075
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider_usa = USASpecProvider()
    assert provider_usa.tracking_number() == '9X1Z 8UMB KAG8 YJYU 2KG'


# Generated at 2022-06-23 20:28:57.633293
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    spec = USASpecProvider()
    ssn = spec.ssn()
    assert isinstance(ssn, str)
    assert len(ssn) == 11
    print(ssn)


# Generated at 2022-06-23 20:29:04.735880
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usaspec = USASpecProvider()
    assert usaspec is not None
    assert (usaspec.personality() in {'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                     'ISTP', 'ISFP', 'INFP', 'INTP',
                                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'})
    assert type(usaspec.personality(category='rheti')) == int
    assert (usaspec.tracking_number() in {'#### #### #### #### ####',
                                          '@@ ### ### ### US'})
    assert type(usaspec.ssn()) == str


# Generated at 2022-06-23 20:29:13.085800
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    prov = USASpecProvider()
    assert prov.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                  'ISTP', 'ISFP', 'INFP', 'INTP',
                                  'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                  'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert prov.personality(category="rheti") in (1,2,3,4,5,6,7,8,9,10)

    prov_f = USASpecProvider(seed=1)
    assert prov_f.personality() == 'INTJ'
    assert prov_f.personality(category="rheti") == 8


# Generated at 2022-06-23 20:29:19.471752
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                             'ISTP', 'ISFP', 'INFP', 'INTP',
                                             'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')



# Generated at 2022-06-23 20:29:22.270104
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    test_provider = USASpecProvider()
    assert test_provider.tracking_number() in (
        '#### #### #### #### ####',
        '@@ ### ### ### US',
        '#### #### ####',
        '#### #### #### ###',
        '1Z@####@##########',
    )


# Generated at 2022-06-23 20:29:28.404519
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for USASpecProvider.tracking_number.
    :method: USASpecProvider.tracking_number
    :param service: Post service.
    :return: Tracking number.
    """
    test_instance = USASpecProvider(seed=None)
    assert test_instance.tracking_number(service='usps') != ''
    assert test_instance.tracking_number(service='fedex') != ''
    assert test_instance.tracking_number(service='ups') != ''



# Generated at 2022-06-23 20:29:35.156776
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider(seed=42)
    tracking_number_usps = us.tracking_number(service='usps')
    tracking_number_fedex = us.tracking_number(service='fedex')
    tracking_number_ups = us.tracking_number(service='ups')
    assert tracking_number_usps != tracking_number_fedex
    assert tracking_number_ups != tracking_number_fedex
    assert tracking_number_ups != tracking_number_usps


# Generated at 2022-06-23 20:29:36.541875
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider(seed=55) is not None


# Generated at 2022-06-23 20:29:38.236959
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    testTrackingNumber = USASpecProvider()
    assert testTrackingNumber.tracking_number() != ''


# Generated at 2022-06-23 20:29:40.439880
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec = USASpecProvider()
    assert usa_spec.__class__.__name__ == 'USASpecProvider'

# Generated at 2022-06-23 20:29:43.492980
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    inst = USASpecProvider()
    trac_num = inst.tracking_number()
    # print(trac_num)
    assert trac_num


# Generated at 2022-06-23 20:29:46.066322
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number() == "1ZV 651 010 16 0595 203 6"


# Generated at 2022-06-23 20:29:47.427451
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    USASpecProvider()


# Generated at 2022-06-23 20:29:54.556479
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert 1 <= usa_spec_provider.personality('rheti') <= 10


# Generated at 2022-06-23 20:30:00.996020
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    assert USASpecProvider().personality('mbti') in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    ]


# Generated at 2022-06-23 20:30:06.492834
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number(service='usps') == '8N6C AFVA 8369 0U52 E9RV'
    assert provider.tracking_number(service='fedex') == '8H92 5F31 4Z'    
    assert provider.tracking_number(service='ups') == '1Z1E75CY8787211335'


# Generated at 2022-06-23 20:30:08.929915
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usp = USASpecProvider()
    assert all([len(usp.ssn()) == 11])
    assert all(['-' in usp.ssn()])


# Generated at 2022-06-23 20:30:15.509031
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # To ensure that the list of states will be shuffled in the same way.
    usa = USASpecProvider(seed=42)
    ssn = usa.ssn()
    assert ssn == '698-05-3450'
    # Testing mask
    usa = USASpecProvider(seed=42)
    ssn = usa.ssn()
    assert ssn == '698-05-3450'

# Generated at 2022-06-23 20:30:16.854669
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    print(provider.ssn())

# Generated at 2022-06-23 20:30:23.352226
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    u = USASpecProvider()
    ssn = u.ssn()
    assert len(ssn) == 11
    assert ssn[3] == "-"
    assert ssn[6] == "-"
    assert ssn[0:3] != "666"
    assert ssn[3:5] != "66"
    assert ssn[6:9] != "666"


# Generated at 2022-06-23 20:30:26.047734
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking_number = provider.tracking_number()
    assert ('#' in tracking_number) == True


# Generated at 2022-06-23 20:30:28.234924
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
  usaspp = USASpecProvider()
  assert usaspp.get_spec('tracking_number', 'usps')

# Generated at 2022-06-23 20:30:30.629612
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert type(ssn) == str
    assert len(ssn) == 11

# Generated at 2022-06-23 20:30:31.767452
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider() is not None


# Generated at 2022-06-23 20:30:33.028566
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    sp = USASpecProvider()
    tracker = sp.tracking_number()
    assert len(tracker) > 10

# Generated at 2022-06-23 20:30:35.824679
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test USASpecProvider.tracking_number()."""
    usa = USASpecProvider()
    assert usa.tracking_number() != usa.tracking_number()


# Generated at 2022-06-23 20:30:44.042785
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    type_list1 = ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    type_list2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    for _ in range(100):
        # MBTI
        assert USASpecProvider().personality() in type_list1
        # Rheti
        assert USASpecProvider().personality(category='Rheti') in type_list2

# Generated at 2022-06-23 20:30:48.329076
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_spec_provider.personality('rheti') in range(1,11)

# Generated at 2022-06-23 20:30:59.701140
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Arrange
    us = USASpecProvider()
    usps = us.tracking_number(service='USPS')
    fedex = us.tracking_number(service='fedex')
    ups = us.tracking_number(service='UPS')

    # Act
    is_usps_valid = is_tracking_number_valid(usps, service='USPS')
    is_fedex_valid = is_tracking_number_valid(fedex, service='fedex')
    is_ups_valid = is_tracking_number_valid(ups, service='UPS')

    # Assert
    assert is_usps_valid == True, 'USPS tracking number is not valid'
    assert is_fedex_valid == True, 'FedEx tracking number is not valid'

# Generated at 2022-06-23 20:31:01.467096
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn) == 11
    assert type(ssn) == str


# Generated at 2022-06-23 20:31:10.082535
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    provider = USASpecProvider() # Create an object of class USASpecProvider

    # Create a list of tuples that contain the results from function personality of class USASpecProvider
    list_of_tuples = [provider.personality(category=category) for category in ('mbti', 'rheti') for _ in range(1000)]

    # Count the number of occurrences of each result
    unique_values_with_counts = {(value, list_of_tuples.count(value)) for value in list_of_tuples}

    # Print the results.
    print(unique_values_with_counts)

# Generated at 2022-06-23 20:31:11.602130
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider(seed = '1')
    ssn = provider.ssn()
    assert (ssn == '860-69-2214')

# Generated at 2022-06-23 20:31:15.534590
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider(seed=123)
    tracking_number = provider.tracking_number()
    assert tracking_number == '9U5L6S03C6U59JFFB3', \
        "Test for method tracking_number of class USASpecProvider failed"


# Generated at 2022-06-23 20:31:20.100862
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method tracking_number of class USASpecProvider"""
    provider = USASpecProvider()
    assert provider.tracking_number(service = 'usps') == '9420 5023 2091 2678 6123'
    assert provider.tracking_number(service = 'fedex') == '2473 8139 1188'
    assert provider.tracking_number(service = 'ups') == '1Z9X9979VH85334904'


# Generated at 2022-06-23 20:31:27.594150
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    import random
    from mimesis.builtins import USASpecProvider
    usa_provider = USASpecProvider(seed=random.randint(0, 2**16))
    assert usa_provider.personality(category='mbti') \
        in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert usa_provider.personality(category='rheti') \
        in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]



# Generated at 2022-06-23 20:31:38.375261
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test USASpecProvider.personality."""
    from mimesis.enums import Personality

    usa_spec_provider = USASpecProvider()

    assert usa_spec_provider.personality(Personality.MBTI) in \
        ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP',
         'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert usa_spec_provider.personality(Personality.RHETI) in \
        (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-23 20:31:45.903452
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test constructor of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.__dict__ == {
        '_datetime': usa_provider,
        '_file': usa_provider,
        '_generic': usa_provider,
        '_internet': usa_provider,
        '_language': usa_provider,
        '_personal': usa_provider,
        '_numbers': usa_provider,
        '_random': usa_provider,
        '_text': usa_provider,
        '_translate': usa_provider,
        'locale': 'en',
        '_seed': usa_provider,
    }


# Generated at 2022-06-23 20:31:53.089976
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for test_USASpecProvider_personality"""
    sut = USASpecProvider()
    assert sut.personality('mbti') in ['ISFJ','ISTJ','INFJ','INTJ','ISTP','ISFP','INFP','INTP','ESTP','ESFP','ENFP','ENTP','ESTJ','ESFJ','ENFJ','ENTJ']
    assert sut.personality('rheti') in range(1,10)

# Generated at 2022-06-23 20:32:01.119505
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()

    # Test case 1
    result = usa_spec_provider.personality(category="mbti")
    assert result in ('ISFJ','ISTJ','INFJ','INTJ','ISTP','ISFP','INFP','INTP','ESTP','ESFP','ENFP','ENTP','ESTJ','ESFJ','ENFJ','ENTJ')

    # Test case 2
    result = usa_spec_provider.personality(category="rheti")
    assert result in (1,2,3,4,5,6,7,8,9,10)

# Generated at 2022-06-23 20:32:09.667769
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for tracking_number method in USASpecProvider class."""
    spec = USASpecProvider()
    assert '9400 1098 7631 7881 1110' == spec.tracking_number(service='USPS')
    assert '7112492435451' == spec.tracking_number(service='UPS')
    assert '0388 5151 9206' == spec.tracking_number(service='FedEx')
    assert '9500 5243 9682 1163' == spec.tracking_number()


# Generated at 2022-06-23 20:32:12.627372
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    service = 'usps'
    tracking_number = USASpecProvider.tracking_number(service)
    print(tracking_number)
    assert isinstance(tracking_number, str)



# Generated at 2022-06-23 20:32:20.582093
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality('mbti') in ('INFJ', 'INTJ',
                     'INFP', 'INTP', 'ESTP', 'ESFP',
                     'ENFP', 'ENTP', 'ESTJ', 'ESFJ',
                     'ENFJ', 'ENTJ', 'ISFJ', 'ISTJ',
                     'ISTP', 'ISFP')
    assert type(provider.personality('rheti')) == int
    assert provider.personality('rheti') in range(1, 11)

# Generated at 2022-06-23 20:32:22.523403
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    x = USASpecProvider()
    assert x is not None
    assert len(x) > 0


# Generated at 2022-06-23 20:32:27.012297
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    # Test for the method tracking_number()
    assert(len(usa_spec_provider.tracking_number()) == 22)
    # test for the method ssn()
    assert(len(usa_spec_provider.ssn()) == 11)
    # test for the method personality()
    assert(len(usa_spec_provider.personality()) == 4)

# Generated at 2022-06-23 20:32:28.567483
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    isinstance(provider, USASpecProvider)

# Generated at 2022-06-23 20:32:31.406317
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider(seed=42)

    for i in range(100):
        assert True if str(us.ssn()) == '523-77-8355' else False


# Generated at 2022-06-23 20:32:33.994150
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    provider = USASpecProvider()
    assert provider.tracking_number().find(' ') > 0


# Generated at 2022-06-23 20:32:39.315931
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.__class__.__name__ == 'USASpecProvider'
    assert usa_provider.__class__.__name__\
        == USASpecProvider.Meta.name


# Generated at 2022-06-23 20:32:49.337931
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for personality() method."""
    usa = USASpecProvider()

    # testing unstructured string
    result = usa.personality('mbti')
    assert result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                      'ISTP', 'ISFP', 'INFP', 'INTP',
                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    # testing numeric
    result = usa.personality('rheti')
    assert result in range(1, 11)

    # testing error
    try:
        assert usa.personality('123') is not None
    except Exception as e:
        assert isinstance(e, ValueError)

# Generated at 2022-06-23 20:32:51.507303
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() == "USPS 957-97-0201"

# Generated at 2022-06-23 20:32:59.762359
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality(category="mbti") in \
        ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
         'ISTP', 'ISFP', 'INFP', 'INTP',
         'ESTP', 'ESFP', 'ENFP', 'ENTP',
         'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert usa_spec_provider.personality(category="rheti") in [i for i in range(1, 11)]

# Generated at 2022-06-23 20:33:02.470058
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    spec = USASpecProvider()
    assert len(spec.ssn()) == 11
    assert spec.ssn().find('-') >= 0


# Generated at 2022-06-23 20:33:07.291038
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.enums import PostService
    from mimesis.builtins import USASpecProvider
    usa = USASpecProvider()
    assert len(usa.tracking_number(PostService.FedEx)) == 18
    assert len(usa.tracking_number(PostService.USPS)) == 22
    assert len(usa.tracking_number(PostService.UPS)) == 18



# Generated at 2022-06-23 20:33:13.670977
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    from .en import English
    from .usa import USASpecProvider
    usa = USASpecProvider()
    eng = English()
    for kind in (Gender.FEMALE, Gender.MALE, Gender.NEUTRAL, ):
        print(eng.gender(kind.value))
        print(usa.ssn())

test_USASpecProvider_ssn()

# Generated at 2022-06-23 20:33:15.531707
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
	us = USASpecProvider()
	assert us.__class__.__bases__[0].__name__ == 'BaseSpecProvider'

# Unit tests for method USASpecProvider:tracking_number

# Generated at 2022-06-23 20:33:23.807527
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    tracking_number = usa.tracking_number()
    # Tracking number must contain only numbers, spaces, and letters
    assert re.search('[^0-9^A-Z^\s]', tracking_number) == None
    # Tracking number must contain both numbers and letters
    assert re.search('[0-9]', tracking_number) != None and re.search('[A-Z]', tracking_number) != None
    tracking_number = usa.tracking_number('fedex')
    # Tracking number must contain only numbers and spaces
    assert re.search('[^0-9^\s]', tracking_number) == None
    # Tracking number must contain both numbers and letters
    assert re.search('[0-9]', tracking_number) != None

# Generated at 2022-06-23 20:33:26.756281
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    #test_constructor_of_class_USASpecProvider(USASpecProvider)
    print('test_constructor_of_class_USASpecProvider: ')


# Generated at 2022-06-23 20:33:36.455722
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_personality = USASpecProvider()
    category = 'mbti'
    result = usa_personality.personality(category)
    assert result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                      'ISTP', 'ISFP', 'INFP', 'INTP',
                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(result, str)

    category = 'rheti'
    result = usa_personality.personality(category)
    assert result in range(1, 11)
    assert isinstance(result, int)

    # Unsupported category
    category = 'mbtii'
    result = usa_personality.personality(category)

# Generated at 2022-06-23 20:33:41.919697
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    p = USASpecProvider()
    assert isinstance(p, USASpecProvider)
    assert p.provider == 'usa_provider'
    assert p.datetime.datetime.today().year == p.datetime.datetime.today().year
    assert p.datetime.datetime.today().month == p.datetime.datetime.today().month


# Generated at 2022-06-23 20:33:47.381316
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality(category='mbti') in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    ]
    assert provider.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-23 20:33:48.646423
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider(seed=123)
    assert provider.personality('mbti') == 'INFP'
    assert provider.personality('rheti') == 7


# Generated at 2022-06-23 20:33:54.818293
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert usa.personality()     # type: ignore
    assert usa.personality('mbti') in mbtis
    assert type(usa.personality('rheti')) == int
    assert usa.personality('rheti')



# Generated at 2022-06-23 20:34:02.769055
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    import random
    # Using random seed
    random_seed = random.getrandbits(32)
    # Simple ssn generation
    us_ssn_1 = USASpecProvider(seed=random_seed)
    assert us_ssn_1.ssn() == us_ssn_1.ssn()
    assert len(us_ssn_1.ssn().split('-')) == 3
    # ssn generation with a different seed
    us_ssn_2 = USASpecProvider(seed=random_seed + 1)
    assert us_ssn_1.ssn() != us_ssn_2.ssn()



# Generated at 2022-06-23 20:34:04.010728
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert callable(USASpecProvider)


# Generated at 2022-06-23 20:34:05.428594
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a=USASpecProvider()
    assert isinstance(a.tracking_number("usps"),str)


# Generated at 2022-06-23 20:34:11.216168
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    usps = provider.tracking_number('usps')
    assert len(usps) == 27
    assert usps[0] in '0123456789'
    assert usps[5] == ' '
    assert usps[22] == ' '
    assert usps[-4:-1] == 'US'
    usps = provider.tracking_number('usps')
    assert len(usps) == 22
    assert usps[0] in '0123456789'
    assert usps[5] == ' '
    assert usps[-3:] == 'US'

    fedex = provider.tracking_number('fedex')
    assert len(fedex) == 16
    assert fedex[0] in '0123456789'

# Generated at 2022-06-23 20:34:17.731804
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', \
                                               'ISTP', 'ISFP', 'INFP', 'INTP', \
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP', \
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:34:25.867858
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    personality = provider.personality(category='mbti')
    assert personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                           'ISTP', 'ISFP', 'INFP', 'INTP',
                           'ESTP', 'ESFP', 'ENFP', 'ENTP',
                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    personality = provider.personality(category='rheti')
    assert personality in list(range(1, 11))



# Generated at 2022-06-23 20:34:31.968219
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    ssn = usa.ssn()
    assert isinstance(ssn, str)
    assert len(ssn) == 11
    area, group, serial = ssn.split('-')
    assert int(area) > 0 and int(area) < 899
    assert int(area) != 666
    assert int(group) > 0 and int(group) < 99
    assert int(serial) > 0 and int(serial) < 9999

# Generated at 2022-06-23 20:34:33.628597
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    service = 'usps'
    assert len(usa.tracking_number(service=service)) > 15


# Generated at 2022-06-23 20:34:38.519931
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert isinstance(ssn, str), ""
    assert ssn.count("-") == 2, ""
    assert ssn.count("-") == 2, ""
    for ssn in range(100):
        assert provider.ssn() != provider.ssn(), ""


# Generated at 2022-06-23 20:34:39.919921
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    USASpecProvider().personality(category='mbt')



# Generated at 2022-06-23 20:34:42.837380
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    for i in range(0,10):
        spec_provider = USASpecProvider()
        print(spec_provider.ssn())
        
test_USASpecProvider()


# Generated at 2022-06-23 20:34:46.904047
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Test with category=mbti
    assert isinstance(USASpecProvider().personality(),str)
    # Test with category=rheti
    assert isinstance(USASpecProvider().personality('rheti'),int)
    # Test with category not in (mbti, rhetorical, rheti) 
    try:
        USASpecProvider().personality('mbti')
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-23 20:34:52.691671
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    for i in range(10):
        provider = USASpecProvider()
        assert provider.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
