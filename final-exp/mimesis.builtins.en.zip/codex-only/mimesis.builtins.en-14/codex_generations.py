

# Generated at 2022-06-23 20:24:57.939814
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    provider = USASpecProvider()
    assert provider.personality('mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert type(provider.personality('rheti')) is int
    assert provider.personality('rheti') in (1,2,3,4,5,6,7,8,9,10)

# Generated at 2022-06-23 20:25:02.096683
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider(seed='0')
    ssn = usa_provider.ssn() # Ex. 569-66-5801
    assert ssn == '569-66-5801'

# Generated at 2022-06-23 20:25:04.219990
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """
    Test method tracking_number of class USASpecProvider.
    """
    instance = USASpecProvider()
    assert instance.tracking_number() != ''


# Generated at 2022-06-23 20:25:06.338328
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Constructor test."""
    p = USASpecProvider()
    assert p.localization != None
    assert p.localization.locale != None
    assert p.localization.language != None
    assert p.localization.country != None
    assert p.localization.time_zone != None
    assert p.random != None


# Generated at 2022-06-23 20:25:10.239926
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Given
    test_USASpecProvider=USASpecProvider()
    assert test_USASpecProvider.tracking_number('usps') == '7742 9585 8076 0931 5194'


# Generated at 2022-06-23 20:25:12.375096
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Make a test case for Unit test for constructor of class USASpecProvider."""
    assert USASpecProvider()
    assert USASpecProvider('859957084')



# Generated at 2022-06-23 20:25:18.470708
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number('usps') in ['8316 1079 1398 8989 1333', 'RZ 085 091 879 US']
    assert usa.tracking_number('FedEx') in ['0842 9187 545', '7238 9483 546 478']
    assert usa.tracking_number('UPS') in ['1Z0X904Y6950881447']


# Generated at 2022-06-23 20:25:21.958808
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert len(USASpecProvider().tracking_number('usps')) == 27
    assert len(USASpecProvider().tracking_number('fedex')) in (12, 17)
    assert len(USASpecProvider().tracking_number('ups')) == 17



# Generated at 2022-06-23 20:25:25.632273
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    t = USASpecProvider()
    assert type(t.ssn()) == str, "Error 1"

# Generated at 2022-06-23 20:25:28.237844
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider(seed=1)
    assert isinstance(usa_provider, USASpecProvider)
    assert usa_provider.locale == 'en'


# Generated at 2022-06-23 20:25:29.546501
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    assert us is not None

# Generated at 2022-06-23 20:25:38.580265
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    # GIVEN an object of USASpecProvider class
    usa_spec_provider = USASpecProvider(seed=1)

    # WHEN tracking number is generated for FedEx
    tracking_number = usa_spec_provider.tracking_number(service='fedex')

    # THEN tracking number should be as below
    assert tracking_number == '1785 6295 549'

    # WHEN tracking number is generated for UPS
    tracking_number = usa_spec_provider.tracking_number(service='ups')

    # THEN tracking number should be as below
    assert tracking_number == '1Z1B214A6590137116'

    # WHEN tracking number is generated for USPS
    tracking_number = usa_spec_provider.tracking_number(service='usps')

    # THEN tracking number should be as below
    assert tracking_

# Generated at 2022-06-23 20:25:44.921188
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender
    usa = USASpecProvider()
    assert usa
    assert usa.flags
    assert usa.datetime
    assert usa.random
    assert usa.location
    assert usa.numbers
    assert usa.text
    assert usa.internet
    assert usa.address
    assert usa.business

    # test the extension
    assert usa.random.personality()
    assert usa.random.ssn()
    assert usa.random.tracking_number()
    assert usa.random.first_name() is not None
    assert usa.random.gender() == Gender.FEMALE
    assert usa.random.gender() == Gender.MALE
    assert usa.random.last_name() is not None

# Generated at 2022-06-23 20:25:47.113303
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_obj = USASpecProvider()
    assert isinstance(usa_obj, USASpecProvider)


# Generated at 2022-06-23 20:25:49.628326
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    seed = 'foobar'
    us = USASpecProvider(seed=seed)
    assert hasattr(us, 'random')
    assert hasattr(us, 'datetime')

# Generated at 2022-06-23 20:25:50.871673
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in mbtis


# Generated at 2022-06-23 20:25:53.809458
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test the constructor of USASpecProvider."""
    assert USASpecProvider(seed=123).random.state == 123
    assert USASpecProvider(seed=123).seed == 123
    assert USASpecProvider().seed is None


# Generated at 2022-06-23 20:25:59.857734
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender

    from . import USASpecProvider
    provider = USASpecProvider()
    assert len(provider.ssn()) == 11
    assert len(provider.ssn(gender=Gender.MALE)) == 11
    assert len(provider.ssn(gender=Gender.FEMALE)) == 11



# Generated at 2022-06-23 20:26:02.228395
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider(seed=123)
    assert usa.tracking_number() == '1Z0663T30331568687'


# Generated at 2022-06-23 20:26:10.584232
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_provider = USASpecProvider()
    us_provider.set_seed()

    fedex_number = us_provider.tracking_number("Fedex")
    assert("#### #### ####" in fedex_number or "#### #### #### ###" in fedex_number)

    ups_number = us_provider.tracking_number("UPS")
    assert("1Z@####@##########" in ups_number)

    usps_number = us_provider.tracking_number("USPS")
    assert("@@ ### ### ### US" in usps_number or "#### #### #### #### ####" in usps_number)

    try:
        us_provider.tracking_number("Random")
    except ValueError:
        assert(True)
        return
    assert(False)

#

# Generated at 2022-06-23 20:26:12.057725
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    return usa.tracking_number()


# Generated at 2022-06-23 20:26:19.862917
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality('rheti') in range(1, 10)
    assert usa_provider.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')



# Generated at 2022-06-23 20:26:26.978804
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Check if the value of method will be integer.
    # Example: 1Z0Y0Y90Y3Y87Y5Y5Y7
    usa_provider = USASpecProvider()
    tracking_number_ups = usa_provider.tracking_number(service='ups')
    assert isinstance(tracking_number_ups, u''.__class__)

    # Check if the value of method will be integer.
    # Example: 2Y4Y3Y3Y3Y3Y3Y3Y3Y3Y3
    tracking_number_fedex = usa_provider.tracking_number(service='fedex')
    assert isinstance(tracking_number_fedex, u''.__class__)

    # Check if the value of method will be integer.
    # Example: 9Y2Y6Y2Y2Y2Y

# Generated at 2022-06-23 20:26:28.224481
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    assert (usa_provider.ssn() != "666-66-6666")


# Generated at 2022-06-23 20:26:30.834400
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider(seed=42)

    ssn = usa.ssn()
    assert ssn == '768-82-8436'


# Generated at 2022-06-23 20:26:33.197170
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """ Test constructor of class USASpecProvider """
    spec_provider = USASpecProvider()
    assert spec_provider is not None


# Generated at 2022-06-23 20:26:34.764111
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    assert usa.ssn()
    assert len(usa.ssn()) == 11

# Generated at 2022-06-23 20:26:37.910112
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert(len(provider.tracking_number()) == 27)


# Generated at 2022-06-23 20:26:43.596887
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number() # test tracking_number() when service is not specified
    assert provider.tracking_number('USPS') # test tracking_number() when service is USPS
    assert provider.tracking_number('FedEx') # test tracking_number() when service is FedEx
    assert provider.tracking_number('UPS') # test tracking_number() when service is UPS


# Generated at 2022-06-23 20:26:53.251296
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    res = USASpecProvider.personality(category= "rheti")
    assert ( (res >= 1) & (res <= 10) )
    res2 = USASpecProvider.personality(category= "mbti")

# Generated at 2022-06-23 20:26:56.452592
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    x = USASpecProvider()
    assert x.ssn() in ('###-##-####','###-##-####','###-##-####','###-##-####','###-##-####','###-##-####','###-##-####','###-##-####','###-##-####','###-##-####')

# Generated at 2022-06-23 20:26:58.485280
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Docstring."""
    usa = USASpecProvider()
    assert usa.tracking_number()



# Generated at 2022-06-23 20:27:06.023195
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    uss = USASpecProvider()
    result = uss.tracking_number()
    strLen = len(result)
    # test lenght
    assert(strLen == 22 or strLen == 28)
    assert(result[0] == '1')
    assert(result[1] == 'Z')
    # no repeated letters
    assert(len(set(result)) == len(result))

if __name__ == '__main__':
    test_USASpecProvider_tracking_number()

# Generated at 2022-06-23 20:27:09.692532
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    tn = us.tracking_number()

    assert len(tn) == 18 or len(tn) == 22 or len(tn) == 14


# Generated at 2022-06-23 20:27:12.246536
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider(seed=123456789)
    assert usa_provider.ssn() == "672-35-5202"

# Generated at 2022-06-23 20:27:20.100840
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test USASpecProvider.tracking_number."""
    assert USASpecProvider().tracking_number() == '1DE XXX XXX US'
    assert USASpecProvider().tracking_number('FedEx') == '#### #### ####'
    assert USASpecProvider().tracking_number('UPS') == '1ZE2 XXX XXX XXX XX'
    assert USASpecProvider().tracking_number('UPS') != '1Z12 XXX XXX XXX XX'
    assert USASpecProvider().tracking_number('UPS') != '1ZE2 XXX XXX XXX XY'
   # assert USASpecProvider().tracking_number('DHL') == None
    assert USASpecProvider().tracking_number('USPS') == '#### #### #### #### ####'


# Generated at 2022-06-23 20:27:31.862791
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():

    # Create a instance of class USASpecProvider
    from mimesis.enums import Gender

    us_provider = USASpecProvider()
    # Set the seed for the instance
    us_provider.seed(15037)

    assert us_provider.ssn() == '841-01-1482'
    assert us_provider.ssn() == '111-20-9822'
    assert us_provider.ssn() == '538-88-7279'
    assert us_provider.ssn() == '325-06-5629'
    assert us_provider.ssn() == '801-56-7013'
    assert us_provider.ssn() == '744-75-8197'
    assert us_provider.ssn() == '413-11-2837'
   

# Generated at 2022-06-23 20:27:33.033698
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    p = USASpecProvider()
    print(p.ssn())


# Generated at 2022-06-23 20:27:34.742845
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
  assert len(USASpecProvider().ssn().split(sep='-')) == 3


# Generated at 2022-06-23 20:27:37.833524
# Unit test for method tracking_number of class USASpecProvider

# Generated at 2022-06-23 20:27:42.594791
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test personality method of USASpecProvider class."""
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.personality(
        category="rheti"), int) is True
    assert isinstance(usa_provider.personality(
        category="mbti"), str) is True

# Generated at 2022-06-23 20:27:43.329393
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider()

# Generated at 2022-06-23 20:27:45.951844
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider"""
    usa = USASpecProvider(seed=123)   # type: ignore
    assert usa.random.getstate() is None
    assert usa.random.getstate() is not None


# Generated at 2022-06-23 20:27:51.697670
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    mbti_type = us.personality(category='mbti')
    assert mbti_type in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP',
                         'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    rheti_type = us.personality(category='rheti')
    assert isinstance(rheti_type, int)
    assert rheti_type in range(1,11)



# Generated at 2022-06-23 20:28:00.889680
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.builtins.us import USASpecProvider

    us = USASpecProvider()
    us.random.set_seed('test') # Set seed for reproduce

    # Testing USPS tracking number
    usps = us.tracking_number(service='usps')
    assert usps == '02871 57375 6051 5096', 'Wrong tracking number'

    # Testing FedEx tracking number
    fedex = us.tracking_number(service='fedex')
    assert fedex == '2617 2574 9801 772', 'Wrong tracking number'

    # Testing UPS tracking number
    ups = us.tracking_number(service='ups')
    assert ups == '1ZDE488A8926287825', 'Wrong tracking number'



# Generated at 2022-06-23 20:28:04.975727
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider(seed=1)
    usa.personality() == 'ENTJ'
    usa.personality(category='rheti') == 4

# Generated at 2022-06-23 20:28:12.582068
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    # check the type of attr locale
    assert isinstance(usa_provider.locale, str)
    # check the type of attr seed
    assert isinstance(usa_provider.seed, Optional[Seed])

    # test for method personality
    personality = usa_provider.personality()
    # check the type of personality
    assert isinstance(personality, str) or isinstance(personality, int)
    # test for method tracking_number
    service = ['usps', 'fedex', 'ups']
    s = usa_provider.random.choice(service)
    # check the type of str
    assert isinstance(usa_provider.tracking_number(s), str)
    # test for method ssn

# Generated at 2022-06-23 20:28:14.305667
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert len(USASpecProvider().tracking_number()) == 19


# Generated at 2022-06-23 20:28:17.300175
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert hasattr(USASpecProvider, 'tracking_number')
    assert hasattr(USASpecProvider, 'ssn')
    assert hasattr(USASpecProvider, 'personality')

# Generated at 2022-06-23 20:28:19.328166
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    ssn = USASpecProvider.ssn()
    assert USASpecProvider.validate_ssn(ssn) is True


# Generated at 2022-06-23 20:28:21.840310
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test case for method ssn of class USASpecProvider."""
    usa = USASpecProvider()
    print(usa.ssn())


# Generated at 2022-06-23 20:28:26.159384
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider().__class__.__name__ == 'USASpecProvider'
    assert USASpecProvider().__class__.__mro__[0].__name__ == 'USASpecProvider'
    assert USASpecProvider().__class__.__mro__[1].__name__ == 'BaseSpecProvider'
    assert USASpecProvider().__class__.__mro__[2].__name__ == 'BaseProvider'



# Generated at 2022-06-23 20:28:34.005922
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()

    assert isinstance(usa_provider.tracking_number(service='usps'), str)
    assert isinstance(usa_provider.tracking_number(service='fedex'), str)
    assert isinstance(usa_provider.tracking_number(service='ups'), str)
    try:
        usa_provider.tracking_number(service='other')
    except ValueError as e:
        assert e.args[0] == 'Unsupported post service'
    except:
        assert False


# Generated at 2022-06-23 20:28:42.939947
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()

    assert usa_provider.personality('rheti') in range(1, 11)
    assert usa_provider.personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
												'ISTP', 'ISFP', 'INFP', 'INTP',
												'ESTP', 'ESFP', 'ENFP', 'ENTP',
												'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:28:48.534648
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():  # noqa: D202
    # Arrange
    usa_spec_provider = USASpecProvider()
    usps_number = usa_spec_provider.tracking_number('USPS')

    # Assert
    assert len(usps_number) == 22
    assert usps_number[21] == 'S' or (usps_number[20] == 'U' and usps_number[21] == 'S')



# Generated at 2022-06-23 20:28:50.023298
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    usa.tracking_number()


# Generated at 2022-06-23 20:29:00.373583
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    from mimesis.builtins import USASpecProvider
    from mimesis.providers.address import Address

    usa = USASpecProvider()
    address = Address(seed=1)
    address.gender = Gender.MALE
    address.country_code = 'US'
    address.locale = 'en'

    data = [usa.ssn() for _ in range(0, 200)]

    for itm in data:
        assert len(itm) == 11
        assert itm[:3].isdecimal() is True
        assert itm[4:6].isdecimal() is True
        assert itm[7:11].isdecimal() is True



# Generated at 2022-06-23 20:29:06.537609
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()

    print("USPS tracking number is: ",usa.tracking_number("USPS"))
    print("FedEx tracking number is: ",usa.tracking_number("FedEx"))
    print("UPS tracking number is: ",usa.tracking_number("UPS"))


# Generated at 2022-06-23 20:29:11.019083
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us_provider = USASpecProvider()
    assert us_provider.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                         'ISTP', 'ISFP', 'INFP', 'INTP',
                                         'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                         'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert 1 <= us_provider.personality('rheti') <= 10


# Generated at 2022-06-23 20:29:20.125473
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'], "Testing personality function"
    assert type(usa_spec_provider.personality('rheti')) == int, "Testing personality function"

# Generated at 2022-06-23 20:29:22.265215
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for ssn method of USASpecProvider."""
    assert len(USASpecProvider().ssn()) == 11


# Generated at 2022-06-23 20:29:29.218260
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.builtins.usa import USASpecProvider
    import random

    provider = USASpecProvider(random)

    assert provider.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'],\
        str(provider.personality())

    assert 0 < provider.personality(category='rheti') <= 10, \
        str(provider.personality(category='rheti'))

    assert provider.personality(category='rheti') == 1



# Generated at 2022-06-23 20:29:39.166990
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # GIVEN
    provider = USASpecProvider()

    # WHEN
    result = provider.tracking_number() + " " + provider.tracking_number('usps') + " " + provider.tracking_number('fedex') + " " + provider.tracking_number('ups')

    # THEN
    assert len(result.split(' ')) == 4
    assert len(provider.tracking_number().split(' ')[0]) == 4
    assert len(provider.tracking_number('usps').split(' ')[0]) == 4
    assert len(provider.tracking_number('fedex').split(' ')[0]) == 4
    assert len(provider.tracking_number('ups').split(' ')[0]) == 1


# Generated at 2022-06-23 20:29:43.873858
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():

    # Test tracking number for USPS
    result = USASpecProvider().tracking_number()
    assert len(result) == 22
    assert result.startswith('91')

    # Test tracking number for FedEx
    result = USASpecProvider().tracking_number(service='fedex')
    assert len(result) == 12
    assert result.startswith('9')

    # Test tracking number for UPS
    result = USASpecProvider().tracking_number(service='ups')
    assert len(result) == 18
    assert result.startswith('1Z')


# Generated at 2022-06-23 20:29:54.108194
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for USASpecProvider constructor."""
    ssn = USASpecProvider(seed = 0).ssn()
    assert ssn == "638-86-9581"
    ssn = USASpecProvider(seed = 1).ssn()
    assert ssn == "766-41-9181"
    ssn = USASpecProvider(seed = -1).ssn()
    assert ssn == "668-47-9581"
    mbti = USASpecProvider(seed = 0).personality()
    assert mbti == "ISFJ"
    mbti = USASpecProvider(seed = 1).personality()
    assert mbti == "ISTJ"
    mbti = USASpecProvider(seed = -1).personality()
    assert mbti == "ISTP"
   

# Generated at 2022-06-23 20:29:57.031304
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    assert us.tracking_number() is not None
    assert us.ssn() is not None
    assert us.personality() is not None

# Generated at 2022-06-23 20:29:58.438623
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider.Meta.name == 'usa_provider'


# Generated at 2022-06-23 20:30:05.634673
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from unittest.mock import patch
    from mimesis.builtins import USASpecProvider as USA

    with patch('mimesis.Random.choice') as random_choice:
        random_choice.return_value = '#### #### #### #### ####'
        usa = USA()
        usa.tracking_number(service='usps')
        usa.tracking_number(service='fedex')
        usa.tracking_number(service='ups')

        random_choice.assert_called()


# Generated at 2022-06-23 20:30:10.179008
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:30:18.201581
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    usa = USASpecProvider()
    assert isinstance(usa.person, Person)
    assert isinstance(usa.person.full_name(gender=Gender.FEMALE), str)
    assert isinstance(usa.person.full_name(gender=Gender.MALE), str)
    assert isinstance(usa.person.full_name(gender=Gender.MALE), str)
    assert isinstance(usa.person.full_name(gender=None), str)

# to be completed

# Generated at 2022-06-23 20:30:29.131106
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import Personality
    from hypothesis import given
    from .strategies import strategies

    data_provider = USASpecProvider()

    @given(strategies.sentence_strategy)
    def test_personality(strategy):
        result = data_provider.personality(strategy)
        assert result not in ['', None, [], (), {}]
    test_personality()

    result_1 = data_provider.personality(Personality.MBTI)
    assert result_1 not in ['', None, [], (), {}, 0]

    result_2 = data_provider.personality(Personality.RHETI)
    assert result_2 != 0
    assert 1 <= result_2 <= 10


# Generated at 2022-06-23 20:30:30.550640
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()

    assert usa_provider is not None

# Generated at 2022-06-23 20:30:37.261877
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    personality = provider.personality(category='mbti')
    assert personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    personality = provider.personality(category='rheti')
    assert personality in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-23 20:30:41.051327
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    ssn = usa_spec_provider.ssn()
    assert ssn == '321-98-4626'


# Generated at 2022-06-23 20:30:49.040996
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import Category
    from mimesis.providers.usa.usaspecprovider import USASpecProvider
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    user = USASpecProvider()
    assert user.personality(category=Category.MBTI) in mbtis
    assert user.personality(category=Category.RHETI) >= 1
    assert user.personality(category=Category.RHETI) <= 10
    assert user.personality(category=Category.MBTI) in mbtis

# Generated at 2022-06-23 20:30:50.888281
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number()


# Generated at 2022-06-23 20:30:54.374819
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test case for USASpecProvider.personality."""
    assert USASpecProvider().personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert USASpecProvider().personality('rheti') in list(range(1, 11))
    assert USASpecProvider().personality('random') == None

# Generated at 2022-06-23 20:30:57.700092
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()

    one = provider.tracking_number()
    assert isinstance(one, str)

    two = provider.tracking_number(service='fedex')
    assert isinstance(two, str)

    three = provider.tracking_number(service='ups')
    assert isinstance(three, str)


# Generated at 2022-06-23 20:31:03.123735
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert isinstance(provider.personality('rheti'), int)


# Generated at 2022-06-23 20:31:11.324435
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.builtins import USASpecProvider
    sp = USASpecProvider()
    l = [sp.personality(category='rheti') for _ in range(1000)]
    assert all(i in l for i in range(1, 10))
    l = [sp.personality(category='mbti') for _ in range(1000)]
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert all(i in l for i in mbtis)

# Generated at 2022-06-23 20:31:12.250009
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    x = USASpecProvider()
    x.ssn()

# Generated at 2022-06-23 20:31:19.654161
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    print("Testing ssn of USASpecProvider...")

    from mimesis.enums import Gender
    from mimesis.providers.us import USASpecProvider as USASP

    usasp = USASP()

    ssn = usasp.ssn()
    assert ssn is not None

    gender = usasp.gender()
    if gender == Gender.MALE:
        assert ssn[0] != '9'
    else:
        assert ssn[0] == '9'

    print("Done.")


if __name__ == "__main__":
    # Unit test for method ssn of class USASpecProvider
    test_USASpecProvider_ssn()

# Generated at 2022-06-23 20:31:27.072806
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test to check tracking_number method."""
    p = USASpecProvider()
    tracking_number_usps = p.tracking_number('usps')
    tracking_number_fedex = p.tracking_number('fedex')
    tracking_number_ups = p.tracking_number('ups')
    assert (tracking_number_usps != tracking_number_fedex
            and tracking_number_usps != tracking_number_ups
            and tracking_number_fedex != tracking_number_ups)

    # This value is not supported
    tracking_number_tnt = p.tracking_number('tnt')

    assert (tracking_number_tnt is not None)


# Generated at 2022-06-23 20:31:31.119215
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us_spec_provider = USASpecProvider()
    assert us_spec_provider.ssn() == '666-66-9999'
    assert us_spec_provider.ssn() != '666-66-6665'


# Generated at 2022-06-23 20:31:33.871911
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    mb = USASpecProvider()
    assert isinstance(mb.random.randint(1, 10), int)


# Generated at 2022-06-23 20:31:41.888348
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usps_tracking_number = USASpecProvider().tracking_number(service='usps')
    fedex_tracking_number = USASpecProvider().tracking_number(service='fedex')
    ups_tracking_number = USASpecProvider().tracking_number(service='ups')

    assert isinstance(usps_tracking_number, str)
    assert len(usps_tracking_number) == 24
    assert isinstance(fedex_tracking_number, str)
    assert len(fedex_tracking_number) == 15
    assert isinstance(ups_tracking_number, str)
    assert len(ups_tracking_number) == 18


# Generated at 2022-06-23 20:31:47.074866
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():  # type: ignore
    """Unit test for method tracking_number of class USASppecProvider."""
    from mimesis.enums import PostService

    usa = USASpecProvider()
    tracking_number = usa.tracking_number(PostService.FEDEX)
    assert len(tracking_number) == 12
    tracking_number = usa.tracking_number(PostService.UPS)
    assert len(tracking_number) == 18
    tracking_number = usa.tracking_number(PostService.USPS)
    assert len(tracking_number) in (15, 14)



# Generated at 2022-06-23 20:31:52.703959
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    values = {'usps': 'USPS', 'fedex': 'FedEx', 'ups': 'UPS'}
    for k, v in values.items():
        result = provider.tracking_number(k)
        print(result)
        assert result[0:len(v)] == v


# Generated at 2022-06-23 20:32:00.007195
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='rheti') in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert USASpecProvider().personality(category='MBTI') in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ',
        'ENFJ', 'ENTJ'
    ]


# Generated at 2022-06-23 20:32:01.620771
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    USASpecs = USASpecProvider()
    assert USASpecs is not None



# Generated at 2022-06-23 20:32:05.254444
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider.Meta.name == 'usa_provider'
    assert USASpecProvider().__class__.__bases__[0].__name__ == 'BaseSpecProvider'


# Generated at 2022-06-23 20:32:15.465225
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    import pytz
    from mimesis.enums import Gender
    from mimesis.providers.internet.en import Internet
    from mimesis.providers.address.en import Address
    from mimesis.providers.person.en import Person
    from mimesis.providers.misc.en import Misc

    # explicitly set timezone
    timezone = pytz.timezone('America/New_York')

    # instantiate the class
    misc = Misc(timezone=timezone)
    person = Person(timezone=timezone)
    address = Address(timezone=timezone)
    usa_provider = USASpecProvider(seed=50)

    # generate tracking number
    tracking_number = usa_provider.tracking_number()
    print('US Postal Service tracking number:', tracking_number)
    tracking

# Generated at 2022-06-23 20:32:21.624689
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    # Test with category = 'mbti'
    obj = USASpecProvider()
    ssn = obj.personality(category='mbti')
    assert len(ssn) == 4

    # Test with category = 'rheti'
    obj = USASpecProvider()
    ssn = obj.personality(category='rheti')
    assert isinstance(ssn, int)
    assert 1 <= ssn <= 10


# Generated at 2022-06-23 20:32:23.766706
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    sr = USASpecProvider()
    assert len(sr.ssn()) == 11
    assert sr.ssn().count('-')==2

# Generated at 2022-06-23 20:32:27.702141
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for USASpecProvider class."""
    provider = USASpecProvider()
    assert provider.tracking_number() == provider.tracking_number()


# Generated at 2022-06-23 20:32:29.559382
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider(seed=0)

    assert provider.personality() == 'ENTP'


# Generated at 2022-06-23 20:32:31.234030
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for USASpecProvider."""
    USASpecProvider().tracking_number()



# Generated at 2022-06-23 20:32:33.237338
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    s = USASpecProvider()
    print('test_USASpecProvider_str: ', s)

# Generated at 2022-06-23 20:32:37.595155
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test USASpecProvider class - tracking_number method."""
    usa = USASpecProvider()
    assert usa.tracking_number()
    assert usa.tracking_number()
    assert usa.tracking_number()


# Generated at 2022-06-23 20:32:44.736522
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider(seed=12345)
    assert provider.personality() == 'INFJ'
    assert provider.personality() == 'ISFJ'
    assert provider.personality() == 'INTJ'
    assert provider.personality() == 'ISFJ'
    assert provider.personality() == 'INTP'
    assert provider.personality() == 'INFJ'
    assert provider.personality() == 'ISFJ'
    assert provider.personality() == 'ISFJ'
    assert provider.personality() == 'INFJ'
    assert provider.personality() == 'INTJ'
    assert provider.personality('rheti') == 3
    assert provider.personality('rheti') == 5
    assert provider.personality('rheti') == 5
    assert provider.personality

# Generated at 2022-06-23 20:32:50.974457
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tracking_number_result_usps = USASpecProvider().tracking_number()
    assert len(tracking_number_result_usps) > 8

    tracking_number_result_fedex = USASpecProvider().tracking_number('fedex')
    assert len(tracking_number_result_fedex) > 8

    tracking_number_result_ups = USASpecProvider().tracking_number('ups')
    assert len(tracking_number_result_ups) > 8


# Generated at 2022-06-23 20:32:52.798494
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print(USASpecProvider(seed=0))



# Generated at 2022-06-23 20:32:55.074211
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(list(set([USASpecProvider().ssn() for i in range(20)]))) == 20



# Generated at 2022-06-23 20:32:57.644203
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number() is not None
    assert len(provider.tracking_number()) == 22


# Generated at 2022-06-23 20:33:07.363935
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    from mimesis.providers.us_provider import USAProvider
    from mimesis.providers.usa_provider import USASpecProvider
    from re import match

    usa = USAProvider('en')
    usa_spec = USASpecProvider()
    for _ in range(10):
        gender = usa.gender(Gender.FEMALE)
        dob = usa.date_of_birth(
            minimum_age=18,
            maximum_age=100,
            format_string='%Y%m%d',
        )

        ssn = usa_spec.ssn()
        assert match(r'^\d{3}-\d{2}-\d{4}$', ssn) is not None, ssn


# Generated at 2022-06-23 20:33:18.183057
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for tracking_number method of class USASpecProvider."""
    from mimesis.enums import PostService

    usa_provider = USASpecProvider('en')

    usps_tracking_number = usa_provider.tracking_number('usps')
    assert isinstance(usps_tracking_number, str)
    assert len(usps_tracking_number) == 22

    fedex_tracking_number = usa_provider.tracking_number('fedex')
    assert isinstance(fedex_tracking_number, str)
    assert len(fedex_tracking_number) in (12, 16)

    ups_tracking_number = usa_provider.tracking_number('ups')
    assert isinstance(ups_tracking_number, str)
    assert len(ups_tracking_number) == 18

    #

# Generated at 2022-06-23 20:33:22.376704
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """It test the method ssn of the class USASpecProvider."""
    usaspecprovider = USASpecProvider()
    assert isinstance(usaspecprovider.ssn(), str)
    assert len(usaspecprovider.ssn()) == 11


# Generated at 2022-06-23 20:33:26.526570
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    n = provider.tracking_number()
    s = provider.ssn()
    p = provider.personality()
    assert n or s or p

# Unit test 2 for constructor of class USASpecProvider

# Generated at 2022-06-23 20:33:33.746297
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    tmp = USASpecProvider().personality()
    assert (tmp == "ISFJ" or tmp == "ISTJ" or tmp == "INFJ" or tmp == "INTJ" or tmp == "ISTP" or tmp == "ISFP" or tmp == "INFP" or tmp == "INTP" or tmp == "ESTP" or tmp == "ESFP" or tmp == "ENFP" or tmp == "ENTP" or tmp == "ESTJ" or tmp == "ESFJ" or tmp == "ENFJ" or tmp == "ENTJ")

# Generated at 2022-06-23 20:33:35.516129
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn) == 11

# Generated at 2022-06-23 20:33:42.940917
# Unit test for constructor of class USASpecProvider

# Generated at 2022-06-23 20:33:45.231858
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    prov = USASpecProvider()
    result = prov.tracking_number()
    assert type(result) == str

# Generated at 2022-06-23 20:33:54.130815
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    import pytest
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.us import USASpecProvider

    usa_spec_provider = USASpecProvider()

    with pytest.raises(NonEnumerableError):
        usa_spec_provider.personality(category='rheti')

    assert usa_spec_provider.gender(gender=Gender.MALE) == 'male'

    assert usa_spec_provider.gender(gender=Gender.FEMALE) == 'female'

    assert usa_spec_provider.race() == 'African American'

    assert usa_spec_provider.height() == '4.4'

    assert usa_spec_provider.weight() == '800.0'



# Generated at 2022-06-23 20:33:59.660925
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
	seed(11)
	t = USASpecProvider()
	assert t.tracking_number(service='usps') == '8665 5207 0507 2227 5853'
	assert t.tracking_number(service='fedex') == '1218 8144 4983'
	assert t.tracking_number(service='ups') == '1Z6F7V650327477911'


# Generated at 2022-06-23 20:34:07.481113
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""

    usa_provider = USASpecProvider()
    assert usa_provider.personality(category='rheti') in range(1, 11)

    assert usa_provider.personality() in 'ISFJISTJINFJINTJISTPISFPINFPINTPESTPESFPENFPENTPESTJESFJENFJENTJ'

    assert usa_provider.personality(category='rheti') in range(1, 11)

    assert usa_provider.personality(category='mbti') in 'ISFJISTJINFJINTJISTPISFPINFPINTPESTPESFPENFPENTPESTJESFJENFJENTJ'

# Generated at 2022-06-23 20:34:19.859452
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    
    from mimesis.enums import Personality
    from mimesis.providers.us_provider import USASpecProvider

    personnality_inst_1 = USASpecProvider()
    personnality_inst_1_1 = USASpecProvider()
    personnality_inst_2 = USASpecProvider()

    assert personnality_inst_1.personality(Personality.MBTI) != None, \
        "USASpecProvider#personnality : method should return a string or int"


    assert personnality_inst_1.personality(Personality.Rheti) != None, \
        "USASpecProvider#personnality : method should return a string or int"


# Generated at 2022-06-23 20:34:26.193819
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    answer_mbti = usa.personality('mbti')
    assert(len(answer_mbti) == 4)
    answer_rheti = usa.personality('rheti')
    assert(type(answer_rheti) == type(1))


# Generated at 2022-06-23 20:34:35.186693
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    usps = us.tracking_number(service='usps')
    fedex = us.tracking_number(service='fedex')
    ups = us.tracking_number(service='ups')

    assert isinstance(usps, str)
    assert isinstance(fedex, str)
    assert isinstance(ups, str)

    assert ' ' not in ups
    assert ups[2] != '@'
    assert ups[0] == '1'
    assert ups[1] == 'Z'
    assert ups[3] == '@'
    assert ups[4] != '@'
    assert ups[5] != '@'
    assert ups[6] == '@'
    assert ups[7] != '@'
    assert ups[8] != '@'

# Generated at 2022-06-23 20:34:40.701268
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Tests constructor of class USASpecProvider."""
    locale = 'en'
    seed = 42
    assert isinstance(USASpecProvider().spec, USASpecProvider)
    assert isinstance(USASpecProvider(seed=seed).spec, USASpecProvider)
    assert USASpecProvider(seed=seed).spec.seed == seed



# Generated at 2022-06-23 20:34:42.113662
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn().replace('-', '').isnumeric()

# Generated at 2022-06-23 20:34:43.577702
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usaps = USASpecProvider()
    assert isinstance(usaps.tracking_number(), str)


# Generated at 2022-06-23 20:34:45.709098
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    tracking_number = usa_spec_provider.tracking_number(service='usps')
    assert len(tracking_number) == 22



# Generated at 2022-06-23 20:34:54.935240
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Tracking number is valid."""
    provider = USASpecProvider()
    assert provider.tracking_number('usps').startswith('94')
    assert provider.tracking_number('usps').startswith('94')
    assert provider.tracking_number('usps').startswith('94')
    assert provider.tracking_number('usps').startswith('94')
    assert provider.tracking_number('usps').startswith('94')
    assert provider.tracking_number('usps').startswith('94')
    assert provider.tracking_number('usps').startswith('94')
    assert provider.tracking_number('usps').startswith('94')
    assert provider.tracking_number('usps').startswith('94')
    assert provider.tracking_number('usps').startswith('94')
