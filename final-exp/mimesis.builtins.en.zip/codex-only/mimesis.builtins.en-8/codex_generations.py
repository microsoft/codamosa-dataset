

# Generated at 2022-06-23 20:25:00.113357
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()

    tracking_number = usa_provider.tracking_number(service='USPS')
    assert len(tracking_number) == 22
    assert tracking_number.startswith('E')

    tracking_number = usa_provider.tracking_number(service='FedEx')
    assert len(tracking_number) == 12
    assert tracking_number.startswith('4')

    tracking_number = usa_provider.tracking_number(service='UPS')
    assert len(tracking_number) == 18
    assert tracking_number.startswith('1Z')

    tracking_number = usa_provider.tracking_number(service='Russian Post')
    assert tracking_number == ''



# Generated at 2022-06-23 20:25:01.429789
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11

# Generated at 2022-06-23 20:25:02.987280
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == '419-16-3444'

# Generated at 2022-06-23 20:25:05.705525
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Arrange
    post_service = "usps"
    temp = USASpecProvider()
    # Act
    result = temp.tracking_number(post_service)
    # Assert
    assert isinstance(result, str)


# Generated at 2022-06-23 20:25:09.619191
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                       'ISTP', 'ISFP', 'INFP', 'INTP',
                                       'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                       'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert 1 <= provider.personality(category='rheti') <= 10


# Generated at 2022-06-23 20:25:11.792873
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    assert usa_provider.ssn() == '898-65-3886'


# Generated at 2022-06-23 20:25:21.268383
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for method tracking_number of class USASpecProvider."""
    usa = USASpecProvider()
    tracking_number_ups = usa.tracking_number('ups')
    assert isinstance(tracking_number_ups, str)
    assert 15 == len(tracking_number_ups)
    assert '1Z' == tracking_number_ups[0:2]
    assert 'A' <= tracking_number_ups[2] <= 'Z'

    tracking_number_fedex = usa.tracking_number('fedex')
    assert isinstance(tracking_number_fedex, str)
    assert 12 == len(tracking_number_fedex)
    assert ' ' == tracking_number_fedex[3]
    assert ' ' == tracking_number_fedex[7]

    tracking_number_usps = usa.tracking_

# Generated at 2022-06-23 20:25:32.123010
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() == 'ISFJ'
    assert provider.personality() == 'INFJ'
    assert provider.personality() == 'ISFP'
    assert provider.personality() == 'ISFJ'
    assert provider.personality() == 'INFJ'
    assert provider.personality() == 'ENTP'
    assert provider.personality() == 'INFJ'
    assert provider.personality() == 'INFJ'
    assert provider.personality() == 'ISFJ'
    assert provider.personality() == 'ISFJ'
    assert provider.personality() == 'INFJ'
    assert provider.personality() == 'ISFJ'
    assert provider.personality() == 'ISTJ'

# Generated at 2022-06-23 20:25:33.789797
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    result = USASpecProvider().personality(category='rheti')
    assert type(result) == int and result <= 10


# Generated at 2022-06-23 20:25:37.091903
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    p = USASpecProvider()
    # USPS tracking number
    number = p.tracking_number('USPS')
    assert isinstance(number, str)
    # FedEx tracking number
    number = p.tracking_number('FedEx')
    assert isinstance(number, str)
    # UPS tracking number
    number = p.tracking_number('UPS')
    assert isinstance(number, str)


# Generated at 2022-06-23 20:25:39.979731
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():

    from mimesis.providers.usa_provider import USASpecProvider
    usa_ssn = USASpecProvider().ssn()

    assert len(usa_ssn) == 11
    assert isinstance(usa_ssn, str)

# Generated at 2022-06-23 20:25:48.056944
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test USASpecProvider.personality."""
    usa = USASpecProvider()
    assert usa.personality(category='rheti') in range(1, 11)
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')



# Generated at 2022-06-23 20:25:49.580443
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a=USASpecProvider().tracking_number(service='usps')
    assert len(a)==31


# Generated at 2022-06-23 20:25:54.062593
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:25:56.674927
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    provider.tracking_number("USPS")

# Generated at 2022-06-23 20:26:05.669287
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert USASpecProvider().personality('rheti') in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-23 20:26:09.529319
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider(seed=0)
    tracking_number = provider.tracking_number()
    ssn = provider.ssn()
    personality = provider.personality()
    assert tracking_number == '9265 7581 9049 1234'
    assert ssn == '354-96-3401'
    assert personality == 'INFJ'

# Generated at 2022-06-23 20:26:11.228098
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    assert (len(usa_provider.ssn().split('-')) == 3)

# Generated at 2022-06-23 20:26:19.457182
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    for i in range(0, 2):
        #assert provider.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        #                                'ISTP', 'ISFP', 'INFP', 'INTP',
        #                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
        #                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
        assert provider.personality(category='rheti') in range(1, 10)

# Generated at 2022-06-23 20:26:24.860322
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    ssn_set = set()
    for i in range(100000):
        ssn = USASpecProvider().ssn()
        assert len(ssn) == 11
        ssn_set.add(ssn)
    assert len(ssn_set) > 5000
    assert len(ssn_set) < 8800

# Unit tests for method tracking_number

# Generated at 2022-06-23 20:26:29.110999
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test constructor of class USASpecProvider"""
    # Create object
    obj = USASpecProvider()
    # Check is this object instance of class USASpecProvider
    assert isinstance(obj, USASpecProvider) == True


# Generated at 2022-06-23 20:26:33.076176
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    upp = USASpecProvider()

    assert upp.tracking_number('USPS') is not None
    assert upp.tracking_number('FedEx') is not None
    assert upp.tracking_number('UPS') is not None
    assert upp.tracking_number('DHL') is None


# Generated at 2022-06-23 20:26:33.934645
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider()

# Generated at 2022-06-23 20:26:38.152036
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.personality(), str)

# Generated at 2022-06-23 20:26:39.931013
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    assert isinstance(us, USASpecProvider)


# Generated at 2022-06-23 20:26:47.875706
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    data = USASpecProvider(seed=4)
    assert data.tracking_number('usps') == '4901 3607 7758 4142'
    assert data.tracking_number('FedEx') == '6313 6304 2822'
    assert data.tracking_number('UPS') == '1Z52A91E7616710193'
    assert data.ssn() == '872-38-9893'
    assert data.personality() == 'ENFJ'
    assert data.personality('rheti') == 4
    return True


# Generated at 2022-06-23 20:26:50.897657
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    country = USASpecProvider()
    print(country.tracking_number())
    print(country.ssn())
    print(country.personality())

test_USASpecProvider()

# Generated at 2022-06-23 20:26:56.418672
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    a = USASpecProvider()
    assert a.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                               'ISTP', 'ISFP', 'INFP', 'INTP',
                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert type(a.personality('rheti')) == int
    assert 1 <= a.personality('rheti') <= 10


# Generated at 2022-06-23 20:27:02.017339
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
        assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:27:07.313960
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() is not None
    assert USASpecProvider().tracking_number('usps') is not None
    assert USASpecProvider().tracking_number('fedex') is not None
    assert USASpecProvider().tracking_number('ups') is not None
    assert USASpecProvider().tracking_number('') is not None
    assert USASpecProvider().tracking_number('unknown') is not None

# Generated at 2022-06-23 20:27:16.317388
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    print("\nUnit test for method personality of class USASpecProvider")
    mbtis = ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    for _ in range(30):
        print("Your personality:", USASpecProvider().personality("mbti"))
        print("Your personality:", USASpecProvider().personality("rheti"))
    print("\n" * 3)



# Generated at 2022-06-23 20:27:18.707343
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider"""
    provider = USASpecProvider()
    # Assert class
    assert provider.__class__.__name__ == 'USASpecProvider'



# Generated at 2022-06-23 20:27:27.374096
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()

    for _ in range(1000):
        assert 'ESFJ' in provider.personality()
        assert 'ENTJ' in provider.personality()
        assert 'ENTP' not in provider.personality()
        assert 'ESTP' not in provider.personality()

    assert provider.personality(category='rheti') in range(1, 10)
    assert provider.personality(category='rheti') not in range(11, 15)


# Generated at 2022-06-23 20:27:34.577821
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.enums import PostService

    usps1 = USASpecProvider().tracking_number('usps')
    usps2 = USASpecProvider().tracking_number(PostService.USPS)
    assert usps1 == usps2

    fedex1 = USASpecProvider().tracking_number('fedex')
    fedex2 = USASpecProvider().tracking_number(PostService.FEDEX)
    assert fedex1 == fedex2

    ups1 = USASpecProvider().tracking_number('ups')
    ups2 = USASpecProvider().tracking_number(PostService.UPS)
    assert ups1 == ups2

# Generated at 2022-06-23 20:27:41.609559
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    expected = random.choice(mbtis)
    assert USASpecProvider().personality(category='mbti') == expected

    input_ = random.choice(['rheti'])
    assert 1 <= USASpecProvider().personality(category='rheti') <= 10

    input_ = random.choice(['mbti', '', 'rheti', 'rheti'])
    assert USASpecProvider().personality(category=input_) in mbtis + list(range(1, 11))

# Generated at 2022-06-23 20:27:43.789853
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert ssn.count('-') == 2
    assert len(ssn) == 11


# Generated at 2022-06-23 20:27:48.945856
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test docstring of class USASpecProvider attribute personality."""
    from mimesis.providers.us.us import USASpecProvider as us
    usa = us()
    assert usa.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ', ]



# Generated at 2022-06-23 20:27:50.374223
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() != provider.ssn()



# Generated at 2022-06-23 20:27:57.919023
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()

    # Validate length
    if not len(ssn) == 11:
        raise AssertionError("ssn did not validate length")

    # Validate dash placement
    if not ssn[3] == ssn[6] == '-':
        raise AssertionError("ssn did not validate dashes")

    # Validate area
    area = int(ssn[0:3])
    if not area > 0 and area < 900:
        raise AssertionError("ssn did not validate area")



# Generated at 2022-06-23 20:28:02.594302
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider, USASpecProvider)
    assert isinstance(usa_provider.random, object)
    assert isinstance(usa_provider.provider, object)
    assert usa_provider.localization == 'en'
    assert isinstance(usa_provider.seed, int)



# Generated at 2022-06-23 20:28:04.832887
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
	assert USASpecProvider().random.randint(1, 10) != None

# Generated at 2022-06-23 20:28:09.129747
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'

if __name__ == '__main__':
    test_USASpecProvider_ssn()

# Generated at 2022-06-23 20:28:12.134349
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_spec_provider = USASpecProvider()
    assert len(usa_spec_provider.ssn()) == 11


# Generated at 2022-06-23 20:28:15.371132
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider(seed=123)

    assert provider.personality() == 'ISFJ'
    assert provider.personality(category='rheti') == 5



# Generated at 2022-06-23 20:28:18.243330
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider(seed=222)
    provider.tracking_number(service='usps')
    # should return '4412 2481 7863 1207 1371'



# Generated at 2022-06-23 20:28:23.163913
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Tests for the constructor"""
    
    assert(USASpecProvider().tracking_number()!=USASpecProvider().tracking_number()) # tests the function tracking_number()
    assert(USASpecProvider().ssn()!=USASpecProvider().ssn()) # tests the function ssn()
    assert(USASpecProvider().personality()!=USASpecProvider().personality()) # tests the function personality()

# Generated at 2022-06-23 20:28:29.419165
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from random import seed
    from mimesis.providers.usa import USASpecProvider
    seed(39)

    usa = USASpecProvider()
    assert usa.tracking_number(service='USPS') == '9489 4239 0092 3003 4644'
    assert usa.tracking_number(service='USPS') == 'NJ 385 499 652 US'
    assert usa.tracking_number(service='USPS') == '5953 6403 0294 7963 2356'
    assert usa.tracking_number(service='USPS') == '7750 9500 9084 5889 7886'
    assert usa.tracking_number(service='USPS') == 'IN 314 544 906 US'
    assert usa.tracking_number(service='FedEx') == '4889 2518 7647'

# Generated at 2022-06-23 20:28:30.397893
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number()
    

# Generated at 2022-06-23 20:28:34.524381
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test USASpecProvider."""
    provider = USASpecProvider(seed=100)
    assert provider.__class__.__name__ == 'USASpecProvider'
    assert provider.random.seed == 100000


# Generated at 2022-06-23 20:28:38.628823
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    original_ssn_generator = USASpecProvider().ssn
    for _ in range(10000):
        assert len(original_ssn_generator()) == 11
        assert original_ssn_generator().count('-') == 2

# Generated at 2022-06-23 20:28:40.675463
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usaProvider = USASpecProvider()

    assert(usaProvider.tracking_number() != None)


# Generated at 2022-06-23 20:28:44.784714
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usssn = USASpecProvider()
    assert usssn.ssn() == '651-01-2947'
    assert len(usssn.ssn()) == 11


# Generated at 2022-06-23 20:28:48.149121
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us_spec = USASpecProvider()
    US_SSN = us_spec.ssn()
    assert len(US_SSN) == 11
    assert US_SSN[3] == '-'
    assert US_SSN[6] == '-'


# Generated at 2022-06-23 20:28:56.028582
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    usaspecprovider = USASpecProvider()
    assert usaspecprovider.tracking_number() != ''
    assert usaspecprovider.tracking_number('usps') != ''
    assert usaspecprovider.tracking_number('fedex') != ''
    assert usaspecprovider.tracking_number('ups') != ''
    assert usaspecprovider.tracking_number('unsupported') == ValueError


# Generated at 2022-06-23 20:29:01.864313
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert len(provider.tracking_number(service="ups")) == 18
    assert len(provider.tracking_number(service="fedex")) == 17
    assert len(provider.tracking_number(service="usps")) == 30
    assert len(provider.tracking_number(service="ups")) == 18
    assert len(provider.tracking_number(service="fedex")) == 17
    assert len(provider.tracking_number(service="usps")) == 30


# Generated at 2022-06-23 20:29:05.303496
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usaspec = USASpecProvider()
    assert usaspec.__class__.__name__ == 'USASpecProvider'

# Generated at 2022-06-23 20:29:09.956088
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number()
    assert usa_provider.tracking_number(service='fedex')
    assert usa_provider.tracking_number(service='ups')
    assert usa_provider.tracking_number(service='usps')


# Generated at 2022-06-23 20:29:14.166218
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.specifiers.usa import USASpecProvider

    usa = USASpecProvider()

    assert usa.ssn() == '142-32-4331'
    assert usa.ssn() == '544-74-7323'


# Generated at 2022-06-23 20:29:18.885373
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test the method ssn of class USASpecProvider."""
    usa_provider = USASpecProvider()
    result = usa_provider.ssn()
    assert len(result) == 11
    assert result[3] == result[6] == '-'

# Generated at 2022-06-23 20:29:20.678812
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Check random personality type"""
    assert type(USASpecProvider().personality()) == str


# Generated at 2022-06-23 20:29:22.046223
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number()


# Generated at 2022-06-23 20:29:23.898124
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    limit = 10
    for i in range(0, limit):
        us.tracking_number()


# Generated at 2022-06-23 20:29:26.207404
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number("UPS")[0] == "1"
    assert usa.tracking_number("USPS")[0] != "1"


# Generated at 2022-06-23 20:29:27.472724
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    ssn = USASpecProvider().ssn()
    assert ssn.isdigit() == False
    assert len(ssn) == 11


# Generated at 2022-06-23 20:29:36.729563
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    from mimesis.providers.geography.en import ENSpecProvider
    from mimesis.providers.person import Person

    p = Person('en')
    g = ENSpecProvider(seed=42)
    u = USASpecProvider(seed=42)

    ssn = u.ssn()

    # SSN has format xxx-xx-xxxx
    assert ssn[3] == '-'
    assert ssn[6] == '-'

    # SSN area is between 1 and 899
    assert int(ssn[0:3]) in list(range(1, 899))

    # SSN group is between 1 and 99
    assert int(ssn[4:6]) in list(range(1, 99))

    # SSN serial is between 1 and 9999
   

# Generated at 2022-06-23 20:29:43.683848
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    import unittest.mock as mock
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    usa_provider = USASpecProvider()

    assert isinstance(usa_provider, USASpecProvider)
    assert usa_provider.meta.name == 'usa_provider'

    # Check that provider is initialised as expected
    with mock.patch.object(Person, '__init__', return_value=None) as p:
        with mock.patch.object(Address, '__init__', return_value=None) as a:
            p.assert_called_once_with(seed=usa_provider.seed, locale='en')

# Generated at 2022-06-23 20:29:48.012433
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test provider of USA."""
    # Arrange
    # Action
    provider = USASpecProvider()

    # Assert
    assert isinstance(provider, USASpecProvider)
    assert provider.__class__.Meta.name == 'usa_provider'


# Generated at 2022-06-23 20:29:49.813432
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    for i in range(100):
        assert len(USASpecProvider().ssn()) == 11


# Generated at 2022-06-23 20:29:55.206449
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality(category='rheti') in range(1, 11)
    assert provider.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP',
                                                     'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:30:05.681556
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    provider = USASpecProvider()

    # test for USPS
    assert re.match('^[0-9]{20}$', provider.tracking_number('USPS')) is not None
    assert re.match('^[A-Z]{10}(US)?$', provider.tracking_number('USPS')) is not None

    # test for FedEx
    assert re.match('^[0-9]{12}$', provider.tracking_number('FedEx')) is not None
    assert re.match('^[0-9]{15}$', provider.tracking_number('FedEx')) is not None

    # test for UPS

# Generated at 2022-06-23 20:30:07.009658
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number()



# Generated at 2022-06-23 20:30:14.565471
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usaSpecProvider = USASpecProvider()

    assert isinstance(usaSpecProvider.tracking_number(), str) is True
    assert isinstance(usaSpecProvider.tracking_number('usps'), str) is True
    assert isinstance(usaSpecProvider.tracking_number('fedex'), str) is True
    assert isinstance(usaSpecProvider.tracking_number('ups'), str) is True
    assert (
        isinstance(usaSpecProvider.tracking_number('non_existing_service'),
                  str) is False) is True


# Generated at 2022-06-23 20:30:22.453626
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    count = 0
    def usps_tracking_number():
        nonlocal count
        count += 1
        return '#### #### #### #### ####'

    def fedex_tracking_number():
        nonlocal count
        count += 1
        return '#### #### ####'

    def ups_tracking_number():
        nonlocal count
        count += 1
        return '1Z@####@##########'

    class MockRandom(object):
        def choice(self, seq):
            return usps_tracking_number()

        def custom_code(self, mask):
            return '1406 7058 7060 0050 5333'
    mr = MockRandom()


# Generated at 2022-06-23 20:30:24.605632
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usaspecprovider = USASpecProvider()
    assert (usaspecprovider)


# Generated at 2022-06-23 20:30:33.194846
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    tracking = usa_provider.tracking_number('usps')
    assert len(tracking) == 34
    assert tracking[0] in '0123456789'
    #assert tracking[1] in '0123456789'
    assert tracking[2] in '0123456789'
    assert tracking[3] in '0123456789'
    assert tracking[4] == ' '
    assert tracking[5] in '0123456789'
    assert tracking[6] in '0123456789'
    assert tracking[7] in '0123456789'
    assert tracking[8] in '0123456789'
    assert tracking[9] == ' '
    assert tracking[10] in '0123456789'

# Generated at 2022-06-23 20:30:35.585508
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
  usa_spec_provider = USASpecProvider()
  for i in range(10):
    assert len(usa_spec_provider.ssn()) == 11


# Generated at 2022-06-23 20:30:36.491041
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider()


# Generated at 2022-06-23 20:30:44.301133
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Testing method tracking_number of class USASpecProvider."""

    service_map = {
        "ups": ("1Z 123 456 7 890 123 456 7", ),
        "fedex": ("1234 1234 1234", "1234 1234 1234 1234", ),
        "usps": ("1234 1234 1234 1234 1234", "AB 123 123 123 US", ),
    }

    for service_name, mask_tuples in service_map.items():
        for mask in mask_tuples:
            assert len(mask) == len(USASpecProvider().tracking_number(
                service_name
            ))

# Generated at 2022-06-23 20:30:47.881711
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number('usps') == '5112 6409 9051 3256 3292'
    assert USASpecProvider().tracking_number('ups') == '1Z85284A1348471765'
    assert USASpecProvider().tracking_number('fedex') == '5402 2460 9424'


# Generated at 2022-06-23 20:30:51.888399
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert(USASpecProvider.generator('en').ssn())
    assert(USASpecProvider.generator(locale='en').ssn())


# Generated at 2022-06-23 20:30:56.099502
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test generation of tracking numbers by post services."""
    prov = USASpecProvider()
    assert prov.tracking_number()
    assert prov.tracking_number(service='usps')
    assert prov.tracking_number(service='fedex')
    assert prov.tracking_number(service='ups')



# Generated at 2022-06-23 20:31:03.062006
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from pprint import pprint
    from mimesis import USASpecProvider
    usa_spec_provider = USASpecProvider()
    pprint(usa_spec_provider.tracking_number(service='usps'))
    pprint(usa_spec_provider.tracking_number(service='fedex'))
    pprint(usa_spec_provider.tracking_number(service='ups'))
    pprint(usa_spec_provider.tracking_number(service='usps'))
    pprint(usa_spec_provider.tracking_number(service='usps'))


# Generated at 2022-06-23 20:31:10.009593
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa.personality('rheti'), int)
    assert usa.personality('rheti') in range(1,11)


# Generated at 2022-06-23 20:31:12.276195
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    result0 = provider.ssn()
    assert result0
    assert len(result0) == 11
    assert result0[3] == '-'
    assert result0[6] == '-'


# Generated at 2022-06-23 20:31:14.811242
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    ssn = usa.ssn()
    if not ssn:
        raise Exception('Generated an empty SSN')


# Generated at 2022-06-23 20:31:20.905319
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method 'tracking_number' of class 'USASpecProvider'."""
    usa_provider = USASpecProvider()
    number = usa_provider.tracking_number()
    assert number
    assert isinstance(number, str)
    assert len(number) in (18, 22)

    number = usa_provider.tracking_number('UPS')
    assert number
    assert isinstance(number, str)
    assert len(number) == 18

    number = usa_provider.tracking_number('FedEx')
    assert number
    assert isinstance(number, str)
    assert len(number) in (12, 15)

# Generated at 2022-06-23 20:31:27.593563
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    import pytest
    x = USASpecProvider()
    with pytest.raises(TypeError):
        x.personality()


    y = x.personality('rheti')
    assert type(y) == int
    assert y >= 1


    z = x.personality('mbti')
    assert type(z) == str
    assert z in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:31:33.110318
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    usa_provider.seed(8)
    assert usa_provider.personality() == 'INTP'
    assert usa_provider.personality() != 'INTJ'
    assert usa_provider.personality() != 'ISFJ'


# Generated at 2022-06-23 20:31:38.560833
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:31:41.237184
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider(seed=None)
    usa_provider.personality(category="rheti")
    usa_provider.personality(category="mbti")



# Generated at 2022-06-23 20:31:44.681285
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    usps = us.tracking_number(service='USPS')
    assert len(usps) == 22

    fedex = us.tracking_number(service='Fedex')
    assert len(fedex) == 22

    ups = us.tracking_number(service='UPS')
    assert len(ups) == 18

# Generated at 2022-06-23 20:31:46.641570
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    assert usa.ssn() == '000-00-0000'

# Generated at 2022-06-23 20:31:48.848433
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa is not None, 'Should be initialized without fail'


# Generated at 2022-06-23 20:31:50.050382
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11

# Generated at 2022-06-23 20:31:53.039912
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider(seed=123).personality(category='rheti') == 10
    assert USASpecProvider(seed=123).personality() == 'ISFJ'

# Generated at 2022-06-23 20:31:57.462938
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    from mimesis.enums import PostService

    ssn = USASpecProvider().tracking_number(PostService.USPS)
    assert type(ssn) is str
    assert len(ssn) == 26



# Generated at 2022-06-23 20:32:03.679373
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider(seed=12345)
    # USPS: 2016 8991 1781 4581 5337
    assert provider.tracking_number(service='USPS') == '2016 8991 1781 4581 5337'
    # UPS: 1Z81578X0304257313
    assert provider.tracking_number(service='UPS') == '1Z81578X0304257313'
    # FedEx: 9295 0710 5245
    assert provider.tracking_number(service='FedEx') == '9295 0710 5245'


# Generated at 2022-06-23 20:32:06.962505
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for method tracking_number of class USASpecProvider."""
    provider = USASpecProvider()
    assert len(provider.tracking_number()) == 22


# Generated at 2022-06-23 20:32:10.574007
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider_ssn = USASpecProvider(seed=None)
    assert usa_provider_ssn.ssn()  # XXX: Change this

# Generated at 2022-06-23 20:32:12.366498
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == '566-68-5044'

# Generated at 2022-06-23 20:32:22.774981
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for USASpecProvider method ssn."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    ssn = USASpecProvider()
    assert len(ssn.ssn()) == 11
    assert ssn.ssn().count('-') == 2

    person = Person('en', seed='1234567890')
    person.add_gender_extra_rules(Gender.MALE, Gender.FEMALE)

    for i in range(1000):
        gender = person.gender()
        assert len(person.ssn()) == 11
        assert person.ssn().count('-') == 2

# Generated at 2022-06-23 20:32:26.909404
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.mbti() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:32:28.966642
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert usa_provider.__class__.__name__ == "USASpecProvider"


# Generated at 2022-06-23 20:32:34.945118
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_spec = USASpecProvider()
    usps_number = us_spec.tracking_number(service='USPS')
    print('USPS Tracking Number:', usps_number)
    fedex_number = us_spec.tracking_number(service='FedEx')
    print('FedEx Tracking Number:', fedex_number)
    ups_number = us_spec.tracking_number(service='UPS')
    print('UPS Tracking Number:', ups_number)


# Generated at 2022-06-23 20:32:42.558150
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa_spec_provider.personality(category='rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    

# Generated at 2022-06-23 20:32:44.973711
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Unit test for method personality of class USASpecProvider
    provider = USASpecProvider()
    assert type(provider.personality(category='mbti')) == str

# Generated at 2022-06-23 20:32:54.697482
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Testing for unit test for method personality of class USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert isinstance(usa_spec_provider.personality('rheti'), int)
    #assert usa_spec_provider.personality('rheti') in range(1, 11)

# Generated at 2022-06-23 20:32:57.600647
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    test_USASpecProvider = USASpecProvider(seed=5)
    # test_USASpecProvider.seed = 5
    print(test_USASpecProvider.seed)


# Generated at 2022-06-23 20:33:01.689795
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_provider = USASpecProvider()
    test_cases = [
        ('usps'),
        ('fedex'),
        ('ups'),
    ]
    for i in test_cases:
        assert isinstance(us_provider.tracking_number(service=i), str)
        print("result of tracking_number() with service=%s: %s" % (i, us_provider.tracking_number(service=i)))


# Generated at 2022-06-23 20:33:03.059868
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider(seed=None).seed is not None


# Generated at 2022-06-23 20:33:05.521706
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider"""
    sp = USASpecProvider()
    assert isinstance(sp, USASpecProvider)


# Generated at 2022-06-23 20:33:06.967595
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert 1 == len(USASpecProvider().ssn())


# Generated at 2022-06-23 20:33:13.296014
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking_number = provider.tracking_number('ups')
    tracking_number_2 = provider.tracking_number('usps')
    tracking_number_3 = provider.tracking_number('fedex')

    assert isinstance(tracking_number, str)
    assert isinstance(tracking_number_2, str)
    assert isinstance(tracking_number_3, str)



# Generated at 2022-06-23 20:33:20.025073
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for method tracking_number.
       Verify method return the tracking number of post service.
    """
    usa_provider = USASpecProvider(seed=12345)
    assert usa_provider.tracking_number(service='usps') == '5918 7339 0761 5247 9706'
    assert usa_provider.tracking_number(service='fedex') == '9376 7566 8187'
    assert usa_provider.tracking_number(service='ups') == '1Z2F9X9A6694414519'
    return True



# Generated at 2022-06-23 20:33:27.790375
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn_generated = provider.ssn()
    assert len(ssn_generated) == 11
    assert ssn_generated[3] == '-'
    parsed_ssn = ssn_generated.split('-')
    assert int(parsed_ssn[0]) in range(1, 899)
    assert int(parsed_ssn[1]) in range(1, 99)
    assert int(parsed_ssn[2]) in range(1, 9999)


# Generated at 2022-06-23 20:33:31.812195
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    a = USASpecProvider()
    assert a.personality(category='rheti') in range(1, 11)
    assert a.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                              'ISTP', 'ISFP', 'INFP', 'INTP',
                                              'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                              'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']



# Generated at 2022-06-23 20:33:41.014386
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_provider.personality(category='rheti'), int)
    assert usa_provider.personality(category='rheti') in list(range(1, 11))


# Generated at 2022-06-23 20:33:45.049757
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    sp = USASpecProvider()
    for i in range(5):
        service = sp.random.choice(['USPS', 'UPS', 'FedEx'])
        tracking_number = sp.tracking_number(service)
        assert len(tracking_number) > 0


# Generated at 2022-06-23 20:33:54.011332
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    random = USASpecProvider()
    print("random.personality() : ", random.personality())
    # random.personality() :  ENFJ
    print("random.ssn() : ", random.ssn())
    # random.ssn() :  500-28-4986
    print("random.tracking_number() : ", random.tracking_number())
    # random.tracking_number() :  9380 7799 0231 9915
    print("random.tracking_number(service='fedex') : ", random.tracking_number(service='fedex'))
    # random.tracking_number(service='fedex') :  8695 3186 452
    print("random.tracking_number(service='ups') : ", random.tracking_number(service='ups'))
    # random.tracking_number(service='ups') : 

# Generated at 2022-06-23 20:33:56.319921
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider is not None



# Generated at 2022-06-23 20:33:59.399005
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Initialize class
    us_provider = USASpecProvider(seed=1234567890)

    # Call function
    assert us_provider.ssn() == '468-25-7549'

# Generated at 2022-06-23 20:34:01.828365
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    try:
        c = USASpecProvider()
    except:
        print("Unable to create instance of USASpecProvider")
        assert False
    assert True


# Generated at 2022-06-23 20:34:05.269237
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """ Test the tracking_number method of the USASpecProvider class
    """
    gen = USASpecProvider()
    tracking_number = gen.tracking_number()
    assert len(tracking_number) == 11 or len(tracking_number) == 18, "the length of the tracking number must be 11 or 18"



# Generated at 2022-06-23 20:34:07.829375
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test case for method personality() of class USASpecProvider."""
    provider = USASpecProvider()

    assert(len(provider.personality(category='rheti'))==1)
    assert(len(provider.personality(category='mbti'))==4)

# Generated at 2022-06-23 20:34:12.715548
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    a = USASpecProvider(seed=12345678)
    b = USASpecProvider(seed=12345678)
    assert a.personality() == "ISFJ"
    assert a.personality() == b.personality()


# Generated at 2022-06-23 20:34:13.799025
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test USASpecProvider."""
    USASpecProvider()
    USASpecProvider(seed=123456)



# Generated at 2022-06-23 20:34:18.340849
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """
    Given an instance of USASpecProvider, when tracking_number is called,
    then a tracking number should be returned.
    """
    provider = USASpecProvider(seed=10)
    assert provider.tracking_number() == '1214 7745 4457 1040 0389'

# Generated at 2022-06-23 20:34:19.986887
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert len(USASpecProvider().tracking_number()) == 14 or 18 or 22


# Generated at 2022-06-23 20:34:24.269423
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print("\nTest USASpecProvider")
    provider = USASpecProvider()
    assert isinstance(provider, USASpecProvider)
    print("\ttest_USASpecProvider: Okay")


# Generated at 2022-06-23 20:34:31.793095
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
  usa_provider = USASpecProvider()
  assert usa_provider.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                              'ISTP', 'ISFP', 'INFP', 'INTP',
                                              'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                              'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
  assert usa_provider.personality('rheti') in range(1, 10)


# Generated at 2022-06-23 20:34:33.183279
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Check the method USASpecProvider.ssn
    assert USASpecProvider().ssn() == '568-05-7657'

# Generated at 2022-06-23 20:34:38.064389
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality('mbti') in {
        'ISFJ',
        'ISTJ',
        'INFJ',
        'INTJ',
        'ISTP',
        'ISFP',
        'INFP',
        'INTP',
        'ESTP',
        'ESFP',
        'ENFP',
        'ENTP',
        'ESTJ',
        'ESFJ',
        'ENFJ',
        'ENTJ'
    }

    assert type(provider.personality('rheti')) is int



# Generated at 2022-06-23 20:34:40.089277
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tmp = USASpecProvider().tracking_number('USPS')
    assert isinstance(tmp, str)
    assert len(tmp) > 0



# Generated at 2022-06-23 20:34:42.649188
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test of method ssn of class USASpecProvider"""
    us_provider = USASpecProvider()
    assert len(us_provider.ssn()) == 11

# Generated at 2022-06-23 20:34:44.890613
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    try:
        USASpecProvider()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-23 20:34:51.639146
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality of class USASpecProvider."""
    usa = USASpecProvider()
    val1 = usa.personality()
    # assert alpha
    assert val1 in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    val2 = usa.personality('rheti')
    # assert integer
    assert isinstance(val2, int)
    # assert value in range 1-10
    assert val2 in range(1, 11)

    # assert exception

# Generated at 2022-06-23 20:34:56.096457
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
	ssn_col = []
	for i in range(100000):
		ssn = USASpecProvider().ssn()
		ssn_col.append(ssn)
	print(ssn_col)
	print(ssn_col[0], ssn_col[-1])
	