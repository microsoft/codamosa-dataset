

# Generated at 2022-06-23 20:24:56.978028
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_provider = USASpecProvider()
    assert us_provider.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:24:59.623755
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    data_provider = USASpecProvider()
    tracking_number = data_provider.tracking_number(service='usps')
    tracking_number_len = len(tracking_number)
    assert tracking_number_len == 22, "The tracking_number length is not 22"
    

# Generated at 2022-06-23 20:25:05.354137
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP',
                                       'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert 0 < usa.personality('rheti') <= 10


# Generated at 2022-06-23 20:25:06.798794
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of Class USASpecProvider."""
    USASpecProvider().ssn()

# Generated at 2022-06-23 20:25:11.600900
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    n = 100
    ssn = []
    while n > 0:
        ssn.append(USASpecProvider().ssn())
        n -= 1
    a = [re.match(r'\d{3}-\d{2}-\d{4}', x) for x in ssn]
    assert all(a)

# Generated at 2022-06-23 20:25:16.981738
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # 7.701
    provider = USASpecProvider()
    personality = provider.personality()
    assert personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                           'ISTP', 'ISFP', 'INFP', 'INTP',
                           'ESTP', 'ESFP', 'ENFP', 'ENTP',
                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    personality = provider.personality('rheti')
    assert personality in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)


# Generated at 2022-06-23 20:25:19.418415
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test the private constructor of class USASpecProvider."""
    usa_provider = USASpecProvider(seed=123)
    assert isinstance(usa_provider, USASpecProvider)



# Generated at 2022-06-23 20:25:24.840290
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test USASpecProvider."""
    provider = USASpecProvider()
    usps_pattern = '#### #### #### #### ####'
    assert provider.tracking_number(service='usps') in usps_pattern
    assert provider.tracking_number(service='USPS') not in usps_pattern
    assert provider.tracking_number(service='fedex') in '#### #### ####'
    assert provider.tracking_number(service='ups') in '1Z@####@##########'
    assert provider.ssn() in '###-##-####'
    assert provider.tracking_number(service='fake') == ValueError

# Generated at 2022-06-23 20:25:30.582041
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality(): #test_USASpecProvider_personality
    from mimesis.enums import Category

    usa_provider = USASpecProvider(seed=4)
    assert usa_provider.personality() == 'INTJ'
    assert usa_provider.personality(Category.RANDOM) == 8
    assert usa_provider.random.choice(('ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')) == 'ENFJ'



# Generated at 2022-06-23 20:25:35.162065
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Testing constructor method of USASpecProvider class."""
    from mimesis.enums import Gender

    p = USASpecProvider()
    assert p.gender == Gender.MALE, "ERROR: Error in constructor method of USASpecProvider class."
    assert p.locale == 'en', "ERROR: Error in constructor method of USASpecProvider class."



# Generated at 2022-06-23 20:25:39.222991
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test the constructor of class USASpecProvider."""
    usa = USASpecProvider()
    ssn = usa.ssn()
    tracking_num = usa.tracking_number(service='usps')
    personality = usa.personality(category='rheti')
    assert isinstance(ssn, str)
    assert isinstance(tracking_num, str)
    assert isinstance(personality, int)
    assert ssn != ''
    assert tracking_num != ''
    assert personality != ''


# Generated at 2022-06-23 20:25:40.817368
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    u = USASpecProvider()
    assert isinstance(u, USASpecProvider)


# Generated at 2022-06-23 20:25:44.832382
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Arrange
    random_engine = 'faker'
    seed = '1234567890'
    us_provider = USASpecProvider(seed)
    us_provider.random.set_random_engine(random_engine)

    service = 'UPS'
    expected = '1Z1A1B1C1D1E1F1G1H1I'

    # Act
    actual = us_provider.tracking_number(service)

    # Assert
    assert expected == actual



# Generated at 2022-06-23 20:25:49.333455
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    USASpecProvider_1 = USASpecProvider()
    USASpecProvider_2 = USASpecProvider()
    USASpecProvider_3 = USASpecProvider()
    tracking_number_1 = USASpecProvider_1.tracking_number(service='usps')
    tracking_number_2 = USASpecProvider_2.tracking_number(service='fedex')
    tracking_number_3 = USASpecProvider_3.tracking_number(service='ups')
    print(tracking_number_1)
    print(tracking_number_2)
    print(tracking_number_3)
    
    

# Generated at 2022-06-23 20:25:50.911169
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == "437-54-6211"

# Generated at 2022-06-23 20:26:00.220773
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.personal import Personal
    from mimesis.providers.us_address import USAddress
    usa = USASpecProvider()
    assert usa.tracking_number() != usa.tracking_number()
    assert usa.tracking_number(service='FedEx') != usa.tracking_number(service='FedEx')
    assert usa.tracking_number(service='UPS') != usa.tracking_number(service='UPS')
    assert usa.ssn() != usa.ssn()
    assert usa.personality() != usa.personality()
    assert usa.personality(category='rheti') != usa

# Generated at 2022-06-23 20:26:01.936279
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider()
    assert len(us.ssn())==11


# Generated at 2022-06-23 20:26:04.435362
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for class USASpecProvider"""
    provider = USASpecProvider(seed=12345)
    assert isinstance(provider.ssn(), str)
    assert isinstance(provider.tracking_number(), str)

# Generated at 2022-06-23 20:26:07.476656
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
	
	import re

	provider = USASpecProvider()
	my_ssn = provider.ssn()
	assert re.match(r'[0-9]{3}-[0-9]{2}-[0-9]{4}', my_ssn) is not None



# Generated at 2022-06-23 20:26:08.941430
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usap = USASpecProvider()
    assert (usap is not None)


# Generated at 2022-06-23 20:26:10.779444
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.ssn(), str)



# Generated at 2022-06-23 20:26:15.850565
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider(seed=0)
    assert provider.tracking_number(service='usps') == '9101 5373 5729 1894 9264'
    assert provider.tracking_number(service='usps') == 'XN 368 002 952 US'
    assert provider.tracking_number(service='fedex') == '2892 4167 9473'
    assert provider.tracking_number(service='fedex') == '0381 2487 7240'
    assert provider.tracking_number(service='ups') == '1Z0P10B43129119933'


# Generated at 2022-06-23 20:26:20.834224
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test ssn method"""
    seed = "afs8dvaf"
    expected = "117-36-4937"
    actual = USASpecProvider(seed=seed).ssn()
    assert actual == expected, "Expected: " + str(expected) + " But was: " + str(actual)

if __name__ == '__main__':
    test_USASpecProvider_ssn()

# Generated at 2022-06-23 20:26:22.982700
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    valid_ssn = '123-45-6789'
    assert provider.ssn()


# Generated at 2022-06-23 20:26:25.456363
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.__class__.__name__ == 'USASpecProvider'
    assert usa.__class__.Meta.name == 'usa_provider'


# Generated at 2022-06-23 20:26:27.943129
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    import re
    from mimesis.typing import Seed
    provider = USASpecProvider(Seed())
    ssn = provider.ssn()
    assert re.match(r'\d{3}-\d{2}-\d{4}', ssn), "Wrong format of SSN"

# Generated at 2022-06-23 20:26:31.110819
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for USASpecProvider"""
    usa_spec_provider = USASpecProvider(seed=42)

    assert usa_spec_provider is not None
    assert usa_spec_provider.random is not None


# Generated at 2022-06-23 20:26:33.236105
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    #print(usa.ssn())
    #print(usa.ssn())


# Generated at 2022-06-23 20:26:41.023699
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert str(usa_provider.personality('rheti')) in '12345678910'

# Generated at 2022-06-23 20:26:51.224291
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    import math
    from typing import NoReturn
    from hypothesis import given
    from hypothesis.strategies import text, integers
    from mimesis import Generic
    from mimesis.enums import Gender
    from mimesis.typing import LocalizedType

    @given(category=text())
    def test_personality(category):
        provider = USASpecProvider()
        result = provider.personality(category=category)

        if not isinstance(result, LocalizedType):
            raise TypeError(f'\nExpected type: {LocalizedType}\nActual type: {type(result)}')

        if len(result) > 7 and not isinstance(result, int):
            raise ValueError(f'\nExpected value of length 1 to 7\nActual value: {result}')


# Generated at 2022-06-23 20:26:58.410647
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    test = USASpecProvider()
    assert test.tracking_number(service='usps') == '9458 8153 5402 7043 3585'
    assert test.tracking_number(service='usps') == '52 260 079 830 US'
    assert test.tracking_number(service='UPS') == '1Z1458YV8299201363'
    assert test.tracking_number(service='UPS') == '1Z6E04Z66694255550'
    assert test.tracking_number(service='FedEx') == '5656 2994 5412'
    assert test.tracking_number(service='FedEx') == '4342 5227 9688'
    # test if service is valid or not
    try:
        assert test.tracking_number(service='null')
    except ValueError:
        assert True


# Generated at 2022-06-23 20:27:04.787166
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:27:07.194259
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for USASpecProvider.ssn()"""
    foo = USASpecProvider()
    assert len(foo.ssn()) == 11


# Generated at 2022-06-23 20:27:14.424059
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # create data
    provider = USASpecProvider(seed=1)
    # test
    assert provider.personality() == "ENFJ"
    assert provider.personality('rheti') == 3
    assert provider.personality('rheti') == 1
    assert provider.personality('rheti') == 7
    assert provider.personality('rheti') == 7
    assert provider.personality('rheti') == 8
    assert provider.personality('rheti') == 6


# Generated at 2022-06-23 20:27:19.489207
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    result = usa_provider.ssn()
    assert len(result) == 11
    assert result[3] == '-'
    assert result[6] == '-'
    assert result[0:3].isdigit()
    assert result[4:6].isdigit()
    assert result[7:11].isdigit()
    assert result[0:3] != '666'


# Generated at 2022-06-23 20:27:25.407708
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test gen_ssn method of class USASpecProvider."""
    from . import en

    provider = en.USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'



# Generated at 2022-06-23 20:27:27.668677
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert(len(ssn) == 11)

# Generated at 2022-06-23 20:27:30.822110
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """."""
    result = USASpecProvider(seed=12345).personality(category='rheti')
    assert result == 5
    assert result == 5, 'Test success.'


# Generated at 2022-06-23 20:27:40.567016
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    usps_tracking_number = usa_provider.tracking_number()
    assert isinstance(usps_tracking_number, str)
    assert len(usps_tracking_number) == 29
    assert usps_tracking_number[0].isdigit()
    assert usps_tracking_number[1].isdigit()
    assert usps_tracking_number[2].isdigit()
    assert usps_tracking_number[3].isdigit()
    assert usps_tracking_number[4] == ' '
    assert usps_tracking_number[5].isdigit()
    assert usps_tracking_number[6].isdigit()
    assert usps_tracking_number[7].isdigit()

# Generated at 2022-06-23 20:27:43.839914
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    usa_provider.random.set_random_seed(3)
    assert usa_provider.ssn() == "511-28-9816"

# Unit test method tracking_number of class USASpecProvider

# Generated at 2022-06-23 20:27:51.202655
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    import sys
    import doctest
    from mimesis.enums import PostService
    from mimesis.providers.usa_provider import USASpecProvider
    from random import SystemRandom
    results = doctest.testmod()
    if results.failed == 0:
        sys.stdout.write("TEST PASSED")
    else:
        sys.stdout.write("TEST FAILED")
    usa = USASpecProvider(seed=SystemRandom())
    assert usa.tracking_number()
    assert usa.tracking_number(str(PostService.UPS))
    assert usa.tracking_number(str(PostService.USPS))
    assert usa.tracking_number(str(PostService.FEDEX))


# Generated at 2022-06-23 20:27:54.135089
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    with USASpecProvider() as provider:
        rv = provider.tracking_number()
        assert isinstance(rv, str)
        assert len(rv) in (15, 22)


# Generated at 2022-06-23 20:27:57.256344
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    for _ in range(100):
        ssn = USASpecProvider().ssn()
        assert re.match(r'\d{3}-\d{2}-\d{4}', ssn)



# Generated at 2022-06-23 20:28:02.381342
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number('usps') == '6427 4522 6647 5432 7272'
    assert usa_provider.tracking_number('fedex') == '1234 5678 9012'
    assert usa_provider.tracking_number('ups') == '1Z9X1F848E63081522'

# Generated at 2022-06-23 20:28:10.108829
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """
    Test is method ssn of class USASpecProvider generate valid data
    """
    ssn = USASpecProvider().ssn()
    assert len(ssn) == 11
    assert ssn[0] not in ('0', '9')
    assert ssn[4] == '-'
    assert ssn[7] == '-'
    assert 0 < int(ssn[1:4]) < 900
    assert 0 <= int(ssn[5:7]) <= 99
    assert 0 <= int(ssn[8:]) <= 9999

# Generated at 2022-06-23 20:28:17.575693
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                       'ISTP', 'ISFP', 'INFP', 'INTP',
                                       'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                       'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert type(usa.personality('rheti')) == int


# Generated at 2022-06-23 20:28:20.099837
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)
    assert usa.locale == 'en'


# Generated at 2022-06-23 20:28:22.452946
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider."""
    spec_provider = USASpecProvider()
    assert spec_provider is not None


# Generated at 2022-06-23 20:28:25.087272
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    print("USASpecProvider.provider: ", usa_provider.provider)
    assert usa_provider.provider == "usa_provider"


# Generated at 2022-06-23 20:28:31.054384
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Create a class object and test his method
    usa = USASpecProvider()
    ssn = usa.ssn()
    assert(len(ssn) == 11)
    assert(ssn[3] == '-')
    assert(ssn[6] == '-')
    assert(ssn.isdigit())

# Generated at 2022-06-23 20:28:36.839069
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.__class__.__name__ == 'USASpecProvider'
    assert issubclass(usa.__class__, BaseSpecProvider)
    assert hasattr(usa, 'Meta')
    assert hasattr(usa, 'random')
    assert hasattr(usa, 'seed')
    assert isinstance(usa.seed, Seed)
    assert hasattr(usa, 'localization')
    assert isinstance(usa.localization, dict)
    assert hasattr(usa, '__version__')


# Generated at 2022-06-23 20:28:39.161701
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider(seed=1234)
    assert USASpecProvider(seed=1234).__repr__()


# Generated at 2022-06-23 20:28:43.016387
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    print(usa.tracking_number(service='usps'))
    print(usa.ssn())
    print(usa.personality(category='rheti'))

if __name__ == "__main__":
    test_USASpecProvider()

# Generated at 2022-06-23 20:28:45.365462
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    usa.personality(category='mbti')
    assert usa is not None


# Generated at 2022-06-23 20:28:47.388829
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for class USASpecProvider"""
    usa_provider = USASpecProvider()
    assert usa_provider is not None


# Generated at 2022-06-23 20:28:51.123723
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_provider_instance = USASpecProvider(seed=0)
    tracking_number_result = us_provider_instance.tracking_number(service='usps')
    assert tracking_number_result == '7053 8884 6142 7037 5934'
    assert isinstance(tracking_number_result, str)


# Generated at 2022-06-23 20:28:59.084308
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='rheti') in range(1,11)

# Generated at 2022-06-23 20:29:03.738863
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    personality = usa_spec_provider.personality()
    assert personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP',
                           'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ') or isinstance(personality, int)

# Generated at 2022-06-23 20:29:07.966961
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert (ssn == '000-00-0000' or ssn == '665-00-0000')
    assert (len(ssn) == 11)


# Generated at 2022-06-23 20:29:11.971480
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality('rheti') in range(1, 11)
    assert provider.personality('mbti') in {'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                            'ISTP', 'ISFP', 'INFP', 'INTP',
                                            'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'}

# Generated at 2022-06-23 20:29:22.344606
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    random_ssn = usa.ssn()
    area_field = random_ssn[:3]
    group_field = random_ssn[4:6]
    serial_field = random_ssn[7:]

    area_field_int = int(area_field)
    assert (area_field_int) >= 1 and area_field_int <= 899 and area_field_int != 666

    group_field_int = int(group_field)
    assert group_field_int >= 1 and group_field_int <= 99

    serial_field_int = int(serial_field)
    assert serial_field_int >= 1 and serial_field_int <= 9999

# Generated at 2022-06-23 20:29:24.323289
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa._locale == 'en'

# Generated at 2022-06-23 20:29:27.268478
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
	provider = USASpecProvider()
	assert hasattr(provider, 'random')
	assert hasattr(provider, 'datetime')
	assert hasattr(provider, '__version__')
	assert hasattr(provider, 'seed')


# Generated at 2022-06-23 20:29:29.628519
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)
    assert hasattr(usa, 'locale')
    assert hasattr(usa, 'seed')


# Generated at 2022-06-23 20:29:32.786705
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    assert usa.ssn() == '569-66-5801'


# Generated at 2022-06-23 20:29:42.087964
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    expected_mbti = {'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                     'ISTP', 'ISFP', 'INFP', 'INTP',
                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'}
    expected_rheti = set(range(1,11))
    result_mbti = set()
    result_rheti = set()
    for i in range(500):
        result_mbti.add(provider.personality())
        result_rheti.add(provider.personality(category='rheti'))
    assert result_mbti == expected_mbti
    assert result_rheti == expected_rheti

# Generated at 2022-06-23 20:29:43.292655
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    obj = USASpecProvider()
    assert obj



# Generated at 2022-06-23 20:29:45.835414
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    a = USASpecProvider()
    print(a.personality())
    print(a.tracking_number())
    return a
    

# Generated at 2022-06-23 20:29:48.409173
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    spec = USASpecProvider()
    expected = "123-45-6789"
    assert spec.ssn() == expected



# Generated at 2022-06-23 20:29:49.787340
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() == '498-51-7368'

# Generated at 2022-06-23 20:29:55.415802
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us_spec = USASpecProvider()

    assert us_spec.personality('mbti') in (
        'ISFJ',
        'ISTJ',
        'INFJ',
        'INTJ',
        'ISTP',
        'ISFP',
        'INFP',
        'INTP',
        'ESTP',
        'ESFP',
        'ENFP',
        'ENTP',
        'ESTJ',
        'ESFJ',
        'ENFJ',
        'ENTJ')


# Generated at 2022-06-23 20:30:02.920950
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit testing for method tracking_number of class USASpecProvider."""
    u = USASpecProvider()
    assert len(u.tracking_number()) >= 8 and len(u.tracking_number()) <= 20
    assert len(u.tracking_number('usps')) >= 20
    assert len(u.tracking_number('fedex')) >= 12 and len(u.tracking_number('fedex')) <= 15
    assert len(u.tracking_number('ups')) == 18
    assert len(u.tracking_number('dhl')) == 10


# Generated at 2022-06-23 20:30:07.041916
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    result = usa_provider.ssn()
    assert isinstance(result, str)
    assert len(result) == 11
    assert str.isdigit(result[0:9])
    assert '-' in result


# Generated at 2022-06-23 20:30:09.446986
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """ Unit test for method ssn of class USASpecProvider"""
    usaspecprovider = USASpecProvider()
    print(usaspecprovider.ssn())

# Generated at 2022-06-23 20:30:11.836196
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():

    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('en')
    for item in range(0, 10):
        ssn = person.ssn()
        assert ssn is not None


# Generated at 2022-06-23 20:30:14.817017
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
        u = USASpecProvider()
        assert u.ssn() == '659-82-2535'


# Generated at 2022-06-23 20:30:22.915673
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():

    # Arrange
    from mimesis.enums import PostService
    import random
    import string

    random.seed(0)

    # Act
    tracking_usps = USASpecProvider().tracking_number(PostService.USPS)
    tracking_fedex = USASpecProvider().tracking_number(PostService.FEDEX)
    tracking_ups = USASpecProvider().tracking_number(PostService.UPS)

    # Assert
    assert isinstance(tracking_usps, str)
    assert isinstance(tracking_fedex, str)
    assert isinstance(tracking_ups, str)

    assert all(c in string.digits for c in tracking_usps)

    assert tracking_fedex.startswith('7')
    assert tracking_ups.startswith('1Z')


# Generated at 2022-06-23 20:30:28.102215
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    a = USASpecProvider()
    assert isinstance(a.personality(), str)
    assert isinstance(a.personality(category='rheti'), int)
    assert 0 < a.personality(category='rheti') < 11
    assert a.personality(category='invalid') is None  # error


# Generated at 2022-06-23 20:30:31.220352
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    instance = USASpecProvider()
    # mbti
    print(instance.personality())
    # rheti
    print(instance.personality(category='rheti'))

# Generated at 2022-06-23 20:30:34.409298
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert isinstance(USASpecProvider().tracking_number(), str)
    assert USASpecProvider().tracking_number() in '1234567890'


# Generated at 2022-06-23 20:30:37.203294
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider, USASpecProvider)
    assert isinstance(usa_provider._data, dict)


# Generated at 2022-06-23 20:30:41.001645
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()

    assert isinstance(provider.tracking_number(), str)
    assert isinstance(provider.ssn(), str)
    assert isinstance(provider.personality(), str)
    assert isinstance(provider.personality('rheti'), int)

# Generated at 2022-06-23 20:30:48.986360
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test USASpecProvider method tracking_number.

    Description:
        Test method tracking_number for different post services.

    :return: None
    """
    ups = USASpecProvider()
    usps = USASpecProvider()
    fedex = USASpecProvider()

    def test(post_service: str, function: USASpecProvider) -> str:
        """Test method tracking_number.

        :param post_service: Post service.
        :param function: USASpecProvider object.
        :return: Tracking number.
        """
        number = function.tracking_number(service=post_service)
        print(number)
        return number

    ups_number = test('UPS', ups)
    usps_number = test('USPS', usps)
    fedex_number = test('FedEx', fedex)

# Generated at 2022-06-23 20:30:55.605306
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tracking_number_USPS = USASpecProvider().tracking_number()
    assert len(tracking_number_USPS) == 35

    tracking_number_FedEx = USASpecProvider().tracking_number('FedEx')
    assert len(tracking_number_FedEx) in [12, 18]

    tracking_number_UPS = USASpecProvider().tracking_number('UPS')
    assert len(tracking_number_UPS) == 18


# Generated at 2022-06-23 20:31:00.169508
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.providers.person.usa import USASpecProvider
    u = USASpecProvider(seed=1234567890)
    assert u.__class__.__name__ == "USASpecProvider"
    assert u.__doc__  == "Class that provides special data for USA (en)."

# Unit tests for function tracking_number

# Generated at 2022-06-23 20:31:08.730218
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    test_object = USASpecProvider()
    assert len(test_object.tracking_number()) == 22
    assert len(test_object.tracking_number('ups')) == 18
    assert test_object.tracking_number('ups')[:2] == '1Z'
    assert len(test_object.tracking_number('fedex')) == 11
    assert len(test_object.tracking_number('usps')) == 13
    assert test_object.tracking_number('usps')[:2] == '@@'


# Generated at 2022-06-23 20:31:12.385732
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test constructor of the class USASpecProvider."""
    spec_us = USASpecProvider()
    assert spec_us.locale == 'en'


# Generated at 2022-06-23 20:31:19.491269
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()

    assert usa_provider.personality(category='MBTI') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    )

    assert usa_provider.personality(category='Rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)


# Generated at 2022-06-23 20:31:25.333611
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider(seed=42)
    assert isinstance(usa.__provider__, USASpecProvider)
    assert isinstance(usa.__data__, dict)
    assert isinstance(usa.__custom_data__, dict)
    assert isinstance(usa.__seed__, int)
    assert usa.__seed__ == 42
    assert isinstance(usa.__seed_data__, int)
    assert usa.__seed_data__ == 42


# Generated at 2022-06-23 20:31:27.531268
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.__repr__() != ''

# Generated at 2022-06-23 20:31:31.785206
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    x = USASpecProvider().ssn()
    assert len(x) == 11
    assert "-" in x
    assert x[0:3].isdigit()
    assert x[4:6].isdigit()
    assert x[7:].isdigit()

# Generated at 2022-06-23 20:31:34.123862
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    print(provider.tracking_number())


# Generated at 2022-06-23 20:31:37.537538
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test for constructor of class USASpecProvider."""
    usa = USASpecProvider()
    assert usa is not None
    assert isinstance(usa, USASpecProvider)



# Generated at 2022-06-23 20:31:39.500803
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert isinstance(usa.tracking_number(), str)


# Generated at 2022-06-23 20:31:45.139412
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()

    assert usa_spec_provider.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

    assert isinstance(usa_spec_provider.personality(category='rheti'), int)



# Generated at 2022-06-23 20:31:50.006472
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() != None
    assert USASpecProvider().tracking_number() != None
    assert USASpecProvider().tracking_number() != None
    assert USASpecProvider().tracking_number() != None
    assert USASpecProvider().tracking_number() != None


# Generated at 2022-06-23 20:31:51.720519
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert(str == type(USASpecProvider.personality(USASpecProvider)))

# Generated at 2022-06-23 20:31:54.520638
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for ssn."""
    test_object = USASpecProvider()
    assert len(test_object.ssn()) == 11


# Generated at 2022-06-23 20:31:59.402462
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    up = USASpecProvider()
    assert up.tracking_number('usps') == 'BW3J 8X5C C9BG YRTP 8R5G'
    assert up.tracking_number('fedex') == '4125 4927 5960'
    assert up.tracking_number('ups') == '1ZLE01226600896476'


# Generated at 2022-06-23 20:32:03.633459
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert str(usa_spec_provider) == 'USASpecProvider()'
    assert usa_spec_provider.__repr__() == 'USASpecProvider()'
    assert isinstance(usa_spec_provider, USASpecProvider)


# Generated at 2022-06-23 20:32:11.894670
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    tmp = USASpecProvider()
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert tmp.personality() in mbtis
    assert (tmp.personality("Rheti") >= 1 and tmp.personality("Rheti") <= 10)

# Generated at 2022-06-23 20:32:13.556661
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    temp = USASpecProvider()
    assert len(temp._data) > 5


# Generated at 2022-06-23 20:32:17.660019
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.ssn() == "818-29-7341"

# Generated at 2022-06-23 20:32:23.348001
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test the method ssn of class USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    assert isinstance(usa_spec_provider.ssn(), str)
    assert len(usa_spec_provider.ssn().split('-')) == 3
    assert not usa_spec_provider.ssn().startswith('666')


# Generated at 2022-06-23 20:32:30.405125
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_provider = USASpecProvider()
    assert us_provider._validators.tracking_number.match(
        us_provider.tracking_number(service='usps'),
    )
    assert us_provider._validators.tracking_number.match(
        us_provider.tracking_number(service='fedex'),
    )
    assert us_provider._validators.tracking_number.match(
        us_provider.tracking_number(service='ups'),
    )

    with us_provider.use_seed(seed=42):
        assert us_provider.tracking_number(service='usps') == '0543 0868 1382 1325 5170'
        assert us_provider.tracking_number(
            service='fedex') == '2582 8380'
        assert us_provider.tracking

# Generated at 2022-06-23 20:32:32.033188
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number()


# Generated at 2022-06-23 20:32:34.426045
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert (isinstance(usa_provider, USASpecProvider))
    assert (usa_provider != None)


# Generated at 2022-06-23 20:32:41.127716
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test personality method of class USASpecProvider"""
    usa_provider = USASpecProvider()
    usa_provider_personality = usa_provider.personality()
    assert isinstance(usa_provider_personality, str)

    usa_provider_rheti = usa_provider.personality('rheti')
    assert isinstance(usa_provider_rheti, int)
    assert usa_provider_rheti in range(1, 11)

# Generated at 2022-06-23 20:32:43.126713
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider(seed=1) != None

# Generated at 2022-06-23 20:32:45.598217
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    p = USASpecProvider(seed=909)
    assert p.ssn() == '692-95-1544'

# Generated at 2022-06-23 20:32:48.195560
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    seed = "123"
    usa_provider = USASpecProvider(seed)
    assert usa_provider.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:32:52.805722
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_provider = USASpecProvider()
    tracking_number = us_provider.tracking_number(service='usps')
    assert  len(tracking_number) == 22
    tracking_number = us_provider.tracking_number(service='fedex')
    assert tracking_number.startswith('2')
    tracking_number = us_provider.tracking_number(service='ups')
    assert tracking_number.startswith('1')



# Generated at 2022-06-23 20:32:56.221938
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Given When Then
    obj = USASpecProvider()
    result = obj.tracking_number()
    assert result

    result = obj.tracking_number('usps')
    assert result

    result = obj.tracking_number('fedex')
    assert result

    result = obj.tracking_number('ups')
    assert result

    try:
        obj.tracking_number('bla bla')
    except ValueError:
        pass


# Generated at 2022-06-23 20:32:58.680714
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider."""
    us_provider = USASpecProvider()
    assert us_provider != None


# Generated at 2022-06-23 20:33:04.530686
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider"""
    assert isinstance(USASpecProvider().personality('mbti'), str)
    assert USASpecProvider().personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert isinstance(USASpecProvider().personality('rheti'), int)
    assert 0 < USASpecProvider().personality('rheti') < 11

# Generated at 2022-06-23 20:33:08.235969
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider(seed=12345678)

    assert us.personality() == 'ISFJ'
    assert us.personality(category='rheti') == 7


# Generated at 2022-06-23 20:33:10.568596
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    for _ in range(10):
        assert len(USASpecProvider().ssn()) == 11


# Generated at 2022-06-23 20:33:17.007937
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Test for USPS
    assert (len(USASpecProvider().tracking_number(service='USPS')) == 22 or
            len(USASpecProvider().tracking_number(service='USPS')) == 22)
    assert len(USASpecProvider().tracking_number(service='FEDEX')) == 12 or\
           len(USASpecProvider().tracking_number(service='FEDEX')) == 15
    assert len(USASpecProvider().tracking_number(service='UPS')) == 18

# Generated at 2022-06-23 20:33:20.964464
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test USASpecProvider.tracking_number"""
    usa = USASpecProvider()
    usa.tracking_number()
    usa.tracking_number(service='ups')
    usa.tracking_number(service='fedex')
    # TODO: more test for tracking_number



# Generated at 2022-06-23 20:33:28.644812
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.provider == 'usa_provider'
    assert usa_spec_provider._seed is None
    assert usa_spec_provider.Meta.name == 'usa_spec_provider'

    seed = 'abc'
    usa_spec_provider_with_seed = USASpecProvider(seed)
    assert usa_spec_provider_with_seed._seed == 'abc'


# Generated at 2022-06-23 20:33:30.399804
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    random_ssn = USASpecProvider().ssn()
    assert len(random_ssn) == 11


# Generated at 2022-06-23 20:33:32.612712
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    ssn = USASpecProvider().ssn()
    assert(ssn.count("-") == 2)

# Generated at 2022-06-23 20:33:37.683119
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """
    Unit test for method tracking_number of class USASpecProvider
    """
    provider = USASpecProvider()

    service = 'usps'
    tracking_number = provider.tracking_number(service=service)
    assert len(tracking_number) == 9
    with pytest.raises(ValueError):
        provider.tracking_number("Fedex")


# Generated at 2022-06-23 20:33:46.743549
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()

    assert usa.random.choice(('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')) in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:33:48.484325
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Tests the constructor of class USASpecProvider."""
    assert USASpecProvider() is not None


# Generated at 2022-06-23 20:33:50.425123
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider is not None
    # Test type
    assert isinstance(provider, USASpecProvider)


# Generated at 2022-06-23 20:33:54.887997
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityEnum
    from mimesis.providers.usa import USASpecProvider
    provider = USASpecProvider()
    assert provider.personality(PersonalityEnum.MBTI) in provider.personality.__annotations__['return']._field_type.__args__
    assert provider.personality(PersonalityEnum.RETI) in provider.personality.__annotations__['return']._field_type.__args__

# Generated at 2022-06-23 20:33:55.688748
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    random = USASpecProvider()
    random.ssn()

# Generated at 2022-06-23 20:33:59.547139
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:34:00.838725
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print(USASpecProvider().tracking_number('ups'))


# Generated at 2022-06-23 20:34:07.026382
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality(category='rheti') >= 1
    assert usa.personality(category='rheti') <= 10
    assert usa.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert usa.personality(category='not') == ''


# Generated at 2022-06-23 20:34:10.079582
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    x = USASpecProvider()
    assert x.tracking_number() != x.tracking_number()


# Generated at 2022-06-23 20:34:17.684596
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    
    assert 1 <= usa.personality('rheti') <= 10

# Generated at 2022-06-23 20:34:23.204478
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # тестируем генерацию ssn
    usa = USASpecProvider()
    # проверка на строковое значение
    assert type(usa.ssn()) == str


# Generated at 2022-06-23 20:34:29.024873
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    assert us.personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:34:35.186513
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # without seed
    usa_provider = USASpecProvider()
    assert usa_provider.__class__.__name__ == 'USASpecProvider'
    assert usa_provider.__doc__ == 'Class that provides special data for USA (en).'
    # with seed
    usa_provider = USASpecProvider(seed=42)
    assert usa_provider.__class__.__name__ == 'USASpecProvider'
    assert usa_provider.__doc__ == 'Class that provides special data for USA (en).'


# Generated at 2022-06-23 20:34:38.533546
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    result = provider.ssn()
    assert isinstance(result,str)


# Generated at 2022-06-23 20:34:48.157263
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # This is a unit test to check the functionality of the the method ssn()
    # of the class USASpecProvider() in the locales/en/us_spec.py file
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'
    assert ssn.count('-') == 2
    assert ssn.count('666') == 0
    area, group, serial = [int(item) for item in ssn.split('-')]
    assert 1 <= area <= 899
    assert 1 <= group <= 99
    assert 1 <= serial <= 9999
    assert ssn.isdigit() == False


# Generated at 2022-06-23 20:34:50.427032
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usaObj = USASpecProvider()
    assert isinstance(usaObj, USASpecProvider)


# Generated at 2022-06-23 20:34:54.760006
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in [ 'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                           'ISTP', 'ISFP', 'INFP', 'INTP',
                                           'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:34:57.462532
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
	us = USASpecProvider()
	assert us.tracking_number() != None
	assert us.ssn() != None
	assert us.personality() != None