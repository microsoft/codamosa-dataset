

# Generated at 2022-06-23 20:24:59.276807
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for provider method tracking_number."""
    from mimesis.enums import TrackService
    p = USASpecProvider()
    assert len(p.tracking_number()) == 34
    assert len(p.tracking_number(service=TrackService.USPS)) == 34
    assert len(p.tracking_number(service=TrackService.FedEx)) == 22
    assert len(p.tracking_number(service=TrackService.UPS)) == 16


# Generated at 2022-06-23 20:25:04.761762
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    result = provider.ssn()
    assert len(result) == 11
    assert result[3] == "-" and result[6] == "-"
    assert result.isdigit() == False
    assert result[0:3].isdigit() == True
    assert result[4:6].isdigit() == True
    assert result[7:11].isdigit() == True


# Generated at 2022-06-23 20:25:06.833643
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    u = USASpecProvider()
    service = "usps"
    tracking_number = u.tracking_number(service)
    assert tracking_number != None


# Generated at 2022-06-23 20:25:14.281437
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality('mbti') is not None
    assert USASpecProvider().personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                     'ISTP', 'ISFP', 'INFP', 'INTP',
                                                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert USASpecProvider().personality('rheti') is not None
    assert USASpecProvider().personality('rheti') in range(1, 10)

# Generated at 2022-06-23 20:25:19.798841
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    # unit test for method personality of class USASpecProvider
    assert usa_provider.personality() in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:25:21.886753
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # test example
    # ISFJ
    assert USASpecProvider().personality() == 'ISFJ'
    assert USASpecProvider().personality(category='rheti') == 7

# Generated at 2022-06-23 20:25:27.387442
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number(service='USPS') != None
    assert usa.tracking_number(service='FedEx') != None
    assert usa.tracking_number(service='UPS') != None


# Generated at 2022-06-23 20:25:36.909670
# Unit test for method personality of class USASpecProvider

# Generated at 2022-06-23 20:25:40.142864
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    usa_tracking_number = usa.tracking_number(service='ups')
    print('tracking_number : ', usa_tracking_number)
    assert usa_tracking_number != None and len(usa_tracking_number) == 18


# Generated at 2022-06-23 20:25:50.602243
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tracking_number_criteria_list = [
        {'input': {'service': 'usps'}, 'output': ['#### #### #### #### ####']},
        {'input': {'service': 'usps'}, 'output': ['@@ ### ### ### US']},
        {'input': {'service': 'fedex'}, 'output': ['#### #### ####']},
        {'input': {'service': 'fedex'}, 'output': ['#### #### #### ###']},
        {'input': {'service': 'ups'}, 'output': ['1Z@####@##########']},
    ]
    usa_spec_provider = USASpecProvider()

# Generated at 2022-06-23 20:25:52.442984
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()

    assert provider.locale == 'en'
    assert provider.seed is None


# Generated at 2022-06-23 20:25:56.022843
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of the class USASpecProvider."""
    spec = USASpecProvider()
    match = r'\d{3}-\d{2}-\d{4}'

    for x in range(100):
        assert spec.ssn()
        assert spec.regex.match(match, spec.ssn())

# Generated at 2022-06-23 20:25:59.525059
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    spec = USASpecProvider()
    assert isinstance(spec.personality(), str)
    assert isinstance(spec.personality(category='rheti'), int)
    assert len(spec.personality()) == 4


# Generated at 2022-06-23 20:26:01.355793
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    usps = usa.tracking_number()
    print(usps)


# Generated at 2022-06-23 20:26:04.116552
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    usa_provider = USASpecProvider(seed=123)
    ssn = usa_provider.ssn()
    assert ssn == "007-04-2518"

# Generated at 2022-06-23 20:26:05.713719
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    t = USASpecProvider().tracking_number()
    assert len(t.split(" ")) > 0


# Generated at 2022-06-23 20:26:07.065486
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    USASpecProvider().ssn() == '569-66-5801'

# Generated at 2022-06-23 20:26:09.838915
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider."""
    obj = USASpecProvider()
    assert obj._locale == 'en'
    assert obj._seed is None


# Generated at 2022-06-23 20:26:10.885468
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test constructor of class USASpecProvider"""
    USASpecProvider()

# Generated at 2022-06-23 20:26:21.603381
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number()
    assert usa_provider.tracking_number('UPS')
    assert usa_provider.tracking_number('USPS')
    assert usa_provider.tracking_number('Fedex')
    assert usa_provider.tracking_number('Fedex')
    assert usa_provider.tracking_number('Fedex')
    assert usa_provider.tracking_number('Fedex')
    assert usa_provider.tracking_number('Fedex')
    assert usa_provider.tracking_number('Fedex')
    assert usa_provider.tracking_number('Fedex')
    assert usa_provider.tracking_number('Fedex')

# Generated at 2022-06-23 20:26:22.428971
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usp = USASpecProvider()


# Generated at 2022-06-23 20:26:24.383850
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider(seed=100)
    person = provider.personality(category="mbti")
    assert person == "INFJ"

# Generated at 2022-06-23 20:26:32.320867
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider"""
    from mimesis.providers.usa import USASpecProvider
    usaProvider = USASpecProvider()
    personality = usaProvider.personality()
    assert personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                           'ISTP', 'ISFP', 'INFP', 'INTP',
                           'ESTP', 'ESFP', 'ENFP', 'ENTP',
                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    

# Generated at 2022-06-23 20:26:33.848712
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() == '1Z6N0A639314793636'

# Generated at 2022-06-23 20:26:42.795931
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa = USASpecProvider()
    random_personality = usa.personality()
    if random_personality in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                              'ISTP', 'ISFP', 'INFP', 'INTP',
                              'ESTP', 'ESFP', 'ENFP', 'ENTP',
                              'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']:
        return True
    else:
        return False

# Generated at 2022-06-23 20:26:46.855776
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    p = USASpecProvider()
    assert len(p.tracking_number()) == 22
    assert len(p.tracking_number('fedex')) in (12, 15)
    assert len(p.tracking_number('ups')) == 18


# Generated at 2022-06-23 20:26:52.990036
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider.personality() in ("ISFJ", "ISTJ", "INFJ", "INTJ", "ISTP", "ISFP", "INFP", "INTP", "ESTP", "ESFP", "ENFP", "ENTP", "ESTJ", "ESFJ", "ENFJ", "ENTJ")
    assert USASpecProvider.personality(category = "rheti") in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-23 20:26:54.133192
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn()


# Generated at 2022-06-23 20:26:57.334962
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert len(usa.tracking_number()) == 22
    assert usa.ssn() != usa.ssn()
    assert usa.personality() != usa.personality()
    assert len(usa.tracking_number()) == 22
    print("You successfully tested the USASpecProvider class")

# Generated at 2022-06-23 20:26:59.413622
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert type(usa.tracking_number()) == str


# Generated at 2022-06-23 20:27:05.434361
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality('mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:27:09.544891
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    s = provider.personality()
    assert isinstance(s, str)
    assert s in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    s = provider.personality('rheti')
    assert isinstance(s, int)
    assert s in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)



# Generated at 2022-06-23 20:27:13.250547
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider, USASpecProvider)
    assert hasattr(usa_provider, "personalit")
    assert hasattr(usa_provider, "ssn")


# Generated at 2022-06-23 20:27:21.194724
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method USASpecProvider.personality"""
    seed = "random_tests.USASpecProvider_test_personality"
    # MBTI types
    MBTI = ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    r = USASpecProvider(seed=seed).personality()
    assert any(r == e for e in MBTI)
    assert r != 'rh'

    # Rheti types
    r = USASpecProvider(seed=seed).personality(category='rheti')
    assert r < 10
    assert r > 0
    assert r != 'mb'

# Generated at 2022-06-23 20:27:28.151634
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                            'ISTP', 'ISFP', 'INFP', 'INTP',
                            'ESTP', 'ESFP', 'ENFP', 'ENTP',
                            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']



# Generated at 2022-06-23 20:27:30.523797
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usp = USASpecProvider()
    value = usp.tracking_number('usps')
    assert value is not None


# Generated at 2022-06-23 20:27:34.762777
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    actual = USASpecProvider().personality()
    assert actual in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                      'ISTP', 'ISFP', 'INFP', 'INTP',
                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']


# Generated at 2022-06-23 20:27:36.910340
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider."""
    provider = USASpecProvider()
    assert provider.locale == 'en'
    assert provider.seed is not None

# Generated at 2022-06-23 20:27:45.098770
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
  usa_provider = USASpecProvider()
  print(usa_provider.tracking_number())
  print(usa_provider.tracking_number())
  print(usa_provider.tracking_number())
  print(usa_provider.tracking_number())
  print(usa_provider.tracking_number())
  print(usa_provider.tracking_number())
  print(usa_provider.tracking_number())
  print(usa_provider.tracking_number())
  print(usa_provider.tracking_number())
  print(usa_provider.tracking_number())


# Generated at 2022-06-23 20:27:53.907213
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit tests for method personality of class USASpecProvider."""
    # Test for MBTI category
    for i in range(10):
        assert USASpecProvider().personality() in [
            'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
            'ISTP', 'ISFP', 'INFP', 'INTP',
            'ESTP', 'ESFP', 'ENFP', 'ENTP',
            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ',
        ]

    # Test for RHETI category
    for i in range(10):
        assert 1 <= USASpecProvider().personality('rheti') <= 10



# Generated at 2022-06-23 20:27:56.294524
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a = USASpecProvider()
    b = a.tracking_number(service="usps")
    assert b
    assert isinstance(b, str)


# Generated at 2022-06-23 20:27:59.750668
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider_obj = USASpecProvider()
    tracking_number = usa_provider_obj.tracking_number()
    assert tracking_number
    assert len(tracking_number) >= 16 and len(tracking_number) <= 19


# Generated at 2022-06-23 20:28:09.654931
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    for _ in range(100):
        assert usa_spec_provider.personality() in \
               ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                'ISTP', 'ISFP', 'INFP', 'INTP',
                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
        assert isinstance(usa_spec_provider.personality(category='rheti'), int)
        assert 1 <= usa_spec_provider.personality(category='rheti') <= 10

# Generated at 2022-06-23 20:28:17.011223
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert type(provider.personality(category = 'rheti')) is int


# Generated at 2022-06-23 20:28:18.672705
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    assert bool(us.tracking_number()) == True


# Generated at 2022-06-23 20:28:20.099056
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    print("USA:", usa.ssn())

# Generated at 2022-06-23 20:28:27.665232
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender
    from mimesis.builtins import USASpecProvider

    usa_state = USASpecProvider()
    assert usa_state.full_name(gender=Gender.MALE) == 'Ernesto Russo'
    assert usa_state.address() == '66083 Kelly Stream'
    assert usa_state.postal_code() == '95526'
    assert usa_state.street_name() == 'Lake Delaney'
    assert usa_state.us_state() == 'Pennsylvania'

# Generated at 2022-06-23 20:28:35.268388
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    assert us.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(us.personality(category='rheti'), int)
    assert us.personality(category='rheti') in range(1, 11)



# Generated at 2022-06-23 20:28:36.606700
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider()


# Generated at 2022-06-23 20:28:40.406277
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
	usp = USASpecProvider()
	val = usp.personality()
	assert val != None
	val2 = usp.tracking_number()
	assert val2 != None
	val3 = usp.ssn()
	assert val3 != None

# Generated at 2022-06-23 20:28:44.113217
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:28:46.758562
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    ssn = USASpecProvider().ssn()
    assert isinstance(ssn, str)
    assert len(ssn) == 11
    assert ssn.count('-') == 2


# Generated at 2022-06-23 20:28:48.023145
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() != None

# Generated at 2022-06-23 20:28:49.865550
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number(service='ups') == '1ZR1 087 24 0198 513'



# Generated at 2022-06-23 20:28:52.965812
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """
    Test method USASpecProvider.ssn

    Expected output:
        569-66-5801
    """

    tmp_test = USASpecProvider(seed=1).ssn()
    print (f"tmp_test: {tmp_test}")


test_USASpecProvider_ssn()

# Generated at 2022-06-23 20:29:02.220871
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # the method returns mbtis
    for _ in range(0, 100):
        assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    # the method returns random int in range [1, 10] when category to be 'rheti'
    for _ in range(0, 100):
        assert 1 <= USASpecProvider().personality(category='rheti') <= 10
    # the method does not return mbtis when category to be 'rheti'

# Generated at 2022-06-23 20:29:12.384578
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    obj = USASpecProvider()
    assert obj.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

    assert isinstance(obj.personality('RHEti'), int)
    assert obj.personality('RHEtI') <= 10 and obj.personality('RHEtI') >= 1
    assert isinstance(obj.personality('rheti'), int)
    assert obj.personality('rheti') <= 10 and obj.personality('rheti') >= 1
    assert isinstance(obj.personality('Rhemi'), int)

# Generated at 2022-06-23 20:29:23.619485
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.builtins import USASpecProvider
    a = USASpecProvider(seed=4)

    assert a.tracking_number('usps') == '5443 0127 2401 9085 6058'
    assert a.tracking_number('usps') == '9J6 967 538 US'
    assert a.tracking_number('fedex') == '1410 0537 092'
    assert a.tracking_number('fedex') == '5042 1864 785'
    assert a.tracking_number('ups') == '1ZCK351Y9118584940'
    assert a.tracking_number('ups') == '1ZCK351Y9118584940'
    assert a.tracking_number('unknown') == '1C8H366K7XXT6T0P'

# Unit

# Generated at 2022-06-23 20:29:24.779891
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usaspecprovider = USASpecProvider()
    assert usaspecprovider != None

# Generated at 2022-06-23 20:29:25.587378
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    print(USASpecProvider().ssn())

# Generated at 2022-06-23 20:29:26.587462
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    print(usa.ssn())

# Generated at 2022-06-23 20:29:29.051493
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""

    assert USASpecProvider().tracking_number('usps')
    assert USASpecProvider().tracking_number('fedex')
    assert USASpecProvider().tracking_number('ups')


# Generated at 2022-06-23 20:29:33.093672
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number(service="usps")
    assert usa.tracking_number(service="fedex")
    assert usa.tracking_number(service="ups")


# Generated at 2022-06-23 20:29:42.310119
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.providers.generic import Generic
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.useragent import UserAgent
    from mimesis.providers.system import System
    from mimesis.providers.business import Business
    from mimesis.providers.web import Web

    spec = USASpecProvider()

    gen = Generic(seed=42)
    add = Address(seed=42)
    dat = Datetime(seed=42)
    per = Person(seed=42)
    pay

# Generated at 2022-06-23 20:29:48.157312
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print("Test: test_USASpecProvider")

    my_usa_provider = USASpecProvider()

    print("my_usa_provider = USASpecProvider()")

    assert my_usa_provider.__class__.__name__ == "USASpecProvider"
    assert my_usa_provider.locale == "en"
    assert my_usa_provider.seed is None


# Generated at 2022-06-23 20:29:49.570672
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11


# Generated at 2022-06-23 20:29:52.546196
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    test_USASpecProvider = USASpecProvider()
    assert ('3211 2113 3240 2133 3433' or '00 222 333 333 US') == test_USASpecProvider.tracking_number()


# Generated at 2022-06-23 20:29:57.775780
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert usa_provider.seed == usa_provider.random.seed
    assert usa_provider.locale == 'en'
    assert isinstance(usa_provider, BaseSpecProvider)


# Generated at 2022-06-23 20:30:02.814311
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Test that method personality returns a random type of personality
    usa_provider = USASpecProvider(seed=42)
    assert usa_provider.personality() == "INFP"
    assert usa_provider.personality(category='mbti') == "INFP"
    assert usa_provider.personality(category='rheti') == 7


# Generated at 2022-06-23 20:30:05.733960
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us_data = USASpecProvider()
    assert us_data.personality('mbti') in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP',
        'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert us_data.personality('rheti') in range(1, 10)

# Generated at 2022-06-23 20:30:16.405877
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    from mimesis.enums import Gender
    from mimesis.specs import USASpecProvider
    t = USASpecProvider()
    print(t.person())
    print(t.ascii_email())
    print(t.ascii_email('test.py'))
    print(t.ascii_free_email())
    print(t.ascii_company_email())
    print(t.ascii_safe_email())
    print(t.company_email())
    print(t.free_email())
    print(t.safe_email())
    print(t.username())
    print(t.domain_name())
    print(t.domain_word())
    print(t.tld())
    print(t.domain_zone())
    print(t.ipv4())

# Generated at 2022-06-23 20:30:28.058508
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from pprint import pprint
    from mimesis.enums import Gender
    from mimesis.providers.person.en import EnglishPerson

    from mimesis.builtins.usa import USASpecProvider
    # Create an instance of the EnglishPerson class
    ep = EnglishPerson('en')
    # Create an instance of the USASpecProvider class
    usa = USASpecProvider('en')
    # Prints the result
    print('The gender is:',  ep.gender(gender=Gender.MALE))
    print('The SSN is :',     usa.ssn())
    print('The SSN is :',     usa.ssn())
    print('The SSN is :',     usa.ssn())
    print('The SSN is :',     usa.ssn())

# Generated at 2022-06-23 20:30:31.543925
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    mprovider = USASpecProvider()
    assert len(mprovider.personality()) == 4
    assert len(mprovider.personality(category='rheti')) == 1


# Generated at 2022-06-23 20:30:36.653107
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'], 'test_USASpecProvider_personality failed'

# Generated at 2022-06-23 20:30:39.637051
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider(seed=321).personality('mbti') == 'ESTP'
    assert USASpecProvider(seed=321).personality('rheti') == 2


# Generated at 2022-06-23 20:30:45.377785
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    us_gen = USASpecProvider()
    assert us_gen.ssn() != None
    assert us_gen.ssn() != us_gen.ssn()
    us_gen = USASpecProvider()
    assert us_gen.ssn(gender=Gender.FEMALE) != None
    assert us_gen.ssn(gender=Gender.FEMALE) != us_gen.ssn()


# Generated at 2022-06-23 20:30:50.438972
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test USASpecProvider"""
    usa = USASpecProvider()
    print(usa.tracking_number("usps"))
    print(usa.ssn())
    print(usa.personality("mbti"))
    print(usa.personality("rheti"))



# Generated at 2022-06-23 20:30:58.097187
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    usps = usa_provider.tracking_number()
    fedex = usa_provider.tracking_number(service='FedEx')
    ups = usa_provider.tracking_number(service='UPS')
    assert isinstance(usps, str)
    assert isinstance(fedex, str)
    assert isinstance(ups, str)
    assert len(usps) == 22
    assert len(fedex) in (12, 15)
    assert len(ups) == 18
    return True


# Generated at 2022-06-23 20:31:02.835408
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    s = USASpecProvider().personality()
    assert s in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:31:05.924800
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number('usps') == '9293 6529 3635 6448 7358'
    assert provider.tracking_number('fedex') == '7198 6253 5232'
    assert provider.tracking_number('ups') == '1Z015A990122174598'


# Generated at 2022-06-23 20:31:11.411238
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # USASpecProvider(seed=None)
    p1 = USASpecProvider(seed=None)
    # USASpecProvider(seed=None)
    p2 = USASpecProvider(seed=None)
    # USASpecProvider(seed=10)
    p3 = USASpecProvider(seed=10)
    # USASpecProvider(seed=10)
    p4 = USASpecProvider(seed=10)

    for i in range(0, 10):
        assert p1.personality() == p2.personality()
        assert p3.personality() == p4.personality()



# Generated at 2022-06-23 20:31:12.695789
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    assert us.provider == 'usa_provider'

# Generated at 2022-06-23 20:31:14.891531
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider(seed=2384738)
    assert provider.ssn() == '975-37-1887'


# Generated at 2022-06-23 20:31:17.248226
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    c = USASpecProvider()
    assert c.ssn() in ('681-53-3060', '288-13-5387', '903-34-4529')


# Generated at 2022-06-23 20:31:23.173161
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider"""
    usp = USASpecProvider()
    print(usp.tracking_number())
    print(usp.tracking_number())
    print(usp.tracking_number())
    print(usp.tracking_number())
    print(usp.tracking_number())
    print(usp.tracking_number())


# Generated at 2022-06-23 20:31:26.464962
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.builtins import USASpecProvider

    us_provider = USASpecProvider()

    assert us_provider.ssn() == '540-66-5801'
    assert isinstance(us_provider.ssn(), str)


# Generated at 2022-06-23 20:31:29.933120
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality(category='test') in usa.__class__.Meta.personality
    

# Generated at 2022-06-23 20:31:40.905420
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender
    from mimesis.typing import DatetimeData
    from datetime import datetime
    
    us_provider = USASpecProvider()
    us_provider.seed(123456789)
    assert us_provider.__doc__ == """Class that provides special data for USA (en)."""
    assert us_provider.Meta.name == 'usa_provider'
    assert us_provider.random.reseed(123456789) == (
        '673780821929303907',
        '1132502282163334875',
    )
    assert us_provider.gender() == Gender.MALE
    assert us_provider.full_name(gender=Gender.MALE) == 'John K. Macleod'
    assert us_prov

# Generated at 2022-06-23 20:31:42.882322
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    usa_spec_provider = USASpecProvider(seed=123456789)
    assert usa_spec_provider.tracking_number() == '1Z0224322664750163'


# Generated at 2022-06-23 20:31:46.548292
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number."""

    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.tracking_number(), str)
    assert len(usa_provider.tracking_number()) == 25
    assert isinstance(usa_provider.tracking_number('ups'), str)
    assert len(usa_provider.tracking_number('ups')) == 18
    assert isinstance(usa_provider.tracking_number('fedex'), str)
    assert len(usa_provider.tracking_number('fedex')) in (12, 18)



# Generated at 2022-06-23 20:31:48.329150
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    a = USASpecProvider()
    assert a is not None


# Generated at 2022-06-23 20:31:59.120891
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider"""
    import random
    import unittest
    from mimesis.enums import PersonalityCategory, RhetiCategory
    from mimesis.providers.usa_provider import USASpecProvider
    from mimesis.providers.base import BaseProvider

    class TestUSASpecProvider(unittest.TestCase):
        """Test cases for class USASpecProvider."""

        def setUp(self):
            """Set the seed."""
            seed = 'test_usa_provider_personality'
            random.seed(seed)

            self.usa = USASpecProvider(seed)

        def test_personality(self):
            """Test for method personality of class USASpecProvider."""
            self.assertIsInstance(self.usa, BaseProvider)


# Generated at 2022-06-23 20:32:03.275717
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityType
    from mimesis.enums import RhETICategory

    t = USASpecProvider()
    assert t.personality(category="mbti") in \
        [p.value for p in PersonalityType]
    assert t.personality(category="rheti") in \
        [r.value for r in RhETICategory]

# Generated at 2022-06-23 20:32:10.070669
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usp = USASpecProvider()
    assert usp.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:32:17.337906
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() != USASpecProvider().tracking_number()
    assert USASpecProvider().tracking_number('usps') != USASpecProvider().tracking_number('usps')
    assert USASpecProvider().tracking_number('fedex') != USASpecProvider().tracking_number('fedex')
    assert USASpecProvider().tracking_number('ups') != USASpecProvider().tracking_number('ups')
    assert USASpecProvider().tracking_number() != USASpecProvider().tracking_number('usps')
    assert USASpecProvider().tracking_number() != USASpecProvider().tracking_number('fedex')
    assert USASpecProvider().tracking_number() != USASpecProvider().tracking_number('ups')
    assert USASpecProvider().tracking_number('usps') != USASpecProvider().tracking

# Generated at 2022-06-23 20:32:22.858694
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test tracking_number method in class USASpecProvider"""
    usa = USASpecProvider()
    assert usa.tracking_number() == usa.tracking_number(service='usps')
    assert usa.tracking_number() == usa.tracking_number(service='fedex')
    assert usa.tracking_number() == usa.tracking_number(service='ups')

# Generated at 2022-06-23 20:32:29.273123
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider
    tracking_numbers = set([])
    for i in range(1000):
        tracking_numbers.add(usa_spec_provider.tracking_number("UPS"))
    for i in range(1000):
        tracking_numbers.add(usa_spec_provider.tracking_number("USPS"))
    for i in range(1000):
        tracking_numbers.add(usa_spec_provider.tracking_number("FEDEX"))
    print(tracking_numbers)
    assert len(tracking_numbers) == 3000
    assert len(tracking_numbers) > 0

# Generated at 2022-06-23 20:32:30.177581
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider() is not None

# Generated at 2022-06-23 20:32:40.615802
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    usaspp = USASpecProvider()
    assert usaspp.personality(category='rheti') in range(1, 11)
    assert usaspp.personality() in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP',
        'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ',
    ]

# Generated at 2022-06-23 20:32:45.237987
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()

    n = 8

    for i in range(n):
        assert len(str(provider.personality('rheti'))) == 1
        assert len(str(provider.personality('MBTI'))) == 4


# Generated at 2022-06-23 20:32:48.377480
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test tracking_number method."""
    usa = USASpecProvider()
    # this should be lowered to 'usps|fedex|ups'
    assert usa.tracking_number(service='USPS') != ...



# Generated at 2022-06-23 20:32:51.890809
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality of class USASpecProvider."""
    provider = USASpecProvider()
    provider.personality('mbti')
    provider.personality('Rheti')
    provider.personality('Rheti')
    provider.personality('Rheti')
    provider.personality('Rheti')



# Generated at 2022-06-23 20:32:54.107245
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider(seed=12345)
    assert provider.random.seed == 12345
    assert provider.locale == 'en'
    assert provider.Meta.name == 'usa_provider'


# Generated at 2022-06-23 20:33:04.313202
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    expected_values = {
        'ISFJ': 1,
        'ISTJ': 1,
        'INFJ': 1,
        'INTJ': 1,
        'ISTP': 1,
        'ISFP': 1,
        'INFP': 1,
        'INTP': 1,
        'ESTP': 1,
        'ESFP': 1,
        'ENFP': 1,
        'ENTP': 1,
        'ESTJ': 1,
        'ESFJ': 1,
        'ENFJ': 1,
        'ENTJ': 1
    }
    esp = USASpecProvider()
    for i in range(0, 5000):
        s = esp.personality()
        if s in expected_values.keys():
            expected_values[s] += 1

# Generated at 2022-06-23 20:33:15.555963
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for method tracking_number of class USASpecProvider."""
    from mimesis.enums import PostService, PostServiceLabels
    from mimesis.providers.usa_spec import USASpecProvider
    from mimesis.typing import Enum

    class _PostService(Enum):
        """Enum for post services."""

        @classmethod
        def choices(cls) -> Enum:
            """Return list with enum instances."""
            return [
                PostService.USPS,
                PostService.FEDEX,
                PostService.UPS,
            ]

    class _PostServiceLabels(Enum):
        """Enum for post service labels."""

        @classmethod
        def choices(cls) -> Enum:
            """Return list with enum instances."""

# Generated at 2022-06-23 20:33:16.583835
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11

# Generated at 2022-06-23 20:33:18.184637
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    ssn = usa.ssn()
    assert ssn.isnumeric()
    assert len(ssn) == 11

# Generated at 2022-06-23 20:33:24.030162
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number(service='usps') == '2738 2803 9154 1468 5672'
    assert USASpecProvider().tracking_number(service='fedex') == '7612 3286 08'
    assert USASpecProvider().tracking_number(service='ups') == '1Z95A7A66010639297'


# Generated at 2022-06-23 20:33:25.681962
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    a = USASpecProvider()
    assert a is not None


# Generated at 2022-06-23 20:33:28.273024
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    prov = USASpecProvider()
    ssn = prov.ssn()
    assert ssn != prov.ssn()


# Generated at 2022-06-23 20:33:35.563907
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for personality().
    """
    usa_spec_provider = USASpecProvider()
    usa_spec_provider_result = usa_spec_provider.personality('rheti')
    assert isinstance(usa_spec_provider_result, int)
    assert 0 < usa_spec_provider_result <= 10
    usa_spec_provider_result = usa_spec_provider.personality('mbti')
    assert isinstance(usa_spec_provider_result, str)
    assert len(usa_spec_provider_result) == 4



# Generated at 2022-06-23 20:33:41.316609
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Initialize the object
    usa_provider = USASpecProvider()

    # Check if the output is str
    assert isinstance(usa_provider.personality(), str)

    # Check the answer
    assert usa_provider.personality().upper() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                   'ISTP', 'ISFP', 'INFP', 'INTP',
                                   'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                   'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:33:42.522353
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality()



# Generated at 2022-06-23 20:33:45.599390
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_spec_provider = USASpecProvider(seed=12345)
    assert usa_spec_provider.ssn() == "664-89-9451"

# Generated at 2022-06-23 20:33:51.507899
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    for i in range(10):
        personality = usa_provider.personality(category='rheti')
        assert type(personality) == int, 'USASpecProvider.personality is not a int'
    for i in range(10):
        personality = usa_provider.personality()
        assert type(personality) == str, 'USASpecProvider.personality is not a str'


# Generated at 2022-06-23 20:33:55.543067
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    ssn = usa_provider.ssn()
    assert re.search(r'^\d{3}-\d{2}-\d{4}$', ssn)


# Generated at 2022-06-23 20:33:57.858875
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.__class__.__name__ is "USASpecProvider"


# Generated at 2022-06-23 20:33:59.281002
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    a = USASpecProvider()
    assert a


# Generated at 2022-06-23 20:34:01.381329
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider(seed=22)
    assert usa.ssn() == '721-54-2341'

# Generated at 2022-06-23 20:34:07.152082
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import Personality
    usa = USASpecProvider()
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert usa.personality(Personality.MBTI) in mbtis
    assert usa.personality(Personality.RHETI) in range(1, 11)

# Generated at 2022-06-23 20:34:10.663299
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert 'ISFJ' == USASpecProvider().personality()
    assert 'ESTJ' == USASpecProvider().personality()


# Generated at 2022-06-23 20:34:13.940787
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    us = USASpecProvider()
    assert len(us.ssn()) == 11


# Generated at 2022-06-23 20:34:16.010336
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider(seed=123456).ssn() == "868-39-0723"

# Generated at 2022-06-23 20:34:17.778609
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider().ssn()
    assert USASpecProvider().personality()

# Generated at 2022-06-23 20:34:23.957006
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert (provider.random.choice([provider.random.choice([1, 2, 3]), 4])) == 1
    assert (provider.random.choice([provider.random.choice([1, 2, 3]), 4])) == 2
    assert (provider.random.choice([provider.random.choice([1, 2, 3]), 4])) == 3
    assert (provider.random.choice([provider.random.choice([1, 2, 3]), 4])) == 4
    assert (provider.random.choice([provider.random.choice([1, 2, 3]), 4])) == 1


# Generated at 2022-06-23 20:34:27.735790
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:34:37.744036
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    # test USPS tracking number
    usps_tracking_number = usa_spec_provider.tracking_number("usps")
    assert len(usps_tracking_number) == 32
    # test FedEx tracking number
    fedex_tracking_number = usa_spec_provider.tracking_number("fedex")
    assert len(fedex_tracking_number) in [12, 17]
    # test UPS tracking number
    ups_tracking_number = usa_spec_provider.tracking_number("ups")
    assert len(ups_tracking_number) == 18
    # test unsupported service
    try:
        usa_spec_provider.tracking_number("usps")
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-23 20:34:40.131210
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    tracking_number = usa_spec_provider.tracking_number()
    assert tracking_number is not None



# Generated at 2022-06-23 20:34:42.950855
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider().tracking_number('usps')
    assert USASpecProvider().ssn()
    assert USASpecProvider().personality('mbti')
    assert USASpecProvider().personality('rheti')

# Generated at 2022-06-23 20:34:47.491274
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Arrange
    provider = USASpecProvider()
    expected = 'INFP'
    expected_type = str
    
    # Act
    actual = provider.personality('mbti')

    # Assert
    assert expected == actual, "Expected: " + str(expected) + ", but actual: " + str(actual)
    assert type(actual) is expected_type, "Expected type of result: " + str(expected_type) + ", but actual: " + str(type(actual))

# Generated at 2022-06-23 20:34:51.036019
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    ssn = USASpecProvider(seed=0).ssn()
    # Check whether the result is a string data type
    assert type(ssn) == str
    # Check whether the length is 9
    assert len(ssn) == 9
    # Check whether the first number is 5
    assert ssn[0] == '5'
    # Check whether the fifth number is 6
    assert ssn[4] == '6'


# Generated at 2022-06-23 20:34:52.296045
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11

# Generated at 2022-06-23 20:35:00.547055
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider.
    
    :return:
    """
    provider = USASpecProvider()
    
    assert provider.personality(category='rheti') in [1,2,3,4,5,6,7,8,9,10]
    assert provider.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                     'ISTP', 'ISFP', 'INFP', 'INTP',
                                                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']