

# Generated at 2022-06-23 20:24:53.556858
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    print(usa.mbti())
    print(usa.tracking_number())
    print(usa.ssn())

# Generated at 2022-06-23 20:24:56.682754
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_gen = USASpecProvider()
    ssn = usa_gen.ssn()
    assert isinstance(ssn, str)
    assert len(ssn) == 11
    assert ssn[3] == '-' and ssn[6] == '-'


# Generated at 2022-06-23 20:25:01.588406
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    usa_provider.ssn()
    usa_provider.personality()
    usa_provider.tracking_number()



# Generated at 2022-06-23 20:25:03.453701
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    x = USASpecProvider()
    assert x.__class__.__name__ == "USASpecProvider"


# Generated at 2022-06-23 20:25:09.057024
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    ssn = usa.ssn()
    assert len(ssn) == 11
    assert ' ' not in ssn
    assert '-' in ssn
    assert ssn[3] == '-'
    assert ssn[6] == '-'
    area, group, serial = ssn.split('-')
    assert len(area) == 3
    assert len(group) == 2
    assert len(serial) == 4
    assert area.isdigit()
    assert group.isdigit()
    assert serial.isdigit()
    assert int(area) != 666

# Generated at 2022-06-23 20:25:14.770564
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Test USASpecProvider
    test = USASpecProvider()

    # Test string 'Unsupported post service'
    try:
        test.tracking_number(service='fake service')
    except ValueError as str:
        print(str)
    else:
        print('Tracking number: ' + test.tracking_number())

    # Test string 'SSN'
    print(test.ssn())

    # Test string 'Personality type'
    print(test.personality())


if __name__ == '__main__':
    test_USASpecProvider()

# Generated at 2022-06-23 20:25:18.431747
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.tracking_number(), str)
    assert len(usa_provider.tracking_number()) > 0



# Generated at 2022-06-23 20:25:19.339439
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()


# Generated at 2022-06-23 20:25:21.594868
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider(seed=123)
    result = provider.tracking_number()
    assert result in ['1890 9367 5343', '8E 935 539 14 US']


# Generated at 2022-06-23 20:25:25.677130
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    assert len(usa_spec_provider.tracking_number()) == 18



# Generated at 2022-06-23 20:25:27.957637
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    obj = USASpecProvider(seed=1)
    assert isinstance(obj, USASpecProvider)
    assert obj.session_id == 1



# Generated at 2022-06-23 20:25:37.379683
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    expected = [
        '#### #### #### #### ####',
        '@@ ### ### ### US',
        '#### #### ####',
        '#### #### #### ###',
        '1Z@####@##########',
    ]
    usa_provider = USASpecProvider()

    result = usa_provider.tracking_number('usps')
    assert len(result) == len(expected[0])
    assert result[2] == ' '
    assert result[10] == ' '
    assert result[18] == ' '
    assert result[26] == ' '
    assert result[34] == ' '

    result = usa_provider.tracking_number('fedex')
    assert len(result) == len(expected[2])
    assert result[2] == ' '

# Generated at 2022-06-23 20:25:38.257202
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa is not None

# Generated at 2022-06-23 20:25:45.678187
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for USASpecProvider_personality"""
    import os
    import random
    import mimesis.builtins.usa as usa

    random.seed(os.getenv('SEED', 42))
    usa_provider = usa.USASpecProvider(seed=os.getenv('SEED', 42))

    person_type = usa_provider.personality()

    assert person_type == 'INFJ'



# Generated at 2022-06-23 20:25:49.408573
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa
    assert isinstance(usa, USASpecProvider)

# Generated at 2022-06-23 20:25:54.219017
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    a = USASpecProvider()
    b = a.personality('mbti')
    assert b in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:26:01.689175
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.tracking_number('usps')
    assert usa_spec_provider.tracking_number()
    assert usa_spec_provider.tracking_number('fedex')
    assert usa_spec_provider.tracking_number('ups')
    assert usa_spec_provider.tracking_number(service='ups')
    assert usa_spec_provider.tracking_number(service='usps')


# Generated at 2022-06-23 20:26:03.867446
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality."""
    ssn = USASpecProvider().ssn()
    assert isinstance(ssn, str)
    assert len(ssn) == 11

# Generated at 2022-06-23 20:26:10.717055
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    #Takes in an optional category parameter and returns an appropriate value
    #Default category is mbti (16 possibilities)
    assert len(USASpecProvider().personality()) == 4

    #Category 'rheti' will return 10 possible values (1-10)
    assert int(USASpecProvider().personality('rheti')) in range(1, 11)

    #Category 'mbti' will return 16 possibilities
    categories = {'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                  'ISTP', 'ISFP', 'INFP', 'INTP',
                  'ESTP', 'ESFP', 'ENFP', 'ENTP',
                  'ESTJ', 'ESFJ', 'ENFP', 'ENTJ'}
    assert USASpecProvider().personality('mbti') in categories

    #Method should throw

# Generated at 2022-06-23 20:26:17.966113
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality(category='rheti') in range(1, 10)
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:26:18.900155
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test constructor."""
    USASpecProvider()

# Generated at 2022-06-23 20:26:24.709084
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.data import PROVIDERS
    from mimesis.enums import Gender

    # test for gender male
    provider = PROVIDERS['usaspecprovider']
    provider.seed(1234567890)
    # test for gender female
    provider.gender.gender = Gender.FEMALE
    for _ in range(0, 10):
        test_ssn = provider.ssn()
        assert test_ssn[3] == '-'
        assert test_ssn[6] == '-'
        assert len(test_ssn) == 11


# Generated at 2022-06-23 20:26:29.139081
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()

    usps = usa.tracking_number(service='usps')
    fedex = usa.tracking_number(service='fedex')
    ups = usa.tracking_number(service='ups')

    assert type(usps) == str
    assert type(fedex) == str
    assert type(ups) == str
    assert len(usps) >= len('#### #### #### #### ####')
    assert len(fedex) >= len('#### #### ####')
    assert len(ups) >= len('1Z@####@##########')


# Generated at 2022-06-23 20:26:32.111882
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Check if USASpecProvider is working."""
    from mimesis.providers.usa import USASpecProvider
    provider = USASpecProvider()
    tracking_number = provider.tracking_number()
    assert len(tracking_number) > 0

# Generated at 2022-06-23 20:26:33.984280
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.ssn() == '569-66-5801'

# Generated at 2022-06-23 20:26:45.738861
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print('Reference: https://en.wikipedia.org/wiki/List_of_U.S._state_abbreviations')
    usa = USASpecProvider()
    postal_code = usa.postal_code()
    assert len(postal_code) == 5
    assert postal_code.isdigit()

    ssn = usa.ssn()
    assert len(ssn) == 11
    assert ssn[:3].isdigit()
    assert ssn[4: 6].isdigit()
    assert ssn[7: 11].isdigit()

    tracking_number_usps = usa.tracking_number(service='usps')
    assert tracking_number_usps[:5].isdigit()
    assert tracking_number_usps[6: 10].isdigit()
    assert tracking

# Generated at 2022-06-23 20:26:47.739832
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    usa_provider.tracking_number()


# Generated at 2022-06-23 20:26:50.307542
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
	ssn = USASpecProvider()
	assert(len(ssn.ssn()) == 11)


# Generated at 2022-06-23 20:26:56.735275
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Case 1. With service = 'usps'
    tracking_number = USASpecProvider().tracking_number(service='usps')

    assert len(tracking_number) >= 22 and len(tracking_number) <= 24

    # Case 2. With service = 'fedex'
    tracking_number = USASpecProvider().tracking_number(service='fedex')

    assert len(tracking_number) >= 12 and len(tracking_number) <= 14

    # Case 3. With service = 'ups'
    tracking_number = USASpecProvider().tracking_number(service='ups')

    assert len(tracking_number) == 18


# Generated at 2022-06-23 20:27:06.465576
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""

    ut = USASpecProvider()
    my_personality = ut.personality()
    assert my_personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                           'ISTP', 'ISFP', 'INFP', 'INTP',
                           'ESTP', 'ESFP', 'ENFP', 'ENTP',
                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    re_rheti = ut.personality("rheti")
    assert re_rheti >= 1 and re_rheti <= 10
    assert isinstance(re_rheti, int)

# Generated at 2022-06-23 20:27:10.522758
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    seed = "7fefb0a07d7c4240b7770c8d1c4cb4cb"
    usa = USASpecProvider(seed=seed)
    assert isinstance(usa, USASpecProvider)


# Generated at 2022-06-23 20:27:12.343252
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    x = USASpecProvider()
    result = x.ssn()
    assert result == '231-43-8280'

# Generated at 2022-06-23 20:27:18.891455
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    usps_tracking_number = usa_provider.tracking_number('usps')
    fedex_tracking_number = usa_provider.tracking_number('fedex')
    ups_tracking_number = usa_provider.tracking_number('ups')

    assert usps_tracking_number
    assert usps_tracking_number.isalnum()
    assert fedex_tracking_number
    assert fedex_tracking_number.isalnum()
    assert ups_tracking_number
    assert ups_tracking_number.isalnum()


# Generated at 2022-06-23 20:27:26.524388
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """
    Test for method tracking_number of class USASpecProvider
    """
    random_state = 42
    mimesis_seed = USASpecProvider(seed=random_state)

    result = mimesis_seed.tracking_number()
    assert isinstance(result, str)

    result = mimesis_seed.tracking_number("usps")
    assert isinstance(result, str)

    result = mimesis_seed.tracking_number("fedex")
    assert isinstance(result, str)

    result = mimesis_seed.tracking_number("ups")
    assert isinstance(result, str)

    # Negative case test
    result = mimesis_seed.tracking_number("Test")
    assert isinstance(result, ValueError)


# Generated at 2022-06-23 20:27:33.069440
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    personality = provider.personality()
    assert personality in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    )
    assert (provider.personality('rheti') in range(1, 10))



# Generated at 2022-06-23 20:27:41.721537
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    male = Person('en', gender=Gender.MALE)
    female = Person('en', gender=Gender.FEMALE)

    person = USASpecProvider()

    assert isinstance(person.personality('mbti'), str)
    assert isinstance(person.personality('rheti'), int)

    assert type(person.personality(category='mbti')) == str
    assert type(person.personality(category='rheti')) == int

    assert len(person.personality(category='mbti')) == 4
    assert 1 <= person.personality(category='rheti') <= 10



# Generated at 2022-06-23 20:27:43.428034
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_spec_provider = USASpecProvider()
    assert isinstance(usa_spec_provider.ssn(),str)
    

# Generated at 2022-06-23 20:27:46.363683
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    ssn = USASpecProvider.personality("mbti")
    if len(ssn) <= 8:
        print("test_USASpecProvider_personality() -> passed")
    else:
        print("test_USASpecProvider_personality() -> FAILED")



# Generated at 2022-06-23 20:27:49.467325
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    data = ["#### #### #### #### ####", "@@ ### ### ### US"]
    assert USASpecProvider().tracking_number() in data


# Generated at 2022-06-23 20:27:50.609788
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)

# Generated at 2022-06-23 20:27:53.118805
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11


# Generated at 2022-06-23 20:27:56.652233
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    print()
    usa = USASpecProvider()
    for _ in range(100):
        print(f'USA Spec Provider: {usa.personality()}')

if __name__ == '__main__':
    test_USASpecProvider_personality()

# Generated at 2022-06-23 20:27:59.971756
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider.

    Tests a random, but valid Social Security Number.
    """
    usa = USASpecProvider()
    assert len(usa.ssn()) == 11

# Generated at 2022-06-23 20:28:04.260901
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityType
    from mimesis.providers.usa import USASpecProvider
    usa = USASpecProvider()
    assert PersonalityType.MBTI in usa.personality()

# Generated at 2022-06-23 20:28:11.190046
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                     'ISTP', 'ISFP', 'INFP', 'INTP',
                                                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert provider.personality(category='rheti') in range(1, 10)
    print("test_USASpecProvider_personality OK")
    provider.close()


# Generated at 2022-06-23 20:28:17.062551
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print("USASpecProvider()")
    provider = USASpecProvider()
    print("provider.personality(category='mbti'):", provider.personality(category='mbti'))
    print("provider.personality(category='rheti'):", provider.personality(category='rheti'))
    
if __name__ == "__main__":
    test_USASpecProvider()

# Generated at 2022-06-23 20:28:19.417823
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    spec = USASpecProvider()
    ssn = spec.ssn()
    assert len(ssn) == 11
    assert ssn.count('-') == 2


# Generated at 2022-06-23 20:28:22.206474
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider"""
    usa = USASpecProvider()
    result = usa.tracking_number()
    assert result != ''


# Generated at 2022-06-23 20:28:31.756109
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method ssn() of class USASpecProvider."""
    from mimesis.providers.us import USASpecProvider

    us = USASpecProvider()

    for _ in range(100):
        ssn: str = us.ssn()

        assert len(ssn) == 11

        separated = ssn.split('-')
        assert len(separated[0]) == 3
        assert len(separated[1]) == 2
        assert len(separated[2]) == 4

        assert int(separated[0]) not in (666, 900)

# Generated at 2022-06-23 20:28:35.951960
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Check initialization of USASpecProvider class
    assert USASpecProvider().__class__.__name__ == 'USASpecProvider'
    assert USASpecProvider().__class__.__mro__[1].__name__ == 'BaseSpecProvider'
    assert USASpecProvider().__class__.__mro__[2].__name__ == 'BaseProvider'


# Generated at 2022-06-23 20:28:45.213040
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()

# Generated at 2022-06-23 20:28:50.179939
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='rheti') in range(1,10)
    assert USASpecProvider().personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:28:55.276091
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaspec_provider = USASpecProvider()
    assert usaspec_provider.personality(category='rheti') in range(1, 11)

    assert usaspec_provider.personality() in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    )


# Generated at 2022-06-23 20:28:58.176797
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider(seed=123)
    assert usa_provider is not None
    assert isinstance(usa_provider, USASpecProvider)



# Generated at 2022-06-23 20:28:59.917453
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_personality = USASpecProvider()
    assert usa_personality.personality() is not None

# Generated at 2022-06-23 20:29:05.948372
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test unit for method tracking_number of class USASpecProvider."""
    us_spec = USASpecProvider()
    assert len(us_spec.tracking_number()) == 22
    assert us_spec.tracking_number()[0] != us_spec.tracking_number()[0]


# Generated at 2022-06-23 20:29:11.167874
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    ssn = USASpecProvider().ssn()
    assert isinstance(ssn, str)

    sections = ssn.split('-')
    assert len(sections) == 3
    assert sections[0].isnumeric()
    assert sections[1].isnumeric()
    assert sections[2].isnumeric()

    assert '666' not in sections[0]



# Generated at 2022-06-23 20:29:13.813728
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    esp = USASpecProvider(seed=12)
    print(esp.personality())


# Generated at 2022-06-23 20:29:15.214258
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa


# Generated at 2022-06-23 20:29:21.547250
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    pass
    # # Test mbti
    # with USASpecProvider() as provider:
    #     assert provider.personality('mbti')

    # # Test rheti
    # with USASpecProvider() as provider:
    #     assert provider.personality('rheti')

    # # Test invalid
    # with USASpecProvider() as provider:
    #     assert not provider.personality('invalid')

# Generated at 2022-06-23 20:29:22.352833
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    random = USASpecProvider()
    random.ssn()

# Generated at 2022-06-23 20:29:28.665817
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert (usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'))
    assert (1 <= usa.personality(category='rheti') <= 10)



# Generated at 2022-06-23 20:29:39.034388
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.identifier import Provider
    from mimesis.providers.internet import Internet
    from mimesis.providers.geo import Geo


    usa_provider = USASpecProvider()

    # Unit test for method 'ssn'
    usa_provider.ssn()

    assert usa_provider.person.gender == Gender.MALE
    assert usa_provider.person.age(minimum=18) >= 18
    assert isinstance(usa_provider.person, Person)

    assert isinstance(usa_provider.address, Address)
    assert usa_provider.address.country == "United States of America"


# Generated at 2022-06-23 20:29:44.167948
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Test method personality with option 1
    assert USASpecProvider().personality(category='rheti') in (1,2,3,4,5,6,7,8,9,10)
    
    # Test method personality with option 2
    assert USASpecProvider().personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:29:48.106465
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    data = USASpecProvider().personality('rheti')
    assert isinstance(data, int)
    assert data >= 1 and data <= 10
    data = USASpecProvider().personality('mbti')
    assert isinstance(data, str)

# Generated at 2022-06-23 20:29:52.388320
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    USASpecProvider = USASpecProvider()
    assert USASpecProvider.tracking_number('ups')
    assert USASpecProvider.tracking_number('fedex')
    assert USASpecProvider.tracking_number('usps')
    assert USASpecProvider.ssn()
    assert USASpecProvider.personality()

# Generated at 2022-06-23 20:30:01.993666
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider is not None

    # test_ssn
    assert len(provider.ssn()) == 11

    # test_tracking_number
    assert len(provider.tracking_number()) >= 12
    assert len(provider.tracking_number('ups')) >= 11
    assert len(provider.tracking_number('fedex')) >= 11
    # test_shipping_companies
    assert len(provider.tracking_number('dhl')) == 0
    # test_personality
    assert len(provider.personality()) == 4
    assert len(provider.personality('rheti')) == 1

# Generated at 2022-06-23 20:30:04.307037
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
  a = USASpecProvider(seed=0)
  assert a.ssn() == '090-63-8932'


# Generated at 2022-06-23 20:30:08.959149
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                              'ISTP', 'ISFP', 'INFP', 'INTP',
                                              'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                              'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:30:10.707064
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    result = provider.tracking_number()
    assert len(result) == 22 and result.startswith('94001')


# Generated at 2022-06-23 20:30:13.524938
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    usa = USASpecProvider()
    print(usa.tracking_number())
    print(usa.tracking_number('USPS'))
    print(usa.tracking_number('fedex'))
    print(usa.tracking_number('ups'))
    #print(usa.tracking_number('wrong'))



# Generated at 2022-06-23 20:30:14.861544
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:30:21.028721
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usps_num = USASpecProvider().tracking_number(service='USPS')
    fedex_num = USASpecProvider().tracking_number(service='FEDEX')
    ups_num = USASpecProvider().tracking_number(service='UPS')
    assert isinstance(usps_num, str)
    assert isinstance(fedex_num, str)
    assert isinstance(ups_num, str)
    assert len(usps_num) == 22
    assert len(fedex_num) == 18
    assert len(ups_num) == 18


# Generated at 2022-06-23 20:30:26.937791
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print("\n----- test_USASpecProvider -----\n")

    print("Create an instance of USASpecProvider")
    usa_provider = USASpecProvider()
    print("Get class name of this provider: ", usa_provider.Meta.name)

    print("\n----- End test_USASpecProvider -----\n")


# Generated at 2022-06-23 20:30:27.505713
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvi

# Generated at 2022-06-23 20:30:37.314775
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    provider = USASpecProvider()
    ssn = provider.ssn()

    # "SSN" should be a string with leading zeros
    assert isinstance(ssn, str)
    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'

    # area_id should be an integer from 1 to 899
    area_str = ssn[:3]
    assert area_str.isdigit()
    area_int = int(area_str)
    assert 1 <= area_int <= 899

    # group_id should be an integer from 1 to 99
    group_str = ssn[4:6]
    assert group_str.isdigit()
    group_int = int

# Generated at 2022-06-23 20:30:43.021261
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider"""
    prov = USASpecProvider()
    ssn = prov.ssn()  
    assert len(ssn) == 11
    # Test that the format is correct
    import re
    regex = re.compile(r'(\d\d\d)-(\d\d)-(\d\d\d\d)')
    assert regex.match(ssn)
    

# Generated at 2022-06-23 20:30:47.732999
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # this test is a part of function:
    # def ssn(self) -> str:
    usa_spec = USASpecProvider()
    # assert_type
    # assert_true
    # assert_not_equal
    assert isinstance(usa_spec.ssn(), str)
    assert len(usa_spec.ssn()) == 11
    assert usa_spec.ssn() != '666-66-5801'


# Generated at 2022-06-23 20:30:51.855392
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test constructor of class USASpecProvider."""
    spec = USASpecProvider()
    assert isinstance(spec, USASpecProvider)


# Generated at 2022-06-23 20:30:54.354240
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider, USASpecProvider)


# Generated at 2022-06-23 20:30:55.982839
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa is not None

# Test for tracking number

# Generated at 2022-06-23 20:31:00.264953
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    #Create instance of class USASpecProvider
    usa_provider = USASpecProvider()

    #Check type of instance
    assert isinstance(usa_provider, USASpecProvider)

    # Check count of attributes
    assert len(dir(usa_provider)) == 12



# Generated at 2022-06-23 20:31:07.877072
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
         'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
         'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert 0 < usa_provider.personality('rheti') < 11


# Generated at 2022-06-23 20:31:14.689745
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Test 1
    provider = USASpecProvider()
    assert len(provider.ssn()) == 11

    # Test 2
    provider = USASpecProvider()
    assert provider.ssn() == "011-11-1111"

    # Test 3: Negative test
    provider = USASpecProvider()
    assert provider.ssn() != "00-11-1111"


# Generated at 2022-06-23 20:31:19.183577
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')



# Generated at 2022-06-23 20:31:21.011368
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    ssn = USASpecProvider().ssn()
    assert isinstance(ssn, str)


# Generated at 2022-06-23 20:31:27.214595
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test case for method "personality" of class "USASpecProvider"."""
    from mimesis_json import USASpecProvider as USASpecProviderJson
    csv_vals = set()
    for i in range(0, 20):
        csv_vals.add(USASpecProvider().personality(category='rheti'))
    json_vals = set()
    for i in range(0, 20):
        json_vals.add(USASpecProviderJson().personality(category='rheti'))
    assert csv_vals == json_vals


# Generated at 2022-06-23 20:31:29.737192
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    for i in range(0, 1000):
        assert len(USASpecProvider().tracking_number()) > 3


# Generated at 2022-06-23 20:31:31.325884
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert isinstance(USASpecProvider(), USASpecProvider)


# Generated at 2022-06-23 20:31:34.075755
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:31:35.474361
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    USASpecProvider().personality()

# Generated at 2022-06-23 20:31:38.048400
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Create a random generator."""
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider, USASpecProvider)



# Generated at 2022-06-23 20:31:39.739190
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert isinstance(provider.tracking_number(), str)


# Generated at 2022-06-23 20:31:44.074865
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:31:51.260317
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    usa_spec_provider = USASpecProvider()
    result = usa_spec_provider.personality()

    assert result in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    ]

# Generated at 2022-06-23 20:31:59.531595
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityType
    from mimesis.providers.personality import Personality

    p = Personality()
    p.add_provider(USASpecProvider())

    assert p.personality('mbti').upper() in PersonalityType.MBTI.value
    assert p.personality().upper() in PersonalityType.MBTI.value
    assert 1 <= p.personality('rheti') and p.personality('rheti') <= 10
    assert 1 <= p.personality().rheti() and p.personality().rheti() <= 10
    assert 1 <= p.rheti() and p.rheti() <= 10

# Generated at 2022-06-23 20:32:05.144637
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test function to generate a tracking number."""
    provider = USASpecProvider()

    # USPS
    assert provider.tracking_number() == '1185 6972 8188 8992 0776'
    assert provider.tracking_number('USPS') == '8664 6955 3513 3513 1882'

    # Fedex
    assert provider.tracking_number('Fedex') == '1157 6093 6266'
    assert provider.tracking_number('Fedex') == '8141 7751 0687'

    # UPS
    assert provider.tracking_number('UPS') == '1Z9Y2G0Y8W85917214'



# Generated at 2022-06-23 20:32:06.331301
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn()

# Generated at 2022-06-23 20:32:10.272933
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Strategy: Check if name of provider is 'usat_provider'
    usa_provider = USASpecProvider()
    assert (usa_provider.Meta.name) == 'usa_provider'

# Generated at 2022-06-23 20:32:12.134147
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.__class__.__name__ == 'USASpecProvider'

# Generated at 2022-06-23 20:32:16.192801
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider, "USASpecProvider() is null"


# Generated at 2022-06-23 20:32:18.107155
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    s = USASpecProvider()
    print(s.ssn())

# Generated at 2022-06-23 20:32:19.314990
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider()

# Generated at 2022-06-23 20:32:21.810172
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """

    :return:
    """
    provider = USASpecProvider()
    print('=> test_USASpecProvider_tracking_number')
    print('Generate USPS tracking number: {0}'.format(
        provider.tracking_number(),
    ))
    print('Generate FedEx tracking number: {0}'.format(
        provider.tracking_number('fedex'),
    ))
    print('Generate UPS tracking number: {0}'.format(
        provider.tracking_number('ups'),
    ))



# Generated at 2022-06-23 20:32:23.758778
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Arrange
    usa_sp = USASpecProvider()

    # Act
    personality = usa_sp.personality()

    # Assert
    assert isinstance(personality, str)

# Generated at 2022-06-23 20:32:31.839847
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                         'ISTP', 'ISFP', 'INFP', 'INTP',
                                         'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                         'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa.personality('rheti'), int)
    assert len(usa.personality()) == 4

# Generated at 2022-06-23 20:32:33.863430
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tracking_number = USASpecProvider().tracking_number()
    assert tracking_number is not None and len(tracking_number) > 1



# Generated at 2022-06-23 20:32:37.498419
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit testing for method personality of class USASpecProvider."""
    assert USASpecProvider().personality()
    assert USASpecProvider().personality(category='rheti')

# Generated at 2022-06-23 20:32:39.072564
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.spec.name == 'usa_provider'


# Generated at 2022-06-23 20:32:43.083180
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of USASpecProvider class."""
    usa = USASpecProvider()
    for _ in range(100):
        ssn = usa.ssn()
        assert ssn.startswith('86')



# Generated at 2022-06-23 20:32:49.616409
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    assert us.personality('mbti') in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ',
    ]
    assert isinstance(us.personality('rheti'), int)
    assert 0 < us.personality('rheti') <= 10



# Generated at 2022-06-23 20:32:51.255914
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    print(usa.us_state_name())

# Generated at 2022-06-23 20:32:56.827246
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number(service='usps') == '0169 9158 5372 2293 6584'
    assert provider.tracking_number(service='fedex') == '7411 7340 0861'
    assert provider.tracking_number(service='ups') == '1Z175A509344152881'


# Generated at 2022-06-23 20:32:58.908467
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():

    from mimesis.providers.usa.usa_provider import USASpecProvider

    ego = USASpecProvider()
    assert ego.ssn() != ego.ssn()


# Generated at 2022-06-23 20:33:01.077266
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number(service='usps')
    assert provider.tracking_number(service='fedex')
    assert provider.tracking_number(service='ups')

# Generated at 2022-06-23 20:33:03.103322
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    p = USASpecProvider()
    assert isinstance(p, USASpecProvider)


# Generated at 2022-06-23 20:33:08.487201
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    type = provider.personality(category="rheti")
    assert type > 0 and type <= 10
    type = provider.personality()
    assert type in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:33:10.416525
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    sp = USASpecProvider()
    sp.personality("mbti")

# Generated at 2022-06-23 20:33:13.436774
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # assert_string(USASpecProvider().name, 'usa_provider')
    assert_string(USASpecProvider().__doc__, 'Class that provides special data for USA (en).')


# Generated at 2022-06-23 20:33:16.678595
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider_instance = USASpecProvider()
    print(usa_provider_instance.personality(category='rheti'))
    print(usa_provider_instance.personality(category='mbti'))

# Generated at 2022-06-23 20:33:22.220201
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert len(provider.tracking_number(service='ups')) == 18
    assert len(provider.tracking_number(service='fedex')) in (12, 14)
    assert len(provider.tracking_number(service='usps')) in (22, 15)
    try:
        provider.tracking_number(service='asda')
    except ValueError:
        pass
    else:
        raise AssertionError('The method should raise an error.')


# Generated at 2022-06-23 20:33:29.890479
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """
    Unit test for method tracking_number of class USASpecProvider.

    Format of tracking number is the following:
    USPS: 9 letters and 20 digits, or 1Z followed by 15 digits
    FedEx: 12 digits
    UPS: 18 letters and digits, starting with 1Z

    :return: None
    """
    provider = USASpecProvider()
    assert provider.tracking_number('USPS').isalnum()
    assert provider.tracking_number('FedEx').isdigit()
    assert provider.tracking_number('UPS').isalnum()


# Generated at 2022-06-23 20:33:32.929093
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    assert USASpecProvider().ssn() == '625-66-8567'



# Generated at 2022-06-23 20:33:34.929533
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_spec_provider = USASpecProvider()
    assert isinstance(usa_spec_provider.ssn(), str)


# Generated at 2022-06-23 20:33:42.515694
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit tests for method ``personality`` of class ``USASpecProvider``."""
    assert USASpecProvider().personality('rheti') in range(1, 11)
    assert USASpecProvider().personality('rheti') in range(1, 11)
    assert USASpecProvider().personality('mbti') in \
           ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
            'ISTP', 'ISFP', 'INFP', 'INTP',
            'ESTP', 'ESFP', 'ENFP', 'ENTP',
            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:33:45.554466
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert isinstance(provider.personality(), str)
    assert isinstance(provider.personality('rheti'), int)

# Generated at 2022-06-23 20:33:48.038811
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_data = USASpecProvider()
    assert usa_data.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:33:55.637433
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert type(provider.tracking_number()) == str
    assert len(provider.tracking_number()) == 22
    assert type(provider.tracking_number(service='fedex')) == str
    assert len(provider.tracking_number(service='fedex')) == 12 or len(
        provider.tracking_number(service='fedex')) == 16
    assert type(provider.tracking_number(service='ups')) == str
    assert len(provider.tracking_number(service='ups')) == 18


# Generated at 2022-06-23 20:33:59.135744
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    assert us.tracking_number(service = 'usps') != us.tracking_number(service = 'fedex')
    assert len(us.tracking_number(service = 'ups')) == 18


# Generated at 2022-06-23 20:34:03.350341
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Return a string below
    anonymous = USASpecProvider()

    # Test the case of "ssn" method, if it returns a string
    assert isinstance(anonymous.ssn(), str)
    # Test the case of "tracking_number" method, if it returns a string
    assert isinstance(anonymous.tracking_number(), str)

# Generated at 2022-06-23 20:34:05.950746
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    for name in USASpecProvider.Meta.name:
        us = USASpecProvider(name)
        assert len(us.tracking_number()) > 0 or len(us.tracking_number('usps')) > 0 or \
            len(us.tracking_number('fedex')) > 0


# Generated at 2022-06-23 20:34:07.992252
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    test = USASpecProvider()
    print(test.tracking_number())


# Generated at 2022-06-23 20:34:20.278651
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import SpecialChars
    from mimesis.providers.usa import USASpecProvider
    
    x = USASpecProvider() 
    
    assert x.ssn() != x.ssn() # Two SSN are different
    assert len(x.ssn()) == 11 # lenght of SSN is 11
    
    check = re.compile(r'\d{3}[-]\d{2}[-]\d{4}') # check format of SSN
    assert check.match(x.ssn()) != None # SSN has the proper format
    
    test = x.ssn(mask='###-##-####') # create mask ###-##-####
    assert test == x.ssn() # SSN is equal to test
    
    test = x.ssn

# Generated at 2022-06-23 20:34:23.472599
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    u = USASpecProvider(seed=123)
    for i in range(0, 100):
        assert u.ssn()


# Generated at 2022-06-23 20:34:25.463960
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)


# Generated at 2022-06-23 20:34:28.677656
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider(seed=0)
    assert usa.personality('rheti') == 7
    assert usa.personality() == 'ISFJ'


# Generated at 2022-06-23 20:34:34.028063
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    personality = provider.personality()
    assert personality in \
        ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    personality = provider.personality('rheti')
    assert personality in range(1, 10)

# Generated at 2022-06-23 20:34:37.426151
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usaspecprovider = USASpecProvider()
    assert isinstance(usaspecprovider.personality(), str)
    assert isinstance(usaspecprovider.personality(category='rheti'), int)
    assert usaspecprovider.personality(category='rheti') in range(1, 10)


# Generated at 2022-06-23 20:34:44.070864
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='rheti') in range(1,11)
    assert USASpecProvider().personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']


# Generated at 2022-06-23 20:34:45.806471
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    assert usa.ssn() == usa.ssn()


# Generated at 2022-06-23 20:34:49.092587
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    b = USASpecProvider()
    assert b.current_locale() == 'en'

# Generated at 2022-06-23 20:34:51.778036
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    data = ['569-66-5801', 'ISFJ']
    provider = USASpecProvider()
    assert provider.ssn() in data
    assert provider.personality('mbti') in data