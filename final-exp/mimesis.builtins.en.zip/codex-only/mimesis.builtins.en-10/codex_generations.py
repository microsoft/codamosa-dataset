

# Generated at 2022-06-23 20:24:53.249067
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tp = USASpecProvider()
    tracking_number = tp.tracking_number('usps')
    assert isinstance(tracking_number, str)

# Generated at 2022-06-23 20:24:57.611843
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    fake = USASpecProvider()
    assert fake.tracking_number() in (
        '94055 1620 0003 8869 4099',
        '94055 1620 0003 8869 4099',
        '94055 1620 0003 8869 4099',
        '94055 1620 0003 8869 4099',
        '94055 1620 0003 8869 4099',
    )


# Generated at 2022-06-23 20:25:03.376082
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit tests for USASpecProvider class."""
    with USASpecProvider() as spec_provider:
        assert spec_provider.tracking_number() is not None
        assert spec_provider.personality() is not None
        assert spec_provider.ssn() is not None
        assert spec_provider.meta.name == 'usa_provider'


# Generated at 2022-06-23 20:25:04.182182
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider()
    assert(True)

# Generated at 2022-06-23 20:25:05.978313
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.__class__ == USASpecProvider


# Generated at 2022-06-23 20:25:12.647160
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Tests for USASpecProvider.personality."""
    assert USASpecProvider().personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                     'ISTP', 'ISFP', 'INFP', 'INTP',
                                                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:25:14.073893
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider() is not None


# Generated at 2022-06-23 20:25:15.315348
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    print(USASpecProvider().tracking_number('Fedex'))


# Generated at 2022-06-23 20:25:17.901359
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    assert us is not None


# Generated at 2022-06-23 20:25:23.422943
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    assert USASpecProvider().ssn() == '569-66-5801'
    assert USASpecProvider().ssn() == '036-74-6212'
    assert USASpecProvider().ssn() == '004-40-9582'
    assert USASpecProvider().ssn() == '042-89-4281'
    assert USASpecProvider().ssn() == '104-63-8494'



# Generated at 2022-06-23 20:25:25.586695
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider('en')
    usa.personality()

# Generated at 2022-06-23 20:25:30.582551
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """ Test USASpecProvider.

    Test that the provider is properly initialized and that
    the right data is returned.
    """
    usa_provider = USASpecProvider()
    assert usa_provider.__class__.__name__ == 'USASpecProvider'
    assert isinstance(usa_provider.location(), str)
    assert hasattr(usa_provider, 'random')
    assert isinstance(usa_provider.random, object)



# Generated at 2022-06-23 20:25:32.292825
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    tmp = USASpecProvider()
    assert tmp.ssn() == '666-66-0001'


# Generated at 2022-06-23 20:25:40.440212
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Running unittest for method tracking_number of class USASpecProvider."""
    usa = USASpecProvider()
    # USPS

# Generated at 2022-06-23 20:25:43.657297
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    prov = USASpecProvider(seed = 12345678)

    assert prov.tracking_number() == '5877-3918-9115-8482-3289'


# Generated at 2022-06-23 20:25:46.889156
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Arrange
    provider = USASpecProvider(seed=123)

    # Act
    result = provider.ssn()

    # Assert
    assert result == '318-12-6409'


# Generated at 2022-06-23 20:25:52.621355
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    faker = USASpecProvider()
    assert faker.tracking_number(service='usps') != faker.tracking_number(service='usps')
    assert faker.tracking_number(service='fedex') != faker.tracking_number(service='fedex')
    assert faker.tracking_number(service='ups') != faker.tracking_number(service='ups')


# Generated at 2022-06-23 20:25:59.072200
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    t = USASpecProvider()
    assert t.tracking_number() is not None
    assert t.tracking_number(service = 'USPS') is not None
    assert t.tracking_number(service = 'FedEx') is not None
    assert t.tracking_number(service = 'UPS') is not None
    assert t.tracking_number(service = 'usps') is not None
    assert t.tracking_number(service = 'fedex') is not None
    assert t.tracking_number(service = 'ups') is not None
    try:
        t.tracking_number(service = 'toto')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-23 20:26:07.610724
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    # Test for 4 types of categories
    for category in ["mbti", "rheti", "enneagram", "disc"]:
        # Test for the method run 100 times
        for _ in range(100):
            result = provider.personality(category=category)
            # Test if the result is correct
            if category == "mbti":
                assert len(result) == 4
                assert result in ("ISFJ", "ISTJ", "INFJ", "INTJ",
                                  "ISTP", "ISFP", "INFP", "INTP",
                                  "ESTP", "ESFP", "ENFP", "ENTP",
                                  "ESTJ", "ESFJ", "ENFJ", "ENTJ")

# Generated at 2022-06-23 20:26:09.282356
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert usa_provider is not None


# Generated at 2022-06-23 20:26:12.514554
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.provider == 'usa_provider'
    

# Generated at 2022-06-23 20:26:14.893439
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.name == "usa_provider"

# Generated at 2022-06-23 20:26:17.617500
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    p = USASpecProvider()
    assert p.ssn() not in ["666-66-6666", "000-00-0000", "999-99-999"]

# Generated at 2022-06-23 20:26:19.603297
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert type(ssn) is str


# Generated at 2022-06-23 20:26:20.834037
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider() is not None


# Generated at 2022-06-23 20:26:22.908274
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    my_USASpecProvider = USASpecProvider()
    print(my_USASpecProvider.tracking_number('USPS'))


# Generated at 2022-06-23 20:26:25.376746
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number()
    assert usa_provider.ssn()
    assert usa_provider.personality()

# Generated at 2022-06-23 20:26:28.305902
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() == 'G7F2 7Q04 2K11 1L88 5A13'


# Generated at 2022-06-23 20:26:29.872587
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usasp = USASpecProvider()
    usasp.personality('mbti')
    usasp.personality('rheti')



# Generated at 2022-06-23 20:26:33.645474
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider"""

    usa_provider = USASpecProvider()
    num = usa_provider.tracking_number()
    assert len(num) > 0
    assert type(num) is str


# Generated at 2022-06-23 20:26:40.173467
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    post_service = 'USPS'
    track_number = USASpecProvider().tracking_number(post_service)
    assert isinstance(track_number, str)
    assert len(track_number) == 18
    for i in range(4):
        assert track_number[4*i+1] == ' '
    assert track_number[-3:] == 'US'


# Generated at 2022-06-23 20:26:50.604973
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Create instance of class USASpecProvider
    usa_spec_provider = USASpecProvider()
    # create ttype of list, list of lists
    usa_post_services = [
        ['usps', '#### #### #### #### ####', '@@ ### ### ### US'],
        ['fedex', '#### #### ####', '#### #### #### ###'],
        ['ups', '1Z@####@##########'],
    ]
    # return random tracking number
    number = usa_spec_provider.tracking_number()
    assert number is not None and number != ''
    # loop through usa_post_services to see if the post service matches the returned number

# Generated at 2022-06-23 20:26:52.491877
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() == '0V732 8042 7221 2215 Q867'


# Generated at 2022-06-23 20:26:58.554877
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    usa_spec_provider = USASpecProvider()

    #Get unit test data from data file
    import json
    import os

    file_dir = os.path.dirname(__file__)
    file_path = os.path.join(file_dir, './data/USASpecProvider_test_data.json')

    with open(file_path, 'r') as f:
        test_data = json.load(f)

    # Test
    assert usa_spec_provider.personality(category = 'rheti') in test_data['rheti'] 
    assert usa_spec_provider.personality(category = 'mbti') in test_data['mbti']

# Generated at 2022-06-23 20:27:04.924533
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test USASpecProvider class."""
    usa = USASpecProvider()
    assert hasattr(usa, 'random')
    assert hasattr(usa, 'seed')
    assert hasattr(usa, '__initialised')
    assert hasattr(usa, 'Meta')
    assert hasattr(usa, 'trash')
    assert hasattr(usa, 'locale')


# Generated at 2022-06-23 20:27:06.250395
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality('mbti')


# Generated at 2022-06-23 20:27:13.428235
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn."""
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert ssn is not None
    assert isinstance(ssn, str)
    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'
    assert ssn[0:3].isdigit()
    assert ssn[4:6].isdigit()
    assert ssn[7:11].isdigit()


# Generated at 2022-06-23 20:27:15.009502
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.__dict__['locale'] == 'en'

# Generated at 2022-06-23 20:27:16.198544
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    test = USASpecProvider()
    assert test.ssn()


# Generated at 2022-06-23 20:27:21.337173
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider(seed=7).tracking_number() == '3V2F113950'
    assert USASpecProvider(seed=7).tracking_number(service='USPS') == '3V2F113950'
    assert USASpecProvider(seed=7).tracking_number(service='FedEx') == '8T7T039967663'
    assert USASpecProvider(seed=7).tracking_number(service='UPS') == '1ZW0N94A0308536254'



# Generated at 2022-06-23 20:27:24.735617
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method ssn of class USASpecProvider
    """
    usa=USASpecProvider()
    assert isinstance(usa.ssn(), str)


# Generated at 2022-06-23 20:27:29.661137
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert ssn.isdigit()
    assert (len(ssn) == 11)
    assert (ssn[3] == '-')
    assert (ssn[6] == '-')
    


# Generated at 2022-06-23 20:27:32.517040
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    u = USASpecProvider()
    assert repr(u) == "<USASpecProvider('en')>"
    assert u.ssn() != u.ssn()
    assert isinstance(u.ssn(), str)


# Generated at 2022-06-23 20:27:35.511278
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider(seed=0)
    assert usa_provider.tracking_number(service='ups') == '1Z96A832023725854'

test_USASpecProvider_tracking_number()


# Generated at 2022-06-23 20:27:37.163212
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    print(us.personality(category='rheti'))


# Generated at 2022-06-23 20:27:42.043551
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    from mimesis.builtins import USASpecProvider
    usa = USASpecProvider()
    assert usa.tracking_number(service='fedex') == '7441 6394 559'

# Generated at 2022-06-23 20:27:48.875581
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    for i in range(1, 101):
        person = provider.personality()
        assert person == 'ISFJ' or person == 'ISTJ' or person == 'INFJ' or person == 'INTJ'\
        or person == 'ISTP' or person == 'ISFP' or person == 'INFP' or person == 'INTP'\
        or person == 'ESTP' or person == 'ESFP' or person == 'ENFP' or person == 'ENTP'\
        or person == 'ESTJ' or person == 'ESFJ' or person == 'ENFJ' or person == 'ENTJ', 'Error!'


# Generated at 2022-06-23 20:27:52.032826
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.providers.us_provider import USASpecProvider
    usaSpecProvider = USASpecProvider()
    s = usaSpecProvider.tracking_number(service = 'usps')
    # print("test_USASpecProvider_tracking_number : " + s)


# Generated at 2022-06-23 20:27:59.883445
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    for _ in range(100):
        ssn = provider.ssn()
        assert isinstance(ssn, str)
        assert len(ssn) == 11
        assert ssn[3:5].isnumeric()
        assert ssn[3:5] != '00'
        assert ssn[6:8].isnumeric()
        assert ssn[6:8] != '00'
        assert ssn[9:].isnumeric()
        assert ssn[9:] != '0'
        area = int(ssn[:3])
        assert 666 > area >= 1

# Generated at 2022-06-23 20:28:04.150833
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Arrange
    provider = USASpecProvider()
    
    # Act
    tracking_number = provider.tracking_number('usps')

    # Assert 
    assert len(tracking_number) >= 0

# Generated at 2022-06-23 20:28:08.069500
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider(seed=2)
    personality = provider.personality(category='mbti')
    assert personality == 'ISFJ'
    personality = provider.personality(category='rheti')
    assert personality == 4


# Generated at 2022-06-23 20:28:14.596302
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    value1 = provider.personality(category='mbti')
    assert isinstance(value1, str)
    assert len(value1) == 4
    assert value1.isupper()
    value2 = provider.personality(category='rheti')
    assert isinstance(value2, int)
    assert value2 <= 10 and value2 >= 1

# Generated at 2022-06-23 20:28:16.819461
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    p1 = USASpecProvider(seed=123)
    assert p1.ssn() == '679-77-7527'


# Generated at 2022-06-23 20:28:18.534640
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    ssn = usa.ssn()
    assert len(ssn) == 11

# Generated at 2022-06-23 20:28:20.723818
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test constructor of USASpecProvider."""
    assert USASpecProvider(seed=100).random.seed == 100  # type: ignore


# Generated at 2022-06-23 20:28:24.191963
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    #name = 'usa_provider'
    provider = USASpecProvider()
    for i in range(10):
        print(provider.tracking_number(service='usps'))
        print(provider.ssn())
        print(provider.personality())
        print('\n')

# Generated at 2022-06-23 20:28:29.000903
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test."""
    provider = USASpecProvider()
    result = provider.tracking_number()
    assert result is not None
    assert ' ' in result
    assert 'US' in result
    assert ' ' in result



# Generated at 2022-06-23 20:28:31.010666
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    test = USASpecProvider()
    assert isinstance(test, USASpecProvider)


# Generated at 2022-06-23 20:28:36.598019
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider()
    assert_that(p.personality(category='rheti')).is_in(range(1,10))
    assert_that(p.personality(category='mbti')).is_in(['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'])

# Generated at 2022-06-23 20:28:38.007147
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider, USASpecProvider)


# Generated at 2022-06-23 20:28:43.052840
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn) == 11
    assert ssn[0:3].isdigit()
    assert ssn[4] == '-'
    assert ssn[5:7].isdigit()
    assert ssn[8] == '-'
    assert ssn[9:11].isdigit()


# Generated at 2022-06-23 20:28:45.070329
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    usa.personality('mbti')


# Generated at 2022-06-23 20:28:48.452987
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Initialized an object of the class USASpecProvider
    usaspecprovider= USASpecProvider()

    # Generate a type of personality
    person_obj=usaspecprovider.personality()

    # Print the result
    print(person_obj)



# Generated at 2022-06-23 20:28:49.708435
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    print(usa.ssn())

# Generated at 2022-06-23 20:28:59.826373
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """As a user I want to test the method tracking_number of class USASpecProvider"""

    from mimesis import USASpecProvider
    usaspecprovider = USASpecProvider()

    usps_tracking_number = usaspecprovider.tracking_number(service='usps')
    assert usps_tracking_number.startswith("9")

    fedex_tracking_number = usaspecprovider.tracking_number(service='fedex')
    assert fedex_tracking_number.startswith("7")

    ups_tracking_number = usaspecprovider.tracking_number(service='ups')
    assert ups_tracking_number.startswith("1Z")


# Generated at 2022-06-23 20:29:09.783562
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert (usa_provider.__class__.__name__ == 'USASpecProvider')
    assert (usa_provider.__class__.__mro__[1].__name__ == 'BaseSpecProvider')
    assert (usa_provider.__class__.__mro__[2].__name__ == 'SpecProvider')
    assert (usa_provider.__class__.__mro__[3].__name__ == 'BaseProvider')
    assert (usa_provider.__class__.__mro__[4].__name__ == 'BaseSpec')


# Generated at 2022-06-23 20:29:13.240775
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider()
    # an invalid SSN is one where the area number is 666
    # the test is for this case
    assert us.ssn() != '666-66-6666'

# Generated at 2022-06-23 20:29:14.312701
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider(seed=100)

# Generated at 2022-06-23 20:29:16.912772
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    result = provider.tracking_number()
    assert result is not None


# Generated at 2022-06-23 20:29:19.678842
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider1 = USASpecProvider()
    provider2 = USASpecProvider(seed=0)
    assert type(provider1) == type(provider2)


# Generated at 2022-06-23 20:29:21.871212
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider(seed=1234)
    assert provider.ssn() == '220-63-9589'


# Generated at 2022-06-23 20:29:22.934607
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider()
    assert us.ssn() != us.ssn()


# Generated at 2022-06-23 20:29:24.318236
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider()
    assert len(us.ssn()) == 11
    assert any(char in us.ssn() for char in "-")


# Generated at 2022-06-23 20:29:29.416907
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    personlity = provider.personality()
    assert personlity in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP',
                          'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:29:37.969804
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert(len(ssn) == 11)
    parts = ssn.split('-')
    assert(len(parts) == 3)
    assert(int(parts[0]) >= 1 and int(parts[0]) <= 899)
    assert(int(parts[0]) == 665 or int(parts[0]) != 666)
    assert(int(parts[1]) >= 1 and int(parts[1]) <= 99)
    assert(int(parts[2]) >= 1 and int(parts[2]) <= 9999)



# Generated at 2022-06-23 20:29:40.587875
# Unit test for method ssn of class USASpecProvider

# Generated at 2022-06-23 20:29:42.757394
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider() != BaseSpecProvider(seed='test')



# Generated at 2022-06-23 20:29:46.334909
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider"""
    test_provider = USASpecProvider()
    assert test_provider.tracking_number('upS') is not None

test_USASpecProvider_tracking_number()

# Generated at 2022-06-23 20:29:54.071795
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert(USASpecProvider().personality('rheti') == 1)
    s = set()
    for i in range(1000):
        n = USASpecProvider().personality('mbti')
        assert(n in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                'ISTP', 'ISFP', 'INFP', 'INTP',
                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'))
        s.add(n)
    assert(len(s) == 16)

# Generated at 2022-06-23 20:29:57.724909
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider()
    assert isinstance(p.personality(), str)
    assert isinstance(p.personality(category='rheti'), int)


# Unit tests for method tracking number of class USASpecProvider

# Generated at 2022-06-23 20:30:00.351537
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    print(ssn)
    assert len(ssn) == 11

# Generated at 2022-06-23 20:30:07.228633
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test the method ssn of class USASpecProvider"""
    ssn = USASpecProvider(seed=4321).ssn()

    assert len(ssn.split('-')) == 3
    assert ssn[3] == '-'
    assert ssn[6] == '-'
    assert ssn[0:3].isnumeric()
    assert ssn[4:6].isnumeric()
    assert ssn[7:11].isnumeric()
    assert int(ssn[0:3]) < 900


# Generated at 2022-06-23 20:30:17.828696
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test the method tracking_number of class USASpecProvider."""
    provider = USASpecProvider(seed=42)
    assert provider.tracking_number(service='usps') == '9075 0449 6581 4808 4965'
    assert provider.tracking_number(service='usps') == 'RE 505 679 162 US'
    assert provider.tracking_number(service='fedex') == '6005 9960 6737'
    assert provider.tracking_number(service='fedex') == '1606 8330 6290 793'
    assert provider.tracking_number(service='ups') == '1ZP78W7P8290899568'
    assert provider.tracking_number(service='ups') == '1Z1G5327E643416390'

# Generated at 2022-06-23 20:30:23.352228
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider() # type: USASpecProvider
    assert usa_spec_provider.tracking_number() is not None
    assert usa_spec_provider.ssn() is not None
    assert usa_spec_provider.personality() is not None

test_USASpecProvider()

# Generated at 2022-06-23 20:30:24.993023
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert type(USASpecProvider()._random) == random.Random


# Generated at 2022-06-23 20:30:33.606741
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider(seed=0).ssn() == '227-56-3685'
    assert USASpecProvider(seed=0).tracking_number() == '5854 9061 2800 2340 7753'
    assert USASpecProvider(seed=0).tracking_number(service='UPS') == '1Z42747W4070909196'
    assert USASpecProvider(seed=0).tracking_number(service='FedEx') == '6677 2880 1128'
    assert USASpecProvider(seed=0).personality(category='Rheti') == 4
    assert USASpecProvider(seed=0).personality() == 'INFJ'

# The following code block is used to output the unit test results to the console.
if __name__ == '__main__':
    test_USASpecProvider()

# Generated at 2022-06-23 20:30:41.922660
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa = USASpecProvider()
    resultado = usa.personality('mbti')
    assert type(resultado) is str
    assert len(resultado) == 4
    assert resultado in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    resultado = usa.personality('rheti')
    assert type(resultado) is int
    assert resultado > 0
    assert resultado < 11

# Generated at 2022-06-23 20:30:49.566735
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    import re
    from mimesis.enums import Gender
    from mimesis.providers.en_US import EnUsSpecProvider
    from mimesis.providers.en_US import USASpecProvider
    pattern = re.compile(r'\d{3}-\d{2}-\d{4}')
    is_valid_ssn = lambda s: bool(pattern.match(s))
    usa_spec_provider = USASpecProvider(seed=42)
    en_us_spec_provider = EnUsSpecProvider(seed=42)
    ssn_result_1 = usa_spec_provider.ssn()
    assert is_valid_ssn(ssn_result_1)
    assert ssn_result_1 == '682-45-0288'
    ssn_result

# Generated at 2022-06-23 20:30:56.654160
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality(category='mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    )
    assert provider.personality(category='rheti') in range(1, 11)

# Generated at 2022-06-23 20:31:02.134842
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
  usa = USASpecProvider()
  # ISFJ
  assert str(usa.personality(category='mbti')) == 'ISFJ'
  # 1-10
  assert int(usa.personality(category='rheti')) > 0
  assert int(usa.personality(category='rheti')) <= 10
  # Assertion error
  assert usa.personality(category='mbti') != 'INFJ'

# Generated at 2022-06-23 20:31:06.376337
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usas = USASpecProvider()
    assert type(usas.personality(category='mbti')) == str
    assert type(usas.personality(category='rheti')) == int


# Generated at 2022-06-23 20:31:09.019813
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    a = USASpecProvider()
    i = 0
    while (i <= 10):
        ssn = a.ssn()
        assert isinstance(ssn, str)
        i += 1


# Generated at 2022-06-23 20:31:14.446616
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.provider == 'en'
"""if __name__ == '__main__':
    from mimesis.builtins import USASpecProvider
    usa = USASpecProvider()
    print(usa.tracking_number())
    print(usa.ssn())
    print(usa.personality())"""

# Generated at 2022-06-23 20:31:16.242476
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    obj = USASpecProvider()
    assert obj.tracking_number() in ['USPS', 'FedEx', 'UPS']


# Generated at 2022-06-23 20:31:20.921072
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_provider = USASpecProvider()
    tracking_number = us_provider.tracking_number()
    assert isinstance(tracking_number, str)
    assert len(tracking_number) > 0


# Generated at 2022-06-23 20:31:27.622781
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tracker = USASpecProvider(seed=314)

    # USPS
    for _ in range(0,1000):
        assert len(tracker.tracking_number('usps')) == 22
        assert not tracker.tracking_number('usps').startswith('@@ ')

    # FedEx
    for _ in range(0,1000):
        assert len(tracker.tracking_number('fedex')) == 12 or len(tracker.tracking_number('fedex')) == 15

    # UPS
    assert len(tracker.tracking_number('ups')) == 18
    assert tracker.tracking_number('ups').startswith('1Z@')


# Generated at 2022-06-23 20:31:39.110749
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    USASpecProvider = USASpecProvider()

    # test for method tracking_number of class USASpecProvider
    res = USASpecProvider.tracking_number()
    assert len(res) > 0
    assert USASpecProvider.tracking_number() != USASpecProvider.tracking_number()

    # test for method ssn of class USASpecProvider
    res = USASpecProvider.ssn()
    assert len(res) == 11
    assert res[3] == '-'
    assert res[6] == '-'
    assert res[0:3].isdigit()
    assert res[4:6].isdigit()
    assert res[7:].isdigit()
    assert USASpecProvider.ssn() != USASpecProvider.ssn()

    # test for method personality of class USASpecProvider
    res

# Generated at 2022-06-23 20:31:40.734990
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    spec = USASpecProvider()
    res = spec.tracking_number()
    print(res)


# Generated at 2022-06-23 20:31:43.756773
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider"""
    usa_spec_provider = USASpecProvider()

    assert usa_spec_provider.provider == 'usa_provider'
    assert usa_spec_provider.locale == 'en'


# Generated at 2022-06-23 20:31:46.011282
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert isinstance(USASpecProvider().ssn(), str)
    assert not len(USASpecProvider().ssn()) == 0


# Generated at 2022-06-23 20:31:49.312456
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # GIVEN
    provider = USASpecProvider()
    # WHEN
    result = provider.tracking_number()
    # THEN
    assert result


# Generated at 2022-06-23 20:31:56.009789
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    ussp = USASpecProvider()
    assert ussp.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP',
                                   'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                   'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert ussp.personality('rheti') in range(1, 10)

# Generated at 2022-06-23 20:32:01.370889
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Create USASpecProvider object with no args
    spec1 = USASpecProvider()
    # Check if generated SSN is valid
    # Format: ###-##-####
    # Since 3rd digit has specified range, there is chance of getting a wrong SSN
    assert (len(spec1.ssn()) == 11) and ('-' in spec1.ssn()) and ('#' not in spec1.ssn())


# Generated at 2022-06-23 20:32:03.730038
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    a = USASpecProvider()
    # print(a.ssn())
    assert a.ssn() != a.ssn()




# Generated at 2022-06-23 20:32:08.471983
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """."""
    usa = USASpecProvider()
    usa.random.seed(seed=42)

    assert usa.tracking_number('fedex') == '5770 7082 3025' # noqa



# Generated at 2022-06-23 20:32:14.725920
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider()
    assert p.personality(category="mbti") in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                              'ISTP', 'ISFP', 'INFP', 'INTP',
                                              'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                              'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert p.personality(category="mbti") == 'ISFJ'

# Generated at 2022-06-23 20:32:16.011316
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usp = USASpecProvider()
    assert usp.pid == 'seed'
    assert usp.pid != 'no_seed'


# Generated at 2022-06-23 20:32:19.537861
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    a = USASpecProvider()
    assert isinstance(a.personality(), str)
    assert isinstance(a.personality('mbti'), str)
    assert isinstance(a.personality('rheti'), int)


# Generated at 2022-06-23 20:32:20.509584
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    u = USASpecProvider



# Generated at 2022-06-23 20:32:21.991675
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() != 'UNDEFINED'

# Generated at 2022-06-23 20:32:24.781512
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    import re

    provider = USASpecProvider()
    ssn = provider.ssn()
    assert re.match(r'\d{3}-\d{2}-\d{4}', ssn)

# Generated at 2022-06-23 20:32:32.404630
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()

    # Assertions
    assert len(provider.tracking_number()) > 0
    service = provider.random.choice(('usps', 'fedex', 'ups'))
    assert len(provider.tracking_number(service)) > 0
    assert len(provider.tracking_number(service)) > 0
    assert provider.tracking_number('ups')[0] == '1'
    assert provider.tracking_number('usps')[-2:] == 'US'


# Generated at 2022-06-23 20:32:39.197707
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking_number = provider.tracking_number()
    assert len(tracking_number) == 9
    tracking_number = provider.tracking_number('usps')
    assert len(tracking_number) == 16
    tracking_number = provider.tracking_number('FedEx')
    assert len(tracking_number) == 12
    tracking_number = provider.tracking_number('UPS')
    assert len(tracking_number) == 18


# Generated at 2022-06-23 20:32:42.849291
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Test for length of SSN
    usa = USASpecProvider()
    assert len(usa.ssn()) == 11
    assert len(usa.ssn()) == 11


# Generated at 2022-06-23 20:32:49.092722
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality('mbti') in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ',
    ]
    assert usa_provider.personality('rheti') in range (1, 10)

# Generated at 2022-06-23 20:33:00.179134
# Unit test for method ssn of class USASpecProvider

# Generated at 2022-06-23 20:33:00.715068
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    pass

# Generated at 2022-06-23 20:33:04.014612
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.tracking_number() in ['#### #### #### #### ####', '@@ ### ### ### US']


# Generated at 2022-06-23 20:33:05.045680
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
	pass


# Generated at 2022-06-23 20:33:08.517730
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number() == '2JY 068 313 050 US'
    assert provider.tracking_number(service='fedex') == '6743 7343 057'
    assert provider.tracking_number(service='ups') == '1ZAA27354632980057'


# Generated at 2022-06-23 20:33:11.794801
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert isinstance(test_USASpecProvider_instance.tracking_number(), str)
    assert len(test_USASpecProvider_instance.tracking_number()) > 4


# Generated at 2022-06-23 20:33:16.537035
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityCategory
    from mimesis.providers.usa import USASpecProvider

    usa_spec = USASpecProvider()
    for _ in range(10):
        usa_spec.personality(PersonalityCategory.MBTI)
    for _ in range(10):
        usa_spec.personality(PersonalityCategory.RHETI)

# Generated at 2022-06-23 20:33:22.963704
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()

    usps_number = us.tracking_number('USPS')
    assert usps_number.startswith('0') or usps_number.startswith('1')
    assert len(usps_number) == 22

    fedex_number = us.tracking_number('FedEx')
    assert len(fedex_number) == 12 or len(fedex_number) == 15

    ups_number = us.tracking_number('UPS')
    assert ups_number.startswith('1Z')
    assert len(ups_number) == 18


# Generated at 2022-06-23 20:33:32.840680
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    
    ssn = USASpecProvider().ssn()
    assert len(ssn) == 11 and ssn[:1].isdigit() and ssn[2:3].isdigit() and ssn[5:6].isdigit() and ssn[:3].isdigit() and ssn[4:5].isdigit() and ssn[7:8].isdigit() and ssn[:5].isdigit() and ssn[6:7].isdigit() and ssn[9:10].isdigit() and ssn[:7].isdigit() and ssn[8:9].isdigit() and ssn[10:].isdigit()


# Generated at 2022-06-23 20:33:37.324237
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:33:39.149287
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert isinstance(usa_spec_provider, USASpecProvider)


# Generated at 2022-06-23 20:33:42.928826
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    up = USASpecProvider(seed=12345)
    assert up.personality('rheti') == 5
    up = USASpecProvider(seed=12346)
    assert up.personality('rheti') == 10
    assert up.personality('mbti') == 'ESFP'

# Generated at 2022-06-23 20:33:50.342820
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test cases for USASpecProvider class."""
    usa = USASpecProvider()
    ssn = usa.ssn()
    print(ssn)
    assert ssn
    assert isinstance(ssn, str)

    tracking_number = usa.tracking_number('usps')
    print(tracking_number)
    assert tracking_number
    assert isinstance(tracking_number, str)

    personality = usa.personality('rheti')
    print(personality)
    assert isinstance(personality, int)

# Generated at 2022-06-23 20:33:52.439219
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    us.personality()
    us.personality(category='rheti')
    us.personality(category='unknown')

# Generated at 2022-06-23 20:33:54.330190
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test for constructor of class USASpecProvider."""
    us = USASpecProvider()
    assert us != None

# Generated at 2022-06-23 20:33:57.474575
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(provider.personality('rheti'), int)
    assert provider.personality('rheti') in range(1, 11)


# Generated at 2022-06-23 20:34:04.321990
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method USASpecProvider.personality."""
    us_provider = USASpecProvider()
    assert us_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                         'ISTP', 'ISFP', 'INFP', 'INTP',
                                         'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                         'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert 1 <= us_provider.personality(category='rheti') <= 10

# Generated at 2022-06-23 20:34:06.365050
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:34:14.443451
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    usps_result = provider.tracking_number(service="usps") # type: str
    fedex_result = provider.tracking_number(service="fedex") # type: str
    ups_result = provider.tracking_number(service="ups") # type: str
    assert isinstance(usps_result, str)
    assert isinstance(fedex_result, str)
    assert isinstance(ups_result, str)


# Generated at 2022-06-23 20:34:21.151838
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # test constructor of class USASpecProvider
    try:
        spec = USASpecProvider()
        assert(len(spec.ssn()) > 0)
        assert(len(spec.tracking_number()) > 0)
        assert(len(spec.tracking_number()) > 0)
        assert(len(spec.personality('mbti')) > 0)
        assert(type(spec.personality('rheti')) is int)
    except:
        print("test_USASpecProvider failed")


# Generated at 2022-06-23 20:34:23.118893
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() != None


# Generated at 2022-06-23 20:34:25.462335
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    usa_provider1 = USASpecProvider(seed="abcd")

# Generated at 2022-06-23 20:34:27.441854
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_spec = USASpecProvider()
    assert isinstance(us_spec, USASpecProvider)


# Generated at 2022-06-23 20:34:30.369818
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tracker = USASpecProvider()
    for i in range(2, 5):
        assert len(tracker.tracking_number()) == i * 5, "Length should be 5 * i"


# Generated at 2022-06-23 20:34:33.037544
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    obj = USASpecProvider()
    assert len(obj.ssn()) == 11
    assert isinstance(obj.ssn(), str)

# Generated at 2022-06-23 20:34:36.891153
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    try:
        USASpecProvider()
        print("Passed Test: test_USASpecProvider")
    except (Exception) as error:
        print("Failed Test: test_USASpecProvider")
        print(error)
        print()


# Generated at 2022-06-23 20:34:43.837927
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert (1 <= USASpecProvider().personality(category='rheti') <= 10)


# Generated at 2022-06-23 20:34:46.638780
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    ssn = usa_provider.ssn()
    assert ssn not in ('000-00-0000', '666-66-6666')

# Generated at 2022-06-23 20:34:53.581315
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Test method personality on class USASpecProvider
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa.personality('rheti'), int)
    assert 1 <= usa.personality('rheti') <= 10
