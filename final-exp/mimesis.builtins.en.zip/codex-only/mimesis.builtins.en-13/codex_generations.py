

# Generated at 2022-06-23 20:24:56.537665
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    class_name = USASpecProvider.__name__

    assert hasattr(USASpecProvider, 'tracking_number')
    assert callable(getattr(USASpecProvider, 'tracking_number'))
    assert callable(getattr(eval(class_name)(), 'tracking_number'))

    # Test for different services
    assert hasattr(eval(class_name)(), 'tracking_number')
    assert hasattr(eval(class_name)().tracking_number('USPS'), '__call__')
    assert hasattr(eval(class_name)().tracking_number('FedEx'), '__call__')
    assert hasattr(eval(class_name)().tracking_number('UPS'), '__call__')

    # Test for error

# Generated at 2022-06-23 20:25:01.296295
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert USASpecProvider().personality() in mbtis, 'Wrong mbtis'
    assert 0 < USASpecProvider().personality(category='rheti') <= 10, 'Wrong value'



# Generated at 2022-06-23 20:25:06.654053
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    expected_outcomes = ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                         'ISTP', 'ISFP', 'INFP', 'INTP',
                         'ESTP', 'ESFP', 'ENFP', 'ENTP',
                         'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert USASpecProvider().personality(category='mbti') in expected_outcomes
    assert USASpecProvider().personality(category='rheti') <= 10

# Generated at 2022-06-23 20:25:11.600157
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
	assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
	'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
	'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:25:18.261713
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    locale = 'en'
    from mimesis.enums import Gender
    from mimesis.providers.us import USASpecProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    usa = USASpecProvider(locale)
    
    person = Person(locale)
    address = Address(locale)
    
    first_name = person.name(gender = Gender.MALE) 
    middle_name = person.name(gender = Gender.MALE)
    last_name = person.name(gender = Gender.MALE)
    address_full = address.address()
    
    ssn = usa.ssn()
    print(first_name, middle_name, last_name, address_full, ssn)


# Generated at 2022-06-23 20:25:20.130225
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
  assert len(USASpecProvider().ssn()) == 11


# Generated at 2022-06-23 20:25:22.123116
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Unit test for method ssn of class USASpecProvider
    ssn = USASpecProvider().ssn()

    assert 10 < len(ssn) <= 11



# Generated at 2022-06-23 20:25:25.263088
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider.personality('mbti') not in ('', [], (), {})

# Generated at 2022-06-23 20:25:29.488378
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    usps = usa_provider.tracking_number('usps')
    assert len(usps) == 27

    fedex = usa_provider.tracking_number('fedex')
    assert len(fedex) == 17

    ups = usa_provider.tracking_number('ups')
    assert len(ups) == 18

# Generated at 2022-06-23 20:25:33.933345
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_spec_provider = USASpecProvider()
    assert us_spec_provider.provider.Meta.name == 'usa_provider'
    assert type(us_spec_provider).__name__ == 'USASpecProvider'
    assert us_spec_provider.__doc__ is not None


# Generated at 2022-06-23 20:25:35.918037
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.tracking_number()



# Generated at 2022-06-23 20:25:39.155201
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    for _ in range(10):
        tracking_number = USASpecProvider().tracking_number()
        assert(isinstance(tracking_number, str))



# Generated at 2022-06-23 20:25:43.748439
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis import Person
    from mimesis.enums import Gender

    person = Person('en')
    person.seed(10)
    person.gender = Gender.MALE

    usa = USASpecProvider(seed=10)
    assert usa.personality(category="Personality") == 'ISFJ'

# Generated at 2022-06-23 20:25:50.174362
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Tests for USASpecProvider method personality."""
    tmp = USASpecProvider()
    ret = tmp.personality()
    assert ret in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                   'ISTP', 'ISFP', 'INFP', 'INTP',
                   'ESTP', 'ESFP', 'ENFP', 'ENTP',
                   'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ') or isinstance(ret, int)


# Generated at 2022-06-23 20:25:55.498847
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_provider = USASpecProvider()
    # USPS
    assert len(us_provider.tracking_number(service = 'USPS')) > 0
    # UPS
    assert len(us_provider.tracking_number(service = 'UPS')) > 0
    # FedEx
    assert len(us_provider.tracking_number(service = 'FedEx')) > 0
    # False
    assert len(us_provider.tracking_number(service = 'false')) == 0


# Generated at 2022-06-23 20:25:58.948262
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    seed = 0
    provider = USASpecProvider(seed)
    assert provider.spec.name == 'usa_provider'


# Generated at 2022-06-23 20:26:02.411235
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usaspec = USASpecProvider()
    assert usaspec.ssn()
    assert usaspec.tracking_number(service = 'usps')
    assert usaspec.personality(category = 'rheti')
    assert usaspec.personality(category = 'mbti')


# Generated at 2022-06-23 20:26:04.659697
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    up = USASpecProvider()
    up.tracking_number(service='usps')  # (pdb) p up.random.code_list


# Generated at 2022-06-23 20:26:08.238241
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider(seed=42)
    provider.tracking_number(service='USPS')
    provider.tracking_number(service='FedEx')
    provider.tracking_number(service='UPS')
    provider.ssn()
    provider.personality()
    provider.personality('rheti')

# Generated at 2022-06-23 20:26:12.452785
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    import datatest as dt
    provider = USASpecProvider()
    assert dt.validators.is_empty(provider.ssn()) == False
    assert dt.validators.is_empty(provider.ssn()) == False
    assert dt.validators.is_empty(provider.ssn()) == False
    assert dt.validators.is_empty(provider.ssn()) == False
    assert dt.validators.is_empty(provider.ssn()) == False


# Generated at 2022-06-23 20:26:15.244571
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # ISFJ personality
    assert USASpecProvider().ssn() == '569-66-5801'


# Generated at 2022-06-23 20:26:20.707263
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_personality = USASpecProvider()
    assert usa_personality.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                             'ISTP', 'ISFP', 'INFP', 'INTP',
                                             'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:26:27.970559
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert type(usa_provider.personality()) == str
    assert (usa_provider.personality() in
            ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'))
    assert type(usa_provider.personality('rheti')) == int
    assert usa_provider.personality('rheti') in range(1, 11)

# Generated at 2022-06-23 20:26:29.009796
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    print(USASpecProvider().personality())


# Generated at 2022-06-23 20:26:30.067322
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    UsaSpecProvider = USASpecProvider()
    print(UsaSpecProvider.personality())

# Generated at 2022-06-23 20:26:32.288537
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()

    assert provider.random
    assert provider._data



# Generated at 2022-06-23 20:26:42.891479
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider_ssn = USASpecProvider()
    for ssn in range(0,10):
        s = provider_ssn.ssn()
        # Assert that the social security number is a string
        assert type(s) == str
        assert len(s) == 11
        assert s[0].isdigit() and s[1].isdigit() and s[2].isdigit()
        assert s[3] == '-'
        assert s[4].isdigit() and s[5].isdigit()
        assert s[6] == '-'
        assert s[7].isdigit() and s[8].isdigit() and s[9].isdigit() and s[10].isdigit()


# Generated at 2022-06-23 20:26:49.546055
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from random import seed
    from mimesis.data import USAData

    usdata = USAData()
    seed(4000)
    usspecprovider = usdata.us_spec_provider

    # mbti
    assert usspecprovider.personality('mbti') == 'ISTP'

    # rheti
    assert usspecprovider.personality('rheti') == 4

    # Invalid category
    assert usspecprovider.personality('123') == 'ISFJ'

# Generated at 2022-06-23 20:26:52.978642
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider"""
    usa_provider = USASpecProvider()
    result = usa_provider.tracking_number()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 20:27:04.641892
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test tracking_number function of USASpecProvider"""
    data = []
    provider = USASpecProvider()
    for i in range(0, 5):
        usps_tracking_number, usps_format = provider.tracking_number(service='usps')
        fedex_tracking_number, fedex_format = provider.tracking_number(service='fedex')
        ups_tracking_number, ups_format = provider.tracking_number(service='ups')
        data.append((usps_tracking_number, usps_format))
        data.append((fedex_tracking_number, fedex_format))
        data.append((ups_tracking_number, ups_format))

    assert len(data) == 15
    assert all([len(tup) == 2 for tup in data])


# Generated at 2022-06-23 20:27:07.719909
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    testing = USASpecProvider()
    assert testing.tracking_number(service = 'usps')
    assert testing.tracking_number(service = 'fedex')
    assert testing.tracking_number(service = 'ups')

# Generated at 2022-06-23 20:27:10.808557
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    usa_spec_provider.personality()


# Generated at 2022-06-23 20:27:12.631694
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    assert us.__init__() != None


# Generated at 2022-06-23 20:27:16.965306
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from src.mimesis import USASpecProvider

    with open('../../tests/records/spec/tracking_number.json', 'r', encoding="utf-8") as f:
        data = json.loads(f.read())
        for i in data:
            assert USASpecProvider().tracking_number(i) in data[i]


# Generated at 2022-06-23 20:27:19.602132
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider= USASpecProvider()
    assert provider.__class__.__name__=='USASpecProvider'


# Generated at 2022-06-23 20:27:23.694179
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider which generates U.S. Soc. Sec. No.

    Supported services: USPS, FedEx and UPS.
    :return:
    """

    usa_spec_provider_instance = USASpecProvider()
    ssn = usa_spec_provider_instance.ssn()
    #print("ssn =", ssn)

    # TODO: assert

# Generated at 2022-06-23 20:27:31.105512
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    print("Test method personality of class USASpecProvider")
    assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert USASpecProvider().personality("rheti") in range(1, 10)

# Generated at 2022-06-23 20:27:40.920556
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # There are 2 possibilities: 1) return mbtis or 2) return 10 types
    # that declared in "rheti" category.
    # So, the probability of return each type is 1/2 * 1/16 = 1/32
    # 16 types
    mbti = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    # 10 types
    rheti = [0,0,0,0,0,0,0,0,0,0,0]
    for i in range(1000):
        mbti_temp = USASpecProvider().personality()
        rheti_temp = USASpecProvider().personality('rheti')

# Generated at 2022-06-23 20:27:44.821330
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usp = USASpecProvider()
    assert usp.tracking_number('ups') == '1Z83A972X326515589'
    assert usp.tracking_number('fedex') == '2089 6574 2109'
    assert usp.tracking_number('usps') == 'EL 147 844 US'


# Generated at 2022-06-23 20:27:55.212979
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method tracking_number of class USASpecProvider."""

    test_US_tracking_number = USASpecProvider()
    assert test_US_tracking_number.tracking_number(service='usps')
    assert test_US_tracking_number.tracking_number(service='fedex')
    assert test_US_tracking_number.tracking_number(service='ups')
    assert test_US_tracking_number.tracking_number(service='usps')
    assert test_US_tracking_number.tracking_number(service='fedex')
    assert test_US_tracking_number.tracking_number(service='ups')
    assert test_US_tracking_number.tracking_number(service='usps')
    assert test_US_tracking_number.tracking_number(service='fedex')

# Generated at 2022-06-23 20:27:57.010076
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert isinstance(ssn, str)
    assert len(ssn) == 11



# Generated at 2022-06-23 20:28:00.207352
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    test_tracking_number = usa_spec_provider.tracking_number()

    assert test_tracking_number != None


# Generated at 2022-06-23 20:28:03.703582
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    result = provider.ssn()
    assert provider.validate_ssn(result) == True



# Generated at 2022-06-23 20:28:11.570286
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn(): # unit test for method ssn of class USASpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.us import USASpecProvider
    from mimesis.types import Datetime
    from datetime import datetime, timedelta
    from mimesis.enums import Gender

    usa = USASpecProvider()
    x = [usa.ssn() for _ in range(10)]
    assert x[0] == '277-31-5366'
    assert x[1] == '972-77-6014'
    assert x[2] == '689-13-6468'
    assert x[3] == '072-71-3175'


# Generated at 2022-06-23 20:28:16.532739
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    usps = usa.tracking_number()
    fedex = usa.tracking_number('fedex')
    ups = usa.tracking_number('ups')
    assert len(usps) == 22
    assert len(ups) == 18
    assert len(fedex) == 13 or len(fedex) == 14

# Generated at 2022-06-23 20:28:18.243571
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    print(usa.tracking_number())


# Generated at 2022-06-23 20:28:19.182507
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert isinstance(USASpecProvider.personality, str)


# Generated at 2022-06-23 20:28:21.012150
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """test ssn function"""
    provider = USASpecProvider()
    assert len(provider.ssn()) == 11

# Generated at 2022-06-23 20:28:21.474866
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    USASpecProvider().tracking_number()

# Generated at 2022-06-23 20:28:22.970670
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    result = '569-66-5801'
    assert result == USASpecProvider().ssn()


# Generated at 2022-06-23 20:28:26.040585
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test if the method ssn of class USASpecProvider works fine."""
    some_ssn = USASpecProvider().ssn()
    assert some_ssn[3] == '-' and some_ssn[6] == '-'
    assert len(some_ssn) == 11


# Generated at 2022-06-23 20:28:33.025638
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    usp = USASpecProvider()

    # Generate a USPS tracking number
    print(usp.tracking_number(service='usps'))

    # Generate a FedEx tracking number
    print(usp.tracking_number(service='fedex'))

    # Generate a UPS tracking number
    print(usp.tracking_number(service='ups'))


# Generated at 2022-06-23 20:28:40.927754
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    up = USASpecProvider()

    assert up.personality('rheti') in range(1, 10)

    assert up.personality('mbti') in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ',
    ]


# Generated at 2022-06-23 20:28:44.822507
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for class USASpecProvider."""
    usa = USASpecProvider()
    assert usa.provider == 'usa_provider'
    assert usa.locale == 'en'


# Generated at 2022-06-23 20:28:47.855934
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    instances = [USASpecProvider().ssn() for _ in range(11)]
    assert len(instances) == 11
    assert all([len(i) == 11 for i in instances])
    assert '-' in instances[0]


# Generated at 2022-06-23 20:28:52.370366
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityType
    from mimesis.providers.person import Person

    # MBTI
    provider = USASpecProvider()
    for i in range(100):
        assert provider.personality() in PersonalityType.MBTI

    # RHETI
    person = Person(USASpecProvider())
    for i in range(100):
        assert 1 <= person.personality(category='rheti') <= 10



# Generated at 2022-06-23 20:29:00.453996
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Create a provider for testing
    provider = USASpecProvider()
    # Testing of mbti personality
    type1 = provider.personality()
    assert type1 in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    # Testing of Rheti personality
    type2 = provider.personality('rheti')
    assert type2 >= 1 and type2 <= 10

# Generated at 2022-06-23 20:29:03.428782
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    def run():
        assert len(USASpecProvider().ssn()) == 11

    run()

# Generated at 2022-06-23 20:29:06.011812
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number()


# Generated at 2022-06-23 20:29:09.744624
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider """
    usp = USASpecProvider()
    
    assert len(usp.tracking_number()) > 0
    assert usp.tracking_number()[0:2] == '1Z'


# Generated at 2022-06-23 20:29:19.380243
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # These tests can't be run in CircleCI due to the following error:
    # AttributeError: module 'mimesis.providers.address' has no attribute 'BaseAddressProvider'
    us = USASpecProvider()
    ssn = us.ssn()
    assert len(ssn) == 11
    for i in range(0, len(ssn) - 1):
        if i == 3 or i == 6:
            assert ssn[i] == '-'
        else:
            assert ssn[i].isdigit()

if __name__ == '__main__':
    test_USASpecProvider_ssn()

# Generated at 2022-06-23 20:29:22.000004
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    assert isinstance(USASpecProvider().tracking_number(), str)


# Generated at 2022-06-23 20:29:25.262725
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityCategory
    p = PersonalityCategory.MBTI
    r = USASpecProvider.personality(p)
    assert r in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:29:32.451242
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.enums import USPS, FedEx, UPS
    import re

    provider = USASpecProvider()
    tracking = provider.tracking_number()

    assert tracking is not None

    assert re.match('^\d{4} \d{4} \d{4}$', tracking)

    assert provider.tracking_number(USPS) is not None
    assert provider.tracking_number(FedEx) is not None
    assert provider.tracking_number(UPS) is not None

    assert provider.tracking_number('UPS') is not None

    try:
        provider.tracking_number('DHL')
    except ValueError:
        pass

    assert provider.tracking_number('usps') is not None
    assert provider.tracking_number('fedex') is not None
    assert provider.tracking_number('ups') is not None

# Generated at 2022-06-23 20:29:34.050499
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    print(provider.tracking_number())

# Generated at 2022-06-23 20:29:35.106253
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # USASpecProvider
    USASpecProvider()

# Generated at 2022-06-23 20:29:36.860706
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    x = USASpecProvider()
    y = x.ssn()
    print(y)


# Generated at 2022-06-23 20:29:38.861362
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider(seed=100)
    assert usa_provider.ssn() == '421-04-3975'

# Generated at 2022-06-23 20:29:45.379636
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test of class USASpecProvider"""
    assert USASpecProvider().usaspec.tracking_number() == '1ZV495R90393306776'
    assert USASpecProvider(seed=1234).usaspec.tracking_number() == '1ZV495R90393306776'
    assert USASpecProvider().usaspec.tracking_number('fedex') == '1425 7191 6231 510'
    assert USASpecProvider().usaspec.ssn() == '824-66-2188'
    assert USASpecProvider().usaspec.personality() == 'INTP'
    assert USASpecProvider().usaspec.personality('rheti') == 5

# Generated at 2022-06-23 20:29:47.624278
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    p = USASpecProvider()
    ssn = p.ssn()
    assert len(ssn) == 11

# Generated at 2022-06-23 20:29:51.642923
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    spec_provider = USASpecProvider()
    assert len(spec_provider.ssn()) == 11
    assert spec_provider.ssn()[3] == '-'
    assert spec_provider.ssn()[6] == '-'


# Generated at 2022-06-23 20:29:59.900427
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    print("\nUnit testing method tracking_number of class USASpecProvider")
    print("  USPS tracking number: %s" % usa_spec_provider.tracking_number(service="usps"))
    print("  FedEx tracking number: %s" % usa_spec_provider.tracking_number(service="fedex"))
    print("  UPS tracking number: %s" % usa_spec_provider.tracking_number(service="ups"))


# Generated at 2022-06-23 20:30:01.012520
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    try:
        a = USASpecProvider()
        assert a
    except Exception:
        assert False


# Generated at 2022-06-23 20:30:02.862731
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider()

#Unit test for method personality of class USASpecProvider

# Generated at 2022-06-23 20:30:09.071609
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                       'ISTP', 'ISFP', 'INFP', 'INTP',
                                       'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                       'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

    assert 1 <= provider.personality(category='Rheti') <= 10
    assert 1 <= provider.personality(category='rheti') <= 10

# Generated at 2022-06-23 20:30:11.836082
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert isinstance(provider, BaseSpecProvider)
    assert provider.__class__.__name__ == "USASpecProvider"
    assert provider.__class__.__module__ == "mimesis.builtins.en.USASpecProvider"


# Generated at 2022-06-23 20:30:16.810671
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    import re
    import unittest.mock as mock
    ssn = USASpecProvider().ssn()
    r = re.compile(r'\d\d\d-\d\d-\d\d\d\d')
    assert r.match(ssn)

# Generated at 2022-06-23 20:30:20.467369
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    print(provider.personality('rheti'))

if __name__ == "__main__":
    test_USASpecProvider_personality()

# Generated at 2022-06-23 20:30:23.034207
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test personality."""
    assert USASpecProvider().personality() == 1 or 16 or 'IS' or 'ISF' or 'ISFJ'

# Generated at 2022-06-23 20:30:30.301983
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider(seed=12345)
    mbti = us.personality()
    assert mbti in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                    'ISTP', 'ISFP', 'INFP', 'INTP',
                    'ESTP', 'ESFP', 'ENFP', 'ENTP',
                    'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert us.personality('rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-23 20:30:34.451219
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()

    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'


# Generated at 2022-06-23 20:30:39.510070
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.random
    assert provider.seed
    assert provider.__doc__
    assert provider.__init__.__doc__
    assert provider.tracking_number.__doc__
    assert provider.ssn.__doc__
    assert provider.personality.__doc__


# Generated at 2022-06-23 20:30:41.684417
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_spec_provider = USASpecProvider()
    string = usa_spec_provider.ssn()


# Generated at 2022-06-23 20:30:45.812974
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert isinstance(USASpecProvider(), USASpecProvider)
    assert issubclass(USASpecProvider, BaseSpecProvider)
    assert hasattr(USASpecProvider, 'ssn')
    assert hasattr(USASpecProvider, 'Meta')
    assert USASpecProvider.Meta.name == 'usa_provider'


# Generated at 2022-06-23 20:30:49.772652
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
	usaspecprovider = USASpecProvider()

	# 1. Test if the method returns an instance of str object
	assert isinstance(usaspecprovider.personality(), str)
	# 2. Test if the method returns an instance of str object
	assert isinstance(usaspecprovider.personality(category='rheti'), int)
	# 3. Test if the method returns a non-empty string
	assert len(usaspecprovider.personality()) > 0


# Generated at 2022-06-23 20:30:52.431027
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_data = USASpecProvider()

    assert us_data.__class__.__name__ == "USASpecProvider"


# Generated at 2022-06-23 20:30:54.486440
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    for i in range(10):
        print(USASpecProvider().tracking_number('fedex'))

# Generated at 2022-06-23 20:30:58.615201
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality('rheti') in range(1, 10)
    assert USASpecProvider().personality() in ("ISFJ", "ISTJ", "INFJ", "INTJ", "ISTP", "ISFP", "INFP", "INTP",
                                               "ESTP", "ESFP", "ENFP", "ENTP", "ESTJ", "ESFJ", "ENFJ", "ENTJ")

# Generated at 2022-06-23 20:30:59.529184
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider is not None


# Generated at 2022-06-23 20:31:01.056698
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    usp = USASpecProvider()
    print(usp.ssn())



# Generated at 2022-06-23 20:31:07.536507
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider(seed=1)
    assert provider.ssn() == "233-99-3481"

    # Unit test for method ssn of class USASpecProvider
    def test2_USASpecProvider_ssn():
        provider = USASpecProvider(seed=2)
        assert provider.ssn() == "934-14-9353"



# Generated at 2022-06-23 20:31:08.566073
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert 9 == len(provider.ssn())

# Generated at 2022-06-23 20:31:12.027456
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    assert usa_provider.ssn() != '134-00-3539'

# Generated at 2022-06-23 20:31:16.812996
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in \
        ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:31:23.050791
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a = USASpecProvider()
    test1 = a.tracking_number(service='usps')
    test2 = a.tracking_number(service='ups')
    test3 = a.tracking_number(service='fedex')

    assert isinstance(test1, str)
    assert isinstance(test2, str)
    assert isinstance(test3, str)



# Generated at 2022-06-23 20:31:27.072814
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """This is a unit test for method personality of class USASpecProvider."""
    from mimesis.enums import MBTI
    from mimesis.providers.us_spec import USASpecProvider
    usas = USASpecProvider()
    for i in range(0, 10):
        assert usas.personality() in MBTI.to_list()

# Generated at 2022-06-23 20:31:30.708654
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test constructor and attributes of class USASpecProvider."""
    usa = USASpecProvider()
    assert hasattr(usa, 'random')
    assert hasattr(usa, 'generate')

# Generated at 2022-06-23 20:31:40.047766
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    expected_results = {
        'USPS': (
            '0123 456 7891 2345 6789',
            'XX 123 456 123 US',
        ),
        'FedEx': (
            '1234 5678 9012',
            '1234 5678 9012 345',
        ),
        'UPS': (
            '1ZAW23S67890123456',
        ),
    }
    for serv in expected_results:
        for pattern in expected_results[serv]:
            result = USASpecProvider().tracking_number(service=serv)
            assert result != pattern
            assert len(result) == len(pattern)


# Generated at 2022-06-23 20:31:42.573787
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a= USASpecProvider().tracking_number('usps')
    assert len(a) == 26
    b= USASpecProvider().tracking_number('fedex')
    assert len(b) == len(a)
    c= USASpecProvider().tracking_number('ups')
    assert len(c) == len(b)


# Generated at 2022-06-23 20:31:49.616896
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert USASpecProvider().personality(category = 'rheti') in list(range(1, 11))

# Generated at 2022-06-23 20:32:00.096892
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usaspecp = USASpecProvider()
    usaspecp.seed(2151)
    assert usaspecp.tracking_number() == '8Z00 0E99 8034 0046 2467'
    assert usaspecp.tracking_number() == '1Z73 9A99 4046 3840 4351'
    assert usaspecp.tracking_number() == '1Z34 1361 0647 7355 4609'
    assert usaspecp.tracking_number() == '7M21 4168 7183 82'
    assert usaspecp.tracking_number() == '4898 4400 3466 6894'
    assert usaspecp.tracking_number() == '6316 3769 8451 7180'
    assert usaspecp.tracking_number() == '9400 1179 0662 14'
    assert us

# Generated at 2022-06-23 20:32:01.584044
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa is not None


# Generated at 2022-06-23 20:32:09.518636
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    result = USASpecProvider().ssn()
    assert len(result) == 11
    assert isinstance(result, str)
    assert USASpecProvider().ssn() != USASpecProvider().ssn()
    assert result[:3].isdigit()
    assert result[4:6].isdigit()
    assert result[7:11].isdigit()
    assert result[3] == '-'
    assert result[6] == '-'



# Generated at 2022-06-23 20:32:13.255486
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    u = USASpecProvider()
    s = u.ssn()

    assert len(s) == 11
    assert s.count('-') == 2
    assert s[0:3].isdigit()
    assert s[4:6].isdigit()
    assert s[7:11].isdigit()

    assert s[3] == '-'
    assert s[6] == '-'

    assert int(s[0:3]) < 900
    assert int(s[0:3]) != 666

    assert int(s[4:6]) < 100
    assert int(s[7:11]) < 10000


# Generated at 2022-06-23 20:32:16.757887
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    ssn = usa_provider.ssn()
    assert len(ssn) == 11
    assert ssn.startswith('666') == False

# Generated at 2022-06-23 20:32:20.322202
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number(service='usps')
    assert usa.tracking_number(service='FedEx')
    assert usa.tracking_number(service='UPS')



# Generated at 2022-06-23 20:32:24.821768
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """
    Test docstring for method personality of class USASpecProvider
    """
    _ = USASpecProvider()
    print(_.personality())
    print(_.personality())
    print(_.personality(category='rheti'))
    print(_.personality(category='rheti'))
    print(_.personality())

# Generated at 2022-06-23 20:32:26.041598
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    USASpecProvider()


# Generated at 2022-06-23 20:32:28.667049
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == "964-41-8609"

# Generated at 2022-06-23 20:32:30.319817
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider."""
    assert USASpecProvider() is not None

# Generated at 2022-06-23 20:32:34.122015
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for tracking_number."""
    provider = USASpecProvider()
    tracking_number = provider.tracking_number()
    assert tracking_number
    assert type(tracking_number) == str
    assert len(tracking_number) != 0


# Generated at 2022-06-23 20:32:40.048912
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    ssn = usa_provider.ssn()
    area = int(ssn.split("-")[0])
    assert ssn is not None
    assert (area > 0 and area < 900)
    assert len(ssn.split("-")[1]) == 2
    assert len(ssn.split("-")[2]) == 4


# Generated at 2022-06-23 20:32:46.116700
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usasp = USASpecProvider()
    assert USASpecProvider.Meta.name == 'usa_provider'
    assert isinstance(usasp, USASpecProvider)
    assert isinstance(usasp, BaseSpecProvider)
    assert hasattr(usasp, 'random')
    assert hasattr(usasp, 'seed')
    assert hasattr(usasp, 'provider')



# Generated at 2022-06-23 20:32:53.778959
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider(seed=8).tracking_number('usps') == 'SBTC BUQQ 2673 6510'
    assert USASpecProvider(seed=51).tracking_number('usps') == 'PVOG ANHJ 1595 3734'
    assert USASpecProvider(seed=66).tracking_number('usps') == 'JLQG RQIC 7595 8754'
    assert USASpecProvider(seed=8).tracking_number('fedex') == '8300 5895'
    assert USASpecProvider(seed=51).tracking_number('fedex') == '5513 7741'
    assert USASpecProvider(seed=66).tracking_number('fedex') == '6450 2351'

# Generated at 2022-06-23 20:32:55.446294
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    assert us.random.seed != None


# Generated at 2022-06-23 20:33:05.681831
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis import USASpecProvider
    from mimesis.exceptions import NonEnumerableError

    # Create a list for testing.
    list_ssn = []
    # Create an instance of USASpecProvider and fill the list.
    usa = USASpecProvider()
    for i in range(100):
        list_ssn.append(usa.ssn())

    # Check that all elements of the list are unique.
    assert len(set(list_ssn)) == 100

    # Check that all elements of the list begin with 0.
    for i in list_ssn:
        assert i.startswith('0') == False

    with USASpecProvider() as usa:
        # Check that the method does not return strings with an empty string.
        assert usa.ssn() == ''

        # Check that the

# Generated at 2022-06-23 20:33:07.407124
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() == '868-20-9779'



# Generated at 2022-06-23 20:33:17.506480
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number('usps') != None
    assert usa_provider.tracking_number('usps') != None
    assert usa_provider.tracking_number('usps') != None
    assert usa_provider.tracking_number('fedex') != None
    assert usa_provider.tracking_number('fedex') != None
    assert usa_provider.tracking_number('fedex') != None
    assert usa_provider.tracking_number('ups') != None
    assert usa_provider.tracking_number('ups') != None
    assert usa_provider.tracking_number('ups') != None


# Generated at 2022-06-23 20:33:24.174392
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert type(provider.personality(category='rheti')) is int

# Generated at 2022-06-23 20:33:25.313679
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
  usa = USASpecProvider()
  assert isinstance(usa, USASpecProvider)


# Generated at 2022-06-23 20:33:27.788865
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert(isinstance(usa_provider, USASpecProvider))


# Generated at 2022-06-23 20:33:29.453458
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number()


# Generated at 2022-06-23 20:33:33.845724
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert USASpecProvider.Meta.name == 'usa_provider'
    assert isinstance(usa.ssn(), str)
    assert isinstance(usa.tracking_number(), str)
    assert isinstance(usa.personality(), str)


# Generated at 2022-06-23 20:33:36.210781
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Return success in creating an object of USA Spec Provider."""
    usa = USASpecProvider()
    assert usa.us == "US"
    assert usa.code == "en-US"


# Generated at 2022-06-23 20:33:42.991499
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Docstring for test_USASpecProvider_personality."""
    usas = USASpecProvider()
    personality = usas.personality()
    assert personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'), 'Personality type must be a str in the list [ISFJ, ISTJ, INFJ, INTJ, ISTP, ISFP, INFP, INTP, ESTP, ESFP, ENFP, ENTP, ESTJ, ESFJ, ENFJ, ENTJ]'


# Generated at 2022-06-23 20:33:47.995460
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    from mimesis.providers.usa.usa_provider import USASpecProvider
    usa = USASpecProvider()
    ssn = usa.ssn()
    assert len(ssn) == 11


# Generated at 2022-06-23 20:33:50.016135
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert isinstance(usa.tracking_number('usps'), str)


# Generated at 2022-06-23 20:33:51.157968
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    usa.__init__()


# Generated at 2022-06-23 20:34:01.474903
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    personality = usa_spec_provider.personality()
    assert isinstance(personality, str), 'Not string'
    assert personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                           'ISTP', 'ISFP', 'INFP', 'INTP',
                           'ESTP', 'ESFP', 'ENFP', 'ENTP',
                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'), 'Bad'
    personality = usa_spec_provider.personality(category='rheti')
    assert isinstance(personality, int), 'Not integer'
    assert personality in range(1, 11), 'Bad'


# Generated at 2022-06-23 20:34:02.741177
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Arrange:
    # Act:
    # Assert:
    assert USASpecProvider(seed=2345)

# Generated at 2022-06-23 20:34:04.283709
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_provider = USASpecProvider()
    assert us_provider is not None


# Generated at 2022-06-23 20:34:05.976823
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    for p in range(10):
        tracker_number = USASpecProvider().tracking_number()
        assert tracker_number is not None


# Generated at 2022-06-23 20:34:10.186017
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa = USASpecProvider()
    assert isinstance(usa.personality(), str) or isinstance(usa.personality(), int)


# Generated at 2022-06-23 20:34:14.650282
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    seed = "123e4567-e89b-12d3-a456-426655440000"
    usa = USASpecProvider(seed)
    assert usa.tracking_number() == '2227 1375 0666 1359 4586'


# Generated at 2022-06-23 20:34:19.054349
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    for i in range(0, 20):
        ssn = provider.ssn()
        print(ssn)
        assert len(ssn)==11
        assert (ssn[0:3] != '666')


# Generated at 2022-06-23 20:34:24.093200
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method tracking_number of class USASpecProvider."""
    service = 'usps'
    assert len(USASpecProvider().tracking_number(service)) == 22
    service = 'fedex'
    assert (
        len(USASpecProvider().tracking_number(service))
        in (12, 15)
    )
    service = 'ups'
    assert len(USASpecProvider().tracking_number(service)) == 18
    service = 'sss'
    assert USASpecProvider().tracking_number(service) == ''



# Generated at 2022-06-23 20:34:33.880849
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for method USASpecProvider.tracking_number()."""
    provider = USASpecProvider()

    # Тестируем USPS
    usps_num = provider.tracking_number(service='USPS')
    if not (usps_num.startswith('94') or \
            usps_num.startswith('92') or \
            usps_num.startswith('90')) or \
            len(usps_num) != 22:
        raise AssertionError("Неправильный формат номера отслеживания USPS.")

    # Тестируем FedEx

# Generated at 2022-06-23 20:34:36.771766
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider(seed=42)
    ssn = provider.ssn()
    assert ssn == '863-40-0122'


# Generated at 2022-06-23 20:34:39.575144
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Ensure that the personality method works properly."""
    us = USASpecProvider()
    assert us.personality().isalpha()
    assert us.personality('rheti').isdigit()


# Generated at 2022-06-23 20:34:42.530883
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():

    provider = USASpecProvider()

    # Checking if the output is a string and its length
    assert isinstance(provider.ssn(), str)
    assert len(provider.ssn()) == 11

# Generated at 2022-06-23 20:34:45.169971
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Generate a random, but valid SSN."""
    uss = USASpecProvider()
    assert uss.ssn() == '565-66-5801'

# Generated at 2022-06-23 20:34:49.334145
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)
