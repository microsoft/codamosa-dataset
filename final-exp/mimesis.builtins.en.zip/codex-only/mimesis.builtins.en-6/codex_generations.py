

# Generated at 2022-06-23 20:24:48.892810
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_specprovider = USASpecProvider()
    usa_specprovider.tracking_number()

# Generated at 2022-06-23 20:24:50.220341
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    obj = USASpecProvider()
    assert obj.ssn() == '741-48-5011'


# Generated at 2022-06-23 20:24:53.149025
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()

    assert provider.ssn() == '130-24-5441'

# Generated at 2022-06-23 20:24:59.454200
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.ssn() is not None
    assert usa.tracking_number('FedEx') is not None
    assert usa.tracking_number(service='fedEx') is not None
    assert usa.tracking_number('fedEx') is not None
    assert usa.tracking_number('fedEX') is not None
    assert usa.tracking_number(service='FedEx') is not None
    assert usa.tracking_number() is not None
    assert usa.personality(category='rheti') is not None
    assert usa.personality() is not None
    assert usa.personality(category='MBTI') is not None

# Generated at 2022-06-23 20:25:02.054150
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    result = provider.ssn()
    assert len(result) == 11
    assert '-' in result



# Generated at 2022-06-23 20:25:06.097488
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    ssn = USASpecProvider().ssn()
    assert len(ssn.replace('-', '')) == 9
    assert ssn.split('-')[0].startswith('5')
    assert ssn.split('-')[1].startswith('6')
    assert ssn.split('-')[2].startswith('5')


# Generated at 2022-06-23 20:25:09.653798
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider"""
    assert len(USASpecProvider().ssn()) <= 11


# Generated at 2022-06-23 20:25:14.770009
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    en = USASpecProvider(seed="test")
    person_male = {'gender': Gender.MALE,
            'name': 'John',
            'surname': 'Smith',
            'phone': '202-555-0157',
            'email': 'smithjohn17@gmail.com',
            'ssn': '412-45-9556'}
    
    assert(en.person(**person_male) == person_male)
    return True

# Generated at 2022-06-23 20:25:18.667172
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis import Person

    p = Person('en')
    assert p.us.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP',
            'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ',
            'ESFJ', 'ENFJ', 'ENTJ')
    assert 1 <= p.us.personality('rheti') <= 10

# Generated at 2022-06-23 20:25:21.146177
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    usa.personality()
    usa.personality('mbti')
    usa.personality('rheti')

# Generated at 2022-06-23 20:25:27.012559
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn."""
    provider = USASpecProvider()
    result = provider.ssn()
    assert result is not None
    assert isinstance(result, str)
    assert len(result) == 11
    assert result.count('-') == 2


# Generated at 2022-06-23 20:25:31.027546
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Function that tests method tracking_number of class USASpecProvider."""
    usa_provider = USASpecProvider(seed=12345)
    result = usa_provider.tracking_number(service='fedex')
    assert result == '7467 4685 8517'


# Generated at 2022-06-23 20:25:32.380833
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    usa_provider = USASpecProvider()


# Generated at 2022-06-23 20:25:38.349137
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import Categories
    random = USASpecProvider()
    assert random.personality(category=Categories.MBTI.value) in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert type(random.personality(category=Categories.RHETI.value)) == int
    return

# Generated at 2022-06-23 20:25:44.745712
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
#    assert USASpecProvider().personality() in ['ISFJ', 'ESTP', 'ISFP', 'ESTJ',
#                                               'ESFP', 'ESFJ', 'ENTJ', 'ENTP',
#                                               'ENFP', 'INFP', 'INTP', 'INFJ',
#                                               'INTJ', 'ISTJ', 'ISTP']
    assert USASpecProvider().personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']



# Generated at 2022-06-23 20:25:48.056858
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    p = USASpecProvider()
    assert len(p.personality('rheti')) == 1
    assert len(p.personality()) == 4


# Generated at 2022-06-23 20:25:51.404730
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usasp = USASpecProvider()
    assert usasp.ssn() in ['569-66-5801', '837-80-0026', '962-42-5712', '592-85-6667', '386-76-5008']


# Generated at 2022-06-23 20:25:52.580372
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() == 'ESFJ'


# Generated at 2022-06-23 20:25:58.524453
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p1 = Person('en')
    p2 = Person('en')

    count_males = 0
    count_females = 0

    for i in range(100):

        personality = p1.personality(category='rheti')
        if personality == 1:
            count_males += 1

        personality = p2.personality(category='rheti')
        if personality == 2:
            count_females += 1

    assert count_males == count_females

# Generated at 2022-06-23 20:26:00.458929
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_spec_provider = USASpecProvider()
    assert USASpecProvider.ssn(usa_spec_provider)

# Generated at 2022-06-23 20:26:08.410967
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    provider = USASpecProvider()
    usps_tn = provider.tracking_number('usps')
    assert provider.check_mask(pattern='#### #### #### #### ####', data=usps_tn)
    assert provider.check_mask(pattern='@@ ### ### ### US', data=usps_tn)

    fedex_tn = provider.tracking_number('fedex')
    assert provider.check_mask(pattern='#### #### ####', data=fedex_tn)
    assert provider.check_mask(pattern='#### #### #### ###', data=fedex_tn)

    ups_tn = provider.tracking_number('ups')
    assert provider.check_mask(pattern='1Z@####@##########', data=ups_tn)



# Generated at 2022-06-23 20:26:14.376495
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method tracking_number for class USASpecProvider."""
    tracking_numbers = []
    for x in range(0, 100):
        usa_sp = USASpecProvider()
        tracking_numbers.append(usa_sp.tracking_number('usps'))
        tracking_numbers.append(usa_sp.tracking_number('fedex'))
        tracking_numbers.append(usa_sp.tracking_number('ups'))

    tracking_numbers_set = set(tracking_numbers)
    assert len(tracking_numbers_set) == 100


# Generated at 2022-06-23 20:26:20.413041
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    for x in range (0, 20):
        ssn = USASpecProvider().ssn()
        assert len(ssn) == 11
        assert ssn[3] == '-'
        assert ssn[6] == '-'
        assert ssn[0:3].isdigit()
        assert ssn[4:6].isdigit()
        assert ssn[7:11].isdigit()

#Unit test for method personality of class USASpecProvider

# Generated at 2022-06-23 20:26:28.989429
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    sample_size = 100
    # Valid tracking number of USPS
    assert len(set([USASpecProvider().tracking_number('usps') for x in range(0, sample_size)])) == sample_size
    # Valid tracking number of FedEx
    assert len(set([USASpecProvider().tracking_number('fedex') for x in range(0, sample_size)])) == sample_size
    # Valid tracking number of UPS
    assert len(set([USASpecProvider().tracking_number('ups') for x in range(0, sample_size)])) == sample_size
    # Error
    try:
        USASpecProvider().tracking_number('a')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-23 20:26:30.454317
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    with pytest.raises(ValueError):
        USASpecProvider()
    with pytest.raises(ValueError):
        USASpecProvider(seed=None)


# Generated at 2022-06-23 20:26:39.734671
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    x = USASpecProvider(seed=1234).ssn()
    assert x == "717-29-3150" or x == "717-29-3151" or x == "717-29-3152" or x == "717-29-3153" or x == "717-29-3154" or x == "717-29-3155" or x == "717-29-3156" or x == "717-29-3157" or x == "717-29-3158" or x == "717-29-3159"


# Generated at 2022-06-23 20:26:42.695310
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert len(USASpecProvider().tracking_number()) > 0
    assert len(USASpecProvider().ssn()) > 0
    assert len(USASpecProvider().personality()) > 0

# Generated at 2022-06-23 20:26:51.103467
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Unit tests for method personality of class USASpecProvider
    assert USASpecProvider().personality() in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP',
        'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    ]
    assert type(USASpecProvider().personality("rheti")) is int
    assert USASpecProvider().personality("rheti") in [
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10
    ]

# Generated at 2022-06-23 20:26:56.315232
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                       'ISTP', 'ISFP', 'INFP', 'INTP',
                                       'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                       'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality('rheti') in range(1, 11)


# Generated at 2022-06-23 20:26:57.996125
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider(seed="123")
    assert provider.random.seed == "123"


# Generated at 2022-06-23 20:26:59.704060
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number(service='usps')


# Generated at 2022-06-23 20:27:03.326333
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    result = usa.ssn()
    # assert type(result) is str
    assert len(result) == 11
    # assert result.isnumeric() is True

# Generated at 2022-06-23 20:27:13.942749
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    # Unit test for method tracking_number of class USASpecProvider for service: USPS
    for _ in range(100):
        assert len(USASpecProvider().tracking_number(service= 'usps')) in (18, 13)
        assert USASpecProvider().tracking_number(service= 'usps').startswith(('EE', 'EA', 'EC', 'CP', 'L', 'M', 'T', '9', 'T'))
        assert len(USASpecProvider().tracking_number(service= 'fedex')) in (12, 15)
        assert len(USASpecProvider().tracking_number(service= 'ups')) == 18
        assert USASpecProvider().tracking_number(service= 'ups').startswith('1Z')

#

# Generated at 2022-06-23 20:27:17.757798
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider(seed=None)

    assert usa_provider.tracking_number(service='usps') is not None
    assert usa_provider.tracking_number(service='fedex') is not None
    assert usa_provider.tracking_number(service='ups') is not None


# Generated at 2022-06-23 20:27:18.852583
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider is not None


# Generated at 2022-06-23 20:27:22.421866
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test for constructor of class USASpecProvider"""

    # Test for constructor with default value
    usa_provider = USASpecProvider(seed=None)
    assert isinstance(usa_provider, USASpecProvider)

    # Test for constructor with default value
    seed = 'test'
    usa_provider = USASpecProvider(seed)
    assert isinstance(usa_provider, USASpecProvider)


# Generated at 2022-06-23 20:27:27.852484
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.ssn() == '914-25-3124'
    assert usa.tracking_number() == '0Z037W052332114742'
    assert usa.tracking_number('ups') == '1Z08527N6751946725'

# Generated at 2022-06-23 20:27:30.221053
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test USASpecProvider.ssn()"""
    assert USASpecProvider().ssn() == '068-45-8606'

# Generated at 2022-06-23 20:27:31.614204
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    a = USASpecProvider()
    assert a.Meta.name == 'usa_provider'


# Generated at 2022-06-23 20:27:40.080656
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test personality of class USASpecProvider."""
    usa = USASpecProvider()
    assert usa.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert usa.personality(category='rheti') in range(1, 11)
    assert usa.personality(category='rheti') <= 10


# Generated at 2022-06-23 20:27:41.696568
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)


# Generated at 2022-06-23 20:27:45.438257
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Tested unit: /mimesis/en/USASpecProvider.py
    # Tested method: def ssn(self) -> str:
    # Enviroment: Python 3.6.8 :: Anaconda, Inc.
    
    # TEST CASE 1
    # Inputs: 
    # Outputs: 569-66-5801
    
    assert len(USASpecProvider().ssn()) == 11


# Generated at 2022-06-23 20:27:51.775699
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert provider.personality(category='rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    assert isinstance(provider.personality(category='rheti'), int)
    assert isinstance(provider.personality(), str)


# Generated at 2022-06-23 20:28:01.587708
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    assert USASpecProvider().ssn() == '451-81-8271'
    assert USASpecProvider(seed=1).ssn() == '179-92-5879'
    assert USASpecProvider(seed=2).ssn() == '569-26-7679'
    assert USASpecProvider(seed=3).ssn() == '244-67-7380'
    assert USASpecProvider(seed=4).ssn() == '876-34-6549'
    assert USASpecProvider(seed=5).ssn() == '299-57-3524'
    assert USASpecProvider(seed=6).ssn() == '700-51-5729'

# Generated at 2022-06-23 20:28:08.226884
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    ssn = usa.ssn()
    assert ssn.startswith('666') == False
    assert ssn.startswith('00') == False
    assert ssn.endswith('0000') == False
    assert len(ssn) == 11
    assert ssn.count('-') == 2


# Generated at 2022-06-23 20:28:17.809548
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Return a random tracking number from a post service."""
    usa_provider = USASpecProvider()

    # USPS
    tracking_number_USPS = usa_provider.tracking_number('usps')
    assert isinstance(tracking_number_USPS, str)

    # FedEx
    tracking_number_FedEx = usa_provider.tracking_number('fedex')
    assert isinstance(tracking_number_FedEx, str)

    # UPS
    tracking_number_UPS = usa_provider.tracking_number('ups')
    assert isinstance(tracking_number_UPS, str)

# Generated at 2022-06-23 20:28:21.107449
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    tests = ['mbti', 'rheti']
    for test in tests:
        assert USASpecProvider().personality(test) is not None


# Generated at 2022-06-23 20:28:26.133767
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()

    assert usa_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert 1 <= usa_provider.personality('rheti') <= 10

# Generated at 2022-06-23 20:28:29.617831
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    prov = USASpecProvider()
    ssn = prov.ssn()
    assert ssn is not None
    assert len(ssn) is 11


# Generated at 2022-06-23 20:28:31.524569
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    up = USASpecProvider()
    assert len(up.ssn()) == 11


# Generated at 2022-06-23 20:28:37.690563
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    results = []
    for i in range(10000):
        results.append(usa.personality())

    assert any(i in results for i in 'ISFJ ISTJ INFJ INTJ ISTP ISFP INFP INTP ESTP ESFP ENFP ENTP ESTJ ESFJ ENFJ ENTJ'.split())

# Generated at 2022-06-23 20:28:41.857572
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():

    from mimesis.enums import PostService

    assert USASpecProvider().tracking_number(service=PostService.USPS)
    assert USASpecProvider().tracking_number(service=PostService.FEDEX)
    assert USASpecProvider().tracking_number(service=PostService.UPS)



# Generated at 2022-06-23 20:28:46.164644
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number() == '8adb 4287 7e83 2a36 6c4b'
    assert provider.tracking_number('usps') == '3918 1606 492f 3c0e 64b5'


# Generated at 2022-06-23 20:28:50.972236
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert(USASpecProvider().personality(category="test") in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert(USASpecProvider().personality(category="test2") in ['ISFJ','ISTJ','INFJ','INTJ','ISTP','ISFP','INFP','INTP','ESTP','ESFP','ENFP','ENTP','ESTJ','ESFJ','ENFJ','ENTJ'])

# Generated at 2022-06-23 20:28:53.452998
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() != None


# Generated at 2022-06-23 20:28:56.356202
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    provider = USASpecProvider()
    person = provider.personality(category="rheti") # type: ignore
    assert isinstance(person, int)

# Generated at 2022-06-23 20:28:59.826375
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking_number = provider.tracking_number(service = 'usps')
    assert ' ' in tracking_number
    assert len(tracking_number) in {18, 15, 21}
    

# Generated at 2022-06-23 20:29:01.153074
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    provider.ssn()


# Generated at 2022-06-23 20:29:05.800644
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    p = USASpecProvider()
    assert p.ssn() not in ['000-00-0000', '666-00-0000', '000-01-0000', '000-00-0001']

# Generated at 2022-06-23 20:29:09.104692
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    for service in ('USPS', 'FEDEX', 'UPS'):
        tracking_number = provider.tracking_number(service)
        assert tracking_number is not None



# Generated at 2022-06-23 20:29:12.034251
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tn = provider.tracking_number()
    assert len(tn) > 0
    assert tn[:2].isalpha()
    assert tn[2].isupper()
    assert tn[3:].isalnum()


# Generated at 2022-06-23 20:29:14.814316
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.__class__.__name__ == "USASpecProvider"


# Generated at 2022-06-23 20:29:17.009466
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert isinstance(USASpecProvider(), USASpecProvider)


# Generated at 2022-06-23 20:29:26.175574
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for USASpecProvider method personality."""
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality('rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    assert usa.personality('rheti') == usa.personality('rheti')
    assert usa.personality(category='rheti') == usa.personality('rheti')
    assert usa

# Generated at 2022-06-23 20:29:30.962562
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test constructor of class USASpecProvider"""
    import random
    seed = random.getrandbits(32)

    provider_a = USASpecProvider()
    provider_b = USASpecProvider(seed=seed)

    assert provider_a.__seed__ != provider_b.__seed__

    print(provider_a.tracking_number())
    print(provider_a.tracking_number('ups'))
    print(provider_a.ssn())
    print(provider_a.personality())
    print(provider_a.personality('rheti'))


# Generated at 2022-06-23 20:29:33.438771
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method by calling it."""
    us = USASpecProvider()
    assert isinstance(us.ssn(), str)

# Generated at 2022-06-23 20:29:37.176555
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityCategory
    provider = USASpecProvider(seed=42)

    for field in PersonalityCategory:
        try:
            provider.personality(field.value)
        except ValueError:
            assert True
        else:
            assert False

# Generated at 2022-06-23 20:29:42.379508
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, BaseSpecProvider)
    with pytest.raises(ValueError):
        usa.tracking_number('DHL')
    assert isinstance(usa.tracking_number(), str)
    assert len(usa.tracking_number('USPS')) == 29
    assert isinstance(usa.ssn(), str)
    assert len(usa.ssn()) == 11
    assert isinstance(usa.personality(), str)

# Generated at 2022-06-23 20:29:44.170906
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider().__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:29:54.341847
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()

    # USPS
    for _ in range(10):
        assert len(usa.tracking_number('usps')) == 22
    for _ in range(10):
        assert len(usa.tracking_number('usps')) == 22
        assert isinstance(usa.tracking_number('usps'), str)

    # Fedex
    for _ in range(10):
        assert len(usa.tracking_number('fedex')) == 12
    for _ in range(10):
        assert len(usa.tracking_number('fedex')) == 15
        assert isinstance(usa.tracking_number('fedex'), str)

    # UPS
    for _ in range(10):
        assert len(usa.tracking_number('ups')) == 18

# Generated at 2022-06-23 20:30:01.593022
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert type(usa.personality('rheti')) is int
    assert 1 <= usa.personality('rheti') <= 10

# Generated at 2022-06-23 20:30:03.958940
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p1 = USASpecProvider()
    p2 = USASpecProvider()
    assert p1.personality() != p2.personality()

# Generated at 2022-06-23 20:30:05.814457
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number(service='FedEx') is not None


# Generated at 2022-06-23 20:30:07.605113
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()

    assert provider.personality() != None


# Generated at 2022-06-23 20:30:09.880610
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.providers.usa import USASpecProvider
    ssn = USASpecProvider().ssn()
    assert len(ssn) == 11


# Generated at 2022-06-23 20:30:17.619454
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of USASpecProvider class."""
    sp = USASpecProvider()
    assert sp.ssn() == '214-61-0386'
    assert sp.ssn() == '721-59-0273'
    assert sp.ssn() == '028-19-0989'
    assert sp.ssn() == '272-19-9069'
    assert sp.ssn() == '512-06-9801'
    assert sp.ssn() == '522-53-1519'


# Generated at 2022-06-23 20:30:20.889961
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usaspecp = USASpecProvider()
    ssn = usaspecp.ssn()
    assert ssn is not None
    assert type(ssn) is str

# Generated at 2022-06-23 20:30:22.594992
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider().ssn() != None

# Generated at 2022-06-23 20:30:26.150397
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn()
    assert provider.ssn()
    assert provider.ssn()
    assert provider.ssn()
    assert provider.ssn()

# Generated at 2022-06-23 20:30:27.590452
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() != ''


# Generated at 2022-06-23 20:30:30.321184
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    sp = USASpecProvider(seed=123456789)
    assert sp.ssn() == "666-45-5801"


# Generated at 2022-06-23 20:30:34.110119
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():   
    usa_spec_provider = USASpecProvider()
    assert isinstance(usa_spec_provider.random, Random)
    assert usa_spec_provider.locale == 'en'

# Generated at 2022-06-23 20:30:36.906199
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.enums import PostService
    from mimesis.providers.usa import USASpecProvider

    USASpecProvider.tracking_number(service=PostService.USPS)


# Generated at 2022-06-23 20:30:44.387752
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    t = USASpecProvider()
    ssn = t.ssn()
    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'
    area=int(ssn[0:3])
    group=int(ssn[4:6])
    serial=int(ssn[7:11])
    assert area >= 1
    assert area < 900
    assert group >= 1
    assert group < 100
    assert serial >= 1
    assert serial < 10000

# Generated at 2022-06-23 20:30:47.582831
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert type(usa.personality("rheti")) == int
    assert type(usa.personality("rheti")) == int


# Generated at 2022-06-23 20:30:50.283589
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    tmp = USASpecProvider()
    assert tmp is not None


# Generated at 2022-06-23 20:30:55.051847
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print('\nTesting constructor of class USASpecProvider...')
    quantum_random = USASpecProvider()
    print('Generate:', quantum_random.personality())
    quantum_random = USASpecProvider('random')
    print('Generate:', quantum_random.personality())


# Generated at 2022-06-23 20:31:03.270673
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a = USASpecProvider()
    assert len(a.tracking_number(service='usps')) == 32
    assert len(a.tracking_number(service='usps')) == 32
    assert len(a.tracking_number(service='usps')) == 32
    assert len(a.tracking_number(service='fedex')) == 13
    assert len(a.tracking_number(service='fedex')) == 13
    assert len(a.tracking_number(service='fedex')) == 13
    assert len(a.tracking_number(service='ups')) == 18
    assert len(a.tracking_number(service='ups')) == 18
    assert len(a.tracking_number(service='ups')) == 18


# Generated at 2022-06-23 20:31:05.516623
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    random_data = USASpecProvider()
    print(random_data.tracking_number())
    print(random_data.tracking_number('UPS'))
    print(random_data.tracking_number('usps'))


# Generated at 2022-06-23 20:31:07.476183
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    s = USASpecProvider()

    # Test that s is an object of class USASpecProvider
    assert isinstance(s, USASpecProvider)


# Generated at 2022-06-23 20:31:12.637764
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    r = USASpecProvider()
    #generate a valid MBTI personality for testing
    v1 = r.personality(category='mbti')
    assert len(v1) is 4
    #generate a valid Rheti personality for testing
    v2 = r.personality(category='rheti')
    assert 0 < v2 < 10
    #generate a personality of unsupported category
    try:
        v3 = r.personality(category='unsupported')
    except Exception as ex:
        assert str(ex) == 'No data found for category \'unsupported\''

# Generated at 2022-06-23 20:31:20.782000
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    us.seed(1)
    assert us.personality('mbti') == 'INFJ'
    assert us.personality('Myers-Briggs Type Indicator') == 'INFJ'
    assert us.personality('MBTI') == 'INFJ'
    assert us.personality('Myers-Briggs') == 'INFJ'
    assert us.personality('Myers') == 'INFJ'
    assert us.personality('MB') == 'INFJ'
    assert us.personality('Briggs') == 'INFJ'
    assert us.personality('rheti') == 5
    assert us.personality('MBTI') == 'INFJ'
    assert us.personality('RHETI') == 5

# Generated at 2022-06-23 20:31:25.761612
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:31:30.320301
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    usa_spec_provider.seed('123456789')
    assert usa_spec_provider.tracking_number(service="USPS") == '7PN 898 898 US'


# Generated at 2022-06-23 20:31:35.111100
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    generator = USASpecProvider()
    packages = ('usps', 'fedex', 'ups')
    for pack in packages:
        tracker = generator.tracking_number(pack)
        assert len(tracker) > 3, "Minimum length of the tracking number is 3"


# Generated at 2022-06-23 20:31:35.649820
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Docstring."""
    pass

# Generated at 2022-06-23 20:31:38.608455
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method USASpecProvider.ssn()."""
    assert USASpecProvider().ssn() == '049-80-3622', 'The Social Security Number is not correct!'


# Generated at 2022-06-23 20:31:41.152727
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit-Test method tracking_number of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number('USPS')
    assert usa_provider.tracking_number('ups')
    assert usa_provider.tracking_number('fedex')
    assert not usa_provider.tracking_number('post')


# Generated at 2022-06-23 20:31:43.833845
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    for i in range(0, 10):
        provider = USASpecProvider()
        ssn = provider.ssn()
        assert(ssn.find('-') != -1)
        assert(len(ssn) == 11)

# Generated at 2022-06-23 20:31:55.259597
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    print('Testing method personality of class USASpecProvider')

    # Verify type and value of personality when category is mbti
    # and personality is a valid personality type
    mbti_personality = USASpecProvider().personality(category='mbti')
    assert isinstance(mbti_personality, str)
    assert mbti_personality in {'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'}
    
    # Verify type and value of personality when category is rheti
    # and personality is a valid personality type
    rheti_personality = USAS

# Generated at 2022-06-23 20:32:00.733987
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:32:05.751704
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    objUSASpecProvider = USASpecProvider(seed=1)
    assert objUSASpecProvider is not None
    assert objUSASpecProvider.random.seed == 1
    assert objUSASpecProvider.locale == 'en'
    assert objUSASpecProvider.random.locale == 'en'



# Generated at 2022-06-23 20:32:08.285750
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    assert isinstance(us.tracking_number(service='usps'), str)


# Generated at 2022-06-23 20:32:11.615550
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():

    assert len(USASpecProvider().ssn()) == 11
    assert USASpecProvider().ssn()[3] == '-'
    assert USASpecProvider().ssn()[6] == '-'


# Generated at 2022-06-23 20:32:17.933936
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Method to test the personality of class USASpecProvider."""
    provider = USASpecProvider()

    expected_mbti = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                     'ISTP', 'ISFP', 'INFP', 'INTP',
                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    result = provider.personality()

    assert type(result) == str
    assert result in expected_mbti

    expected_rheti = ""
    for i in range(1, 11):
        expected_rheti += str(i)

    result = provider.personality('rheti')
    assert type(result) == int
    assert str(result) in expected_rheti

# Generated at 2022-06-23 20:32:21.638694
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    print(usa.tracking_number('fedex'))
    print(usa.ssn())
    print(usa.personality())
    print(usa.personality('rheti'))


# Generated at 2022-06-23 20:32:29.444844
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    result = usa_spec_provider.personality()
    assert result == 'ISFJ' or result == 'ISTJ' or result == 'INFJ' or result == 'INTJ' \
     or result == 'ISTP' or result == 'ISFP' or result == 'INFP' or result == 'INTP' \
     or result == 'ESTP' or result == 'ESFP' or result == 'ENFP' or result == 'ENTP' \
     or result == 'ESTJ' or result == 'ESFJ' or result == 'ENFJ' or result == 'ENTJ'

    result = usa_spec_provider.personality('rheti')
    assert result > 0 and result < 11



# Generated at 2022-06-23 20:32:31.094234
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    print(us)
    assert us is not None


# Generated at 2022-06-23 20:32:33.618749
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking = provider.tracking_number()
    assert len(tracking) == 29


# Generated at 2022-06-23 20:32:37.592952
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa.random, type(usa._random))
    assert usa.seed is None
    assert usa.locale == 'en'


# Generated at 2022-06-23 20:32:39.789562
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    a = USASpecProvider()
    if a is None:
        raise AssertionError("USASpecProvider is null")

# Test for personality of USASpecProvider

# Generated at 2022-06-23 20:32:49.854392
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
	# Using an empty seed
	u = USASpecProvider()
	# Creating an instance of USASpecProvider with a random seed
	u2 = USASpecProvider(seed=None)
	
	ssnList = [];
	counter = 0
	
	# Calling the function ssn 9 times
	while counter < 9:
		ssnList.append(u.ssn())
		counter += 1

	# Generating an empty list
	ssnList2 = []
	counter = 0
	# Calling the function ssn 9 times
	while counter < 9:
		ssnList2.append(u2.ssn())
		counter += 1

	# Check that the SSN are different, since the unique instance was created with a random seed

# Generated at 2022-06-23 20:32:54.648500
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test USASpecProvider.personality method."""
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.personality(category="mbti"), str)
    assert isinstance(usa_provider.personality(category="rheti"), int)


# Generated at 2022-06-23 20:32:56.827228
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usp = USASpecProvider()
    x = usp.tracking_number(service='ups')
    assert len(x) == 18


# Generated at 2022-06-23 20:33:03.819824
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """ Test the constructor of class USASpecProvider. Checking that the structure is correct """
    from mimesis.enums import Gender
    from mimesis.builtins.base import BaseSpecProvider
    from mimesis.providers.address import Address
    from mimesis.providers.generic import Generic
    from mimesis.providers.internet import Internet
    from mimesis.providers.media import Media
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.unit import Unit

    usa_provider = USASpecProvider()

    assert isinstance(usa_provider._data, dict)
    assert isinstance(usa_provider.address, Address)

# Generated at 2022-06-23 20:33:06.155698
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Create instance of class USASpecProvider"."""
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)


# Generated at 2022-06-23 20:33:08.651557
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    x = USASpecProvider()
    y = x.personality(category='MBTI')
    assert len(y)==4

# Generated at 2022-06-23 20:33:12.261159
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    tracking_number = usa_provider.tracking_number("usps")
    assert len(tracking_number) == 23
    

# Generated at 2022-06-23 20:33:17.007173
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method """
    srv = USASpecProvider()
    assert srv.tracking_number('USPS') == '1704 4153 7975 1700 8127'
    assert srv.tracking_number('FedEx') == '9462 9707 6782'
    assert srv.tracking_number('UPS') == '1Z7594PV7172373732'


# Generated at 2022-06-23 20:33:23.888653
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    usa = USASpecProvider()
    assert isinstance(usa.random, USASpecProvider)
    assert usa.locale == 'en'

    person = Person('en')
    person.seed(1337)
    assert person.random.randint(0, 10) == 9

    person.seed(42)
    assert person.random.randint(0, 10) == 8



# Generated at 2022-06-23 20:33:34.448891
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    # Randomly picked

# Generated at 2022-06-23 20:33:36.638081
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tnp = USASpecProvider()
    tn = tnp.tracking_number()
    assert tn is not None
    assert isinstance(tn, str)

# Generated at 2022-06-23 20:33:41.117447
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP',
        'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']


# Generated at 2022-06-23 20:33:42.514677
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    a = USASpecProvider()
    b = a.ssn()
    assert type(b) == str


# Generated at 2022-06-23 20:33:45.555862
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaspec_provider = USASpecProvider()
    result_personality = usaspec_provider.personality()
    print(result_personality)


# Generated at 2022-06-23 20:33:54.331507
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                       'ISTP', 'ISFP', 'INFP', 'INTP',
                                       'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                       'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa.personality('rheti'), int)

    # Different checks for ISFJ becauce of a high probability of getting it
    assert isinstance(usa.personality('rheti'), int)
    assert isinstance(usa.personality('rheti'), int)

# Generated at 2022-06-23 20:33:55.458597
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() == '000-00-0000'


# Generated at 2022-06-23 20:34:00.952089
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    gen = USASpecProvider()
    assert gen.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                       'ISTP', 'ISFP', 'INFP', 'INTP',
                                       'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                       'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:34:04.514603
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test ssn method of class USASpecProvider."""
    # Prepare values for compare
    provider = USASpecProvider()
    ssn = provider.ssn()
    # Check
    assert len(ssn) == 11
    assert ssn.count('-') == 2


# Generated at 2022-06-23 20:34:06.728791
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() == usa.personality('mbti')
    assert usa.personality('rheti') in range(1,10)

# Generated at 2022-06-23 20:34:09.508836
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    p = USASpecProvider()
    assert p.tracking_number() is not None


# Generated at 2022-06-23 20:34:19.563911
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_service = USASpecProvider()

    # Test for value mbti, real values
    assert usa_service.personality() in ['ISFJ', 'ISTJ', 'INFJ',
                                         'INTJ', 'ISTP', 'ISFP',
                                         'INFP', 'INTP', 'ESTP',
                                         'ESFP', 'ENFP', 'ENTP',
                                         'ESTJ', 'ESFJ', 'ENFJ',
                                         'ENTJ']
    assert usa_service.personality(category='rheti') in [1, 2, 3, 4, 5, 6,
                                                         7, 8, 9, 10]

# Generated at 2022-06-23 20:34:22.574315
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    spec = USASpecProvider()
    assert isinstance(spec.personality(), str)

# Generated at 2022-06-23 20:34:29.174457
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usspec = USASpecProvider()
    res = usspec.tracking_number(service='usps')
    print(res)
    assert len(res) == 26
    res = usspec.tracking_number(service='fedex')
    print(res)
    assert len(res) == 12 or len(res) == 14
    res = usspec.tracking_number(service='ups')
    print(res)
    assert len(res) == 18


# Generated at 2022-06-23 20:34:35.697076
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print("\n ----------------- Unit test for constructor of class USASpecProvider ----------------- \n")
    # initialize unit test provider
    provider = USASpecProvider(seed=1)
    # generate random tracking number
    print("Test next data: random tracking number => ", provider.tracking_number())
    # generate SSN
    print("Test next data: SSN => ", provider.ssn())
    # generate personality
    print("Test next data: personality => ", provider.personality())
test_USASpecProvider()


# Generated at 2022-06-23 20:34:37.176811
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number()


# Generated at 2022-06-23 20:34:38.989739
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider(seed=0)
    assert provider.name == 'usa_provider'
    assert provider.seed == 0


# Generated at 2022-06-23 20:34:45.423982
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    provider = USASpecProvider()
    assert provider.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']


# Generated at 2022-06-23 20:34:49.438010
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() != USASpecProvider().ssn()

