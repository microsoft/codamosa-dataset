

# Generated at 2022-06-23 20:24:59.025767
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    list_ssn = ssn.split("-")

    assert isinstance(ssn, str)
    assert len(ssn)==11
    assert list_ssn[0]!="666"
    assert len(list_ssn)==3
    assert len(list_ssn[0])==3
    assert len(list_ssn[1])==2
    assert len(list_ssn[2])==4


# Generated at 2022-06-23 20:25:01.633043
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    sp = USASpecProvider()
    assert sp.provider_name == "usa_provider"
    assert sp.seed is not None


# Generated at 2022-06-23 20:25:04.080942
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test constructor of class USASpecProvider"""
    usa = USASpecProvider()
    assert usa.__class__.__dict__['Meta'].__dict__['name'] is 'usa_provider'

# Generated at 2022-06-23 20:25:08.796623
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """
    Test case: method tracking_number of class USASpecProvider
    """
    print('\nTesting tracking_number ...')
    service = 'USPS'

    usa_specs = USASpecProvider()
    print(f"\nThe given service is: {service}")

    tracking_number = usa_specs.tracking_number(service)
    print(f'\nThe tracking number: {tracking_number}')

    assert isinstance(tracking_number, str)


# Generated at 2022-06-23 20:25:13.132606
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    USASpecProv = USASpecProvider()
    usps = USASpecProv.tracking_number()
    assert len(usps.split()) == 5
    fedex = USASpecProv.tracking_number('fedex')
    assert len(fedex.split()) in (2, 3)
    ups = USASpecProv.tracking_number('ups')
    assert len(ups.split()) == 5

# Generated at 2022-06-23 20:25:21.196878
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    import pytest

    tn = USASpecProvider().tracking_number('ups')
    assert len(tn) == 18 and tn[2].isalpha()

    tn = USASpecProvider().tracking_number('fedex')
    assert len(tn) == 12 or len(tn) == 16

    tn = USASpecProvider().tracking_number('usps')
    assert len(tn) == 35 and tn[2:5].isdigit() and tn[5] == ' '

    with pytest.raises(ValueError):
        USASpecProvider().tracking_number('parcel')



# Generated at 2022-06-23 20:25:26.326471
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    tracking_number = usa_provider.tracking_number()
    assert len(tracking_number) == 18, "Error lenght tracking_number"


# Generated at 2022-06-23 20:25:29.098236
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider"""
    provider = USASpecProvider(seed=14)
    result = provider.ssn()
    assert result == '569-66-5801'


# Generated at 2022-06-23 20:25:32.114162
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for class USASpecProvider."""
    usa = USASpecProvider()
    assert usa.random.choice(('a', 'b', 'c')) in ('a', 'b', 'c')

# Generated at 2022-06-23 20:25:33.623733
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Create object USASpecProvider
    USASpecProvider()

# Generated at 2022-06-23 20:25:35.620026
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    ssn = usa_provider.ssn()
    assert ssn != None

# Generated at 2022-06-23 20:25:38.779124
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    print(USASpecProvider().ssn())


if __name__ == "__main__":
    test_USASpecProvider_ssn()

# Generated at 2022-06-23 20:25:47.968354
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    print("test_USASpecProvider_tracking_number")
    from mimesis.providers.usa import USASpecProvider
    u = USASpecProvider()

    assert len(u.tracking_number("usps")) == 29, "Wrong tracking number for USPS"
    assert len(u.tracking_number("fedex")) == 17, "Wrong tracking number for FedEx"
    assert len(u.tracking_number("ups")) == 18, "Wrong tracking number for UPS"

    try:
        u.tracking_number("unsupported_service")
        assert False, "Tracking number should not be generated with unsupported service"
    except ValueError as e:
        assert True


# Generated at 2022-06-23 20:25:49.612975
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usaspecprovider = USASpecProvider()
    assert usaspecprovider != None


# Generated at 2022-06-23 20:25:54.242705
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:25:56.674922
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider().random.seed == 'mimesis'

# Generated at 2022-06-23 20:25:58.612741
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert len(usa.tracking_number()) == 16


# Generated at 2022-06-23 20:25:59.809733
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us_provider = USASpecProvider()
    assert us_provider.ssn()

# Generated at 2022-06-23 20:26:01.473777
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_spec = USASpecProvider()
    us_spec.mbti() == 'ISFJ'

# Generated at 2022-06-23 20:26:02.101087
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider.ssn()

# Generated at 2022-06-23 20:26:03.409173
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    prov = USASpecProvider()
    assert prov.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:26:04.713712
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn."""
    ssn = USASpecProvider().ssn()
    assert isinstance(ssn, str)



# Generated at 2022-06-23 20:26:07.324813
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider()
    assert len(p.personality(category='rheti')) == 1
    assert len(p.personality(category='mbti')) == 4


# Generated at 2022-06-23 20:26:14.839936
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    import random
    random.seed(12061994)
    assert USASpecProvider().tracking_number('usps') == '8532986145592112741833US'
    assert USASpecProvider().tracking_number('usps') == '7496718429753401364494US'
    assert USASpecProvider().tracking_number('usps') == '6827084209580872868115US'
    random.seed(12061994)
    assert USASpecProvider().tracking_number('fedex') == '9046177772'
    assert USASpecProvider().tracking_number('fedex') == '9627226562'
    assert USASpecProvider().tracking_number('fedex') == '8649123597'
    random.seed(12061994)
    assert USASpecProvider().tracking

# Generated at 2022-06-23 20:26:18.683781
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    print(usa_spec_provider.tracking_number())
    print(usa_spec_provider.ssn())
    print(usa_spec_provider.personality())

test_USASpecProvider()

# Generated at 2022-06-23 20:26:24.266862
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider(seed=1)
    # Default value is 'usps'
    assert usa_provider.tracking_number() == '8809 7366 4175 6234 5916'
    assert usa_provider.tracking_number('usps') == '6771 0175 8407 7805 7301'
    assert usa_provider.tracking_number('UPS') == '1ZA67U038157692764'
    assert usa_provider.tracking_number('FedEx') == '9114 2904 7641'
    assert usa_provider.tracking_number('fedex') == '0860 4197 2339'
    assert usa_provider.tracking_number('FedEx') == '4117 8074 1278'

# Generated at 2022-06-23 20:26:33.566637
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tracker1 = USASpecProvider().tracking_number(service='FedEx')
    tracker2 = USASpecProvider().tracking_number(service='USPS')
    tracker3 =  USASpecProvider().tracking_number(service='USPS')
    valid_fedex = [
        '1451 0996 1387',
        '7115 9250 1855 387',
        '4066 0333 1449'
    ]
    valid_usps = [
        '6T57 3521 7004 006A C878',
        '2811 0789 4552 US',
        '4L29 1237 0749 9796 0356'
    ]
    assert tracker1 in valid_fedex
    assert tracker2 in valid_usps
    assert tracker3 in valid_usps
    assert tracker1 != tracker2
    assert tracker2 != tracker3

# Generated at 2022-06-23 20:26:43.597040
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Testing method tracking_number of class USASpecProvider."""
    usps = USASpecProvider()
    assert usps.tracking_number()
    assert usps.tracking_number('USPS')
    assert usps.tracking_number('ups')
    assert usps.tracking_number('fedex')
    try:
        assert not usps.tracking_number('Russia')
    except ValueError:
        assert True
    try:
        assert not usps.tracking_number('Ebay')
    except ValueError:
        assert True
    try:
        assert not usps.tracking_number('China')
    except ValueError:
        assert True


# Generated at 2022-06-23 20:26:48.048099
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    counter = 0
    while counter < 1000:
        ssn = usa_provider.ssn()
        assert ssn[3] == '-' and ssn[6] == '-'
        assert len(ssn) == 11
        counter += 1

# Generated at 2022-06-23 20:26:50.616639
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.Meta.name == 'usa_provider'


# Generated at 2022-06-23 20:26:53.031067
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Create a USASpecProvider object."""
    
    usa_provider = USASpecProvider()
    assert usa_provider.seed is None
    assert usa_provider.random.seed is None
    assert usa_provider.random.random == usa_provider.random.random_instance

# Generated at 2022-06-23 20:26:54.215371
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() == 'ENTJ'



# Generated at 2022-06-23 20:26:55.332024
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() == 'ISFJ'


# Generated at 2022-06-23 20:26:57.747575
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider(seed=123)
    ssn = provider.ssn()

    assert(ssn == '469-12-8071')


# Generated at 2022-06-23 20:27:09.409325
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    ss = USASpecProvider()
    # Unit test for ssn
    for i in range(100):
        r = ss.ssn()
        assert len(r) == 11
        assert r[0] != '0'
        assert r[1] != '0'
        assert r[3] != '0'
        assert r[4] != '0'
        assert r[6] != '0'
        assert r[7] != '0'
        assert r[8] != '0'
        assert r[9] != '0'
        assert r[0:3] != '666'
    # Unit test for tracking_number
    # Test USPS
    for i in range(100):
        r = ss.tracking_number('USPS')
        assert len(r.split(' ', 1)) == 2
    # Test Fed

# Generated at 2022-06-23 20:27:10.388066
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa

# Generated at 2022-06-23 20:27:12.970494
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.builtins import USASpecProvider
    usa = USASpecProvider()
    assert '153-51-8410' == usa.ssn()



# Generated at 2022-06-23 20:27:21.701165
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn."""
    # Generate a list with regex patterns
    regex_patterns = ['\d{3}-\d{2}-\d{4}']*10
    # Initialize a USASpecProvider
    usa_provider = USASpecProvider()
    # Get a random social security number
    test_ssn = usa_provider.ssn()
    # Verify if the generated SSN matches one of the regex patterns
    returns = [regex_pattern.search(test_ssn) for regex_pattern in regex_patterns]
    assert bool(returns)

# Generated at 2022-06-23 20:27:23.556567
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert len(provider.tracking_number()) == 22


# Generated at 2022-06-23 20:27:26.828407
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    assert usa_provider.ssn() == '569-66-5801'

# Generated at 2022-06-23 20:27:35.339102
# Unit test for method tracking_number of class USASpecProvider

# Generated at 2022-06-23 20:27:43.055352
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    import mimesis
    import pytest
    from random import seed
    from json import dump

    seed(123)

    USA_person = Person('en-US', gender=Gender.MALE)
    USA_person.seed(123)

    generic_person = mimesis.Person('en', gender=Gender.MALE)
    generic_person.seed(123)

    person_dict = {}

    for person_number in range(1, 5000):
        person_dict[person_number] = {
            'en': generic_person.ssn(),
            'en-US': USA_person.ssn(),
        }

# Generated at 2022-06-23 20:27:46.111502
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert (len(USASpecProvider().personality()) == 4)
    assert (len(USASpecProvider().personality(category='rheti')) == 2)

# Generated at 2022-06-23 20:27:49.185157
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider(48)
    assert usa.get_random_seed() == 48
    assert usa.get_locale() == 'en'


# Generated at 2022-06-23 20:27:54.848119
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    prototest = USASpecProvider()
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',\
             'ISTP', 'ISFP', 'INFP', 'INTP',\
             'ESTP', 'ESFP', 'ENFP', 'ENTP',\
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    try:
        assert prototest.personality(category='mbti') in mbtis
        assert prototest.personality(category='rheti') in range(1,11)
    except ValueError as e:
        print(e)

# Generated at 2022-06-23 20:28:00.652917
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaSpecProvider = USASpecProvider()
    assert usaSpecProvider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP',
                                             'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ',
                                             'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:28:11.276863
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    usps_1 = usa_provider.tracking_number('usps')
    usps_2 = usa_provider.tracking_number(service='usps')
    fedex_1 = usa_provider.tracking_number('fedex')
    fedex_2 = usa_provider.tracking_number(service='fedex')
    ups_1 = usa_provider.tracking_number('ups')
    ups_2 = usa_provider.tracking_number(service='ups')
    assert usps_1 is not None
    assert usps_2 is not None
    assert fedex_1 is not None
    assert fedex_2 is not None
    assert ups_1 is not None
    assert ups_2 is not None

# Generated at 2022-06-23 20:28:15.137869
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    ssn = usa_spec_provider.ssn()
    assert len(ssn.split('-')) == 3

# Generated at 2022-06-23 20:28:21.845882
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    
    assert provider.personality(category='mbti') in mbtis
    assert provider.personality(category='rheti') in range(1, 11)



# Generated at 2022-06-23 20:28:30.567199
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_sp = USASpecProvider()
    tracking_number_post_usps = usa_sp.tracking_number('usps')
    tracking_number_post_fedex = usa_sp.tracking_number('fedex')
    tracking_number_post_ups = usa_sp.tracking_number('ups')
    assert tracking_number_post_usps is not None
    assert tracking_number_post_fedex is not None
    assert tracking_number_post_ups is not None


# Generated at 2022-06-23 20:28:35.814259
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print('Test USASpecProvider')

    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person_en = Person('en')
    driver_license_en = person_en.driver_license(gender=Gender.MALE)
    print(driver_license_en)

    usa = USASpecProvider('en')
    ssn = usa.ssn()
    print(ssn)

# Generated at 2022-06-23 20:28:40.411391
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Arrange
    # expected_result = '1Z12345E0205271688'
    expected_result = "expected_result"

    # Act
    provider = USASpecProvider()
    result = provider.tracking_number()

    # Assert
    assert result == expected_result


# Generated at 2022-06-23 20:28:43.558882
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    for personality in USASpecProvider().personality():
        assert isinstance(personality, str)


# Generated at 2022-06-23 20:28:46.045235
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert len(USASpecProvider().tracking_number()) == 40
    assert len(USASpecProvider().tracking_number("ups")) == 18
    

# Generated at 2022-06-23 20:28:53.980221
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Test for create a instance of class USASpecProvider
    usa_provider = USASpecProvider()
    
    # Test for method personality of class USASpecProvider
    mbti = usa_provider.personality()
    assert mbti in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                    'ISTP', 'ISFP', 'INFP', 'INTP',
                    'ESTP', 'ESFP', 'ENFP', 'ENTP',
                    'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    
    # Test for method personality of class USASpecProvider
    assert type(usa_provider.personality('rheti')) == int

    # Test for method personality of class USASpecProvider

# Generated at 2022-06-23 20:28:57.105454
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider.

    :return: void.
    """
    from mimesis.enums import Personality
    from mimesis.providers.usa import USASpecProvider

    usaspp = USASpecProvider()
    usaspp.personality(Personality.MBTI)
    usaspp.personality(Personality.RHETI)
    

# Generated at 2022-06-23 20:29:02.792069
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert 1 <= usa.personality(category='rbeti') <= 10
    assert usa.personality(category='rbeti') != 6

# Generated at 2022-06-23 20:29:12.237708
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    usa.set_seed(10)
    assert usa.personality() == 'ISFJ'
    assert usa.personality() == 'INFJ'
    assert usa.personality() == 'ESTJ'
    assert usa.personality() == 'ENTJ'
    assert usa.personality() == 'ISFJ'

    assert usa.personality(category='rheti') == 6
    assert usa.personality(category='rheti') == 2
    assert usa.personality(category='rheti') == 10
    assert usa.personality(category='rheti') == 7
    assert usa.personality(category='rheti') == 9



# Generated at 2022-06-23 20:29:19.084165
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    usps = usa_provider.tracking_number(service = 'usps')
    fedex = usa_provider.tracking_number(service = 'fedex')
    ups = usa_provider.tracking_number(service = 'ups')

    print(usps)
    print(fedex)
    print(ups)


# Generated at 2022-06-23 20:29:22.429068
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.builtins import USASpecProvider

    usa_spec_provider = USASpecProvider()

    for _ in range(10):
        result = usa_spec_provider.ssn()
        assert len(result) == 11

# Generated at 2022-06-23 20:29:25.086320
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    for _ in range(10):
        ssn = USASpecProvider().ssn()
        assert isinstance(ssn, str)
        assert ssn == ssn.strip()
    

# Generated at 2022-06-23 20:29:27.500195
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa != None
    assert isinstance(usa, USASpecProvider)


# Generated at 2022-06-23 20:29:31.392686
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert len(provider.ssn()) == 11
    assert provider.ssn()[3] == '-'
    assert provider.ssn()[6] == '-'
    assert provider.ssn()[0:3].isdigit()
    assert provider.ssn()[4:6].isdigit()
    assert provider.ssn()[7:].isdigit()


# Generated at 2022-06-23 20:29:33.439257
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    number = provider.tracking_number()
    assert number is not None


# Generated at 2022-06-23 20:29:34.702798
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    x = USASpecProvider()
    assert x.personality(category='unknown') is None

# Generated at 2022-06-23 20:29:36.905422
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    mbti = provider.personality()
    assert type(mbti) is str


# Generated at 2022-06-23 20:29:44.301006
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider"""
    
    usa_provider = USASpecProvider(seed=100)
    
    # Test 1
    tracking_number = usa_provider.tracking_number(service="fedex")
    
    assert tracking_number == "4918 8411 6"
    
    # Test 2
    tracking_number = usa_provider.tracking_number(service="ups")
    
    assert tracking_number == "1Z 2S 595 2S6 638U 37"
    
    # Test 3
    tracking_number = usa_provider.tracking_number()
    
    assert tracking_number == "1300 0775 2474 US"
    
    

# Generated at 2022-06-23 20:29:47.427332
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.__class__.__name__ == "USASpecProvider"  # Constructor for class USASpecProvider


# Generated at 2022-06-23 20:29:53.738230
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    personality = provider.personality()
    assert personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                'ISTP', 'ISFP', 'INFP', 'INTP',
                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    personality = provider.personality(category='rheti')
    assert personality in range(1, 11)

# Generated at 2022-06-23 20:29:58.139119
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    for i in range(0, 10):
        assert type(us.personality()) == str
    for i in range(0, 10):
        assert type(us.personality("rheti")) == int


# Generated at 2022-06-23 20:29:59.947544
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    a = USASpecProvider()
    assert a.personality('rheti') == a.personality('rheti')

# Generated at 2022-06-23 20:30:00.794399
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.provider == 'usa_provider'


# Generated at 2022-06-23 20:30:09.886966
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    sp = USASpecProvider()
    assert sp.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                     'ISTP', 'ISFP', 'INFP', 'INTP',
                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

    assert sp.personality(category='rheti') in range(1,10)
    assert sp.personality(category='rheti') == sp.personality(category='rheti')

    assert sp.personality(category='mbti') == sp.personality(category='mbti')

    assert sp.personality(category='mbti') == sp.personality(category='mbti')

# Generated at 2022-06-23 20:30:15.662800
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider"""

    usa_provider = USASpecProvider()

    ssn_list = []
    for i in range(10):
        ssn_list.append(usa_provider.ssn())

    d = {}
    for i in ssn_list:
        d[i] = d.get(i, 0) + 1  # 次数加1

    if d.keys() == ssn_list:  # ssn_list即可以作为key也可以作为value，说明不能有相同的ssn
        print("test_USASpecProvider_ssn: PASS")
    else:
        print("test_USASpecProvider_ssn: FAIL")




# Generated at 2022-06-23 20:30:23.006619
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test USASpecProvider.tracking_number"""
    from ._fixtures.providers.usa_provider import test_data

    # Test by using USPS.
    data = test_data['usps']
    usps_number = test_data['usps_number']
    usa_tracking_number = data['usa_tracking_number']
    usa_tracking_number_mask = data['usa_tracking_number_mask']
    assert usps_number('USPS') == usa_tracking_number

    # Test by using FedEx.
    data = test_data['fedex']
    fedex_number = test_data['fedex_number']
    usa_tracking_number = data['usa_tracking_number']
    usa_tracking_number_mask = data['usa_tracking_number_mask']
    assert fedex

# Generated at 2022-06-23 20:30:30.996844
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.builtins import USASpecProvider

    usa_spec_provider = USASpecProvider('en') # seed = None

    test_ssn = usa_spec_provider.ssn()
    test_tracking_number = usa_spec_provider.tracking_number()
    test_personality = usa_spec_provider.personality()

    print('ssn: ', test_ssn)
    print('tracking number (USPS): ', test_tracking_number)
    print('personality: ', test_personality)

if __name__ == "__main__":
    test_USASpecProvider()

# Generated at 2022-06-23 20:30:33.848123
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider is not None
    assert provider.__class__.__name__ == 'USASpecProvider'

# Generated at 2022-06-23 20:30:37.208793
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    sp = USASpecProvider()
    assert(not sp.ssn().startswith("666"))
    assert(len(sp.ssn()) == 11)
    assert('-' in sp.ssn())
    assert(sp.ssn().count('-') == 2)


# Generated at 2022-06-23 20:30:40.621396
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    obj = USASpecProvider()
    result = obj.ssn()
    assert len(result) == 11
    assert result[3]=='-'
    assert result[6]=='-'
    assert ' ' not in result


# Generated at 2022-06-23 20:30:42.782387
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method ssn."""
    ssn = USASpecProvider().ssn()
    assert len(ssn.split('-')) == 3

# Generated at 2022-06-23 20:30:47.502395
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Initialize instance
    usa_spec_provider = USASpecProvider()

    # Generate an random SSN
    random_ssn = usa_spec_provider.ssn()
    ssn_list = random_ssn.split("-")
    # Area
    assert len(ssn_list[0]) == 3
    # Group
    assert len(ssn_list[1]) == 2
    # Serial
    assert len(ssn_list[2]) == 4

    # Generate an specific SSN
    specific_ssn = usa_spec_provider.ssn(seed=1)
    ssn_list = specific_ssn.split("-")
    # Area
    assert int(ssn_list[0]) == 1
    # Group

# Generated at 2022-06-23 20:30:52.919558
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider(seed=42)
    assert(usa_provider.personality("mbti") == "INTJ")
    assert(usa_provider.personality("rheti") == 3)



# Generated at 2022-06-23 20:30:55.904162
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number('usps')
    assert usa.tracking_number('fedex')
    assert usa.tracking_number('ups')


# Generated at 2022-06-23 20:31:00.461617
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.providers.usa import USASpecProvider

    usa_provider = USASpecProvider()

    assert len(usa_provider.ssn()) == 11
    assert usa_provider.ssn().count('-') == 2
    assert usa_provider.ssn().startswith('666') == False


# Generated at 2022-06-23 20:31:08.127003
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality('mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    )
    assert provider.personality('rheti') in range(1, 11)



# Generated at 2022-06-23 20:31:12.340640
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # noinspection PyTypeChecker
    USASpecProvider = USASpecProvider(seed=3)
    assert USASpecProvider.ssn() == '087-12-2052'

# Generated at 2022-06-23 20:31:16.163921
# Unit test for method tracking_number of class USASpecProvider

# Generated at 2022-06-23 20:31:17.598093
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    usa.tracking_number()


# Generated at 2022-06-23 20:31:25.260686
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    for _ in range(100):
        assert us.personality(category='rheti') in range(1, 11)
        assert us.personality(category='mbti') in ('ISFJ', 'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                   'ISTP', 'ISFP', 'INFP', 'INTP',
                                                   'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                   'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:31:29.113561
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method ssn of class USASpecProvider."""
    usa_ssn_generator = USASpecProvider()

    value_for_test = usa_ssn_generator.ssn()
    assert(len(value_for_test) == 11)
    assert(value_for_test == usa_ssn_generator.ssn())


# Generated at 2022-06-23 20:31:40.229010
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    e = USASpecProvider()

    assert e.ssn() == '569-66-5801'
    assert e.ssn() == '819-23-9027'
    assert e.ssn() == '978-51-0531'
    assert e.ssn() == '449-84-3412'
    assert e.ssn() == '546-86-1048'
    assert e.ssn() == '971-51-5028'
    assert e.ssn() == '120-51-4955'
    assert e.ssn() == '799-61-8464'
    assert e.ssn() == '761-44-0349'
    assert e.ssn() == '909-40-1591'
    assert e.ssn() == '399-74-9222'

# Generated at 2022-06-23 20:31:43.906773
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    print("\nUnit test for method 'tracking_number' of class 'USASpecProvider'.")
    for i in range(100):
        print(USASpecProvider().tracking_number('ups'))
    print("\nUnit test for method 'tracking_number' of class 'USASpecProvider' DONE.")



# Generated at 2022-06-23 20:31:51.872524
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    p = USASpecProvider()
    out = p.ssn()
    assert len(out) == 11
    assert all(x.isdigit() for x in out[0:3])
    assert all(x.isdigit() for x in out[4:6])
    assert all(x.isdigit() for x in out[7:11])
    assert out[3] == '-'
    assert out[6] == '-'
    assert (int)(out[0:3]) not in (666, 900)



# Generated at 2022-06-23 20:31:53.743171
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    print(usa.ssn())



# Generated at 2022-06-23 20:31:54.864382
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert bool(USASpecProvider()) == True

# Generated at 2022-06-23 20:32:03.804446
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Check if method ssn of class USASpecProvider works correctly."""
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.identification import Identification
    import re
    import pandas as pd
    
    mimesis = Person('en')
    mimesis_address = Address('en')
    mimesis_identification = Identification('en') # 'uk'

    # Generate 10,000 random SSNs
    data = []
    for i in range(10000):
        name = mimesis.full_name(gender=Gender.FEMALE)
        address = mimesis_address.street_name()
        city = mimesis_address.city()
        state = mimesis

# Generated at 2022-06-23 20:32:14.315331
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    from mimesis.providers.us_provider import USASpecProvider
    usps_track_number = USASpecProvider(seed=4).tracking_number()
    assert usps_track_number == "0MPR 52634 0101 2380 5414"
    fedex_track_number = USASpecProvider(seed=4).tracking_number(service="FedEx")
    assert fedex_track_number == "7922 5534 7336"
    ups_track_number = USASpecProvider(seed=4).tracking_number(service="UPS")
    assert ups_track_number == "1Z8W826A0249054034"


# Generated at 2022-06-23 20:32:18.638710
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider(seed=0)
    assert p.personality('mbti') == 'ENTJ'
    assert p.personality('rheti') == 9
    assert p.personality('rheti') == 4


# Generated at 2022-06-23 20:32:21.204945
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Using the constructor of a class USASpecProvider
    usa = USASpecProvider()
    # assert
    assert isinstance(usa, USASpecProvider)


# Generated at 2022-06-23 20:32:26.699277
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert USASpecProvider.personality('rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-23 20:32:29.004395
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number()


# Generated at 2022-06-23 20:32:34.644897
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Check method personality of class USASpecProvider."""
    assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:32:37.908874
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    assert usa.ssn() == '534-79-3335'


# Generated at 2022-06-23 20:32:39.536686
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider
    assert provider.random



# Generated at 2022-06-23 20:32:40.703001
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    up = USASpecProvider()
    assert up.ssn() != up.ssn()

# Generated at 2022-06-23 20:32:44.249474
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert type(usa.ssn()) == str
    assert type(usa.tracking_number()) == str
    assert type(usa.personality()) == str

# Generated at 2022-06-23 20:32:47.889508
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider(seed=1)
    # returns 1 for a category == 'rheti'
    assert p.personality(category='rheti') == 1
    # returns 'INTP' for a category == 'mbti'
    assert p.personality(category='mbti') == 'INTP'

# Generated at 2022-06-23 20:32:57.641289
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    # Test unlimited number of times
    for i in range(0, 100):
        result = provider.ssn()
        assert type(result) is str
        assert len(result) == 11
        assert result[3] == '-'
        assert result[6] == '-'
        assert len(result[:3]) == 3
        assert len(result[4:6]) == 2
        assert len(result[7:]) == 4
        assert result[:3].isdigit()
        assert result[4:6].isdigit()
        assert result[7:].isdigit()
        assert result[:3] != '666'
    assert True


# Generated at 2022-06-23 20:32:58.692299
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    a = USASpecProvider(seed=1)
    assert a.name != None

# Generated at 2022-06-23 20:33:01.656895
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert usa_provider.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:33:07.146334
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test function tracking_number of class USASpecProvider."""

    provider = USASpecProvider()
    number = provider.tracking_number('usps')
    assert ' ' in number
    assert len(number) == 22

    number = provider.tracking_number('ups')
    assert ' ' not in number
    assert len(number) == 18

    number = provider.tracking_number('fedex')
    assert ' ' in number
    assert len(number) == 14


# Generated at 2022-06-23 20:33:12.729776
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    
    fruit = USASpecProvider()
    
    #tracking number
    fruit.tracking_number()
    fruit.tracking_number('USPS')
    
    #ssn
    fruit.ssn()
    
    #personality
    fruit.personality()
    fruit.personality('MBTI')
    fruit.personality('RHETI')

# Generated at 2022-06-23 20:33:21.755990
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    person = USASpecProvider()
    person1 = USASpecProvider()
    person2 = USASpecProvider()
    assert(person.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                    'ISTP', 'ISFP', 'INFP', 'INTP',
                                    'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                    'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'])
    assert(person1.personality("rheti") in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

# Generated at 2022-06-23 20:33:24.059924
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    for i in range(1):
        usa_provider = USASpecProvider()
        ssn = usa_provider.ssn()
        assert len(ssn) == 11
        assert ssn[0:3] != '666'

# Generated at 2022-06-23 20:33:26.990665
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert len(USASpecProvider().personality('mbti')) == 4
    assert type(USASpecProvider().personality('rheti')) == int


# Generated at 2022-06-23 20:33:34.138892
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    data = ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
            'ISTP', 'ISFP', 'INFP', 'INTP',
            'ESTP', 'ESFP', 'ENFP', 'ENTP',
            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    item = USASpecProvider()
    r = item.personality()
    assert isinstance(r, str)
    assert r in data

# Generated at 2022-06-23 20:33:42.994766
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.enums import PostService
    from mimesis.providers.usa_provider import USASpecProvider

    usa_spec_provider = USASpecProvider()
    usps_tracking_number = usa_spec_provider.tracking_number(PostService.USPS)
    assert len(usps_tracking_number) == 22

    fedex_tracking_number = usa_spec_provider.tracking_number(PostService.FEDEX)
    assert len(fedex_tracking_number) in (12, 15)

    ups_tracking_number = usa_spec_provider.tracking_number(PostService.UPS)
    assert len(ups_tracking_number) == 18


# Generated at 2022-06-23 20:33:45.694672
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert type(ssn) == str


# Generated at 2022-06-23 20:33:47.819410
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    prov = USASpecProvider()
    assert prov.ssn().find('-') != -1


# Generated at 2022-06-23 20:33:49.841129
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality("rheti") >= 1
    assert USASpecProvider().personality("rheti") <= 10

# Generated at 2022-06-23 20:33:51.546924
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    ssn = USASpecProvider().tracking_number()
    assert len(ssn) > 0
    assert isinstance(ssn, str)


# Generated at 2022-06-23 20:33:55.192595
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number('usps') is not None
    assert provider.tracking_number('fedex') is not None
    assert provider.tracking_number('ups') is not None


# Generated at 2022-06-23 20:33:57.472366
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
	up = USASpecProvider()
	test_data = up.personality()
	print(test_data)


# Generated at 2022-06-23 20:34:01.610072
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for USASpecProvider"""
    u = USASpecProvider()

    assert u.random.seed is not None
    assert isinstance(u.random.seed, int) is True
    assert u.random.seed >= 0 and u.random.seed < 999_999


# Generated at 2022-06-23 20:34:03.529522
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider(seed=0)
    assert usa.name == 'usa_provider'


# Generated at 2022-06-23 20:34:07.756501
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert (usa.personality(category='rheti') >= 1 and usa.personality(category='rheti') <= 10)
    assert (usa.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'))
    assert (usa.personality(category='test') == None)

# Generated at 2022-06-23 20:34:13.234438
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Create an instance of class USASpecProvider
    usa_provider = USASpecProvider()
    # Call the method
    ssn = usa_provider.ssn()
    print(str(ssn) + " is a sample number of SSN")


# Generated at 2022-06-23 20:34:18.157976
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    subj = USASpecProvider()
    assert subj.personality() == subj.personality()
    assert subj.personality(category='rheti') == subj.personality(category='rheti')
    assert subj.personality(category='anything') == subj.personality()


# Generated at 2022-06-23 20:34:20.154095
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert isinstance(usa_spec_provider, USASpecProvider)



# Generated at 2022-06-23 20:34:22.738243
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert 'USASpecProvider' in globals()


# Generated at 2022-06-23 20:34:24.871738
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    r = USASpecProvider(seed=0)
    assert r.ssn() == '666-69-7465'


# Generated at 2022-06-23 20:34:30.953225
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    x = usa_spec_provider.personality()
    assert x in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:34:32.385027
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.provider == 'usa_provider'



# Generated at 2022-06-23 20:34:36.066112
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:34:38.302806
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_provider = USASpecProvider()
    tracking_number = us_provider.tracking_number()
    assert isinstance(tracking_number, str)


# Generated at 2022-06-23 20:34:46.197512
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider(seed=0)

    # USPS
    assert provider.tracking_number(service='USPS') == '072745337735 5704'
    # FedEx
    assert provider.tracking_number(service='FedEx') == '0805 9345 8986'
    # UPS
    assert provider.tracking_number(service='UPS') == '1Z6314A61009454444'
    # invalid service
    try:
        provider.tracking_number('Canada Post')
    except ValueError:
        assert True


# Generated at 2022-06-23 20:34:49.933093
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider(seed=8888)
    assert us.ssn() == "878-43-8254"


# Generated at 2022-06-23 20:34:51.481837
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() == '565-66-5801'


# Generated at 2022-06-23 20:34:53.780819
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for function tracking_number."""
    assert isinstance(USASpecProvider().tracking_number(), str)



# Generated at 2022-06-23 20:34:55.487543
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert(provider is not None)