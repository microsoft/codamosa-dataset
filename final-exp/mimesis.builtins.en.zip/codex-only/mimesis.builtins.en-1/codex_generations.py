

# Generated at 2022-06-23 20:24:56.147013
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider().tracking_number()
    assert USASpecProvider().personality()
    assert USASpecProvider().personality('rheti')
    assert USASpecProvider().ssn()

# Generated at 2022-06-23 20:24:58.169590
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.tracking_number()
    assert usa.ssn()
    assert usa.personality()


# Generated at 2022-06-23 20:24:59.053706
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert isinstance(USASpecProvider().personality(), str)


# Generated at 2022-06-23 20:25:04.528853
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'] or isinstance(provider.personality('rheti'), int)

# Generated at 2022-06-23 20:25:06.326372
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test SSN generator."""
    ssn = USASpecProvider().ssn()
    assert len(ssn) == 11

# Generated at 2022-06-23 20:25:11.246907
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tn1 = provider.tracking_number(service='usps')
    tn2 = provider.tracking_number(service='ups')
    tn3 = provider.tracking_number(service='fedex')
    assert tn1 != tn2 != tn3


# Generated at 2022-06-23 20:25:13.020868
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for test_USASpecProvider_tracking_number."""
    assert USASpecProvider().tracking_number(service='usps')


# Generated at 2022-06-23 20:25:14.733970
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    spe = USASpecProvider()
    assert spe.seed == None


# Generated at 2022-06-23 20:25:16.747271
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)


# Generated at 2022-06-23 20:25:22.332240
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    seed = 12345678

    # USPS
    usps = USASpecProvider(seed)
    assert usps.tracking_number(service='usps') == 'XGCV #OXO #HOR #VGI #OIO'

    # FedEx
    fedex = USASpecProvider(seed)
    assert fedex.tracking_number(service='fedex') == 'AAKE #APU'

    # UPS
    ups = USASpecProvider(seed)
    assert ups.tracking_number(service='ups') == '1Z18E79W7530534040'

# Generated at 2022-06-23 20:25:29.090774
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()

    assert usa.ssn() is not None
    assert usa.personality() is not None
    assert usa.tracking_number('usps') is not None
if __name__ == "__main__":
    usa = USASpecProvider()

    assert usa.ssn() is not None
    assert usa.personality() is not None
    assert usa.tracking_number('usps') is not None

# Generated at 2022-06-23 20:25:32.117808
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert type(usa_provider.personality()) == str
    assert usa_provider.personality(category = 'rheti') in range(1, 11)

# Generated at 2022-06-23 20:25:34.105768
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    rpg = USASpecProvider()
    assert rpg.personality(category="rheti") in range(1, 10)
    assert rpg.personality(category="mbti") in mbtis

# Generated at 2022-06-23 20:25:36.422821
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    usa = USASpecProvider()
    ssn = usa.ssn()
    assert len(ssn) == 11

# Generated at 2022-06-23 20:25:39.193374
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityType

    personality = USASpecProvider().personality()

    assert PersonalityType[personality] in PersonalityType


# Generated at 2022-06-23 20:25:47.158825
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()

    assert usa.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                       'ISTP', 'ISFP', 'INFP', 'INTP',
                                       'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                       'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality('rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)


# Generated at 2022-06-23 20:25:49.627673
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
  actual = USASpecProvider().ssn()
  assert actual.isdigit()
  assert actual[0] != 0
  assert len(actual) == 11


# Generated at 2022-06-23 20:25:51.529203
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test ssn method."""
    usa = USASpecProvider()
    assert usa.ssn() != usa.ssn()

# Generated at 2022-06-23 20:25:56.226230
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaspectest = USASpecProvider()
    # Method personality()
    assert isinstance(usaspectest.personality(), str)
    # Method personality() with valid category argument
    assert isinstance(usaspectest.personality("mbti"), str)
    assert isinstance(usaspectest.personality("rheti"), int)
# End of unit tests for method personality



# Generated at 2022-06-23 20:25:59.031530
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    spec = USASpecProvider()
    assert spec.__class__ == USASpecProvider
    assert spec.Meta.name == 'usa_provider'


# Generated at 2022-06-23 20:26:03.446468
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']



# Generated at 2022-06-23 20:26:07.329634
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert 'USPS' in provider.tracking_number()
    assert 'FedEx' in provider.tracking_number('FedEx')



# Generated at 2022-06-23 20:26:10.409406
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()

    result = (usa_spec_provider.personality(category='mbti'))
    type(result) is str
    len(result) != 0
    len(result)


# Generated at 2022-06-23 20:26:12.787744
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider().__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:26:21.169055
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Given
    st = USASpecProvider()
    # When
    res = st.tracking_number('usps')
    print(res)
    assert_equal(res in ('#### #### #### #### ####', '@@ ### ### ### US'), True)
    # When
    res = st.tracking_number('fedex')
    print(res)
    assert_equal(res in ('#### #### ####', '#### #### #### ###'), True)
    # When
    res = st.tracking_number('ups')
    assert_equal(res, '1Z@####@##########')
    return True

# Generated at 2022-06-23 20:26:25.533463
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:26:26.375046
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11

# Generated at 2022-06-23 20:26:29.180581
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_spec_provider = USASpecProvider() # create an USASpecProvider object
    ssn = usa_spec_provider.ssn() # call function ssn on the object
    assert ssn == '875-66-5801'

# Generated at 2022-06-23 20:26:34.950498
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """BaseSpecProvider.ssn."""
    # Tested with https://www.ssnvalidator.com/
    usa_provider = USASpecProvider(seed=12345)
    ssn_test_data = [
        ('569-66-5801',),
        ('117-86-8750',),
        ('200-78-3520',),
        ('105-46-1961',),
        ('807-24-5449',),
        ('362-55-5541',),
        ('764-09-9183',),
        ('436-76-4197',),
        ('270-98-8443',),
        ('445-54-0881',),
    ]
    for test_data in ssn_test_data:
        assert usa_provider.ssn() == test_

# Generated at 2022-06-23 20:26:41.992712
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit testing USASpecProvider.tracking_number method.

    Return random valid postal tracking number.
    Supported services: USPS, FedEx and UPS
    """
    assert len(USASpecProvider().tracking_number()) == 22
    assert len(USASpecProvider().tracking_number('FedEx')) == 22
    assert len(USASpecProvider().tracking_number('UPS')) == 18



# Generated at 2022-06-23 20:26:43.815922
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    print(usa.personality(category="rheti"))


# Generated at 2022-06-23 20:26:47.094772
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Create a USASpecProvider object."""
    User = USASpecProvider()
    # print('User.personality() = ', User.personality(), '\n')
    assert User.personality()


# Generated at 2022-06-23 20:26:50.938744
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test class USASpecProvider."""
    usa = USASpecProvider()

    assert usa.ssn() == "835-45-4813" or usa.ssn() == "776-39-6084" or usa.ssn() == "670-75-4795"


# Generated at 2022-06-23 20:26:55.332409
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """
    Test method USASpecProvider.ssn
    """
    # Create random object
    from mimesis.enums import Gender, PersonPosition
    from mimesis.builtins import USASpecProvider
    usa = USASpecProvider()
    usa.random.seed(830)

    test_ssn = usa.ssn()
    assert test_ssn == '530-35-6343'

# Generated at 2022-06-23 20:26:57.747794
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn()[3] == '-'
    assert provider.ssn()[6] == '-'


# Generated at 2022-06-23 20:27:02.819544
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():

    seed = 'mimesis'
    service = 'usps'
    usa_spec_provider = USASpecProvider(seed=seed)
    tracking_number = usa_spec_provider.tracking_number(service=service)
    assert len(tracking_number) == 25


# Generated at 2022-06-23 20:27:06.159282
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()

    assert len(provider.tracking_number()) == 22
    assert len(provider.tracking_number('Fedex')) in (12, 15)
    assert len(provider.tracking_number('Ups')) == 18

# Generated at 2022-06-23 20:27:07.723934
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider(12345)
    assert provider.__init__(12345)


# Generated at 2022-06-23 20:27:14.968396
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Return true if argment is a valid ssn."""
    provider = USASpecProvider()
    ssn = provider.ssn()
    digit_list = ssn.split('-')
    first_digit = int(digit_list[0])
    second_digit = int(digit_list[1])
    third_digit = int(digit_list[2])
    assert 0 < first_digit < 900
    assert 0 < second_digit < 100
    assert 0 < third_digit < 10000



# Generated at 2022-06-23 20:27:19.610103
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for method tracking_number of class USASpecProvider"""
    provider = USASpecProvider()
    assert isinstance(provider.tracking_number('USPS'), str)
    assert isinstance(provider.tracking_number('Fedex'), str)
    assert isinstance(provider.tracking_number('UPS'), str)

# Generated at 2022-06-23 20:27:22.825473
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_provider = USASpecProvider()
    us_provider.tracking_number()
    us_provider.ssn()
    us_provider.personality()

# Generated at 2022-06-23 20:27:26.941016
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    print(usa_provider.personality('rheti'))
    print(usa_provider.personality('mbti'))


# Generated at 2022-06-23 20:27:28.964963
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_instance = USASpecProvider()
    assert isinstance(us_instance, USASpecProvider)


# Generated at 2022-06-23 20:27:31.540695
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    import re
    ssn = USASpecProvider().ssn()
    assert re.match('\d{3}-\d{2}-\d{4}', ssn) != None

# Generated at 2022-06-23 20:27:33.656265
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)


if __name__ == '__main__':
    test_USASpecProvider()

# Generated at 2022-06-23 20:27:39.859882
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    u = USASpecProvider() # Object of class

    assert hasattr(u, 'random') # random attribute (generated by mimesis)
    assert hasattr(u, 'Meta') # subclass Meta
    assert hasattr(u.Meta, 'name') # Meta.name attribute
    assert u.Meta.name == 'usa_provider' # Meta.name attribute value is 'usa_provider'
    assert hasattr(u, 'tracking_number') # tracking_number method
    assert hasattr(u, 'ssn') # ssn method
    assert hasattr(u, 'personality') # personality method


# Generated at 2022-06-23 20:27:42.509648
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print("test_USASpecProvider()")
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider is not None, 'Error USASpecProvider is None.'


# Generated at 2022-06-23 20:27:44.368956
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.random.provider_name == 'us_provider'


# Generated at 2022-06-23 20:27:54.726290
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test the constructor of class USASpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.en_US import USASpecProvider
    x = USASpecProvider()
    x.full_name(gender=Gender.FEMALE)
    print("Testing method full_name(gender=Gender.FEMALE) : "+ str(x.full_name(gender=Gender.FEMALE)))
    print("Testing method age(): "+ str(x.age()))
    print("Testing method address(): "+ str(x.address()))
    print("Testing method tracking_number(service='Fedex'): "+ str(x.tracking_number(service='Fedex')))
    print("Testing method ssn(): "+ str(x.ssn()))

# Generated at 2022-06-23 20:27:55.648610
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider()


# Generated at 2022-06-23 20:28:00.395940
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert usa_provider.__class__.__name__ == 'USASpecProvider'
    assert usa_provider.Meta.name == 'usa_provider'
    assert usa_provider.__dict__['locale'] == 'en'


# Generated at 2022-06-23 20:28:03.252471
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert callable(usa_provider.ssn) == True

# Generated at 2022-06-23 20:28:11.218861
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    exp = 'ISFJ'
    assert usa.personality() in mbtis
    assert usa.personality() == exp
    assert usa.personality(category='personality') in mbtis
    assert usa.personality('personality') == exp



# Generated at 2022-06-23 20:28:15.847927
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider
    If number of unit test executed is less than 10,
    an error will be reported.
    """
    assert len(set([USASpecProvider().tracking_number("usps") for i in range(10)])) == 10


# Generated at 2022-06-23 20:28:17.980130
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    import random
    random.seed(7)
    assert USASpecProvider().personality() == 'INFP'


# Generated at 2022-06-23 20:28:20.149010
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    us.personality(category='mbti')
    us.personality(category='rheti')

# Generated at 2022-06-23 20:28:21.839959
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() == '429-28-8477'


# Generated at 2022-06-23 20:28:30.567332
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Test the constructor
    r = USASpecProvider()
    assert hasattr(r, 'random')
    assert hasattr(r, 'datetime')
    assert hasattr(r, 'seed')
    assert hasattr(r, 'provider')
    assert hasattr(r, 'Meta')
    assert hasattr(r.Meta, 'name')
    assert hasattr(r, 'ssn')
    assert hasattr(r, 'tracking_number')
    assert hasattr(r, 'personality')


# Generated at 2022-06-23 20:28:33.025149
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tn = USASpecProvider()
    number = tn.tracking_number()
    assert len(number) > 10
    assert number.isalnum()

# Generated at 2022-06-23 20:28:40.589276
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    assert us.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert us.personality('rheti') >= 1 and us.personality('rheti') <=10

# Generated at 2022-06-23 20:28:48.933150
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():

    usa_provider = USASpecProvider()

    # Generate 100 random SSN
    for _ in range(100):
        ssn = usa_provider.ssn()
        assert ssn[0:3].isdigit()
        assert ssn[4:6].isdigit()
        assert ssn[7:11].isdigit()
        assert ssn[3] == '-'
        assert ssn[6] == '-'

        # 666 is not a valid area in SSN
        area = int(ssn[0:3])
        assert area != 666



# Generated at 2022-06-23 20:28:59.964322
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Copyright (c) 2019-present, Stanislav Pidhorskyi
    # All rights reserved.
    #
    # See the LICENSE file distributed with this work for terms.
    from mimesis.builtins.usa import USASpecProvider as USASP
    
    usasp = USASP()
    usps = usasp.tracking_number(service='usps')
    print(usps)
    assert isinstance(usps, str)
    assert len(usps) == 22

    fedex = usasp.tracking_number(service='fedex')
    print(fedex)
    assert isinstance(fedex, str)
    assert 10 <= len(fedex) <= 12

    ups = usasp.tracking_number(service='ups')
    print(ups)
    assert isinstance(ups, str)


# Generated at 2022-06-23 20:29:03.222379
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number(service = 'usps') is not None


# Generated at 2022-06-23 20:29:06.249778
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_ssn = USASpecProvider(seed='test')
    assert usa_ssn.ssn() == '418-75-6919'

# Generated at 2022-06-23 20:29:07.615524
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec = USASpecProvider()
    assert usa_spec.__str__() == 'USASpecProvider'

# Generated at 2022-06-23 20:29:09.655551
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():

    spec_provider = USASpecProvider()

    assert type(spec_provider.tracking_number()) == str


# Generated at 2022-06-23 20:29:13.666303
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    spec_provider = USASpecProvider()
    print(spec_provider.tracking_number())
    print(spec_provider.tracking_number('fedex'))
    print(spec_provider.tracking_number('ups'))



# Generated at 2022-06-23 20:29:24.257559
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.random.choice == provider.random.choice
    assert provider.random.randint == provider.random.randint
    assert provider.random.custom_code == provider.random.custom_code
    assert provider.random.choice_bool == provider.random.choice_bool
    assert provider.random.choice_hash == provider.random.choice_hash
    assert provider.random.choice_sha1 == provider.random.choice_sha1
    assert provider.random.choice_sha2 == provider.random.choice_sha2
    assert provider.random.choice_fqdn == provider.random.choice_fqdn
    assert provider.random.choice_domain_name == provider.random.choice_domain_name
    assert provider.random.choice_ipv4 == provider.random.choice_ipv4


# Generated at 2022-06-23 20:29:25.422659
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    x = USASpecProvider()
    assert x.random.randint(1, 99) != x.random.randint(1, 99)


# Generated at 2022-06-23 20:29:26.317184
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert 'ISFJ' in provider.personality()


# Generated at 2022-06-23 20:29:28.619358
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    result = provider.ssn()
    print(result)
    assert str(result).count('-') == 2
    #assert len(result) == 11


# Generated at 2022-06-23 20:29:31.706244
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us_provider = USASpecProvider()
    ssn = us_provider.ssn()
    list_ssn=ssn.split('-')
    assert int(list_ssn[0]) != 666

# Generated at 2022-06-23 20:29:33.342158
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11


# Generated at 2022-06-23 20:29:35.206975
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert len(usa.tracking_number()) > 0



# Generated at 2022-06-23 20:29:38.462939
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider_ssn_obj = USASpecProvider(seed=19)
    result = usa_provider_ssn_obj.ssn()
    assert result == '829-89-0661'



# Generated at 2022-06-23 20:29:42.409452
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    prov = USASpecProvider()
    assert prov.tracking_number(service='fedex') == '#### #### ####' or '#### #### #### ###'
    assert prov.tracking_number(service='usps') == '#### #### #### #### ####' or '@@ ### ### ### US'
    assert prov.tracking_number(service='ups') == '1Z@####@##########'


# Generated at 2022-06-23 20:29:44.457556
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test USASpecProvider's ssn()."""
    us_provider = USASpecProvider()
    print('us_provider.ssn() -->', us_provider.ssn())


# Generated at 2022-06-23 20:29:51.737119
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider"""
    import random
    from mimesis.enums import PersonalityTypes
    from mimesis.builtins import USASpecProvider
    from mimesis.typing import Seed

    seed = Seed(1)
    person_instance = USASpecProvider(seed)

    category = random.choice([PersonalityTypes.MBTI, PersonalityTypes.REHTI])

    result = person_instance.personality(category=category)
    print(result)

# Generated at 2022-06-23 20:29:55.133569
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a = USASpecProvider()
    s = a.tracking_number()
    assert isinstance(s, str)


# Generated at 2022-06-23 20:30:01.382281
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    obj = USASpecProvider(100)
    result = obj.personality()
    assert type(result) is str
    result = obj.personality('mbti')
    assert type(result) is str
    result = obj.personality('rheti')
    assert type(result) is int
    result = obj.personality('')
    assert type(result) is str
    result = obj.personality('invalid')
    assert type(result) is str

# Generated at 2022-06-23 20:30:04.105295
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking_num = provider.tracking_number()
    assert type(tracking_num) == str and len(tracking_num) == 29


# Generated at 2022-06-23 20:30:11.867171
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method tracking_number of class USASpecProvider."""
    provider = USASpecProvider()
    provider.raw('service', 'usps')
    provider.raw('tracking', '#### #### #### #### ####')
    result_usps = provider.tracking_number()
    assert result_usps

    provider.raw('service', 'fedex')
    provider.raw('tracking', '#### #### ####')
    result_fedex = provider.tracking_number()
    assert result_fedex

    provider.raw('service', 'ups')
    provider.raw('tracking', '1Z@####@##########')
    result_ups = provider.tracking_number()
    assert result_ups

    num = provider.tracking_number(service='usps')
    assert isinstance(num, str)

# Generated at 2022-06-23 20:30:20.644463
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test case for method tracking_number of class USASpecProvider."""
    provider = USASpecProvider(seed=1234567890)
    test_data = [
        ('1Z9999999999999999',  'usps'),
        ('9999 9999 9999 9999 9999',  'usps'),
        ('SS 999 999 999 US',  'usps'),
        ('9999 9999 999',  'fedex'),
        ('9999 9999 9999 999',   'fedex'),
        ('1Z9999999999999999',  'ups'),
    ]
    result = provider.tracking_number()
    assert result == '919-99-9999'



# Generated at 2022-06-23 20:30:23.243251
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert (provider.ssn() == '569-66-5801')


# Generated at 2022-06-23 20:30:27.967027
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert isinstance(ssn, str)
    assert '-' in ssn
    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'


# Generated at 2022-06-23 20:30:36.498025
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    t = USASpecProvider()

    # USPS
    tn = t.tracking_number(service='usps')
    assert tn.startswith('94')
    assert tn.endswith('US')
    assert tn.count(' ') == 4

    # FedEx
    tn = t.tracking_number(service='fedex')
    assert tn.startswith('96')
    assert tn.count(' ') == 2

    # UPS
    tn = t.tracking_number(service='ups')
    assert tn.startswith('1Z')
    assert ' ' not in tn


# Generated at 2022-06-23 20:30:37.373627
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()

# Generated at 2022-06-23 20:30:40.437821
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # initialize USASpecProvider object
    example = USASpecProvider()
    # initialize tracking_number
    result = example.tracking_number()
    assert isinstance(result, str)
    assert result


# Generated at 2022-06-23 20:30:45.088302
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    assert us.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:30:52.086338
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    string = usa.tracking_number(service='usps')
    assert len(string) > 0
    string = usa.personality()
    assert len(string) > 0
    string = usa.ssn()
    assert len(string) > 0
    int_value = usa.personality(category='rheti')
    assert isinstance(int_value, int)

# Generated at 2022-06-23 20:30:54.922101
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    a = USASpecProvider()
    assert a.ssn() != a.ssn()
    assert len(a.ssn()) == 11


# Generated at 2022-06-23 20:30:56.823339
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    result = usa_spec_provider.tracking_number()
    assert type(result) == str


# Generated at 2022-06-23 20:31:04.784816
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()

    dict_rheti_valid_types = {
        'rheti': 'int',
        'mbti': 'str',
    }

# Generated at 2022-06-23 20:31:06.443082
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.random.__class__.__name__=='Generator'


# Generated at 2022-06-23 20:31:08.003262
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == '573-42-6914'


# Generated at 2022-06-23 20:31:11.217205
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() is not None


# Generated at 2022-06-23 20:31:19.926333
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    for i in range(100):
        # Create a class instance
        p = USASpecProvider()
        number = p.random.randint()
        ssn = p.ssn()
        # tracking_number returns a random tracking number
        assert len(p.tracking_number()) > 0
        assert isinstance(p.tracking_number(), str)
        # ssn returns a random, but valid SSN
        assert len(ssn) == 11
        assert ssn.count('-') == 2
        assert ssn[0:3].isdigit()
        assert ssn[4:6].isdigit()
        assert ssn[7:11].isdigit()
        if ssn[0:3] != '666':
            assert ssn[0:3].isdigit()

# Generated at 2022-06-23 20:31:23.088912
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    usa_spec_provider = USASpecProvider(seed=123)

    assert usa_spec_provider.personality(category='mbti') == 'ENFJ'


# Generated at 2022-06-23 20:31:30.748446
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a = USASpecProvider()
    b = USASpecProvider(a.seed)
    # The mask of USPS is '#### #### #### #### ####'
    tracking_number_usps = a.tracking_number('usps')
    assert len(tracking_number_usps) == 29
    assert tracking_number_usps == b.tracking_number('usps')

    # The mask of FedEx is '#### #### ####' and '#### #### #### ###'
    tracking_number_fedex = a.tracking_number('fedex')
    tracking_number_length = len(tracking_number_fedex)
    assert tracking_number_length == 13 or tracking_number_length == 17
    assert tracking_number_fedex == b.tracking_number('fedex')

    # The mask of UPS is '1Z@

# Generated at 2022-06-23 20:31:38.282525
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    import re
    import random

    # Initialize seed
    seed = random.randint(0,10000)
    random.seed(seed)    
    
    # Set up data provider
    usa = USASpecProvider(seed=seed)
    
    # Perform unit test
    assert re.match(r'[0-9]{3}\-[0-9]{2}\-[0-9]{4}', usa.ssn())



# Generated at 2022-06-23 20:31:40.308216
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    val = USASpecProvider()
    assert val != None
    val = USASpecProvider('seed')
    assert val != None


# Generated at 2022-06-23 20:31:41.301772
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert 'usa_provider' == provider.Meta.name

# Generated at 2022-06-23 20:31:45.462212
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    usp = USASpecProvider()
    print(usp.tracking_number())


# Generated at 2022-06-23 20:31:48.505189
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print('test_USASpecProvider: Start testing')
    objUSASpecProvider = USASpecProvider()
    print(objUSASpecProvider)


# Generated at 2022-06-23 20:31:52.374032
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():  # IGNORE:C01303
    a = USASpecProvider()
    assert a.personality().isalpha()

    b = USASpecProvider()
    assert b.personality(category='rheti').isdigit()


# Generated at 2022-06-23 20:31:57.222600
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    ssn = usa_provider.ssn()    # example: 569-66-5801
    print('Social Security Number (SSN) of citizen from the USA:', ssn)

if __name__ == '__main__':
    test_USASpecProvider_ssn()

# Generated at 2022-06-23 20:32:04.404898
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    tracking_number1 = usa_spec_provider.tracking_number('usps')
    tracking_number2 = usa_spec_provider.tracking_number('fedex')
    tracking_number3 = usa_spec_provider.tracking_number('ups')
    tracking_number4 = usa_spec_provider.tracking_number('abc')

    # Asserts
    assert len(tracking_number1) == 22
    assert len(tracking_number2) == 13 or len(tracking_number2) == 16
    assert len(tracking_number3) == 17
    assert tracking_number4 == '9X8 131 442 FR'


# Generated at 2022-06-23 20:32:05.949415
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() is not None


# Generated at 2022-06-23 20:32:12.665615
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    actual_result = USASpecProvider().tracking_number()
    actual_result_1 = USASpecProvider().tracking_number('ups')
    actual_result_2 = USASpecProvider().tracking_number('fedex')
    actual_result_3 = USASpecProvider().tracking_number('usps')

    assert (actual_result == actual_result_3 or actual_result == actual_result_1 or actual_result == actual_result_2)

# Generated at 2022-06-23 20:32:14.468503
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider


# Generated at 2022-06-23 20:32:24.379437
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider(seed=123)
    ssns = []
    for i in range(0, 50):
        ssns.append(usa_provider.ssn())


# Generated at 2022-06-23 20:32:31.750291
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us_spec = USASpecProvider()
    assert us_spec.ssn() == '814-82-4182'
    assert us_spec.ssn() == '219-27-1699'
    assert us_spec.ssn() == '569-66-5801'
    assert us_spec.ssn() == '277-49-6421'
    assert us_spec.ssn() == '841-57-8862'

# Generated at 2022-06-23 20:32:34.511397
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    u = USASpecProvider()
    assert u.tracking_number("usps")
    assert u.tracking_number("fedex")
    assert u.tracking_number("ups")


# Generated at 2022-06-23 20:32:42.489845
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    s = USASpecProvider()
    assert s.personality() in ("ESTJ","ENFP","INTP","ESTP","ESFJ","ESFP","ENTJ","ISTJ","ISFJ","ISTP","ISFP","INFP","INFJ","ENFJ","ENTP","INTJ")
    assert 0 < s.personality("rheti") < 11
    assert s.personality("unknown_type") in ("ESTJ","ENFP","INTP","ESTP","ESFJ","ESFP","ENTJ","ISTJ","ISFJ","ISTP","ISFP","INFP","INFJ","ENFJ","ENTP","INTJ")

# Generated at 2022-06-23 20:32:51.221871
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    provider = USASpecProvider()
    result_1 = provider.personality()
    result_2 = provider.personality()

    assert result_1 in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                        'ISTP', 'ISFP', 'INFP', 'INTP',
                        'ESTP', 'ESFP', 'ENFP', 'ENTP',
                        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert result_2 in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                        'ISTP', 'ISFP', 'INFP', 'INTP',
                        'ESTP', 'ESFP', 'ENFP', 'ENTP',
                        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:32:55.826676
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    myUSASpecProvider = USASpecProvider()
    tracking_number = myUSASpecProvider.tracking_number(service = 'usps')
    print(tracking_number)
    assert (len(tracking_number) > 0)
    assert (len(tracking_number) < 32)


# Generated at 2022-06-23 20:32:59.656951
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method tracking_number."""
    assert USASpecProvider().tracking_number(service='usps').__len__() == 32
    assert USASpecProvider().tracking_number(service='usps').__len__() == 26
    assert USASpecProvider().tracking_number(service='fedex').__len__() == 22
    assert USASpecProvider().tracking_number(service='ups').__len__() == 20


# Generated at 2022-06-23 20:33:01.520920
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test constructor of class USASpecProvider"""
    provider = USASpecProvider()
    assert isinstance(provider, USASpecProvider)


# Generated at 2022-06-23 20:33:07.588629
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    mbtis = ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    usa = USASpecProvider(seed=42)
    assert usa.personality(category='mbti') in mbtis
    assert type(usa.personality(category='rheti')) == int
    # Test for unit test: test_USASpecProvider_personality
    assert usa.personality(category='rheti') == 9
    assert usa.personality(category='mbti') == 'ENFP'

# Generated at 2022-06-23 20:33:18.219913
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    # Make an instance of USASpecProvider
    provider = USASpecProvider()
    # Generate a random, but valid SSN
    ssn = provider.ssn()

    assert isinstance(ssn, str)
    assert len(ssn) == 11
    # First number can't be 666 or 900-999
    assert ssn[:3] != '666'
    assert 900 <= int(ssn[:3]) <= 999
    # Second number can't be 00
    assert ssn[4:6] != '00'
    # Last number can't be 0000
    assert ssn[-4:] != '0000'

    for i in (3, 6):
        assert ssn[i] == '-'

    # Run test 100 times

# Generated at 2022-06-23 20:33:29.533662
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Note: ssn is not a constant, but for this test we will assume it is
    result = str(USASpecProvider().ssn())
    # Check the format of the string is what we expect
    assert len(result) == 11
    assert result[3] == '-'
    assert result[6] == '-'
    values = result[0:3], result[4:6], result[7:11]
    # Check the digits are all numeric
    assert values[0].isnumeric()
    assert values[1].isnumeric()
    assert values[2].isnumeric()
    # Check the values are within acceptable ranges
    assert 0 <= int(values[0]) <= 899
    assert 0 <= int(values[1]) <= 99
    assert 0 <= int(values[2]) <= 9999

# Generated at 2022-06-23 20:33:31.732657
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert len(provider.tracking_number()) > 0


# Generated at 2022-06-23 20:33:34.174941
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Test for 'USASpecProvider.personality'.
    pass

# Generated at 2022-06-23 20:33:38.431279
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test whether the method personality produces values of
    the right type
    """
    test = USASpecProvider()
    output = test.personality(category='rheti')
    assert isinstance(output, int)
    output = test.personality(category='mbti')
    assert isinstance(output, str)


# Generated at 2022-06-23 20:33:44.563621
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    pattern = re.compile(r'^[A-z]{4}$')
    usa = USASpecProvider()
    assert pattern.match(usa.personality()) is not None
    assert pattern.match(usa.personality('mbti')) is not None
    assert pattern.match(usa.personality('rheti')) is None
    assert isinstance(usa.personality('rheti'), int)


# Generated at 2022-06-23 20:33:48.574428
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert len(provider.tracking_number('USPS')) == 34
    assert len(provider.tracking_number('FedEx')) == 22
    assert len(provider.tracking_number('UPS')) == 17


# Generated at 2022-06-23 20:33:53.610412
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    test = USASpecProvider()
    result = test.ssn()
    assert len(result) == 11
    for i in range(3):
        assert result[i].isdigit()
    assert result[3] == '-'
    for i in range(4,6):
        assert result[i].isdigit()
    assert result[6] == '-'
    for i in range(7,11):
        assert result[i].isdigit()


# Generated at 2022-06-23 20:33:55.372986
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    t = USASpecProvider()

    assert isinstance(t.ssn(), str)


# Generated at 2022-06-23 20:34:00.018278
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    usa = USASpecProvider()
    assert usa.ssn()
    assert usa.personality() in mbtis
    assert usa.tracking_number()

# Generated at 2022-06-23 20:34:02.430820
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    tracking_number = us.tracking_number()
    assert(tracking_number != None)
    assert(tracking_number != '')


# Generated at 2022-06-23 20:34:03.295520
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print(USASpecProvider())

# Generated at 2022-06-23 20:34:08.583242
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality(category='rheti') in range(1, 11)
    assert usa_spec_provider.personality(category='mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP',
        'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    )



# Generated at 2022-06-23 20:34:18.879616
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    result = provider.tracking_number(service='usps')
    assert len(result) == 22
    assert ' ' in result
    assert '#' in result
    assert '@' in result

    result = provider.tracking_number(service='fedex')
    assert len(result) in (13, 22)
    assert ' ' in result
    assert '#' in result

    result = provider.tracking_number(service='ups')
    assert len(result) == 18
    assert '1' in result
    assert 'Z' in result
    assert '@' in result
    assert '#' in result



# Generated at 2022-06-23 20:34:20.777105
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    assert usa_provider.ssn() == '358-73-4132'

# Generated at 2022-06-23 20:34:22.265916
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.ssn(), str)


# Generated at 2022-06-23 20:34:24.507309
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    assert USASpecProvider().ssn() == '569-66-5801'

# Generated at 2022-06-23 20:34:27.092932
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_provider = USASpecProvider()
    result = us_provider.tracking_number()
    assert len(result) > 0


# Generated at 2022-06-23 20:34:29.322005
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    assert len(USASpecProvider().ssn()) == 11


# Generated at 2022-06-23 20:34:32.902427
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():

    data = USASpecProvider().ssn()

    if len(data) == 11:
        print("PASS: ssn() function return 11 chars")
    else:
        print("FAIL: ssn() function not return 11 chars")


# Generated at 2022-06-23 20:34:34.917030
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    print("test method tracking_number of class USASpecProvider")
    usa = USASpecProvider()
    num = usa.tracking_number()
    print(num)
    assert len(num) == 18
    print('*' * 10)


# Generated at 2022-06-23 20:34:37.257336
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():  # NOQA: N802
    usa_provider = USASpecProvider()
    assert usa_provider.ssn() == '465-11-7555'


# Generated at 2022-06-23 20:34:38.106645
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    a = USASpecProvider()
    assert a != None

# Generated at 2022-06-23 20:34:46.639240
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityType
    from mimesis.enums import RhetiType
    provider = USASpecProvider()
    assert isinstance(provider.personality(category='mbti'), str)
    assert isinstance(provider.personality(category='rheti'), int)
    assert provider.personality(category='mbti') in PersonalityType.ALL
    assert provider.personality(category='rheti') in RhetiType.ALL
    assert provider.personality(category='mbti') not in RhetiType.ALL
    assert provider.personality(category='rheti') not in PersonalityType.ALL


# Generated at 2022-06-23 20:34:51.101143
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking_number = provider.tracking_number()
    assert isinstance(tracking_number, str)
    assert len(tracking_number) > 0
    assert tracking_number != None


# Generated at 2022-06-23 20:34:54.413967
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.__dict__ == {'_seed': None, '_data_set': None}
