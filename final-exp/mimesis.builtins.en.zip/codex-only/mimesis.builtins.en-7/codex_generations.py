

# Generated at 2022-06-23 20:24:48.892810
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    person = provider.personality()
    assert person != 0


# Generated at 2022-06-23 20:24:49.770847
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa is not None


# Generated at 2022-06-23 20:24:52.854753
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    assert usa_provider.ssn() != None


# Generated at 2022-06-23 20:24:54.435259
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_data = USASpecProvider()
    assert '111-22-3333' == usa_data.ssn()

# Generated at 2022-06-23 20:24:59.221083
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert(
        USASpecProvider().personality("mbti") in
        ("ISFJ", "ISTJ", "INFJ", "INTJ", "ISTP",
         "ISFP", "INFP", "INTP", "ESTP", "ESFP",
         "ENFP", "ENTP", "ESTJ", "ESFJ", "ENFJ", "ENTJ")
    )
    assert(
        USASpecProvider().personality("rheti") in range(1, 10)
    )

# Generated at 2022-06-23 20:25:01.108038
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider(seed=123)
    assert provider


# Generated at 2022-06-23 20:25:06.175505
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """
    Create and test an instance of USASpecProvider.
    """
    provider = USASpecProvider()
    assert provider.tracking_number(service='usps') is not None
    assert provider.ssn() is not None
    assert provider.personality() is not None
    assert provider.personality(category='rheti') is not None
    assert provider.tracking_number(service='fedex') is not None
    assert provider.tracking_number(service='ups') is not None

# Generated at 2022-06-23 20:25:09.572571
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='rheti')

    assert USASpecProvider().personality(category='mbti')

# Generated at 2022-06-23 20:25:11.089989
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    result = us.tracking_number()
    print(result)


# Generated at 2022-06-23 20:25:15.936881
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality of class USASpecProvider.

    The goal of the test is to verify the current implementation.
    """
    from mimesis.enums import PersonalityType
    from mimesis.providers.usa import USASpecProvider
    
    usa = USASpecProvider()
    
    assert usa.personality(PersonalityType.MBTI) in usa.data['personality']['mbti']

    assert usa.personality(PersonalityType.RHETI) in range(1, 11)

# Generated at 2022-06-23 20:25:23.097880
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usas = USASpecProvider()
    usas.seed(123 if usas.random.random() > 0.5 else 456)
    test_str = usas.personality(category = 'mbti')
    assert test_str in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                        'ISTP', 'ISFP', 'INFP', 'INTP',
                        'ESTP', 'ESFP', 'ENFP', 'ENTP',
                        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:25:29.874748
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    personality_type = usa_spec_provider.personality(category='mbti')
    assert personality_type in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:25:30.802352
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    pass


# Generated at 2022-06-23 20:25:32.158106
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    data = USASpecProvider()
    assert data is not None


# Generated at 2022-06-23 20:25:35.619634
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider_0 = USASpecProvider()
    assert provider_0.ssn() == '025-03-4127'
    provider_1 = USASpecProvider(seed=1)
    assert provider_1.ssn() == '865-46-2058'


# Generated at 2022-06-23 20:25:39.711898
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Arrange
    en_provider = USASpecProvider()
    
    # Act
    actual_result = en_provider.ssn()
    
    # Assert
    assert actual_result != None


# Generated at 2022-06-23 20:25:46.336940
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    assert us.tracking_number() == 'XXXX XXXX XXXX XXXX XXXX'
    assert us.tracking_number(service='usps') == 'XXXX XXXX XXXX XXXX XXXX'
    assert us.tracking_number(service='fedex') == 'XXXX XXXX XXXX XXXXX'
    assert us.tracking_number(service='ups') == '1ZXXXXXXXXXXXXXXXX'


# Generated at 2022-06-23 20:25:54.358081
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('en')
    gender = person.gend('en')
    title = person.title(gender = gender)


    usa = USASpecProvider(seed=2)

    assert usa.tracking_number(service='usps') == '0HV6 8453 6075 2597 4597'
    assert usa.ssn() == '665-42-8446'
    assert usa.personality(category='mbti') == 'ENFP'

# Generated at 2022-06-23 20:25:59.233316
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    ret = provider.tracking_number("usps")
    assert len(ret) == 22 and ret.startswith("94")


# Generated at 2022-06-23 20:26:00.418461
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    test = USASpecProvider()
    assert test is not None


# Generated at 2022-06-23 20:26:08.906229
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider(seed=12345)
    print(usa_spec_provider.tracking_number())
    # '3940 3349 4178 8597 8162'
    print(usa_spec_provider.tracking_number('usps'))
    # '0606 5665 5463 US'
    print(usa_spec_provider.tracking_number('fedex'))
    # '8908 2960 1083'
    print(usa_spec_provider.tracking_number('ups'))
    # '1Z7W8A9X0105857501'
    print(usa_spec_provider.tracking_number('usps'))
    # '8177 5252 4149 US'
    print(usa_spec_provider.tracking_number('ups'))
    # '

# Generated at 2022-06-23 20:26:15.698245
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.enums import Service, ServiceType
    from mimesis.providers.us_provider import USASpecProvider
    
    for service in Service:
        if service.value[0] == 'us':
            service_type = ServiceType.US
        else:
            service_type = ServiceType.INTL
        provider = USASpecProvider(seed=service)
        try:
            assert provider.tracking_number(service=service.value)
        except ValueError:
            assert service_type == ServiceType.INTL
            assert len(service.value) >= 3
        else:
            assert service_type == ServiceType.US
            assert len(service.value) <= 2


# Generated at 2022-06-23 20:26:23.559235
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn(): 
    
    # Create an instance of USASpecProvider
    usa_provider = USASpecProvider()
    # Create an list and append 10 ssn
    ssn_list =[]
    for i in range(10):
        ssn_list.append(usa_provider.ssn())
    # Create a set of ssn_list. A set is used because it returns uniques values only.
    ssn_set = set(ssn_list)
    # Check if there are 10 unique ssn    
    assert len(ssn_set) == 10
    # If a set contains an element. It returns True, otherwise False
    assert ssn_set.issubset(ssn_list)
    
    

# Generated at 2022-06-23 20:26:25.742939
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    x = USASpecProvider().personality()
    assert x == 'ISFJ'

# Generated at 2022-06-23 20:26:28.124300
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality."""
    usasp = USASpecProvider()
    assert usasp.personality('rheti') in range(1, 11)
    assert isinstance(usasp.personality(), str)

# Generated at 2022-06-23 20:26:31.267810
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_spec = USASpecProvider()
    assert len(us_spec.tracking_number(service='FedEx')) == 18
    assert len(us_spec.ssn()) == 11
    assert len(us_spec.personality()) == 4

# Generated at 2022-06-23 20:26:32.440835
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    result = usa_provider.personality('Rheti')
    assert type(result) == int

# Generated at 2022-06-23 20:26:34.299566
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    instance = USASpecProvider()
    for i in range(5):
        assert (len(instance.tracking_number()) >= 16)


# Generated at 2022-06-23 20:26:38.608998
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number('USPS')
    assert USASpecProvider().tracking_number('FedEx')
    assert USASpecProvider().tracking_number('UPS')


# Generated at 2022-06-23 20:26:41.326526
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert len(provider.personality()) == 4
    assert len(provider.personality('rheti')) == 1

# Generated at 2022-06-23 20:26:45.437708
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis import USASpecProvider
    obj = USASpecProvider()
    assert obj.tracking_number('usps') is not None
    assert obj.tracking_number('fedex') is not None
    assert obj.tracking_number('ups') is not None


# Generated at 2022-06-23 20:26:53.693125
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    from mimesis.providers.us import USASpecProvider
    provider = USASpecProvider()
    assert provider.tracking_number(service='USPS') == '4314 0495 7592 4885 6490'
    assert provider.tracking_number(service='USPS') == '64 753 013 US'
    assert provider.tracking_number(service='FedEx') == '6183 7061 04'
    assert provider.tracking_number(service='FedEx') == '8680 5127 986'
    assert provider.tracking_number(service='UPS') == '1Z91584W1285996035'


# Generated at 2022-06-23 20:26:55.544247
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    USASpecProvider()

# Generated at 2022-06-23 20:27:05.298745
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    usa_provider = USASpecProvider()
    tracking_number = usa_provider.tracking_number()
    assert(tracking_number[0:2] == '1Z')

    ssn = usa_provider.ssn()
    assert(len(ssn) == 11)

    personality = usa_provider.personality()
    assert(personality in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                           'ISTP', 'ISFP', 'INFP', 'INTP',
                           'ESTP', 'ESFP', 'ENFP', 'ENTP',
                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'])

# Generated at 2022-06-23 20:27:09.316533
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.builtins.usa import USASpecProvider
    usa_provider = USASpecProvider()
    tracking_number = usa_provider.tracking_number()
    assert len(tracking_number) > 10


# Generated at 2022-06-23 20:27:11.471670
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:27:13.624369
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:27:15.872554
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.builtins import USASpecProvider
    USASpecProvider.ssn()
# '087-12-2485'


# Generated at 2022-06-23 20:27:21.556672
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    category = usa.personality(category='mbti')
    assert category in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    category = usa.personality(category='rheti')
    assert category in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-23 20:27:24.881533
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usaspp = USASpecProvider('ua')
    actual = usaspp.ssn()
    # ...
    assert actual != None
    assert len(actual) > 0

# Generated at 2022-06-23 20:27:34.545288
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test USASpecProvider.ssn method."""
    # the first ssn has a fixed value
    assert USASpecProvider(seed=42).ssn() == '569-66-5801'
    assert USASpecProvider(seed=42).ssn() == '569-66-5801'
    assert USASpecProvider(seed=42).ssn() == '569-66-5801'
    assert USASpecProvider(seed=42).ssn() == '569-66-5801'

    # the second ssn has a different value
    assert USASpecProvider(seed=42).ssn() != '569-66-5801'
    assert USASpecProvider(seed=42).ssn() != '569-66-5801'
    assert USASpecProvider(seed=42).ssn

# Generated at 2022-06-23 20:27:35.662015
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() != None


# Generated at 2022-06-23 20:27:37.217624
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    assert USASpecProvider().personality() == 'ESTP'
# END Unit test for method personality of class USASpecProvider

# Generated at 2022-06-23 20:27:47.218256
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    obj = USASpecProvider()
    assert type(obj.personality()) == str or type(obj.personality()) == int
    assert type(obj.ssn()) == str
    assert type(obj.tracking_number()) == str
    assert type(obj.us_zip_code()) == str
    assert type(obj.us_state_abbr()) == str
    assert type(obj.us_state()) == str
    assert type(obj.us_phone_number()) == str
    assert type(obj.us_military()) == str
    assert type(obj.us_house_number()) == str
    assert type(obj.us_country_area_code()) == str
    assert type(obj.us_city()) == str
    assert type(obj.us_car_number()) == str

# Generated at 2022-06-23 20:27:50.084340
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    
    for i in range(0, 10):
        print(provider.ssn())


# Generated at 2022-06-23 20:27:55.780699
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.providers.person.us import USPerson
    person = USPerson()
    usa = USASpecProvider()

    for i in range(10):
        assert len(usa.ssn().replace("-", "")) == 9
        assert isinstance(usa.ssn(), str)
        assert isinstance(person.ssn(), str)
        assert len(person.ssn().replace("-", "")) == 9


# Generated at 2022-06-23 20:27:59.841652
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    print(us.tracking_number('usps'))
    print(us.tracking_number('fedex'))
    print(us.tracking_number('ups'))
    print(us.tracking_number(''))



# Generated at 2022-06-23 20:28:04.095268
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(None) != None
    assert USASpecProvider().personality() != None
    assert USASpecProvider().personality(category='mbti') != None


# Generated at 2022-06-23 20:28:08.353420
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    result = usa_spec_provider.tracking_number("usps")
    assert result != None
    #assert len(result) == 22
    assert type(result) is str


# Generated at 2022-06-23 20:28:11.567824
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Tests for USASpecProvider class"""
    us = USASpecProvider()
    assert us is not None


# Generated at 2022-06-23 20:28:21.799675
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    test_cases = {
        'rheti': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        'mbti': ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'],
    }

    for category in test_cases:
        data = set()
        for _ in range(100):
            data.add(USASpecProvider().personality(category))
        test_result = data
        expected_result = set(test_cases[category])
        assert test_result

# Generated at 2022-06-23 20:28:23.623291
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    ssn = usa.ssn()
    assert(ssn == usa.ssn())

# Generated at 2022-06-23 20:28:27.530521
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()  # type: USASpecProvider
    assert isinstance(usa.russian_passport_number(), str)
    assert isinstance(usa.facility_number(), str)
    assert isinstance(usa.geo_number(), str)
    assert isinstance(usa.personality(), Union[str, int])
    assert isinstance(usa.ssn(), str)
    assert isinstance(usa.tracking_number(), str)

# Generated at 2022-06-23 20:28:30.286046
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
   usaSpecProvider = USASpecProvider()
   print(usaSpecProvider.ssn())

if __name__ == "__main__":
    test_USASpecProvider_ssn()

# Generated at 2022-06-23 20:28:33.120368
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    tmp = USASpecProvider()
    ssn = tmp.ssn()
    print(ssn)
    assert bool(ssn) == True


# Generated at 2022-06-23 20:28:37.731351
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    usa_tracking_number = usa.tracking_number()
    print("usa_tracking_number:", usa_tracking_number)
    assert len(usa_tracking_number) > 0


# Generated at 2022-06-23 20:28:42.517930
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    # test USPS tracking_number
    assert len(provider.tracking_number('usps')) == 22
    # test FedEx tracking_number
    assert len(provider.tracking_number('fedex')) in (12, 22)
    # test UPS tracking_number
    assert len(provider.tracking_number('ups')) == 18


# Generated at 2022-06-23 20:28:45.408680
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    result = USASpecProvider().tracking_number(service='usps')
    assert result == '0998 4882 3223 4713 4476'


# Generated at 2022-06-23 20:28:48.453194
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    assert usa_provider.ssn() != usa_provider.ssn()
    assert isinstance(usa_provider.ssn(), str)


# Generated at 2022-06-23 20:28:57.305465
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    for _ in range(10):
        provider = USASpecProvider(seed=None)
        assert provider.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                         'ISTP', 'ISFP', 'INFP', 'INTP',
                                                         'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                         'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

        assert provider.personality(category='rheti') >= 1 and provider.personality(category='rheti') <= 10

# Generated at 2022-06-23 20:29:02.974051
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""

    usa_provider = USASpecProvider()

    result_mbti = usa_provider.personality()
    assert result_mbti.isalpha()
    assert not result_mbti.isnumeric()

    result_rheti = usa_provider.personality('rheti')
    assert result_rheti.isnumeric()
    assert not result_rheti.isalpha()
    assert result_rheti >= 1 and result_rheti <= 10

# Generated at 2022-06-23 20:29:07.229341
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    for i in range(0, 50):
        us_tracking_number = USASpecProvider().tracking_number()
        assert us_tracking_number is not None
        assert(len(us_tracking_number) > 0)


# Generated at 2022-06-23 20:29:12.466569
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()

    # Category mbti
    assert provider.personality(category='mbti') in \
             ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP',
              'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    # Category rheti
    assert 0 < provider.personality(category='rheti') < 11

# Generated at 2022-06-23 20:29:21.642132
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # USASpecProvider init
    usa_spec_provider = USASpecProvider()
    # test personality
    assert usa_spec_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_spec_provider.personality(category='rheti'), int)

# Generated at 2022-06-23 20:29:23.215234
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() == 'ISTJ'



# Generated at 2022-06-23 20:29:28.284368
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a = USASpecProvider()
    assert a.tracking_number() != a.tracking_number()
    assert a.tracking_number(service='usps') != a.tracking_number(service='usps')
    assert a.tracking_number(service='fedex') != a.tracking_number(service='fedex')
    assert a.tracking_number(service='ups') != a.tracking_number(service='ups')
    assert a.tracking_number(service='DHL') == 'enter valid service'


# Generated at 2022-06-23 20:29:30.037737
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='rheti') == 1
    assert USASpecProvider().personality(category='mbtI') == 'ISFJ'

# Generated at 2022-06-23 20:29:33.439293
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    '''Method tracking_number of class USASpecProvider
    '''
    usaspp = USASpecProvider()
    print(usaspp.tracking_number())


# Generated at 2022-06-23 20:29:35.308028
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us=USASpecProvider()
    assert issubclass(USASpecProvider, object)


# Generated at 2022-06-23 20:29:40.868003
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test the function tracking_number from the class USASpecProvider."""
    us = USASpecProvider(seed=123456789)
    assert us.tracking_number(service="usps") == "1229 9100 3342 5389 5842"
    assert us.tracking_number(service="fedex") == "9156 4178 2474"
    assert us.tracking_number(service="ups") == "1Z805577YW43765808"


# Generated at 2022-06-23 20:29:48.259012
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    tracking_number_u = us.tracking_number(service="usps")
    tracking_number_f = us.tracking_number(service="fedex")
    tracking_number_u_ = us.tracking_number(service="ups")
    assert isinstance(tracking_number_u, str)
    assert isinstance(tracking_number_f, str)
    assert isinstance(tracking_number_u_, str)


# Generated at 2022-06-23 20:29:50.452107
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider, USASpecProvider)


# Generated at 2022-06-23 20:29:51.905807
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    x = USASpecProvider()
    print(x.tracking_number())
    print(x.tracking_number('ups'))
    print(x.tracking_number('fedex'))



# Generated at 2022-06-23 20:30:01.043417
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert hasattr(USASpecProvider, 'Meta')
    assert hasattr(USASpecProvider, '__init__')
    assert callable(USASpecProvider)
    # class attributes
    assert type(USASpecProvider.Meta.name) == str
    assert USASpecProvider.Meta.name == 'usa_provider'
    assert USASpecProvider.Meta.name == 'usa_provider'
    usa = USASpecProvider()
    assert hasattr(usa, 'random')
    assert hasattr(usa, 'datetime')
    assert hasattr(usa, 'seed')


# Generated at 2022-06-23 20:30:07.828753
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality of class USASpecProvider."""
    usas = USASpecProvider()
    assert usas.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                  'ISTP', 'ISFP', 'INFP', 'INTP',
                                  'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                  'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usas.personality('rheti') in range(1, 11)

# Generated at 2022-06-23 20:30:09.448007
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()

    assert usa.ssn() == '569-66-5801'

# Generated at 2022-06-23 20:30:11.400960
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert 9 == len(ssn)
    assert '-' in ssn

# Generated at 2022-06-23 20:30:19.440770
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality(category='rheti') > 0 and usa.personality(category='rheti') <= 10
    assert usa.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:30:26.250619
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.providers.usa import USASpecProvider
    usa = USASpecProvider()
    a = usa.tracking_number()
    b = usa.tracking_number()
    c = usa.tracking_number()
    d = usa.tracking_number()
    e = usa.tracking_number()
    assert(a != b and b != c and c != d and d != e)


# Generated at 2022-06-23 20:30:33.819942
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    result = provider.ssn()
    # check if mask is valid
    assert result.count("-") == 2
    assert len(result) == 11
    # check if mask is valid
    assert(result[0].isdigit())
    assert(result[1].isdigit())
    assert(result[2].isdigit())
    assert result[3] == "-"
    assert(result[4].isdigit())
    assert(result[5].isdigit())
    assert result[6] == "-"
    assert(result[7].isdigit())
    assert(result[8].isdigit())
    assert(result[9].isdigit())
    assert(result[10].isdigit())


# Generated at 2022-06-23 20:30:36.822595
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    # Given Post service
    service_list = ['usps', 'fedex', 'ups']
    # Then Testing
    assert us.tracking_number(service=service_list[0])


# Generated at 2022-06-23 20:30:38.729014
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    trackingNumber = USASpecProvider().tracking_number()
    assert trackingNumber is not None


# Generated at 2022-06-23 20:30:47.074135
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaspecprovider = USASpecProvider()

    assert(type(usaspecprovider.personality('rheti')) == int)
    assert(usaspecprovider.personality('rheti') in list(range(1,11)))
    assert(type(usaspecprovider.personality('mbti')) == str)
    assert(usaspecprovider.personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'])

# Generated at 2022-06-23 20:30:51.740792
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    expected_result = ('#### #### #### #### ####',
                       '@@ ### ### ### US')
    assert USASpecProvider().tracking_number(service='usps') in expected_result


# Generated at 2022-06-23 20:30:53.905618
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == '569-66-5801'

# Generated at 2022-06-23 20:31:03.003467
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    UNIT=USASpecProvider()
    expected_output_1 = "ENTP"
    expected_output_2 = "ENTP"
    expected_output_3 = "ENTP"
    expected_output_4 = "ENTP"
    expected_output_5 = "ENTP"
    expected_output_6 = "ENTP"
    expected_output_7 = "ENTP"
    expected_output_8 = "ENTP"
    expected_output_9 = "ENTP"
    expected_output_10 = "ENTP"
    expected_output_11 = "ENTP"
    expected_output_12 = "ENTP"
    expected_output_13 = "ENTP"
    expected_output_14 = "ENTP"
    expected_output_15 = "ENTP"

# Generated at 2022-06-23 20:31:11.828555
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                     'ISTP', 'ISFP', 'INFP', 'INTP',
                                                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert provider.personality(category='rheti') in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


    with pytest.raises(ValueError) as error:
        provider.personality(category='')
    assert error.value.args[0] == "category must be one of ['rheti', 'mbti']."

    assert provider.person

# Generated at 2022-06-23 20:31:15.332130
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    track_number_1 = usa.tracking_number()
    track_number_2 = usa.tracking_number()

    assert isinstance(track_number_1, str)
    assert isinstance(track_number_2, str)
    assert len(track_number_1) == len(track_number_2)
    assert track_number_1 != track_number_2


# Generated at 2022-06-23 20:31:20.268836
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    t = USASpecProvider()
    tmp = t.ssn()
    t2 = USASpecProvider(seed=tmp)
    tmp2 = t2.ssn()
    assert tmp == tmp2

# Generated at 2022-06-23 20:31:23.077362
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert len(USASpecProvider().personality()) == 4 or len(USASpecProvider().personality()) == 1


# Generated at 2022-06-23 20:31:24.417269
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert isinstance(USASpecProvider(), USASpecProvider)


# Generated at 2022-06-23 20:31:26.339415
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider"""
    assert USASpecProvider().Meta.name == 'usa_provider'


# Generated at 2022-06-23 20:31:30.167305
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    tracking_number = usa_provider.tracking_number(service="usps")
    assert tracking_number is not None


# Generated at 2022-06-23 20:31:37.491218
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print("Testing USASpecProvider...")
    prov = USASpecProvider()
    assert prov.tracking_number() != prov.tracking_number()
    assert prov.ssn() != prov.ssn()
    assert prov.personality() != prov.personality()
    assert prov.personality("rheti") != prov.personality("rheti")
    assert prov.personality("mbti") != prov.personality("mbti")
    print("Done")


# Generated at 2022-06-23 20:31:39.201747
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    print(usa.ssn())  # Expected no raise


# Generated at 2022-06-23 20:31:44.714149
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    # Test personality
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality('mbti') in \
           ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP',
            'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_spec_provider.personality('rheti'), int)

# Generated at 2022-06-23 20:31:53.942068
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # testing default post service
    usaspp_object_default = USASpecProvider()
    assert len(usaspp_object_default.tracking_number()) == 22
    assert len(usaspp_object_default.tracking_number('usps')) == 22
    assert len(usaspp_object_default.tracking_number('fedex')) == 12
    assert len(usaspp_object_default.tracking_number('ups')) == 18
    # testing invalid post service
    usaspp_object_invalid = USASpecProvider()
    assert usaspp_object_invalid.tracking_number('invalid') == ValueError


# Generated at 2022-06-23 20:31:58.249840
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    def ssn_test(provider):
        assert len(provider.ssn()) == 11

    usa_provider = USASpecProvider()
    ssn_test(usa_provider)
    usa_provider.seed(42)
    ssn_test(usa_provider)



# Generated at 2022-06-23 20:32:00.365490
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    # USASpecProvider
    usa = USASpecProvider()

    # test tracking number
    assert usa.tracking_number()

    # test ssn
    assert usa.ssn()

    # test personality
    assert usa.personality()

# Generated at 2022-06-23 20:32:02.655133
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_specs = USASpecProvider()
    assert usa_specs.ssn() == '569-66-5801'


# Generated at 2022-06-23 20:32:05.161985
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider is not None
#

# Generated at 2022-06-23 20:32:09.077820
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.tracking_number() != usa_spec_provider.tracking_number()


# Generated at 2022-06-23 20:32:09.712944
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    USASpecProvider().tracking_number()


# Generated at 2022-06-23 20:32:14.233147
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.math.en_US import Math
    from mimesis.providers.person import Person
    from mimesis.providers.usa import USASpecProvider
    usa_specProvider = USASpecProvider()
    math = Math()
    person = Person('en')
    set_number = math.random(range_=(0,7))
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    m

# Generated at 2022-06-23 20:32:23.508169
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    class DummyProvider(USASpecProvider):
        class Meta:
            name = 'dummy'

    dp = DummyProvider(seed=42)
    assert dp.personality() == 'ISFJ'
    assert dp.personality() == 'INTP'
    assert dp.personality() == 'INTJ'
    assert dp.personality('rheti') == 4
    assert dp.personality('rheti') == 6
    assert dp.personality('rheti') == 9
    assert dp.personality('Rheti') == 7
    assert dp.personality('Rheti') == 1
    assert dp.personality('Rheti') == 3
    assert dp.personality('Rheti') == 8

    dp = DummyProvider(seed=42)


# Generated at 2022-06-23 20:32:26.591552
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec = USASpecProvider()
    result = usa_spec.personality(category='mbti')
    assert type(result) == str
    result = usa_spec.personality(category='rheti')
    assert type(result) == int


# Generated at 2022-06-23 20:32:30.089358
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    usa_provider = USASpecProvider()

    assert usa_provider.ssn() == '521-78-3436'



# Generated at 2022-06-23 20:32:32.077477
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert isinstance(provider, USASpecProvider)


# Generated at 2022-06-23 20:32:34.858777
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider"""

    tracking_number = USASpecProvider().tracking_number()
    assert type(tracking_number) == str



# Generated at 2022-06-23 20:32:38.125182
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert test_USASpecProvider_tracking_number().tracking_number('usps') == '9ZEE 0598 6T51 2464 0N03'

# Generated at 2022-06-23 20:32:39.633024
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    sp = USASpecProvider()
    assert sp.tracking_number() != None


# Generated at 2022-06-23 20:32:43.392212
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_provider = USASpecProvider()
    assert us_provider is not None
    assert us_provider.__class__.__name__ == "USASpecProvider"



# Generated at 2022-06-23 20:32:46.158733
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_obj = USASpecProvider()

    assert isinstance(usa_obj.personality(), str)
    assert usa_obj.personality().isalpha()
    assert len(usa_obj.personality()) == 4

# Generated at 2022-06-23 20:32:48.407610
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    provider_ssn = provider.ssn()
    length_ssn = len(provider_ssn)

    assert length_ssn == 11

# Generated at 2022-06-23 20:32:57.218897
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider(seed=62)
    assert usa.tracking_number(service='usps') == '4M4W H4X9 0535 9694 1984'
    assert usa.tracking_number(service='usps') == 'E0 092 715 US'
    assert usa.tracking_number(service='fedex') == '0559 9241 8'
    assert usa.tracking_number(service='fedex') == '5299 7901 503'
    assert usa.tracking_number(service='ups') == '1Z9Y0X747528689085'



# Generated at 2022-06-23 20:32:59.375438
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn.split('-')) == 3
    assert ssn.split('-')[0] != '666'


# Generated at 2022-06-23 20:33:00.309822
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    for x in range(1000):
        us.tracking_number()


# Generated at 2022-06-23 20:33:02.672504
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    number = USASpecProvider().tracking_number()
    assert isinstance(number, str)
    assert len(number) >= 15


# Generated at 2022-06-23 20:33:04.164110
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:33:07.948856
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    ssn = USASpecProvider().ssn()

    steps = [str(i) + '-' + str(j) + '-' + str(k)
             for i in range(900)
             for j in range(100)
             for k in range(10000)
             if i != 666
             ]
    assert ssn in steps


# Generated at 2022-06-23 20:33:11.704348
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.providers.us import USASpecProvider
    usaspecprovider = USASpecProvider()
    print(str(usaspecprovider.tracking_number()))


# Generated at 2022-06-23 20:33:17.189430
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # class USASpecProvider
    provider = USASpecProvider()
    personality = provider.personality()
    assert personality in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']



# Generated at 2022-06-23 20:33:20.802601
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()

    usps = provider.tracking_number(service='usps')
    assert provider.tracking_number(service='usps') is not None
    assert provider.tracking_number(service='usps') != usps

    fedex = provider.tracking_number(service='fedex')
    assert provider.tracking_number(service='fedex') is not None
    assert provider.tracking_number(service='fedex') != fedex

    ups = provider.tracking_number(service='ups')
    assert provider.tracking_number(service='ups') is not None
    assert provider.tracking_number(service='ups') != ups

# Generated at 2022-06-23 20:33:28.481407
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert len(usa.tracking_number('usps')) == 29
    assert len(usa.tracking_number('fedex')) == 22
    assert len(usa.tracking_number('ups')) == 18
    assert usa.tracking_number('ups')[0] == '1'
    assert len(usa.ssn()) == 11
    assert len(usa.personality()) == 4
    assert len(usa.personality('rheti')) == 1

# Generated at 2022-06-23 20:33:30.430265
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    test_provider = USASpecProvider()
    assert test_provider.tracking_number() == test_provider.tracking_number()


# Generated at 2022-06-23 20:33:34.308304
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider(seed=12345)
    assert (usa.tracking_number() == "7064 6828 3776 3615 1826")


# Generated at 2022-06-23 20:33:35.693023
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() == '569-66-5801'


# Generated at 2022-06-23 20:33:38.208218
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    u = USASpecProvider()
    assert u.__class__.__name__ == "USASpecProvider"
    assert u.__class__.__module__ == "mimesis. en.USASpecProvider"

# Generated at 2022-06-23 20:33:40.503882
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Arrange
    spec_provider = USASpecProvider()

    # Act
    output = spec_provider.tracking_number(service='usps')

    # Assert
    assert output is not None

# Generated at 2022-06-23 20:33:41.867274
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert isinstance(provider.personality(), str)

# Generated at 2022-06-23 20:33:43.970911
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider(seed=0)
    assert usa_provider.ssn() == '679-78-6627'


# Generated at 2022-06-23 20:33:49.798369
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP',
        'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    ]



# Generated at 2022-06-23 20:33:52.257113
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test tracking_number method of class USASpecProvider."""
    assert USASpecProvider().tracking_number(service='usps') == '5267 6614 4236 5188 3097'



# Generated at 2022-06-23 20:33:59.935796
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    # check mbti
    assert (us.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'))
    # check rheti
    assert isinstance(us.personality(category='rheti'), int)


# Generated at 2022-06-23 20:34:04.937946
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method tracking_number of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.tracking_number(), str)
    assert isinstance(usa_provider.tracking_number("usps"), str)
    assert isinstance(usa_provider.tracking_number("fedex"), str)
    assert isinstance(usa_provider.tracking_number("ups"), str)


# Generated at 2022-06-23 20:34:07.121428
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    tracking_number = usa_provider.tracking_number()
    assert len(tracking_number) >= 1
    assert isinstance(tracking_number,str)

# Generated at 2022-06-23 20:34:15.250255
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    assert 1 <= us.personality('rheti') <= 10
    assert us.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                       'ISTP', 'ISFP', 'INFP', 'INTP',
                                       'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                       'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:34:19.988088
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityTypes
    from mimesis.enums import RhetiTypes

    usp = USASpecProvider()

    assert usp.personality() in PersonalityTypes.all()
    assert usp.personality(category='rheti') in RhetiTypes.all()



# Generated at 2022-06-23 20:34:24.271165
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    a = USASpecProvider()
    assert a.ssn() != ""
    assert a.personality() != ""
    assert a.tracking_number() != ""

test_USASpecProvider()

# Generated at 2022-06-23 20:34:30.369432
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    test_data = [
        ("usps", 'T692 7056 4707 5010 9300'),
        ("fedex", '7103 9428 5405'),
        ("ups", '1ZP0A2X9Y3W816081'),
    ]
    us = USASpecProvider()
    for service, expected_value in test_data:
        assert us.tracking_number(service=service) == expected_value



# Generated at 2022-06-23 20:34:33.611449
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    p = USASpecProvider()
    assert p.random.__class__.__name__ == 'Random'
    assert p.datetime.__class__.__name__ == 'DateTime'
    assert p.__class__.__name__ == 'USASpecProvider'



# Generated at 2022-06-23 20:34:35.479915
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # USASpecProvider()
    assert USASpecProvider()



# Generated at 2022-06-23 20:34:37.914181
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11


# Generated at 2022-06-23 20:34:40.631359
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us_provider = USASpecProvider()

    assert isinstance(us_provider.ssn(), str)
    assert len(us_provider.ssn()) == 11


# Generated at 2022-06-23 20:34:43.947881
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()

    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'
    assert ssn[:3] != '666'


# Generated at 2022-06-23 20:34:45.587231
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.spec.data == 'en'
    assert provider.spec.seed is None

# Generated at 2022-06-23 20:34:51.290136
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.builtins import USASpecProvider
    provider = USASpecProvider()
    assert provider.__module__ == 'mimesis.builtins.usa_provider'
    assert isinstance(provider, USASpecProvider)

