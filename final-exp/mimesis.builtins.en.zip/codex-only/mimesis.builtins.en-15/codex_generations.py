

# Generated at 2022-06-23 20:24:51.596393
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    up = USASpecProvider()
    assert(up.tracking_number() != '')
    assert(up.tracking_number(service='ups') != '')
    assert(up.tracking_number(service='fedex') != '')
    assert(up.tracking_number(service='usps') != '')


# Generated at 2022-06-23 20:24:53.764228
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    spec = USASpecProvider()
    ans = spec.ssn()
    assert type(ans) is str
    assert len(ans) == 11

# Generated at 2022-06-23 20:24:55.329113
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usss = USASpecProvider().ssn()
    assert usss.count('-') == 2

# Generated at 2022-06-23 20:24:58.012623
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider()
    ssn = us.ssn()
    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'



# Generated at 2022-06-23 20:25:07.339198
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    from mimesis.data import USA_PROVIDER_DEFAULT_DATA

    usa = USASpecProvider(seed=12345)

    # SSN with male gender
    assert usa.ssn(gender=Gender.MALE) == '642-22-6283'

    # SSN with female gender
    assert usa.ssn(gender=Gender.FEMALE) == '971-14-2016'

    # SSN with not-male and not-female gender
    assert usa.ssn(gender='not-male or not-female') == '873-26-6657'

    # SSN with not-male and not-female gender (wrong gender name)

# Generated at 2022-06-23 20:25:09.453111
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    spec = USASpecProvider()
    print(spec.name)


# Generated at 2022-06-23 20:25:16.845898
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()

    # Test category MBTI
    # Test value will be a string
    assert(type(us.personality()) is str)
    # Test value will be one of the 16 MBTI types
    assert(us.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'))

    # Test category RHETI
    # Test value will be an integer
    assert(type(us.personality(category = 'rheti')) is int)
    # Test value will be in range of 1 and 10

# Generated at 2022-06-23 20:25:18.665389
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    ssn = provider.tracking_number(service='UPS')
    assert ssn is not None, 'Method returns None!'

# Generated at 2022-06-23 20:25:21.339953
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    print(usa.tracking_number())
    print(usa.ssn())
    print(usa.personality('mbti'))

if __name__ == '__main__':
    test_USASpecProvider()

# Generated at 2022-06-23 20:25:26.325243
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from random import seed
    random = seed(1)
    sut = USASpecProvider(random)
    ret = sut.personality('mbti')
    print(ret)
    assert ret == 'ESFP'

# Generated at 2022-06-23 20:25:27.037807
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider() == USASpecProvider()

# Generated at 2022-06-23 20:25:28.334579
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.seed is None

# Generated at 2022-06-23 20:25:35.959078
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    ssn = USASpecProvider().ssn()
    assert isinstance(ssn, str)
    assert len(ssn) == 11
    first_three_characters = int(ssn[:3])
    assert first_three_characters > 0
    assert first_three_characters != 666
    second_two_characters = int(ssn[4:6])
    assert second_two_characters > 0
    last_four_characters = int(ssn[7:])
    assert last_four_characters > 0


# Generated at 2022-06-23 20:25:39.753354
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    for i in range(1000):
        ssn = USASpecProvider().ssn()
        assert (len(ssn) == 11)
        #assert (ssn[3] == ssn[6] == '-')


# Generated at 2022-06-23 20:25:48.189463
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality(category='rheti') <= 10
    assert usa.personality(category='rheti') >= 1
    assert usa.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:25:49.491816
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa is not None

# Generated at 2022-06-23 20:25:50.362765
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider(seed=None)

# Generated at 2022-06-23 20:25:52.219536
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking_number = provider.tracking_number()
    assert tracking_number != ''


# Generated at 2022-06-23 20:25:54.165321
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider(seed=42)
    assert provider.ssn() == '589-86-9981'

# Generated at 2022-06-23 20:25:57.579239
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider, USASpecProvider)


# Generated at 2022-06-23 20:26:01.812652
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Initialize object
    provider = USASpecProvider()
    # Generate SSN
    ssn = provider.ssn()
    # Check format of SSN
    assert type(ssn) is str
    assert len(ssn) == 11
    assert ssn[3] == '-'
    assert ssn[6] == '-'

# Generated at 2022-06-23 20:26:06.665014
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider(seed=1327)
    tracking_number = provider.tracking_number('usps')
    assert tracking_number == '2400 2364 2673 6648 3255'

    tracking_number = provider.tracking_number('fedex')
    assert tracking_number == '8737 0805 8526'

    tracking_number = provider.tracking_number('ups')
    assert tracking_number == '1Z4986W62136678103'



# Generated at 2022-06-23 20:26:09.144411
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    a = USASpecProvider()
    type1 = a.personality('rheti')
    print(type1)
    type2 = a.personality('mbti')
    print(type2)

# Generated at 2022-06-23 20:26:15.012968
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # number of test case
    num_test = 1000

    provider = USASpecProvider()
    for i in range(num_test):
        assert provider.personality(category='mbti') in (
            'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
            'ISTP', 'ISFP', 'INFP', 'INTP',
            'ESTP', 'ESFP', 'ENFP', 'ENTP',
            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
        )

    for i in range(num_test):
        assert 1 <= provider.personality(category='rheti') <= 10

# Generated at 2022-06-23 20:26:16.113858
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    x = USASpecProvider()


# Generated at 2022-06-23 20:26:17.920140
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert isinstance(provider.tracking_number(), str)


# Generated at 2022-06-23 20:26:20.244161
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print(USASpecProvider().personality())
    print(USASpecProvider().ssn())
    print(USASpecProvider().tracking_number())

# Generated at 2022-06-23 20:26:24.433882
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    personality = provider.personality()
    assert personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:26:27.955535
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.provider == "usa_provider"


# Generated at 2022-06-23 20:26:29.908302
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    ssn = USASpecProvider().ssn()
    assert (len(ssn.split('-')) == 3)
    print(ssn)

# Generated at 2022-06-23 20:26:36.802114
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    print("\nFull Test of USASpecProvider_tracking_number:")
    usa = USASpecProvider()
    print("\tRandom USPS tracking number generated: " + usa.tracking_number("usps"))
    print("\tRandom FedEx tracking number generated: " + usa.tracking_number("fedex"))
    print("\tRandom UPS tracking number generated: " + usa.tracking_number("ups"))

test_USASpecProvider_tracking_number()


# Generated at 2022-06-23 20:26:43.683810
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number() in (
        '#### #### #### #### ####',
        '@@ ### ### ### US',
    )
    assert usa.tracking_number('ups') in (
        '1Z@####@##########',
    )
    assert usa.tracking_number('fedex') in (
        '#### #### ####',
        '#### #### #### ###',
    )


# Generated at 2022-06-23 20:26:49.622175
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    assert USASpecProvider().personality() in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:26:55.105359
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    assert len(usa_provider.tracking_number()) == 20
    assert len(usa_provider.tracking_number(service='fedex')) in (12, 18)
    assert len(usa_provider.tracking_number(service='ups')) == 18

    # Test error
    try:
        usa_provider.tracking_number(service='test')
    except ValueError:
        pass
    else:
        raise ValueError('Expected error')

# Generated at 2022-06-23 20:26:58.709183
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usaSpecProvider = USASpecProvider()
    ssn = usaSpecProvider.ssn()
    assert ssn
    assert isinstance(ssn, str)
    assert len(ssn) == 11
    assert ssn.count("-") == 2



# Generated at 2022-06-23 20:27:05.064610
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    usa = USASpecProvider()
    #: Generate a random, but valid SSN.
    ssn = usa.ssn()
    assert len(ssn) == 11
    #: Generate a random, but valid SSN.
    ssn = usa.ssn()
    assert len(ssn) == 11


# Generated at 2022-06-23 20:27:07.729178
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    spec = USASpecProvider()
    for i in range(20):
        assert len(spec.tracking_number()) == 18
        assert len(spec.tracking_number()) == 24


# Generated at 2022-06-23 20:27:13.629548
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category="rheti" ) in range(1,10)

if __name__ == '__main__':
    print("\n")
    print("Testing USASpecProvider")
    print("------------------------")
    print("\n")
    print("Personality:")
    print(USASpecProvider().personality(category="rheti"))

# Generated at 2022-06-23 20:27:21.166032
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method tracking_number of class USASpecProvider."""
    from mimesis.builtins.usa import USASpecProvider

    usa = USASpecProvider()
    assert usa.tracking_number() is not None
    assert usa.tracking_number('usps') is not None
    assert usa.tracking_number('fedEx') is not None
    assert usa.tracking_number('ups') is not None
    assert usa.tracking_number('test') is not None


# Generated at 2022-06-23 20:27:28.122828
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.education import Education
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    # Initialize provider
    usa = USASpecProvider()
    # Test SSN
    assert len(usa.ssn()) == 11
    # Test tracking_number
    assert len(usa.tracking_number()) == 22
    # Test personality

# Generated at 2022-06-23 20:27:36.712031
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    print("\nStart testing the 'tracking_number' method...\n")

    spec = USASpecProvider()

    USPS_tracking_number = spec.tracking_number("usps")
    if len(USPS_tracking_number) == 27:
        print("The value returned by the function is correct.\n")
    else:
        print("The value returned by the function is incorrect.\n")

    FedEx_tracking_number = spec.tracking_number("fedex")
    if (len(FedEx_tracking_number) == 12 or
            len(FedEx_tracking_number) == 15):
        print("The value returned by the function is correct.\n")
    else:
        print("The value returned by the function is incorrect.\n")

    UPS_tracking_number = spec.tracking_number("ups")

# Generated at 2022-06-23 20:27:40.676986
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider(seed=123456)
    
    assert provider.tracking_number('usps') == '1188 9805 0673 6641 5302'
    assert provider.tracking_number('fedex') == '3456 4995 4176'
    assert provider.tracking_number('ups') == '1Z23BL128319290259'


# Generated at 2022-06-23 20:27:43.925263
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Initialising object of class USASpecProvider
    usa_provider = USASpecProvider()
    # Testing method tracking_number of class USASpecProvider
    tracking_number = usa_provider.tracking_number()
    # Checking the format of return value
    assert isinstance(tracking_number, str)
    

# Generated at 2022-06-23 20:27:46.888798
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    obj1 = USASpecProvider()
    obj2 = USASpecProvider(seed=11)
    obj3 = USASpecProvider(seed='hello')

    assert (False)


# Generated at 2022-06-23 20:27:49.704985
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    assert isinstance(usa_spec_provider.tracking_number(), str)


# Generated at 2022-06-23 20:27:57.256277
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider"""

    provider = USASpecProvider()

    # Test tracking_number method
    assert isinstance(provider.tracking_number(), str)
    assert isinstance(provider.tracking_number('USPS'), str)
    assert isinstance(provider.tracking_number('FEDEX'), str)
    assert isinstance(provider.tracking_number('UPS'), str)

    # Test tracking_number method with wrong service
    try:
        provider.tracking_number('Ebay')
    except ValueError:
        pass


# Generated at 2022-06-23 20:28:00.528056
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider(seed=None)
    print(usa.personality(category='rheti'))
    print(usa.personality(category='mbti'))



# Generated at 2022-06-23 20:28:04.095862
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    a = USASpecProvider()
    assert a.__class__.__name__ == 'USASpecProvider'



# Generated at 2022-06-23 20:28:10.140870
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    usa_spec_provider = USASpecProvider()

    # test case: default category
    usa_spec_provider.load_data(data_type='mbti')
    personality = usa_spec_provider.personality()

    # test case: category=rheti
    usa_spec_provider.load_data(data_type='rheti')
    personality = usa_spec_provider.personality(category='rheti')



# Generated at 2022-06-23 20:28:13.663313
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    obj=USASpecProvider()
    #print(obj.tracking_number())



# Generated at 2022-06-23 20:28:14.918140
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider is not None


# Generated at 2022-06-23 20:28:24.192124
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test the method personality of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.personality(category='rheti') == int
    assert isinstance(usa_provider.personality(category='rheti'), int)
    assert isinstance(usa_provider.personality(category='mbti'), str)
    assert usa_provider.personality(category='mbti') in list(
        'ISFJ ISTJ INFJ INTJ '
        'ISTP ISFP INFP INTP '
        'ESTP ESFP ENFP ENTP '
        'ESTJ ESFJ ENFJ ENTJ'.split())
    assert usa_provider.personality(category='rheti') in list(range(1, 11))



# Generated at 2022-06-23 20:28:26.583369
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
	assert USASpecProvider(seed=9585467).personality() == 'INFP'

# Generated at 2022-06-23 20:28:33.413750
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    result = provider.ssn()
    check = True
    if len(result) != 11:
        check = False
    elif result[3] != '-':
        check = False
    elif result[6] != '-':
        check = False
    elif int(result[0]) >= 9:
        check = False
    elif int(result[0:3]) == 666:
        check = False
    return check


# Generated at 2022-06-23 20:28:44.275352
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number(service="usps") == "6BQ8 7451 6461 2962 4320"
    assert usa.tracking_number(service="usps") == "4315 6771 7760 3926 1309"
    assert usa.tracking_number(service="usps") == "2CM2 2948 8215 6581 0434"
    assert usa.tracking_number(service="fedex") == "6835 8559 8888"
    assert usa.tracking_number(service="fedex") == "9262 4104 2140"
    assert usa.tracking_number(service="fedex") == "8329 0783 4925"
    assert usa.tracking_number(service="fedex") == "3927 4205 3131"
    assert usa.tracking

# Generated at 2022-06-23 20:28:45.866986
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() == '914-65-6099'

# Generated at 2022-06-23 20:28:49.564614
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider(seed='123')
    #  1
    assert us.tracking_number() == '2D92 8505 3557 6181 5995'
    #  2
    assert 'tracking_number' in dir(us)
    #  3
    assert us.ssn() == '461-11-7891'
    #  4
    assert 'ssn' in dir(us)
    #  5
    assert us.personalities() == 'INFJ'
    #  6
    assert 'personalities' in dir(us)

# Generated at 2022-06-23 20:28:58.490354
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method tracking_number of class USASpecProvider."""
    assert USASpecProvider().tracking_number(service='usps') == '5249 5311 2456 7364 1655'
    assert USASpecProvider().tracking_number(service='fedex') == '4465 6959 3091'
    assert USASpecProvider().tracking_number(service='ups') == '1Z3V7B621286342607'

    service = 'ups'
    assert USASpecProvider().tracking_number(service) == '1Z3V7B621286342607'


# Generated at 2022-06-23 20:29:02.753610
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
   # Test case #1
   assert hasattr(USASpecProvider, 'ssn')

   # Test case #2
   output1 = USASpecProvider().ssn()
   output2 = USASpecProvider().ssn()

   # Test case #3
   assert type(output1) == str
   assert type(output2) == str

   # Test case #4
   assert output1 != output2


# Generated at 2022-06-23 20:29:04.212672
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test USASpecProvider constructor."""
    assert USASpecProvider()

# Generated at 2022-06-23 20:29:06.442828
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
   usa = USASpecProvider()
   assert usa


# Generated at 2022-06-23 20:29:08.609856
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    assert len(usa.ssn()) == 11
    assert type(usa.ssn()) == str

# Generated at 2022-06-23 20:29:10.238504
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number() == '9412 2408 2115 8479 4741'

# Generated at 2022-06-23 20:29:21.825997
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    seed = 1
    up = USASpecProvider(seed=seed)
    assert up.personality() == 'ENFP'
    assert up.personality() == 'INTP'
    assert up.personality() == 'INFP'
    assert up.personality('rheti') == 9
    assert up.personality() == 'INFJ'
    assert up.personality() == 'ISFP'
    assert up.personality() == 'ISFP'
    assert up.personality() == 'INTJ'
    assert up.personality() == 'INFP'
    assert up.personality() == 'ENTP'
    assert up.personality() == 'ISFP'
    assert up.personality() == 'INTP'
    assert up.personality() == 'ESTJ'

# Generated at 2022-06-23 20:29:25.859177
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality of class USASpecProvider."""

    usa = USASpecProvider()
    assert usa.personality(category='rheti')
    assert usa.personality(category='rheti') == int
    assert usa.personality(category='mbti')
    assert usa.personality(category='mbti') == str


# Generated at 2022-06-23 20:29:32.720896
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for USASpecProvider.personality function.
    
    1. Test argument count.
    2. Test argument type.
    3. Test randomness.
    4. Test return type.
    5. Test return range."""
    
    # 1. Test argument count.
    # Function takes 1 argument by default.
    
    assert len(inspect.signature(usaspecprovider.personality).parameters) == 1
    
    # 2. Test argument type.
    # Argument "category" can be a string.
    
    assert 'category' in inspect.signature(usaspecprovider.personality).parameters

# Generated at 2022-06-23 20:29:35.802615
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us_spec = USASpecProvider()
    assert us_spec.personality() == 'INTJ'
    assert us_spec.personality(category='rheti') == 2


# Generated at 2022-06-23 20:29:40.947964
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    exp = r'^(ISFJ|ISTJ|INFJ|INTJ|ISTP|ISFP|INFP|INTP|ESTP|ESFP|ENFP|ENTP|ESTJ|ESFJ|ENFJ|ENTJ)$'
    us.regex.match(exp, us.personality())
    assert isinstance(us.personality(category='rheti'), int)

# Generated at 2022-06-23 20:29:43.252372
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == '429-15-4200'


# Generated at 2022-06-23 20:29:53.157365
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """ Unit Test function for USASpecProvider.tracking_number() """

    # Using service USPS
    tracking_number = USASpecProvider().tracking_number()
    assert len(tracking_number) == 33
    # Using service UPS
    tracking_number = USASpecProvider().tracking_number(service = 'UPS')
    assert len(tracking_number) == 18
    # Using service FedEx
    tracking_number = USASpecProvider().tracking_number(service = 'FedEx')
    assert (len(tracking_number) == 13 or len(tracking_number) == 18)

    #Testing wrong input
    try:
        tracking_number = USASpecProvider().tracking_number(service = 'asd')
    except ValueError:
        pass



# Generated at 2022-06-23 20:29:59.637037
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityCategory

    provider = USASpecProvider(seed=41327)
    results = {
        PersonalityCategory.MBTI: "ISTJ",
        PersonalityCategory.RHE: 3,
    }

    for category, result in results.items():
        assert provider.personality(category) == result, (
            'Provider does not generate personality type correctly'
        )

# Generated at 2022-06-23 20:30:01.883186
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking_number = provider.tracking_number()
    assert type(tracking_number) == str

# Generated at 2022-06-23 20:30:07.863967
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    # Create an instance of USASpecProvider
    usa_spec_provider = USASpecProvider()

    # Call method personality of class USASpecProvider
    result1 = usa_spec_provider.personality()
    result2 = usa_spec_provider.personality(category='rheti')

    # Check if the method personality of class USASpecProvider works as expected
    assert isinstance(result1, str)
    assert isinstance(result2, int)

# Generated at 2022-06-23 20:30:10.819084
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """
    Unit test for method :method:`USASpecProvider.tracking_number`.
    """
    provider = USASpecProvider()
    result = provider.tracking_number()
    assert isinstance(result, str)



# Generated at 2022-06-23 20:30:13.757957
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.providers.us import USASpecProvider
    t = USASpecProvider()
    print(t.ssn())


# Generated at 2022-06-23 20:30:16.306689
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number() == '1119 3472 0263 9070 7107'


# Generated at 2022-06-23 20:30:21.216038
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    prov = USASpecProvider()

    assert len(prov.tracking_number()), 22
    assert prov.tracking_number().startswith('92')
    assert prov.tracking_number().endswith('US')
    assert prov.ssn() != prov.ssn()
    assert prov.personality(), 'ISFJ'

# Generated at 2022-06-23 20:30:25.182723
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number()
    assert USASpecProvider().tracking_number('usps')
    assert USASpecProvider().tracking_number('fedex')
    assert USASpecProvider().tracking_number('ups')


# Generated at 2022-06-23 20:30:29.911565
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test method ssn."""
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert isinstance(ssn, str)
    assert len(ssn) == 11
    assert ssn != '000-00-0000'
    assert ssn != '666-66-6666'
    assert ssn != '999-99-9999'


# Generated at 2022-06-23 20:30:32.272135
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usaspecprovider = USASpecProvider(seed=123)
    assert usaspecprovider.random.seed[0] == 123


# Generated at 2022-06-23 20:30:38.162166
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
            'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert type(provider.personality(category='rheti')) is int
    assert provider.personality(category='rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

# Generated at 2022-06-23 20:30:39.545615
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_ssn = USASpecProvider()
    usa_ssn.ssn()


# Generated at 2022-06-23 20:30:46.239067
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider(seed=1)
    us.random.seed(1)
    # USPS
    assert us.tracking_number() == '3232 9482 0883 8714 5557'
    # FedEx
    assert us.tracking_number('fedex') == '2984 9780 7207'
    # UPS
    assert us.tracking_number('ups') == '1Z0J92BV7014143205'
    # Error Value
    try:
        us.tracking_number('error')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-23 20:30:49.253476
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider(seed=12345)
    result1 = provider.tracking_number()
    result2 = provider.tracking_number('usps')
    expected1 = '1ZR7VYT08974527097'
    expected2 = '8530 7152 4973 2522 2423'
    assert result1 == expected1
    assert result2 == expected2


# Generated at 2022-06-23 20:30:56.137762
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    result = USASpecProvider().personality()
    if not (result in (
            'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
            'ISTP', 'ISFP', 'INFP', 'INTP',
            'ESTP', 'ESFP', 'ENFP', 'ENTP',
            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')):
        raise Exception('test_USASpecProvider_personality failed')



# Generated at 2022-06-23 20:30:59.317780
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usaspecprovider = USASpecProvider()
    assert isinstance(usaspecprovider.ssn(), str)
    assert len(usaspecprovider.ssn()) == 11


# Generated at 2022-06-23 20:31:00.932737
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    obj_USASpecProvider = USASpecProvider(None)
    assert isinstance(obj_USASpecProvider.tracking_number("usps"), str)


# Generated at 2022-06-23 20:31:09.866647
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality(category="mbti") in ["ISFJ", "ISTJ", "INFJ", "INTJ", "ISTP", "ISFP", "INFP", "INTP", "ESTP", "ESFP", "ENFP", "ENTP", "ESTJ", "ESFJ", "ENFJ", "ENTJ"]
    assert isinstance(usa_spec_provider.personality(category="rheti"), int) == True
    assert (1 <= usa_spec_provider.personality(category="rheti") <= 10) == True

# Generated at 2022-06-23 20:31:11.466936
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in mbtis

# Generated at 2022-06-23 20:31:19.042179
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    try:
        u = USASpecProvider()
        assert u.personality() in [
            'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP',
            'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ',
            'ENFJ', 'ENTJ'
        ]
        assert u.personality(category='rheti') in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    except Exception as e:
        print(e)
        assert False
    else:
        assert True
        

# Generated at 2022-06-23 20:31:20.876169
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    a = usa.tracking_number()
    assert isinstance(a, str)

# Generated at 2022-06-23 20:31:24.376539
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method ssn of class USASpecProvider."""
    ssn = USASpecProvider().ssn()
    print(ssn)  # Ex: 569-66-5801

    assert len(ssn) == 11


# Generated at 2022-06-23 20:31:27.269956
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking_number = provider.tracking_number()
    assert isinstance(tracking_number, str)
    assert len(tracking_number) > 0
    assert tracking_number[0].isdigit()


# Generated at 2022-06-23 20:31:35.265780
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality('rheti') in range(1, 11)
    assert USASpecProvider().personality('mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ',
    )



# Generated at 2022-06-23 20:31:37.861250
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test case for constructor."""
    usa_provider = USASpecProvider()
    assert usa_provider.__dict__ != {}


# Generated at 2022-06-23 20:31:39.563682
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    x = USASpecProvider()
    assert x.ssn() == '000-00-0000'


# Generated at 2022-06-23 20:31:40.612674
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number()


# Generated at 2022-06-23 20:31:45.497468
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.enums import PostService
    from mimesis.providers.usa import USASpecProvider

    usa_provider = USASpecProvider()
    for i in range(10):
        tracking_number = usa_provider.tracking_number()
        assert tracking_number != None
        assert len(tracking_number) == 20

    tracking_number = usa_provider.tracking_number(PostService.DHL_EXPRESS)
    tracking_number = usa_provider.tracking_number(PostService.DHL_GLOBAL_MAIL)
    tracking_number = usa_provider.tracking_number(PostService.DHL_PARCELL)


# Generated at 2022-06-23 20:31:53.489652
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert isinstance(provider.personality(), str)
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP',
                                      'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP',
                                      'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ',
                                      'ENTJ')
    assert isinstance(provider.personality(category='rheti'), int)


# Generated at 2022-06-23 20:31:54.664859
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    print(USASpecProvider())


# Generated at 2022-06-23 20:31:57.702366
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Create an object of USASpecProvider
    _x = USASpecProvider()
    assert _x.random.randint(1,5) != _x.random.randint(1,5)

# Generated at 2022-06-23 20:32:00.277222
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider_usaspecprovider_personality = USASpecProvider()
    result_usaspecprovider_personality = provider_usaspecprovider_personality.personality()
    print(result_usaspecprovider_personality)
    return result_usaspecprovider_personality


# Generated at 2022-06-23 20:32:05.299277
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert isinstance(USASpecProvider().personality('rheti'), int)
    assert isinstance(USASpecProvider().personality(), str)
    assert USASpecProvider().personality('rheti') in range(1, 10+1)
    assert USASpecProvider().personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']


# Generated at 2022-06-23 20:32:08.322504
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() is not None
    assert len(provider.ssn()) == 11


# Generated at 2022-06-23 20:32:11.222261
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # test for USPS
    provider = USASpecProvider()
    tracking = provider.tracking_number('usps')
    assert len(tracking) == 22


# Generated at 2022-06-23 20:32:13.269230
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider(seed=103)
    print("Test for constructor of class USASpecProvider Done")
    

# Generated at 2022-06-23 20:32:15.687455
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider, object)


# Generated at 2022-06-23 20:32:23.994669
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()

    # Test with mbti
    result = provider.personality(category="mbti")
    print(result)
    result = provider.personality(category="mbti")
    print(result)
    result = provider.personality(category="mbti")
    print(result)
    result = provider.personality(category="mbti")
    print(result)
    result = provider.personality(category="mbti")
    print(result)
    result = provider.personality(category="mbti")
    print(result)

    # Test with rhei
    print("")

    result = provider.personality(category="rheti")
    print(result)
    result = provider.personality(category="rheti")
    print(result)

# Generated at 2022-06-23 20:32:31.244741
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number() != ''
    assert usa_provider.tracking_number('usps') != ''
    assert usa_provider.tracking_number('fedex') != ''
    assert usa_provider.tracking_number('ups') != ''
    assert usa_provider.tracking_number('ups') == '1Z4A58344400739340'


# Generated at 2022-06-23 20:32:34.293108
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import Category
    usa_provider = USASpecProvider()
    assert usa_provider.personality() in Category.PERSONALITY



# Generated at 2022-06-23 20:32:39.902290
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Initialize the class and its attributes
    prov = USASpecProvider()
    assert prov.ssn() == '965-84-3335'

    prov.seed(1)
    assert prov.ssn() == '465-98-2538'

    prov.reset_seed()
    assert prov.ssn() == '808-46-5667'


# Generated at 2022-06-23 20:32:49.967843
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider=USASpecProvider()
    usa_spec_provider.random.set_state(0)
    assert usa_spec_provider.tracking_number(service="fedex")=="3910 9834 9843"
    assert usa_spec_provider.tracking_number(service="usps")=="C958 745 083 US"
    assert usa_spec_provider.tracking_number(service="ups")=="1ZF972X9287679900"
    assert usa_spec_provider.ssn()=="313-63-7214"
    assert usa_spec_provider.personality(category="rheti")==4
    assert usa_spec_provider.personality(category="mbti")=='INFP'

# Generated at 2022-06-23 20:32:59.806316
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    up = USASpecProvider()
    # Test MBI
    mb = up.personality("mbti")
    assert mb is not None
    assert mb in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                  'ISTP', 'ISFP', 'INFP', 'INTP',
                  'ESTP', 'ESFP', 'ENFP', 'ENTP',
                  'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    # Test Rheti
    assert up.personality("rheti") is not None
    assert up.personality("rheti") in [1,2,3,4,5,6,7,8,9,10]


# Generated at 2022-06-23 20:33:06.234793
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert isinstance(provider.tracking_number(), str)
    assert isinstance(provider.tracking_number('USPS'), str)
    assert isinstance(provider.tracking_number('FEDEX'), str)
    assert isinstance(provider.tracking_number('UPS'), str)

    try:
        assert isinstance(provider.tracking_number('DHL'), str)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-23 20:33:07.533068
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    obj = USASpecProvider()
    assert obj.personality()

# Generated at 2022-06-23 20:33:10.127549
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == "130-21-3694"


# Generated at 2022-06-23 20:33:12.304927
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Create a random from a random seed
    random = USASpecProvider(seed=1)
    # Get ssn with seed=1, uniqueId=100
    assert random.ssn() == '769-74-5801'

# Generated at 2022-06-23 20:33:18.562918
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    usps_tn = usa.tracking_number()
    usps_tn_l = usps_tn.replace(" ", "-").replace("@", "").replace("U", "").replace("S", "")
    fedex_tn = usa.tracking_number('fedex')
    fedex_tn_l = fedex_tn.replace(" ", "-")
    ups_tn = usa.tracking_number('ups')
    ups_tn_l = ups_tn.replace(" ", "-").replace("@", "").replace("1", "").replace("Z", "")
    print("Postal Service   : USPS")
    print("Tracking Number  : %s" % usps_tn)
    print("Tracking Number  : %s" % usps_tn_l)

# Generated at 2022-06-23 20:33:21.370655
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    number = provider.ssn()
    # print(number)
    assert len(number) == 11
    assert number[3] == '-'
    assert number[6] == '-'


# Generated at 2022-06-23 20:33:25.175264
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    ussp = USASpecProvider()

    assert ussp.personality() in ussp.CONST_PERSONALITY


# Generated at 2022-06-23 20:33:30.579273
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:33:34.265493
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test USASpecProvider method ssn"""
    assert USASpecProvider().ssn() == '000-00-0000'


# Generated at 2022-06-23 20:33:35.371061
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert isinstance(USASpecProvider(), BaseSpecProvider)


# Generated at 2022-06-23 20:33:37.203394
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    category = 'rheti'
    print(provider.personality(category))


# Generated at 2022-06-23 20:33:39.618151
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert usa_provider._data['tracking_number']['usps'][0] == '#### #### #### #### ####'


# Generated at 2022-06-23 20:33:42.881470
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider(seed=123)
    tracking_number_usps = "3678 7504 9932 0386 9917"
    assert provider.tracking_number('usps') == tracking_number_usps
    tracking_number_usps = provider.tracking_number('fedex')
    assert len(tracking_number_usps) in (12, 15)


# Generated at 2022-06-23 20:33:51.619447
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    x = USASpecProvider.personality()
    assert x == 'ISFJ'
    assert x == 'ISTJ'
    assert x == 'INFJ'
    assert x == 'INTJ'
    assert x == 'ISTP'
    assert x == 'ISFP'
    assert x == 'INFP'
    assert x == 'INTP'
    assert x == 'ESTP'
    assert x == 'ESFP'
    assert x == 'ENFP'
    assert x == 'ENTP'
    assert x == 'ESTJ'
    assert x == 'ESFJ'
    assert x == 'ENFJ'
    assert x == 'ENTJ'



# Generated at 2022-06-23 20:34:00.526954
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test gengerate a type of personality."""
    usa = USASpecProvider()
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    for _ in range(10):
        assert usa.personality('mbti') in mbtis
        assert isinstance(usa.personality('rheti'), int) and 1 <= usa.personality('rheti') <= 10

# Generated at 2022-06-23 20:34:02.218028
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a = USASpecProvider()
    print(a.tracking_number('Fedex'))


# Generated at 2022-06-23 20:34:03.091939
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider()

# Generated at 2022-06-23 20:34:04.591795
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number('usps') is not None


# Generated at 2022-06-23 20:34:09.218538
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    usa = USASpecProvider()
    test_tracking_numbers = usa.tracking_number("usps")
    test_ssn = usa.ssn()
    test_personality = usa.personality("mbti")
    
    print("Testing constructed class USASpecProvider...")
    print("Testing tracking_number method: ", test_tracking_numbers)
    print("Testing ssn method: ", test_ssn)
    print("Testing personality method: ", test_personality) 

if __name__ == "__main__":
    test_USASpecProvider()

# Generated at 2022-06-23 20:34:18.791033
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.enums import PostService
    from mimesis.providers.us import USASpecProvider
    assert USASpecProvider().tracking_number() == "1Z856A6Y9895835658"
    assert USASpecProvider().tracking_number(PostService.UPS) == "1Z856A6Y9895835658"
    assert USASpecProvider().tracking_number(PostService.USPS) == "7287 6825 6700 0777 8951"
    assert USASpecProvider().tracking_number(PostService.FedEx) == "3007 6609 2584"


# Generated at 2022-06-23 20:34:21.528838
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    rnd_ssn = usa.ssn()
    is_valid_ssn = len(rnd_ssn.split('-')) == 3
    assert is_valid_ssn

# Generated at 2022-06-23 20:34:32.182347
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test tracking_number method of class USASpecProvider."""
    provider = USASpecProvider()
    tracking_number = provider.tracking_number(service='ups')
    assert len(tracking_number) == 18
    assert tracking_number[0] == '1'
    assert tracking_number[1] == 'Z'
    assert tracking_number[3] == 'A'
    assert tracking_number[4] == 'A'
    assert tracking_number[5] == 'A'
    assert tracking_number[6] == 'A'
    assert tracking_number[7] == 'A'
    assert tracking_number[8] == 'A'
    assert tracking_number[9] == 'A'
    assert tracking_number[10] == 'A'
    assert tracking_number[11] == 'A'
    assert tracking_

# Generated at 2022-06-23 20:34:40.438408
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import Category

    usa_provider = USASpecProvider(seed=123)
    assert usa_provider.personality(category=Category.RHETI) in range(1, 11)
    assert usa_provider.personality(category=Category.MBTI) in (
        'ISFJ',
        'ISTJ',
        'INFJ',
        'INTJ',
        'ISTP',
        'ISFP',
        'INFP',
        'INTP',
        'ESTP',
        'ESFP',
        'ENFP',
        'ENTP',
        'ESTJ',
        'ESFJ',
        'ENFJ',
        'ENTJ',
    )

# Generated at 2022-06-23 20:34:44.360726
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    data = ["1901 0012 0242 4862 4129", "91 985 571 467 US", "3195 0584 4133", "4268 4610 8949 166", "1Z82051A4755049995"]

    for d in data:
        assert d in USASpecProvider().tracking_number()


# Generated at 2022-06-23 20:34:46.689027
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():

    from mimesis.providers.usaspec import USASpecProvider

    usa_provider = USASpecProvider()

    for i in range(0, 10):
        assert len(usa_provider.tracking_number()) == 22



# Generated at 2022-06-23 20:34:48.336702
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """ Test for the constructor of class USASpecProvider"""
    a = USASpecProvider()
    assert type(a) == USASpecProvider
