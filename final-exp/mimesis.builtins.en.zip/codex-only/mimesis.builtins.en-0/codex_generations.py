

# Generated at 2022-06-23 20:24:53.567848
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    test_data = []
    for i in range(10):
        test_data.append(usa_provider.ssn())
    for item in test_data:
        assert item == '000-00-0000'


# Generated at 2022-06-23 20:24:56.681702
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    assert len(USASpecProvider().ssn()) == 11
    assert USASpecProvider().ssn()[3] == '-'
    assert USASpecProvider().ssn()[6] == '-'

# Generated at 2022-06-23 20:25:02.921184
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality of class USASpecProvider."""
    from mimesis.enums import Category
    assert USASpecProvider(seed=123).personality(category=Category.MBTI) == 'ISFJ'
    assert USASpecProvider(seed=123).personality(category=Category.RHETI) == 7


# Generated at 2022-06-23 20:25:09.868497
# Unit test for method tracking_number of class USASpecProvider

# Generated at 2022-06-23 20:25:15.999305
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    for num in range(0, 10):
        assert usa_spec_provider.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                   'ISTP', 'ISFP', 'INFP', 'INTP',
                                                   'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                   'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
        num = usa_spec_provider.personality(category='rheti')
        assert num in range (1, 10)



# Generated at 2022-06-23 20:25:19.219761
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # create an instance of USASpecProvider
    usaSpecProvider = USASpecProvider()

    # generate a personality
    personality_type = usaSpecProvider.personality(category='rheti')

    # test the result
    assert (1 <= personality_type <= 10)
# EOF

# Generated at 2022-06-23 20:25:23.292691
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert check_match_re(usa.tracking_number('usps'), r'\d{22}$')
    assert check_match_re(usa.tracking_number('FedEx'), r'\d{12}$')
    assert check_match_re(usa.tracking_number('UPS'), r'1Z[A-Z]{3}\d{16}')


# Generated at 2022-06-23 20:25:27.055175
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.provider == 'usa_provider'
    assert usa.locale == 'en'
    assert isinstance(usa.seed, int)


# Generated at 2022-06-23 20:25:28.372436
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() is not None


# Generated at 2022-06-23 20:25:33.582384
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()

    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFP', 'ENTJ')


# Generated at 2022-06-23 20:25:34.856110
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    spec = USASpecProvider()
    assert spec is not None


# Generated at 2022-06-23 20:25:38.114049
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_provider = USASpecProvider()
    us_provider.random.set_seed('mimesis')
    print(us_provider.tracking_number(service = 'usps'))
    print(us_provider.tracking_number(service = 'fedex'))
    print(us_provider.tracking_number(service = 'ups'))


# Generated at 2022-06-23 20:25:44.771865
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    usps_tracking_number = usa.tracking_number()
    fedex_tracking_number = usa.tracking_number('fedex')
    ups_tracking_number = usa.tracking_number('ups')

    assert bool(usps_tracking_number)
    assert bool(fedex_tracking_number)
    assert bool(ups_tracking_number)


# Generated at 2022-06-23 20:25:46.618027
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider"""
    assert USASpecProvider().seed is not None


# Generated at 2022-06-23 20:25:52.142869
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    assert us.random.__class__.__name__ == 'Random'
    assert us.datetime.__class__.__name__ == 'DateTime'
    assert hasattr(us.random, 'seed')
    assert hasattr(us.random, 'random')
    assert hasattr(us.random, 'getrandbits')



# Generated at 2022-06-23 20:25:56.294013
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test ss of USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    ssn = usa_spec_provider.ssn()
    assert isinstance(ssn, str)
    assert len(ssn) == 11
    assert ssn[3] == '-' and ssn[6] == '-'
    assert ssn[-4:] != '0000'


# Generated at 2022-06-23 20:25:58.704723
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()

    for i in range(0,10):
        print(usa.tracking_number())


# Generated at 2022-06-23 20:26:00.216834
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert len(provider.ssn()) == 11


# Generated at 2022-06-23 20:26:01.395513
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # USASpecProvider()
    assert USASpecProvider()


# Generated at 2022-06-23 20:26:09.837794
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from pprint import pprint
    from time import time
    from random import randint
    from mimesis.enums import Gender
    from mimesis.providers.date_time import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.localization import Localization
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Utilities, Address
    from mimesis.providers.payment import Payment
    from mimesis.providers.business import Business
    from mimesis.enums import Gender
    from mimesis.providers.identifiers import SocialInsuranceNumber
    from mimesis.providers.lorem import Lorem

# Generated at 2022-06-23 20:26:21.211761
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.us_provider import USASpecProvider

    usa = USASpecProvider()

    # "ISFJ" is valid for method personality
    assert usa.personality(category='mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    # "5" is valid for method personality

# Generated at 2022-06-23 20:26:30.537349
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.enums import PostCodeType
    spec = USASpecProvider()
    assert isinstance(spec.tracking_number(), str)
    assert isinstance(spec.tracking_number('USPS'), str)
    assert isinstance(spec.ssn(), str)
    assert isinstance(spec.ssn(), str)
    assert isinstance(spec.postal_code_type(PostCodeType.ZIP_CODE), str)
    assert isinstance(spec.postal_code_type(PostCodeType.ZIP_CODE_PLUS_FOUR), str)
    assert isinstance(spec.personality(), str)
    assert isinstance(spec.personality('rheti'), int)

# Generated at 2022-06-23 20:26:36.461521
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    test_object_USASpecProvider = USASpecProvider()
    for i in range(10):
        assert len(test_object_USASpecProvider.personality('mbti'))==4
        assert test_object_USASpecProvider.personality('rheti')<11
        assert test_object_USASpecProvider.personality('rheti')>0


# Generated at 2022-06-23 20:26:44.806254
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider(seed='test')
    assert usa.ssn() == '168-62-7124'
    assert usa.tracking_number() == '1340 6258 0475 4237 5847'
    assert usa.tracking_number(service='ups') == '1Z6A19A33787178415'
    assert usa.tracking_number('fedex') == '2394 3399 6316'
    assert usa.personality() == 'INFJ'
    assert usa.personality(category='rheti') == 1

# Generated at 2022-06-23 20:26:46.300573
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
	obj = USASpecProvider()
	assert obj is not None


# Generated at 2022-06-23 20:26:48.807730
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method ssn of class USASpecProvider."""
    usssn = USASpecProvider()
    assert type(usssn.ssn()) is str


# Generated at 2022-06-23 20:26:51.182789
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.tracking_number() is not None
    assert usa.ssn() is not None
    assert usa.personality() is not None

# Generated at 2022-06-23 20:26:52.978291
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    ssn = USASpecProvider().ssn()
    assert ssn



# Generated at 2022-06-23 20:26:55.661260
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test personality method of USASpecProvider class."""
    tmp = USASpecProvider()
    tmp2 = tmp.personality()
    tmp.seed(10)
    tmp3 = tmp.personality()

    assert tmp3 == tmp2

# Generated at 2022-06-23 20:26:57.014962
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert len(USASpecProvider().tracking_number()) >= 4


# Generated at 2022-06-23 20:27:06.022907
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaspec = USASpecProvider()
    result = usaspec.personality()
    assert result in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ',
    )
    assert isinstance(usaspec.personality(category='rheti'), int)
    assert usaspec.personality(category='rheti') in range(1, 11)



# Generated at 2022-06-23 20:27:07.559541
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider(seed=1)
    name = usa.personality('mbti')
    assert name == 'INTP', "test_USASpecProvider_personality failed."


# Generated at 2022-06-23 20:27:14.117966
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from pprint import pprint
    usa = USASpecProvider()
    # Get tracking number
    pprint(usa.tracking_number())
    pprint(usa.tracking_number('fedex'))
    pprint(usa.tracking_number('ups'))
    # Get SSN
    pprint(usa.ssn())
    # Get personality
    pprint(usa.personality())
    pprint(usa.personality('rheti'))

# Generated at 2022-06-23 20:27:22.157608
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import Category
    from mimesis.providers.personality import Personality

    en = Personality('en')
    usa = USASpecProvider()

    assert isinstance(usa.personality(), str)
    assert isinstance(usa.personality(Category.PERSONALITY.value), str)
    assert usa.personality(Category.PERSONALITY.value) in en.mbti()
    assert isinstance(usa.personality(category='rheti'), int)
    assert 1 <= usa.personality(category='rheti') <= 10



# Generated at 2022-06-23 20:27:33.000872
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test method tracking_number of class USASpecProvider."""
    usa = USASpecProvider()

# Generated at 2022-06-23 20:27:34.089142
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    v = USASpecProvider()


# Generated at 2022-06-23 20:27:35.266586
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    spec = USASpecProvider()
    assert spec is not None


# Generated at 2022-06-23 20:27:41.333099
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    spec_provider = USASpecProvider()
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert spec_provider.personality() in mbtis, 'This is not a MBTI personality'
    assert spec_provider.personality(category='rheti') in range(1,11), 'This is not a Rheti personality'

# Generated at 2022-06-23 20:27:43.881683
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # test_USASpecProvider_ssn_1
    seed = 0
    actual = USASpecProvider(seed=seed).ssn()
    expected = '268-64-8755'
    assert actual == expected

# Generated at 2022-06-23 20:27:45.451305
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    assert usa.ssn() == '724-64-6118'


# Generated at 2022-06-23 20:27:51.934506
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    name = 'usaspecialprovider.py'
    import sys
    if name in sys.modules:
        del sys.modules[name]
    from usa_provider import USASpecProvider
    us = USASpecProvider()
    personality = us.personality()
    assert personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                           'ISTP', 'ISFP', 'INFP', 'INTP',
                           'ESTP', 'ESFP', 'ENFP', 'ENTP',
                           'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    personality = us.personality(category='rheti')
    assert personality in range(1, 11)


# Generated at 2022-06-23 20:27:57.783994
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert 1 <= provider.personality('rheti') <= 10


# Generated at 2022-06-23 20:28:05.643124
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                            'ISTP', 'ISFP', 'INFP', 'INTP',
                                            'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert provider.personality('rheti') in range(1, 11)

# Generated at 2022-06-23 20:28:07.060860
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() == '786-14-4927'

# Generated at 2022-06-23 20:28:08.023222
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    USASpecProvider().personality()


# Generated at 2022-06-23 20:28:16.151059
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    p = USASpecProvider()
    assert p.ssn() in ["000-00-0000", "999-99-9999"]


## References:
# https://www.usps.com/business/web-tools-apis/address-information-apis.htm#_Toc518951222
# http://www.postalreference.com/usps-track-trace
# http://www.ups.com/WebTracking/track?loc=en_US
# http://www.fedex.com/us/

# Generated at 2022-06-23 20:28:18.301935
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # USASpecProvider.tracking_number() => str
    assert type(USASpecProvider().tracking_number()) == str


# Generated at 2022-06-23 20:28:20.049903
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec_provider = USASpecProvider()
    usa_spec_provider.tracking_number()

# Generated at 2022-06-23 20:28:20.997297
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()


# Generated at 2022-06-23 20:28:22.176972
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider."""
    assert len(USASpecProvider().ssn()) == 11

# Generated at 2022-06-23 20:28:24.838260
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Expected result is a string of an SSN"""
    from mimesis.providers.usa.en import USASpecProvider
    usa_provider = USASpecProvider()
    assert type(usa_provider.ssn()) == str

# Generated at 2022-06-23 20:28:29.045461
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test the method tracking_number of class USASpecProvider."""
    usa_provider = USASpecProvider()
    assert usa_provider.tracking_number(service='usps') != ''


# Generated at 2022-06-23 20:28:32.023544
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider."""
    spec = USASpecProvider(seed=123)
    assert spec._seed == 123


# Generated at 2022-06-23 20:28:38.071206
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    usa = USASpecProvider()

    usps = usa.tracking_number(service='usps')
    print(f"USPS tracking number: {usps}")

    fedex = usa.tracking_number(service='fedex')
    print(f"FedEx tracking number: {fedex}")

    ups = usa.tracking_number(service='ups')
    print(f"UPS tracking number: {ups}")

    unknown_service = usa.tracking_number(service='unknown-service')
    print(f"Unknown service tracking number: {unknown_service}")


# Generated at 2022-06-23 20:28:40.886444
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """ Testing constructor of class USASpecProvider"""
    obj = USASpecProvider()
    assert obj.__class__.__name__ == "USASpecProvider"


# Generated at 2022-06-23 20:28:44.155373
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == "082-56-9391"


# Generated at 2022-06-23 20:28:46.803361
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    us.tracking_number(service='usps')
    us.tracking_number(service='fedex')
    us.tracking_number(service='ups')


# Generated at 2022-06-23 20:28:49.530813
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    
    assert len(ssn) == 11


# Generated at 2022-06-23 20:28:54.963863
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    print(us.ssn())
    print(us.tracking_number())
    print(us.tracking_number(service="UPS"))
    print(us.personality())
    print(us.personality(category="rheti"))

test_USASpecProvider()

# Generated at 2022-06-23 20:28:56.274292
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    assert usa.ssn()

# Generated at 2022-06-23 20:28:58.134156
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    usa_spec_provider.personality()

# Generated at 2022-06-23 20:28:59.870018
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test constructor of class USASpecProvider."""
    assert USASpecProvider()



# Generated at 2022-06-23 20:29:06.391271
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Initialize an instance of USASpecProvider
    usa = USASpecProvider(seed=1)

    # Tests for method personality of class USASpecProvider
    assert usa.personality(category='rheti') == 7
    assert usa.personality(category='mbti') == 'INTP'



# Generated at 2022-06-23 20:29:08.564463
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider(seed=101)
    assert provider.ssn() == '185-76-8651'


# Generated at 2022-06-23 20:29:12.613147
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()

    assert isinstance(usa.personality(), str)
    assert isinstance(usa.personality(category='rheti'), int)


# Generated at 2022-06-23 20:29:16.666187
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for method ssn of class USASpecProvider"""
    provider = USASpecProvider()

    for _ in range(100):
        ssn = provider.ssn()
        assert ssn.count('-') == 2

        area_code, group_code, serial_number = ssn.split('-')

        assert int(area_code) in range(1, 900)
        assert int(group_code) in range(1, 100)
        assert int(serial_number) in range(1, 10000)

# Generated at 2022-06-23 20:29:22.180651
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

# Generated at 2022-06-23 20:29:23.699020
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert isinstance(provider.personality(), str)



# Generated at 2022-06-23 20:29:25.446625
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.providers.usa import USASpecProvider
    provider = USASpecProvider()
    assert len(provider.ssn()) == 11
    assert provider.ssn() != provider.ssn()


# Generated at 2022-06-23 20:29:31.922446
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider"""

    # Test for default parameter
    assert (set(USASpecProvider().personality('mbti') for i in range(1000))) == set(
        ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
         'ISTP', 'ISFP', 'INFP', 'INTP',
         'ESTP', 'ESFP', 'ENFP', 'ENTP',
         'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'])

    # Test for different category
    assert (set(USASpecProvider().personality('rheti') for i in range(1000))) == set(
        range(1, 10))

# Generated at 2022-06-23 20:29:41.636450
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    test_usps_tracking_number_value = '9400 1112 2222 3333 4444'
    test_fedex_tracking_number_value = '4009 1390 3429'
    test_ups_tracking_number_value = '1Z1234567890'

    test_usps_tracking_number = USASpecProvider().tracking_number(service='usps')
    test_fedex_tracking_number = USASpecProvider().tracking_number(service='fedex')
    test_ups_tracking_number = USASpecProvider().tracking_number(service='ups')

    assert test_usps_tracking_number_value == test_usps_tracking_number
    assert test_fedex_tracking_number_value == test_fedex_tracking_number
    assert test_ups_tracking_number_value == test_ups_

# Generated at 2022-06-23 20:29:44.737846
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaSpecProvider = USASpecProvider()
    assert 'ISFJ' == usaSpecProvider.personality(category='mbti')
    assert '9' == usaSpecProvider.personality(category='rheti')

# Generated at 2022-06-23 20:29:45.644843
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider(seed=555)


# Generated at 2022-06-23 20:29:47.764153
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider()
    assert us.tracking_number().isalnum()


# Generated at 2022-06-23 20:29:50.404968
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    p = USASpecProvider()
    ssn = p.ssn()
    assert ssn.split('-')[0] in ('000', '666') is False


# Generated at 2022-06-23 20:29:54.870822
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.providers.us import USASpecProvider
    us = USASpecProvider()
    assert len(us.tracking_number()) == 18
    assert len(us.tracking_number(service='fedex')) == 17
    assert len(us.tracking_number(service='ups')) == 18
    assert len(us.tracking_number(service='dhl')) != 18



# Generated at 2022-06-23 20:30:03.216105
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality of class USASpecProvider."""

    usa = USASpecProvider()

    assert usa.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                'ISTP', 'ISFP', 'INFP', 'INTP',
                                                'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert usa.personality(category='rheti') in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-23 20:30:08.785881
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us = USASpecProvider(seed=1)

    usps   = us.tracking_number('usps')
    ups    = us.tracking_number('ups')
    fedex  = us.tracking_number('fedex')

    assert usps   == '3055 4745 7955 9015 6591'
    assert ups    == '1Z8V74W80342923611'
    assert fedex  == '7985 4822 8411'


# Generated at 2022-06-23 20:30:10.691354
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
	usa_provider = USASpecProvider(seed=300)
	assert isinstance(usa_provider, USASpecProvider)


# Generated at 2022-06-23 20:30:14.511507
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    assert us.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert 1 <= us.personality(category='rheti') <= 10
    try:
        us.personality(category='non_existing_category')
        assert False
    except:
        assert True
        pass


# Generated at 2022-06-23 20:30:19.440977
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_spec_provider = USASpecProvider()
    ssn = usa_spec_provider.ssn()
    assert len(ssn) == 11
    assert ssn[3:5] != '66'
    assert ssn[6:8] != '00'
    for i in range(9, 13):
        assert '0' <= ssn[i] <= '9'


# Generated at 2022-06-23 20:30:22.984959
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.personality(), str)
    assert isinstance(usa_provider.personality('rheti'), int)

# Generated at 2022-06-23 20:30:32.305360
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Testing the method personality of class USASpecProvider."""
    test = USASpecProvider()
    assert test.personality('mbti') in ['ISFJ','ISTJ','INFJ','INTJ','ISTP','ISFP','INFP','INTP','ESTP','ESFP','ENFP','ENTP','ESTJ','ESFJ','ENFJ','ENTJ']
    assert type(test.personality('rheti')) == int
    assert test.personality('rheti') in range(1, 11)

# Generated at 2022-06-23 20:30:34.281499
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    s = USASpecProvider()
    assert s.personality() == ''

# Generated at 2022-06-23 20:30:36.408754
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test class USASpecProvider."""
    provider = USASpecProvider()
    assert provider.__class__.__name__ == 'USASpecProvider'

# Generated at 2022-06-23 20:30:39.774824
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test if USASpecProvider initializes correctly."""
    from mimesis.enums import Gender
    us = USASpecProvider()
    assert us.get_gender(gender=Gender.FEMALE) == 'Female'

# Generated at 2022-06-23 20:30:42.302429
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    usa_provider.personality()


#Unit test for method ssn of class USASpecProvider

# Generated at 2022-06-23 20:30:44.982393
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert len(USASpecProvider().tracking_number(service='usps')) == 22
    assert len(USASpecProvider().tracking_number(service='usps').replace(' ', '')) == 22


# Generated at 2022-06-23 20:30:50.129330
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.providers.usa.usa_provider import USASpecProvider

    usa_provider = USASpecProvider('en')

    for i in range(100):
        assert(len(usa_provider.personality('mbti')) == 4)

# Generated at 2022-06-23 20:30:54.175697
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method ssn of class USASpecProvider."""
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert type(ssn) is str
    assert len(ssn) == 11


# Generated at 2022-06-23 20:30:55.821141
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    x = USASpecProvider()
    assert x.ssn() != x.ssn()


# Generated at 2022-06-23 20:30:57.971988
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.ssn(), str), "fail"


# Generated at 2022-06-23 20:31:00.587065
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality('rheti') in [1,2,3,4,5,6,7,8,9,10]


# Generated at 2022-06-23 20:31:08.290752
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of the class USASpecProvider."""
    test_USASpecProvider = USASpecProvider()
    assert test_USASpecProvider.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                  'ISTP', 'ISFP', 'INFP', 'INTP',
                                                  'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                  'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:31:11.980389
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usaSpecProvider = USASpecProvider()
    assert usaSpecProvider.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:31:14.569937
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """
    Implement unit test for constructor of class USASpecProvider

    :return:
    """
    us = USASpecProvider()
    us.seed("123")


# Generated at 2022-06-23 20:31:21.679935
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()

    # Calling tracking_number() with an unacceptable argument should
    # raise a ValueError
    try:
        provider.tracking_number(service='throw-away')
        assert False
    except ValueError:
        assert True

    # Calling tracking_number() with an acceptable argument should not raise
    # a ValueError
    try:
        assert len(provider.tracking_number(service='usps')) > 0
        assert True
    except ValueError:
        assert False

    # Calling ssn() should return a string
    assert isinstance(provider.ssn(), str)

    # Calling personality() with an acceptable argument should not raise
    # a ValueError
    try:
        assert len(provider.personality()) > 0
        assert True
    except ValueError:
        assert False

    # Calling personality

# Generated at 2022-06-23 20:31:30.082579
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    t = USASpecProvider()
    assert t.tracking_number() is not None and t.tracking_number() != ""
    assert t.tracking_number().isnumeric() is True
    assert t.tracking_number("usps") is not None and t.tracking_number("usps") != ""
    assert t.tracking_number("usps").isnumeric() is True
    assert t.tracking_number("ups") is not None and t.tracking_number("ups") != ""
    assert t.tracking_number("ups").isnumeric() is True
    assert t.tracking_number("fedex") is not None and t.tracking_number("fedex") != ""
    assert t.tracking_number("fedex").isnumeric() is True
    assert t.tracking_number("notaservice") is None

# Generated at 2022-06-23 20:31:33.819749
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # client = USASpecProvider()
    usa_spec_provider_client = USASpecProvider()
    assert len(usa_spec_provider_client.ssn()) == 11


# Generated at 2022-06-23 20:31:36.036949
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():    
    a = USASpecProvider(seed=0)
    assert a.ssn() == '112-76-8266'

# Generated at 2022-06-23 20:31:42.623314
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality of class USASpecProvider."""
    usp = USASpecProvider()
    assert usp.personality('mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    )
    assert 1 <= usp.personality('rheti') <= 10


# Generated at 2022-06-23 20:31:51.025232
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality(category='rheti') in range(1, 10)
    assert usa_provider.personality() in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    ]

# Generated at 2022-06-23 20:31:54.266293
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for USASpecProvider.personality."""
    provider = USASpecProvider()
    subtype = provider.personality()
    assert isinstance(subtype, str)


# Generated at 2022-06-23 20:32:00.604013
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    tmp = USASpecProvider()

    mbti = tmp.personality()
    assert mbti in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                    'ISTP', 'ISFP', 'INFP', 'INTP',
                    'ESTP', 'ESFP', 'ENFP', 'ENTP',
                    'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    assert tmp.personality('rheti') in range(1, 11)

# Generated at 2022-06-23 20:32:02.760530
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    g = USASpecProvider()
    result = g.tracking_number(service='usps')
    assert "B531 0648" in result


# Generated at 2022-06-23 20:32:14.629007
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # It will test the method personality of class USASpecProvider
    # using pytest
    # Step 1 : create an instance of class USASpecProvider
    us = USASpecProvider()
    # Step 2 : run the method personality
    p1 = us.personality()
    assert p1 in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    # Step 3 : run the method personality with "rheti" as parameter
    p2 = us.personality(category='rheti')
    assert p2 in list(range(1, 10+1))


# Generated at 2022-06-23 20:32:18.793227
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
	us = USASpecProvider()
	ssn = us.ssn()
	assert len(ssn) == 11
	assert ssn[3] == '-'
	assert ssn[6] == '-'


# Generated at 2022-06-23 20:32:20.981642
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    for i in range(1, 10):
        print(provider.ssn())


# Generated at 2022-06-23 20:32:25.689261
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider(seed=42).tracking_number() == '9358 7826 9246 5697'
    assert USASpecProvider(seed=42).tracking_number(service='fedex') == '5252 9369 1863'
    assert USASpecProvider(seed=42).tracking_number(service='ups') == '1Z66416E0492602229'


# Generated at 2022-06-23 20:32:30.177352
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality(): # type: ignore
    usa = USASpecProvider()
    assert usa.personality(category='mbti') in usa.personality(category='mbti')
    assert usa.personality(category='rheti') in usa.personality(category='rheti')

# Generated at 2022-06-23 20:32:31.140919
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert len(USASpecProvider().personality()) == 4

# Generated at 2022-06-23 20:32:41.328432
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider()

# Generated at 2022-06-23 20:32:43.904864
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Create an instance of class USASpecProvider
    usa = USASpecProvider()
    
    # Check that values are not null
    assert usa.tracking_number() != None
    assert usa.ssn() != None
    assert usa.personality() != None

# Generated at 2022-06-23 20:32:51.024337
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number(service='usps') == '0657 9669 6259 0690 5953'
    assert USASpecProvider().tracking_number(service='usps') == '1Z 827 967 63 5045 445 5'
    assert USASpecProvider().tracking_number(service='fedex') == '9589 0569 8803'
    assert USASpecProvider().tracking_number(service='fedex') == '3750 1804 7441'
    assert USASpecProvider().tracking_number(service='ups') == '1Z G48 9E4 80 4844 803 9'


# Generated at 2022-06-23 20:32:54.991698
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('en')
    gender = Gender.FEMALE
    assert person.gender(gender=gender) == 'female'



# Generated at 2022-06-23 20:33:04.056275
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    # assert provider.ssn() in [], 'Expected value not found in %s' % provider.ssn()
    assert len(provider.ssn()) == 11, 'Should be 11'
    assert provider.ssn()[3] == '-', 'Should be -'
    assert provider.ssn()[6] == '-', 'Should be -'
    assert provider.ssn()[:3].isnumeric() == True, 'Should be numbers'
    assert provider.ssn()[4:6].isnumeric() == True, 'Should be numbers'
    assert provider.ssn()[7:].isnumeric() == True, 'Should be numbers'


# Generated at 2022-06-23 20:33:07.726063
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    result = provider.ssn()
    assert result.isdigit() is True
    assert len(result) == 11
    assert "-" in result
    assert len(result.split("-")) == 3
    assert result.split("-")[0].isdigit() is True
    assert result.split("-")[1].isdigit() is True
    assert result.split("-")[2].isdigit() is True


# Generated at 2022-06-23 20:33:12.310681
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Constructor test for class USASpecProvider."""
    usa = USASpecProvider()
    assert usa.locale == 'en'
    assert usa.code == 'en_US'
    assert usa.name == 'usa_provider'


# Generated at 2022-06-23 20:33:15.140584
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec = USASpecProvider()
    assert (usa_spec is not None)
    assert (isinstance(usa_spec.random, type(usa_spec.random)))


# Generated at 2022-06-23 20:33:16.913854
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert usa_provider.ssn() != ""

# Generated at 2022-06-23 20:33:18.566228
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_provider = USASpecProvider()
    assert type(usa_provider.ssn()) == str


# Generated at 2022-06-23 20:33:20.233584
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    u = USASpecProvider()
    assert isinstance(u.ssn(), str)

# Generated at 2022-06-23 20:33:31.232539
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # print("Entering test_USASpecProvider_personality")
    test_obj = USASpecProvider()

    cat = 'mbti'
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')

    for i in range(5):
        print(test_obj.personality(cat))
        #print(test_obj.personality(cat))

    cat = 'rheti'
    for i in range(5):
        print(test_obj.personality(cat))
        #print(test_obj.personality(cat))

    cat

# Generated at 2022-06-23 20:33:39.170860
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in ['ISFJ','ISTJ','INFJ','INTJ','ISTP','ISFP','INFP','INTP','ESTP','ESFP','ENFP','ENTP','ESTJ','ESFJ','ENFJ','ENTJ']
    assert usa_spec_provider.personality("rheti") in range(1,10)

# Generated at 2022-06-23 20:33:40.504806
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a = USASpecProvider()

    assert a.tracking_number() != None

# Generated at 2022-06-23 20:33:40.981792
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
  assert True

# Generated at 2022-06-23 20:33:45.078484
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    sp = USASpecProvider()
    assert sp.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP',
                                'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'), "Wrong result for USASpecProvider.personality()"
    assert (1 <= sp.personality("rheti") <= 10), "Wrong result for USASpecProvider.personality(rheti)"

# Generated at 2022-06-23 20:33:47.173231
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert(usa_spec_provider)


# Generated at 2022-06-23 20:33:48.529607
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert(USASpecProvider().ssn() != USASpecProvider().ssn())

# Generated at 2022-06-23 20:33:50.465482
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider"""
    result = USASpecProvider()
    assert result != None


# Generated at 2022-06-23 20:33:51.695275
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    print(usa.ssn())

# Generated at 2022-06-23 20:34:02.089365
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from random import seed

    from mimesis.enums import Service

    provider = USASpecProvider(seed=11)

    assert provider.tracking_number(service=Service.FEDEX.value) \
        in ['4870 0641 7264', '4571 0858 0951 643']
    assert provider.tracking_number(service=Service.USPS.value) \
        in ['0032 6292 2869 8177', '0764 1855 US']
    assert provider.tracking_number(service=Service.UPS.value) \
        in ['1Z A0021 0108 2868 009']
    assert provider.tracking_number(service='Unsupported') == ''

    seed(11)

# Generated at 2022-06-23 20:34:06.085343
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    x = USASpecProvider().personality()
    assert x in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')



# Generated at 2022-06-23 20:34:11.966224
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()

    user_input = input('Enter your tracking number: ')

    if usa.tracking_number(service="usps") == user_input:
        print('The tracking number is valid')
    else:
        print('The tracking number is invalid')


# Generated at 2022-06-23 20:34:20.667974
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(usa_spec_provider.personality(category=''), str)
    assert isinstance(usa_spec_provider.personality(category='rheti'), int)

# Generated at 2022-06-23 20:34:23.159626
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert len(provider.personality()) == 4



# Generated at 2022-06-23 20:34:25.520847
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Test if there any error
    for i in range(500):
        a = USASpecProvider().ssn() # type: ignore


# Generated at 2022-06-23 20:34:27.500480
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() == '000-00-0000'

# Generated at 2022-06-23 20:34:30.099712
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    result = usa_provider.random.randint(0, 100)
    assert isinstance(result, int)


# Generated at 2022-06-23 20:34:32.096260
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us_provider = USASpecProvider()
    result = us_provider.ssn()
    assert result is not None


# Generated at 2022-06-23 20:34:33.270728
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    print(USASpecProvider().tracking_number())


# Generated at 2022-06-23 20:34:38.940989
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # This test demonstrates the error `Unsupported post service`
    usa = USASpecProvider()
    try:
        usa.tracking_number(service='Unsupported')
    except ValueError:
        print('Unsupported post service')
    print()

    # This test demonstrates the USPS tracking number
    usa = USASpecProvider()
    print(usa.tracking_number(service='usps'))
    print()

    # This test demonstrates the FedEx tracking number
    usa = USASpecProvider()
    print(usa.tracking_number(service='fedex'))
    print()

    # This test demonstrates the UPS tracking number
    usa = USASpecProvider()
    print(usa.tracking_number(service='ups'))
    print()


# Generated at 2022-06-23 20:34:42.623810
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider(seed=42)
    assert provider.personality(category='mbti') == 'ESFJ'
    assert provider.personality(category='rheti') == 6


# Generated at 2022-06-23 20:34:49.614985
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Define a valid test for method personality of class USASpecProvider.
    
    To test the method, make sure that the test file is in the same
    directory as the mimesis package and run:
    
    $ python3 -m pytest test_USASpecProvider_personality.py
    
    To run a specific test from the module:
    
    $ pytest -k test_USASpecProvider_personality.py::test_personality
    """
    spec = USASpecProvider()
    result = spec.personality()
    assert(isinstance(result, str) and
           (len(result) == 4 or len(result) == 5))
