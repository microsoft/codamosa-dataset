

# Generated at 2022-06-23 20:24:57.867762
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()

    assert usa_provider.personality('mbti') in ['ISFJ', 'ISTP', 'ESTP', 'ESTJ', 'ETC.']
    assert usa_provider.personality('rheti') in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


# Generated at 2022-06-23 20:24:59.931439
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    a = USASpecProvider()
    a.ssn()


# Generated at 2022-06-23 20:25:04.181858
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider(seed=11)
    assert usa_provider.personality() == 'ISFP'
    assert usa_provider.personality(category='mbti') == 'ISFP'
    assert usa_provider.personality(category='rheti') == 8


# Generated at 2022-06-23 20:25:06.900030
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tracking = USASpecProvider.tracking_number()
    USASpecProvider.tracking_number(service='usps')
    USASpecProvider.tracking_number(service='ups')
    USASpecProvider.tracking_number(service='fedex')

# Generated at 2022-06-23 20:25:15.644425
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category='rheti') <= 10
    assert USASpecProvider().personality(category='mbti') in [
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    ]

# Generated at 2022-06-23 20:25:17.854306
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    prov = USASpecProvider()
    assert len(prov.tracking_number(service='usps')) == 22


# Generated at 2022-06-23 20:25:24.633081
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    for i in range(100):
        ssn = provider.ssn()
        if (ssn != '666-66-5801'):
            if (len(ssn) != 11):
                raise ValueError("Invalid length!")
            if (ssn[3] != '-' or ssn[6] != '-'):
                raise ValueError("Invalid format!")
        else:
            if (len(ssn) != 11):
                raise ValueError("Invalid length!")
            if (ssn[3] != '-' or ssn[6] != '-'):
                raise ValueError("Invalid format!")
            if (ssn[0] != '6'):
                raise ValueError("Invalid format!")


# Generated at 2022-06-23 20:25:26.753318
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_spec = USASpecProvider()
    # print(usa_spec.ssn())

test_USASpecProvider_ssn()

# Generated at 2022-06-23 20:25:30.358513
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test USASpecProvider.personality function."""
    provider = USASpecProvider(seed='mimesis')
    result = provider.personality()
    assert result == 'INFJ'

    # Rheti
    result = provider.personality(category='rheti')
    assert result == 2



# Generated at 2022-06-23 20:25:32.425195
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
  usa_spec_provider = USASpecProvider()
  assert type(usa_spec_provider.tracking_number()) == str


# Generated at 2022-06-23 20:25:34.111026
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_spec = USASpecProvider()
    print(usa_spec.tracking_number())


# Generated at 2022-06-23 20:25:35.991046
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert type(usa_provider.personality()) == int
    assert type(usa_provider.personality(category="mbti")) == str

# Generated at 2022-06-23 20:25:39.509764
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a = USASpecProvider()
    result = a.tracking_number(service="ups")
    print (result)
    print (len(result))
    print (a.tracking_number(service="ups"))
    print (a.tracking_number(service="fedex"))
    print (a.tracking_number(service="usps"))

# Generated at 2022-06-23 20:25:40.771294
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    us.personality()

# Generated at 2022-06-23 20:25:42.182416
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
	us=USASpecProvider()
	assert(us != None)

# Generated at 2022-06-23 20:25:47.735336
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():

    sp = USASpecProvider()

    assert len(sp.tracking_number()) == 22
    assert len(sp.tracking_number(service = "fedex")) == 16
    assert len(sp.tracking_number(service = "ups")) == 18
    assert isinstance(sp.tracking_number(service = "fedex"), str)



# Generated at 2022-06-23 20:25:49.666156
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    try:
        obj = USASpecProvider()
        res = obj.tracking_number()
        assert len(res) > 0
    except:
        assert False


# Generated at 2022-06-23 20:25:55.054461
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaSpecProvider = USASpecProvider()
    assert usaSpecProvider.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usaSpecProvider.personality('rheti') in range(1, 10)
    

# Generated at 2022-06-23 20:26:04.389495
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    usps_number = usa_provider.tracking_number(service='usps')
    assert len(usps_number) == 34
    assert usps_number == "T077 721 488 8US"
    fedex_number = usa_provider.tracking_number(service='fedex')
    assert len(fedex_number) == 16
    assert fedex_number == "2767 5387 7"
    ups_number = usa_provider.tracking_number(service='ups')
    assert len(ups_number) == 18
    assert ups_number == "1Z6F3940A1E490113A"


# Generated at 2022-06-23 20:26:08.247906
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    ssn = USASpecProvider().ssn()
    tracking_number = USASpecProvider().tracking_number()
    personality = USASpecProvider().personality()
    if (ssn != 1 and tracking_number != 1) and personality != 1:
        print("Succesfully USASpecProvider works correctly")
    else:
        print("The USASpecProvider is broken")


# Generated at 2022-06-23 20:26:15.967998
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    test_obj = USASpecProvider('test_seed')
    tests = []
    for i in range(0, 5):
        tests.append(test_obj.tracking_number(service='usps'))
        tests.append(test_obj.tracking_number(service='fedex'))
        tests.append(test_obj.tracking_number(service='ups'))

# Generated at 2022-06-23 20:26:21.260463
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # Testing with no special data
    data_provider = USASpecProvider()
    data_provider.seed(10)
    # Testing with special data
    data_provider = USASpecProvider(seed=10)
    data_provider.seed(10)
    assert data_provider.ssn() == '142-10-0472'
    assert data_provider.personality() == 'ISFJ'



# Generated at 2022-06-23 20:26:25.372469
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    random = USASpecProvider()

    assert random.usaspec.tracking_number() is not None
    assert random.usaspec.ssn() is not None
    assert random.usaspec.personality() is not None

    assert random.usaspec.tracking_number('fedEx') is not None
    assert random.usaspec.ssn() is not None
    assert random.usaspec.personality('rheTi') is not None

# Generated at 2022-06-23 20:26:30.723585
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    usa.seed(12)
    assert usa.personality() == 'ENTJ'
    assert usa.personality('rheti') == 8
    assert usa.personality('Rheti') == 10
    assert usa.personality('MBTI') == 'INFJ'


# Generated at 2022-06-23 20:26:32.835692
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usspec = USASpecProvider()
    print(usspec.ssn())


# Generated at 2022-06-23 20:26:39.979394
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for testing USASpecProvider.personality()."""
    usa = USASpecProvider()
    assert usa.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:26:46.754757
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
	provider = USASpecProvider()
	assert provider.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                     'ISTP', 'ISFP', 'INFP', 'INTP',
                                     'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                     'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
	assert 0 < provider.personality(category='rheti') < 11

# Generated at 2022-06-23 20:26:48.090565
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    prov = USASpecProvider()
    assert prov is not None


# Generated at 2022-06-23 20:26:53.461487
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()

    # Issues with 997 in area number
    assert provider.ssn() != '997-33-1234'
    assert provider.ssn() != '997-12-1234'

    # Issue with 999 in area number
    assert provider.ssn() != '998-33-1234'
    assert provider.ssn() != '999-12-1234'

    # Issue with 666 in area number
    assert provider.ssn() != '665-33-1234'
    assert provider.ssn() != '666-12-1234'

# Generated at 2022-06-23 20:26:57.791238
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    ssn_result = usa.ssn()
    assert '-' in ssn_result  # e.g. 569-66-5801
# end of test_USASpecProvider_ssn

# Generated at 2022-06-23 20:27:08.367875
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    generation = USASpecProvider()
    
    # Result for default ssn()
    default_ssn = generation.ssn()
    assert(isinstance(default_ssn,str))
    default_ssn_split = default_ssn.split('-')
    assert(len(default_ssn_split) == 3)
    assert(len(default_ssn_split[0]) == 3)
    assert(len(default_ssn_split[1])== 2)
    assert(len(default_ssn_split[2])== 4)
    if int(default_ssn_split[0]) in range(900):
        assert(666 not in default_ssn_split[0])


# Generated at 2022-06-23 20:27:13.526546
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    # test class attributes
    assert hasattr(USASpecProvider, 'Meta')
    assert hasattr(USASpecProvider, 'ssn')
    assert hasattr(USASpecProvider, 'tracking_number')
    assert hasattr(USASpecProvider, 'personality')
    assert hasattr(USASpecProvider, '__init__')


# Generated at 2022-06-23 20:27:15.790297
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.__class__.__name__ == 'USASpecProvider'


# Generated at 2022-06-23 20:27:22.646867
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_provider = USASpecProvider()
    # USPS tracking number is a 20-digit number with 4 dashes between consecutive groups of 4 digits.
    # "US" should be at the end of the number.
    tracking_number_usps = us_provider.tracking_number(service='USPS')
    assert len(tracking_number_usps) == 20
    assert tracking_number_usps[20-3:] == "US"

    # FedEx tracking number is 12 digits.
    tracking_number_fedex1 = us_provider.tracking_number(service='FedEx')
    assert len(tracking_number_fedex1) == 12
    # FedEx tracking number is also 15 digits.
    tracking_number_fedex2 = us_provider.tracking_number(service='FedEx')

# Generated at 2022-06-23 20:27:30.645142
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us_provider = USASpecProvider()
    assert us_provider.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert us_provider.personality('rheti') in range(1, 11)

# Generated at 2022-06-23 20:27:33.382572
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # Arrange
    spec = USASpecProvider()

    # Act
    result = spec.personality(category='mbti')

    # Assert
    assert isinstance(result, str)
    assert len(result) == 4


# Generated at 2022-06-23 20:27:35.507144
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)
    assert isinstance(usa, BaseSpecProvider)


# Generated at 2022-06-23 20:27:37.321852
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    assert us.code == 'en'
    assert isinstance(us.random, Seed)


# Generated at 2022-06-23 20:27:41.829932
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test USASpecProvider"""
    # Create a USASpecProvider
    usa_provider = USASpecProvider()

    # Test USASpecProvider
    assert str(usa_provider) == '<USASpecProvider>'

# Generated at 2022-06-23 20:27:43.058569
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number()


# Generated at 2022-06-23 20:27:46.806450
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    usa.seed(0)

    assert usa.ssn() == "259-90-4649"
    assert usa.tracking_number() == "5588 5803 1527 7354 6707"
    assert usa.personality(category="mbti") == "ISFJ"
    assert usa.personality(category="rheti") == 10

# Generated at 2022-06-23 20:27:49.626814
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tester = USASpecProvider()
    result = tester.tracking_number()
    assert result != ""


# Generated at 2022-06-23 20:27:51.352987
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    result = usa.tracking_number(service='USPS')
    assert result is not None


# Generated at 2022-06-23 20:27:53.119156
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11


# Generated at 2022-06-23 20:27:57.785848
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test USASpecProvider's personality method."""
    usa = USASpecProvider()

    # Check if return type is string
    assert type(usa.personality()) is str, 'Return type should be a string'
    # Check if return type is int
    assert type(usa.personality(category='rheti')) is int, 'Return type should be a int'

# Generated at 2022-06-23 20:27:59.610728
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert len(USASpecProvider().tracking_number()) == 35

# Generated at 2022-06-23 20:28:06.586593
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():

    # initialize the class
    USA = USASpecProvider()

    # test for valid USPS tracking number
    USPS_tracking_num = USA.tracking_number(service='usps')
    assert len(USPS_tracking_num) >= 18
    assert USPS_tracking_num[0:20] == '94001 10200 5833 0000'

    # test for valid FedEx tracking number
    FedEx_tracking_num = USA.tracking_number(service='fedex')
    assert len(FedEx_tracking_num) == 12
    assert FedEx_tracking_num[0:12] == '9612 9123 2346'

    # test for valid UPS tracking number
    UPS_tracking_num = USA.tracking_number(service='ups')
    assert len(UPS_tracking_num) == 18

# Generated at 2022-06-23 20:28:09.508692
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    usa.seed(10)
    tracking_number = usa.tracking_number()
    assert tracking_number == '5319 1297 4963 7603 0155'



# Generated at 2022-06-23 20:28:12.577232
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    for i in range(1, 100):
        print(provider.tracking_number())


# Generated at 2022-06-23 20:28:22.573332
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality(): 
    from mimesis.enums import Gender
    from mimesis.builtins import USASpecProvider
    usaSpecProvider = USASpecProvider()
    list_of_all_types = [] # to check if the returned type is unique
    category = "rheti"
    assert isinstance(usaSpecProvider.personality(category), int) # should be integer
    for i in range(9):
        list_of_all_types.append(usaSpecProvider.personality(category))
    unique_types = list(set(list_of_all_types)) # to check if the returned type is unique
    assert len(list_of_all_types)==len(unique_types) # if all types are unique, then length of list_of_all_types == length of unique_types

# Generated at 2022-06-23 20:28:34.565741
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Testing method personality of class USASpecProvider."""
    usa = USASpecProvider()
    # testing mbti category
    assert usa.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert usa.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    # testing rheti category

# Generated at 2022-06-23 20:28:37.244483
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    tester = USASpecProvider()
    assert tester.personality(category='rheti')
    assert tester.personality(category='mbti')

# Generated at 2022-06-23 20:28:40.262577
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    print(provider.personality(category="mbti"))
    print(provider.personality(category="rheti"))


# Generated at 2022-06-23 20:28:42.806128
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert len(USASpecProvider().tracking_number()) == 22


# Generated at 2022-06-23 20:28:46.255583
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    result = USASpecProvider().tracking_number()
    assert len(result) == 18
    assert result[5] == ' '
    assert result[11] == ' '
    assert result[15] == ' '


# Generated at 2022-06-23 20:28:51.047294
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method USASpecProvider.ssn."""
    provider = USASpecProvider()
    ssn = provider.ssn()

    assert isinstance(ssn, str)
    assert len(ssn) == 11
    assert ssn.count('-') == 2

    ssn = provider.ssn(raw=True)

    assert isinstance(ssn, int)
    assert len(str(ssn)) == 9



# Generated at 2022-06-23 20:28:51.802652
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider()


# Generated at 2022-06-23 20:28:58.075996
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.text import Text
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.us import USASpecProvider

    a = Address('en')
    t = Text('en')
    i = Internet('en')
    p = Person('en')
    u = USASpecProvider()

    print("Method personality of class USASpecProvider")
    print("\tPersonality type:")
    for i in range(10):
        print("\t\t{}".format(u.personality()))
        print("\t\t{}".format(u.personality("rheti")))


# Unit test

# Generated at 2022-06-23 20:29:06.232852
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Testing method tracking_number of class USASpecProvider."""
    from mimesis.enums import PostService

    # type = None
    provider = USASpecProvider()
    assert provider.tracking_number(service=None)

    # type = ''
    provider = USASpecProvider()
    assert provider.tracking_number(service='')

    # type = 'usps'
    provider = USASpecProvider()
    assert provider.tracking_number(service=PostService.USPS)

    # type = 'fedex'
    provider = USASpecProvider()
    assert provider.tracking_number(service=PostService.FEDEX)

    # type = 'ups'
    provider = USASpecProvider()
    assert provider.tracking_number(service=PostService.UPS)

    # type = 'post_service'


# Generated at 2022-06-23 20:29:11.617574
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    trackingNumber = usa.tracking_number(service='usps')
    assert trackingNumber == '1376 7894 2234 6061 2102'

    trackingNumber = usa.tracking_number(service='fedex')
    assert trackingNumber == '7486 9516 8665'

    trackingNumber = usa.tracking_number(service='ups')
    assert trackingNumber == '1Z1699W21836763817'



# Generated at 2022-06-23 20:29:23.134706
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    us.seed_instance('test')

    assert us.personality('rheti') in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    assert us.personality('mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    )

    assert us.tracking_number('FedEx') in (
        '#### #### #### ',
        '#### #### #### ###'
    )


# Generated at 2022-06-23 20:29:24.853268
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    for _ in range(100):
        assert len(USASpecProvider().personality('mbti')) == 4


# Generated at 2022-06-23 20:29:30.382182
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    up = USASpecProvider()
    for i in range(1000):
        ssn = up.ssn()
        assert len(ssn) == 11
        first_area = int(ssn[0:3])
        third_area = int(ssn[7:9])
        assert 666 > first_area > 100
        assert third_area > 0
        assert 100 > int(ssn[4:6]) > 0
        assert 10000 > int(ssn[-4:]) > 0


# Generated at 2022-06-23 20:29:40.587849
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Create a USASpecProvider object
    obj = USASpecProvider()
    assert isinstance(obj, USASpecProvider)

    # Test whether input has default value
    pattern1 = re.compile(r'^[A-Za-z0-9]+$')
    assert pattern1.match(obj.tracking_number()) is not None

    # Test for service other than 'usps', 'fedex' and 'ups'
    with pytest.raises(ValueError) as excinfo:
        obj.tracking_number('service')
    assert str(excinfo.value) == 'Unsupported post service'

    # Test for 'usps'

# Generated at 2022-06-23 20:29:44.456322
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():

    provider = USASpecProvider()
    ssn = provider.ssn()
    assert ssn[0] != '0'
    assert ssn[3] != '0'
    assert ssn[4] != '0'
    assert ssn[6] != '0'

    ssn = provider.ssn(seed=0)
    assert ssn == '822-81-3870'



# Generated at 2022-06-23 20:29:47.967067
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
	usas = USASpecProvider()
	assert usas.tracking_number('usps')
	assert usas.tracking_number('fedex')
	assert usas.tracking_number('ups')
	

# Generated at 2022-06-23 20:29:52.915043
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()
    assert usa_spec_provider.Meta.name == 'usa_provider'
    assert usa_spec_provider.random.seed is None
    assert usa_spec_provider.random.locale == 'en'
    assert str(usa_spec_provider) == 'USA (en)'



# Generated at 2022-06-23 20:29:59.184886
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():

    # Arrange
    usa_spec_provider = USASpecProvider()

    # Assert
    assert usa_spec_provider.tracking_number(service='usps')
    assert usa_spec_provider.tracking_number(service='fedex')
    assert usa_spec_provider.tracking_number(service='ups')


# Generated at 2022-06-23 20:30:08.814063
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # test default USPS tracking number
    assert USASpecProvider().tracking_number() == '2725 5336 1726 1294 4093'
    assert USASpecProvider().tracking_number(service='usps') == '6157 6830 5114 0605 3906'

    # test Fedex tracking number
    assert USASpecProvider().tracking_number(service='fedex') in ['1254 6818 5005', '2531 7509 6096 681']

    # test UPS tracking number
    assert USASpecProvider().tracking_number(service='ups') == '1Z397A57YW07693846'

# Testing method ssn
# Example:
# >>> assert USASpecProvider().ssn() == '342-91-2376'

# Testing method personality
# Example:
# >>> assert USASpecProvider().personality() ==

# Generated at 2022-06-23 20:30:19.300908
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.us_provider import USASpecProvider
    from mimesis.providers.geo import GeoLocation

    us_spec = USASpecProvider('en')
    us_spec = USASpecProvider('en')
    tracking_number = us_spec.tracking_number()

    assert len(tracking_number) == 22

    name = us_spec.name(gender=Gender.FEMALE)
    assert name is not None
    assert isinstance(name, str) is True

    ssn = us_spec.ssn()
    assert ssn is not None
    assert isinstance(ssn, str) is True

    personality = us_spec.personality()
    assert personality is not None

# Generated at 2022-06-23 20:30:22.105899
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    print(provider.ssn())

if __name__ == "__main__":
    test_USASpecProvider_ssn()

# Generated at 2022-06-23 20:30:23.760561
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    prov = USASpecProvider()
    ssn = prov.ssn()
    assert len(ssn) == 11
    assert ssn[3] == "-"
    assert ssn[6] == "-"

# Generated at 2022-06-23 20:30:26.386939
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider(seed=147852369)
    assert provider.tracking_number(service='usps') == '0XQ1 563G 9786 W0P3 8K23'
    assert provider.tracking_number(service='fedex') == '6217 2050 0462'
    assert provider.tracking_number(service='ups') == '1Z62443A6389593427'


# Generated at 2022-06-23 20:30:34.101291
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """The test for constructor of class USASpecProvider."""
    x = USASpecProvider()
    # All tests passed
    print("{!s}".format(x))
    print("{!s}".format(str(x)))
    print("{!s}".format(repr(x)))
    print("{!s}".format(hash(x)))
    print("{!s}".format(hex(id(x))))
    print("{!s} {:!s} {:!s}".format(x.__class__, x.__module__, x.__name__))
    print("{!s}".format(x.__dict__))
    print("{!s}".format(x.__doc__))
    print("{!s}".format(x.__sizeof__()))

# Generated at 2022-06-23 20:30:43.784878
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # test for random tracking number
    assert isinstance(USASpecProvider().tracking_number(), str)
    assert isinstance(USASpecProvider().tracking_number('usps'), str)
    assert isinstance(USASpecProvider().tracking_number('fedex'), str)
    assert isinstance(USASpecProvider().tracking_number('ups'), str)
    # test for random ssn
    assert isinstance(USASpecProvider().ssn(), str)
    # test for random personality
    assert isinstance(USASpecProvider().personality(), str)
    assert isinstance(USASpecProvider().personality('mbti'), str)
    assert isinstance(USASpecProvider().personality('rheti'), int)
    assert isinstance(USASpecProvider().personality('rheti'), int)

# Generated at 2022-06-23 20:30:49.805191
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test method personality from class USASpecProvider."""
    usa_spec_provider = USASpecProvider()
    
    # test for personality method by mbti
    mbti_generate = usa_spec_provider.personality('mbti')
    assert type(mbti_generate) is str
    assert len(mbti_generate) == 4
    assert mbti_generate in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
            'ISTP', 'ISFP', 'INFP', 'INTP',
            'ESTP', 'ESFP', 'ENFP', 'ENTP',
            'ESTJ', 'ESFJ', 'ENFP', 'ENTJ')
    
    #test for personality method by mbti
    rheti_generate = usa_spec_

# Generated at 2022-06-23 20:30:51.638478
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() in ["999-66-9999"]

# Generated at 2022-06-23 20:30:57.586008
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider._test_function(
        USASpecProvider.personality,
        arg_types=[],
        seed=123,
        args=['mbti'],
        expected='ISFJ',
    )

    assert USASpecProvider._test_function(
        USASpecProvider.personality,
        arg_types=[],
        seed=123,
        args=['rheti'],
        expected=9,
    )



# Generated at 2022-06-23 20:31:00.749578
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    us = USASpecProvider()
    test1 = us.personality()
    test2 = us.personality(category='rheti')

    assert test1 != ''
    assert test2 != ''

# Generated at 2022-06-23 20:31:11.038389
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider().otp() == 'xxHxQeea7Iu'
    assert USASpecProvider().personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ',
            'ISTP', 'ISFP', 'INFP', 'INTP',
            'ESTP', 'ESFP', 'ENFP', 'ENTP',
            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert USASpecProvider().personality('rheti') in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-23 20:31:16.654935
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    ssn = USASpecProvider()
    
    # Check default value which is mbti
    assert ssn.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    
    # Check that rheti returns int from 1 to 10
    assert ssn.personality(category = "rheti") in range(1, 11)
    
    # Check that invalid category throws ValueError
    try:
        ssn.personality(category = "invalid")
        assert 0
    except ValueError:
        assert 1

# Generated at 2022-06-23 20:31:21.277768
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Unit test for ssn method of USASpecProvider class."""
    provider = USASpecProvider()
    result = provider.ssn()
    assert len(result) == 11, 'Invalid result'



# Generated at 2022-06-23 20:31:29.758599
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Define the tested method
    tested_function = USASpecProvider().tracking_number
    # Define the expected arguments for the tested method
    args = {
        'service': ['usps'],
    }
    # Define the expected results for the tested method
    expected_results = {
        'usps': [
            r'\d\d\d\d \d\d\d\d \d\d\d\d \d\d\d\d \d\d\d\d',
            r'\d\d \d\d\d \d\d\d \d\d\d US',
        ],
    }
    # Define the tested method name
    tested_function_name = 'tracking_number'
    # Unit test the tested method

# Generated at 2022-06-23 20:31:31.371601
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider(seed=12345)



# Generated at 2022-06-23 20:31:33.210480
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
  us = USASpecProvider()
  assert us is not None

# Generated at 2022-06-23 20:31:37.165505
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.__class__.__name__ == "USASpecProvider"
    assert usa.__class__.__bases__[0].__name__ == "BaseSpecProvider"


# Generated at 2022-06-23 20:31:41.951846
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaspecprovider = USASpecProvider()
    x = usaspecprovider.personality()
    assert x in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:31:46.500754
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    import random
    a = random.random()
    g = USASpecProvider(seed=a)
    expected = g.tracking_number()
    result = g.tracking_number()
    assert expected == result


# Generated at 2022-06-23 20:31:51.921794
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider(seed=42)
    # test __init__ method of class USASpecProvider
    assert us.seed is not None
    assert us.random is not None
    assert us.datetime is not None
    assert us.provider_name == 'usa_provider'
    assert us.locale == 'en'


# Generated at 2022-06-23 20:32:01.826509
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():

    # USPS tracking number
    assert(USASpecProvider().tracking_number('usps') == 'GJ 046 725 539 US')

    # FedEx tracking numbers
    # Status: Delivered
    assert(USASpecProvider().tracking_number('fedex') == '3072 6195 9298')

    # Status: In transit
    assert(USASpecProvider().tracking_number('fedex') == '9895 3902 9369')

    # Status: Exception
    assert(USASpecProvider().tracking_number('fedex') == '5609 6282 7592')

    # UPS tracking number
    # Status: On the way to destination
    assert(USASpecProvider().tracking_number('ups') == '1Z7V79R90469684967')

    # assert that a tracking number for an unknown service raises an error

# Generated at 2022-06-23 20:32:11.520696
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test providing MBTI personality type."""
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP',
                                 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP',
                                 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ',
                                 'ENTJ')
    assert usa.personality(category='rheti') in range(1, 10)
    assert type(usa.personality()) is str


# Generated at 2022-06-23 20:32:13.228306
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.__str__() == 'USASpecProvider'

# Generated at 2022-06-23 20:32:20.133936
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Testing method personality of class USASpecProvider."""
    from mimesis.enums import Category
    from mimesis.providers.personality import Personality
    sp = USASpecProvider()
    # mbti
    result = sp.personality(Category.MBTI)
    assert result in Personality.MBTI.value
    # rheti
    result = sp.personality(Category.RHETI)
    assert type(result) == int
    assert result in range(1, 11)

# Generated at 2022-06-23 20:32:22.810419
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    ssn = provider.tracking_number()
    assert isinstance(ssn, str)
    assert len(ssn) > 0


# Generated at 2022-06-23 20:32:25.880653
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test generation of social security number."""
    usssn = USASpecProvider()  # type: ignore
    assert isinstance(usssn.ssn(), str)


# Generated at 2022-06-23 20:32:26.978749
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_spec_provider = USASpecProvider()



# Generated at 2022-06-23 20:32:29.422946
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    assert len(list(set([usa.ssn() for _ in range(100)]))) == 100


# Generated at 2022-06-23 20:32:35.034747
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality(category="mbti") in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
    )


# Generated at 2022-06-23 20:32:38.621619
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert ssn.count('-') == 2
    assert '666' not in ssn

# Generated at 2022-06-23 20:32:39.648553
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality(category = '') != ''

# Generated at 2022-06-23 20:32:45.643056
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    tracking_number_usps = USASpecProvider().tracking_number()
    assert tracking_number_usps     # make sure it returns a string, not None
    tracking_number_fedex = USASpecProvider().tracking_number('FEDEX')
    assert tracking_number_fedex
    tracking_number_ups = USASpecProvider().tracking_number('UPS')
    assert tracking_number_ups


# Generated at 2022-06-23 20:32:46.648251
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider()


# Generated at 2022-06-23 20:32:48.907749
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Initialize a provider
    provider = USASpecProvider()

    # Get a tracking number
    track_number = provider.tracking_number()


# Generated at 2022-06-23 20:32:57.010671
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert isinstance(provider.tracking_number(), str), 'It should be string'
    assert isinstance(provider.tracking_number('usps'), str), 'It should be string'
    assert isinstance(provider.tracking_number('fedex'), str), 'It should be string'
    assert isinstance(provider.tracking_number('ups'), str), 'It should be string'
    try:
        provider.tracking_number('other')
    except ValueError:
        pass


# Generated at 2022-06-23 20:32:58.352565
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert type(USASpecProvider().tracking_number()) == str


# Generated at 2022-06-23 20:32:59.964895
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider()
    assert us.ssn()
    assert isinstance(us.ssn(),str)


# Generated at 2022-06-23 20:33:02.897718
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """
    test_USASpecProvider_personality()
    """
    usa = USASpecProvider()
    result1 = usa.personality()
    result2 = usa.personality("rheti")
    assert result1 in usa.personality()
    assert isinstance(result2, int)

# Generated at 2022-06-23 20:33:10.518463
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    my_provider = USASpecProvider()
    assert my_provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'), 'Personality type is not correct' 
    assert my_provider.personality(category='rheti') in range(1,10), 'Personality type is not correct'

# Generated at 2022-06-23 20:33:13.181029
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    for _ in range(10):
        provider = USASpecProvider()
        assert len(provider.ssn()) == 11
        assert provider.ssn()[3] == '-'
        assert provider.ssn()[6] == '-'
        assert provider.ssn()[0] != '0'


# Generated at 2022-06-23 20:33:14.354703
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    spec = USASpecProvider()
    assert isinstance(spec, USASpecProvider) == True


# Generated at 2022-06-23 20:33:16.623041
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider(seed=1)
    assert usa_provider.personality(category='rheti') == 7
    assert usa_provider.personality(category='mbti') == "ESTJ"


# Generated at 2022-06-23 20:33:23.303216
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Method to test USASpecProvider_personality method."""
    from mimesis.enums import Category
    from mimesis.providers.personality import Personality
    from mimesis.providers.usa import USASpecProvider

    us_spec = USASpecProvider()
    pers = Personality()

    for _ in range(1000):
        mbti = us_spec.personality()
        assert mbti in pers.all('mbti')

    for _ in range(1000):
        rheti = us_spec.personality(category='rheti')
        assert rheti in pers.all('rheti')


# Generated at 2022-06-23 20:33:24.993496
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    x=USASpecProvider()
    assert x.personality()

# Generated at 2022-06-23 20:33:26.430122
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa


# Generated at 2022-06-23 20:33:31.160760
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert isinstance(provider.personality(category='rheti'), int)
    assert isinstance(provider.personality(category='mbti'), str)
    assert isinstance(provider.personality(category='rheti'), int)



# Generated at 2022-06-23 20:33:34.438632
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    usa_gen = USASpecProvider()
    assert isinstance(usa_gen, USASpecProvider)


# Generated at 2022-06-23 20:33:38.521092
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:33:42.847225
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test the method tracking_number."""
    usa = USASpecProvider()
    assert isinstance(usa.tracking_number(), str)
    assert len(usa.tracking_number()) == 22
    assert ' ' in usa.tracking_number()
    assert usa.tracking_number('ups')[1] == 'Z'


# Generated at 2022-06-23 20:33:47.229231
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    # Arrange
    provider = USASpecProvider()

    # Act
    for _ in range(10):
        res = provider.ssn()

        # Assert
        assert isinstance(res, str)
        assert len(res) == 11
        assert res[3] == '-'
        assert res[6] == '-'
        assert res[0:3].isdigit()
        assert 0 < int(res[0:3]) < 900
        assert res[4:6].isdigit()
        assert 0 < int(res[4:6]) < 100
        assert res[7:11].isdigit()
        assert 0 < int(res[7:11]) < 10000


# Generated at 2022-06-23 20:33:50.301737
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality(category='rheti') in range(1, 11)
    assert usa_provider.personality() in mbtis

# Generated at 2022-06-23 20:33:53.375607
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    # USPS
    assert provider.tracking_number(service='USPS')
    # FedEx
    assert provider.tracking_number(service='FedEx')
    # UPS
    assert provider.tracking_number(service='UPS')


# Generated at 2022-06-23 20:33:55.241963
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    result = usa.ssn()
    assert len(result) == 11
    assert result[3] == '-'
    assert result[6] == '-'


# Generated at 2022-06-23 20:33:57.532219
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    result = USASpecProvider().ssn()
    print(result)
    assert len(result) == 11, "error"


# Generated at 2022-06-23 20:34:00.961057
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method ssn of class USASpecProvider"""
    usa = USASpecProvider(seed=42)
    ssn = usa.ssn()
    assert ssn == '076-62-6180'


# Generated at 2022-06-23 20:34:02.260739
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert USASpecProvider(seed=42).seed == 42


# Generated at 2022-06-23 20:34:04.771811
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    test_spec_provider = USASpecProvider()
    assert test_spec_provider.personality("mbti") == "ISFJ"
    assert test_spec_provider.personality("rheti") == 10

# Generated at 2022-06-23 20:34:06.424633
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
  usa = USASpecProvider()
  assert isinstance(usa, USASpecProvider), 'instance is not of type USASpecProvider'


# Generated at 2022-06-23 20:34:09.632373
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa.__class__.__name__ == "USASpecProvider"


# Generated at 2022-06-23 20:34:18.158476
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import PersonalityType
    from mimesis.providers.us import USASpecProvider

    provider = USASpecProvider()
    # Generate personality
    personality = provider.personality()
    assert personality in PersonalityType.MBTI_LIST
    # Generate personality using category mbti
    personality = provider.personality('mbti')
    assert personality in PersonalityType.MBTI_LIST
    # Generate Rheti personality
    personality = provider.personality('rheti')
    assert personality not in PersonalityType.MBTI_LIST

# Generated at 2022-06-23 20:34:21.610153
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    up = USASpecProvider()
    assert up.us_state() == 'AL'
    assert len(up.us_state()) == 2
    assert up.us_territory() == 'Northern Mariana Islands'
    assert len(up.us_territory()) == 27


# Generated at 2022-06-23 20:34:24.971187
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usp = USASpecProvider()
    assert isinstance(usp.spec.arguments.d.key, str)
    assert isinstance(usp.spec.arguments.d.value, list)

# Generated at 2022-06-23 20:34:30.325257
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    special_provider = USASpecProvider(seed=None)
    assert special_provider.__class__.__name__ == 'USASpecProvider'
    assert special_provider
    assert special_provider.__str__() == '<USASpecProvider>'
    assert special_provider.__repr__() == '<USASpecProvider>'


# Generated at 2022-06-23 20:34:35.857340
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality('mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP',
                                            'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                            'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
    assert provider.personality('rheti') in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-23 20:34:37.336712
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number()


# Generated at 2022-06-23 20:34:41.852444
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    mbti_type = usa.personality()

    assert type(mbti_type) == str

    for i in range(10):
        assert usa.personality(category="rheti") in range(1, 11)



# Generated at 2022-06-23 20:34:47.066232
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:34:51.066594
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                               'ISTP', 'ISFP', 'INFP', 'INTP',
                                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert USASpecProvider().personality(category='rheti') in list(range(1, 11))

# Generated at 2022-06-23 20:34:52.631639
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert type(provider.ssn()) == str

# Generated at 2022-06-23 20:34:54.928392
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    assert provider.ssn() in ['569-66-5801']
