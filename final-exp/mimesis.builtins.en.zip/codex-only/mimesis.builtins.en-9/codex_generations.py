

# Generated at 2022-06-23 20:24:53.556875
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider(seed=12345)
    assert usa.ssn() == '933-96-6579'

# Generated at 2022-06-23 20:24:57.313542
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    usaProvider = USASpecProvider()

    assert usaProvider.ssn() == '321-12-1234'
    assert usaProvider.tracking_number() == '9XW9 6R76 YF5J QR89'
    assert usaProvider.random.choice(tuple(usaProvider.Meta.name)) == 'u'

# Generated at 2022-06-23 20:25:02.680360
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    # Arrange
    provider = USASpecProvider()

    # Act
    actual_result = provider.tracking_number()

    # Assert
    assert len(actual_result.replace(" ", "")) == 22 or \
           len(actual_result.replace(" ", "")) == 34


# Generated at 2022-06-23 20:25:06.363591
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider(seed=666)
    assert provider.locale == 'en'
    assert provider.tracking_number() == 'RD6 4CY6 3K2D 757U 8'
    assert provider.ssn() == '957-24-7921'
    assert provider.personality() == 'INFJ'


# Generated at 2022-06-23 20:25:11.247523
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('en')
    p.set_gender(Gender.MALE)
    ssn = p.ssn()
    assert ssn == '569-66-5801'

# Generated at 2022-06-23 20:25:17.620391
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from sys import version_info
    if version_info < (3, 7):
        from unittest import TestCase
        from mimesis.enums import Gender
        from mimesis.providers.usa.usa_provider import USASpecProvider
        from mimesis.types import CustomCode

        class TestUSASpecProvider(TestCase):

            def setUp(self):
                self.ssn = USASpecProvider(seed=123)

            def test_ssn(self):
                result = self.ssn.ssn()
                self.assertIsInstance(result, str)

        locals()['TestUSASpecProvider'] = TestUSASpecProvider
        unittest.main(exit=not locals().get('assert_'))



# Generated at 2022-06-23 20:25:19.569788
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test the method personality of class USASpecProvider."""
    usa = USASpecProvider()
    usa.personality()


# Generated at 2022-06-23 20:25:20.942437
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert USASpecProvider().ssn() == '703-99-6096'


# Generated at 2022-06-23 20:25:30.081273
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    from mimesis.enums import Category
    from mimesis.providers.person import Person

    p = Person(category=Category.PERSONALITY.value)
    assert p.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                               'ISTP', 'ISFP', 'INFP', 'INTP',
                               'ESTP', 'ESFP', 'ENFP', 'ENTP',
                               'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert 0 < p.personality(category='rheti') < 11



# Generated at 2022-06-23 20:25:31.748235
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    assert usa.ssn() != usa.ssn()


# Generated at 2022-06-23 20:25:34.994229
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaspp = USASpecProvider()
    assert usaspp.personality() in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP',
                                    'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:25:39.748325
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for method ssn of class USASpecProvider.
    
        For example:
        >>> provider = USASpecProvider()
        >>> print(provider.ssn())
        569-66-5801
    """
    assert USASpecProvider().ssn()


# Generated at 2022-06-23 20:25:45.985027
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    import mimesis
    import re
    en = mimesis.USASpecProvider(seed=42)
    tracking_number = en.tracking_number()
    match = re.search(r"\d{4}-?\d{4}-?\d{4}-?\d{4}-?\d{4}", tracking_number)
    assert match is not None


# Generated at 2022-06-23 20:25:51.774414
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    special_data = USASpecProvider()

    assert special_data.tracking_number()
    assert special_data.tracking_number('FedEx')
    assert special_data.tracking_number('ups')
    assert special_data.ssn()
    assert special_data.personality()
    assert special_data.personality('rheti')

# Generated at 2022-06-23 20:25:57.475999
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Unit test for constructor of class USASpecProvider."""
    from mimesis.builtins import USASpecProvider
    from mimesis.enums import Language
    
    usa = USASpecProvider()
    assert usa.__class__.__name__ == 'USASpecProvider'
    assert usa._seed is None
    assert usa.language == Language.EN
    assert usa.Meta.name == 'usa_provider'


# Generated at 2022-06-23 20:26:05.015109
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    provider = USASpecProvider()
    tracking_number = provider.tracking_number('ups')
    assert isinstance(tracking_number, str)
    assert len(tracking_number) == 18
    assert tracking_number[2] == '1'
    assert tracking_number[3] in ('Z', 'Y')
    assert tracking_number[4] == ' '
    assert tracking_number[5].isalpha()
    assert tracking_number[6] == ' '
    assert tracking_number[-2].isalpha()
    assert tracking_number[-1].isalpha()


# Generated at 2022-06-23 20:26:10.094914
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    assert usa.personality(category='rheti') in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert usa.personality(category='mbti').isalpha()
    assert usa.personality(category='mbti').isupper()
    assert len(usa.personality(category='mbti')) == 4

# Generated at 2022-06-23 20:26:12.435465
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test for USASpecProvider: tracking_number"""
    us = USASpecProvider()
    assert us.tracking_number() is not None
    assert us.tracking_number() is not None


# Generated at 2022-06-23 20:26:15.174704
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    a = USASpecProvider()
    assert a.tracking_number() == '1511 1526 3662 9509 8714'


# Generated at 2022-06-23 20:26:16.267180
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11

# Generated at 2022-06-23 20:26:24.466240
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    us_provider = USASpecProvider()
    # USPS
    assert us_provider.tracking_number() != ''
    assert us_provider.tracking_number('usps') != ''
    # FedEx
    assert us_provider.tracking_number('FedEx') != ''
    assert us_provider.tracking_number('fedex') != ''
    # UPS
    assert us_provider.tracking_number('UPS') != ''
    assert us_provider.tracking_number('ups') != ''
    # Return error message
    with pytest.raises(ValueError):
        us_provider.tracking_number('usps_test')
        us_provider.tracking_number('FedEx_test')
        us_provider.tracking_number('UPS_test')

# Generated at 2022-06-23 20:26:28.234956
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa_ssn_provider=USASpecProvider()
    assert len(usa_ssn_provider.ssn())==11

# Generated at 2022-06-23 20:26:30.441687
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    usa = USASpecProvider()
    for _ in range(10):
        tracking_number = usa.tracking_number()
        assert type(tracking_number) == str
        assert len(tracking_number) == 21


# Generated at 2022-06-23 20:26:36.461216
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us_spec_provider = USASpecProvider()
    assert us_spec_provider.__class__.__name__ == 'USASpecProvider'
    assert us_spec_provider.__class__.__mro__ == (
        USASpecProvider,
        BaseSpecProvider,
        BaseSpecProvider,
        BaseProvider,
        object,
    )

# Generated at 2022-06-23 20:26:47.694333
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""

    x = USASpecProvider()

    # USPS
    u = x.tracking_number('usps')
    # Using Regex to determine if the string is valid
    usps_regex = r'\d{4} \d{4} \d{4} \d{4} \d{4}'
    usps_regex2 = r'[A-Z]{2} \d{3} \d{3} \d{3} US'
    assert re.search(usps_regex, u) or re.search(usps_regex2, u) is not None

    # FedEx
    f = x.tracking_number('fEDEx')
    # Using Regex to determine if the string is valid

# Generated at 2022-06-23 20:26:52.031706
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usaspp = USASpecProvider()
    assert not set(usaspp.personality() for _ in range(1000)) - set(mbtis)
    assert all(len(usaspp.personality()) < 5 for _ in range(1000))
    assert all(0 < usaspp.personality(category='rheti') < 11 for _ in range(1000))



# Generated at 2022-06-23 20:26:58.351187
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():

    provider = USASpecProvider()
    assert provider.random.choice(1, 999) == 724
    assert provider.random.randint(1, 999) == 82
    assert provider.random.custom_code(mask='1Z@####@##########') == '1Z8D98G35F7268530'
    assert provider.random.choice('ISFJ', 'INTJ', 'INFJ') == 'ISFJ'
    
test_USASpecProvider()


# Generated at 2022-06-23 20:27:09.315578
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.enums import PostService

    usa = USASpecProvider()
    usa.seed(1)
    assert usa.tracking_number() == '6113 5839 1492 8690 9416'
    assert usa.tracking_number('FedEx') == '3414 5574 064'
    assert usa.tracking_number(PostService.UPS) == '1Z6U51506815307353'
    assert usa.tracking_number('usps') == '8409 4372 4997 US'
    assert usa.tracking_number(PostService.UPS).startswith('1Z')
    assert usa.tracking_number(PostService.FEDEX).startswith('1Z')



# Generated at 2022-06-23 20:27:12.248325
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert provider.tracking_number(service='usps')
    assert provider.tracking_number(service='fedex')
    assert provider.tracking_number(service='ups')


# Generated at 2022-06-23 20:27:18.519050
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usa = USASpecProvider()
    ssn = usa.ssn()
    check = ssn.split("-")
    assert len(check) == 3
    assert len(check[0]) == 3
    assert len(check[1]) == 2
    assert len(check[2]) == 4
    assert int(check[0]) >= 1 and int(check[0]) <= 899
    assert int(check[1]) >= 1 and int(check[1]) <= 99
    assert int(check[2]) >= 1 and int(check[2]) <= 9999
    

# Generated at 2022-06-23 20:27:23.762220
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    for i in range(20):
        result = provider.ssn()
        assert re.match(r'^\d{3}-\d{2}-\d{4}$', result)
        assert result[3:5] != '00'
        assert result[6:9] != '000'
        assert result[3:5] != '66'
        assert result[9:13] != '0000'


# Generated at 2022-06-23 20:27:29.145721
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    value = provider.personality()
    assert value in [
        1, 2, 3, 4, 4, 5, 6, 7, 7, 8, 8, 9, 9, 10, 10
    ]
    assert isinstance(value, str) or isinstance(value, int)

# Generated at 2022-06-23 20:27:32.594711
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.providers.usa import USASpecProvider
    from mimesis.enums import Gender
    from mimesis.data.usa import Personality
    u = USASpecProvider()
    ssn = u.ssn()
    assert len(ssn) == 11

# Generated at 2022-06-23 20:27:39.176020
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    for _ in range(100):
        tmp_personality = USASpecProvider().personality(category='MBTI')
        assert tmp_personality in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                   'ISTP', 'ISFP', 'INFP', 'INTP',
                                   'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                   'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'), \
            'Bad personality.'

# Generated at 2022-06-23 20:27:44.983233
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider(seed=12345)
    result = usa_spec_provider.personality()
    assert isinstance(result, str)
    assert result in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')



# Generated at 2022-06-23 20:27:51.170898
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality() in  ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert provider.personality('rheti') in range(1,11)


# Generated at 2022-06-23 20:27:53.395336
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider, USASpecProvider)


# Generated at 2022-06-23 20:28:02.764895
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa = USASpecProvider(seed=12345)
    assert usa.personality(category='rheti') in range(1, 10)
    assert usa.personality(category='rheti') != 5
    assert usa.personality(category='rheti') == 7

    assert usa.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                 'ISTP', 'ISFP', 'INFP', 'INTP',
                                 'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality() != 'ISTJ'

# Generated at 2022-06-23 20:28:10.141197
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number(service='usps') in [
        '5126 6421 2637 1656 3145', 'RV 308 669 227 US',
    ]
    assert usa.tracking_number(service='fedex') in [
        '1285 2556 3427',
        '7013 9127 5151 614',
    ]
    assert usa.tracking_number(service='ups') in [
        '1Z9A73E90350264620',
    ]


# Generated at 2022-06-23 20:28:14.840909
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider(seed=None)
    assert provider.__class__.__name__ == "USASpecProvider"
    assert provider._meta.name == "usa_provider"
    assert provider._meta.localizer.locale == "en"


# Generated at 2022-06-23 20:28:17.763240
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    instance = USASpecProvider()
    result   = instance.ssn()
    assert isinstance(result, str)
    assert '-' in result
    assert len(result) == 11


# Generated at 2022-06-23 20:28:19.875117
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking_number = provider.tracking_number()
    assert len(tracking_number) > 0


# Generated at 2022-06-23 20:28:23.234940
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test for result of method ssn of class USASpecProvider."""
    test_value = USASpecProvider(seed=1234)
    result = test_value.ssn()
    assert result == '817-57-9530'



# Generated at 2022-06-23 20:28:27.890221
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tracking_number = provider.tracking_number('usps')

    assert len(tracking_number) >= 15
    assert tracking_number[20] == ' '

# Generated at 2022-06-23 20:28:29.910270
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    try:
        USASpecProvider()
    except AttributeError as error:
        print(error)


# Generated at 2022-06-23 20:28:33.120445
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import SpecialPurpose
    provider = USASpecProvider(seed=42)
    assert provider.ssn() == '366-92-4572'


# Generated at 2022-06-23 20:28:36.410170
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    try:
        USASpecProvider(seed=10)
    except Exception as error:
        print(error)


# Generated at 2022-06-23 20:28:46.297274
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    tracking_number = usa.tracking_number()
    # basic test that tracking number is not empty
    assert tracking_number is not None

    tracking_number = usa.tracking_number(service='fedex')
    # basic test that tracking number is not empty
    assert tracking_number is not None

    tracking_number = usa.tracking_number(service='ups')
    # basic test that tracking number is not empty
    assert tracking_number is not None

    # basic test that SSN is not empty
    ssn = usa.ssn()
    assert ssn is not None

    # basic test that personality is not empty
    personality = usa.personality()
    assert personality is not None

    personality = usa.personality(category='rheti')
    # basic test that personality is not

# Generated at 2022-06-23 20:28:49.495471
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn) == 11
    assert ssn[3] == ssn[6] == '-'


# Generated at 2022-06-23 20:28:53.690993
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    p = USASpecProvider()
    for _ in range(100):
        print(p.personality('mbti'))
        print(p.personality('Rheti'))


# Generated at 2022-06-23 20:28:55.524316
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    assert USASpecProvider().tracking_number(service='UPS').startswith("1Z")


# Generated at 2022-06-23 20:29:01.763621
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    # GIVEN
    provider = USASpecProvider()

    # THEN
    # The personality method should not return a ValueError
    # because the personality category is one of two values
    assert provider.personality(category=provider.random.choice(['mbti', 'rheti']))

    # THEN
    # The personality method should return a ValueError
    # because the personality category is not one of two values
    try:
        provider.personality(category='aaa')
    except ValueError as e:
        assert str(e)

# Generated at 2022-06-23 20:29:06.834897
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.providers.usa.usaspecprovider import USASpecProvider
    a = USASpecProvider()
    b = a.ssn()
    assert a.ssn() == b
    assert a.ssn() != b

# Generated at 2022-06-23 20:29:09.654166
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    spec = USASpecProvider()
    tracking_number = spec.tracking_number()
    print(tracking_number)
    

# Generated at 2022-06-23 20:29:10.803806
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    seed = "mimesis"
    USASpecProvider(seed)

# Generated at 2022-06-23 20:29:14.116883
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    tn = provider.tracking_number('usps')
    assert len(tn) >= 18 and len(tn) <= 28


# Generated at 2022-06-23 20:29:21.266611
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider()
    ssn = provider.ssn()
    assert len(ssn) == 11
    assert ssn[3] == "-"
    assert ssn[6] == "-"
    assert ssn[0:3].isdigit()
    assert ssn[4:6].isdigit()
    assert ssn[7:11].isdigit()
    assert int(ssn[0:3]) != 666


# Generated at 2022-06-23 20:29:27.817006
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """ Unit test for method ssn of class USASpecProvider"""
    u = USASpecProvider()
    ssn = u.ssn()
    assert ssn == "046-82-4418" or ssn == "141-08-1951" or ssn == "219-35-0597" or ssn == "358-00-1684" or ssn == "062-90-6397" or ssn == "034-09-6054" or ssn == "286-70-4104" or ssn == "279-12-6853" or ssn == "212-94-7042" or ssn == "197-54-9766"

# Generated at 2022-06-23 20:29:31.181084
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    a = USASpecProvider()
    print("tracking_number: ", a.tracking_number("ups"))
    print("ssn: ", a.ssn())
    print("personality1: ", a.personality("rheti"))
    print("personality2: ", a.personality("mbti"))

if __name__ == "__main__":
    test_USASpecProvider()

# Generated at 2022-06-23 20:29:37.608246
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Unit test for method tracking_number of class USASpecProvider."""
    from mimesis.builtins.usa import USASpecProvider as usa

    usa_ = usa()
    usps_tracking_number = usa_.tracking_number()
    assert usps_tracking_number in usa_.tracking_number()
    assert isinstance(usps_tracking_number, str)
    assert usps_tracking_number.find('#') == -1


# Generated at 2022-06-23 20:29:39.504200
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
	ssn = USASpecProvider().ssn()
	assert len(ssn) == 11


# Generated at 2022-06-23 20:29:46.020504
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    provider = USASpecProvider()
    assert len(provider.tracking_number(service='usps')) == len('#### #### #### #### ####')
    assert len(provider.tracking_number(service='fedex')) == len('#### #### ####')
    assert len(provider.tracking_number(service='ups')) == len('1Z@####@##########')


# Generated at 2022-06-23 20:29:49.009851
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    service = "USPS"
    tracking_number = USASpecProvider().tracking_number(service)
    assert len(tracking_number) > 0


# Generated at 2022-06-23 20:29:54.982679
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    expected_usps_tracking_number = "WM202 621 852 741"
    assert USA.tracking_number(service='usps') == expected_usps_tracking_number

    expected_fedex_tracking_number = "2074293970"
    assert USA.tracking_number(service='fedex') == expected_fedex_tracking_number

    expected_ups_tracking_number = "1Z0080497969633239"
    assert USA.tracking_number(service='ups') == expected_ups_tracking_number


# Generated at 2022-06-23 20:30:05.366589
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    tracking = provider.tracking_number()
    assert len(tracking) == 18
    tracking = provider.tracking_number()
    assert len(tracking) == 18
    tracking = provider.tracking_number()
    assert len(tracking) == 18
    tracking = provider.tracking_number()
    assert len(tracking) == 18
    tracking = provider.tracking_number()
    assert len(tracking) == 18
    tracking = provider.tracking_number()
    assert len(tracking) == 18
    tracking = provider.ssn()
    assert len(tracking) == 11
    tracking = provider.ssn()
    assert len(tracking) == 11
    tracking = provider.ssn()
    assert len(tracking) == 11
    tracking = provider.ssn()
    assert len(tracking) == 11
    tracking = provider

# Generated at 2022-06-23 20:30:13.403336
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    customs = [
        '9400 1112 2222 3333 4444',
        '9400 1111 2222 3333 444U S',
        '8160 9843 7228',
        '8160 9843 7228 7419',
        '1Z0BA0E9X034500374',
    ]
    usa_spec_provider = USASpecProvider()

    for service in ('usps', 'fedex', 'ups'):
        for _ in range(10):
            value = usa_spec_provider.tracking_number(service)
            assert isinstance(value, str)
            assert value in customs

# Generated at 2022-06-23 20:30:18.348360
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert provider.__class__.__name__ == 'USASpecProvider'
    assert provider._meta.name == 'usa_provider'
    assert provider._meta.localizer.locale == 'en'
    assert provider.provider_name == 'usa_provider'


# Unit tests for ssn() of class USASpecProvider

# Generated at 2022-06-23 20:30:19.990523
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa != ""


# Generated at 2022-06-23 20:30:24.197714
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us = USASpecProvider()
    assert(len(us.ssn()) == 11)
    assert(us.ssn()[3] == '-')
    assert(us.ssn()[6] == '-')


# Generated at 2022-06-23 20:30:26.648829
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """ Unit test for class USASpecProvider. """

    usa = USASpecProvider()
    assert usa is not None


# Generated at 2022-06-23 20:30:34.250288
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    tracking_number = usa_provider.tracking_number('usps')
    assert(type(tracking_number) == str)
    assert(len(tracking_number) == 34)
    assert(tracking_number[-2] == 'U' and tracking_number[-1] == 'S')

    tracking_number = usa_provider.tracking_number('usps')
    assert(type(tracking_number) == str)
    assert(len(tracking_number) == 32)

    tracking_number = usa_provider.tracking_number('fedex')
    assert(type(tracking_number) == str)
    assert(len(tracking_number) == 22 or len(tracking_number) == 24)


# Generated at 2022-06-23 20:30:39.545923
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_provider = USASpecProvider()
    assert usa_provider.personality(category='mbti') in ['ISFJ', 'ISTJ', 'INFJ', 'INTJ','ISTP', 'ISFP', 'INFP', 'INTP','ESTP', 'ESFP', 'ENFP', 'ENTP','ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']

# Generated at 2022-06-23 20:30:43.967174
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from pprint import pprint
    import sys

    if sys.version_info.major == 2:
        from re import compile as compile_regex

        def is_valid_ssn(ssn):
            SSN_RE = compile_regex(r'^\d{3}-?\d{2}-?\d{4}$')
            return True if SSN_RE.match(ssn) else False
    else:
        from re import fullmatch as match_regex

        def is_valid_ssn(ssn) -> bool:
            SSN_RE = match_regex(r'^\d{3}-?\d{2}-?\d{4}$', ssn)
            return True if SSN_RE else False

    provider_ssn = USASpecProvider().ssn
   

# Generated at 2022-06-23 20:30:46.125393
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa_spec_provider = USASpecProvider()
    assert(len(usa_spec_provider.personality('mbti')) == 4)
    assert(len(usa_spec_provider.personality('rheti')) == 1)

# Generated at 2022-06-23 20:30:47.523479
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert all(len(usa.tracking_number(service=service)) > 0 for service in ('usps', 'fedex', 'ups'))


# Generated at 2022-06-23 20:30:52.234172
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    provider = USASpecProvider(seed=12345)
    result = provider.ssn()
    assert result == '199-52-1252'
    assert type(result) is str


# Generated at 2022-06-23 20:30:56.061220
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test case for constructor of class USASpecProvider."""
    assert USASpecProvider.Meta.name in (
        'usa_provider',
        'usa',
        'USASpecProvider',
        'USAProvider',
    )


# Generated at 2022-06-23 20:30:57.266876
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    assert callable(USASpecProvider)


# Generated at 2022-06-23 20:31:00.169308
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa_provider = USASpecProvider()
    assert isinstance(usa_provider.tracking_number(service='usps'), str)


# Generated at 2022-06-23 20:31:03.744609
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test method USASpecProvider.ssn()."""
    usa = USASpecProvider()
    assert len(usa.ssn()) == 11


# Generated at 2022-06-23 20:31:05.860552
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert isinstance(provider, USASpecProvider)


# Generated at 2022-06-23 20:31:09.069786
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.providers.us.usa_provider import USASpecProvider
    usa = USASpecProvider()

    ssn = usa.ssn()
    print(ssn)
    assert ssn == '012-31-1232'


# Generated at 2022-06-23 20:31:17.248639
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('en')
    provider = USASpecProvider()

    ssn = provider.ssn()
    assert len(ssn) == 11

    ssn_male = p.ssn(gender=Gender.MALE)
    assert len(ssn_male) == 11

    ssn_female = p.ssn(gender=Gender.FEMALE)
    assert len(ssn_female) == 11

    ssn_unknown = p.ssn(gender=Gender.UNKNOWN)
    assert len(ssn_unknown) == 11

# Generated at 2022-06-23 20:31:27.121157
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    pattern_list = [
        # USPS tracking number
        '#### #### #### #### ####',
        '@@ ### ### ### US'
    ]
    pattern_list.extend([
        # UPS tracking number
        '1Z@####@##########',
        # FedEx tracking number
        '#### #### ####',
        '#### #### #### ###'
    ])
    usa_provider = USASpecProvider()
    for service in ('usps','fedex','ups'):
        tracking_number = usa_provider.tracking_number(service)
        assert any(pattern in tracking_number for pattern in pattern_list) == True
        assert isinstance(tracking_number, str) == True


# Generated at 2022-06-23 20:31:38.795946
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    import random
    import sys
    import os
    
    # initializes the seed
    random.seed(1)

    # Initializes the specification provider
    us_spec_provider = USASpecProvider()

    # Creates an instance of the custom function
    function = us_spec_provider.personality

    # Creates the expected result

# Generated at 2022-06-23 20:31:42.179019
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    sp = USASpecProvider()
    assert sp.personality() in ["ISFJ", "ISTJ", "INFJ", "INTJ", "INTP", "INFP",
                                "ISTP", "ISFP", "ESFP", "ENFP", "ENFJ", "ENTP",
                                "ENTJ", "ESTP", "ESFJ", "ESTJ"]
    assert 1 <= sp.personality('rheti') <= 10



# Generated at 2022-06-23 20:31:45.266249
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    import mimesis
    ssn = mimesis.USASpecProvider.ssn()
    assert len(ssn) == 11


# Generated at 2022-06-23 20:31:47.079898
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert usa._locale == 'en'


# Generated at 2022-06-23 20:31:54.813418
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Test USASpecProvider method tracking_number."""
    from mimesis.providers.status import Status

    status = Status()
    data = ['usps', 'fedex', 'ups']
    for x in range(0, len(data)):
        d = data[x]
        print("d = {}".format(d))
        for _ in range(6):
            print("\t{}".format(status.us_provider.tracking_number(service=d)))



# Generated at 2022-06-23 20:31:57.042149
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    USASpecProvider().personality('rheti')
    USASpecProvider().personality('mbti')
    USASpecProvider().personality('abc')

# Generated at 2022-06-23 20:32:04.331547
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    """Test USASpecProvider constructor."""
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    usa = USASpecProvider()
    seed = "7d4c93f9-2b8c-4b77-acb0-66df4036f8a3"
    usa_seed = USASpecProvider(seed)
    assert isinstance(usa, USASpecProvider)
    assert isinstance(usa.address, Address)
    assert usa.gender.get_gender() == Gender.MASCULINE
    assert 'USA' in usa.address._countries

# Test ssn() method of class USASpecProvider

# Generated at 2022-06-23 20:32:09.026829
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    type1 = USASpecProvider().personality()
    assert len(type1) == 4

    type2 = USASpecProvider().personality(category='rheti')
    assert type(type2) == int
    assert type2 > 0
    assert type2 < 10



# Generated at 2022-06-23 20:32:13.941803
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    assert usa.tracking_number() in [
        '9406 1310 1250 1656 9041', '7899 7683 9051 US',
        '9861 8956 6993', '8407 5592 6651 501',
        '1ZW56E8A6883171242'
    ]



# Generated at 2022-06-23 20:32:15.923090
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    actual = USASpecProvider().ssn()
    assert actual



# Generated at 2022-06-23 20:32:24.118085
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider(seed=42)

    assert provider.personality(category='mbti') == 'ISFJ'
    assert provider.personality(category='rheti') == 1
    assert provider.personality(category='mbti') == 'INTJ'
    assert provider.personality(category='rheti') == 7
    assert provider.personality(category='mbti') == 'INFP'
    assert provider.personality(category='rheti') == 2
    assert provider.personality(category='mbti') == 'ISFJ'
    assert provider.personality(category='rheti') == 1
    assert provider.personality(category='mbti') == 'ENTJ'
    assert provider.personality(category='rheti') == 8

# Generated at 2022-06-23 20:32:28.609735
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    country = USASpecProvider()
    assert country.__class__.__name__ == 'USASpecProvider'
    assert country.__class__.__bases__[0].__name__ == 'BaseSpecProvider'


# Generated at 2022-06-23 20:32:31.046339
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """ Unit test for method tracking_number of class USASpecProvider
    """
    assert isinstance(USASpecProvider().tracking_number(), str)


# Generated at 2022-06-23 20:32:41.264451
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    """Create a USASpecProvider class instance."""
    usa_provider = USASpecProvider()
    print(usa_provider)
    usa_provider.seed(seed=0)
    usps_num = usa_provider.tracking_number()
    print(usps_num)
    assert ('9X9S' in usps_num and 'CN836' in usps_num)
    ups_num = usa_provider.tracking_number(service='ups')
    print(ups_num)
    assert ('1Z4AN' in ups_num and 'X9DX' in ups_num)
    fedex_num = usa_provider.tracking_number(service='fedex')
    print(fedex_num)

# Generated at 2022-06-23 20:32:42.772949
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    assert len(USASpecProvider().ssn()) == 11 and isinstance(USASpecProvider().ssn(), str)

# Generated at 2022-06-23 20:32:46.625285
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() == 'ISFJ'
    assert isinstance(USASpecProvider().personality(), str)
    assert len(USASpecProvider().personality()) == 4
    assert isinstance(USASpecProvider().personality('rheti'), int)



# Generated at 2022-06-23 20:32:49.854487
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    usa = USASpecProvider()
    usa.personality('rheti') == 1 or 2 or 3 or 4 or 5 or 6 or 7 or 8 or 9 or 10
    usa.personality('mbti') == 'ISFJ' or ... or 'ENTJ'

# Generated at 2022-06-23 20:32:54.648501
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    a = USASpecProvider().personality()
    b = USASpecProvider().personality('rheti')
    a1 = USASpecProvider().personality()
    b1 = USASpecProvider().personality('rheti')
    assert (a != a1) and (b != b1)


# Generated at 2022-06-23 20:32:59.975791
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)
    assert isinstance(usa.random, Seed)
    assert usa.__doc__ is not None
    assert usa.tracking_number.__doc__ is not None
    assert usa.ssn.__doc__ is not None
    assert usa.personality.__doc__ is not None


# Generated at 2022-06-23 20:33:03.520654
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    usaspecprovider = USASpecProvider()
    ssn = usaspecprovider.ssn()
    assert isinstance(ssn, str)
    assert len(ssn) == 11
    assert ssn == '099-51-2698'

# Generated at 2022-06-23 20:33:08.550346
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality('mbti') in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ',
        'ISTP', 'ISFP', 'INFP', 'INTP',
        'ESTP', 'ESFP', 'ENFP', 'ENTP',
        'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert USASpecProvider().personality('rheti') in range(1,11)

# Generated at 2022-06-23 20:33:16.679749
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    ssn = USASpecProvider().ssn()
    # ssn should have 9 numbers
    assert len(ssn) == 11
    # split the ssn
    ssn = ssn.split('-')
    # first number should be between 1 and 899
    assert int(ssn[0]) <= 899
    # second number should be between 1 and 99
    assert int(ssn[1]) <= 99
    # third number should be between 1 and 9999
    assert int(ssn[2]) <= 9999
    # 666 is a invalid first number
    assert ssn[0] != '666'

# Generated at 2022-06-23 20:33:17.832377
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    for i in range(0, 10):
        assert USASpecProvider().tracking_number()


# Generated at 2022-06-23 20:33:21.491864
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert provider.personality('mbti') in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP',
                                            'ISFP', 'INFP', 'INTP', 'ESTP', 'ESFP',
                                            'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ',
                                            'ENTJ')
    assert provider.personality('rheti') in range(1, 11)


# Generated at 2022-06-23 20:33:26.990272
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    usa = USASpecProvider()
    for _ in range(1000):
        assert len(usa.tracking_number(service='USPS')) == 22
        assert len(usa.tracking_number(service='FedEx')) == 12
        assert len(usa.tracking_number(service='UPS')) == 18


# Generated at 2022-06-23 20:33:28.643241
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()
    assert isinstance(provider.personality(), str)

# Generated at 2022-06-23 20:33:35.912440
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    import doctest
    doctest.testmod(verbose=True)
    x = USASpecProvider(seed=5)
    assert x.ssn() == '736-88-3273'
    assert x.personality(category='mbti') == 'ENTP'
    assert x.tracking_number(service='usps') == '4141 9451 5562 2260 8909'
    assert x.tracking_number(service='fedex') == '2052 0428 3668'
    assert x.tracking_number(service='ups') == '1Z8K97A90693490020'

# Generated at 2022-06-23 20:33:37.124572
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
	usaspp = USASpecProvider()
	assert(usaspp != None)

# Generated at 2022-06-23 20:33:42.226451
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    assert USASpecProvider.personality(
        'rheti') in range(1, 10 + 1) or USASpecProvider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                                                          'ISTP', 'ISFP', 'INFP', 'INTP',
                                                                          'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                                                          'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')



# Generated at 2022-06-23 20:33:44.342718
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    """Test the method ss of class USASpecProvider."""
    c_usaspecprovider = USASpecProvider()
    for _ in range(0, 10):
        assert '###-##-####' == c_usaspecprovider.ssn()



# Generated at 2022-06-23 20:33:46.229561
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    usa = USASpecProvider()
    assert isinstance(usa, USASpecProvider)


# Generated at 2022-06-23 20:33:47.769172
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    us = USASpecProvider()
    assert not us


# Generated at 2022-06-23 20:33:49.109636
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    provider = USASpecProvider()

    assert isinstance(provider.personality(), str)

# Generated at 2022-06-23 20:33:52.824389
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    
    obj = USASpecProvider()
    assert isinstance(obj, USASpecProvider)
    assert obj.__class__.__name__ == 'USASpecProvider'
    assert obj.__class__.__module__ == 'mimesis.providers.usa_provider'
    assert len(obj.__dict__) == 2


# Generated at 2022-06-23 20:33:55.499328
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    us_provider = USASpecProvider()
    ssn = us_provider.ssn()
    print(ssn)
    assert ssn == '887-45-7884'

# Generated at 2022-06-23 20:33:58.559197
# Unit test for method ssn of class USASpecProvider
def test_USASpecProvider_ssn():
    from mimesis.providers.us import USASpecProvider
    usssn = USASpecProvider()
    print(usssn.ssn())


# Generated at 2022-06-23 20:34:02.229452
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    print("[+] Test for method 'tracking_number' of class 'USASpecProvider' : ")
    instance = USASpecProvider()
    print("     [i] Result of method 'tracking_number' : ", instance.tracking_number())


# Generated at 2022-06-23 20:34:07.999488
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():

    assert USASpecProvider().personality('rheti') == 1
    assert USASpecProvider().personality('rheti') == 2
    assert USASpecProvider().personality('rheti') == 3
    assert USASpecProvider().personality('rheti') == 4
    assert USASpecProvider().personality('rheti') == 5
    assert USASpecProvider().personality('rheti') == 6
    assert USASpecProvider().personality('rheti') == 7
    assert USASpecProvider().personality('rheti') == 8
    assert USASpecProvider().personality('rheti') == 9
    assert USASpecProvider().personality('rheti') == 10
    assert USASpecProvider().personality() == 'INFP'

# Generated at 2022-06-23 20:34:14.698850
# Unit test for method tracking_number of class USASpecProvider
def test_USASpecProvider_tracking_number():
    from mimesis.providers.usa import USASpecProvider
    from mimesis.providers.usps import USPSProvider
    usps = USPSProvider()
    usa = USASpecProvider()
    tracking_number_USPS = usa.tracking_number("USPS")
    assert usps.tracking_number() == tracking_number_USPS


# Generated at 2022-06-23 20:34:23.684695
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    # setup
    from mimesis import Person
    from mimesis.providers.person import PersonProvider
    from mimesis.providers.address import AddressProvider
    from mimesis.providers.geography import GeographyProvider
    from mimesis.providers.file import FileProvider
    from mimesis.providers.generic import GenericProvider
    from mimesis.providers.payment import PaymentProvider
    from mimesis.providers.internet import InternetProvider
    from mimesis.providers.numbers import NumbersProvider
    from mimesis.providers.science import ScienceProvider
    from mimesis.providers.business import BusinessProvider
    from mimesis.providers.code import CodeProvider
    from mimesis.providers.text import TextProvider
    from mimesis.providers.date_time import DateTimeProvider

# Generated at 2022-06-23 20:34:29.919086
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    assert USASpecProvider().personality() in (
        'ISFJ', 'ISTJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP', 'ESTP',
        'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ',
    )
    assert 0 < USASpecProvider().personality(category='rheti') < 11

# Generated at 2022-06-23 20:34:33.531713
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """
    Test the method personality of class USASpecProvider
    """

    usa_spec_provider = USASpecProvider()
    assert isinstance(usa_spec_provider.personality(),str)
    assert isinstance(usa_spec_provider.personality(category='rheti'),int)

# Generated at 2022-06-23 20:34:38.063347
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Unit test for method personality of class USASpecProvider."""
    usa = USASpecProvider()
    mbtis = ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
             'ISTP', 'ISFP', 'INFP', 'INTP',
             'ESTP', 'ESFP', 'ENFP', 'ENTP',
             'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')
    assert usa.personality(category='personality') in mbtis
    assert 1 <= usa.personality(category='rheti') <= 10

# Generated at 2022-06-23 20:34:44.802756
# Unit test for method personality of class USASpecProvider
def test_USASpecProvider_personality():
    """Test for method personality of class USASpecProvider."""
    provider = USASpecProvider()
    assert provider.personality() in ('ISFJ', 'ISTJ', 'INFJ', 'INTJ',
                                      'ISTP', 'ISFP', 'INFP', 'INTP',
                                      'ESTP', 'ESFP', 'ENFP', 'ENTP',
                                      'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ')


# Generated at 2022-06-23 20:34:50.810914
# Unit test for constructor of class USASpecProvider
def test_USASpecProvider():
    provider = USASpecProvider()
    assert isinstance(provider, USASpecProvider)
    assert isinstance(provider._random.randint(1, 10), int)
    assert type(provider.tracking_number()) == str