

# Generated at 2022-06-20 19:53:40.139965
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import FactsCollector

    # Mocking method 'get_bin_path' of module 'basic'
    def mocked_get_bin_path(command):
        if command == 'systemctl':
            return '/bin/systemctl'
        if command == 'init':
            return '/sbin/init'

    basic.get_bin_path = mocked_get_bin_path

    # Mocking method 'check_procs' of module 'basic'
    def mocked_check_procs(name):
        return True

    basic.check_procs = mocked_check_procs

    # Make sure that there is no '/run/systemd/system/' directory
    os.rmdir('/run/systemd/system/')

    # Make

# Generated at 2022-06-20 19:53:44.565365
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.name == 'service_mgr'
    assert set(service_mgr.required_facts) == set(['platform', 'distribution'])
    assert service_mgr._fact_ids == set()

# Generated at 2022-06-20 19:53:53.115608
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts

    class TestModule(object):
        def get_bin_path(self, program):
            return "/usr/bin/{}".format(program)

    class TestCollectedFacts(object):
        def __init__(self):
            self.fact_ids = []

        def get(self, key):
            return None

    m = TestModule()
    f = TestCollectedFacts()
    s = ansible.module_utils.facts.collector.ServiceMgrFactCollector()

    with patch.object(ansible.module_utils.facts.collector.ServiceMgrFactCollector, "_read_systemctl_file", return_value=('systemd')):
        assert s.is_systemd_managed(m)

# Generated at 2022-06-20 19:53:57.282558
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = AnsibleModuleMock(
        bin_path={
            'systemctl': '/bin/systemctl'
        }
    )
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False


# Generated at 2022-06-20 19:54:04.086884
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    m = Mock()
    m.get_bin_path.return_value = '/sbin/systemctl'

    value = ServiceMgrFactCollector.is_systemd_managed_offline(m)
    assert value == False

    m.run_command.return_value = [0, '/usr/lib/systemd/systemd']
    value = ServiceMgrFactCollector.is_systemd_managed_offline(m)
    assert value == True


# Generated at 2022-06-20 19:54:09.127613
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class FakeModule:
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/systemctl'
    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed_offline(FakeModule()) == False
    os.symlink('systemd', '/sbin/init')
    assert collector.is_systemd_managed_offline(FakeModule()) == True
    os.remove('/sbin/init')

# Generated at 2022-06-20 19:54:19.077679
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    try:
        import mock
    except ImportError:
        from unittest import mock

    from ansible.module_utils.facts import collector

    # construct a mock class
    collector.AnsibleModule = mock.Mock()
    collector.AnsibleModule.get_bin_path = mock.Mock()
    collector.AnsibleModule.get_bin_path.return_value = False
    assert not collector.ServiceMgrFactCollector.is_systemd_managed(collector.AnsibleModule)

    collector.AnsibleModule.get_bin_path.return_value = '/usr/bin/systemctl'

# Generated at 2022-06-20 19:54:28.424949
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    # Mock module
    class AnsibleModuleMock(object):
        def get_bin_path(self, *args, **kwargs):
            return '/bin/systemctl'

    # Mock module
    class AnsibleModuleMock1(object):
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/systemctl'

    # Mock module
    class AnsibleModuleMock2(object):
        def get_bin_path(self, *args, **kwargs):
            return '/bin/systemctl'

    import tempfile
    from ansible.module_utils._text import to_bytes

    with tempfile.TemporaryFile() as temp_file:
        temp_file.write(to_bytes('systemd', errors='surrogate_or_strict'))
        temp_file

# Generated at 2022-06-20 19:54:35.749011
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import platform
    import os

    class FakeModule:
        def __init__(self, result=None):
            self.result = result

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

        def get_bin_path(self, cmd, opts=None, required=False):
            if cmd == 'systemctl':
                return 'systemctl'
            else:
                return None

    class FakeFacts:
        def __init__(self, system, distribution):
            self.ansible_system = system
            self.ansible_distribution = distribution


# Generated at 2022-06-20 19:54:45.741135
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    data = [
        # input, expected_result
        (False, False),
        (True, True),
    ]

    # List that will contain all the mocks used
    mocks = []

    for input_, expected_result in data:
        # Mock module
        module = type('', (), {})()
        module.get_bin_path = lambda x: input_

        # Mock os.path.islink
        mocks.append(lambda: setattr(os.path, 'islink', lambda x: input_))
        mocks[-1]()

        # Mock os.readlink
        mocks.append(lambda: setattr(os, 'readlink', lambda x: 'systemd' if input_ else ''))
        mocks[-1]()

        # Call method

# Generated at 2022-06-20 19:55:05.797952
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import os
    import shutil
    import tempfile
    import stat

    class FakeModule(object):
        def __init__(self):
            self.path = None

        def get_bin_path(self, name):
            return None

    # test if it returns False when tools aren't available
    module = FakeModule()
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

    # test if it returns False when the marker files aren't available
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 19:55:10.344977
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Testing false condition
    module_mock = FakeAnsibleModule()
    module_mock.get_bin_path_mock = lambda x: None
    result = ServiceMgrFactCollector.is_systemd_managed_offline(module_mock)
    assert result == False

    # Testing true condition
    module_mock.get_bin_path_mock = lambda x: 'systemctl'
    os.symlink('systemd', '/sbin/init')
    result = ServiceMgrFactCollector.is_systemd_managed_offline(module_mock)
    assert result == True
    os.unlink('/sbin/init')


# Generated at 2022-06-20 19:55:21.773150
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import basic

    mock_module = basic.AnsibleModule(
        argument_spec={},
    )

    # If get_bin_path returns false
    mock_module.get_bin_path = lambda name: False
    assert not ServiceMgrFactCollector.is_systemd_managed(mock_module)

    # If get_bin_path returns true and no canary directory exists
    mock_module.get_bin_path = lambda name: True
    assert not ServiceMgrFactCollector.is_systemd_managed(mock_module)

    # If get_bin_path returns true and the first canary directory exists
    mock_module.get_bin_path = lambda name: True
    mock_module.os_path_exists = lambda path: path == "/run/systemd/system/"

# Generated at 2022-06-20 19:55:27.285728
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import collector

    Sm = ServiceMgrFactCollector()
    assert Sm.name == 'service_mgr'
    assert set(Sm.required_facts) == set(['platform', 'distribution'])



# Generated at 2022-06-20 19:55:39.244459
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # initialization
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector._module_name = "ansible_service_mgr_facts"
    service_mgr_fact_collector._module = None
    service_mgr_fact_collector._facts_cache = {}

    # checks if a module is available
    service_mgr_fact_collector.is_systemd_managed_offline = MagicMock(return_value=False)
    service_mgr_fact_collector.is_systemd_managed = MagicMock(return_value=False)
    service_mgr_fact_collector.collect(collected_facts={'ansible_distribution': 'OpenWrt'})
    service_mgr_fact_collector.is_systemd

# Generated at 2022-06-20 19:55:49.646497
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # instantiate an instance of the class under test
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # create a mock module
    class MockModule(object):
        @staticmethod
        def get_bin_path(binary_name):
            return True

    # create a mock collected_facts dict
    collected_facts = dict()
    collected_facts['ansible_distribution'] = 'OpenWrt'
    collected_facts['ansible_system'] = 'Linux'
    # call method collect of class ServiceMgrFactCollector
    result = service_mgr_fact_collector.collect(module=MockModule(), collected_facts=collected_facts)
    # assert that the result of the call is the expected result
    assert result == {'service_mgr': 'openwrt_init'}

# Generated at 2022-06-20 19:56:00.508493
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import is_systemd_managed

    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector.name == 'service_mgr'
    assert service_mgr_collector.required_facts == set(['platform', 'distribution'])
    assert service_mgr_collector.__dict__ == {'_fact_ids': set()}

    # Unit test is_systemd_managed
    assert is_systemd_managed() == False

    return True

# Generated at 2022-06-20 19:56:02.960031
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    sm = ServiceMgrFactCollector()
    assert sm.name == 'service_mgr'
    assert sm.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:56:05.161218
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Constructs ServiceMgrFactCollector and verifies returned class is equal to the constructor parameter
    assert ServiceMgrFactCollector().__class__ == ServiceMgrFactCollector


# Generated at 2022-06-20 19:56:06.277156
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector.collect()

# Generated at 2022-06-20 19:56:34.882914
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    obj = ServiceMgrFactCollector()
    assert obj.is_systemd_managed_offline(None)

# Generated at 2022-06-20 19:56:38.591975
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector.name == 'service_mgr'
    assert service_mgr_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:56:42.780605
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc.name == 'service_mgr'
    assert smfc._fact_ids == set()
    assert smfc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:56:51.567319
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class ModuleStub:
        def get_bin_path(self, arg):
            return None

        def run_command(self, arg, use_unsafe_shell=False):
            return 0, "/sbin/init", ""

    collection_module = ModuleStub()
    collection_facts = {'ansible_distribution': 'Ubuntu',
                        'ansible_system': 'Linux'}
    test_object = ServiceMgrFactCollector(collection_module, collection_facts)
    test_result = test_object.collect()
    assert('service_mgr' in test_result)
    assert(test_result['service_mgr'] == 'service')


# Generated at 2022-06-20 19:57:02.202461
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.formatters import BaseFormatter

    class FakeModule:
        def get_bin_path(self, *args, **kwargs):
            return None

        def run_command(self, *args, **kwargs):
            return [0, "stdout", "stderr"]

    class FakeFormatter(BaseFormatter):
        pass

    class FakeFactCollector(FactsCollector):
        name = 'test_service_mgr'


# Generated at 2022-06-20 19:57:05.889617
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test_ServiceMgrFactCollector = ServiceMgrFactCollector()
    assert not test_ServiceMgrFactCollector.is_systemd_managed(None)


# Generated at 2022-06-20 19:57:15.656317
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = object()
    module.get_bin_path = lambda x: '/bin/systemctl'
    mod_obj = ServiceMgrFactCollector()


# Generated at 2022-06-20 19:57:25.966580
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    '''
    Test is_systemd_managed() method of class ServiceMgrFactCollector
    '''
    class TestAnsibleModule:
        # Test module

        def __init__(self):
            self._tmpdir = None

        def get_bin_path(self, executable):
            # simulate executable found in $PATH
            return executable

        def run_command(self, command, use_unsafe_shell):
            self.command = command
            self.use_unsafe_shell = use_unsafe_shell
            return (0, '', '')

    # unit test for is_systemd_managed():
    # test case where systemd is used, /run/system/systemd is present

# Generated at 2022-06-20 19:57:30.144745
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    worker = ServiceMgrFactCollector()
    assert worker.name == 'service_mgr'
    assert worker.required_facts == {'platform', 'distribution'}
    assert worker.priority == -1
    assert worker._fact_ids == set()

# Generated at 2022-06-20 19:57:37.149767
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class ModuleStub(object):
        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return cmd

    collector = ServiceMgrFactCollector()

    # Test with a symlink to systemd
    collector.is_systemd_managed_offline(ModuleStub())

    # Test without symlink
    os.remove('/sbin/init')
    collector.is_systemd_managed_offline(ModuleStub())

# Generated at 2022-06-20 19:58:39.763788
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import platform
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    class MockModule():
        def __init__(self, path):
            self.bin_path = path
            self.run_command_called = False

            if (os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd'):
                self.run_command_return_value = ("", "/sbin/init: symbolic link to systemd", "")

# Generated at 2022-06-20 19:58:49.350028
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    import tempfile

    class MockModule(object):
        def __init__(self):
            self.tmpdir = tempfile.mkdtemp()

        def get_bin_path(self, cmd):
            return '/bin/%s' % cmd

        def run_command(self, cmd, use_unsafe_shell=True):
            return None

    # systemd
    def mock_isdir(path):
        if path[0:12] == '/run/systemd':
            return True
        return False

    def mock_exist(path):
        if path[0:12] == '/dev/.run/systemd':
            return True
        return False

    with MockModule() as module:
        from ansible.module_utils.facts.system.service_mgr import is_systemd_managed

# Generated at 2022-06-20 19:58:53.681435
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x.name == 'service_mgr'
    assert x.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:59:00.734813
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Test function collects facts related to system service manager and init.
    It raises an exception if there are any missing facts.
    """
    collector = ServiceMgrFactCollector({})

    facts_dict = collector.collect()
    assert isinstance(facts_dict, dict)

    # Check if the required fact is present in the collected facts
    assert 'service_mgr' in facts_dict


# Generated at 2022-06-20 19:59:12.177964
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule:
        def get_bin_path(self, path, opt_dirs=()):
            re_tests = [
                ('systemctl', '/usr/bin/systemctl'),
                ('not-existing-executable', None),
            ]
            for test in re_tests:
                if path == test[0]:
                    return test[1]

    class MockExists:
        def __init__(self, exists):
            self.exists = exists

        def exists(self, path):
            return self.exists

    class MockReadlink:
        def __init__(self, path):
            self.path = path

        def readlink(self, path):
            return self.path

    class Mock:
        def __init__(self, systemctl, canary):
            self.systemctl = systemctl


# Generated at 2022-06-20 19:59:21.579163
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create mock module and facts
    module = MagicMock()
    collected_facts = {}

    # Mock systemctl, /run/systemd/system/, /dev/.run/systemd/ and /dev/.systemd/ (all exist and point to files)
    paths = ["/bin/systemctl", "/run/systemd/system", "/dev/.run/systemd", "/dev/.systemd"]
    for path in paths:
        module.get_bin_path.return_value = path

    # Get ServiceMgrFactCollector instance
    collector = ServiceMgrFactCollector()

    # Check that is_systemd_managed returns True
    assert collector.is_systemd_managed(module) == True


# Generated at 2022-06-20 19:59:24.766951
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc
    assert smfc.name == 'service_mgr'
    assert smfc.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-20 19:59:27.805083
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    facts_dict = ServiceMgrFactCollector().collect()
    assert isinstance(facts_dict, dict)
    assert 'service_mgr' in facts_dict

# Generated at 2022-06-20 19:59:29.470828
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # TODO: write unit test once ansible module is available
    return True

# Generated at 2022-06-20 19:59:35.491271
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Create the instance of ServiceMgrFactCollector
    service_mgr_fc = ServiceMgrFactCollector()
    # Check instance created successfully
    assert service_mgr_fc

    assert service_mgr_fc.is_systemd_managed("systemctl") == False
    assert service_mgr_fc.is_systemd_managed("systemctlx") == False
    assert service_mgr_fc.is_systemd_managed("abcdefg") == False



# Generated at 2022-06-20 20:01:47.357238
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    import platform
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import get_collector_instance

    collectors = default_collectors
    collector = get_collector_instance(
        collector_class=ServiceMgrFactCollector,
        collectors=collectors,
        builtin_collectors=Collector.builtin_collectors,
        collector_name=ServiceMgrFactCollector.name
    )

    assert isinstance(collector, ServiceMgrFactCollector)

# Generated at 2022-06-20 20:01:57.624530
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create fake module object
    module = type('module', (), dict())()

    # Create fake get_bin_path method which returns True
    def fake_get_bin_path(self, path):
        return True

    module.get_bin_path = fake_get_bin_path

    # Create fake readlink method which returns 'systemd' when p= 'systemctl'
    def fake_readlink(self, p):
        if p == 'systemctl':
            return 'systemd'

    os.readlink = fake_readlink

    # Create fake islink method which returns True
    os.path.islink = lambda self: True

    # Create fake object for is_systemd_managed_offline() method
    service_manager = type('ServiceMgrFactCollector', (), dict())()

    # Check if method returns True
   

# Generated at 2022-06-20 20:01:58.659271
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    This test should be implemented in future
    """
    pass


# Generated at 2022-06-20 20:01:59.133911
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-20 20:02:10.374891
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys
    import os

    class TestServiceMgrFactCollector():
        def __init__(self, module):
            self.module = module
            self.test_dir = os.path.dirname(os.path.realpath(__file__))

        def get_bin_path(self, name):
            # return fake path to name if it exists in test environment
            if os.path.isfile("%s/../bin/%s" % (self.test_dir, name)):
                return("%s/../bin/%s" % (self.test_dir, name))

        def run_command(self, command, use_unsafe_shell=False):
            # Return false rc, empty string and false error
            return 0, '', None

    # Instantiate a fact collector, so we can test and reuse its is

# Generated at 2022-06-20 20:02:16.688476
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Unit test for method collect of class ServiceMgrFactCollector
    # Mock a module object
    mock_module = MagicMock()

    # Create a ServiceMgrFactCollector object
    service_mgr_fc = ServiceMgrFactCollector()

    # Create a test case dictionary
    test_case = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': '',
        'systemd': 'True',
    }

    # Mock a get_bin_path method of ServiceMgrFactCollector object,
    # which will return 'systemctl' as the path for systemctl
    service_mgr_fc.get_bin_path = MagicMock(return_value='systemctl')

    # Mock a platform.mac_ver method of platform module

# Generated at 2022-06-20 20:02:24.253043
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic

    sut, module = ServiceMgrFactCollector(), basic.AnsibleModule()

    def get_bin_path(name):
        return '/bin/%s' % name


# Generated at 2022-06-20 20:02:33.731933
# Unit test for method collect of class ServiceMgrFactCollector

# Generated at 2022-06-20 20:02:38.468172
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Given a ServiceMgrFactCollector object
    ServiceMgrFactCollector = ServiceMgrFactCollector()

    # When I call the method collect
    returned = ServiceMgrFactCollector.collect()

    # Then I see that the returned dict is not empty
    assert returned is not None

# Generated at 2022-06-20 20:02:40.866147
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector().collect()