

# Generated at 2022-06-20 19:53:46.370970
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Replicate the module class
    class MockModule(object):
        def get_bin_path(self, executable, required=False):
            if executable == "systemctl":
                return "/bin/systemctl"
            else:
                return None

    # Test for systemctl and a canary path
    module = MockModule()
    assert ServiceMgrFactCollector.is_systemd_managed(module)

    # Test for systemctl and no canary path
    class MockModule(object):
        def get_bin_path(self, executable, required=False):
            if executable == "systemctl":
                return "/bin/systemctl"
            else:
                return None
    module = MockModule()
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

    # Test no systemctl

# Generated at 2022-06-20 19:53:56.120896
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # By setting the 'ANSIBLE_FACTS_CACHE_PLUGIN' environment variable,
    # we can cause the module to use our test class instead of the real one.
    test_module = ServiceMgrFactCollectorTestModule()
    test_module.exit_json = lambda facts: facts
    test_module.run_command = lambda params: ('1', 'init\n', '')

    facts_dict = ServiceMgrFactCollector.collect(module=test_module)
    assert 'service_mgr' in facts_dict
    assert facts_dict['service_mgr'] == 'init'


# Generated at 2022-06-20 19:54:04.089600
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    module = None
    collected_facts = {"ansible_system": "Linux", "ansible_distribution": "OpenWrt"}
    service_mgr_collector = ServiceMgrFactCollector()

    # We do not need to test if service_mgr_collector can handle invalid input.
    # The code is covered in ansible/module_utils/facts/collector.py where
    # BaseFactCollector.collect() handles that situation.
    assert service_mgr_collector.collect(module, collected_facts) == {"service_mgr": "openwrt_init"}

# Generated at 2022-06-20 19:54:11.863417
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class Module(object):
        def get_bin_path(self, bin_path):
            if bin_path == "systemctl":
                return "/usr/bin/systemctl"

    module = Module()
    service_mgr_fact_collector = ServiceMgrFactCollector(module=module)
    assert service_mgr_fact_collector.is_systemd_managed_offline(module) == False

# Generated at 2022-06-20 19:54:20.040689
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    fake_module = AnsibleModule(argument_spec={})
    fake_module.get_bin_path = lambda x: '/bin/systemctl'
    fake_module.run_command = lambda cmd: (1, '', 'error')
    fake_module.os = os
    fake_module.platform = platform
    fake_module.os.path = os.path
    fake_module.os.path.exists = os.path.exists
    fake_module.os.path.islink = os.path.islink
    fake_module.os.readlink = os.readlink

    fake_module.os.path.exists.return_value = True
    fake_module.os.path.exists.generic = True

    collector = ServiceMgrFactCollector(fake_module)
    is_systemd_managed_off

# Generated at 2022-06-20 19:54:20.679218
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert True

# Generated at 2022-06-20 19:54:26.984044
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Unit test for method collect of class ServiceMgrFactCollector
    """
    class MockModule(object):
        def get_bin_path(self, command):
            return command

        def run_command(self, command, use_unsafe_shell=True):
            return (0, "COMMAND", "")

    module = MockModule()
    factCollector = ServiceMgrFactCollector()

    res = factCollector.collect(module)

    assert res['service_mgr'] == 'service'

# Generated at 2022-06-20 19:54:37.377215
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Mock module and class method
    import ansible.module_utils.facts.system.service_mgr as service_mgr
    service_mgr.get_file_content = lambda x: 'init'
    service_mgr.os.path.exists = lambda x: True
    service_mgr.os.path.islink = lambda x: True
    service_mgr.os.readlink = lambda x: 'systemd'
    service_mgr.platform.mac_ver = lambda _: ('10.11', ('', '', ''), 'x86_64')
    service_mgr.platform.uname = lambda _: ('Linux', '', '', '', 'x86_64')
    service_mgr.platform.system = lambda: 'SunOS'

# Generated at 2022-06-20 19:54:41.162111
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Test the constructor of ServiceMgrFactCollector
    smfc = ServiceMgrFactCollector()
    assert smfc.name == "service_mgr"
    assert smfc._fact_ids == set()
    assert smfc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:54:42.445930
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    x = ServiceMgrFactCollector()
    assert x
    assert x.name == 'service_mgr'

# Generated at 2022-06-20 19:55:04.721739
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class ModuleMock:
        """Mock class for module.run_command"""
        def __init__(self, rc, proc_1, err):
            self.rc = rc
            self.proc_1 = proc_1
            self.err = err

        def run_command(self, *args, **kwargs):
            return self.rc, self.proc_1, self.err

        def get_bin_path(self, *args, **kwargs):
            if args[0] == 'systemctl':
                return True
            if args[0] == 'initctl':
                return True
            if args[0] == 'zsh':
                return True

    # Test for proc_1 = 'init'
    module_mock = ModuleMock(0, 'systemd', '')

# Generated at 2022-06-20 19:55:12.442664
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Arrange
    test_module = type('FakeModule', (object,), {
        'get_bin_path': lambda _: '/sbin/init',
        'run_command': lambda _, args, opts: (0, {
            '/proc/1/comm': 'init',
            'ps -p 1 -o comm|tail -n 1': 'init\n',
            '/sbin/init': 'systemd',
        }[args], None)
    })()

    # Act
    fact_collector = ServiceMgrFactCollector()
    facts_dict = fact_collector.collect(test_module, {
        'ansible_distribution': 'Linux',
        'ansible_system': 'Linux'
    })

    # Assert
    assert facts_dict['service_mgr'] == 'systemd'

# Generated at 2022-06-20 19:55:18.605812
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class MockModule:
        def run_command(self, command, use_unsafe_shell):
            return 0, '/usr/lib/systemd/systemd', ''
        def get_bin_path(self, command):
            return '/lib/systemd'

    mock_module = MockModule()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(mock_module)



# Generated at 2022-06-20 19:55:27.034291
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import loader

    class FakeModule:
        def __init__(self, distro=None):
            self._distro = distro
            self._facts = {}

        def get_bin_path(self, path):
            return '/bin/{0}'.format(path)

        def run_command(self, cmd, use_unsafe_shell=False):
            if self._distro:
                return 0, self._distro, ''
            return 1, '', ''

        def get_distribution(self):
            return self._distro

    def test_systemd_init(distro=None):
        fake_module = FakeModule(distro=distro)

        # test is_systemd_managed

# Generated at 2022-06-20 19:55:28.428957
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x is not None

# Generated at 2022-06-20 19:55:40.545878
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockAnsibleModule(object):
        def get_bin_path(self, command):
            return '/bin/' + command

        def run_command(self, cmd, use_unsafe_shell=True):
            filename = {
                'systemctl list-units': 'systemctl_list_units.txt',
                'ps -p 1 -o comm|tail -n 1': 'ps_p_1_o_comm.txt'
            }[cmd]
            with open(os.path.join(os.path.dirname(__file__), filename)) as input_file:
                return (0, input_file.read(), '')

    def mock_exists(file_name):
        if file_name == '/dev/.run/systemd/':
            return False
        return True


# Generated at 2022-06-20 19:55:45.759615
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import Systemd
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    assert not ServiceMgrFactCollector.is_systemd_managed_offline(Systemd())

# Generated at 2022-06-20 19:55:48.806713
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    facts = ServiceMgrFactCollector()
    assert facts.name == 'service_mgr'
    assert set(facts.required_facts) == set(['platform', 'distribution'])
    assert facts.collected_facts == None

# Generated at 2022-06-20 19:55:58.315513
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Test with empty module argument
    facts_dict = ServiceMgrFactCollector().collect(module=None)
    assert facts_dict == {}

    # Test with non-empty module argument
    import ansible.module_utils.facts.collector
    service_mgr_fact_collector_obj = ansible.module_utils.facts.collector.ServiceMgrFactCollector()
    service_mgr_fact_collector_obj.files = {}
    facts_dict = service_mgr_fact_collector_obj.collect(module=None)
    assert facts_dict == {}


# Generated at 2022-06-20 19:56:03.162076
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    import mock
    import AnsibleModule

    # Test is_systemd_managed()
    with mock.patch('ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed') as is_systemd_managed_mock:
        is_systemd_managed_mock.return_value = True
        test_module = AnsibleModule.AnsibleModule(argument_spec={})
        smfc = ServiceMgrFactCollector(module=test_module)
        assert smfc.collect()['service_mgr'] == 'systemd'
        is_systemd_managed_mock.assert_called_once()

    # Test is_systemd_managed_offline()

# Generated at 2022-06-20 19:56:39.559212
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class MockModule():
        def __init__(self, system_command):
            self.system_command = system_command

        def get_bin_path(self, filename, required=False):
            return '/bin/' + self.system_command

        def run_command(self, command, *args, **kwargs):
            return 0, self.system_command, None

    # Generate systemctl command outputs

# Generated at 2022-06-20 19:56:50.332543
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def get_bin_path(self, path):
            return '/bin/%s' % path

    class MockFacts(object):
        def __init__(self, **kwargs):
            self.values = kwargs

        def get(self, k, d=None):
            return self.values.get(k, d)

    # Do not collect facts on Windows.
    # If we're on Windows, return "service" as it is most likely
    if platform.system() == 'Windows':
        smfc = ServiceMgrFactCollector()
        facts = smfc.collect()
        assert facts['service_mgr'] == 'service'
        return

    # MockModule is sufficient unless we need to mock `get_bin_path`
    # If we need to test an edge case where the module is

# Generated at 2022-06-20 19:57:00.923063
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import DictCollector
    from ansible.module_utils.facts.collector import ListCollector

    # Create a TestModule instance
    testmodule = type('ansible_module', (object,), {})()
    testmodule.params = {}

    def get_bin_path(self, executable):
        return '/bin/' + executable

    setattr(testmodule, 'get_bin_path', get_bin_path)

    # Create a BaseFactCollector instance
    b = BaseFactCollector(testmodule)
    assert isinstance(b, BaseFactCollector)
    assert isinstance(b, Collector)


    # Create a DictCollector instance
    d = DictCollector(testmodule)


# Generated at 2022-06-20 19:57:12.591779
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    test_module = MockModule()

    test_module.collect_subset = []

    test_module.get_bin_path.side_effect = lambda s: {'systemctl': '/usr/bin/systemctl', 'systemd': '/usr/lib/systemd'}.get(s, None)
    test_module.run_command.return_value = (0, '/bin/init', '')

    test_collector = ServiceMgrFactCollector()
    test_collector.required_facts = set(['platform', 'distribution'])

    ansible_facts = {'ansible_system': 'Linux', 'ansible_distribution': 'CentOS'}

    assert test_collector.collect(test_module, ansible_facts) == {'service_mgr': 'sysvinit'}

    test_module.run

# Generated at 2022-06-20 19:57:22.830548
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class ModuleMock():
        def __init__(self, result):
            self.result = result

        def get_bin_path(self, app):
            if app == 'systemctl':
                return True
            else:
                return False

        def run_command(self, command, use_unsafe_shell):
            if command == "ps -p 1 -o comm|tail -n 1" and use_unsafe_shell == True:
                return (0, self.result, '')

    # Test for macosx
    moduleMock = ModuleMock("test")
    collected_facts = {'ansible_distribution': 'MacOSX', 'ansible_system': 'Darwin'}
    smfc = ServiceMgrFactCollector(moduleMock)
    assert smfc.collect(moduleMock, collected_facts)

# Generated at 2022-06-20 19:57:29.614083
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a mock module so that we can access the module's methods
    class MockModule:
        def get_bin_path(self, systemctl):
            return '/bin/systemctl'

    module = MockModule()
    facts_collector = Collector()


# Generated at 2022-06-20 19:57:31.738287
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    obj = obj.collect()

    assert obj['service_mgr'] in ['systemd', 'service']

# Generated at 2022-06-20 19:57:41.065338
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.utils import get_file_content

    def mock_get_file_content(file):
        content_map = {
            '/proc/1/comm': 'systemd',
            '/sbin/init': '/systemd',
            '/etc/suse-release': 'suse',
            '/etc/redhat-release': 'redhat',
            '/etc/debian_version': 'debian',
        }
        return content_map.get(file)

    def mock_is_systemd_managed(module):
        return True

    def mock_is_systemd_managed_offline(module):
        return True

    class MockModule:
        def __init__(self):
            self.run_command_results

# Generated at 2022-06-20 19:57:53.165790
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # test for Red Hat Enterprise Linux 7.4
    class FakeModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary):
            return '/usr/bin/' + binary

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '/usr/lib/systemd/systemd', ''

    m = FakeModule()

    collected_facts = {'ansible_system': 'Linux', 'ansible_distribution': 'RedHat'}
    SMFC = ServiceMgrFactCollector(m)
    result = SMFC.collect(collected_facts=collected_facts)
    assert result['service_mgr'] == 'systemd'

    # test for Fedora 27

# Generated at 2022-06-20 19:57:56.238827
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Test ServiceMgrFactCollector class
    service_mgr_obj = ServiceMgrFactCollector()
    assert isinstance(service_mgr_obj, ServiceMgrFactCollector)

# Generated at 2022-06-20 19:58:36.262436
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-20 19:58:41.479625
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    os.symlink('systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None)
    os.remove('/sbin/init')

# Generated at 2022-06-20 19:58:42.372683
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # TODO: add unit tests
    return None

# Generated at 2022-06-20 19:58:51.028705
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.test.test_service_mgr_facts import TestModule

    # Test is_systemd_managed with systemd installed
    test_module = TestModule()
    service_mgr_collector = get_collector_instance(ServiceMgrFactCollector)

    assert service_mgr_collector.is_systemd_managed(module=test_module)
    assert not service_mgr_collector.is_systemd_managed_offline(module=test_module)

    # Test is_systemd_managed_offline with systemd installed
    test_module = TestModule(systemd=False)
    service_mgr_collector = get_collector_instance(ServiceMgrFactCollector)

   

# Generated at 2022-06-20 19:58:56.344826
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(mock_module())

    restore_is_systemd_test_env()
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(mock_module())


# Generated at 2022-06-20 19:59:09.273884
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}
            self.run_command = lambda x: (0, x, '')
            self.get_bin_path = lambda x: x

    fact_collector = ServiceMgrFactCollector()
    module = AnsibleModuleMock()

# Generated at 2022-06-20 19:59:12.137417
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test 1: check if /sbin/init is a symlink to systemd and return True
    os.symlink('systemd','/sbin/init')
    assert service_mgr_fact_collector.is_systemd_managed_offline(None)
    os.remove('/sbin/init')

    # Test 2: if init is not a symlink to systemd and return False
    assert not service_mgr_fact_collector.is_systemd_managed_offline(None)


# Generated at 2022-06-20 19:59:13.794693
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = MockModule()
    fact_collector = ServiceMgrFactCollector()
    is_systemd_managed = fact_collector.is_systemd_managed(module)

    assert (is_systemd_managed in (True, False))


# Generated at 2022-06-20 19:59:18.126603
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    x = ServiceMgrFactCollector()
    assert isinstance(x, BaseFactCollector)
    assert hasattr(x, 'collect')
    assert x.name == "service_mgr"
    assert x.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:59:18.664106
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    pass

# Generated at 2022-06-20 20:00:15.979436
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    import platform
    from collections import namedtuple
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.service_mgr.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Make class ServiceMgrFactCollector testable
    ServiceMgrFactCollector._collect = lambda self: {'service_mgr': 'sysvinit'}
    ServiceMgrFactCollector._read_file_on_remote = lambda self, host, path: ''
    BaseFactCollector._get_file_content = lambda self, path: ''

    # Mocking classes needed for instantiation of class ServiceMgrFactCollector
    class MockModule(object):
        def __init__(self):
            pass


# Generated at 2022-06-20 20:00:27.871618
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector()
    # This test is known to fail on systems without systemd-sysvinit package, e.g. on Leap42.1.
    # Finer granularity is needed
    # from ansible.module_utils.facts import test_module
    # test_module.exit_json = lambda info: info
    # module = test_module.MockModule({})
    # assert collector.is_systemd_managed_offline(module=module)

# Generated at 2022-06-20 20:00:31.340794
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    svc_facts = ServiceMgrFactCollector(None)
    assert svc_facts.name == 'service_mgr'
    assert svc_facts.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 20:00:34.329168
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    '''Unit test for constructor of class ServiceMgrFactCollector'''
    service_mgr_fact_collector = ServiceMgrFactCollector()

    assert service_mgr_fact_collector.name == 'service_mgr'

# Generated at 2022-06-20 20:00:37.094192
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed({'get_bin_path': lambda _: '/bin/systemctl'}) == True


# Generated at 2022-06-20 20:00:47.848310
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import tempfile
    import os
    import os.path

    # pylint: disable=missing-docstring
    class ModuleStub(object):
        def __init__(self):
            self.bin_path_cache = {}
            self.tmpdir = tempfile.mkdtemp()
            self.PATH = [self.tmpdir]
            self.libc_path = os.path.join(self.tmpdir, 'libc.so.6')
            with open(self.libc_path, 'w') as fh:
                fh.write('#!/usr/bin/python\n')
            os.chmod(self.libc_path, 0o755)


# Generated at 2022-06-20 20:00:49.870820
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    serviceMgrFactCollector = ServiceMgrFactCollector()
    assert serviceMgrFactCollector.is_systemd_managed_offline(None) == False

# Generated at 2022-06-20 20:01:02.098393
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import pytest

    # Mocking the module object
    class ModuleMock(object):
        def __init__(self):
            self.params = dict()
            self.params['path'] = os.environ['PATH']

        def get_bin_path(self, arg):
            # Return path of arg if it exists in PATH
            import distutils.spawn
            path_ = distutils.spawn.find_executable(arg)
            return path_

    # Create object of ServiceMgrFactCollector
    serviceMgrFactCollector = ServiceMgrFactCollector()

    # Mocking the module for method is_systemd_managed_offline
    moduleMock = ModuleMock()

    # Case 1: When /sbin/init is a symlink to systemd

# Generated at 2022-06-20 20:01:11.965967
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    def get_bin_path_mock(module_name):
        return module_name
    
    # mock module
    class ModuleMock:
        def get_bin_path(self, module_name):
            return get_bin_path_mock(module_name)
    
    module = ModuleMock()
    service_manager_fact_collector = ServiceMgrFactCollector()

    # generate is_systemd_managed_offline
    def test_is_systemd_managed_offline(check_symlink_path, systemctl_path, expected_value):
        os.symlink(check_symlink_path, '/sbin/init')
        get_bin_path_mock.side_effect = {'systemctl': systemctl_path}

# Generated at 2022-06-20 20:01:22.372440
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    ''' test method ServiceMgrFactCollector.is_systemd_managed '''
    from ansible.module_utils.facts.collector import Cache

    # Mock the module
    import ansible.module_utils.facts.collector.service_mgr

    class MyModule:
        def __init__(self, sbpath):
            self.sbpath = sbpath
            self.env = {}
            self.params = {}
            self.fail_json = {}
            self.exit_json = {}
            self.fail_json_content = {}

        def get_bin_path(self, name, required=False):
            if name == 'systemctl':
                return self.sbpath
