

# Generated at 2022-06-20 19:53:42.796685
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    supported_os = [
        'Archlinux',
        'Debian',
        'Fedora',
        'FreeBSD',
        'MacOSX',
        'OpenBSD',
        'OpenWrt',
        'RHEL',
        'RedHat',
        'SuSE',
        'Ubuntu',
        'Alpine',
        'AIX',
        'Solaris',
    ]

    unsupported_os = [
        'Bitrig',
        'CentOS',
        'DragonFly',
        'Gentoo',
        'Mageia',
        'NetBSD',
        'SLES',
        'Windows',
    ]


# Generated at 2022-06-20 19:53:49.512071
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Method to test constructor of class ServiceMgrFactCollector
    s_test_service_mgr_fact_collector = ServiceMgrFactCollector()
    assert not s_test_service_mgr_fact_collector.required_facts
    assert s_test_service_mgr_fact_collector.name == 'service_mgr'
    assert isinstance(s_test_service_mgr_fact_collector._fact_ids, set)


# Generated at 2022-06-20 19:54:01.681832
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    class FakeModule:
        def __init__(self):
            self.fail_json = None
            self.params = None

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

    false_module = FakeModule()
    false_module.params = {}
    false_service_mgr_collector = ServiceMgrFactCollector(false_module)
    fd, fname = tempfile.mkstemp(suffix='.py', text=True)

# Generated at 2022-06-20 19:54:09.462266
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import injector
    from ansible.module_utils.facts.processor.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import DictObject

    fact_collector = ServiceMgrFactCollector()

    class FakeModule(object):
        def __init__(self):
            self.fake_module = True

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

        def run_command(self, executable, use_unsafe_shell=True):
            return 0, '',

# Generated at 2022-06-20 19:54:19.287982
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    s = ServiceMgrFactCollector()

    # Test with no systemctl binary
    module = mock.MagicMock()
    module.get_bin_path = lambda path: None
    assert (s.is_systemd_managed(module) is False)

    # Test with systemctl but no systemd
    module = mock.MagicMock()
    module.get_bin_path = lambda path: path
    assert (s.is_systemd_managed(module) is False)

    # Test with systemctl and systemd but /run/systemd/system doesn't exist
    module = mock.MagicMock()
    module.get_bin_path = lambda path: path
    assert (s.is_systemd_managed(module) is False)

    # Test with systemctl and systemd and /run/systemd/system exists
   

# Generated at 2022-06-20 19:54:28.528986
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import shutil
    import sys
    import tempfile
    import unittest

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector

    class FakeModule(object):
        def __init__(self):
            self._ansible_sys_exec_path = None

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'

        def get_system_temp_dir(self):
            return '/tmp'

    class FakePlatformFactCollector(PlatformFactCollector):
        def __init__(self):
            self._facts = {'system': 'Linux'}


# Generated at 2022-06-20 19:54:32.109915
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector()
    class MockModule(object):
        def get_bin_path(self, binary):
            return '/usr/bin/systemctl'
    mock_module = MockModule()
    assert collector.is_systemd_managed_offline(mock_module) == True


# Generated at 2022-06-20 19:54:35.011445
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x
    assert x.name == 'service_mgr'

# Generated at 2022-06-20 19:54:40.663468
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    ServiceMgrFactCollector = ServiceMgrFactCollector()
    ServiceMgrFactCollector.platform = 'Linux'
    ServiceMgrFactCollector.distribution = 'Debian'
    assert ServiceMgrFactCollector.is_systemd_managed({'run_command':run_command_fake, 'get_bin_path':get_bin_path_fake})


# Generated at 2022-06-20 19:54:46.867980
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    collector = ServiceMgrFactCollector()
    for f in BaseFactCollector.__subclasses__():
        ModuleFactCollector.add_collector(f)
    facts_dict = ModuleFactCollector.collect(module=None, collected_facts=None, gather_subset=['all'])
    assert('service_mgr' in facts_dict)


# Generated at 2022-06-20 19:55:00.834943
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'service_mgr'

# Generated at 2022-06-20 19:55:08.093725
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import FactCollector
    import ansible.module_utils.facts.system.service_mgr

    class MockModule():
        def get_bin_path(self, command):
            if command == 'systemctl':
                return '/usr/bin/systemctl'
            elif command == 'initctl':
                return '/sbin/initctl'
            return None

        def run_command(self, command):
            if command == "ps -p 1 -o comm|tail -n 1":
                return 0, '/lib/systemd/systemd', ''
            else:
                return 0, '', ''

    class MockFactCollector(FactCollector):
        def __init__(self, module):
            self.module = module
            self

# Generated at 2022-06-20 19:55:14.620148
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys
    class MockModule:
        def __init__(self):
            self.run_command_list = [
                (0, 'init\n', ''),
                (1, '', ''),
                (0, 'SYSTEMD\n', ''),
                (0, 'SVC\n', ''),
                (0, 'OpenRC\n', ''),
            ]
            self.run_command_counter = 0

        def run_command(self, command, use_unsafe_shell=False):
            self.run_command_counter += 1
            index = self.run_command_counter
            if index > len(self.run_command_list):
                print("run_command called out of bounds, maximum len is %d" % len(self.run_command_list))
                sys.exit(1)


# Generated at 2022-06-20 19:55:17.155796
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # collect() returns a dictionary
    assert isinstance(ServiceMgrFactCollector().collect(), dict)


# Generated at 2022-06-20 19:55:18.204378
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    print(ServiceMgrFactCollector)

# Generated at 2022-06-20 19:55:26.797722
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts import ModuleSpecificFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector
    from ansible.module_utils.facts.network import NetworkFactCollector
    from ansible.module_utils.facts.collector import FactCollector

    # Create list of FactCollector subclasses which are used to collect facts
    fact_collector_subclasses = [SystemFactCollector, NetworkFactCollector]
    # Create instance of ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # Create list of fact ids which are collected by ServiceMgrFactCollector
    fact_ids = ['service_mgr']
    # Create instance of ModuleSpecificFactCollector

# Generated at 2022-06-20 19:55:38.733290
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import get_collector_class
    import platform

    # on all non-linux systems and on newer versions of linux, is_systemd_managed should return false
    if platform.system() != 'Linux' or LooseVersion(platform.linux_distribution()[1]) >= LooseVersion('3.19.0'):
        assert ServiceMgrFactCollector.is_systemd_managed(None) == False

# Generated at 2022-06-20 19:55:49.243340
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FakeModule

    module = FakeModule()
    module.run_command = lambda args, use_unsafe_shell=False: (0, '', '')
    module.get_bin_path = lambda x: True

    # Test 1: systemd-test
    module.params = {'is_systemd_managed': lambda module: True}
    collector = ServiceMgrFactCollector()
    assert collector.collect(module) == {'service_mgr': 'systemd'}

    # Test 2: upstart-test

# Generated at 2022-06-20 19:56:01.260148
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts import injector

    # Tell the injector to look for the 'platform' and 'distribution' facts
    injector.add_category('platform', ServiceMgrFactCollector.required_facts)
    injector.add_category('distribution', ServiceMgrFactCollector.required_facts)

    # Confirm the constructor of the base class is called
    BaseFactCollector.__init__ = lambda x: None
    ServiceMgrFactCollector()

    # Confirm the instance members of the class are initialized properly
    sm = ServiceMgrFactCollector()
    assert sm.name == 'service_mgr'
    assert sm._fact_ids == set()
    assert sm.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-20 19:56:08.439251
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    mock_module = MockModule()
    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector.is_systemd_managed(mock_module) == False

    mock_module.mock_bin_path = '/usr/bin/systemctl'
    assert service_mgr_collector.is_systemd_managed(mock_module) == True

    mock_module.mock_bin_path = False
    assert service_mgr_collector.is_systemd_managed(mock_module) == False

    mock_module.mock_bin_path = '/usr/bin/systemctl'
    mock_module.mock_os_path_exists = [True, False, False]

# Generated at 2022-06-20 19:56:38.082952
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    collector = Collector()
    assert ServiceMgrFactCollector.is_systemd_managed(collector) == True


# Generated at 2022-06-20 19:56:41.669272
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert not is_systemd_managed_offline(None)
    assert is_systemd_managed_offline(module=AnsibleModule())

# Generated at 2022-06-20 19:56:51.841055
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    print("Running service_mgr test")

    import os
    import platform
    import re

    from ansible.module_utils._text import to_native
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.compat.version import LooseVersion

    # The distutils module is not shipped with SUNWPython on Solaris.
    # It's in the SUNWPython-devel package which also contains development files
    # that don't belong on production boxes.  Since our Solaris code doesn't
    # depend on LooseVersion, do not import it on Solaris.
    if platform.system() != 'SunOS':
        from ansible.module_utils.compat.version import LooseVersion


# Generated at 2022-06-20 19:56:55.027612
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Unit test for constructor of class ServiceMgrFactCollector"""
    ServiceMgrFactCollector()


# Generated at 2022-06-20 19:57:03.789636
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes

    system_init_content = to_bytes('#!/usr/bin/python \n print("Hello World")')
    link_target = os.sep.join(['..'] * 3) + os.sep + 'systemd'
    link_content = to_bytes(link_target)
    broken_link_content = to_bytes('something wrong')

    module = type('module', (object,), {
        'get_bin_path': (lambda path: path)
    })()

    # test case 1: link to systemd
    with tempfile.TemporaryDirectory() as tmpdir:
        init_path = os.path.join(tmpdir, 'init')

# Generated at 2022-06-20 19:57:14.631360
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Unit test requires unittest-mock, so skip this test on platforms that
    # don't support that module.
    try:
        import unittest.mock
    except ImportError:
        return
    module = unittest.mock.Mock()
    platform_system = unittest.mock.Mock()
    os_path_exists = unittest.mock.Mock()
    os_path_islink = unittest.mock.Mock()
    os_readlink = unittest.mock.Mock()

    platform_system.return_value = 'SunOS'
    module.get_bin_path.return_value = None
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

    platform_system.return_value = 'Linux'
   

# Generated at 2022-06-20 19:57:21.025737
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():  # pylint: disable=invalid-name
    import ansible.module_utils.facts.system.service_mgr
    test_module = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    assert ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed(test_module) is False


# Generated at 2022-06-20 19:57:23.423589
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Arrange
    # No preparations needed

    # Act
    ret = ServiceMgrFactCollector().collect()

    # Assert
    assert 'service_mgr' in ret

# Generated at 2022-06-20 19:57:27.736436
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Module mockup
    class ModuleMockup:
        def get_bin_path(self, path):
            return True

    # Testing
    test_object = ServiceMgrFactCollector()

    # Systemd is online (running command)
    test_object.is_systemd_managed(ModuleMockup()) == True

    # Systemd is offline (checking path)
    test_object.is_systemd_managed_offline(ModuleMockup()) == True

# Generated at 2022-06-20 19:57:38.934460
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import os

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    #
    # Prepare the test
    #
    collection_tempdir = tempfile.mkdtemp(prefix='ansible_facter_test_', suffix='_service_mgr_is_systemd_managed')
    os.environ["PATH"] = ':'.join((collection_tempdir, os.environ.get("PATH", "")))
    os.makedirs(os.path.join(collection_tempdir, 'bin'))
    os.makedirs(os.path.join(collection_tempdir, 'run', 'systemd', 'system'))

# Generated at 2022-06-20 19:58:48.202730
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    collector = Collector()
    collector.collect_service_mgr_facts() # pylint: disable=unused-variable
    fact_collector = ServiceMgrFactCollector(collector)

    class FakeModule(object):
        def get_bin_path(self, arg):
            return True

    assert fact_collector.is_systemd_managed(FakeModule()) is True

# Generated at 2022-06-20 19:58:49.590112
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    '''Unit test for method collect of class ServiceMgrFactCollector.'''
    # fix me: implement

    return

# Generated at 2022-06-20 19:58:55.279698
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance

    myfact = get_collector_instance('service_mgr')
    assert myfact.is_systemd_managed == ServiceMgrFactCollector.is_systemd_managed


# Generated at 2022-06-20 19:59:01.389862
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    info = {
        'ansible_distribution': 'OpenWrt',
        'ansible_system': 'Linux'
    }

    module = MockModule()
    service_mgr_fact_collector.collect(module=module, collected_facts=info)

    assert module.exit_args['failed'] is False
    assert info == {
        'ansible_distribution': 'OpenWrt',
        'ansible_system': 'Linux',
        'service_mgr': 'openwrt_init',
    }

    info = {
        'ansible_system': 'Linux'
    }

    module = MockModule()
    service_mgr_fact_collector.is_systemd_managed = lambda x: True
    service_mgr

# Generated at 2022-06-20 19:59:13.134793
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils import basic
    from ansible.module_utils.compat.os import get_exec_path

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.facts = {}
            self.exit_args = {}
            self.exit_args['failed'] = False

        def get_bin_path(self, binary_name):
            return get_exec_path(binary_name, False)


# Generated at 2022-06-20 19:59:19.569294
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Setup test environment
    import sys
    sys.modules['ansible.module_utils.facts.utils'] = __import__('ansible.module_utils.facts.utils')

    # test: AnsibleModule is mocked
    class AnsibleModuleMock:
        def get_bin_path(self, command):
            return 'test_bin_path'

        def run_command(self, args, use_unsafe_shell=False):
            return (0, 'test_stdout', 'test_stderr')

    class ModuleExitException(Exception):
        pass

    class AnsibleModule:
        def __init__(self, argument_spec, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode


# Generated at 2022-06-20 19:59:24.742707
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # ServiceMgrFactCollector inherits object
    collector = ServiceMgrFactCollector()
    # If a class doesn't have a method, it raises AttributeError
    assert hasattr(collector, 'is_systemd_managed_offline') \
        and callable(getattr(collector, 'is_systemd_managed_offline'))

# Generated at 2022-06-20 19:59:35.458231
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_collector

    # create the AnsibleModule object
    module = AnsibleModule(argument_spec={})

    # create the BaseFactCollector using the module object
    base_fact_collector = BaseFactCollector(module=module)

    # create ServiceMgrFactCollector from BaseFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector(base_fact_collector)

    # test if systemd is detected
    ansible_version = ansible_collector.get_ansible_version(module=module)
    ansible_platform = ansible_collector.get_ansible_platform(module=module)

# Generated at 2022-06-20 19:59:38.624839
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # TODO: mock 'module' parameter
    # TODO: test for other distros
    module = None
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False

# Generated at 2022-06-20 19:59:49.274292
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import shutil
    import os
    import os.path

    from ansible.module_utils import basic

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, cmd, required=False, opt_dirs=[]):
            return '/bin/' + cmd

    class CustomServiceMgrFactCollector(ServiceMgrFactCollector):
        name = 'custom_service_mgr'
        required_facts = set()

    mydir = tempfile.mkdtemp()

# Generated at 2022-06-20 20:02:17.576362
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.name == 'service_mgr'
    assert service_mgr.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-20 20:02:24.761294
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector

    class TestModule:
        def get_bin_path(self, a):
            return a
        def run_command(self, a, b=None):
            return (1, 'testout', 'testerr')

    class TestAnsibleModule:
        def __init__(self):
            self.facts = {}
            self.params = {'gather_subset': ['all']}
            self.collector = ansible_collector.get_collector(self.params['gather_subset'], self.facts)
            self.collector.collect(self)

        def get_bin_path(self, a):
            return a

    class TestOS:
        pass


# Generated at 2022-06-20 20:02:33.237960
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class dummy:
        def __init__(self, key, value):
            self.key=key
            self.value=value

        def get_bin_path(self, path):
            if path == 'systemctl' and self.value == 'systemd' \
                    or path == 'systemctl' and self.value == 'systemd_offline':
                # if you are looking for systemctl path, it must be installed
                return '/bin/systemctl'
            elif path == 'systemctl' and self.value == 'not_systemd':
                return None
            elif path == 'initctl' and self.value == 'upstart':
                return '/bin/initctl'
            elif path == 'initctl' and self.value == 'not_upstart':
                return None


# Generated at 2022-06-20 20:02:44.548902
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    ''' Test the subsystem_name method'''
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    import ansible.module_utils.facts.system.service_mgr

    # Mock the init
    def init(self):
        self.bin_path = AnsibleModuleMock.bin_path
        self.run_command = AnsibleModuleMock.run_command

    # Mock class for testing module utils without actually running anything
    class AnsibleModuleMock(object):
        def __init__(self):
            self.exit_json = lambda x: x

        # Mock the bin path method
        @staticmethod
        def get_bin_path(bin_path):
            if bin_path == 'systemctl':
                return '/usr/bin/systemctl'

# Generated at 2022-06-20 20:02:56.846446
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule:

        def __init__(self):
            self.ansible_facts = {}

        def get_bin_path(self, arg):
            pass

        def run_command(self, arg, use_unsafe_shell=False):
            return 0, "", ""

    module = MockModule()

    def is_systemd_managed(arg):
        return False

    def is_systemd_managed_offline(arg):
        return False

    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    ServiceMgrFactCollector.is_systemd_managed = is_systemd_managed
    ServiceMgrFactCollector.is_systemd_managed_offline = is_systemd_managed_offline

    ServiceMgrFactCollector.collect(module)

# Generated at 2022-06-20 20:03:05.715125
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    facts_collector = ServiceMgrFactCollector()
    ansible_facts = {}
    ansible_facts['ansible_distribution'] = 'OpenWrt'
    ansible_facts['ansible_system'] = 'Linux'
    facts_collector.collect(collected_facts=ansible_facts)
    assert ansible_facts['service_mgr'] == 'openwrt_init'
    ansible_facts['ansible_distribution'] = 'MACOSX'
    ansible_facts['ansible_system'] = ''
    facts_collector.collect(collected_facts=ansible_facts)
    assert ansible_facts['service_mgr'] == 'launchd'
    ansible_facts['ansible_distribution'] = 'Linux'

# Generated at 2022-06-20 20:03:15.373376
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockModule()
    module.paths = ('/usr/bin', '/usr/sbin', '/bin', '/sbin')
    mgr = ServiceMgrFactCollector(module=module)
    assert not mgr.is_systemd_managed_offline(module)

    module.paths = ('/usr/bin', '/usr/sbin', '/bin', '/sbin', '/usr/lib/systemd/systemd')
    assert mgr.is_systemd_managed_offline(module)

    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    assert mgr.is_systemd_managed_offline(module)
    os.unlink('/sbin/init')


# Generated at 2022-06-20 20:03:25.354832
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Mock object for module_util method class
    class ModuleMock():
        def __init__(self):
            self.path = "/usr/bin:/bin"

        def get_bin_path(self, executable=None, opt_dirs=None):
            return "/usr/bin/systemctl"

    mod = ModuleMock()
    mod.run_command = ServiceMgrFactCollector.is_systemd_managed

    assert ServiceMgrFactCollector.is_systemd_managed(mod)

    # Mock object for module_util method class
    class ModuleMock():
        def __init__(self):
            self.path = "/usr/bin:/bin"
