

# Generated at 2022-06-20 19:53:38.917847
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    class_object = ServiceMgrFactCollector()
    assert class_object.name == "service_mgr"

# Generated at 2022-06-20 19:53:50.317881
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import Processor
    from ansible.module_utils.facts.collector import collect_subset_facts
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Mock of AnsibleModule
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None

        def run_command(self, cmd, **kwargs):
            return 0, '', ''

        def get_bin_path(self, exe, opt_dirs=[]):
            return "/usr/bin/" + exe

        def set_fact(self, fact_name, value):
            self.params[fact_name] = value

    module = MockAnsibleModule()

# Generated at 2022-06-20 19:53:56.918713
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module_mock = AnsibleModule_mock()
    collected_facts = {}
    service_mgr_collector = ServiceMgrFactCollector(module=module_mock, collected_facts=collected_facts)

    # test collect function
    service_mgr_collector.collect()
    assert service_mgr_collector.get_fact_from_cache('service_mgr') == 'service'

# Generated at 2022-06-20 19:54:01.013946
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts import collect_facts
    facts = collect_facts.setup_collect_subset('all')

    assert 'service_mgr' in facts
    assert facts['service_mgr'] == 'service'

# Generated at 2022-06-20 19:54:03.591363
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert type(x) == ServiceMgrFactCollector
    assert x.platform == 'ServiceMgrFactCollector'

# Generated at 2022-06-20 19:54:10.452971
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr as service_mgr_system
    import mock
    import unittest

    def run_command_mock(command, data, check_rc=False, executable=None,
                         binary_data=False, use_unsafe_shell=False):
        if command == "systemctl list-units --type=service --all --no-legend":
            return (0, 'meh.service', None)
        else:
            return (1, '', None)

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}
            self.fail_json = mock.Mock()
            self.run_command = run_command_mock


# Generated at 2022-06-20 19:54:12.805982
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
   f = ServiceMgrFactCollector()
   assert f.service_mgr == 'service'

# Generated at 2022-06-20 19:54:16.473447
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collectors.service.service_mgr import ServiceMgrFactCollector
    collector = ServiceMgrFactCollector()
    import ansible.module_utils.basic
    return collector.collect(module=ansible.module_utils.basic)

# Generated at 2022-06-20 19:54:18.337372
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-20 19:54:28.033330
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule():
        def __init__(self, facts=None):
            self.exit_json = lambda x: x

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, "COMMAND\n", ""

        def get_bin_path(self, cmd, required=True):
            if cmd in ('systemctl', 'initctl'):
                return '/bin/' + cmd
            return None

    class MockInitModule(MockModule):
        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, cmd, ""

    class MockUpstartModule(MockModule):
        def get_bin_path(self, cmd, required=True):
            if cmd == 'initctl':
                return '/bin/' + cmd
            return None

   

# Generated at 2022-06-20 19:54:49.708819
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ModuleFactsCollector
    fixture_file = "unit/modules/ansible/module_utils/facts/fixtures/service_mgr_facts.json"
    with open(fixture_file) as f:
        fixture_data = f.read()
    deserialized_data = ModuleFactsCollector.deserialize_facts(fixture_data)
    collector = ServiceMgrFactCollector(deserialized_data.get("ansible_facts"))
    result = collector.collect()
    assert result['service_mgr'] == 'systemd'


# Generated at 2022-06-20 19:54:59.233299
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Mock class for module
    class Module:
        def get_bin_path(self, arg):
            return True

    # Mock class for os
    class Os:
        def path(self):
            return "test"

    # Mock class for os.path
    class OSpath:
        def exists(self, canary):
            return True

    m = Module()
    ospath = OSpath()
    os = Os()

    # Mocking the system call for "systemctl"
    m.get_bin_path = Mock(return_value=True)

    # Mocking the system call to "os.path.exists"
    os.path.exists = Mock(side_effect=[True, True, True])

    # Mocking the system call to "os.path.exists"
    os.path.exists

# Generated at 2022-06-20 19:55:05.865693
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class Module(object):

        def get_bin_path(self, *args, **kwargs):
            return '/bin/systemctl'

    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed_offline(Module()) is True

    class Module(object):

        def get_bin_path(self, *args, **kwargs):
            return None

    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed_offline(Module()) is False

# Generated at 2022-06-20 19:55:08.151685
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector._fact_ids == set()
    assert ServiceMgrFactCollector.required_facts == {'platform', 'distribution'}
    assert ServiceMgrFactCollector.collect() == {}

# Generated at 2022-06-20 19:55:09.239315
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector.collect()

# Generated at 2022-06-20 19:55:11.882494
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()
    assert s is not None

# Generated at 2022-06-20 19:55:21.636421
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test = ServiceMgrFactCollector()
    fact_data = {}
    fact_data['ansible_distribution'] = 'OpenWrt'
    result = test.collect({}, fact_data)
    assert result['service_mgr'] == 'openwrt_init', \
        "test_ServiceMgrFactCollector_collect returned wrong result : %s" % result['service_mgr']
    fact_data['ansible_system'] = 'AIX'
    result = test.collect({}, fact_data)
    assert result['service_mgr'] == 'src', \
        "test_ServiceMgrFactCollector_collect returned wrong result : %s" % result['service_mgr']



# Generated at 2022-06-20 19:55:28.482807
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    # For this test we will fake the existence of a file system, by creating
    # a class that mocks the existence of files
    class FakeFileSystem(Mapping):
        def __init__(self, files_dict):
            self._data = files_dict

        def __getitem__(self, key):
            return self._data[key]

        def __len__(self):
            return len(self._data)

        def __iter__(self):
            return iter(self._data)

    #

# Generated at 2022-06-20 19:55:40.656148
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    import os
    import pwd
    import tempfile
    basedir = tempfile.mkdtemp()
    os.rmdir(basedir)
    os.mkdir(basedir)
    os.mkdir(os.path.join(basedir, 'sbin'))
    os.symlink('/bin/systemd', os.path.join(basedir, 'sbin', 'init'))
    os.mkdir(os.path.join(basedir, 'run'))
    os.mkdir(os.path.join(basedir, 'run', 'systemd'))

# Generated at 2022-06-20 19:55:50.563333
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class FakeAnsibleModule:
        def __init__(self, *args, **kwargs):
            self.params = None
        def get_bin_path(self, command):
            return {}.get(command, None)
        def run_command(self, command, use_unsafe_shell=False):
            return {}.get(command, (1, '', 'error'))

    collector = ServiceMgrFactCollector()
    ansible_module = FakeAnsibleModule()

    ansible_module.get_bin_path = lambda x: None
    ansible_module.run_command = lambda x, y: (1, '', '')
    ansible_module.run_command.values = {'/sbin/init': (0, '/usr/lib/systemd/systemd', '')}
    ansible_module

# Generated at 2022-06-20 19:56:26.443048
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Test default constructor
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector is not None
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector._fact_ids == set()
    assert service_mgr_fact_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-20 19:56:38.593262
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.test.loader_fixtures

    class MockModule(object):
        params = {}
        def get_bin_path(self, arg):
            if arg == 'systemctl':
                return '/usr/bin/systemctl'
            else:
                raise Exception('get_bin_path does not know about %s', arg)

    module = MockModule()

    # Don't mock exists, otherwise we get infinite recursion
    is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed
    def exists_mock(arg):
        if arg == '/run/systemd/system/':
            return True
        elif arg == '/dev/.run/systemd/':
            return False
        elif arg == '/dev/.systemd/':
            return False

# Generated at 2022-06-20 19:56:50.123280
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import module_base
    class MockSystemctl(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                return self.path
            else:
                return None

    class MockModule(object):
        def __init__(self, canaries):
            self.systemd_canaries = canaries

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None


# Generated at 2022-06-20 19:56:57.755554
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class TestModule:
        def run_command(self, cmd, use_unsafe_shell=True):
            return (0, 'COMMAND')

    # Case when the class service manager name is None
    test_module = TestModule()
    test_collector = ServiceMgrFactCollector()
    test_collector.collect(module=test_module)
    assert test_collector.collector.get('service_mgr') is None

if __name__ == '__main__':
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-20 19:57:05.436940
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import loader

    class FakeModule(object):
        def __init__(self, *args):
            self.exit_args = {}
            self.exit_args_with_rc = {}
            for arg in args:
                self.exit_args[arg] = False
                self.exit_args_with_rc[arg] = 1

        def fail_json(self, *args, **kwargs):
            self.exit_args.update(kwargs)
            self.exit_args['failed'] = True
            if 'rc' in kwargs:
                self.exit_args_with_rc[kwargs['rc']] = kwargs['rc']
            else:
                self

# Generated at 2022-06-20 19:57:15.381087
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.system.service_mgr

    class ModuleMock(object):
        def which(self, cmd):
            if cmd in ["/sbin/init", "systemctl"]:
                return cmd

    module = ModuleMock()
    # case 1: init is not a symlink
    os.symlink("/bin/true", "/sbin/init")
    # case 2: init is a symlink but not to systemd
    os.symlink("/bin/true", "/sbin/init")
    # case 3: init is a symlink to systemd
    os.symlink("/bin/systemd", "/sbin/init")

    result = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed_

# Generated at 2022-06-20 19:57:18.929156
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # import module here to ensure no circular dependencies on import
    module = AnsibleModule(argument_spec=dict())
    ServiceMgrFactCollector.is_systemd_managed_offline(module=module)

    '''
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == test_results

    def '''



# Generated at 2022-06-20 19:57:20.836364
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    facts = FactCollector(collect_only=['service_mgr'])
    fact_result = facts.get_facts()

    assert fact_result['service_mgr'] == 'systemd'

# Generated at 2022-06-20 19:57:24.529609
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    o = ServiceMgrFactCollector()
    assert o.name == 'service_mgr'
    assert set(o.required_facts) == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:57:34.175289
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, command):
            if command == 'systemctl':
                return '/usr/bin/systemctl'
            else:
                return None

    FactCollector = BaseFactCollector()
    FactCollector._collectors = []

    module = FakeModule()

    result = ServiceMgrFactCollector.is_systemd_managed(module)
    assert result


# Generated at 2022-06-20 19:59:02.294764
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Mock required modules
    import os
    import platform

    # Create instances of the mocked modules
    os_mod = os
    platform_mod = platform

    # Create an instance of the class to be tested
    service_mgr_f_c = ServiceMgrFactCollector()

    # Mock os.path.islink to control what is returned by the method.
    if (os_mod.path.islink.return_value == True):
        assert service_mgr_f_c.is_systemd_managed_offline() == True
    else:
        assert service_mgr_f_c.is_systemd_managed_offline() == False


# Generated at 2022-06-20 19:59:06.018744
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    import mock
    import os
    import sys

    # Add our test directory to sys.path
    test_dir = os.path.join(os.path.dirname(__file__), '..')
    test_dir = os.path.abspath(test_dir)
    mock_mod_list = {'ansible.module_utils.facts': mock.MagicMock(),
                     'ansible.module_utils.facts.collector': mock.MagicMock(),
                     'ansible.module_utils.facts.collector.BaseFactCollector': mock.MagicMock(),
                     'ansible.module_utils.facts.utils': mock.MagicMock(),
                     'ansible.module_utils.facts.utils.get_file_content': mock.MagicMock(),
                     }


# Generated at 2022-06-20 19:59:15.636057
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """ test method is_systemd_managed of class ServiceMgrFactCollector """

    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import DummyModule
    from ansible.module_utils.facts.collector import BashModule

    class MockPath():
        def __init__(self, symlink_to_systemd=True):
            self.symlink_to_systemd = symlink_to_systemd

        def islink(self, dummy_filename):
            if dummy_filename == '/sbin/init':
                return self.symlink_to_systemd
            return False

        def readlink(self, dummy_filename):
            if dummy_filename == '/sbin/init':
                return 'systemd'
            return

# Generated at 2022-06-20 19:59:26.173123
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    '''
    Returns True if the system is managed by systemd
    '''

    class MockModule(object):
        @staticmethod
        def get_bin_path(name, required=False, opt_dirs=[]):
            return '/bin/systemctl'

    service_mgr_fact_collector = ServiceMgrFactCollector
    module = MockModule()
    assert(service_mgr_fact_collector.is_systemd_managed(module) is False)
    open('/run/systemd/system/','w').close()
    assert(service_mgr_fact_collector.is_systemd_managed(module) is True)
    os.remove('/run/systemd/system/')
    open('/dev/.run/systemd/','w').close()

# Generated at 2022-06-20 19:59:36.318014
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def get_bin_path(self, path, opt_dirs=[]):
            if path == "systemctl":
                return path
            else:
                return None

    # Test case 1:
    # Test if path to init exists and is a symlink to systemd, in this case
    # the init system is systemd.
    def test_case_1(test_module):
        class TestOS(object):
            def islink(self, path):
                return True
            def readlink(self, path):
                return "systemd"

        sys.modules['os'] = TestOS
        result

# Generated at 2022-06-20 19:59:44.473268
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import CollectorMeta
    from ansible.module_utils.facts.collector import load_collectors

    my_collector = ServiceMgrFactCollector()
    assert isinstance(my_collector, ServiceMgrFactCollector)
    assert isinstance(my_collector, BaseFactCollector)
    assert issubclass(ServiceMgrFactCollector, CollectorMeta)


# Generated at 2022-06-20 19:59:45.972343
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    facts = ServiceMgrFactCollector().collect()
    assert 'service_mgr' in facts

# Generated at 2022-06-20 19:59:53.204549
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    obj = ServiceMgrFactCollector(module=facts.AnsibleModule())
    assert obj.name == "service_mgr", "name property of the ServiceMgrFactCollector class should be 'service_mgr'"

# Generated at 2022-06-20 20:00:04.674807
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Mock module
    module = MockModule()

    # Create an instance of ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.module = module

    # Set up a mock class for the function is_systemd_managed.
    # Return value can be set here.
    class Mock_is_systemd_managed():
        def __init__(self, return_value):
            self.return_value = return_value

    # Create an instance of Mock_is_systemd_managed
    mock_is_systemd_managed = Mock_is_systemd_managed(return_value=True)
    # Assign the newly created instance to module.is_systemd_managed
    module.is_systemd_managed = mock_is_systemd_

# Generated at 2022-06-20 20:00:12.024069
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr

    x = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector()

    # Test is_systemd_managed method

    # Inject mocked module and invoke is_systemd_managed method
    module = MockModule()
    module.get_bin_path = Mock(return_value="/usr/bin/systemctl")
    os.path.exists = Mock(side_effect=[True])
    x.is_systemd_managed(module=module)
    assert not module.get_bin_path.called
    assert not os.path.exists.called
    module.get_bin_path = Mock(return_value=None)
    x.is_systemd_managed(module=module)
    assert module.get_bin