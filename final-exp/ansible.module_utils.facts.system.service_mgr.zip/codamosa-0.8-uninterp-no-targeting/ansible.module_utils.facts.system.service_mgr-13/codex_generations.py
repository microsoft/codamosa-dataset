

# Generated at 2022-06-20 19:53:46.500065
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import basic
    import sys

    def get_bin_path_mock_func(name):
        return sys.executable

    def run_command_mock_func(cmd, use_unsafe_shell):
        if cmd == 'systemctl list-units --plain --all --full':
            return 0, '', ''
        else:
            raise NotImplementedError('Mock function not implemented for command %s' % cmd)

    smfc = ServiceMgrFactCollector()

# Generated at 2022-06-20 19:53:57.063120
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    with open('/proc/1/cmdline', 'r') as f:
        cmdline = f.read()

    if cmdline != "/sbin/init":
        open('/proc/1/cmdline', 'w').write("/sbin/init")

    # Let's put a canary for systemd
    open('/run/systemd/system/canary', 'w')

    from ansible.module_utils.facts.collectors.system import ServiceMgrFactCollector

    s = ServiceMgrFactCollector()
    assert s.is_systemd_managed() == True

    os.unlink('/run/systemd/system/canary')

# Generated at 2022-06-20 19:54:07.185755
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    import os

    service_mgr_collector = ServiceMgrFactCollector()

    dummy_module_mock = BaseFactCollector()

    # The is_systemd_managed method should return True if the system is managed by systemd

    dummy_module_mock.get_bin_path = classmethod(lambda cls, binary_name: '/bin/systemctl')

    # /run/systemd/system must exist
    os.makedirs('/run/systemd/system')
    assert service_mgr_collector.is_systemd_managed(dummy_module_mock)

# Generated at 2022-06-20 19:54:17.886229
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    import mock
    import os
    import sys

    def os_path_islink(x):
        if x == '/sbin/init':
            return True
        else:
            return False

    if sys.version_info[0] == 3:
        from functools import reduce

    class MockedModule:

        def __init__(self):
            pass

        def get_bin_path(self, cmd, required=False):
            if cmd == 'systemctl':
                return '/sbin/systemctl'
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=True):
            if cmd == 'systemctl list-unit-files --type=service --full --no-legend':
                return 0, '', ''
            else:
                raise Exception


# Generated at 2022-06-20 19:54:19.971821
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.name == 'service_mgr'

# Generated at 2022-06-20 19:54:24.836616
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a dummy module
    module = AnsibleModule(argument_spec={})

    # Create a dummy collector
    collector = ServiceMgrFactCollector()

    # Call the collect method
    result = collector.collect(module=module)

    # Test that the result is a dict
    assert(isinstance(result, dict))

# Generated at 2022-06-20 19:54:33.951440
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.service_mgr.service_mgr import ServiceMgrFactCollector

    class ModuleMock(object):
        def get_bin_path(self, executable):
            return executable

    module = ModuleMock()

    # Prepare test
    os.symlink("systemd", "/sbin/init-symlink")
    os.symlink("/tmp/does-not-exist", "/sbin/init-broken-symlink")
    os.symlink("/bin/systemctl", "/sbin/init-systemctl-symlink")

    # Test
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) is False
    os.sy

# Generated at 2022-06-20 19:54:44.789604
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = AnsibleModule(argument_spec={})
    setattr(module, 'run_command', lambda x, check_rc=True, close_fds=True, executable=None, use_unsafe_shell=False, data=None: (0, '', ''))

    # check expected output when systemd_service is true
    setattr(module, 'get_bin_path', lambda x: True)
    setattr(os, 'path', type('', (), dict(exists=lambda x: True)))
    assert ServiceMgrFactCollector.is_systemd_managed(module) is True

    # check expected output when systemd_service is false
    setattr(module, 'get_bin_path', lambda x: False)
    assert ServiceMgrFactCollector.is_systemd_managed(module) is False

# Generated at 2022-06-20 19:54:56.420012
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 19:55:05.265232
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # Create mock module
    class MockModule:
        def get_bin_path(self, cmd):
            return '/bin/' + cmd

    mock_module = MockModule()

    # Create mock os.path
    class MockOS_Path(object):
        def __init__(self, *args, **kwargs):
            pass

        def islink(self, path):
            if path == "/sbin/init":
                return True
            return False

        def readlink(self, path):
            return "systemd"

        def exists(self, path):
            return True

    # Create mock os
    class MockOS(object):
        def __init__(self, *args, **kwargs):
            pass

        def pathexists(self, path):
            if path == "/run/systemd/system/":
                return

# Generated at 2022-06-20 19:55:26.340980
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class StubModule(object):
        def __init__(self, service_mgr_name='systemd', is_systemd_managed_offline_rc=True):
            self.service_mgr_name = service_mgr_name
            self.is_systemd_managed_offline_rc = is_systemd_managed_offline_rc

        def get_bin_path(self, cmd):
            return cmd if cmd == 'systemctl' else None

    class StubCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-20 19:55:28.292220
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x
    assert isinstance(x, BaseFactCollector)

# Generated at 2022-06-20 19:55:40.395663
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # A case where systemctl is present but systemd is not the boot init system
    # simulates that systemd has been installed manually but it's not the
    # boot init system.
    m_open = MagicMock(return_value=True)
    m_isdir = MagicMock(return_value=False)
    with patch.multiple(os.path, isdir=m_isdir):
        assert ServiceMgrFactCollector.is_systemd_managed(m_open)
    # A case where systemctl is not present.
    m_open = MagicMock(return_value=False)
    m_isdir = MagicMock(return_value=False)
    with patch.multiple(os.path, isdir=m_isdir):
        assert not ServiceMgrFactCollector.is_systemd_managed(m_open)

# Generated at 2022-06-20 19:55:42.221437
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    a = ServiceMgrFactCollector()
    assert isinstance(a, ServiceMgrFactCollector)

# Generated at 2022-06-20 19:55:49.526006
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import tempfile
    import shutil
    import os
    import mock

    def mock_get_file_content(path):
        return "mock"
    cache_dir = tempfile.mkdtemp()
    with mock.patch("ansible.module_utils.facts.collector.BaseFactCollector.get_file_content", mock_get_file_content):
        ServiceMgrFactCollector.cache_dir = cache_dir
        ServiceMgrFactCollector.collect()
    shutil.rmtree(cache_dir)
    os.unlink("get_file_content")

# Generated at 2022-06-20 19:55:58.165447
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import DummyModule
    import ansible.module_utils.facts.collectors.service_mgr
    smfc = ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector()
    module = DummyModule()
    module.get_bin_path = lambda x: '/bin/'+x
    assert smfc.is_systemd_managed(module) != smfc.is_systemd_managed_offline(module)

# Generated at 2022-06-20 19:56:05.521842
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module_args = dict()
    module_args['bin_env'] = dict()

    class MockModule:
        def __init__(self):
            pass

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    fake_module = MockModule()
    fake_module.run_command = Mock(return_value=(0, "/bin/systemctl", ""))

    mfc = ServiceMgrFactCollector()
    assert mfc.is_systemd_managed(fake_module)



# Generated at 2022-06-20 19:56:15.496621
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    m = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    m.get_bin_path = lambda *args: '/sbin/systemctl'
    m.run_command = lambda *args: (0, '', '')

    fc = collector.get_collector('service_mgr')

    assert fc.is_systemd_managed_offline(m) == False

    m.run_command = lambda *args: (0, '/sbin/init', '')
    assert fc.is_systemd_managed_offline(m) == False

    m.run_command = lambda *args: (0, '/sbin/init', '')
   

# Generated at 2022-06-20 19:56:16.864357
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()

# Generated at 2022-06-20 19:56:26.587570
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # create dummy module
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # the following use a custom init, instead of the system's
    # this does not provide /run, /dev/.run, but test are run on a systemd machine
    for canary, systemctl_path in (
        ("/run/systemd/system/", "/bin/systemctl"),
        ("/dev/.run/systemd/", "/bin/systemctl"),
        ("/dev/.systemd/", "/bin/systemctl"),
    ):
        assert ServiceMgrFactCollector.is_systemd_managed(module=module) == False
        module.run_command = create_command_mock(systemctl_path, os.path.exists, canary)
        assert ServiceMgrFactCollector.is_systemd_

# Generated at 2022-06-20 19:57:00.721581
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    coll = ServiceMgrFactCollector()

    class Module:
        def get_bin_path(self, cmd):
            return '/bin/' + cmd
    module = Module()

    # Systemd is managed
    if os.path.exists('/etc/systemd/system'):
        assert coll.is_systemd_managed(module) is True
    elif os.path.exists('/dev/.run/systemd'):
        assert coll.is_systemd_managed(module) is True
    elif os.path.exists('/dev/.systemd'):
        assert coll.is_systemd_managed(module) is True
    # Systemd is not managed
    else:
        assert coll.is_systemd_managed(module) is False


# Generated at 2022-06-20 19:57:12.550225
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """Validate the collect method of the ServiceMgrFactCollector"""

    # Make sure all required modules and system commands exist
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    if not module.get_bin_path('comm'):
        module.fail_json(msg="'comm' command not found in PATH.  Unable to collect service_mgr fact.")

    # Initialize a ServiceMgrFactCollector with module
    fact_collector = ServiceMgrFactCollector(module = module)

    # Test collect on a supported service manager
    msg = "'comm' command exists in PATH.  " + \
          "Unable to collect service_mgr fact."
    assert_equal(fact_collector.collect()['service_mgr'], 'service')


# Generated at 2022-06-20 19:57:19.999314
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    def fake_os_path_exists(path):
        fake_paths = {
            '/sbin/init': False,
            '/proc/1/comm': False,
            '/etc/init.d/': False,
            '/etc/init/': False,
            '/dev/.systemd/': False,
            '/dev/.run/systemd/': False,
            '/run/systemd/system/': False,
            '/dev/.run/openrc/': False,
            '/sbin/openrc': False,
            '/usr/lib/systemd/systemd':'/usr/bin/systemd'
        }

# Generated at 2022-06-20 19:57:23.207250
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x is not None
    assert x.name == 'service_mgr'

# Unit tests for detection and naming of service management tools

# Generated at 2022-06-20 19:57:29.191462
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """ Unit test for method is_systemd_managed of class ServiceMgrFactCollector """
    mock_module = {
        'run_command': lambda x: None,
        'get_bin_path': lambda x: None,
        'exit_json': lambda x: None,
        'fail_json': lambda x: None,
    }
    result = ServiceMgrFactCollector.is_systemd_managed(mock_module)
    assert not result


# Generated at 2022-06-20 19:57:39.555383
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.utils.module_docs as module_docs
    mod_null = module_docs.AnsibleModule(argument_spec={}, supports_check_mode=True)
    mod_not_systemd = module_docs.AnsibleModule(argument_spec={}, supports_check_mode=True)

    facts_dict = {'platform': 'Linux', 'ansible_distribution' : 'Ubuntu', 'ansible_system': 'Linux'}

    # Expected results:
    # is_systemd_managed on no system should return False
    # is_systemd_managed on a system with systemd installed but not running, should return False
    # is_systemd_managed on a system with systemd installed, running, and not in a container, should return True
    # is_systemd_managed on a system with systemd installed, running, and in

# Generated at 2022-06-20 19:57:43.783262
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc.name == 'service_mgr'
    assert smfc._fact_ids == set()
    assert smfc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:57:55.365351
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    class TestModule:
        def get_bin_path(self, *args, **kwargs):
            return '/bin/systemctl'
    test_module = TestModule()
    assert ServiceMgrFactCollector.is_systemd_managed(test_module) == False
    class TestModule:
        def get_bin_path(self, *args, **kwargs):
            return '/bin/systemctl'
    test_module = TestModule()
    assert ServiceMgrFactCollector.is_systemd_managed(test_module) == False
    import os
    import shutil
    class TestModule:
        def get_bin_path(self, *args, **kwargs):
            return '/bin/systemctl'
    test

# Generated at 2022-06-20 19:58:00.196844
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fc = ServiceMgrFactCollector()
    assert service_mgr_fc.name == 'service_mgr'
    assert service_mgr_fc.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-20 19:58:02.947436
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Test ServiceMgrFactCollector class"""
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'

# Generated at 2022-06-20 19:59:02.286215
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    class MockModule(object):
        # This makes sure, that we have an object, that supports the
        # get_bin_path method.
        def get_bin_path(self, name, required=True):
            return None

    smfc = ServiceMgrFactCollector()
    assert smfc.is_systemd_managed_offline(MockModule()) is False

# Generated at 2022-06-20 19:59:05.141246
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # TODO: Fix this test
    pass

# vim: set sts=4 ts=8 sw=4 et ft=python :

# Generated at 2022-06-20 19:59:09.155960
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    """ Unit test for constructor of class ServiceMgrFactCollector """

    assert ServiceMgrFactCollector.__name__ == 'ServiceMgrFactCollector'

# Generated at 2022-06-20 19:59:10.130588
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    pass


# Generated at 2022-06-20 19:59:19.382588
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    '''True if systemctl command is present and is a link to systemd, False otherwise'''
    ServiceMgr = ServiceMgrFactCollector()
    class MockModule:
        def get_bin_path(self, arg):
            if arg == 'systemctl':
                return '/usr/bin/systemctl'
    def MockIsLink(arg):
        if arg == '/sbin/init':
            return True
        return False
    def MockReadLink(arg):
        if arg == '/sbin/init':
            return 'systemd'

    module = MockModule()
    ServiceMgr.is_systemd_managed = Mock(return_value=True)
    ServiceMgr.is_systemd_managed(module)
    ServiceMgr.is_systemd_managed.assert_called_once_with(module)

    os.path

# Generated at 2022-06-20 19:59:28.195412
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import platform
    import re
    import shutil
    import tempfile

    class MockModule(object):
        def __init__(self):
            self.run_command = MockModule.run_command
            self.get_bin_path = MockModule.get_bin_path

        @staticmethod
        def run_command(command, use_unsafe_shell=False):
            if command == 'ps -p 1 -o comm|tail -n 1':
                return 123, 'systemd', None

            return 0, '', None

        @staticmethod
        def get_bin_path(name):
            # there is no command for the `systemctl` utility
            if name == 'systemctl':
                return None

            # return systemctl command
            return '/bin/systemctl'



# Generated at 2022-06-20 19:59:37.909510
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class Module:
        def get_bin_path(self, bin_name):
            if bin_name == 'systemctl':
                return '/bin/systemctl'
            return None

    smf = ServiceMgrFactCollector()
    module = Module()

    # test_is_systemd_managed - return False, /sbin/init not present
    assert(smf.is_systemd_managed_offline(module) == False)

    # test_is_systemd_managed_offline - return True
    os.symlink('/bin/systemd', '/sbin/init')
    assert(smf.is_systemd_managed_offline(module) == True)
    os.unlink('/sbin/init')

    # test_is_systemd_managed_offline - return False, service mgr is

# Generated at 2022-06-20 19:59:43.859932
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class FakeModule(object):
        def get_bin_path(self, name):
            return "/bin/{}".format(name)

    smfc = ServiceMgrFactCollector(None)
    module = FakeModule()
    assert smfc.is_systemd_managed_offline(module) == False

# Generated at 2022-06-20 19:59:47.588536
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class mock_module(object):
        def __init__(self, **kwargs):
            for attribute, value in kwargs.items():
                setattr(self, attribute, value)

        def get_bin_path(self, executable):
            return None

    module = mock_module(ansible_system='Linux',
                         ansible_distribution='RedHat',
                         ansible_distribution_version=7.6)

    # with collect_subset=['!all', 'network'], only required facts will be collected
    # here, only ansible_system and ansible_distribution facts are available.
    # as a result, the service_mgr fact could not be collected.
    fact_collector = ServiceMgrFactCollector

# Generated at 2022-06-20 19:59:53.553609
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    import ansible.module_utils.facts.service_mgr

    module_class_name = 'ansible.module_utils.facts.service_mgr.ServiceMgrFactCollector'
    class_ = getattr(ansible.module_utils.facts.service_mgr, module_class_name)
    collector_instance = class_()
    assert collector_instance.is_systemd_managed_offline('test') is False

# Generated at 2022-06-20 20:02:23.519540
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import collections
    import json

    class MockModule(object):
        def __init__(self, rc, output, err=None):
            self.rc = rc
            self.output = output
            self.err = err

        def get_bin_path(self, path):
            return '/usr/bin/%s' % path

        def run_command(self, cmd, use_unsafe_shell=True):
            return (self.rc, self.output, self.err)

    # Testing collect()
    # Collected facts will be a dictionary like below
    collected_facts = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': 'Darwin',
    }

    # Testing collect() with distribution as MacOSX
    # Expected fact data is as below

# Generated at 2022-06-20 20:02:33.655130
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    collector = ServiceMgrFactCollector()
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {
                'sysvinit': 'sudo /sbin/service rsyslog restart',
                'openrc': 'sudo /sbin/rc-service rsyslog restart',
                'systemd': 'sudo /bin/systemctl restart rsyslog',
                'upstart': 'sudo /sbin/initctl restart rsyslog',
                'default': ['/bin/systemctl restart rsyslog', '/sbin/service rsyslog restart']
            }

        def get_bin_path(self, command, required=False, opt_dirs=[]):
            if command == 'initctl':
                return '/sbin/initctl'

# Generated at 2022-06-20 20:02:44.714040
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import shutil
    from ansible.module_utils.facts.collector import get_collector_instance

    # Creation of the 2 temporary files
    tempdir = tempfile.mkdtemp()
    with open(os.path.join(tempdir, "systemctl"), "w+") as systemctl_file:
        with open(os.path.join(tempdir, "systemctl.py"), "w+") as systemctl_py_file:
            # Definition of the module and of the instance of class ServiceMgrFactCollector
            module = type('module')()
            module.run_command = lambda *args, **kwargs: (0, "", "")
            service_mgr_fact_collector = get_collector_instance(module, 'ServiceMgrFactCollector')

            # The following tests check the

# Generated at 2022-06-20 20:02:49.383010
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'
    assert obj.required_facts == {'distribution', 'platform'}

# Generated at 2022-06-20 20:02:58.484565
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """
    This test case checks the correctness of returned value for different cases.
    """
    import ansible.module_utils.facts.system.service_mgr_fact_collector as service_mgr_fact_collector

    def is_systemd_managed_for(expected_return_value, expected_side_effects):
        def mock_module(**kwargs):
            class MockModule(object):
                def __init__(self, **kwargs):
                    self.params = kwargs

                def get_bin_path(self, program, **kwargs):
                    return kwargs.get('required', False)

                def run_command(self, cmd, **kwargs):
                    return True
            return MockModule(**kwargs)


# Generated at 2022-06-20 20:03:06.582349
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile

    # Test with /sbin/init being a symlink to systemd
    tempdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tempdir, 'sbin'))
    os.symlink('/bin/systemd', os.path.join(tempdir, 'sbin/init'))

# Generated at 2022-06-20 20:03:13.620315
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.facts import Facts

    facts = Facts(collect_default=False, gather_subset=['service_mgr'])
    collector = Collector()
    facts.collect(collector)
    assert collector.execute(None, facts.get_facts())['service_mgr'] == 'service'



# Generated at 2022-06-20 20:03:24.523664
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible_collections.ansible.community.plugins.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible_collections.ansible.community.plugins.module_utils.facts.system.platform import PlatformFactCollector

    # TODO: add more tests with less systemd-y distros (centos 7, etc)
    # TODO: move this test code into a proper unit test instead of relying on the legacy collection sync pattern
