

# Generated at 2022-06-20 19:53:35.589298
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()

    assert smfc.name == 'service_mgr'
    assert smfc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:53:43.330560
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """
    Unit test mocking module and executing is_systemd_managed(module)
    """
    class TestModule():
        @staticmethod
        def get_bin_path(name, opt_dirs=[]):
            if name == "systemctl":
                return "/usr/bin/%s" % name
            else:
                return None


    assert ServiceMgrFactCollector.is_systemd_managed(TestModule()) == False


# Generated at 2022-06-20 19:53:51.560185
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import ModuleUtils
    smfc = ServiceMgrFactCollector()
    if ServiceMgrFactCollector.is_systemd_managed_offline(ModuleUtils):
        assert (os.path.basename(os.readlink('/sbin/init')) == 'systemd')
    else:
        assert (os.path.basename(os.readlink('/sbin/init')) != 'systemd')

# Generated at 2022-06-20 19:54:03.319167
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule():
        def __init__(self):
            self.run_command_response = (0, "init", "")
            self.run_command_response_unknown_init = (0, "unknown_init", "")
            self.get_bin_path_systemctl = "/usr/bin/systemctl"
            self.get_bin_path_systemctl_not_exist = None
            self.run_command_response_unknown = (1, "unknown", "")
        def get_bin_path(self, path):
            if path == "systemctl":
                return self.get_bin_path_systemctl
            return self.get_bin_path_systemctl_not_exist

# Generated at 2022-06-20 19:54:09.128132
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    mgr = ServiceMgrFactCollector()
    assert mgr.name == "service_mgr"
    assert mgr.required_facts == set(['platform', 'distribution'])

    # we can't directly compare the "collect" results because the "is_systemd_managed" method may
    # return different values based on the current system, but verify in the results exist
    result = mgr.collect()
    assert 'service_mgr' in result
    assert result['service_mgr'] is not None

# Generated at 2022-06-20 19:54:12.309367
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = None
    test_class = ServiceMgrFactCollector()
    assert test_class.is_systemd_managed_offline(module) == False

# Generated at 2022-06-20 19:54:17.885751
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import DummyModule

    dummy_module = DummyModule()

    collector = ServiceMgrFactCollector()

    # Check if system is Systemd managed
    if collector.is_systemd_managed(dummy_module) is True:
        assert(dummy_module.run_command.call_count == 3)
    else:
        assert(dummy_module.run_command.call_count == 0)


# Generated at 2022-06-20 19:54:20.413667
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector


if __name__ == '__main__':
    test_ServiceMgrFactCollector()

# Generated at 2022-06-20 19:54:24.839801
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    svc_mgr = ServiceMgrFactCollector.collect()
    assert svc_mgr['service_mgr'] in ['sysvinit', 'service', 'upstart', 'openrc', 'launchd', 'bsdinit', 'systemd']

# Generated at 2022-06-20 19:54:25.805826
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()

# Generated at 2022-06-20 19:54:45.914023
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    collected_facts = {}
    collected_facts["ansible_system"] = "Linux"
    collected_facts["ansible_distribution"] = "CentOS"

    distro_collector = DistributionFactCollector()
    service_mgr_collector = ServiceMgrFactCollector()

    facts = {}
    facts['ansible_facts'] = {}

    service_mgr_fact = {'service_mgr': 'sysvinit'}


# Generated at 2022-06-20 19:54:50.683128
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # define the module
    module = type('module', (), {})()
    module.get_bin_path = lambda x: '/bin/systemctl'
    module.run_command = lambda x, u: (0, '', '')

    # define the collector
    ServiceMgrFactCollector.is_systemd_managed = staticmethod(ServiceMgrFactCollector.is_systemd_managed)
    c = ServiceMgrFactCollector()

    # test for True
    for canary in ["/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"]:
        open(canary, 'w').close()
        result = c.is_systemd_managed(module=module)
        os.remove(canary)
        assert result is True

    # test for False

# Generated at 2022-06-20 19:54:59.565905
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Used in module mocks
    from ansible.module_utils.facts.collector import BaseFactCollector
    import base64
    BaseFactCollector._collectors = {}
    BaseFactCollector._cache = {}

    # Set up a mock module object with basic params
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = (lambda x: (0, '', ''))
            self.debug = (lambda x: None)
            self.fail_json = (lambda x: None)
            self.get_bin_path = lambda x: x
            self.log = (lambda x: None)

# Generated at 2022-06-20 19:55:07.287403
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    fact_collector = ServiceMgrFactCollector()

    # SUSE 11
    os.symlink("../bin/systemd", "/sbin/init")
    assert fact_collector.is_systemd_managed_offline(collector.get_file_module())

    # SUSE 12
    os.symlink("systemd","/sbin/init")
    assert fact_collector.is_systemd_managed_offline(collector.get_file_module())

    # CentOS 6.7
    os.symlink("/usr/lib/systemd/systemd", "/sbin/init")
    assert fact_collector.is_systemd

# Generated at 2022-06-20 19:55:14.064985
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    f = ServiceMgrFactCollector()

    class ModuleMock():
        def get_bin_path(name):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    # ld.so.conf.d/00-systemd.conf exists
    class osModuleMock():
        @staticmethod
        def path():
            class pathModuleMock():
                @staticmethod
                def islink(path):
                    if path == '/sbin/init':
                        return True
                    else:
                        return False
                @staticmethod
                def readlink(path):
                    if path == '/sbin/init':
                        return 'systemd'
                    else:
                        return None
            return pathModuleMock()


# Generated at 2022-06-20 19:55:21.896852
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector = ServiceMgrFactCollector()
    ServiceMgrFactCollector.is_systemd_managed = lambda x: False
    ServiceMgrFactCollector.is_systemd_managed_offline = lambda x: False
    ansible_module = MockAnsibleModule()
    ansible_module.run_command = lambda x, y: (0, '', '')
    results = ServiceMgrFactCollector.collect(module=ansible_module)
    assert results['service_mgr'] == 'service'



# Generated at 2022-06-20 19:55:23.339360
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    svc = ServiceMgrFactCollector()
    assert isinstance(svc, ServiceMgrFactCollector)
    assert svc.name == 'service_mgr'
    assert svc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:55:32.460586
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = type('module', (), dict(get_bin_path=lambda self, executable: executable))()
    service_mgr_facts = ServiceMgrFactCollector()
    managed_systemd = service_mgr_facts.is_systemd_managed_offline(module=module)
    managed_systemd_expected = False
    assert managed_systemd == managed_systemd_expected, "Expected is_systemd_managed_offline() to return '{0}' but it returned '{1}'".format(managed_systemd_expected, managed_systemd)

# Generated at 2022-06-20 19:55:44.384288
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        class FakeOs(object):
            def readlink(self, path):
                if path == '/sbin/init':
                    return b'systemd'
            islink = lambda x, path: path == '/sbin/init'
        class FakePath(object):
            exists = lambda x, path: path == b'/etc/os-release'
        class FakeGetBinPath(object):
            def __call__(self, exe):
                if exe == 'systemctl':
                    return '/usr/bin/systemctl'
                else:
                    return None
        os = FakeOs()
        path = FakePath()
        get_bin_path = FakeGetBinPath()

    collector = ServiceMgrFactCollector()

    # test

# Generated at 2022-06-20 19:55:52.449866
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class FakeModule():
        def __init__(self, module_arg_spec, module_name=None):
            self.run_command = lambda cmd, use_unsafe_shell=False: 0, 'cmd', 'err'
            self.get_bin_path = lambda a: '/bin/' + a if a == 'systemctl' else None
            self.params = {}
            self.check_mode = False
            self.exit_json = lambda a: False
            self.fail_json = lambda a: False
            self.warn = lambda a: False

    test_collector = ServiceMgrFactCollector()
    result = test_collector.collect(FakeModule({}))

    assert result['service_mgr'] == 'systemd', 'was not able to detect systemd'



# Generated at 2022-06-20 19:56:25.296360
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class TestModule(object):
        def get_bin_path(self, bin_name):
            if bin_name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    # test if systemd is detected when the init is a symlink to systemd
    result = ServiceMgrFactCollector.is_systemd_managed_offline(TestModule())
    assert result == True

    # test if systemd is not detected when the init is not a symlink to systemd
    class TestModule(object):
        def get_bin_path(self, bin_name):
            if bin_name == 'systemctl':
                return '/bin/notthesystemctl'
            else:
                return None

    result = ServiceMgrFactCollector.is_systemd_managed_offline(TestModule())

# Generated at 2022-06-20 19:56:33.485950
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.service_mgr

    class TestModule(object):
        def get_bin_path(self, x):
            return "/bin/systemctl"

    module = TestModule()
    s = ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector()

    assert s.is_systemd_managed_offline(module) == False


# Generated at 2022-06-20 19:56:41.234054
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    from ansible.module_utils.facts import Collector
    import ansible.module_utils.facts.collectors.service_mgr as SM
    import ansible.module_utils.facts.collectors.system as System

    '''
    Test ServiceMgrFactCollector
    '''

    SM.get_file_content = lambda x: 'runit-init' if x == '/proc/1/comm' else None

    # instantiate ServiceMgrFactCollector object
    SM.platform = 'Linux'
    SM.Collector = Collector
    S = SM.ServiceMgrFactCollector()

    assert S.name == 'service_mgr'
    assert S._fact_ids == set()

    assert S.required_facts == set(['platform', 'distribution'])

    # test is_systemd_managed()

# Generated at 2022-06-20 19:56:50.819070
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """
    Test the ``is_systemd_managed`` method of ``ServiceMgrFactCollector`` of the fact collection
    module, as invoked by ``ansible-doc -t collection -M .``.
    """

    from importlib import import_module
    from ansible.module_utils.facts.collector import DictModule

    result = """
    ansible_system: Linux
    ansible_service_mgr: systemd
    """
    dummy_module = DictModule()
    dummy_module.params['gather_subset'] = ['service_mgr']
    collector = ServiceMgrFactCollector(module=dummy_module)

    assert collector.is_systemd_managed(dummy_module) is True



# Generated at 2022-06-20 19:56:51.339065
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    pass

# Generated at 2022-06-20 19:56:56.835364
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.local_ansible_utils_extension import get_bin_path

    class ModuleStub():
        def run_command(self, cmd, use_unsafe_shell=True):
            return (0, '', '')
        def get_bin_path(self, module):
            return '/usr/bin/systemctl'


# Generated at 2022-06-20 19:57:00.293650
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Test ServiceMgrFactCollector constructor"""
    assert(ServiceMgrFactCollector.name == 'service_mgr')
    assert(ServiceMgrFactCollector.required_facts == set(['platform', 'distribution']))
    assert(ServiceMgrFactCollector.collect()) == {}

# Generated at 2022-06-20 19:57:02.709684
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    fact_info = ServiceMgrFactCollector.is_systemd_managed_offline(None)
    assert fact_info is False

# Generated at 2022-06-20 19:57:13.991823
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    try:
        from ansible.module_utils.facts.collector import BaseFactCollector
    except ImportError:
        # prior to 2.4 BaseFactCollector was in ansible.module_utils.facts.collector
        from ansible.module_utils.facts.collector import BaseFactCollector

    # create dummy module
    class DummyModule:
        def __init__(self, *args, **kwargs):
            self.params = type('Params', (), {})()
            self.params.update(kwargs)

        def run_command(self, *args, **kwargs):
            return 0, 'systemd', ''

        def get_bin_path(self, *args, **kwargs):
            return '/bin/systemctl'

    def os_path_exists(*args, **kwargs):
        return

# Generated at 2022-06-20 19:57:17.004953
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.name == 'service_mgr'
    assert service_mgr.required_facts == set(['platform', 'distribution'])
    assert service_mgr._fact_ids == set()


# Generated at 2022-06-20 19:58:12.207102
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert isinstance(ServiceMgrFactCollector, object)


# Generated at 2022-06-20 19:58:13.267637
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # test with invalid module
    ServiceMgrFactCollector(None)

# Generated at 2022-06-20 19:58:16.143858
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module_mock = Mock()
    module_mock.get_bin_path = Mock(return_value=True)
    collector = ServiceMgrFactCollector()
    collector.is_systemd_managed_offline(module_mock)
    return True


# Generated at 2022-06-20 19:58:25.269609
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # pylint: disable=invalid-name
    from mock import Mock, patch

    module = Mock()
    module.get_bin_path.return_value = True
    module.run_command.return_value = (0, '', '')

    # simulate symlink /sbin/init -> systemd
    with patch('os.path.islink') as path_islink:
        path_islink.return_value = True

        with patch('os.readlink') as readlink:
            readlink.return_value = '/systemd'
            result = ServiceMgrFactCollector.is_systemd_managed_offline(module)

    assert result == True


# Generated at 2022-06-20 19:58:35.482842
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    opts = {
        'module_name': 'dummy',
        'module_args': {},
        'module_vars': {},
    }

    # create a dummy module
    class DummyModule():
        def __init__(self, opts):
            self.params = opts['module_args']
            self.args = {}
            self.basedir = os.path.dirname(os.path.realpath(__file__))
            self.tmpdir = os.path.join(self.basedir, 'tmp')
        def get_bin_path(self, arg, required=True, opt_dirs=[]):
            return '/sbin/systemctl'



# Generated at 2022-06-20 19:58:42.830555
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class TestModule:
        def get_bin_path(self, command):
            return '/bin/systemctl'

    collector = ServiceMgrFactCollector()
    assert not collector.is_systemd_managed_offline(TestModule())

    os.symlink('/bin/systemd', '/sbin/init')
    assert collector.is_systemd_managed_offline(TestModule())

    return True

# Generated at 2022-06-20 19:58:51.316880
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_platforms = ['MacOSX', 'SunOS', 'AIX', 'Linux']
    test_distributions = ['OpenWrt']
    test_systems = ['BSD', 'OpenBSD', 'FreeBSD', 'NetBSD', 'DragonFly', 'Bitrig']
    test_run_command_values = {'systemd': 'systemd', 'systemd --version': 'systemd', 'syswelld': ''}
    test_get_file_content_values = {'/proc/1/comm': 'systemd', '/proc/2/comm': 'init', '/proc/3/comm': 'syswelld'}

    from ansible.module_utils.facts.collector import ContentException
    from ansible.module_utils.facts.collector import NoSuchFileException

# Generated at 2022-06-20 19:59:04.355082
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.exit_json = params.get('exit_json')
            self.fail_json = params.get('fail_json')

        def run_command(self, command, use_unsafe_shell=True):
            return 0, '', ''
        def get_bin_path(self):
            return 'systemctl'

    class FakeFailedModule(object):
        def __init__(self, params):
            self.params = params
            self.exit_json = params.get('exit_json')
            self.fail_json = params.get('fail_json')


# Generated at 2022-06-20 19:59:14.921148
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Create a FakeModule object
    class FakeModule(object):
        def __init__(self, param_comm_systemctl, param_comm_systemd, param_comm_initctl):
            self.params = dict()
            self.params['commands'] = dict()
            self.params['commands']['systemctl'] = param_comm_systemctl
            self.params['commands']['systemd'] = param_comm_systemd
            self.params['commands']['initctl'] = param_comm_initctl
        def get_bin_path(self, arg):
            return self.params['commands'][arg]

    # Default, returns 'service'
    service_mgr_facts = ServiceMgrFactCollector
    service_mgr_facts.is_systemd_managed = lambda _: False


# Generated at 2022-06-20 19:59:16.792322
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    srv_mgr_fact = ServiceMgrFactCollector()
    assert srv_mgr_fact is not None

# Generated at 2022-06-20 20:00:37.259167
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    for fixture in ('systemd', 'upstart', 'sysvinit', 'openrc'):
        module = get_fixture_class(fixture)("/bin/false")
        collector = Collector(module=module, facts={'platform': 'Linux'})
        facts_dict = ServiceMgrFactCollector(module, collector).collect()
        assert facts_dict.get('service_mgr') == fixture

# Generated at 2022-06-20 20:00:47.886531
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """
    Check if the method ServiceMgrFactCollector._is_systemd_managed detects correctly a systemd managed system.
    This is a very simple test case but gives us a start.
    :return:
    """
    class MockModule(object):
        def get_bin_path(self, path):
            return '/usr/bin/systemctl'

    smfc = ServiceMgrFactCollector()

    # Test False
    assert smfc.is_systemd_managed(MockModule()) is False

    # Test True
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    os.symlink('/usr/bin/systemctl', tmp_dir + '/run/systemd/system/')
    assert smfc.is_systemd_managed(MockModule()) is True

# Generated at 2022-06-20 20:00:53.795298
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MagicMock()
    module.get_bin_path.return_value = '/bin/systemctl'
    service_mgr = ServiceMgrFactCollector()

    # check that it returns False if /sbin/init is not a link to systemd
    os.symlink = MagicMock(side_effect=OSError("[Errno 2] No such file or directory:"))
    assert service_mgr.is_systemd_managed_offline(module) is False

    # check that it returns True if /sbin/init is a link to systemd
    os.symlink = MagicMock(return_value=True)
    os.readlink = MagicMock(return_value='systemd')
    assert service_mgr.is_systemd_managed_offline(module) is True

    os.symlink

# Generated at 2022-06-20 20:01:04.766496
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class Platform(object):
        system = 'Linux'
        dist = ('', '', '')

    class Distribution(object):
        name = 'BSD'

    class Module(object):
        # Return path to executable if found.
        # Return None if executable not found.
        def get_bin_path(self, executable):
            if executable == 'initctl':
                return '/bin/initctl'
            elif executable == 'systemctl':
                return '/bin/systemctl'

    facts_dict = {
        'platform': Platform(),
        'distribution': Distribution(),
    }

    service_mgr = ServiceMgrFactCollector()
    module = Module()

    service_mgr.collect(module=module, collected_facts=facts_dict)

    assert module.get_bin_path('systemctl')

# Generated at 2022-06-20 20:01:09.028459
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ffc = ServiceMgrFactCollector()
    assert ffc.name == 'service_mgr'
    assert ffc._fact_ids == set()
    assert ffc.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-20 20:01:20.172836
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class Module(object):

        def __init__(self, bin_path=None, file_exists=None, file_content=None):
            if bin_path:
                self.bin_path = bin_path
            else:
                self.bin_path = {}
            if file_exists:
                self.file_exists = file_exists
            else:
                self.file_exists = {}
            if file_content:
                self.file_content = file_content
            else:
                self.file_content = {}

        def get_bin_path(self, param):
            return self.bin_path[param]
    class Facts(object):
        def __init__(self, facts=None):
            self.facts = facts

        def get(self, param):
            return self.facts.get

# Generated at 2022-06-20 20:01:29.696871
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # create a dummy module object
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict()
    )
    # stub the get_bin_path method
    module.get_bin_path = lambda x: 'systemctl'
    # if /sbin/init is a symlink to systemd
    if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
        assert ServiceMgrFactCollector().is_systemd_managed_offline(module) == True
    else:
        # Code flow goes to "return False"
        assert ServiceMgrFactCollector().is_systemd_managed_offline(module) == False

# Generated at 2022-06-20 20:01:40.093032
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service import ServiceMgrFactCollector

    class TestModule(object):
        def get_bin_path(self, path):
            return 'test'

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            return {}

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.module = TestModule()

    if PY3:
        import os.path
        import os
        def os_readlink(path):
            return os

# Generated at 2022-06-20 20:01:44.273028
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.name == 'service_mgr'
    assert isinstance(fact_collector.required_facts, set)
    assert 'platform' in fact_collector.required_facts
    assert 'distribution' in fact_collector.required_facts

# Generated at 2022-06-20 20:01:44.737130
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass