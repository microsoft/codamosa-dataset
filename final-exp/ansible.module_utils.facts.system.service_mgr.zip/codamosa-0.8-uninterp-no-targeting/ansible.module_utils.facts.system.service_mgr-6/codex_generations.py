

# Generated at 2022-06-20 19:53:33.639525
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Test method with None argument
    """
    result = ServiceMgrFactCollector.collect()
    assert {} == result


# Generated at 2022-06-20 19:53:42.471752
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    import os
    import platform
    import shutil
    import sys
    import tempfile

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    from ansible.module_utils.six.moves import builtins

    # Allocate temporary directory for testing
    tmpdir = tempfile.mkdtemp()

    # Override platform.system()
    orig_platform_system = platform.system
    platform.system = lambda: 'Linux'

    # Override os.listdir()
    orig_os_listdir = os.listdir
    os.listdir = lambda path: ['initctl'] if path == '/usr/bin' else orig_os_listdir(path)

    # Override os.path.isdir


# Generated at 2022-06-20 19:53:52.315268
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def __init__(self, bin_path, exists_return_value):
            self.bin_path = bin_path
            self.exists_return_value = exists_return_value
        def get_bin_path(self, command, opt_dirs=[]):
            return self.bin_path
        def exists(self, path):
            return self.exists_return_value

    class_under_test = ServiceMgrFactCollector()

    # argument
    # systemctl_path: 'systemctl' exists, canary path: existence
    # expected_result


# Generated at 2022-06-20 19:53:56.523621
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    module_mock = type('Module')()
    module_mock.get_bin_path = lambda *args: None
    smfc = ServiceMgrFactCollector()
    smfc.collect(module=module_mock)

# Generated at 2022-06-20 19:54:04.088331
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class ModuleMock(object):
        def get_bin_path(self, cmd):
            if cmd in [ 'systemctl' ]:
                return '/usr/bin/%s' % cmd
            return None

    service_mgr_fact_collector = ServiceMgrFactCollector()
    if not service_mgr_fact_collector.is_systemd_managed_offline(module=ModuleMock()):
        raise AssertionError('ServiceMgrFactCollector.is_systemd_managed_offline() failed')


# Generated at 2022-06-20 19:54:16.431981
# Unit test for constructor of class ServiceMgrFactCollector

# Generated at 2022-06-20 19:54:27.837676
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import namespace_facts
    from ansible.module_utils.facts import collector

    # set up mock module
    module = FakeAnsibleModule()

    # set up mock module.run_command
    module_run_command = FakeModuleRunCommand()
    module.run_command = module_run_command

    # set up mock module.get_bin_path
    module.get_bin_path = FakeGetBinPath()


    # is_systemd_managed should return False when the /run/systemd/system directory does not exist
    # since /run/systemd/system directory is a canary used to detect systemd
    module_run_command.reset()
    module_run_command.rc = 0
    module_run_command.output = 'systemd'
    module.get_bin_

# Generated at 2022-06-20 19:54:39.163312
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """Test ServiceMgrFactCollector.collect()
    """
    ServiceMgrFactCollector.is_systemd_managed = classmethod(lambda _: True)
    ServiceMgrFactCollector.is_systemd_managed_offline = classmethod(lambda _: True)
    ServiceMgrFactCollector.collect_based_on_sysv = classmethod(lambda _, module: {
        'service_mgr': 'sysvinit'})
    ServiceMgrFactCollector.collect_based_on_pid1 = classmethod(lambda _, module, proc_1: {
        'service_mgr': proc_1})
    ServiceMgrFactCollector.collect_based_on_platform_value = classmethod(lambda _, module, collected_facts: {
        'service_mgr': 'launchd'})
    ServiceM

# Generated at 2022-06-20 19:54:46.856899
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Test for Red Hat Enterprise Linux 7
    module = MockModule(ansible_system='Linux', ansible_distribution='RedHat', ansible_system_vendor='', ansible_distribution_major_version='7')
    service_mgr_fact_collector = ServiceMgrFactCollector()
    facts_dict = service_mgr_fact_collector.collect(module=module)
    assert 'systemd' in facts_dict.values()

    # Test for CentOS 7
    module = MockModule(ansible_system='Linux', ansible_distribution='CentOS', ansible_system_vendor='', ansible_distribution_major_version='7')
    service_mgr_fact_collector = ServiceMgrFactCollector()

# Generated at 2022-06-20 19:54:57.174773
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # Mock class definition for os to create instance
    class MockModule:
        def get_bin_path(self, arg):
            return True

    mock_module = MockModule()

    # Mocking class definition for os to static method to return True
    class MockTrue:
        def exists(self, arg):
            return True

    # Mocking class definition for os to static method to return False
    class MockFalse:
        def exists(self, arg):
            return False

    os = MockTrue()
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module) == True

    os = MockFalse()
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module) == False



# Generated at 2022-06-20 19:55:23.235614
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class TestModule(object):
        def get_bin_path(self, name):
            return '/bin/%s' % name

    module = TestModule()
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # test existing /sbin/init symlink to systemd
    os.symlink('/bin/systemd', '/sbin/init')
    assert service_mgr_fact_collector.is_systemd_managed_offline(module)

    # test non-existing systemd
    os.unlink('/bin/systemd')
    assert not service_mgr_fact_collector.is_systemd_managed_offline(module)

    # test non-existing /sbin/init symlink to systemd

# Generated at 2022-06-20 19:55:28.422980
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Arrange
    class Module(object):
        def get_bin_path(self, arg):
            return '/bin/test'

    # Act
    result = ServiceMgrFactCollector.is_systemd_managed(Module())

    # Assert
    assert result

# Generated at 2022-06-20 19:55:40.544906
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_content
    import os


# Generated at 2022-06-20 19:55:50.227133
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import MockModule

    serviceMgrFactCollector = ServiceMgrFactCollector()
    # mock module
    module = MockModule(
        os_path_exists=lambda x: False,
        get_bin_path=lambda x: True
    )

    result = serviceMgrFactCollector.is_systemd_managed(module)

    assert result

    serviceMgrFactCollector = ServiceMgrFactCollector()
    # mock module
    module = MockModule(
        os_path_exists=lambda x: False,
        get_bin_path=lambda x: False
    )

    result = serviceMgrFactCollector.is_systemd_managed(module)

    assert not result


# Generated at 2022-06-20 19:55:52.803798
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector().collect()



# Generated at 2022-06-20 19:55:59.082871
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """
    This function instantiates ServiceMgrFactCollector class;
    ServiceMgrFactCollector class is a subclass of BaseFactCollector
    """
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert 'platform' and 'distribution' in service_mgr_fact_collector.required_facts


# Generated at 2022-06-20 19:56:07.423081
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system import ServiceMgrFactCollector as ServiceMgrFactCollector_old
    from ansible.module_utils.facts.utils import MockModule
    module = MockModule(
        params={},
        ansible_facts={'ansible_facts': {'service_mgr': None}},
        check_mode=False
    )

    with open("/etc/mock/os-release", "w+") as f:
        f.write("ID=rhel\nVERSION_ID=7.0\n")
        f.close()


# Generated at 2022-06-20 19:56:10.841315
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fc = ServiceMgrFactCollector()
    assert fc.name == 'service_mgr'

# Generated at 2022-06-20 19:56:13.921239
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector().is_systemd_managed_offline('systemd') == False
    assert ServiceMgrFactCollector().is_systemd_managed_offline('No systemd') == False
    assert ServiceMgrFactCollector().is_systemd_manag

# Generated at 2022-06-20 19:56:25.413860
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector

    # create a stub for module
    class ModuleStub:
        def get_bin_path(self, command):
            return "/bin/systemctl"

    module_stub = ModuleStub()

    # create a file for canary test
    open('/run/systemd/system/', 'a').close()

    # run the test with canary file existing
    result = ServiceMgrFactCollector.is_systemd_managed(module_stub)
    assert result

    # delete the canary file
    os.remove('/run/systemd/system/')

    # run the test again with the file deleted
    result = ServiceMgrFactCollector.is_systemd_managed(module_stub)
    assert not result

# Generated at 2022-06-20 19:56:52.342651
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Arrange
    # mock object ServiceMgrFactCollector
    class ServiceMgrFactCollectorMock:
        # method to test
        is_systemd_managed_offline = ServiceMgrFactCollector.is_systemd_managed_offline

    # mock module from ansible.module_utils
    class AnsibleModuleMock:
        def get_bin_path(self, path):
            return path

    # Act/Assert

    # test for Linux and systemd
    is_systemd_managed_offline = ServiceMgrFactCollectorMock.is_systemd_managed_offline(AnsibleModuleMock(), collected_facts={'ansible_system': 'Linux'})
    assert is_systemd_managed_offline == True

    # test for Linux and not systemd
    is_systemd_managed_off

# Generated at 2022-06-20 19:57:02.941309
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collectors

    class MockModule:
        def get_bin_path(self, name):
            return '/bin/' + name

    module = MockModule()
    collectors.setup(module)

    # Case 1: is_systemd_managed_offline returns False if systemd is not installed
    if os.path.islink('/sbin/init'):
        os.unlink('/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False

    # Case 2: is_systemd_managed_offline returns True if systemd is installed
    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')

# Generated at 2022-06-20 19:57:11.018476
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import ModuleStub

    # Given
    mock_module = ModuleStub({'which': {'systemctl': '/bin/systemctl'},
                              'path': {'/bin/systemctl': 1,
                                       '/run/systemd/system/': 1}})
    # When
    service_mgr_name = ServiceMgrFactCollector.is_systemd_managed(mock_module)
    # Then
    assert service_mgr_name

# Generated at 2022-06-20 19:57:19.100621
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import os
    import shutil
    import stat


# Generated at 2022-06-20 19:57:22.342914
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    svcMgrCol = ServiceMgrFactCollector()
    assert svcMgrCol.name == 'service_mgr'
    assert svcMgrCol.required_facts == {'distribution', 'platform'}
    assert svcMgrCol.collect() == {}

# Generated at 2022-06-20 19:57:25.451556
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import os
    import shutil

    tmpdir = tempfile.mkdtemp(suffix='systemd_test')
    init_path = os.path.join(tmpdir, 'init')
    open(init_path, 'a').close()
    os.symlink('systemd', init_path)

    smfc = ServiceMgrFactCollector()
    assert smfc.is_systemd_managed_offline({'get_bin_path': lambda x: init_path}) == True

    os.remove(init_path)
    os.rmdir(tmpdir)


# Generated at 2022-06-20 19:57:37.765417
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock

    # Both /dev/.run/systemd/ and /dev/.systemd/ exists
    module = mock.Mock()
    module.get_bin_path.return_value = "/bin/systemctl"
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(module)

    # /run/systemd/system/ exists
    step2_module = mock.Mock()
    step2_module.get_bin_path.return_value = "/bin/systemctl"
    def mock_open_sideeffect(path):
      if path == "/run/systemd/system/":
        raise OSError(13, 'Permission denied')

# Generated at 2022-06-20 19:57:39.858585
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Object required for is_systemd_managed
    module = object()

    assert ServiceMgrFactCollector.is_systemd_managed(module) == False


# Generated at 2022-06-20 19:57:42.414700
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()
    assert s.__class__.__name__ == "ServiceMgrFactCollector"

# Generated at 2022-06-20 19:57:54.824638
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.service_mgr

    # test openwrt case
    module = MockModule()
    module.get_bin_path.return_value = None
    assert ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector.is_systemd_managed(module) is False

    # test non-systemd case
    module = MockModule()
    module.get_bin_path.return_value = '/bin/systemctl'
    assert ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector.is_systemd_managed(module) is False

    # test systemd case
    module = MockModule()
    module.get_bin_path.return_value = '/bin/systemctl'

# Generated at 2022-06-20 19:58:48.348618
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector_test_is_systemd_managed_offline

    wrong_filename = '/tmp/wrong_systemd_facts.json'
    right_filename = '/tmp/right_systemd_facts.json'

    class Module:
        def __init__(self, filename):
            self.filename = filename
            self.rc = 0
            self.failed = False
            self.exit_args = None
            self.exit_kwargs = None
            self.warnings = []
            self.deprecations = []
            self.fail_json_called = False

        def get_bin_path(self, exe):
            return exe


# Generated at 2022-06-20 19:59:02.751055
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # In this unit test we will use the `module` fixture to mock out the
    # `Command` class.

    # First, initialize the `ServiceMgrFactCollector` class
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test 1: systemctl is not found, but /run/systemd/system/ is present
    with module as mock_module:
        mock_module.get_bin_path.return_value = None
        assert not service_mgr_fact_collector.is_systemd_managed(mock_module)

    # Test 2: systemctl is found, but /run/systemd/system/ is not present
    with module as mock_module:
        mock_module.get_bin_path.return_value = 'systemctl'
        assert not service_mgr_fact_

# Generated at 2022-06-20 19:59:12.794799
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    svc_mgr_fac_coll = ServiceMgrFactCollector()
    assert type(svc_mgr_fac_coll) == ServiceMgrFactCollector
    assert svc_mgr_fac_coll.name == 'service_mgr'
    assert isinstance(svc_mgr_fac_coll._fact_ids, set)
    assert isinstance(svc_mgr_fac_coll.required_facts, set)
    assert 'platform' in svc_mgr_fac_coll.required_facts
    assert 'distribution' in svc_mgr_fac_coll.required_facts
    assert hasattr(svc_mgr_fac_coll, 'collect')

# Generated at 2022-06-20 19:59:14.881590
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    assert ServiceMgrFactCollector.is_systemd_managed(None) == False

# Generated at 2022-06-20 19:59:24.465074
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Runner
    import ansible.module_utils.facts.collector

    my_runner = Runner(None, None, None, None, None, None, None)
    my_runner.get_all_facts = lambda: { 'ansible_distribution': 'Linux' }

    ServiceMgrFactCollector.get_runner = lambda: my_runner

    my_collector = ServiceMgrFactCollector()
    ServiceMgrFactCollector.collect = lambda: { 'service_mgr': 'upstart' }
    assert my_collector.collect() == { 'service_mgr': 'upstart' }

# Generated at 2022-06-20 19:59:31.136030
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Mocks
    class ModuleMock(object):
        def get_bin_path(self, *args, **kwargs):
            return 'systemctl'
    module_mock = ModuleMock()

    def exists(path):
        sym_links = {
            '/run/systemd/system/': False,
            '/dev/.run/systemd/': False,
            '/dev/.systemd/': False,
        }
        return sym_links[path]

    class OsMock(object):
        @staticmethod
        def path(path_name, *args, **kwargs):
            return OsMock()

        @staticmethod
        def readlink(path):
            return 'systemd'

        exists = exists

    os_mock = OsMock()

    # Test
    service_mgr_fact_collect

# Generated at 2022-06-20 19:59:38.679020
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Import neccesary libs
    from ansible.module_utils.facts.utils import AnsibleCollector
    from ansible.module_utils.facts.collectors import get_collector_instance
    # Create Collector instance
    ansible_collector_object = AnsibleCollector()
    service_mgr_fact_collector = get_collector_instance(ansible_collector_object, ServiceMgrFactCollector)
    # Call collect method
    service_mgr_fact_collector.collect()
    # Get value of attribute fact_ids
    service_mgr_fact_collector_ids = service_mgr_fact_collector.fact_ids

# Generated at 2022-06-20 19:59:47.818436
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = AnsibleModuleMock()
    module.get_bin_path = get_bin_pathMock()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False
    module.get_bin_path.return_value = '/bin/systemctl'
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False
    module.get_bin_path.return_value = '/bin/systemctl'
    os.symlink = symlinkMock()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == True


# Generated at 2022-06-20 19:59:51.542065
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

    # create a symbolic link pointing to systemd in /sbin/init
    os.symlink('/bin/systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == True
    os.remove('/sbin/init')

# Generated at 2022-06-20 20:00:03.378858
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    mock_res = {"distribution": "RedHat",
                "platform": "RedHat",
                "system": "RedHat"}
    mock_module = MockModuleUtils
    mock_module.run_command = Mock(return_value=(0, "", ""))
    mock_module.get_bin_path = Mock(return_value=True)
    assert not ServiceMgrFactCollector.is_systemd_managed(mock_module)
    mock_module.get_bin_path = Mock(return_value="/usr/bin/systemctl")

    mock_module.run_command = Mock(return_value=(0, "", ""))
    assert not ServiceMgrFactCollector.is_systemd_managed(mock_module)


# Generated at 2022-06-20 20:01:41.402080
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mock_module = False
    mock_facts = {
        'platform' : 'linux',
        'distribution' : 'CentOS',
    }
    servmgr_collector = ServiceMgrFactCollector(mock_module, mock_facts)

    assert servmgr_collector.collect() == {}

# Generated at 2022-06-20 20:01:48.080343
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from mock import Mock
    from ansible.module_utils.facts.collector import BaseFactCollector

    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.name == 'service_mgr'

    # simulate init systemd
    module = Mock()
    module.get_bin_path.return_value = '/bin/systemctl'
    fact_collector.is_systemd_managed(module=module)

    # simulate init upstart
    module.get_bin_path.return_value = ''
    fact_collector.is_systemd_managed(module=module)

    # simulate init upstart
    module.get_bin_path.return_value = '/bin/systemctl'
    open_mock = Mock()
    open_mock.read.return_value = ''
    open_m

# Generated at 2022-06-20 20:01:56.102115
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # Load the module
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class Testmodule(object):
        def get_bin_path(self, bin_path):
            return bin_path

        def run_command(self, command, use_unsafe_shell=False):
            return 0, '', ''

    test_module = Testmodule()
    assert ServiceMgrFactCollector.is_systemd_managed(test_module) == False


# Generated at 2022-06-20 20:02:05.326289
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    import mock

    svc_mgr_fact_collector = ServiceMgrFactCollector()

# Generated at 2022-06-20 20:02:14.185133
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import shutil
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.functions import module_framework_from_str
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector

    # Prepare temporary directory with symlinks
    tmpdir = "/tmp/ansible_test_service_mgr"
    os.makedirs(tmpdir+"/usr/bin/")
    os.symlink("/tmp/ansible_test_service_mgr/usr/bin", "/tmp/ansible_test_service_mgr/bin")
    os.makedirs("/tmp/ansible_test_service_mgr/lib/systemd/")

   

# Generated at 2022-06-20 20:02:19.863154
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector

# Generated at 2022-06-20 20:02:21.491152
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    sp = ServiceMgrFactCollector()
    assert sp.name == 'service_mgr'
    assert sp._fact_ids == set()

# Generated at 2022-06-20 20:02:29.228049
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, '/usr/bin/systemctl', None))
    module.get_bin_path = Mock(return_value='/usr/bin/systemctl')

    fc = ServiceMgrFactCollector()
    fc.module = module

    assert fc.is_systemd_managed(module)


# Generated at 2022-06-20 20:02:35.755379
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.basic import AnsibleModule

    class FactsCollectorModule(AnsibleModule):
        def __init__(self, **kwargs):
            super(FactsCollectorModule, self).__init__(**kwargs)
            self.service_mgr_collector = ServiceMgrFactCollector(self)

    def get_bin_path(self, executable):
        return self._command_search_path(executable)

    # Pre prepare the test environment
    test_systemd = './test/units/service_mgr_fact_collector_is_systemd_managed_offline/systemd'

# Generated at 2022-06-20 20:02:45.401860
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            pass

    mockmodule = MockModule()
    mockmodule.get_bin_path = lambda x: True

    # init
    serviceMgr = ServiceMgrFactCollector()
    facts_dict = {
        'platform': 'Linux',
        'distribution': 'RedHat',
        'ansible_system': 'Linux',
        'ansible_distribution': 'RedHat'
    }

    # verify openwrt_init
    serviceMgr.is_systemd_managed_offline = lambda x: True
    facts_dict = serviceMgr.collect(mockmodule, facts_dict)
    assert len(facts_dict) == 1 and 'openwrt_init' in facts_dict['service_mgr']

    # verify openwrt_init
