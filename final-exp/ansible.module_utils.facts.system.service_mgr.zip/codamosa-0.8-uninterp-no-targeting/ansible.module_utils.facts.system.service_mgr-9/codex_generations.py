

# Generated at 2022-06-20 19:53:34.690382
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module = Mock(return_value=None)
    setattr(module, 'run_command', lambda command: (0, 'systemd\n', ''))
    setattr(module, 'get_bin_path', lambda command: '/bin/%s' % command)
    facts = ServiceMgrFactCollector.collect(module=module)
    assert facts['service_mgr'] == 'systemd'

# Generated at 2022-06-20 19:53:36.233068
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    '''Unit test for constructor of class ServiceMgrFactCollector'''
    ServiceMgrFactCollector()

# Generated at 2022-06-20 19:53:47.167683
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import ModuleDepFactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_status

    class FakeModule(object):
        def __init__(self):
            self._name = 'fake'
            self._specific_params = []
        def get_bin_path(self, path, required=False):
            return 'fake_path'

    class FakeCollector(BaseFactCollector):
        name = 'fake_collector'
        _fact_ids = set()

    module = FakeModule()
    c = ServiceMgrFactCollector()
    assert c.is_systemd_managed(module) == False


# Generated at 2022-06-20 19:53:59.835314
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Test my_object is instance of ServiceMgrFactCollector
    my_object = ServiceMgrFactCollector()
    assert isinstance(my_object, ServiceMgrFactCollector)

    # Test my_object has name property
    assert hasattr(my_object, 'name')

    # Test my_object has _fact_ids property
    assert hasattr(my_object, '_fact_ids')

    # Test my_object has required_facts property
    assert hasattr(my_object, 'required_facts')

    # Test value of my_object's name properties
    assert my_object.name == 'service_mgr'

    # Test the values of my_object's _fact_ids
    assert my_object._fact_ids == set()

    # Test the values of my_object's required_facts
    assert my_object

# Generated at 2022-06-20 19:54:04.192241
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    test_module = AnsibleModule(argument_spec={})

    systemd_managed_offline = service_mgr_fact_collector.is_systemd_managed_offline(test_module)

    assert(systemd_managed_offline)

# Generated at 2022-06-20 19:54:10.714907
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class MockModule:
        def __init__(self):
            self.bin_path = None

        def get_bin_path(self, executable):
            return executable

    mock_module = MockModule()
    obj = ServiceMgrFactCollector()

    # /sbin/init is not a symlink, should not be systemd managed
    if os.path.islink('/sbin/init'):
        os.unlink('/sbin/init')

    assert obj.is_systemd_managed_offline(mock_module) is False

    # /sbin/init is a symlink to systemd, should be systemd managed
    if os.path.exists('/usr/lib/systemd/systemd'):
        os.symlink('/usr/lib/systemd/systemd', '/sbin/init')

# Generated at 2022-06-20 19:54:19.628772
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    from ansible.module_utils._text import to_bytes

    class MockModule(object):
        def get_bin_path(self, filename):
            return '/bin/systemctl'
        def run_command(self, command):
            return 1, '', ''

    module_obj = MockModule()
    collector = ansible.module_utils.facts.collector.ServiceMgrFactCollector()
    is_systemd_managed = collector.is_systemd_managed(module_obj)
    assert not is_systemd_managed

    class MockModule(object):
        def get_bin_path(self, filename):
            return False
        def run_command(self, command):
            return 1, '', ''

    module_obj = MockModule()
    collector = ans

# Generated at 2022-06-20 19:54:27.810021
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector

# Generated at 2022-06-20 19:54:35.360436
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys
    import tempfile
    import shutil
    import stat
    import subprocess
    import contextlib
    import os
    import os.path

    is_systemd_managed_offline = ServiceMgrFactCollector.is_systemd_managed_offline

    systemd_path = '/usr/lib/systemd/systemd'
    if not os.path.exists(systemd_path):
        raise Exception("Unable to find systemd executable at %s" % systemd_path)

    class FakeModule(object):
        def get_bin_path(self, executable):
            return systemd_path

    @contextlib.contextmanager
    def fake_init_links():
        tmp_dir = tempfile.mkdtemp()


# Generated at 2022-06-20 19:54:45.564566
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    ServiceMgrFactCollector.is_systemd_managed_offline() Test function

    This function is a unit test for ServiceMgrFactCollector.is_systemd_managed_offline() function.

    Parameters
    ----------
    module : object
        AnsibleModule object

    Returns
    -------
    boolean
        True, if the test passes. Otherwise, returns False.
    """

    import tempfile
    import shutil
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    facts_dict = {}
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Create temp folder

# Generated at 2022-06-20 19:55:13.802296
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.cache import FactsCache
    from ansible.module_utils.facts import default_collectors

    test_platform = os.environ.get('_TEST_UNIT_SERVICE_MGR_PLATFORM')
    if test_platform:
        saved_platform = platform.system()
        platform.system = lambda: test_platform

    test_distribution = os.environ.get('_TEST_UNIT_SERVICE_MGR_DISTRIBUTION')
    if test_distribution:
        saved_distribution = platform.dist()
        platform.dist = lambda: test_distribution



# Generated at 2022-06-20 19:55:14.471299
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-20 19:55:24.736037
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import collector

    # Mock module
    class MockModule:
        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                raise Exception("Invalid call")

    # Mock for stat.S_ISLNK
    class MockS_ISLNK:
        def __init__(self, x):
            pass

        def isfile(self):
            return True

        def isdir(self):
            return False

    # Mocked os
    class MockOS:
        def __init__(self):
            self.path = MockPath()

        class MockPath:
            def __init__(self):
                pass

            exists = Mock()

# Generated at 2022-06-20 19:55:38.021726
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    import unittest

    class TestServiceMgrFactCollector(unittest.TestCase):
        def test_name(self):
            assert ServiceMgrFactCollector.name == 'service_mgr'

        def test_is_systemd_managed_offline(self):
            import os
            import tempfile
            import shutil

            tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, tmpdir)

            os.mkdir(os.path.join(tmpdir, 'sbin'))

            # Test the False case with is_systemd_managed_offline():
            # That is /sbin/init does not exist or is not a symlink to systemd.
            assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False

           

# Generated at 2022-06-20 19:55:40.842253
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    collector = ServiceMgrFactCollector()
    assert collector.name == 'service_mgr'
    assert collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-20 19:55:50.699406
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts import ModuleFilestate

    # test case: systemctl is not available
    # expected result: False
    smfc = ServiceMgrFactCollector()
    module = ModuleFilestate()
    assert not smfc.is_systemd_managed_offline(module)

    # test case: /sbin/init does not exists
    # expected result: False
    module.get_bin_path = lambda x: '/bin/'+x
    assert not smfc.is_systemd_managed_offline(module)

    # test case: /sbin/init is not a symbolic link
    # expected result: False
    module.run_command = lambda x: (0, '/sbin/upstart', '')
   

# Generated at 2022-06-20 19:55:55.546557
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector._fact_ids == set()
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:56:05.455093
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class TestModule(object):
        def __init__(self):
            self.run_command = self.__run_command
            self.get_bin_path = self.__get_bin_path

        def __run_command(self, *args, **kwargs):
            if 'ps -p 1 -o comm' in args:
                return (0, 'init\n', None)
            else:
                return (1, '', None)

        def __get_bin_path(self, *args, **kwargs):
            if 'systemctl' in args:
                return '/usr/bin/systemctl'
            else:
                return None

    results = {'ansible_system': 'Linux'}
    test_collector = ServiceMgrFactCollector()
    test_module = TestModule()

    result = test_

# Generated at 2022-06-20 19:56:08.241063
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = AnsibleModule(argument_spec={})
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.is_systemd_managed(module) is False


# Generated at 2022-06-20 19:56:17.008244
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """
    Test the is_systemd_managed() method of ServiceMgrFactCollector.
    :return:
    """
    import tempfile
    import sys

    from ansible.module_utils.facts.collector import (
        ModuleFactCollector,
    )

    from ansible.module_utils.facts import (
        get_collector_instance,
    )

    from ansible.module_utils.facts.collector.system.service_mgr import (
        ServiceMgrFactCollector,
    )

    from ansible.module_utils.facts.utils import (
        get_bin_path,
    )

    # In the Mocker, we simulate that systemctl is found in $PATH.
    if "mocker" in sys.modules:
        get_bin_path = sys.modules['mocker'].replace

# Generated at 2022-06-20 19:56:51.762201
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Import module for method testing
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector

    # Set test parameters
    class MockModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'
        def run_command(self, command, use_unsafe_shell=True):
            return (0, '/bin/systemd', '')
    test_module = MockModule()
    expected_result = True

    # Run test with parameters
    result = ServiceMgrFactCollector.is_systemd_managed(module=test_module)

    # Check expected result is returned
    assert result == expected_result



# Generated at 2022-06-20 19:56:59.433355
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Override is_systemd_managed method in order to force ServiceMgrFactCollector
    # to query pid 1
    ServiceMgrFactCollector.is_systemd_managed = lambda x: False
    ServiceMgrFactCollector.is_systemd_managed_offline = lambda x: True
    input = {'ansible_system': 'OpenWrt'}
    result = ServiceMgrFactCollector.collect(input)
    assert result == {'service_mgr': 'openwrt_init'}

# Generated at 2022-06-20 19:57:06.610842
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # pylint: disable=import-error,unused-import,unused-variable
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.basic import AnsibleModule

    # The following code is for the purpose of testing the method of the same name
    # in the ServiceMgrFactCollector class in this file. As such, the code is not
    # PEP8 compliant.
    # pylint: disable=too-many-branches

    service_mgr_fact_collector = ServiceMgrFactCollector()

    # For testing, we replace the AnsibleModule instance used by the function
    # under test with a MagicMock object.

# Generated at 2022-06-20 19:57:08.424093
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_facts_collector = ServiceMgrFactCollector()


# Generated at 2022-06-20 19:57:11.927685
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc.name == 'service_mgr'
    assert smfc._fact_ids == set()
    assert smfc.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-20 19:57:19.632781
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil

    import ansible.module_utils.facts.collector
    module = ansible.module_utils.basic.AnsibleModule()
    module.get_bin_path = lambda x: '/bin/' + x

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-20 19:57:27.553853
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils import basic


# Generated at 2022-06-20 19:57:38.939531
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule():
        def __init__(self):
            self.params = {}

        def get_bin_path(self, cmd, opt_dirs=None, required=False):
            if cmd == 'systemctl':
                return '/bin/systemctl'

            if cmd == 'initctl':
                return '/bin/initctl'

            return None

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "ps -p 1 -o comm|tail -n 1":
                return (0, 'systemd\n', '')

            return (0, '<unknown>', '')

    facts_collector = BaseFactCollector()

# Generated at 2022-06-20 19:57:43.564341
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector.name == 'service_mgr'
    assert service_mgr_collector.required_facts == set(['platform', 'distribution'])
    assert service_mgr_collector._fact_ids == set()

# Generated at 2022-06-20 19:57:46.410235
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
  service_mgr_fact_collector = ServiceMgrFactCollector()
  assert isinstance(service_mgr_fact_collector, ServiceMgrFactCollector)

# Generated at 2022-06-20 19:58:59.046871
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import tempfile
    import shutil

    class Module:

        def __init__(self):
            self.file_name = tempfile.NamedTemporaryFile()

            with open('/proc/1/comm', 'r') as f:
                self.proc1_comm = f.read()

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/usr/bin/systemctl'

            return None

        def run_command(self, executable, use_unsafe_shell):
            return 0, self.proc1_comm, None

    module = Module()

    def os_path_isdir(path):
        if path == '/etc/init/':
            return False
        elif path == '/etc/init.d/':
            return True

# Generated at 2022-06-20 19:59:01.140911
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert isinstance(ServiceMgrFactCollector(), ServiceMgrFactCollector)

# Generated at 2022-06-20 19:59:12.261785
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = MagicMock()
    module.get_bin_path.return_value = None
    service_mgr_collector = ServiceMgrFactCollector()
    assert not service_mgr_collector.is_systemd_managed(module=module)

    module.get_bin_path.return_value = "systemctl"
    module.run_command.return_value = [2, None, None]

    assert not service_mgr_collector.is_systemd_managed(module=module)

    module.run_command.return_value = [0, None, None]
    module.run_command.return_value = [0, "systemd", None]

    assert service_mgr_collector.is_systemd_managed(module=module)


# Generated at 2022-06-20 19:59:14.214851
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()
    assert s.name == 'service_mgr'
    assert s == ServiceMgrFactCollector()
    assert s is not None
    assert s._fact_ids == set()
    assert s.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:59:19.294282
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return "/sbin/systemctl"

    class MockCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.module = MockModule()

        def collect(self, module=None, collected_facts=None):
            return ServiceMgrFactCollector.is_systemd_managed_offline(self, module=self.module)

    assert MockCollector() is False

# Generated at 2022-06-20 19:59:28.146586
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.system.service_mgr import ServiceMgrFactCollector

    collector = Collector()

    facts_dict = {}
    facts_dict['ansible_system'] = 'Linux'
    facts_dict['ansible_distribution'] = 'MacOSX'

    # Initialize the ServiceMgrFactCollector
    collector.set_fact_cache(facts_dict)
    # Get the fact object
    fact = collector.get_fact('service_mgr')

    assert fact.__class__ == ServiceMgrFactCollector
    assert fact.COLLECTOR_FACT_NAME == 'service_mgr'
    assert fact.COLLECTOR_FACT_CLASS == ServiceMgrFactCollector
    assert fact.COLLECTOR_F

# Generated at 2022-06-20 19:59:29.865732
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert isinstance(ServiceMgrFactCollector(), ServiceMgrFactCollector)

# Generated at 2022-06-20 19:59:38.731095
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import get_collector_instance
    from ansible.module_utils.facts.collectors.base import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    get_file_content_orig = get_file_content
    # We assume the unit tests will run on systemd based systems
    get_file_content_mock = lambda path: "systemd"

    # Mocking module calls
    class MyModule:
        def __init__(self):
            self.run_command_params = []

        def run_command(self, params, use_unsafe_shell=True):
            self.run_command_params.append((params, use_unsafe_shell))
           

# Generated at 2022-06-20 19:59:49.346838
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Build a mock module object
    default_module_args = {
        'ansible_system': 'Linux'
    }
    module = FakeAnsibleModule(**default_module_args)

    # Build a mock collected_facts object
    collected_facts = {
        'ansible_facts': {
            'ansible_distribution': 'ArchLinux',
            'ansible_distribution_major_version': '10',
            'ansible_distribution_release': '10.0',
            'ansible_distribution_version': '10.0',
            'ansible_distribution_version_abs': '10.0'
        }
    }

    # Run collect and check
    result = ServiceMgrFactCollector().collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-20 20:00:00.723953
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    is_systemd_managed_offline = ServiceMgrFactCollector.is_systemd_managed_offline
    assert not is_systemd_managed_offline(None)

    from ansible.module_utils.facts.utils import MockModule

    class MockOS(object):
        def exists(self, file):
            return file.endswith('systemctl')

        def islink(self, file):
            return file.endswith('init') and file.startswith('/sbin/')

        def basename(self, filename):
            return 'systemd'

    fake_module = MockModule({})
    fake_module.get_bin_path = lambda x: '/usr/bin/' + x
    fake_module.run_command = lambda cmd: (0, 'systemd\n', '')
    fake_

# Generated at 2022-06-20 20:02:43.496846
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Setup temporary directory structure for testing
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    systemd_canary = os.path.join(tmpdir, 'systemd_canary')
    os.mkdir(systemd_canary)

    # Test true condition
    from ansible.module_utils.basic import AnsibleModule
    mymod = AnsibleModule({}, {}, support_check_mode=False)
    setattr(mymod, '_ansible_tmpdir', tmpdir)
    mymod.get_bin_path = lambda *args, **kwargs: os.path.join(tmpdir, 'bin', 'systemctl')
    try:
        assert True is ServiceMgrFactCollector.is_systemd_managed(mymod)
    except Exception as e:
        raise Assert

# Generated at 2022-06-20 20:02:56.720531
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test 1
    module = MockModule()
    ServiceMgrFactCollector.is_systemd_managed(module)
    assert module.run_command.call_count == 1
    assert module.get_bin_path.call_count == 1
    assert module.os_path.exists.call_count == 3
    assert module.os_path.exists.call_args_list == [call('/run/systemd/system/'),
                                                    call('/dev/.run/systemd/'),
                                                    call('/dev/.systemd/')]
    assert module.os_path.exists.return_value == False

    # Test 2
    module.os_path.exists.reset_mock()
    module.os_path.exists.return_value = True

# Generated at 2022-06-20 20:03:05.618253
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    current_os = platform.system()
    if current_os == 'Linux':
        import ansible.module_utils.facts.system.service_mgr as service_mgr_method
        from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
        from ansible.module_utils.facts.system.system import MockedModule

        # Initialize MockedModule Object
        mocked_module = MockedModule()
        service_mgr_fact_collector = ServiceMgrFactCollector()

        # Test (1) - Systemd is installed and "/sbin/init" is symlink to systemd
        mocked_module.get_bin_path_return_value = '/usr/bin/systemd'
        mocked_module.os_path_islink_return_value = True

# Generated at 2022-06-20 20:03:06.562804
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    ServiceMgrFactCollector.is_systemd_managed_offline(module=None)

# Generated at 2022-06-20 20:03:16.450589
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import ansible_collected_facts
    from ansible.module_utils.facts import ansible_created_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_facts
    FactsCollector.add_collector(ServiceMgrFactCollector())
    ansible_facts = ansible_facts(ansible_collected_facts)
    # test OpenWrt
    setattr(ansible_facts, 'ansible_distribution', 'OpenWrt')
    from ansible.module_utils.facts.utils import get_file_content
    setattr(get_file_content, '/proc/1/comm', 'procd')
   