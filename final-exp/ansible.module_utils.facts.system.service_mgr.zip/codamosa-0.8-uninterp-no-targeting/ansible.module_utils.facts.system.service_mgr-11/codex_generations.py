

# Generated at 2022-06-20 19:53:45.823568
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class Module:
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    service_mgr_fact_collector = ServiceMgrFactCollector()

    def make_test_function(test, expected_result):
            return lambda: (test, service_mgr_fact_collector.is_systemd_managed(Module()), expected_result)

    os.environ['_'] = '/bin/systemctl'
    os.environ['LANG'] = ''
    os.environ['PATH'] = ''
    os.environ['PWD'] = ''

    for canary in ["/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"]:
        os.system('rm -rf {0}'.format(canary))


# Generated at 2022-06-20 19:53:57.885578
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from AnsibleModuleMock import AnsibleModuleMock
    am = AnsibleModuleMock()
    service_mgr_fact_collector = ServiceMgrFactCollector(am)

    # No platform, distribution in collected_facts
    collected_facts = {}
    facts_dict = service_mgr_fact_collector.collect(None, collected_facts)
    assert 'service_mgr' not in facts_dict

    # Empty platform, distribution in collected_facts
    collected_facts = {'platform': '', 'distribution': ''}
    facts_dict = service_mgr_fact_collector.collect(None, collected_facts)
    assert 'service_mgr' not in facts_dict

    # Non-Linux platform in collected_facts

# Generated at 2022-06-20 19:54:02.022152
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc.name == 'service_mgr'
    assert smfc.requirements == set(['platform', 'distribution'])
    assert smfc._fact_ids == set()

# Generated at 2022-06-20 19:54:04.448072
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector_obj = ServiceMgrFactCollector()
    assert type(service_mgr_fact_collector_obj) == ServiceMgrFactCollector

# Generated at 2022-06-20 19:54:16.837227
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, bin_path=None):
            if bin_path is None:
                self.bin_path = {}
            else:
                self.bin_path = bin_path

        def get_bin_path(self, path):
            return self.bin_path.get(path)

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "ps -p 1 -o comm|tail -n 1" and use_unsafe_shell is True:
                if self.bin_path.get('systemctl'):
                    return (0, 'systemd', '')
                else:
                    return (0, 'sysvinit', '')

    class MockCollectedFacts(object):
        def __init__(self):
            self.facts

# Generated at 2022-06-20 19:54:19.535324
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.collect() == {'service_mgr': 'service'}

# Generated at 2022-06-20 19:54:28.650746
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile

    module = type('', (), {})()
    module.run_command = lambda *args: False  # default
    module.get_bin_path = lambda *args: None

    # Tools not installed, something is wrong, should return None
    assert ServiceMgrFactCollector.is_systemd_managed(module) is None

    # Create tempfile for systemd-bin
    temp_systemd_bin = tempfile.mkstemp()[1]
    module.get_bin_path = lambda *args: temp_systemd_bin # Return the path to the systemd-bin executable

    # No canary file present, so return False
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

    # Create canary file
    temp_canary_file = tempfile.mkstemp()[1]


# Generated at 2022-06-20 19:54:31.618355
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    facts = dict()
    fact = ServiceMgrFactCollector()

    assert fact.name == 'service_mgr'
    assert fact.required_facts == set(['platform', 'distribution'])
    assert facts == dict()


# Generated at 2022-06-20 19:54:32.348005
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-20 19:54:44.265187
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    from ansible.module_utils.facts.collector import BaseFactCollector
    setattr(BaseFactCollector, '_warnings', [])
    setattr(BaseFactCollector, '_errors', [])

    ServiceMgrFactCollector.required_facts = set([])

    # Create a valid AnsibleModule instance
    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    # Create an instance of the ServiceMgrFactCollector class
    collector_instance = ServiceMgrFactCollector(module)
    # The result should be False, because the command executed should not return a valid result
    assert collector_instance.is_systemd_managed_offline(module) == False


# Generated at 2022-06-20 19:55:04.605654
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service import ServiceMgrFactCollector

    module_mock = Mock()

    # Setup the default facts collector with the ServiceMgrFactCollector class
    def side_effect(name):
        if name == "service":
            return ServiceMgrFactCollector
        else:
            return None
    collector = Collector()
    collector.get_collector = Mock(side_effect=side_effect)

    # Call method collect on default facts collector
    result = collector.collect(module_mock)

    # Check if key 'service_mgr' is in result
    assert 'service_mgr' in result

# Generated at 2022-06-20 19:55:07.873833
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    collector = ServiceMgrFactCollector()
    class FakeModule(object):
        def get_bin_path(self, path):
            return '/usr/bin/systemctl'

    module = FakeModule()
    assert collector.is_systemd_managed(module) == True

# Generated at 2022-06-20 19:55:08.981798
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

# Generated at 2022-06-20 19:55:15.873253
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    from ansible.module_utils._text import to_bytes
    service_mgr = ServiceMgrFactCollector()

    # test for cases where facts for platform, distribution must exist
    os_facts = MagicMock()
    os_facts.get.return_value = None
    os_facts.get.__getitem__.side_effect = None
    ans = service_mgr.collect(os_facts)
    assert ans == {}

    # test for platforms openwrt, macosx >= 10.4, launchd, bsd
    os_facts = MagicMock()
    os_facts.get.return_value = None

# Generated at 2022-06-20 19:55:25.278907
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import get_collector

    class DummyModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, param):
            return True

    class DummyFacts(object):
        def __init__(self):
            self.ansible_facts = {
                'ansible_distribution': None,
                'ansible_system': None,
            }

    ServiceMgrFactCollector.is_systemd_managed = lambda x: True
    ServiceMgrFactCollector.is_systemd_managed_offline = lambda x: True
    dummy_module = DummyModule()
    dummy_facts = DummyFacts()
    # Let

# Generated at 2022-06-20 19:55:38.062381
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import shutil
    import os

    # Method is static, we can mock it and call it with no arguments
    with tempfile.TemporaryDirectory() as temp_dir:
        # Init the true things that systemd init system has
        os.makedirs('/run/systemd/system/', exist_ok=True)
        os.makedirs('/dev/.run/systemd/', exist_ok=True)
        os.makedirs('/dev/.systemd/', exist_ok=True)

        # Check that returns true when systemd init system is present
        assert ServiceMgrFactCollector.is_systemd_managed('/bin/true')

        # Remove all that init system is present
        shutil.rmtree('/run')
        shutil.rmtree('/dev/.run')
        shutil

# Generated at 2022-06-20 19:55:48.712304
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Test ServiceMgrFactCollector
    """

    class MockModule(object):
        def get_bin_path(self, path):
            return "/path/to/{}".format(path)

    def mock_run_command(self, cmd, use_unsafe_shell=False):
        if cmd == "ps -p 1 -o comm|tail -n 1":
            return (0, "dnf", "")
        else:
            return (0, "/sbin/init", "")

    mock_module = MockModule()
    mock_module.run_command = mock_run_command
    result = ServiceMgrFactCollector.is_systemd_managed(mock_module)
    assert result is False

    mock_module.run_command = mock_run_command

# Generated at 2022-06-20 19:55:54.831978
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import mock

    # Test with systemd as init system
    proc_service_mgr = ServiceMgrFactCollector()
    module = mock.Mock()
    module.get_bin_path.return_value = "/bin/systemctl"
    with mock.patch("ansible.module_utils.facts.collector.service_mgr.os.readlink") as readlink:
        readlink.return_value = "/bin/systemd"
        assert(proc_service_mgr.is_systemd_managed_offline(module=module) == True)

    # Test with non-systemd init system
    proc_service_mgr = ServiceMgrFactCollector()
    module = mock.Mock()
    module.get_bin_path.return_value = "/bin/systemctl"

# Generated at 2022-06-20 19:56:05.007632
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # create mock module
    class MockModule:
        def get_bin_path(self, path, opt_dirs=[]):
            if path == 'systemctl':
                return path
            else:
                return None

    module = MockModule()

    # create mock collector
    mock_collector = ServiceMgrFactCollector()

    # create mock link
    from mock import patch
    mock_link = patch('os.readlink').start()

    # 1. Case: link to systemd
    mock_link.return_value = 'systemd'
    assert mock_collector.is_systemd_managed_offline(module=module) == True

    # 2. Case: link to init
    mock_link.return_value = 'init'
    assert mock_collector.is_systemd_managed_offline(module=module)

# Generated at 2022-06-20 19:56:15.183213
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test_module = AnsibleModuleStub()
    collector = ServiceMgrFactCollector()

    # test with empty bin_path
    test_module.bin_path = ''
    assert collector.is_systemd_managed(module=test_module) == False

    # test with no systemd directories
    test_module.bin_path = '/sbin'
    assert collector.is_systemd_managed(module=test_module) == False

    # test with /run/systemd/system/
    test_module.bin_path = '/sbin'
    test_module.check_file_exists = lambda path: path == '/run/systemd/system/'
    assert collector.is_systemd_managed(module=test_module) == True

    # test with /dev/.run/systemd/
    test_module.bin_

# Generated at 2022-06-20 19:56:49.484270
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module = AnsibleModuleMock()
    smfc = ServiceMgrFactCollector()
    smfc.collect(module)

# Generated at 2022-06-20 19:56:55.847022
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    from ansible_collections.misc.tests.unit.compat.mock import patch

    from ansible.module_utils.facts import collector

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestFactsCollector(FactsCollector):

        def __init__(self, *args, **kwargs):
            super(TestFactsCollector, self).__init__(*args, **kwargs)

            self._collected_facts = {
                'ansible_distribution': 'MacOSX'
            }

    class TestBaseFactCollector(BaseFactCollector):

        name = 'service_mgr'
        _fact_ids = set()


# Generated at 2022-06-20 19:57:04.267725
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_module = type('module', (), {})
    fake_bin_path = {'systemctl': ['/usr/bin/systemctl'], 'initctl' : ['/usr/bin/initctl'], 'ps': ['/usr/bin/ps'], 'mv': ['/usr/bin/mv'], 'systemd': ['/usr/bin/systemd']}
    test_module.run_command = lambda cmd, use_unsafe_shell=True: (0, '', '')
    test_module.get_bin_path = lambda cmd: fake_bin_path.get(cmd)
    test_module.get_file_content = lambda file: None

    service_mgr_fact_collector = ServiceMgrFactCollector()
    # test for systemd
    test_module.is_systemd_managed = Service

# Generated at 2022-06-20 19:57:15.090711
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    collect = ServiceMgrFactCollector()

    collected_facts = {}
    collected_facts.update(dict(
        ansible_distribution='MacOSX',
        ansible_system='Darwin',
    ))

    # service_mgr should be set to 'launchd' because of the collected facts above.
    # The version is 10.13.1. The comparison is done by LooseVersion so '10.13.1' < '10.4' == True.
    test_platform = platform.mac_ver()
    test_platform = (test_platform[0] == '10.13.1') and test_platform or False
    if test_platform:
        test_collect = collect.collect(collected_facts=collected_facts)
        assert test_collect

# Generated at 2022-06-20 19:57:21.497498
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # create a mock module object
    class MockModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, path, required=False):
            if path == 'systemctl':
                return '/bin/systemctl'
            if path == 'initctl':
                return '/usr/bin/initctl'

        def run_command(self, cmd, use_unsafe_shell=True):
            if cmd == 'ps -p 1 -o comm|tail -n 1':
                return 0, 'init\n', ''
            if cmd == 'ps -p 1 -o comm':
                return 0, 'init', ''
            if cmd == 'rc-status':
                return 0, '', ''
            if cmd == 'systemctl list-units':
                return 0, '', ''

   

# Generated at 2022-06-20 19:57:23.851148
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    serviceMgrFactCollector = ServiceMgrFactCollector()
    assert isinstance(serviceMgrFactCollector, ServiceMgrFactCollector)


# Generated at 2022-06-20 19:57:30.175832
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import platform
    class MockModule:
        def __init__(self, run_command_rcs):
            self.run_command_rcs = run_command_rcs

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=False):
            return self.run_command_rcs.pop(0)

    # Test when pid 1 is systemd
    class MockSysFS:
        def __init__(self):
            pass

        def islink(self, file):
            if file == '/sbin/init':
                return True

        def readlink(self, file):
            return 'systemd'

    mocked_platform = platform.__class__


# Generated at 2022-06-20 19:57:40.205434
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    import os

    # Mock the get_file_content function from utils
    with mock.patch('ansible.module_utils.facts.collector.base.get_file_content') as get_file_content:
        get_file_content.return_value=None

        # Create a ServiceMgrFactCollector object and mock the functions needed
        smfcObj = ServiceMgrFactCollector()
        smfcObj.is_systemd_managed_offline= mock.MagicMock()
        smfcObj.is_systemd_managed_offline.return_value=False
        smfcObj.get_bin_path = mock.MagicMock()

        # Path to systemctl exist and we detect that systemd is the boot init
        smfcObj.get_bin_path.return_value="/bin/systemctl"
       

# Generated at 2022-06-20 19:57:46.409251
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    from ansible.module_utils.facts.test import MockModule
    module = MockModule()
    module.get_bin_path = lambda x: "/bin/%s" % x

    assert service_mgr_fact_collector.is_systemd_managed_offline(module) is True

# Generated at 2022-06-20 19:57:56.551127
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    mgr = ServiceMgrFactCollector()

    import ansible.module_utils.facts.system.service_mgr as service_mgr
    import ansible.module_utils.facts.system.service_mgr_setup as service_mgr_setup
    from ansible.module_utils.facts.system.service_mgr_setup import setup_systemd

    # setup a mock class for the return of a mock module
    module = service_mgr_setup.setup_systemd()
    module_class = module.__class__

    # Create a mock "run_command" function in the instance
    # set the return values based on the call
    # the first call will return True, the second False and the third None, i.e. run_command will return the third value, None
    # no matter what it is called with as arguments
   

# Generated at 2022-06-20 19:59:08.738992
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False


# Generated at 2022-06-20 19:59:18.128010
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils._text import to_bytes

    test_path = '/usr/bin/test123'
    test_data = to_bytes('#!/bin/sh\necho list-unit-files\nexit 0\n')
    test_file = open(test_path, 'wb')
    test_file.write(test_data)
    test_file.close()
    import os
    os.chmod(test_path, 0o755)

    class ModuleTest(object):
        def get_bin_path(self, *args, **kwargs):
            return test_path
    module = ModuleTest()
    module.run_command = lambda *args, **kwargs: (0, 'systemd-tmpfiles-setup.service\n', '')

    assert ServiceMgrFactCollector.is_systemd

# Generated at 2022-06-20 19:59:22.247307
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr = ServiceMgrFactCollector({}, {}, [])

    assert service_mgr.name == 'service_mgr'
    assert service_mgr.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-20 19:59:27.351991
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    collected_facts = {}

    # Create instance of ServiceMgrFactCollector
    fact_collector = ServiceMgrFactCollector()

    # run test on method collect
    if fact_collector.requires_facts:
        for fact_requirement in fact_collector.requires_facts:
            collected_facts[fact_requirement] = {}

    facts_dict = fact_collector.collect(collected_facts=collected_facts)
    assert 'service_mgr' in facts_dict, facts_dict

# Generated at 2022-06-20 19:59:31.091909
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()
    assert s.name == 'service_mgr'
    assert s.required_facts == set(['platform', 'distribution'])
    assert {'service_mgr'} == s._fact_ids


# Generated at 2022-06-20 19:59:36.809101
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    mock_module = MockModule({
        'PATH': '/bin:/usr/bin:/usr/local/bin',
        'supports_check_mode': False,
        'no_log': False,
    })
    mock_module.run_command = Mock(return_value=(0, 'systemd', ''))
    assert ServiceMgrFactCollector.is_systemd_managed_offline(mock_module) == True



# Generated at 2022-06-20 19:59:41.692440
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj
    assert obj.name == 'service_mgr'
    required_facts = set(['platform', 'distribution'])
    assert obj.required_facts == required_facts
    assert obj.is_systemd_managed_offline

# Generated at 2022-06-20 19:59:46.119093
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    sMFC = ServiceMgrFactCollector()
    assert sMFC.name == 'service_mgr'
    assert sMFC.required_facts == set(['platform', 'distribution'])
    assert isinstance(sMFC._fact_ids, set)

# Generated at 2022-06-20 19:59:49.700884
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    module = {
        'get_bin_path': lambda x: x,
        'run_command': lambda x: (0, '', '')
    }
    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector.collect(module) == {'service_mgr': 'service'}

# Generated at 2022-06-20 19:59:55.714664
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    res = {}
    # FIXME: how to fake module with run_command
    # TODO: test the other cases
    if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
        res['service_mgr'] = 'systemd'
    else:
        res['service_mgr'] = None
    return res

# Generated at 2022-06-20 20:03:06.227922
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import Cache
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector

    # Creates a temporary directory and returns the absolute path to it.
    tmpdir = tempfile.mkdtemp()

    # create a local fake module
    class FakeModule:
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir
            self.run_command_calls = []

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return executable

        def run_command(self, args):
            self.run_command_calls.append(args)

# Generated at 2022-06-20 20:03:10.081940
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Test ServiceMgrFactCollector method constructor
    """
    x = ServiceMgrFactCollector()
    assert x is not None, "Failed to instantiate ServiceMgrFactCollector"

# Generated at 2022-06-20 20:03:17.371550
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.service_mgr as collector

    MOCK_SYSTEMCTL = '/usr/bin/systemctl'
    MOCK_COMMAND_RESULT = (0, '', '')

    class MockModule(object):
        def __init__(self):
            self.run_command = lambda x: MOCK_COMMAND_RESULT
            self.get_bin_path = lambda x: MOCK_SYSTEMCTL if x == 'systemctl' else None

    # no library installed - must be False
    module = MockModule()
    assert not collector.ServiceMgrFactCollector.is_systemd_managed(module)

    module.get_bin_path = lambda x: MOCK_SYSTEMCTL if x == 'systemctl' else None

# Generated at 2022-06-20 20:03:25.864288
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.service_mgr as service_mgr

    # this class is not actually used for mocking purposes
    class MockModule(object):
        @staticmethod
        def fail_json(*args, **kwargs):
            pass

        @staticmethod
        def get_bin_path(name, *args, **kwargs):
            # return path of some tool only if 'systemctl'
            if name == 'systemctl':
                return 'systemctl'


    # this function is not actually used for mocking purposes
    def mock_os_path_lexists(name):
        if name == '/dev/.run/systemd' or name == '/dev/.systemd':
            return True
        else:
            return False

    # this function is not actually used for mocking purposes