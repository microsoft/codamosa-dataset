

# Generated at 2022-06-20 19:53:39.613527
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    mgr = ServiceMgrFactCollector()
    systemd_managed = mgr.is_systemd_managed_offline(None)
    assert systemd_managed == False


# Generated at 2022-06-20 19:53:51.307989
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Collector

    class FakeModule:
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return True

        def run_command(self, *args, **kwargs):
            return (0, 'init', '')

    collector = ServiceMgrFactCollector()

    # test without a module parameter
    collected_facts = Collector().collect(collectors=[collector])
    assert 'service_mgr' not in collected_facts

    # test with a module parameter
    collected_facts = Collector().collect(module=FakeModule(), collectors=[collector])
    assert 'service_mgr' in collected_facts
    assert collected_facts['service_mgr'] == 'sysvinit'

# Generated at 2022-06-20 19:54:03.094365
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    class MockModule():
        def __init__(self):
            self.params = {'gather_subset': ['all']}

        def get_bin_path(self, cmd):
            return "/bin/" + cmd

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == 'ps -p 1 -o comm|tail -n 1':
                return 0, 'systemd\n', ''
            elif cmd == 'systemctl':
                return 0, '', ''
            else:
                return 1, '', ''

    module = MockModule()

    # ps -p 1 -o comm|tail -n 1 == systemd
    # is_systemd_managed == True
    collector = Collector()

# Generated at 2022-06-20 19:54:05.253426
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    facts_collector = ServiceMgrFactCollector()
    facts = facts_collector.collect()
    assert facts['service_mgr'] is None

# Generated at 2022-06-20 19:54:17.533601
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """Unit test for method collect of class ServiceMgrFactCollector"""
    # Initialize
    default_collector = BaseFactCollector()
    test_service_mgr_collector = ServiceMgrFactCollector(default_collector)
    run_command_return = (0, '', '')
    get_file_content_return = ""
    test_system = "SunOS"
    test_distribution = "OpenWrt"
    os.start_mock(return_value=True)
    setattr(platform, 'system', lambda: test_system)
    setattr(platform, 'mac_ver', lambda: (test_system, '', ''))
    setattr(platform, 'linux_distribution', lambda: (test_distribution, '', ''))

    # Test 1: ansible_system = MacOSX,

# Generated at 2022-06-20 19:54:27.712854
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.collectors.service_mgr
    import ansible.module_utils.facts.collectors.system

    class ModuleMock(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            raise Exception(args, kwargs)

        @staticmethod
        def get_bin_path(bin_name, required=False, opt_dirs=[]):
            return '/sbin/'+bin_name

    test_dict = {}
    test_system_dict = {}

    system_collector = ansible.module_utils.facts.collectors.system.SystemFactCollector()
    test_system_dict = system_collector.collect(ModuleMock())

    test_dict = ansible.module_

# Generated at 2022-06-20 19:54:32.363807
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    class FakeModule:
        def get_bin_path(self, my_bin_path):
            return '/bin/systemctl'
    my_module = FakeModule()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(my_module)



# Generated at 2022-06-20 19:54:44.303576
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector as service_mgr_test_module
    import ansible.module_utils.facts.service_mgr as service_mgr_test_module_service
    import ansible.module_utils.facts.utils as service_mgr_test_module_utils
    import ansible.module_utils.facts.system as service_mgr_test_module_system

    module_object = service_mgr_test_module.AnsibleModule(argument_spec={})
    module_object.get_bin_path = service_mgr_test_module_service.ServiceMgrFactCollector.get_bin_path
    module_object.exit_json = service_mgr_test_module_service.ServiceMgrFactCollector.exit_json
    module_object.fail_json = service

# Generated at 2022-06-20 19:54:48.111242
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.collector
    # instantiate Collector
    facts_collector = ansible.module_utils.facts.collector.get_collector(ServiceMgrFactCollector.name, collected_facts=None)
    # execute collect, get result
    result = facts_collector.collect()
    assert ServiceMgrFactCollector.name == result["service_mgr"]

# Generated at 2022-06-20 19:54:56.596005
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    from ansible.module_utils.facts import Module

    fake_module = Module()

    fake_module.get_bin_path = lambda x: '/sbin/%s' % x
    fake_module.run_command = lambda x: (0, '', '')

    fake_module.exists = lambda x: False

    assert ServiceMgrFactCollector.is_systemd_managed(fake_module) == False

    fake_module.exists = lambda x: True

    assert ServiceMgrFactCollector.is_systemd_managed(fake_module) == True

# Generated at 2022-06-20 19:55:20.765162
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector

    ansible_module = MockAnsibleModule()
    ansible_module.params = {}

    # Mocked variable
    ansible_module.get_bin_path.return_value = '/usr/bin/systemctl'

    os.path.islink = mock.Mock(return_value=True)
    os.readlink = mock.Mock(return_value='/sbin/init')

    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed_offline(mock)

# Generated at 2022-06-20 19:55:21.727547
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector.collect()

# Generated at 2022-06-20 19:55:27.823391
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    module=object()
    module.get_bin_path=lambda x:x
    module.run_command=lambda x:'',''
    assert not ServiceMgrFactCollector.is_systemd_managed(module)
    with tempfile.TemporaryDirectory() as td:
        open(os.path.join(td,'systemctl'),'w').close()
        for canary in ["/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"]:
            os.makedirs(canary)
            assert ServiceMgrFactCollector.is_systemd_managed(module)
            os.rmdir(canary)

# Generated at 2022-06-20 19:55:39.742605
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule:
        bin_path = lambda self, prog: '/usr/bin/'+prog

    class MockCollectedFacts:
        ansible_distribution = 'MacOSX'
        ansible_system = 'MacOSX'

    # Test on MacOSX
    fact_collector = ServiceMgrFactCollector()
    ansible_facts = fact_collector.collect(module = MockModule(), collected_facts = MockCollectedFacts())
    assert(ansible_facts['service_mgr'] == 'launchd')

    # Test on BSD
    MockCollectedFacts.ansible_system = 'FreeBSD'
    ansible_facts = fact_collector.collect(module = MockModule(), collected_facts = MockCollectedFacts())

# Generated at 2022-06-20 19:55:42.646392
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed({'stat': lambda canary: os.path.exists(canary)})



# Generated at 2022-06-20 19:55:44.474815
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc.name == 'service_mgr'

# Generated at 2022-06-20 19:55:52.503500
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    module_mock = mock.Mock()
    module_mock.get_bin_path.return_value = '/bin/systemctl'
    smm = ServiceMgrFactCollector()
    # Return True when canary files exists
    canaries = ["/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"]
    for canary in canaries:
        smm.is_systemd_managed(module_mock)
        module_mock.run_command.assert_called_with("systemctl list-units --full --no-legend 2>/dev/null", use_unsafe_shell=True)
    module_mock.get_bin_path.return_value = None


# Generated at 2022-06-20 19:55:56.665534
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.basic import AnsibleModule

    # Test for check for systemd
    module = AnsibleModule(
        argument_spec=dict()
    )
    ServiceMgrFactCollector.is_systemd_managed(module=module)


# Generated at 2022-06-20 19:56:03.422537
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    class Module(object):
        def __init__(self):
            self.run_command = None
            self.get_bin_path = None
        def get_bin_path(self, bin_name):
            return "/usr/bin/" + bin_name

    module = Module()
    smfc = ServiceMgrFactCollector(module=module)
    assert smfc.is_systemd_managed(module) == True


# Generated at 2022-06-20 19:56:11.071025
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    test_cases = {
        '/sbin/init': False,
        '/sbin/init -> /lib/systemd/systemd': True,
    }
    class module:
        @staticmethod
        def get_bin_path(path):
            return path

    for path, result in test_cases.items():
        assert(ServiceMgrFactCollector.is_systemd_managed_offline(module=module, init_path=path) == result)

# Generated at 2022-06-20 19:56:31.929887
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    collector = ServiceMgrFactCollector()
    assert isinstance(collector, ServiceMgrFactCollector)
    assert not collector.is_systemd_managed_offline({})

# Generated at 2022-06-20 19:56:35.250892
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.required_facts == set(['platform', 'distribution'])
    assert obj.collect() is not None

# Generated at 2022-06-20 19:56:42.036577
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, executable):
            return None

        def run_command(self, cmd, use_unsafe_shell):
            return 1, 'Command failed', 'error'

    sut = ServiceMgrFactCollector()
    assert isinstance(sut, BaseFactCollector), 'is an instance of ServiceMgrFactCollector'
    assert isinstance(sut, Collector), 'is an instance of Collector'
    assert hasattr(sut, 'name'), "has 'name' attribute"
    assert sut.name

# Generated at 2022-06-20 19:56:52.168670
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    '''Unit test for method collect of class ServiceMgrFactCollector'''
    # Mock module class, required for is_systemd_managed
    class ModuleUtilMock(object):
        @staticmethod
        def get_bin_path(name_):
            return 'systemctl'
    # Create instance of ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # Create fake module instance
    module_mock = ModuleUtilMock()
    # Create instance of class with test data
    service_mgr_data = {
        'platform': 'Linux',
        'distribution': 'Debian'
    }
    # Test service_mgr_fact_collector.collect()

# Generated at 2022-06-20 19:57:02.760719
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Test is_systemd_managed
    assert ServiceMgrFactCollector.is_systemd_managed(None) is False
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False

    # Test is_systemd_managed_offline on Solaris
    if platform.system() != 'SunOS':
        assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False
    
    # Test is_systemd_managed on Solaris

# Generated at 2022-06-20 19:57:14.035139
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class MockedModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, "/bin/systemctl", ""),
                (0, "/bin/systemctl", ""),
                (0, "/bin/systemctl", ""),
                (0, "/bin/systemctl", ""),
                (0, "/bin/systemctl", ""),
            ]
            self.run_command_call_count = 0

        def get_bin_path(self, _):
            return "/bin/systemctl"


# Generated at 2022-06-20 19:57:24.529789
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class TestModule:
        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            print(args)
            print(kwargs)
            raise Exception(args)

        def get_bin_path(self, *args, **kwargs):
            return None

        def run_command(self, *args, **kwargs):
            return (0, None, None)

        def get_file_content(self, *args, **kwargs):
            return None

    class TestFactCollector:
        def __init__(self, params):
            self.params = params

    _FactsCollectorModule = ServiceMgrFactCollector()

    _collector = ServiceMgrFactCollector()
    test_module = TestModule({})
    test_fact

# Generated at 2022-06-20 19:57:36.041667
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a mock SystemModule
    class SystemModuleMock():
        def get_bin_path(self, command):
            if command == 'systemctl':
                return '/bin/systemctl'
            return None

        def run_command(self, command, use_unsafe_shell=None):
            return 0, '', None

    system_module_mock = SystemModuleMock()

    # Create a mock module
    class ModuleMock():
        def __init__(self):
            self.running_systemd = True

    module_mock = ModuleMock()

    # We are using /bin/systemctl and the run_command returns data so we are expecting systemd to be running
    assert ServiceMgrFactCollector.is_systemd_managed(module_mock, system_module_mock)

# Generated at 2022-06-20 19:57:40.987218
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed
            self.is_systemd_managed_offline = ServiceMgrFactCollector.is_systemd_managed_offline
            self.get_bin_path = lambda x : None

    mock_module = MockModule()

    mfc = ServiceMgrFactCollector(module=mock_module)
    mfc.collect()

# Generated at 2022-06-20 19:57:43.607689
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
  spfc = ServiceMgrFactCollector()
  assert spfc.name == 'service_mgr'

# Generated at 2022-06-20 19:58:15.347941
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Module invocation to validate execution
    module_args = {
        'path' : [
            '/bin',
            '/usr/bin',
            '/sbin',
            '/usr/sbin'
        ]
    }

    module_exit_json = {
        'ansible_facts': {
            'ansible_path': [
                '/bin',
                '/usr/bin',
                '/sbin',
                '/usr/sbin'
            ],
            'ansible_service_mgr': 'service'
        },
        'changed': False
    }

    module_exit_skipped = {
        'ansible_facts': {},
        'skipped': True
    }

    # Populate module params
    # Instanciate ServiceMgrFactCollector class
    class_instance = ServiceMgrFactCollector()

# Generated at 2022-06-20 19:58:26.503160
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    from ansible.module_utils.facts.collector import get_collector_instance


# Generated at 2022-06-20 19:58:29.242002
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Test the constructor of ServiceMgrFactCollector
    ServiceMgrFactCollector()

# Generated at 2022-06-20 19:58:36.991629
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """Unit test for method is_systemd_managed of class ServiceMgrFactCollector"""
    import tempfile

    class MockModule:
        """Mock module class for testing method is_systemd_managed of class ServiceMgrFactCollector"""
        def __init__(self):
            self.run_command = lambda cmd, args: (0, '', '')
            self.get_bin_path = lambda name: os.path.join(tempfile.gettempdir(), name)

    mock_module = MockModule()
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module) is False

# Generated at 2022-06-20 19:58:48.423514
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys
    import ansible.utils.display
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self._name = 'service_mgr'
            self.check_mode = False
            self.debug = False
            self.verbosity = 3
            self.no_log = False
            self.logger = ''
            self.warning = ''
            self.env = ''
            self.args = ''
            sys.modules['ansible.module_utils.facts.collector'] = ''

        def get_bin_path(self,name):
            return 'bin_%s' % name

        def run_command(self,cmd,use_unsafe_shell=True):
            return 'run_command_%s' % cmd

# Generated at 2022-06-20 19:58:55.277385
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    '''Unit test for constructor of class ServiceMgrFactCollector'''
    collector = ServiceMgrFactCollector()
    assert collector.name == 'service_mgr'
    assert collector._fact_ids == set()
    assert collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:58:59.927823
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.name == 'service_mgr'
    assert fact_collector._fact_ids == set()
    assert fact_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:59:01.530754
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fc = ServiceMgrFactCollector({})
    assert fc
    assert fc.name == 'service_mgr'
    assert fc.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-20 19:59:13.227186
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    mock_module = MockModule()
    mock_module.run_command.return_value = (0, '{"Status":"inactive","Result":"unknown"}', '')
    mock_module.get_bin_path.return_value = True
    collector = ServiceMgrFactCollector()
    # Test case where is_systemd_managed returns True
    assert collector.is_systemd_managed(mock_module)
    mock_module.get_bin_path.assert_called_with('systemctl')
    mock_module.run_command.assert_called_with('systemctl is-system-running 2>/dev/null', use_unsafe_shell=True)
    # Test case where is_systemd_managed returns False
    mock_module.get_bin_path.return_value = False
    assert not collector.is_systemd

# Generated at 2022-06-20 19:59:19.667724
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys
    import tempfile

    # Imports required for mocking
    import mock
    import ansible.module_utils.basic

    # import module code
    sys.path = [os.path.join(os.getcwd(), "platform", "systemd")] + sys.path
    exec("from systemd_facts import ServiceMgrFactCollector")

    # Mocking
    # Create temporary file
    tmp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".ini")
    tmp_file.close()
    # Generate fake systemctl executable
    fake_systemctl = "/usr/bin/systemctl"
    with open(fake_systemctl, "w"):
        pass
    # Generate fake init executable
    fake_init = "/sbin/init"

# Generated at 2022-06-20 20:00:01.048069
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    facts_collector = Collector(None)
    facts_dict = {
        'ansible_distribution': 'MacOSX',
    }
    facts_collector.custom_facts_cache = facts_dict
    service_mgr_collector = ServiceMgrFactCollector(facts_collector)
    result_dict = service_mgr_collector.collect()
    assert {'service_mgr': 'launchd'} == result_dict

if __name__ == '__main__':
    # Unit test
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-20 20:00:05.508483
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
  x = ServiceMgrFactCollector(None)
  assert x
  assert x.name == 'service_mgr'
  assert x.required_facts == set(['platform', 'distribution'])
  assert x._fact_ids == set()


# Generated at 2022-06-20 20:00:12.462916
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class ModuleDouble:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, bin):
            if bin == 'systemctl':
                return '/bin/systemctl'
            return None

        def run_command(self, cmd, use_unsafe_shell=False):
            return (0, '', '')

    class CollectedFactsDouble:
        def __init__(self):
            self.ansible_facts = {
                'ansible_system': 'Linux',
                'ansible_distribution': 'Ubuntu',
            }

    assert ServiceMgrFactCollector().collect(ModuleDouble(), CollectedFactsDouble()) == {'service_mgr': 'systemd'}

# Generated at 2022-06-20 20:00:18.722416
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = AnsibleModuleMock()
    instance = ServiceMgrFactCollector()

    # Case 1: systemctl cannot be found in PATH
    instance.is_systemd_managed_offline(module=None)

    # Case 2: systemctl found but /sbin/init is not a symlink to systemd
    module.get_bin_path = MagicMock(return_value='/bin/systemctl')
    os.path.islink = MagicMock(return_value=False)
    instance.is_systemd_managed_offline(module)

    # Case 3: systemctl found and /sbin/init is a symlink to systemd
    module.get_bin_path = MagicMock(return_value='/bin/systemctl')
    os.path.islink = MagicMock(return_value=True)


# Generated at 2022-06-20 20:00:22.548192
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    test_paths = {
        'systemctl': None,
        '/sbin/init': '/lib/systemd/systemd'
    }

    def fake_get_bin_path(binname):
        return test_paths[binname]

    # setup module_utils.basic.AnsibleModule.get_bin_path()
    module_name = 'ansible.module_utils.facts.system.service_mgr'
    module = __import__(module_name, fromlist=['AnsibleModule'])
    module.AnsibleModule.get_bin_path = fake_get_bin_path

    # test
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module.AnsibleModule) == True

# Generated at 2022-06-20 20:00:26.272744
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collectors.system.service_mgr

    c = ansible.module_utils.facts.collectors.system.service_mgr.ServiceMgrFactCollector()

    class MockModule(object):
        def get_bin_path(self, pathname):
            return '/bin/systemctl'

    test_module = MockModule()

    def fake_os_readlink(path):
        if path == '/sbin/init':
            return 'systemd'
        return ''

    c._original_os_readlink = os.readlink
    os.readlink = fake_os_readlink

    service_mgr_name = c.is_systemd_managed_offline(test_module)

    assert service_mgr_name == True

    os.readlink = c._original_

# Generated at 2022-06-20 20:00:36.808051
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import FactCollector

    module = basic.AnsibleModule(
        argument_spec = dict(
            data=dict(required=False, type='dict', default=dict()),
        ),
        supports_check_mode=False,
    )
    mm = module._socket_path = None

    # Stub module is defaulted to 'linux'
    fc = FactCollector(module=module)
    fc.collect_platform_facts()
    fc.collect_distribution_facts()
    fact_collector = ServiceMgrFactCollector(module=module)

    module.run_command = lambda cmd: (0, '/sbin/init', '')
    facts = fact_collector.collect(module=module)

# Generated at 2022-06-20 20:00:47.786559
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.service_mgr as service_mgr_collector
    import ansible.module_utils.facts.utils as utils

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    def get_file_content(file_name):
        if (file_name == '/proc/1/comm'):
            return 'systemd'
        return None

    # Test that is_systemd_managed returns True if /proc/1/comm is systemd
    module = MockModule()
    service_mgr_collector.get_file_content = get_file_content
    systemd_managed = service_mgr_collector.ServiceMgrFactCollector.is_systemd_managed(module)
    assert systemd_managed


# Generated at 2022-06-20 20:00:50.356775
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()
    assert s.name == "service_mgr"
    assert s.required_facts == set(['platform', 'distribution'])
    assert s._fact_ids == set()


# Generated at 2022-06-20 20:00:53.507499
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'

# Generated at 2022-06-20 20:02:33.576147
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class TestModule(object):
        def __init__(self, *args, **kwargs):
            self.__dict__.update(kwargs)
            self.params = {
                'gather_subset': '!all',
                'gather_timeout': 10,
            }
            self.args = None
            self.fail_json = False

        def run_command(self, args, use_unsafe_shell=False):
            return 0, "", ""

        def get_bin_path(self, path):
            return ''

    mod = TestModule()

    service_mgr_fact_collector = ServiceMgrFactCollector()
    platform_fact_collector = ServiceMgrFactCollector()

    service_mgr_fact_collector.collect(mod, platform_fact_collector.collect(mod))

# Generated at 2022-06-20 20:02:44.699684
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    def _mock_module(name):
        mock = MagicMock()
        mock.get_bin_path = MagicMock(return_value=name)
        return mock

    class _MockModule(object):
        pass

    mock_module = _mock_module("initctl")

    mock_module.run_command = MagicMock(return_value=[0, 'initctl', ''])
    mock_module.get_bin_path = MagicMock(return_value='initctl')

    mock_facts = {'platform': 'Linux', 'ansible_system': 'Linux', 'distribution': 'Fedora'}
    facts = ServiceMgrFactCollector().collect(mock_module, mock_facts)
    assert facts['service_mgr'] == 'upstart'


# Generated at 2022-06-20 20:02:46.915450
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert issubclass(ServiceMgrFactCollector, BaseFactCollector)

# Generated at 2022-06-20 20:02:53.694492
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert isinstance(service_mgr_fact_collector.required_facts, set)
    assert isinstance(service_mgr_fact_collector._fact_ids, set)
    assert service_mgr_fact_collector.name == 'service_mgr'


# Generated at 2022-06-20 20:03:00.509477
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Mock module import
    module = MagicMock()
    module.run_command = MagicMock(side_effect=[[0, 'init', ''], [0, 'COMMAND', ''], [127, '', ''], [127, '', ''], [0, 'systemd', ''], [0, 'init', '']])
    module.get_bin_path = MagicMock(side_effect=[True, False, False, False])
    mock_platform_system = MagicMock(side_effect=['Linux', 'Linux', 'SunOS'])
    mock_platform_distribution = MagicMock(side_effect=['', '', ['RedHat'], ['RedHat'], ['Debian'], ['Debian']])
    mock_is_systemd_managed = MagicMock(side_effect=[True, False, False])

# Generated at 2022-06-20 20:03:04.260968
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector_obj = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_obj.name == 'service_mgr'
    assert service_mgr_fact_collector_obj.required_facts == set(['platform', 'distribution'])
    assert service_mgr_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-20 20:03:15.301776
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = 'fake_module'

    def fake_get_bin_path(name):
        if name == 'systemctl':
            return 'fake_path'
        return None

    test_data = {
        'is_systemd_managed_offline': True,
        'is_systemd_managed_offline_condition': [
            {
                'name': '/sbin/init',
                'is_link': True,
                'readlink': '/lib/systemd/systemd'
            }
        ]
    }

    # Generate fake_module
    fake_module = type('fake_module', (object,), {})
    for attr in test_data:
        setattr(fake_module, attr, test_data[attr])
    fake_module.get_bin_path = fake_get_bin_