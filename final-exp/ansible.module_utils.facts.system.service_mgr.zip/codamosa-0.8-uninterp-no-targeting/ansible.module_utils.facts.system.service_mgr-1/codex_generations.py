

# Generated at 2022-06-20 19:53:43.119905
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import ModuleCollector
    mc = ModuleCollector()
    mc.get_module = lambda x: None # a lambda function to just return an empty module, it does nothing when called
    facts = ServiceMgrFactCollector()
    assert facts.is_systemd_managed(module = mc) is False


# Generated at 2022-06-20 19:53:46.296804
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    mock_module = type('MockModule', (object,), {})
    mock_module.get_bin_path = lambda self, x: False
    service_mgr = ServiceMgrFactCollector()
    facts = service_mgr.collect(mock_module)
    assert facts['service_mgr'] == 'service'
    assert not service_mgr.is_systemd_managed(mock_module)
    assert not service_mgr.is_systemd_managed_offline(mock_module)

# Generated at 2022-06-20 19:53:58.683023
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    # create a fake file
    open('/sbin/init', 'a').close()

    # fake 'systemctl' command
    systemctl_cmd = os.path.join(tmpdir, 'systemctl')
    open(systemctl_cmd, 'a').close()
    os.chmod(systemctl_cmd, 0o0755)

    # Test without symlink to systemd
    module = BaseFactCollector(module_name='module', module_args={})
    collector = ServiceMgrFactCollector(module)

# Generated at 2022-06-20 19:54:08.048764
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    test_service_mgr = ServiceMgrFactCollector()
    test_module = False
    class TestModule:
        def get_bin_path(self, arg1):
            return arg1
    if test_service_mgr.is_systemd_managed_offline(TestModule()):
        assert True
    else:
        assert False
    # test with systemd-sysvinit not installed on SUSE.
    class TestModule2:
        def get_bin_path(self, arg1):
            return False
        os.symlink('/sbin/init','test')
        if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
            test_module = True
    if test_module:
        assert True

# Generated at 2022-06-20 19:54:12.590371
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector._fact_ids == set()
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:54:14.533454
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False

# Generated at 2022-06-20 19:54:21.278375
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, command):
            return '/bin/' + command

    # testing systemd detection
    collector = ServiceMgrFactCollector()

    module = MockModule()

    platform_system = platform.system()
    platform_mac_ver = platform.mac_ver()[0]
    ansible_system = 'SomeSystem'
    ansible_distribution = 'OpenWrt'
    setattr(module, 'run_command', lambda cmd: (0, 'systemd', None))

    facts_dict = collector.collect(module)
    assert len(facts_dict) == 1
    assert facts_dict['service_mgr'] == 'systemd'

    # testing upstart detection
    collector = ServiceMgrFact

# Generated at 2022-06-20 19:54:29.330415
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """Unit test for method collect of class ServiceMgrFactCollector."""
    import ansible.module_utils

    ansible.module_utils.basic.AnsibleModule = None
    ansible.module_utils.command_spec = None

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import (
        Collector,
    )

    from ansible.module_utils.basic import AnsibleModule

    # Dummy instance of ServiceMgrFactCollector class.
    sf = ServiceMgrFactCollector()

    # Dummy instance of AnsibleModule class.
    module = AnsibleModule(argument_spec={})

    # Assert that ansible facts directory is empty before running the is_systemd_managed method.
    collected_facts = {}

    #

# Generated at 2022-06-20 19:54:34.580664
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # GIVEN:
    # Mock the module.run_command() method.
    mock_module = type('MockModule', (object,), {
        'get_bin_path': lambda self, command: command == 'systemctl',
        'run_command': lambda self, command: [0, 'offline_systemd', '']
    })()

    # WHEN:
    result = ServiceMgrFactCollector.is_systemd_managed_offline(mock_module)

    # THEN:
    assert result == True


# Generated at 2022-06-20 19:54:39.691788
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    test_collector = ServiceMgrFactCollector()
    assert test_collector.name == 'service_mgr'
    assert test_collector._fact_ids == set()
    assert test_collector.required_facts == set(['platform', 'distribution'])
    test_collector.collect()

# Generated at 2022-06-20 19:55:00.880531
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    collector = ServiceMgrFactCollector()

    assert isinstance(collector, ServiceMgrFactCollector)
    assert isinstance(collector, BaseFactCollector)
    assert collector.name == 'service_mgr'
    assert len(collector._fact_ids) == 0
    assert isinstance(collector.required_facts, set)
    assert len(collector.required_facts) == 2


# Generated at 2022-06-20 19:55:04.905638
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ansible_input = {'ansible_system': 'Linux', 'ansible_distribution': 'OpenWrt'}
    correct_output = {'service_mgr': 'openwrt_init'}

    collector = ServiceMgrFactCollector()
    collected_facts = collector.collect(collected_facts=ansible_input)

    assert collected_facts == correct_output

# Generated at 2022-06-20 19:55:09.902949
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])
    assert ServiceMgrFactCollector._fact_ids == set()
    assert ServiceMgrFactCollector.is_systemd_managed(None) is False
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False
    assert ServiceMgrFactCollector.collect() == {}

# Generated at 2022-06-20 19:55:12.510333
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Test case for class method "collect" of class ServiceMgrFactCollector.
    """
    pass

# Generated at 2022-06-20 19:55:23.259723
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # See /usr/share/doc/systemd/README.Debian
    # and /lib/systemd/systemd --test --system
    # and http://0pointer.de/blog/projects/os-release.html

    mock_module = MockModule({})

    # It could be Debian with systemd on its
    # way out and /run is tmpfs
    mock_module.command_results[0]['rc'] = 0
    mock_module.command_results[0]['cmd'] = "/bin/true"
    mock_module.command_results[0]['stdout'] = "/run/systemd/system/"
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module)

    # Here is the Debian case

# Generated at 2022-06-20 19:55:27.646496
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    mock_module = MockModule()
    service_mgr_col = ServiceMgrFactCollector(mock_module)
    assert service_mgr_col.name == 'service_mgr'


# Generated at 2022-06-20 19:55:34.116804
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class Module:
        def get_bin_path(self, command):
            if command == "systemctl":
                return "/bin/systemctl"

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, "", ""


    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.is_systemd_managed(Module())
    assert not service_mgr.is_systemd_managed(Module())

# Generated at 2022-06-20 19:55:46.531127
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import DictModule
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector


# Generated at 2022-06-20 19:55:48.114128
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()
    assert isinstance(s, ServiceMgrFactCollector)

# Generated at 2022-06-20 19:55:48.998289
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()

# Generated at 2022-06-20 19:56:11.533683
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # this is a dict of yet not collected facts
    collected_facts = {}

    # this is a dict of facts which we will inject into ServiceMgrFactCollector
    injected_facts = {}

    # now create a ServiceMgrFactCollector instance with the injected facts and run collect method
    ServiceMgrFactCollector(injected_facts).collect(collected_facts)

    # ensure that the collected facts and injected facts are equal
    injected_facts.update(collected_facts)
    assert ServiceMgrFactCollector(injected_facts).collect() == injected_facts

# Generated at 2022-06-20 19:56:24.620377
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockModule()
    collector = ServiceMgrFactCollector()

    # Case 1 - Systemd is installed
    module.get_bin_path.return_value = True
    os.path.islink.return_value = True
    os.readlink.return_value = 'systemd'
    assert collector.is_systemd_managed_offline(module)

    # Case 2 - Systemd is not installed
    module.get_bin_path.return_value = None
    os.path.islink.return_value = True
    os.readlink.return_value = 'systemd'
    assert not collector.is_systemd_managed_offline(module)

    # Case 3 - Systemd is installed, but /sbin/init is not symlink to systemd

# Generated at 2022-06-20 19:56:26.139740
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False

# Generated at 2022-06-20 19:56:32.804311
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    fact_collector = ServiceMgrFactCollector()
    # Create fake module
    module = type('', (), {})()
    # Collect the service manager facts
    result = fact_collector.collect(module)
    # Check that the result is a dictionary
    assert isinstance(result, dict)
    # Check that the result has the required keys
    assert set(result.keys()) >= set(['service_mgr'])

# Generated at 2022-06-20 19:56:38.592367
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.name == 'service_mgr'
    assert service_mgr.required_facts == set(['platform', 'distribution'])
    assert service_mgr._fact_ids == set()


# Generated at 2022-06-20 19:56:50.123499
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os
    import sys

    class AnsibleModuleMock():
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, binary):
            if binary == 'systemctl':
                return '/bin/systemctl'

        def get_tmp_path(self):
            return '/tmp/systemctltmpdir'

        def run_command(self, command, use_unsafe_shell=True):
            if command == '/bin/systemctl --system is-enabled systemd-sysv-install':
                return 0, 'enabled', ''
            elif command == '/bin/systemctl is-enabled systemd-sysv-install':
                return 0, 'enabled', ''

# Generated at 2022-06-20 19:57:00.639058
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class FakeModule:
        def __init__(self):
            self.paths = {'binaries': []}

        def get_bin_path(self, binary_name):
            return os.path.join('/usr/bin', binary_name)
            # return binary_name in self.paths['binaries']

    module = FakeModule()

    for init_file in ['systemd', 'sy']:
        os.symlink('/lib/systemd/systemd', '/sbin/init')
        assert ServiceMgrFactCollector.is_systemd_managed_offline(module=module)

        # restore /sbin/init
        os.remove('/sbin/init')


# Generated at 2022-06-20 19:57:06.348655
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr = ServiceMgrFactCollector()
    assert 'service_mgr' == service_mgr.name
    assert 'service_mgr' in service_mgr._fact_ids
    assert 'platform' in service_mgr.required_facts
    assert 'distribution' in service_mgr.required_facts

# Generated at 2022-06-20 19:57:16.036964
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import collections

    mock_module = collections.namedtuple("MockModule", ["get_bin_path", "run_command"])
    mock_run_command = collections.namedtuple("MockRunCommand", ["rc", "err", "stdout"])
    mock_get_file_content = collections.namedtuple("MockGetFileContent", ["output"])
    facts = dict()

    # Mocking get_bin_path method of the module
    def mock_get_bin_path(executable):
        if executable == "systemctl":
            return "/bin/systemctl"
        return None
    mock_module.get_bin_path = mock_get_bin_path

    # Mocking run_command method of the module

# Generated at 2022-06-20 19:57:24.893661
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collectors.service_mgr
    import tempfile
    import os

    tmpDir = tempfile.gettempdir()
    os.symlink("/lib/systemd/systemd", os.path.join(tmpDir, "init"))
    assert ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector.is_systemd_managed_offline(None)
    os.unlink(os.path.join(tmpDir, "init"))
    assert not ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector.is_systemd_managed_offline(None)

# Generated at 2022-06-20 19:58:07.709450
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # See:
    # https://docs.pytest.org/en/latest/example/simple.html#control-skipping-of-test-functions-according-to-command-line-option
    import pytest
    # Skip test if we are running on Windows
    # https://docs.pytest.org/en/latest/skipping.html#skip-tests-according-to-command-line-option
    pytestmark = pytest.mark.skipif(platform.system() == "Windows", reason="Requires Linux")
    # mock module
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr_offline
    import ansible.module_utils.facts.system.systemd_managed

# Generated at 2022-06-20 19:58:16.207302
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector
    class MockModule(object):
        def __init__(self):
            self.bin_path = '/usr/bin/'

    module = MockModule()
    service_mgr = ServiceMgrFactCollector()

    # Running system should not return True
    result = service_mgr.is_systemd_managed_offline(module=module)
    assert result is False

    # Testing symlink of /sbin/init to systemd
    import os
    os.symlink('systemd', '/sbin/init')
    result = service_mgr.is_systemd_managed_offline(module=module)
    assert result is True

    # Remove symlink of /sbin/init to systemd

# Generated at 2022-06-20 19:58:28.156344
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys
    # Mock Module class
    class MockModule(object):

        def __init__(self):
            self.run_command_results = [(0, "systemd\n", ""), (0, "init\n", "")]
            self.run_command_calls = 0

        def get_bin_path(self, arg1):
            return arg1
        def run_command(self, arg1, arg2):
            if arg1 == "readlink -f /sbin/init":
                self.run_command_calls += 1
                return self.run_command_results[self.run_command_calls - 1]
            else:
                sys.exit(1)

    module = MockModule()

    fact_collector = ServiceMgrFactCollector()
    results = fact_collector.is_

# Generated at 2022-06-20 19:58:31.985466
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """
    Test the constructor ServiceMgrFactCollector()
    """
    assert ServiceMgrFactCollector().name == 'service_mgr'
    assert ServiceMgrFactCollector()._fact_ids == set()
    assert ServiceMgrFactCollector().required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:58:38.128126
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a mock module
    mock_module = MockModule()

    mock_module.params = {}
    mock_module.paths.update({'/usr/sbin':['systemctl']})
    #mock_module.run_command = Mock(side_effect=lambda x: (0, x, None))

    collector = ServiceMgrFactCollector
    # Test on a system that has systemd
    assert collector.is_systemd_managed(mock_module) == True
    # Test on a system that hasn't systemd
    mock_module.paths.update({'/usr/sbin':[]})
    assert collector.is_systemd_managed(mock_module) == False


# Generated at 2022-06-20 19:58:42.986310
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts import Collector

    # collect facts
    facts_dict = Collector().collect(module=None, collected_facts=dict())

    # test if facts were collected properly
    assert 'ansible_distribution' in facts_dict
    assert 'ansible_system' in facts_dict
    assert 'service_mgr' in facts_dict

# Generated at 2022-06-20 19:58:51.393224
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    import module_utils.facts.service_mgr


# Generated at 2022-06-20 19:58:55.797030
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    facts_dict = {}
    service_mgr = ServiceMgrFactCollector()
    ret = service_mgr.is_systemd_managed(None)
    assert ret == False


# Generated at 2022-06-20 19:58:59.532766
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils import basic  # unittest doesn't seem to support import module from non-root directory
    facts_dict = {}
    test_object = ServiceMgrFactCollector(basic.AnsibleModule(facts=facts_dict))
    assert test_object.name == 'service_mgr'
    assert test_object._fact_ids == set()
    assert test_object.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:59:09.156031
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.system.service_mgr import ServiceMgrFactCollector as service_mgr_collector

    system_collector = Collector.create_instance('system')
    system_collector.collect()

    # test collect function (possible to write a test calling collect)
    service_mgr_collector_inst = service_mgr_collector()
    service_mgr_collector_inst.collect()



# Generated at 2022-06-20 20:00:17.877553
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector.service_mgr as sm
    import ansible.module_utils.facts.system_platform as sp
    import os

    # no systemd
    #
    # create a fake module
    module = sp.SystemPlatform()
    module.get_bin_path = lambda x: None
    if not os.path.exists('/run/systemd/system'):
        os.makedirs('/run/systemd/system')
    # create a fake result and pass it to the method
    result = {
        'service_mgr': None,
        'system': 'Linux',
    }
    # run the method
    outcome = sm.ServiceMgrFactCollector.is_systemd_managed(module=module)
    # run the test

# Generated at 2022-06-20 20:00:30.315068
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = AnsibleModuleMock()
    module.get_bin_path = MagicMock(return_value=None)
    result = ServiceMgrFactCollector.is_systemd_managed(module)
    assert result == False

    module.get_bin_path = MagicMock(return_value='systemctl')
    result = ServiceMgrFactCollector.is_systemd_managed(module)
    assert result == False

    module.get_bin_path = MagicMock(return_value='systemctl')
    os.path.exists = MagicMock(return_value=False)
    result = ServiceMgrFactCollector.is_systemd_managed(module)
    assert result == False

    module.get_bin_path = MagicMock(return_value='systemctl')
    os.path.exists = Magic

# Generated at 2022-06-20 20:00:39.803881
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.system.service_mgr

    collector = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector()
    sysvinit_module = MagicMock()
    sysvinit_module.get_bin_path.return_value = "/sbin/init"
    systemd_module = MagicMock()
    systemd_module.get_bin_path.return_value = "/lib/systemd/systemd"

    def os_path_islink(path):
        return path == "/sbin/init"

    def os_readlink(path):
        if path == "/sbin/init":
            return "/lib/systemd/systemd"

    class MockModule(object):
        def __init__(self):
            self.run_command = MagicMock

# Generated at 2022-06-20 20:00:47.917512
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class module(object):
        def get_bin_path(self, binary):
            binary_path = '/bin/systemctl'
            return binary_path

    collected_facts = {}
    collected_facts['ansible_system'] = 'Linux'
    service_manager = ServiceMgrFactCollector()
    assert False == service_manager.is_systemd_managed_offline(module)


# Generated at 2022-06-20 20:00:58.426972
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule():
        def __init__(self):
            self.params = {}

        def get_bin_path(self, command, required=False, opt_dirs=[]):
            return '/bin/' + command

        # This method is not used by ServiceMgrFactCollector()

# Generated at 2022-06-20 20:01:02.020968
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc.name == 'service_mgr'
    assert smfc._fact_ids == set()
    assert smfc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 20:01:11.895236
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule:
        class MockOS:
            path = '/sbin/init'
            stat_result = None

        class MockLStat(object):
            st_mode = 0o100

        class MockStat(object):
            st_mode = 0o100

        def __init__(self, path, stat_result):
            self.os = self.MockOS
            self.os.path = path
            self.os.stat_result = stat_result

        def lstat(self, path):
            return self.stat_result

        def stat(self, path):
            return self.stat_result

        def readlink(self, path):
            return os.path.basename(path)

        def exists(self, path):
            return True

    # run these tests on Linux

# Generated at 2022-06-20 20:01:22.377659
# Unit test for method collect of class ServiceMgrFactCollector

# Generated at 2022-06-20 20:01:31.898590
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class FakeAnsibleModule(object):
        def __init__(self, bin_path=None):
            self._bin_path = bin_path

        def get_bin_path(self, executable):
            return self._bin_path

    class FakeOs(object):
        def __init__(self, path_exists=None):
            self._path_exists = path_exists


# Generated at 2022-06-20 20:01:42.995517
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import is_systemd_managed_offline
    from ansible.module_utils.facts.system.service_mgr import is_systemd_managed
    import os
    import shutil
    import tempfile

    # Create a temporary directory and a symbolic link named systemd to it
    tmpdir = tempfile.mkdtemp()
    os.symlink(tmpdir, "/sbin/init")

    # Create the fake Systemd-managed filesystem tree