

# Generated at 2022-06-20 19:53:45.526723
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import unittest2 as unittest
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    class TestServiceMgrFactCollector(unittest.TestCase):
        def test_is_systemd_managed_smoke_test(self):
            ServiceMgrFactCollector.is_systemd_managed(None)

        def test_is_systemd_managed_offline_smoke_test(self):
            ServiceMgrFactCollector.is_systemd_managed_offline(None)

    unittest.main()

# Generated at 2022-06-20 19:53:48.873911
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Instantiate a module
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    x = ServiceMgrFactCollector(module)
    assert x is not None

# Generated at 2022-06-20 19:54:01.112821
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    FakeModule.run_command = lambda self, arg: (0, 'systemd', '')
    FakeModule.get_bin_path = lambda self, arg: '/bin/systemctl'

    FakeBaseFactCollector = FakeBase(BaseFactCollector)

    def fake_open(self, file, mode):
        return OpenFake(file, mode)


# Generated at 2022-06-20 19:54:07.515176
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.service_mgr as service_mgr
    import ansible.module_utils.facts.system.linux as linux

    os_system = 'Linux'

    if os_system == 'Linux':
        module = linux.LinuxHardware()
    else:
        module = None

    service_mgr_collector = service_mgr.ServiceMgrFactCollector()

    if service_mgr_collector.is_systemd_managed(module):
        print('System is systemd managed')
    else:
        print('System is not systemd managed')

# Generated at 2022-06-20 19:54:11.161053
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_collector = ServiceMgrFactCollector()
    assert not service_mgr_collector.is_systemd_managed_offline(module=None)

# Generated at 2022-06-20 19:54:19.729206
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile

    my_obj = ServiceMgrFactCollector()
    my_module = AnsibleModule(argument_spec={'include': dict(required=False, type='list')})
    # We need a directory to mock os.path.exists, so we use a temporary
    # directory.
    tmpdir = tempfile.mkdtemp()

    # Empty temporary directory in order to "not find" the directories we
    # want to test for.
    for d in ['/sbin/init', '/run/systemd/system', '/dev/.run/systemd', '/dev/.systemd']:
        try:
            os.unlink(os.path.join(tmpdir, d))
        except:
            pass

    my_module.run_command = lambda *args, **kwargs: (0, 'systemd', None)


# Generated at 2022-06-20 19:54:27.985148
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test_platforms = [
        # (system, is_booted_into_systemd)
        ('Linux', False),
        ('Linux', True),
        ('Linux', False),
        ('Linux', False),
        ('Linux', True),
        ('Linux', True),
        ('Darwin', False),
        ('DragonFly', False),
        ('SunOS', False),
        ('FreeBSD', False),
        ('AIX', False),
        ('OpenWrt', False),
        ('Bitrig', False),
    ]

# Generated at 2022-06-20 19:54:34.728672
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Create a ServiceMgrFactCollector instance
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector._fact_ids == set()
    assert service_mgr_fact_collector.required_facts == set(['platform', 'distribution'])

if __name__ == '__main__':
    # Unit test
    test_ServiceMgrFactCollector()

# Generated at 2022-06-20 19:54:35.422415
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-20 19:54:39.976867
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-20 19:55:00.573622
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector._fact_ids == set()
    assert service_mgr_fact_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:55:08.110673
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector.init import InitFactCollector

    # test is_systemd_managed_offline when init is systemd
    systemd_init = InitFactCollector()
    init = {"name": "systemd"}
    systemd_init.collect(init=init)
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=init)

    # test is_systemd_managed_offline when init is not systemd
    sysvinit_init = InitFactCollector()
    init = {"name": "sysvinit"}
    sysvinit_init.collect(init=init)

# Generated at 2022-06-20 19:55:13.221703
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    test_ServiceMgrFactCollector_is_systemd_managed_offline method tests ServiceMgrFactCollector method is_systemd_managed_offline
    :return: no return
    """
    collector = ServiceMgrFactCollector()
    collector.is_systemd_managed_offline()

# Generated at 2022-06-20 19:55:16.951874
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector(None)
    assert smfc.name == 'service_mgr'
    assert smfc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:55:25.169479
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
    from ansible.module_utils.facts.collectors import BaseFactCollector
    service_mgr_name = ServiceMgrFactCollector()
    fact_collector = FactCollector()
    fact_collector.populate()
    assert isinstance(service_mgr_name, BaseFactCollector)
    assert service_mgr_name.name == 'service_mgr'
    assert service_mgr_name.required_facts == {'platform', 'distribution'}
    assert service_mgr_name._fact_ids == set()

# Generated at 2022-06-20 19:55:38.062942
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fake_module = lambda: None
    fake_module.is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed
    fake_module.is_systemd_managed_offline = ServiceMgrFactCollector.is_systemd_managed_offline
    fake_module.get_bin_path = lambda program: None
    fake_module.run_command = lambda _, use_unsafe_shell=None: (0, '', '')
    collected_facts = {
        'ansible_distribution': 'Ubuntu',
        'ansible_distribution_version': '14.04',
        'ansible_system': 'Linux',
        'platform': 'Linux',
    }
    expected_result = {'service_mgr': 'sysvinit'}
    fact_collector = ServiceMgrFact

# Generated at 2022-06-20 19:55:48.712618
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Mock module
    module = MockAnsibleModule()

    # create fake systemctl executable
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    tmpfile.close()
    os.chmod(tmpfile.name, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)
    module.run_command_environ["PATH"] = os.pathsep.join(os.environ["PATH"].split(os.pathsep) + [os.path.dirname(tmpfile.name)])

    # test without systemd in 'boot init system'
    def is_systemd():
        return False
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.is_systemd_managed(module) == is_systemd()


# Generated at 2022-06-20 19:55:54.714129
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert ServiceMgrFactCollector.is_systemd_managed(None) == False
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

# Generated at 2022-06-20 19:55:57.944467
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class Module():
        def get_bin_path(self, command):
            return '/usr/bin/' + command

    smfc = ServiceMgrFactCollector()
    smfc.is_systemd_managed(Module())

# Generated at 2022-06-20 19:56:07.736190
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector

    class MockModule:
        def get_bin_path(self, name):
            return "/bin/" + name

    module = MockModule()

    # /sbin/init is not a symlink to systemd
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # create a symlink of /sbin/init
    os.symlink("/bin/systemctl", "/sbin/init")

    # /sbin/init is a symlink to systemd
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # clean up
    os.remove("/sbin/init")

# Generated at 2022-06-20 19:56:42.432426
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    assert(ServiceMgrFactCollector.is_systemd_managed_offline(None) == False)

# Generated at 2022-06-20 19:56:44.329790
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()


# Generated at 2022-06-20 19:56:55.027922
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import tempfile
    import os

    class MockModule:
        def get_bin_path(self, path):
            # When path equals systemctl will return None and vice versa.
            # Else return a string that is equal to the path.
            if 'systemctl' == path:
                return None
            elif 'systemctl' == path:
                return path
            else:
                return path

        def run_command(self, cmd, *args, **kwargs):
            # The run_command function expects the arguments use_unsafe_shell=True
            # when using shell commands
            if 'COMMAND' == cmd:
                return 1, cmd, 'Error message'

            if 'ps -p 1 -o comm|tail -n 1' == cmd:
                return 0, cmd, 'Error messages'


# Generated at 2022-06-20 19:57:03.789617
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import os
    import shutil
    import contextlib
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    systemd_canary1 = "/dev/.run/systemd/"
    systemd_canary2 = "/dev/.systemd/"
    systemd_canary3 = "/run/systemd/system/"

    @contextlib.contextmanager
    def fake_root_dir():
        d = tempfile.mkdtemp()
        orig = os.environ.get('FAKE_ROOT_DIR', None)
        os.environ['FAKE_ROOT_DIR'] = d

# Generated at 2022-06-20 19:57:07.639495
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fact = ServiceMgrFactCollector()
    assert fact.name == 'service_mgr'
    assert fact._fact_ids == set()
    assert fact.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:57:16.655767
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Dummy object of AnsibleModule
    class AnsibleModule():
        def __init__(self):
            return None

    # Dummy object of AnsibleModule.run_command
    def run_command(self, cmd, use_unsafe_shell=False):
        return 0, "sbin/init", ""

    # Dummy object of AnsibleModule.get_bin_path
    def get_bin_path(self, cmd):
        return "path"

    setattr(AnsibleModule, 'run_command', run_command)
    setattr(AnsibleModule, 'get_bin_path', get_bin_path)

    # Test will fail if instantiation of this class raises exception
    service_mgr = ServiceMgrFactCollector()



# Generated at 2022-06-20 19:57:22.256660
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
    from ansible.module_utils.facts import UnitTestHelper

    module = UnitTestHelper(collector=ServiceMgrFactCollector, module_args='')
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

# Generated at 2022-06-20 19:57:24.232380
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    coll = ServiceMgrFactCollector()

    assert coll.is_systemd_managed_offline({}) is False



# Generated at 2022-06-20 19:57:35.476801
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # get instance of ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # mock the module
    module = MockSystemdModule()

    # test case 1: has systemctl and /run/systemd/system/ exist so return True
    module.systemctl = True
    module.systemd_path = '/run/systemd/system/'
    assert(service_mgr_fact_collector.is_systemd_managed(module))

    # test case 2: has no systemctl but /run/systemd/system/ exist so return True
    module.systemctl = False
    module.systemd_path = '/run/systemd/system/'
    assert(service_mgr_fact_collector.is_systemd_managed(module))

    # test case 3: has system

# Generated at 2022-06-20 19:57:42.456772
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    def run_test_for_is_systemd_managed_offline(test_case, module_parameters):
        from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector as service_mgr
        service_mgr.is_systemd_managed_offline.__dict__.clear()
        service_mgr.is_systemd_managed_offline.__dict__.update(module_parameters)
        expected_value = test_case['expected_value']

# Generated at 2022-06-20 19:59:01.433618
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    # Use a mock module to test this method
    m = ServiceMgrFactCollector()
    m.fail_json = lambda **args: {'msg': args}

    # Mock module.get_bin_path() for testing
    def mock_get_bin_path(bin_name):
        bin_name_to_path_map = {'systemctl': '/usr/bin/systemctl'}
        return bin_name_to_path_map.get(bin_name, None)
    m.get_bin_path = mock_get_bin_path

    # Mock os.path.exists() for testing

# Generated at 2022-06-20 19:59:13.176897
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleCollector

    class FakeModule:
        def __init__(self):
            self.run_command_count = 0
            self.run_command_calls = []
            self.run_command_results = {}

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            elif name == 'initctl':
                return '/bin/initctl'
            else:
                return None

        def run_command(self, command, use_unsafe_shell=False):
            self.run_command_count += 1
            self.run_command_calls.append((command, use_unsafe_shell))
            return self.run_command_results[(command, use_unsafe_shell)]

# Generated at 2022-06-20 19:59:18.750742
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = True
    os.path.islink.return_value = True
    os.readlink.return_value = 'systemd'
    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed_offline(module=module)
    module.get_bin_path.assert_called_once_with('systemctl')
    os.path.islink.assert_called_once_with('/sbin/init')
    os.readlink.assert_called_once_with('/sbin/init')


# Generated at 2022-06-20 19:59:27.815889
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class FakeModule(object):
        @staticmethod
        def get_bin_path(name):
            return name
    collected_facts = {
        "ansible_distribution": None,
        "ansible_system": None,
    }
    # Set the environment
    os.environ["PATH"] = "/sbin:/bin:/usr/sbin:/usr/bin"

    # Collect non-existing files to trigger system detection
    collector = ServiceMgrFactCollector()
    collector.collect(module=FakeModule(), collected_facts=collected_facts)


    # Set the environment
    os.environ["PATH"] = "/sbin:/bin:/usr/sbin:/usr/bin"

    # Collect non-existing files to trigger system detection
    collector = ServiceMgrFactCollector()

# Generated at 2022-06-20 19:59:37.597834
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a dummy class, which can be used for offline testing
    class DummyModule(object):
        def get_bin_path(self, cmd):
            if cmd == "systemctl":
                return "/usr/bin/systemctl" # Hardcoded, as most distros ship this
            else:
                return ""

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, "/usr/bin/systemd", None

    # Create a instance of ServiceMgrFactCollector to run the method as if it was run as a module
    collector = ServiceMgrFactCollector()
    collector.required_facts = set()

    # Create a fake module
    module = DummyModule()

    # Try to get the result of the ServiceMgrFactCollector.is_systemd_managed_offline method
    result

# Generated at 2022-06-20 19:59:46.233068
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.system.service_mgr
    fact_collector = collector.get_collector('system.service_mgr')
    assert isinstance(fact_collector, ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector)
    assert fact_collector.is_systemd_managed_offline(None) == False


# Generated at 2022-06-20 19:59:53.262535
# Unit test for method collect of class ServiceMgrFactCollector

# Generated at 2022-06-20 20:00:04.699252
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    coll = ServiceMgrFactCollector()

    def get_bin_path(program):
        return program

    def run_command(command, use_unsafe_shell=False):
        return 0, "/sbin/init -> /usr/lib/systemd/systemd", ""

    class FakeModule(object):
        get_bin_path = get_bin_path
        run_command = run_command

    # Test with file /sbin/init exists and it is a symlink to systemd
    os.symlink("/usr/lib/systemd/systemd", "/sbin/init")
    assert coll.is_systemd_managed_offline(FakeModule()) == True

    # Test with file /sbin/init exists and it is not a symlink to systemd
    os.unlink("/sbin/init")
   

# Generated at 2022-06-20 20:00:08.839536
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import MockModule
    service_mgr_name = "init"
    if platform.system() == 'Linux':
        service_mgr_name = "sysvinit"
    elif platform.system() == 'MacOSX':
        service_mgr_name = "launchd"
    elif platform.system() == 'FreeBSD':
        service_mgr_name = "bsdinit"
    elif platform.system() == 'AIX':
        service_mgr_name = "src"
    elif platform.system() == 'SunOS':
        service_mgr_name = "smf"
    mock_module = MockModule()
    service_mgr_collector = ServiceMgrFactCollector()
    facts = service_mgr_collector

# Generated at 2022-06-20 20:00:11.054551
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc is not None
    assert smfc.name == 'service_mgr'
    assert 'service_mgr' in smfc._fact_ids

# Generated at 2022-06-20 20:03:15.764813
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collectors.service_mgr
    c = ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector(BaseFactCollector)
    assert c.is_systemd_managed_offline(None) == False

# Generated at 2022-06-20 20:03:25.441671
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Get module argument spec
    import ansible.module_utils.common.removed
    module = ansible.module_utils.common.removed.AnsibleModule(argument_spec=dict())

    # Test is_systemd_managed_offline method
    service_mgr = ServiceMgrFactCollector()
    assert not service_mgr.is_systemd_managed_offline(module=module)

    # Create fake /sbin/init symlink
    import tempfile
    target = '/bin/systemd'
    link_name = os.path.join(tempfile.mkdtemp(), 'init')
    os.symlink(target, link_name)
    assert service_mgr.is_systemd_managed_offline(module=module)

    # Remove symlink