

# Generated at 2022-06-20 19:53:33.314241
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'
    assert obj.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-20 19:53:41.724431
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts import FactCollector

    # create facts collections with default set of ansible_facts
    test_collector = FactCollector()

    # collect the facts
    test_facts = test_collector.get_facts(MockModule())

    # Assert the service_mgr facts
    assert test_facts['service_mgr'] == 'service'

    # create facts collections with specific set of ansible_facts
    test_collector = FactCollector(ansible_facts={'platform': 'Darwin', 'distribution': 'MacOSX'})

    # collect the facts
    test_facts = test_collector.get_facts(MockModule())

    # Assert the service_mgr facts

# Generated at 2022-06-20 19:53:54.607936
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collector

    module = basic.AnsibleModule(
        argument_spec = dict(),
    )
    module.get_bin_path = lambda cmd: '/usr/bin/{0}'.format(cmd)

    os.symlink('systemd', '/sbin/init')
    assert ansible.module_utils.facts.collector.ServiceMgrFactCollector.is_systemd_managed_offline(module)

    os.unlink('/sbin/init')
    os.symlink('systemd', '/lib/systemd/systemd')
    assert ansible.module_utils.facts.collector.ServiceMgrFactCollector.is_systemd_managed_offline(module)


# Generated at 2022-06-20 19:53:59.030158
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector


# Generated at 2022-06-20 19:54:02.717165
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Given
    module = MockModule()
    smfc = ServiceMgrFactCollector()

    # When
    result = smfc.is_systemd_managed(module)

    # Then
    assert result == False


# Generated at 2022-06-20 19:54:05.253567
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()
    assert s.required_facts == {'platform', 'distribution'}
    assert s.name == "service_mgr"

# Generated at 2022-06-20 19:54:17.539463
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import types
    module = types.ModuleType('ansible.module_utils.facts.system.service_mgr')
    module.get_bin_path = lambda x: '/bin/' + x

    if os.path.islink('/sbin/init'):
        # Save current /sbin/init target
        old_init = os.readlink('/sbin/init')
        saved_old_init = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 'test.sbin.init')
        os.rename('/sbin/init', saved_old_init)


# Generated at 2022-06-20 19:54:18.308241
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()

# Generated at 2022-06-20 19:54:28.005114
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.component = "service_mgr"

        def get_bin_path(self, name):
            return name in self.params['bin_paths']

        def run_command(self, cmd, use_unsafe_shell):
            if cmd == 'ps -p 1 -o comm|tail -n 1' and use_unsafe_shell:
                if self.params['proc_1_data'] and self.params['rc'] == 0:
                    return self.params['rc'], self.params['proc_1_data'], ''
                else:
                    return 1, '', ''
            else:
                raise Exception("Unsupported command: %s" % cmd)


# Generated at 2022-06-20 19:54:35.454163
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import FactsFilesAnsibleModule

    # default test
    test_module = FactsFilesAnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    test_module.exit_json = lambda a: print(a)
    test_module.run_command = lambda a: (0, None, None)
    ServiceMgrFactCollector.is_systemd_managed = lambda a: True
    ServiceMgrFactCollector.is_systemd_managed_offline = lambda a: True
    ServiceMgrFactCollector.get_file_content = lambda a: None
    Collector.collect

# Generated at 2022-06-20 19:54:56.939696
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector.service_mgr import MockModule
    from ansible.module_utils.facts.collector.service_mgr import MockPathExists

    # Arrange
    test_paths = [
        '/run/systemd/system/',
        '/dev/.run/systemd/',
        '/dev/.systemd/',
        '/sbin/init'
    ]

    def is_systemd_managed(path_exists_func):
        # Act
        result = ServiceMgrFactCollector.is_systemd_managed(MockModule(path_exists_func))

        # Assert
        return result

    # path_exists_func returns true if only one

# Generated at 2022-06-20 19:55:05.536837
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import tempfile
    import os
    import platform
    from ansible.module_utils._text import to_bytes

    distro_name = platform.dist()[0]
    # Create temporary test directory
    tmp_dir = tempfile.mkdtemp()
    tmp_init = os.path.join(tmp_dir, 'init')

    # Create temporary init file
    f = open(tmp_init, 'w')
    f.write('')
    f.close()

    # Patch ModuleUtils
    module_utils = BaseFactCollector.module_utils
    BaseFactCollector.module_utils = MockModuleUtils()

    # Patch platform
    old_platform = platform.system
    platform.system = lambda: 'Linux'

    # Patch

# Generated at 2022-06-20 19:55:06.414074
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector().collect()

# Generated at 2022-06-20 19:55:11.382489
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Mock the module instance
    class MockModule(object):
        @staticmethod
        def get_bin_path(path, required=False):
            if path == 'systemctl':
                return path

        @staticmethod
        def exit_json(**kwargs):
            return kwargs

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.result = {
                'changed': False,
                'ansible_facts': {
                    'ansible_system': 'Linux',
                },
            }
            self.module = MockModule()
            self.check_mode = False

    # Mock the os module
    class MockOs(object):
        @staticmethod
        def path(path):
            if path == '/dev/null':
                return MockFile()
           

# Generated at 2022-06-20 19:55:22.151708
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class FakeModule(object):
        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/usr/bin/systemctl'
            else:
                return None

    # Setup classic environment
    test_paths = ['/sbin/init']
    for path in test_paths:
        os.symlink(path, path)

    # Check if 'systemctl' command exists
    m = FakeModule()
    if m.get_bin_path('systemctl') is None:
        return

    # Check if init is a symlink to systemd
    if os.path.islink(test_paths[0]) and os.path.basename(os.readlink(test_paths[0])) == 'systemd':
        print("Init is a symlink to systemd")
   

# Generated at 2022-06-20 19:55:33.512746
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Test the method collect of ServiceMgrFactCollector class.
    """
    module_mock = MagicMock()
    module_mock.run_command = MagicMock()
    collect_mock = MagicMock()

    # test when proc_1 is not None - service_mgr_name is not none
    module_mock.get_bin_path = Mock(return_value='/bin/systemctl')
    module_mock.run_command.return_value = (0, '', '')
    service_mgr = ServiceMgrFactCollector(module=module_mock, collected_facts=None)
    result = service_mgr.collect()
    assert result['service_mgr'] == 'systemd'

    # test when proc_1 is not None - service_mgr_name is not none

# Generated at 2022-06-20 19:55:37.583466
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    test_module = MyModule()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(test_module) == False


# Generated at 2022-06-20 19:55:39.393829
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

# Generated at 2022-06-20 19:55:49.725435
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import platform
    import os

    # We need a module class to unit test
    import ansible.module_utils.basic

    # On RPM distros, the lsb_release package should be installed by default. If not, the tests will fail.
    # On Debian distros, the lsb-release package needs to be installed separately before running the tests.
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    service_mgr_collector = ServiceMgrFactCollector()
    if 'bsd' in platform.system().lower():
        # No native 'stat' command on BSD, use GNU coreutils instead
        STANDARD_STAT_CMD = '/usr/local/bin/stat'
    else:
        STANDARD_STAT_CMD = '/usr/bin/stat'


# Generated at 2022-06-20 19:56:02.043343
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector()

    # is_systemd_managed_offline should return False if os.path.islink('/sbin/init') is False
    os.islink = lambda x: False
    assert collector.is_systemd_managed_offline(None) is False

    # is_systemd_managed_offline should return False if os.readlink('/sbin/init') is not equal to 'systemd'
    os.islink = lambda x: True
    os.readlink = lambda x: 'other'
    assert collector.is_systemd_managed_offline(None) is False

    # is_systemd_managed_offline should return True if os.readlink('/sbin/init') is equal to 'systemd'
    os.readlink = lambda x: 'systemd'
   

# Generated at 2022-06-20 19:56:17.169884
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    m = MagicMock()
    s = ServiceMgrFactCollector()
    s.collect(m)
    assert not s.is_systemd_managed_offline(m)


# Generated at 2022-06-20 19:56:26.751372
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    class FakeModule(object):
        def get_bin_path(self, cmd):
            return '/bin/systemctl'

    module = FakeModule()
    fact_collector = ServiceMgrFactCollector
    # Test1
    # create a symlink /sbin/init to systemd and test if systemd is detected
    os.symlink('/bin/systemctl', '/sbin/init')
    assert fact_collector.is_systemd_managed_offline(module)
    # clean up
    os.remove('/sbin/init')
    # Test2
    # create a symlink /sbin/init to the cat command, and test if systemd is not detected

# Generated at 2022-06-20 19:56:39.825285
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    serviceMgrFactCollector = ServiceMgrFactCollector()
    class DummyModule(object):
        @staticmethod
        def get_bin_path(binary_name):
            if binary_name == 'systemctl':
                return '/bin/systemctl'

    testcases = {
        '/run/systemd/system/': True,
        '/dev/.run/systemd/': True,
        '/dev/.systemd/': True,
        '/run/initctl': True,
        '/': False,
    }
    test_result = True
    message = ''

# Generated at 2022-06-20 19:56:50.372634
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    class MockModule(object):
        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

        def run_command(self,cmd, use_unsafe_shell=None):
            return 0, '', ''

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.facts = {}

        def collect(self, module=None, collected_facts=None):
            return self.facts


    # Test when systemd is the active init system.
    collector = TestServiceMgrFactCollector()
    module = MockModule()
    os.environ['PATH'] = '/bin'
    assert ServiceMgrFactCollector.is_systemd_managed(module=module) == True

    # Test

# Generated at 2022-06-20 19:57:00.923013
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mock_module = MockModule()
    mock_module.params = {}

    # Test the positive path when service_mgr is sysvinit
    fake_facts = {
        'ansible_distribution': 'Debian',
        'ansible_system': 'Linux'
    }
    facts_dict = {'service_mgr': 'sysvinit'}

    s = ServiceMgrFactCollector()
    assert facts_dict == s.collect(mock_module, fake_facts)

    # Test the negative path when command 'ps -p 1 -o comm|tail -n 1' fails.
    fake_facts = {
        'ansible_distribution': 'Debian',
        'ansible_system': 'Linux'
    }
    facts_dict = {'service_mgr': 'service'}

    s = ServiceM

# Generated at 2022-06-20 19:57:12.591864
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Test cases will define variables in the test case class which will be used by test_ServiceMgrFactCollector_is_systemd_managed_offline()
    """
    import mock
    import os.path

    class TestIsSystemdManagedOffline:
        """
        Class will define variables specific to a test case and test_ServiceMgrFactCollector_is_systemd_managed_offline will consume those variables
        """

        def __init__(self, init_symlink, expected_output):
            self.init_symlink = init_symlink
            self.expected_output = expected_output

    # Test data for test_ServiceMgrFactCollector_is_systemd_managed_offline

# Generated at 2022-06-20 19:57:15.539162
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == "service_mgr"
    assert 'platform' in ServiceMgrFactCollector.required_facts
    assert 'distribution' in ServiceMgrFactCollector.required_facts


# Generated at 2022-06-20 19:57:18.530675
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    svc_mgr = ServiceMgrFactCollector()
    assert svc_mgr.name == 'service_mgr'
    assert svc_mgr.required_facts == set(['platform', 'distribution'])
    assert isinstance(svc_mgr.collect(), dict)


# Generated at 2022-06-20 19:57:23.207762
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    fc = FactCollector(None, None)

    fc.collectors = [BaseFactCollector(fc),
                     ServiceMgrFactCollector(fc)]
    res = fc.get_facts(module=None, collected_facts=None)
    assert 'service_mgr' in res['ansible_local']
    assert res['ansible_local']['service_mgr']


# Generated at 2022-06-20 19:57:24.919080
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
   service_mgr_object = ServiceMgrFactCollector()
   print("Service Manager: %s" % service_mgr_object)
   assert service_mgr_object is not None

# Generated at 2022-06-20 19:58:05.371616
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import get_collector_object
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Write mock files
    os.mkdir('/run')
    os.mkdir('/run/systemd')
    os.mkdir('/run/systemd/system')
    os.mkdir('/dev')
    os.mkdir('/dev/.run')
    os.mkdir('/dev/.run/systemd')
    os.mkdir('/dev/.systemd')

    # Create mock ansible module

# Generated at 2022-06-20 19:58:09.932621
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector._fact_ids == set()
    assert service_mgr_fact_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 19:58:17.343012
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Test to check:
    * if init is systemd, output service_mgr=systemd
    * if init is upstart, output service_mgr=upstart
    * if init is sysv, output service_mgr=sysvinit
    * if init is openrc, output service_mgr=openrc
    * if invalid service_mgr, output service_mgr=service
    """
    # Using try/except because class ServiceMgrFactCollector is calling class BaseFactCollector,
    # on which we are mocking methods.
    try:
        from ansible.module_utils.facts import collector
        from ansible.module_utils.facts.collector import ServiceMgrFactCollector
        from ansible.module_utils.facts.collector import BaseFactCollector
    except:
        pass

    # Create a mock

# Generated at 2022-06-20 19:58:18.011937
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x

# Generated at 2022-06-20 19:58:19.110962
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    pass


# Generated at 2022-06-20 19:58:20.537276
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed() == False

# Generated at 2022-06-20 19:58:21.256705
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-20 19:58:23.738487
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.is_systemd_managed_offline("") is False

# Generated at 2022-06-20 19:58:29.579112
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import ModuleCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Create object of ModuleCollector
    collector = ModuleCollector()

    # Create object of Facts
    facts_obj = Facts(collector)

    # get the value of service_mgr
    service_mgr = facts_obj.get_fact('service_mgr')

    # Create object of ServiceMgrFactCollector and get the values of service_mgr
    service_mgr_obj = ServiceMgrFactCollector()
    service_mgr_new = service_mgr_obj.collect(module=None, collected_facts=None)

    # Check for the equality of service_mgr and

# Generated at 2022-06-20 19:58:37.218047
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Test ServiceMgrFactCollector class"""
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule:
        def get_bin_path(self, path):
            return False
    t = TestModule()

    c = ServiceMgrFactCollector(t)
    assert c.name == 'service_mgr'
    assert c._fact_ids == set()
    assert c.required_facts == {'platform', 'distribution'}

    assert c.is_systemd_managed(t) == False
    assert c.is_systemd_managed_offline(t) == False
    assert c.collect(t) == {'service_mgr': 'service'}

# Generated at 2022-06-20 19:59:39.138385
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.params = { 'collect_subset': ['all'] }
            self.config = { 'fact_path': [] }

        def get_bin_path(self, app):
            if app == 'initctl':
                return 'initctl'
            elif app == 'systemctl':
                return 'systemctl'

        def run_command(self, cmd, use_unsafe_shell=False):
            return [0, 'init', '']

    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import collect_subset

    module = MockModule()
    fact_collector = fact_collector = FactCollector(module=module)

# Generated at 2022-06-20 19:59:49.702153
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import platform
    import unittest

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.six import PY3

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': [], 'gather_timeout': 10, 'filter': '*'}
            self.check_mode = False

        def get_bin_path(self, arg):
            return '/bin'


# Generated at 2022-06-20 20:00:00.817894
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.platform.service_mgr import ServiceMgrFactCollector

    # Test is_systemd_managed on a system without systemd
    fake_module = BaseFactCollector()
    fake_module.get_bin_path = lambda *a: None
    assert not ServiceMgrFactCollector.is_systemd_managed(fake_module)

    # Test is_systemd_managed on a system with systemd
    fake_module.get_bin_path = lambda *a: '/usr/bin/systemctl'
    fake_module.run_command = lambda *a, **k: (0, '', '')
    assert ServiceMgrFactCollector.is_systemd_managed(fake_module)

# Generated at 2022-06-20 20:00:04.733981
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x.name == 'service_mgr'
    assert x.required_facts == set(['platform', 'distribution'])
    assert x._fact_ids == set()

# Generated at 2022-06-20 20:00:09.033862
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Get ansible module_utils fact collector class ServiceMgr
    fact_collector = ServiceMgrFactCollector()

    # Test facts collect with expected result
    actual_result = fact_collector.collect()
    expected_result = {'service_mgr': 'systemd'}
    assert actual_result == expected_result

# Generated at 2022-06-20 20:00:16.416921
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import mock_module
    from ansible.module_utils.facts.utils import MockModule

    def mock_module_get_bin_path(module, path):
        if path == 'systemctl':
            return '/bin/true'
        elif path == 'initctl':
            return '/bin/false'
        else:
            return '/sbin/init'

    def mock_module_run_command(module, cmd, use_unsafe_shell=False):
        output = ''
        if cmd == "ps -p 1 -o comm|tail -n 1":
            output = 'systemd'
        return (0, output, '')


# Generated at 2022-06-20 20:00:30.314964
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # implements method used by ansible-test for unit testing
    # https://docs.ansible.com/ansible-test/dev_guide/unit_testing.html#unit-test-for-is_enabled
    testcases = [
        {
            'service_mgr': {
                'is_systemd_managed_offline': True,
            },
        },
    ]

    # The test data must be in the form of a list of lists.
    # i.e. A list of dictionaries, each dictionary containing a list of arguments to pass to the is_systemd_managed_offline
    # metod of the ServiceMgrFactCollector class.
    from ansible.module_utils.facts.collector import AnsibleModule


# Generated at 2022-06-20 20:00:31.813079
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-20 20:00:38.524317
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule(object):
        def __init__(mockself, params):
            mockself.params = params
            mockself.exit_json = Mock(return_value=None)

        def get_bin_path(mockself, exe):
            if exe == 'systemctl':
                return '/sbin/systemctl'
            elif exe == 'initctl':
                return '/sbin/initctl'
            else:
                return False

        def run_command(mockself, cmd, use_unsafe_shell=False):
            if cmd == 'ps -p 1 -o comm|tail -n 1':
                return 0, 'init\n', ''
            else:
                return 1, '', ''


# Generated at 2022-06-20 20:00:43.287040
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert len(ServiceMgrFactCollector().required_facts) == 2
    assert ServiceMgrFactCollector().required_facts == set(['platform', 'distribution'])
    assert 'service_mgr' in ServiceMgrFactCollector().name
    assert ServiceMgrFactCollector._fact_ids == set()