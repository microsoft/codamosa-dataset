

# Generated at 2022-06-20 19:53:32.762904
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    collector = ServiceMgrFactCollector()
    assert not collector.is_systemd_managed(module=MockModule())


# Generated at 2022-06-20 19:53:39.197188
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    import unittest.mock as mock

    class MockModule(object):

        def get_bin_path(self, path):
            return path

    def mock_os_path_exists(path):
        return path == "/run/systemd/system/"

    module = MockModule()
    m_os_path_exists = mock.patch('os.path.exists', new=mock_os_path_exists)
    m_os_path_exists.start()
    result = ServiceMgrFactCollector.is_systemd_managed(module)
    assert result
    m_os_path_exists.stop()



# Generated at 2022-06-20 19:53:39.832019
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector()

# Generated at 2022-06-20 19:53:42.596669
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector.name is not None

# Generated at 2022-06-20 19:53:49.066999
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts import FactCollector

    # Initialize module and ServiceMgrFactCollector
    module = {}
    fact_collector = ServiceMgrFactCollector(module=module)

    assert isinstance(fact_collector, FactCollector) is True
    assert fact_collector.module == module
    assert fact_collector.name == 'service_mgr'
    assert fact_collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-20 19:54:01.276945
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class ModuleStub(object):
        def get_bin_path(self, path):
            if path == 'systemctl':
                return '/bin/systemctl'
            return None

    class AnsibleModuleStub(object):
        def __init__(self):
            self.check_mode = False

        def run_command(self, cmd, use_unsafe_shell=False):
            return (0, None, None)

        def get_bin_path(self, path):
            return ModuleStub.get_bin_path(self, path)

    module = AnsibleModuleStub()

    collector = ServiceMgrFactCollector()
    assert collector._fact_class.is_systemd_managed_offline(module) == False
    os.symlink('systemd', '/sbin/init')
    assert collector._fact

# Generated at 2022-06-20 19:54:03.457482
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    
    test_object = ServiceMgrFactCollector()

    # TODO: Write method collect unit tests for class ServiceMgrFactCollector

    return

# Generated at 2022-06-20 19:54:10.383888
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import ModuleDataCollector
    from ansible.module_utils.facts.collectors.system import SystemCollector

    system_collector = SystemCollector()
    collected_facts = system_collector.collect()


# Generated at 2022-06-20 19:54:19.600059
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Assume to be able to run lsb_release and
    # report Ubuntu 16.04 platform
    lsb_release_platform = "Ubuntu"
    lsb_release_distro = "16.04"
    lsb_release_codename = "xenial"
    lsb_release_major = 16
    lsb_release_minor = 4

    # patch ansible module to report the above
    class AnsibleModuleMock:
        def run_command(self, command, **kwargs):
            if command == "lsb_release -is":
                return (0, lsb_release_platform, "")
            elif command == "lsb_release -cs":
                return (0, lsb_release_codename, "")

# Generated at 2022-06-20 19:54:23.281256
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = {}
    mgr = ServiceMgrFactCollector()
    assert (mgr.is_systemd_managed_offline(module) != True)


# Generated at 2022-06-20 19:54:47.228062
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils import basic

    # Mock a module
    module = basic.AnsibleModule(argument_spec={})

    # Create a new facts object
    facts_obj = FactsCollector()

    # Add the fact
    facts_obj.add_fact(ServiceMgrFactCollector())

    # Assert
    assert 'service_mgr' in facts_obj.collect(module=module).keys()

# Generated at 2022-06-20 19:54:58.087380
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import ModuleProcessor
    from ansible.module_utils.facts.collector import Collectors, get_collector_instance
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    import tempfile

    def get_file_content(path):
        if path == '/proc/1/comm':
            return 'systemd'
        return None

    def get_bin_path(name):
        return '/sbin/' + name

    def run_command(cmd, use_unsafe_shell=True):
        if cmd == "ps -p 1 -o comm|tail -n 1":
            return [0, 'systemd\n', '']
        return [1, '', '']


# Generated at 2022-06-20 19:54:59.010271
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    # TODO
    pass

# Generated at 2022-06-20 19:55:03.292907
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mgr = ServiceMgrFactCollector()
    assert type(mgr).__name__ == 'ServiceMgrFactCollector'
    assert type(mgr.collect()).__name__ == 'dict'
    assert mgr.collect().keys() == ['service_mgr']
    assert type(mgr.collect()['service_mgr']).__name__ == 'str'

# Generated at 2022-06-20 19:55:09.587417
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Mocking a module
    mock_module = {}

    # Mock a ServiceMgrFactCollector instantiated
    mock_smfc = ServiceMgrFactCollector()

    # Mock systemctl
    mock_module.get_bin_path = lambda x: "path/to/systemctl"

    # Mock os.path.islink(path) to return True, then False
    os_path_islink = os.path.islink
    os.path.islink = lambda x: True
    assert mock_smfc.is_systemd_managed_offline(mock_module) == True
    os.path.islink = lambda x: False
    assert mock_smfc.is_systemd_managed_offline(mock_module) == False
    os.path.islink = os_path_islink

    # Mock os

# Generated at 2022-06-20 19:55:18.002777
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class ModuleMock:
        def get_bin_path(self, arg):
            return '/bin/' + arg

        def run_command(self, arg, use_unsafe_shell=False):
            return 0, '', ''

    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    facts_collector = ServiceMgrFactCollector()

    assert facts_collector.is_systemd_managed_offline(ModuleMock()) == False



# Generated at 2022-06-20 19:55:20.037886
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    sm = ServiceMgrFactCollector()
    assert sm
    assert sm.name == 'service_mgr'

# Generated at 2022-06-20 19:55:27.704520
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a mock of class AnsibleModule
    class AnsibleModule:
        def __init__(self):
            self.run_command_output = ""
            self.run_command_rc = 0

        def get_bin_path(self, app):
            return True

        def run_command(self, cmd, use_unsafe_shell=False):
            return (self.run_command_rc, self.run_command_output, "")

    # Create a mock of class AnsibleModule
    class AnsibleModuleOffline:
        def __init__(self):
            self.run_command_output = ""
            self.run_command_rc = 0

        def get_bin_path(self, app):
            return False


# Generated at 2022-06-20 19:55:39.592803
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    os_mock = {
        'path': {
            'exists': lambda x: False,
            'islink': lambda x: False,
        },
    }

    module_mock = {
        'get_bin_path': lambda x: '',
    }

    test_cases = [
        {'systemctl': '', 'result': False},
        {'systemctl': '', 'result': False},
        {'systemctl': '', 'result': False},
        {'systemctl': '', 'result': False},
        {'systemctl': '', 'result': False},
        {'systemctl': '', 'result': True},
        {'systemctl': '', 'result': True},
        {'systemctl': '', 'result': True},
    ]


# Generated at 2022-06-20 19:55:49.879728
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import MythicFact
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Create an instance of linux MythicFact class
    mf = MythicFact(
        name='service_mgr',
        fname='service_mgr.py',
        factnames='ansible_service_mgr',
        runner=None,
        stack=[],
    )

    # Create an instance of MythicFact class
    sf = ServiceMgrFactCollector(mf)

    # Check if systemd is managed
    mf.module.get_bin_path = MagicMock(return_value='/bin/systemctl')
    mf.module.run_command = MagicMock(return_value=(0, 'xyz', ''))
   

# Generated at 2022-06-20 19:56:13.839270
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()

# Generated at 2022-06-20 19:56:25.366008
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Mock all module inputs
    mock_module = 'AnsibleModule'

    # Init AnsibleModule
    am = AnsibleModule(
        argument_spec = dict()
    )

    # Side effects when calling AnsibleModule()
    mock_AnsibleModule = MagicMock(return_value=am)
    setattr(sys.modules['ansible.module_utils.facts.system.service_mgr'], 'AnsibleModule', mock_AnsibleModule)

    # Prepare test input
    test_obj = ServiceMgrFactCollector()

    # Make collect() return a fact
    test_obj.collect = MagicMock(return_value='fact')
    assert test_obj.collect(mock_module) == 'fact'

    # Side effects when calling get_file_content(<some_path>)
    mock_

# Generated at 2022-06-20 19:56:33.896534
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    def callback(callback_name, *callback_args):
        callback_results[callback_name] = callback_args[0]

    callback_results = {}
    facts = Collector()
    facts.subscribe(ServiceMgrFactCollector())
    facts._callback = callback
    facts._collect()
    return callback_results



# Generated at 2022-06-20 19:56:44.921336
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import glob
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    class_under_test = ServiceMgrFactCollector()

    # systemd
    real_path = "/usr/lib/systemd/systemd"
    fake_path = "/usr/lib/systemd/systemd_fake"
    fake_path_list = glob.glob("/usr/bin/*")
    # remove any real_path in fake_path_list
    if real_path in fake_path_list:
        fake_path_list.remove(real_path)
    # add the fake path to fake_path_list
    fake_path_list.append(fake_path)


# Generated at 2022-06-20 19:56:55.032556
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, params=None):
            self.params = params
            self.run_command_results = (None, None, None)

        def get_bin_path(self, path, opt_dirs=[]):
            return '/bin/%s' % path

        def run_command(self, cmd, use_unsafe_shell=True):
            return self.run_command_results

    class MockFacts(object):
        def __init__(self, modular_facts_dict):
            self.ansible_facts = modular_facts_dict

        def populate(self):
            return self.ansible_facts
    # service_mgr is known (upstart)
    mock_module = MockModule()

# Generated at 2022-06-20 19:56:57.921687
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == "service_mgr"
    assert obj.required_facts == set(['platform', 'distribution'])
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:56:58.856285
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector.collect()

# Generated at 2022-06-20 19:57:05.655831
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system

    class TestModule:
        def get_bin_path(self, path, required=False):
            if path == 'systemctl':
                return '/usr/bin/systemctl'
            else:
                return None

    testmodule = TestModule()
    system_facts = ansible.module_utils.facts.collector.collect(ansible.module_utils.facts.system.SystemFactCollector(), gathered_facts=None, module=testmodule)
    system_facts.update({'ansible_facts': {'system': system_facts}})

    assert ServiceMgrFactCollector.is_systemd_managed(module=testmodule) == True

# Generated at 2022-06-20 19:57:15.500711
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector"""
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        def get_bin_path(self, path, env=None, opt_dirs=None):
            return '/usr/bin/systemctl'

    class MockBase(BaseFactCollector):
        def __init__(self, module=None, collected_facts=None):
            self.facts_dict = {}

    s = ServiceMgrFactCollector(base=MockBase(module=MockModule()))
    assert s.is_systemd_managed_offline(MockModule()) == True

    s = ServiceMgrFactCollector(base=MockBase(module=MockModule()))

# Generated at 2022-06-20 19:57:23.579313
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr

    # Test with systemd
    module = MockModule(dict(ansible_facts={}))
    module.run_command = Mock(return_value=(0, '/sbin/init', ''))
    module.get_bin_path = Mock(return_value='/bin/systemctl')

    facts = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector(module).collect()

    assert facts['service_mgr'] == 'systemd'

# Generated at 2022-06-20 19:58:33.485919
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    def return_empty_string(*args, **kwargs):
        return ''

    def return_systemd_string(*args, **kwargs):
        return 'systemd'

    class MockModule(object):
        def __init__(self, bin_path=None, get_bin_path_return=None):
            self.bin_path = bin_path
            self.get_bin_path_return = get_bin_path_return
        def get_bin_path(self, *args, **kwargs):
            return self.get_bin_path_return

    # MockModule with mock bin_path and get_bin_path_return
    module = MockModule(bin_path='/bin/systemctl', get_bin_path_return='/bin/systemctl')
    # check that /sbin/init is not a symlink

# Generated at 2022-06-20 19:58:36.497224
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys
    import ansible.module_utils.facts.collector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Ensure method returns expected data
    assert service_mgr_fact_collector.collect() == {'service_mgr': 'service'}

# Generated at 2022-06-20 19:58:46.752144
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    fact_collector_mock_module = AnsibleMock()
    fact_collector_mock_module.run_command = AnsibleMock(return_value=(1, 'error', 'error'))
    fact_collector_mock_module.get_bin_path = AnsibleMock(return_value='/usr/bin/systemctl')
    os.path.exists = AnsibleMock(return_value=True)

    assert ServiceMgrFactCollector.is_systemd_managed(fact_collector_mock_module) == True, \
        'Unexpected return for is_systemd_managed method'

# Generated at 2022-06-20 19:59:00.821296
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    test_module = basic.AnsibleModule(argument_spec=dict())
    test_module.exit_json = lambda a: a
    test_module.params = {}
    test_module.params['gather_subset'] = ['!all', 'service_mgr']
    test_module.params['gather_timeout'] = 1
    test_module.params['filter'] = ['*']

    test_module.run_command = lambda x, use_unsafe_shell=False: (0, '', '')
    test_module.get_bin_path = lambda x: '/usr/bin/' + x

# Generated at 2022-06-20 19:59:12.256549
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector, ansible_collector

    class DummyModule(object):

        def get_bin_path(self, *args):
            return None

        def run_command(self, *args):
            pass

    class DummyAnsibleModule(object):

        def __init__(self):
            self.run_command = DummyModule().run_command
            self.get_bin_path = DummyModule().get_bin_path

        def fail_json(self, *args, **kwargs):
            pass

        def exit_json(self, **kwargs):
            pass

        def set_check_mode(self):
            pass

        def add_cleanup_file(self, *args):
            pass


# Generated at 2022-06-20 19:59:22.696795
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # importing ServiceMgrFactCollector class dynamically
    from ansible.module_utils.facts import collectors
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.basic
    class MockAnsibleModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self):
            pass
    class MockFactsUtils(ansible.module_utils.facts.utils.FactsUtils):
        def __init__(self):
            pass
        def get_file_content(self, path):
            return None
    class MockFactCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        def __init__(self):
            pass
    # setting is_systemd_managed_

# Generated at 2022-06-20 19:59:29.382053
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    '''
    Test case for ServiceMgrFactCollector is_systemd_managed_offline method
    '''
    class FakeModule(object):
        def __init__(self):
            self.executable = '/bin/systemctl'

        def get_bin_path(self, executable, required=False):
            return self.executable

        def run_command(self, command, use_unsafe_shell=False):
            self.command = command
            return 0, '', ''

    fake_module = FakeModule()
    service_mgr_collector = ServiceMgrFactCollector()

    # Test case when no systemctl executable
    fake_module.executable = None
    assert not service_mgr_collector.is_systemd_managed_offline(fake_module)

    # Test case when /sbin/

# Generated at 2022-06-20 19:59:32.422641
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # This test is not intended to provide 100% code coverage as it's too
    # difficult to test this method.

    fc = ServiceMgrFactCollector()

    assert not fc.is_systemd_managed(None)



# Generated at 2022-06-20 19:59:42.061494
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from mock import patch
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(
        argument_spec = dict()
    )

    # Mock globals
    with patch.dict(os.environ, {'PATH': ':/bin'}):
        with patch('os.path.exists') as path_exists:
            # Mock os.path.exists
            # - Calls to os.path.exists return False
            path_exists.side_effect = lambda path: True if path == '/bin/systemctl' else False
            # - Return False when the path is not found
            path_exists.return_value = False

            # Ensure systemd is not detected by default
            assert ServiceMgrFactCollector.is_systemd_managed(module) is False

            # Mock os

# Generated at 2022-06-20 19:59:48.991026
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ''' service_mgr.py:ServiceMgrFactCollector constructor'''

    # Configure mock module
    module = AnsibleModule(argument_spec={})

    # Construct ServiceMgrFactCollector
    service_mgr_fc = ServiceMgrFactCollector(module=module)

    assert service_mgr_fc.name == 'service_mgr'
    assert service_mgr_fc.required_facts == set(['platform', 'distribution'])
    assert service_mgr_fc._fact_ids == set()


# Generated at 2022-06-20 20:02:13.985275
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    result = ServiceMgrFactCollector.is_systemd_managed(None)
    assert result == False

    # case 1: when systemctl and /run/systemd/system exist and /etc/init.d does not exist
    def get_bin_path(bin_name):
        return "/"
    def exists(path):
        if path == '/etc/init.d/':
            return False
        else:
            return True
    module = AttributeDict()
    module.get_bin_path = get_bin_path
    module.exists = exists
    result = ServiceMgrFactCollector.is_systemd_managed(module)
    assert result == True

# Generated at 2022-06-20 20:02:19.628067
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import inspect
    import sys
    import unittest

    from mock import Mock

    from ansible.module_utils.facts import collector

    class Cls:
        def __init__(self):
            self.mock_run_command = Mock()
            self.mock_get_bin_path = Mock()
            sys.modules['ansible'].module_utils.facts.collector = Mock()
            sys.modules['ansible'].module_utils.facts.collector.collect_platform_facts = Mock()
            sys.modules['ansible'].module_utils.facts.collector.collect_platform_facts.return_value = {'platform': 'Linux', 'distribution': 'Red Hat Enterprise Linux Server'}

            self.dummy_module = Mock()
            self.dummy_module.run_command = self.mock

# Generated at 2022-06-20 20:02:30.987819
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    import os
    import tempfile
    import shutil

    class ModuleMock:

        def get_bin_path(self, name):
            if name == 'systemctl':
                return True
            else:
                return None

        def run_command(self,cmd):
            return None, None, None

    class OSMock:

        def __init__(self):
            self.files = {}
            self.files[('/sbin/init')] = (None, False)

        def exists(self, file):
            try:
                return self.files[(file)][1]
            except KeyError:
                return True


# Generated at 2022-06-20 20:02:42.410224
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-20 20:02:49.754476
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector._fact_ids == set()
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-20 20:02:51.148573
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector

# Generated at 2022-06-20 20:02:58.130396
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return True
            return False

    module = FakeModule()
    service_mgr_obj = ServiceMgrFactCollector()

    assert service_mgr_obj.is_systemd_managed_offline(module)

    module.get_bin_path = lambda x: False
    assert not service_mgr_obj.is_systemd_managed_offline(module)

# Generated at 2022-06-20 20:03:02.794339
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Check that class is available and its instance can be created"""
    from ansible.module_utils.facts import collector

    service_mgr_collector = collector.get_collector('service_mgr')
    assert service_mgr_collector != None

    this_collector = service_mgr_collector(None, None)
    assert this_collector != None

# Generated at 2022-06-20 20:03:08.517583
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    def get_bin_path(name):
        if name == 'systemctl':
            return '/bin/systemctl'
        else:
            return None

    def run_command(command, use_unsafe_shell=True):
        if command == "ps -p 1 -o comm|tail -n 1":
            return (0, 'init', '')
        else:
            return (None, None, None)

    def islink(path):
        if path == '/sbin/init':
            return True
        else:
            return False

    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Test function without mocking os.readlink method
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

    # Test function without mocking os.

# Generated at 2022-06-20 20:03:12.023934
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_facts = ServiceMgrFactCollector()
    assert service_mgr_facts.collect()['service_mgr'] == 'service'