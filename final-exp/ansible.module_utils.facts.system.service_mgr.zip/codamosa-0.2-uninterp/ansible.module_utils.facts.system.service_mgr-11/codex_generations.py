

# Generated at 2022-06-17 02:37:29.694709
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    test_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, check_rc=True: (0, '', ''),
        'get_bin_path': lambda self, name: '/bin/' + name,
        'exit_json': lambda self, **kwargs: None,
        'fail_json': lambda self, msg: None
    })()

    # Create a mock ansible module

# Generated at 2022-06-17 02:37:37.470165
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, cmd, required=False):
            if cmd == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class FakeOs(object):
        def __init__(self, path):
            self.path = path

        def islink(self, path):
            if path == '/sbin/init':
                return True
            else:
                return False


# Generated at 2022-06-17 02:37:44.569264
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import search_file
    from ansible.module_utils.facts.utils import search_file_for_string

# Generated at 2022-06-17 02:37:55.960249
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Mock module
    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    # Mock module class
    class MockModuleClass:
        def __init__(self):
            self.params = {}

    # Mock AnsibleModule
    class MockAnsibleModule:
        def __init__(self):
            self.params = {}


# Generated at 2022-06-17 02:38:07.644187
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    # Test with systemctl installed and /sbin/init symlinked to systemd
    module = MockModule(bin_path='/usr/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == True

    # Test with systemctl installed and /sbin/init not symlinked to systemd

# Generated at 2022-06-17 02:38:12.117149
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary systemd init file
    systemd_init_file = os.path.join(tmpdir, 'systemd')
    open(systemd_init_file, 'a').close()

    # Create a temporary symlink to systemd init file
    symlink_to_systemd_init_file = os.path.join(tmpdir, 'sbin', 'init')
    os.makedirs(os.path.dirname(symlink_to_systemd_init_file))
    os.symlink(systemd_init_file, symlink_to_systemd_init_file)

# Generated at 2022-06-17 02:38:21.992147
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_symlink_target
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid


# Generated at 2022-06-17 02:38:33.933348
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module.params = {}

    # Create a mock ansible module
    ansible_module.run_command = AnsibleModuleMock.run_command

    # Create a mock ansible module
    ansible_module.get_bin_path = AnsibleModuleMock.get_bin

# Generated at 2022-06-17 02:38:45.011398
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_selinux

# Generated at 2022-06-17 02:38:51.680308
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_

# Generated at 2022-06-17 02:39:13.308574
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def get_bin_path(self, executable):
            return os.path.join(self.tmpdir, executable)

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''


# Generated at 2022-06-17 02:39:23.240786
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            return path

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

    class MockPath(object):
        def __init__(self):
            self.exists_return_value = False
            self.islink_return_value = False

        def exists(self, path):
            return self.exists_return_value


# Generated at 2022-06-17 02:39:31.606659
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid

# Generated at 2022-06-17 02:39:44.702959
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    # Test case 1: /sbin/init is a symlink

# Generated at 2022-06-17 02:39:55.720271
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    # Test case 1: /sbin/init is a symlink to systemd
    test_module = TestModule()
    test_base_fact_collector

# Generated at 2022-06-17 02:40:07.569731
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return None

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class MockFacts(object):
        def __init__(self, **kwargs):
            self.facts = kwargs


# Generated at 2022-06-17 02:40:17.267798
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
        'get_bin_path': lambda self, cmd: cmd,
    })

    # Create a mock ansible module

# Generated at 2022-06-17 02:40:30.001899
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, executable: '/bin/' + executable,
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
    })()

    # Create a mock collected_facts
    mock_collected_facts = {
        'ansible_distribution': 'OpenWrt',
        'ansible_system': 'Linux',
    }

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the collect method

# Generated at 2022-06-17 02:40:39.162537
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None

        def get_bin_path(self, name):
            return '/bin/' + name

    class MockFactCollector(BaseFactCollector):
        def __init__(self):
            self.name = 'test'
            self.required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {}


# Generated at 2022-06-17 02:40:48.924818
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_stdout = ''
            self.run_command_stderr = ''

        def get_bin_path(self, executable):
            return '/bin/' + executable

        def run_command(self, cmd, use_unsafe_shell=True):
            self.run_command_called = True

# Generated at 2022-06-17 02:41:28.723431
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock fact cache
    fact_cache = FactCache()

    # Create a mock collector
    collector = Collector(module=module, fact_cache=fact_cache)

    # Create a ServiceMgrFactCollector instance
    service_mgr_fact_collector = ServiceMgrFactCollector(module=module, fact_cache=fact_cache)

    # Add the ServiceMgrFactCollector instance to the collector
    collector.add_collector(service_mgr_fact_collector)

    # Collect facts
    facts

# Generated at 2022-06-17 02:41:41.314736
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    mock_module = MockModule()

    # Create a mock ansible module
    mock_ansible_module = MockAnsibleModule(mock_module)

    # Create a mock ansible module class
    mock_ansible_module_class = MockAnsibleModuleClass(mock_ansible_module)

    # Create a mock BaseFactCollector
    mock_base_fact_collector = MockBaseFactCollector(mock_ansible_module_class)

    #

# Generated at 2022-06-17 02:41:53.144831
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

        def __enter__(self):
            return self


# Generated at 2022-06-17 02:42:05.457021
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name):
            return self.bin_path

    # Test case 1: systemctl is not installed
    module = TestModule(bin_path=None)
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test case 2: systemctl is installed, but /sbin/init is not a symlink to systemd
    module = TestModule(bin_path='/bin/systemctl')

# Generated at 2022-06-17 02:42:14.402071
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self, islink, readlink):
            self.islink = islink
            self.readlink = readlink

        def islink(self, path):
            return self.islink

        def readlink(self, path):
            return self

# Generated at 2022-06-17 02:42:24.977536
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts.utils import MockCommand
    from ansible.module_utils.facts.utils import MockFile

    # Create a mock module
    module = MockModule()

    # Create a mock command
    command = MockCommand()

    # Create a mock file
    file = MockFile()

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test if init is a symlink to systemd
    file.set_content("/sbin/init", "systemd")
    assert service_mgr_fact_collector.is_systemd_managed_offline(module) == True

# Generated at 2022-06-17 02:42:36.712732
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_stat
   

# Generated at 2022-06-17 02:42:49.015993
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # create a fake module
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x, **kwargs: x
            self.fail_json = lambda x, **kwargs: x
            self.run_command = lambda x, **kwargs: (0, '', '')
            self.get_bin_path = lambda x: x

    # create a fake ansible module
    module = FakeModule()

    # create a fake ansible module
    module = FakeModule()

    # create a fake ansible module


# Generated at 2022-06-17 02:42:59.251895
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class MockFile(object):
        def __init__(self, name):
            self.name = name

        def exists(self):
            return True

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

    class MockPath(object):
        def __init__(self):
            self.isfile = MockIsFile()


# Generated at 2022-06-17 02:43:08.710393
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, required=False):
            if name in self.bin_path:
                return self.bin_path[name]
            return None

    class MockCollector(BaseFactCollector):
        name = 'mock'
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {}

    # Test with no systemctl binary
    module = MockModule({})

# Generated at 2022-06-17 02:44:17.959800
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a mock module
    module = MockModule()
    module.get_bin_path = Mock(return_value='/bin/systemctl')

    # Create a mock os.path
    os.path = Mock()
    os.path.exists = Mock(return_value=True)

    # Create a mock os
    os = Mock()
    os.readlink = Mock(return_value='systemd')

    # Create a mock platform
    platform = Mock()
    platform.system = Mock(return_value='Linux')

    # Create a mock LooseVersion
    LooseVersion = Mock()
    LooseVersion.return_value = True

    # Create a mock ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Call the method is_systemd_managed
   

# Generated at 2022-06-17 02:44:29.159347
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts.utils import MockCommand

    # Mock the module
    mock_module = MockModule()
    mock_module.run_command = MockCommand()

    # Mock the command
    mock_module.run_command.add_command(
        'systemctl --version',
        stdout='systemd 219\n+PAM +AUDIT +SELINUX +IMA +APPARMOR +SMACK +SYSVINIT +UTMP +LIBCRYPTSETUP +GCRYPT +GNUTLS +ACL +XZ -LZ4 +SECCOMP +BLKID +ELFUTILS +KMOD -IDN')

    # Mock the

# Generated at 2022-06-17 02:44:39.446607
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    class MockFile(object):
        def __init__(self, exists):
            self.exists = exists

        def exists(self, path):
            return self.exists

    class MockOs(object):
        def __init__(self, path):
            self.path = path

        def islink(self, path):
            return self

# Generated at 2022-06-17 02:44:50.957497
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import platform
    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a fake /sbin/init symlink
    os.symlink('systemd', os.path.join(tmpdir, 'sbin', 'init'))

    # Create a fake systemctl executable
    systemctl_path = os.path.join(tmpdir, 'systemctl')
    with open(systemctl_path, 'w') as systemctl_file:
        systemctl_file.write('#!/bin/sh\n')

    # Make the fake systemctl executable

# Generated at 2022-06-17 02:45:00.762471
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'

    module = MockModule()
    service_mgr_fact_collector = ServiceMgrFactCollector()

    assert service_mgr_fact_collector.is_systemd_managed_offline(module) == False

# Generated at 2022-06-17 02:45:10.020603
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_fact_collect

# Generated at 2022-06-17 02:45:17.184659
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Initialize the collector
    c = Collector()
    c.add_collector(ServiceMgrFactCollector())

    # Collect facts
    facts = c.collect(module=None, collected_facts=None)

    # Test if the service_mgr fact is present
    assert 'service_mgr' in facts

# Generated at 2022-06-17 02:45:24.536278
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return executable

    class MockCollector(BaseFactCollector):
        def __init__(self):
            self.facts = {}

    module = MockModule()
    collector = MockCollector()
    service_mgr_collector = ServiceMgrFactCollector(module=module, collector=collector)

    # Test with /sbin/init symlink to systemd
    os.symlink('/bin/systemd', '/sbin/init')
    assert service_mgr_collector

# Generated at 2022-06-17 02:45:35.576801
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None
            self.exit_json = lambda **kwargs: None

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []


# Generated at 2022-06-17 02:45:45.126451
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule

    module = MockModule()
    module.get_bin_path = lambda x: '/bin/systemctl'
    module.run_command = lambda x, **kwargs: (0, '', '')

    # Test case 1: /sbin/init is a symlink to systemd
    os.symlink('/bin/systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test case 2: /sbin/init is not a symlink to systemd
    os.remove('/sbin/init')