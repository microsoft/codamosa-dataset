

# Generated at 2022-06-17 02:37:31.467509
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    test_module = TestModule()
    test_base_fact_collector = TestBaseFactCollector(test_module)
    test_service_mgr_fact_collector = TestServiceMgrFactCollector(test_module)



# Generated at 2022-06-17 02:37:42.700688
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts.utils import MockCommand
    from ansible.module_utils.facts.utils import MockFile

    # Mock module
    module = MockModule()

    # Mock command
    module.run_command = MockCommand()

    # Mock file
    module.get_bin_path = MockFile()

    # Mock file
    os.path.islink = MockFile()
    os.path.islink.return_value = True

    # Mock file
    os.readlink = MockFile()
    os.readlink.return_value = 'systemd'

    # Test is_systemd_managed_offline

# Generated at 2022-06-17 02:37:52.926759
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/bin/' + name

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []


# Generated at 2022-06-17 02:38:00.114068
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, required=False):
            return executable

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockCollectedFacts(object):
        def __init__(self):
            self.collected_facts = {}

    # Test case 1: /sbin/init is a symlink to systemd
    mock_module = MockModule()
    mock_base_fact_collector = MockBaseFactCollector()
    mock_

# Generated at 2022-06-17 02:38:04.586942
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    import os

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['path'] = os.environ['PATH']

        def get_bin_path(self, executable):
            return executable

    class FakeFactCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set()
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {}

    # Create a fake module
    module = FakeModule()

    # Create a fake fact collector
    fact_collector = FakeFactCollector()

   

# Generated at 2022-06-17 02:38:13.981627
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, facts_dict):
            self.facts_dict = facts_dict

        def collect(self, module=None, collected_facts=None):
            return self.facts_dict

    # Test case 1: systemctl is not installed

# Generated at 2022-06-17 02:38:23.848196
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:38:34.888273
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

    class MockPath(object):
        def __init__(self):
            self.exists_return_value = False

        def exists(self, path):
            return self.exists_return_value

    class MockOsModule(object):
        def __init__(self):
            self.path = MockPath()


# Generated at 2022-06-17 02:38:42.027613
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:38:49.890518
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution

    class MockModule(object):
        def __init__(self):
            self.run_command = ansible.module_utils.facts.utils.get_file_content
            self.get_bin_path = ansible.module_utils.facts.utils.get_file_content

    class MockCollector(object):
        def __init__(self):
            self.collect = ansible.module_utils.facts.system.distribution.DistributionFact

# Generated at 2022-06-17 02:39:17.852098
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import search_file_for_string

# Generated at 2022-06-17 02:39:28.847561
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            return path

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

    class MockPath(object):
        def __init__(self):
            self.exists = Mock(return_value=False)

        def islink(self, path):
            return False

        def basename(self, path):
            return path


# Generated at 2022-06-17 02:39:39.353109
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, binary: '/bin/' + binary,
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
    })()

    # Create a mock ansible module
    mock_ansible_module = type('AnsibleModule', (object,), {
        'params': {},
        'fail_json': lambda self, *args, **kwargs: None,
        'exit_json': lambda self, *args, **kwargs: None,
    })()



# Generated at 2022-06-17 02:39:48.876827
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/bin/' + name

    class MockCollector(BaseFactCollector):
        def __init__(self):
            self.name = 'mock'
            self.required_facts = set()

    class MockCollectedFacts(object):
        def __init__(self):
            self.facts = {}

    # Test case 1: /sbin/init is a symlink to systemd
    module = MockModule()
    collector = MockCollector()
    collected_facts = Mock

# Generated at 2022-06-17 02:39:54.382962
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module
    module = BaseFactCollector()
    module.tmpdir = tmpdir

    # Create a temporary systemd directory
    systemd_dir = os.path.join(tmpdir, 'systemd')
    os.mkdir(systemd_dir)

    # Create a temporary init symlink
    init_symlink = os.path.join(tmpdir, 'sbin', 'init')

# Generated at 2022-06-17 02:40:05.679812
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name):
            return self.bin_path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    # Mock module with systemctl installed
    module = MockModule(bin_path='/bin/systemctl')
    base_fact_collector = MockBaseFactCollector(module=module)

# Generated at 2022-06-17 02:40:18.478326
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self):
            self.run_command = ansible.module_utils.facts.utils.get_file_content

        def get_bin_path(self, name, required=False):
            return '/bin/' + name

    class MockFactsCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        def __init__(self, module):
            self.module = module
            self.collect()

        def collect(self):
            self.facts = {'ansible_system': 'Linux'}


# Generated at 2022-06-17 02:40:30.092930
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}


# Generated at 2022-06-17 02:40:38.446530
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

    # Create a mock module
    module = ansible.module_utils.facts.collector.BaseFactCollector()
    module.get_bin_path = lambda x: '/bin/systemctl'

    # Create a mock os module
    os = ansible.module_utils.facts.system.service_mgr.os
    os.path.exists = lambda x: True

    # Create a mock platform module
    platform = ansible.module_utils.facts.system.service_mgr.platform
    platform.system = lambda: 'Linux'

    # Create a mock open function

# Generated at 2022-06-17 02:40:48.258587
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    class MockCollectedFacts(object):
        def __init__(self):
            self.facts = {}

        def get(self, key, default=None):
            return self.facts.get(key, default)

    class MockOs(object):
        def __init__(self):
            self

# Generated at 2022-06-17 02:41:33.869187
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule

    module = MockModule()
    module.run_command = lambda x: (0, 'systemd', '')
    module.get_bin_path = lambda x: '/bin/systemctl'
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    module.run_command = lambda x: (0, '', '')
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

    module.run_command = lambda x: (0, 'systemd', '')
    module.get_bin_path = lambda x: None
    assert not ServiceMgrFactCollector.is_systemd_managed_offline

# Generated at 2022-06-17 02:41:40.691935
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:41:49.922469
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collect

# Generated at 2022-06-17 02:41:55.711046
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    # Test case 1: systemctl is not installed
    module = FakeModule(bin_path=None)
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

    # Test case 2: systemctl is installed, but no systemd canary files exist
    module = FakeModule(bin_path='/bin/systemctl')
   

# Generated at 2022-06-17 02:42:00.801530
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import shutil
    import tempfile

    class MockModule(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def get_bin_path(self, name):
            return os.path.join(self.tmpdir, name)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary systemd binary
    systemd_bin = os.path.join(tmpdir, 'systemctl')

# Generated at 2022-06-17 02:42:11.696574
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, command):
            return command

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    # Create a mock module
    module = MockModule()

    # Create a mock BaseFactCollector
    base_fact_collector = MockBaseFactCollector()

    # Create a mock ServiceMgrFactCollector
    service_mgr_fact_collector = Mock

# Generated at 2022-06-17 02:42:22.566307
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, name):
            if name == 'systemctl':
                return self.path

    class MockOs(object):
        def __init__(self, path_exists):
            self.path_exists = path_exists

        def path(self, path):
            return MockPath(self.path_exists)

    class MockPath(object):
        def __init__(self, path_exists):
            self

# Generated at 2022-06-17 02:42:30.253193
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, name):
            return '/bin/' + name

    class MockFile(object):
        def __init__(self, exists):
            self.exists = exists

        def exists(self):
            return self.exists

    class MockOs(object):
        def __init__(self, islink, readlink):
            self.islink = islink
            self.readlink = readlink

        def islink(self, path):
            return self.islink

        def readlink(self, path):
            return self.readlink


# Generated at 2022-06-17 02:42:39.526527
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Test with no module argument
    result = ServiceMgrFactCollector.collect()
    assert result == {}

    # Test with module argument, but no facts
    result = ServiceMgrFactCollector.collect(module=None)
    assert result == {}

    # Test with module argument, but no facts
    result = ServiceMgrFactCollector.collect(module=None, collected_facts={})
    assert result == {}

    # Test with module argument, but no facts
    result = ServiceMgrFactCollector.collect(module=None, collected_facts={'ansible_distribution': 'MacOSX'})
    assert result == {}

    # Test with module argument, but no facts
    result = ServiceMgrFactCollector.collect(module=None, collected_facts={'ansible_distribution': 'OpenWrt'})
    assert result

# Generated at 2022-06-17 02:42:50.939481
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_facts
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_

# Generated at 2022-06-17 02:44:20.345632
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    import os

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.paths = []

        def get_bin_path(self, path):
            if path in self.paths:
                return path
            else:
                return None

    class MockOs(object):
        def __init__(self):
            self.paths = []

        def path(self, path):
            if path in self.paths:
                return True
            else:
                return False

        def islink(self, path):
            if path in self.paths:
                return True

# Generated at 2022-06-17 02:44:30.229393
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, command):
            return self.bin_path

    # Test when systemctl is not installed
    module = MockModule(bin_path=None)
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

    # Test when systemctl is installed but systemd is not used
    module = MockModule(bin_path='/usr/bin/systemctl')
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

    # Test when system

# Generated at 2022-06-17 02:44:39.601937
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import PY3

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None
            self.exit_json = lambda **kwargs: None

        def get_bin_path(self, executable):
            return executable

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content


# Generated at 2022-06-17 02:44:51.317999
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None
            self.run_command = lambda **kwargs: None
            self.get_bin_path = lambda **kwargs: None

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()


# Generated at 2022-06-17 02:45:02.848009
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, systemctl_path):
            self.systemctl_path = systemctl_path

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return self.systemctl_path

    # Test with systemctl installed
    module = MockModule('/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False

    # Test with systemctl not installed
    module = MockModule(None)
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False

    # Test with systemctl installed

# Generated at 2022-06-17 02:45:12.863703
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def get_bin_path(self, name):
            return '/bin/' + name

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set()
        required_facts = set()

    fake_module = FakeModule()
    fake_collector = FakeCollector()
    fake_collector.module = fake_module
    service_mgr_collector = ServiceMgrFactCollector()
    service_mgr_collector.module = fake_module

    # Test for systemd

# Generated at 2022-06-17 02:45:22.363825
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    class MockFacts(object):
        def __init__(self):
            self.facts = {}

        def __getitem__(self, key):
            return self.facts[key]

        def __setitem__(self, key, value):
            self.facts[key] = value

        def __contains__(self, key):
            return key in self.facts

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set()
        required_facts = set()


# Generated at 2022-06-17 02:45:27.750103
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

    class MockFile(object):
        def __init__(self, path, content):
            self.path = path
            self.content = content

        def exists(self):
            return self.content is not None

        def readlink(self):
            return self.content

    class MockOs(object):
        def __init__(self):
            self.files = {}


# Generated at 2022-06-17 02:45:36.808034
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

# Generated at 2022-06-17 02:45:44.202527
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, cmd):
            return self.path

    class MockOs(object):
        def __init__(self, path):
            self.path = path

        def exists(self, path):
            return self.path

    class MockOsPath(object):
        def __init__(self, path):
            self.path = path

        def islink(self, path):
            return self.path
