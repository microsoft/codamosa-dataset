

# Generated at 2022-06-17 02:37:33.229671
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_selinux

# Generated at 2022-06-17 02:37:43.370753
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

# Generated at 2022-06-17 02:37:55.885290
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/bin/' + name

    module = MockModule()
    fact_collector = ServiceMgrFactCollector(module=module)

    # Test with /sbin/init symlinked to systemd
    os.symlink('/bin/systemd', '/sbin/init')
    assert fact_collector.is_systemd_managed_offline(module)

    # Test with /sbin/init symlinked to something else

# Generated at 2022-06-17 02:38:07.537596
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def get_bin_path(self, path):
            return path

    test_module = TestModule()

    # Test case 1:
    # Test with /run/systemd/system/
    # Expected result: True
    test_collector = ServiceMgrFactCollector()
    assert test_collector.is_systemd_managed(test_module) == True

    # Test case 2:
    # Test with /dev/.run/systemd/
    # Expected result: True
    test_collector = ServiceMgrFactCollector()

# Generated at 2022-06-17 02:38:15.782874
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            return path

    class MockFile(object):
        def __init__(self, path):
            self.path = path

        def exists(self):
            return True

        def islink(self):
            return True

        def readlink(self):
            return self.path

    class MockOs(object):
        def __init__(self):
            self.files = {}

        def path(self, path):
            return MockFile(path)


# Generated at 2022-06-17 02:38:25.373307
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def __init__(self, systemctl_path):
            self.systemctl_path = systemctl_path

        def get_bin_path(self, binary):
            if binary == 'systemctl':
                return self.systemctl_path

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class FakeCollectedFacts(object):
        def __init__(self, ansible_system):
            self.ansible_system = ansible_system


# Generated at 2022-06-17 02:38:34.993936
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = lambda x, use_unsafe_shell=False: (0, '', '')
            self.get_bin_path = lambda x: None

    class MockFactCollector(FactCollector):
        def __init__(self):
            self.collectors = [ServiceMgrFactCollector]
            self.collected_facts = {}

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.module = Mock

# Generated at 2022-06-17 02:38:42.095175
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, name):
            return '/bin/' + name

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = [ServiceMgrFactCollector()]

    class TestFacts(object):
        def __init__(self):
            self.facts = dict()

        def get(self, key, default=None):
            return self.facts.get(key, default)


# Generated at 2022-06-17 02:38:49.952010
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:38:59.773487
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Test with a mocked module
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}


# Generated at 2022-06-17 02:39:24.889830
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda **kwargs: None

        def get_bin_path(self, name, required=False):
            return '/bin/' + name

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}


# Generated at 2022-06-17 02:39:30.710120
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, 'init', ''),
        'get_bin_path': lambda *args, **kwargs: '/bin/systemctl',
    })

    # Create a mock AnsibleModule instance
    mock_am = mock_module()

    # Create a ServiceMgrFactCollector instance
    service_mgr_fc = ServiceMgrFactCollector()

    # Test the collect method
    service_mgr_facts = service_mgr_fc.collect(module=mock_am)
    assert service_mgr_facts['service_mgr'] == 'systemd'

# Generated at 2022-06-17 02:39:43.395609
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a fake module
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_environ_update = {}
            self.run_command_stdout_lines = []
            self.run_command_rc = 0
            self.run_command_stderr = ''

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, use_unsafe_shell=False):
            return self.run_command_rc, self.run_command_stdout

# Generated at 2022-06-17 02:39:55.603692
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_2 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_3 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_4 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_5 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_6 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_7 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_8

# Generated at 2022-06-17 02:40:07.271279
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None
            self.run_command = lambda **kwargs: (0, 'systemd', '')
            self.get_bin_path = lambda **kwargs: '/sbin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    mock_module = Mock

# Generated at 2022-06-17 02:40:19.048488
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import PY3

    class MockModule(object):
        def __init__(self, systemctl_path, systemd_canaries):
            self.systemctl_path = systemctl_path
            self.systemd_canaries = systemd_canaries

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return self.systemctl_path
            else:
                return None

    class MockFile(object):
        def __init__(self, content):
            self.content = content

       

# Generated at 2022-06-17 02:40:30.244070
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a mock module
    module = type('', (), {})()
    module.get_bin_path = lambda x: '/bin/systemctl'
    module.run_command = lambda x: (0, '', '')

    # Create a mock os
    os = type('', (), {})()
    os.path = type('', (), {})()
    os.path.islink = lambda x: True
    os.path.basename = lambda x: 'systemd'
    os.readlink = lambda x: '/bin/systemd'

    # Create a mock platform
    platform = type('', (), {})()
    platform.system = lambda: 'Linux'

    # Create a mock LooseVersion
    LooseVersion = type('', (), {})()
    LooseVersion.__init__ = lambda x, y: None

   

# Generated at 2022-06-17 02:40:36.975578
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid


# Generated at 2022-06-17 02:40:46.926195
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.service_mgr as service_mgr
    import ansible.module_utils.facts.collectors.system as system
    import ansible.module_utils.facts.collectors.distribution as distribution
    import ansible.module_utils.facts.collectors.platform as platform
    import ansible.module_utils.facts.collectors.pkg_mgr as pkg_mgr

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.run_command_result = (0, '', '')
            self.run_command_exception = None
            self.run_command_rc = 0


# Generated at 2022-06-17 02:40:57.154250
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/bin/' + executable

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_calls.append(cmd)
            if cmd == "ps -p 1 -o comm|tail -n 1":
                return 0, "init\n", ""
            elif cmd == "systemctl":
                return 0, "", ""

# Generated at 2022-06-17 02:41:41.249624
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a mock module
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value='/bin/systemctl')

    # Create a mock os
    os = MockOS()
    os.path.exists = Mock(return_value=True)

    # Create a mock platform
    platform = MockPlatform()
    platform.system = Mock(return_value='Linux')

    # Create a mock ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test if the method is_systemd_managed returns True
    assert service_mgr_fact_collector.is_systemd_managed(module) == True


# Generated at 2022-06-17 02:41:52.973042
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, executable):
            return executable

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content


# Generated at 2022-06-17 02:42:05.307752
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, command):
            if command == 'systemctl':
                return '/bin/systemctl'
            return None

    class MockOs(object):
        def __init__(self, path):
            self.path = path

        def islink(self, path):
            return path == '/sbin/init'

        def readlink(self, path):
            if path == '/sbin/init':
                return 'systemd'

# Generated at 2022-06-17 02:42:14.360924
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return "/bin/%s" % name

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            pass

    mock_module = MockModule()
    mock_base_fact_collector = MockBaseFactCollector()


# Generated at 2022-06-17 02:42:24.951488
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 02:42:36.676132
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

# Generated at 2022-06-17 02:42:48.977295
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFile
    from ansible.module_utils.facts.collector import MockCommand

    # Mock module
    module = MockModule()

    # Mock facts
    collected_facts = {
        'ansible_distribution': 'OpenWrt',
        'ansible_system': 'Linux',
    }

    # Mock commands

# Generated at 2022-06-17 02:43:00.481799
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    # Create a mock module
    class MockModule2(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return None
            else:
                return

# Generated at 2022-06-17 02:43:05.298083
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.module = TestModule()

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.base_fact_collector = TestBaseFactCollector()

    test_service_mgr_fact_collector = TestServiceMgrFactCollector()

    # Test with /sbin

# Generated at 2022-06-17 02:43:15.387610
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}


# Generated at 2022-06-17 02:44:31.120234
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/bin/' + name

    class FakeFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class FakeOs(object):
        def __init__(self):
            self.path = FakePath()

        def readlink(self, path):
            return path


# Generated at 2022-06-17 02:44:36.963296
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Mock module
    class MockModule:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, path):
            return path

        def run_command(self, cmd, use_unsafe_shell=False):
            return (0, '', '')

    # Mock module facts
    class MockModuleFacts:
        def __init__(self):
            self.facts = {}


# Generated at 2022-06-17 02:44:48.175604
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a mock module
    module.get_bin_path = MagicMock(return_value='/bin/systemctl')

    # Create a mock os
    os = MagicMock()
    os.path.islink = MagicMock(return_value=True)
    os.path.basename = MagicMock(return_value='systemd')

    # Create a mock os.readlink
    os.readlink = MagicMock(return_value='/sbin/init')

    # Create a mock ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test if is_systemd_managed_offline returns True
    assert service_mgr_fact_collector.is_systemd

# Generated at 2022-06-17 02:44:57.165684
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_instance_by_name
    from ansible.module_utils.facts.collector import get_collector_instance_by_fact_name

# Generated at 2022-06-17 02:45:04.185136
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

    class FakeFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content


# Generated at 2022-06-17 02:45:12.988735
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFile
    from ansible.module_utils.facts.collector import MockOS

    # Create a mock module
    module = MockModule()

    # Create a mock file
    file = MockFile()

    # Create a mock os
    os = MockOS()

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test is_systemd_managed method
    # Test case 1: systemd is the boot init system
    os.path.exists.return_value = True
    assert service_mgr_fact_collector.is_systemd_managed(module) == True

    # Test case 2: systemd is not the boot init system

# Generated at 2022-06-17 02:45:22.425682
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collectors.service_mgr as service_mgr_collector
    import ansible.module_utils.facts.utils as utils
    import os

    class FakeModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, executable):
            return os.path.join(self.path, executable)

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set()
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {}

    # Test with no tools installed
    module = FakeModule('/nonexistent')
    collector

# Generated at 2022-06-17 02:45:27.768846
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:45:36.808436
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform

# Generated at 2022-06-17 02:45:44.196452
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/bin/' + name

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class FakeCollectedFacts(object):
        def __init__(self):
            self.collected_facts = {}

    class FakeOs(object):
        def __init__(self):
            self.path = FakePath()

    class FakePath(object):
        def __init__(self):
            self.isl