

# Generated at 2022-06-17 02:37:28.748390
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda *args, **kwargs: (0, 'systemd', None)
            self.get_bin_path = lambda *args, **kwargs: '/bin/systemctl'

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    fake_module = FakeModule()
    fake_base_fact_collector = FakeBaseFactCollector()
    service_mgr_fact_collector = ServiceMgrFactCollector(fake_base_fact_collector)

    assert service

# Generated at 2022-06-17 02:37:36.958203
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    class MockOs(object):
        def __init__(self, islink, readlink):
            self.islink = islink
            self.readlink = readlink

        def islink(self, path):
            return self.islink

        def readlink(self, path):
            return self.readlink


# Generated at 2022-06-17 02:37:47.216030
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, check_rc=True: (0, '', ''),
        'get_bin_path': lambda self, name, opt_dirs=[] : '/usr/bin/' + name,
        'fail_json': lambda self, *args, **kwargs: None
    })()

    # Create a mock collected_facts
    mock_collected_facts = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': 'Darwin',
    }

    # Create a ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the collect method

# Generated at 2022-06-17 02:37:56.636084
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Test with a mocked module
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFile
    from ansible.module_utils.facts.collector import MockCommand
    from ansible.module_utils.facts.collector import MockFileContent
    from ansible.module_utils.facts.collector import MockFileExists
    from ansible.module_utils.facts.collector import MockFileIsLink
    from ansible.module_utils.facts.collector import MockFileReadLink
    from ansible.module_utils.facts.collector import MockFileStat

    # Create a mock module
    module = MockModule()

    # Create a mock file
    file = MockFile()

    # Create a mock command
    command = MockCommand()

    # Create a mock

# Generated at 2022-06-17 02:38:08.269991
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None
            self.exit_json = lambda **kwargs: None

        def get_bin_path(self, executable):
            return executable

    # Create a dummy module
    module = DummyModule()

    # Create a dummy class
    class DummyBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.name = 'dummy'
            self

# Generated at 2022-06-17 02:38:15.131683
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    module = MockModule()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module)

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module)

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module)

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module)

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module)

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module)

# Generated at 2022-06-17 02:38:24.798690
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:38:30.876348
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

    # Create a mock module
    module = ansible.module_utils.facts.collector.BaseFactCollector()

    # Create a mock systemctl command
    module.get_bin_path = lambda x: '/usr/bin/systemctl'

    # Create a mock os.path.exists
    import os
    os.path.exists = lambda x: True

    # Test if systemd is detected
    assert ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed(module) == True

    # Create a mock os.path.exists

# Generated at 2022-06-17 02:38:40.358237
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:38:49.295609
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:39:15.746135
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_environ_update = {}

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == 'ps -p 1 -o comm|tail -n 1':
                return 0, 'systemd',

# Generated at 2022-06-17 02:39:26.150101
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    # Create a mock module
    mock_module = MockModule()

    # Create a mock

# Generated at 2022-06-17 02:39:33.236590
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_2 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_3 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_4 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_5 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_6 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_7 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_8

# Generated at 2022-06-17 02:39:44.973330
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_stat

# Generated at 2022-06-17 02:39:55.718750
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = '/tmp'

        def get_bin_path(self, executable):
            return '/bin/' + executable

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set()
        required_facts = set()

    class FakeFacts(object):
        def __init__(self):
            self.collectors = [FakeCollector()]
            self.ansible_facts = {}


# Generated at 2022-06-17 02:40:07.569437
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            return path

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set()
        required_facts = set()

    class MockFile(object):
        def __init__(self, path):
            self.path = path

        def exists(self):
            return os.path.exists(self.path)


# Generated at 2022-06-17 02:40:15.816659
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, path):
            if path == 'systemctl':
                return self.path
            else:
                return None

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self, path_exists, is_link, read_link):
            self.path

# Generated at 2022-06-17 02:40:22.070397
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    # Mock the get_file_content function
    def mock_get_file_content(path):
        if path == '/proc/1/comm':
            return 'systemd'
       

# Generated at 2022-06-17 02:40:27.744258
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, path: path,
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', '')
    })()

    # Create a mock collected_facts
    mock_collected_facts = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': 'Darwin',
        'platform': 'Darwin',
        'distribution': 'MacOSX'
    }

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector_obj = ServiceMgrFactCollector()

    # Test the collect method

# Generated at 2022-06-17 02:40:36.403476
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.module = TestModule()

    # Test 1: /sbin/init is a symlink to systemd
    os.symlink('/bin/systemd', '/sbin/init')


# Generated at 2022-06-17 02:41:14.568450
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            return '/bin/' + arg

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

        class MockPath(object):
            def __init__(self):
                self.exists = Mock

# Generated at 2022-06-17 02:41:20.871472
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    # Test with systemctl installed and systemd canary files present
    module = TestModule('/usr/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(module)

    # Test with systemctl installed and systemd canary files not present
    module = TestModule('/usr/bin/systemctl')
    assert not Service

# Generated at 2022-06-17 02:41:29.113554
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts.utils import MockCommand

    module = MockModule()
    module.run_command = MockCommand()

# Generated at 2022-06-17 02:41:41.476315
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil
    import pytest

    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/bin/systemctl'

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.module = TestModule()

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary systemd init symlink

# Generated at 2022-06-17 02:41:53.307491
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name):
            return self.bin_path

    class MockFactCollector(BaseFactCollector):
        name = 'mock'

    # Test with systemctl not installed
    module = MockModule(bin_path=None)
    collector = MockFactCollector(module=module)
    assert not collector.is_systemd_managed(module=module)

    # Test with systemctl installed but no canary files
   

# Generated at 2022-06-17 02:42:05.528650
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = MockModule.run_command
        def get_bin_path(self, path):
            return path
        @staticmethod
        def run_command(command, use_unsafe_shell=False):
            return 0, '', ''
    module = MockModule()

    # Create a mock collected_facts
    collected_facts = {}

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the collect method
    service_mgr_fact_collector.collect(module=module, collected_facts=collected_facts)

    # Assert that the service_mgr fact is present in the collected_facts

# Generated at 2022-06-17 02:42:14.725887
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.service_mgr as service_mgr

    # Test with a module that has systemctl
    class MockModule:
        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/bin/systemctl'
            return None

    # Test with a module that does not have systemctl
    class MockModule2:
        def get_bin_path(self, cmd):
            return None

    # Test with a module that has systemctl and a canary file
    class MockModule3:
        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/bin/systemctl'
            return None


# Generated at 2022-06-17 02:42:25.034427
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockModule2(object):
        def get_bin_path(self, arg):
            return None

    class MockModule3(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

        def run_command(self, arg, use_unsafe_shell=True):
            return 0, '', ''

    class MockModule4(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

        def run_command(self, arg, use_unsafe_shell=True):
            return 1, '', ''


# Generated at 2022-06-17 02:42:36.748952
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Test ServiceMgrFactCollector.collect()
    """
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    mock_module = ansible.module_utils.facts.collector.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a mock AnsibleModule object
    am = ansible.module_utils.facts.collector.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Set module.run_

# Generated at 2022-06-17 02:42:49.016110
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os

    # Create a BaseFactCollector object
    base_fact_collector = BaseFactCollector()

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None
            self.run_command = None
            self.get_bin_path = None


# Generated at 2022-06-17 02:43:58.384254
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockCollectedFacts(object):
        def __init__(self):
            self.ansible_facts = {}

    # Create a MockModule object
    mock_module = MockModule()

    # Create a MockBaseFactCollector object
    mock_base_fact_collector = MockBaseFactCollector()

    # Create a MockCollectedFacts object
    mock_collected_facts = MockCollectedF

# Generated at 2022-06-17 02:44:06.204324
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import search_file
    from ansible.module_utils.facts.utils import search_file_for_string

# Generated at 2022-06-17 02:44:17.415295
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution

# Generated at 2022-06-17 02:44:29.000555
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, command):
            return '/bin/' + command

        def run_command(self, command, use_unsafe_shell=False):
            self.run_command_calls.append((command, use_unsafe_shell))
            return 0, '', ''

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collect_called = 0
            self

# Generated at 2022-06-17 02:44:35.192318
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            return path

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set()
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {}

    class FakeFacts(object):
        def __init__(self):
            self.collectors = [FakeCollector()]
            self.collector_classes = [FakeCollector]
            self.all_facts = {}


# Generated at 2022-06-17 02:44:45.116877
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.system import SystemFactCollector
    from ansible.module_utils.facts.system.path import PathFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector

# Generated at 2022-06-17 02:44:56.346028
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'

    class MockFile(object):
        def __init__(self, path):
            self.path = path

        def exists(self):
            return self.path in ['/run/systemd/system/', '/dev/.run/systemd/', '/dev/.systemd/']

    class MockOs(object):
        def __init__(self):
            self.path = MockFile('')

        def islink(self, path):
            return False

        def readlink(self, path):
            return 'systemd'

# Generated at 2022-06-17 02:45:04.034379
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.facts = {}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.facts = {}

    def mock_get_file_content(path):
        if path == '/sbin/init':
            return 'systemd'
        return None

    # test when /sbin/init is a

# Generated at 2022-06-17 02:45:12.879871
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, name):
            return '/bin/' + name

    class MockFacts(object):
        def __init__(self):
            self.facts = {}

        def get(self, name):
            return self.facts.get(name)

        def set(self, name, value):
            self.facts[name] = value

    module = MockModule()
    facts = MockFacts()

    # test with systemd
    facts.set('ansible_system', 'Linux')
    facts.set('ansible_distribution', 'Fedora')

# Generated at 2022-06-17 02:45:22.395329
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockFile(object):
        def __init__(self, path):
            self.path = path

        def exists(self):
            return self.path in ['/run/systemd/system/', '/dev/.run/systemd/', '/dev/.systemd/']

    class MockOs(object):
        def __init__(self):
            self.path = MockFile('/run/systemd/system/')
