

# Generated at 2022-06-17 02:37:33.542670
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class MockFile(object):
        def __init__(self, name):
            self.name = name

        def islink(self):
            return True

        def readlink(self):
            return 'systemd'

# Generated at 2022-06-17 02:37:44.631514
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return executable

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    test_module = TestModule()
    test_base_fact_collector = TestBaseFactCollector()
    test

# Generated at 2022-06-17 02:37:55.959350
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collectors.service_mgr as service_mgr
    import ansible.module_utils.facts.collectors.system as system
    import ansible.module_utils.facts.collectors.distribution as distribution

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.run_command = lambda x, y: (0, 'systemd', '')
            self.get_bin_path = lambda x: '/bin/systemctl'
            self.get_bin_path.__name__ = 'get_bin_path'
            self.run_command.__name__ = 'run_command'

    # Create a mock ansible module
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

# Generated at 2022-06-17 02:38:07.644280
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, command):
            if command == 'systemctl':
                return self.path

    class MockOs(object):
        def __init__(self, path):
            self.path = path

        def exists(self, path):
            return self.path == path

    class MockOsPath(object):
        def __init__(self, path):
            self.path = path

        def islink(self, path):
            return self.path == path

        def basename(self, path):
            return

# Generated at 2022-06-17 02:38:15.820377
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, path):
            return self.path

    class MockOs(object):
        def __init__(self, path):
            self.path = path

        def path(self, path):
            return self.path

    class MockOsPath(object):
        def __init__(self, path):
            self.path = path

        def exists(self, path):
            return self.path


# Generated at 2022-06-17 02:38:25.409944
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_device
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 02:38:34.991801
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts.utils import MockCommand
    from ansible.module_utils.facts.utils import MockFile

    # Create a mock module
    module = MockModule()

    # Create a mock command
    command = MockCommand()

    # Create a mock file
    file = MockFile()

    # Create a mock service manager fact collector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Create a mock system
    system = 'Linux'

    # Create a mock distribution
    distribution = 'SUSE'

    # Create a mock service manager
    service_mgr = 'systemd'

    # Create a mock service manager name
    service

# Generated at 2022-06-17 02:38:43.949381
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def __init__(self, systemctl_path):
            self.systemctl_path = systemctl_path

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                return self.systemctl_path

    class FakeOs(object):
        def __init__(self, exists_return_value):
            self.exists_return_value = exists_return_value

        def exists(self, path):
            return self.exists_return_value


# Generated at 2022-06-17 02:38:51.140131
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class MockFile(object):
        def __init__(self, path):
            self.path = path

        def exists(self):
            if self.path == '/run/systemd/system/':
                return True
            else:
                return False


# Generated at 2022-06-17 02:39:00.625712
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, path):
            return '/bin/' + path

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class MockCollector(Collector):
        def __init__(self, module):
            self.module = module
            self.facts = {}

        def collect(self, module=None, collected_facts=None):
            return self.facts

    class MockDistribution(object):
        def __init__(self, name):
            self.name = name

   

# Generated at 2022-06-17 02:39:24.466480
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/bin/systemctl'

    class MockFacts(object):
        def __init__(self):
            self.facts = {}

    class MockCollector(BaseFactCollector):
        def __init__(self):
            self.name = 'mock'
            self.collected_facts = {}

    class MockFile(object):
        def __init__(self):
            self.content = ''


# Generated at 2022-06-17 02:39:32.108680
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
   

# Generated at 2022-06-17 02:39:44.896640
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    class MockOs(object):
        def path_exists(self, path):
            return True

        def is_link(self, path):
            return True

        def readlink(self, path):
            return 'systemd'

    class MockOsPath(object):
        def islink(self, path):
            return True

        def readlink(self, path):
            return 'systemd'


# Generated at 2022-06-17 02:39:55.717687
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, path: path,
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', '')
    })

    # Create a mock collected_facts
    mock_collected_facts = {
        'ansible_distribution': 'OpenWrt',
        'ansible_system': 'Linux'
    }

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the collect method
    assert service_mgr_fact_collector.collect(mock_module, mock_collected_facts) == {'service_mgr': 'openwrt_init'}

# Generated at 2022-06-17 02:40:07.569831
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform

    # Create a mock module
    module = ansible.module_utils.facts.collector.BaseFactCollector()
    module.get_bin_path = lambda x: '/bin/systemctl'
    module.run_command = lambda x, y: (0, '', '')

    # Create a mock distribution
    distribution = ansible.module_utils.facts.system.distribution.DistributionFactCollector()
    distribution.collect = lambda x: {'ansible_distribution': 'SUSE'}

    # Create a mock platform
    platform = ansible.module_utils

# Generated at 2022-06-17 02:40:19.149668
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, command):
            if command in self.bin_path:
                return self.bin_path[command]
            return None

    class TestAnsibleModule(object):
        def __init__(self, bin_path):
            self.module = TestModule(bin_path)

        def get_bin_path(self, command):
            return self.module.get_bin_path(command)


# Generated at 2022-06-17 02:40:30.271434
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = AnsibleModuleMock()
    module.get_bin_path = lambda x: '/bin/systemctl'
    os.path.islink = lambda x: True
    os.readlink = lambda x: '/sbin/init'
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == True
    os.path.islink = lambda x: False
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False
    os.path.islink = lambda x: True
    os.readlink = lambda x: '/sbin/init.d'
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False
    os.path.islink = lambda x: True

# Generated at 2022-06-17 02:40:39.499741
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid
    from ansible.module_utils.facts.utils import get_file_mode
    from ansible.module_utils.facts.utils import get_file_mtime


# Generated at 2022-06-17 02:40:49.133259
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, path):
            return os.path.join(self.path, path)

    class MockFactsCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set()
        required_facts = set()


# Generated at 2022-06-17 02:40:59.565542
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            return path

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

    class MockPath(object):
        def __init__(self):
            self.exists_return_value = False



# Generated at 2022-06-17 02:41:35.896197
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule

    module = MockModule()
    module.get_bin_path = lambda x: '/bin/systemctl'
    module.run_command = lambda x: (0, '', '')

    # Test with /sbin/init symlinked to systemd
    os.symlink('/bin/systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test with /sbin/init not symlinked to systemd
    os.unlink('/sbin/init')
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

# Generated at 2022-06-17 02:41:47.361441
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    import stat
    import subprocess
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary 'ansible_module_utils.facts' module
    module_utils_facts = os.path.join(tmpdir, 'ansible_module_utils')
    os.mkdir(module_utils_facts)
    init_py = os.path.join(module_utils_facts, '__init__.py')
    with open(init_py, 'w') as f:
        f.write('\n')

# Generated at 2022-06-17 02:41:58.099772
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    test_module = TestModule()
    test_base_fact_collector = TestBaseFactCollector(test_module)

# Generated at 2022-06-17 02:42:12.244173
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()


# Generated at 2022-06-17 02:42:22.596995
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:42:30.277494
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, check_rc=True: (0, '', ''),
        'get_bin_path': lambda self, name, opt_dirs=[] : '/bin/' + name,
        'fail_json': lambda self, *args, **kwargs: None
    })()

    # Create a mock ansible module

# Generated at 2022-06-17 02:42:39.548139
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, path):
            return self.params.get(path)

        def run_command(self, cmd, use_unsafe_shell=False):
            return self.params.get(cmd)

    class MockFacts(object):
        def __init__(self, facts):
            self.facts = facts

        def __getitem__(self, key):
            return self.facts.get(key)

    # Test with systemd

# Generated at 2022-06-17 02:42:50.940031
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'

    class MockOs(object):
        def path(self, path):
            return True

    class MockOsPath(object):
        def exists(self, path):
            return True

    class MockOsReadlink(object):
        def readlink(self, path):
            return 'systemd'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-17 02:43:00.589770
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['path'] = '/bin:/usr/bin:/sbin:/usr/sbin'

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []
            self.collectors.append(ServiceMgrFactCollector())


# Generated at 2022-06-17 02:43:04.993627
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'

    class FakeModule2(object):
        def get_bin_path(self, name):
            return None

    class FakeModule3(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

    class FakeModule4(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'


# Generated at 2022-06-17 02:43:53.670691
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_gid
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_mode

# Generated at 2022-06-17 02:43:59.392129
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, path: '/bin/' + path,
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
    })()

    # Create a mock collected facts
    mock_collected_facts = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': 'Darwin',
    }

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the method collect

# Generated at 2022-06-17 02:44:08.121570
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, systemctl_path):
            self.systemctl_path = systemctl_path

        def get_bin_path(self, name):
            if name == 'systemctl':
                return self.systemctl_path

    class MockOs(object):
        def __init__(self, path_exists):
            self.path_exists = path_exists

        def path(self, path):
            return MockPath(self.path_exists)

    class MockPath(object):
        def __init__(self, path_exists):
            self.path_exists = path

# Generated at 2022-06-17 02:44:18.052588
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

# Generated at 2022-06-17 02:44:29.190843
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:44:39.447443
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_

# Generated at 2022-06-17 02:44:51.208974
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a fake module
    class FakeModule:
        def get_bin_path(self, path):
            return '/bin/systemctl'

    # Create a fake ansible module
    module = FakeModule()

    # Create a fake os module
    class FakeOs:
        def path(self, path):
            return True

        def readlink(self, path):
            return '/bin/systemd'

    # Create a fake os module
    os = FakeOs()

    # Create a fake platform module
    class FakePlatform:
        def system(self):
            return 'Linux'

    # Create a fake platform module
    platform = FakePlatform()

    # Create a fake ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Check if the method is_systemd_managed returns

# Generated at 2022-06-17 02:45:02.848211
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/bin/' + name

    class FakeFactCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            return {}

    fake_module = FakeModule()
    fake_fact_collector = FakeFactCollector()
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test with a canary file that exists

# Generated at 2022-06-17 02:45:12.447751
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule:
        def get_bin_path(self, name):
            return '/bin/' + name

    test_module = TestModule()

    # Test case: systemd is not the boot init system
    os.symlink('/bin/init', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(test_module) == False
    os.unlink('/sbin/init')

    # Test case: systemd is the boot init system
    os.symlink('/bin/systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_

# Generated at 2022-06-17 02:45:16.775321
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['path'] = '/usr/bin:/bin'
            self.params['_uses_shell'] = True
            self.params['_raw_params'] = 'ls -l /'
            self.params['_diff'] = False
            self.params['_ansible_check_mode'] = False
            self.params['_ansible_verbosity'] = 0
            self.params['_ansible_no_log'] = False

# Generated at 2022-06-17 02:46:54.493017
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary 'sbin' directory
    sbindir = os.path.join(tmpdir, 'sbin')
    os.mkdir(sbindir)

    # Create a temporary 'systemctl' file
    systemctl = os.path.join(sbindir, 'systemctl')
    with open(systemctl, 'w') as f:
        f.write('#!/bin/sh\necho "systemd"\n')
    os.chmod(systemctl, 0o755)

    # Create a temporary 'init' file
    init = os.path.join(sbindir, 'init')
    with open(init, 'w') as f:
        f

# Generated at 2022-06-17 02:47:03.921851
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_stat