

# Generated at 2022-06-17 02:37:28.591002
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

    class MockPath(object):
        def __init__(self):
            self.exists_return_value = False

        def exists(self, path):
            return self.exists_return_value

    class MockOsPath(object):
        def __init__(self):
            self

# Generated at 2022-06-17 02:37:36.877193
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFile
    from ansible.module_utils.facts.collector import MockCommand
    from ansible.module_utils.facts.collector import MockOs
    from ansible.module_utils.facts.collector import MockPath

    # Create a mock module
    module = MockModule()

    # Create a mock command
    command = MockCommand()

    # Create a mock file
    file = MockFile()

    # Create a mock os
    os = MockOs()

    # Create a mock path
    path = MockPath()

    # Create a mock service manager fact collector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Create a mock module
    module = MockModule()

   

# Generated at 2022-06-17 02:37:47.181427
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = lambda x, **kwargs: (0, '', '')
            self.get_bin_path = lambda x: '/bin/' + x

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self, is_link, readlink_target):
            self.is_

# Generated at 2022-06-17 02:37:56.609221
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Create a dummy module
    module = type('AnsibleModule', (object,), {'run_command': lambda *args, **kwargs: (0, '', '')})

    # Create a dummy ansible module facts
    collected_facts = {
        'ansible_distribution': 'OpenWrt',
        'ansible_system': 'Linux',
    }

    # Create a dummy collector
    collector = Collector()

    # Create a ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector(module=module, collected_facts=collected_facts)

    # Test the collect method
    assert service_m

# Generated at 2022-06-17 02:38:08.244202
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def get_bin_path(self, binary):
            return binary

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            super(TestServiceMgrFactCollector, self).__init__(module)

    test_module = TestModule()
    test_base_fact_collector = TestBaseFactCollector(test_module)

# Generated at 2022-06-17 02:38:15.107445
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a mock module
    module = MockModule()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module, module_utils)

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test for is_systemd_managed_offline method
    # Create a mock os module
    os_module = MockOsModule()

    # Create a mock os.path module
    os_path_module = MockOsPathModule()

    # Create a mock os.readlink method
    os_readlink_method = MockOsReadlinkMethod()

    # Create a mock os.path.islink method
    os_path_islink_method = Mock

# Generated at 2022-06-17 02:38:24.797332
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils

    class FakeModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, name, required=False):
            if name == 'systemctl':
                return self.path

    class FakeOs(object):
        def __init__(self, path):
            self.path = path

        def path(self, path):
            return self.path

        def islink(self, path):
            return path == '/sbin/init'

        def readlink(self, path):
            return 'systemd'


# Generated at 2022-06-17 02:38:30.905316
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class MockOs(object):
        def __init__(self, path):
            self.path = path

        def path(self, path):
            return self.path

        def islink(self, path):
            return False

        def readlink(self, path):
            return ''

       

# Generated at 2022-06-17 02:38:40.358195
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

# Generated at 2022-06-17 02:38:49.294888
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockCollectedFacts(object):
        def __init__(self):
            self.collected_facts = {}

    # Test 1: /sbin/init is a symlink to systemd
    module = MockModule()
    base_fact_collector = MockBaseFactCollector()
    collected_facts = MockCol

# Generated at 2022-06-17 02:39:16.194652
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

    class MockPath(object):
        def __init__(self):
            self

# Generated at 2022-06-17 02:39:21.618946
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:39:28.878596
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.distribution

    class MockModule:
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                return self.bin_path
            return None

    class MockCollector:
        def __init__(self, facts_dict):
            self.facts_dict = facts_dict

        def collect(self, module=None, collected_facts=None):
            return self.facts_dict


# Generated at 2022-06-17 02:39:39.806108
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution

# Generated at 2022-06-17 02:39:48.897983
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import list_collectors

    # Create a mock module
    module = MockModule()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_no_facts = MockAnsibleModule(facts={})

    # Create a mock ansible module
    ansible_module_no_facts_no_platform = MockAnsibleModule(facts={'distribution': 'RedHat'})

    # Create a mock ansible module

# Generated at 2022-06-17 02:39:53.509254
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    import platform
    import subprocess
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module
    module_path = os.path.join(tmpdir, 'ansible_test_service_mgr.py')

# Generated at 2022-06-17 02:40:03.943383
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:40:17.540866
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return executable

    class MockFile(object):
        def __init__(self, exists):
            self.exists = exists

        def exists(self):
            return self.exists

    class MockOs(object):
        def __init__(self, islink, readlink):
            self.islink = islink
            self.readlink = readlink

        def islink(self, path):
            return self.islink


# Generated at 2022-06-17 02:40:29.995607
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid

# Generated at 2022-06-17 02:40:36.829977
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 02:41:18.547961
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.facts = {}

    class MockGetFileContent(object):
        def __init__(self):
            self.content = None

        def __call__(self, path):
            return self.content

    mock_module = MockModule()
    mock_base_fact_

# Generated at 2022-06-17 02:41:28.693935
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, name, required=False):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set()
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {}

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module

# Generated at 2022-06-17 02:41:41.282037
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content_string

# Generated at 2022-06-17 02:41:53.096554
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    test_module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, path: path,
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, cmd, ''),
    })

    # Create a mock ansible module

# Generated at 2022-06-17 02:42:05.467851
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []

        def get_bin_path(self, path):
            return path

        def run_command(self, cmd, use_unsafe_shell=False):
            return self.run_command_results.pop(0)

    class MockCollector(ansible.module_utils.facts.collector.BaseFactCollector):
        def __init__(self):
            self.collect_called = False
            self.module = MockModule()

        def collect(self, module=None, collected_facts=None):
            self.collect_called = True
            return {}

# Generated at 2022-06-17 02:42:14.674267
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.facts.collector

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module
    module = ansible.module_utils.facts.collector.BaseFactCollector()
    module.tmpdir = tmpdir

    # Create a temporary systemd symlink
    os.symlink('systemd', os.path.join(tmpdir, 'sbin', 'init'))

    # Create a temporary ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Check if systemd is detected
    assert service_mgr_fact_collector.is_systemd_managed_offline(module)

    # Remove the temporary directory
    shutil

# Generated at 2022-06-17 02:42:25.046905
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['path'] = '/bin:/usr/bin'
            self.params['_uses_shell'] = False
            self.params['_raw_params'] = ''
            self.params['_diff'] = False
            self.params['_ansible_check_mode'] = False
            self.params['_ansible_debug'] = False
            self.params['_ansible_verbosity'] = 0
            self.params['_ansible_no_log'] = False

# Generated at 2022-06-17 02:42:28.854095
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'systemctl':
                return self.bin_path

    # systemctl is not installed
    module = MockModule(None)
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

    # systemctl is installed, but /run/systemd/system/ does not exist
    module = MockModule('/bin/systemctl')
    assert not ServiceMgrFactCollector.is_systemd_

# Generated at 2022-06-17 02:42:38.915559
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:42:50.663579
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x
            self.fail_json = lambda x: x

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    # Create a mock facts

# Generated at 2022-06-17 02:43:58.198234
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:44:02.843882
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    class MockFile(object):
        def __init__(self, exists):
            self.exists = exists

        def exists(self, path):
            return self.exists

    class MockOs(object):
        def __init__(self, path):
            self.path = path

        def islink(self, path):
            return self

# Generated at 2022-06-17 02:44:16.301244
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:44:23.911939
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import search_file_for_string
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 02:44:33.109394
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    # Test case 1: systemctl is not installed
    module = MockModule(bin_path=None)
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False

    # Test case 2: systemctl is installed, but /sbin/init is not a symlink to systemd

# Generated at 2022-06-17 02:44:42.939722
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)

    # Create a temporary symlink
    os.symlink('systemd', os.path.join(tmpdir, 'init'))

    # Create a module
    module = ansible.module_utils.facts.collector.BaseFactCollector.create_module()

    # Create a ServiceMgrFactCollector
    service_mgr_fact_collector = ansible.module_

# Generated at 2022-06-17 02:44:52.961930
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    class MockFile(object):
        def __init__(self, exists):
            self.exists = exists

        def exists(self):
            return self.exists

    class MockOs(object):
        def __init__(self, islink, readlink):
            self.islink = islink
            self.readlink = readlink



# Generated at 2022-06-17 02:45:00.217356
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a Collector object
    test_collector = Collector()

    # Create a ServiceMgrFactCollector object
    test_ServiceMgrFactCollector_obj = ServiceMgrFactCollector()

    # Set a test value for ansible_distribution
    test_collector.ansible_facts['ansible_distribution'] = 'MacOSX'

    # Set a test value for ansible_system
    test_collector.ansible_facts['ansible_system'] = 'AIX'

    # Set a test value for ansible_distribution

# Generated at 2022-06-17 02:45:09.906641
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    # Test with systemctl present and no canary files
    module = MockModule(bin_path='/bin/systemctl')
    base_fact_collector = MockBaseFactCollector(module)
    service_

# Generated at 2022-06-17 02:45:20.709820
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule

    module = MockModule()
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda *args, **kwargs: '/bin/systemctl'

    # test for systemd
    module.os.path.islink = lambda *args, **kwargs: True
    module.os.readlink = lambda *args, **kwargs: '/sbin/init'
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # test for non-systemd
    module.os.path.islink = lambda *args, **kwargs: False
    assert not ServiceMgrFactCollect