

# Generated at 2022-06-17 02:37:27.114757
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.get_bin_path_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            self.get_bin_path_calls.append(name)
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_calls

# Generated at 2022-06-17 02:37:36.043866
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    test_module = TestModule()
    test_base_fact_collector = TestBaseFactCollector(test_module)
    test_service_mgr_fact_collector = TestServiceMgrFactCollector(test_module)



# Generated at 2022-06-17 02:37:46.538945
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution

# Generated at 2022-06-17 02:37:56.238474
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.paths = []

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    # Create a fake facts collector
    class FakeFactCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set()
        required_facts = set()


# Generated at 2022-06-17 02:38:07.916956
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_stdout = ''
            self.run_command_stderr = ''

        def get_bin_path(self, command):
            return '/bin/' + command

        def run_command(self, command, use_unsafe_shell=False):
            self.run_command_called = True
            return self.run_command_rc, self.run_command_stdout

# Generated at 2022-06-17 02:38:15.874542
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule:
        def get_bin_path(self, path):
            return path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    mock_module = MockModule()
    mock_base_fact_collector = MockBaseFactCollector()
    mock_service_mgr_fact_collector = MockServiceMgrFactCollector

# Generated at 2022-06-17 02:38:25.479910
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    module = type('AnsibleModule', (object,), dict(
        run_command=lambda *args, **kwargs: (0, '', ''),
        get_bin_path=lambda *args, **kwargs: '/bin/systemctl'
    ))

    # Create a mock file system
    class MockFileSystem(object):
        def __init__(self, files):
            self.files = files

        def exists(self, path):
            return path in self.files

        def islink(self, path):
            return self.files[path] == 'symlink'


# Generated at 2022-06-17 02:38:31.319441
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x, **kwargs: x

        def get_bin_path(self, path):
            return path

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

    class MockPath(object):
        def __init__(self):
            self.exists = lambda x: True

    class MockOsPath(object):
        def __init__(self):
            self.exists = lambda x: True


# Generated at 2022-06-17 02:38:40.387140
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 02:38:49.322710
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None

        def get_bin_path(self, name, required=False):
            return '/bin/' + name

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class MockFile(object):
        def __init__(self, name):
            self.name = name

        def exists(self):
            return True


# Generated at 2022-06-17 02:39:06.782312
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def get_bin_path(self, path):
            return path

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class FakeServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    # Test 1: systemd is the boot init system
    module = FakeModule()
    base_fact_collector = FakeBaseFactCollector(module)
    service_mgr_fact_collector = FakeServiceMgrFactCollector(module)


# Generated at 2022-06-17 02:39:17.691291
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    test_module = TestModule()
    test_base_fact_collector = TestBaseFact

# Generated at 2022-06-17 02:39:28.618858
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import mock

    # Create a mock module
    module = mock.MagicMock()

    # Create a mock BaseFactCollector
    base_fact_collector = BaseFactCollector(module=module)

    # Create a mock ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector(module=module, collected_facts=base_fact_collector.collected_facts)

    # Create a mock module.get

# Generated at 2022-06-17 02:39:38.895119
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "ps -p 1 -o comm|tail -n 1":
                return 0, 'init', ''
            return 0, '', ''

    class MockFacts(object):
        def __init__(self, facts):
            self.facts = facts

        def __getitem__(self, key):
            return self.facts[key]


# Generated at 2022-06-17 02:39:49.689923
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
   

# Generated at 2022-06-17 02:39:58.942456
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = lambda x, y: (0, '', '')
            self.get_bin_path = lambda x: None

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set()
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {'mock': 'mock'}


# Generated at 2022-06-17 02:40:09.264462
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x
            self.fail_json = lambda x: x

        def get_bin_path(self, name, required=False):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    # Create a mock module
    module

# Generated at 2022-06-17 02:40:19.098592
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', '!min']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockFactCollector(BaseFactCollector):
        def __init__(self):
            self.name = 'service_mgr'
            self.collected_facts = {}

# Generated at 2022-06-17 02:40:30.244070
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_device
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 02:40:36.943261
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, executable: '/bin/' + executable,
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
    })()

    # Create a mock collected_facts
    mock_collected_facts = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': 'Darwin',
    }

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the collect method

# Generated at 2022-06-17 02:41:01.817087
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import test_ServiceMgrFactCollector_is_systemd_managed
    from ansible.module_utils.facts.system.service_mgr import test_ServiceMgrFactCollector_is_systemd_managed_offline
    from ansible.module_utils.facts.system.service_mgr import test_ServiceMgrFactCollector_is_systemd_managed_offline_2
    from ansible.module_utils.facts.system.service_mgr import test_ServiceMgrFactCollector_is_systemd_managed_offline_3

# Generated at 2022-06-17 02:41:15.709482
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule

    # Create a mock module
    module = MockModule()

    # Create a mock module
    module.get_bin_path = lambda x: '/bin/systemctl'

    # Create a mock module
    module.run_command = lambda x: (0, '', '')

    # Create a mock module
    module.os.path.exists = lambda x: True

    # Create a mock module
    module.os.path.islink = lambda x: True

    # Create a mock module
    module.os.readlink = lambda x: 'systemd'

    # Create a mock module
    module.os.path.basename = lambda x: 'systemd'

    # Create a mock

# Generated at 2022-06-17 02:41:21.236506
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_encoding


# Generated at 2022-06-17 02:41:29.293515
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.system import SystemFactCollector

    class Module(object):
        def __init__(self):
            self.params = {}
            self.run_command = lambda *args, **kwargs: (0, '', '')
            self.get_bin_path = lambda *args, **kwargs: '/bin/' + args[0]


# Generated at 2022-06-17 02:41:41.501133
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.module = TestModule()

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.base_fact_collector = TestBaseFactCollector()

    test_service_mgr_fact_collector = TestServiceMgrFactCollector()

    # Test case 1: /

# Generated at 2022-06-17 02:41:53.345625
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, cmd):
            return self.params.get(cmd)

        def run_command(self, cmd, use_unsafe_shell=False):
            return self.params.get(cmd)

    class MockFacts(object):
        def __init__(self, facts):
            self.facts = facts

        def __getitem__(self, key):
            return self.facts[key]

    # Test for systemd
    module = MockModule({'systemctl': '/bin/systemctl'})
    facts = MockFacts({'ansible_system': 'Linux', 'ansible_distribution': 'Fedora'})
    collector = ServiceMgrFactCollector()

# Generated at 2022-06-17 02:42:05.558138
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary):
            return binary

    class MockFacts(object):
        def __init__(self):
            self.facts = {}

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []


# Generated at 2022-06-17 02:42:15.054120
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

    module = MockModule()
    base_fact_collector = MockBaseFactCollector()
    service_mgr_fact_collector = MockServiceMgrFact

# Generated at 2022-06-17 02:42:25.118084
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.get_bin_path_calls = []

        def get_bin_path(self, executable):
            self.get_bin_path_calls.append(executable)
            return '/bin/systemctl'

        def run_command(self, cmd, use_unsafe_shell=True):
            self.run_command_calls.append(cmd)
            return 0, '', ''


# Generated at 2022-06-17 02:42:36.828303
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:43:15.096787
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options

# Generated at 2022-06-17 02:43:24.515314
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Create a mock ansible module
    class AnsibleModuleMock(object):
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = {}

        def fail_json(self, *args, **kwargs):
            self.exit_args = args

# Generated at 2022-06-17 02:43:35.256744
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    test_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
        'get_bin_path': lambda self, cmd: cmd,
        'fail_json': lambda self, *args, **kwargs: None,
    })

    # Create a mock ansible module

# Generated at 2022-06-17 02:43:43.287215
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a fake module
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    # Create a fake ansible module
    fake_module = FakeModule()

    # Create a fake ansible module facts

# Generated at 2022-06-17 02:43:52.478812
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module path
    old_path = sys.path
    sys.path = [tmpdir]

    # Create a temporary module
    module_name = 'ansible_test_service_mgr_facts'
    module_path = os.path.join(tmpdir, '%s.py' % module_name)

# Generated at 2022-06-17 02:44:02.583893
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:44:16.204906
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
        'get_bin_path': lambda *args, **kwargs: '/bin/systemctl',
        'exit_json': lambda *args, **kwargs: None,
        'fail_json': lambda *args, **kwargs: None
    })()

    # Create a mock collected_facts
    mock_collected_facts = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': 'Darwin',
        'platform': 'Darwin',
        'distribution': 'MacOSX'
    }

    # Create a ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceM

# Generated at 2022-06-17 02:44:28.833975
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    test_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
        'get_bin_path': lambda self, name: '/bin/' + name,
    })

    # Create a mock collected_facts
    test_collected_facts = {
        'ansible_distribution': 'Linux',
        'ansible_system': 'Linux',
    }

    # Create a ServiceMgrFactCollector instance
    test_Service

# Generated at 2022-06-17 02:44:39.408917
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    test_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, check_rc=True: (0, '', ''),
        'get_bin_path': lambda self, name, required=False: '/bin/' + name,
        'fail_json': lambda self, *args, **kwargs: None,
    })()

    # Create a mock ansible module

# Generated at 2022-06-17 02:44:50.963421
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock AnsibleModule
    ansible_module = AnsibleModuleMock()

    # Create a mock AnsibleModule
    ansible_module.params = {}

    # Create a mock AnsibleModule
    ansible_module.params = {'gather_subset': ['!all', '!min']}

    # Create a mock AnsibleModule
    ansible_module.params = {'gather_subset': ['!all', '!min', 'service_mgr']}

    # Create a mock AnsibleModule
    ansible_module.params = {'gather_subset': ['all', '!min', 'service_mgr']}

    # Create a mock AnsibleModule

# Generated at 2022-06-17 02:46:00.536811
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Test get_collector_names
    assert 'service_mgr' in get_collector_names()

    # Test list_collectors
    assert 'service_mgr' in list_collectors()

    # Test get_collector_instance
    assert isinstance(get_collector_instance('service_mgr'), ServiceMgrFactCollector)

    # Test ServiceMgrFactCollector.collect
    # Test with module_utils.facts.collector.Collector
    collector = Collector()

# Generated at 2022-06-17 02:46:06.659545
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    module = MockModule()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module.params = {}

    # Create a mock ansible module
    ansible_module.run_command = Mock(return_value=(0, 'init', ''))

    # Create a mock ansible module
    ansible_module.get_bin_path = Mock(return_value='/bin/systemctl')

    # Create a mock ansible module
    ansible_module.os

# Generated at 2022-06-17 02:46:17.044727
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, required=False):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

    module = MockModule()
    base_fact_collector = MockBaseFact

# Generated at 2022-06-17 02:46:27.457382
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self._fact

# Generated at 2022-06-17 02:46:36.969758
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:46:47.140830
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    module = MockModule()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_2 = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_3 = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_4 = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_5 = MockAnsibleModule()

    # Create a mock ans

# Generated at 2022-06-17 02:46:55.610924
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()


# Generated at 2022-06-17 02:47:04.551585
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['path'] = '/bin:/usr/bin'

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/usr/bin/systemctl'

    class MockOs(object):
        def __init__(self):
            self.path = '/sbin/init'

        def islink(self, path):
            return True

        def readlink(self, path):
            return 'systemd'
