

# Generated at 2022-06-17 02:37:27.560090
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os
    import os.path
    import platform
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
        'get_bin_path': lambda *args, **kwargs: os.path.join(tmpdir, 'systemctl'),
    })

    # Create a temporary systemd executable
    systemd_path = os.path.join(tmpdir, 'systemctl')
    with open(systemd_path, 'w') as systemd_file:
        systemd_file.write('#!/bin/sh\n')
        systemd_file.write('echo systemd\n')



# Generated at 2022-06-17 02:37:36.305231
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/bin/' + name

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}



# Generated at 2022-06-17 02:37:46.756515
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10

        def get_bin_path(self, executable):
            return executable

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()



# Generated at 2022-06-17 02:37:56.353771
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule
    import os

    # Create a mock module
    module = MockModule()

    # Create a mock systemctl command
    systemctl_path = os.path.join(os.path.dirname(__file__), 'systemctl')
    module.add_command(systemctl_path)

    # Create a mock /sbin/init symlink
    init_path = os.path.join(os.path.dirname(__file__), 'init')
    os.symlink(init_path, '/sbin/init')

    # Create a mock systemd command
    systemd_path = os.path.join(os.path.dirname(__file__), 'systemd')
   

# Generated at 2022-06-17 02:38:08.030597
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.utils
    import ansible.module

# Generated at 2022-06-17 02:38:15.010261
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, command):
            return '/bin/systemctl'

    class MockOs(object):
        def path(self, path):
            return True

    class MockOsPath(object):
        def exists(self, path):
            return True

    class MockOsReadLink(object):
        def readlink(self, path):
            return 'systemd'

    class MockOsPathIsLink(object):
        def islink(self, path):
            return True


# Generated at 2022-06-17 02:38:24.730621
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:38:34.940932
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    fake_base_fact_collector = FakeBaseFactCollector()
    fake_module = FakeModule()
    service_mgr_fact_collector = ServiceMgrFactCollector(fake_base_fact_collector)

    # Test case 1: /sbin/init is a symlink to systemd

# Generated at 2022-06-17 02:38:42.049088
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:38:49.921139
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:39:16.159287
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os

    # Mock module
    class MockModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    # Mock os.path.exists

# Generated at 2022-06-17 02:39:21.596895
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
   

# Generated at 2022-06-17 02:39:28.817540
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:39:34.743095
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return executable

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class MockFactsCollector(object):
        def __init__(self):
            self.facts = {}


# Generated at 2022-06-17 02:39:45.681886
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    test_module = Test

# Generated at 2022-06-17 02:39:55.781170
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Create a Collector instance
    collector = Collector()

    # Create a ServiceMgrFactCollector instance
    service_mgr_fact_collector = get_collector_instance(ServiceMgrFactCollector, collector)

    # Test the method collect of ServiceMgrFactCollector
    service_mgr_fact_collector.collect()

    # Test the method get_fact_names of ServiceMgrFactCollector
    service_mgr_fact_collector.get_fact_names()

    # Test the method

# Generated at 2022-06-17 02:40:07.719019
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, command):
            return self.bin_path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    # Test 1: systemctl is not installed
    module = MockModule(bin_path=None)
    base_fact_collector = Mock

# Generated at 2022-06-17 02:40:19.238555
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, systemctl_bin_path):
            self.systemctl_bin_path = systemctl_bin_path

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return self.systemctl_bin_path

    # Test with systemctl installed
    module = MockModule('/usr/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False

    # Test with systemctl not installed
    module = MockModule(None)

# Generated at 2022-06-17 02:40:30.328111
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    # Mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
            self.params['fact_path'] = '/etc/ansible/facts.d'
            self.params['fact_basename'] = 'ansible_local'

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/bin/systemctl'

    # Mock module

# Generated at 2022-06-17 02:40:36.984381
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return "/bin/%s" % name

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

    # Mock

# Generated at 2022-06-17 02:41:19.213467
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a mock module
    module = MockModule()

    # Create a mock module
    module.get_bin_path = Mock(return_value='/bin/systemctl')

    # Create a mock os
    os = MockOs()

    # Create a mock os.path
    os.path = MockOsPath()

    # Create a mock os.path.islink
    os.path.islink = Mock(return_value=True)

    # Create a mock os.readlink
    os.readlink = Mock(return_value='systemd')

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Call the is_systemd_managed_offline method of the ServiceMgrFactCollector object

# Generated at 2022-06-17 02:41:28.751168
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import default_collectors

    # Create a dummy module
    module = DummyModule()

    # Create a dummy ansible_facts
    ansible_facts = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': 'Darwin',
    }

    # Create a dummy collector
    collector = Collector(module=module, ansible_facts=ansible_facts)

    # Create a dummy ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the collect method
    service_mgr_fact_collector.collect(module=module, collected_facts=collector.collect())

    # Assert the result
    assert service_mgr

# Generated at 2022-06-17 02:41:41.341944
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_bin_path

    # Test case 1:
    # Test if method is_systemd_managed_offline returns True when /sbin/init is a symlink to systemd
    # and systemd is the boot init system.
    #
    # Create a symlink from /sbin/init to systemd
    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    # Create a canary file for systemd
    os.makedirs('/dev/.systemd')

    # Call method is_systemd_managed_offline

# Generated at 2022-06-17 02:41:53.188098
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/bin/' + name

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_calls.append(cmd)
            if cmd == 'systemctl list-units --no-legend --no-pager --plain':
                return 0, '', ''
            elif cmd == 'systemctl list-units --no-legend --no-pager --plain --state=failed':
                return 0

# Generated at 2022-06-17 02:42:05.491774
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.distribution

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.facts = {}

        def get_bin_path(self, path):
            return path

    class MockDistribution(ansible.module_utils.facts.system.distribution.DistributionFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'ansible_distribution': 'Linux'}


# Generated at 2022-06-17 02:42:14.699795
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, path):
            return path

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

    # Test 1: systemd is not the boot init system
    test

# Generated at 2022-06-17 02:42:25.033382
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import PY2
    import os
    import platform
    import shutil
    import tempfile
    import unittest

    class TestModule(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None


# Generated at 2022-06-17 02:42:36.747796
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution

# Generated at 2022-06-17 02:42:49.017552
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, command):
            return '/bin/' + command

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

    class MockPath(object):
        def __init__(self):
            self.isfile_return

# Generated at 2022-06-17 02:43:00.482324
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_paths
    from ansible.module_utils.facts.utils import get_mount_points
   

# Generated at 2022-06-17 02:44:20.419319
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    import platform
    import subprocess
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.collectors.service_mgr

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module
    module_path = os.path.join(tmpdir, 'ansible_module_mytest.py')
    with open(module_path, 'w') as f:
        f.write("#!/usr/bin/python\n")
        f.write("import os\n")
        f.write("import sys\n")
        f.write("import platform\n")

# Generated at 2022-06-17 02:44:30.612604
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid

# Generated at 2022-06-17 02:44:39.903953
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.params['_ansible_verbosity'] = 0
            self.params['_ansible_no_log'] = False
            self.params['_ansible_debug'] = False
            self.params['_ansible_diff'] = False
            self.params['_ansible_version'] = '2.4.0.0'
            self.params['_ansible_syslog_facility'] = 'LOG_USER'

# Generated at 2022-06-17 02:44:51.478723
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    test_base_fact_collector = TestBaseFactCollector()
    test_service_mgr_fact_collector = TestServiceMgrFactCollector()


# Generated at 2022-06-17 02:45:02.874598
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    test_module = TestModule()
    test_base_fact_collector = TestBaseFactCollector(test_module)
    test_service_m

# Generated at 2022-06-17 02:45:12.128387
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Test case 1:
    # Test if method is_systemd_managed_offline returns True when /sbin/init is a symlink to systemd
    # and False when /sbin/init is not a symlink to systemd
    import os
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    module = MockModule()
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test case 1.1:
    # Test if method is_systemd_managed_offline returns True when /sbin/init is a symlink to systemd

# Generated at 2022-06-17 02:45:22.055053
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_selinux

# Generated at 2022-06-17 02:45:27.620243
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, systemctl_path, canary_path):
            self.systemctl_path = systemctl_path
            self.canary_path = canary_path

        def get_bin_path(self, command):
            if command == 'systemctl':
                return self.systemctl_path
            else:
                return None

    class MockOs(object):
        def __init__(self, canary_path):
            self.canary_path = canary_path

        def path(self, path):
            if path == self.canary_path:
                return True

# Generated at 2022-06-17 02:45:36.730065
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution

    class MockModule(object):
        def __init__(self):
            self.run_command_environ_update = None
            self.run_command_rc = None
            self.run_command_stdout = None
            self.run_command_stderr = None
            self.run_command_args = None
            self.run_command_kwargs = None


# Generated at 2022-06-17 02:45:45.203722
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = '/tmp'
            self.exit_json = lambda x: x

        def get_bin_path(self, binary):
            return binary

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []
