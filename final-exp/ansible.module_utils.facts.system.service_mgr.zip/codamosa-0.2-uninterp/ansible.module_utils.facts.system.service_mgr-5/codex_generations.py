

# Generated at 2022-06-17 02:37:27.165836
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a new instance of ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Create a new instance of Collector
    collector = Collector()

    # Add ServiceMgrFactCollector to Collector
    collector.add_collector(service_mgr_fact_collector)

    # Create a new instance of AnsibleModule
    from ansible.module_utils.facts import AnsibleModule
    ansible_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    #

# Generated at 2022-06-17 02:37:36.043011
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None

        def get_bin_path(self, name):
            return '/bin/' + name

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()


# Generated at 2022-06-17 02:37:46.538603
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, required=False):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}


# Generated at 2022-06-17 02:37:56.237073
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_facts
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:38:07.916562
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class MockFacts(object):
        def __init__(self, **kwargs):
            self.facts = kwargs

        def __getitem__(self, key):
            return self.facts[key]

        def __contains__(self, key):
            return key in self.facts

    # Test with systemd
    module = MockModule()
    facts = MockFacts(ansible_system='Linux', ansible_distribution='Fedora')
    collector = ServiceMgrFactCollector()
    result = collector

# Generated at 2022-06-17 02:38:14.932199
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, required=False):
            return '/bin/' + name

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.facts = {}

    class MockCollectedFacts:
        def __init__(self):
            self.facts = {}

    module = MockModule()
    base_fact_collector = MockBaseFactCollector()
    collected_facts = MockCollectedFacts()

    service_mgr_fact_collector = ServiceMgrFactCollector

# Generated at 2022-06-17 02:38:23.358125
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = MockModule()

    # Create a mock ansible facts
    collected_facts = dict()

    # Create a instance of ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test method collect of class ServiceMgrFactCollector
    service_mgr_fact_collector.collect(module=module, collected_facts=collected_facts)

    # Assertion for method collect of class ServiceMgrFactCollector
    assert service_mgr_fact_collector.collect(module=module, collected_facts=collected_facts) == {'service_mgr': 'service'}


# Generated at 2022-06-17 02:38:34.685686
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os

    class MockModule(object):
        def __init__(self):
            self.tmpdir = tempfile.mkdtemp()
            self.bin_path = {}

        def get_bin_path(self, binary):
            return self.bin_path.get(binary)

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

    class MockOs(object):
        def __init__(self):
            self.path = {}

        def islink(self, path):
            return self.path.get(path)

        def readlink(self, path):
            return self.path.get(path)

    class MockOsPath(object):
        def __init__(self):
            self.basename = {}

# Generated at 2022-06-17 02:38:45.308383
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    def test_is_systemd_managed(self, monkeypatch):
        monkeypatch.setattr(os, 'path', MockPath())

# Generated at 2022-06-17 02:38:51.884474
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, executable):
            return '/bin/' + executable

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content


# Generated at 2022-06-17 02:39:16.228405
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

# Generated at 2022-06-17 02:39:21.633320
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

# Generated at 2022-06-17 02:39:28.842204
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils

# Generated at 2022-06-17 02:39:39.352780
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil
    import platform
    import sys

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module in the temporary directory
    module = os.path.join(tmpdir, 'ansible_test_facts.py')
    with open(module, 'w') as f:
        f.write("#!/usr/bin/python\n")
        f.write("import os\n")
        f.write("import platform\n")
        f.write("import sys\n")
        f.write("\n")

# Generated at 2022-06-17 02:39:48.876715
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
        'get_bin_path': lambda self, name: '/usr/bin/' + name,
    })()

    # Create a mock collected facts
    mock_collected_facts = {
        'ansible_distribution': 'OpenWrt',
        'ansible_system': 'Linux',
    }

    # Create a ServiceMgrFactCollector instance
   

# Generated at 2022-06-17 02:39:54.634834
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None

        def get_bin_path(self, name):
            return name

    class FakeCollector(BaseFactCollector):
        def __init__(self):
            self.name = 'fake'
            self._fact_ids = set()
            self.required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {}

    # Test case 1: /sbin

# Generated at 2022-06-17 02:40:06.409283
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class FakeCollectedFacts(object):
        def __init__(self):
            self.ansible_facts = {}

    class FakeServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    module = FakeModule()
    base_fact_collector = FakeBaseFactCollector(module)
    collected

# Generated at 2022-06-17 02:40:14.414889
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create an instance of class ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Create a mock module
    mock_module = MockModule()

    # Collect facts
    facts_dict = service_mgr_fact_collector.collect(module=mock_module)

    # Check if facts_dict is not empty
    assert facts_dict


# Generated at 2022-06-17 02:40:21.483014
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:40:30.773413
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:40:54.855358
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
   

# Generated at 2022-06-17 02:41:04.346646
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    # Create a mock collected_facts
    collected_facts = dict()

    # Create a mock BaseFactCollector
    base_fact_collector = BaseFactCollector()

    # Create a ServiceMgrFactCollector instance
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the collect method

# Generated at 2022-06-17 02:41:09.243397
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Mock module
    class MockModule(object):
        def __init__(self):
            self.run_command = lambda *args, **kwargs: (0, 'systemd', '')
            self.get_bin_path = lambda *args, **kwargs: '/bin/systemctl'

    # Mock get_file_content
    def mock_get_file_content(path):
        if path == '/proc/1/comm':
            return 'systemd'
        else:
            return None

   

# Generated at 2022-06-17 02:41:18.576909
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a symlink to the temporary file
    os.symlink(tmpfile.name, os.path.join(tmpdir, 'sbin', 'init'))

    # Create a temporary module
    tmpmodule = type('tmpmodule', (object,), {'get_bin_path': lambda self, x: os.path.join(tmpdir, x)})()

    # Test the method
    assert ServiceMgrFactCollector.is_systemd_managed_offline(tmpmodule)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 02:41:28.693699
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr

    # create a mock module
    module = ansible.module_utils.facts.collector.BaseFactCollector()

    # create a mock module.run_command
    def run_command(command, use_unsafe_shell=False):
        return 0, '', ''

    module.run_command = run_command

    # create a mock module.get_bin_path
    def get_bin_path(name):
        return '/bin/' + name

    module.get_bin_path = get_bin_path

    # create a mock os.path.exists
    def path_exists(path):
        return True

    os.path.exists = path_exists

    # create a

# Generated at 2022-06-17 02:41:41.313284
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule:
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return self.path

    class MockModuleNoSystemctl(MockModule):
        def __init__(self):
            super(MockModuleNoSystemctl, self).__init__(None)

    class MockModuleSystemctl(MockModule):
        def __init__(self):
            super(MockModuleSystemctl, self).__init__('/bin/systemctl')

# Generated at 2022-06-17 02:41:53.144751
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import mock

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, facts_dict):
            self.facts

# Generated at 2022-06-17 02:42:05.455968
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil
    import sys

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary module
    module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, cmd: os.path.join(tmpdir, cmd),
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
    })

    # Create a temporary collector
    collector = ServiceMgrFactCollector()

    # Create a temporary symlink
    os.symlink('systemd', os.path.join(tmpdir, 'init'))

    # Check if systemd is detected
    assert collector.is_systemd_managed_offline(module)

    # Remove temporary directory
    shut

# Generated at 2022-06-17 02:42:14.675145
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector

    # Create a mock module
    module = ansible.module_utils.facts.collector.BaseFactCollector()
    module.get_bin_path = lambda x: '/bin/systemctl'

    # Create a mock os
    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

    # Create a mock os.path
    class MockPath(object):
        def __init__(self):
            self.exists = lambda x: False

    # Create a mock platform
    class MockPlatform(object):
        def __init__(self):
            self.system = lambda: 'Linux'

    # Create a mock ServiceMgrFactCollector

# Generated at 2022-06-17 02:42:25.034736
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil
    import platform

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def get_bin_path(self, name):
            return os.path.join(self.tmpdir, name)

    class FakeFacts(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def get(self, name, default=None):
            if name == 'ansible_system':
                return platform.system()
            return default

# Generated at 2022-06-17 02:43:02.347205
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a mock module
    class MockModule(object):
        def get_bin_path(self, path):
            return path

    # Create a mock module
    module = MockModule()

    # Create a ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Create a fake file system
    fake_file_system = {
        '/run/systemd/system/': '',
        '/dev/.run/systemd/': '',
        '/dev/.systemd/': '',
    }

    # Create a fake os module
    class FakeOsModule(object):
        def path(self, path):
            return fake_file_system.get(path, None)

        def islink(self, path):
            return False

    # Create a fake os module

# Generated at 2022-06-17 02:43:14.701245
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution

# Generated at 2022-06-17 02:43:24.524669
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
        'get_bin_path': lambda *args, **kwargs: '/bin/systemctl',
        'get_file_content': lambda *args, **kwargs: None,
    })()

    # Create a mock collector
    collector = Collector()
    collector.module = module

    # Create a mock facts
    facts = {
        'platform': 'Linux',
        'distribution': 'OpenWrt',
    }

    # Create a ServiceMgrFactCollector
   

# Generated at 2022-06-17 02:43:35.286583
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, required=False):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

# Generated at 2022-06-17 02:43:43.288801
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []
            self.run_command_calls = []
            self.get_bin_path_results = []
            self.get_bin_path_calls = []


# Generated at 2022-06-17 02:43:53.702799
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule

    module = MockModule()
    module.get_bin_path.return_value = '/bin/systemctl'
    module.run_command.return_value = (0, '', '')

    # Test case 1: /sbin/init is a symlink to systemd
    os.symlink('/bin/systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test case 2: /sbin/init is not a symlink to systemd
    os.unlink('/sbin/init')
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

# Generated at 2022-06-17 02:43:59.416400
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    mock_module = MockModule()
    mock_base_fact_collector = MockBaseFactCollector()
    mock_service_mgr_fact_collector = MockServiceMgrFactCollector()

    assert mock_service_mgr_fact

# Generated at 2022-06-17 02:44:08.525904
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, systemctl_path):
            self.systemctl_path = systemctl_path

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return self.systemctl_path

    class MockOs(object):
        def __init__(self, path_exists):
            self.path_exists = path_exists

        def path(self, path):
            return MockPath(self.path_exists)

    class MockPath(object):
        def __init__(self, path_exists):
            self.path_exists = path

# Generated at 2022-06-17 02:44:18.178026
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:44:29.191204
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, 'init', ''),
        'get_bin_path': lambda *args, **kwargs: '/bin/systemctl',
        'get_file_content': lambda *args, **kwargs: 'systemd'
    })

    # Create a mock collected_facts
    mock_collected_facts = {
        'ansible_distribution': 'Linux',
        'ansible_system': 'Linux'
    }

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the method collect

# Generated at 2022-06-17 02:45:45.034018
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, name):
            if name == 'systemctl':
                return self.path

    # Test with systemctl in path
    module = FakeModule('/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(module)

    # Test with systemctl not in path
    module = FakeModule(None)
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

   

# Generated at 2022-06-17 02:45:51.045017
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, command):
            if command == 'systemctl':
                return self.path

    # Test with systemctl in path
    module = MockModule('/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(module) == True

    # Test with systemctl not in path
    module = MockModule(None)
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False

# Generated at 2022-06-17 02:45:56.935967
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    import os
    import tempfile
    import shutil

    class FakeModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, path):
            return os.path.join(self.path, path)

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = set()

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a fake module
    module = FakeModule(tmpdir)

    # Create a fake collector
    collector = FakeCollector()

# Generated at 2022-06-17 02:46:03.991008
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_calls.append(cmd)
            return 0, '', ''

    # Create a mock module
    module = MockModule()

# Generated at 2022-06-17 02:46:16.090723
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_2 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_3 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_4 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_5 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_6 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_7 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_8

# Generated at 2022-06-17 02:46:21.207882
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 02:46:28.185950
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import search_file
    from ansible.module_utils.facts.utils import search_file_in_path

# Generated at 2022-06-17 02:46:36.600556
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule

    # Create a MockModule object
    module = MockModule()

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Create a symlink /sbin/init -> systemd
    os.symlink('systemd', '/sbin/init')

    # Call the is_systemd_managed_offline method
    assert service_mgr_fact_collector.is_systemd_managed_offline(module)

    # Remove the symlink
    os.remove('/sbin/init')

# Generated at 2022-06-17 02:46:46.528825
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status

# Generated at 2022-06-17 02:46:54.825935
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable):
            return '/bin/' + executable

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class MockFacts(object):
        def __init__(self, facts):
            self.facts = facts

        def __getitem__(self, key):
            return self.facts[key]

    class MockCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module
