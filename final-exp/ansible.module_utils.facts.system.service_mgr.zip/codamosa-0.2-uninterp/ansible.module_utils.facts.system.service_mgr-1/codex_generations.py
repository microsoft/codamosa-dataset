

# Generated at 2022-06-17 02:37:30.942877
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    class MockOs(object):
        def __init__(self, path_exists):
            self.path_exists = path_exists

        def path_exists(self, path):
            return self.path_exists


# Generated at 2022-06-17 02:37:42.620190
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:37:52.858167
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a mock module
    module = MockModule()
    # Create a mock module.params
    module.params = {}
    # Create a mock module.run_command
    module.run_command = Mock(return_value=(0, 'systemd', ''))
    # Create a mock module.get_bin_path
    module.get_bin_path = Mock(return_value='/bin/systemctl')
    # Create a mock os.path.islink
    os.path.islink = Mock(return_value=True)
    # Create a mock os.readlink
    os.readlink = Mock(return_value='systemd')
    # Create a mock os.path.exists
    os.path.exists = Mock(return_value=True)

    # Create a ServiceMgrFactCollector object
    service_mgr

# Generated at 2022-06-17 02:38:02.058820
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 02:38:14.335535
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def get_bin_path(self, command):
            return '/bin/systemctl'

    fake_module = FakeModule()
    fake_collector = BaseFactCollector()
    fake_collector.module = fake_module
    service_mgr_collector = ServiceMgrFactCollector()
    service_mgr_collector.module = fake_module

    # test when /sbin/init is not a symlink
    os.symlink('/bin/systemctl', '/sbin/init')

# Generated at 2022-06-17 02:38:24.171989
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_2 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_3 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_4 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_5 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_6 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_7 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_8

# Generated at 2022-06-17 02:38:34.915094
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Create a test module
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Create a test collector
    test_collector = ServiceMgrFactCollector(test_module)

    # Create a test facts dictionary
    test_facts_dict = dict()

    # Collect facts
    test_facts_dict = test_collector.collect(module=test_module, collected_facts=test_facts_dict)

    # Assert that the service_mgr fact is present in the test facts dictionary
    assert 'service_mgr' in test_facts_dict

    # Assert that the service

# Generated at 2022-06-17 02:38:45.332987
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, command):
            if command == 'systemctl':
                return self.path

    class MockOs(object):
        def __init__(self, path):
            self.path = path

        def exists(self, path):
            return self.path == path

    class MockOsPath(object):
        def __init__(self, path):
            self.path = path

        def islink(self, path):
            return self.path == path

        def basename(self, path):
            return

# Generated at 2022-06-17 02:38:51.583786
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:39:01.179511
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os
    import os.path

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.path = None

        def get_bin_path(self, name):
            return self.path

    class MockFacts(object):
        def __init__(self):
            self.facts = {}

        def get(self, key):
            return self.facts.get(key)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 02:39:24.582155
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'

    test_module = TestModule()

    # Test with /run/systemd/system/
    os.makedirs('/run/systemd/system/')
    assert ServiceMgrFactCollector.is_systemd_managed(test_module)

    # Test with /dev/.run/systemd/
    os.makedirs('/dev/.run/systemd/')
    assert ServiceMgrFactCollector.is_systemd_managed(test_module)

    # Test with /dev/.systemd/
    os

# Generated at 2022-06-17 02:39:31.093089
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:39:44.007286
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, path: '/bin/' + path,
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
    })()

    # Create a mock facts
    mock_facts = {
        'ansible_distribution': '',
        'ansible_system': '',
    }

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the collect method
    assert service_mgr_fact_collector.collect(module=mock_module, collected_facts=mock_facts) == {'service_mgr': 'service'}

    #

# Generated at 2022-06-17 02:39:55.642896
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule:
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    test_module = TestModule()

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    test_base_fact_collector = TestBaseFactCollector()

    test_service_mgr_fact_collector = ServiceMgrFactCollector(test_base_fact_collector)

    assert test_service_mgr_fact_collector.is_systemd_managed(test_module) == True


# Generated at 2022-06-17 02:40:07.418339
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collector import list_collectors

    # Create a fake module
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: None

        def get_bin_path(self, path):
            return path

    module = FakeModule()

    # Create a fake ansible_facts
    ansible_facts = {
        'ansible_distribution': 'OpenWrt',
        'ansible_system': 'Linux',
    }

    # Create a fake collector


# Generated at 2022-06-17 02:40:19.082449
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, systemctl_path):
            self.systemctl_path = systemctl_path

        def get_bin_path(self, name):
            if name == 'systemctl':
                return self.systemctl_path

    class MockOs(object):
        def __init__(self, path_exists):
            self.path_exists = path_exists

        def path(self, path):
            return MockPath(self.path_exists)

    class MockPath(object):
        def __init__(self, path_exists):
            self.path_exists = path

# Generated at 2022-06-17 02:40:30.558608
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    test_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, check_rc=True: (0, 'systemd', ''),
        'get_bin_path': lambda self, name, opt_dirs=[] : '/bin/' + name,
        'fail_json': lambda self, *args, **kwargs: None
    })

    # Create a mock ansible module

# Generated at 2022-06-17 02:40:39.733339
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a fake module
    class FakeModule:
        def get_bin_path(self, path):
            return path

    # Create a fake module
    module = FakeModule()

    # Create a fake file
    class FakeFile:
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    # Create a fake file
    class FakeFile2:
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    #

# Generated at 2022-06-17 02:40:49.299216
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

    mock_module = MockModule()
    mock_base_fact_collector = MockBaseFactCollector()
    service_mgr_fact_collector = ServiceMgrFactCollector(mock_base_fact_collector)

    assert service_mgr_fact_collector.is_systemd_managed(mock_module) == False



# Generated at 2022-06-17 02:40:59.760755
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    # Test with systemctl not installed
    module = TestModule(bin_path=None)
    assert ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed(module) == False

    # Test with systemctl installed and /run/systemd/system/ exists
    module = TestModule(bin_path='/bin/systemctl')
    ansible.module_utils

# Generated at 2022-06-17 02:41:43.650368
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.system import SystemFactCollector
    from ansible.module_utils.facts.system.path import PathFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector

# Generated at 2022-06-17 02:41:55.056791
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module = AnsibleModuleMock()

    # Create a mock ansible facts
    ansible_facts = AnsibleFactsMock()

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Set the ansible_facts['ansible_system'] value
    ansible_facts.ansible_facts['ansible_system'] = 'Linux'

    # Set the ansible_facts['ansible_distribution'] value
    ansible_facts.ansible_facts['ansible_distribution'] = 'OpenWrt'

    # Set the module.run_command return value

# Generated at 2022-06-17 02:42:06.116305
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    module = MockModule()
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test case 1: /sbin/init is a symlink to systemd
    os.symlink('/bin/systemd', '/sbin/init')
    assert service_mgr_fact_collector.is_systemd_managed_offline(module)

    # Test case 2: /sbin/init is not a symlink to systemd
    os.unlink('/sbin/init')
   

# Generated at 2022-06-17 02:42:16.520724
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_

# Generated at 2022-06-17 02:42:26.750435
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/bin/' + name

    class MockFile(object):
        def __init__(self, path):
            self.path = path

        def exists(self):
            return self.path in ['/run/systemd/system/', '/dev/.run/systemd/', '/dev/.systemd/']

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()


# Generated at 2022-06-17 02:42:37.703710
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Test with a mocked module
    class MockModule:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, command):
            return command

        def run_command(self, command, use_unsafe_shell=False):
            return 0, "", ""

    # Test with a mocked module
    class MockModule2:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x


# Generated at 2022-06-17 02:42:49.799779
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, arg):
            return "/bin/systemctl"

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    mock_module = MockModule()
    mock_base_fact_collector = MockBaseFactCollector()
    mock_service_mgr_fact_collector = MockServiceMgrFactCollector()

    assert mock_service_mgr_fact

# Generated at 2022-06-17 02:43:00.531605
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockModule2(object):
        def get_bin_path(self, arg):
            return None

    class MockModule3(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockModule4(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockModule5(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'


# Generated at 2022-06-17 02:43:05.317011
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid

# Generated at 2022-06-17 02:43:15.386889
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def get_bin_path(self, name):
            return '/bin/' + name

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.module = FakeModule()

    # Test case 1: /sbin/init is a symlink to systemd
    class FakeBaseFactCollector1(FakeBaseFactCollector):
        def __init__(self):
            super(FakeBaseFactCollector1, self).__init__()
            self.os_path_islink = lambda path: True
            self.os_readlink = lambda path: 'systemd'



# Generated at 2022-06-17 02:44:39.288503
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_bin_path
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import file_exists
    from ansible.module_utils.facts.utils import file_is_link
    from ansible.module_utils.facts.utils import file_is_directory
    from ansible.module_utils.facts.utils import file_is_device
    from ansible.module_utils.facts.utils import file_is_pipe

# Generated at 2022-06-17 02:44:50.825327
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, command):
            return command

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    # Test case 1: /sbin/init is a symlink to systemd
    module = MockModule()
    base_fact_collector = MockBaseFactCollector(module)

# Generated at 2022-06-17 02:45:02.793888
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    # Test case 1: systemctl is not installed
    module

# Generated at 2022-06-17 02:45:12.422287
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None
            self.run_command = None

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class FakeFacts(object):
        def __init__(self):
            self.data = {}


# Generated at 2022-06-17 02:45:22.195721
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name):
            return self.bin_path

    # Test case 1: systemctl is not installed
    module = TestModule(bin_path=None)
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test case 2: systemctl is installed but /sbin/init is not a symlink to systemd
    module = TestModule(bin_path='/bin/systemctl')

# Generated at 2022-06-17 02:45:27.664500
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opts=None, required=False):
            return '/bin/' + name

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class FakeCollectedFacts(object):
        def __init__(self):
            self.facts = {}

    # Test with /sbin/init symlink to systemd
    fake_module = FakeModule

# Generated at 2022-06-17 02:45:36.757392
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    class MockCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class MockFacts(object):
        def __init__(self, facts):
            self.facts = facts

        def __getitem__(self, key):
            return self.facts[key]

        def __contains__(self, key):
            return key in self.facts

    module = MockModule()
    collector = MockCollector(module)
    service_mgr_collector = ServiceMgrFactCollect

# Generated at 2022-06-17 02:45:45.191055
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, path: path,
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
    })()

    # Create a mock collected_facts
    mock_collected_facts = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': 'Darwin',
    }

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the method collect with the mock data

# Generated at 2022-06-17 02:45:54.044300
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:46:00.542840
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, systemctl_path):
            self.systemctl_path = systemctl_path

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return self.systemctl_path

    class MockOs(object):
        def __init__(self, path_exists):
            self.path_exists = path_exists

        def path(self, path):
            return MockPath(self.path_exists)

    class MockPath(object):
        def __init__(self, path_exists):
            self.path_exists = path