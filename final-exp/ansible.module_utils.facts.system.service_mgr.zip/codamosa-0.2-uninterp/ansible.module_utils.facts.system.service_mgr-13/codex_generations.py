

# Generated at 2022-06-17 02:37:33.842614
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda *args, **kwargs: None

        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class FakeCollectedFacts(object):
        def __init__(self):
            self.collected_facts = {}

    module = FakeModule()
    base_fact_collector = FakeBaseFactCollector()
    collected_facts = FakeCollected

# Generated at 2022-06-17 02:37:44.981485
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, command):
            return '/bin/systemctl'

    class MockFileContent(object):
        def __init__(self):
            self.content = ''

        def read(self):
            return self.content

    class MockFile(object):
        def __init__(self):
            self.content = MockFileContent()

        def open(self, *args, **kwargs):
            return self.content


# Generated at 2022-06-17 02:37:55.993457
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector

    class MockModule(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'

    class MockModule2(object):
        def get_bin_path(self, name):
            return None

    class MockModule3(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

    class MockModule4(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'

        def run_command(self, cmd, use_unsafe_shell=True):
            return 1, '', ''


# Generated at 2022-06-17 02:38:07.682868
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    # Test 1: /sbin/init is a symlink to systemd
    class FakeOs(object):
        def __init__(self):
            self.path = '/sbin/init'
            self.readlink_return = 'systemd'


# Generated at 2022-06-17 02:38:12.134979
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return executable

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = [ServiceMgrFactCollector()]

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.module = TestModule()

    # test on a system with systemd
    test_collector = TestServiceMgrFactCollector()
    assert test_collector.is_systemd_managed_

# Generated at 2022-06-17 02:38:21.996138
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['path'] = ['/bin', '/sbin', '/usr/bin', '/usr/sbin', '/usr/local/bin', '/usr/local/sbin']
            self.params['removed_path'] = []

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None


# Generated at 2022-06-17 02:38:29.202356
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name):
            return self.bin_path

    class MockOs(object):
        def __init__(self, path_exists):
            self.path_exists = path_exists

        def path_exists(self, path):
            return self.path_exists

    class MockOs(object):
        def __init__(self, path_exists):
            self.path_exists = path_exists

        def path_exists(self, path):
            return self.path_exists


# Generated at 2022-06-17 02:38:40.236879
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module = AnsibleModuleMock()

    # Create a mock ansible facts
    ansible_facts = AnsibleFactsMock()

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Set the ansible_facts['ansible_system'] value
    ansible_facts['ansible_system'] = 'Linux'

    # Set the ansible_facts['ansible_distribution'] value
    ansible_facts['ansible_distribution'] = 'OpenWrt'

    # Set the ansible_module.get_bin_path() return value

# Generated at 2022-06-17 02:38:49.071181
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid


# Generated at 2022-06-17 02:38:58.768904
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, path):
            if path == 'systemctl':
                return '/bin/systemctl'
            return None

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    # Test 1: /

# Generated at 2022-06-17 02:39:19.205858
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule

    module = MockModule()
    module.get_bin_path = lambda x: '/bin/systemctl'
    module.run_command = lambda x: (0, '', '')

    # Test 1: /sbin/init is a symlink to systemd
    os.symlink('/bin/systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test 2: /sbin/init is not a symlink
    os.remove('/sbin/init')
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test 3: /

# Generated at 2022-06-17 02:39:26.882105
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_fact_collect

# Generated at 2022-06-17 02:39:33.721735
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda **kwargs: None
            self.fail_json = lambda **kwargs: None

        def get_bin_path(self, command):
            return '/bin/' + command

    # Create a fake module
    class FakeModuleNoSystemctl:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda **kwargs: None
            self.fail_json = lambda **kwargs: None

# Generated at 2022-06-17 02:39:45.084027
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:39:55.750976
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule:
        def get_bin_path(self, path):
            return path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    module = MockModule()
    base_fact_collector = MockBaseFactCollector(module)
    service_mgr_fact_collector = MockServiceMgrFactCollector(module)

    assert service_mgr_fact_collector.is_systemd_

# Generated at 2022-06-17 02:40:07.643734
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'

    class MockOs(object):
        def path(self, path):
            return True

    class MockOsPath(object):
        def exists(self, path):
            return True

    class MockOsPathLink(object):
        def islink(self, path):
            return True

        def readlink(self, path):
            return 'systemd'

    class MockOsPathExists(object):
        def exists(self, path):
            return False

    class MockOsPathIsLink(object):
        def islink(self, path):
            return False

    class MockOsPathReadLink(object):
        def readlink(self, path):
            return 'systemd'


# Generated at 2022-06-17 02:40:19.180159
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, cmd):
            return cmd

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collected_facts = {'ansible_system': 'Linux'}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collected_facts = {'ansible_system': 'Linux'}

    # Test with /sbin/init is a symlink to systemd

# Generated at 2022-06-17 02:40:30.300514
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, command):
            return '/bin/systemctl'

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

        class MockPath(object):
            def __init__(self):
                self.exists = Mock

# Generated at 2022-06-17 02:40:39.525787
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name):
            return self.params.get('bin_path', None)

        def run_command(self, cmd, use_unsafe_shell=False):
            return self.params.get('run_command', (0, '', ''))

    class MockFacts(object):
        def __init__(self, facts):
            self.facts = facts

        def __getitem__(self, key):
            return self.facts.get(key, None)

    # Test with systemd
    module = MockModule({
        'bin_path': '/bin/systemctl',
        'run_command': (0, 'systemd', ''),
    })

# Generated at 2022-06-17 02:40:49.133023
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return executable

    class MockFile(object):
        def __init__(self):
            self.exists = False

        def exists(self):
            return self.exists

    class MockOs(object):
        def __init__(self):
            self.path = MockFile()

        def path(self):
            return self.path

    class MockOsPath(object):
        def __init__(self):
            self.path = MockFile()


# Generated at 2022-06-17 02:41:23.732840
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module path
    old_path = sys.path
    sys.path = [tmpdir]

    # Create a temporary module
    module_name = 'ansible_fake_collector'
    os.mkdir(os.path.join(tmpdir, module_name))
    init_file = os.path.join(tmpdir, module_name, '__init__.py')
    open(init_file, 'a').close()

    # Create a temporary ansible module
    module_file = os.path.join(tmpdir, module_name, 'ansible_fake_collector.py')

# Generated at 2022-06-17 02:41:33.821196
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:41:43.687825
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return executable

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self, islink, readlink):
            self.islink = islink
            self.readlink = readlink

        def path(self, path):
            return self.path

# Generated at 2022-06-17 02:41:55.394423
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:42:05.594726
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    # Test with systemctl installed
    module = MockModule('/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(module) == True

    # Test without systemctl installed
    module = MockModule(None)
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False

# Generated at 2022-06-17 02:42:14.327947
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts.utils import MockCommand
    import os

    # init is a symlink to systemd
    os.symlink('systemd', '/sbin/init')
    module = MockModule()
    module.get_bin_path = MockCommand('systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # init is not a symlink to systemd
    os.remove('/sbin/init')
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

# Generated at 2022-06-17 02:42:24.949446
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class MockFactCollector(BaseFactCollector):
        def __init__(self):
            self.facts = {}

    class MockCollectedFacts(object):
        def __init__(self):
            self.facts = {}

    # Test case 1:
    # /sbin/init is a symlink to systemd
    # Expected result: True
    module = MockModule()
    fact_collector = MockFactCollector()
    collected_

# Generated at 2022-06-17 02:42:36.675413
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import search_file

# Generated at 2022-06-17 02:42:48.985550
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_2 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_3 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_4 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_5 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_6 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_7 = AnsibleModuleMock()

    # Create a mock ansible module
    ansible_module_8

# Generated at 2022-06-17 02:43:00.482322
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    # create a mock module
    module = MockModule()

    # create a mock Facts class
    facts = Facts(module=module)

    # create a mock Collector class
    collector = Collector(module=module)

    # create a ServiceMgrFactCollector class
    service_mgr_collector = ServiceMgrFactCollector(module=module)

    # create a mock collected_facts
    collected_facts = {}

    # test the collect method of ServiceMgrFactCollector class
    service_mgr_collector.collect(module=module, collected_facts=collected_facts)

    # assert that the

# Generated at 2022-06-17 02:43:36.432739
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class FakeCollectedFacts(object):
        def __init__(self):
            self.ansible_facts = {}

    # Test case 1: /sbin/init is a symlink to systemd
    fake_module = FakeModule()
    fake_base_fact_collector = FakeBaseFactCollector()
    fake_collected_facts = FakeCollectedFacts()
    fake_

# Generated at 2022-06-17 02:43:44.172696
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil
    import platform
    import sys

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module in the temporary directory
    module = os.path.join(tmpdir, 'ansible_test_facts.py')
    with open(module, 'w') as f:
        f.write("#!/usr/bin/python\n")
        f.write("import os\n")
        f.write("import platform\n")
        f.write("import sys\n")
        f.write("\n")

# Generated at 2022-06-17 02:43:53.041821
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, path: path,
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
    })()

    # Create a mock ansible module
    ansible_module = type('AnsibleModule', (object,), {
        'params': {},
        'get_bin_path': lambda self, path: path,
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
    })()

    # Create

# Generated at 2022-06-17 02:44:02.609987
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name):
            return self.bin_path

    class MockOs(object):
        def __init__(self, path_exists, is_link, readlink):
            self.path_exists = path_exists
            self.is_link = is_link
            self.readlink = readlink

        def path(self, path):
            return self.path_exists

        def islink(self, path):
            return self.is_link


# Generated at 2022-06-17 02:44:16.204654
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    # Test 1: /run/systemd/system/ exists
    module = MockModule()
    base_fact_collector = MockBaseFactCollector(module)
   

# Generated at 2022-06-17 02:44:28.833805
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, executable):
            return executable

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    # Test 1: systemd is the boot init system
    mock_module = MockModule()
    mock_base_fact_collector = MockBaseFactCollector()
    mock_service_mgr_fact_collector = MockServiceMgrFactCollector()

    assert mock

# Generated at 2022-06-17 02:44:39.408341
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_

# Generated at 2022-06-17 02:44:50.927553
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class MockCollector(Collector):
        def __init__(self):
            self.collectors = [ServiceMgrFactCollector()]
            self.collected_facts = {'ansible_distribution': 'OpenWrt'}

    module = MockModule()
    collector = MockCollector()
    facts = collector.collect(module=module)
    assert facts

# Generated at 2022-06-17 02:45:02.792918
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['path'] = '/usr/bin:/bin'

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    # Create a mock module
    class MockModule2(object):
        def __init__(self):
            self.params = {}
            self.params['path'] = '/usr/bin:/bin'


# Generated at 2022-06-17 02:45:12.420630
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 02:46:20.293774
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:46:29.070909
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            if path == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self, path_exists, is_link, readlink):
            self.path

# Generated at 2022-06-17 02:46:38.385826
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution

# Generated at 2022-06-17 02:46:47.969418
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, bin_path):
            return '/bin/' + bin_path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}

# Generated at 2022-06-17 02:46:56.608081
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class MockFacts(object):
        def __init__(self):
            self.facts = {}

    class MockCollector(BaseFactCollector):
        name = 'mock'
        _fact_ids = set()
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {}


# Generated at 2022-06-17 02:47:02.752720
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Mock module
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []
            self.get_bin_path_results = []
            self.get_bin_path_calls = []

        def get_bin_path(self, arg):
            self.get_bin_path_calls.append(arg)
            return self.get_bin_path_results.pop(0)
