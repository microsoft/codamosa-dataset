

# Generated at 2022-06-17 02:37:30.374923
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock ansible_facts
    ansible_facts = {
        'ansible_distribution': 'OpenWrt',
        'ansible_system': 'Linux',
    }

    # Create a ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the collect method
    service_mgr_fact_collector.collect(module=module, collected_facts=ansible_facts)

    # Assert the result
    assert ansible_facts['service_mgr'] == 'openwrt_init'


# Generated at 2022-06-17 02:37:39.109802
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid


# Generated at 2022-06-17 02:37:45.050688
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import search_file_for_string
    from ansible.module_utils.facts.utils import search_file_for_pattern
    from ansible.module_utils.facts.utils import search_file_for_line

# Generated at 2022-06-17 02:37:55.992577
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
            self.params['fact_path'] = None
            self.params['fact_basename'] = None
            self.params['_ansible_version'] = '2.5.0'
            self.params['_ansible_verbosity'] = 0

# Generated at 2022-06-17 02:38:07.683266
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    module = MockModule()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_2 = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_3 = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_4 = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_5 = MockAnsibleModule()

    # Create a mock ans

# Generated at 2022-06-17 02:38:18.154609
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    # Test 1: systemd is not the boot init system
    mock_

# Generated at 2022-06-17 02:38:27.169907
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name):
            return self.params.get('bin_path', None)

        def run_command(self, cmd, use_unsafe_shell=False):
            return self.params.get('run_command', (0, '', ''))

    class MockFacts(object):
        def __init__(self, facts):
            self.facts = facts

        def get(self, key, default=None):
            return self.facts.get(key, default)

    # Test with systemd
    module = MockModule({'bin_path': '/bin/systemctl'})
    facts = MockFacts({'ansible_distribution': 'Linux'})
    collector = ServiceMgrFactCollect

# Generated at 2022-06-17 02:38:35.081447
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule

    # Create a mock module
    module = MockModule()

    # Create a mock module
    module.get_bin_path = lambda x: '/bin/systemctl'

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Create a symlink to systemd
    os.symlink('/bin/systemd', '/sbin/init')

    # Test if the method is_systemd_managed_offline returns True
    assert service_mgr_fact_collector.is_systemd_managed_offline(module)

    # Remove the symlink to systemd

# Generated at 2022-06-17 02:38:42.135538
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    # Test case 1: /sbin/init is a symlink to systemd
    module = MockModule()
    base_fact_collector = MockBaseFact

# Generated at 2022-06-17 02:38:49.981884
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule:
        def get_bin_path(self, path):
            return path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    # Mock the module
    module = MockModule()

    # Mock the BaseFactCollector
    base_fact_collector = MockBaseFactCollector()

    # Mock the ServiceMgrFactCollect

# Generated at 2022-06-17 02:39:16.898748
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.fail_json = None
            self.run_command = None

        def get_bin_path(self, name, required=False):
            return '/bin/' + name

    # Create a fake module
    module = FakeModule()

    # Create a fake file
    class FakeFile:
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    # Create a

# Generated at 2022-06-17 02:39:27.657855
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible

# Generated at 2022-06-17 02:39:34.073293
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class MockFile(object):
        def __init__(self, path):
            self.path = path

        def exists(self):
            return self.path in ['/run/systemd/system/', '/dev/.run/systemd/', '/dev/.systemd/']

    class MockOs(object):
        def __init__(self):
            self.path = MockFile(None)


# Generated at 2022-06-17 02:39:45.294747
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_symlink_target
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_

# Generated at 2022-06-17 02:39:55.751068
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:40:07.643709
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    #

# Generated at 2022-06-17 02:40:15.870387
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import set_file_content
    from ansible.module_utils.facts.utils import remove_file
    from ansible.module_utils.facts.utils import is_executable
    from ansible.module_utils.facts.utils import is_readable
    from ansible.module_utils.facts.utils import is_writable
    from ansible.module_utils.facts.utils import is_directory
    from ansible.module_utils.facts.utils import is_symlink

# Generated at 2022-06-17 02:40:22.106406
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    # Test case 1: /sbin/init is a symlink to systemd
    module = MockModule()
    base_fact_collector = MockBaseFact

# Generated at 2022-06-17 02:40:30.990780
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

# Generated at 2022-06-17 02:40:39.905856
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/bin/' + executable

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_calls.append(cmd)
            return 0, '', ''

    class MockFile(object):
        def __init__(self, content):
            self.content = content


# Generated at 2022-06-17 02:41:20.825317
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_selinux

# Generated at 2022-06-17 02:41:29.089250
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_for_platform
    from ansible.module_utils.facts.collector import get_collector_class_for_platform_by_name
    from ansible.module_utils.facts.collector import get_collector_classes_for_platform
    from ansible.module_utils.facts.collector import get

# Generated at 2022-06-17 02:41:41.476629
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable):
            return '/bin/' + executable

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class MockCollector(Collector):
        def __init__(self, module, collected_facts=None):
            self.module = module
            self.collected_facts = collected_facts or {}

    # Test with empty collected_facts
    module = MockModule({})

# Generated at 2022-06-17 02:41:53.308318
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_by_name
    from ansible.module_utils.facts.collector import get_collector_classes_by_names
    from ansible.module_utils.facts.collector import get_collector_classes_for_platform
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 02:42:05.526105
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible module
    module = BaseFactCollector()
    module.tmpdir = tmpdir

    # Create a temporary systemd symlink
    os.symlink('/bin/systemd', tmpdir + '/sbin/init')

    # Create a temporary ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test if the method is_systemd_managed_offline returns True
    assert service_mgr_fact_collector.is_systemd_

# Generated at 2022-06-17 02:42:14.725025
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils

# Generated at 2022-06-17 02:42:25.033208
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class MockCollector(BaseFactCollector):
        def __init__(self):
            self.name = 'service_mgr'

# Generated at 2022-06-17 02:42:36.748688
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    class MockOs(object):
        def __init__(self, path_exists):
            self.path_exists = path_exists

        def path_exists(self, path):
            return self.path_exists

    class MockOsPath(object):
        def __init__(self, islink, readlink):
            self.islink = islink
            self.readlink = readlink


# Generated at 2022-06-17 02:42:49.017104
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=[]):
            if name in self.bin_path:
                return self.bin_path[name]
            return None

    # Create a mock collector
    class MockCollector(Collector):
        def __init__(self, module):
            self.module = module
            self.collectors = [ServiceMgrFactCollector(self.module)]

# Generated at 2022-06-17 02:43:00.482553
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    module = Mock()
    module.run_command.return_value = (0, 'systemd', '')
    module.get_bin_path.return_value = '/bin/systemctl'

    # Create a mock ansible_facts
    ansible_facts = {
        'ansible_distribution': 'Linux',
        'ansible_system': 'Linux'
    }

    # Create a mock Collector
    collector = Collector()

    # Create a ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Add the ServiceMgrFactCollector to the Collector

# Generated at 2022-06-17 02:44:14.642647
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, check_rc=True: (0, '', ''),
        'get_bin_path': lambda self, name, opt_dirs=[] : '/bin/' + name,
        'fail_json': lambda self, *args, **kwargs: None
    })()

    # Create a mock ansible module

# Generated at 2022-06-17 02:44:20.808132
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_stdout = ''
            self.run_command_stderr = ''
            self.run_command_args = None

        def get_bin_path(self, name):
            return '/bin/' + name

        def run_command(self, args, use_unsafe_shell=False):
            self.run_command_called = True
            self.run_command_

# Generated at 2022-06-17 02:44:30.260295
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule:
        def get_bin_path(self, path):
            return path

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            pass

    test_module = TestModule()
    test_base_fact_collector = TestBaseFactCollector()
    test_service_mgr_fact_collector = TestServiceMgrFactCollector()

    # Test

# Generated at 2022-06-17 02:44:33.864270
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class MockModule(object):
        def get_bin_path(self, command):
            if command == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    module = MockModule()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False

# Generated at 2022-06-17 02:44:43.659527
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule:
        def get_bin_path(self, cmd):
            return '/bin/systemctl'

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    test_module = TestModule()
    test_base_fact_collector = TestBaseFactCollector(test_module)
    test_service_mgr_fact

# Generated at 2022-06-17 02:44:53.315596
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda **kwargs: kwargs

        def get_bin_path(self, name):
            return '/bin/' + name

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []


# Generated at 2022-06-17 02:45:02.950544
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import search_file_for_string
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:45:12.199842
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    class MockFacts(object):
        def __init__(self, facts):
            self.facts = facts

        def get(self, fact):
            return self.facts.get(fact)

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, facts):
            self.facts = MockFacts(facts)

    # Test systemd managed
    module = MockModule()
    facts = {
        'ansible_system': 'Linux',
    }
    base_fact_collector = MockBaseFactCollector

# Generated at 2022-06-17 02:45:22.093758
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'

    class MockFile(object):
        def __init__(self, path):
            self.path = path

        def exists(self):
            return self.path in ['/run/systemd/system/', '/dev/.run/systemd/', '/dev/.systemd/']

    class MockOs(object):
        def __init__(self):
            self.path = MockFile('')

        def path(self, path):
            self.path.path = path
            return self.path


# Generated at 2022-06-17 02:45:33.341842
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.systemd
    import ansible.module_utils.facts.system.init
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.pkg_mgr_yum
    import ansible.module_utils.facts.system.pkg_mgr_apt
    import ansible.module_utils.facts.system.pkg_mgr_pkgng
    import ansible.module_utils.facts.system.pkg_mgr_apk
    import ansible