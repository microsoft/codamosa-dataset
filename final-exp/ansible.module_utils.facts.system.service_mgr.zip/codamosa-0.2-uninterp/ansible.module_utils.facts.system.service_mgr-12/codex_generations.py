

# Generated at 2022-06-17 02:37:31.035298
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import shutil
    import tempfile

    class MockModule(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def get_bin_path(self, name, opts=None, required=False, check_sudo=False,
                         force_sudo=False, follow=True):
            if name == 'systemctl':
                return os.path.join(self.tmpdir, 'systemctl')
            else:
                return None


# Generated at 2022-06-17 02:37:42.642724
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, systemctl_path, systemctl_exists):
            self.systemctl_path = systemctl_path
            self.systemctl_exists = systemctl_exists

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                if self.systemctl_exists:
                    return self.systemctl_path
                else:
                    return None
            else:
                return None

    class MockOs(object):
        def __init__(self, path_exists):
            self.path_exists

# Generated at 2022-06-17 02:37:52.880821
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr

    class MockModule:
        def get_bin_path(self, path):
            return path

    module = MockModule()
    service_mgr_fact_collector = ansible.module_utils.facts.collector.get_collector('service_mgr')

    assert service_mgr_fact_collector.is_systemd_managed(module) == False

    service_mgr_fact_collector.is_systemd_managed = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed
    assert service_mgr_fact_collector.is_systemd_managed(module) == False

    service_mgr_fact

# Generated at 2022-06-17 02:38:02.059204
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a mock module
    module = type('', (), {})()
    module.get_bin_path = lambda x: '/bin/systemctl'
    module.run_command = lambda x: (0, '', '')
    module.run_command.__name__ = 'run_command'

    # Create a mock os module
    os = type('', (), {})()
    os.path = type('', (), {})()
    os.path.exists = lambda x: True
    os.path.exists.__name__ = 'exists'

    # Create a mock platform module
    platform = type('', (), {})()
    platform.system = lambda: 'Linux'
    platform.system.__name__ = 'system'

    # Create a mock LooseVersion module
    LooseVersion = type('', (), {})()

# Generated at 2022-06-17 02:38:09.529994
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.collectors = []

    # Mock module
    module = MockModule()

    # Mock BaseFactCollector
    base_fact_collector = MockBaseFactCollector()

    # Mock ServiceMgrFactCollector
    service_mgr_fact_collector = MockServiceMgrFactCollector

# Generated at 2022-06-17 02:38:21.694080
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import get_collector_

# Generated at 2022-06-17 02:38:33.532209
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = '/tmp'
            self.exit_json = lambda **kwargs: kwargs
            self.fail_json = lambda **kwargs: kwargs

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/bin/' + executable

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []


# Generated at 2022-06-17 02:38:44.954636
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

# Generated at 2022-06-17 02:38:51.695148
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 02:38:58.516636
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockOs(object):
        def path(self, arg):
            return True

    class MockOsPath(object):
        def exists(self, arg):
            return True

    module = MockModule()
    os = MockOs()
    os.path = MockOsPath()
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(module) == True

# Generated at 2022-06-17 02:39:19.609920
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class ModuleMock(object):
        def __init__(self):
            self.bin_path = {}

        def get_bin_path(self, command):
            return self.bin_path.get(command)

    module = ModuleMock()
    module.bin_path['systemctl'] = '/bin/systemctl'

    # Test case 1: /sbin/init is a symlink to systemd
    os.symlink('/bin/systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test case 2: /sbin/init is a symlink to systemd-

# Generated at 2022-06-17 02:39:27.173984
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Mock module
    class MockModule:
        def get_bin_path(self, path):
            return path

    # Mock os.path.exists
    def mock_os_path_exists(path):
        if path == "/run/systemd/system/":
            return True
        return False

    # Mock os.path.islink
    def mock_os_path_islink(path):
        if path == "/sbin/init":
            return True
        return False

    # Mock os.readlink

# Generated at 2022-06-17 02:39:33.913210
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class FakeGetFileContent(object):
        def __init__(self, path):
            self.path = path


# Generated at 2022-06-17 02:39:43.920092
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = MockModule()

    # Create a mock ansible_facts
    ansible_facts = {
        'ansible_distribution': 'OpenWrt',
        'ansible_system': 'Linux',
    }

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Call method collect of the ServiceMgrFactCollector object
    result = service_mgr_fact_collector.collect(module=module, collected_facts=ansible_facts)

    # Check result
    assert result == {'service_mgr': 'openwrt_init'}


# Generated at 2022-06-17 02:39:55.643094
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()
    # Create a mock ansible module
    ansible_module = AnsibleModuleMock()
    # Create a mock ansible module facts
    ansible_module_facts = AnsibleModuleFactsMock()
    # Create a mock ansible module facts
    ansible_module_facts_system = AnsibleModuleFactsSystemMock()
    # Create a mock ansible module facts
    ansible_module_facts_distribution = AnsibleModuleFactsDistributionMock()
    # Create a mock ansible module facts
    ansible_module_facts_platform = AnsibleModuleFactsPlatformMock()
    # Create a mock ansible module facts
    ansible_module_facts_service_mgr = AnsibleModuleFactsServiceMgrMock()
    # Create a mock ans

# Generated at 2022-06-17 02:40:07.428923
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:40:15.723243
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, path):
            if path == 'systemctl':
                return self.path

    # Test with systemctl installed
    module = MockModule('/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(module) == True

    # Test without systemctl installed
    module = MockModule(None)
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False



# Generated at 2022-06-17 02:40:22.031626
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

    class MockFile(object):
        def __init__(self, path):
            self.path = path

        def exists(self):
            return True

        def islink(self):
            return True

        def readlink(self):
            return '/bin/systemd'


# Generated at 2022-06-17 02:40:25.407767
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Test with no module argument
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.collect() == {}

    # Test with module argument
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.collect(module=None) == {}

# Generated at 2022-06-17 02:40:35.669809
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    from ansible.module_utils.facts.collector.distribution import DistributionFactCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.collector.virtual import VirtualFactCollector
    from ansible.module_utils.facts.collector.zfs import ZFSFactCollector
    from ansible.module_utils.facts.collector.zpool import ZPoolFactCollector

# Generated at 2022-06-17 02:40:58.549878
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = None
    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed_offline(module) == False

# Generated at 2022-06-17 02:41:06.058500
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10

        def get_bin_path(self, arg):
            if arg == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content


# Generated at 2022-06-17 02:41:14.589787
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os
    import os.path
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = tempfile.mkdtemp()
            self.bin_path = self.tmpdir

        def get_bin_path(self, executable):
            return os.path.join(self.bin_path, executable)

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''


# Generated at 2022-06-17 02:41:20.891052
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    import os

    class MockModule(object):
        def get_bin_path(self, path):
            if path == 'systemctl':
                return '/bin/systemctl'
            return None

    class MockOs(object):
        def islink(self, path):
            if path == '/sbin/init':
                return True
            return False

        def readlink(self, path):
            if path == '/sbin/init':
                return 'systemd'
            return None

    class MockOsPath(object):
        def exists(self, path):
            if path == '/sbin/init':
                return True
            return False

   

# Generated at 2022-06-17 02:41:29.138270
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    module = MockModule()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module)

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module)

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module)

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module)

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module)

    # Create a mock ansible module
    ansible_module = MockAnsibleModule(module)



# Generated at 2022-06-17 02:41:38.448471
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Initialize the collector
    collector = get_collector_instance(ServiceMgrFactCollector)

    # Test the method collect
    assert collector.collect() == {'service_mgr': 'service'}

# Generated at 2022-06-17 02:41:48.302990
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import PY3

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, path):
            return self.path

    class MockOs(object):
        def __init__(self, path):
            self.path = path

        def path(self, path):
            return self.path

    class MockOsPath(object):
        def __init__(self, path):
            self.path = path


# Generated at 2022-06-17 02:41:58.575244
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule

    module = MockModule()
    module.get_bin_path = lambda x: '/bin/systemctl'
    module.run_command = lambda x: (0, '', '')

    # test with /sbin/init symlink to systemd
    os.symlink('/bin/systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # test with /sbin/init symlink to systemd-sysv
    os.symlink('/bin/systemd-sysv', '/sbin/init')

# Generated at 2022-06-17 02:42:07.575908
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []


# Generated at 2022-06-17 02:42:17.026901
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Create a mock ansible module
    class MockAnsibleModule():
        def __init__(self, module_args, check_invalid_arguments=None, bypass_checks=False):
            self.params = module_args
            self.check_mode = check_invalid_arguments
            self.bypass_checks = bypass_checks

        def fail_json(self, *args, **kwargs):
            self

# Generated at 2022-06-17 02:43:00.550854
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule:
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, cmd):
            return self.bin_path

    # Test with systemctl installed and /sbin/init is a symlink to systemd
    module = MockModule(bin_path='/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test with systemctl installed and /sbin/init is not a symlink to systemd

# Generated at 2022-06-17 02:43:04.963658
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a mock module
    class MockModule(object):
        def get_bin_path(self, command):
            return '/bin/systemctl'

    # Create a mock module
    class MockModule2(object):
        def get_bin_path(self, command):
            return None

    # Create a mock module
    class MockModule3(object):
        def get_bin_path(self, command):
            return '/bin/systemctl'

    # Create a mock module
    class MockModule4(object):
        def get_bin_path(self, command):
            return '/bin/systemctl'

    # Create a mock module
    class MockModule5(object):
        def get_bin_path(self, command):
            return '/bin/systemctl'

    # Create a mock module

# Generated at 2022-06-17 02:43:09.751674
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    # Test with systemctl installed and /run/systemd/system/ present
    module = FakeModule(bin_path='/usr/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(module)

    # Test with systemctl installed and /run/systemd/system/ missing
    module = FakeModule(bin_path='/usr/bin/systemctl')
    assert not ServiceMgrFactCollect

# Generated at 2022-06-17 02:43:19.148990
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class FakeServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    module = FakeModule()

    # Test case 1: /sbin/init is a symlink to systemd

# Generated at 2022-06-17 02:43:26.604010
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, executable):
            return '/bin/' + executable

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content


# Generated at 2022-06-17 02:43:35.762209
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:43:43.701376
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/bin/' + name

    class MockCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {}

    class MockFacts(object):
        def __init__(self):
            self.collectors = [MockCollector()]


# Generated at 2022-06-17 02:43:52.791551
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    test_module = TestModule()
    test_collector = ServiceMgrFactCollector()

    # Test 1: /sbin/init is not a symlink
    assert test_collector.is_systemd_managed_offline(test_module) == False

    # Test 2: /sbin/init is a symlink to systemd
    os.symlink('/bin/systemd', '/sbin/init')

# Generated at 2022-06-17 02:44:02.609131
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None
            self.run_command = None

        def get_bin_path(self, command):
            return command

    module = FakeModule()

    # Create a fake collector
    class FakeCollector(BaseFactCollector):
        name = 'fake_collector'
        _fact_ids = set()
        required_facts = set()


# Generated at 2022-06-17 02:44:12.228069
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os
    import os.path
    import platform
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary module
    class TestModule(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir
            self.run_command_environ_update = dict()
            self.params = dict()


# Generated at 2022-06-17 02:45:24.501668
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    # Test case 1: systemctl is not installed
    module = TestModule(bin_path=None)
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test case 2: systemctl is installed, but /sbin/init is not a symlink to systemd

# Generated at 2022-06-17 02:45:35.576367
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, required=False):
            if name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

    class MockPath(object):
        def __init__(self):
            self.exists_return_value = False

        def exists(self, path):
            return self.exists_return_value


# Generated at 2022-06-17 02:45:45.128160
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts.utils import MockCommand
    from ansible.module_utils.facts.utils import MockFile
    from ansible.module_utils.facts.utils import MockOS

    # Create a MockModule object
    mock_module = MockModule()

    # Create a MockCommand object
    mock_command = MockCommand()

    # Create a MockFile object
    mock_file = MockFile()

    # Create a MockOS object
    mock_os = MockOS()

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the is_systemd_managed_offline method


# Generated at 2022-06-17 02:45:53.970587
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid
    from ansible.module_utils.facts.utils import get_file_mode
    from ansible.module_utils.facts.utils import get_file_mtime


# Generated at 2022-06-17 02:46:00.472585
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a mock module
    module = Mock()
    module.get_bin_path.return_value = None
    module.run_command.return_value = (0, '', '')

    # Create a mock ansible_facts
    ansible_facts = {
        'ansible_distribution': '',
        'ansible_system': '',
    }

    # Create a ServiceMgrFactCollector
    service_mgr_fc = ServiceMgrFactCollector(module=module, ansible_facts=ansible_facts)

    # Test with ansible_dist

# Generated at 2022-06-17 02:46:05.233549
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'

    class MockCollector(Collector):
        def __init__(self):
            self.collectors = [ServiceMgrFactCollector()]

    collector = MockCollector()
    module = MockModule()
    facts = collector.collect(module=module)

    assert facts['service_mgr'] == 'systemd'

# Generated at 2022-06-17 02:46:15.175350
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/bin/systemctl'

    class MockFile(object):
        def __init__(self, path, content):
            self.path = path
            self.content = content

        def exists(self):
            return True

        def islink(self):
            return True

        def readlink(self):
            return self.content


# Generated at 2022-06-17 02:46:23.327748
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, required=False):
            return '/bin/' + name

    class FakeCollector(BaseFactCollector):
        name = 'fake'

    module = FakeModule()
    collector = FakeCollector()
    service_mgr_collector = ServiceMgrFactCollector()

    # Test with no systemd canary files
    assert service_mgr_collector.is_systemd_managed(module) is False

    # Test with /run/systemd/system/ canary file

# Generated at 2022-06-17 02:46:29.634547
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 02:46:38.778465
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda *args, **kwargs: None

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return executable

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

   