

# Generated at 2022-06-17 02:37:30.608387
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, name, opts=None, required=False):
            if name == 'systemctl':
                return self.path

    class MockFile(object):
        def __init__(self, path):
            self.path = path

        def exists(self, path):
            return os.path.exists(path)

        def islink(self, path):
            return os.path.islink(path)


# Generated at 2022-06-17 02:37:39.200676
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import platform
    import tempfile

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = tempfile.mkdtemp()
            self.bin_path = {}

        def get_bin_path(self, name):
            return self.bin_path.get(name)

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''


# Generated at 2022-06-17 02:37:45.126800
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

# Generated at 2022-06-17 02:37:53.751022
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:38:00.496259
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_collectors
    from ansible.module_utils.facts.collector import list_platform_collectors
    from ansible.module_utils.facts.collector import list_network_collectors
    from ansible.module_utils.facts.collector import list_all_collectors
    from ansible.module_utils.facts.collector import list_collector_

# Generated at 2022-06-17 02:38:04.887317
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, required=False):
            return self.bin_path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class MockCollectedFacts(object):
        def __init__(self, ansible_distribution):
            self.ansible_distribution = ansible_distribution

    # Test case 1

# Generated at 2022-06-17 02:38:14.175633
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self, systemctl_path, canary_path):
            self.systemctl_path = systemctl_path
            self.canary_path = canary_path

        def get_bin_path(self, command):
            if command == 'systemctl':
                return self.systemctl_path
            else:
                return None

        def path_exists(self, path):
            if path == self.canary_path:
                return True
            else:
                return False

    # Test with systemctl installed and canary path exists

# Generated at 2022-06-17 02:38:24.010860
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    # Test case 1: /sbin/init is a symlink to systemd
    module = MockModule()
    base_fact_collector = MockBaseFactCollector(module)
    service_mgr_fact_collector = MockService

# Generated at 2022-06-17 02:38:34.888033
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None

        def get_bin_path(self, path):
            return path

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.name = 'service_mgr'
            self._fact_ids = set()
            self.required_facts = set(['platform', 'distribution'])


# Generated at 2022-06-17 02:38:42.026411
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    # Create a mock module
    module = MockModule()

    # Create a mock ansible_facts
    ansible_facts = {'ansible_distribution': 'MacOSX', 'ansible_system': 'Darwin'}

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the collect method
    result = service_mgr_fact_collector.collect(module=module, collected_facts=ansible_facts)
    assert result == {'service_mgr': 'launchd'}


# Generated at 2022-06-17 02:39:03.471335
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, executable: '/bin/' + executable,
        'run_command': lambda self, cmd, use_unsafe_shell=False: (0, '', ''),
    })()

    # Create a mock collected_facts
    mock_collected_facts = {
        'ansible_distribution': 'OpenWrt',
        'ansible_system': 'Linux',
    }

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the method collect

# Generated at 2022-06-17 02:39:16.429926
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_info
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_size_info
    from ansible.module_utils.facts.utils import get_file_gid
    from ansible.module_utils.facts.utils import get_file

# Generated at 2022-06-17 02:39:26.730180
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict()
    )
    # Create a mock ansible module
    ansible_module = AnsibleModule(
        argument_spec = dict()
    )
    # Create a mock ansible facts
    ansible_facts = dict(
        ansible_distribution = 'MacOSX',
        ansible_system = 'Darwin'
    )
    # Create a mock ansible module
    ansible_module_2 = AnsibleModule(
        argument_spec = dict()
    )
    # Create a mock ansible facts
    ansible_facts_2 = dict(
        ansible_distribution = 'OpenWrt',
        ansible_system = 'Linux'
    )
    # Create a mock ansible module
    ansible_module_3 = Ans

# Generated at 2022-06-17 02:39:33.647771
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, executable):
            return self.bin_path

    # Test 1: systemctl is not installed
    module = TestModule(bin_path=None)
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test 2: systemctl is installed, but /sbin/init is not a symlink to systemd
    module = TestModule(bin_path='/usr/bin/systemctl')

# Generated at 2022-06-17 02:39:45.045672
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule

    # Create a mock module
    module = MockModule()

    # Create a mock module
    collector = ServiceMgrFactCollector()

    # Test with a symlink to systemd
    os.symlink('systemd', '/sbin/init')
    assert collector.is_systemd_managed_offline(module)

    # Test with a symlink to something else
    os.unlink('/sbin/init')
    os.symlink('/bin/bash', '/sbin/init')
    assert not collector.is_systemd_managed_offline(module)

    # Test with no symlink
    os.unlink('/sbin/init')
   

# Generated at 2022-06-17 02:39:55.750922
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary systemd symlink
    os.symlink('systemd', tmpdir + '/sbin/init')

    # Create a temporary module
    class Module:
        def __init__(self):
            self.path = tmpdir

        def get_bin_path(self, name):
            return name

    # Create a temporary ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test the is_systemd_managed_offline method
    assert service_mgr_fact_collector.is_systemd_managed_offline(Module())

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 02:40:07.718786
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.facts = {}

        def get_bin_path(self, command):
            return command

        def run_command(self, command, use_unsafe_shell=False):
            return 0, '', ''

# Generated at 2022-06-17 02:40:17.515173
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name):
            return self.bin_path

    # Test case 1: systemctl is not installed
    module = TestModule(bin_path=None)
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

    # Test case 2: systemctl is installed, but /run/systemd/system/ does not exist
    module = TestModule(bin_path='/bin/systemctl')
    assert not ServiceMgrFactCollector.is_systemd_

# Generated at 2022-06-17 02:40:29.996303
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts.utils import MockCommand
    from ansible.module_utils.facts.utils import MockFile
    from ansible.module_utils.facts.utils import MockOS
    from ansible.module_utils.facts.utils import MockVersion

    # Create a mock module
    module = MockModule()

    # Create a mock command
    command = MockCommand()

    # Create a mock file
    file = MockFile()

    # Create a mock os
    os = MockOS()

    # Create a mock version
    version = MockVersion()

    # Create a mock service manager fact collector
    service_mgr_fact_collector = ServiceMgrFactCollector()

# Generated at 2022-06-17 02:40:38.334865
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_enabled_collectors
    from ansible.module_utils.facts.collector import list_disabled_collectors
    from ansible.module_utils.facts.collector import enable_collector
    from ansible.module_utils.facts.collector import disable_collector
    from ansible.module_utils.facts.collector import disable_collectors

# Generated at 2022-06-17 02:41:19.059832
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

# Generated at 2022-06-17 02:41:28.723400
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'

    class MockOs(object):
        def path(self, path):
            return True

    class MockOsPath(object):
        def exists(self, path):
            return True

    class MockPlatform(object):
        def system(self):
            return 'Linux'

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.module = MockModule()
            self.os = MockOs()
            self.os.path = MockOsPath()
            self.platform = MockPlatform()

    service_mgr_fact_collector = MockServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed()

# Generated at 2022-06-17 02:41:41.313265
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, command):
            return '/bin/systemctl'

    class MockFile(object):
        def __init__(self, path):
            self.path = path

        def exists(self):
            return self.path in ['/run/systemd/system/', '/dev/.run/systemd/', '/dev/.systemd/']

    class MockOs(object):
        def __init__(self):
            self.path = MockPath()

        class MockPath(object):
            def islink(self, path):
                return path == '/sbin/init'


# Generated at 2022-06-17 02:41:53.144875
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution

# Generated at 2022-06-17 02:42:05.457072
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            return path

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []

        def collect(self, module=None, collected_facts=None):
            return {}

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            pass

    # Test case 1: /sbin/init is a symlink to systemd
    mock_module = MockModule()
    mock_base

# Generated at 2022-06-17 02:42:14.689097
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collector import get_collector_fact_status
    from ansible.module_utils.facts.collector import get_collector_fact_value

# Generated at 2022-06-17 02:42:25.033249
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import search_file

# Generated at 2022-06-17 02:42:30.844493
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None

        def get_bin_path(self, path):
            return path

    class MockFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class MockOs(object):
        def __init__(self, islink=True):
            self.islink = islink


# Generated at 2022-06-17 02:42:39.800722
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:42:50.938938
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, command):
            return self.bin_path

    # Test with systemctl installed and /sbin/init is a symlink to systemd
    module = TestModule(bin_path='/usr/bin/systemctl')
    os.symlink('/usr/bin/systemd', '/sbin/init')
   

# Generated at 2022-06-17 02:44:10.017127
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_

# Generated at 2022-06-17 02:44:18.605934
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    test_module = TestModule()
    test_base_fact_collector = TestBaseFactCollector(test_module)
    test_service_mgr

# Generated at 2022-06-17 02:44:29.414306
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFile
    from ansible.module_utils.facts.collector import MockSubprocess
    from ansible.module_utils.facts.collector import MockOs

    # Create a mock module
    module = MockModule()

    # Create a mock subprocess
    subprocess = MockSubprocess()

    # Create a mock os
    os = MockOs()

    # Create a mock file
    file = MockFile()

    # Create a mock service manager fact collector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Create a mock systemctl command
    systemctl_command = MockFile()
    systemctl_command.content = "systemctl"

    # Create a mock systemctl command
   

# Generated at 2022-06-17 02:44:39.446773
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Create a mock module
    module = MockModule()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_2 = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_3 = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_4 = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module

# Generated at 2022-06-17 02:44:51.209294
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule:
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

    class MockServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

    # Test 1: /run/systemd/system/ exists

# Generated at 2022-06-17 02:45:02.848845
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary module
    class TestModule(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def get_bin_path(self, name):
            return os.path.join(self.tmpdir, name)

    # Create a temporary module
    module = TestModule(tmpdir)

    # Create a temporary systemd executable
    systemd_path = os.path.join(tmpdir, 'systemctl')

# Generated at 2022-06-17 02:45:12.446491
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return '/bin/systemctl'

    class FakeOs(object):
        def __init__(self):
            self.path = FakePath()

    class FakePath(object):
        def __init__(self):
            pass

        def islink(self, path):
            return True

        def readlink(self, path):
            return 'systemd'


# Generated at 2022-06-17 02:45:22.195161
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import search_file_for_line
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:45:33.553720
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None

        def get_bin_path(self, executable):
            return executable

        def run_command(self, command, use_unsafe_shell=False):
            return 0, '', ''

    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self):
            self.collectors = []
            self.collected_facts = {}


# Generated at 2022-06-17 02:45:45.021376
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Mock module
    module = Mock()
    module.run_command.return_value = (0, 'init', '')
    module.get_bin_path.return_value = '/bin/systemctl'

    # Mock facts
    facts = {
        'platform': 'Linux',
        'distribution': 'OpenWrt',
    }

    # Mock get_file_content
    get_file_content.return_value = 'openwrt_init'

    # Create instance of ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFact