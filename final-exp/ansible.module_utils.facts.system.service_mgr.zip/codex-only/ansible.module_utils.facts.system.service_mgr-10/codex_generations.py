

# Generated at 2022-06-23 01:40:03.917112
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), dict(params={}, fail_json=lambda a,b: 1))
    ServiceMgrFactCollector().collect(mock_module)

# Generated at 2022-06-23 01:40:12.507433
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Unit test for ServiceMgrFactCollector
    """
    from ansible.module_utils import basic
    module_args = dict()
    module = basic.AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # init and without systemd
    module.run_command = lambda args, **kwargs: (0, "1 ?     00:00:00 init", None)
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # systemd
    module.run_command = lambda args, **kwargs: (0, "1 ?     00:00:00 systemd", None)
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

# Generated at 2022-06-23 01:40:16.802752
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.name == 'service_mgr'
    assert service_mgr.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:40:27.401489
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import Collector
    import tempfile
    import shutil

    # Create a temporary directory with a fake /sbin/init
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 01:40:37.417346
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Test object of class ServiceMgrFactCollector
    """
    # Command module is mocked.
    # See test/unit/mock_modules/test_command.py for more details
    service_mgr_facts = ServiceMgrFactCollector()
    collected_facts = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': '',
    }
    collected_facts = service_mgr_facts.collect(module=None, collected_facts=collected_facts)
    collected_facts = service_mgr_facts.collect(module=None, collected_facts=collected_facts)
    assert collected_facts['service_mgr'] == 'systemstarter'


if __name__ == '__main__':
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-23 01:40:46.132084
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.processor import FactsProcessor

    fixed_collector_names = ['chroot', 'mounts', 'pip', 'pkg_mgr', 'platform', 'python', 'systemd_analyze', 'systemd_logind',
                             'systemd_networkd', 'virtual', 'selinux', 'service_mgr', 'term']

    def get_test_module(test_ansible_collector_values):
        class TestAnsibleModule(object):
            def __init__(self):
                self.params = {}
                self.exit_json = lambda **kv: None

# Generated at 2022-06-23 01:40:51.046649
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFact
    ServiceMgrFactCollector.required_facts = set()  # Stop ServiceMgrFactCollector from trying to collect its required facts
    ServiceMgrFactCollector.collect()

# Generated at 2022-06-23 01:41:05.162424
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys

    class MockModule(object):
        def __init__(self, result):
            self.params = {}
            self.result = result

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            sys.exit(1)

        def get_bin_path(self, arg, *args, **kwargs):
            valid_bins = ['systemctl', 'initctl']
            if arg in valid_bins:
                return arg

        def run_command(self, arg, *args, **kwargs):
            return self.result

    class MockFactCollector(object):
        def __init__(self, result):
            self.result = result


# Generated at 2022-06-23 01:41:14.639922
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class Module:
        def get_bin_path(self, bin):
            if bin == "systemctl":
                return "/bin/systemctl"

        # pylint: disable=unused-argument
        def run_command(self, command, use_unsafe_shell=False):
            return 0, "", ""

    class CollectedFacts:
        def __init__(self, collected_facts_dict):
            self.collected_facts_dict = collected_facts_dict

        def __getitem__(self, key):
            return self.collected_facts_dict[key]

    class Os:
        @staticmethod
        def path():
            return "path"

        @staticmethod
        def islink(file):
            if file == "/sbin/init":
                return True
            return False


# Generated at 2022-06-23 01:41:26.161841
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

        def run_command(self, command, use_unsafe_shell=False):
            return 0, "", ""

    class MockFs(object):
        def exists(self, path):
            if path == "/run/systemd/system/":
                return True
            elif path == "/dev/.run/systemd/":
                return False
            elif path == "/dev/.systemd/":
                return False
            else:
                raise AssertionError("Unexpected path passed to MockFs.exists: " + path)

        def islink(self, path):
            if path == '/sbin/init':
                return False
           

# Generated at 2022-06-23 01:41:32.469380
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    serviceMgrFactCollector = ServiceMgrFactCollector()
    assert serviceMgrFactCollector.name == "service_mgr"
    assert serviceMgrFactCollector.platform == "generic"
    assert serviceMgrFactCollector.required_facts == {"platform", "distribution"}

# Generated at 2022-06-23 01:41:42.514569
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils.facts.collector.system import SystemFactCollector

    # Mock module
    mock_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    # Mock system fact collector
    mock_system_facts = SystemFactCollector(module=mock_module)
    # Mock service manager fact collector
    mock_service_manager_fact_collector = ServiceMgrFactCollector(module=mock_module, collected_facts=mock_system_facts.collect())
    # Unit test method is_systemd_managed()
    assert mock_service_manager_fact_collector.is_systemd_managed() == False

# Generated at 2022-06-23 01:41:51.580357
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # pylint: disable=protected-access
    """Unit test for constructor of class ServiceMgrFactCollector"""

    from ansible.module_utils.facts.network.distro import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector as system_DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    obj = ServiceMgrFactCollector()
    facts = {}

    _distro_fact_collector = DistributionFactCollector(collect_only=[obj.name])
    _system_distro_fact_collector = system_DistributionFactCollector(collect_only=[obj.name])
    _platform_fact_collector = PlatformFactCollector(collect_only=[obj.name])

    # Set mandatory distro facts
   

# Generated at 2022-06-23 01:42:01.901314
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class TestModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, tool):
            if(tool == 'systemctl'):
                if self.bin_path:
                    return '/sbin/systemctl'
                else:
                    return None
            return None

    # if systemctl is not installed, we should say False
    test = ServiceMgrFactCollector.is_systemd_managed_offline(TestModule(None))
    assert test == False

    # if systemctl is installed, but /sbin/init is missing, then we should say False
    test = ServiceMgrFactCollector.is_systemd_managed_offline(TestModule([]))
    assert test == False

    # if systemctl is installed, and /s

# Generated at 2022-06-23 01:42:13.783784
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import timeout

    def run_systemctl_side_effect(*args, **kwargs):
        if 'list-unit-files' in args:
            return (0, '', '')
        return (127, '', '')

    def systemctl_is_available():
        return True

    def run_command_side_effect(*args, **kwargs):
        if args[0] == 'systemctl list-unit-files':
            return (0, '', '')
        return (127, '', '')

    def get_bin_path_side_effect(*args, **kwargs):
        if args[0] == 'systemctl':
            return '/bin/systemctl'
        return None

    collector = Collector()
   

# Generated at 2022-06-23 01:42:15.139909
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # FIXME: finish this test
    assert False



# Generated at 2022-06-23 01:42:16.552365
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()

# Generated at 2022-06-23 01:42:28.920718
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collectors.service_mgr
    import ansible.module_utils.facts.systemd

    # First, test with a dummy module
    class ModuleDummy:
        def get_bin_path(self, command):
            return '/bin/true'
        def run_command(self, command, check_rc=True):
            return 0, '--prefix=/', ''
        def fail_json(self, rc):
            return dict(rc=rc)
    module = ModuleDummy()

    # Inject the test module into system_service and service_mgr classes
    ansible.module_utils.facts.collectors.service_mgr.module = module
    ansible.module_utils.facts.systemd.module = module

    # Create an instance of the facts collector
    fact = ServiceM

# Generated at 2022-06-23 01:42:38.199089
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    import sys
    import os
    #sys.path.append(os.path.join(os.path.dirname(__file__), '../../../'))

    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    #TODO:
    #yum install systemd-sysvinit
    #rm /sbin/init
    #ln -s ../lib/systemd/systemd /sbin/init
    #init 6

    #systemd should be still detected

    class MockModule:
        # Parameterize results of function os.path.exists
        def __init__(self):
            self.os_path_exists_values = {}
            self.os_path_exists_return_values = {}


# Generated at 2022-06-23 01:42:46.768469
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # create a mock module
    module = AnsibleModuleMock()

    # create instance
    service_manager_fact_collector = ServiceMgrFactCollector()
    collected_facts = {}

    # get platform
    platform = get_platform()

    # set platform-specific things
    if platform == 'Linux':
        # set up systemd
        set_fs_attribute('/sbin/init', src='/bin/systemd')
        module.get_bin_path_mock = MagicMock(return_value='/bin/systemctl')

        # set up upstart
        set_fs_attribute('/etc/init/', type='d')
        module.get_bin_path_mock = MagicMock(return_value='/sbin/initctl')

        # set up sysvinit

# Generated at 2022-06-23 01:42:54.702714
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import get_module_facts
    from ansible.module_utils.facts.collector import run_collector
    from ansible.module_utils.facts.collector import ModuleCollector

    class FakeModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg):
            return None
        def run_command(self, command, use_unsafe_shell):
            return None, None, None

    class FakeCollector(ModuleCollector):
        def __init__(self, module):
            self._fact_ids = set()
            pass

        def collect(self, module, collected_facts):
            return {
                'ansible_distribution': 'Linux',
                'ansible_system': 'Linux'
            }

# Generated at 2022-06-23 01:43:05.341842
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collectors.service_mgr
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collector

    from ansible.module_utils.facts.utils import AnsibleModule

    task = AnsibleModule(
        argument_spec=dict()
    )

    task.run_command = service_mgr_unittest_run_command
    task.get_bin_path = system_unittest_get_bin_path

    sut = ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector(task)

    result = sut.is_systemd_managed_offline(task)

# Generated at 2022-06-23 01:43:15.831123
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import unittest
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, cmd, *args, **kwargs):
            if cmd == 'systemctl':
                return '/usr/bin/systemctl'
            return None

    class TestServiceMgrFactCollector(unittest.TestCase):

        @classmethod
        def setUpClass(self):
            self.service_mgr_fact_collector = ServiceMgrFactCollector()
            self.mock_module = MockModule()

        def test_no_systemctl(self):
            self.service_mgr_fact_collector.is_systemd_managed_offline(module=self.mock_module)

       

# Generated at 2022-06-23 01:43:17.350301
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    collector = ServiceMgrFactCollector
    assert collector.is_systemd_managed(None) == False

# Generated at 2022-06-23 01:43:17.914835
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-23 01:43:27.088175
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Test if system is systemd managed or not
    """
    import sys
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import DummyModule
    from ansible.module_utils.facts.utils import MockModule

    def _create_module(python_version):
        t = tempfile.NamedTemporaryFile()
        module = MockModule(python_version=python_version, bin_path=t.name)
        return module

    if sys.version_info[0] >= 3:
        b_unlink = b'unlink'
    else:
        b_unlink = 'unlink'

    # Create a symlink to systemd
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 01:43:32.981450
# Unit test for method collect of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:43:42.291842
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import collection_options

    class FakeModule:
        """ Fake Module """
        def __init__(self):
            """ initialization """
            self._init = {}
            self._options = {}

        def get_bin_path(self, path):
            """ return the path """
            return "/bin/%s" % path

        def run_command(self, command, use_unsafe_shell=False):
            """ run command """
            return 1, "test", "test"

    smgfc = ServiceMgrFactCollector()
    fake_module = FakeModule()
    facts = Facts(FakeModule(), collection_options)

# Generated at 2022-06-23 01:43:43.678532
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    #TODO:
    pass

# Generated at 2022-06-23 01:43:53.611275
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Testing class stub for ServiceMgrFactCollector
    class ModuleStub():
        def __init__(self, name, bin_path=None, run_command_ok=True):
            self.name = name
            self.run_command_args = []
            self.run_command_ok = run_command_ok
            self.run_command_rc = 0
            self.run_command_stdout = ''
            self.run_command_stderr = ''
            self.bin_path = bin_path

        def get_bin_path(self, name):
            return self.bin_path

        def run_command(self, args, use_unsafe_shell=None):
            self.run_command_args.append(args)

            if not self.run_command_ok:
                return 1, '', ''

# Generated at 2022-06-23 01:44:04.508114
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr
    module = ansible.module_utils.facts.system.service_mgr.ModuleStub()

    # test return True when command systemctl and /dev/.run/systemd/ exist
    module.COMMAND_REQUIRES = ('systemctl',)
    module.FILES_REQUIRES = ('/dev/.run/systemd/',)
    assert ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed(module)

    # test return True when command systemctl and /dev/.systemd/ exist
    module.COMMAND_REQUIRES = ('systemctl',)
    module.FILES_REQUIRES = ('/dev/.systemd/',)
    assert ansible

# Generated at 2022-06-23 01:44:07.883676
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()
    assert isinstance(s, BaseFactCollector)

# Generated at 2022-06-23 01:44:09.880267
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_name = ServiceMgrFactCollector.collect(None)
    assert service_mgr_name['service_mgr'] == 'service'

# Generated at 2022-06-23 01:44:20.271881
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Set up a mock module for the unit test
    module = AnsibleModuleMock()

    # Set up a mock module for the unit test
    test_service_mgr_collector = ServiceMgrFactCollector(module=module)

    def mock_get_bin_path(name):
        path = '/bin/name'
        return path if name == 'systemctl' else None
    module.get_bin_path = mock_get_bin_path

    def mock_os_path_exists(path):
        return path == '/run/systemd/system' or path == '/dev/.run/systemd' or path == '/dev/.systemd'
    module.os.path.exists = mock_os_path_exists


# Generated at 2022-06-23 01:44:32.770243
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system

    class Mock(object):

        def __init__(self):
            self.sys_path = 'ansible/module_utils/facts/system'
            self.fact_paths = list()
            self.fact_paths.append('ansible/module_utils/facts/system')
            #self.fact_module_names = list()
            self.collector_class_names = list()

    svc = ServiceMgrFactCollector().collect()

# Generated at 2022-06-23 01:44:42.364939
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    ServiceMgrFactCollector = getattr(__import__(
        'ansible.module_utils.facts.system.service_mgr',
        fromlist=['ServiceMgrFactCollector']
    ), 'ServiceMgrFactCollector')

    class FakeModule(object):
        def get_bin_path(self, foo, *args, **kwargs):
            return '/bin/systemctl'

    class FakeModuleNoBinPath(object):
        def get_bin_path(self, foo, *args, **kwargs):
            return  None

    module = FakeModule()
    module_nopath = FakeModuleNoBinPath()

    # Test 1: no /sbin/init
    os.system('rm -f /sbin/init')
    assert not ServiceMgrFactCollector.is_systemd_managed_off

# Generated at 2022-06-23 01:44:52.126181
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ModuleFailException
    import pytest
    import sys

    if sys.version_info[0] < 3:
        # ModuleFailException is used in python 3 only
        pytest.skip()

    class MockModule(object):
        def get_bin_path(self, command):
            if command == 'systemctl':
                return 'systemctl'
            else:
                return None

    class MockSystemdMgrFactCollector(BaseFactCollector):
        name = 'service_mgr'
        _fact_ids = set()
        required_facts = set(['platform', 'distribution'])


# Generated at 2022-06-23 01:45:03.167318
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys
    sys.modules['ansible.module_utils.facts.collector'] = sys.modules['ansible.module_utils.facts.collector_test']
    import test_ServiceMgrFactCollector_is_systemd_managed_offline
    import test_ServiceMgrFactCollector_is_systemd_managed_offline.A_module
    test_ServiceMgrFactCollector_is_systemd_managed_offline.A_module.A_module.__dict__['run_command'].__dict__['return_value'] = (0, 'systemd', None)

    service_mgr_fact_collector = ServiceMgrFactCollector()

# Generated at 2022-06-23 01:45:11.911789
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    smf = ServiceMgrFactCollector()
    class MockModule:
        def get_bin_path(self, _): return '/sbin/systemctl'
        def run_command(self, _, **kwargs): return 0, '', ''
    m = MockModule()
    os.symlink('/lib/systemd/systemd', '/sbin/init')
    assert smf.is_systemd_managed_offline(m)
    os.remove('/sbin/init')
    assert not smf.is_systemd_managed_offline(m)


# Generated at 2022-06-23 01:45:23.281654
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import os
    import shutil
    import platform

    # The distutils module is not shipped with SUNWPython on Solaris.
    # It's in the SUNWPython-devel package which also contains development files
    # that don't belong on production boxes.  Since our Solaris code doesn't
    # depend on LooseVersion, do not import it on Solaris.
    if platform.system() != 'SunOS':
        from ansible.module_utils.compat.version import LooseVersion

    class FakeModule(object):

        @staticmethod
        def get_bin_path(path):
            return '/bin/' + path

    class FakeTempDirectory(object):

        def enter_context(self):
            return self.name

        def __init__(self):
            self.name = tempfile.mkdtemp()

# Generated at 2022-06-23 01:45:29.187678
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False
    assert ServiceMgrFactCollector.is_systemd_managed(None) == False

# Generated at 2022-06-23 01:45:32.417808
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smc = ServiceMgrFactCollector()
    if not isinstance(smc, BaseFactCollector):
        raise("Wrong type of ServiceMgrFactCollector")

if __name__ == '__main__':
    # Unit test code
    test_ServiceMgrFactCollector()

# Generated at 2022-06-23 01:45:42.004707
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Test ServiceMgrFactCollector.collect
    """
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import ModuleFactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    import ansible.module_utils.facts.utils


# Generated at 2022-06-23 01:45:45.903538
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class FakeModule(object):
        def get_bin_path(self, command):
            return '/bin/systemctl'

    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed_offline(FakeModule())

# Generated at 2022-06-23 01:45:53.851360
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Patch module_utils.facts.collector.BaseFactCollector to avoid
    # to execute the code that tries to execute a binary (systemctl)
    import mock
    from ansible.module_utils.facts.collector import BaseFactCollector

    serviceMgrFactCollector = ServiceMgrFactCollector()
    test_module = mock.MagicMock()
    test_module.get_bin_path.return_value = ''

    assert serviceMgrFactCollector.is_systemd_managed_offline(test_module) == False

    # Patch is_systemd_managed_offline to always return true

# Generated at 2022-06-23 01:46:01.239362
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    def get_bin_path(path):
        if path == 'systemctl':
            return '/bin/systemctl'
        return None
    module = type('Module', (object,), {'get_bin_path': get_bin_path})
    if os.path.exists('/run/systemd/system'):
        assert ServiceMgrFactCollector.is_systemd_managed(module) == True
    else:
        assert ServiceMgrFactCollector.is_systemd_managed(module) == False


# Generated at 2022-06-23 01:46:12.040052
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import shutil
    import tempfile
    import stat

    class Module:
        def __init__(self):
            self.executable = 'python'

        def get_bin_path(self, executable_name):
            return '/bin/' + executable_name

    tmp_dir = tempfile.mkdtemp(prefix='ansible_test_ServiceMgrFactCollector_is_systemd_managed')

# Generated at 2022-06-23 01:46:13.429153
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    facts_dict = ServiceMgrFactCollector()


# Generated at 2022-06-23 01:46:19.536793
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    a = ServiceMgrFactCollector()
    # get the name of the class
    assert a.name == "service_mgr"
    # get the required facts
    assert a.required_facts == set(['platform', 'distribution'])
    # check the _fact_ids
    assert a._fact_ids == set()

    # test collect method
    # TODO: how to test collect method?
    # assert a.collect() == service_mgr_name

# Generated at 2022-06-23 01:46:25.421702
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # TEST 1:
    # calling function without module object and without collected facts
    # Expected:
    # => service_mgr = 'service'
    ansible_module = None
    collected_facts = None
    test = ServiceMgrFactCollector()
    actual = test.collect(module=ansible_module, collected_facts=collected_facts)
    expected = {
        'service_mgr': 'service'
    }
    assert actual == expected



# Generated at 2022-06-23 01:46:34.617876
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    mock_module = None

    if platform.system() == 'SunOS':
        # the module cannot be mocked on Solaris because it is not shipped with SUNWPython
        pass
    elif platform.system() == 'Linux' or platform.system() == 'Darwin':
        mock_module = type('MockModule', (object,), {})()
        mock_module.get_bin_path = lambda x: '/bin/systemctl'
    else:
        return

    if mock_module is not None:
        assert ServiceMgrFactCollector.is_systemd_managed(mock_module)

# Generated at 2022-06-23 01:46:41.307526
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    facts_collector = collector.get_collector(ServiceMgrFactCollector.name, module=module)
    module.exit_json(changed=False, ansible_facts=facts_collector.collect(collected_facts=dict(), module=module))


# Generated at 2022-06-23 01:46:46.944664
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector().name == 'service_mgr'
    assert ServiceMgrFactCollector()._fact_ids == set()
    assert ServiceMgrFactCollector().required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:46:58.319891
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import platform
    import sys

    class MockModule:
        class MockFacts:
            def __init__(self, facts):
                self.facts = facts

            def __getitem__(self, item):
                return self.facts[item]

            def __setitem__(self, key, value):
                self.facts[key] = value

        def __init__(self, facts):
            self.facts = self.MockFacts(facts)

        def get_bin_path(self, path):
            return '/bin/systemctl'

    class MockOS:
        def __init__(self, os_name):
            self.name = os_name

        def path(self, path):
            return self

        def join(self, *args):
            return '/'.join([str(item) for item in args])



# Generated at 2022-06-23 01:47:08.126116
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible_collections.ansible.community.plugins.module_utils.facts.collectors.service_mgr


# Generated at 2022-06-23 01:47:19.109789
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # pylint: disable=protected-access
    mgr = ServiceMgrFactCollector()
    module = AnsibleModuleMock()

    assert not mgr.is_systemd_managed_offline(module=module)

    # setup /sbin/init as symlink poiting to systemd
    mod_path = os.path.dirname(os.path.abspath(__file__))
    systemd_path = os.path.join(mod_path, "../../../test/units/module_utils/systemd/systemd")

    if os.path.exists(systemd_path):
        os.symlink(systemd_path, "/sbin/init")
        assert mgr.is_systemd_managed_offline(module=module)
        os.remove("/sbin/init")

#

# Generated at 2022-06-23 01:47:28.735917
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils._text import to_text
    from ansible.module_utils import common
    from ansible.module_utils.facts.collector import BaseFactCollector

    module = common.AnsibleModule(argument_spec=dict())
    class FakeModule:
        def __init__(self):
            self.run_command_results = {}
            self.run_command_calls = []

        def get_bin_path(self, _):
            return '/bin/systemctl'

        def run_command(self, cmd, use_unsafe_shell=None):
            self.run_command_calls.append(cmd)
            return self.run_command_results.get(cmd, (0, '', ''))

    module.run_command = FakeModule().run_command


# Generated at 2022-06-23 01:47:30.870291
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert type(x) == ServiceMgrFactCollector


# Generated at 2022-06-23 01:47:41.529351
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector.distribution import DistributionFactCollector
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    import os

    # to_native added in Ansible 2.0
    try:
        from ansible.module_utils._text import to_native
    except ImportError:
        to_native = lambda obj: obj

    tmp = {}

# Generated at 2022-06-23 01:47:52.331536
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import Collector

    a = ServiceMgrFactCollector()
    assert a.name == 'service_mgr'
    assert a._fact_class == {}
    assert a._fact_ids == set()
    assert a.required_facts == set(['platform', 'distribution'])

    # test ServiceMgrFactCollector class instance(s) attributes
    b = ServiceMgrFactCollector()
    assert b.name == 'service_mgr' and b._fact_ids == set() and b.required_facts == set(['platform', 'distribution'])

    # if more than one instance is created, then the fact_ids are the same
    c = ServiceMgrFactCollector()
    assert c.name == 'service_mgr' and c._fact_ids == b._fact_

# Generated at 2022-06-23 01:47:59.582582
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    '''
    Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
    '''
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector

    dummy_module = BaseFactCollector()

    # Happily, systemd doesn't run under unit tests, but we fake it to test the method
    dummy_module.get_bin_path = lambda s: '/usr/bin/' + s
    if os.path.islink('/sbin/init'):
        os.unlink('/sbin/init')

    assert not ServiceMgrFactCollector.is_systemd_managed_offline(dummy_module)


# Generated at 2022-06-23 01:48:11.878268
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock

    module = mock.MagicMock()
    module.get_bin_path.return_value = '/bin/systemctl'
    systemctl_path = '/bin/systemctl'

    with mock.patch.object(os.path, 'exists', side_effect=[False, False, True]):
        assert ServiceMgrFactCollector.is_systemd_managed(module)

    if os.path.exists(systemctl_path):
        with mock.patch.object(os.path, 'exists', side_effect=[True, True, True]):
            assert ServiceMgrFactCollector.is_systemd_managed(module)
        with mock.patch.object(os.path, 'exists', side_effect=[True, True, False]):
            assert ServiceMgrFactCollector.is_systemd_managed

# Generated at 2022-06-23 01:48:12.994491
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # FIXME: code needs to change to support mock module
    pass

# Generated at 2022-06-23 01:48:24.299162
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import os

    from mock import patch

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collectors import systemd_version

    class MockModule:
        def get_bin_path(self, name):
            return fake_systemctl

    fake_systemctl = "/bin/systemctl"

    # Create temporary work directory
    oldcwd = os.getcwd()
    workdir = tempfile.mkdtemp(prefix="ansible_test_utils_facts_collecotrs_service_mgr_")
    os.chdir(workdir)
    os.mkdir("bin")
    os.mkdir("etc")
   

# Generated at 2022-06-23 01:48:30.490272
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    obj = ServiceMgrFactCollector()
    assert isinstance(obj, Collector)
    assert isinstance(obj, ServiceMgrFactCollector)
    assert obj.name == 'service_mgr'
    assert obj.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:48:42.875150
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class TestAnsibleModule(object):
        def __init__(self, params, fail_json):
            self.params = params
            self.fail_json = fail_json
            self.facts = {}

        def get_bin_path(self, executable, required=False):
            return 'systemctl'

        def run_command(self, command, use_unsafe_shell=False):
            return 0, "", ""

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, collector, module):
            self.collector = collector
            self.module

# Generated at 2022-06-23 01:48:46.288428
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # Method ServiceMgrFactCollector.is_systemd_managed of class ServiceMgrFactCollector is marked as deprecated: Use platform.systemd_service_check() instead
    pass

# Generated at 2022-06-23 01:48:56.768231
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = AnsibleModule(command_spec=dict())
    sys_mgr_collector = ServiceMgrFactCollector()

    # test with a symlink, should return True
    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    result = sys_mgr_collector.is_systemd_managed_offline(module)
    assert result
    # test with a file, should return False
    os.unlink('/sbin/init')
    with open('/sbin/init', 'w') as fd:
        fd.write('#!/bin/bash\nexit 0')

    result = sys_mgr_collector.is_systemd_managed_offline(module)
    assert not result


# Generated at 2022-06-23 01:49:05.470438
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a dummy module object
    class x:
        @staticmethod
        def get_bin_path(name):
            if name == 'systemctl':
                # Simulate that the systemctl command exists
                return True
            else:
                # Simulate that the command does not exist
                return False

    # The /sbin/init file is a symlink to systemd
    class y:
        @staticmethod
        def islink(name):
            return True

        @staticmethod
        def readlink(name):
            return 'systemd'

    module = x()
    os = y()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=module) == True

    # The /sbin/init file is a symlink to init

# Generated at 2022-06-23 01:49:16.018064
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactManager
    from ansible.module_utils.facts.collector import collect_facts

    # We will mock 'ansible_facts' to include the collected facts
    from ansible.module_utils.facts import AnsibleFacts

    class ModuleMock(object):
        def __init__(self):
            self.path = os.path.dirname(os.path.abspath(__file__))
            self.binary_path = os.path.dirname(os.path.abspath(__file__)) + os.path.sep + 'bin'
            self.params = {}

        def run_command(self, command, use_unsafe_shell):
            if command.endswith('systemctl'):
                return 0, '/bin/systemctl', ''

# Generated at 2022-06-23 01:49:24.777351
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.system.service_mgr as service_mgr

    class FakeModule():
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    # init is a symlink to systemd
    module = FakeModule()
    service_mgr.os.readlink = MagicMock(return_value='systemd')
    assert service_mgr.ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # init is not a symlink
    service_mgr.os.path.islink = MagicMock(return_value=False)
    assert not service_mgr.ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # init is a symlink to something else

# Generated at 2022-06-23 01:49:28.223225
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:49:37.783797
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_facts = dict()
    test_facts['ansible_system'] = 'Linux'
    test_facts['ansible_distribution'] = 'Debian'
    test_service_mgr_fact_collector = ServiceMgrFactCollector(module=None, collected_facts=test_facts)
    assert test_service_mgr_fact_collector.collect()['service_mgr'] == 'sysvinit'
    test_facts['ansible_distribution'] = 'CentOS'
    test_service_mgr_fact_collector = ServiceMgrFactCollector(module=None, collected_facts=test_facts)
    assert test_service_mgr_fact_collector.collect()['service_mgr'] == 'sysvinit'
    test_facts['ansible_distribution'] = 'RedHat'
   

# Generated at 2022-06-23 01:49:48.428859
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    ServiceMgrFactCollector.is_systemd_managed_offline = lambda self, module: True
    ServiceMgrFactCollector.is_systemd_managed = lambda self, module: True
    assert ServiceMgrFactCollector().collect(module=None, collected_facts=None) == {'service_mgr': 'systemd'}

    ServiceMgrFactCollector.is_systemd_managed_offline = lambda self, module: False
    ServiceMgrFactCollector.is_systemd_managed = lambda self, module: True
    assert ServiceMgrFactCollector().collect(module=None, collected_facts=None) == {'service_mgr': 'systemd'}

    ServiceMgrFactCollector.is_systemd_managed_offline = lambda self, module: False
    ServiceMgrFactCollector.is_

# Generated at 2022-06-23 01:49:51.393039
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = FakeAnsibleModule()
    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed_offline(module) is False



# Generated at 2022-06-23 01:49:58.197403
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """ Test of method is_systemd_managed in class ServiceMgrFactCollector """

    # Expected result
    expected = False

    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.module import FactsModule

    module = FactsModule()
    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: '/bin/systemctl'

    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.is_systemd_managed(module=module) == expected
