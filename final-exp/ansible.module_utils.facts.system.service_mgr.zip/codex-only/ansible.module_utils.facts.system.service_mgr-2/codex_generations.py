

# Generated at 2022-06-23 01:40:04.630572
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule:
        def __init__(self, name):
            self.name = name
            self.run_command = self.mock_run_command
            self.get_bin_path = self.mock_get_bin_path

        def mock_run_command(self):
            return (0, self.name, '')

        def mock_get_bin_path(self):
            return 'path/to/' + self.name

    open_wrt_init = MockModule('procd')
    open_wrt_init.run_command = open_wrt_init.mock_run_command
    open_wrt_init.get_bin_path = open_wrt_init.mock_get_bin_path

    mac_osx_leopard = MockModule('mDNSResponder')


# Generated at 2022-06-23 01:40:08.223841
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'

# Generated at 2022-06-23 01:40:09.560994
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline({}) == False

# Generated at 2022-06-23 01:40:17.019820
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule:
        def __init__(self, required_facts, return_value):
            self.required_facts = required_facts
            self.return_value = return_value

        def get_bin_path(self, binpath):
            if binpath == 'systemctl':
                return True
            return False

        def run_command(self, cmd, use_unsafe_shell=True):
            return 1, '', ''

    # test if ServiceMgrFactCollector.is_systemd_managed return True
    mock_module = MockModule({'platform', 'distribution'}, True)
    mock_required_facts = {'platform': 'Linux', 'distribution': 'RedHat'}
    test_collector = ServiceMgrFactCollector(mock_module)

# Generated at 2022-06-23 01:40:27.565608
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    sys_mgr = ServiceMgrFactCollector()

    class TestModule(object):
        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/bin/systemctl'
    class TestFacts(object):
        def __init__(self):
            self.platform = "Linux"
            self.distribution = "centos"
        def __contains__(self, x):
            return self.has_key(x)
        def __getitem__(self, x):
            return self.get(x)
        def items(self):
            return self.__dict__.items()
        def has_key(self, x):
            return self.__dict__.has_key(x)

# Generated at 2022-06-23 01:40:37.534919
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Prepare a test class, with specified methods mocked
    class TestClass(object):
        @staticmethod
        def get_bin_path(path):
            if path == 'systemctl':
                return '/bin/true'
            return None

    module = TestClass()

    # Test 1: /run/systemd/system/
    os.environ['PATH'] = '/usr/bin:/usr/local/bin'
    del os.environ['PATHEXT']
    service_mgr_inst = ServiceMgrFactCollector()
    with open('/run/systemd/system/', 'wt') as f:
        f.write('systemd exists')
    assert service_mgr_inst.is_systemd_managed(module=module)

    # Test 2: /dev/.run/systemd/

# Generated at 2022-06-23 01:40:43.511701
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    module = mock.Mock()
    module.get_bin_path.return_value = 'systemctl'
    module.run_command.return_value = (0, 'systemd', '')
    module.params = dict(gather_subset=['all'])
    x = ServiceMgrFactCollector(module=module)

    x.collect()
    assert x._fact_ids == {'service_mgr'}
    assert x.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-23 01:40:51.946893
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import MockModule

    module = MockModule()

    module._bin_paths['ls'] = "/bin/ls"
    module._bin_paths['systemctl'] = "/bin/systemctl"

    module.mkdtemp.return_value = "/tmp/test_ServiceMgrFactCollector_is_systemd_managed"

    ServiceMgrFactCollector.is_systemd_managed(module)
    assert module.mkdtemp.call_count == 0

    old_is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed

    # Set up a module with ls and systemctl in different locations
    # mock_module does not support chmod, use subprocess directly
    module = MockModule()


# Generated at 2022-06-23 01:41:05.345731
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test override of sysvinit detection when using systemd
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.is_systemd_managed({'PATH': '/bin:/usr/bin'}) == False
    assert service_mgr.is_systemd_managed({'PATH': '/bin:/usr/bin:/usr/bin/core_perl', 'CONFIG_PATH': '/etc/systemd/system.conf'}) == False
    assert service_mgr.is_systemd_managed({'PATH': '/bin:/usr/bin:/usr/bin/core_perl', 'CONFIG_PATH': '/etc/systemd/system.conf', 'SYSTEMD_SYSTEM_UNITS_PATH': '/etc/systemd/system/'}) == True

# Generated at 2022-06-23 01:41:20.163799
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import facts
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    import tempfile
    import shutil
    import os

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    module = facts.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        add_file_common_args=False,
    )

    # create symlink /sbin/init
    os.symlink('systemd', os.path.join(temp_dir, 'sbin', 'init'))
    module.tmpdir = temp_dir

    collector = Collector()
    collector.collect(module=module)
    cached_

# Generated at 2022-06-23 01:41:27.904958
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    sys_type = platform.system()
    my_file = __file__
    if not my_file.endswith(".py"):
        # not running from source
        my_file = None
    module = MockModuleUtils(sys_type, my_file)
    facts_collector = ServiceMgrFactCollector()
    facts_dict = facts_collector.collect(module=module)
    assert 'service_mgr' in facts_dict
    assert facts_dict['service_mgr'] in ['systemd', None]


# Generated at 2022-06-23 01:41:37.156665
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    is_systemd_mock = ServiceMgrFactCollector.is_systemd_managed
    is_systemd_offline_mock = ServiceMgrFactCollector.is_systemd_managed_offline
    ServiceMgrFactCollector.is_systemd_managed = lambda _: True
    ServiceMgrFactCollector.is_systemd_managed_offline = lambda _: True

    # Test with platform 'Linux' and distribution 'CentOS'
    collected_facts = {'platform': 'Linux', 'distribution': 'CentOS'}
    facts_dict = ServiceMgrFactCollector().collect(collected_facts=collected_facts)
    assert facts_dict == {'service_mgr': 'systemd'}

    # Test with platform 'SunOS' and distribution 'OpenIndiana'

# Generated at 2022-06-23 01:41:41.207045
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

if __name__ == '__main__':
    test_ServiceMgrFactCollector_is_systemd_managed_offline()

# Generated at 2022-06-23 01:41:43.784141
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    assert ServiceMgrFactCollector.is_systemd_managed(None)

# Generated at 2022-06-23 01:41:49.474321
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        pass

    mock_module = MockModule()
    mock_module.get_bin_path = lambda x: '/bin/systemctl'

    class MockAnsibleModule(object):
        def __init__(self):
            self.facts = ServiceMgrFactCollector(mock_module, None).collect(mock_module)

    assert ServiceMgrFactCollector(mock_module, None).is_systemd_managed(mock_module) is True

# Generated at 2022-06-23 01:41:54.738249
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector is not None
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-23 01:41:55.810301
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector().name == 'service_mgr'

# Generated at 2022-06-23 01:42:01.859935
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    module = get_module_mock()
    for name,cls in Collector.get_collectors(module):
        if name == 'service_mgr':
            service_mgr=cls()
    assert service_mgr is not None
    assert 'service_mgr' in service_mgr.collect()


# Generated at 2022-06-23 01:42:05.314257
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'
    assert set(obj.required_facts) == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:42:10.395056
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    This is a unit test for AnsibleModuleUtils.facts.service_mgr.ServiceMgrFactCollector
    The method collect() is a private method.
    We need to fake a module to test it.
    """

    module = FakeModule()
    ServiceMgrFactCollector().collect(module)

# Generated at 2022-06-23 01:42:19.762132
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collector

    def get_bin_path_mock(name):
        return name

    def _is_systemd_managed_offline(module):
        return ServiceMgrFactCollector.is_systemd_managed_offline(module)

    original_get_bin_path = ansible.module_utils.facts.collector.get_bin_path
    original_is_systemd_managed_offline = ServiceMgrFactCollector._is_systemd_managed_offline
    ansible.module_utils.facts.collector.get_bin_path = get_bin_path_mock
    ServiceMgrFactCollector._is_systemd_managed_offline = _is_systemd_managed_offline

    module = basic

# Generated at 2022-06-23 01:42:23.674639
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # check that is_systemd_managed() returns True if tools are present and /run/systemd/system/ exists
    assert ServiceMgrFactCollector.is_systemd_managed(module) == (os.path.exists('/run/systemd/system/'))


# Generated at 2022-06-23 01:42:34.483971
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    run_without_module_mock: service_mgr
    """
    from ansible.utils.path import which
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import default_collectors
    import sys

    if sys.version_info >= (3,):
        from io import StringIO
    else:
        from StringIO import StringIO

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.run_command_args = None
            self.run_command_kwargs = None

        class RunCommandError(OSError):
            pass

        class FailJson(Exception):
            pass


# Generated at 2022-06-23 01:42:44.671893
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule:
        def __init__(self, return_value):
            self.return_value = return_value

        def run_command(self, command, use_unsafe_shell=False):
            return self.return_value

        def get_bin_path(self, path):
            return None

    class MockStruct:
        def __init__(self, init_dict):
            self.__dict__.update(init_dict)

    smfc = ServiceMgrFactCollector()
    facts_dict = dict()

    # Mock module with a answer for is_systemd_managed
    mock_module = MockModule(None)

    # Mock module with a answer for is_systemd_managed_offline
    mock_module2 = MockModule(None)

    # Mock module with a answer for is_systemd_managed and

# Generated at 2022-06-23 01:42:50.399870
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_collector = ServiceMgrFactCollector()

    assert service_mgr_collector.name == 'service_mgr'
    assert service_mgr_collector._fact_ids == set()
    assert service_mgr_collector.required_facts == set(['platform', 'distribution']), \
        "service_mgr_collector.required_facts == %s" % service_mgr_collector.required_facts



# Generated at 2022-06-23 01:42:55.995125
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    test = ServiceMgrFactCollector()
    assert not test.is_systemd_managed_offline(None)
    assert not test.is_systemd_managed_offline(object())
    assert not test.is_systemd_managed_offline(test)

# Generated at 2022-06-23 01:43:06.439501
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    def module_run_command(cmd):
        if cmd == 'ps -p 1 -o comm|tail -n 1':
            return 0, 'systemd', ''

# Generated at 2022-06-23 01:43:16.626892
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    ld_so_cache = dict()
    ld_so_cache_expiration = dict()
    path_info = {
        'default_path': '/opt/local/sbin:/opt/local/bin:/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin',
        'ld_library_path': ['/opt/local/lib', '/usr/local/lib', '/lib', '/usr/lib', '/lib64', '/usr/lib64']
    }
    module = AnsibleModule(argument_spec={})
    module.PATH = path_info
    module.LD_LIBRARY_PATH = path_info['ld_library_path']
    module.run_command = run_command

# Generated at 2022-06-23 01:43:25.872392
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import AnsibleCollector

    import tempfile

    test_cases = [
        {
            'name': 'no systemctl',
            'systemctl': None,
            'result' : False
        },
        {
            'name': 'no systemd',
            'systemctl': '/bin/true',
            'result' : False
        },
        {
            'name': 'systemd',
            'systemctl': '/bin/true',
            'systemd_canary': '/dev/.run/systemd',
            'result' : True
        },
        {
            'name': 'upstart',
            'systemctl': '/bin/true',
            'upstart_canary': '/dev/initctl',
            'result' : False
        }
    ]


# Generated at 2022-06-23 01:43:33.915356
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import mock
    import tempfile
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    # Mock module
    test_module = mock.MagicMock()

    # Mock systemctl command
    (handle, temp_path) = tempfile.mkstemp()
    os.close(handle)
    test_module.get_bin_path.return_value = temp_path

    # Prepare /sbin/init symlink
    os.symlink('systemd', '/sbin/init')

    # Invoke test
    is_systemd_managed_offline = ServiceMgrFactCollector.is_systemd_managed_offline(test_module)

    # Verify results
    os.unlink('/sbin/init')
    os.unlink(temp_path)
    assert is_

# Generated at 2022-06-23 01:43:38.090134
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()

    assert obj.name == 'service_mgr'
    required_facts = set(['platform', 'distribution'])
    assert obj.required_facts == required_facts

# Generated at 2022-06-23 01:43:41.940316
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    collector_instance = ServiceMgrFactCollector()
    assert collector_instance.name == 'service_mgr'
    assert collector_instance._fact_ids == set()
    assert collector_instance.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:43:44.282253
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

# Generated at 2022-06-23 01:43:52.985476
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    '''
    Unit test to check the function ServiceMgrFactCollector.is_systemd_managed_offline()
    '''

    # Method is_systemd_managed_offline() under test
    def is_systemd_managed_offline(self, module):
        # tools must be installed
        if module.get_bin_path('systemctl'):
            # check if /sbin/init is a symlink to systemd
            # on SUSE, /sbin/init may be missing if systemd-sysvinit package is not installed.
            if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
                return True
        return False


# Generated at 2022-06-23 01:44:03.896372
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = type('AnsibleModule', (), {})()
    collector = ServiceMgrFactCollector()
    # True test - init is a symlink to systemd
    if os.path.islink('/sbin/init'):
        os.unlink('/sbin/init')
    os.symlink('systemd', '/sbin/init')
    assert collector.is_systemd_managed_offline(module)
    if os.path.islink('/sbin/init'):
        os.unlink('/sbin/init')
    # False test - init is a symlink to something else
    if os.path.islink('/sbin/init'):
        os.unlink('/sbin/init')
    os.symlink('foobar', '/sbin/init')

# Generated at 2022-06-23 01:44:15.579515
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    '''
    Test method ServiceMgrFactCollector.is_systemd_managed_offline
    '''
    # create an instance of the class ServiceMgrFactCollector
    am = ServiceMgrFactCollector()
    class Object(object):
        pass
    module = Object()
    module.get_bin_path = lambda name: '/bin/systemctl' if name == 'systemctl' else None

    # test for systemd
    os.symlink('/lib/systemd/systemd', '/sbin/init')
    assert am.is_systemd_managed_offline(module)
    os.remove('/sbin/init')

    # test for not systemd
    os.symlink('/bin/bash', '/sbin/init')
    assert not am.is_systemd_managed_offline(module)

# Generated at 2022-06-23 01:44:25.085043
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    def mocked_get_bin_path(name, opt_dirs=None):
        return name

    module = Mock()
    module.get_bin_path.side_effect = mocked_get_bin_path

    # Return False if systemctl does not exist.
    f = ServiceMgrFactCollector()
    assert f.is_systemd_managed_offline(module=module) == False

    # Return False if /sbin/init does not exist.
    module.run_command.return_value = ( 1, "", "")
    assert f.is_systemd_managed_offline(module=module) == False

    # Return True if /sbin/init is a symlink to systemd and systemctl exists.
    module.run_command.return_value = ( 0, "", "")
    module.FILE_COMMON

# Generated at 2022-06-23 01:44:35.279449
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import re

    module_path = os.path.dirname(os.path.abspath(__file__))
    test_path = os.path.join(module_path, '..', '..', 'unit', 'module_utils', 'facts')
    fixture_path = os.path.join(test_path, 'fixtures', 'service_mgr')

    # create a temporary directory for the test
    tmpdir = tempfile.mkdtemp()
    pytest_command = [sys.executable, '-m', 'pytest', '-s', '-v', test_path, '-k', 'test_ServiceMgrFactCollector_collect']


# Generated at 2022-06-23 01:44:45.366073
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector()

    modules = [FakeModule({'/sbin/init': '/lib/systemd/systemd'}), FakeModule({'/sbin/init': '/lib/systemd/systemd'}), FakeModule({'/sbin/init': '/lib/systemd/systemd'}), FakeModule({'noinit': 'noninit'})]

    for module in modules:
        assert collector.is_systemd_managed_offline(module) == True

        module.captured_output = {
            '/sbin/init': '/lib/systemd/systemd'
        }

        assert collector.is_systemd_managed_offline(module) == True

        module.captured_output = {
            '/sbin/init': '/lib/init/upstart-job'
        }


# Generated at 2022-06-23 01:44:48.912413
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    dut = ServiceMgrFactCollector()
    assert dut.name == 'service_mgr'
    assert dut._fact_ids == set()
    assert dut.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:44:52.636790
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Init the class and set up test variables
    smfc = ServiceMgrFactCollector({})
    module = MockModule({'ansible_distribution': 'Linux'})

    # Call collect()
    result = smfc.collect(module)

    # Verify the result
    assert result == {'service_mgr': 'service'}



# Generated at 2022-06-23 01:45:03.418074
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class AnsibleModuleFake:
        def get_bin_path(self, arg):
            return "/some/path/to/installed/systemctl"

        def run_command(self, arg):
            return (0, "", "")

    smfc = ServiceMgrFactCollector()

    # returns false when systemctl exists but /sbin/init is not a symlink to systemd
    with open("/sbin/init", 'w') as fh:
        fh.write("test")
        os.chmod("/sbin/init", 0o755)

    assert False == smfc.is_systemd_managed_offline(AnsibleModuleFake)
    os.remove("/sbin/init")

    # returns true when /sbin/init is a symlink to systemd

# Generated at 2022-06-23 01:45:11.772051
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockModule()
    service_mgr_fact_collector = ServiceMgrFactCollector(module=module, collected_facts={})
    if service_mgr_fact_collector.is_systemd_managed_offline(module=module):
        assert os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd'
    else:
        assert not os.path.islink('/sbin/init') or os.path.basename(os.readlink('/sbin/init')) == 'systemd'


# Generated at 2022-06-23 01:45:23.086179
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import sys

    import mock

    mock_module = mock.Mock()
    mock_module.get_bin_path.return_value = "/bin/systemctl"

    # If the file can not be read because of permissions
    with mock.patch('os.path.exists', return_value=True):
        with mock.patch('os.readlink', side_effect=OSError(13, "Permission denied", "/sbin/init")):
            assert ServiceMgrFactCollector.is_systemd_managed_offline(mock_module) == False

    # If /sbin/init does not exist
    with mock.patch('os.path.exists', return_value=False):
        assert ServiceMgrFactCollector.is_systemd_managed_offline(mock_module) == False

    #

# Generated at 2022-06-23 01:45:30.204648
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    collector_instance = get_collector_instance('ServiceMgrFactCollector')
    assert isinstance(collector_instance, Collector)

# Generated at 2022-06-23 01:45:37.767845
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_file_content

    test_class = get_collector_class('service_mgr')

    class MockModule(object):

        def __init__(self):
            self.run_command_result = (0, "", "")

        def get_bin_path(self, command):
            return command


# Generated at 2022-06-23 01:45:48.765710
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    params = dict(
        ansible_system='Linux',
        ansible_lsb=dict(
            distribution='Ubuntu',
        )
    )
    test_platform1 = dict(
        Linux='Linux',
        SunOS='SunOS',
        Darwin='MacOSX',
    )
    test_platform2 = dict(
        SunOS='SunOS',
        Darwin='MacOSX',
    )
    fc = ServiceMgrFactCollector(params)
    expected_result_platform1 = dict(
        Linux=True,
        SunOS=True,
        Darwin=False,
    )
    expected_result_platform2 = dict(
        SunOS=False,
        Darwin=False,
    )

# Generated at 2022-06-23 01:46:02.673795
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class ModuleMock(object):
        def __init__(self, params):
            self.params = params
            self.exit_json = lambda x, **kw: x
        def get_bin_path(self, name, required=False):
            return '/bin/' + name
        def run_command(self, command, check_rc=False, **kwargs):
            if command == "ps -p 1 -o comm|tail -n 1":
                return 0, '/bin/bash', ''
            elif command == "systemctl":
                return 0, 'active (running)', ''

    class AnsibleModuleMock(object):
        def __init__(self, params):
            self.params = params
            self.service_mgr = ModuleMock(params)
            self.exit_json = lambda x, **kw: x

# Generated at 2022-06-23 01:46:08.521029
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr = ServiceMgrFactCollector()
    class TestModule():
        def get_bin_path(self, binary_name):
            return ""
    module = TestModule()
    assert service_mgr.is_systemd_managed_offline(module) == False
    assert service_mgr.is_systemd_managed_offline(None) == False

# Generated at 2022-06-23 01:46:09.248046
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    return True

# Generated at 2022-06-23 01:46:19.016528
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Setup a mock module
    module = MockModule()

    # Setup a mock command runner
    module.run_command = Mock(return_value=(0, "init", ""))

    # Setup a fact collector
    fact_collector = ServiceMgrFactCollector()

    # Execute command
    fact_collector.collect(module=module)

    # Verify the module.run_command was called
    module.run_command.assert_called_once_with("ps -p 1 -o comm|tail -n 1", use_unsafe_shell=True)

    # Test with a custom init process
    # Setup a mock module
    module = MockModule()

    # Setup a mock command runner
    module.run_command = Mock(return_value=(1, "openwrt_init", "error"))

    # Setup a fact collector
    fact

# Generated at 2022-06-23 01:46:26.224613
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Get instance of ServiceMgrFactCollector
    _ServiceMgrFactCollector = ServiceMgrFactCollector()
    assert _ServiceMgrFactCollector.name == 'service_mgr'
    assert _ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])
    assert 'service_mgr' not in _ServiceMgrFactCollector._fact_ids

    # Basic test of _fact_id attribute
    assert _ServiceMgrFactCollector._fact_id == 'ansible_service_mgr'



# Generated at 2022-06-23 01:46:31.026868
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'

if __name__ == '__main__':
    test_ServiceMgrFactCollector()

# Generated at 2022-06-23 01:46:40.639141
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_name = 'service'
    if ServiceMgrFactCollector.is_systemd_managed(module=None):
        service_mgr_name = 'systemd'
    elif os.path.exists('/sbin/openrc'):
        service_mgr_name = 'openrc'
    elif ServiceMgrFactCollector.is_systemd_managed_offline(module=None):
        service_mgr_name = 'systemd'
    elif os.path.exists('/etc/init.d/'):
        service_mgr_name = 'sysvinit'

    assert service_mgr_name == ServiceMgrFactCollector().collect()['service_mgr']

# Generated at 2022-06-23 01:46:47.976309
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector_obj = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_obj.name == 'service_mgr'
    assert service_mgr_fact_collector_obj.required_facts == {'platform', 'distribution'}
    assert service_mgr_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-23 01:46:58.530647
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import fallback_reader

    def run_command_mock(arg, **kwargs):
        if arg == 'systemctl list-unit-files':
            return (0, ' ', '')
        else:
            raise Exception("Unexpected arg: %s" % arg)

    classes = (ServiceMgrFactCollector,)
    module = fallback_reader(None, classes).get_module_reader(None)
    module.run_command = run_command_mock

    # The run_command_mock is set up to always return 0 (success) if the
    # command is `systemctl list-unit-files`. So we expect is_systemd_managed()
    # to return True.
    #
    # FIXME: This test does not check for the actual commit.
    assert ServiceMgr

# Generated at 2022-06-23 01:47:03.095040
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.name == 'service_mgr'
    assert fact_collector._fact_ids == set()
    # facts required for this fact collection
    assert 'platform' in fact_collector.required_facts
    assert 'distribution' in fact_collector.required_facts

# Generated at 2022-06-23 01:47:12.948295
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.system.service_mgr as facts
    import ansible.module_utils.facts.system.service_mgr_test_cases as test_cases
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    fact_collector = ServiceMgrFactCollector()
    assert isinstance(fact_collector, BaseFactCollector)
    assert hasattr(fact_collector, 'collect')
    for version, expected_result in test_cases.collect_results.items():
        assert fact_collector.collect(get_mock_ansible_module(version)) == expected_result


# Generated at 2022-06-23 01:47:23.187547
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # We need to create a mock module with some attributes
    module = AnsibleModule(argument_spec={})
    
    # We need to let the module know it is running as a unit test, otherwise it will fail
    module.params['ANSIBLE_MODULE_ARGS'] = {}
    
    # Create an instance of our ServiceMgrFactCollector class
    serviceFactCollector = ServiceMgrFactCollector()
    
    # Test with a known invalid path
    currentSystemdBinary = "/bin/systemctl"
    module.params['ANSIBLE_FACTS'] = {'ansible_system': 'Linux'}
    module.params['ANSIBLE_SYSTEM'] = 'Linux'
    isSystemd = serviceFactCollector.is_systemd_managed_offline(module)
    assert(not isSystemd)

    # Test

# Generated at 2022-06-23 01:47:31.221642
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import FactsCommon
    from ansible.module_utils.six import PY2
    from ansible.module_utils.basic import AnsibleModule

    class FakeAnsibleModule(object):
        def __init__(self):
            self.get_bin_path_called = 0

        def get_bin_path(self, name):
            self.get_bin_path_called += 1
            if self.get_bin_path_called == 1:
                if name == 'systemctl':
                    return '/bin/true'
            return None

    class FakeModuleUtil(object):
        def __init__(self):
            self.run_command_called = 0


# Generated at 2022-06-23 01:47:32.212667
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector()

# Generated at 2022-06-23 01:47:39.413983
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts import FactCollector

    myfact = FactCollector()
    # create instance of ServiceMgrFactCollector
    test_inst = ServiceMgrFactCollector(myfact.collector)
    assert test_inst.name == 'service_mgr'
    assert test_inst.required_facts == {'platform', 'distribution'}


if __name__ == '__main__':
    test_ServiceMgrFactCollector()

# Generated at 2022-06-23 01:47:44.675569
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    '''
    Test the constructor of class ServiceMgrFactCollector without mock imports.
    '''
    svc = ServiceMgrFactCollector()
    assert svc.name == 'service_mgr'
    assert svc.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-23 01:47:56.224643
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class CollectFacts:
        def __init__(self, service_mgr_name):
            self.ansible_facts={'service_mgr': service_mgr_name}

    # return value from collect()
    fact_collector = ServiceMgrFactCollector()
    facts = fact_collector.collect()

    # return value from get_distribution()
    distribution = CollectFacts(facts['service_mgr']).ansible_facts['service_mgr']

    assert distribution == facts['service_mgr']

# Generated at 2022-06-23 01:48:05.263597
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Stub for method collect of class ServiceMgrFactCollector
    class StubModule(object):
        def get_bin_path(self, *args, **kwargs):
            return None

        def run_command(self, *args, **kwargs):
            return (0, '', '')

    class StubCollectedFacts(object):
        pass

    x = ServiceMgrFactCollector()
    module = StubModule()
    collected_facts = StubCollectedFacts()
    service_mgr = x.collect(module, collected_facts=collected_facts)
    assert service_mgr == { 'service_mgr': 'service' }

# Generated at 2022-06-23 01:48:09.781158
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    ServiceMgr = ServiceMgrFactCollector()
    assert ServiceMgr.is_systemd_managed_offline(None) == False
    assert ServiceMgr.is_systemd_managed_offline("") == False
    assert ServiceMgr.is_systemd_managed_offline("test") == False

# Generated at 2022-06-23 01:48:18.552038
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    from ansible.module_utils.common.collections import ImmutableDict
    # temp directory for test
    tmpdir = tempfile.mkdtemp()
    # create test init_symlink
    test_init = os.path.join(tmpdir, 'sbin')
    os.makedirs(test_init)
    os.symlink(os.path.join(tmpdir, 'systemd'),
               os.path.join(test_init, 'init'))
    # create paths for test module

# Generated at 2022-06-23 01:48:25.219404
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    if platform.system() != 'SunOS':
        from ansible.module_utils.compat.version import LooseVersion
    from ansible.module_utils.facts.collector import BaseFactCollector

    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert isinstance(service_mgr_fact_collector, BaseFactCollector)
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector._fact_ids == set()
    assert service_mgr_fact_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:48:31.180302
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import DefaultCollectors

    pc = FactsCollector(collected_facts=dict(platform='SunOS'),
                        collectors=DefaultCollectors)
    service_mgr_name = 'smf'
    pc.add_collector(ServiceMgrFactCollector())
    facts = pc.collect()

    assert facts['service_mgr'] ==  service_mgr_name

# Generated at 2022-06-23 01:48:42.040899
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mock_module = MockModule()
    mock_module.run_command.side_effect = [(0, '/usr/bin/systemd', ''), (0, '/bin/init', ''), (0, 'procd', '')]
    mock_module.get_bin_path.return_value = '/bin/systemctl'
    mock_module.get_bin_path.side_effect = [None, '/usr/bin/systemctl', '/bin/systemctl']

    collector = ServiceMgrFactCollector(mock_module)
    results = collector.collect(mock_module, {'platform': 'Linux', 'distribution': 'CentOS'})

    assert results['service_mgr'] == 'service', \
        'Expected service as service_mgr, but got {0}'.format(results['service_mgr'])

   

# Generated at 2022-06-23 01:48:52.057870
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils._text import to_bytes

    os.environ['PATH'] = '/usr/bin:/bin'

    # Mock module in module_utils because we don't want to
    # depend on the results of get_bin_path.  This is a
    # known problem with unittest.mock.patch (see
    # https://github.com/testing-cabal/mock/issues/493).
    # The simple solution is to mock the module in the
    # module_utils directory, which works, but is a little
    # ugly.
    class MockModule():
        def get_bin_path(self, _executable, required=True):
            return '/usr/bin/systemctl'

    # Create a fake "canary" file
    canary_path = '/run/systemd/system/'
   

# Generated at 2022-06-23 01:49:02.650411
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector._test_module = None
    ServiceMgrFactCollector._test_collector = None
    ServiceMgrFactCollector._test_collector_result = {}
    ServiceMgrFactCollector._test_collector_result['ansible_system'] = 'Linux'
    ServiceMgrFactCollector._test_collector_result['ansible_distribution'] = 'Debian'
    ServiceMgrFactCollector._test_module_result = {'service_mgr': 'service'}


if __name__ == '__main__':
    # using sys.argv[1] because python uses argv[0] for the module filename
    test_ServiceMgrFactCollector_collect()
    print("Failed; No unit tests are implemented for %s." % sys.argv[1])

# Generated at 2022-06-23 01:49:11.361587
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class TestModule(object):
        def get_bin_path(name=None, opt_dirs=None):
            return "/bin/systemctl"

    systemd = ServiceMgrFactCollector()
    res = systemd.is_systemd_managed_offline(module=TestModule())
    assert res == False

# Generated at 2022-06-23 01:49:17.290141
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    class FakeModule(object):
        @staticmethod
        def get_bin_path(cmd):
            return "/bin/systemctl"

    fake_module = FakeModule()
    c = ServiceMgrFactCollector(fake_module)
    assert c.is_systemd_managed_offline(fake_module)

# Generated at 2022-06-23 01:49:27.230742
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):

        def __init__(self):
            self.run_command_return_values = {
                ('stat -c %a /etc/systemd/system/',): (0, '755\n', ''),
            }
            self.run_command_calls = []

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

        def run_command(self, cmd, use_unsafe_shell=False, check_rc=True):
            self.run_command_calls.append((cmd,))
            return_value = self.run_command_return_values[(cmd,)]
            return return_value

    # Return value for is_systemd_managed should

# Generated at 2022-06-23 01:49:36.854418
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    import ansible.module_utils.facts.collector as facts_collector
    import ansible.module_utils.basic as basic
    import tempfile

    # build fake module object for testing
    class FakeModule(object):
        def __init__(self, bin_path=None):
            self.params = {}
            self.tmpdir = tempfile.mkdtemp(dir='/tmp')
            basic.ANSIBLE_LOCALHOST = {'ansible_system': 'Linux'}
            facts_collector.collected_facts = basic.ANSIBLE_LOCALHOST


# Generated at 2022-06-23 01:49:39.761450
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x
    assert x.name == 'service_mgr'
    assert 'service_mgr' in x._fact_ids

# Generated at 2022-06-23 01:49:42.671487
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.service_mgr as service_mgr_utils

    module_mock = basic.AnsibleModule(argument_spec={})
    module_mock.params = {'path': '/bin'}
    service_mgr_utils.ServiceMgrFactCollector.is_systemd_managed(module_mock)
    assert True

# Generated at 2022-06-23 01:49:54.107907
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module = AnsibleModuleMock()

    # test detection of service_mgr using /proc/1/comm output
    sut = ServiceMgrFactCollector()

    proc_1_output_examples = [
        ['foo', 'foo'],
        ['upstart', 'upstart'],
        ['/sbin/init', 'init'],
        ['/path/to/init', 'init'],
        ['', 'service'],
    ]

    for proc_1_output, expected_service_mgr in proc_1_output_examples:

        module.get_bin_path.return_value = True
        module.run_command.return_value = proc_1_output

        actual_service_mgr = sut.collect()

        assert 'service_mgr' in actual_service_mgr

# Generated at 2022-06-23 01:49:58.233264
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_obj = ServiceMgrFactCollector()
    assert service_mgr_obj.name == 'service_mgr'
    assert service_mgr_obj.required_facts == set(['platform', 'distribution'])