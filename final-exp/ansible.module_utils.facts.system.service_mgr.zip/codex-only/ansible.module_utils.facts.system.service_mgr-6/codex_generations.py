

# Generated at 2022-06-23 01:40:04.144635
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collectors.service import ServiceMgrFactCollector

    # This is SUSE OpenStack Cloud 7 SP1
    module = MockModule(
        dict(
            run_command=mock_run_command_for_is_systemd_managed_offline_test,
            get_bin_path=lambda _: '/usr/bin/systemctl'
        )
    )
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # This is SUSE Linux Enterprise Server 12 SP2
    module = MockModule(
        dict(
            run_command=mock_run_command_for_is_systemd_managed_offline_test,
            get_bin_path=lambda _: '/usr/bin/systemctl'
        )
    )

# Generated at 2022-06-23 01:40:10.000395
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    test_object = ServiceMgrFactCollector()
    assert test_object
    assert test_object.name == 'service_mgr'
    assert test_object._fact_ids is not None
    assert len(test_object._fact_ids) == 1
    assert test_object.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:40:17.904498
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class MockModule():
        def get_bin_path(self, path):
            return '/usr/bin/systemctl'

    module = MockModule()
    service_mgr = ServiceMgrFactCollector()

    # Test system with systemd init
    os.symlink('/lib/systemd/systemd', '/sbin/init')
    assert service_mgr.is_systemd_managed_offline(module)

    # Test system with systemd initscripts installed
    os.unlink('/sbin/init')
    os.symlink('/lib/systemd/systemd-sysv-install', '/sbin/init')
    assert not service_mgr.is_systemd_managed_offline(module)

# Generated at 2022-06-23 01:40:28.212910
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/path/to/systemctl'
            elif cmd == 'initctl':
                return '/path/to/initctl'
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd is None:
                return (0, 'bash', 'test-stderr')
            elif cmd == 'ps -p 1 -o comm|tail -n 1':
                return (0, 'init', 'test-stderr')
            else:
                return (0, 'empty', 'test-stderr')


# Generated at 2022-06-23 01:40:36.899549
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    # assert that the object has the following required attributes
    assert obj.name == 'service_mgr'
    assert obj.required_facts == {'platform', 'distribution'}
    assert obj.collect() == {}

if __name__ == '__main__':
    # Test module
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['all'], required=False),
        'gather_timeout': dict(default=10, required=False)
    })

    res_args = {
        'changed': False,
        'failed': False,
        'ansible_facts': {}
    }

    res_args['ansible_facts'] = ServiceMgrFactCollector().collect(module=module)

# Generated at 2022-06-23 01:40:43.393413
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = object()
    get_bin_path_value = None
    class Module:
        def get_bin_path(self, path):
            return get_bin_path_value
    module.Module = Module
    module.run_command = lambda command, **kwargs: ('', '', '')

    service_mgr = ServiceMgrFactCollector()
    service_mgr.is_systemd_managed_offline(module)
    assert get_bin_path_value == 'systemctl'


# Generated at 2022-06-23 01:40:51.874994
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class MockModule:
        def get_bin_path(self, name):
            return "/bin/systemctl"

        def run_command(self, a, b):
            return 0, "", ""

    mock_module = MockModule()
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module) == True

    class MockModule2:
        def get_bin_path(self, name):
            return False

        def run_command(self, a, b):
            return 0, "", ""

    mock_module2 = MockModule2()

# Generated at 2022-06-23 01:41:05.310695
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    mocked_module = MyMockModule()

    def mocked_is_systemd_managed(module):
        # test with 'systemctl' present, but without a systemd canary directory
        mocked_module.params = {'module_setup': True, 'executable': '/usr/bin/systemctl'}
        return ServiceMgrFactCollector.is_systemd_managed(module)


# Generated at 2022-06-23 01:41:14.759378
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    # Constructor of class ServiceMgrFactCollector is an instance of class FactCollector
    assert isinstance(ServiceMgrFactCollector.__dict__['__init__'], FactCollector)

    # Required facts are 'platform', 'distribution'
    assert ServiceMgrFactCollector.required_facts == {'platform', 'distribution'}

    # _fact_ids to collect
    _fact_ids = set()
    assert ServiceMgrFactCollector._fact_ids == _fact_ids

    # Call the method 'is_systemd_managed' of class ServiceMgrFactCollector
    #sys.modules['ansible.module_utils.facts

# Generated at 2022-06-23 01:41:16.047874
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector().collect()

# Generated at 2022-06-23 01:41:18.802672
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ('service_mgr', ) == ServiceMgrFactCollector.depends

# Generated at 2022-06-23 01:41:20.103686
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(mock_module=None) == False

# Generated at 2022-06-23 01:41:25.772426
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a module object
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Run ServiceMgrFactCollector.collect and check result
    result = ServiceMgrFactCollector.collect(module, dict())

    assert result == {'service_mgr': 'systemd'}

# Generated at 2022-06-23 01:41:29.862785
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import get_file_content

    # prepare persistence of ServiceMgrFactCollector._fact_ids
    fact_ids = ServiceMgrFactCollector._fact_ids
    fact_ids.add('service_mgr')
    # ... and ensure it goes back to empty after the run
    try:
        # call the static method collect via class instance
        service_mgr = ServiceMgrFactCollector.collect()
    finally:
        ServiceMgrFactCollector._fact_ids = fact_ids

    # unsupported OSes

# Generated at 2022-06-23 01:41:37.965757
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    class MockModule():
        def get_bin_path(self, path):
            return path
    class MockFactCollector():
        def __init__(self):
            self.platform = "MacOSX"
            self.distribution = "OpenWrt"
    mock_module = MockModule()
    mock_fact_collector = MockFactCollector()
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_dict = service_mgr_fact_collector.collect(mock_module, mock_fact_collector)
    assert service_mgr_fact_dict['service_mgr'] == "service"

# Generated at 2022-06-23 01:41:43.076881
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector.collect({'get_file_content': get_file_content,
                                     'get_bin_path': lambda _: True,
                                     'run_command': lambda _, use_unsafe_shell=False: (0, '', '')},
                                    {'ansible_distribution': 'OpenWrt', 'ansible_system': 'Linux'})

# Generated at 2022-06-23 01:41:46.417923
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    class FakeModule:
        def get_bin_path(self, command):
            return '/bin/systemctl'
    smfc = ServiceMgrFactCollector()
    assert smfc.is_systemd_managed_offline(FakeModule()) == False

# Generated at 2022-06-23 01:41:54.569736
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test_cases = [(False, '/var/run/systemd/system', False, True),
                  (True, '/var/run/systemd/system', False, True),
                  (True, '/var/run/systemd/system', True, False),
                  (True, '/var/run/systemd/system', True, True),
                  ]
    for test_case in test_cases:
        proc_cmdline = '/proc/cmdline'
        proc_cmdline_content = 'BOOT_IMAGE'
        openwrt_canary = '/run/systemd/system/'
        if test_case[0]:
            openwrt_canary = '/dev/.run/systemd/'
        if test_case[1]:
            openwrt_canary = '/dev/.systemd/'

# Generated at 2022-06-23 01:42:04.006971
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # mocks
    class MockSystemctl:
        def __init__(self, cmd, return_code, stdout, stderr):
            self.cmd = cmd
            self.return_code = return_code
            self.stdout = stdout
            self.stderr = stderr

        def __call__(self, module, cmd, check_rc=True):
            if cmd == self.cmd:
                return (self.return_code, self.stdout, self.stderr)
            else:
                return (1, '', 'systemctl not mocked')

    class MockModule:
        def __init__(self):
            self.run_command = MockSystemctl(['systemctl', 'foo'], 0, '', '')

    # tests
    mock_module = MockModule()

    # check if a mocked

# Generated at 2022-06-23 01:42:06.763965
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    ServiceMgrFactCollector.is_systemd_managed(None)

# Generated at 2022-06-23 01:42:10.594620
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Unit test for constructor of class ServiceMgrFactCollector"""
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:42:12.759441
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    unit = ServiceMgrFactCollector()
    assert unit.is_systemd_managed(None) is False


# Generated at 2022-06-23 01:42:23.051163
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector()

    class MyModule:
        def get_bin_path(self, name):
            return '/usr/bin/{}'.format(name) if name == 'systemctl' else None

    class MyPlatform:
        system = lambda: 'Linux'
        mac_ver = lambda: ('', ('', '', ''), '')
        dist = lambda: ('', '', '')

    class MyOS:
        path = os.path
        readlink = os.readlink

    # Validate that ServiceMgrFactCollector.is_systemd_managed_offline behaves correctly if /sbin/init
    # is a symlink to systemd.
    orig_os = ServiceMgrFactCollector.os
    orig_platform = ServiceMgrFactCollector.platform
    ServiceMgrFactCollector.os

# Generated at 2022-06-23 01:42:26.397378
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # check if we have detected generic service as service manager
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.collect() == {'service_mgr': 'service'}

# Generated at 2022-06-23 01:42:35.167585
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    mock_module = create_mock_module(
        dict(
            path='/usr/bin:/usr/sbin:/bin:/sbin',
            file_exists=lambda x: True,
            get_bin_path=lambda x: '/bin/systemctl',
        )
    )

    service_mgr = ServiceMgrFactCollector(mock_module)
    assert service_mgr.is_systemd_managed(mock_module)


# Generated at 2022-06-23 01:42:43.224619
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector.service.service_mgr import (
        ServiceMgrFactCollector
    )

    # Real test no module argument
    collector = ServiceMgrFactCollector()
    result = collector.collect()
    assert result == {}

    # Real test no module argument
    collector = ServiceMgrFactCollector(module=None)
    result = collector.collect()
    assert result == {}

    # Real test no module argument
    collector = ServiceMgrFactCollector(module=None, collected_facts={})
    result = collector.collect()
    assert result == {}


# Generated at 2022-06-23 01:42:50.132198
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    mock_module = type('MockModule', (object,), {'get_bin_path': lambda x: '/bin/systemctl', 'run_command': lambda *args, **kwargs: (0, 'init (/usr/lib/systemd/systemd)', '')})
    x = ServiceMgrFactCollector(mock_module)
    assert x._fact_ids == set()
    assert x.name == 'service_mgr'
    assert x.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:42:54.026950
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Test with platform name as linux
    svc_mgr = ServiceMgrFactCollector()
    assert svc_mgr.name == 'service_mgr'
    assert svc_mgr._fact_ids == set()
    assert 'platform' in svc_mgr.required_facts

# Generated at 2022-06-23 01:43:04.922125
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    test_is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed
    test_is_systemd_managed_offline = ServiceMgrFactCollector.is_systemd_managed_offline

    # Fake the module's platform.system() to return 'Linux'
    testPlatform = platform.system
    platform.system = lambda: 'Linux'

    # Fake the module's get_bin_path() to return different values depending on
    # the argument
    testGetBinPath = os.path.isfile
    def fakeGetBinPath(cmd):
        if cmd == 'systemctl':
            return True
        else:
            return False

    test_is_systemd_managed_offline_dir = os.path.isdir

# Generated at 2022-06-23 01:43:08.672171
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    module = AnsibleModuleMock(params={})
    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector.is_systemd_managed(module) == True

test_ServiceMgrFactCollector_is_systemd_managed()

# Generated at 2022-06-23 01:43:18.412879
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args, exit_json, fail_json, AnsibleExitJson
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock
    from ansible.module_utils import basic

    # Setup
    tmp_dir = tempfile.mkdtemp()
    init_path = '%s/init' % tmp_dir

    # Mock
    class AnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs


# Generated at 2022-06-23 01:43:20.507754
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_obj = ServiceMgrFactCollector()

    assert service_mgr_obj.name == 'service_mgr'

# Generated at 2022-06-23 01:43:30.372633
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    import tempfile

    # AnsibleModule will be mocked for us by basic.AnsibleModule
    ansible_module = basic.AnsibleModule(argument_spec={})

    # Create fake directories and files
    tmp_dir = tempfile.mkdtemp()
    dev_run_systemd_dir = os.path.join(tmp_dir, 'dev', '.run', 'systemd')
    dev_systemd_dir = os.path.join(tmp_dir, 'dev', '.systemd')
    init_path = os.path.join(tmp_dir, 'sbin', 'init')

    os.makedirs(dev_run_systemd_dir)

# Generated at 2022-06-23 01:43:36.545328
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x
    assert x.name == 'service_mgr'
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert x._fact_ids is not None
    assert ServiceMgrFactCollector._fact_ids is not None

# Generated at 2022-06-23 01:43:43.828398
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import mock
    import platform
    serviceMgrFactCollector = ServiceMgrFactCollector()

    # test is_systemd_managed_offline
    if platform.system() != 'SunOS':
        module = mock.MagicMock()
        module.get_bin_path.return_value = None
        result = serviceMgrFactCollector.is_systemd_managed_offline()
        assert result is False

        module = mock.MagicMock()
        module.get_bin_path.return_value = '/usr/bin/systemctl'
        result = serviceMgrFactCollector.is_systemd_managed_offline()
        assert result is False

        # is_systemd_managed_offline returns True if /sbin/init is a symlink to systemd
        module = mock.MagicMock()
        module

# Generated at 2022-06-23 01:43:46.987183
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    '''Unit test for constructor of class ServiceMgrFactCollector'''
    smfc = ServiceMgrFactCollector()
    assert 'service_mgr' in smfc.name

# Generated at 2022-06-23 01:43:49.860312
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False


# Generated at 2022-06-23 01:43:52.831690
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    instance = ServiceMgrFactCollector()
    assert isinstance(instance, ServiceMgrFactCollector)
    assert instance.name == 'service_mgr'
    assert instance._fact_ids == set()
    assert instance.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:43:55.488498
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'
    assert obj.required_facts == {'platform', 'distribution'}
    assert obj._fact_ids == set()
    assert not obj.collected_facts

# Generated at 2022-06-23 01:43:58.325787
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed(None) == False
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

# Generated at 2022-06-23 01:44:06.502389
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock

    # create instance of module
    module = mock.Mock()
    module.get_bin_path.return_value = None

    # create instance of ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector.__new__(ServiceMgrFactCollector)

    # test getting service manager
    service_mgr = service_mgr_fact_collector.is_systemd_managed(module)

    # assert that service_mgr is False
    assert service_mgr == False, \
        "service_mgr is expected to be False but is {0}".format(service_mgr)


# Generated at 2022-06-23 01:44:10.242547
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector(None)
    assert x.name == 'service_mgr'
    assert x.required_facts == {'distribution', 'platform'}
    assert x._fact_ids == set()
# EOF

# Generated at 2022-06-23 01:44:16.662770
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    try:
        # Not a Linux platform.
        svc_mgr_fact_collector = ServiceMgrFactCollector()
    except TypeError:
        pass
    else:
        assert False, 'The ServiceMgrFactCollector constructor should raise a TypeError for non-linux platforms.'

    svc_mgr_fact_collector = ServiceMgrFactCollector(module=None)
    svc_mgr_fact_collector = ServiceMgrFactCollector(module=object())

# Generated at 2022-06-23 01:44:25.587596
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    import os
    import tempfile

    # test without anything
    m = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    del m.params
    m.exit_json = lambda xx: xx
    f = ServiceMgrFactCollector(m)
    assert f.is_systemd_managed_offline(m) == False

    # create a temporary directory to run our systemd test

# Generated at 2022-06-23 01:44:26.957255
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Test empty constructor
    ServiceMgrFactCollector()


# Generated at 2022-06-23 01:44:37.523341
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    def fake_get_bin_path(arg):
        return True


# Generated at 2022-06-23 01:44:38.553995
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()



# Generated at 2022-06-23 01:44:42.848525
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    '''Unit test for constructor of class ServiceMgrFactCollector'''
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:44:50.282263
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert issubclass(ServiceMgrFactCollector, BaseFactCollector)
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])
    xp = ServiceMgrFactCollector()
    assert xp

# Note: Ansible will not execute this module functions because this file
# name does not start with facts_ or contain test_
if __name__ == '__main__':
    print(ServiceMgrFactCollector.collect())

# Generated at 2022-06-23 01:44:52.352546
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x.name == 'service_mgr'
    assert x.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:44:53.801345
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector.collect()

# Generated at 2022-06-23 01:44:59.551017
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """Unit test for method collect of class ServiceMgrFactCollector"""

    # Collected facts is a dict with the collected facts
    collected_facts = {}

    # Module argument spec used in the AnsibleModule init of the collect method
    collected_facts['ansible_facts'] = {'ansible_system': 'Linux', 'ansible_distribution': 'Fedora'}
    ansible_module = {'get_bin_path': lambda x: '/usr/libexec/platform-python'}

    # Collect the service_mgr fact from ServiceMgrFactCollector instance
    service_mgr_fact = ServiceMgrFactCollector().collect(module=ansible_module, collected_facts=collected_facts)

    # Assert service_mgr fact is as expected

# Generated at 2022-06-23 01:45:10.261340
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector

    class DummyServiceMgrFactCollector(ServiceMgrFactCollector):
        @staticmethod
        def is_systemd_managed_offline(module):
            return super(DummyServiceMgrFactCollector, DummyServiceMgrFactCollector).is_systemd_managed_offline(module)

    class DummyModule:
        def get_bin_path(self, path):
            return "/usr/bin/systemctl"

    class DummyModule2:
        def get_bin_path(self, path):
            return None

    collector = DummyServiceMgrFactCollector()
    module = DummyModule()
    assert collector.is_systemd_managed_offline(module) is True

    module = DummyModule2()
    assert collector.is_

# Generated at 2022-06-23 01:45:15.188633
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector_obj = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_obj.name == 'service_mgr'
    assert service_mgr_fact_collector_obj.required_facts == {'platform', 'distribution'}


# Generated at 2022-06-23 01:45:26.766884
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import collections
    import os
    import tempfile
    import unittest
    import ansible.module_utils
    from ansible.module_utils.facts.collector import BaseFactCollector

    class ServiceMgrFactCollectorTest(unittest.TestCase):
        def setup(self, module_data_dir):
            mock_module = collections.namedtuple('MockModule', 'get_bin_path,run_command,get_bin_path')
            mock_module.params = {}
            mock_module.check_mode = False

            def mock_get_bin_path(inst, command):
                return os.path.join(module_data_dir, command)

            def mock_run_command(inst, command, use_unsafe_shell=False):
                return 0, None, None

            mock_module.get

# Generated at 2022-06-23 01:45:28.849626
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == "service_mgr"

# Generated at 2022-06-23 01:45:31.723886
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    fact_collector = ServiceMgrFactCollector(None)
    assert fact_collector.is_systemd_managed_offline(None) == False


# Generated at 2022-06-23 01:45:38.922155
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    import platform
    import os

    def mock_get_bin_path(name):
        if name == 'systemctl':
            return True
        else:
            return False

    def mock_run_command(command, use_unsafe_shell):
        return 0, '', ''

    def mock_exists(name):
        return True

    # construct ServiceMgrFactCollector object
    module = mock.Mock()
    module.get_bin_path = mock.Mock(side_effect=mock_get_bin_path)
    module.run_command = mock.Mock(side_effect=mock_run_command)
    module.exists = mock.Mock(side_effect=mock_exists)

    s = ServiceMgrFactCollector()

    # test case:  is_

# Generated at 2022-06-23 01:45:47.110073
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    facts = {}
    sf = ServiceMgrFactCollector()
    assert sf is not None
    assert sf.name == 'service_mgr'
    assert sf.required_facts == set(['platform', 'distribution'])
    assert sf.collect(collected_facts=facts) == {}

# Generated at 2022-06-23 01:45:54.925425
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    import os
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestServiceMgrCollector(ServiceMgrFactCollector):
        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            collected_facts['ansible_system'] = 'Linux'
            collected_facts['ansible_distribution'] = 'CentOS'
            return super(TestServiceMgrCollector, self).collect(module=module, collected_facts=collected_facts)

    # Make sure pid 1 is symlinked to systemd
    with open('/proc/1/comm', 'w') as f:
        f.write('systemd\n')

    # make sure systemctl bin exists

# Generated at 2022-06-23 01:46:04.035760
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import os
    import shutil
    import logging
    import platform

    s = ServiceMgrFactCollector()
    if platform.system() == 'Windows':
        print('Test platform is Windows, cannot run test')
        return

    from ansible.module_utils.basic import AnsibleModule

    def run_module():
        # since we are testing just the fact collector, we don't need the full payload
        module_args = dict()
        module = AnsibleModule(
            argument_spec=module_args,
        )
        if module.params['_ansible_check_mode']:
            return dict(skipped=True, msg="Test can only be run in ansible-playbook mode, as it stands currently")
        return s.collect(module=module, collected_facts={})


# Generated at 2022-06-23 01:46:09.926777
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test_module = lambda *args, **kwargs: None
    test_module.get_bin_path = lambda *args, **kwargs: None
    test_module.run_command = lambda *args, **kwargs: (0, "", "")

    def test_exists(path):
        return path in [ "/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/" ]

    os.path.exists = test_exists

    service_mgr = ServiceMgrFactCollector()
    assert(service_mgr.is_systemd_managed(test_module) == True)


# Generated at 2022-06-23 01:46:18.065856
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule:
        def get_bin_path(self, cmd):
            return cmd

    class MockOs:
        @staticmethod
        def path_exists(path):
            if path == '/run/systemd/system/':
                return True
            if path == '/dev/.run/systemd/':
                return True
            if path == '/dev/.systemd/':
                return True
            return False

    srv_mgr = ServiceMgrFactCollector()
    srv_mgr.os = MockOs
    assert srv_mgr.is_systemd_managed(MockModule())
    

# Generated at 2022-06-23 01:46:27.478552
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    collector = ServiceMgrFactCollector()
    class FakeModule(object):
        def get_bin_path(self, path):
            if path == 'systemctl':
                return '/usr/bin/systemctl'
            return None
    class FakeFacts():
        def __init__(self):
            self.ansible_os_family = 'Suse'
            self.ansible_distribution = 'Suse'
            
    module = FakeModule()
    facts = FakeFacts()
    # no canary files
    assert collector.is_systemd_managed(module) == False
    # add one canary file
    with open('/dev/.run/systemd/', 'a'):
        os.utime('/dev/.run/systemd/', None)
    assert collector.is_systemd_managed(module)


# Generated at 2022-06-23 01:46:38.993873
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils import basic
    from ansible.module_utils.six.moves import builtins
    import os

    file_name = "/sbin/init"
    if os.path.isfile(file_name):
        os.remove(file_name)
    os.symlink('/bin/systemd', file_name)
    a = ServiceMgrFactCollector()

    class TestModule:
        def __init__(self):
            self.run_command = basic.AnsibleModule.run_command

    b = TestModule()
    assert not a.is_systemd_managed(b)
    assert a.is_systemd_managed_offline(b)
    os.remove(file_name)

# Generated at 2022-06-23 01:46:47.461775
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def __init__(self):
            self._systemctl_path = None
            self._is_systemd_managed_paths = []

        def get_bin_path(self, arg):
            if arg == 'systemctl':
                return self._systemctl_path

        def exists(self, path):
            return path in self._is_systemd_managed_paths

        def set_systemctl_path(self, path):
            self._systemctl_path = path

        def set_is_systemd_managed_paths(self, paths):
            self._is_systemd_managed_paths = paths

    collector = ServiceMgrFactCollector()
    module = MockModule()

    module.set_systemctl_path('/bin/systemctl')
    assert collector.is_systemd

# Generated at 2022-06-23 01:46:55.847407
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    class MockRunner():
        def __init__(self, rc, output, err):
            self.rc = rc
            self.output = output
            self.err = err

        def run_command(self, cmd, use_unsafe_shell=True):
            return (self.rc, self.output, self.err)

    class MockModule():
        def __init__(self, runner):
            self.runner = runner

        def get_bin_path(self, command, required=False):
            return True

        def run_command(self, cmd, use_unsafe_shell=True):
            return self.runner.run_command(cmd, use_unsafe_shell)

    # Test 1: Check is false if there is no systemd
    collector = ServiceMgrFactCollector()

# Generated at 2022-06-23 01:47:03.630014
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:47:10.492657
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    collector = ServiceMgrFactCollector()
    module_mock = Mock()
    module_mock.get_bin_path.return_value = '/usr/bin/systemctl'

    # Init with systemd
    is_systemd = collector.is_systemd_managed(module_mock)
    assert is_systemd is True

    # Init with different service manager
    module_mock.get_bin_path.return_value = None
    is_systemd = collector.is_systemd_managed(module_mock)
    assert is_systemd is False


# Generated at 2022-06-23 01:47:16.606815
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import which_collector

    def mock_get_file_content(path):
        return 'init'

    def mock_get_bin_path(binary):
        return True

    def mock_is_systemd_managed(module=None):
        return True

    def mock_is_systemd_managed_offline(module=None):
        return True

    def mock_run_command(cmd, use_unsafe_shell=True):
        return (1, '', '')

    service_mgr_collector = ServiceMgrFactCollector()
    module = MockModule()
    collected_facts = {}
    service_mgr_collector.collect(module, collected_facts)


# Generated at 2022-06-23 01:47:21.757697
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    module = {
        'get_bin_path': lambda path: path,
        'run_command': lambda cmd, use_unsafe_shell=False: (1, '', ''),
    }
    collected_facts = {
    }
    service_mgr = ServiceMgrFactCollector()
    service_mgr.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-23 01:47:25.848460
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fc = ServiceMgrFactCollector()
    assert service_mgr_fc.name == 'service_mgr'
    assert service_mgr_fc._fact_ids == set()
    assert service_mgr_fc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:47:34.005664
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    # Create a class instance
    service_mgr = ServiceMgrFactCollector()

    # Create a module
    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    # Check on a valid path that systemctl is the boot init system
    if os.path.exists("/dev/.run/systemd/"):
        assert service_mgr.is_systemd_managed_offline(module) == True
    # Check on a valid path that systemd is not the boot init system
    elif os.path.exists("/etc/init.d/"):
        assert service_mgr.is_systemd_managed_offline(module) == False
    # Assume that systemd is not the boot init system

# Generated at 2022-06-23 01:47:37.917978
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fc = ServiceMgrFactCollector()
    assert fc is not None

# Generated at 2022-06-23 01:47:49.441198
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # This is a fake module to be used by ServiceMgrFactCollector.
    # The following functions shall be implemented by the fake module:
    #   - run_command
    #   - get_bin_path
    class FakeModule:
        def __init__(self):
            self.bin_path_map = {}

        def run_command(self, command, **kwargs):
            # Mapping of commands to expected outputs.
            cmd_map = {
                'ps -p 1 -o comm|tail -n 1': ['0', 'systemd', '']
            }

            # No mapping for command?
            if not command in cmd_map:
                raise Exception('unexpected command: {}'.format(command))

            return cmd_map[command]

        def get_bin_path(self, binary):
            return self.bin_

# Generated at 2022-06-23 01:47:57.465430
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import os
    import os.path
    import stat

    # Mock the module
    class MockModule():
        def __init__(self):
            # Create a temporary folder
            self.tmpdir = tempfile.mkdtemp()
            # Create a tmp dir in it
            os.makedirs(os.path.join(self.tmpdir, 'tmp'))
            # Create a fake command
            self.systemctl = os.path.join(self.tmpdir, 'tmp', 'systemctl')
            content = '#!/bin/sh\necho "systemctl (systemd)"'
            with open(self.systemctl, 'w') as f:
                f.write(content)

# Generated at 2022-06-23 01:48:06.845938
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = mock.MagicMock()

    # Create a mock command
    mock_command = mock.MagicMock()

    # Set the run_command method to return the mock_command.
    module.run_command = mock.Mock(return_value=mock_command)

    #Set the rc of the mock command to 0.
    module.run_command.return_value.rc = 0

    # Set the command to return string "/sbin/init\n"
    module.run_command.return_value.stdout = "/sbin/init\n"

    # Set the method get_bin_path to return False.
    module.get_bin_path = mock.Mock(return_value=False)

    # Set the collected_facts dictionary

# Generated at 2022-06-23 01:48:09.930022
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    o = ServiceMgrFactCollector()
    assert o.name == 'service_mgr'
    assert o.required_facts == set(['platform', 'distribution'])
    assert o._fact_ids == set()

# Generated at 2022-06-23 01:48:12.245620
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:48:16.631996
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.service_mgr
    mgr = ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector()
    assert mgr.is_systemd_managed({ 'get_bin_path': lambda x: True }) == True
    assert mgr.is_systemd_managed({ 'get_bin_path': lambda x: False }) == False


# Generated at 2022-06-23 01:48:22.467492
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # this test requires systemd
    # FIXME: mock module object to test
    try:
        import systemd
    except ImportError:
        import pytest
        pytest.skip("this test requires systemd")

    # create a test object and call the method
    fact_collector = ServiceMgrFactCollector()
    result = fact_collector.is_systemd_managed_offline(None)
    assert result == True

# Generated at 2022-06-23 01:48:33.219682
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # test is_systemd_managed function
    is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed
    assert is_systemd_managed(None) == False
    assert is_systemd_managed(MockModule(systemctl_cmd='/bin/systemctl')) == False
    assert is_systemd_managed(MockModule(systemctl_cmd='/bin/systemctl', systemd_canary='/run/systemd/system/')) == True
    assert is_systemd_managed(MockModule(systemctl_cmd='/bin/systemctl', systemd_canary='/dev/.run/systemd/')) == True
    assert is_systemd_managed(MockModule(systemctl_cmd='/bin/systemctl', systemd_canary='/dev/.systemd/')) == True



# Generated at 2022-06-23 01:48:41.619394
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.util_systemd_managed
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.util_systemd_managed import ServiceMgrFactCollector

    service_mgr_fact_collector = ServiceMgrFactCollector()
    print(type(service_mgr_fact_collector.is_systemd_managed))
    assert service_mgr_fact_collector.is_systemd_managed(None) == False

# Generated at 2022-06-23 01:48:49.249998
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import ModuleFactsCollector
    service_mgr_fact_collector = ServiceMgrFactCollector({},{})
    module_fact_collector = ModuleFactsCollector()

    module_fact_collector.collect()
    module = module_fact_collector.module

    assert (not service_mgr_fact_collector.is_systemd_managed(module)) == True

# Generated at 2022-06-23 01:48:55.770955
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Set up mock module object
    class MockModule(object):
        def get_bin_path(self, cmd, required=True):
            return False
        def run_command(self, cmd, use_unsafe_shell=True):
            return (0, 'upstart', '')

    mod = MockModule()
    fact = ServiceMgrFactCollector()
    res = fact.collect(module=mod)
    assert 'upstart' in res


# Generated at 2022-06-23 01:48:59.180090
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Test the constructor."""
    collector = ServiceMgrFactCollector()
    assert collector.name == 'service_mgr'
    assert collector._fact_ids == set()
    assert collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:49:04.389113
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import get_collector_instance, BaseFactCollector
    service_mgr = get_collector_instance(BaseFactCollector)
    service_mgr.get_bin_path = lambda executable: "/bin/"+executable
    service_mgr.is_systemd_managed_offline = ServiceMgrFactCollector.is_systemd_managed_offline
    service_mgr.collect = lambda: None
        
    assert service_mgr.is_systemd_managed_offline(service_mgr) == False

# Generated at 2022-06-23 01:49:15.583392
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Test converting /sbin/init symlink to 'systemd'
    """
    # create dummy module for testing
    class DummyModule:
        def get_bin_path(self, path):
            return "/usr/bin/systemctl"


# Generated at 2022-06-23 01:49:25.910712
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    import unittest
    import __builtin__
    import types
    class AnsibleModule():
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.run_command = lambda x, **kwargs: (0, 'openrc', None)
            self.get_bin_path = lambda x: '/sbin/' + x
        def fail_json(self, msg):
            raise Exception("Fail: %s" % msg)
    class MockOs():
        def __init__(self):
            pass
        def path(self):
            return MockOsPath()
        class MockOsPath():
            def __init__(self):
                pass
            def islink(self, path):
                if path in ['/sbin/init', '/sbin/openrc']:
                    return True

# Generated at 2022-06-23 01:49:35.986378
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    mocks = {}

    class AnsibleModule:

        def __init__(self):
            # for ServiceMgrFactCollector.is_systemd_managed method
            self.params = {}
            self.run_command = mocks['run_command']
            self.get_bin_path = mocks['get_bin_path']

    class EmptyModuleUtils:
        pass

    ansible_module = AnsibleModule()
    ServiceMgrFactCollector.is_systemd_managed(ansible_module)

    def test_run_command(cmd, use_unsafe_shell, check_rc=False):
        assert cmd == 'systemctl'
        assert use_unsafe_shell
        assert check_rc
        return 0, '/bin/systemctl', ''


# Generated at 2022-06-23 01:49:43.051084
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    import ansible.module_utils.facts.system.service_mgr
    import mock

    # Exists /sbin/init symlink to systemd, should return True
    module = mock.MagicMock()
    module.get_bin_path.return_value = '/usr/bin/systemctl'
    assert ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed_offline(module) is True

    # Exists /sbin/init symlink to sysinit, should return False
    module = mock.MagicMock()
    module.get_bin_path.return_value = '/usr/bin/systemctl'
    os.symlink = mock.MagicMock(return_value=False)
    assert ansible.module_utils.facts.system.service

# Generated at 2022-06-23 01:49:47.422613
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    collector = ServiceMgrFactCollector()
    assert not collector.is_systemd_managed_offline(None)

# Generated at 2022-06-23 01:49:49.805904
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.name == 'service_mgr'

# Generated at 2022-06-23 01:49:58.059761
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import Collector

    # Create a mock module object
    class MockModule(object):
        def get_bin_path(self, cmd, required=False, opt_dirs=[]):
            # Hack to make bin check work when run from test/units/modules
            # In real life, the bin check is failing because the
            # ansible.module_utils.facts.collector.get_file_content() invokes
            # os.stat(). It will fail because there are no such files as
            # /run/systemd/system, /dev/.run/systemd, /dev/.systemd. But we want
            # it just to return None
            if cmd == "systemctl":
                # return the path to a dummy executable
                return os.path.abspath(__file__)

    # Create a mock