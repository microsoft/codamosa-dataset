

# Generated at 2022-06-23 01:40:00.862595
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mock_module = MockModule()
    mock_module.params = {'gather_subset': ['all']}
    mock_module.run_command.side_effect = [[0, '/bin/systemd', ''], [0, '', 'could not find kernel image: linux']]
    cm = ServiceMgrFactCollector()
    assert cm.collect(module=mock_module) == {'service_mgr': 'systemd'}


# Generated at 2022-06-23 01:40:10.329540
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    Collector._module = False

    # init to force particular test
    Collector._module.run_command = lambda x: ''

    # test with ansible_distribution=MacOSX
    Collector._module.get_bin_path = lambda x: None
    Collector._module._KERNEL_RELEASE = None
    Collector._module._KERNEL_VERSION = None
    Collector._module._KERNEL_VERSION_NUMERIC = None
    Collector._module._KERNEL_NAME = None
    Collector._module._KERNEL_PRETTY_NAME = None
    Collector._module.distribution = 'MacOSX'
    service_mgr_facts = ServiceMgrFactCollector().collect(module=Collector._module, collected_facts={})
    assert service_mgr

# Generated at 2022-06-23 01:40:18.700941
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    collector = ServiceMgrFactCollector()

    # with a mock module, return '/bin/systemctl' for get_bin_path('systemctl')
    with mock.patch('os.path.exists') as mock_exists:
        mock_exists.return_value = True
        with mock.patch.object(BaseFactCollector, '_create_module', return_value=None) as mock_create_module:
            mock_create_module.return_value.get_bin_path.return_value = '/bin/systemctl'

            # check when /run/systemd/system/ exists
            # the

# Generated at 2022-06-23 01:40:29.000820
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    obj = ServiceMgrFactCollector()
    obj.name = 'service_mgr'
    obj._fact_ids = set()
    obj.required_facts = set(['platform', 'distribution'])

# Generated at 2022-06-23 01:40:32.005661
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    c = ServiceMgrFactCollector()
    assert c.name == 'service_mgr'
    assert c.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-23 01:40:40.692925
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import ansible.module_utils.facts.collectors
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

    collector = Collector(ansible_module=None)
    service_mgr_fact_collector = ServiceMgrFactCollector()
    collector._fact_cache['ansible_distribution'] = 'Linux'
    collector._fact_cache['ansible_system'] = 'Linux'

    # Case 1: is_systemd_managed returns False, is_systemd_managed_offline returns True, /etc/init.d/ exists, /etc/

# Generated at 2022-06-23 01:40:50.780610
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import mock
    import tempfile
    import os

    test_module = mock.Mock()
    test_module.get_bin_path.return_value = None

    assert not ServiceMgrFactCollector.is_systemd_managed_offline(test_module)

    test_module.get_bin_path.return_value = '/bin/systemctl'

    assert not ServiceMgrFactCollector.is_systemd_managed_offline(test_module)

    # temporary directory
    tmp_dir = tempfile.mkdtemp(prefix='ansible-test-facts.d')

# Generated at 2022-06-23 01:41:05.044900
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class dummymodule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/bin/systemctl'
            return None

        def run_command(self, cmd, use_unsafe_shell=None):
            return 0, cmd, ''

    sign_mock = dummymodule()
    sign_mock.run_command = lambda cmd, use_unsafe_shell=None: (0, '\n'.join(cmd.split()[1:]), '')
    collected_facts = {
        'ansible_system': 'linux',
        'ansible_service_mgr': 'sysvinit',
    }

# Generated at 2022-06-23 01:41:16.693537
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.gather import AnsibleFactCollector
    from ansible.module_utils import basic
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.mock import patch

    # Create the FactsCollector object
    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            filter=dict(default='*', required=False),
        )
    )
    facts_collector = AnsibleFactCollector(module=module)

    # Initalize the ServiceMgr

# Generated at 2022-06-23 01:41:20.112933
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    from ansible.module_utils.basic import AnsibleModule

    # Create a mock module for the test
    module = AnsibleModule()

    assert(ServiceMgrFactCollector.is_systemd_managed(module=module) == False)

# Generated at 2022-06-23 01:41:25.379187
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class TestModule:
        def get_bin_path(self, cmd):
            if (cmd == 'systemctl'):
                return '/usr/bin/systemctl'
            return None

    collector = ServiceMgrFactCollector()
    collector.is_systemd_managed(TestModule())


# Generated at 2022-06-23 01:41:35.371148
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import index
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts.collector

    dummy_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    dummy_module.get_bin_path = lambda _: '/bin/systemctl'

    mgr = index.FactCollector(dummy_module, 'setup')
    mgr._collectors = {}
    mgr._collectors['service_mgr'] = ServiceMgrFactCollector(mgr)
    mgr.collect()

    if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
        assert mgr.ans

# Generated at 2022-06-23 01:41:46.258855
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils
    import ansible.module_utils.facts.collector
    import test_utils
    import os

    # Test functionality of systemd_managed_offline method
    # Create dummy instance of ansible.module_utils.facts.collector.BaseFactCollector class
    dummy_collector = ansible.module_utils.facts.collector.BaseFactCollector(name="service_mgr")

    # Create dummy instance of ansible.module_utils.basic.AnsibleModule class
    dummy_ansible_module = test_utils.create_dummy_ansible_module()

    # Create instance of ansible.module_utils.facts.collector.ServiceMgrFactCollector class

# Generated at 2022-06-23 01:41:55.354485
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a Service Manager Fact Collector
    collector = ServiceMgrFactCollector()

    # Create test module
    def get_bin_path(path):
        return path

    def run_command(command, use_unsafe_shell=False):
        return 0, '\n', ''

    module = type('', (), {})()
    module.get_bin_path = get_bin_path
    module.run_command = run_command

    # Populate sys.modules with a dummy distutils module
    import sys
    sys.modules['distutils'] = None

    # Initialize test data

# Generated at 2022-06-23 01:42:01.480257
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_obj = ServiceMgrFactCollector()
    assert service_mgr_obj.name == 'service_mgr', "Actual: {} Expected: {}".format(service_mgr_obj.name, 'service_mgr')
    assert service_mgr_obj.required_facts == set(['platform', 'distribution']), "Actual: {} Expected: {}".format(service_mgr_obj.required_facts, set(['platform', 'distribution']))

# Generated at 2022-06-23 01:42:13.350888
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import FakeModule
    module = FakeModule(name='ansible.module_utils.facts.collector.Testfunction')
    service_mgr = ServiceMgrFactCollector(module=module)

    # The function is_systemd_managed should return False when systemctl command is not found.
    module.run_command.return_value = [127, None, None]
    assert service_mgr.is_systemd_managed(module) is False

    # The function is_systemd_managed should return True when /run/systemd/system exists.
    module.run_command.return_value = [0, None, None]
    module.get_bin_path.return_value = '/usr/bin/systemctl'
    module.stat.return_value = False
    assert service_

# Generated at 2022-06-23 01:42:18.114952
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # class needed for mock_module
    class Class:
        pass

    module = Class()
    module.get_bin_path = lambda x: '/bin/systemctl'
    module.run_command = lambda x, **kwargs: (0, '/run/systemd/system/', None)

    assert ServiceMgrFactCollector.is_systemd_managed(module) == True

# Generated at 2022-06-23 01:42:27.863672
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    tests = []

    # Empty test, should fail
    tests.append({
        'input_facts': {},
        'expected': False,
        'msg': "Empty test, should fail"
    })

    # Test with a linux distribution
    tests.append({
        'input_facts': {
            'ansible_distribution': 'Linux',
            'ansible_system': 'Linux',
        },
        'expected': {
            'service_mgr': 'sysvinit'
        },
        'msg': "Test with a linux distribution"
    })

    # Test with a macosx distribution

# Generated at 2022-06-23 01:42:38.082571
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a mock class module and a mock class ServiceMgrFactCollector
    class MockModule():
        def get_bin_path(self, cmd):
            return True
    class ServiceMgrFactCollectorTest():
        def __init__(self, module):
            self.module = module

    # Create a mock class LooseVersion
    class MockLooseVersion():
        def __init__(self, ver1):
            self.ver1 = ver1
        def __lt__(self, ver2):
            return False

    # Create a mock class os
    class MockOs():
        def __init__(self):
            self.path = MockPath()
    # Create a mock class os.path
    class MockPath():
        def islink(self, path):
            return True
        def readlink(self, path):
            return

# Generated at 2022-06-23 01:42:39.472408
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()


# Generated at 2022-06-23 01:42:43.025219
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert 'service_mgr' in ServiceMgrFactCollector._fact_ids
    assert 'platform' in ServiceMgrFactCollector.required_facts
    assert 'distribution' in ServiceMgrFactCollector.required_facts

# Generated at 2022-06-23 01:42:52.410101
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import get_collector_instance

    # Test is_systemd_managed method
    mock_module = MockAnsibleModule()
    mock_module.get_bin_path.return_value = "/usr/bin/systemctl"
    mock_module.run_command.return_value = (0, "", 0)
    service_mgr = get_collector_instance('service_mgr')
    assert service_mgr.is_systemd_managed(mock_module)

    mock_module = MockAnsibleModule()
    mock_module.get_bin_path.return_value = "/usr/bin/systemctl"
    mock_module.run_command.return_value = (0, "", 0)
    service_mgr = get_collect

# Generated at 2022-06-23 01:42:54.409465
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collectors.service_mgr as service_mgr

    assert service_mgr.ServiceMgrFactCollector().is_systemd_managed_offline(None) == False

# Generated at 2022-06-23 01:43:05.171987
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # import for unit testing
    import sys
    import tempfile
    import shutil

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.compat.version import LooseVersion

    # Initialize class
    sf = ServiceMgrFactCollector()

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create AnsibleModule object
    am = AnsibleModule(argument_spec=dict())

    # Init class ServiceMgrFactCollector
    sf.init_module_obj(am=am)

    _temp_bin = temp_dir + '/bin'

# Generated at 2022-06-23 01:43:09.214952
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    test_inst = ServiceMgrFactCollector()
    assert test_inst.name == 'service_mgr'
    assert isinstance(test_inst._fact_ids, set)
    assert test_inst.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-23 01:43:11.259241
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Unit test for constructor of class ServiceMgrFactCollector"""
    ServiceMgrFactCollector()



# Generated at 2022-06-23 01:43:13.865232
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    fake_module = FakeModule({})
    assert ServiceMgrFactCollector.is_systemd_managed_offline(fake_module) == False


# Generated at 2022-06-23 01:43:21.747983
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import ModuleFactCollector

    mfc = ModuleFactCollector()
    mock_module = mfc.get_module()
    mock_module.get_bin_path = lambda x: '/usr/bin/chsh'
    mock_module.run_command = lambda x: (0, '/etc/init.d/', '')
    smfc = ServiceMgrFactCollector()
    collected_facts = {'ansible_distribution': 'CentOS', 'ansible_system': 'Linux', 'platform': 'Linux'}
    result = smfc.collect(mock_module, collected_facts)
    assert result['service_mgr'] == 'sysvinit'


# Generated at 2022-06-23 01:43:29.692985
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Test the ServiceMgrFactCollector class.
    """
    # Import the class to test at the top level so that it can be mocked
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Mock the AnsibleModule class so that we can instantiate the collector class
    # without the need for any other external dependencies.
    from ansible.module_utils._text import to_native
    class AnsibleModuleMock:
        def __init__(self):
            self.check_mode = False
            self.debug = False
            self.params = { 'gather_timeout': 10 }

        def get_bin_path(self, executable):
            return executable


# Generated at 2022-06-23 01:43:32.078087
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()
    assert s.name == 'service_mgr'

# Generated at 2022-06-23 01:43:37.685472
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector.name == 'service_mgr'
    assert service_mgr_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:43:47.995499
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import platform
    import sys

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector


    class TestCollector(BaseFactCollector):
        _fact_ids = ['test_fact']
        def collect(self, module=None, collected_facts=None):
            return {'test_fact': "Test value"}

    collected_facts = {}
    Collector.add_collector(TestCollector())

    # initialize empty module
    module = MockModule()
    module.params = {}
    module.exit_json = Mock()
    module.fail_json = Mock()

    # mock module.run_commands which is used in test_collect
    mock_run_commands = Mock(return_value=(0, "", ""))

# Generated at 2022-06-23 01:43:56.424048
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import os

    class MockModule(object):
        class MockOsPath(object):
            def exists(self, x):
                mock_paths = ['/run/systemd/system/', '/dev/.run/systemd/', '/dev/.systemd/']
                return x in mock_paths
            def islink(self, x):
                mock_paths = ['/sbin/init']
                return x in mock_paths
            def basename(self, x):
                return 'systemd'
        class MockOs(object):
            path = MockOsPath()
            def readlink(self, x):
                return 'systemd'
        def get_bin_path(self, bin):
            mock_paths = ['systemctl']
            return bin in mock_paths

# Generated at 2022-06-23 01:44:03.779753
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    # Initialize class
    service_mgr_collector = ServiceMgrFactCollector()

    # Create a mock module
    class MockModule(object):

        def get_bin_path(self, path):
            return '/usr/bin/systemctl'

    # Initialize mock module
    module = MockModule()

    # Test is_systemd_managed_offline method when /sbin/init is a symlink to systemd
    os.symlink('/lib/systemd/systemd', '/sbin/init')
    if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
        assert service_mgr_collector.is_systemd_managed_offline(module) == True

    # Test is_systemd

# Generated at 2022-06-23 01:44:14.070735
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.utils.display import Display
    from ansible.module_utils.facts.collector import BaseFactCollector

    s = ServiceMgrFactCollector()
    s.display = Display()

    class FakeModule(object):
        def get_bin_path(self, thing, opt_dirs=[]):
            if thing == 'systemctl':
                return '/bin/systemctl'

    f = FakeModule()

    if os.path.exists('/run/systemd/system/'):
        assert s.is_systemd_managed(f)
    else:
        assert s.is_systemd_managed(f) == False


# Generated at 2022-06-23 01:44:19.679767
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collecter = ServiceMgrFactCollector()
    module = type('', (), {})()
    os.symlink('systemd', '/sbin/init')

    assert collecter.is_systemd_managed_offline(module) == True
    os.remove('/sbin/init')

# Generated at 2022-06-23 01:44:27.382215
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr
    class module:
        def get_bin_path(self, arg):
            if arg == 'systemctl':
                return '/sbin/systemctl'

    # Positive tests
    # Systemd managing init
    module.run_command = lambda arg: (0, '/run/systemd/system/\n/dev/.run/systemd/\n/dev/.systemd/', '')
    assert ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed(module) is True

    # Negative test
    # Systemd not managing init
    module.run_command = lambda arg: (0, '', '')
    assert ansible.module_utils.facts.system.service_mgr.ServiceMgr

# Generated at 2022-06-23 01:44:35.279307
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class module:
        # By default, fall back on 'systemctl'
        def get_bin_path(self, binary):
            return binary

    class os:
        @staticmethod
        def readlink(path):
            return '/sbin/init'

    class os_path:
        @staticmethod
        def islink(path):
            return True

    ServiceMgrFactCollector.is_systemd_managed_offline(module)
    module.get_bin_path = lambda x: None
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

# Generated at 2022-06-23 01:44:44.080560
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    '''
    Test that ServiceMgrFactCollector.is_systemd_managed() detects the
    presence of systemd correctly.
    '''
    class TestModule:
        def get_bin_path(self, arg, *args, **kwargs):
            if arg == 'systemctl':
                return '/bin/systemctl'
            return None


# Generated at 2022-06-23 01:44:47.750066
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False

# Generated at 2022-06-23 01:44:50.986628
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    module = type('FakeModule', (object,), dict(run_command=lambda *a, **kw: (0, 'COMMAND', None)))

    obj = ServiceMgrFactCollector()
    obj.collect(module=module)

# Generated at 2022-06-23 01:45:02.350216
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    import tempfile
    import os
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a mock module object
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Change to temporary directory
    orig_dir = os.getcwd()
    os.chdir(tmpdir)

    # Mock the method to return the path to the temporary directory
    module.get_bin_path = lambda *args, **kwargs: tmpdir

    # Create a symbolic link to systemctl
    os.symlink('systemctl', os.path.join(tmpdir, 'systemctl'))

    # Create a symbolic

# Generated at 2022-06-23 01:45:06.582902
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = mock.MagicMock()
    module.get_bin_path.return_value = '/usr/bin/systemctl'
    assert ServiceMgrFactCollector.is_systemd_managed(module)
    module.get_bin_path.return_value = None
    assert not ServiceMgrFactCollector.is_systemd_managed(module)


# Generated at 2022-06-23 01:45:16.007455
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector as t_collector

    m = t_collector.ModuleCollector()
    t_collector.register_collectors(m)
    service_mgr_object = m.collectors['service_mgr']
    # if /sbin/init is a symlink to systemd, then set the variable is_systemd_managed_offline to true
    if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
        t_is_systemd_managed_offline = True
    else:
        t_is_systemd_managed_offline = False
    assert service_mgr_object.is_systemd_managed_off

# Generated at 2022-06-23 01:45:21.245306
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    class MockModule:
        def get_bin_path(self, arg):
            return '/usr/bin/'+ arg

        def run_command(self, arg, use_unsafe_shell=True):
            return 0, 'ps -p 1 -o comm|tail -n 1', None

    assert ServiceMgrFactCollector.collect(module=MockModule())

# Generated at 2022-06-23 01:45:24.731317
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    collector = ServiceMgrFactCollector()
    assert collector.name == 'service_mgr'
    assert collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:45:36.273436
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """
    Test service management detection on a system managed by systemd.
    """
    def get_bin_path(bin_name):
        """
        Mock of module.get_bin_path which should always return a value.
        """
        return "/bin/%s" % (bin_name)

    def exists(path):
        """
        Mock of os.path.exists which should return True for paths defined by the tests.
        """
        return path in ['/run/systemd/system/', '/dev/.run/systemd/', '/dev/.systemd/']

    class MockModule:
        def __init__(self):
            self.run_command = run_command

        def get_bin_path(self, bin_name):
            return get_bin_path(bin_name)


# Generated at 2022-06-23 01:45:39.613949
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector.collect()

# Generated at 2022-06-23 01:45:49.695457
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collectors
    import mock

    def test_get_file_content(path):
        if path == '/sbin/init':
            return 'systemd'
        return None
    mock_module = mock.MagicMock()
    setattr(mock_module, 'get_file_content',test_get_file_content)
    assert collectors.ServiceMgrFactCollector.is_systemd_managed_offline(mock_module)

# Generated at 2022-06-23 01:46:02.707921
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils

    class FakeModule():
        _module = None

        def __init__(self):
            return

        def get_bin_path(self, path, opt_dirs=[]):
            return None

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, None, None

    class FakeCollectedFacts():
        def __init__(self):
            self.data = {
                'ansible_system': 'Darwin',
                'ansible_distribution': 'MacOSX',
            }
            return

    module = FakeModule()
    collected_facts = Fake

# Generated at 2022-06-23 01:46:03.943522
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    a = ServiceMgrFactCollector()
    assert a.name == 'service_mgr'
    assert a.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-23 01:46:07.596260
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    facts_dict = ServiceMgrFactCollector.collect(None, {'ansible_distribution': 'OpenWrt'})
    assert facts_dict['service_mgr'] == 'openwrt_init'

# Generated at 2022-06-23 01:46:09.495782
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    facts_dict = ServiceMgrFactCollector().collect()
    assert 'service_mgr' in facts_dict

# Generated at 2022-06-23 01:46:12.108586
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    generator = ServiceMgrFactCollector()
    assert generator.is_systemd_managed_offline(None) == False
    assert generator.is_systemd_managed(None) == False

# Generated at 2022-06-23 01:46:15.423453
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_collector = ServiceMgrFactCollector()
    # Assert we get back the name 'service_mgr' on property `name`
    assert service_mgr_collector.name == "service_mgr"

# Generated at 2022-06-23 01:46:21.473354
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector

    collector = ServiceMgrFactCollector()
    mock_module = BaseFactCollector()
        
    mock_module.get_bin_path = lambda x: "/sbin/systemctl"
    os.path.islink = lambda path: True
    os.readlink = lambda path: '/usr/lib/systemd/systemd'

    assert collector.is_systemd_managed_offline(mock_module) == True

# Generated at 2022-06-23 01:46:33.160955
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    '''
    Unit test for method is_systemd_managed of class ServiceMgrFactCollector
    '''
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.basic import AnsibleModule

    ansible_module = AnsibleModule(argument_spec=dict())
    ansible_module.run_command = lambda *args, **kwargs: (0, '/bin/systemctl(systemctl)', '')
    ansible_module.get_bin_path = lambda *args, **kwargs: '/bin/systemctl'
    ansible_module.path = os.environ['PATH'].split(os.pathsep)
    ansible_module._shell_builtins = {}

    # Test scenario 1. None of the canaries exist.
   

# Generated at 2022-06-23 01:46:43.156560
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    def mocked_module_runner(module_name, *args, **kwargs):
        if 'run_command' == module_name:
            return 0, 'systemd\n', ''
        elif 'get_bin_path' == module_name:
            return True

    def mocked_is_systemd_managed(module):
        return True

    def mocked_is_systemd_managed_offline(module):
        return True

    facts_collector = FactsCollector()

    ServiceMgrFactCollector.is_systemd_managed = mocked_is_systemd_managed
    ServiceMgrFactCollector.is_systemd_managed_offline = mocked_is_systemd_managed_offline

# Generated at 2022-06-23 01:46:50.443018
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class TestModule:
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    collector = ServiceMgrFactCollector()

    # Test with a real case
    module = TestModule()
    assert(collector.is_systemd_managed_offline(module=module) == True)

    # Test with a fake case
    module = TestModule()
    assert(collector.is_systemd_managed_offline(module=None) == False)

# Generated at 2022-06-23 01:47:00.589288
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    import platform
    import mock

    def mock_get_bin_path(*args, **kwargs):
        return '/bin/systemctl'

    def mock_exists(path):
        if path == '/run/systemd/system/':
            return True
        else:
            return False

    platform_system = platform.system
    platform.system = mock.Mock(return_value="Linux")

    mock.patch.object(BaseFactCollector, 'get_bin_path', mock_get_bin_path).start()
    mock.patch('os.path.exists', mock_exists).start()

    assert ServiceMgrFactCollector

# Generated at 2022-06-23 01:47:07.634900
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:47:10.412824
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'
    assert obj.required_facts == set(['platform', 'distribution'])
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:47:12.901780
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    facts = ServiceMgrFactCollector()
    assert facts.is_systemd_managed() == True


# Generated at 2022-06-23 01:47:23.144155
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_module = MockModule()
    test_module.exit_json = Mock(return_value=None)
    test_module.fail_json = Mock(return_value=None)
    test_collector = ServiceMgrFactCollector()
    test_fake_data = {'ansible_system': 'Linux'}

    # test will return '/sbin/init' as the service_mgr
    test_module.run_command = Mock(
        return_value=(0, "/sbin/init", None)
    )
    test_module.get_bin_path = Mock(
        return_value=None
    )
    test_module.os_path_exists = Mock(
        return_value=False
    )

# Generated at 2022-06-23 01:47:25.475768
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    sm = ServiceMgrFactCollector()
    # Asserting initialized variables
    assert sm.name == 'service_mgr'
    assert sm.required_facts == set(['platform', 'distribution'])
    assert sm._fact_ids == set()

# Generated at 2022-06-23 01:47:37.055031
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class ModuleMock(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    module_mock = ModuleMock()

    def os_path_islink(file_path):
        return file_path == '/sbin/init'

    def os_readlink(file_path):
        return 'systemd'

    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed_offline(module_mock) is False

    os.path.islink = os_path_islink
    service_mgr_fact_collector = ServiceMgrFactCollector()

# Generated at 2022-06-23 01:47:46.905017
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    try:
        import ansible.module_utils.facts.fact_collector
        import ansible.module_utils.facts.system_platform
        import ansible.module_utils.basic
        import ansible.module_utils.facts.utils
        import ansible.module_utils.facts.collector
        import ansible.module_utils.facts
    except ImportError as e:
        print('skipping tests, missing imports: %s' % e)

    Collector = ansible.module_utils.facts.fact_collector.FactCollector
    Platform = ansible.module_utils.facts.system_platform.SystemPlatform
    AnsibleModule = ansible.module_utils.basic.AnsibleModule

# Generated at 2022-06-23 01:47:54.099808
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    class FakeModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path
        def get_bin_path(self, bin_path):
            if os.path.exists(self.bin_path):
                return self.bin_path
            else:
                return None

    if not os.path.exists('/tmp/test_ServiceMgrFactCollector_is_systemd_managed'):
        os.makedirs('/tmp/test_ServiceMgrFactCollector_is_systemd_managed')

    # systemctl present
    fake_module = FakeModule('/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(fake_module) == False

    # systemctl present, /run/systemd/system/ present
    fake

# Generated at 2022-06-23 01:48:06.240141
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockAnsibleModule()
    # check that returns True if init is a link to system
    module.module_utils.module_facts_global_facts['paths'] = ['/sbin/init']
    module.module_utils.module_facts_global_facts['path_links'] = {'/sbin/init': '/lib/systemd/systemd'}
    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector.is_systemd_managed_offline(module)
    # check that returns False if init is not a link
    module.module_utils.module_facts_global_facts['paths'] = ['/sbin/init']
    module.module_utils.module_facts_global_facts['path_links'] = {}
    assert not service_mgr_

# Generated at 2022-06-23 01:48:16.687366
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class DummyModule(object):
        def __init__(self, *args, **kwargs):
            self.run_command_result = 0, '', ''

        def get_bin_path(self, *args, **kwargs):
            return None

        def run_command(self, *args, **kwargs):
            return self.run_command_result

        def fail_json(self, *args, **kwargs):
            raise Exception(args, kwargs)

        def exit_json(self, *args, **kwargs):
            raise Exception(args, kwargs)


# Generated at 2022-06-23 01:48:25.396013
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    class MockModule(object):
        def __init__(self,
                     # mock of ansible_distribution_version
                     ansible_distribution_version=None,

                     # mock of get_bin_path
                     get_bin_path_result=None,

                     # mock of os.path.exists
                     os_path_exists_results=[],

                     # mock of os.path.islink
                     os_path_islink_results=[]
                     ):
            self.ansible_distribution_version = ansible_distribution_version

            self.get_bin_path_result = get_bin_path_result
            self.def_get_bin_path_args = None
            self.def_get_bin_path_kwargs = None

            self.os_path_exists_results = os_path_exists

# Generated at 2022-06-23 01:48:32.804813
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    class MockModule:
        pass

    mock_module = MockModule()
    mock_module.run_command = lambda *args, **kwargs: (0, 'init', '')
    mock_module.get_bin_path = lambda *args, **kwargs: None

    class MockFacts:
        pass

    mock_facts = MockFacts()
    mock_facts.ansible_distribution = None
    mock_facts.ansible_system = None
    mock_facts.platform = None

    result = ServiceMgrFactCollector().collect(module=mock_module, collected_facts=mock_facts)
    assert result['service_mgr'] == 'sysvinit'

# Generated at 2022-06-23 01:48:35.596861
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:48:45.613780
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    This is a functional test for ServiceMgrFactCollector.collect method to check
    the output of the method is in expected format

    Following is the sample data generated from the method

    {
        'service_mgr': 'smf'
    }
    """

    # Create a test ServiceMgrFactCollector object
    smfc = ServiceMgrFactCollector()

    # set the ansible_facts['ansible_system'] with 'SunOS' value
    ansible_facts = {
        'ansible_system':'SunOS'
    }
    service_mgr_facts = smfc.collect(module=None, collected_facts=ansible_facts)

    # assert service_mgr_facts['service_mgr'] value is 'smf'

# Generated at 2022-06-23 01:48:46.710619
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()

# Generated at 2022-06-23 01:48:52.318954
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    collected_facts = {
        "ansible_distribution": "MacOSX",
        "ansible_system": "Darwin",
        "ansible_system_vendor": "Apple",
        "ansible_virtualization_type": "xen",
    }
    module = set()
    ServiceMgrFactCollector._collect(module, collected_facts)
    assert collected_facts['service_mgr'] == 'launchd'


# Generated at 2022-06-23 01:49:01.135347
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:49:14.905244
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    from ansible.module_utils.facts.collector import ModuleDataCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector

    mdc = ModuleDataCollector()
    smfc = ServiceMgrFactCollector(mdc)
    sfc = SystemFactCollector(mdc)

    assert smfc.is_systemd_managed(sfc) is False

    sfc.module.run_command = lambda x: (0, "1", "")
    sfc.module.get_bin_path = lambda x: "/bin/systemctl"

    assert smfc.is_systemd_managed(sfc) is True


# Generated at 2022-06-23 01:49:25.607599
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import shutil
    import tempfile

    import ansible.module_utils.facts.collector

    # use a temporary directory as the test environment
    temp_dir = tempfile.mkdtemp()
    temp_sbin = os.path.join(temp_dir, 'sbin')
    os.makedirs(temp_sbin)

    # create a mock module
    class MockModule:
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'

    test_module = MockModule()

    # test: init -> systemd
    shutil.copy('/sbin/init', os.path.join(temp_sbin, 'init'))
    os.symlink('systemd', os.path.join(temp_sbin, 'init'))

# Generated at 2022-06-23 01:49:35.827518
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    test_subject = ServiceMgrFactCollector()

    class Module:
        @staticmethod
        def get_bin_path(name):
            if name == 'systemctl':
                return '/usr/bin/systemctl'
            return None

    def my_test_os_path_islink(path):
            if path == '/sbin/init':
                return True
            return False

    def my_test_os_readlink(path):
        return '/lib/systemd/systemd'

    module = Module()
    test_subject.os.path.islink = my_test_os_path_islink
    test_subject.os.path.realpath = my_test_os_readlink

    result = test_subject.is_systemd_managed_offline(module)

    assert result == True


# Generated at 2022-06-23 01:49:42.889866
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import imp
    import tempfile
    import shutil
    import os
    import re

    # Create directory for mock binary
    tempdir = tempfile.mkdtemp()

    # Mock platform.system()
    original_platform_system = platform.system
    platform.system = lambda: 'Linux'

    # Mock module_utils.basic.AnsibleModule.get_bin_path()
    class FakeModule:
        def get_bin_path(self, name):
            return os.path.join(tempdir, name)
    module = FakeModule()

    # Mock module_utils.basic.AnsibleModule.run_command()
    class FakePopen:
        def __init__(self, cmd, _rc=0, _stdout='', _stderr=''):
            self.cmd = cmd

# Generated at 2022-06-23 01:49:54.245747
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.platform import PlatformFactCollector
    from ansible.module_utils.facts.collectors.distribution import DistributionFactCollector

    module = FakeModule()
    collected_facts = {'platform': PlatformFactCollector(module).collect(),
                       'distribution': DistributionFactCollector(module).collect()}

    if collected_facts['platform'] == 'Linux':
        def run_command_result(command):
            if command == 'systemctl':
                return 0, '/bin/systemctl', ''
            elif command == 'which systemd':
                return 0, '/bin/systemd', ''
            elif command.startswith('systemctl'):
                return 0, '', ''