

# Generated at 2022-06-23 01:40:03.957092
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Setup test
    test_dict = {}
    test_dict['ansible_facts'] = {}
    test_dict['ansible_facts']['ansible_distribution'] = 'Red Hat Enterprise Linux Server'
    test_dict['ansible_facts']['ansible_system'] = 'Linux'

    # Module test
    ServiceMgrFactCollector.collect(test_dict)

    assert test_dict['ansible_facts']['service_mgr'] == 'systemd'

# Generated at 2022-06-23 01:40:12.883004
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = AnsibleModuleMock()
    collector = ServiceMgrFactCollector()

    module.get_bin_path.return_value = True
    for canary in ["/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"]:
        os.path.exists.return_value = True
        assert(collector.is_systemd_managed(module))
        os.path.exists.return_value = False

    module.get_bin_path.return_value = False
    assert(collector.is_systemd_managed(module) == False)


# Generated at 2022-06-23 01:40:25.127675
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import Collector

    def module_mock():
        def mock_get_bin_path(path):
            if path == 'systemctl':
                return path
            return None

        class ModuleMock:
            def __init__(self):
                self.get_bin_path = mock_get_bin_path

        return ModuleMock()

    def os_path_exists_fn(path):
        if path == '/run/systemd/system/':
            return True
        return False

    # Mock module
    module = module_mock()

    # Mock os.path.exists
    Collector.backup_os_path_exists = os.path.exists
    os.path.exists = os_path_exists_fn

    # os.path.exists returns True for

# Generated at 2022-06-23 01:40:35.463437
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.system.service import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service import is_systemd_managed

    import mock

    module = mock.Mock()
    module.get_bin_path = mock.Mock()

    # return value of get_bin_path for systemctl
    get_bin_path_result_systemctl = "/path/to/systemctl"

    # return value of get_bin_path for init
    get_bin_path_result_init = "/path/to/init"

    # case 1
    module.get_bin_path.return_value = get_bin_path_result_systemctl

    # with side effect
    module.run_command = mock.Mock()
    module.run_command.side_effect = Exception

# Generated at 2022-06-23 01:40:36.978400
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class_under_test = ServiceMgrFactCollector()
    class_under_test.collect({})

# Generated at 2022-06-23 01:40:46.108287
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda *_: (0, '', ''),
        'get_bin_path': lambda *_: '',
        'params': {},
        'check_mode': False,
        'ansible_facts': {
            'ansible_system': 'Linux',
            'ansible_distribution': 'Ubuntu'
        }
    })()

    mock_collector = type('Collector', (object,), {'collect': lambda *_: {}})()

    collected_facts = mock_collector.collect(module=mock_module)

    svc_mgr_collector = ServiceMgrFactCollector()
    collected_facts = svc_mgr_collector.collect(collected_facts=collected_facts)

# Generated at 2022-06-23 01:40:55.602794
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    fake_module = type('obj', (object,), {'get_bin_path': lambda self, path: path, 'run_command': lambda self, cmd, **kwargs: (0, 'sbin/init -> /root/systemd', '')})()
    assert ServiceMgrFactCollector().is_systemd_managed_offline(module=fake_module) == True

    fake_module = type('obj', (object,), {'get_bin_path': lambda self, path: path, 'run_command': lambda self, cmd, **kwargs: (0, 'sbin/init -> /root/path/systemd', '')})()
    assert ServiceMgrFactCollector().is_systemd_managed_offline(module=fake_module) == False

# Generated at 2022-06-23 01:40:59.095804
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'
    assert len(obj.required_facts) == 2
    assert obj.required_facts[0] == 'platform'
    assert obj.required_facts[1] == 'distribution'

# Generated at 2022-06-23 01:41:06.492936
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector._fact_ids == set()
    assert service_mgr_fact_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:41:20.258054
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # The test expects 'systemctl' to be absent in PATH.
    # So, create a fake module with a fake PATH.
    class TestModule:
        def get_bin_path(self, cmd):
            return None
    # NOTE: TestModule.run_command is not defined to simulate a missing
    # command.

    # The following test cases are copied from the systemd tests.
    # systemd/tests/tmpfile.c

# Generated at 2022-06-23 01:41:30.269322
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # create a stub class and a mock module to get a handle on the method
    class StubClass(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'
    class MockModule:
        def __init__(self):
            self.class_stub = StubClass()

    test_module = MockModule()
    # test value of is_systemd_managed with a fake file that exists
    test_is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed(test_module)
    assert test_is_systemd_managed is True
    # test value of is_systemd_managed with a fake file that doesn't exist
    test_is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed(test_module)
    assert test_is_

# Generated at 2022-06-23 01:41:33.578414
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    collector = ServiceMgrFactCollector()
    facts_dict = collector.collect()
    assert type(facts_dict) is dict, 'test_ServiceMgrFactCollector_collect assert type(facts_dict) is dict'


# Generated at 2022-06-23 01:41:43.375132
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    testcases = [
        {
            'init': None,
            'expected': False,
            'comment': "No init"
        },
        {
            'init': 'systemd',
            'expected': True,
            'comment': "Init is systemd"
        },
        {
            'init': 'sysvinit',
            'expected': False,
            'comment': "Init is sysvinit"
        },
        {
            'init': 'launchd',
            'expected': False,
            'comment': "Init is launchd"
        },
        {
            'init': 'unknown',
            'expected': False,
            'comment': "Init is unknown"
        },
    ]

# Generated at 2022-06-23 01:41:54.984824
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # arrange
    fact = ServiceMgrFactCollector()

    # run test cases

# Generated at 2022-06-23 01:42:04.283636
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    fake_platform_distro = 'SunOS'
    fake_ansible_system = 'SunOS'

    fake_module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    fake_module.run_command = lambda command, use_unsafe_shell: (0, '', '')

    collected_facts = {
        'platform_distro': fake_platform_distro,
        'ansible_system': fake_ansible_system,
        'ansible_facts': {}
    }

# Generated at 2022-06-23 01:42:15.978306
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    test_module = AnsibleModule(argument_spec={}, supports_check_mode = False)

    def os_readlink(path):
        if path == '/sbin/init':
            return 'systemd'
        raise OSError()

    test_module.os_path_islink = os.path.islink
    test_module.os_path_exists = os.path.exists

    test_module.get_bin_path = lambda x: True
    os.path.islink = lambda x: True
    os.path.exists = lambda x: True
    os.readlink = lambda x: 'systemd'

    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector.is_systemd_managed_offline(test_module) == True

    #

# Generated at 2022-06-23 01:42:17.529495
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False

# Generated at 2022-06-23 01:42:24.758729
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Required facts must be present
    required_facts = {
        'platform': None,
        'distribution': None,
    }

    # Required module must be present
    module = {}

    # Create the object
    collector = ServiceMgrFactCollector()
    # Collect facts
    collected_facts = collector.collect(module=module, collected_facts=required_facts)

    # Validate the facts and assert the data type of the value
    assert isinstance(collected_facts['service_mgr'], str)


# Generated at 2022-06-23 01:42:35.485552
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes

    c = Collector()
    m = c.collect_fact(to_bytes(u'service_mgr'))['service_mgr']

    test_config = dict(
        run_command_environ_update={'PATH': '/usr/bin'}
    )

    # Set systemctl to be available
    test_config['FILE_CONTENT'] = '/proc/1/comm'
    test_config['FILE_CONTENTS'] = '/proc/1/comm'
    test_config['FILE_EXISTS'] = '/proc/1/comm'
    m._module.params = test_config

# Generated at 2022-06-23 01:42:44.464560
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collections import FacterCollector
    from ansible.module_utils.facts.collections import NetworkCollector
    from ansible.module_utils.facts.collections import OsCollector
    from ansible.module_utils.facts.collections import VirtualizationCollector

    from ansible.module_utils.basic import AnsibleModule

    def mock_get_file_content(path):
        if path == '/proc/1/comm':
            return 'systemd'
        else:
            return None

    class MockModule:
        def __init__(self):
            self.get_bin_path = lambda bin_path: '/usr/bin/' + bin_path

# Generated at 2022-06-23 01:42:46.514027
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    mgr = ServiceMgrFactCollector()
    assert mgr.name == 'service_mgr'

# Generated at 2022-06-23 01:42:47.848324
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector().name == 'service_mgr'


# Generated at 2022-06-23 01:42:59.498094
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    # Stub BaseFactCollector class
    class StubBaseFactCollector(BaseFactCollector):
        name = 'fake_name'
        _fact_ids = set()
        required_facts = set()
        _depends = set()

        def collect(self, module=None, collected_facts=None):
            pass

    # Generate fake environment to emulate module instance
    module = type(
        'FakeModule',
        (),
        {
            'get_bin_path': lambda self, *args, **kwargs: None,
            'run_command': lambda self, *args, **kwargs: None,
        }
    )()
   

# Generated at 2022-06-23 01:43:10.219905
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a test Module
    class MockModule(object):
        def __init__(self, is_systemd_managed, is_systemd_managed_offline):
            self.is_systemd_managed = is_systemd_managed
            self.is_systemd_managed_offline = is_systemd_managed_offline

        def get_bin_path(self, path):
            return path


    # Collect facts without any mocking
    collector_no_mocking = ServiceMgrFactCollector()
    collected_facts_no_mocking = collector_no_mocking.collect(MockModule(False, False))
    assert collected_facts_no_mocking['service_mgr'] == 'sysvinit'

    # Collect facts with service manager is_systemd_managed() mocked
    collector_with_mock_is

# Generated at 2022-06-23 01:43:19.478506
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a mocked module
    module = type('MockedModule', (object,), {
        'get_bin_path': classmethod(lambda cls, arg: arg)
    })

    fact_collector = ServiceMgrFactCollector()

    # Case: systemd is the boot init system
    assert fact_collector.is_systemd_managed(module=module)

    # Case: systemd is not the boot init system
    mock_os = type('MockOs', (object,), {
        'path': type('MockPath', (object,), {
            'exists': classmethod(lambda cls, arg: False)
        })
    })
    fact_collector.os = mock_os
    assert not fact_collector.is_systemd_managed(module=module)


# Generated at 2022-06-23 01:43:21.231702
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector()
    collector.is_systemd_managed_offline


# Generated at 2022-06-23 01:43:30.985513
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule():
        def get_bin_path(self, cmd):
            return '/bin/systemctl'

        def run_command(self, args, use_unsafe_shell=False):
            return (0, None, None)

    class MockCollector(ServiceMgrFactCollector):
        pass

    # mock os.path.exists(canary) to return values for testing different cases
    exists_run_systemd_system = False
    def mock_os_path_exists(canary):
        nonlocal exists_run_systemd_system
        if canary == '/run/systemd/system/':
            return exists_run_systemd_system
        elif canary == '/dev/.run/systemd/':
            return True
        elif canary == '/dev/.systemd/':
            return True



# Generated at 2022-06-23 01:43:41.408569
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import DummyModule
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    os.environ['PATH'] = '/bin:/usr/bin'

    # case 1: test for /run/systemd/system/
    os.environ['PATH'] = '/bin:/usr/bin'

    if os.path.exists('/run/systemd/system'):
        os.rmdir('/run/systemd/system')

    os.mkdir('/run/systemd/system')

    module = DummyModule()
    module.run_command = lambda x: (0, '', '')

    assert ServiceMgrFactCollector.is_systemd_managed(module)


# Generated at 2022-06-23 01:43:52.315446
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    runit_comm = b'svscan'
    systemd_comm = b'systemd'

    class MockModule(object):
        def __init__(self, runit_comm=None, systemd_comm=None):
            self.runit_comm = runit_comm
            self.systemd_comm = systemd_comm
            self.is_systemd_managed_called_with = None

        def get_bin_path(self, binary, required=False, opt_dirs=[]):
            if binary == 'systemctl':
                return 'systemctl'
            if binary == 'systemd':
                return 'systemd' if self.systemd_comm else None
            if binary == 'runit':
                return 'runit' if self.runit_comm else None
            return None


# Generated at 2022-06-23 01:43:59.540196
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    import platform
    import sys

    # Mocking module instance
    class MockModuleAnsible:

        def __init__(self):
            self.run_command_environ_update = mock.MagicMock()
            self.get_bin_path = mock.MagicMock(return_value=True)

    class MockModuleAnsibleSystem:
        def __init__(self):
            self.run_command_environ_update = mock.MagicMock()
            self.get_bin_path = mock.MagicMock(return_value=False)

        def get_bin_path(self):
            return False

    class MockModuleAnsiblePathExists:

        def __init__(self):

            self.run_command_environ_update = mock.MagicMock()
            self.get_bin

# Generated at 2022-06-23 01:44:07.751908
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import Collector

    # Mock the module object
    module = ModuleFacts()
    module_facts = Collector()

    # Mock the module methods
    def mock_get_bin_path(arg):
        if arg == 'systemctl':
            return '/usr/bin/systemctl'
        else:
            return None

    module.get_bin_path = mock_get_bin_path

    # Mock os.path.islink()
    original_islink = os.path.islink
    os.path.islink = lambda path: True

    # Mock os.readlink()
    original_readlink = os.readlink
    os.readlink = lambda path: 'systemd'

    # Mock the collect() method of module

# Generated at 2022-06-23 01:44:18.302052
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockModule()
    module.SYSTEMCTL_PATH = '/usr/bin/systemctl'
    module.SYSTEMD_PATH = '/usr/bin/systemd'
    module.get_bin_path.side_effect = ['/usr/bin/systemctl', '/usr/bin/systemd']
    module.run_command.return_value = [0, 'sd_boot', '']
    module.os.path.exists.side_effect = [False, True, True]
    module.os.path.islink.side_effect = [True, False]
    module.os.readlink.return_value = 'systemd'

    service_mgr_fact_collector = ServiceMgrFactCollector()


# Generated at 2022-06-23 01:44:22.340503
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_facts_collector = ServiceMgrFactCollector()
    assert service_mgr_facts_collector.name == 'service_mgr'
    assert service_mgr_facts_collector._fact_ids == set()
    assert service_mgr_facts_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:44:33.592431
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    This is a test for the ServiceMgrFactCollector class.
    It ensures that fact 'service_mgr' is collected correctly
    """
    mgr = ServiceMgrFactCollector()

    def _run_command_side_effect(args, **kwargs):
        if args == "test -e /run/systemd/system/":
            return (0, '', '')
        elif args == "test -e /dev/.run/systemd/":
            return (1, '', '')
        elif args == "test -e /dev/.systemd/":
            return (0, '', '')

    module = MagicMock()
    module.get_bin_path.return_value = True
    module.run_command.side_effect = _run_command_side_effect

    # test when given

# Generated at 2022-06-23 01:44:38.711260
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_module = object()
    test_module.run_command = lambda *_: (0, None, None)
    test_module.get_bin_path = lambda *_: False

    test_collector = ServiceMgrFactCollector()
    test_collector.collect(module=test_module,
                           collected_facts={
                               'ansible_distribution': 'MacOSX',
                               'ansible_system': 'MacOSX',
                           })

# Generated at 2022-06-23 01:44:41.764011
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fact = ServiceMgrFactCollector()
    assert fact.name == 'service_mgr'
    assert len(fact._fact_ids) == 0
    assert len(fact.required_facts) == 2


# Generated at 2022-06-23 01:44:51.143638
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Test for is_systemd_managed
    module = MockModule()
    module.executable_exists = lambda path: path == 'systemctl'
    assert ServiceMgrFactCollector.is_systemd_managed(module)

    # Test for is_systemd_managed_offline
    module = MockModule()
    module.executable_exists = lambda path: path == 'systemctl'
    os.path.islink = lambda path: path == '/sbin/init'
    os.readlink = lambda path: 'systemd'
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test for collect method - exits early
    module = MockModule()
    collected_facts = {}
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_

# Generated at 2022-06-23 01:44:58.345530
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Test if ServiceMgrFactCollector exists
    assert 'ServiceMgrFactCollector' in globals().keys()

    # Test if ServiceMgrFactCollector is a class
    assert isinstance(ServiceMgrFactCollector, type)

    # Test if ServiceMgrFactCollector is a subclass of BaseFactCollector
    assert issubclass(ServiceMgrFactCollector, BaseFactCollector)


# Unit tests for the 'is_systemd_managed' method of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:45:09.256909
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # pylint: disable=import-error
    from ansible.module_utils.basic import AnsibleModule
    # pylint: enable=import-error

    # Required for mocking of os.readlink to work
    # pylint: disable=no-name-in-module,import-error
    from mock import patch
    # pylint: enable=no-name-in-module,import-error
    from ansible.module_utils.facts.collector import Collector

    collector = Collector()
    collector.collect_platform_facts()
    collector.collect_distro_facts()

    module = AnsibleModule(
        argument_spec={},
    )


# Generated at 2022-06-23 01:45:09.869221
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-23 01:45:14.459045
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """
    Method is_systemd_managed return correct value
    """
    with patch('ansible.module_utils.facts.collector.ServiceMgrFactCollector.is_systemd_managed'):
        testcase = ServiceMgrFactCollector()
        assert testcase.is_systemd_managed('systemctl') == 'systemd'


# Generated at 2022-06-23 01:45:26.058852
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test for mock module
    class TestModule:
        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/usr/bin/systemctl'
            else:
                return None

    # Test method is_systemd_managed
    def test_method():
        # Test with /run/systemd/system
        module = TestModule()
        ServiceMgrFactCollector.is_systemd_managed(module=module)
        # Test with /dev/.systemd
        os.makedirs('/dev/.systemd')
        module = TestModule()
        ServiceMgrFactCollector.is_systemd_managed(module=module)
        # Test with /dev/.run/systemd
        os.makedirs('/dev/.run/systemd')
        module = TestModule()
        Service

# Generated at 2022-06-23 01:45:35.694311
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    This test is only intended to be run on Linux with systemd installed,
    and will be skipped on other OSs
    """
    class TestModule(object):
        def __init__(self, systemd_present=True):
            self.systemd_present = systemd_present

        def get_bin_path(self, cmd):
            if cmd == 'systemctl' and self.systemd_present:
                return '/bin/systemctl'
            return None

        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, '', ''

    # test systemd present

# Generated at 2022-06-23 01:45:41.746653
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:45:52.348763
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule():
        def __init__(self):
            self.params = { 'gather_subset' : ['service_mgr'] }

        def run_command(self, command, use_unsafe_shell=False):
            return 1, '', ''

        def get_bin_path(self, executable):
            return None

    import os
    import platform
    import shutil

    # Place to store test files
    annotations = '/tmp/ansible_test_ServiceMgrFactCollector_collect'

    # Cleanup existing test files
    if os.path.exists(annotations):
        shutil.rmtree(annotations)

    os.mkdir(annotations)

    # Create a symlink from /sbin/init to systemd

# Generated at 2022-06-23 01:45:58.123076
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import collector

    import pickle

    m = collector.BaseFactCollector({},{'system': 'Linux', 'distribution': 'RedHat'})

    asm = ServiceMgrFactCollector.is_systemd_managed_offline(m)

    assert(asm == False)

# Generated at 2022-06-23 01:46:06.578501
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = object
    module.get_bin_path = lambda x: 'systemctl' if x == 'systemctl' else None
    # systemd boot environment type 1 canaries
    canaries1 = [
        'systemctl --verify',
        'systemctl --system --full list-dependencies | grep -v "^$"',
        'systemctl --system --full list-dependencies | grep -v "^$" | grep -v "^multi-user.target$"',
        'systemctl'
    ]
    for cmd in canaries1:
        rc, out, err = module.run_command(cmd, use_unsafe_shell=True)
        assert ServiceMgrFactCollector.is_systemd_managed(module) == (rc == 0)
    # systemd boot environment type 2 canaries

# Generated at 2022-06-23 01:46:09.345051
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'
    assert obj._fact_ids is not None


# Generated at 2022-06-23 01:46:18.055123
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    mgr_fact_collector = ServiceMgrFactCollector()

    module = None
    collected_facts = {}
    assert mgr_fact_collector.collect(module=module, collected_facts=collected_facts) == {}

    module = MagicMock()
    module.get_bin_path.return_value = None
    collected_facts = {'ansible_distribution': 'OpenWrt'}
    assert mgr_fact_collector.collect(module=module, collected_facts=collected_facts) == {"service_mgr": 'openwrt_init'}


# Generated at 2022-06-23 01:46:28.075443
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.parsers.service_mgr

    # Create instance of ServiceMgrFactCollector
    serviceMgrFactCollector = ansible.module_utils.facts.parsers.service_mgr.ServiceMgrFactCollector()

    # Override module.run_command to pass hardcoded value
    # to is_systemd_managed_offline
    class MockModule:
        def run_command(self, cmd, check_rc=False):
            return 0, '/sbin/init', ''

        def get_bin_path(self, cmd):
            return '/bin/false'

    class MockAnsibleModule:
        def __init__(self):
            self.params = {}
            self.fail = False

    # Call method is_systemd_managed_offline

# Generated at 2022-06-23 01:46:39.425566
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Mock out module
    class MockModule:
        @staticmethod
        def get_bin_path(cmd):
            return '/bin/' + cmd

    # Make sure that the systemd init system does not get detected if the
    # tools are not present
    module = MockModule()
    module.get_bin_path = lambda cmd: None
    assert not ServiceMgrFactCollector.is_systemd_managed(module)
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Mock out module
    class MockModule:
        @staticmethod
        def get_bin_path(cmd):
            return '/bin/' + cmd

# Generated at 2022-06-23 01:46:51.390880
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collectors.base import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class ModuleMock(object):
        @staticmethod
        def get_bin_path(program, required=False, opt_dirs=[]):
            return "fake_bin_path"

    class Mock(object):
        def __init__(self):
            self.out = "out"
            self.rc = 0

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}
            self.exit_json = Mock()


# Generated at 2022-06-23 01:47:01.557668
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    import mock

    # Mock module
    module = mock.MagicMock()

    # Mock module.get_bin_path
    module.get_bin_path.return_value = "/bin/systemctl"

    # Mock os.path.exists
    os_path_exists = mock.MagicMock()
    os_path_exists.return_value = True
    os.path.exists = os_path_exists

    # Mock os.path.islink
    os_path_islink = mock.MagicMock()
    os_path_islink.return_value = True
    os.path.islink = os_path_islink

    # Mock os.readlink
    os_readlink = mock.MagicMock()
    os_readlink.return_value = "systemd"
    os.readlink

# Generated at 2022-06-23 01:47:10.768130
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a mock module
    mocked_module = MockAnsibleModule()

    # Create a mock module base class
    mocked_module_base = MockAnsibleModuleBase(mocked_module)

    # Create a mock module utils
    mocked_module_utils = MockAnsibleModuleUtils(mocked_module_base)

    # Create a mock module class
    mocked_module_class = MockAnsibleModuleClass(mocked_module_utils)

    # Create a ServiceMgrFactCollector instance
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Call is_systemd_managed with mocked module class
    is_systemd_managed = service_mgr_fact_collector.is_systemd_managed(mocked_module_class)

    # Check if the method returned expected result
   

# Generated at 2022-06-23 01:47:21.777770
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # This test will ensure that the returned facts are the expected ones
    # given our test data, which is a snapshot of a particular service manager's
    # status

    # We need to mock some Ansible module arguments and facts
    module_mock = Mock(params={})
    # We also need some collected facts, mock them with a snapshot of the
    # status of our service manager.
    collected_facts = {
        'ansible_system': 'Linux',
        'ansible_distribution': 'Debian',
    }

    # The mocked version of the ServiceMgrFactCollector class will get the
    # status of our service manager, and then just return it.
    smfc_mock = Mock(spec_set=ServiceMgrFactCollector)

# Generated at 2022-06-23 01:47:33.294512
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Mock the module to return a static fact
    mock_module = "test.test_service_mgr.ServiceMgrFactCollector.is_systemd_managed "
    mock_module += "test.test_service_mgr.ServiceMgrFactCollector.is_systemd_managed_offline"

    ServiceMgrFactCollector.is_systemd_managed = lambda module: False
    ServiceMgrFactCollector.is_systemd_managed_offline = lambda module: False

    # No service_mgr detected, default to generic 'service'
    collected_facts = {}
    facts_dict = ServiceMgrFactCollector.collect(module=mock_module, collected_facts=collected_facts)
    assert facts_dict['service_mgr'] == 'service'

    # Check is_systemd_managed
    Service

# Generated at 2022-06-23 01:47:36.017082
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector.name == 'service_mgr'
    assert service_mgr_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:47:38.780126
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

# Generated at 2022-06-23 01:47:45.246626
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Unit test for method collect of class ServiceMgrFactCollector
    """
    test_module = {"ansible_distribution": "Linux"}

    test_instance = ServiceMgrFactCollector()

    # When
    test_result = test_instance.collect(module=test_module)

    # Then
    assert "service_mgr" in test_result

# Generated at 2022-06-23 01:47:58.741063
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.collector

    def get_bin_path(self, *args):
        return None

    def get_file_content(self, *args):
        return None

    def run_command(self, *args):
        return 0, '{}', None

    def is_systemd_managed(self, *args):
        return False

    def is_systemd_managed_offline(self, *args):
        return False

    collected_facts = {
        'ansible_distribution': 'OpenWrt',
        'ansible_system': 'Linux',
        'platform': 'Linux'
    }
    module = ansible.module_utils.facts.collector.BaseFactCollector._create_module()
    module.get_bin_path = get_bin_path.__get__

# Generated at 2022-06-23 01:48:10.964420
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def __init__(self):
            pass

        @staticmethod
        def get_bin_path(binary):
            if binary == 'systemctl':
                return binary

            return None

    class MockFilePath(object):
        def __init__(self, name, exists=False):
            self.name = name
            self.exists = exists

        def exists(self):
            return self.exists

        def islink(self):
            return self.name == '/sbin/init'

        def readlink(self):
            return self.name

    class MockOS(object):
        def __init__(self):
            self.path = MockFilePath('/run/systemd/system/')

        def path(self):
            return self.path


# Generated at 2022-06-23 01:48:18.626325
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCache
    cache = FactCache()
    cache.collector['platform'] = "linux"
    cache.collector['distribution'] = "openwrt"
    ServiceMgrFactCollector.collect(None, collected_facts=cache.collector)
    assert cache.collector['service_mgr'] == 'openwrt_init'

    cache = FactCache()
    cache.collector['platform'] = "darwin"
    cache.collector['distribution'] = "OpenWrt"
    ServiceMgrFactCollector.collect(None, collected_facts=cache.collector)
    assert cache.collector['service_mgr'] == 'service'

# Generated at 2022-06-23 01:48:20.355378
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed(None) is False


# Generated at 2022-06-23 01:48:32.047833
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    test_module = AnsibleModule(
        argument_spec=dict(
            executable_exists=dict(type='str', required=False),
            executable_find=dict(type='str', required=False),
        ),
        supports_check_mode=True
    )
    test_module.executable_exists = {'systemctl': 'fake_path_to_systemctl',
                                     '/sbin/init': 'fake_dir_does_not_exist',
                                     }
    test_module.executable_find = {'systemctl': 'fake_path_to_systemctl',
                                   '/sbin/init': 'fake_dir_does_not_exist',
                                   }

# Generated at 2022-06-23 01:48:34.240390
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert isinstance(smfc.collect(), dict)
    assert 'service_mgr' in smfc.collect()

# Generated at 2022-06-23 01:48:36.515484
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    # The constructor of the class ServiceMgrFactCollector
    # should always return an object of class ServiceMgrFactCollector
    assert (isinstance(ServiceMgrFactCollector(), ServiceMgrFactCollector))

# Generated at 2022-06-23 01:48:43.898831
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Input data relevant for the test
    #
    # System is running systemd
    # systemctl is available
    # /dev/.run/systemd exists
    systemctl = "/bin/systemctl"
    systemd = "/dev/.run/systemd"

    # Result expected
    expected_result = True

    # Initialize the test
    #
    # Mock the module
    module = MagicMock()
    module.get_bin_path.return_value = systemctl
    module.run_command.return_value = 0

    # Test the method
    #
    # Create a ServiceMgrFactCollector, call the method and compare the result.
    fact_collector = ServiceMgrFactCollector()
    is_systemd = fact_collector.is_systemd_managed(module)

# Generated at 2022-06-23 01:48:55.164554
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a new instance of class ServiceMgrFactCollector
    srv_mgr_fc = ServiceMgrFactCollector()
    # Create a simple module for argument module of method collect of class ServiceMgrFactCollector
    # class AnsibleModule(object):
    #     def __init__(self, argument_spec, bypass_checks=False, no_log=False,
    #                  check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
    #                  required_one_of=None, add_file_common_args=False, supports_check_mode=False,
    #                  required_if=None, required_by=None):
    #     def get_bin_path(self, arg, required=False, opt_dirs=[]):
    #         return None

# Generated at 2022-06-23 01:49:04.398531
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name):
            bin_path = None
            if name == 'systemctl':
                bin_path = "/usr/bin/systemctl"
            return bin_path

        def run_command(self, command, use_unsafe_shell=False):
            rc = 0
            out = ""
            err = ""
            if command == "ps -p 1 -o comm|tail -n 1":
                if self.params.get('service_mgr') == 'openwrt_init':
                    out = "procd\n"
                if self.params.get('service_mgr') == 'runit':
                    out = "runit-init\n"

# Generated at 2022-06-23 01:49:07.088206
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector._fact_ids == set()
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:49:10.347916
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Test with no module parameter
    x = ServiceMgrFactCollector()
    assert x


# Generated at 2022-06-23 01:49:17.859345
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Create an instance of ServiceMgrFactCollector
    serv_mgr_obj = ServiceMgrFactCollector()

    # Check the value of the 'name' attribute
    assert serv_mgr_obj.name == 'service_mgr'

    # Check the value of the '_fact_ids' attribute
    assert serv_mgr_obj._fact_ids == set()

    # Check the value of the 'required_facts' attribute
    assert serv_mgr_obj.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:49:27.710252
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """Mock a module and collect facts.
    Here, we mock 'systemctl' and '/sbin/init' file to test the
    is_systemd_managed_offline method.
    """
    # Create a mock module
    test_module = MagicMock()
    test_module.get_bin_path.return_value = 'systemctl'

    # Create an instance of the ServiceMgrFactCollector class
    smfc = ServiceMgrFactCollector()

    # Mock the os.path.islink module to check for
    # systemd as init system
    mock_os_path_islink = MagicMock()
    mock_os_path_islink.return_value = True
    mock_os_path_basename = MagicMock()
    mock_os_path_basename.return_value = 'systemd'



# Generated at 2022-06-23 01:49:33.071358
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    m = Mock()
    s = ServiceMgrFactCollector(dummy_module=m)
    m.get_bin_path.return_value = '/sbin/systemctl'
    os.path.islink.return_value = True
    os.readlink.return_value = 'systemd'
    assert s.is_systemd_managed_offline()


# Generated at 2022-06-23 01:49:44.784291
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys
    import os
    import copy
    import platform
    from mock import Mock, MagicMock, patch

    class MockModule(object):
        def __init__(self, params={}):
            self.params = params
            self.exit_json  = Mock()
            self.fail_json  = Mock()
            self.is_executable = Mock(return_value=False)

        def get_bin_path(self, path, required=False, opt_dirs=[]):
            if path == "systemctl":
                return '/bin/systemctl'
            else:
                return None

    def mock_run_command_with_output(commands):
        return code, stdout, stderr


# Generated at 2022-06-23 01:49:54.073542
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import FactsCollector
    import ansible.module_utils.facts.system.service_mgr

    module = FakeModule()

    def myfunc(self, module):
        return 'True'

    ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed = myfunc
    facts = FactsCollector(module)
    results = facts.collect()

    assert results['service_mgr'] == 'systemd'
    module.run_exit_json.assert_called_once_with(changed=False, ansible_facts=results)


# Generated at 2022-06-23 01:49:56.238730
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    '''
    Ensure module loads properly
    '''
    ServiceMgrFactCollector()

# Generated at 2022-06-23 01:49:57.798449
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()
    assert s is not None