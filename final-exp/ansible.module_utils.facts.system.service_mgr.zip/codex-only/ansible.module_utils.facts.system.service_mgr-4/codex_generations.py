

# Generated at 2022-06-23 01:40:04.560629
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    import sys
    if sys.version_info[0] > 2:
        from importlib import reload

    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    if sys.version_info[0] < 3:
        reload(mock)  # Python 2.6, 2.7

    # Simple test for systemd
    with mock.patch('os.path.exists', return_value=True):
        assert ServiceMgrFactCollector.is_systemd_managed(None) is True

    # Test for false positive on non-systemd
    with mock.patch('os.path.exists', return_value=False):
        assert ServiceMgrFactCollector.is_systemd_managed(None) is False

# Generated at 2022-06-23 01:40:13.354483
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    tested_module = lambda: None
    tested_module.get_bin_path = lambda x: '/usr/bin/systemctl'
    os.environ['PATH'] = os.environ.get('PATH', '/usr/bin')
    os.makedirs('/etc/systemd/system')
    open('/etc/systemd/system/test.service', 'a').close()  # touch
    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed_offline(tested_module)


# Generated at 2022-06-23 01:40:18.273767
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    if platform.system() == 'SunOS':
        return
    instance = ServiceMgrFactCollector()
    assert instance.name == 'service_mgr'
    assert instance.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:40:24.634416
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return "/somepath/%s" % name

    module = MockModule()
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False
    module.sd_booted = lambda: True
    assert ServiceMgrFactCollector.is_systemd_managed(module) == True


# Generated at 2022-06-23 01:40:26.049795
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    v = ServiceMgrFactCollector()
    assert v is not None

# Generated at 2022-06-23 01:40:36.283572
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BashColonFactCollector
    class FakeModule:
        def get_bin_path(self, exe):
            return '/bin/' + exe
    fake_module = FakeModule()
    fake_collector = BashColonFactCollector()
    fake_collector.collect = lambda x: {'ansible_system': 'Linux'}
    required_facts = ServiceMgrFactCollector.required_facts.copy()
    required_facts.add('command_paths')
    service_mgr_collector = ServiceMgrFactCollector(
        module=fake_module,
        collectors={ 'bash_colon': fake_collector },
        required_facts=required_facts)

# Generated at 2022-06-23 01:40:38.922719
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    first = ServiceMgrFactCollector()
    second = ServiceMgrFactCollector()
    assert first is second

# Generated at 2022-06-23 01:40:48.127722
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector()

    assert collector.is_systemd_managed_offline(object()) is False

    # Mocking the original method using a decorator
    # See http://stackoverflow.com/questions/12219967/how-to-mock-an-imported-class-using-python-mock-library
    @classmethod
    def is_systemd_managed_offline_mock_true(cls, module):
        return True

    collector.is_systemd_managed_offline = is_systemd_managed_offline_mock_true

    assert collector.is_systemd_managed_offline(object()) is True


# Generated at 2022-06-23 01:40:58.150669
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # First case where we are running on BSD
    os.uname = lambda: ('FreeBSD', '9.0', '9.0-RELEASE', 'FreeBSD 9.0-RELEASE #0: Thu Jan 12 12:40:38 UTC 2012', 'root@farrell.cse.buffalo.edu:/usr/obj/usr/src/sys/GENERIC')
    ServiceMgrFactCollector.is_systemd_managed = lambda x: False
    ServiceMgrFactCollector.is_systemd_managed_offline = lambda x: False
    module = AnsibleModuleMock()
    module.get_bin_path = lambda x: False
    assert ServiceMgrFactCollector(module).collect()['service_mgr'] == 'bsdinit'

    # Second case where we are running on Linux

# Generated at 2022-06-23 01:41:04.477519
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collectors.service_mgr as module

    testobject1 = {'stat_result': {'st_nlink': 1,
                                   'st_size': 0,
                                   'st_mode': 0o120777,
                                   'st_atime': 1,
                                   'st_mtime': 1,
                                   'st_uid': 0,
                                   'st_ctime': 1,
                                   'st_ino': 2,
                                   'st_dev': 2049,
                                   'st_gid': 0},
                   'path': 'test'}
    assert module.ServiceMgrFactCollector.is_systemd_managed_offline(testobject1) == False



# Generated at 2022-06-23 01:41:04.963904
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-23 01:41:14.598698
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:41:26.174852
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import os.path
    import shutil
    import tempfile

    def get_bin_path(path):
        return path

    module = type('module', (object,), {'get_bin_path': get_bin_path})


# Generated at 2022-06-23 01:41:32.749211
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    sfc = ServiceMgrFactCollector()
    assert isinstance(sfc, ServiceMgrFactCollector)
    assert sfc.name == 'service_mgr'
    assert sfc._fact_ids == set()
    assert sfc.required_facts == {'distribution', 'platform'}

# Generated at 2022-06-23 01:41:34.165293
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector().name == 'service_mgr'

# Generated at 2022-06-23 01:41:45.508012
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.get_bin_path_calls = []
            self.fail_json_calls = []

        def get_bin_path(self, name):
            self.get_bin_path_calls.append(name)
            if name == 'systemctl':
                return 'systemctl'
            elif name == 'systemctl-offline':
                return 'systemctl-offline'
            return None

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_calls.append({'args': cmd, 'kwargs': {'use_unsafe_shell': use_unsafe_shell}})

# Generated at 2022-06-23 01:41:53.867063
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector

    module = MockModule()

    for p in ['systemctl']:
        results = ServiceMgrFactCollector.is_systemd_managed_offline(module)
        assert(results is False)

        module.run_command.return_value = 1, "", ""
        results = ServiceMgrFactCollector.is_systemd_managed_offline(module)
        assert(results is False)

        module.run_command.return_value = 0, "", ""
        results = ServiceMgrFactCollector.is_systemd_managed_offline(module)
        assert(results is False)

        module.run_command.return_value = 0, "systemd", ""
        results = ServiceMgrFactCollector.is_system

# Generated at 2022-06-23 01:41:59.724364
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import mock
    import os

    class ModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        @staticmethod
        def get_bin_path(name):
            return '/bin/%s' % name

    # no symlink
    with mock.patch('os.path.islink', return_value=False):
        module = ModuleMock()
        mgr = ServiceMgrFactCollector()
        assert mgr.is_systemd_managed_offline(module) is False

    # symlink, but not to systemd
    with mock.patch('os.path.islink', return_value=True):
        with mock.patch('os.readlink', return_value='/sbin/fake-init'):
            module = ModuleMock()

# Generated at 2022-06-23 01:42:08.103463
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.facts import FallbackModuleUtils
    from ansible.module_utils.six import PY2

    # If python is 2, then import module mock. If python is 3, then import unittest.mock
    if PY2:
        from mock import Mock
    else:
        from unittest.mock import Mock

    module = Mock()

    class ModuleUtils(FallbackModuleUtils):
        def __init__(self, module=module):
            self.module = module

# Generated at 2022-06-23 01:42:10.558196
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """
    Unit test for constructor of class ServiceMgrFactCollector
    """
    d = ServiceMgrFactCollector()
    assert type(d).__name__ == "ServiceMgrFactCollector"

# Generated at 2022-06-23 01:42:21.027773
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # pylint: disable=anomalous-backslash-in-string,no-self-use
    import unittest
    from ansible.module_utils.facts import collector
    import ansible.module_utils.basic
    import ansible.module_utils.facts # to register collectors (import is a side-effect)

    class FakeModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

        def run_command(self, command, use_unsafe_shell):
            return (0, '', '')




# Generated at 2022-06-23 01:42:28.123578
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    # Set different values for service_mgr
    service_mgr_value = "service_mgr"

    # Create instance of ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Check instance created successfully
    assert isinstance(service_mgr_fact_collector, ServiceMgrFactCollector)

    # Check result with value of service_mgr
    assert service_mgr_fact_collector.collect()['service_mgr'] == service_mgr_value

# Generated at 2022-06-23 01:42:32.448347
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.collect() == {'service_mgr': 'service'}

# Generated at 2022-06-23 01:42:43.870619
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    class MockModule:

        class MockRunCommandParams:
            return_rc = 0
            return_stdout = None
            return_stderr = None

            def __init__(self, rc, out, err):
                self.return_rc = rc
                self.return_stdout = out
                self.return_stderr = err

        def __init__(self, run_command_params):
            if not isinstance(run_command_params, list):
                run_command_params = [run_command_params]

            self.run_command_returns = dict(
                (idx, self.MockRunCommandParams(*params))
                for idx, params in enumerate(run_command_params)
            )


# Generated at 2022-06-23 01:42:53.776111
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import os
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    os_path_isfile_mock_path = None
    os_path_exists_mock_path = None
    os_path_islink_mock_path = None
    os_readlink_mock_path = None
    os_executable_mock_path = None

    # Mocking of os.path.isfile(path)

# Generated at 2022-06-23 01:43:04.779634
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.basic
    class MockModule(object):
        def run_command(self, command, use_unsafe_shell=None):
            return 0, 'fake_proc_1_output', None
        def get_bin_path(self, binary, opt_dirs=None):
            return binary
    module = MockModule()
    collected_facts = {}
    # Check that on Linux the method returns systemd when it is the boot init system
    module.run_command = lambda x, y: (0, 'systemd', None)
    module.get_bin_path = lambda x, y: True
    collected_facts['ansible_system'] = 'Linux'
    collected_facts['ansible_distribution'] = None
    service_

# Generated at 2022-06-23 01:43:15.440667
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import facts.collector.service_mgr
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import platform
    import os

    class ModuleMock:
        class params:
            def __init__(self):
                self.systemd_managed = None

        def __init__(self):
            self.params = self.params()

        def get_bin_path(self, binary):
            original_get_bin_path = ansible.module_utils.facts.utils.get_bin_path
            if binary == 'systemctl':
                if platform.system() == 'SunOS':
                    bin_path = '/usr/bin/svcs'
                else:
                    bin_path = '/bin/systemctl'
            else:
                bin_path = original_get

# Generated at 2022-06-23 01:43:24.906164
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Test with available facts: ansible_distribution and ansible_system
    module = AnsibleModule({'ansible_distribution': 'RedHat', 'ansible_system': 'Linux'})
    assert ServiceMgrFactCollector.collect(module) == {'service_mgr': 'service'}
    assert ServiceMgrFactCollector.collect(module) == {'service_mgr': 'service'}
    assert ServiceMgrFactCollector.collect(module) == {'service_mgr': 'service'}

    # Test with available facts: ansible_system and ansible_distribution
    module = AnsibleModule({'ansible_system': 'Microsoft', 'ansible_distribution': 'Windows'})
    assert ServiceMgrFactCollector.collect(module) == {'service_mgr': 'service'}

# Generated at 2022-06-23 01:43:29.066248
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Creating an object of the class to call its methods
    ServiceMgrFactCollector_object = ServiceMgrFactCollector()
    # Calling the method collect() of the class
    assert ServiceMgrFactCollector_object.collect() == {}


# Generated at 2022-06-23 01:43:38.504600
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Unit test for method collect of ServiceMgrFactCollector.

    :param self: ServiceMgrFactCollectorTest object
    """
    service_mgr_names = {'upstart', 'sysvinit', 'systemd', 'rc'}
    service_mgr_name = ServiceMgrFactCollector().collect({'platform_version': '18.04'})['service_mgr']
    assert service_mgr_name in service_mgr_names

# Generated at 2022-06-23 01:43:48.991098
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    fact = ServiceMgrFactCollector()
    mock_module = Mock()

    # It is systemd
    mock_module.get_bin_path = MagicMock(return_value='systemctl')
    mock_module.run_command = MagicMock(return_value=('/sbin/init', 'systemd'))
    assert fact.is_systemd_managed_offline(mock_module)

    # Not systemd
    mock_module.get_bin_path = MagicMock(return_value='systemctl')
    mock_module.run_command = MagicMock(return_value=('/sbin/init', 'not_systemd'))
    assert not fact.is_systemd_managed_offline(mock_module)

    # No systemctl
    mock_module.get_bin_path = MagicMock

# Generated at 2022-06-23 01:43:56.830227
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a stub of module class
    class Module(object):
        def get_bin_path(self, name):
            if name == 'systemctl':
                return 'systemctl'
            else:
                return None
    module = Module()
    # Create a stub of is_systemd_managed_offline
    m = ServiceMgrFactCollector()
    # Test case 1: /sbin/init is a symlink to systemd
    # Expected: True
    try:
        os.symlink('systemd', '/sbin/init')
    except OSError:
        pass
    assert m.is_systemd_managed_offline(module)

    # Test case 2: /sbin/init is not a symlink to systemd
    # Expected: False

# Generated at 2022-06-23 01:43:58.855701
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    collector = ServiceMgrFactCollector()
    # TODO: mock ansible module
    collector.is_systemd_managed()

# Generated at 2022-06-23 01:44:08.185536
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    def is_systemd_managed_offline(self, module):
        return ServiceMgrFactCollector.is_systemd_managed_offline(module)

    from ansible.module_utils.facts import ModuleBase
    smfc = ServiceMgrFactCollector()
    module_argv_global = ""

    # dummy function for test purposes
    def get_bin_path(self, executable):
        return executable

    # dummy function for test purposes
    def readlink(self, symlink):
        if symlink == "/sbin/init":
            return "systemd"
        else:
            return None

    def test_not_systemd_managed(test_module, readlink_func):
        class TestModule(ModuleBase):
            def __init__(self, argv):
                self.module_argv = arg

# Generated at 2022-06-23 01:44:11.762735
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smc = ServiceMgrFactCollector()
    assert smc.name == 'service_mgr'
    assert smc._fact_ids == set()
    assert smc.required_facts == {'platform', 'distribution'}



# Generated at 2022-06-23 01:44:21.637905
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    import module_utils.facts.system.service_mgr
    module_utils.facts.system.service_mgr.os = mock.Mock()

    # os.path.islink returns False
    os.path.islink = mock.Mock(return_value = False)
    assert ServiceMgrFactCollector.is_systemd_managed_offline(mock.Mock()) == False

    # /sbin/init is not a symlink
    os.path.islink = mock.Mock(return_value = True)
    os.readlink = mock.Mock(return_value = '/usr/lib/systemd/systemd')
    assert ServiceMgrFactCollector.is_systemd_managed_off

# Generated at 2022-06-23 01:44:23.784794
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed(ServiceMgrFactCollector) == False

# Generated at 2022-06-23 01:44:29.039248
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class Module():
        def get_bin_path(self, executable):
            return None

        def run_command(self, cmd, use_unsafe_shell=True):
            return None

    sut = ServiceMgrFactCollector()
    result = sut.collect(module=Module())

    print(result)


# Generated at 2022-06-23 01:44:39.394188
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    m = mock.MagicMock()
    m.get_bin_path.return_value = '/bin/systemctl'
    # Test True with valid symlink
    os.readlink = mock.Mock(return_value='systemd')
    os.path.islink = mock.Mock(return_value=True)
    assert ServiceMgrFactCollector.is_systemd_managed_offline(m)
    # Test False with invalid symlink
    os.readlink = mock.Mock(return_value='rc-sysinit')
    os.path.islink = mock.Mock(return_value=True)
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(m)
    # Test False with unset symlink

# Generated at 2022-06-23 01:44:40.490177
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector

# Generated at 2022-06-23 01:44:50.113970
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """Unit test for method is_systemd_managed_offline.

    This method is called by the method is_systemd_managed, so we can check only
    if the method is_systemd_managed_offline returns the expected value
    and we don't need to unit test is_systemd_managed.
    """
    import mock
    import os

    # Use temporary directory to simulate the presence of systemd
    with mock.patch.object(os, 'getcwd') as mock_getcwd:
        mock_getcwd.return_value = '/tmp'
        with mock.patch.object(os, 'readlink') as mock_readlink:
            mock_readlink.return_value = 'systemd'
            mgr = ServiceMgrFactCollector()
            assert mgr.is_systemd_managed_offline(None)

# Generated at 2022-06-23 01:44:51.759515
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.name == 'service_mgr'

# Generated at 2022-06-23 01:45:02.910372
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.virtual.sysv_service import SysVServiceModule
    from ansible.module_utils.facts.virtual.systemd_service import SystemdServiceModule
    from ansible.module_utils.facts.virtual.svc_service import SvSvcModule
    from ansible.module_utils.facts.virtual.openwrt_service import OpenWrtServiceModule

    svc_module = ServiceMgrFactCollector()
    assert svc_module.is_systemd_managed_offline(SysVServiceModule()) == False
    assert svc_module.is_systemd_managed_offline(SystemdServiceModule()) == True

# Generated at 2022-06-23 01:45:13.158221
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils
    #Collect fake data to be used in test
    class FakeModule(object):
        class FakeArgs(object):
            pass

        def __init__(self):
            self.params = self.FakeArgs()

        def get_bin_path(self, *args, **kwargs):
            return '/bin/systemctl'

        def run_command(self, args, use_unsafe_shell=False):
            return (1, '', '')

    fs = ansible.module_utils.basic.AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True,
    )
    mm = FakeModule()
    # Set some defaults for the method collect.

# Generated at 2022-06-23 01:45:25.212654
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    import mock
    import sys

    if sys.version_info[0] == 2:
        builtin_module_name = '__builtin__'
    else:
        builtin_module_name = 'builtins'

    sut = ServiceMgrFactCollector()
    class ModuleMock(mock.Mock):
        params = mock.Mock()
        def get_bin_path(self, bin_path, required=False):
            if bin_path == 'systemctl':
                return bin_path
            else:
                return None
    module = ModuleMock()


# Generated at 2022-06-23 01:45:29.953964
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Check to make sure that the constructor of the class does not fail
    assert ServiceMgrFactCollector()

# Generated at 2022-06-23 01:45:37.539773
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    import sys
    import unittest

    class test_module:
        pass

    module = test_module()
    module.run_command = module.get_bin_path = lambda x: None

    class test(unittest.TestCase):
        def test_init(self):
            try:
                test_obj = ServiceMgrFactCollector(module)
            except Exception as e:
                self.fail("Failed to create ServiceMgrFactCollector object: {0}".format(e))

            self.assertEqual(test_obj.name, 'service_mgr')
            self.assertIsInstance(test_obj._fact_ids, set)
            self.assertIsInstance(test_obj.required_facts, set)

    unit_test = test(methodName='test_init')
    unit_test.test_

# Generated at 2022-06-23 01:45:41.047503
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    sm_fc = ServiceMgrFactCollector()
    assert sm_fc.is_systemd_managed(module_mock)


# Generated at 2022-06-23 01:45:42.941382
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-23 01:45:51.555719
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils
    import ansible.module_utils.facts.collector

    class DummyModule(object):
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            return None

    # create a dummy module
    dummy_module = DummyModule()

    # create a dummy fact collector
    fact_collector = ServiceMgrFactCollector()

    # assert that it is not managed when there is no systemctl executable
    assert False == fact_collector.is_systemd_managed(dummy_module)

    # assert that it is managed when there is a systemctl executable
    dummy_module.get_bin_path = lambda executable: executable

    assert True == fact_collector.is_systemd_managed(dummy_module)

# Generated at 2022-06-23 01:45:53.677501
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    collector = ServiceMgrFactCollector()
    result = collector.collect()
    assert result == {}, "service_mgr_collect returns unexpected value"


# Generated at 2022-06-23 01:46:03.443809
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a module for passing to the fact collector
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Create a ServiceMgrFactCollector object to test against
    x = ServiceMgrFactCollector(module=module)

    # Create a dict to hold the results of the collect method
    result = dict()
    result["ansible_facts"] = dict()
    result["ansible_facts"]["service_mgr"] = None

    # First test without any collected_facts
    result = x.collect(module=module, collected_facts=None)
    assert "ansible_facts" in result
    assert "service_mgr" in result["ansible_facts"]
    assert result["ansible_facts"]["service_mgr"] is None

    # Second test

# Generated at 2022-06-23 01:46:14.440390
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors import get_collector_instance
    import os

    module = AnsibleModuleStub()

# Generated at 2022-06-23 01:46:21.603784
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert (smfc.name == 'service_mgr')
    assert (smfc._fact_ids == set())
    assert (smfc.required_facts == set(['platform', 'distribution']))

# Generated at 2022-06-23 01:46:24.488194
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x
    assert x.name == 'service_mgr'
    assert x.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:46:32.456121
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import Collector

    # mock module
    mocked_module = type('ansible.module_utils.facts.collector.system.ServiceMgrFactCollector_mod', (object, ), {
        'get_bin_path': lambda self, cmd: '/bin/' + cmd
    })

    # mock file system objects
    mocked_os_path = type('ansible.module_utils.facts.collector.system.ServiceMgrFactCollector_ospath', (object, ), {
        'isdir': lambda path: True,
        'islink': lambda path: True,
        'basename': lambda path: 'systemd',
        'exists': lambda path: True
    })

# Generated at 2022-06-23 01:46:42.640420
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible_collections.os.solaris.tests.unit.compat.mock import Mock
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils._text import to_bytes


    class TestSystemdManagedOffline(object):

        def test_is_systemd_managed_offline(self):
            test_module = Mock()
            test_module.get_bin_path.return_value = '/usr/bin/systemctl'
            test_module.run_command.return_value = 0

            smfc = ServiceMgrFactCollector(test_module)
            result = smfc.is_systemd_managed_offline(test_module)

            assert result is False


# Generated at 2022-06-23 01:46:47.089199
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline() == False, 'is_systemd_managed_offline should return False if init is not a symlink to systemd'



# Generated at 2022-06-23 01:46:58.372255
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.test import MockModule
    module = MockModule(
        env={
            'PATH': '',
            'SYSTEMD_COLORS': '1',
            'SYSTEMD_LESS': 'FRSXMK'
        },
        sys_executable='/usr/bin/python2.7'
    )
    assert ServiceMgrFactCollector.is_systemd_managed(module) is False

    module = MockModule(
        run_command_stdout=['systemd'],
        env={
            'PATH': '/usr/bin:/bin'
        },
        sys_executable='/usr/bin/python2.7'
    )
    assert ServiceMgrFactCollector.is_systemd_managed(module) is True


# Generated at 2022-06-23 01:47:08.169065
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    from ansible.module_utils.facts.cpu.openbsd import OpenBSDProcessor
    from ansible.module_utils.facts.cpu.linux import LinuxCpu
    from ansible.module_utils.facts.cpu.netbsd import NetBSDProcessor
    from ansible.module_utils.facts.filesystem.linux import LinuxFileSystem
    from ansible.module_utils.facts.filesystem.openbsd import OpenBSDFileSystem
    from ansible.module_utils.facts.filesystem.netbsd import NetBSDFileSystem
    from ansible.module_utils.facts.filesystem.aix import AIXFileSystem

    # initialize module, set fact_list and collect the facts
    ansible_module = AnsibleModule(
        argument_spec=dict()
    )


# Generated at 2022-06-23 01:47:19.154694
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # TODO: This test needs to be unified. It should be platform independent and should not use the module as a parameter.
    class MockModule(object):
        def __init__(self, result=None):
            self.result = result

        def get_bin_path(self, cmd):
            return self.result

    # test case: tools must be installed
    mm = MockModule(result='/usr/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(mm)

    # test case: this should show if systemd is the boot init system if checking init faild to mark as systemd
    # these mirror systemd's own sd_boot test http://www.freedesktop.org/software/systemd/man/sd_booted.html

# Generated at 2022-06-23 01:47:28.779982
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import mock
    import __builtin__

    # Mock modules
    modules_mock = mock.MagicMock()
    modules_mock.get_bin_path.return_value = None

    # Mock is_systemd_managed
    from ansible.module_utils import facts

    facts.service_mgr = ServiceMgrFactCollector()
    facts.service_mgr.is_systemd_managed = mock.MagicMock(return_value=None)
    facts.service_mgr.is_systemd_managed_offline = mock.MagicMock(return_value=None)

    # Collect data
    collected_facts = dict()

    # Test 1: test with system OpenWrt
    collected_facts["ansible_distribution"] = "OpenWrt"

# Generated at 2022-06-23 01:47:33.540725
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import DictFactsCollector
    collected_facts = DictFactsCollector()
    facts_collected = ServiceMgrFactCollector().collect(None, collected_facts)
    assert isinstance(facts_collected, dict)

# Generated at 2022-06-23 01:47:38.924473
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    argument_spec = {
        'module': True,
        'get_bin_path': True,
        'readlink': True,
        'run_command': True,
    }
    mf = ServiceMgrFactCollector(argument_spec=argument_spec)
    module_mock = MockModule()

    # No tools installed - should return False
    module_mock.reset()
    module_mock.temp_bin_path_exists = False
    module_mock.readlink_output = False
    module_mock.run_command_output = False
    assert not mf.is_systemd_managed_offline(module_mock)

    # Command failed - should return False
    module_mock.reset()
    module_mock.temp_bin_path_exists = True
    module_m

# Generated at 2022-06-23 01:47:50.714862
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    from ansible.module_utils.facts.collector import Cache
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Test without required facts
    cache = Cache(None, {}, {})
    collector = ServiceMgrFactCollector(None)
    assert collector.collect(cache=cache) == {'service_mgr': 'service'}

    # Test with system facts
    cache = Cache(None, {}, {'ansible_system': 'AIX'})
    collector = ServiceMgrFactCollector(None)
    assert collector.collect(cache=cache) == {'service_mgr': 'src'}
    cache = Cache(None, {}, {'ansible_system': 'SunOS'})
    collector = ServiceMgrFactCollector(None)

# Generated at 2022-06-23 01:47:59.634060
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Default is 'service'
    def mock_execute_module(self):
        return {'ansible_facts':{}}

    fact_collector = ServiceMgrFactCollector()
    fact_collector.execute_module = mock_execute_module
    ansible_facts = fact_collector.collect(None, collected_facts={})
    assert 'service_mgr' in ansible_facts
    assert ansible_facts['service_mgr'] == 'service'

    # 'service_mgr' is 'upstart'
    def mock_is_systemd_managed(self, module):
        return False

    def mock_get_bin_path(self, module):
        return os.path.join('/sbin','initctl')

    fact_collector.is_systemd_managed = mock_is_systemd_managed

# Generated at 2022-06-23 01:48:02.286229
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(None)



# Generated at 2022-06-23 01:48:12.871845
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    # create test module
    class TestModule(BaseFactCollector):
        def __init__(self):
            self.facts = {}

        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return "/usr/bin/systemctl"
            else:
                return None

    test_module = TestModule()

    # create test class
    class Test(ServiceMgrFactCollector):
        pass

    # create test object
    test_obj = Test()

    # create test conditions
    has_run_systemctl = Test.is_systemd_managed(test_module)

    # test method
    assert has_run_systemctl == False


# Generated at 2022-06-23 01:48:20.074606
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create an instance of ServiceMgrFactCollector
    serviceMgrFactCollector = ServiceMgrFactCollector()

    # Create a module mock object and class instance
    m = MockModule()
    serviceMgrFactCollector.module = m

    # Test case 1: boot by systemd
    cmd = 'ps -p 1 -o comm|tail -n 1'
    rc = 0
    stdout = '/sbin/init\n'
    err = ''
    m.run_command.return_value = (rc, stdout, err)
    cmd_args = 'systemctl list-unit-files'.split()
    m.run_command.return_value = (0, '', '')
    result = serviceMgrFactCollector.is_systemd_managed_offline(m)
    m.run_command.assert_called

# Generated at 2022-06-23 01:48:32.048156
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Import pytest just for the test
    import pytest
    os.system('rm -r /dev &>/dev/null')
    os.system('rm -r /run &>/dev/null')
    os.system('rm -f /sbin/init &>/dev/null')
    os.system('ln -s /bin/ls /sbin/init &>/dev/null')

    # Mock the module
    from ansible.utils.module_docs_fragments import get_test_modules_path
    mock_module = MockModule(path=get_test_modules_path())

    # Create a test object
    service_mgr_obj = ServiceMgrFactCollector(module=mock_module)

# Generated at 2022-06-23 01:48:43.788104
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Requires testinfra 1.0.0 or higher to be installed
    https://testinfra.readthedocs.io/en/latest/
    """

    from testinfra.utils import get_os_distribution
    from testinfra.modules.systeminfo import CommandCapacity

    # Test required platforms
    required_platforms = [
        'Linux', 'MacOSX', 'AIX', 'SunOS'
    ]
    if get_os_distribution() not in required_platforms:
        return

    # Test required command capacities
    required_cmds = [
        CommandCapacity.COMMAND, CommandCapacity.ARGUMENTS, CommandCapacity.PIPE
    ]
    if not CommandCapacity().satisfy(required_cmds):
        return


# Generated at 2022-06-23 01:48:46.691760
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline({'get_bin_path': lambda name: None}) == False

# Generated at 2022-06-23 01:48:57.364979
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Set up class
    Module = type('Module', (), {
        'get_bin_path': lambda self, x: True,
        'run_command': lambda self, x, **kwargs: (0, '', ''),
    })
    module = Module()
    fact_collector = ServiceMgrFactCollector()

    # Set up test filesystem under /tmp
    os.makedirs('/tmp/is_systemd_managed_test')
    os.open('/tmp/is_systemd_managed_test/run_systemd_system', os.O_CREAT).close()
    os.open('/tmp/is_systemd_managed_test/dev_run_systemd', os.O_CREAT).close()

# Generated at 2022-06-23 01:49:02.019800
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # 1. Check for positive case
    test_systemd_managed = ServiceMgrFactCollector.is_systemd_managed_offline()
    assert test_systemd_managed is False

    # 2. Check for negative case
    test_systemd_managed = ServiceMgrFactCollector.is_systemd_managed_offline()
    assert test_systemd_managed is False

# Generated at 2022-06-23 01:49:08.732181
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 01:49:12.587489
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Arrange
    fact_collector = ServiceMgrFactCollector()
    collected_facts = dict()
    # Act
    facts_dict = fact_collector.collect(collected_facts=collected_facts)
    # Assert
    assert facts_dict == dict()

# Generated at 2022-06-23 01:49:23.413097
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    x = ServiceMgrFactCollector()

    class Module(object):
        def get_bin_path(self, executable, required=True, opt_dirs=[]):
            return '/bin/systemctl'

    assert x.is_systemd_managed_offline(Module()) == False

    # create a dummy symlink
    os.symlink('/bin/bash', '/sbin/init')
    assert x.is_systemd_managed_offline(Module()) == False

    # remove the symlink
    os.unlink('/sbin/init')

    # create a dummy symlink named 'systemd'
    os.symlink('/bin/bash', '/sbin/init')
    assert x.is_system

# Generated at 2022-06-23 01:49:31.734359
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.service_mgr as service_mgr
    import ansible.module_utils.facts.utils as utils

    # set up testing data
    module = utils.get_ansible_module_mock()
    service_mgr.platform.system = lambda: 'Linux'
    service_mgr.ansible.module_utils.basic.AnsibleModule.get_bin_path = lambda x: '/usr/bin/systemctl'

    service_mgr.os.path.exists = lambda x: True

    # test if methods returns True
    assert service_mgr.ServiceMgrFactCollector.is_systemd_managed(module) is True

    # cleanup
    del module, utils, service_mgr


# Generated at 2022-06-23 01:49:34.226690
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    collector = ServiceMgrFactCollector()
    assert collector.name == 'service_mgr'
    assert collector._fact_ids == set()
    assert collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:49:39.336557
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = None
    collector = ServiceMgrFactCollector.is_systemd_managed_offline(module)
    assert collector == False

if __name__ == '__main__':
    test_ServiceMgrFactCollector_is_systemd_managed_offline()

# Generated at 2022-06-23 01:49:42.827964
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector.name == 'service_mgr'
    assert service_mgr_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:49:52.798916
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Run test for class ServiceMgrFactCollector.

    :returns: ``True`` if test is passed, ``False`` otherwise.
    :rtype: bool
    """
    import mock
    import sys

    # init Signature to check mocked call of module_utils.facts.utils.get_file_content()

    # mock get_file_content with empty string content
    with mock.patch.object(get_file_content, return_value='') as mock_get_file_content:
        # init ServiceMgrFactCollector class instance
        service_mgr_fact_collector = ServiceMgrFactCollector()
        # mock ModuleUtilsLegacy class instance
        class MockModuleUtilsLegacy:
            def __init__(self):
                self.params = {}


# Generated at 2022-06-23 01:49:56.333628
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfact = ServiceMgrFactCollector()
    assert smfact.required_facts == {'platform', 'distribution'}