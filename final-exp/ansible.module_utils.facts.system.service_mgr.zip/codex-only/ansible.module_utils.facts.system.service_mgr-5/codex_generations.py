

# Generated at 2022-06-23 01:39:56.540596
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    svc_mgr_collector = ServiceMgrFactCollector()
    assert svc_mgr_collector.name == 'service_mgr'

# Generated at 2022-06-23 01:40:05.672066
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # ServiceMgrFactCollector should be registered with FactCache instance
    assert ServiceMgrFactCollector.name in FactCache().collectors

    # ServiceMgrFactCollector should be registered with Collector instance
    assert ServiceMgrFactCollector.name in Collector()._collectors

    # get_collector_class should return ServiceMgrFactCollector class
    assert get_collector_class('service_mgr') == ServiceMgrFactCollector

    # ServiceMgrFactCollector.collect method should not return empty dict
   

# Generated at 2022-06-23 01:40:15.586409
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    import tempfile, shutil
    import os
    import logging

    result = False
    test_dir = tempfile.mkdtemp()
    # The canary files are marked as directories, so that we can test the scenario of
    # is_systemd_managed() returning True
    # in the 3rd condition:
    # the orignal code runs "os.path.exists(canary)" to test if the directory canary exists
    # the orignal code then sees if the directory canary is a directory
    # when os.path.exists sees it is a directory, it returns false
    # so we will create the directory as a file, then run is_systemd_managed()
    # we will also make sure there is a tmpfs mounted at /run
    # thus the

# Generated at 2022-06-23 01:40:24.406682
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Instance of class
    smfc = ServiceMgrFactCollector()
    # Name of class
    assert smfc.name == 'service_mgr'
    # Required Facts
    assert smfc.required_facts == set(['platform', 'distribution'])
    # Fact Ids
    assert smfc._fact_ids is not None

# Generated at 2022-06-23 01:40:34.419050
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Unit test for method ServiceMgrFactCollector.collect
    """
    module = MockModule()
    base_collector = BaseFactCollector(module)
    fact_collector = ServiceMgrFactCollector(base_collector)
    facts_dict = fact_collector.collect()
    assert facts_dict == {'service_mgr': 'service'}

    module = MockModule(params={"service_mgr": "bsdinit"})
    base_collector = BaseFactCollector(module)
    fact_collector = ServiceMgrFactCollector(base_collector)
    facts_dict = fact_collector.collect()
    assert facts_dict == {'service_mgr': 'bsdinit'}


# unit test class.

# Generated at 2022-06-23 01:40:44.475346
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    import MockModule

    module = MockModule.MockModule()

    assert ServiceMgrFactCollector.is_systemd_managed(module) == False, 'is_systemd_managed should return False if tools are not installed'

    module.get_bin_path_mock = MockModule.MockFunction()
    module.get_bin_path_mock.return_value = '/path/to/systemctl'

    assert ServiceMgrFactCollector.is_systemd_managed(module) == True, 'is_systemd_managed should return True if tools are installed and systemd is boot init system'


# Generated at 2022-06-23 01:40:52.669056
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test_modules = dict(ansible_facts={}, ansible_check_mode=False,
        ansible_system='Linux', ansible_system_capabilities=None,
        ansible_pkg_mgr=None, ansible_distribution=None,
        ansible_distribution_file_parsed=False,
        ansible_distribution_file_path=None,
        ansible_distribution_file_variety=None,
        ansible_diff_mode=False)

    # Expact is_systemd_managed to return False if systemd tools are not present
    test_modules['get_bin_path'] = lambda bin_path: None
    assert ServiceMgrFactCollector.is_systemd_managed(test_modules) is False

    # Expect is_systemd_managed to return True if systemd
    # tools are

# Generated at 2022-06-23 01:41:05.592270
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils._text import to_bytes

    def run_command(self, command):
        if command == 'systemctl':
            return 0, to_bytes('/sbin/init'), None
        elif command == 'systemctl list-units':
            return 1, b'', b''
        else:
            raise Exception('Unexpected command run: {}'.format(command))

    import ansible.module_utils.facts.collector.service_mgr
    old_run_command = ansible.module_utils.facts.collector.service_mgr.run_command

# Generated at 2022-06-23 01:41:16.857217
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:41:19.439410
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    result = ServiceMgrFactCollector.is_systemd_managed_offline(None)
    assert result == False
    result = ServiceMgrFactCollector.is_systemd_managed(None)
    assert result == True

# Generated at 2022-06-23 01:41:24.427748
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Collect required parameters
    def get_bin_path(arg):
        return '/bin/sbin'

    # Initialize the collector
    smfc = ServiceMgrFactCollector()

    # Run the is_systemd_managed method
    class ModuleMock(object):
        @staticmethod
        def get_bin_path(arg):
            return None

    assert not smfc.is_systemd_managed(ModuleMock)

    class ModuleMock(object):
        @staticmethod
        def get_bin_path(arg):
            return '/bin/systemctl'

    assert not smfc.is_systemd_managed(ModuleMock)

    class ModuleMock(object):
        @staticmethod
        def get_bin_path(arg):
            return '/bin/systemctl'

    # NOTE: is_systemd_

# Generated at 2022-06-23 01:41:32.291374
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    test_is_systemd_managed_offline - unit test method is_systemd_managed_offline of class ServiceMgrFactCollector
    """
    def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
        """
        Mock run_command method for module
        """
        if not args.startswith("readlink"):
            raise Exception("Unknown command " + args)
        if "/sbin/init" in args:
            return 0, "systemd", ""
        else:
            return 0, "abc", ""


# Generated at 2022-06-23 01:41:32.898657
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-23 01:41:40.858149
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    class MockModule(object):
        def __init__(self):
            self.params = basic.AnsibleModule.params
            self.params['path'] = None
            self.check_mode = False
            self.exit_json = basic.AnsibleModule.exit_json
            self.fail_json = basic.AnsibleModule.fail_json

        def get_bin_path(self, executable):
            return '/usr/bin/systemctl'

    return ServiceMgrFactCollector.is_systemd_managed_offline(MockModule())

# Generated at 2022-06-23 01:41:50.298630
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Init
    collector = ServiceMgrFactCollector

    # Mock module
    class Module(object):
        def __init__(self, path, errmsg, rc):
            self.path = path
            self.errmsg = errmsg
            self.rc = rc
            self.init = None
            self.booted = None
            self.comm = None
            self.os = None
            self.srv = None

        def get_bin_path(self, name):
            return self.path.get(name)

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "ps -p 1 -o comm|tail -n 1":
                return (self.rc, self.comm, self.errmsg)
            elif cmd == "systemctl is-system-running":
                return

# Generated at 2022-06-23 01:41:51.331264
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector({})

# Generated at 2022-06-23 01:42:01.707035
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Initialise a mock module and call collect method of ServiceMgrFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import is_systemd_managed
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.facts.utils import get_file_content

    class MockCollector(BaseFactCollector):
        name = 'name'
        _fact_ids = set()
        required_facts = set()

        def _collect(self, module=None, collected_facts=None):
            return {'name': 'value'}


# Generated at 2022-06-23 01:42:06.386591
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x.name == 'service_mgr'
    assert x._fact_ids == set()
    assert x.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:42:16.842108
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    class MockModule(object):
        def __init__(self, module_name, argspec):
            self.check_mode = False
            self.name = module_name
            self.params = {}

        def exit_json(self):
            pass

        def fail_json(self):
            pass

        def get_bin_path(self, cmd):
            return self.bin_paths[cmd]

    # Required:
    # - collect method
    # - name
    # - required_facts
    # - _fact_ids
    # - required_facts is a subset of _fact_ids
    test_collector = ServiceMgrFactCollector()
    assert hasattr(test_collector, 'collect')

# Generated at 2022-06-23 01:42:24.174148
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class TestModule:
        @staticmethod
        def get_bin_path(command):
            return '/bin/systemctl'
    assert ServiceMgrFactCollector.is_systemd_managed_offline(TestModule)
    os.remove('/sbin/init')
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(TestModule)

# Generated at 2022-06-23 01:42:34.992655
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Test prep
    import mock
    import tempfile
    import shutil

    # Mock setup
    mocked_module = mock.Mock()
    mocked_module.run_command.return_value = (0, '', '')
    mocked_module.get_bin_path.return_value = None
    mocked_module.params = {}
    mocked_module.check_mode = False

    mocked_facts = {'ansible_system': 'Linux'}

    # Test setup
    test_dir = tempfile.mkdtemp(prefix='ansible_test_ServiceMgrFactCollector_')
    open(os.path.join(test_dir, 'systemd'), 'w').close()

    # Test teardown
    def remove_test_dir():
        shutil.rmtree(test_dir)
    request.add

# Generated at 2022-06-23 01:42:44.855518
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import unittest
    from ansible.module_utils.facts.collector import DummyModule
    from ansible.module_utils.facts import collector

    class TestServiceMgrFactCollector(unittest.TestCase):
        def test_is_systemd_managed(self):
            testmodule = DummyModule(platform_system="Linux")

            with unittest.mock.patch.object(collector, 'os') as mo:
                mo.path.exists.return_value = False
                mo.path.islink.return_value = False

                self.assertFalse(ServiceMgrFactCollector.is_systemd_managed(module=testmodule))

                mo.path.exists.assert_any_call('/run/systemd/system/')

# Generated at 2022-06-23 01:42:53.673039
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Test the collect method of ServiceMgrFactCollector.
    """
    # Note that this works as long as we don't call the superclass's __init__
    # method, which in turn means we cannot change the signature of this
    # method in the future.
    # If any of the above changes, we should move this test to a proper unit test
    # file, which will require writing proper unit tests for the BaseFactCollector
    # class, and then instantiating the ServiceMgrFactCollector class.
    mocker_distribution_facts = dict(ansible_distribution='CentOS', ansible_distribution_version='7')
    mocker_system_facts = dict(ansible_system='Linux')
    mocker_systemd_facts = dict(service_mgr='systemd')
    mocker_init_facts = dict

# Generated at 2022-06-23 01:43:04.707928
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    import platform

    class MyModule():
        def __init__(self):
            self.facts = FactsCollector()
            self.params = {}

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

    class Test_Init():
        def __init__(self):
            if platform.system() != 'Linux':
                raise ImportError

            if not os.path.exists('/proc/1/comm'):
                raise OSError

            self.proc_1 = None
            self.cmd_rc = 0

        def run_command(self, cmd, use_unsafe_shell=True):
            if 'ps -p 1' in cmd:
                return

# Generated at 2022-06-23 01:43:12.211749
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a dummy class instead of using a real ServiceMgrFactCollector class to test collect method
    test_collector = BaseFactCollector()
    test_collector.get_file_content = lambda file_name : file_name
    test_collector.get_bin_path = lambda file_name : file_name
    test_collector.run_command = lambda command, use_unsafe_shell : (0, '', '')
    test_collector.collect_file_facts = lambda collected_facts : {}

    # Create mock collected_facts
    collected_facts = {
        'ansible_distribution' : '',
        'ansible_system' : ''
    }

    # Throw out false positives during testing!
    expected_output = {
        'service_mgr' : ''
    }

    # Contents of /

# Generated at 2022-06-23 01:43:15.569184
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    serviceMgrFactCollector = ServiceMgrFactCollector()
    assert isinstance(serviceMgrFactCollector, BaseFactCollector)
    assert serviceMgrFactCollector.name == 'service_mgr'


# Generated at 2022-06-23 01:43:25.030783
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import mock
    import sys

    if sys.version_info < (2, 7):
        return
    if sys.version_info >= (3, 0) and sys.version_info < (3, 3):
        return

    module_patcher = mock.patch('ansible.module_utils.facts.collector.BaseFactCollector.get_bin_path')
    file_patcher = mock.patch('os.path.exists')
    symlink_patcher = mock.patch('os.path.islink')
    readlink_patcher = mock.patch('os.readlink')
    module = mock.Mock()
    is_systemd_managed_offline = ServiceMgrFactCollector.is_systemd_managed_offline

    # Case 0: init is not systemd
    file_mock = file_pat

# Generated at 2022-06-23 01:43:33.798640
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    class MockModule(object):
        def __init__(self):
            self.params = None
            self.exit_args = None
            self.exit_kwargs = None

        def get_bin_path(self, exec_name):
            if exec_name == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs


    service_mgr = ServiceMgrFactCollector()

    # test for version above or equal to 10.4
    module = MockModule()
    assert service_mgr.is_systemd_managed(module) is True

    # test for version below 10.4
    module = MockModule()
    assert service_m

# Generated at 2022-06-23 01:43:42.163008
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import ModuleData
    from ansible.module_utils.facts import FactData

    # Define generic module data.
    module_data = ModuleData(
        # FIXME: put a real implementation for get_bin_path
        get_bin_path=lambda path: path,
        run_command=lambda command, use_unsafe_shell: (0, '', ''),
    )

    # Define generic fact data.
    fact_data = FactData(
        ansible_distribution=None,
        ansible_system=None,
        platform=None,
        distribution=None,
    )

    # Collect facts related to system service manager and init.
    service_mgr_fact_collector = ServiceMgrFactCollector()
    facts_dict = service_mgr_fact_collector

# Generated at 2022-06-23 01:43:46.478453
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    module = None

    if ServiceMgrFactCollector.is_systemd_managed(module):
        assert False
    else:
        assert True



# Generated at 2022-06-23 01:43:55.305081
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector

    # no symlink to systemd
    class MockModule:
        @staticmethod
        def get_bin_path(command, required=False):
            return '/bin/false'

    mock_module = MockModule()
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(mock_module)

    # symlink to systemd
    class MockModule:
        @staticmethod
        def get_bin_path(command, required=False):
            return '/usr/lib/systemd/systemd'

    mock_module = MockModule()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(mock_module)

# Generated at 2022-06-23 01:43:57.484216
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    obj.collect()

    assert obj.name == 'service_mgr'

# Generated at 2022-06-23 01:43:59.868239
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc.name == 'service_mgr'
    assert smfc.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:44:08.757498
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Mock ansible.module_utils.facts.collector.BaseFactCollector
    class MockBaseFactCollector(BaseFactCollector):
        def __init__(self, module=None):
            self.module = module
            self.method = None

        def __getattr__(self, method):
            self.method = method
            return self.run

        def run(self, *args, **kwargs):
            if self.method == 'get_bin_path':
                return to_bytes('/bin/systemd')
            elif self.method == 'readlink':
                return to_bytes('systemd')

            return None

    #

# Generated at 2022-06-23 01:44:11.961262
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x.name == 'service_mgr'
    assert x._fact_ids == set()
    assert x.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:44:20.582545
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """Test ServiceMgrFactCollector.is_systemd_managed()."""
    # create a mock module
    facts_dict = {}
    results = {}
    results['ansible_facts'] = facts_dict
    module = MockModule(results=results)

    # create a ServiceMgrFactCollector object for testing
    collector = ServiceMgrFactCollector()

    # run test cases
    assert collector.is_systemd_managed(module) == False

    with patch.object(os.path, 'exists', Mock(side_effect=lambda canary: True if canary == '/run/systemd/system/' else False)):
        assert collector.is_systemd_managed(module) == True

# Generated at 2022-06-23 01:44:22.048015
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector()
    assert not collector.is_systemd_managed_offline(module=None)

# Generated at 2022-06-23 01:44:33.331109
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class MockModule:
        def get_bin_path(self, module_name):
            return '/usr/bin/systemctl'


# Generated at 2022-06-23 01:44:42.511326
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule:
        def __init__(self, return_values):
            self.return_values = return_values
            self.run_command_values = return_values

        def get_bin_path(self, command):
            return self.return_values[command]

        def run_command(self, cmd, use_unsafe_shell=True):
            return self.run_command_values[cmd]

    #  command1:
    #      get_bin_path: /bin/systemctl
    #      run_command:
    #          cmd1 = ps -p 1 -o comm|tail -n 1
    #          cmd1result (stdout): init
    #  command2:
    #      get_bin_path: /usr/bin/systemctl
    #      run_command:
    #          cmd1result

# Generated at 2022-06-23 01:44:47.094150
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    from ansible.module_utils.facts.collector import BaseFactCollector
    facts_dict = {}
    base_fact_collector = BaseFactCollector()
    base_fact_collector.populate()
    facts_dict.update(base_fact_collector.facts)

    service_mgr_fact_collector = ServiceMgrFactCollector()

    assert service_mgr_fact_collector.is_systemd_managed(module=base_fact_collector) == True



# Generated at 2022-06-23 01:44:49.776576
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'
    assert obj.required_facts

# Generated at 2022-06-23 01:44:51.724296
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    svc = ServiceMgrFactCollector()
    assert svc.name == 'service_mgr'
    assert 'platform' in svc.required_facts

# Generated at 2022-06-23 01:44:53.195970
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector()

# Generated at 2022-06-23 01:44:59.825364
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # given
    module = MockModule()
    module.run_command = Mock(return_value=('', '', 0))
    # when
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False

    # given
    module = MockModule()
    module.run_command = Mock(return_value=('main.css', '', 0))
    # when
    assert ServiceMgrFactCollector.is_systemd_managed(module) == True


# Generated at 2022-06-23 01:45:10.566203
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import get_collector_instance
    svc = get_collector_instance(
        'ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector'
    )
    class mocked_module(object):
        class AttributeDict(object):
            def __init__(s, **kwargs):
                s.kwargs = kwargs
                s.__dict__ = kwargs
        def __init__(s):
            s.params = s.AttributeDict(**{})
            s.run_command = lambda x: (0, '/sbin/init', '')
            s.get_bin_path = lambda x: True
            s.check_mode = False
        def fail_json(s, **kwargs):
            raise

# Generated at 2022-06-23 01:45:15.324650
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import ModuleFacts

    module = ModuleFacts(
        module_name='test',
        module_args='',
        kwargs='',
        inject=dict()
    )

    module.get_bin_path = lambda x=None: '/bin/some_exe'
    ServiceMgrFactCollector.is_systemd_managed_offline(module)


# Generated at 2022-06-23 01:45:22.353427
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector

    collector = Collector()
    sm = ServiceMgrFactCollector(collector)

    class ModuleMock:
        @staticmethod
        def get_bin_path(path):
            return path

        @staticmethod
        def run_command(command, use_unsafe_shell):
            return (0, "", "")

    module = ModuleMock()

    assert sm.is_systemd_managed(module)


# Generated at 2022-06-23 01:45:25.136750
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # class ServiceMgrFactCollector is tested in unit test file: test/unit/modules/linux/test_linux.py
    pass

# Generated at 2022-06-23 01:45:33.336045
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class ModuleFake:

        def get_bin_path(self, path=''):
            return '/bin/systemctl'

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "ps -p 1 -o comm|tail -n 1":
                return 0, "systemd\n", ""
            elif cmd == "ps -p 1 -o comm":
                return 0, "systemd", ""
            return 255, "", ""

    service_mgr_fc = ServiceMgrFactCollector()
    module = ModuleFake()
    collected_facts = {}
    collected_facts['ansible_distribution'] = 'RedHat'
    collected_facts['ansible_system'] = 'Linux'
    result = service_mgr_fc.collect(module, collected_facts)
    sysvinit

# Generated at 2022-06-23 01:45:39.853499
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector

    # Mock parameters
    module = ansible.module_utils.facts.collector.BaseFactCollector()
    module.get_bin_path = lambda x: '/sbin/systemctl'

    # Run test
    test_result = ServiceMgrFactCollector.is_systemd_managed(module=module)

    assert test_result == False


# Generated at 2022-06-23 01:45:44.895163
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    assert service_mgr_fact_collector.name == "service_mgr"
    assert service_mgr_fact_collector._fact_ids == set()
    assert service_mgr_fact_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:45:49.851799
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    collected_facts = {'ansible_system': 'Linux'}
    class MockModule(object):
        @staticmethod
        def get_bin_path(program):
            if program == 'systemctl':
                return '/bin/systemctl'
            return None
    module = MockModule()
    test_smfc = ServiceMgrFactCollector()
    assert test_smfc.is_systemd_managed(module=module)


# Generated at 2022-06-23 01:45:53.591738
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed(module='something') != 'expected_value'
    assert ServiceMgrFactCollector.is_systemd_managed(module='something') != 'unexpected_value'


# Generated at 2022-06-23 01:45:56.299714
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smc = ServiceMgrFactCollector()
    assert smc.name == 'service_mgr'

# Generated at 2022-06-23 01:46:05.598462
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.utils

    if platform.system() == 'SunOS':
        import unittest
        raise unittest.SkipTest("The distutils module is not shipped with SUNWPython on Solaris.")

    import mock

    from ansible.module_utils.compat.version import LooseVersion

    mock_module = mock.MagicMock()
    mock_get_file_content = mock.MagicMock()
    mock_run_command = mock.MagicMock()
    mock_version = mock.MagicMock()

    # Mocked return values
    mock_get_file_content.return_value = "systemd"

# Generated at 2022-06-23 01:46:12.835227
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class TestModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'

    class TestOs(object):
        def path(self, path):
            return True

    class TestOsModule(object):
        os = TestOs()

    test_module = TestModule()
    collector = ServiceMgrFactCollector(test_module)

    result = collector.is_systemd_managed(test_module)
    assert(result == True)


# Generated at 2022-06-23 01:46:21.817510
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class DummyModule(object):
        def run_command(self, command, use_unsafe_shell=False, check_rc=True, executable=None, data=None):
            return 1, '', ''

        def get_bin_path(self, executable):
            return True

    module = DummyModule()
    service_mgr_fact_collector = ServiceMgrFactCollector(module=module)

    assert service_mgr_fact_collector.is_systemd_managed(module) == True


# Generated at 2022-06-23 01:46:29.572765
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import ModuleBase
    # Test happy path
    if ServiceMgrFactCollector.is_systemd_managed(ModuleBase):
        assert True

    if ServiceMgrFactCollector.is_systemd_managed_offline(ModuleBase):
        assert True

    # Test empty path
    moduleBase = ModuleBase()
    moduleBase.bin_path = None
    if not ServiceMgrFactCollector.is_systemd_managed(moduleBase):
        assert True

    if not ServiceMgrFactCollector.is_systemd_managed_offline(moduleBase):
        assert True

# Generated at 2022-06-23 01:46:40.496664
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import ModuleUtilsLegacyFacts
    import shutil
    ClassServiceMgrFactCollector = ServiceMgrFactCollector()
    class TestModule:

        def run_command(self,args,check_rc=True,close_fds=True,executable=None,data=None,binary_data=False,path_prefix=None,cwd=None,use_unsafe_shell=False,prompt_regex=None, environ_update=None):
            return 0, 'systemd\n', ''
        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/bin/systemctl'

# Generated at 2022-06-23 01:46:47.314244
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return True
            return False
    class Mock(object):
        pass
    x = ServiceMgrFactCollector()
    module = MockModule()
    mock = Mock()
    mock.path = '/tmp/foo'
    mock.checksum = lambda x: 'bar'
    mock.params = {'path': mock.path, 'checksum': 'sha1'}
    mock.run_command = Mock()
    mock.run_command.return_value = ('', '', 0)
    setattr(mock, '_module', module)
    x.collect(mock)
    assert x.is_systemd_managed(MockModule())

# Generated at 2022-06-23 01:46:49.790933
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj1 = ServiceMgrFactCollector()
    assert obj1.name == 'service_mgr'
    assert obj1.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:47:00.027370
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # initialize test classes
    class mod(object):
        def __init__(self):
            self.params = {'gather_subset': '!all', 'gather_timeout': 10, 'filter': 'service_mgr'}
            self.fail_json = lambda **kwargs: False
            self.exit_json = lambda **kwargs: True
            self.run_command = lambda **kwargs: (0, '', '')
            self.get_bin_path = lambda **kwargs: 'True'
    class collected_facts(object):
        def __init__(self):
            self.facts = {'ansible_distribution': 'OpenWrt'}
    # call method
    result = ServiceMgrFactCollector().collect(module=mod(), collected_facts=collected_facts())
    # check result
   

# Generated at 2022-06-23 01:47:03.306102
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector().name == ServiceMgrFactCollector.name
    assert ServiceMgrFactCollector()._fact_ids == set()
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:47:12.174388
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.common._collections_compat import Mapping

    module = type(str('FakeModule'), (), {})()
    module.get_bin_path = lambda _: None
    module.run_command = lambda _, **__: (1, None, None)
    # This value is not important, just faking a class attribute to provide get_file_content()
    module.collector_classes = [get_collector_class('ServiceMgrFactCollector')]

    collector = get_collector_class('ServiceMgrFactCollector')(module=module)
    assert not collector.is_systemd_managed_offline(module=module)

    collector.collector_classes[0]._fact_ids = set()

# Generated at 2022-06-23 01:47:15.165767
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockAnsibleModule()
    collector = ServiceMgrFactCollector(module=module)

    assert collector.is_systemd_managed_offline(module=module) == False


# Generated at 2022-06-23 01:47:25.563943
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.utils.display import Display
    import ansible.module_utils.facts.service_mgr as service_mgr

    class MockModuleBase:
        def get_bin_path(self, cmd):
            return "invalid"

    class MockModule(MockModuleBase):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.display = Display()

    class MockModuleWithSystemd(MockModuleBase):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.display = Display()

        def get_bin_path(self, cmd):
            return "/bin/systemctl"


# Generated at 2022-06-23 01:47:31.252736
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc.name == 'service_mgr'
    assert smfc._fact_ids == set()
    assert smfc.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:47:36.135148
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.system.service_mgr as service_mgr
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    test_fixture = service_mgr.ServiceMgrFactCollector()
    test_fixture.collect()
    assert test_fixture.collect() == test_fixture.collect()

# Generated at 2022-06-23 01:47:41.213536
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    ServiceMgrFactCollector.is_systemd_managed(module)


# Generated at 2022-06-23 01:47:52.252174
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Test that 'service_mgr' is detected as 'openrc' when ansible_system_vendor is 'Gentoo'
    """
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector, test_ServiceMgrFactCollector_collect as test_function
    from ansible.module_utils.facts import FallbackableCollector
    from ansible.module_utils.facts.utils import get_file_content, get_file_lines

    # create mock module
    class Module(object):
        def __init__(self):
            self.run_command = test_function.real_run_command
            self.get_bin_path = test_function.real_get_bin_path

# Generated at 2022-06-23 01:47:59.613466
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """
    Test ServiceMgrFactCollector constructor
    :return:
    """
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'

# Generated at 2022-06-23 01:48:11.878780
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """Unit test for method collect of class ServiceMgrFactCollector"""

    class MockModule(object):
        def __init__(self):
            self.run_command_on_device = None

        def get_bin_path(self, arg):
            return None

    class MockFacts(object):
        def __init__(self, *args):

            distrib = args[0]['distribution']
            system = args[0]['system']

            self._facts = {'ansible_distribution': distrib,
                           'ansible_system': system}

        def __getitem__(self, key):
            return self._facts[key]

        def get(self, key, default):
            return self[key]

    # Test with system 'Linux' and distribution 'RedHat'
    # call method collect and check result

# Generated at 2022-06-23 01:48:22.390435
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    import sys

    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    elif sys.version_info[0] == 3:
        import builtins

    mock_module = mock.Mock()
    mock_module.get_bin_path.return_value = '/usr/bin/systemctl'

    # if /run/systemd/system/ exists, return True
    open_mock = mock.mock_open(read_data='')
    with mock.patch.object(builtins, 'open', open_mock, create=True):
        with mock.patch.object(os.path, 'exists', return_value=True):
            result = ServiceMgrFactCollector.is_systemd_managed(mock_module)
            assert result

    #

# Generated at 2022-06-23 01:48:29.901550
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import ModuleDataCollectorFactory
    from ansible.module_utils.facts.utils import get_file_content

    m = MockModule()
    ModuleDataCollectorFactory.add_default_collectors(m)
    facts = m.get_facts()
    service_mgr = facts.get('service_mgr')

    if get_file_content('/proc/1/comm') == 'systemd':
        assert service_mgr == 'systemd'

# Generated at 2022-06-23 01:48:42.014822
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import is_systemd_managed
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFact
    from ansible.module_utils.facts.system.platform import PlatformFact
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils.facts.utils import CachingFile

# Generated at 2022-06-23 01:48:47.981238
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # /run/systemd/system is exists.
    mock_module = MockModule()
    mock_module.stat_result.st_mode = 17407
    mock_module.stat_result.st_ino = 7
    mock_module.stat_result.st_dev = 21
    mock_module.stat_result.st_nlink = 1
    mock_module.stat_result.st_uid = 0
    mock_module.stat_result.st_gid = 0
    mock_module.stat_result.st_size = 0
    mock_module.stat_result.st_atime = 1557296744
    mock_module.stat_result.st_mtime = 1557296744
    mock_module.stat_result.st_ctime = 1557296744
    service_mgr_fact_collect

# Generated at 2022-06-23 01:48:57.879513
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.utils import MockModule

    class TestClass(object):
        def __init__(self):
            self._cache = {}
            self._verbosity = 0

        def get_bin_path(self, arg):
            if 'systemctl' == arg:
                return '/bin/systemctl'
            return None

    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    test_class_instance = TestClass()
    test_module.run_command = test_class_instance.run_command
    test_module.get_bin_path = test_class_instance.get

# Generated at 2022-06-23 01:49:06.264767
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import shutil
    import tempfile

    from ansible.module_utils.facts import default_collectors

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = dict()
            self.exit_json = dict()

        def get_bin_path(self, app):
            return '/bin/%s' % app

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, cmd, None

    tmpdir = tempfile.mkdtemp()

    # Test 1: /sbin/init is not a symlink to systemd
    os.symlink("/bin/systemd", os.path.join(tmpdir, 'init'))

# Generated at 2022-06-23 01:49:16.027089
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockModule()
    # When /sbin/init is not a symlink and systemd is not installed, the result should be False.
    module.run_command = MagicMock(return_value=(0, "Not systemd", ""))
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)
    # When /sbin/init is a symlink to init and systemd is not installed, the result should be False.
    module.run_command = MagicMock(return_value=(0, "Not systemd", ""))
    module.path_exists = lambda p: p == "/sbin/init"
    module.path_is_symlink = lambda p: p == "/sbin/init"
    module.path_readlink = lambda p: "init"
    assert not ServiceMgrFactCollect

# Generated at 2022-06-23 01:49:24.777393
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def __init__(self, paths, is_systemd_managed_offline_result):
            self.paths = paths
            self.is_systemd_managed_offline_result = is_systemd_managed_offline_result

        def get_bin_path(self, path):
            return self.paths.get(path)

    # Test if systemd is detected when systemctl exists and there's a /run/systemd/system
    module = MockModule(paths={'systemctl' : '/usr/bin/systemctl'}, is_systemd_managed_offline_result=False)


# Generated at 2022-06-23 01:49:30.850863
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector._fact_ids == set()
    assert service_mgr_fact_collector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:49:39.498926
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestModule(object):
        def __init__(self):
            self.params = dict()

        def fail_json(self, **args):
            raise RuntimeError

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return 'systemctl'

    # Test whether the method ServiceMgrFactCollector.is_systemd_managed_offline returns correct value

    # Test 1: Fail to find /sbin/init, and return False
    def is_systemd_managed_offline_test_1():
        test_collector = ServiceMgrFactCollector()
        test_module = TestModule()
        returned_value = test_collector.is_systemd_managed_offline(test_module)


# Generated at 2022-06-23 01:49:49.882614
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    collected_facts = { 'ansible_system': 'Linux' }

    # systemd is available
    basic._ANSIBLE_ARGS = None
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=False)
    module.run_command = lambda *args, **kwargs: (0, '', None)
    module.get_bin_path = lambda *args, **kwargs: get_bin_path('systemctl')
    module.get_bin_path.is_systemd_managed_offline = lambda *args, **kwargs: False
    ServiceMgrFactCollector().collect(collected_facts=collected_facts, module=module)

# Generated at 2022-06-23 01:49:52.493070
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """
    Test constructor of class ServiceMgrFactCollector
    """
    smfc = ServiceMgrFactCollector()
    assert 'service_mgr' == smfc.name

# Generated at 2022-06-23 01:49:56.237838
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    test_obj = ServiceMgrFactCollector()
    assert test_obj is not None
