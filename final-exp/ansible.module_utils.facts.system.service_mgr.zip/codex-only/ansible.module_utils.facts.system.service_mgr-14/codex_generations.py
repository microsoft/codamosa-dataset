

# Generated at 2022-06-23 01:40:03.248535
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = Mock()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False
    module.get_bin_path.return_value = True
    module.run_command.return_value = 0, '/usr/lib/systemd/systemd', None
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == True


# Generated at 2022-06-23 01:40:12.281810
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # test method is_systemd_managed() of class ServiceMgrFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collectors.systemd import SystemdFactCollector
    from ansible.module_utils.facts.collectors.distro import DistributionFactCollector
    from ansible.module_utils.facts.collectors.system import SystemFactCollector
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors.base import BaseFactCollector

    # create test classes
    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        # override
        def collect(self, module=None, collected_facts=None):
            self.module = module

# Generated at 2022-06-23 01:40:13.260184
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    assert ServiceMgrFactCollector.collect() is None

# Generated at 2022-06-23 01:40:18.209251
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # If we create instance of ServiceMgrFactCollector, service_mgr should be
    # in the result even if we don't do anything
    result = ServiceMgrFactCollector.collect()
    assert 'service_mgr' in result



# Generated at 2022-06-23 01:40:22.903357
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mock_module = MockModule()
    mock_module.run_command.return_value = (0, 'init', None)
    facts_dict = ServiceMgrFactCollector().collect(mock_module)
    assert facts_dict['service_mgr'] == 'sysvinit'


# Generated at 2022-06-23 01:40:26.765666
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc.name == 'service_mgr'
    assert smfc._fact_ids == {}
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:40:28.180967
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()
    assert s is not None

# Generated at 2022-06-23 01:40:32.204537
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts import mock_module_instance

    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed_offline(module=mock_module_instance()) == False

# Generated at 2022-06-23 01:40:33.259319
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    print(ServiceMgrFactCollector())

# Generated at 2022-06-23 01:40:43.141018
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class TestModule:
        def get_bin_path(path):
            return path

        def run_command(self, command, use_unsafe_shell=False):
            output = 'COMMAND'
            if command == "ps -p 1 -o comm|tail -n 1":
                output = 'COMMAND'
            return 0, output, ''

    class TestAnsibleModule:
        def __init__(self):
            return

        def get_bin_path(self, filename):
            return filename

    testfacts = {'ansible_distribution': 'MacOSX', 'ansible_system': ''}

    mgr = ServiceMgrFactCollector()
    mgr.collect(module=TestModule(), collected_facts=testfacts)


# Generated at 2022-06-23 01:40:51.097248
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils import basic
    import os

    ServiceMgrFactCollector.is_systemd_managed = staticmethod(lambda x: True)
    ServiceMgrFactCollector.is_systemd_managed_offline = staticmethod(lambda x: False)
    ServiceMgrFactCollector.get_file_content = staticmethod(lambda y: '1')
    ServiceMgrFactCollector.get_bin_path = staticmethod(lambda z: True)

    setattr(os, 'path', MockOSPath)
    setattr(os, 'readlink', MockReadLink)

    collected_facts = ServiceMgrFactCollector.collect()
    assert collected_facts['service_mgr'] == 'systemd'


# Generated at 2022-06-23 01:40:54.635681
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector._fact_ids == set()
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:41:03.174378
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create object to test
    obj = ServiceMgrFactCollector()

    class DummyModule(object):

        def get_bin_path(name):
            # Return None if name is 'systemctl'
            if name == 'systemctl':
                return None
            else:
                return name

        # No need to define 'run_command' method

    # Create a dummy module
    module = DummyModule()
    # method must return False (systemctl is not installed and not running)
    assert obj.is_systemd_managed(module=module) == False

    class DummyModule(object):

        def get_bin_path(name):
            # Return 'systemctl' if name is 'systemctl'
            if name == 'systemctl':
                return 'systemctl'
            else:
                return name

        # No need to define

# Generated at 2022-06-23 01:41:09.577888
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    svc_mgr_collector = ServiceMgrFactCollector()
    # If the required facts are not present, no fact should get collected
    required_facts = svc_mgr_collector.required_facts
    target_facts = svc_mgr_collector.collect(collected_facts={fact : None for fact in required_facts})
    assert not target_facts

# Generated at 2022-06-23 01:41:12.550428
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class Mock(object):
        @staticmethod
        def get_bin_path(cmd):
            return 'systemctl'

    assert ServiceMgrFactCollector.is_systemd_managed_offline(Mock()) == False

# Generated at 2022-06-23 01:41:14.406293
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert type(ServiceMgrFactCollector()) is ServiceMgrFactCollector

# Generated at 2022-06-23 01:41:25.973424
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import platform
    class Empty:
        pass
    ansible_module_rhel_7 = Empty()
    ansible_module_rhel_7.get_bin_path = lambda x: x
    ansible_module_rhel_6 = Empty()
    ansible_module_rhel_6.get_bin_path = lambda x: x
    ansible_module_suse = Empty()
    ansible_module_suse.get_bin_path = lambda x: x
    ansible_module_wrong = Empty()
    ansible_module_wrong.get_bin_path = lambda x: x


    # if /sbin/init is not a symlink, then systemctl is not available
    ansible_module_wrong.run_command = lambda x: (0, '', '')

# Generated at 2022-06-23 01:41:29.620229
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    if platform.system() != 'Linux':
        return
    module = AnsibleModuleStub()
    module.run_command.return_value = (0, '/usr/lib/systemd', None)
    collector = ServiceMgrFactCollector()
    assert(collector.is_systemd_managed(module=module) == True)

# Generated at 2022-06-23 01:41:34.076571
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    distro = ServiceMgrFactCollector()

    assert ServiceMgrFactCollector.__name__ == distro.name
    assert ServiceMgrFactCollector._fact_ids == set(), ServiceMgrFactCollector._fact_ids
    assert distro.required_facts == set(['platform', 'distribution']), distro.required_facts

# Generated at 2022-06-23 01:41:44.983583
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Test sample variation for detecting the init system used
    class ModuleStub(object):
        def __init__(self, return_value):
            self.run_command = lambda x: (0, return_value, '')
            self.get_bin_path = lambda x: '/bin/systemctl'

    # Test 1 - Detect runit
    ServiceMgrFactCollector().collect(ModuleStub('svscan\n'))

    # Test 2 - Detect svc
    ServiceMgrFactCollector().collect(ModuleStub('svscan\n'))

    # Test 3 - Detect systemd
    ServiceMgrFactCollector().collect(ModuleStub('init\n'))

    # Test 4 - Detect sysvinit
    ServiceMgrFactCollector().collect(ModuleStub('init\n'))

# Generated at 2022-06-23 01:41:51.965107
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
  import ansible.module_utils

  class MockModule(object):
    def __init__(self, params):
      self.params = params
      self.fail_json = ansible.module_utils.fail_json
      self.run_command = lambda command, use_unsafe_shell: ('0', 'sysvinit', '')
      self.get_bin_path = lambda path: path

  module = MockModule({})
  s = ServiceMgrFactCollector()
  assert s.collect(module=module, collected_facts={'ansible_system': 'Linux'}) == {'service_mgr': 'sysvinit'}

# Generated at 2022-06-23 01:42:02.218369
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class ModuleMock(object):
        def __init__(self):
            self.run_command = self.run_command_mock
            self.get_bin_path = self.get_bin_path_mock

        def run_command_mock(self, command, use_unsafe_shell=False):
            if command == "ps -p 1 -o comm|tail -n 1":
                return 0, "bash\n", ''
            elif command == "systemctl -V":
                return 0, "systemd 237\n", ''

        def get_bin_path_mock(self, command):
            if command == 'systemctl':
                return '/bin/systemctl'
            elif command == 'bash':
                return '/bin/bash'


# Generated at 2022-06-23 01:42:14.341061
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Unit test for method collect of class ServiceMgrFactCollector
    """

    class MockGetFileContent:
        """
        Mock class for method ansible.module_utils.facts.collector.get_file_content
        """
        def __init__(self):
            pass

        def __call__(self, file):
            """
            Override for method ansible.module_utils.facts.collector.get_file_content
            """
            if file == "/proc/1/comm":
                return "systemd"
            else:
                return None
    class MockModule:
        """
        Mock class for module ansible.modules.system.service_facts
        """
        def __init__(self):
            """
            Constructor for class MockModule
            """
            self.params = {}
            self.exit

# Generated at 2022-06-23 01:42:18.122931
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector.systemd import SystemdFactCollector

    systemd = SystemdFactCollector()
    service_mgr = ServiceMgrFactCollector()

    # Test on a systemd managed system that works.
    facts = dict(ansible_distribution='RedHat')
    systemd_facts = dict(package_mgr='systemd')
    systemd.collect(collected_facts=systemd_facts, module=None)
    assert service_mgr.is_systemd_managed(module=systemd)

    # Test on a systemd managed system that failed.
    facts = dict(ansible_distribution='RedHat')
    systemd_facts = dict(package_mgr='systemd')


# Generated at 2022-06-23 01:42:26.830135
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_host = type('', (), {})
    test_host.get_bin_path = lambda x: None
    test_host.run_command = lambda x, **kw: (0, 'stdout', 'stderr')

    test_host.system = 'SunOS'
    test_facts = {
        'ansible_system': 'SunOS',
        'platform': 'SunOS',
        'distribution': 'SunOS',
    }
    collector = ServiceMgrFactCollector(test_host)
    result = collector.collect(test_host, test_facts)
    assert result == {'service_mgr': 'smf'}

    test_host.system = 'Linux'

# Generated at 2022-06-23 01:42:37.243916
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector
    import mock
    import os

    # set up a mock ansible module
    module = mock.MagicMock()

    # set up a mock command runner
    module.run_command = mock.MagicMock()

    # set up a temproary directory for testing
    test_dir = ansible.module_utils.facts.collector.mkdtemp()

    # create the result of /run/systemd/system
    os.makedirs('{0}/run/systemd/'.format(test_dir))
    os.makedirs('{0}/run/systemd/system'.format(test_dir))

    # ensure that the test directory is serviced before /run

# Generated at 2022-06-23 01:42:38.386605
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()

# Generated at 2022-06-23 01:42:46.912964
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import os
    # Create a directory
    tmpdir = tempfile.mkdtemp()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False
    os.chdir(tmpdir)
    assert os.path.exists('/sbin/init') == True
    assert os.path.islink('/sbin/init') == True
    os.unlink('/sbin/init')
    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is True
    assert os.path.islink('/sbin/init') == True
    os.unlink('/sbin/init')

# Generated at 2022-06-23 01:42:47.848237
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x

# Generated at 2022-06-23 01:42:59.498349
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test_module = type('AnsibleModule', (object,), dict(get_bin_path=lambda self, executable: None))()

    # Test fallback when get_bin_path is None
    service_mgr_fact_collector = ServiceMgrFactCollector()
    if service_mgr_fact_collector.is_systemd_managed(module=test_module):
        raise Exception("Unexpected result: %s" % service_mgr_fact_collector.is_systemd_managed(module=test_module))

    # Test fallback when get_bin_path has systemctl return false
    test_module.get_bin_path = lambda self, executable: False

# Generated at 2022-06-23 01:43:09.264227
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            return None

    class MockFactCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

            self.facts = {}

    mock_module = MockModule()

    # Systemd is running
    mock_fact_collector = MockFactCollector(module=mock_module)
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module) == True

    mock_fact_collector = MockFactCollector

# Generated at 2022-06-23 01:43:18.832543
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import os
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    with tempfile.TemporaryDirectory() as root:
        with open(os.path.join(root, "etc", "os-release"), "w") as f:
            f.write("""
PRETTY_NAME="A test system"
NAME="Test"
ID=test
VARIANT=test
VARIANT_ID=test
VERSION="0"
""")
        os.mkdir(os.path.join(root, "etc", "systemd"))
        os.mkdir(os.path.join(root, "run", "systemd"))

        class FakeModule(object):
            def get_bin_path(self, path):
                return "/bin/systemctl"

       

# Generated at 2022-06-23 01:43:27.809308
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collectors.system.service_mgr import \
            ServiceMgrFactCollector

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict()
    )

    # get the list of functions in the _get_remote_platform method
    # and insert the is_systemd_managed method
    get_remote_platform_method = module.get_bin_path
    methods = [get_remote_platform_method]

    def mockreturn(mname):
        if mname == 'systemctl':
            return '/bin/true'
        else:
            return None

    def mockreturn_nosystemctl(mname):
        if mname == 'systemctl':
            return None
        else:
            return None

    # Unit test

# Generated at 2022-06-23 01:43:37.771985
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import ModuleBase

    def fake_get_bin_path(cmd):
        return '/sbin/' + cmd

    class TestModule(ModuleBase):
        def get_bin_path(self, cmd):
            return fake_get_bin_path(cmd)
    module = TestModule()

    ServiceMgrFactCollector.is_systemd_managed(module)

# Generated at 2022-06-23 01:43:45.228344
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.required_facts = ['platform', 'distribution']
            self.facts = {'platform': 'Linux', 'distribution': 'Ubuntu'}

        def get_bin_path(self, value):
            if value == 'systemctl':
                return '/usr/bin/systemctl'
            elif value == 'initctl':
                return '/usr/bin/initctl'
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=False):
            raise Exception("run_command not implemented")

    class MockLooseVersion:
        def __init__(self, version_string):
            self.version_string = version_string


# Generated at 2022-06-23 01:43:54.493565
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test_module = AnsibleModuleFake({})
    test_ServiceMgrFactCollector = ServiceMgrFactCollector()
    test_true_cases = [
        ('/run/systemd/system/',),
        ('/dev/.run/systemd/',),
        ('/dev/.systemd/',),
    ]
    test_false_cases = [
        ('/dev/systemd/',),
        ('/etc/systemd/',),
    ]
    for case in test_true_cases:
        test_ServiceMgrFactCollector.file_exists = MagicMock(side_effect=[True])
        result = test_ServiceMgrFactCollector.is_systemd_managed(test_module)
        assert result is True
        test_ServiceMgrFactCollector.file_exists.assert_called_

# Generated at 2022-06-23 01:44:05.287101
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class module_test(object):
        class run_command_Test(object):
            def __init__(self, return_value):
                self.return_value = return_value
            def __call__(self, *args, **kwargs):
                return self.return_value

        def __init__(self, systemd_canary):
            self.systemctl_path = '/usr/bin/systemctl'
            self.systemd_canary = systemd_canary
            self.run_command = self.run_command_Test(return_value=(0, '', ''))

        def get_bin_path(self, *args, **kwargs):
            return self.systemctl_path

        def exists_executable(self, *args, **kwargs):
            return True


# Generated at 2022-06-23 01:44:15.966830
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, distribution='Linux', system='Linux'):
            self.params = {}
            self.distribution = distribution
            self.system = system
            self.run_command_splits = []
            self.run_command_rcs = []
            self.run_command_calls = []
            self.run_command_stderrs = []
            self.run_command_outputs = []

        def get_bin_path(self, exe='systemctl'):
            if exe == "systemctl":
                return "/bin/systemctl"

        def fail_json(self, **args):
            raise Exception("failing!")

        def run_command(self, cmd, use_unsafe_shell=False, check_rc=False):
            self.run_command

# Generated at 2022-06-23 01:44:25.269135
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    def mod_exec_module_mock(result=None):
        return dict(changed=False, ansible_facts=result)

    class ModuleMock(object):
        def __init__(self):
            self.run_command = lambda *args: (0, 'test')
            self.get_bin_path = lambda *args: '/bin/systemctl'

    # is_systemd_managed
    class os_mock(object):
        @staticmethod
        def path(path):
            return True

    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.get_file_content = lambda *args: None
    service_mgr_fact_collector.is_systemd_managed(ModuleMock())

# Generated at 2022-06-23 01:44:31.383288
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test cases for method is_systemd_managed.
    # Input value, expected return value
    test_cases = [
        [True, True],
        [False, False]
    ]
    for test_case in test_cases:
        os.path.exists = lambda path: test_case[0]
        assert(test_case[1] == ServiceMgrFactCollector.is_systemd_managed_offline(None))

# Generated at 2022-06-23 01:44:36.942195
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector

    class module():
        def get_bin_path(self, command):
            return '/sbin/systemctl'

    fact_collector = ServiceMgrFactCollector()
    service_mgr = fact_collector.is_systemd_managed_offline(module())
    assert service_mgr == 'systemd'


# Generated at 2022-06-23 01:44:40.340564
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x
    assert x.name == 'service_mgr'
    assert x._fact_ids == set()
    assert x.required_facts == {'distribution', 'platform'}

# Generated at 2022-06-23 01:44:48.959437
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class_method = ServiceMgrFactCollector.is_systemd_managed_offline

    # Test case: SuSE based distro
    module = AnsibleModuleMock(dict(
    ))
    class_method(module)
    assert module.run_command.called
    assert module.run_command.call_args_list[0][0][0] == "ps -p 1 -o comm|tail -n 1"
    assert module.get_bin_path.called
    assert module.get_bin_path.call_args_list[0][0][0] == 'systemctl'



# Generated at 2022-06-23 01:44:52.414502
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    assert 'service_mgr' in service_mgr_fact_collector._fact_ids
    assert set(('platform', 'distribution')) == service_mgr_fact_collector.required_facts



# Generated at 2022-06-23 01:44:55.710708
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import Module
    m = Module()
    assert not ServiceMgrFactCollector.is_systemd_managed(m)


# Generated at 2022-06-23 01:45:05.595578
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr as service_mgr_fact

    # Check if is_systemd_managed return True with given rule
    is_systemd_managed = service_mgr_fact.ServiceMgrFactCollector.is_systemd_managed

    # Mock ansible module
    module = type('ModuleMock', (), {'run_command': lambda self, *args, **kwargs: [0, "/lib/systemd/systemd", ''], 'get_bin_path': lambda self, x: '/usr/bin/systemctl'})()
    assert is_systemd_managed(module) == True

# Generated at 2022-06-23 01:45:15.247926
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance

    # create mock module for use in testing
    class MockModule:
        def __init__(self):
            self.params = {}
            self.run_command = os.system
            self.get_bin_path = os.path
    module = MockModule()
    # use literal string to represent binary output of systemctl
    module.run_command.return_value = ("", "", "")

    # create mock facts for use in testing
    class MockCollector:
        class Fact:
            def __init__(self):
                self.__dict__ = {}
                self.name = ""
                self.__dict__['ansible_facts'] = {}
                self.__dict__['ansible_facts']['service_mgr'] = ''


# Generated at 2022-06-23 01:45:26.808935
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    if platform.system() == 'SunOS':
        return

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.run_command = AnsibleModule.run_command
            self.get_bin_path = AnsibleModule.get_bin_path

    facts = default_collectors['service_mgr'](FakeModule).collect()
    assert 'service_mgr' in facts
    if facts['service_mgr'] == 'systemd':
        assert ServiceMgrFactCollector.is_systemd_managed(FakeModule())
        assert ServiceMgrFactCollector.is_systemd_managed_offline(FakeModule())
        assert not ServiceMgr

# Generated at 2022-06-23 01:45:30.619848
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, bin_path):
            return bin_path

    module = MockModule()

    ServiceMgrFactCollector.is_systemd_managed(module)

# Generated at 2022-06-23 01:45:34.224269
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.system.service_mgr
    test_case = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector()
    test_case.is_systemd_managed_offline()
    test_case.is_systemd_managed_offline(True)

# Generated at 2022-06-23 01:45:41.783762
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import collections
    import ansible.module_utils.facts.collector
    Data = collections.namedtuple('Data', 'ansible_distribution')
    class MockModule:
        def __init__(self):
            self.params = Data(ansible_distribution='MacOSX')
        def get_bin_path(self, path):
            return '/bin/' + path
    module_obj = MockModule()
    result = ServiceMgrFactCollector.collect(module=module_obj, collected_facts={})
    assert 'service_mgr' in result
    assert result['service_mgr'] == 'launchd'


# Generated at 2022-06-23 01:45:48.655838
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = type('test_utils', (object,), {})
    module.run_command = lambda x: (0, "/sbin/init -> systemd\n", None)
    module.get_bin_path = lambda x: "/bin/systemctl"
    mgr = ServiceMgrFactCollector()
    assert mgr.is_systemd_managed_offline(module) is True


# Generated at 2022-06-23 01:46:02.673842
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import os
    import sys
    import platform
    import platform
    import shutil
    import tempfile
    test_dir = tempfile.mkdtemp()

    # create a fake system to test service manager detection on
    os.mkdir(os.path.join(test_dir, 'usr'))
    os.mkdir(os.path.join(test_dir, 'usr', 'bin'))
    os.mkdir(os.path.join(test_dir, 'usr', 'sbin'))
    os.mkdir(os.path.join(test_dir, 'etc'))
    os.mkdir(os.path.join(test_dir, 'sbin'))
    os.mkdir(os.path.join(test_dir, 'proc'))

# Generated at 2022-06-23 01:46:13.768223
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
        assert ServiceMgrFactCollector.is_systemd_managed(MockModule(sysd_bin="/usr/bin/systemctl", runit_dir="/run", file_exists_true=True))
        assert ServiceMgrFactCollector.is_systemd_managed(MockModule(sysd_bin="/usr/bin/systemctl", runit_dir="/run", file_exists_true=False))
        assert ServiceMgrFactCollector.is_systemd_managed(MockModule(sysd_bin="/usr/bin/systemctl", runit_dir="/run", file_exists_true=False))

        assert not ServiceMgrFactCollector.is_systemd_managed(MockModule(sysd_bin=None, runit_dir="/run", file_exists_true=True))
        assert not ServiceMgrFact

# Generated at 2022-06-23 01:46:27.513054
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys
    import os
    import platform
    import tempfile

    # prepare module object
    class Module():
        def __init__(self):
            self.run_command_called = False
            self.get_bin_path_called = False
            self.system = None
            self.distribution = None

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_called = True
            return 0, 'init', None

        def get_bin_path(self, command):
            self.get_bin_path_called = True
            return False

    # prepare collected facts
    class Collected():
        def __init__(self):
            self.ansible_system = None
            self.ansible_distribution = None

    collected = Collected()

    # initialise

# Generated at 2022-06-23 01:46:39.043507
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test for RHEL 7, RHEL 8 and Ubuntu 16.04+
    module = MockModule()
    module.get_bin_path.return_value = '/usr/bin/systemctl'
    module.run_command.return_value = 0, '', ''
    s = ServiceMgrFactCollector()
    assert s.is_systemd_managed(module)

    # Test for RHEL 6
    module.run_command.return_value = 0, '/run/systemd/system/', ''
    assert not s.is_systemd_managed(module)

    # Test for Ubuntu 18.04
    module.run_command.return_value = 0, '/dev/.run/systemd/', ''
    assert s.is_systemd_managed(module)

    # Test for Ubuntu 18.10

# Generated at 2022-06-23 01:46:51.199325
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys
    import io
    import os

    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.utils.module_docs_fragments
    from ansible.utils.module_docs_fragments import get_doc_fragments

    # Create a sys.modules replacement that mocks get_bin_path
    class MockModules(object):
        def __getitem__(self, name):
            if name == 'ansible.module_utils.facts.collector':
                return BaseFactCollector
            elif name == 'ansible.module_utils.facts.collector.BaseFactCollector':
                return BaseFactCollector
            else:
                raise KeyError(name)

        def __setitem__(self, name, object):
            pass


# Generated at 2022-06-23 01:46:53.753580
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    collector = ServiceMgrFactCollector()
    assert isinstance(collector, ServiceMgrFactCollector)
    assert collector.name == 'service_mgr'

# Generated at 2022-06-23 01:46:57.947816
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:47:07.719411
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mock_module = type('', (), {
        'run_command': lambda *args, **kwargs: (0, 'init', ''),
        'get_bin_path': lambda name, opts=None: None,
    })()
    collected_facts = {}
    facts_dict = ServiceMgrFactCollector.collect(mock_module, collected_facts)
    assert 'service_mgr' in facts_dict
    assert facts_dict['service_mgr'] == 'sysvinit'



# Generated at 2022-06-23 01:47:14.332225
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.name == 'service_mgr'
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert fact_collector._fact_ids == set()
    assert ServiceMgrFactCollector._fact_ids == set()
    assert fact_collector.required_facts == set(['platform', 'distribution'])
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:47:24.993595
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):

        def __init__(self):
            self.params = {}
            self.run_command_tests = []
            self.run_command_responses = []
            self.run_command_rcs = []

        def run_command(self, cmd, use_unsafe_shell=False):
            self.run_command_tests.append(cmd)
            return (self.run_command_rcs.pop(0), self.run_command_responses.pop(0), '')

        def get_bin_path(self, cmd):
            for test in self.run_command_tests:
                if test.find(cmd) > -1:
                    return True
            return False

    class MockCollector(object):
        def __init__(self):
            self.collected_facts = {}

# Generated at 2022-06-23 01:47:34.795391
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    tst_collector = get_collector_instance(ServiceMgrFactCollector, {})

    tst_collector._module = None
    assert dict() == tst_collector.collect()

    tst_collector._module = None
    assert dict() == tst_collector.collect(collected_facts={})

# Generated at 2022-06-23 01:47:43.987555
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Import of module_utils.basic not needed in real code
    import ansible.module_utils.basic
    module_mock = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    # Test case for symlink to systemd binary
    test1_module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    if not os.path.exists('/sbin/init_offline'):
        os.symlink('/bin/systemd', '/sbin/init_offline')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(test1_module)

    # Test case for symlink to binary named systemd
    test2_module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
   

# Generated at 2022-06-23 01:47:53.569769
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    '''
    is_systemd_managed_offline:
        expected:
            - True
            - True
            - False
            - False
            - False
            - False
            - False
        value:
            - "/sbin/init"
            - "/usr/lib/systemd/systemd"
            - "/usr/lib/systemd/systemd"
            - "/usr/lib/systemd/systemd "
            - "systemd/"
            - "systemd"
            - "/bin/system"
    '''
    from .test_collector_facts_base import TestBaseFactCollector
    import os
    import json

    # Build mock module
    module = TestBaseFactCollector.mock_module()

    # Build test data

# Generated at 2022-06-23 01:48:02.379961
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    facts_dict = {}

    # boot to an initramfs shell, this should return systemd
    module = FakeAnsibleModule(
        dict(
            ansible_facts=dict(
                ansible_system='Linux',
                ansible_distribution='CentOS',
                ansible_distribution_version='7.2.1511',
                ansible_distribution_release='Core',
                ansible_distribution_major_version='7',
                ansible_distribution_file_parsed=False,
            )
        )
    )
    facts_dict = ServiceMgrFactCollector().collect(module=module, collected_facts=facts_dict)
    assert (facts_dict['service_mgr'] == 'systemd')

    # boot to an initramfs shell, this should return systemd
    module = FakeAns

# Generated at 2022-06-23 01:48:09.924989
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class MockModule(object):
        def get_bin_path(self):
            pass

    obj = ServiceMgrFactCollector()
    module = MockModule()
    obj.module = module
    # Test case: /sbin/init is a symlink to systemd
    obj.run_command = "ps -p 1 -o comm|tail -n 1"
    obj.run_command = ['systemd'], 0, '', ''
    assert obj.is_systemd_managed_offline(module) == True

# Generated at 2022-06-23 01:48:17.804368
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    my_fact_collector = ServiceMgrFactCollector()
    my_module_mock = Mock()

    # no symlink
    my_module_mock.get_bin_path.return_value = '/bin/systemctl'
    my_module_mock.run_command.return_value = (0, '', '')
    assert my_fact_collector.is_systemd_managed_offline(my_module_mock) is False

    # symlink to systemd
    my_module_mock.get_bin_path.return_value = '/bin/systemctl'
    my_module_mock.run_command.return_value = (0, '', '')
    my_module_mock.path_exists.return_value = True
    my_module_mock.os_path

# Generated at 2022-06-23 01:48:23.232226
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import tempfile, os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content, get_bin_path
    from ansible.module_utils.six import b

    tempdir = tempfile.mkdtemp()
    file_path = os.path.join(tempdir, "proc1")

    class MockModule:
        def __init__(self, tempdir=tempdir):
            self.tempdir = tempdir

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return get_bin_path('sh')
            return None


# Generated at 2022-06-23 01:48:34.779009
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Mock module
    module = AnsibleModuleMock()

    # Inputs
    # Set module and collected_facts
    service_mgr_collector = ServiceMgrFactCollector()
    collected_facts = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': 'Linux'
    }

    # Test scenario with ansible_system == Linux
    service_mgr_name = service_mgr_collector.collect(module=module, collected_facts=collected_facts)

    # Assert that the outupt is as expected
    assert service_mgr_name['service_mgr'] == 'upstart'

    # Rest inputs
    # Set module and collected_facts
    service_mgr_collector = ServiceMgrFactCollector()

# Generated at 2022-06-23 01:48:44.690866
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule:
        params = {}
        def get_bin_path(self, appname):
            return appname

    # Import required modules
    from ansible.module_utils.facts import facts as facts_module_utils
    from ansible.module_utils.facts.facts import gather_facts
    from ansible.module_utils.facts.collectors import collector_registry

    # create a fake test repo:
    created_registry = collector_registry.create_registry()

    # initialize test collector
    service_mgr = ServiceMgrFactCollector()

    # initialize fake module
    module = MockModule()

    # get fake facts
    collected_facts = gather_facts(module=module, gathered_subset='all', collected_facts=facts_module_utils)

    # pass fake test case

# Generated at 2022-06-23 01:48:55.108970
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return True
            return False

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            super(ServiceMgrFactCollector, self).__init__(module=module)

    m = MockModule()
    t = TestServiceMgrFactCollector(module=m)

    # create canary
    with open('/dev/.run/systemd/', 'a'):
        os.utime('/dev/.run/systemd/', None)

    assert t.is_systemd_managed(module=m)
    os.remove('/dev/.run/systemd/')
    # returns False if canary not present

# Generated at 2022-06-23 01:49:03.767457
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_col = ServiceMgrFactCollector()
    assert not service_mgr_fact_col._fact_ids

    # TODO: use fixtures or monkeypatch so we don't need to create the entire class
    from ansible.module_utils.facts.collector import Collectors
    Collectors._collectors.append(service_mgr_fact_col)

    # TODO: implement and test
    # service_mgr_fact_col.collect()
    # service_mgr_fact_col.populate()

    # TODO: add test code for detecting service mgr, right now
    # it's all dependent on platform, use mocks to test expected output
    # the tests should raise exceptions if the platform is unexpected

# Generated at 2022-06-23 01:49:14.376260
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr

    test_object = ansible.module_utils.facts.collector.BaseFactCollector()

    test_module = basic.AnsibleModule(
        argument_spec={},
    )
    test_module.get_bin_path = lambda _: "/usr/bin/systemctl"

    test_object = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector()
    test_object.is_systemd_managed_offline(test_module)

    return test_object

# Generated at 2022-06-23 01:49:25.161046
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    # Create a new instance of the collector
    fact_collector = ServiceMgrFactCollector()

    # Create a new instance of the AnsibleModule
    arguments = {}
    ansible_module = FakeAnsibleModule(argument_spec=arguments, supports_check_mode=True)

    # If the AnsibleModule was not called with '--collect-only', then we need to add the collector to the
    # fact_collector
    if not ansible_module.params['collect_only']:
        facts_collector = FactsCollector(ansible_module=ansible_module, collected_facts=None)

        # Add the collector to the facts_collector
        facts_collector.add_collector(fact_collector=fact_collector)

       

# Generated at 2022-06-23 01:49:35.707905
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    import platform
    import os

    # Create a new instance of a module
    module = DummyModule()

    # Create a new instance of a CollectedFacts
    collected_facts = CollectedFacts()

    # Add a distrubution and platform to CollectedFacts
    collected_facts.add('ansible_distribution', 'RedHat')
    collected_facts.add('ansible_system', 'Linux')

    # Create a new instance of a ServiceMgrFactCollector

# Generated at 2022-06-23 01:49:46.786157
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # When the ansible_system fact is not BSD, the service manager is
    # 'service'.
    collected_facts = {
        'ansible_system': 'Linux'
    }
    ServiceMgrFactCollector.is_systemd_managed = lambda *_: False
    ServiceMgrFactCollector.is_systemd_managed_offline = lambda *_: False
    actual = ServiceMgrFactCollector.collect(collected_facts=collected_facts)
    expected = {'service_mgr': 'service'}
    assert actual == expected, actual

    # When the distribution is MacOSX, the service manager is 'systemstarter'
    # if the mac_ver is less than 10.4, and is 'launchd' otherwise.

# Generated at 2022-06-23 01:49:54.742716
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # import module only if running unit test
    import ansible.module_utils.facts.system.service_mgr
    ServiceMgrFactCollector = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector

    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module=MockModule(bin_path='/bin'))
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=MockModule(bin_path='/bin', sbin_init_is_systemd=True))


# Mock ansible.module_utils.basic.AnsibleModule class for unit test

# Generated at 2022-06-23 01:50:02.600852
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Try to detect systemd boot with the systemd canary directory present
    os.path.exists = lambda path: path == "/run/systemd/system/"
    assert ServiceMgrFactCollector.is_systemd_managed(None)

    # Try to detect systemd boot with the systemd canary directory present
    os.path.exists = lambda path: path == "/dev/.run/systemd/"
    assert ServiceMgrFactCollector.is_systemd_managed(None)

    # Try to detect systemd boot with the systemd canary directory present
    os.path.exists = lambda path: path == "/dev/.systemd/"
    assert ServiceMgrFactCollector.is_systemd_managed(None)

    # Try to detect systemd boot with no systemd canary directory present
    os.path.exists = lambda path: False
    assert not ServiceM