

# Generated at 2022-06-23 01:39:59.964967
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc.name == 'service_mgr'
    assert smfc.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-23 01:40:05.663425
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert not ServiceMgrFactCollector.required_facts
    assert ServiceMgrFactCollector._fact_ids == set()
    collect = ServiceMgrFactCollector()
    assert collect.name == 'service_mgr'
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])
    assert set(collect._fact_ids) == set(['service_mgr'])

# Generated at 2022-06-23 01:40:15.590476
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    fake_module = Mock()
    fake_module.get_bin_path.return_value = None
    fake_module.run_command.return_value = (0, 'procd', None)

    my_obj = ServiceMgrFactCollector({})
    result = my_obj.collect(fake_module, {})
    assert result == {'service_mgr': 'openwrt_init'}

    my_obj = ServiceMgrFactCollector({})
    result = my_obj.collect(fake_module, {'ansible_distribution': 'MacOSX'})
    assert result == {'service_mgr': 'launchd'}

    my_obj = ServiceMgrFactCollector({})
    result = my_obj.collect(fake_module, {'ansible_system': 'AIX'})

# Generated at 2022-06-23 01:40:20.072654
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_obj = ServiceMgrFactCollector()
    assert service_mgr_obj.name == 'service_mgr'
    assert service_mgr_obj.collect() == {'service_mgr': 'service'}

# Generated at 2022-06-23 01:40:22.066359
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    this_collector = ServiceMgrFactCollector("Test")
    assert this_collector.name == "Test"

# Generated at 2022-06-23 01:40:31.718344
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import shutil
    import sys
    import ansible.module_utils.basic
    import ansible.module_utils.facts.collectors.service_mgr

    # We need to mock the module parameters, so we can test is_systemd_managed method
    class MockModule:
        def __init__(self, *args, **kwargs):
            self.module_args = dict()

        def get_bin_path(self, arg):
            return 'systemctl'

        def run_command(self, arg, use_unsafe_shell):
            raise NotImplementedError()

    # We need to mock the module parameters, so we can test is_systemd_managed method
    class MockModule2:
        def __init__(self, *args, **kwargs):
            self.module_args = dict()

# Generated at 2022-06-23 01:40:34.513406
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector_obj = ServiceMgrFactCollector()

    # Test ServiceMgrFactCollector method collect
    service_mgr_fact_collector_obj.collect()

# Generated at 2022-06-23 01:40:43.945324
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    MockModule = type('AnsibleModuleMock', (object,), dict(check_mode=False, no_log=False, params={'service_mgr': None}))

    MockModule.get_bin_path = lambda s, command: "/bin/%s" % command

    MockPath = type('PathMock', (object,), dict(exists=lambda s: True))

    MockOs = type('OsMock', (object,), dict(path=MockPath))

    SMFC = ServiceMgrFactCollector()
    SMFC.is_systemd_managed(MockModule)
    assert SMFC.name == 'service_mgr'
    assert SMFC._fact_ids == set()

# Generated at 2022-06-23 01:40:49.332984
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import MockModule
    module = MockModule()
    module.get_bin_path = lambda s: '/bin/systemctl'
    os.path.exists = lambda s: True
    module.run_command = lambda s, use_unsafe_shell: None
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.is_systemd_managed(module) is True


# Generated at 2022-06-23 01:40:52.276412
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    ServiceMgrFactCollector_obj = ServiceMgrFactCollector()
    result = ServiceMgrFactCollector_obj.is_systemd_managed_offline(None)
    assert result == False


# Generated at 2022-06-23 01:41:02.524222
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts.collectors.service import ServiceMgrFactCollector

    test_object = ServiceMgrFactCollector()
    test_module = ansible_local.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    with test_module.mock_command('/bin/systemctl'):
        result = test_object.is_systemd_managed_offline(test_module)
    assert result is False

# Generated at 2022-06-23 01:41:09.430080
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class Module:
        def get_bin_path(self, *args):
            return '/usr/bin/systemctl'

        def run_command(self, *args, **kwargs):
            raise OSError('no such file')
    systemctl_path = ServiceMgrFactCollector.is_systemd_managed(
        module=Module())
    assert systemctl_path == True


# Generated at 2022-06-23 01:41:20.547846
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    collector = Collector()

    # systemd is not running
    collector.module.exit_json = lambda x: None
    assert not ServiceMgrFactCollector.is_systemd_managed(module=collector.module)
    # systemd is running
    collector.module.exit_json = lambda x: x
    assert ServiceMgrFactCollector.is_systemd_managed(module=collector.module)
    # systemctl not installed
    collector.module.get_bin_path = lambda x: None
    assert not ServiceMgrFactCollector.is_systemd_managed(module=collector.module)


# Generated at 2022-06-23 01:41:26.563412
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    ServiceMgrFactCollector.is_systemd_managed = lambda x: False
    ServiceMgrFactCollector.is_systemd_managed_offline = lambda x: True
    assert(ServiceMgrFactCollector.is_systemd_managed_offline(BaseFactCollector))

# Generated at 2022-06-23 01:41:28.495403
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=None) is False

# Generated at 2022-06-23 01:41:34.313128
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    fact_collector = ServiceMgrFactCollector()
    # test case 1
    class module:
        def get_bin_path(self, command):
            return True
    collected_facts = {'ansible_system':'Linux', 'ansible_distribution':'Fedora'}
    module = module()
    facts_dict = fact_collector.collect(module=module, collected_facts=collected_facts)
    assert facts_dict['service_mgr'] == 'systemd'

# Generated at 2022-06-23 01:41:45.749256
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    def mock_get_bin_path(path):
        if path == 'systemctl':
            return True
        else:
            return False

    def mock_is_systemd_managed_offline_os_path_islink(path):
        if path == '/sbin/init':
            return True
        else:
            return False

    def mock_is_systemd_managed_offline_os_readlink(path):
        if path == '/sbin/init':
            return True
        else:
            return False

    def mock_is_systemd_managed_offline_os_path_basename(path):
        if path == '/sbin/init':
            return 'systemd'
        else:
            return False


# Generated at 2022-06-23 01:41:52.136388
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = type('module', (object,), {'get_bin_path': (lambda self, name: True)})
    service_mgr_obj = ServiceMgrFactCollector()
    assert service_mgr_obj.is_systemd_managed_offline(module)

# Generated at 2022-06-23 01:42:02.375611
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    collect_instance = collector.ServiceMgrFactCollector()
    module_mock = basic.AnsibleModule(argument_spec={})

    # mocks
    module_mock.get_bin_path = lambda x: '/bin/systemctl'
    os.path.islink = lambda x: True
    os.readlink = lambda x: '../bin/systemd'

    assert(collect_instance.is_systemd_managed_offline(module=module_mock))

    # mocks
    module_mock.get_bin_path = lambda x: '/bin/systemctl'
    os.path.islink = lambda x: False


# Generated at 2022-06-23 01:42:14.474576
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # import module tools
    from ansible.module_utils.basic import AnsibleModule

    # read the module arguments
    module_args = dict()

    # create a basic module object
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # instantiate the class to be tested
    mgr = ServiceMgrFactCollector()

    # check the main function
    assert not mgr.is_systemd_managed(module=module)

    # patch the module, the module must have a get_bin_path method
    mgr.get_bin_path = lambda x: True

    # patch the module to create the expected file path
    mgr.module.run_command = lambda x: (0, True, None)

    # check the main function

# Generated at 2022-06-23 01:42:19.125395
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # This class is not intended to be tested directly.  Instead, a subclass for the target OS should extend test_ServiceMgrFactCollector_collect
    # and override the get_module method, so that we can test against a mock AnsibleModule instance (mocked to return the required values)
    raise NotImplementedError

# unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:42:24.237335
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import FactsCollector
    service_mgr_collector = ServiceMgrFactCollector()
    facts_collector = FactsCollector()
    facts_collector.collect({})
    facts = facts_collector.get_facts()
    assert(service_mgr_collector.is_systemd_managed({}))

# Generated at 2022-06-23 01:42:27.210637
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'
    assert obj.required_facts == {'platform', 'distribution'}
    assert obj.collect() == {}


# Generated at 2022-06-23 01:42:39.741818
# Unit test for method collect of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:42:43.259924
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    ServiceMgrFactCollector_instance = ServiceMgrFactCollector()
    assert ServiceMgrFactCollector_instance.is_systemd_managed_offline(module=None) == False
    assert ServiceMgrFactCollector_instance.is_systemd_managed_offline(module=n) == False

# Generated at 2022-06-23 01:42:52.509861
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Test that collect() method behaves as expected
    :return:
    """
    test_platform = platform.system()

    mock_module = MockModule({})
    mock_module.run_command.side_effect = [("", "", ""), ("", "", ""), ("", "", ""),
                                           ("", "", ""), ("", "upstart", ""),
                                           ("", "", ""), ("", "", ""), ("", "", ""),
                                           ("", "", ""), ("", "", ""), ("", "", ""),
                                           ("", "", ""), ("", "", ""), ("", "", ""),
                                           ("", "", ""), ("", "", ""), ("", "", "")]

# Generated at 2022-06-23 01:42:59.300421
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts import ModuleConfig
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.service.service_mgr import ServiceMgrFactCollector

    # Create the mock module object
    # The following lines are workarounds for the fact that patch() from unittest.mock cannot patch a method
    # in a class derived from object
    # TODO: Remove with migration of the whole module to Python 3
    try:
        ModuleConfig.get_config_value
    except AttributeError:
        ModuleConfig.get_config_value = object.__getattribute__(ModuleConfig, 'get_config_value')


# Generated at 2022-06-23 01:43:02.644518
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # This method is static, so call it without instantiating the class
    assert ServiceMgrFactCollector.is_systemd_managed_offline() is False
    assert ServiceMgrFactCollector.is_systemd_managed() is False


# Generated at 2022-06-23 01:43:05.241284
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])
    assert ServiceMgrFactCollector.name == 'service_mgr'

# Generated at 2022-06-23 01:43:12.311380
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import ModuleFactsCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Add ServiceMgrFactCollector to the set of fact collectors
    ModuleFactsCollector.add_collector(ServiceMgrFactCollector)

    test_module = AnsibleModuleStub({})

    # Get the facts
    result = ModuleFactsCollector.get_facts(test_module)

    assert 'service_mgr' in result

# Generated at 2022-06-23 01:43:14.495958
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_obj = ServiceMgrFactCollector()
    assert service_mgr_obj.name == 'service_mgr'

# Generated at 2022-06-23 01:43:22.218474
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a class so we can pass the module_executor
    class ClassX(ServiceMgrFactCollector):
        def __init__(self, module_executor):
            ServiceMgrFactCollector.__init__(self, module_executor)

    class mock_module():
        def __init__(self):
            self.params = {}
            self.run_command_patcher = mock.patch('ansible.module_utils.basic.AnsibleModule.run_command')
            self.run_command = self.run_command_patcher.start()
            self.run_command_patcher.stop()

        def get_bin_path(self, _path, required=False, opt_dirs=[]):
            if _path == 'systemctl':
                return '/usr/bin/systemctl'

# Generated at 2022-06-23 01:43:25.493355
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    x = ServiceMgrFactCollector()
    assert x
    assert x.name == 'service_mgr'
    assert x._fact_ids == set()
    assert x.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:43:34.165085
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Get a list of attributes for this class
    ServiceMgrFactCollector_instance = ServiceMgrFactCollector()
    ServiceMgrFactCollector_members = [attr for attr in ServiceMgrFactCollector_instance.__dict__ if attr[:1] != "_"]
    # Remove the get_facts method
    ServiceMgrFactCollector_members.remove("collect")

    facts_module = sys.modules['ansible.module_utils.facts.system.service_mgr']


# Generated at 2022-06-23 01:43:44.373687
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = AnsibleModule(argument_spec={})
    module.exit_json = Mock()
    module.get_bin_path = Mock(return_value=True)

    # Empty case, no files detected
    os.path.exists = Mock(side_effect=False)
    assert ServiceMgrFactCollector.is_systemd_managed(module=module) == False

    # One file detected
    os.path.exists = Mock(side_effect=["a"])
    assert ServiceMgrFactCollector.is_systemd_managed(module=module) == True

    # Two files detected
    os.path.exists = Mock(side_effect=["a", "b"])
    assert ServiceMgrFactCollector.is_systemd_managed(module=module) == True


# Generated at 2022-06-23 01:43:50.425423
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import Collector

    collector = Collector()
    a_collector = BaseFactCollector(collector)
    service_mgr_collector = ServiceMgrFactCollector(a_collector)

    assert service_mgr_collector.is_systemd_managed(a_collector) is False


# Generated at 2022-06-23 01:43:52.355510
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_obj = ServiceMgrFactCollector()
    assert service_obj.__class__.__name__ == 'ServiceMgrFactCollector'

# Generated at 2022-06-23 01:44:03.337110
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils.facts import __file__ as facts_file
    facts_dir = os.path.dirname(facts_file)
    sys_dir = os.path.join(facts_dir, 'systems', 'linux', 'systemd')

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Mock module function
    # 'get_bin_path' is called to check if the "systemctl" command is present
    def mock_get_bin_path(command):
        if command == 'systemctl':
            return '/usr/bin/systemctl'

# Generated at 2022-06-23 01:44:15.294590
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule(object):
        @staticmethod
        def get_bin_path(name, opts=None):
            return True

        def fail_json(self, **kwargs):
            pass

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_or_strict', _uses_shell=False, _raw_params=None):
            return 0, 'systemd', None

    fake_module = FakeModule()

    service_mgr_

# Generated at 2022-06-23 01:44:18.838499
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    mock_module = type('module', (object,), {})()
    service_mgr_collector = ServiceMgrFactCollector()
    assert service_mgr_collector is not None

# Generated at 2022-06-23 01:44:32.722752
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule:
        def __init__(self, name):
            self.name = name

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl' if self.name == 'systemd' else None
            elif name == 'initctl':
                return '/bin/initctl' if self.name == 'upstart' else None
            else:
                return None

        def run_command(self, name, use_unsafe_shell):
            if name == 'ps -p 1 -o comm|tail -n 1':
                if self.name == 'openrc':
                    return 0, 'openrc', None
                elif self.name == 'runit':
                    return 0, 'runit-init', None

# Generated at 2022-06-23 01:44:43.550600
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Test for is_systemd_managed_offline method.
    :return:
    """
    module_obj = object()
    method = ServiceMgrFactCollector.is_systemd_managed_offline
    assert not method(module_obj)

    setattr(module_obj, 'get_bin_path', lambda x: False)
    assert not method(module_obj)

    setattr(module_obj, 'get_bin_path', lambda x: True)
    setattr(os, 'path', type('path', (object,), {
        'exists': lambda path: path == '/sbin/init'
    }))
    setattr(os, 'readlink', lambda path: path)
    assert not method(module_obj)


# Generated at 2022-06-23 01:44:53.108910
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ModuleFactCollector

    class TestServiceMgrCollector(ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module
            super(ServiceMgrFactCollector, self).__init__()

    class MockModule:
        def __init__(self):
            self.params = {}
            self.args = {}

        def get_bin_path(self, name, required=False, opt_dirs=None):
            if name == "systemctl":
                return "/usr/bin"
            return None

    collector = TestServiceMgrCollector(MockModule())

# Generated at 2022-06-23 01:45:03.658412
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import MockModule

    m = MockModule()

    assert ServiceMgrFactCollector.is_systemd_managed_offline(m) == False

    m.set_command_result("which systemctl", 0, "/usr/bin/systemctl")
    m.set_os_path_exists("/usr/bin/systemctl")

    assert ServiceMgrFactCollector.is_systemd_managed_offline(m) == False

    m.set_os_path_exists("/sbin/init")
    m.set_os_path_islink("/sbin/init")

# Generated at 2022-06-23 01:45:08.840521
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    class ModuleMock():
        @staticmethod
        def get_bin_path(exename):
            return '/bin/systemctl'
    module_mock = ModuleMock()

    assert service_mgr_fact_collector.is_systemd_managed_offline(module_mock)

# Generated at 2022-06-23 01:45:17.648405
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class ModuleMock(object):
        def __init__(self, paths):
            self.paths = paths
            self.run_command_calls = 0
            self.run_command_return_value = ''
            self.run_command_fail_once = False

        def get_bin_path(self, name, required=True):
            if name in self.paths:
                return name
            elif required:
                raise ValueError


# Generated at 2022-06-23 01:45:32.573116
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class module_mock:
        def __init__(self):
            self.run_command_result = ('0', '', '')
            self.result = {
                'ansible_facts': {
                    'ansible_system': 'Linux',
                    'ansible_distribution': 'Fedora'
                }
            }

        def run_command(self, cmd, use_unsafe_shell=None):
            return self.run_command_result

    class LooseVersion_mock:
        def __init__(self, ver_str):
            self.version = ver_str

    def readlink_mock(path):
        return '/sbin/init'

    def islink_mock(path):
        return True

    module = module_mock()

    # Checking case with mac osx system (platform.mac

# Generated at 2022-06-23 01:45:39.533245
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # pylint: disable=import-error
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.distribution

    from ansible.module_utils.facts.system import distribution

    # Create a fake module with a stub for its run_command method
    module = type('', tuple(), {'run_command': lambda s,*args,**kwargs: (0, '', '')})

    # the collect method must return the value of the key 'service_mgr'
    obj = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector()
    result = obj.collect(module=module)


# Generated at 2022-06-23 01:45:46.033182
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_obj = ServiceMgrFactCollector()
    assert (service_mgr_obj.name == 'service_mgr')
    assert (service_mgr_obj._fact_ids == set())

# Generated at 2022-06-23 01:45:49.194880
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    package_data = {}
    module = None

    # systemd method is working
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False

    # not systemd method is working
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False

# Generated at 2022-06-23 01:46:02.674619
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CollectorsContainer
    from ansible.module_utils.facts.collector import FactCollectorType
    from ansible.module_utils.facts.collector import _import_collector_class
    from ansible.module_utils.facts.collector import _find_collector_class_files
    from ansible.module_utils.common.process import get_bin_path

    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary):
            if binary == 'systemctl':
                return '/bin/systemctl'
            return None



# Generated at 2022-06-23 01:46:09.874490
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a mock AnsibleModuleClass instance with fake paths to executables
    module = type('AnsibleModule', (), {})
    module.params = {}
    module.exit_json = lambda: None
    module.run_command = lambda cmd: ('', '', '')
    module.get_bin_path = lambda cmd: 'systemctl'

    # systemctl exists, so return True
    assert ServiceMgrFactCollector.is_systemd_managed(module)


# Generated at 2022-06-23 01:46:12.942589
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    collector = ServiceMgrFactCollector()
    # Currently the constructor of a class is not required to return anything.
    # So the assert is commented.
    # assert collector is not None

if __name__ == '__main__':
    test_ServiceMgrFactCollector()

# Generated at 2022-06-23 01:46:20.656909
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    class TestServiceMgrFactCollector(unittest.TestCase):

        def test_collect_returns_dict(self):
            collector = ServiceMgrFactCollector()
            result = collector.collect_now()
            self.assertIsInstance(result, dict)

    unittest.TestLoader().loadTestsFromTestCase(TestServiceMgrFactCollector)

# Generated at 2022-06-23 01:46:29.246098
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    def test_module(**kwargs):
        class MockModule:
            def __init__(self, **kwargs):
                self.params = kwargs

            def get_bin_path(self, executable, required=False, opt_dirs=[]):
                return '/bin/{0}'.format(executable)

            def run_command(self, command, use_unsafe_shell=False):
                if command == 'ps -p 1 -o comm|tail -n 1':
                    return 0, 'init', ''

        return MockModule(**kwargs)

    c = ServiceMgrFactCollector(test_module(
        ansible_distribution='OpenWrt',
        ansible_system='Linux',
    ))
    assert c.collect() == {'service_mgr': 'openwrt_init'}

   

# Generated at 2022-06-23 01:46:40.254595
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Testing when module=None
    assert ServiceMgrFactCollector.collect() == {}

    # Testing when module is not None
    class MockModule:
        def __init__(self):
            self.mock_bin_path = None
        def get_bin_path(self, arg):
            return self.mock_bin_path
        def run_command(self, cmd, use_unsafe_shell=False):
            pass

    mock_module = MockModule()
    mock_module.mock_bin_path = None
    assert ServiceMgrFactCollector.collect(module=mock_module) == {'service_mgr': 'service'}

    mock_module = MockModule()
    mock_module.mock_bin_path = '/usr/bin/systemctl'
    assert ServiceMgrFactCollector.collect

# Generated at 2022-06-23 01:46:42.412093
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    serviceMgrFactCollector = ServiceMgrFactCollector()
    assert serviceMgrFactCollector.name == 'service_mgr'

# Generated at 2022-06-23 01:46:53.037860
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, is_systemd_managed_return_value=None, is_systemd_managed_offline_return_value=None):
            self.params = dict()
            self.params['path'] = ''
            self.params['gather_subset'] = ['all']
            self.params['filter'] = []
            self.is_systemd_managed_return_value = is_systemd_managed_return_value
            self.is_systemd_managed_offline_return_value = is_systemd_managed_offline_return_value

        def get_bin_path(self, name, required=False):
            if name == 'systemctl':
                return 'systemctl'


# Generated at 2022-06-23 01:47:03.096705
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import shutil
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import Mapping

    class MockModule(object):
        def get_bin_path(self, arg):
            return '/bin/systemctl'

    class CollectedFacts(object):
        def __init__(self, module):
            self.module = module

    class MockFile(object):
        def __init__(self, name):
            self.name = name

        def exists(self):
            return True

        def islink(self):
            return True

        def readlink(self):
            return '/sbin/init'


# Generated at 2022-06-23 01:47:12.047189
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        # Override get_file_content with a stub that always returns None
        @staticmethod
        def get_file_content(*args, **kwargs):
            return None
        # Override the parent method to avoid trying to get a module on the filesystem
        def collect(self):
            return
    class TestBaseFactCollector(BaseFactCollector):
        # Override get_file_content with a stub that always returns None
        @staticmethod
        def get_file_content(*args, **kwargs):
            return None

# Generated at 2022-06-23 01:47:16.131711
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class ModulateModule:
        def get_bin_path(self, command):
            return True

    service_mgr_fact = ServiceMgrFactCollector()
    assert not service_mgr_fact.is_systemd_managed_offline(ModulateModule())


# Generated at 2022-06-23 01:47:25.550185
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Unit test for the method is_systemd_managed_offline
    #
    #  Args:
    #    None
    #  Returns:
    #    None

    # Define test variables
    TEST_CASES = [
        # Valid case
        {
            'desc': 'systemd is the boot init system',
            'in_symlink': 'systemd',
            'out': True
        },
        # Valid case
        {
            'desc': 'systemd is not the boot init system',
            'in_symlink': 'inittab',
            'out': False
        }
    ]

    # Import module
    import ansible.module_utils.facts.collector.service_mgr as service_mgr

    # Initialize collector object
    smc = service_mgr.ServiceM

# Generated at 2022-06-23 01:47:37.078518
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = mock.MagicMock()
    module.get_bin_path.return_value = '/bin/systemctl'

    facts_collector = ServiceMgrFactCollector()

    assert facts_collector.is_systemd_managed(module=module) == False
    os.makedirs('/run/systemd/system/')
    assert facts_collector.is_systemd_managed(module=module) == True
    os.removedirs('/run/systemd/system/')
    assert facts_collector.is_systemd_managed(module=module) == False

    os.makedirs('/dev/.run/systemd/')
    assert facts_collector.is_systemd_managed(module=module) == True
    os.removedirs('/dev/.run/systemd/')
    assert facts

# Generated at 2022-06-23 01:47:38.064812
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()

# Generated at 2022-06-23 01:47:49.604957
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Unit test for method collect of class ServiceMgrFactCollector
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import ModuleFacts

    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert_equals = ansible.module_utils.facts.collector.assert_equals

    class TestModule(object):
        # TestModule implements the module API
        def __init__(self):
            pass

        @staticmethod
        def run_command(commands, check_rc=True):
            cmd = " ".join(commands)
            return 0, cmd, ''

        @staticmethod
        def get_bin_path(name, required=False):
            return '/bin/' + name

    def run_test(testcase, expected):
        facts

# Generated at 2022-06-23 01:47:56.519264
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import platform
    import os

    class Platform:
        def __init__(self, platform, distribution, system):
            self.platform = platform
            self.distribution = distribution
            self.system = system

    test_platform = Platform(platform.platform(), platform.linux_distribution(), platform.system())

    class Module:
        def __init__(self, platform):
            self.platform = platform

        def get_bin_path(self, *args, **kwargs):
            return "path"

    class CollectedFacts:
        def __init__(self):
            self.ansible_facts = {}

    class FakeFile:
        def __init__(self, path_exists):
            self.path_exists = path_exists

        def exists(self, path):
            return self.path_exists

   

# Generated at 2022-06-23 01:48:01.748153
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """ Test the method is_systemd_managed_offline from class ServiceMgrFactCollector """
    s = ServiceMgrFactCollector()
    assert s.is_systemd_managed_offline(None) is False
    assert s.is_systemd_managed_offline(s) is False



# Generated at 2022-06-23 01:48:13.011987
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """ Unit test for method is_systemd_managed of class ServiceMgrFactCollector
    """
    # Set up a basic dummy module
    class DummyModule:
        def __init__(self):
            self.run_command = None
        def get_bin_path(self, program):
            if program == 'systemctl':
                return '/usr/bin/systemctl'
    module = DummyModule()

    # Case in which systemd is the boot init system
    m_run_command = lambda _: (0, 'systemd', '')
    module.run_command = m_run_command

    # Test for is_systemd_managed method
    assert ServiceMgrFactCollector.is_systemd_managed(module) is True

    # Case in which systemd is not the boot init system

# Generated at 2022-06-23 01:48:24.299326
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector

    # To test, I create a temp dir which will serve as the temporary root
    # directory.  The temp dir has three subdirs, 'bin', 'sbin' and 'etc'.
    # The 'sbin' subdir contains a symlink to 'bin/systemctl', so that the
    # symlink looks like /sbin/init.
    # The 'etc' subdir contains a symlink to /sbin/init.
    import tempfile
    import shutil
    import ansible.module_utils.facts
    import ansible.module_utils.facts.service_mgr

    tmpdirname = tempfile.mkdtemp()

# Generated at 2022-06-23 01:48:30.040374
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_obj = ServiceMgrFactCollector()
    assert type(service_mgr_obj.required_facts) == set
    assert service_mgr_obj.required_facts == {'platform', 'distribution'}
    assert service_mgr_obj.name == 'service_mgr'
    assert type(service_mgr_obj._fact_ids) == set
    assert service_mgr_obj._fact_ids == set()



# Generated at 2022-06-23 01:48:42.015379
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule:
        def get_bin_path(self, bin_path, opt_dirs=[]):
            if bin_path == "systemctl":
                return True
            else:
                return False

    class MockCollector:
        def __init__(self, module):
            self.module = module

    module = MockModule()
    collector = MockCollector(module)


# Generated at 2022-06-23 01:48:52.059127
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:48:54.717450
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    mgr_fact = ServiceMgrFactCollector.collect()

    assert 'service_mgr' in mgr_fact

# Generated at 2022-06-23 01:49:04.067583
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import sys
    import shutil
    import tempfile
    import subprocess

    try:
        import systemd.journal
    except ImportError:
        # systemd-python package is not installed
        # Skip test
        return

    # Create temporary directory and files
    tmp = tempfile.mkdtemp()
    os.chmod(tmp, 0o755)
    sbin_init_link_filename = os.path.join(tmp, 'sbin', 'init')
    sbin_init_filename = os.path.join(tmp, 'sbin', 'systemd')
    journal_filename = os.path.join(tmp, 'journal', 'journal.json')
    os.makedirs(os.path.join(tmp, 'journal'))

# Generated at 2022-06-23 01:49:11.105209
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # This is not a unit test of a method, but just lints the expected results
    # of the method collect
    mgr = ServiceMgrFactCollector()
    assert mgr.collect() == {'service_mgr': 'service'}

# Generated at 2022-06-23 01:49:21.636924
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class NullModule(object):
        def __init__(self, path=None):
            self.path = path

        def get_bin_path(self, name, *args, **kwargs):
            return self.path

    class Systemd(object):
        def __init__(self, systemctl=True, sbininit=False):
            self.module = NullModule(path=systemctl)
            os.symlink('systemd', '/sbin/init')

        def __enter__(self):
            return self.module

        def __exit__(self, *_):
            os.unlink('/sbin/init')

    class NotSystemd(object):
        def __init__(self, systemctl=True, sbininit=False):
            self.module = NullModule(path=systemctl)

# Generated at 2022-06-23 01:49:26.117355
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """
    Test class constructor of class ServiceMgrFactCollector:
        ServiceMgrFactCollector()
    """
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector._fact_ids == set()
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:49:27.665060
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    ServiceMgrFactCollector.is_systemd_managed()

# Generated at 2022-06-23 01:49:37.175557
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_bin_path
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import search_file
    from ansible.module_utils.facts.utils import get_linux_distribution

# Generated at 2022-06-23 01:49:47.826491
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import os
    import shutil
    import platform

    class MockModule(object):
        def __init__(self, module_name, bin_paths):
            self.module_name = module_name
            self.params = {}
            self.bin_paths = bin_paths

        def get_bin_path(self, binary, required=False, opt_dirs=[]):
            return self.bin_paths[binary]

    temp_dir = tempfile.mkdtemp()
    os.symlink('systemd', os.path.join(temp_dir, 'init'))
    os.symlink('/usr/lib/systemd/systemd', os.path.join(temp_dir, 'systemctl'))

# Generated at 2022-06-23 01:49:52.547908
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == "service_mgr"
    assert service_mgr_fact_collector._fact_ids == set()
    assert service_mgr_fact_collector.required_facts == set(["platform", "distribution"])



# Generated at 2022-06-23 01:50:02.183255
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class DummyModule:
        def __init__(self):
            self.facts = {
                'platform': 'Linux',
                'distribution': 'RedHat',
            }
            self.run_command_environ_update = {}

        def get_bin_path(self, command, opt_dirs=[]):
            return command

        def run_command(self, command, use_unsafe_shell=False):
            return command, command, ''

    class DummySystemdModule(DummyModule):
        def get_bin_path(self, command, opt_dirs=[]):
            if command in ['systemctl', 'initctl']:
                return command
