

# Generated at 2022-06-23 01:40:05.034845
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    '''
    Test ServiceMgrFactCollector
    '''
    svc_mgr_fact_coll = ServiceMgrFactCollector()

    if svc_mgr_fact_coll.name != 'service_mgr':
        print("Unit test has failed in ServiceMgrFactCollector - name")

    if svc_mgr_fact_coll.required_facts != set(['platform', 'distribution']):
        print("Unit test has failed in ServiceMgrFactCollector - required facts")

    if not svc_mgr_fact_coll._fact_ids:
        print("Unit test has failed in ServiceMgrFactCollector - fact ids")


# Generated at 2022-06-23 01:40:15.278258
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    import os

    collected_facts = {}
    collected_facts['ansible_system'] = 'Linux'
    my_module = basic.AnsibleModule(argument_spec={})

    # mock /proc/1/comm file
    my_module._backup_commfile = '/proc/1/comm'
    my_module._create_commfile = True
    my_module.tmpdir = '/tmp/ansible_test_is_systemd_managed'
    os.makedirs(my_module.tmpdir)
    my_module.commfile = my_module.tmpdir + '/comm'

# Generated at 2022-06-23 01:40:26.895950
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    expected_results = {
        '/run/systemd/system/': True,
        '/dev/.run/systemd/': True,
        '/dev/.systemd/': True,
        '/run/openrc/': False,
        '/dev/.openrc/': False,
        '/run/init/': False,
        '/run/dmd/': False,
        '/etc/sysvinit/': False,
        '/init': False,
        '/etc/init.d/': False,
        '/etc/rc.d/init.d/': False,
        '/etc/aix/': False,
        '/var/svc/': False,
    }

    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

    # mock islink to return True when the given path is a key in

# Generated at 2022-06-23 01:40:32.517286
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockModule()
    module.get_bin_path = Mock(return_value=True)
    smfc = ServiceMgrFactCollector()
    smfc._module = module
    os.readlink = Mock(return_value='systemd')
    os.path.islink = Mock(return_value=True)
    assert smfc.is_systemd_managed_offline(module) == True


# Generated at 2022-06-23 01:40:41.089855
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    result = {}
    module = MockModule(result)
    case_platforms = {'Darwin': True, 'Linux': False}
    case_distributions = {'MacOSX': True, 'FreeBSD': False, 'Ubuntu': False}
    for platform, is_platform in case_platforms.items():
        for distribution, is_distribution in case_distributions.items():
            result['ansible_system'] = platform
            result['ansible_distribution'] = distribution
            if is_platform and is_distribution:
                result['ansible_system'] = 'MacOSX'
                result['ansible_distribution'] = 'MacOSX'
                assert ServiceMgrFactCollector.collect(module) == {'service_mgr': 'launchd'}

# Generated at 2022-06-23 01:40:50.186415
# Unit test for method collect of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:40:59.867172
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.six import PY3

    os_path_exists_memo = {}

    class FakeModule(object):
        def get_bin_path(self, arg):
            # Mimics the behavior of module.get_bin_path
            if "systemctl" in arg:
                return True
            else:
                return None

        def run_command(self, arg, use_unsafe_shell=False):
            # Mimics the behavior of module.run_command
            return (0, "", "")


# Generated at 2022-06-23 01:41:06.872785
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Test ServiceMgrFactCollector constructor"""
    s = ServiceMgrFactCollector()
    assert s.name == 'service_mgr'
    assert s._fact_ids == set()
    assert s.required_facts == set(['platform', 'distribution'])


ServiceMgrFactCollector.is_systemd_managed.__dict__['_ansible_test_succeeded'] = True

# Generated at 2022-06-23 01:41:12.781863
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    sm = ServiceMgrFactCollector()
    assert sm
    assert sm.name == 'service_mgr'
    assert sm._fact_ids == set()
    assert sm.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:41:24.671743
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.system.service_mgr
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Create a temporary class that inherits from the module class
    class AnsibleModuleMock():
        def __init__(self, *args, **kwargs):
            pass
        def get_bin_path(self, executable):
            return None

    # Instantiate that class and assign it to a local variable
    module = AnsibleModuleMock()

    # Create an instance of the module that we're testing
    service_mgr = ServiceMgrFactCollector(module=module)

    # Run the code we want to test

# Generated at 2022-06-23 01:41:35.122934
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys
    import tempfile

    # test case 1: /sbin/init is not a symlink to systemd
    sys.modules['ansible.module_utils.facts.collectors.service_mgr'] = None
    sys.modules['ansible.module_utils.facts.system.path'] = None
    sys.modules['ansible.module_utils.facts.system.info'] = None
    sys.modules['ansible.module_utils.facts.system.platform'] = None
    sys.modules['ansible.module_utils.facts.system.distribution'] = None
    sys.modules['ansible.module_utils.common.removed'] = None
    sys.modules['ansible.module_utils.basic'] = None
    sys.modules['ansible.module_utils.facts.utils'] = None
    sys.modules

# Generated at 2022-06-23 01:41:46.172158
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockAnsibleModule()
    collector = ServiceMgrFactCollector()

    # It should return False when /sbin/init is not a symlink
    os.symlink = Mock(return_value=False)
    result = collector.is_systemd_managed_offline(module)
    assert result == False

    # It should return True when /sbin/init is a symlink to systemd
    os.symlink = Mock(return_value=True)
    os.readlink = Mock(return_value='systemd')
    result = collector.is_systemd_managed_offline(module)
    assert result == True

    # It should return False when /sbin/init is not a symlink to systemd
    os.symlink = Mock(return_value=True)

# Generated at 2022-06-23 01:41:55.083146
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class TestModule:
        def get_bin_path(self, command, *args, **kwargs):
            if command == 'systemctl':
                return '/bin/systemctl'
            return None
        @staticmethod
        def run_command(command):
            if command == "ps -p 1 -o comm|tail -n 1":
                return 0, 'systemd\n', None
            return -1, None, None
        @staticmethod
        def is_executable(path):
            return True

    test_module = TestModule()
    test_facts_dict = {}

    service_mgr_fact_collector = ServiceMgrFactCollector()
    result = service_mgr_fact_collector.collect(test_module, test_facts_dict)
    assert result['service_mgr'] == 'systemd'

# Generated at 2022-06-23 01:41:57.707355
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    test_obj = ServiceMgrFactCollector()
    assert test_obj.name == 'service_mgr'
    assert test_obj.required_facts == set(['platform', 'distribution'])
    assert test_obj._fact_ids == set()



# Generated at 2022-06-23 01:42:06.087424
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import AnsibleModuleStub
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Don't test "false" case, since the function's implementation is too brittle
    # instead, test in the Ansible source code using a BSD which doesn't have "systemctl"
    # Don't test "true" case with System.IO.Path.GetTempPath as it returns C:\Users\<UserName>\AppData\Local\Temp on Windows

    #Stub AnsibleModule class
    class AnsibleModuleStubTrue(AnsibleModuleStub):
        def get_bin_path(self, binary):
            return 'C:\\Windows\\system32\\WindowsPowerShell\\v1.0\\powershell.exe'

    assert ServiceMgrFactCollector

# Generated at 2022-06-23 01:42:09.991127
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    mod = mock_module(params={})
    mod.run_command.return_value = (0, "/run/systemd/system/\n", '')
    ServiceMgrFactCollector.is_systemd_managed(mod)


# Generated at 2022-06-23 01:42:12.153189
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    facts_collector = ServiceMgrFactCollector()
    facts_collector.collect(module=None, collected_facts=None)

# Generated at 2022-06-23 01:42:22.482927
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import ModuleFacts
    mf = ModuleFacts()
    smgfc = ServiceMgrFactCollector()

    # Test 1: systemd is not the boot init system and systemctl binary is not present
    assert mf.ansible_facts['service_mgr'] != 'systemd'
    assert mf.ansible_facts['service_mgr'] == 'service'

    # Test 2: systemd is not the boot init system, but systemctl binary is present
    mf.ansible_facts['ansible_system'] = 'Linux'
    assert mf.ansible_facts['ansible_system'] == 'Linux'
    mf.ansible_facts['service_mgr'] = smgfc.is_systemd_managed_offline(mf)
    assert mf.ansible_facts

# Generated at 2022-06-23 01:42:26.298899
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    fc = ServiceMgrFactCollector()
    collected_facts = {'ansible_system': 'Linux'}
    fc.collect(collected_facts=collected_facts)
    assert collected_facts.get('service_mgr') == 'service'

# Generated at 2022-06-23 01:42:36.081301
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Fake module argument
    class Module(object):
        def __init__(self):
            self.get_bin_path = lambda prog: prog

    class CollectedFacts(object):
        def __init__(self):
            setattr(self, 'ansible_distribution', 'OpenWrt')
    module = Module()
    collected_facts = CollectedFacts()

    # Run method and test result
    result = ServiceMgrFactCollector.collect(module, collected_facts)
    assert result['service_mgr'] == 'openwrt_init'

# Generated at 2022-06-23 01:42:44.996714
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils import basic
    from ansible.module_utils.six.moves import StringIO

    # Setup mocks
    module = basic.AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    module.run_command = module.run_command_environ_update = lambda cmd: (0, 'systemd', '')
    module.EXECUTE_MODULE_CACHE[('systemctl', None, None)] = '/bin/systemctl'
    module.EXECUTE_MODULE_CACHE[('/bin/systemctl', None, None)] = '/bin/systemctl'

    # In this case /sbin/init is a symlink to systemd

# Generated at 2022-06-23 01:42:53.766511
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil

    class MockModule():

        def __init__(self, systemctl_found, symlink_source, symlink_expected_result):
            self.systemctl_found = systemctl_found
            self.symlink_source = symlink_source
            self.symlink_expected_result = symlink_expected_result

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            if self.systemctl_found:
                return '/bin/' + executable
            else:
                return None

        def islink(self, path):
            return os.path.islink(path)

        def readlink(self, path):
            return self.symlink_source

    # Run tests
    tempdir = tempfile

# Generated at 2022-06-23 01:42:57.975855
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    a = ServiceMgrFactCollector()
    assert a  # Constructor should return a object if it succeed
    assert a.name == 'service_mgr'
    assert a.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-23 01:43:03.262852
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts import FactCollector

    assert consts.SERVICE_MGR_KEY in Collectors.get_collected_facts(
        FactCollector()).keys()

# Generated at 2022-06-23 01:43:09.005612
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pytest_mode = False
    try:
        import pytest
        pytest_mode = True
    except ImportError:
        pytest_mode = False

    if not pytest_mode:
        return

    res = ServiceMgrFactCollector.collect(module=None, collected_facts=None)
    assert res == {'service_mgr': 'service'}, "service_mgr should be 'service'"

# Generated at 2022-06-23 01:43:18.604230
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    from ansible.module_utils import basic

    collector = ServiceMgrFactCollector()

    assert collector.is_systemd_managed_offline(module = basic.AnsibleModule(argument_spec=dict())) == False

    old_path = os.environ['PATH']
    os.environ['PATH'] = '/sbin:/usr/sbin:/bin:/usr/bin'
    assert collector.is_systemd_managed_offline(module = basic.AnsibleModule(argument_spec=dict())) == False
    os.environ['PATH'] = old_path

    import tempfile
    tmp_file = tempfile.mkstemp(dir='/sbin')
    os.symlink('/bin/systemctl', tmp_file[1])
    old_path = os.environ['PATH']

# Generated at 2022-06-23 01:43:27.648124
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import ansible.module_utils.facts.system.service_mgr
    import copy

    # Create a module mock
    module = type('module', (), {})()

    # Create a class mock
    service_mgr = type('service_mgr', (), {})()

    # Create a module.run_command mock
    def run_command_mock(command, use_unsafe_shell):
        if command == 'cat /proc/1/comm':
            return 0, 'init', ''

    def get_bin_path_mock(binary):
        if binary == 'initctl':
            return 'test/bin/initctl'
        return None

    module.run_command = run_command_mock
    module.get_bin_path = get_bin

# Generated at 2022-06-23 01:43:40.910975
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    import os
    import tempfile
    import shutil
    import pytest


# Generated at 2022-06-23 01:43:52.234625
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import os
    import sys

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs

        def get_bin_path(self, path):
            if path == 'systemctl':
                return '/bin/systemctl'

            return None

        def run_command(self, command, use_unsafe_shell=False):
            if command == 'systemctl list-unit-files':
                return 0, '#systemctl list-unit-files', ''

            return 1, '', ''

    def os_path_exists(path):
        if path == '/bin/systemctl':
            return True

# Generated at 2022-06-23 01:43:59.511010
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module = AnsibleModule(supports_check_mode=False)
    # Mock module.get_bin_path
    # No-op module.run_command
    ServiceMgrFactCollector.is_systemd_managed = lambda: True
    ServiceMgrFactCollector.is_systemd_managed_offline = lambda: True
    service_mgr_fact_collector = ServiceMgrFactCollector(module)
    # Emulate a platform that would trigger the various checks.
    collected_facts = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': 'AIX',
        'ansible_system_vendor': 'Sun Microsystems',
    }
    # Expected result of the collect method in the various cases.

# Generated at 2022-06-23 01:44:08.510789
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import TestModule

    # Define test variables
    class MockTestModule(TestModule):
        def get_bin_path(self, name, required=False):
            if name == 'systemctl':
                return '/bin/systemctl'
            return None

        def run_command(self, cmd, *args, **kwargs):
            if cmd == "ps -p 1 -o comm|tail -n 1":
                return 0, 'init', None
            return 0, '', None

    class MockAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = {}
            self.check_mode = False
            self.debug = False
            self.exit_json = self.exit_json_1

# Generated at 2022-06-23 01:44:15.749183
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_collected_facts = ServiceMgrFactCollector().collect()

    assert isinstance(service_mgr_collected_facts, dict)
    assert isinstance(service_mgr_collected_facts['service_mgr'], str)
    assert service_mgr_collected_facts['service_mgr'] in ['systemd', 'service', 'sysvinit', 'upstart', 'openrc', 'bsdinit', 'src', 'smf', 'launchd', 'systemstarter', 'openwrt_init']

# Generated at 2022-06-23 01:44:20.104614
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module = None
    collected_facts = {}
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.collect(module=module, collected_facts=collected_facts) == {}


# Generated at 2022-06-23 01:44:23.256411
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Arrange
    module = MockModule()
    # Act
    obj = ServiceMgrFactCollector()
    ret_val = obj.is_systemd_managed_offline(module)
    # Assert
    assert ret_val == False



# Generated at 2022-06-23 01:44:24.846700
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'

# Generated at 2022-06-23 01:44:28.686426
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    cm = ServiceMgrFactCollector()
    res = cm.collect(collected_facts={'platform': 'Linux', 'distribution': 'CentOS'})
    assert 'service_mgr' in res
    assert res['service_mgr'] == 'sysvinit'



# Generated at 2022-06-23 01:44:39.078238
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import AnsibleModuleUtils

    ansible_module = AnsibleModuleUtils()
    service_mgr_fact_collector = ServiceMgrFactCollector()

    expected_service_mgr = 'systemd'
    ansible_module.get_bin_path = lambda x: True
    ansible_module.run_command = lambda x: (1, '/run/systemd/system/', '')
    service_mgr = service_mgr_fact_collector.is_systemd_managed(ansible_module)
    assert service_mgr == expected_service_mgr, 'Expected service_mgr "{0}", got "{1}".'.format(expected_service_mgr, service_mgr)

    expected_service_mgr = 'systemd'
    ansible_

# Generated at 2022-06-23 01:44:46.621735
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule

    # Create a mock object for Ansible module.
    module = MockModule()
    module.run_command = Mock(
        return_value=(0, "/sbin/init", None))
    module.get_bin_path = Mock(
        return_value=True)
    module.os_path_exists = Mock(
        side_effect=[True, True, True, True, True, True, True, True,
                     True, True, True, True, True])
    module.os_path_islink = Mock(
        return_value=True)

    service_mgr_fc = ServiceMgrFactCollector()
    actual = service_mgr_fc.collect(module=module, collected_facts={})

# Generated at 2022-06-23 01:44:53.543499
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    '''
    Unit test function.
    '''
    import ansible.module_utils.facts.collectors.service_mgr
    ServiceMgrFactCollector = ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector

    fake_ansible_module = object()
    fake_collector = ServiceMgrFactCollector()

    facts_dict = fake_collector.collect(
        module=fake_ansible_module,
        collected_facts={'ansible_distribution': 'MacOSX'})

    assert 'ansible_service_mgr' in facts_dict
    assert 'ansible_distribution' in facts_dict

# Generated at 2022-06-23 01:45:00.680400
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # If the following call to service_mgr_fact_collector.collect() returns None,
    # it means ServiceMgrFactCollector.collect() is a broken method that should be
    # tested better. If a dictionary is returned, it means the method works as it
    # should and is ready to be tested along with the rest of the module.
    service_mgr_fact_collector = ServiceMgrFactCollector()
    return service_mgr_fact_collector.collect()


# Generated at 2022-06-23 01:45:08.211972
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.processor.service_mgr import ServiceMgrFactCollector

    class _MockModule:
        def get_bin_path(self, _):
            return '/bin/systemctl'

    assert ServiceMgrFactCollector.is_systemd_managed_offline(_MockModule()) is False
    os.symlink('systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(_MockModule()) is True
    os.remove('/sbin/init')

# Generated at 2022-06-23 01:45:17.172849
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockModule()
    collector = ServiceMgrFactCollector()

    with patch('os.path.islink', return_value=True):
        with patch('os.readlink', return_value='systemd'):
            result = collector.is_systemd_managed_offline(module)
            assert result == True

    with patch('os.path.islink', return_value=False):
        with patch('os.readlink', return_value=True):
            result = collector.is_systemd_managed_offline(module)
            assert result == False

    with patch('os.path.islink', return_value=True):
        with patch('os.readlink', return_value='upstart'):
            result = collector.is_systemd_managed_offline(module)
            assert result == False


# Unit

# Generated at 2022-06-23 01:45:28.200584
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class ModuleFake(object):
        def get_bin_path(self, executable):
            return executable

    module = ModuleFake()
    service_mgr_collector = ServiceMgrFactCollector()

    # scenario: /sbin/init is a symlink to systemd
    os.symlink('systemd', '/sbin/init')
    is_systemd_managed = service_mgr_collector.is_systemd_managed_offline(module)
    assert is_systemd_managed is True
    os.unlink('/sbin/init')

    # scenario: /sbin/init does not exist
    is_systemd_managed = service_mgr_collector.is_systemd_managed_offline(module)
    assert is_systemd_managed is False

    # scenario: /sbin/init is

# Generated at 2022-06-23 01:45:35.118839
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.required_facts == set(['platform', 'distribution']), \
        'required facts are not correct'


# Generated at 2022-06-23 01:45:46.620908
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil

    # imports that are required for the method is_systemd_managed_offline to work
    import platform
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.utils
    from ansible.module_utils.facts.utils import get_file_content

    # create a directory to mimic files under /sbin
    path = tempfile.mkdtemp()

# Generated at 2022-06-23 01:45:56.329397
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    # test_ServiceMgrFactCollector.__doc__
    assert ServiceMgrFactCollector.__doc__

    # test_ServiceMgrFactCollector.name
    assert ServiceMgrFactCollector.name == 'service_mgr'

    # test_ServiceMgrFactCollector._fact_ids
    assert ServiceMgrFactCollector._fact_ids == set()

    ServiceMgrFactCollector()

    # test_ServiceMgrFactCollector.is_systemd_managed()
    assert ServiceMgrFactCollector.is_systemd_managed(module=None) == False

    # test_ServiceMgrFactCollector.is_systemd_managed_offline()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=None) == False

# Generated at 2022-06-23 01:45:57.764721
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.name == 'service_mgr'

# Generated at 2022-06-23 01:46:04.298382
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    mock_module = type('AnsibleModule', (object,), dict(run_command=lambda *args, **kwargs: (0, 'init', '')))()
    mock_module.get_bin_path = lambda *args, **kwargs: None
    mock_facts = dict()
    sut = ServiceMgrFactCollector(mock_module, mock_facts)
    assert sut.collect()['service_mgr'] == 'sysvinit'
    mock_module.run_command = lambda *args, **kwargs: (0, 'systemd', '')
    assert sut.collect()['service_mgr'] == 'systemd'

# Generated at 2022-06-23 01:46:14.869126
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule:
        def get_bin_path(self, _):
            return 'systemctl'

    class MockAnsibleModule:
        def __init__(self):
            self.params = {}

    import os
    original_systemd_canaries = os.path.exists.__globals__['_systemd_canaries']
    os.path.exists.__globals__['_systemd_canaries'] = None

    m = MockModule()
    true_canary = '1_true_canary'
    false_canary = '1_false_canary'
    os.path.exists.__globals__['_systemd_canaries'] = {true_canary: True, false_canary: False}
    assert ServiceMgrFactCollector.is_systemd_managed

# Generated at 2022-06-23 01:46:27.520911
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    ##########################################################################
    # Test case: file /run/systemd/system exists

    class TestModule():
        def get_bin_path(self, executable, required=False):
            assert executable == 'systemctl'
            return '/bin/systemctl'

    collector = ServiceMgrFactCollector()
    result = collector.is_systemd_managed(module=TestModule())

    assert result == True

    ##########################################################################
    # Test case: file /dev/.run/systemd/ exists

    class TestModule():
        def get_bin_path(self, executable, required=False):
            assert executable == 'systemctl'
            return '/bin/systemctl'

    collector = ServiceMgrFactCollector()
    result = collector.is_systemd_managed(module=TestModule())

    assert result == True

    #

# Generated at 2022-06-23 01:46:32.359745
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    obj  = ServiceMgrFactCollector()

    assert obj.name == "service_mgr"
    assert obj.required_facts == set(['platform', 'distribution'])
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:46:39.624552
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from mock import patch, PropertyMock
    class MockModule(object):
        def __init__():
            pass
        def get_bin_path(self, path):
            return "/sbin/init"
    module = MockModule
    with patch.object(os.path, 'islink', new=PropertyMock(return_value=True)), \
         patch.object(os, 'readlink', new=PropertyMock(return_value="systemd")):
        assert ServiceMgrFactCollector.is_systemd_managed_offline(module=module)

# Generated at 2022-06-23 01:46:46.229701
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    sys_init = '/sbin/init'
    sys_init_systemd = 'systemd'

    # is_systemd_managed_offline should return False with sys_init_systemd
    assert ServiceMgrFactCollector().is_systemd_managed_offline(sys_init_systemd) is False

# Generated at 2022-06-23 01:46:50.786993
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    m = __import__("ansible.module_utils.facts.collector.service_mgr")
    s = m.service_mgr.ServiceMgrFactCollector()
    assert not s.is_systemd_managed_offline(None)

# Generated at 2022-06-23 01:47:00.999015
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import mock

    sut = ServiceMgrFactCollector()

    import tempfile
    init_link = tempfile.mktemp()

    mock_module = mock.MagicMock()
    mock_module.get_bin_path.return_value = True

    with mock.patch('os.path.islink') as mock_islink:
        with mock.patch('os.readlink') as mock_readlink:
            with mock.patch('os.remove') as mock_remove:
                # Case 1: target of /sbin/init is not systemd
                mock_islink.return_value = True
                mock_readlink.return_value = '/bin/bash'
                assert not sut.is_systemd_managed_offline(module=mock_module)

                # Case 2: /sbin/init doesn't exist
               

# Generated at 2022-06-23 01:47:06.934888
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mock_module = type('', (), {'get_bin_path': lambda x: None, 'run_command': lambda x, y: (0, '', '')})
    mock_collectfacts = {'platform': 'Linux', 'ansible_distribution': 'CentOS'}

    test_obj = ServiceMgrFactCollector()
    assert test_obj.collect(mock_module, mock_collectfacts) == {'service_mgr': 'sysvinit'}


# Generated at 2022-06-23 01:47:15.820915
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    ServiceMgrFactCollector_obj = ServiceMgrFactCollector()

    # results for True
    for system in ['Linux']:
        for distribution in ['CentOS', 'Debian', 'Arch', 'RHEL', 'SLES', 'SLED', 'openSUSE', 'FreeBSD', 'OpenBSD']:
            module_obj = MockModule(system, distribution)
            assert ServiceMgrFactCollector_obj.is_systemd_managed(module_obj)

    # results for False
    for system in ['AIX', 'SunOS']:
        for distribution in ['Solaris10']:
            module_obj = MockModule(system, distribution)
            assert not ServiceMgrFactCollector_obj.is_systemd_managed(module_obj)



# Generated at 2022-06-23 01:47:20.626128
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module_mock = MockAnsibleModule()
    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed_offline(module_mock) == False

# Create a class MockAnsibleModule with a method 'get_bin_path' which returns the
# expected value when the 'systemctl' paramater is passed.

# Generated at 2022-06-23 01:47:26.976999
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    collector = ServiceMgrFactCollector()
    # Create a module_mock, that can return the /sbin/init symlink when asked.
    module_mock = BaseFactCollector()
    module_mock.get_bin_path = lambda x:x
    # Set-up the symlink
    os.symlink('systemd', '/sbin/init')
    assert collector.is_systemd_managed_offline(module_mock)
    # Clean-up
    os.unlink('/sbin/init')

# Generated at 2022-06-23 01:47:31.532624
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    o = ServiceMgrFactCollector()
    assert o.name == 'service_mgr'
    assert o.required_facts == set(['platform', 'distribution'])



# Generated at 2022-06-23 01:47:33.792044
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    result = False
    obj = ServiceMgrFactCollector()
    assert obj.is_systemd_managed_offline() == result

# Generated at 2022-06-23 01:47:44.574932
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    module_mock = Mock(path_exists=Mock(return_value=True),
                       get_bin_path=Mock(return_value=True),
                       run_command=Mock(return_value=(0, "", "")),
                       params=Mock(return_value=""),
                       fail_json=Mock())

    ansible_module_mock = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': '',
        'platform': '',
    }

    # Test when ansible_distribution is MacOSX
    service_mgr_collector_obj = ServiceMgrFactCollector()
    assert 'launchd' == service_mgr_collector_obj.collect(module_mock, ansible_module_mock)['service_mgr']

   

# Generated at 2022-06-23 01:47:58.741140
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import FactsFilesWrapper
    from ansible.module_utils.facts.fact_cache import FactCache
    from ansible.module_utils.six.moves import mock
    from ansible.module_utils.basic import AnsibleModule

    # Case 1:
    # /sbin/init does not exist
    # /sbin/init is not a symlink to systemd
    # init is not systemd managed
    m = mock.mock_open()

# Generated at 2022-06-23 01:48:01.044325
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fc = ServiceMgrFactCollector()
    assert not fc.is_systemd_managed_offline(None)

# Generated at 2022-06-23 01:48:12.966424
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    class MockModule:
        def get_bin_path(self, app):
            if app == 'systemctl':
                return '/bin/systemctl'
            else:
                return

    module = MockModule()
    collector = ServiceMgrFactCollector()

    # Test for condition where init is not a symlink to systemd
    os.symlink('/bin/foo', '/sbin/init')
    assert collector.is_systemd_managed_offline(module) is False

    # Test for condition where init is a symlink to systemd
    os.unlink('/sbin/init')
    os.symlink('/bin/systemd', '/sbin/init')

# Generated at 2022-06-23 01:48:20.135809
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        """Mock module."""

        def __init__(self):
            """Init function."""
            self.params = {}
            self.args = 'args'
            self.exit_json = lambda x: True

        def get_bin_path(self, path):
            """Mock get bin path."""
            if path == 'systemctl':
                return path
            else:
                return None

    class MockFacts(object):
        """Mock facts."""

        def __init__(self):
            """Init function."""
            self.ansible_distribution = None
            self.ansible_system = None

    MockFacts.ansible_distribution = 'linux'
    MockFacts.ansible_system = 'linux'
    collector_mock = ServiceMgrFactCollector

# Generated at 2022-06-23 01:48:32.048216
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockedModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, cmd, opt_dirs=[]):
            return '/bin/test'

    class MockedCollectedFacts(object):
        def __init__(self):
            self._facts_dict = {
                'platform': 'SunOS',
                'distribution': 'Solaris',
                'ansible_system': 'SunOS',
            }

        def __getitem__(self, key):
            return self._facts_dict[key]

    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.collect(MockedModule(), MockedCollectedFacts()) == {
        'service_mgr': 'smf',
    }

# Generated at 2022-06-23 01:48:37.086221
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule:
        def get_bin_path(self, command):
            return True

    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = MockModule()
    assert service_mgr_fact_collector.is_systemd_managed(module) == True

# Generated at 2022-06-23 01:48:44.507332
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    class ArgvCollector(ServiceMgrFactCollector):
        name = 'argv'
        _fact_ids = set()
        required_facts = set()

        def collect(self, module=None, collected_facts=None):
            return {'argv': module.params['_ansible_argv']}

    # Setup the argument spec
    argv = []
    argv.append('ansible')
    argv.append('-m')
    argv.append('test_module')
    argv.append('-a')
    argv.append('"arg1=value1"')
    argv.append('-a')
    argv.append('"arg2=value2"')

    module = basic

# Generated at 2022-06-23 01:48:47.489714
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    obj = ServiceMgrFactCollector()
    assert obj.name == 'service_mgr'
    assert obj._fact_ids == set()
    assert obj.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:48:58.075994
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class AnsibleModuleMock(object):
        def __init__(self):
            self.path = '/usr/bin'

        def get_bin_path(self, file_name):
            return self.path + '/' + file_name

    test_cases = [
        ('systemd', True),
        ('another', False),
        ('sysvinit', False),
        ('openrc', False),
    ]

    for expected_return, system_name in test_cases:
        ansible_module_mock = AnsibleModuleMock()
        ansible_module_mock.path = '/usr/bin'

# Generated at 2022-06-23 01:49:04.726081
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    def mock_get_bin_path(binary_name):
        if binary_name != "systemctl":
            return ""
        return "/bin/systemctl"

    def mock_run_command(cmd, use_unsafe_shell=None):
        return 0, "/sbin/init", ""

    class FakeModule():
        def __init__(self):
            self.run_command = mock_run_command
            self.get_bin_path = mock_get_bin_path

    module = FakeModule()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)

# Generated at 2022-06-23 01:49:13.078778
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    module_mock = type('module', (), {
        'get_bin_path': lambda self, arg: arg,
        'run_command': lambda self, arg, arg2: (0, '', ''),
        'check_mode': False,
        'debug': False,
        'log': False,
        'warn': False,
        'fail_json': lambda self, **kwargs: False,
    })

    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.get_service_mgr(module_mock) == 'service'

# Generated at 2022-06-23 01:49:23.014488
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    test_cases = {
        '/sbin/init': True,
        'init': True,
        'systemd': True,
        '/sbin/open_wrt_init': False,
        'open_wrt_init': False,
        123: False,
        ' ': False,
        '': False,
    }

    for init_path, expected_result in test_cases.items():
        fake_module = FakeAnsibleModule(dict(init_path=init_path, read_path='/sbin/init', return_value=''))
        result = ServiceMgrFactCollector.is_systemd_managed_offline(fake_module)

# Generated at 2022-06-23 01:49:26.440427
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    test ServiceMgrFactCollector.is_systemd_managed_offline().
    """

    from ansible.module_utils.facts.collector import DummyModule

    module = DummyModule()

    ServiceMgrFactCollector.is_systemd_managed_offline(module=module)
    assert module.run_command.call_args[0][0] == "ps -p 1 -o comm|tail -n 1"

# Generated at 2022-06-23 01:49:30.510096
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_collector_obj = ServiceMgrFactCollector()
    assert service_mgr_collector_obj.name == 'service_mgr'
    assert service_mgr_collector_obj.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:49:34.851786
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    print('Executing mock test for ServiceMgrFactCollector constructor')
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector._fact_ids is not None
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])


# Generated at 2022-06-23 01:49:46.207744
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class Module(object):
        def get_bin_path(self, program):
            return '/usr/bin/' + program
    module = Module()

    # Simulate that systemctl is not available
    def get_file_content_mock(path):
        if path == '/proc/1/comm':
            return 'init\n'
        return None
    ServiceMgrFactCollector.is_systemd_managed.func_globals['get_file_content'] = get_file_content_mock
    assert ServiceMgrFactCollector.is_systemd_managed(module) is False

    # Simulate that /run/systemd/system exists
    def os_path_exists_mock(path):
        if path == '/run/systemd/system/':
            return True

# Generated at 2022-06-23 01:49:50.919617
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    with patch('ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed_offline', return_value=True):
        result = ServiceMgrFactCollector.is_systemd_managed_offline(None)
        assert result == True
    return True


# Generated at 2022-06-23 01:49:52.697070
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    assert ServiceMgrFactCollector.collect()['service_mgr'] is not None

# Generated at 2022-06-23 01:49:57.673052
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.name == 'service_mgr'
    assert fact_collector.fact_ids == set(['service_mgr'])