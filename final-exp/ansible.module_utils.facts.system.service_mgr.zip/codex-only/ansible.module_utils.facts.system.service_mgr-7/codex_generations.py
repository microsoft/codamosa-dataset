

# Generated at 2022-06-23 01:39:58.734050
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x
    assert x.name == 'service_mgr'
    assert x._fact_ids is not None
    assert x.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:40:06.841354
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    mock = type('MockModule', (), {'get_bin_path': lambda self, prog: None})()
    collector = ServiceMgrFactCollector()
    assert collector.collect() == {'service_mgr': 'service'}
    assert collector.collect(module=mock, collected_facts={'ansible_distribution': 'MacOSX', 'ansible_system': 'Darwin'}) == {'service_mgr': 'launchd'}
    assert collector.collect(module=mock, collected_facts={'ansible_system': 'FreeBSD'}) == {'service_mgr': 'bsdinit'}
    assert collector.collect(module=mock, collected_facts={'ansible_system': 'Bitrig'}) == {'service_mgr': 'bsdinit'}

# Generated at 2022-06-23 01:40:10.952447
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    service_mgr = ServiceMgrFactCollector()

    assert service_mgr.name == 'service_mgr'
    assert service_mgr.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:40:18.120018
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    smfc = ServiceMgrFactCollector()

    class FakeModule:
        def get_bin_path(self, name):
            if name == "systemctl":
                return "/usr/bin/systemctl"
            return None

    fake_module = FakeModule()

    with patch("os.path.islink", return_value=True):
        with patch("os.readlink", return_value="systemd"):
            assert True == smfc.is_systemd_managed_offline(fake_module)

    with patch("os.path.islink", return_value=False):
        assert False == smfc.is_systemd_managed_offline(fake_module)


# Generated at 2022-06-23 01:40:28.370887
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.facts = {}

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == "systemctl":
                return "/bin/systemctl"
            return None

        def run_command(self, cmd, use_unsafe_shell=True):
            if cmd == "ps -p 1 -o comm|tail -n 1":
                return 0, "init", ""
            return 0, "", ""

    mmodule = MockModule()

    collector = ServiceMgrFactCollector()
    collector.collect(mmodule, {})

    assert mmodule.facts['service_mgr'] == 'sysvinit'
    assert collector._fact_ids == {'service_mgr'}

# Generated at 2022-06-23 01:40:37.057164
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    import pytest

    class Module(object):

        def __init__(self, params=None):
            self.params = params or {}
            self.run_command_calls = []
            self.run_command_string = ""
            self.run_command_rc = 0
            self.run_command_stdout = ""
            self.run_command_stderr = ""

        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                rc =  0
            elif cmd == 'initctl':
                rc = 1
            else:
                rc = None

            return rc

        def run_command(self, args, use_unsafe_shell=False):
            self.run_command_calls.append(True)
            self.run_command_string = args


# Generated at 2022-06-23 01:40:46.144380
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    ServiceMgrFactCollector._fact_ids = []  # to prevent the execution of collect function while testing the method is_systemd_managed
    ServiceMgrFactCollector._fact_ids.append('service_mgr')
    test_instance = ServiceMgrFactCollector()
    with mock.patch("ansible.module_utils.facts.collectors.service_mgr.os.path.exists") as mock_exists:
        mock_exists.return_value = False

# Generated at 2022-06-23 01:40:58.944777
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.service_mgr
    import ansible.module_utils.facts.utils

    def is_systemd_managed(module):
        return ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector.is_systemd_managed(module)

    class A:
        pass

    class M:
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name):
            if name == 'systemctl':
                return self.bin_path
            raise Exception('unexpected call of get_bin_path with %s' % (name,))

        def run_command(self, *args, **kwargs):
            raise Exception('unexpected call of run_command')



# Generated at 2022-06-23 01:41:00.500461
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector



# Generated at 2022-06-23 01:41:03.397653
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Return ServiceMgrFactCollector object
    :return: ServiceMgrFactCollector object
    :rtype: object
    """
    return ServiceMgrFactCollector()



# Generated at 2022-06-23 01:41:07.623316
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector()
    assert s.name == 'service_mgr'
    assert s.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:41:09.450850
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector().is_systemd_managed_offline(module=None) == False


# Generated at 2022-06-23 01:41:14.742888
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import basic

    # Test for openwrt_init
    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda args, **kwargs: (0, '/sbin/init', '')
    module.get_bin_path = lambda args: '/bin/systemctl'

    assert ServiceMgrFactCollector.is_systemd_managed(module) == True


# Generated at 2022-06-23 01:41:26.295117
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import get_file_content

    class CustomModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path_orig(self, executable, opts=None, required=False, environ=None):
            return '/usr/bin/systemctl'

        get_bin_path = get_bin_path_orig

    # the /sbin/init is a symlink to systemd
    def os_path_islink_orig(path):
        return True


# Generated at 2022-06-23 01:41:37.071680
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create an instance of a dummy module.
    test_module = DummyAnsibleModule()

    # Create an instance of a dummy module.
    # test_module = DummyAnsibleModule()

    # Create an instance of ServiceMgrFactCollector
    svc_mgr_facts_collector = ServiceMgrFactCollector
    test_ansible_system = 'Linux'
    test_ansible_distribution = 'RedHat'
    test_ansible_facts = {'ansible_system': test_ansible_system, 'ansible_distribution': test_ansible_distribution}

    # Obtain a service manager name
    service_mgr_name = svc_mgr_facts_collector.collect(module=test_module, collected_facts=test_ansible_facts).get('service_mgr')

# Generated at 2022-06-23 01:41:42.224549
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    test_collector = ServiceMgrFactCollector()

    is_systemd_managed_offline_output = test_collector.is_systemd_managed_offline(None)

    assert is_systemd_managed_offline_output == False

# Generated at 2022-06-23 01:41:51.343481
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """ test_ServiceMgrFactCollector_collect
    Unit test for method collect of class ServiceMgrFactCollector
    """
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collectors.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule

    facts = Facts()

    mock_module = MockModule(add_ansible_supported_python=False)
    mock_module.add_module_methods(facts)
    mock_module.params = {}

    ServiceMgrFactCollector(mock_module, facts).collect()

    assert isinstance(facts.dict(), dict)

# Generated at 2022-06-23 01:42:01.694464
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    collector = ServiceMgrFactCollector()
    ansible_facts = {}

    # test with systemd
    module = MockModule()
    module.run_command.return_value = (0, "/lib/systemd/systemd")
    collected_facts = collector.collect(module=module)
    assert collected_facts['service_mgr'] == 'systemd'

    # test with sysvinit
    module = MockModule()
    module.run_command.return_value = (0, "/sbin/init")
    collected_facts = collector.collect(module=module)
    assert collected_facts['service_mgr'] == 'sysvinit'

    # test with MacOSX
    module = MockModule()
    ansible_facts['ansible_distribution'] = "MacOSX"

# Generated at 2022-06-23 01:42:04.023389
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    SMFC = ServiceMgrFactCollector()
    assert SMFC.is_systemd_managed_offline({}) is False



# Generated at 2022-06-23 01:42:10.445694
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector._fact_ids == set()
    assert service_mgr_fact_collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-23 01:42:20.881149
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts import ModuleDummy

    # Pretend we run systemd
    is_systemd_managed_offline_dummy = lambda self, module: True
    ServiceMgrFactCollector.is_systemd_managed_offline = is_systemd_managed_offline_dummy
    module = ModuleDummy()
    assert (get_collector_class("service_mgr")().is_systemd_managed_offline(module) == True)

    # Pretend we run sysvinit
    is_systemd_managed_offline_dummy = lambda self, module: False
    ServiceMgrFactCollect

# Generated at 2022-06-23 01:42:28.412246
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    module = MockModule()
    s = ServiceMgrFactCollector(module=module)
    assert s.name == 'service_mgr'
    assert s.required_facts == set(['platform', 'distribution'])
    assert s._fact_ids == set()
    assert ServiceMgrFactCollector._fact_id == 'service_mgr'
    assert ServiceMgrFactCollector._fact_ids == set(['service_mgr'])

# Tests for is_systemd_managed method of class ServiceMgrFactCollector

# Generated at 2022-06-23 01:42:39.816647
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # Extend base class and mock imports
    import __builtin__
    import mock

    class mock_module(object):

        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, arguments, use_unsafe_shell=False):
            return 1, "", ""

        def get_bin_path(self, executable=None, required=False, opt_dirs=[]):
            if executable == 'systemctl':
                return '/usr/bin/systemctl'
            else:
                return None

    class mock_platform(object):
        system = 'linux'

    class mock_os(object):

        def path_exists(self, path):
            if path == '/run/systemd/system/':
                return True

# Generated at 2022-06-23 01:42:49.889920
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule, MockFile
    from ansible.module_utils.facts.utils import AnsibleFactCollector

    import sys
    mock_module = MockModule(collector_class=ServiceMgrFactCollector,
                             required_facts=ServiceMgrFactCollector.required_facts,
                             ignored_facts=[])
    mock_file = MockFile('/proc/1/comm', 'systemd\n')
    mock_file.mock = True
    sys.modules['__main__'].__file__ = 'unitTest'

# Generated at 2022-06-23 01:42:57.652797
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Test case for proc_1='init'
    module = MockModule()
    module.get_bin_path_mock.return_value = None
    delattr(os, 'readlink')
    with patch('ansible.module_utils.facts.collector.get_file_content', Mock(return_value='init')):
        fact_collector = ServiceMgrFactCollector()
        facts_dict = fact_collector.collect(module=module)
        assert facts_dict['service_mgr'] == 'service'

    # Test case for proc_1='busybox'
    module = MockModule()
    module.get_bin_path_mock.return_value = None
    delattr(os, 'readlink')

# Generated at 2022-06-23 01:43:00.237253
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()


# Generated at 2022-06-23 01:43:02.604036
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.name == "service_mgr"

# Generated at 2022-06-23 01:43:05.314897
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    sm = ServiceMgrFactCollector()
    ret = sm.collect()
    assert ret['service_mgr']

# Generated at 2022-06-23 01:43:14.834001
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class Module:
        def get_bin_path(self, path):
            return True

    service_mgr = ServiceMgrFactCollector()

    # When `/sbin/init` is a symlink
    def mock_os_path_islink(foo):
        return True

    def mock_os_readlink(foo):
        return '/lib/systemd/systemd'

    module = Module()
    setattr(module, 'get_bin_path', mock_os_path_islink)
    setattr(module, 'readlink', mock_os_readlink)
    assert service_mgr.is_systemd_managed_offline(module)

    # When `/sbin/init` is absent
    def mock_os_path_islink(foo):
        return False


# Generated at 2022-06-23 01:43:24.489450
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_data = list()
    test_data.append({
        u"ansible_facts": {
            u"ansible_distribution": u"MacOSX",
            u"ansible_system": u"Darwin"
        },
        u"ansible_version": {
            u"full": u"2.7.11",
            u"major": 2,
            u"minor": 7,
            u"revision": 11,
            u"string": u"2.7.11"
        },
        u"changed": False
    })

# Generated at 2022-06-23 01:43:26.962842
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:43:31.417343
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """
    Unit test for constructor of class ServiceMgrFactCollector
    """
    collector = ServiceMgrFactCollector()

    # test default value of attributes
    assert collector.name == 'service_mgr'
    assert collector._fact_ids == set()
    assert collector.required_facts == set(['platform', 'distribution'])
    assert collector.collect() == {}

# Generated at 2022-06-23 01:43:38.538364
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Unit test for constructor of class ServiceMgrFactCollector"""
    # Test without params
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr is not None

    # Test with params
    params = set()
    service_mgr = ServiceMgrFactCollector(params)
    assert service_mgr is not None


# Generated at 2022-06-23 01:43:49.070518
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    fact_collector = ServiceMgrFactCollector()

    if platform.system() == 'Linux':
        # Mock service_mgr variable
        fact_collector.service_mgr = None

        # Mock module variable
        module = Mock(name='module')
        module.run_command.return_value = (0, '', '') # No stdout, no stderr

        # Mock is_systemd_managed and is_systemd_managed_offline method
        fact_collector.is_systemd_managed = Mock(name='is_systemd_managed')
        fact_collector.is_systemd_managed.return_value = False
        fact_collector.is_systemd_managed_offline = Mock(name='is_systemd_managed_offline')
        fact_collector.is_systemd_managed

# Generated at 2022-06-23 01:43:56.895569
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from mock import patch, MagicMock
    import platform

    module = MagicMock()
    get_bin_path_mock = MagicMock()
    module.get_bin_path = get_bin_path_mock
    get_bin_path_mock.return_value = 'systemctl'
    os_path_islink_mock = MagicMock()
    os.path.islink = os_path_islink_mock
    os_path_readlink_mock = MagicMock()
    os.path.readlink = os_path_readlink_mock

    # mocking os.path.islink() return value
    os_path_islink_mock.return_value = True

    # mocking os.path.readlink() return value
    os_path_readlink_mock.return_value

# Generated at 2022-06-23 01:44:04.735209
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import MockModule
    module = MockModule()
    module.get_bin_path = lambda cmd: cmd # For this test, just return the command
    collector = ServiceMgrFactCollector()
    assert not collector.is_systemd_managed(module)
    os.makedirs('/run/systemd/system')
    assert collector.is_systemd_managed(module)
    os.removedirs('/run/systemd/system')
    assert not collector.is_systemd_managed(module)

    os.makedirs('/dev/.run/systemd/')
    assert collector.is_systemd_managed(module)
    os.removedirs('/dev/.run/systemd/')
    assert not collector.is_systemd_managed(module)

    os

# Generated at 2022-06-23 01:44:11.070746
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    svc_mgr_fact_collector = ServiceMgrFactCollector()
    assert svc_mgr_fact_collector.name == 'service_mgr'
    assert svc_mgr_fact_collector._fact_ids == set()
    assert svc_mgr_fact_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:44:20.398940
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class TestModule:
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, executable):
            return self.path if executable == 'systemctl' else None

    # If systemd is not installed, is_systemd_managed_offline should return False
    module = TestModule(None)
    collector = ServiceMgrFactCollector()
    assert not collector.is_systemd_managed_offline(module)

    # If /sbin/init is a symlink to systemd, is_systemd_managed_offline should return True
    module = TestModule('/usr/bin/systemctl')
    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed_offline(module)

# Generated at 2022-06-23 01:44:27.904934
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import json
    import sys


# Generated at 2022-06-23 01:44:31.333880
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    collector = ServiceMgrFactCollector()
    assert collector.name == 'service_mgr'
    assert collector._fact_ids == set()
    assert collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:44:40.969422
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import shutil

    systemd_canaries = ["/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"]

    class MockModule(object):
        def get_bin_path(self, command):
            if command == 'systemctl':
                return 'systemctl'

    class MockOs(object):
        def path_exists(self, path):
            return path in systemd_canaries

    tmpdir = tempfile.mkdtemp()
    for canary in systemd_canaries:
        os.makedirs(tmpdir + canary)

    m = MockModule()
    o = MockOs()
    sm = ServiceMgrFactCollector()
    os.path.exists = o.path_exists

# Generated at 2022-06-23 01:44:43.597189
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    f = ServiceMgrFactCollector()
    assert f.name == 'service_mgr'
    assert 'service_mgr' in f._fact_ids



# Generated at 2022-06-23 01:44:50.122808
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ModuleFactCollector

    module = ModuleFactCollector()

    result = ServiceMgrFactCollector.is_systemd_managed_offline(module)
    assert(result == False)

# Generated at 2022-06-23 01:44:58.567429
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """This test case checks that the collect method of the ServiceMgrFactCollector class
    returns the correct values when run on a Linux system on which systemd is not the
    system service manager."""
    from ansible.module_utils.facts import Collector

    test_collector = Collector()
    collected_facts = test_collector.collect(module=None)
    test_collector.populate()

    facts_dict = ServiceMgrFactCollector.collect(test_collector, collected_facts)

    assert facts_dict['service_mgr'] == 'systemd'


# Generated at 2022-06-23 01:45:04.437349
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    serviceMgrFactCollector = ServiceMgrFactCollector()
    class mymodule:
        def get_bin_path(path):
            return None
    assert not serviceMgrFactCollector.is_systemd_managed_offline(mymodule)
    assert serviceMgrFactCollector.is_systemd_managed_offline(mymodule)

# Generated at 2022-06-23 01:45:08.369409
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    collector = ServiceMgrFactCollector()
    result = collector.is_systemd_managed_offline(module=module)
    assert result == False

# Generated at 2022-06-23 01:45:17.332840
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts import FallbackModuleUtilsModule
    from ansible.module_utils.facts.utils import load_platform_subclass

    class TestModule(FallbackModuleUtilsModule):
        """ Test class for method is_systemd_managed_offline of ServiceMgrFactCollector
        """
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)
            self.platform = 'Linux'

    # systemd_managed = True
    module = TestModule(argument_spec={})
    module.run_command = lambda *args, **kwargs: (0, "/sbin/init -> /usr/lib/systemd/systemd", "")

# Generated at 2022-06-23 01:45:32.573517
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import unittest
    import os
    import shutil
    import tempfile
    import sys

    class AnsibleModuleMock:

        # "AnsibleModule" class has access to the same name space as the module being tested.
        # This makes it easy to access variables in the module.
        def __init__(self, param):
            self.params = param
            self.exit_json = lambda x, y: sys.exit(0)
            self.fail_json = lambda x, y: sys.exit(1)
            self.tmpdir = tempfile.mkdtemp()
        # end of constructor

        def get_bin_path(self, executable):
            if os.path.exists(self.tmpdir + '/' + executable):
                return self.tmpdir + '/' + executable
            else:
                return None


# Generated at 2022-06-23 01:45:40.500042
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Test if is_systemd_managed_offline() method of ServiceMgrFactCollector class returns correct result
    """
    import mock
    import platform
    import os

    if platform.system() != 'SunOS':
        from ansible.module_utils.compat.version import LooseVersion

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.service_mgr.systemd import ServiceMgrFactCollector
    from ansible.module_utils.facts.service_mgr.systemd import ServiceMgrModule

    # Create mock of module
    module = ServiceMgrModule()
    module.run_command = mock.Mock(return_value=(0, None, None))

    # Create mock

# Generated at 2022-06-23 01:45:45.423375
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:45:53.475953
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Test that the method 'is_systemd_managed_offline()' of the class
    'ServiceMgrFactCollector' returns the correct value.
    """
    module = MockModule(fake_bin_path=None)
    collector = ServiceMgrFactCollector.is_systemd_managed_offline(module=module)
    assert not collector, "is_systemd_managed_offline() should return False when systemctl is missing"

    module = MockModule(fake_bin_path='systemctl')
    collector = ServiceMgrFactCollector.is_systemd_managed_offline(module=module)
    assert collector, "is_systemd_managed_offline() should return True when systemctl is present"

# Mock class of AnsibleModule
# Used in the unit tests

# Generated at 2022-06-23 01:46:02.599416
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    def get_bin_path_side_effect(arg):
        if arg == 'systemctl':
            return '/bin/systemctl'
        else:
            return None

    module = Mock()
    module.run_command.return_value = (0, '\nopenrc', '')
    module.get_bin_path.side_effect = get_bin_path_side_effect
    collected_facts = {'ansible_system': 'Linux'}

    service_mgr_collector = ServiceMgrFactCollector()
    result = service_mgr_collector.collect(module, collected_facts)

    assert result == {'service_mgr': 'openrc'}



# Generated at 2022-06-23 01:46:13.723260
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Collect facts
    if platform.system() == 'SunOS':
        # The distutils module is not shipped with SUNWPython (Solaris)
        # It's in the SUNWPython-devel package which also contains
        # development files that don't belong on production boxes.
        # This fact should not exist, and thus there is no test to run.
        pass
    else:
        import mock
        import subprocess
        import sys

        if sys.version_info[0] == 2:
            builtin_module_name = '__builtin__'
        else:
            builtin_module_name = 'builtins'

        fl = ServiceMgrFactCollector()
        fl.collect()

        # Check service_mgr

# Generated at 2022-06-23 01:46:18.373274
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()

# Generated at 2022-06-23 01:46:27.727102
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    try:
        import ansible.module_utils.basic
    except ImportError:
        print("could not import ansible.module_utils.basic, skipping test_ServiceMgrFactCollector_is_systemd_managed_offline")
        return
    class TestModule(object):
        def get_bin_path(self, cmd):
            return '/bin/systemctl'
    module = TestModule()
    fact_collector = ServiceMgrFactCollector()
    assert( fact_collector.is_systemd_managed_offline(module=module) )

    # test does not exist
    class TestModule(object):
        def get_bin_path(self, cmd):
            return None
    module = TestModule()
    fact_collector = ServiceMgrFactCollector()

# Generated at 2022-06-23 01:46:36.371301
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create a stubbed module
    module = type('module', (object,), {
        'run_command': lambda cmd, use_unsafe_shell=True, *args, **kwargs: (0, "/run/systemd/system/", ""),
        'get_bin_path': lambda cmd, *args, **kwargs: True
    })

    service_mgr_collector = ServiceMgrFactCollector()
    is_systemd_managed = service_mgr_collector.is_systemd_managed(module)

    assert is_systemd_managed is True


# Generated at 2022-06-23 01:46:45.650721
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    from ansible.module_utils.facts.collector import ModuleStub

    fake_module = ModuleStub(
        {
            'EXECUTE_SUDO': True,
        }
    )

    fake_bin_paths = {
        'systemctl': '/usr/bin/systemctl',
    }

    fake_module.get_bin_path = lambda x: fake_bin_paths.get(x)

    assert ServiceMgrFactCollector.is_systemd_managed_offline(fake_module) == False

    os.symlink('/bin/systemd', '/sbin/init')
    os.makedirs('/dev/.systemd/', exist_ok=True)

    assert ServiceMgrFactCollector.is_systemd_managed_offline(fake_module) == True


# Generated at 2022-06-23 01:46:54.622130
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # NOTE(aarefiev): mock module is the only way to perform self test
    #                 because of specific of module loading
    #                 pylint: disable=import-error
    from ansible.module_utils import basic
    import os

    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda cmd, shell: (0, '/sbin/init', None) if cmd == "readlink /sbin/init" else (1, None, None)
    module.get_bin_path = lambda name: os.path.abspath(__file__)

    # testing for existance of systemd
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=module)

    # testing for nonexistance of systemd

# Generated at 2022-06-23 01:47:02.816228
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Calls to is_systemd_managed must produce the correct results
    class ModuleMock(object):
        def __init__(self):
            self.paths = ['/usr/bin', '/bin', '/usr/sbin', '/sbin']
        def get_bin_path(self, binary):
            return '/usr/bin/' + binary
    class FactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.module = ModuleMock()
            return
    fc = FactCollector()
    class OsMock(object):
        def exists(self, path):
            if path == '/run/systemd/system/':
                return True
            if path == '/dev/.run/systemd/':
                return False
            if path == '/dev/.systemd/':
                return False


# Generated at 2022-06-23 01:47:06.136280
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """Test method is_systemd_managed_offline of class ServiceMgrFactCollector
    """
    # Test with a dummy module
    module = 'test_module'
    ServiceMgrFactCollector.is_systemd_managed_offline(module)

# Generated at 2022-06-23 01:47:15.220403
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """Tests method is_systemd_managed of class ServiceMgrFactCollector."""
    collector = ServiceMgrFactCollector()
    class FakeOsPath(object):
        @staticmethod
        def exists(path):
            if path == '/run/systemd/system/':
                return True
            else:
                return False
    collector.os_path = FakeOsPath()
    class FakeModule(object):
        @staticmethod
        def get_bin_path(command):
            if command == 'systemctl':
                return '/usr/bin/' + command
    collector.module = FakeModule()
    assert collector.is_systemd_managed(FakeModule()) == True

# Generated at 2022-06-23 01:47:25.607429
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    import platform
    import os
    import shutil

    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.compat.version import LooseVersion

    # Fake module object
    class TestModule():
        def __init__(self, params=None):
            self.params = params or {}

        def run_command(self, cmd, check_rc=None, use_unsafe_shell=False):
            return 0, "", ""

        def fail_json(self, **kwargs):
            raise Exception(kwargs.get("msg"))


# Generated at 2022-06-23 01:47:35.285651
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector.systemd import SystemdFactCollector
    # Reset the cached values
    SystemdFactCollector._fact_ids = set()
    SystemdFactCollector.collect = lambda self, module=None, collected_facts=None: {'systemd_within_docker': False}
    assert ServiceMgrFactCollector.is_systemd_managed(None) == False


# Generated at 2022-06-23 01:47:44.015872
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Verify that the method returns a dictionary
    def fake_find_executable(name, executable_only=False):
        return '/usr/bin/' + name

    def fake_run_command(cmd, use_unsafe_shell=False):
        return (1, '/etc/init/', '')

    def fake_get_file_content(path):
        return 'init\n'

    ServiceMgrFactCollector.is_systemd_managed = staticmethod(lambda x: False)
    ServiceMgrFactCollector.is_systemd_managed_offline = staticmethod(lambda x: False)

    collected_facts = dict(ansible_distribution='OpenWrt',
                           ansible_system='Linux',
                           platform='Linux')

# Generated at 2022-06-23 01:47:52.900816
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import unittest
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils

    class AnsibleModuleMock(object):
        def __init__(self):
            self.args = None
            self.basic = None
            self.check_mode = False
            self.change_caused_reboot = False
            self.changed = False
            self.client = None
            self.command = None
            self.debug = False
            self.deprecations = None
            self.desired_invocation_unit = None
            self.diff = False
            self.exit_json = None
            self.fail_json = None
            self.faild_conditions = None
            self.has_

# Generated at 2022-06-23 01:48:06.239290
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class MockModule:

        def __init__(self):
            self.params = {}

        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/sbin/systemctl'
            else:
                return None

    def mock_os_path_islink(path):
        return path == '/sbin/init'

    def mock_os_readlink(path):
        if path == '/sbin/init':
            return 'systemd'
        else:
            return path

    global os
    os = None
    global os_path_islink
    os_path_islink = mock_os_path_islink
    global os_readlink
    os_readlink = mock_os_readlink

    # Setting up the mock
    mocked_module = MockModule()

# Generated at 2022-06-23 01:48:15.983265
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    def get_bin_path_mock(name, required=True):
        get_bin_path.name = name
        if name == 'systemctl':
            return 'true'
        elif name == 'initctl':
            return 'true'
        else:
            return None
    def run_command_mock(command, check_rc=None, use_unsafe_shell=None):
        return 0, '', ''
    def get_file_content_mock(filename):
        if filename == '/proc/1/comm':
            return None

# Generated at 2022-06-23 01:48:25.281220
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class MockModule(object):
        def get_bin_path(self, name, opts=None):
            return '/bin/systemctl'

    module = MockModule()
    fact = ServiceMgrFactCollector()
    if os.path.exists('/sbin/init'):
        old_init = os.readlink('/sbin/init')
        old_init_target = os.path.basename(old_init)
    os.symlink('/bin/systemctl', '/sbin/init')
    result = fact.is_systemd_managed_offline(module)
    assert result is True
    if os.path.exists('/sbin/init'):
        os.unlink('/sbin/init')
    if os.path.exists(old_init):
        os.syml

# Generated at 2022-06-23 01:48:33.926347
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil
    import contextlib
    import subprocess

    setup_dir = "/sbin"
    os.makedirs(setup_dir)
    file_name = os.path.join(setup_dir, "init")
    test_data = [
        ("init", False),
        ("systemd", True),
        ("foobar", False)
    ]
    
    shutil.rmtree(setup_dir, ignore_errors=True)

    for item in test_data:
        with contextlib.suppress(OSError), open(file_name, 'w') as link:
            link.write("%s" % item[0])


# Generated at 2022-06-23 01:48:39.122196
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = FakeModule({'path': '/bin:/usr/bin:/sbin:/usr/sbin'})
    failed = 'Service manager could not be determined.  Please file a bug report against this module.'
    module.fail_json.assert_called_with(msg=failed)
    ServiceMgrFactCollector.is_systemd_managed(module)


# Generated at 2022-06-23 01:48:45.642851
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic

    class DummyModule():
        def __init__(self):
            self.exit_json = basic.AnsibleModule.exit_json
            self.fail_json = basic.AnsibleModule.fail_json

        def get_bin_path(self, cmd):
            return None

    class CollectedFacts():
        def __init__(self, params):
            self.ansible_facts = {
                'ansible_system': params['ansible_system'],
                'ansible_distribution': params['ansible_distribution'],
            }

    collected_facts = CollectedFacts({
        'ansible_system': 'Linux',
        'ansible_distribution': 'Arch',
    })
    smfc = ServiceMgrFactCollector()
    facts = sm

# Generated at 2022-06-23 01:48:52.101217
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    class Module(object):

        def get_bin_path(self, command):
            return '/bin/systemctl'

    fake_module = Module()
    assert ServiceMgrFactCollector.is_systemd_managed(fake_module) == False

    class Module(object):

        def get_bin_path(self, command):
            return '/bin/systemctl'

    fake_module = Module()
    assert ServiceMgrFactCollector.is_systemd_managed(fake_module) == False



# Generated at 2022-06-23 01:48:53.638225
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass



# Generated at 2022-06-23 01:49:01.793626
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    fact_collector = ServiceMgrFactCollector()
    module = MockModule()
    module.get_bin_path = lambda prog: '/bin/%s' % prog

    # is_systemd_managed_offline should return false if the /sbin/init symlink does not exist
    assert not fact_collector.is_systemd_managed_offline(module)

    # is_systemd_managed_offline should return false if the /sbin/init symlink is not a symlink
    os.symlink('/bin/sh', '/sbin/init')
    assert not fact_collector.is_systemd_managed_offline(module)

    # is_systemd_managed_offline should return false if the /sbin/init symlink does not point to systemd

# Generated at 2022-06-23 01:49:15.150542
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    # create instance of ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector is not None

    # test that instance is ServiceMgrFactCollector
    assert isinstance(service_mgr_fact_collector, ServiceMgrFactCollector)

    # check collect function returns string
    assert isinstance(service_mgr_fact_collector.collect(), dict)

    # check required facts of ServiceMgrFactCollector
    assert service_mgr_fact_collector.required_facts == set(
        ['platform', 'distribution'])

    # check fact_ids of ServiceMgrFactCollector
    assert service_mgr_fact_collector._fact_ids == set()

    # check name of ServiceMgrFactCollector

# Generated at 2022-06-23 01:49:24.117647
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys

    # Mock module
    class MockModule(object):
        def get_bin_path(self, arg, *args, **kwargs):
            return 'systemctl'

    module = MockModule()

    # Mock os
    sys.modules['os'] = MockModule()

    # Mock os.path
    sys.modules['os.path'] = MockModule()

    # Mock  os.path.exists
    class MockPath(object):
        def exists(self, arg, *args, **kwargs):
            return True
    sys.modules['os.path'].exists = MockPath().exists

    # Mock os.path.islink
    class MockLink(object):
        def islink(self, arg, *args, **kwargs):
            return True

# Generated at 2022-06-23 01:49:28.224646
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    collector = ServiceMgrFactCollector()
    # In absence of systemd, this method should return False
    assert not collector.is_systemd_managed(module=None)

# Generated at 2022-06-23 01:49:32.842693
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.platform is None
    assert service_mgr_fact_collector.distribution is None
    assert service_mgr_fact_collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-23 01:49:44.586277
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule()
    mod.get_bin_path = lambda x: "/usr/bin/{0}".format(x)
    collector = ServiceMgrFactCollector()
    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    assert collector.is_systemd_managed_offline(mod) == True
    os.unlink('/sbin/init')
    assert collector.is_systemd_managed_offline(mod) == False
    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    os.remove('/usr/lib/systemd')
    assert collector

# Generated at 2022-06-23 01:49:54.213568
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import mock
    import sys
    import os
    import tempfile

    sys.modules['ansible.module_utils.facts.utils'] = mock.MagicMock()
    sys.modules['ansible.module_utils.facts.collector'] = mock.MagicMock()

    class test_pair:

        def __init__(self, path, proc_1_value, expected_service_manager):
            self.path = path
            self.proc_1_value = proc_1_value
            self.expected_service_manager = expected_service_manager

    # Note: os.readlink will not return 'init', only the actual target, so it will not be
    # tested here.

# Generated at 2022-06-23 01:49:59.674634
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    fact_collector = ServiceMgrFactCollector()

    # test call to is_systemd_managed_offline method
    class module:
        def get_bin_path(self, args):
            if args == 'systemctl':
                return '/usr/bin/systemctl'
            else:
                return None

    assert fact_collector.is_systemd_managed_offline(module())