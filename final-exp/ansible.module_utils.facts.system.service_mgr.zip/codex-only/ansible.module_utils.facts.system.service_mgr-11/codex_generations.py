

# Generated at 2022-06-23 01:40:05.336172
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys
    import unittest
    from mock import Mock, MagicMock, patch

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught by the test case"""
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def run_command_mock(module, *args, **kwargs):
        """function to mock module.run_command. return value should be interpreted by kwargs['returns']"""

# Generated at 2022-06-23 01:40:15.429160
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import pytest

    class MockModule:
        def __init__(self):
            self.run_command = run_command

        def get_bin_path(self, command):
            if command == 'systemctl':
                return '/usr/bin/systemctl'
            elif command == 'initctl':
                return '/sbin/initctl'
            elif command == 'sshd':
                return '/usr/sbin/sshd'
            else:
                return None

    def run_command(cmd, use_unsafe_shell=False):
        if cmd == "ps -p 1 -o comm|tail -n 1":
            return 0, "/sbin/init\n", ""

# Generated at 2022-06-23 01:40:26.982651
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from test.support import EnvironmentVarGuard

    from ansible.module_utils.facts.fact_collector import FactsCollector
    from ansible.module_utils.functions import get_bin_path


# Generated at 2022-06-23 01:40:32.205366
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # test binding of mock module
    class MockModule:
        @staticmethod
        def get_bin_path(argument):
            return '/bin/systemctl'
    test_class = ServiceMgrFactCollector()

    # test method
    # expected result: True
    assert(test_class.is_systemd_managed(MockModule))



# Generated at 2022-06-23 01:40:41.877446
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def get_bin_path(self, name, required=False):
            pass

        def run_command(self, name, use_unsafe_shell=True):
            pass

    class MockModuleReturns(object):
        def __init__(self, return_dict):
            self.result = return_dict

        def get_bin_path(self, name, required=False):
            if "bin_path" in self.result:
                return self.result["bin_path"]
            else:
                return None

        def run_command(self, name, use_unsafe_shell=True):
            if "rc" in self.result:
                return self.result["rc"], self.result["stdout"], self.result["stderr"]
            else:
                return None, None, None

   

# Generated at 2022-06-23 01:40:44.433783
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    serviceMgrFactCollectorInstance = ServiceMgrFactCollector()
    assert serviceMgrFactCollectorInstance.is_systemd_managed(None) is False


# Generated at 2022-06-23 01:40:47.891322
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    result = ServiceMgrFactCollector()
    assert result.name == 'service_mgr'
    assert result.required_facts == {'distribution', 'platform'}

# Generated at 2022-06-23 01:40:53.005614
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts import ModuleManager
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts.utils import MockModuleUtils

    m = MockModule()

    ServiceMgrFactCollector.is_systemd_managed(m)

# Generated at 2022-06-23 01:40:55.330716
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():

    obj = ServiceMgrFactCollector()
    assert obj
    print(obj.name)


# Generated at 2022-06-23 01:41:02.465535
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    mock_module = Mock()
    mock_module.run_command.return_value = (0, '/bin/systemd', '')
    mock_module.get_bin_path.return_value = '/bin/systemctl'
    mock_module.get_bin_path.return_value = '/bin/systemd'

    service_mgr_fact_collector = ServiceMgrFactCollector()
    mock_collected_facts = {}
    facts_dict = service_mgr_fact_collector.collect(module=mock_module, collected_facts=mock_collected_facts)
    assert facts_dict == { 'service_mgr': 'systemd' }

# Generated at 2022-06-23 01:41:13.596408
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    module = BaseModule(argument_spec={})
    # monkey patching module
    module.run_command = lambda *args, **kwargs: (0, "COMMAND", "")
    module.get_bin_path = lambda *args, **kwargs: ""
    module.params = {
       'gather_subset': ['all'],
       'gather_timeout': 10,
       'filter': '*'
    }
    facts_dict = {}
    # monkey patching facts_dict

# Generated at 2022-06-23 01:41:25.239045
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import unittest
    import ansible.module_utils.basic
    from ansible.module_utils.facts import collector

    class TestAnsibleModule(ansible.module_utils.basic.AnsibleModule):
        pass
    test_module = TestAnsibleModule(argument_spec={})

    class MockModule:
        def get_bin_path(self, path):
            return path
    test_module.get_bin_path = MockModule().get_bin_path

    fact_collector = ServiceMgrFactCollector()


# Generated at 2022-06-23 01:41:27.359225
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    s = ServiceMgrFactCollector(None)
    assert s.name == 'service_mgr'

# Generated at 2022-06-23 01:41:36.353147
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import module_framework
    from ansible.module_utils.facts.collector import BaseFactCollector

    # create a dummy module object
    module_obj = module_framework.AnsibleModule(argument_spec={})

    # create a subclass of BaseFactCollector
    class TestCollector(BaseFactCollector):
        name = 'service_mgr'

    # create an instance of the subclass
    test_col = TestCollector(module_obj)

    # test the normal path
    test_col.is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed
    result = test_col.is_systemd_managed(module_obj)
    assert result is False

# Generated at 2022-06-23 01:41:38.386668
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # Test with valid input parameters
    ServiceMgrFactCollector()

# Generated at 2022-06-23 01:41:48.002869
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    from ansible.module_utils.facts.collector.distribution import DistributionFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    ServiceMgrFactCollector.required_facts = set()

    collected_facts = {
        'ansible_distribution': None,
        'ansible_distribution_release': None,
        'ansible_distribution_version': None,
    }

    class MockModule(object):
        def __init__(self, params=None):
            self.params = params or {}


# Generated at 2022-06-23 01:41:51.096210
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # run a test
    # TODO: write test
    pass

# Generated at 2022-06-23 01:42:01.480650
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import sys
    import argparse

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/lib/systemd/systemd'
            else:
                return None

    def setUp():
        global args, service_mgr_fact_collector, module

        # Call is_systemd_managed of class ServiceMgrFactCollector
        args = argparse.Namespace(test_mode=True)
        service_mgr_fact_collector = ServiceMgrFactCollector(args=args)
        module = MockModule()

    # Mocking a platform running systemd
    def test_is_systemd_managed_systemd():
        setUp()
        import stat
        import os

       

# Generated at 2022-06-23 01:42:07.473053
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    # make a dummy module
    module = ansible.module_utils.facts.collector.BaseFactCollector()
    # make a dummy path of systemctl
    module.get_bin_path = lambda cmd: "/bin/systemctl"
    # make a dummy os.path
    os_path = {
        'islink': lambda path: True,
        'basename': lambda path: "systemd"
    }
    # make an instance
    instance = ServiceMgrFactCollector()

    with patch.multiple(os.path, **os_path):
        assert instance.is_systemd_managed_offline(module)

# Generated at 2022-06-23 01:42:15.741847
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    facts = {'platform': 'Linux',
             'ansible_distribution': 'CentOS'}
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    test_collector = ServiceMgrFactCollector()

    is_systemd_managed = test_collector.is_systemd_managed(test_module)

    if is_systemd_managed == False:
        os.makedirs("/run/systemd/system/")
        is_systemd_managed = test_collector.is_systemd_managed(test_module)
        os.remove("/run/systemd/system/")
        rmdir("/run/systemd/system/")

    assert is_systemd_managed == True


# Generated at 2022-06-23 01:42:25.967225
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    with patch('os.path.exists') as os_path_exists:
        os_path_exists.return_value = False
        with patch('ansible.module_utils.facts.system.service_mgr.get_file_content') as get_file_content:
            get_file_content.return_value = 'systemd'
            assert ServiceMgrFactCollector.is_systemd_managed(Module())
            get_file_content.return_value = 'somethingelse'
            assert not ServiceMgrFactCollector.is_systemd_managed(Module())
            os_path_exists.assert_has_calls([call('/run/systemd/system/'), call('/dev/.run/systemd/'), call('/dev/.systemd/')])

        os_path_exists.reset_mock

# Generated at 2022-06-23 01:42:33.138451
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    try:
        import ansible_collections
    except ImportError:
        pass
    else:
        if platform.system() != 'SunOS':
            from ansible.module_utils.compat.version import LooseVersion
        from ansible_collections.ansible.general.plugins.module_utils import facts
        from ansible.module_utils.facts import collector

        # Initialize object and test default values
        s = ServiceMgrFactCollector()
        assert s.name == 'service_mgr'
        assert s._fact_ids == set()
        assert s.required_facts == set(['platform', 'distribution'])

        # Test collect() method
        s = ServiceMgrFactCollector()
        collected_facts = {
            'platform': 'Linux',
            'distribution': 'CentOS',
        }


# Generated at 2022-06-23 01:42:39.260048
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    fact_collector = ServiceMgrFactCollector()
    mock_module = MockModule()
    result = fact_collector.collect(module=mock_module, collected_facts={})
    assert result == {'service_mgr': 'systemd'}


# Generated at 2022-06-23 01:42:49.301643
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # In future we could replace that function with a Mock.
    class ModuleMock:
        def get_bin_path(self, arg1):
            return arg1

    class Mock:
        def __init__(self):
            self.bin_path = None
            self.arg = None
            self.canary = None

        def run_command(self, arg, use_unsafe_shell=True):
            self.arg = arg
            if self.arg == 'systemctl':
                return 0, self.bin_path, ''
            elif self.arg == 'ps':
                if self.bin_path == 'systemd' or self.bin_path == 'systemctl':
                    return 0, 'systemd', ''
                elif self.bin_path == 'initctl':
                    return 0, 'initctl', ''

# Generated at 2022-06-23 01:42:57.059797
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    def mock_module_run_command(command, use_unsafe_shell=False):
        if command == "ps -p 1 -o comm|tail -n 1":
            return 0, "init", ""
        elif command == "ls /sbin/init":
            return 0, "/sbin/init", ""
        else:
            raise ValueError("Unknown command: %s" % command)

    def mock_get_file_content(filepath):
        if filepath == "/proc/1/comm":
            return "init"
        else:
            raise ValueError("Unknown filepath: %s" % filepath)


# Generated at 2022-06-23 01:43:00.291183
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False

# Generated at 2022-06-23 01:43:10.709596
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    '''Unit test for method collect of class ServiceMgrFactCollector'''

    # Create an instance of ServiceMgrFactCollector
    smfc = ServiceMgrFactCollector()

    # Create some mock data structures
    class MockModule(object):
        def __init__(self, cmd_rc, cmd_str, cmd_err):
            self.cmd_rc = cmd_rc
            self.cmd_str = cmd_str
            self.cmd_err = cmd_err

        def run_command(self, cmd, use_unsafe_shell=False):
            return (self.cmd_rc, self.cmd_str, self.cmd_err)

        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    mock_module

# Generated at 2022-06-23 01:43:15.480698
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector() # pylint: disable=assignment-from-no-return
    import ansible.module_utils.facts.system.service_mgr
    module = ansible.module_utils.facts.system.service_mgr
    assert collector.is_systemd_managed_offline(module) == True

# Generated at 2022-06-23 01:43:22.225672
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create an instance of Class ServiceMgrFactCollector
    service_mgr_obj = ServiceMgrFactCollector()

    # Mock module object
    mock_module = type('module', (object,), {})
    mock_module.run_command.return_value = (0, '', '')

    # Run method collect of class ServiceMgrFactCollector
    result = service_mgr_obj.collect(module=mock_module)

    # Assert method collect of class ServiceMgrFactCollector
    assert result['service_mgr'] == 'service'

# Generated at 2022-06-23 01:43:27.476896
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Unit test for method collect of class ServiceMgrFactCollector
    """
    collector = ServiceMgrFactCollector()
    module = None
    collected_facts = {}
    service_mgr = collector.collect(module, collected_facts)
    assert service_mgr == {}
    collected_facts = {'platform': 'Linux', 'distribution': 'RedHat'}
    service_mgr = collector.collect(module, collected_facts)
    assert service_mgr == {}

# Generated at 2022-06-23 01:43:34.572707
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    mock_module = None
    service_mgr_fact_collector = ServiceMgrFactCollector(mock_module)
    assert service_mgr_fact_collector.name == 'service_mgr'


# Generated at 2022-06-23 01:43:38.386192
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.name == 'service_mgr'
    assert ServiceMgrFactCollector._fact_ids == set()
    assert ServiceMgrFactCollector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:43:48.867579
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class FakeModule(object):
        def __init__(self, command_working, link_target_init):
            self.command_working = command_working
            self.link_target_init = link_target_init

        def get_bin_path(self, command):
            if self.command_working:
                return '/bin/systemctl'
            else:
                return False

        def islink(self, file):
            if self.link_target_init:
                return True
            else:
                return False

        def readlink(self, file):
            if self.link_target_init:
                return 'systemd'
            else:
                return 'systemctl'


# Generated at 2022-06-23 01:43:56.779464
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.compat.os import path
    import os

    class DummyModule(object):
        def __init__(self, path_map):
            self.path_map = path_map

        def get_bin_path(self, bin_name, required=False, opt_dirs=[]):
            return self.path_map.get(bin_name)

    class DummyCollector(BaseFactCollector):
        name = 'dummy'

    module = AnsibleModule(argument_spec=dict())

    os.path.islink = lambda x: True

# Generated at 2022-06-23 01:44:05.690946
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """
    Test function for is_systemd_managed method of ServiceMgrFactCollector
    class.
    """
    def get_bin_path(self, exe):
        """
        Mocked version get_bin_path.
        """
        if exe == 'systemctl':
            return exe
        return ''

    def run_command(self, *args, **kwargs):
        """
        Mocked version of run_command.
        """
        return '', '', ''

    module_mock = type('', (object,), {
        '_ansible_version': '2.9.9',
        'get_bin_path': get_bin_path,
        'run_command': run_command
    })

    # use a context manager to temporarily patch os.path.exists
    # to test with

# Generated at 2022-06-23 01:44:08.623585
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    """Test ServiceMgrFactCollector class"""

    x = isinstance(ServiceMgrFactCollector(), object)
    assert x

# Generated at 2022-06-23 01:44:10.994208
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.name == 'service_mgr'



# Generated at 2022-06-23 01:44:19.935882
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import MockModule
    module = MockModule({'path': []})
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False
    module = MockModule({'path': ['/bin']})
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False
    module = MockModule({'path': ['/bin'], 'systemctl': '/usr/bin/systemctl'})
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False
    module = MockModule({'path': ['/bin'], 'systemctl': '/usr/bin/systemctl'})
    os.mkdir('/run/systemd')
    assert ServiceMgrFactCollector.is_systemd_managed(module) == True

#

# Generated at 2022-06-23 01:44:25.824726
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mock_module = type('module', (object,), {
        'get_bin_path': lambda x: None,
        'run_command': lambda x: (0, 'init', ''),
    })
    collected_facts = {
        'ansible_system': 'Linux',
        'ansible_distribution': 'OpenWrt',
    }
    instance = ServiceMgrFactCollector()

    facts_dict = instance.collect(mock_module, collected_facts)

    assert facts_dict == {
        'service_mgr': 'openwrt_init',
    }

# Generated at 2022-06-23 01:44:36.529708
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import unittest.mock as mock
    import tempfile
    import json

    # Create mock module object
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kargs):
            self.exit_args = args
            self.exit_kargs = kargs
            return False

        def get_bin_path(self, *args, **kwargs):
            return '/bin/systemctl'

        def run_command(self, *args, **kwargs):
            return 0, '', None

    def create_temporary_file(content):
        fd, tmp_path = tempfile.mkstemp()
        with os.fdopen(fd, 'w') as tmp:
            tmp.write(content)
        return tmp_path

# Generated at 2022-06-23 01:44:40.340535
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    collector = ServiceMgrFactCollector()
    assert collector.name == 'service_mgr'
    assert sorted(collector.required_facts) == sorted(['platform', 'distribution'])
    assert sorted(collector._fact_ids) == sorted(collector.required_facts)

# Generated at 2022-06-23 01:44:41.329621
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert ServiceMgrFactCollector.collect()  == {}

# Generated at 2022-06-23 01:44:50.807318
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Mock module
    module = Mock(get_bin_path=Mock(return_value='/usr/bin/systemctl'))

    # Mock os.path.exists
    original_exists = os.path.exists
    os.path.exists = Mock(return_value=False)

    # Test systemd
    os.path.exists.reset_mock()
    os.path.exists.side_effect = [False, False, False, False, False, False, False, True]
    assert ServiceMgrFactCollector.is_systemd_managed(module)
    os.path.exists.assert_has_calls([call('/run/systemd/system/'), call('/dev/.run/systemd/'), call('/dev/.systemd/')])

    # Test init

# Generated at 2022-06-23 01:44:53.011469
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert isinstance(ServiceMgrFactCollector(), ServiceMgrFactCollector)

# Generated at 2022-06-23 01:45:00.256439
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    # create an instance of ServiceMgrFactCollector
    obj = ServiceMgrFactCollector()

    # Checks name of instance
    assert obj.name == 'service_mgr', 'name should be \'service_mgr\''

    # Checks list of accepted facts
    assert obj.required_facts == set(['platform', 'distribution']),\
    'required_facts should be set([\'platform\', \'distribution\'])'

    # Checks that dict is not populated
    assert not obj.collect()

# Generated at 2022-06-23 01:45:04.085131
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, cmd):
            return '/bin/%s' % cmd
    smfc = ServiceMgrFactCollector()
    assert not smfc.is_systemd_managed(MockModule())


# Generated at 2022-06-23 01:45:05.169999
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    ServiceMgrFactCollector()


# Generated at 2022-06-23 01:45:09.513510
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    assert ServiceMgrFactCollector.is_systemd_managed(module)


# Generated at 2022-06-23 01:45:20.526617
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils._text import to_bytes

    # Create the collector
    c = ServiceMgrFactCollector()

    # Mock the module
    class AnsibleModuleMock(object):
        def __init__(self, params):
            super(AnsibleModuleMock, self).__init__()
            self.params = params

        def get_bin_path(self, path):
            return 'systemctl'

        def run_command(self, command, use_unsafe_shell=True):
            return 0, 'init', ''

    # Mock the module
    class AnsibleModuleMockBadPath(object):
        def __init__(self, params):
            super(AnsibleModuleMockBadPath, self).__init__()

# Generated at 2022-06-23 01:45:30.063364
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.utils.service_mgr_fact_collector import ServiceMgrFactCollector
    from ansible.module_utils import basic

    testlib_path = os.path.join(os.path.dirname(__file__), 'testlib')
    sys.path.append(testlib_path)
    from ansible_facts_testlib import module_args, AnsibleFactsCollector

    test_collector = ServiceMgrFactCollector(module=basic.AnsibleModule(argument_spec=module_args))
    test_collector.collect(collected_facts={'ansible_system': 'Linux'})
    assert test_collector.facts['service_mgr'] == 'sysvinit'


# Generated at 2022-06-23 01:45:41.079904
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule(object):
        def __init__(self, module_name):
            self.params = {}

        def get_bin_path(self, arg):
            return arg

        def run_command(self, arg, use_unsafe_shell=True):
            if arg == 'ps -p 1 -o comm|tail -n 1':
                return 0, 'init process\n', ''

    module = MockModule('')

    expected_facts = {'service_mgr': 'upstart'}
    actual_facts = ServiceMgrFactCollector(module=module).collect()

    assert actual_facts == expected_facts

# Generated at 2022-06-23 01:45:43.898592
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_name = ServiceMgrFactCollector()

# Generated at 2022-06-23 01:45:45.267178
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector().is_systemd_managed(module=None) == False

# Generated at 2022-06-23 01:45:53.336765
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import Module, FactCollector
    import os
    import platform
    import tempfile
    import shutil

    test_folder = tempfile.mkdtemp()

    t = open(test_folder + '/systemctl', 'w')
    t.close()
    os.symlink(test_folder + '/systemctl', test_folder + '/init')

    # mock module
    module = Module()
    module.run_command = lambda x, y=None: (0, 'root')
    module.exit_json = lambda x: x

    # another mock
    mock_platform = platform.system
    platform.system = lambda: 'Linux'

    # create a mock fact collector
    fact_collector = FactCollector([], [ServiceMgrFactCollector], [], [])
    fact_collect

# Generated at 2022-06-23 01:46:03.339485
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
    from ansible.module_utils.facts import Collector

    ssmfc = ServiceMgrFactCollector(BaseFactCollector, Collector)
    ansible_module_mock = type('AnsibleModuleMock', (), {'get_bin_path': lambda x: '/bin/systemctl'})
    ansible_module_mock.run_command = lambda x, y: (0, None, None)
    ansible_module_mock.params = {}

    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    assert ssmfc.is_systemd_managed_offline(ansible_module_mock)

# Generated at 2022-06-23 01:46:12.402198
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class Module():
        def __init__(self):
            self.params = {}
            self.params['common_shell_default'] = '/bin/sh'

        def get_bin_path(self, args):
            return '/bin/' + args

    module = Module()

    try:
        # os.symlink('/bin/bash', '/sbin/init')
        os.symlink('systemd', '/sbin/init')
    except:
        pass

    sm = ServiceMgrFactCollector()
    assert sm.is_systemd_managed_offline(module)
    os.unlink('/sbin/init')

# Generated at 2022-06-23 01:46:19.194756
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import ModuleFacts
    mock_module = ModuleFacts()

    # Expected values:
    #  - 'is_systemd_managed'    : value returned by method 'is_systemd_managed'
    #  - 'path_systemctl'        : value returned by method 'get_bin_path' for 'systemctl' binary
    #  - 'path_systemd'          : value returned by method 'get_bin_path' for 'systemd' binary
    #  - 'path_systemd_systemctl': value returned by method 'get_bin_path' for 'systemctl' binary from 'systemd' package
    #  - 'output_systemctl'      : output of command 'systemctl'
    #  - 'output_systemd'        : output of command 'systemd'
    test_

# Generated at 2022-06-23 01:46:21.283705
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # FIXME: not testable without mocking module_utils.basic
    pass

# Generated at 2022-06-23 01:46:32.899330
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import TestCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import fact_cache
    import os

    # Test with boot init system as systemd
    test_collector = TestCollector()
    test_collector.collect = lambda self, module=None, collected_facts=None: {'ansible_distribution': 'Ubuntu', 'ansible_distribution_version': '16.04', 'ansible_system': 'Linux'}
    test_collector.get_bin_path = lambda self, name=None: '/usr/bin/systemctl'
    test_collector.is_systemd_managed = lambda self, module=None: False

# Generated at 2022-06-23 01:46:37.694919
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    mock_module = Mock()
    mock_module.get_bin_path.return_value = True
    ServiceMgrFactCollector.is_systemd_managed_offline(mock_module)
    mock_module.get_bin_path.assert_called_with('systemctl')


# Generated at 2022-06-23 01:46:42.137688
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    service_mgr_collector = ServiceMgrFactCollector()

    # Getting list of fact ids
    assert service_mgr_collector.get_fact_ids() == [ 'service_mgr' ]

    # Getting list of required facts
    assert service_mgr_collector.required_facts == set(['platform', 'distribution'])

# Generated at 2022-06-23 01:46:52.860012
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile

    # test systemd-sysvinit is not installed on SLES 11
    def create_special_init_file(content):
        with tempfile.TemporaryDirectory() as path:
            full_path = os.path.join(path, 'init')
            open(full_path, 'w+').write(content)
            return full_path

    def init_suse_returns(ret):
        import ansible.module_utils.facts.network.suse_facts
        orig = ansible.module_utils.facts.network.suse_facts.is_sysvinit_installed
        ansible.module_utils.facts.network.suse_facts.is_sysvinit_installed = lambda: ret
        return orig

    # Simulate systemctl command is available without performing the check

# Generated at 2022-06-23 01:47:02.309130
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    def fake_get_file_content(filename):
        if filename == '/proc/1/comm':
            return 'sshd\n'
        return None

    def fake_is_systemd_managed(module):
        return False

    module = dict()
    module['get_bin_path'] = lambda command: None
    module['run_command'] = lambda command: None
    ServiceMgrFactCollector.get_file_content = fake_get_file_content
    ServiceMgrFactCollector.is_systemd_managed = fake_is_systemd_managed
    module['run_command'] = lambda command, use_unsafe_shell: (0, 'init\n', None)
    module['os'] = dict()
    module['os']['path'] = dict()

# Generated at 2022-06-23 01:47:12.503908
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # create an instance of ServiceMgrFactCollector
    smfc = ServiceMgrFactCollector()
    # test module_utils is not None
    class TestModule:
        params = None
        def get_bin_path(self, arg):
            return '/bin/{0}'.format(arg)
    test_module = TestModule()
    assert smfc.is_systemd_managed_offline(test_module) == False
    # test /sbin/init is not a symlink to systemd
    os.symlink('/bin/systemd', '/sbin/init')
    assert smfc.is_systemd_managed_offline(test_module) == False
    # test /sbin/init is a symlink to systemd
    os.unlink('/bin/systemd')

# Generated at 2022-06-23 01:47:24.322709
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # mock module for testing
    module = Mock()
    module.get_bin_path.return_value = "some_path"
    module.run_command.return_value = (1, "some_output", "some_err")

    # unit under test
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # test 'distribution' not in collected facts resulting in service_mgr: ''
    collected_facts = {}
    collected_facts['ansible_distribution'] = "some_distribution"
    actual_return = service_mgr_fact_collector.collect(module=module, collected_facts=collected_facts)
    assert actual_return == {}

    # test 'ansible_system' is Linux resulting in service_mgr: 'systemd'
    collected_facts = {}
    collected

# Generated at 2022-06-23 01:47:27.204542
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    collector = ServiceMgrFactCollector()
    assert collector.name == 'service_mgr'
    assert collector._fact_ids == set()
    assert collector.required_facts == {'platform', 'distribution'}

# Generated at 2022-06-23 01:47:37.406373
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # mock module object
    class Module():
        def __init__(self):
            self.run_command = Mock(return_value=(0, 'systemd', ''))

        def get_bin_path(self, path, required=False, opt_dirs=[]):
            if path == 'systemctl':
                return 'path'
            else:
                return None
    MockModule = Module()

    # mock base fact collector
    class BaseFactCollector():
        def __init__(self):
            pass
        def filter_facts(self, facts_dict):
            return facts_dict
    MockBaseFactCollector = BaseFactCollector()

    # ServiceMgrFactCollector object with result of collect method
    smfc = ServiceMgrFactCollector()
    smfc.collect_methods = ['is_systemd_managed']

# Generated at 2022-06-23 01:47:47.782401
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Create the Ansible module specific mock objects
    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda x, y=None: (0, "", "")
    module.get_bin_path = lambda x=None: '/bin/' + x

    # Create the collector and get the facts
    collector = ServiceMgrFactCollector(module=module)
    facts_dict = collector.collect(module=module)

    # Assert the facts
    assert facts_dict['service_mgr'] == 'sysvinit'

# Generated at 2022-06-23 01:47:50.500235
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    test_ServiceMgrFactCollector = ServiceMgrFactCollector(None)
    assert test_ServiceMgrFactCollector.is_systemd_managed_offline == ServiceMgrFactCollector.is_systemd_managed_offline


# Generated at 2022-06-23 01:47:59.495189
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import DictData
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFile
    from ansible.module_utils.facts.collector import MockCommand
    from ansible.module_utils.facts.collector import MockOSPathIsLink

    mock_module = MockModule()
    mock_module.run_command = MockCommand()
    mock_module.get_bin_path = MockCommand(return_value="systemctl")
    mock_module.get_bin_path.commands["systemctl"] = 0
    mock_file = MockFile()
    mock_file.exists = MockOSPathIsLink(return_value=True)

# Generated at 2022-06-23 01:48:11.801051
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector()
    class MockModule(object):
        def get_bin_path(self, name):
            if name == "systemctl":
                return "/bin/systemctl"
            else:
                return ""

    module = MockModule()

    # Test when /sbin/init is not present
    assert collector.is_systemd_managed_offline(module) == False

    # Test when /sbin/init is not a symlink
    collector.file_exists = False
    assert collector.is_systemd_managed_offline(module) == False

    collector.file_exists = True
    collector.file_islink = False

    # Test when /sbin/init is not a symlink to systemd
    collector.file_readlink = "/sbin/init"

# Generated at 2022-06-23 01:48:19.229259
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts.collector import TestModuleCollector
    from ansible.module_utils.facts.collector import TestCollectedFacts
    from ansible.module_utils.facts.collector import TestBaseFactCollector
    import os

    # test when systemd-sysvinit package is not installed
    tm = TestModule()
    with open('/sbin/init', 'w') as f:
        f.write('')
    symlink_to_systemd = os.readlink('/sbin/init')
    if symlink_to_systemd == '/lib/systemd/systemd':
        os.remove('/sbin/init')

# Generated at 2022-06-23 01:48:26.298694
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.collector

    # Construct a module mock
    module_mock = ansible.module_utils.facts.collector.AnsibleModule
    module_mock.run_command.return_value = (0, "bin/bash\n", '')

    # Construct a ServiceMgrFactCollector mock
    service_mgr_fact_collector_mock = ServiceMgrFactCollector
    service_mgr_fact_collector_mock.get_file_content = lambda *_: 'bin/bash'

    # Construct a collected_facts mock
    collected_facts_mock = dict()
    collected_facts_mock['ansible_distribution'] = 'Linux'
    collected_facts_mock['ansible_system'] = 'Linux'

    # Execute method collect of class

# Generated at 2022-06-23 01:48:35.013387
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert isinstance(x, ServiceMgrFactCollector)
    assert hasattr(x, 'name')
    assert x.name == "service_mgr"
    assert hasattr(x, 'required_facts')
    assert isinstance(x.required_facts, set)
    assert len(x.required_facts) == 2
    assert 'platform' in x.required_facts
    assert 'distribution' in x.required_facts

    assert hasattr(x, 'collect')
    assert callable(x.collect)
    assert hasattr(x, 'is_systemd_managed')
    assert callable(x.is_systemd_managed)
    assert hasattr(x, 'is_systemd_managed_offline')

# Generated at 2022-06-23 01:48:39.448096
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    x = ServiceMgrFactCollector()
    assert x


# Generated at 2022-06-23 01:48:40.778004
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    smfc = ServiceMgrFactCollector()
    assert smfc.name == 'service_mgr'

# Generated at 2022-06-23 01:48:49.377053
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
    from ansible.module_utils.facts.fake.collector import FakeModule
    module = FakeModule()
    module.get_bin_path = lambda program: '/sbin/systemctl'
    os.symlink('systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=module)
    os.remove('/sbin/init')

# Generated at 2022-06-23 01:49:00.307414
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    import ansible.module_utils

    class TestModule():
        def get_bin_path(self, module, required=False, opt_dirs=[]):
            if module == 'systemctl':
                return '/bin/systemctl'

    test_module = TestModule()

    class TestSystem():
        def __init__(self):
            self.uname_result = ('Linux', '', '', '', 'x86_64')

    class TestOs():
        def path(self):
            return self

        def islink(self, path):
            if path == '/sbin/init':
                return True
            return False

        def readlink(self, path):
            return '/lib/systemd/system/systemd'

    test_os = TestOs()
    test_system = TestSystem()

    ansible.module_

# Generated at 2022-06-23 01:49:04.950770
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    assert hasattr(ServiceMgrFactCollector, "collect")
    assert type(ServiceMgrFactCollector.collect) is type(test_ServiceMgrFactCollector)


# Generated at 2022-06-23 01:49:12.677815
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = FakeAnsibleModule()
    module.run_command = mock_run_command
    smfc = ServiceMgrFactCollector()
    assert smfc.is_systemd_managed(module) == True
    module.run_command = mock_run_command_systemd_off
    assert smfc.is_systemd_managed(module) == False


# Generated at 2022-06-23 01:49:23.509910
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import mock
    import json

    import platform
    import sys

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector

    # helper methods for tests

    def setUpModule():
        import sys
        sys.modules["ansible.module_utils.facts.collector"] = mock.MagicMock()
        sys.modules["ansible.module_utils.facts.collector.BaseFactCollector"] = mock.MagicMock()

    def tearDownModule():
        import sys
        del sys.modules["ansible.module_utils.facts.collector"]
        del sys.modules["ansible.module_utils.facts.collector.BaseFactCollector"]

    def get_test_config(self):
        return dict

# Generated at 2022-06-23 01:49:30.670636
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class Module:
        def get_bin_path(self, bin_name):
            return "/usr/bin/systemctl"

    # test when /run/systemd/system exists
    class MockOsModule:
        def path_exists(self, path):
            return True
    os_module = MockOsModule()
    assert ServiceMgrFactCollector.is_systemd_managed(Module()) == True

    # test when /dev/.run/systemd exists
    class MockOsModule1:
        def path_exists(self, path):
            return True
    os_module = MockOsModule1()
    assert ServiceMgrFactCollector.is_systemd_managed(Module()) == True

    # test when /dev/.systemd exists

# Generated at 2022-06-23 01:49:34.067599
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockModule({}, {})
    service_mgr_fact_collector = ServiceMgrFactCollector()

    assert service_mgr_fact_collector.is_systemd_managed_offline(module) == False

# Test class

# Generated at 2022-06-23 01:49:39.602916
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector

    module = BaseFactCollector()

    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)


# Generated at 2022-06-23 01:49:46.116227
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys
    import json
    import pytest

    from ansible.module_utils.facts import BaseFactCollector

    class BaseTest(BaseFactCollector):
        def __init__(self, module, facts=None):
            super(BaseTest, self).__init__(module, facts)
            self.fact_names = None

    base_facts = {
        'ansible_distribution': 'Linux',
        'ansible_system': 'Linux',
        'platform_dist_name': 'redhat'
    }
    base_module = BaseTest(module=None, facts=base_facts)

    expected_result = {'ansible_facts': base_facts, 'changed': False}
    expected_result['ansible_facts']['service_mgr'] = 'systemd'

    # mock systemd_managed
   

# Generated at 2022-06-23 01:49:55.427022
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import shutil
    import sys
    sys.modules['ansible.module_utils.basic'] = sys.modules['ansible.module_utils.facts.collector.base']
    sys.modules['ansible.module_utils.facts.collector.base'] = sys.modules['ansible.module_utils.facts.collector.base']
    sys.modules['ansible.module_utils.facts.collector'] = sys.modules['ansible.module_utils.facts.collector']

    test_collector = ServiceMgrFactCollector()

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-23 01:50:02.816735
# Unit test for constructor of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector():
    from ansible.module_utils.facts.collector import GenericFactCollector

    a = GenericFactCollector()
    b = ServiceMgrFactCollector()

    current_platform = str(platform.system())
    if current_platform == 'Linux':
        assert b.name == 'service_mgr'
        assert b._fact_ids == set()
        assert b.required_facts == set(['platform', 'distribution'])
    elif current_platform == 'FreeBSD':
        assert b.name == 'service_mgr'
        assert b._fact_ids == set()
        assert b.required_facts == set(['platform', 'distribution'])
    elif current_platform == 'Darwin':
        assert b.name == 'service_mgr'
        assert b._fact_ids == set()