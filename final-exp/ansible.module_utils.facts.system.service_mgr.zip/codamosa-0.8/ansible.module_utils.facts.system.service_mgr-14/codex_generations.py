

# Generated at 2022-06-11 05:10:40.237106
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    #
    # Solaris case
    #
    class SolarisModule:
        def get_bin_path(self, command):
            return '/bin/' + command

        def run_command(self, command, use_unsafe_shell):
            if command == 'systemctl':
                return 0, '/usr/bin/systemd --system --deserialize=19', ''
            else:
                return 1, '', ''

    solaris_module = SolarisModule()
    #
    # check when '/usr/bin/systemd' is installed
    #
    result = ServiceMgrFactCollector.is_systemd_managed_offline(module=solaris_module)
    assert result
    #
    # check when '/usr/bin/systemd' is not installed
    #

# Generated at 2022-06-11 05:10:44.130063
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance

    module = AnsibleModuleMock()
    service_mgr = get_collector_instance('service_mgr')
    assert service_mgr.is_systemd_managed(module=module) == True

# Generated at 2022-06-11 05:10:54.378064
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class ModuleMock():
        def __init__(self):
            self.systemctl_path = None

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            if executable == 'systemctl':
                return self.systemctl_path

    module = ModuleMock()

    # systemctl is installed (systemd is managed)
    module.systemctl_path = '/usr/bin/systemctl'
    assert ServiceMgrFactCollector.is_systemd_managed(module=module) is True

    # systemctl is not installed (systemd is not managed)
    module.systemctl_path = None
    assert ServiceMgrFactCollector.is_systemd_managed(module=module) is False


# Generated at 2022-06-11 05:10:58.622671
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    try:
        import ansible.module_utils.ansible_release
        import ansible.module_utils.facts.system.service_mgr
    except ImportError:
        raise AssertionError("Could not import test module")
    collector = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector()
    assert 'is_systemd_managed_offline' in dir(collector), 'Method is_systemd_managed_offline is not part of ServiceMgrFactCollector'
    assert False == collector.is_systemd_managed_offline(None), 'If systemd is not installed, it should not be detected as managed'

# Generated at 2022-06-11 05:11:03.461451
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import mock_module

    # Test with /sbin/init file
    test_module = mock_module()
    test_module.run_command = lambda *args, **kwargs: (0, '', '')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(test_module)

    # Test without /sbin/init file
    test_module = mock_module()
    test_module.run_command = lambda *args, **kwargs: (127, 'No such file or directory', '')
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(test_module)

# Generated at 2022-06-11 05:11:13.406038
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import os
    import shutil
    import platform

    class MockModule(object):
        def __init__(self):
            self.systemctl_bin = None
            self.is_systemd_managed = False

        def get_bin_path(self, command):
            return self.systemctl_bin

        def run_command(self, command, use_unsafe_shell=False):
            if self.systemctl_bin:
                return 0, '', ''
            else:
                return 1, '', 'file not found'

    class MockFacter(object):
        def __init__(self, facts_dict):
            self.facts = facts_dict

    def copy_systemctl_to_temp_directory(directory):
        os.makedirs(directory)

# Generated at 2022-06-11 05:11:19.655128
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module=None)
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=MockModule(['systemctl','init'],[]))
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=MockModule(['systemctl','init.d'],[]))
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module=MockModule(['systemctl','xyz'],[]))


# Generated at 2022-06-11 05:11:28.038170
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
# Initializing instance of class ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()
# Initializing collected_facts parameter of method collect
    collected_facts = {
        'platform': 'Darwin',
        'distribution': 'MacOSX',
    }
# Calling method collect of class ServiceMgrFactCollector
    facts_dict = service_mgr_fact_collector.collect(collected_facts=collected_facts)
# Asserting expected result
    assert facts_dict == {'service_mgr': 'launchd'}

# Generated at 2022-06-11 05:11:38.510325
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Collector
    import ansible.module_utils
    fact_collector = ServiceMgrFactCollector()
    ansible.module_utils.basic._ANSIBLE_ARGS = '{"hostvars": {}}'
    test_module = ansible.module_utils.basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_module.ROOT_PATH = os.path.join(os.path.dirname(__file__), '..', '..')
    test_module.HOST_NAME = 'localhost'
    test_module.OPTIONS = {'gather_subset': ['all'], 'gather_timeout': 10}
    test_module.params = {}
    test_module.current_paths = {}

# Generated at 2022-06-11 05:11:40.626312
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    collector = ServiceMgrFactCollector()
    assert collector.collect()['service_mgr'] == 'service'


# Generated at 2022-06-11 05:12:04.727006
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule:
        def __init__(self):
            self.path = []
            self.run_command_result_map = {}
            self.run_command_result_map["cat /proc/1/comm"] = [0, "systemd", ""]
            self.run_command_result_map["ps -p 1 -o comm"] = [0, "systemd", ""]

        def get_bin_path(self, cmd):
            if cmd == "systemctl":
                return "/bin/systemctl"
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=True):
            if cmd in self.run_command_result_map:
                return self.run_command_result_map[cmd]
            else:
                return [-1, None, None]

   

# Generated at 2022-06-11 05:12:14.026384
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class Module(object):
        import sys

        @staticmethod
        def get_bin_path(*args):
            return '/bin/systemctl'

    import tempfile
    import shutil
    try:
        tmpdir = tempfile.mkdtemp()
        try:
            os.symlink('/bin/systemd', os.path.join(tmpdir, 'sbin', 'init'))
            assert ServiceMgrFactCollector.is_systemd_managed_offline(Module()) == True
        finally:
            shutil.rmtree(tmpdir)
        assert ServiceMgrFactCollector.is_systemd_managed_offline(Module()) == False
    except NotImplementedError:
        pass # If we cannot create a symlink, skip the test.  Skipping this test is probably good enough.

# Generated at 2022-06-11 05:12:23.803553
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    This is a unit test to verify the collection of service manager facts by the
    ServiceMgrFactCollector class.

    It will:
    - Use the ServiceMgrFactCollector class to collect facts.
    - Verify that the returned facts are as expected.
    """
    import sys
    import platform
    import unittest

    # mock AnsibleModule class
    class MockAnsibleModule:
        def __init__(self, params):
            self._params = params

        def get_bin_path(self, executable):
            if self._params['bin_path'] is None:
                return None
            return self._params['bin_path']

    # mock module input parameters
    module_params = {
        'bin_path': None,
        'exists': None
    }

    # mock subprocess.Popen


# Generated at 2022-06-11 05:12:33.394174
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import os
    import shutil
    import random

    import ansible.module_utils.facts.service_mgr

    # create working directory
    test_dir = os.path.join(tempfile.gettempdir(), 'test_dir_' + str(random.randint(0, 99999)))
    os.mkdir(test_dir)
    old_dir = os.getcwd()
    os.chdir(test_dir)

    # prepare input data
    system_dir = os.path.join(os.getcwd(), 'tmp', 'systemd')
    os.makedirs(os.path.join(system_dir, 'system'))
    open(os.path.join(system_dir, 'system', 'systemd'), 'a').close()

    run_dir = os.path

# Generated at 2022-06-11 05:12:43.038953
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    method_to_test = ServiceMgrFactCollector.is_systemd_managed

    class ModuleMock:

        @staticmethod
        def get_bin_path(binary):
            return "/bin/%s" % binary

        @staticmethod
        def run_command(command, use_unsafe_shell=True):
            if command == "/bin/systemctl list-units --full -all":
                return 0, "", ""

    # 1. Test for return value if systemd is running.
    assert method_to_test(ModuleMock())

    # 2. Test for return value if systemd is not running.
    class ModuleMock2:

        @staticmethod
        def get_bin_path(binary):
            return None

        @staticmethod
        def run_command(command, use_unsafe_shell=True):
            return

# Generated at 2022-06-11 05:12:49.972449
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline({'get_bin_path': lambda x: '/bin/systemctl'}) == False
    assert ServiceMgrFactCollector.is_systemd_managed_offline({'get_bin_path': lambda x: None}) == False
    assert ServiceMgrFactCollector.is_systemd_managed_offline({'get_bin_path': lambda x: '/bin/systemctl'}) == True

# Generated at 2022-06-11 05:12:59.247712
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = None
    os.makedirs("/dev/.run/systemd/")
    result = ServiceMgrFactCollector.is_systemd_managed(module)
    assert result
    result = ServiceMgrFactCollector.is_systemd_managed_offline(module)
    assert not result
    os.unlink("/dev/.run/systemd/")
    os.makedirs("/run/systemd/system/")
    result = ServiceMgrFactCollector.is_systemd_managed(module)
    assert result
    result = ServiceMgrFactCollector.is_systemd_managed_offline(module)
    assert not result
    os.unlink("/run/systemd/system/")
    os.makedirs("/dev/.systemd/")
    result = ServiceMgrFactCollector

# Generated at 2022-06-11 05:12:59.991196
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    pass

# Generated at 2022-06-11 05:13:09.859758
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-11 05:13:14.118384
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_facts

    facts = get_collector_facts()
    assert 'service_mgr' in facts
    assert facts['service_mgr'] == 'systemd' or facts['service_mgr'] == 'service' or facts['service_mgr'] == 'bsdinit'

# Generated at 2022-06-11 05:13:59.080660
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Mock the argument spec and create a dummy module instance
    module = type('', (object,), {})()
    setattr(module, 'get_bin_path', lambda s: '/bin/systemctl')
    # Instantiate the class
    fact = ServiceMgrFactCollector()
    # Expected False
    assert fact.is_systemd_managed(module) is False
    # Mock the /run/systemd/system/ directory as a file
    import tempfile
    open(os.path.join(tempfile.gettempdir(), 'systemd'), 'a').close()
    # Expected False
    assert fact.is_systemd_managed(module) is False
    # Mock the /run/systemd/system/ directory as a directory
    import shutil

# Generated at 2022-06-11 05:14:08.801547
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import sys
    sys.modules['ansible.module_utils.facts.utils'] = __import__('ansible.module_utils.facts.utils', fromlist=['*'])
    sys.modules['ansible.module_utils.facts.collector'] = __import__('ansible.module_utils.facts.collector', fromlist=['*'])
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    class MockModule:
        def __init__(self):
            self.sys_executable = '/bin/sh'

        def get_bin_path(self, executable=None):
            return self.sys_executable

    class MockOs:
        def __init__(self):
            self.systemd_exists = False


# Generated at 2022-06-11 05:14:13.836343
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # test os.path.exists('/run/systemd/system/') == True
    with mock.patch('os.path.exists') as mock_os_path_exists:
        mock_os_path_exists.return_value = True
        assert ServiceMgrFactCollector.is_systemd_managed(module=None)



# Generated at 2022-06-11 05:14:15.193944
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # TODO: write unit test
    return True


# Generated at 2022-06-11 05:14:24.915232
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file to fake /sbin/init
    sbin_init = os.path.join(tmpdir, 'sbin', 'init')
    if not os.path.exists(os.path.dirname(sbin_init)):
        os.makedirs(os.path.dirname(sbin_init))
    open(sbin_init, 'w').close()

    # Create a temporary file to fake /run/systemd/system

# Generated at 2022-06-11 05:14:31.541832
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance
    class MockModule:
        def get_bin_path(self, _):
            return '/bin/systemd'
    assert ServiceMgrFactCollector.is_systemd_managed(MockModule()) == True
    class MockModule:
        def get_bin_path(self, _):
            return None
    assert ServiceMgrFactCollector.is_systemd_managed(MockModule()) == False


# Generated at 2022-06-11 05:14:40.725717
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_status

    # Initialize the collector and its child collectors
    collector = Collector()
    service_mgr_collector = ServiceMgrFactCollector()
    collector.add_collector(service_mgr_collector)

    # ServiceMgrFactCollector is active if it can detect the service manager with tools installed
    assert get_collector_status(service_mgr_collector) == 'active'

    # Execute the collect method of the collector
    output = collector.collect()
    assert output['service_mgr'] is not None

# Generated at 2022-06-11 05:14:46.990135
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Initialize MockedModule object
    module = MockedModule()

    # Instantiate ServiceMgrFactCollector object
    service_mgr_fact_collector_obj = ServiceMgrFactCollector()

    # Call method collect and check the response
    if service_mgr_fact_collector_obj.collect(module):
        assert True
    else:
        assert False

if __name__ == "__main__":
    from ansible.module_utils.facts.collectors import collector_module
    # Run unit test for ServiceMgrFactCollector.collect
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-11 05:14:57.867137
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockModule()
    module.params = {
        'gather_subset': ['all'],
        'filter': '*',
    }
    module.run_command = Mock(return_value=(0, 'systemd', ''))
    s = ServiceMgrFactCollector()
    res = s.is_systemd_managed_offline(module=module)
    module.get_bin_path.assert_called_with('systemctl')
    module.run_command.assert_called_with("ps -p 1 -o comm|tail -n 1", use_unsafe_shell=True)
    assert res == True

    module.run_command = Mock(return_value=(0, 'other_init', ''))
    res = s.is_systemd_managed_offline(module=module)

# Generated at 2022-06-11 05:15:07.067100
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # import modules that would be used when is_systemd_managed_offline is invoked
    import ansible.module_utils.facts.collectors.service_mgr
    from ansible.module_utils.facts.utils import get_file_content

    # mock the module class
    class module:
        @staticmethod
        def get_bin_path(cmd):
            return "systemctl"

    # set the content of /sbin/init
    if os.path.islink('/sbin/init'):
        os.unlink('/sbin/init')
    os.symlink('systemd', '/sbin/init')

    # invoke the is_systemd_managed_offline method
    object = ServiceMgrFactCollector()
    assert object.is_systemd_managed_offline(module) is True

   

# Generated at 2022-06-11 05:16:35.190574
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self):
            self.exit_json = None

        def get_bin_path(self, bin_name):
            return "/bin/{}".format(bin_name)

    def test_case(command, expected_result):
        module = MockModule()
        mock_class = ServiceMgrFactCollector()


# Generated at 2022-06-11 05:16:44.735584
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class Mock(object):
        def get_bin_path(self, binary):
            return binary

    class ModuleMock(object):
        def __init__(self):
            self.run_command_mock_value = None
            self.run_command_mock_exception = None

        def run_command(self, module, use_unsafe_shell):
            if self.run_command_mock_exception:
                raise self.run_command_mock_exception
            return self.run_command_mock_value

    #
    # Test for an existing systemd canary file.
    #
    modules = {
        "/run/systemd/system/": None,
        "/dev/.run/systemd/": None,
        "/dev/.systemd/": None
    }
    module = ModuleMock

# Generated at 2022-06-11 05:16:54.814574
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collectors.service_mgr

    test_dir = mkdtemp()
    systemd_dir = os.path.join(test_dir, 'dev', '.systemd')
    os.makedirs(os.path.dirname(systemd_dir))
    open(systemd_dir, 'w').close()
    symlink_target = 'systemd'
    symlink_name = os.path.join(test_dir, 'sbin', 'init')
    os.symlink(symlink_target, symlink_name)

    test_cases = [(symlink_target, True)]

# Generated at 2022-06-11 05:16:59.493396
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    import os

    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector


# Generated at 2022-06-11 05:17:00.729937
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector.collect()

# Generated at 2022-06-11 05:17:09.774742
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Mock current platform details.
    # platform.system() returns 'Linux' on RHEL
    platform.system = lambda: 'Linux'
    platform.linux_distribution = lambda: ('', '', '')

    # Mock module.
    module = type('Module', (object,), {})

    # Mock module.run_command().
    def run_command(self, cmd, **kwargs):
        return None, 'openSUSE', ''
    module.run_command = run_command

    # Mock module.get_bin_path(). This is needed to run 'systemctl' command.
    def get_bin_path(self, cmd, **kwargs):
        if cmd == 'systemctl':
            return '/bin/systemctl'
        return None
    module.get_bin_path = get_bin_path

    # Mock os.

# Generated at 2022-06-11 05:17:13.600204
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    fc = ServiceMgrFactCollector()
    assert fc.is_systemd_managed_offline({'get_bin_path': lambda x: 'systemctl'}) == True
    assert fc.is_systemd_managed_offline({'get_bin_path': lambda x: None}) == False

# Generated at 2022-06-11 05:17:21.881300
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    test_cases=[
        (__file__, '/sbin/init', 'systemd', True),
        (__file__, '/sbin/init', 'init', False),
        (__file__, None, 'systemd', False),
        (__file__, '/sbin/init', None, False),
    ]

    class cx_mock:
        def run_command(self, args, use_unsafe_shell=True):
            return 0, 'systemd\n', None

        def get_bin_path(self, bin_path):
            return True


# Generated at 2022-06-11 05:17:30.016674
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    This test case has been designed with the purpose of unit testing method
    collect of class ServiceMgrFactCollector.

    This method is testing following aspects:
    - returns empty when module is None.
    - returns service_mgr when module is prsent.

    :return: nothing
    """

    # Create test for class ServiceMgrFactCollector
    test_instance = ServiceMgrFactCollector()

    # Test with module as None
    assert test_instance.collect(module=None) == {}

    # Test with module as not None
    assert type(test_instance.collect(module='/tmp')) == dict
    assert test_instance.collect(module='/tmp').get('service_mgr') == 'service'


# Generated at 2022-06-11 05:17:37.570063
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Mock the module
    module = mock_ansible_module()
    module.get_bin_path.return_value = "/bin/systemctl"
    # Mock the get_file_content method
    module.get_file_content = mock.Mock()
    # Mock the get_file_content method to return PID 1
    module.get_file_content.side_effect = ["1"]

    # Mock the os.path.islink method
    osp_islink = mock.Mock()
    mock_os.path.islink = osp_islink
    # Mock the islink method to return False
    osp_islink.return_value = False

    # Mock the os.readlink method
    osp_readlink = mock.Mock()
    mock_os.readlink = osp_readlink
    #