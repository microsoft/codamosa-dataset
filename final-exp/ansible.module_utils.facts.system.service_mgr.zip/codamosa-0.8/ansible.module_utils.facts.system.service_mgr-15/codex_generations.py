

# Generated at 2022-06-11 05:10:44.574408
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockedModule(object):
        @staticmethod
        def get_bin_path(arg):
            if 'systemctl' == arg:
                return '/bin/systemctl'
            elif 'initctl' == arg:
                return '/bin/initctl'
            else:
                return None

        @staticmethod
        def run_command(cmd, use_unsafe_shell=False):
            return None, None, None

    class MockedFacts(object):
        def __init__(self):
            self.facts = dict(distribution='Linux', system='FooSys')

        def __getitem__(self, key):
            return self.facts[key]

        def get(self, key, default=None):
            return self.facts.get(key, default)

    service_mgr_collector = ServiceM

# Generated at 2022-06-11 05:10:49.462423
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command.return_value = (1, "systemd", "")

    fact = ServiceMgrFactCollector(module=module)
    result = fact.collect()

    assert result['service_mgr'] == 'systemd'



# Generated at 2022-06-11 05:10:52.516158
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    instance = ServiceMgrFactCollector()
    response = instance.collect()
    assert isinstance(response, dict)
    assert 'service_mgr' in response
    assert response['service_mgr'] == 'service'

# Generated at 2022-06-11 05:11:01.691611
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule:
        def __init__(self):
            self.run_command_calls = 0

        def get_bin_path(self, prog):
            if prog == 'systemctl':
                if self.run_command_calls == 0:
                    return '/usr/bin/systemctl'
                else:
                    return None
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=True):
            self.run_command_calls += 1
            if cmd == 'systemctl list-units --all --no-pager --full --plain':
                if self.run_command_calls == 1:
                    return 0, 'ABRT.service        loaded    active   exited    Install ABRT coredump hook\n', ''

# Generated at 2022-06-11 05:11:06.985699
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    collector = ServiceMgrFactCollector()
    class fake_command(object):
        def get_bin_path(self, path, required=False):
            return True
    module = fake_command()
    assert collector.is_systemd_managed_offline(module) == False



# Generated at 2022-06-11 05:11:12.018541
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.params['ansible_system'] = 'Linux'
    result1 = ServiceMgrFactCollector.is_systemd_managed(module)

    if result1:
        assert(result1 is True)
    else:
        assert(result1 is False)


# Generated at 2022-06-11 05:11:18.673804
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    # Mock class for module
    class MockModule:
        bin_path = ''
        # Method for getting executable path
        def get_bin_path(self, exe):
            return self.bin_path

    # Create an instance of the class ServiceMgrFactCollector
    class_instance = ServiceMgrFactCollector()

    # Create an instance of the class MockModule
    module_instance = MockModule()

    # Set bin_path of module_instance to path of executable 'systemctl'
    module_instance.bin_path = '/usr/bin/systemctl'

    # Test is_systemd_managed_offline method when /sbin/init is linked to systemd
    assert class_instance.is_systemd_managed_offline(module_instance) == True

    # Test is_systemd_managed_offline method when /sbin

# Generated at 2022-06-11 05:11:30.008852
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule:
        def __init__(self):
            pass

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return None

    class MockCollector:
        def __init__(self, facts):
            self.facts = facts

        def collect(self, module, collected_facts):
            return self.facts

    def _get_mock_module_with_bin_path(bin_path):
        class MockModule:
            def __init__(self):
                pass

            def fail_json(self, *args, **kwargs):
                pass

            def get_bin_path(self, *args, **kwargs):
                return bin_path

        return MockModule()


# Generated at 2022-06-11 05:11:40.374145
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """Ensure that is_systemd_managed_offline returns the proper value for
    various init systems.
    """
    from ansible.module_utils import facts

    class MockModule(object):
        """Fake module object"""
        def __init__(self):
            self.params = {}

        def get_bin_path(self, command, opts=None, required=False):
            return "/usr/bin/systemctl"

    def NativeString(string):
        """Fake conversion to native data type when using Python 2"""
        return string


# Generated at 2022-06-11 05:11:45.421717
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import DictModule

    # Test for a system when 'systemctl status' can be executed and
    # /dev/.run/systemd/ exists, but /run/systemd/system/ does not exist
    test_module = DictModule()
    test_mock_module = type('module', (object,), {'get_bin_path': test_module.get_bin_path})
    test_collector = ServiceMgrFactCollector()
    assert test_collector.is_systemd_managed(test_mock_module) == True

# Generated at 2022-06-11 05:12:06.987481
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import is_systemd_managed
    from ansible.module_utils._text import to_bytes

    class TestModule():
        def get_bin_path(self, arg, *args, **kwargs):
            return '/bin/systemctl' if arg == 'systemctl' else None

        def run_command(self, arg, *args, **kwargs):
            return (0, '/bin/systemctl', None) if arg == 'ps -p 1 -o comm|tail -n 1' else (1, '', None)


# Generated at 2022-06-11 05:12:16.733086
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    s = ServiceMgrFactCollector()
    mock_module = MockModule()
    assert s.is_systemd_managed_offline(mock_module) == False

    mock_module.run_command = Mock(return_value=(0, '/usr/bin/systemd', ''))
    assert s.is_systemd_managed_offline(mock_module) == False

    def run_command_side_effect(*args, **kwargs):
        return (1, '', 'In order to use this command, the /sbin/init symlink must point to systemd')

    mock_module.run_command.side_effect = run_command_side_effect
    assert s.is_systemd_managed_offline(mock_module) == False


# Generated at 2022-06-11 05:12:23.406704
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    s = ServiceMgrFactCollector()

    class MockModule:
        def get_bin_path(self, executable):
            return executable

    # systemd is running
    class MockOs:
        path = os
        @staticmethod
        def exists(path):
            return True

    s.is_systemd_managed(MockModule())

    # systemd is not running
    class MockOs:
        path = os
        @staticmethod
        def exists(path):
            return False

    s.is_systemd_managed(MockModule())

# Generated at 2022-06-11 05:12:33.068584
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.system.service_mgr as test_obj
    import tempfile
    import shutil

    class TestModule(object):
        def get_bin_path(self, executable):
            return '/bin/' + executable

    # Test 1: using systemctl
    test_module = TestModule()
    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 05:12:40.335672
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class MockModule():
        def get_bin_path(self, binary):
            return True

    mock_module = MockModule()
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module) == False

    from unittest.mock import patch
    import os
    with patch.object(os, 'path') as mock_path:
        mock_path.exists.return_value = True
        assert ServiceMgrFactCollector.is_systemd_managed(mock_module) == True



# Generated at 2022-06-11 05:12:51.037519
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collectors.service_mgr as mycollector

    # test - /sbin/init is linked to systemd
    test_dict = {}
    test_dict['/sbin/init'] = '/lib/systemd/systemd'
    test_dict['/lib/systemd/systemd'] = ''
    test_dict['/proc/1/comm'] = ''
    test_dict['/run/systemd/system/'] = False

    assert mycollector.ServiceMgrFactCollector.is_systemd_managed_offline(test_dict) == True

    # test - /lib/systemd/systemd does not exist
    test_dict = {}
    test_dict['/sbin/init'] = '/lib/systemd/systemd'

# Generated at 2022-06-11 05:12:56.801725
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.system

    class MyModule(object):
        def run_command(self, command, use_unsafe_shell):
            if command == 'systemctl list-units --no-legend':
                return 0, 'systemd-analyze.service loaded active exited', ''

    # If systemctl is not installed we do not think the system is systemd managed
    module = MyModule()
    assert ServiceMgrFactCollector.is_systemd_managed(module=module) == False

    # If systemctl is installed and there is one service with 'systemd' in its name
    # then we think the system is systemd managed
    module.get_bin_path = lambda x: '/bin/systemctl'
    assert ServiceMgrFactCollector.is_systemd_managed(module=module) == True

# Generated at 2022-06-11 05:13:04.709730
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a fake module which is not really executed
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    module = BaseFactCollector()
    module._debug = True
    module.get_bin_path = lambda cmd: None
    if platform.system() == 'Linux':
        assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False, \
            "Unit test of ServiceMgrFactCollector failed."



# Generated at 2022-06-11 05:13:07.988098
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    fact_collector = FactCollector()
    available_collectors = fact_collector.get_collector_classes()
    assert 'service_mgr' in available_collectors

# Generated at 2022-06-11 05:13:16.789469
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})
    module._module.__dict__['_system'] = {
        'can_run_systemctl': True,
        'systemd': False
    }
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(module=module) == False
    module._module.__dict__['_system'] = {
        'can_run_systemctl': False,
        'systemd': True
    }
    assert service_mgr_fact_collector.is_systemd_managed(module=module) == True

# Generated at 2022-06-11 05:14:03.958883
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Setup fake module obj
    class MockModule:
        def get_bin_path(self, _bin):
            if _bin == 'systemctl':
                return _bin
        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "ps -p 1 -o comm|tail -n 1":
                return 0, 'comm\n', ''
    fake_module = MockModule()

    # Setup fake collected facts
    collected_facts = {}

    # Test with mac os x
    collected_facts['ansible_distribution'] = 'MacOSX'
    collected_facts['ansible_system'] = 'Darwin'
    expected_service_mgr = 'launchd'
    _result = ServiceMgrFactCollector.collect(fake_module, collected_facts)

# Generated at 2022-06-11 05:14:14.085209
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrUnsupportedPlatformException
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrUnsupportedDistributionException
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFacts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_native

    from ansible.module_utils.compat.version import LooseVersion

    # Mocking methods

# Generated at 2022-06-11 05:14:23.656101
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class mock_module(object):
        def __init__(self):
            self.run_command_called = 0
            self.get_bin_path_called = 0
            self.run_command_rc = 0
            self.run_command_output = ''
            self.run_command_err = ''
            self.get_bin_path_output = ''

        def run_command(self, command, use_unsafe_shell=False):
            self.run_command_called += 1
            return self.run_command_rc, self.run_command_output, self.run_command_err

        def get_bin_path(self, command):
            self.get_bin_path_called += 1
            return self.get_bin_path_output
        def fail_json(self, **kwargs):
            raise Exception

# Generated at 2022-06-11 05:14:33.900745
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
   fake_module = FakeModule(ansible_facts={})
   collector = ServiceMgrFactCollector()

   fake_module.run_command = FakeMethod(return_value=(0, '/run/systemd/system/', ''))
   assert collector.is_systemd_managed(fake_module)

   fake_module.run_command = FakeMethod(return_value=(0, '', ''))
   assert not collector.is_systemd_managed(fake_module)

   fake_module.get_bin_path = FakeMethod(return_value='')
   assert not collector.is_systemd_managed(fake_module)

   fake_module.run_command = FakeMethod(return_value=(1, '', 'fake-stderr'))
   assert not collector.is_systemd_managed(fake_module)

# Unit

# Generated at 2022-06-11 05:14:44.482792
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    class fake_module:

        @staticmethod
        def get_bin_path(fake_string):
            return fake_string

        class fail_json:
            def __init__(self, msg):
                self.msg = msg

    class FakeCollector(BaseFactCollector):

        has_loaded = False
        name = 'service_mgr'

        def collect(self, module=None, collected_facts=None):
            self.has_loaded = True
            return collected_facts

    class FakeFacts(object):

        def __init__(self):
            self._facts = {}


# Generated at 2022-06-11 05:14:55.518377
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule:
        def __init__(self, rc, stdout):
            self.rc = rc
            self.stdout = stdout

        def get_bin_path(self, *args, **kwargs):
            return "/bin/systemctl"

        def run_command(self, command, use_unsafe_shell=False):
            return self.rc, self.stdout

    # Create a ServiceMgrFactCollector object
    smfc = ServiceMgrFactCollector()

    # Create necessary mocks to collect facts
    proc_1 = '/bin/systemctl'
    init = MockModule(0, "init\n")
    systemd = MockModule(0, "systemd\n")
    upstart = MockModule(0, "upstart\n")

# Generated at 2022-06-11 05:15:03.360055
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create new instance of class ServiceMgrFactCollector with empty facts dict
    smfc = ServiceMgrFactCollector({})
    # Create new module object
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False,
        )
    # Add something to the path
    module.run_command_environ_update = { 'PATH': '/usr/bin' }
    # Test collect method
    result = smfc.collect(module)
    assert result['service_mgr'] == 'sysvinit'
    # Test collect method with none module
    result = smfc.collect()
    assert result['service_mgr'] == 'service'

# Generated at 2022-06-11 05:15:12.380853
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import platform
    import re
    from ansible.module_utils._text import to_native

    from ansible.module_utils.facts.utils import get_file_content

    class SystemMock:

        mac_ver = platform.mac_ver
        system = platform.system

        def islink(self, path):
            return os.path.islink(path)

        def readlink(self, path):
            return os.readlink(path)

    class ModuleMock:

        def __init__(self, bin_path):
            self._bin_path = bin_path
            self._run_command_result = (0, '', '')

        def get_bin_path(self, name):
            return self._bin_path[name]


# Generated at 2022-06-11 05:15:20.356236
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import platform
    import tempfile
    import unittest

    class TestModule(object):
        def __init__(self, dummy_path_values=None):
            self._dummy_path_values = dummy_path_values

        def get_bin_path(self, name, opt_dirs=[]):
            return self._dummy_path_values.get(name)

        def run_command(self, cmd, use_unsafe_shell=False):
            return (0, "systemd\n", "")

    class TestServiceMgrFactCollector(unittest.TestCase):
        def test_is_systemd_managed_offline(self):
            if platform.system() != 'Linux':
                self.skipTest("The test is only applicable to Linux")


# Generated at 2022-06-11 05:15:26.906419
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import platform
    import sys
    import subprocess

    class module(object):

        return_values = {'uname': 'foo-1.0',
                         'system': 'Linux',
                         'ps': 'init',
                         'readlink': platform.system(),
                         'get_bin_path': None}

        def run_command(self, cmd, use_unsafe_shell=False):
            return [0, self.return_values[cmd.split()[1]], '']

        def get_bin_path(self, name, required=False):
            return self.return_values[name]

    _platform = platform.system()
    _distribution = 'Linux'
    if _platform == 'SunOS':
        _distribution = 'Solaris'

    m = module()

# Generated at 2022-06-11 05:16:50.522278
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class Module(object):

        def get_bin_path(self, arg):
            return 'systemctl'

    module = Module()

    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

    os.symlink('systemd', '/sbin/init')

    try:
        assert ServiceMgrFactCollector.is_systemd_managed_offline(module)
    finally:
        os.unlink('/sbin/init')

# Generated at 2022-06-11 05:16:58.102957
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule():

        def __init__(self, path):
            self.path = path

        def get_bin_path(self, path, required=False, opt_dirs=[]):
            return self.path

    module = MockModule('/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(module) is True

    module = MockModule('')
    assert ServiceMgrFactCollector.is_systemd_managed(module) is False



# Generated at 2022-06-11 05:17:02.910269
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
    """

    import tempfile
    import shutil
    import os

    class MockModule:

        def __init__(self, systemctl_path, open_func=None):
            self.systemctl_path = systemctl_path
            self.open_func = open_func

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name == 'systemctl':
                return self.systemctl_path
            return None

        def open_file(self, filename):
            if self.open_func:
                return self.open_func(filename)
            else:
                return open(filename)


# Generated at 2022-06-11 05:17:11.731916
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import get_collector_facts

    class MockModule(object):
        def __init__(self):
            self.params = {
                'gather_subset': ['all'],
            }
            self.exit_json = None

        def get_bin_path(self, binary):
            if binary == 'systemctl':
                return True
            else:
                return None

    class MockCollector(BaseFactCollector):
        name = 'mock'

        def collect(self, module=None, collected_facts=None):
            return {}

    my_collector = ServiceMgrFactCollector()
    my_module = MockModule()
    my_collector.is_systemd_managed

# Generated at 2022-06-11 05:17:20.318290
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys
    import tempfile
    import shutil

    # create an empty temporary directory
    temp_dir = tempfile.mkdtemp()
    # ensure it is empty
    assert len([name for name in os.listdir(temp_dir)]) == 0


# Generated at 2022-06-11 05:17:29.239741
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class FakeAnsibleModule(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, executable, required=True):
            return "/bin/" + executable

    class FakeBaseFactCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            self.facts = {}

    class FakeCollectorModule(object):
        def __init__(self, *args, **kwargs):
            self.ansible_facts = {}
            self.module = FakeAnsibleModule()


# Generated at 2022-06-11 05:17:36.704135
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mock_module = MockModule()

    service_mgr_fact_collector = ServiceMgrFactCollector()

    # always test uname() call on this machine.
    platform_facts = {'ansible_distribution': 'MacOSX', 'ansible_system': 'Darwin'}
    service_mgr_name = service_mgr_fact_collector.collect(
        module=mock_module, collected_facts=platform_facts)
    assert service_mgr_name.get('service_mgr') == 'launchd'

    # test other known systems
    platform_facts = {'ansible_distribution': 'FreeBSD', 'ansible_system': 'FreeBSD'}

# Generated at 2022-06-11 05:17:44.291116
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule:
        def __init__(self, run_command_returns):
            self.run_command_returns = run_command_returns

        def run_command(self, *args, **kwargs):
            return self.run_command_returns.pop(0)

        def get_bin_path(self, *args, **kwargs):
            return '/bin/systemctl'

    class MockCollector:
        def __init__(self, facts_dicts):
            self.facts_dicts = facts_dicts

        def collect(self, module=None, collected_facts=None, *args, **kwargs):
            return self.facts_dicts.pop(0)

    class MockOS:
        def __init__(self, path, islink_returns):
            self.path = path

# Generated at 2022-06-11 05:17:51.817039
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import platform
    import os
    import shutil

    from ansible.module_utils.facts.collector import sysv_service_tools
    from ansible.module_utils.facts.collector import systemd_service_tools

    # backup files
    os.rename("/sbin/init", "/sbin/init.backup")
    os.rename("/lib/systemd/systemd", "/lib/systemd/systemd.backup")

    # setup systemd
    shutil.copyfile("/lib/systemd/systemd.backup", "/lib/systemd/systemd")
    os.symlink("/lib/systemd/systemd", "/sbin/init")

    # test if systemd is detected
    c = ServiceMgrFactCollector()

# Generated at 2022-06-11 05:17:54.779240
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a fake module, since this is a static method
    module = FakeModule()
    # Execute the tested method with a valid result
    result = ServiceMgrFactCollector.is_systemd_managed_offline(module)
    # Assertions
    assert result == False

# Unit test object