

# Generated at 2022-06-11 05:10:41.194954
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Mock AnsibleModule class
    class MockModule:

        def __init__(self, p1, p2):
            self.params = {'p1': p1, 'p2': p2}

        def fail_json(self, msg):
            raise RuntimeError(msg)

    # Mock subprocess.Popen class
    class MockSubprocessPopen:

        def __init__(self, p1, stdout, stderr):
            self.stdout = stdout

        def communicate(self):
            return self.stdout, self.stderr

    # Mock platform class
    class MockPlatform:

        def __init__(self):
            self.mac_ver = lambda: ('10.13.2', ('', '', ''), 'x86_64')
            self.system = lambda: 'Darwin'
           

# Generated at 2022-06-11 05:10:52.170260
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test for the case when systemctl returns exit code 1
    module = AnsibleModuleMock()
    module.run_command.return_value = [1, '', 'Error message']
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

    # Test for the case when systemctl returns exit code 0 and stdout contains state "initializing"
    module.run_command.return_value = [0, 'initializing', '']
    assert ServiceMgrFactCollector.is_systemd_managed(module)

    # Test for the case when systemctl returns exit code 0 and stdout contains state "degraded"
    module.run_command.return_value = [0, 'degraded', '']
    assert ServiceMgrFactCollector.is_systemd_managed(module)

    # Test for the case

# Generated at 2022-06-11 05:10:56.509108
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.modules.system.service_facts
    module = ansible.modules.system.service_facts
    service_mgr_name = ServiceMgrFactCollector.is_systemd_managed(module)
    assert service_mgr_name == False

# Generated at 2022-06-11 05:11:01.299729
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # pylint: disable=import-error
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    module = MockModule()

    assert ServiceMgrFactCollector.is_systemd_managed(module=module) is False

    module.commands['systemctl'] = "/bin/systemctl"
    assert ServiceMgrFactCollector.is_systemd_managed(module=module) is True

    module.commands['systemctl'] = "/bin/systemctl"
    module.files['/run/systemd/system'] = True
    assert ServiceMgrFactCollector.is_systemd_managed(module=module) is True


# Generated at 2022-06-11 05:11:11.217349
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, params, facts):
            self.params = params
            self.facts = facts

        def run_command(self, cmd, use_unsafe_shell=True):
            if self.facts['ansible_distribution'] == 'MacOSX':
                return 1, '', ''
            elif self.facts['ansible_distribution'] == 'OpenWrt':
                return 0, '/sbin/init', ''
            return 1, '', ''

        def get_bin_path(self, cmd):
            if self.facts['ansible_distribution'] == 'MacOSX':
                return '/bin/' + cmd
            elif self.facts['ansible_distribution'] == 'OpenWrt':
                return '/sbin/init'
            return None


# Generated at 2022-06-11 05:11:18.626753
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    # Set up a Fake module object
    module = FakeModule()

    # Set up a Fake Services object
    service_mgr = ServiceMgrFactCollector()

    # Set up a Fake Facts object
    facts = FactCollector(module)

    # Set up an AnsibleModule object
    ansible_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )

    # Collect facts
    facts.collect(module=ansible_module)

    # Collect service_mgr facts
    service_mgr.collect(module=ansible_module, collected_facts=facts.get_facts())

    # Validate the results

# Generated at 2022-06-11 05:11:29.959577
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys, tempfile, os, shutil
    from ansible.module_utils.basic import AnsibleModule

    # Prepare a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Define the target object
    target = ServiceMgrFactCollector()
    target._module = AnsibleModule(argument_spec={},supports_check_mode=True)

    # Create sample test data
    os.symlink('systemd', tmp_dir + '/sbin/init')
    sys.path.append(tmp_dir)
    reload(platform)

    # Test for systemd in the SUSE case (bsc#1120588)
    os.unlink(tmp_dir + '/sbin/init')
    assert target.is_systemd_managed_offline(target._module)

    # Test for systemd in the RH

# Generated at 2022-06-11 05:11:40.332275
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys

    class MockObject(object):

        def __init__(self):
            self.ansible_system = sys.platform
            self.ansible_distribution = platform.dist()[0]

        def get_bin_path(self, path):
            return path

    mock_module_utils_module = MockObject()

    if sys.platform == 'darwin':
        from ansible.module_utils.facts.system.distribution.darwin import Distribution as DarwinDistribution

        mock_module_utils_module.ansible_system = 'Darwin'
        mock_module_utils_module.ansible_distribution = DarwinDistribution().collect()['distribution']

    if sys.platform == 'sunos5':
        from ansible.module_utils.facts.system.distribution.solaris import Distribution as SolarisDistribution

# Generated at 2022-06-11 05:11:42.667743
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import DictFacts
    collected_facts = DictFacts()
    collected_facts['ansible_system'] = 'Linux'
    mgr = ServiceMgrFactCollector()
    mgr.is_systemd_managed()

# Generated at 2022-06-11 05:11:44.552831
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = FakeModule()
    instance = ServiceMgrFactCollector()
    result = instance.is_systemd_managed_offline(module)
    assert result == False


# Generated at 2022-06-11 05:12:07.393523
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(
            ansible_facts=dict(required=False, type='dict'),
            ansible_facts_dictionary=dict(required=False, type='dict'),
            ansible_distribution=dict(required=False, type='str'),
            ansible_system=dict(required=False, type='str'),
            ansible_distribution_version=dict(required=False, type='str'),
        ),
        supported_by = 'core',
    )
    # Create a mock facts dictionary
    collected_facts = dict()
    # Create the collector
    collector = ServiceMgrFactCollector(module, collected_facts)

    # Mock the get_file_content function

# Generated at 2022-06-11 05:12:16.947365
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class MyBaseFactCollector(BaseFactCollector):
        name = 'base'

        def _collect(self, module=None, collected_facts=None):
            return {}

    class MyModule:

        def get_bin_path(self, cmd):
            if cmd == 'systemctl' and '/bin/systemctl' in ['/bin/systemctl']:
                return '/bin/systemctl'
            return None


# Generated at 2022-06-11 05:12:26.661122
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    '''
    Test ServiceMgrFactCollector is_systemd_managed method
    '''

    svc_mgr_fact_collector = ServiceMgrFactCollector()
    class MockModule(object):
        def __init__(self):
            self.bin_path = '/bin'
            self.systemctl = '/bin/systemctl'
            self.path = '/bin'

        def get_bin_path(self, command):
            if command == 'systemctl':
                return self.systemctl
            return None

    class MockFile(object):
        def __init__(self, exists):
            self.exists = exists

        def exists(self):
            return self.exists
    module = MockModule()
    os = MockFile(False)
    # Test that init is systemd managed if systemctl tools are installed


# Generated at 2022-06-11 05:12:31.018078
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    collector = Collector()
    collector.collect()

    sut = ServiceMgrFactCollector()
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os

    # mock module calls
    class OpenRCModule(AnsibleModule):
        def get_bin_path(self, executable=None, required=False, opt_dirs=[]):
            return sut.get_bin_path(self, executable=executable, required=required, opt_dirs=opt_dirs)


# Generated at 2022-06-11 05:12:36.762830
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """Unit test for method collect of class ServiceMgrFactCollector"""

    import sys
    import pytest
    from ansible.module_utils.facts import FactCollector

    class ModuleStub:
        def get_bin_path(self, command, required=True):
            if command == 'systemctl':
                return '/bin/echo'
            return

    class CollectedFactsStub:
        def __init__(self):
            self.facts = {
                'ansible_distribution': 'MacOSX',
                'ansible_system': 'openrc',
            }

    def mock__is_systemd_managed(self, module):
        return True

    def mock__is_systemd_managed_offline(self, module):
        return True


# Generated at 2022-06-11 05:12:38.099705
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert 'systemd' == ServiceMgrFactCollector.is_systemd_managed({})

# Generated at 2022-06-11 05:12:44.504162
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = DummyModule()
    if os.path.exists('/sbin/init'):
        os.remove('/sbin/init')
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)
    os.symlink('systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)
    os.remove('/sbin/init')


# Generated at 2022-06-11 05:12:54.216653
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Mock module for unit test
    class AnsibleModule(object):
        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/usr/bin/systemctl'
            else:
                return None

    # Import modules needed for dependencies
    import sys
    import os
    import platform

    # Add path to unit test module
    sys.path.append(os.path.dirname(os.path.realpath(__file__)))

    # Import definitions for unit test
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Import module under test
    from ansible.module_utils.facts import service_mgr

    # Init variables for unit test
    module = AnsibleModule()
    service_mgr_collector = service_mgr.ServiceMgrFactCollector

# Generated at 2022-06-11 05:13:04.715080
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.common.collections import ImmutableDict

    class ModuleMock(object):
        def __init__(self):
            pass

        def get_bin_path(self, name, opts=None):
            if name == 'systemctl':
                return '/bin/systemctl'

    module = ModuleMock()
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False

    module.path_exists = lambda path: path == '/run/systemd/system/'
    assert ServiceMgrFactCollector.is_systemd_managed(module) == True

    del module.path_exists

# Generated at 2022-06-11 05:13:14.039030
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    '''Test ServiceMgrFactCollector.is_systemd_managed()'''
    import os
    import tempfile

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    # create a temporary directory to hold test data
    tmpdir = tempfile.mkdtemp()

    # create a no-op module
    class DummyModule:
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir
            self.run_command_environ_update = dict()
            self.PATH = '/bin:/usr/bin'

        def get_bin_path(self, name):
            return '/bin/' + name


# Generated at 2022-06-11 05:13:55.361508
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import platform

    # Create a temporary directory (and change to it)
    if platform.system() != 'SunOS':
        test_dir = tempfile.TemporaryDirectory()
        os.chdir(test_dir.name)
    else:
        test_dir = os.getcwd()

    # Test that the functions returns false if the file being linked to is not
    # systemd
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(None)

    # Create a file to be symlinked to
    os.mkdir('testdir')
    with open('testdir/somefile.txt', 'w') as f:
        f.write('foobar')

    # Test that the function returns false if the file being linked to is not
    # systemd

# Generated at 2022-06-11 05:14:02.574049
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class Module:
        def get_bin_path(self, path):
            return True
    module = Module()
    collector = ServiceMgrFactCollector()
    assert(collector.is_systemd_managed_offline(module)) == False
    with open('/sbin/init', 'w') as out:
        out.write('# /bin/sh\n')
        out.write('ls / >/dev/null\n')
    os.symlink('/sbin/init', '/sbin/init.systemd')
    assert(collector.is_systemd_managed_offline(module)) == True

# Generated at 2022-06-11 05:14:12.560516
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module_mock = Mock()
    module_mock.get_bin_path.return_value = "dummy_path"

    service_mgr_fact_collector = ServiceMgrFactCollector()

    # case 1: /sbin/init is not a symlink
    os.readlink = Mock()
    os.readlink.return_value = False

    os.path.islink = Mock()
    os.path.islink.return_value = True

    assert not service_mgr_fact_collector.is_systemd_managed_offline(module_mock)

    # case 2: /sbin/init is a symlink to systemd
    os.path.islink.return_value = True
    os.readlink.return_value = "systemd"

    assert service_mgr_fact_

# Generated at 2022-06-11 05:14:22.229249
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock
    from ansible_collections.ansible.community.tests.unit.modules.shared.test_module import TestAnsibleModule

    # Test with systemd managed, but offline
    ansible_module = TestAnsibleModule()
    ansible_module.get_bin_path = Mock(return_value='/sbin/systemctl')
    os.path.islink = Mock(return_value=True)
    os.readlink = Mock(return_value='systemd')
    assert(ServiceMgrFactCollector.is_systemd_managed_offline(ansible_module) is True)

    # Test with systemd not managed
    os.path.islink = Mock(return_value=False)

# Generated at 2022-06-11 05:14:32.219884
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    import tempfile

    if platform.system() != 'Linux':
        print("test_ServiceMgrFactCollector_is_systemd_managed is only runnable on Linux system")
        return

    class FakeAnsibleModule(object):
        def get_bin_path(self, binary):
            return binary

    def mktempdir(prefix='/tmp'):
        tempdir = tempfile.mkdtemp(prefix=prefix)
        return tempdir

    def mkdummyfile(filepath):
        with open(filepath, 'w') as fd:
            fd.write("dummy text")
        return

    instance = ServiceMgrFactCollector()

    # test1: /run/systemd/system exists
    tmpdir = mktempdir()

# Generated at 2022-06-11 05:14:43.045255
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.facts as facts
    import ansible.module_utils.facts.collector as collector
    import ansible.module_utils.facts.system.service_mgr as service_mgr


    class MockModule(object):
        def __init__(self, systemctl_exists):
            self.systemctl_exists = systemctl_exists

        def get_bin_path(self, command, *further_args, **more_args):
            if command == "systemctl":
                return "/bin/systemctl" if self.systemctl_exists else None

    class MockCollector(object):
        def __init__(self, name, cache_dir):
            pass

        def collect(self, module, collected_facts):
            return {}

    facts.FACTS = {}
   

# Generated at 2022-06-11 05:14:52.839513
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Make sure module_utils.facts.collector.BaseFactCollector exists
    module = MagicMock(path=[])
    module.get_bin_path = MagicMock(return_value=None)
    module.run_command = MagicMock(return_value=(0, b'', ''))

    # Empty collected_facts
    collected_facts = dict()

    # Create an instance of ServiceMgrFactCollector
    fact_collector = ServiceMgrFactCollector()

    # Collect facts
    facts_dict = fact_collector.collect(module=module, collected_facts=collected_facts)

    # Assert that some facts were collected
    assert facts_dict is not None

# Generated at 2022-06-11 05:15:02.597996
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Cache
    from ansible.module_utils.facts.collector import get_file_content
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.utils import get_file_lines, get_file_content
    from ansible.module_utils.facts import default_collectors

    module = AnsibleModule(argument_spec={})

    # Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector with invalid arguments
    with pytest.raises(TypeError) as excinfo:
        detected_service_manager = ServiceMgrFactCollect

# Generated at 2022-06-11 05:15:07.897853
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class Module(object):
        @staticmethod
        def get_bin_path(arg):
            return "/bin/systemctl"
        @staticmethod
        def run_command(arg, use_unsafe_shell=None):
            return (0, "stdout", "stderr")

    module = Module()
    obj = ServiceMgrFactCollector()
    assert obj.is_systemd_managed_offline(module) is False


# Generated at 2022-06-11 05:15:16.419730
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform

    fake_module = type('FakeModule', (object,), dict(run_command=lambda *args, **kwargs: (0, 'init', ''), get_bin_path=lambda _: 1))()
    fake_platform_facts = {'ansible_system': "Linux", 'ansible_distribution': 'CentOS'}

# Generated at 2022-06-11 05:16:41.770638
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import collect_facts
    from ansible.module_utils.facts.collector.platform.service_mgr import ServiceMgrFactCollector
    
    collected_facts = collect_facts(ServiceMgrFactCollector)
    assert collected_facts['service_mgr'] in ['sysvinit', 'systemd', 'launchd', 'bsdinit', 'src', 'src', 'smf', 'openwrt_init', 'upstart','openrc','service']


# Generated at 2022-06-11 05:16:51.181690
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Stub module object
    class Module():
        def __init__(self):
            self._file_content_cache = {}

        def get_bin_path(self, command):
            return None

        def run_command(self, command, use_unsafe_shell=False):
            return (0, '', '')

        def get_file_content(self, path):
            return self._file_content_cache.get(path)

    # Stub Ansible module_utils
    class AnsibleModuleUtils():
        class facts():
            collected_facts = {
                'ansible_distribution': '',
                'ansible_system': '',
            }

    # Create module object
    module = Module()

    # Create Ansible module_utils
    module_utils = AnsibleModuleUtils()

    # Create ServiceMgr

# Generated at 2022-06-11 05:17:00.836351
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import AnsibleFact
    from ansible.module_utils.facts import ModuleBase

    class DummyModule(ModuleBase):
        def get_bin_path(self,binary):
            return "/usr/bin/systemctl"

    class DummyAnsibleFact(AnsibleFact):
        def __init__(self):
            self.collector = ServiceMgrFactCollector()
            self.values = self.collector.collect(DummyModule())

    ansible_fact = DummyAnsibleFact()
    if ansible_fact.get_service_mgr() == "systemd":
        exit(0)
    else:
        exit(1)

# Generated at 2022-06-11 05:17:09.907554
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Mock required modules
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    # Mock class imports
    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.os = MockOsModule()
    ansible.module_utils.facts.collector.platform = MockPlatformModule()

    # Instantiate class
    obj = ServiceMgrFactCollector()

    # Set attributes to mock values
    obj.required_facts = obj.required_facts.union(set(['platform', 'distribution']))

    # Create mock module

# Generated at 2022-06-11 05:17:18.614082
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import platform
    import ansible.module_utils.facts.collectors.service_mgr

    # test systemd
    # Create empty module
    class module(object):
        def __init__(self):
            self.params = dict()

        def fail_json(self, msg):
            print(msg)

    # Create empty module
    class module_b(object):
        def __init__(self):
            self.params = dict()

        def fail_json(self, msg):
            print(msg)

    # Create empty module
    class module_c(object):
        def __init__(self):
            self.params = dict()

        def fail_json(self, msg):
            print(msg)

    class platform:
        system = "Linux"

    # Test if systemd is running

# Generated at 2022-06-11 05:17:19.139023
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-11 05:17:28.098942
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import shutil
    import platform
    import tempfile


    class MockModule(object):
        def __init__(self, files):
            self.files = files

        def get_bin_path(self, cmd):
            return self.files.get(cmd)

        def run_command(self, cmd, use_unsafe_shell=False):
            # Check for return code, stdout, stderr
            if cmd == "ps -p 1 -o comm|tail -n 1":
                return 0, '/bin/sh', ""
            return 1, '', ""

# Generated at 2022-06-11 05:17:35.606328
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr

    method = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed

    class DummyModule:
        def get_bin_path(self, command):
            return '/bin/systemctl' if command == 'systemctl' else None

    # systemd checks
    fake_os = DummyModule()
    fake_os.run_command = lambda command: ('', '/run/systemd/system/', 0)
    assert method(fake_os) == True

    # init checks
    fake_os = DummyModule()
    fake_os.run_command = lambda command: ('', '', 0)
    fake_os.is_systemd_managed = lambda: True

    assert method(fake_os)

# Generated at 2022-06-11 05:17:43.100051
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=None) == False

    # Return `False` if run on a platform different to Linux
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=object()) == False

    # Return `False` if /sbin/init is not a symbolic link
    def get_bin_path(_):
        return ''

    def islink(_):
        return False

    module = type('', (), {'get_bin_path': classmethod(get_bin_path), 'run_command': lambda *args: (1, '', ''), 'os': type('', (), {'readlink': classmethod(lambda *args: 'systemd')})()})()
    setattr(module.os, 'islink', classmethod(islink))

# Generated at 2022-06-11 05:17:50.861369
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts import CallableModule
    import tempfile, shutil

    # create dummy symlink to systemd
    tmpdir = tempfile.mkdtemp()
    systemd_symlink = os.path.join(tmpdir, 'systemd')
    os.symlink(os.path.join(tmpdir, 'dummy'), systemd_symlink)

    # prep module args