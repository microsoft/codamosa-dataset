

# Generated at 2022-06-11 05:10:39.148440
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule:
        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell=True):
            if cmd == "ps -p 1 -o comm|tail -n 1":
                return (0, "/sbin/init\n", '')
            else:
                return (1, '', '')

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.gather import gather_subset
    from ansible.module_utils.facts import ANSIBLE_GATHER_SUBSET

    module = MockModule()

# Generated at 2022-06-11 05:10:49.932468
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule:
        @staticmethod
        def get_bin_path(path):
            return True

        @staticmethod
        def run_command(command, use_unsafe_shell=False):
            return (0, '', '')

    class MockModule2:
        @staticmethod
        def get_bin_path(path):
            if path == 'systemctl':
                return 'systemctl'
            return ''

        @staticmethod
        def run_command(command, use_unsafe_shell=False):
            return (0, '', '')

    class MockModule3:
        @staticmethod
        def get_bin_path(path):
            return 'systemctl'

        @staticmethod
        def run_command(command, use_unsafe_shell=False):
            return (0, '', '')

   

# Generated at 2022-06-11 05:10:59.518777
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.system import SystemFactCollector

    '''
    test_get_collector_instance: Test the get_collector_instance method of class Collector

    :return:
    '''

# Generated at 2022-06-11 05:11:09.332712
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class mock_module:
        def get_bin_path(self, command, **kwargs):
            return "/bin/%s" % command

    class mock_platform:
        system = 'Linux'

    class mock_platform_failing:
        system = 'Linux'

        @staticmethod
        def mac_ver():
            return None

    class mock_platform_mac:
        system = 'Darwin'

        @staticmethod
        def mac_ver():
            return ('10.8.2', ('', '', ''), 'x86_64')

    class mock_facts:
        ansible_distribution = "CentOS"
        ansible_system = "Linux"

    class mock_facts_bsd:
        ansible_distribution = "BSD"
        ansible_system = "Linux"


# Generated at 2022-06-11 05:11:17.349607
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import pytest
    import ansible.module_utils.facts.service_mgr
    import ansible.module_utils.facts.collector
    from ansible.module_utils import basic

    # Create an instance of the MockModule class
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Create service manager collector object
    service_mgr_collector = ansible.module_utils.facts.service_mgr.ServiceMgrFactCollector()

    # Create an instance of the MockFile class
    class MockFile(object):

        def __init__(self, func='exists'):
            self.func = func
            self.count = 0
            self.calls = []


# Generated at 2022-06-11 05:11:28.427617
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Prepare Mocks
    # TODO: use mock patch instead
    class MockFactsCollectorModule(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = False
            self.exit_json = Mock()
            self.fail_json = Mock()
            self.get_bin_path = Mock(return_value=True)
            self.run_command = Mock(return_value=('','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''))


# Generated at 2022-06-11 05:11:33.447023
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module_exec = {}
    service_mgr_get_facts = ServiceMgrFactCollector(module_exec)

    hosts = {"localhost": {"ansible_facts": {"ansible_distribution": "OpenWrt"}}}
    results = service_mgr_get_facts.collect(hosts, {})
    assert results['service_mgr'] == "openwrt_init"

# Generated at 2022-06-11 05:11:43.206803
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            if path == 'systemctl':
                return '/bin/systemctl'
            else:
                return None
    module = MockModule()
    collector = ServiceMgrFactCollector()
    assert (collector.is_systemd_managed(module) == False), "did not detect when not installed"

    module.get_bin_path = lambda x: '/bin/systemctl'
    assert (collector.is_systemd_managed(module) == False), "did not detect when not managed"

# Generated at 2022-06-11 05:11:48.776953
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class module:
        @staticmethod
        def get_bin_path(name):
            if name == "systemctl":
                return "/bin/systemctl"
            else:
                return None
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module)
    class bad_module:
        @staticmethod
        def get_bin_path(name):
            return None
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(bad_module)

# Generated at 2022-06-11 05:11:57.819306
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import CollectedFacts

    # Dummy module that will always use the tmp-dir as root-dir for testing
    def null_execute_module():
        pass
    module = type('Module', (object,), dict(run_command=null_execute_module, tmpdir='/tmp/'))

    # Create a CollectedFacts object
    collected_facts = CollectedFacts(module)

    # Test system with systemd present
    def run_command_systemd(cmd, use_unsafe_shell):
        if cmd=='systemctl':
            return (0, '/bin/systemctl', None)
    module.run_command = run_command_systemd
    module.os.path.exists = lambda path: path == '/run/systemd/system/'
    service_m

# Generated at 2022-06-11 05:12:17.116320
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils
    import ansible.module_utils.basic
    import ansible.module_utils.facts.collector

    class MockModule(object):
        def __init__(self, rc, stdout, stderr):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr

        def get_bin_path(self, executable):
            return '/usr/bin/' + executable

        def run_command(self, cmd):
            return self.rc, self.stdout, self.stderr

    # systemd is reported as the boot init system, systemd is found
    mock_module = MockModule(0, 'upstart', '')
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module) is True

    # systemd is

# Generated at 2022-06-11 05:12:25.739053
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule(object):
        def get_bin_path(self, tool, default=None):
            if tool == 'systemctl':
                return '/bin/systemctl'
            else:
                return

        def run_command(self, cmd, use_unsafe_shell=False):
            if cmd == "ps -p 1 -o comm|tail -n 1":
                return 0, 'init', None
            else:
                return 0, '', ''

    mock_module = MockModule()
    collected_facts = dict()

    facts_dict = ServiceMgrFactCollector().collect(mock_module, collected_facts)

    assert facts_dict == {'service_mgr': 'sysvinit'}

# Generated at 2022-06-11 05:12:27.415524
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

# Generated at 2022-06-11 05:12:36.910611
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import facts
    from ansible.module_utils.facts import testing
    import os

    class TestModule(object):

        def __init__(self):
            self.run_command_calls = 0
            self.run_command_results = []
            self.run_command_exceptions = []

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/systemctl'

        def run_command(self, *args, **kwargs):
            self.run_command_calls += 1
            if self.run_command_exceptions:
                raise self.run_command_exceptions.pop()
            if self.run_command_results:
                return self.run_command_results.pop()
            raise Exception("run_command called without results")



# Generated at 2022-06-11 05:12:39.854079
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    assert ServiceMgrFactCollector.is_systemd_managed(module=None) == False

# Generated at 2022-06-11 05:12:50.620673
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system.service_mgr

    module_mock = ansible.module_utils.basic.AnsibleModule(
        argument_spec={}
    )

    module_mock.get_bin_path = lambda program: '/bin/' + program

    # Systemd not detected
    def os_path_exists(path):
        if path == '/run/systemd/system/':
            return False
        return True
    module_mock.run_command = lambda cmd, shell=True: (0, '', '')
    module_mock.os.path.exists = os_path_exists
    assert not ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_

# Generated at 2022-06-11 05:12:56.586276
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts
    import ansible.module_utils.facts.collectors.service_mgr
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.system

    # Mock a module.
    class MockModule(object):

        def mock_get_bin_path(self, name, opt_dirs=[]):
            bin_path = '/bin/' + name
            return bin_path

        def __init__(self):
            self.run_command = Mock(return_value=(0, None, None))
            self.get_bin_path = Mock(side_effect=self.mock_get_bin_path)
            self.params = {}


# Generated at 2022-06-11 05:13:07.262209
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import __main__
    import json
    import os
    import platform
    import shutil
    import tempfile

    # Used to save the module_utils path
    old_module_utils_path = __main__.__dict__.get('module_utils_path')

    systemd_run_dir = '/run/systemd/system/'
    systemd_dev_dir = '/dev/.run/systemd/'
    systemd_dev_dir_2 = '/dev/.systemd/'

    if not os.path.exists(systemd_run_dir) and not os.path.exists(systemd_dev_dir) and not os.path.exists(systemd_dev_dir_2):
        # Create the directory needed to test
        os.makedirs(systemd_run_dir)

# Generated at 2022-06-11 05:13:16.123217
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import callback_facts
    from ansible.module_utils.facts.collector import get_collector_class

    my_collector_class = get_collector_class('service_mgr')
    my_collector = my_collector_class()
    assert hasattr(my_collector, 'collect')
    assert my_collector.collect({'ansible_facts': {'distribution': 'MacOSX'}}).get('service_mgr') == 'launchd'
    assert my_collector.collect({'ansible_facts': {'distribution': 'MacOSX', 'ansible_system': 'BSD'}}).get('service_mgr') == 'bsdinit'

# Generated at 2022-06-11 05:13:24.260063
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    import os
    import tempfile

    class MockModule(object):
        def get_bin_path(self, cmd):
            return True

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False):
            return 0, "sentinel", "error"

    class MockFactsCollector(object):
        def __init__(self, module):
            self

# Generated at 2022-06-11 05:13:47.651319
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys
    import json
    import inspect
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.six import PY3

    if PY3: # python3
        from io import StringIO
        my_stdout = StringIO()
    else:
        from StringIO import StringIO
        my_stdout = StringIO()

    module = ansible_collector
    module.run_command = lambda x: (0, x, '')
    module.get_bin_path = lambda x: '/bin/%s' % x
    module.fail_json = ModuleFail

# Generated at 2022-06-11 05:13:57.026902
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import six
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    class MyModule(object):
        def get_bin_path(self, name):
            return True

        def run_command(self, cmd, use_unsafe_shell=False):
            # return True for sd_booted
            return 0, six.binary_type('t'), None

    class MyOpen(object):
        def __init__(self, path, mode='r'):
            pass

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            pass

        def read(self):
            # return True for sd_booted
            return six.binary_type('t')


# Generated at 2022-06-11 05:14:06.684445
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os 
    import shutil
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import facts
    
    # Create temporary directory to perform test
    temp_dir = tempfile.mkdtemp()
    module = AnsibleModule({'module_utils': temp_dir})
    
    # Create fake is_systemd_managed
    def is_systemd_managed(self):
        return False

    # Create fake init symlink file
    path = os.path.join(temp_dir, 'sbin/init')
    os.symlink('systemd', path)
    
    # Replace method
    ServiceMgrFactCollector.is_systemd_managed = is_systemd_managed
    
    # Test

# Generated at 2022-06-11 05:14:16.518810
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test of module output if /run/systemd/system exists
    module = namedtuple('Module', ['get_bin_path'])()
    module.get_bin_path = MagicMock(return_value='/bin/systemctl')

    os.path.exists = MagicMock(return_value=True)

    fact_collector = ServiceMgrFactCollector()
    result = fact_collector.is_systemd_managed(module)
    assert result == True

    # Test of module output if /run/systemd/system does not exist
    module = namedtuple('Module', ['get_bin_path'])()
    module.get_bin_path = MagicMock(return_value='/bin/systemctl')

    os.path.exists = MagicMock(return_value=False)

    fact_

# Generated at 2022-06-11 05:14:26.493957
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import shutil
    import ansible.module_utils.facts.collectors

    old_platform = platform.system
    old_systemctl_path = ansible.module_utils.facts.collectors.ServiceMgrFactCollector.systemctl_path

# Generated at 2022-06-11 05:14:37.054417
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # setup mocked module
    module = AnsibleModuleMock()
    module.get_bin_path = MagicMock()
    module.get_bin_path.return_value = 'systemctl'

    # run tests
    assert(ServiceMgrFactCollector.is_systemd_managed(module) == False)
    module.get_bin_path.assert_called_once_with('systemctl')

    module.get_bin_path.reset_mock()
    module.reset_mock()

    module.get_bin_path.return_value = None
    assert(ServiceMgrFactCollector.is_systemd_managed(module) == False)
    module.get_bin_path.assert_called_once_with('systemctl')

    # create mocks
    module.get_bin_path.reset_mock

# Generated at 2022-06-11 05:14:46.361389
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.compat import mock
    from ansible.module_utils.basic import AnsibleModule

    # Create mock module as if ansible-playbook was called like this:
    # ansible-playbook -m debug -e 'msg={{ ansible_service_mgr }}' -i inventory
    # -e 'ansible_facts={"distribution":"MockLinux","ansible_distribution_version":"1.2.3","ansible_architecture":"X86_64"}'

# Generated at 2022-06-11 05:14:57.094071
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.system import get_module_path
    from ansible.module_utils.facts.system.system import get_module_resource
    from ansible.module_utils.facts.system.system import get_platform_subclass

    from ansible.module_utils.basic import AnsibleModule

    class Module(AnsibleModule):
        def get_bin_path(self, arg):
            return 'true'

        def run_command(self, arg, use_unsafe_shell=False):
            return 0, 'output', 'error'

    module = Module(
        argument_spec={},
        supports_check_mode=True
    )


# Generated at 2022-06-11 05:15:00.520548
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class MockModule(object):
        def get_bin_path(self, cmd):
            return '/bin/{0}'.format(cmd)

    m = MockModule()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(m)

# Generated at 2022-06-11 05:15:03.313632
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.service_mgr as service_mgr
    m = service_mgr.ServiceMgrFactCollector()
    assert m.is_systemd_managed(None) == True

# Generated at 2022-06-11 05:15:41.722861
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create an instance of class ServiceMgrFactCollector
    coll = ServiceMgrFactCollector()
    # Create a 'fake' module object with needed attributes
    class fakeModule(object):
        def __init__(self):
            self.bin_path = dict()
            self.bin_path['systemctl'] = '/usr/bin/systemctl'
        def get_bin_path(self, bin_path):
            return self.bin_path[bin_path]
    class fakeDistro(object):
        def __init__(self):
            self.osfamily = dict()
            self.osfamily['Linux'] = 'Linux'
            self.osfamily['SunOS'] = 'SunOS'
    distro = fakeDistro()
    module = fakeModule()
    # Test this method for Linux and for Solaris
    # On

# Generated at 2022-06-11 05:15:47.941008
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # mock module
    class MockModule:
        def __init__(self):
            self.params = {}
            return

        def get_bin_path(self, module_name):
            return '/usr/bin/systemctl'

    module = MockModule()
    # create instance of class
    smf = ServiceMgrFactCollector()
    def _os_readlink(path):
        if path == '/sbin/init':
            return '/lib/systemd/systemd'
        return ''

    def _os_path_exists(path):
        if path == '/sbin/init':
            return True
        return False

    smf.fetch_file_content = lambda x: None
    smf.get_file_content = lambda x: None
    smf.os_path_exists = _os_path_

# Generated at 2022-06-11 05:15:54.980225
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    class TestServiceMgrFactCollector(ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector):
        def __init__(self, module):
            self.module = module

        def collect(self, module=None, collected_facts=None):
            return ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.collect(self)

    # Make sure it properly detects systemd
    module = MockModule()
    module.run_command = lambda path: (0, 'systemd', '')
    collector = TestServiceMgrFactCollector(module)
    assert collector.is_system

# Generated at 2022-06-11 05:16:03.144030
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule:
        def get_bin_path(self, name):
            if name == 'systemctl':
                return 'systemctl'
            return None

    class MockUtilityContainer:
        def __init__(self):
            self.openwrt_init = False
            self.systemd = False
            self.upstart = False

        def is_systemd_managed(self, module=None):
            if self.systemd:
                return True
            return False

        def is_systemd_managed_offline(self, module=None):
            if self.systemd:
                return True
            return False

    mm = MockModule()
    mm.run_command = lambda *args, **kwargs: (0, '', '')
    mm.check_mode = False
    mc = MockUtilityContainer()
   

# Generated at 2022-06-11 05:16:06.301888
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module_mock = MockModule()
    service_mgr_fact_collector_instance = ServiceMgrFactCollector()
    service_mgr_fact_collector_instance.is_systemd_managed(module=module_mock)



# Generated at 2022-06-11 05:16:14.118405
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    out = dict()
    module = type("AnsibleModule", (object,), dict(run_command=lambda x, **kwargs: (0, '', '')))()
    setattr(module, 'get_bin_path', lambda *args: '/bin/systemctl')
    setattr(module, 'check_mode', lambda *args: False)

    collector = ServiceMgrFactCollector()
    collector.collect(module=module, collected_facts=out)
    assert out['ansible_facts']['service_mgr'] == 'systemd'
    # call collect a second time to make sure it's idempotent
    collector.collect(module=module, collected_facts=out)
    assert out['ansible_facts']['service_mgr'] == 'systemd'

# Generated at 2022-06-11 05:16:20.206885
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import unittest.mock as mock

    module = mock.Mock()
    module.get_bin_path.return_value = '/bin/systemctl'

    return_value_true = True
    return_value_false = False

    with mock.patch('os.path.exists', lambda x: return_value_true):
        assert ServiceMgrFactCollector().is_systemd_managed(module=module)

    with mock.patch('os.path.exists', lambda x: return_value_false):
        assert not ServiceMgrFactCollector().is_systemd_managed(module=module)


# Generated at 2022-06-11 05:16:28.873890
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # service_mgr fact collect test for is_systemd_managed method
    class TestModule:
        def get_bin_path(self, path):
            return '/usr/bin/systemctl'

    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed(TestModule()) == True

    # service_mgr fact collect test for is_systemd_managed_offline method
    class TestModule:
        def get_bin_path(self, path):
            return '/usr/bin/systemctl'

    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed_offline(TestModule()) == True

    # service_mgr fact collect test for collect method

# Generated at 2022-06-11 05:16:39.273823
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Add imports here
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector import get_file_content

    # Create the test object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Create module mock
    class Module():
        def get_bin_path(self, arg):
            return('')

    module = Module()
    module.get_bin_path = Module.get_bin_path

    # Create os.path.islink mock
    class Islink():
        def __init__(self, arg):
            self.arg = arg
            self.return_value = 'systemd'

    os.path.islink = Islink

    # Create os mock

# Generated at 2022-06-11 05:16:48.675394
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    serviceMgrFactCollector = ServiceMgrFactCollector()

    test_module = AnsibleModule(argument_spec=dict())

    test_module.get_bin_path('systemctl')

    # both conditions must be met, link exists and its target is "systemd"
    os.symlink('systemd', '/sbin/init')
    assert True == serviceMgrFactCollector.is_systemd_managed_offline(module=test_module)

    # link exists but its target is not "systemd"
    os.symlink('other_system_init', '/sbin/init')
    assert False == serviceMgrFactCollector.is_systemd_managed_offline(module=test_module)

    # link does not exists
    os.remove('/sbin/init')
    assert False == serviceMgr

# Generated at 2022-06-11 05:17:46.461316
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    p = platform.system()
    if p != 'Linux':
        # This test will not work on any other platform than Linux
        return True

    class MockModule(object):
        def __init__(self):
            self._module = None

        def set_module(self, module):
            self._module = module

        def get_bin_path(self, command):
            # Mocked to always return the command
            return command

        def run_command(self, command, use_unsafe_shell=False):
            # Mocked to return various results, depending on argument
            if command == "ps -p 1 -o comm|tail -n 1":
                return (0, 'myservicedaemon\n', None)
            elif command == "systemctl":
                return (1, None, None)

    m = MockModule()



# Generated at 2022-06-11 05:17:47.535296
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    ServiceMgrFactCollector.is_systemd_managed(module=None)

# Generated at 2022-06-11 05:17:48.948594
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed(None) == False

# Generated at 2022-06-11 05:17:56.485991
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector

    # Create fake module object
    class Module():
        def get_bin_path(self, exe, required=False):
            return '/bin/systemctl'

    # Create fake service mgr collector object
    fake_collected_facts = {}
    serv_mgr_coll = ServiceMgrFactCollector(fake_collected_facts)

    # test positive
    os.symlink('/bin/systemd', '/sbin/init')
    assert serv_mgr_coll.is_systemd_managed_offline(Module())

    # test negative
    os.unlink('/sbin/init')
    assert not serv_mgr_coll.is_systemd_managed_offline(Module())

    # test negative with no bin path
    Module.get_bin

# Generated at 2022-06-11 05:17:58.272424
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) is False


# Generated at 2022-06-11 05:18:04.524840
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class MockModule:
        def get_bin_path(self, path, opt_dirs=[]):
            return None

    def mock_exists(path):
        if path == "/run/systemd/system/":
            return True
        else:
            return False

    fc = ServiceMgrFactCollector()
    mock_module = MockModule()
    fc.is_systemd_managed(mock_module)
    mock_module.get_bin_path = lambda path, opt_dirs: None
    assert fc.is_systemd_managed(mock_module) == False
    mock_module.get_bin_path = lambda path, opt_dirs: "systemctl"

# Generated at 2022-06-11 05:18:05.462028
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    collector = ServiceMgrFactCollector()
    facts_dict = collector.collect()
    assert 'service_mgr' in facts_dict


# Generated at 2022-06-11 05:18:09.466163
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    # Create mock module class
    class MockModule:
        mock_bin_path = '/root/bin/systemctl'
        mock_os = 'Linux'
        def get_bin_path(self, command):
            if command == 'systemctl':
                return self.mock_bin_path
            return None

    # Create mock system class
    class MockSystem:
        mock_os_name = 'Linux'
        def os(self):
            return self.mock_os_name

    # Create mock os class
    class MockOS:
        mock_exists_1 = False
        mock_exists_2 = False
        mock_exists_3 = False
        def exists(self, path):
            if path == '/run/systemd/system/':
                return self.mock_exists_1


# Generated at 2022-06-11 05:18:17.686993
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    '''test_ServiceMgrFactCollector_is_systemd_managed
    Test if Systemd is the service manager
    '''

    # Note that mock requires python 2.7 or later
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    module = Mock()
    module.get_bin_path.return_value = None
    module.os.path.exists.return_value = False

    svc_mgr_fact_collector = ServiceMgrFactCollector()

    assert not svc_mgr_fact_collector.is_systemd_managed(module)

    module.get_bin_path.return_value = True
    module.os.path.exists.return_value = True

# Generated at 2022-06-11 05:18:24.533286
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import platform
    import shutil
    import tempfile
    import unittest

    from ansible.module_utils.facts import collector

    class MockModule(object):
        def __init__(self, execute=False, **kwargs):
            self.params = kwargs
            self.execute = execute
        def get_bin_path(self, module):
            return '/sbin/test-systemctl'

    class TestServiceMgrFactCollector(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.orig_path = os.environ['PATH']
            os.environ['PATH'] = ':'.join([self.tmpdir, os.environ['PATH']])