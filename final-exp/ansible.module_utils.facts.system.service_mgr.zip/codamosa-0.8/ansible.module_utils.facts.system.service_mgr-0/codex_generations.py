

# Generated at 2022-06-11 05:10:40.900223
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """ Unit test for method "is_systemd_managed" of class "ServiceMgrFactCollector" """

    class MockModule:
        """ Mock module """

        def __init__(self):
            self.params = {}

        def get_bin_path(self, path_name):
            """ mock get_bin_path """

            script_dir = os.path.dirname(__file__)
            if path_name == 'systemctl':
                return os.path.join(script_dir, 'systemctl')

            return ''

    class MockCollector(ServiceMgrFactCollector):
        """ Mock collector """

        def __init__(self):
            self.facts = {}

    os.symlink('systemd', 'is_systemd_managed_fake_systemd_link')

# Generated at 2022-06-11 05:10:51.562800
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import os
    import shutil
    import tempfile
    import pytest
    # we need to create a fake directory to always have a content at the canaries
    tmpdir = tempfile.mkdtemp()
    module = type('', (), {"get_bin_path": lambda X, y: True})
    try:
        os.makedirs(os.path.join(tmpdir, "run/systemd/system/"))
        os.makedirs(os.path.join(tmpdir, "dev/.run/systemd/"))
        os.makedirs(os.path.join(tmpdir, "dev/.systemd/"))
        assert ServiceMgrFactCollector.is_systemd_managed(module) is True
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-11 05:11:00.919829
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import os
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import BaseFactCollector

    (handle, tmp_tool_path) = tempfile.mkstemp(prefix='ansible_test_systemctl')
    os.close(handle)

    (handle, tmp_canary_path) = tempfile.mkstemp(prefix='ansible_test_systemctl')
    os.close(handle)

    os.write(handle, to_bytes(''))
    os.close(handle)

    class Module:
        def get_bin_path(self, name):
            if name == 'systemctl':
                return tmp_tool_path
            else:
                return None

   

# Generated at 2022-06-11 05:11:10.819285
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    def mock_require(self, *args, **kwargs):
        pass

    def mock_get_file_content(path):
        if path == '/proc/1/comm':
            return 'systemd'
        return None

    def mock_run_command(self, *args, **kwargs):
        if args[0] == 'systemctl --version':
            return 0, 'systemd 229', ''
        elif args[0] == 'ps -p 1 -o comm|tail -n 1':
            return 0, 'init', ''

    def mock_get_bin_path(self, *args, **kwargs):
        if args[0] == 'systemctl':
            return '/bin/systemctl'
        elif args[0] == 'initctl':
            return '/sbin/initctl'

# Generated at 2022-06-11 05:11:18.147570
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    class MockModule:
        def get_bin_path(self, path):
            return '/bin/path/to'

    class MockSystemdCanaryPath:
        exists = False

        def __init__(self, path):
            if path == '/bin/path/to':
                self.exists = True

    # Mock os module
    os.path.exists = MockSystemdCanaryPath

    # check if the is_systemd_managed returns True
    assert ServiceMgrFactCollector.is_systemd_managed(MockModule())

    class NotSystemdCanaryPath:
        exists = True

        def __init__(self, path):
            if path == '/bin/path/to':
                self.exists = False

    os.path.exists = NotSystemdCanaryPath

    # check if is_system

# Generated at 2022-06-11 05:11:26.017797
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Make sure method collect returns a dictionary
    class MyModule(object):
        def __init__(self, *args):
            pass
        def get_bin_path(self, *args):
            return None
    mock_module = MyModule()
    mock_module.run_command = lambda *args: (0, '', '')
    test_obj = ServiceMgrFactCollector()
    service_mgr = test_obj.collect(module=mock_module)
    assert service_mgr == {'service_mgr': 'service'}

# Generated at 2022-06-11 05:11:36.429073
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.is_systemd_managed_offline({'get_bin_path': lambda _: 'systemctl'}) is False
    assert fact_collector.is_systemd_managed_offline({'get_bin_path': lambda _: None}) is False
    assert fact_collector.is_systemd_managed_offline({'get_bin_path': lambda _: 'systemctl'}) is False
    assert fact_collector.is_systemd_managed_offline({'get_bin_path': lambda _: 'systemctl'}) is False
    os.symlink('systemd', '/sbin/init')

# Generated at 2022-06-11 05:11:45.136553
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    m = Mock()

    assert not ServiceMgrFactCollector.is_systemd_managed(m)
    m.get_bin_path().return_value = 'systemctl'
    assert not ServiceMgrFactCollector.is_systemd_managed(m)

    m.get_bin_path().return_value = 'systemctl'
    m.run_command().return_value = ['', '', '']
    assert not ServiceMgrFactCollector.is_systemd_managed(m)

    m.get_bin_path().return_value = 'systemctl'
    m.run_command().return_value = ['', '', '']
    m.os.path.exists.return_value = True
    assert ServiceMgrFactCollector.is_systemd_managed(m)


# Generated at 2022-06-11 05:11:54.075544
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import inspect
    import os

    module = MockModuleUtils()
    module.run_command.return_value = (0, 'fts', '')
    module.get_bin_path.return_value = '/usr/bin/systemctl'

    # SUSE
    os.symlink('systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=module)
    os.unlink('/sbin/init')

    # vanilla systemd distro
    os.symlink('/lib/systemd/systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=module)
    os.unlink('/sbin/init')

    # non-systemd init
    assert not ServiceMgr

# Generated at 2022-06-11 05:11:56.917662
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(['systemctl']) == False
    assert ServiceMgrFactCollector.is_systemd_managed_offline(['init']) == False

# Generated at 2022-06-11 05:12:14.785729
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create a fake module object
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Create a ServiceMgrFactCollector object
    s = ServiceMgrFactCollector()

    # Check if 'service_mgr' fact is present
    assert 'service_mgr' in s.collect()

# Generated at 2022-06-11 05:12:24.538353
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import inspect

    # Collect the function reference
    method = inspect.getmembers(ServiceMgrFactCollector, predicate=inspect.ismethod)[0][1]

    # Provide the required argument (module)
    # class AnsibleModule:
    #     virtual module for passing module arguments
    #     def __init__(self, module_args):
    #         self.params = module_args
    #     def get_bin_path(self, arg):
    #         if arg == 'systemctl':
    #             return 'systemctl'
    #         else:
    #             return None
    # ansible_module = AnsibleModule()
    # ansible_module.get_bin_path = lambda: 'systemctl'

    class AnsibleModule():
        pass
    ansible_module = AnsibleModule()
    ansible_module

# Generated at 2022-06-11 05:12:28.492742
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class MockModule:
        def get_bin_path(self, command):
            return '/bin/{0}'.format(command)

    serviceMgr = ServiceMgrFactCollector()
    m = MockModule()
    assert serviceMgr.is_systemd_managed_offline(m) == False

# Generated at 2022-06-11 05:12:37.896984
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(
                        os.path.abspath(__file__))))
    import ansible.module_utils.facts.service_mgr as service_mgr
    import ansible.module_utils
    class FakeModule(object):
        def get_bin_path(self, exe, opt_dirs=[]):
            return os.path.join(root_dir, 'lib', 'ansible', 'module_utils',
                                'systemd', 'systemctl')
        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, '', ''
    service_mgr_fact = service_mgr.ServiceMgrFactCollector({})

# Generated at 2022-06-11 05:12:48.764450
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import mock
    import tempfile
    test_class = ServiceMgrFactCollector()

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary systemd-sysvinit package, in the Debian package format
    tmp_path = os.path.join(tmpdir, 'systemd-sysvinit_2.110-2_amd64.deb')

# Generated at 2022-06-11 05:12:52.134528
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector
    assert ServiceMgrFactCollector.is_systemd_managed_offline(BaseFactCollector) == False

# Generated at 2022-06-11 05:13:02.234254
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import platform
    os = platform.system()
    service_mgr_name = None
    is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed()
    if os == 'Linux':
        if is_systemd_managed:
            service_mgr_name = 'systemd'
        else:
            service_mgr_name = 'service'
    elif os == 'SunOS':
        service_mgr_name = 'smf'

    # create a fake module
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    def get_bin_path(cmd):
        return None


# Generated at 2022-06-11 05:13:04.486268
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed(dict(get_bin_path=lambda x: '/bin/systemctl'))

# Generated at 2022-06-11 05:13:13.836301
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    platform_mock = 'Linux'
    distribution_mock = 'CentOS'

    class _module_mock(object):
        def __init__(self, *args, **kwargs):
            self.params = {}
            self._debug = None
            self._verbosity = None
        def get_bin_path(self, *args, **kwargs):
            return None

    class _result_mock(object):
        def __init__(self, rc):
            self.rc = rc
            self.stdout = None
            self.stderr = None

    class _collected_facts_mock(dict):
        def __getitem__(self, name):
            return self.get(name, None)

        def __setitem__(self, name, value):
            self[name] = value

    s

# Generated at 2022-06-11 05:13:22.015134
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class Platform:
        system = "Linux"

        @staticmethod
        def mac_ver():
            return ("10.8.52", ("", "", ""), "x86_64")

    class Module:
        def __init__(self):
            self._platform = Platform()
            self.params = {}

        def get_bin_path(self, binary):
            if binary == "systemctl":
                return "/sbin/systemctl"
            else:
                self.params["binaries"] = binary

        @staticmethod
        def run_command(command):
            return 0, "init", ""

    class CollectedFacts:
        def __init__(self):
            self.ansible_distribution = "Linux"
            self.ansible_system = "Linux"

    p = ServiceMgrFactCollector()

   

# Generated at 2022-06-11 05:13:54.210344
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    '''
    This is a dummy test.
    This test won't fail and will print 'Success: ServiceMgrFactCollector collect test'.
    '''
    ServiceMgrFactCollector().collect()

    print('Success: ServiceMgrFactCollector collect test')

# Generated at 2022-06-11 05:14:03.626202
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector

    # Define test cases
    # Each test case is a dict containing a 'name', 'input' and 'output' key.
    # The 'name' is used in logging and as the name of the test case.
    # The 'input' is used as the input for the test.
    # The 'output' is the expected output from the test.

# Generated at 2022-06-11 05:14:13.691011
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # Test with a platform which is not systemd-enabled
    assert not ServiceMgrFactCollector.is_systemd_managed(None)

    # Test with a platform whose /proc/1/comm is not systemd,
    # but which has systemd executables
    class Module:
        def get_bin_path(self, name):
            # Return a path to /bin/systemctl if it exists
            if name == 'systemctl':
                return os.path.join(os.environ['PATH'].split(os.pathsep)[0], 'systemctl')
            return None
    module = Module()
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

    # Test with a platform whose /proc/1/comm is systemd,
    # and which has systemd executables

# Generated at 2022-06-11 05:14:23.309225
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import base_subset
    from ansible.module_utils.facts.collector import DummyModule

    def get_bin_path(name, opts=None):
        return name

    def is_systemd_managed(module):
        return False

    def is_systemd_managed_offline(module):
        return False

    class MockedFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.facts = {}
            self.module = MockedModule()

        def collect(self, module=None, collected_facts=None):
            # Distribution is set to Linux as the default distribution
            collected_facts = {'ansible_distribution': 'Linux'}

# Generated at 2022-06-11 05:14:33.494890
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    import sys

    class MockModule:
        def get_bin_path(self, path):
            # implement the required method so that the class could be used in tests
            assert False
            return None

    content = 'this is systemd managed'
    with open('/run/systemd/system/', 'w') as file_fd:
        file_fd.write(content)

    # Run unit test
    if sys.version_info < (2, 7):
        return dict(msg='skipping due to python2.6')
    else:
        mock_module = MockModule()
        fact_collector = FactCollector(mock_module, collected_facts=dict())

# Generated at 2022-06-11 05:14:43.044386
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class TestModule:
        def get_bin_path(self, cmd):
            if cmd == "systemctl":
                return "/bin/systemctl"
            return None

    smfc = ServiceMgrFactCollector()

    test_module = TestModule()

    # Test 1: empty metadata dict
    result = smfc.is_systemd_managed_offline(test_module)
    assert result == False

    # Test 2: valid metadata dict, script from which we derive the init system
    os.symlink("systemd", "/sbin/init")
    result = smfc.is_systemd_managed_offline(test_module)
    assert result == True
    os.remove("/sbin/init")

# Generated at 2022-06-11 05:14:54.794161
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.service_mgr as module
    module.is_systemd_managed = module.ServiceMgrFactCollector.is_systemd_managed
    import ansible.module_utils.facts.system.service_mgr as facts_service_mgr_module
    is_systemd_managed = facts_service_mgr_module.is_systemd_managed

    class TestModule():
        def get_bin_path(self, name):
            return name
        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, 'stdout', 'stderr'
    module.os = os
    os.path.exists = lambda canary: canary == '/run/systemd/system/'

    is_systemd_managed_ = is_system

# Generated at 2022-06-11 05:15:04.122564
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector._fact_ids = set()
    ServiceMgrFactCollector.required_facts = set(['platform', 'distribution'])

    class Mock:
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return

        def get_file_content(self, *args, **kwargs):
            return 'init'

        def get_platform(self, *args, **kwargs):
            return 'linux'

        def get_distribution(self, *args, **kwargs):
            return 'Linux'

    mock = Mock()
    result = ServiceMgrFactCollector().collect(module=mock)
    assert result['service_mgr'] == 'sysvinit'

# Generated at 2022-06-11 05:15:13.008694
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    class ModuleMock:
        class BaseException:
            pass
        # raise module.fail_json on error
        def fail_json(self, msg):
            raise self.BaseException(msg)

        # check if commands are installed
        def get_bin_path(self, command):
            if command == 'systemctl':
                return '/sbin/systemctl'
            elif command == 'systemd-analyze':
                return '/usr/bin/systemd-analyze'
            else:
                return '/usr/bin/foo'

        # run command

# Generated at 2022-06-11 05:15:19.138852
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    import ansible_collections.ansible.community.plugins.module_utils.facts.collectors as collectors
    module = AnsibleModuleMock()
    module.get_bin_path = lambda x: ''
    module.run_command = lambda cmd, use_unsafe_shell: (0, '', '')
    service_mgr_collector = collectors.service_mgr.ServiceMgrFactCollector()
    service_mgr_collector.collect(module=module, collected_facts={})


# Generated at 2022-06-11 05:16:12.690910
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import sys
    import os
    import shutil
    import tempfile

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collect_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Monkey patch the is_systemd_managed method
    def _is_systemd_managed(self, module=None):
        if self.os_version[:2] == "20":
            if self.os_family == "Ubuntu":
                self.fs = True
            else:
                self.fs = False
        else:
            self.fs = True
        return self.fs


# Generated at 2022-06-11 05:16:18.993658
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts import collector
    import pytest
    from os import path
    from shutil import rmtree

    # Create a dictionary to hold the path to the temporary directories
    temp_dirs = {}

    def setup_module(module):
        # Create one directory
        temp_dirs['/etc/systemd'] = tempfile.mkdtemp()
        temp_dirs['/run/systemd'] = tempfile.mkdtemp()
        temp_dirs['/dev/.run'] = tempfile.mkdtemp()
        temp_dirs['/dev/.systemd'] = tempfile.mkd

# Generated at 2022-06-11 05:16:25.644803
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Initialize the ServiceMgrFactCollector
    service_mgr_collector = ServiceMgrFactCollector()

    # Initialize a module
    module = AnsibleModule(argument_spec={})

    # check if /sbin/init is a symlink to systemd
    # on SUSE, /sbin/init may be missing if systemd-sysvinit package is not installed.
    if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
        return True
    else:
        return False


# Generated at 2022-06-11 05:16:35.189762
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class var:
        def __init__(self, name, value):
            self.name = name
            self.value = value
    from ansible.module_utils.facts.collector import BaseFactCollector
    class BaseFactCollectorOverride(BaseFactCollector):
        def __init__(self, module=None):
            self.module = None
            self.collected_facts = None
        def collect(self, module, collected_facts=None):
            self.module = module
            self.collected_facts = collected_facts
            return {}
    from ansible.module_utils.facts import collector
    collector._fact_classes['BaseFactCollectorOverride'] = BaseFactCollectorOverride
    from ansible.module_utils.facts.collector import get_collector_instance

# Generated at 2022-06-11 05:16:44.697639
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Test class with module/class as dict
    mock_module = type('ansible_module', (object,), dict(
        run_command=lambda self, cmd, check_rc=True: (0, 'init', ''),
        get_bin_path=lambda self, name: None,
        is_systemd_managed=lambda self: False,
    ))()

    collector = ServiceMgrFactCollector()
    data = collector.collect(module=mock_module)
    assert data == dict(service_mgr='sysvinit')

    # Test class with module/class as dict

# Generated at 2022-06-11 05:16:54.814133
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mock_ansible_module = MockAnsibleModule()
    mock_ansible_module.shell = '/bin/sh'

    # mock is_systemd_managed
    mock_ansible_module.get_bin_path.side_effect = [None, None, None, '/usr/bin/systemctl']
    mock_ansible_module.path_has_mode.side_effect = [True, False, False]
    mock_ansible_module.path_exists.side_effect = [True, False, False, False, False]
    mock_ansible_module.readlink.side_effect = ['systemd']

    # mock is_systemd_managed_offline
    mock_ansible_module.path_exists.side_effect = [True, True, False]

# Generated at 2022-06-11 05:16:56.424156
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    data = ServiceMgrFactCollector.collect(None, None)
    assert data['service_mgr'] == 'service'

# Generated at 2022-06-11 05:17:05.725783
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile, sys, os, shutil
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.service_mgr.service_mgr import ServiceMgrFactCollector

    tmpdir = tempfile.mkdtemp()

    # test /sbin/init is not a symlink
    os.symlink('/bin/bash', os.path.join(tmpdir, 'init'))
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(BaseFactCollector(module=None, collected_facts={}))

    os.unlink(os.path.join(tmpdir, 'init'))

    # test /sbin/init is a symlink, but not to systemd

# Generated at 2022-06-11 05:17:14.749857
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Prerequiste: Ansible should be installed on the testing machine
    import sys
    sys.path.append('/usr/share/ansible')
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    class TestModule:

        def __init__(self):
            self.paths = []

        def get_bin_path(self, tool):
            return tool in self.paths

        def run_command(self, cmd, use_unsafe_shell=None):
            if cmd == 'ps -p 1 -o comm|tail -n 1':
                return 0, 'systemd\n', ''
            return 0, '', ''


# Generated at 2022-06-11 05:17:17.540105
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    module = ansible.module_utils.facts.collector.BaseFactCollector()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) is True

# Generated at 2022-06-11 05:19:00.896402
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr

    systemd_manager = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed

    assert systemd_manager({"get_bin_path": lambda cmd: "/bin/systemctl"}) is True
    assert systemd_manager({"get_bin_path": lambda cmd: "/bin/systemctl", "stat": lambda path: [0, 0, 16, 0, 0, 0]}) is False
    assert systemd_manager({"get_bin_path": lambda cmd: "/bin/systemctl"}) is True
    assert systemd_manager({"get_bin_path": lambda cmd: "/bin/systemctl", "/run/systemd/system": False}) is False

# Generated at 2022-06-11 05:19:08.592479
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule
    import os

    test_dir = 'test/unit/module_utils/ansible/module_utils/facts/collector/test_data/systemd'
    # test when /sbin/init is not a symlink
    module = MockModule(run_command_exists=True, run_command_isfile=True)
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

    module = MockModule(run_command_exists=True, run_command_isfile=True, tmpdir=test_dir)
    os.symlink('systemd', os.path.join(module.tmpdir, 'sbin/init'))

# Generated at 2022-06-11 05:19:12.224963
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    module = None

    # This test case result based on value of ansible_system
    # and not value of ansible_service_mgr
    value = ServiceMgrFactCollector().is_systemd_managed(module)
    assert not value



# Generated at 2022-06-11 05:19:20.420028
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import get_collector_instance

    # create a dummy module
    module_args = {}
    setattr(basic.AnsibleModule, 'run_command', lambda self: (0, to_bytes('systemd'), ''))
    module = basic.AnsibleModule('no_name', module_args)

    service_mgr_fact_collector = ServiceMgrFactCollector
    service_mgr_fact_collector._initialized = False
    service_mgr_fact_collector = get_collector_instance(service_mgr_fact_collector)

    service_mgr_name = service_mgr_fact_collector.is_systemd_managed_

# Generated at 2022-06-11 05:19:26.444209
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys

    if sys.version_info[0] >= 3:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    # Create mocked module
    module = MagicMock()

    # Create mocked facts
    facts = dict()

    # Get class instance
    service_manager = ServiceMgrFactCollector()

    # Test is_systemd_managed_offline method
    service_manager.is_systemd_managed_offline(module)
    module.get_bin_path.assert_called_with('systemctl')


# Generated at 2022-06-11 05:19:33.470007
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class Module(object):
        def __init__(self, params):
            self.params = params

# Generated at 2022-06-11 05:19:40.569654
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed({}) == False
    assert ServiceMgrFactCollector.is_systemd_managed({'get_bin_path': lambda x: '/bin/false%s' % x}) == False
    assert ServiceMgrFactCollector.is_systemd_managed({'get_bin_path': lambda x: '/bin/true%s' % x}) == False
    assert ServiceMgrFactCollector.is_systemd_managed({'get_bin_path': lambda x: '/bin/true%s' % x, 'run_command': lambda c: (0, '/bin/systemd', '')}) == False

# Generated at 2022-06-11 05:19:48.108432
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, command):
            if 'systemctl' in command:
                return '/bin/systemctl'
            else:
                return None
    class MockFacts(object):
        def get(self, fact):
            if fact == 'ansible_system':
                return 'Linux'
            else:
                return None
    def mock_isfile(file):
        if 'systemd' in file:
            return True
        else:
            return False

    import sys
    import os
    import re
    import platform
    sys.modules['ansible'] = type('mock_ansible', (object,), {'__name__': 'ansible'})

# Generated at 2022-06-11 05:19:56.589355
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    # Setup mocks
    m_proc_1 = None
    m_is_systemd_managed = False
    m_get_file_content = lambda path: m_proc_1
    m_is_systemd_managed_offline = False

# Generated at 2022-06-11 05:20:02.898019
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Unit test for method collect of class ServiceMgrFactCollector
    """

    from ansible.module_utils.facts.collector import collector_module
    from ansible.module_utils.facts import default_collectors

    current_collectors = default_collectors
    default_collectors = ['ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector']
    ansible_module = collector_module()
    facts_dict = ansible_module.get_facts()
    default_collectors = current_collectors
    assert isinstance(facts_dict, dict)
    assert 'service_mgr' in facts_dict