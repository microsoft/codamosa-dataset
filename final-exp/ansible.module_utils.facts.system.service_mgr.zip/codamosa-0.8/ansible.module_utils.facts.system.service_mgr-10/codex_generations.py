

# Generated at 2022-06-11 05:10:42.319067
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import platform
    import tempfile

    from ansible.module_utils.facts.collector import BaseFactCollector

    class Module:
        def __init__(self):
            self.exit_json = lambda **kwargs: None
            self.fail_json = lambda **kwargs: None

        def run_command(self, cmd, *args, **kwargs):
            return True, "", ""

        def get_bin_path(self, toolname):
            if toolname == "systemctl":
                return True

    class FactsCollector(BaseFactCollector):
        name = 'service_mgr'
        _fact_ids = set()
        required_facts = set(['platform', 'distribution'])

    m = Module()

    tmp_dir = tempfile.mkdtemp()
    os.syml

# Generated at 2022-06-11 05:10:53.429102
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = "/usr/bin/systemctl"
    mock_module.run_command.return_value = 0, "not init", ""
    mock_module.run_command.return_value = 0, "cron", ""
    mock_collected_facts = {
        'platform': 'Linux',
        'ansible_distribution': 'openwrt'
    }
    mock_ServiceMgrFactCollector = ServiceMgrFactCollector()
    assert mock_ServiceMgrFactCollector.collect(module=mock_module, collected_facts=mock_collected_facts) == {'service_mgr': 'openwrt_init'}
    mock_module.get_bin_path.assert_called_with('systemctl')


# Generated at 2022-06-11 05:10:58.457980
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Init module mock
    module = AnsibleModule(argument_spec=dict())
    setattr(module, 'get_bin_path', mock.MagicMock(return_value='systemctl'))

    # Create an instance of ServiceMgrFactCollector
    service_manager = ServiceMgrFactCollector(module)

    # Mock os.path.exists.
    # Return True when the function is called with a canary.
    with mock.patch.object(os.path, 'exists') as mock_path_exists:
        for canary in ["/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"]:
            mock_path_exists.return_value = False
            assert service_manager.is_systemd_managed(module) is False

# Generated at 2022-06-11 05:11:03.499854
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.six import PY2
    from ansible.module_utils.facts.utils import get_file_content

    class CustomBaseFactCollector(BaseFactCollector):

        def __init__(self, *args, **kwargs):
            self.ansible_module = AnsibleModuleMock()

    class AnsibleModuleMock:
        def __init__(self):
            self.bin_path_return = '/bin/systemctl'

        def get_bin_path(self, bin_path, required=False):
            return self.bin_path_return

    class OsMock:

        def __init__(self, path_exists_return_value):
            self.path_exists_return_value = path

# Generated at 2022-06-11 05:11:13.444598
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    '''
    Unit test for method collect of class ServiceMgrFactCollector
    '''
    service_mgr_fc = ServiceMgrFactCollector()

    # Mock module
    class Module(object):
        def __init__(self):
            self.params = {}
            self.exit_json = {}
            self.run_command_output = ""
            self.run_command_rc = 0
        def set_params(self, module_args):
            self.params = module_args
        def get_bin_path(self, check_cmd_path):
            return True
        def run_command(self, cmd, use_unsafe_shell=True):
            return self.run_command_output, self.run_command_rc, ""
        def _log_invocation(self):
            return None

# Generated at 2022-06-11 05:11:22.603433
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    '''
    Test if is_systemd_managed works correctly with different cases
    '''

    def is_systemd_managed_mock(module):
        return "expected"

    class MockModule(object):
        def __init__(self):
            self.params = {}

        # Mock ansible.module_utils.facts.utils.is_systemd_managed
        # with is_systemd_managed_mock
        def get_bin_path(self, executable, required=False):
            return is_systemd_managed_mock(self)

    module = MockModule()

    # The tested method is a static method. Call it through the class.
    if ServiceMgrFactCollector.is_systemd_managed(module) != "expected":
        raise Exception('is_systemd_managed not mocked')


# Generated at 2022-06-11 05:11:30.106583
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Note: this test requires to have coreutils package installed on the system
    # because it uses the 'readlink' command.
    module = AnsibleModuleMock()
    module.get_bin_path = MagicMock(return_value='/usr/bin/readlink')
    module.run_command = MagicMock(return_value=(0, '../usr/lib/systemd/systemd', ''))

    collector = ServiceMgrFactCollector()
    assert True == collector.is_systemd_managed(module=module)

# Generated at 2022-06-11 05:11:40.417755
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil

    fact_collector = ServiceMgrFactCollector()

    # Testing with no init symlink
    os.environ['PATH'] = '/bin:/usr/bin'
    os.environ['PATH'] += ':' + os.path.abspath(os.path.realpath(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'hacking', 'testdeps')))
    module = AnsibleModuleMock()

    assert fact_collector.is_systemd_managed_offline(module) is False

    # Testing with an init symlink to another program
    tmp_path = tempfile.mkdtemp(prefix='ansible_test_system_is_systemd_managed_offline')

# Generated at 2022-06-11 05:11:47.648591
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr as service_mgr
    import types

    for mock_module in [types.ModuleType('ansible.module_utils.facts.system.service_mgr'),
                        types.ModuleType('ansible.module_utils.facts.system.service_mgr', systemctl='/usr/bin/systemctl', service_mgr=types.ModuleType('service_mgr'))]:
        sm = service_mgr.ServiceMgrFactCollector(mock_module)
        # Expected result for ModuleType('ansible.module_utils.facts.system.service_mgr')
        expected_result = False
        assert(sm.is_systemd_managed(mock_module) == expected_result)

# Generated at 2022-06-11 05:11:48.860652
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed(None) is False

# Generated at 2022-06-11 05:12:10.621789
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule():
        def __init__(self, params=None):
            self.params = {
                'filter': '*',
                'gather_subset': ['all']
            }
            if params is not None:
                self.params = params
        def fail_json(self, msg):
            raise AssertionError(msg)
        @staticmethod
        def get_bin_path(arg, required=False, opt_dirs=[]):
            return '/usr/bin/' + arg
        @staticmethod
        def run_command(arg, use_unsafe_shell=False, check_rc=True, encoding=None, errors='surrogate_then_replace'):
            return 0, '', ''

    class MockFacts():
        def __init__(self):
            self.platform = 'Linux'

# Generated at 2022-06-11 05:12:12.538427
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False


# Generated at 2022-06-11 05:12:15.604837
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert not ServiceMgrFactCollector.is_systemd_managed(None)
    assert ServiceMgrFactCollector.is_systemd_managed(MockModule('/bin/systemctl'))


# Generated at 2022-06-11 05:12:25.375140
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule
    import os

    test_module = MockModule(path='/bin/systemctl')

    # Dummy canary files to be used in tests
    dummy_file_list = ['/run/systemd/system/', '/dev/.run/systemd/', '/dev/.systemd/']
    dummy_files_exist = False
    dummy_files_not_exist = False
    for dummy_file in dummy_file_list:
        if not os.path.exists(dummy_file):
            dummy_files_not_exist = True
            fd = os.open(dummy_file, os.O_CREAT)
            os.close(fd)

# Generated at 2022-06-11 05:12:34.705640
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    test_class = ServiceMgrFactCollector()
    test_module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # test no systemctl
    test_module.get_bin_path = lambda x: None
    assert not test_class.is_systemd_managed(test_module)

    # test /run/systemd/system/
    test_module.get_bin_path = lambda x: "/usr/bin/systemctl"
    test_module.run_command = lambda x, check_rc=None, use_unsafe_shell=None: (0, "", "")

# Generated at 2022-06-11 05:12:44.108188
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from . import TestModule
    from ansible.module_utils import basic

    facts_dict = {}
    testmgr = ServiceMgrFactCollector()
    mock_module = TestModule(
        module_args=dict(),
        basic=basic,
        facts=facts_dict
    )

    # Test init system with systemd
    init_file_systemd = '/etc/systemd/system/'
    retval = testmgr.is_systemd_managed_offline(mock_module)
    assert retval == False

    # Test init system with systemd
    init_file_systemd = '/sbin/init'
    retval = testmgr.is_systemd_managed_offline(mock_module)
    assert retval == False

# Generated at 2022-06-11 05:12:47.166377
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """
    Tests for method is_systemd_managed of class ServiceMgrFactCollector.
    """
    # TODO: mock module object
    # assert...



# Generated at 2022-06-11 05:12:56.374428
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils.facts import ansible_collector

    test_collector = ServiceMgrFactCollector
    m = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 05:13:06.900435
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Mock module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )

    # Mock facts

# Generated at 2022-06-11 05:13:14.846823
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create a ServiceMgrFactCollector object
    s = ServiceMgrFactCollector()

    # Import AnsibleModule
    from ansible.module_utils.facts.collector import AnsibleModule

    # Create a fake AnsibleModule object
    module = AnsibleModule(argument_spec={})

    # Check that is_systemd_managed_offline does not recognize systemd PID 1
    # on non-Linux system
    if platform.system() == 'SunOS':
        # Skip this test on SunOS
        pass
    else:
        fake_os_readlink_output = "fake_systemd"
        assert s.is_systemd_managed_offline(module=module) == False

    return

# Generated at 2022-06-11 05:13:45.156595
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    smfc = ServiceMgrFactCollector()

    class FakeModule:
        def get_bin_path(self, arg):
            return ("/bin/systemctl", None)

    fm = FakeModule()
    # Pass fake module object and expected output of the method
    assert smfc.is_systemd_managed_offline(fm)

# Generated at 2022-06-11 05:13:46.506018
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed(None) == False

# Generated at 2022-06-11 05:13:52.576109
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    mock_module = MockModule()
    mock_module.run_command.return_value = 0, "", ""
    mock_module.get_bin_path.return_value = "/usr/bin/systemctl"
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module) is True
    mock_module.get_bin_path.return_value = None
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module) is False


# Generated at 2022-06-11 05:13:55.791759
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = '/bin/systemctl'
    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed(module) == False


# Generated at 2022-06-11 05:14:05.093230
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_module = DummyModule()
    test_module.run_command = mock_run_command
    test_module.get_bin_path = mock_get_bin_path
    test_module.get_file_content = mock_get_file_content

    sut = ServiceMgrFactCollector()

    # Run tests with various facts
    for collected_facts in [{}, {"ansible_distribution": "Linux", "ansible_system": "WeakHost"}, {"ansible_distribution": "MacOSX"}, {"ansible_distribution": "OpenWrt"}, {"ansible_distribution": "OpenWrt", "ansible_system": "StrongHost"}, {"ansible_system": "AIX"}, {"ansible_system": "SunOS"}, {"ansible_system": "Linux"}]:
        expected_result = {}
        # Run

# Generated at 2022-06-11 05:14:07.081747
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed(None) == False


# Generated at 2022-06-11 05:14:16.888727
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import sys
    import os
    import tempfile
    import platform
    import shutil
    import pytest

    # The import below is needed when running unit tests on Python 2.x
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # if not on linux, skip the test
    if platform.system() != 'Linux':
        return

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create subdirectories in the temporary directory
    systemd_dir = tmpdir + '/run/systemd/system'
    if not os.path.isdir(systemd_dir):
        os.makedirs(systemd_dir)
    devrun_dir = tmpdir + '/dev/.run/systemd'

# Generated at 2022-06-11 05:14:26.900561
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    systemctl_paths = [
        "/usr/bin/systemctl",
        "/bin/systemctl",
        "/sbin/systemctl",
        "/usr/local/bin/systemctl"
    ]
    canaries = [ "/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/" ]

    # Test with systemctl installed, with /run/systemd/system/
    module = mock.Mock()
    module.get_bin_path.side_effect = lambda x: systemctl_paths[0] if x == 'systemctl' else None
    path_exists_returns

# Generated at 2022-06-11 05:14:33.492713
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector

    is_systemd_managed = ansible.module_utils.facts.collector.ServiceMgrFactCollector.is_systemd_managed
    assert(is_systemd_managed)


if __name__ == '__main__':
    import ansible.module_utils.facts.collector

    # Unit test for method is_systemd_managed of class ServiceMgrFactCollector
    test_ServiceMgrFactCollector_is_systemd_managed()

# Generated at 2022-06-11 05:14:36.575072
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test_module = AnsibleModule(argument_spec={})
    test_collector = ServiceMgrFactCollector()
    test_collector.is_systemd_managed(test_module)

# Generated at 2022-06-11 05:15:53.039745
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # FIXME: This test does not work on a system with systemd. Because the test
    # is run on the system, it can not be run on a system with systemd.
    # Make sure is_systemd_managed_offline returns False on a system without systemd.
    import platform
    old_system = platform.system()
    platform.system = lambda: 'Linux'

    class MockModule:
        def run_command(self, cmd, use_unsafe_shell=True):
            return 1, None, None
        def get_bin_path(self, cmd):
            return '/bin/' + cmd

    assert not ServiceMgrFactCollector.is_systemd_managed_offline(MockModule())

    # Don't forget to clean up
    platform.system = old_system

# Generated at 2022-06-11 05:16:01.034194
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactProtocol
    module_mock = DistributionFactProtocol()
    distro_facts = DistributionFactCollector(module=module_mock)
    distro_facts.collect()

    service_mgr_facts = ServiceMgrFactCollector(module=module_mock)

    # test if /sbin/init is a symlink to systemd
    module_mock.run_command = lambda x: (0, '/sbin/init -> /lib/systemd/systemd', '')
    assert service_mgr_facts.is_systemd_managed_off

# Generated at 2022-06-11 05:16:09.631212
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Define a fake module and collected_facts
    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return None

    class FakeCollectedFacts(dict):
        def __init__(self):
            self['ansible_distribution'] = 'MacOSX'
            self['ansible_system'] = 'X86_64'

    # Call the method collect of the class ServiceMgrFactCollector
    service_mgr_collector = ServiceMgrFactCollector()
    results = service_mgr_collector.collect(module=FakeModule(), collected_facts=FakeCollectedFacts())

    # FIXME: find way to query executable, version matching is not ideal

# Generated at 2022-06-11 05:16:16.867456
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector

    # Create a temporary module with the required arguments for the collect method
    def get_bin_path(path):
        return path

    test_module = type(
        'AnsibleModule',
        (object, ),
        {
            "run_command": lambda self, cmd: (0, cmd, None),
            "get_bin_path": get_bin_path
        }
    )

    test_module = test_module()

    test_facts = dict()

    # Create instance of ServiceMgrFactCollector which is tested
    sut = ServiceMgrFactCollector()

    # Call method collect of ServiceMgrFactCollector instance
    returned_facts = sut.collect(test_module, test_facts)

    # Check if returned facts dict has the expected keys


# Generated at 2022-06-11 05:16:25.333489
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class MockModule():
        def get_bin_path(self, path):
            return '/bin/' + path

    # Monkey patching MockModule to return correct value of is_systemd_managed_offline method
    MockModule.is_systemd_managed_offline = ServiceMgrFactCollector.is_systemd_managed_offline

    module = MockModule()

    # Case 1: /sbin/init is a symlink to systemd
    os.symlink('systemd', '/sbin/init')

    # assert the return value of is_systemd_managed_offline method is True
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) is True

    # Case 2: /sbin/init is a symlink to init

# Generated at 2022-06-11 05:16:31.481914
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.service_mgr_fact_collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import mock_module
    # Create a mocked module
    module = mock_module(command_start='/bin/systemctl')
    # Create a mocked ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector(module)
    assert service_mgr_fact_collector.is_systemd_managed_offline(module)

# Generated at 2022-06-11 05:16:41.192522
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector()
    collector.module = Mock(name='module')
    collector.module.get_bin_path.return_value = True
    os.path.islink = Mock()

    os.path.islink.return_value = False
    assert not collector.is_systemd_managed_offline(collector.module)

    os.path.islink.return_value = True
    os.readlink = Mock(return_value='systemd')
    assert collector.is_systemd_managed_offline(collector.module)

    os.readlink = Mock(return_value='non_systemd_init')
    assert not collector.is_systemd_managed_offline(collector.module)



# Generated at 2022-06-11 05:16:50.623175
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import DummyModule
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    m = DummyModule()
    s = ServiceMgrFactCollector()

    m.get_bin_path = lambda x: "/bin/" + x
    # systemd is not running
    for canary in ["/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"]:
        m.stat = lambda x: None if x == canary else [0,0]
    assert s.is_systemd_managed(m) == False

    # systemd is running

# Generated at 2022-06-11 05:17:00.061128
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    class MockModule(object):
        def get_bin_path(self, path):
            return path

    # Make sure /sbin/init does not exist
    os.system("rm -f /sbin/init")

    # Check that the result is False when /sbin/init does not exist
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=MockModule()) == False

    # Make sure /sbin/init is a symlink to systemd
    os.system("/bin/ln -s /bin/systemd /sbin/init")

    # Check that the result is False when /sbin/init is a symlink to systemd
    assert ServiceMgrFactCollector.is_systemd_managed_off

# Generated at 2022-06-11 05:17:09.270763
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/usr/bin/systemctl'
            return None
