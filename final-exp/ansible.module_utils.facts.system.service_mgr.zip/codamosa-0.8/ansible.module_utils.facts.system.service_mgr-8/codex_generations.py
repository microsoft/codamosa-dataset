

# Generated at 2022-06-11 05:10:39.299405
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    # create a dummy module
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    # create an instance of ServiceMgrFactCollector
    service_mgr_collector = ServiceMgrFactCollector()
    # Test if the method returns a boolean
    assert (service_mgr_collector.is_systemd_managed_offline(module=module) is True) or \
            (service_mgr_collector.is_systemd_managed_offline(module=module) is False)

# Generated at 2022-06-11 05:10:50.149051
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class Mod:
        def get_bin_path(self, cmd):
            return '/bin/systemctl' if cmd == 'systemctl' else None

    mod = Mod()

    class Fact:
        def __init__(self, name, value):
            self.name = name
            self.value = value

    facts = [Fact('ansible_system', 'Linux'), Fact('ansible_distribution', 'Debian')]

    sm = ServiceMgrFactCollector()
    with open('/proc/1/comm', 'w') as f:
        f.write('init')
    assert not sm.is_systemd_managed(module=mod)

    with open('/proc/1/comm', 'w') as f:
        f.write('systemd')
    assert sm.is_systemd_managed(module=mod)



# Generated at 2022-06-11 05:10:59.699323
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil

# Generated at 2022-06-11 05:11:09.550289
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # 'bronze' test - check the ServiceMgrFactCollector.collect() method
    # by instantiating a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()
    if platform.system() == 'SunOS':
        service_mgr_fact_collector.required_facts = set(['ansible_distribution', 'ansible_system'])
    elif platform.system() == 'Linux':
        service_mgr_fact_collector.required_facts = set(['ansible_system', 'ansible_distribution'])
    else:
        service_mgr_fact_collector.required_facts = set(['ansible_system'])

    # set up the module_utils.facts.utils.get_file_content() function to return a known value
   

# Generated at 2022-06-11 05:11:17.461941
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    '''
    Test ServiceMgrFactCollector.is_systemd_managed_offline method.
    '''

    result = ServiceMgrFactCollector.is_systemd_managed_offline(module=None)
    assert result is False

    fd = open('/sbin/init', 'wb')
    try:
        fd.write('#!/bin/bash\n')
        os.fchmod(fd.fileno(), 0o755)
        result = ServiceMgrFactCollector.is_systemd_managed_offline(module=None)
        assert result is False
    finally:
        fd.close()

    os.unlink('/sbin/init')
    os.symlink('systemd', '/sbin/init')

# Generated at 2022-06-11 05:11:28.569389
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class MockModule(object):
        def get_bin_path(self, name):
            return '/bin/systemctl'
        def run_command(self, cmd, use_unsafe_shell=True):
            return 0, None, None
    test_module = MockModule()

    smfc = ServiceMgrFactCollector()

    # Test 1 returns False, because /sbin/init does not exist
    if os.path.exists("/sbin/init"):
        os.unlink("/sbin/init")
    assert not smfc.is_systemd_managed_offline(test_module)

    # Test 2 returns False, because /sbin/init does not link to systemd
    with open("/sbin/init","w") as f:
        f.write("")
    assert not smfc.is_systemd

# Generated at 2022-06-11 05:11:34.301471
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # initialize class
    t = ServiceMgrFactCollector()
    # prepare a test command module
    import ansible.module_utils.basic
    test_module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    # prepare test command
    command = "echo -n 'procd'"
    # run the test
    result = t.collect(module=test_module, collected_facts={})
    print(result)

# Generated at 2022-06-11 05:11:43.847672
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import platform
    from ansible.module_utils.facts.collector import collect_facts
    from ansible.module_utils.facts import ModuleBase
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(ModuleBase):
        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0

    class MockSystemd:
        def __init__(self):
            self.path = 'systemd'

        def is_systemd_managed_offline(self):
            return True

    class MockNoSystemd:
        def __init__(self):
            self.path = 'nothing'

        def is_systemd_managed_offline(self):
            return False


# Generated at 2022-06-11 05:11:52.586290
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = Mock()

    # test result with /sbin/init symlink to /lib/systemd/systemd
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/usr/bin/systemctl'
    if platform.system() == 'SunOS':
         try:
            os.symlink('/lib/svc/method/systemd-start', '/sbin/init')
         except OSError as e:
            pass

    # this is run instead of the os.symlink call in solaris
    elif platform.system() == 'SunOS':
        module.run_command.return_value = (0, '/usr/bin/systemctl', '')


# Generated at 2022-06-11 05:12:01.720563
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.freebsd import ServiceMgrFactCollector
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3, text_type


    class MockModule(object):

        def __init__(self, *args, **kwargs):
            self.params = {}
            self.params['gather_subset'] = []
            self.params['gather_timeout'] = 10
            self.params['filter'] = None

        def exit_json(self, *args, **kwargs):
            pass


# Generated at 2022-06-11 05:12:26.360702
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Control test: systemctl is available, but /var/lib/dbus/machine-id
    # is missing, so systemd should not be detected.
    service_mgr_collector = ServiceMgrFactCollector()
    facts_dict = service_mgr_collector.collect(module=None, collected_facts={'ansible_system': 'Linux'})
    assert(facts_dict['service_mgr'] == 'service')

    # Create /var/lib/dbus/machine-id.
    # ServiceMgrFactCollector.is_systemd_managed() should then return True.

# Generated at 2022-06-11 05:12:35.769834
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import MockModule
    mock_module = MockModule(global_args='', arguments='')


# Generated at 2022-06-11 05:12:46.485453
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    tmp_ansible_module = None

    # unit test 1
    # test init/None: check for bsdinit, upstart, openrc, sysvinit
    def run_command_fake(args, use_unsafe_shell=True):
        if args.startswith('ps -p 1 -o'):
            return 0, 'runit-init', ''
        elif args == 'systemctl':
            return 1, '', ''
        elif args == 'initctl':
            return 1, '', ''
        elif args == 'openrc':
            return 1, '', ''
        elif args == 'ps -p 1 -o comm':
            return 0, 'init', ''


# Generated at 2022-06-11 05:12:55.655593
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Context
    from ansible.module_utils.facts.collector import Module
    import sys

    # Create a fake module to be used by the facts collector
    # avoid conflicts with AnsibleModule
    class FakeModule(Module):
        def __init__(self, *_, **kwargs):
            super(FakeModule, self).__init__(*_, **kwargs)
            self._tmpdir = None

        def get_bin_path(self, _):
            return None

        def run_command(self, *_, **kwargs):
            return 1, "", "Default error for %s" % self.path

        @property
        def tmpdir(self):
            return self._tmpdir


# Generated at 2022-06-11 05:13:05.536897
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import json

    # Test with setting systemd as service manager.
    test_module = MockModule()
    test_module.run_command.return_value = (0, "", "")
    test_module.get_bin_path.return_value = True
    os.path.exists.return_value = True

    service_mgr_fact_collector = ServiceMgrFactCollector()
    result = service_mgr_fact_collector.is_systemd_managed(test_module)
    assert result == True

    os.path.exists.assert_has_calls([call("/run/systemd/system/"), call("/dev/.run/systemd/"), call("/dev/.systemd/")])



# Generated at 2022-06-11 05:13:14.771352
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """ Methods of class ServiceMgrFactCollector should return correct results
    """
    mod = AnsibleModuleMock()
    os.chdir(os.path.dirname(__file__))
    service_mgr_collector = ServiceMgrFactCollector()
    if not os.path.exists('samples/init-link'):
        os.mkdir('samples/init-link')
    shutil.copy('/sbin/init', 'samples/init-link')
    os.chmod('samples/init-link/init', 0o644)
    os.symlink('./init', 'samples/init-link/init.link')

    assert service_mgr_collector.is_systemd_managed_offline(mod) == False

    assert service_mgr_collector.is_

# Generated at 2022-06-11 05:13:22.935758
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_content

    original_bin_path = get_collector_instance(ServiceMgrFactCollector).get_module().get_bin_path

    class MockModule:
        file = None

        def __init__(self, file):
            self.file = file

        def get_bin_path(self, command):
            if command == "systemctl":
                return "/bin/systemctl"
            return original_bin_path(self, command)

        def is_executable(self, path):
            return os.access(path, os.X_OK)

    # create an empty real file but do not link the file to the specified path
    original_readlink = os.readlink

# Generated at 2022-06-11 05:13:31.181334
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.system.service_mgr

    # test is_systemd_managed with systemd init system
    class TestModule(object):
        def __init__(self, systemd_path='/bin/systemctl'):
            self.systemd_path = systemd_path

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return self.systemd_path

    # create and test module with systemd init system
    testmodule = TestModule()
    test_is_systemd_managed_mock = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed(testmodule)
    assert test_is_systemd_managed_mock == True

    # test is_systemd_managed with sysvin

# Generated at 2022-06-11 05:13:38.563061
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import mock
    fake_module = mock.MagicMock()
    fake_module.get_bin_path.return_value = '/bin/systemctl'
    fake_open = mock.mock_open()
    # Make up a fake /etc/os-release
    osrelease = '/etc/os-release'
    fake_open.return_value.read.return_value = 'ID=ubuntu\nPRETTY_NAME="Ubuntu 16.04.2 LTS"\nVERSION="16.04.2 LTS (Xenial Xerus)"\nVERSION_ID="16.04"\nID_LIKE=debian\n'

# Generated at 2022-06-11 05:13:47.386147
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # Build a mock module
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    system_fact_collector = SystemFactCollector()
    system_facts = system_fact_collector.collect()

    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModuleFacts(ModuleFacts):
        def __init__(self, module):
            super(MockModuleFacts, self).__init__(module)
            self.all_facts = system_facts

        def _get_fact_collector(self, fact_name):
            return BaseFactCollector()

        def populate_facts(self, collected_facts=None, cache=None, warnings=None, **kwargs):
            pass

   

# Generated at 2022-06-11 05:14:03.834300
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(None)
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(object())

# Generated at 2022-06-11 05:14:13.153210
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Test on systems using systemd
    class TestModuleDummy(object):
        def get_bin_path(self, cmd):
            return '/usr/lib/systemd/systemd'

    # On systems using systemd, is_systemd_managed_offline should return True
    assert ServiceMgrFactCollector.is_systemd_managed_offline(TestModuleDummy()) is True

    # Test on systems not using systemd
    class TestModuleDummy(object):
        def get_bin_path(self, cmd):
            return None

    # On systems not using systemd, is_systemd_managed_offline should return False
    assert ServiceMgrFactCollector.is_systemd_managed_offline(TestModuleDummy()) is False

# Generated at 2022-06-11 05:14:22.834178
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule, MockFile

    fake_module = MockModule()

    # systemd canary directories doesn't exists
    fake_module.add_os_path('/run/systemd/system/')
    fake_module.add_os_path('/dev/.run/systemd/')
    fake_module.add_os_path('/dev/.systemd/')

    # tools must be installed
    path_mock = MockFile()
    path_mock.add_entry('/usr/bin/systemctl')
    fake_module.add_mock_entry('FILE', path_mock)

   

# Generated at 2022-06-11 05:14:29.377719
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector

    class FakeModule(object):
        def get_bin_path(self, executable):
            return '/bin/systemctl'

    module = FakeModule()
    collector = ServiceMgrFactCollector()

    rc = os.symlink('systemd', '/sbin/init')
    managed = collector.is_systemd_managed_offline(module)
    assert managed
    os.unlink('/sbin/init')

# Generated at 2022-06-11 05:14:35.873761
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    mgr = ServiceMgrFactCollector()
    collected_facts = {'ansible_distribution': 'OpenWrt', 'ansible_system': 'Linux'}
    service_mgr_facts = mgr.collect(collected_facts=collected_facts)

    assert service_mgr_facts is not None
    assert service_mgr_facts['service_mgr'] is not None
    assert service_mgr_facts['service_mgr'] == 'openwrt_init'

# Generated at 2022-06-11 05:14:45.584221
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    svc_mgr = ServiceMgrFactCollector()

    class MockModule:
        def __init__(self):
            self.run_command = lambda cmd, use_unsafe_shell=None: (1, None, None)
            self.get_bin_path = lambda cmd: None

    class MockAnsibleModule:
        def __init__(self):
            self.params = {}
            self.run_command = MockModule().run_command
            self.get_bin_path = MockModule().get_bin_path

    class MockFactsCollector:
        def __init__(self):
            self.ansible_facts = dict()

    # test_collect_no_facts
    # No facts_dict should be returned when no ansible_facts are given
    collected_facts = None
    ansible_module = Mock

# Generated at 2022-06-11 05:14:48.657417
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class FakeModule:
        def get_bin_path(self, command):
            return True

    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed_offline(FakeModule()) == True

# Generated at 2022-06-11 05:14:59.193219
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    '''
    Test for the ServiceMgrFactCollector._is_systemd_managed method.

    This test is for the method is_systemd_managed of class ServiceMgrFactCollector.
    '''
    # Run the test as root
    if os.geteuid() != 0:
        import sys
        print("1..0 # Skipped: This test must be run as root.")
        sys.exit(0)

    # Create a test module object
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    # Create a ServiceMgrFactCollector object
    service_mgr_collector = ServiceMgrFactCollector()

    # We know that systemd is the service manager on Centos / RHEL 7, test that a True value is returned


# Generated at 2022-06-11 05:15:08.355857
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import sys
    import tempfile
    import shutil
    import os
    import stat

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 05:15:16.758415
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # unit test with list of test inputs and expected output
    service_mgr = ServiceMgrFactCollector()
    test_data = (
        (True, '/run/systemd/system/', '/dev/.run/systemd/', ''),
        (False, '', '', ''),
        (False, '/run/systemd/system/', '', ''),
        (False, '', '/dev/.run/systemd/', ''),
        (False, '', '', '/dev/.systemd/'),
        (True, '', '', '/dev/.systemd/'),
    )

    class MockModule(object):
        def get_bin_path(self, *args, **kwargs):
            return '/bin/systemctl'

    mock_module = MockModule()

    result = True

# Generated at 2022-06-11 05:16:05.104395
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector.collect(None)

# Generated at 2022-06-11 05:16:13.327227
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    mock_module = basic.AnsibleModule(
        argument_spec = dict(),
    )
    mock_module.get_bin_path = lambda x: '' if x == 'systemctl' else None

    # Check is_systemd_managed() when /run/systemd/system exists
    def mock_is_file_exists(filename):
        return True if filename == '/run/systemd/system/' else False
    BaseFactCollector.is_file_exists = mock_is_file_exists
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module) == True
    BaseFactCollector

# Generated at 2022-06-11 05:16:20.760694
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    mocked_module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    mocked_module.get_bin_path = lambda x : "/bin/systemctl"
    mocked_module.run_command = lambda x : (0, "standard output", "standard error")
    service_mgr_facts_collector = ServiceMgrFactCollector()

    # Test with /sbin/init is not a symlink
    assert not service_mgr_facts_collector.is_systemd_managed_offline(mocked_module)

    # Test with /sbin/init is a symlink, but not to systemd
    os.symlink("/bin/bash", "/sbin/init")
    assert not service_mgr

# Generated at 2022-06-11 05:16:27.492428
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class MockModule(object):
        def get_bin_path(self, arg):
            return "/bin/%s" % arg
        def run_command(self, arg1, arg2=None):
            return 0, None, None

    module = MockModule()

    fact_collector = ServiceMgrFactCollector()
    collected_facts = {
        'ansible_system': 'Linux',
        'ansible_distribution': 'Ubuntu',
    }
    facts_dict = fact_collector.collect(module, collected_facts)

    assert facts_dict['service_mgr'] == 'systemd'

# Generated at 2022-06-11 05:16:37.284243
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.network.base import NetworkCollector

    class MockNetwork(NetworkCollector):
        def __init__(self):
            self.facts = {}

    class MockModule(object):
        class params(object):
            collector_network = 'MockNetwork'

        def __init__(self):
            self.params = self.params()
            self.exit_json = None
            self.fail_json = None

        def get_bin_path(self, command):
            return '/bin/' + command

    facts = ServiceMgrFactCollector()
    module = MockModule()
    facts.collect(module=module)
    assert(facts.get_facts()['service_mgr'] == 'systemd')


# Generated at 2022-06-11 05:16:46.684058
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import BaseFactCollector
    from ansible.module_utils.facts.collectors.network import NetworkCollector

    class MockModule():
        def __init__(self):
            self.params = {}
        def get_bin_path(self, executable):
            return '/bin/%s' % executable

    class MockFactCollector(BaseFactCollector):
        name = 'mock_fact'
        _fact_ids = set()
        required_facts = set(['platform', 'distribution'])

        def collect(self, module=None, collected_facts=None):
            return {'mock_fact': 'mock_value'}

    mock_module = MockModule()
    mock_collector = MockFactCollector()

    # Setup required facts
    collected_facts = {}
   

# Generated at 2022-06-11 05:16:49.655338
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class TestModule():
        def get_bin_path(self, _):
            return '/bin/systemctl'

    sm = ServiceMgrFactCollector()

    assert not sm.is_systemd_managed(TestModule())

# Generated at 2022-06-11 05:16:59.139680
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    m = 'ansible_collections.ansible.os_family.tests.unit.collectors.test_ServiceMgrFactCollector.mock'
    mock = __import__(m, fromlist=['ansible.module_utils.facts.collector'])

    # systemctl binary is available
    module = mock.MockModule()
    module.HAVE_SYSTEMCTL = True

    # systemd is the boot init system
    for canary in ["/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"]:
        module.run_command_environ.update({canary: ''})
        assert ServiceMgrFactCollector.is_systemd_managed(module) == True

    # systemctl binary not available
    module = mock.MockModule()
    module.HAVE_

# Generated at 2022-06-11 05:17:08.435931
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import mock_module
    from ansible.module_utils.facts.utils import mock_collector
    from ansible.module_utils.facts import utils

    system = platform.system()
    distribution = platform.distribution()
    if distribution[0] == '':
        distribution = (system,) + distribution[1:]
    
    if system == 'Linux':
        service_mgr = 'sysvinit'
        result = {'service_mgr': 'sysvinit'}
    elif system == 'SunOS':
        service_mgr = 'smf'
        result = {'service_mgr': 'smf'}

# Generated at 2022-06-11 05:17:15.381698
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import os

    if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
        test = ansible.module_utils.facts.collector.ServiceMgrFactCollector.is_systemd_managed_offline(None)
        assert test == True

    else:
        test = ansible.module_utils.facts.collector.ServiceMgrFactCollector.is_systemd_managed_offline(None)
        assert test == False

# Generated at 2022-06-11 05:18:59.487940
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module_mock = MockModule()
    collected_facts = {
        'ansible_distribution': None,
        'ansible_system': None,
        'platform_dist_info': {
            'distribution': None
        }
    }
    service_mgr_fact_collector = ServiceMgrFactCollector()

    service_mgr_fact_collector.collect(module_mock, collected_facts)
    assert collected_facts['service_mgr'] == 'service'

    collected_facts['ansible_distribution'] = 'Windows'
    collected_facts['ansible_system'] = 'Windows'
    service_mgr_fact_collector.collect(module_mock, collected_facts)
    assert collected_facts['service_mgr'] == 'service'

    collected_facts['ansible_system']

# Generated at 2022-06-11 05:19:03.178211
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = '/bin/systemctl'
    ServiceMgrFactCollector.is_systemd_managed_offline(module)
    assert module.get_bin_path.called

# Test class for mocking AnsibleModule class
# Do not delete it, it will be used in future

# Generated at 2022-06-11 05:19:10.804910
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    args = {}
    facts_dict = {}
    module = MockModule(**args)

    # patch run_command to return output of cat /sbin/init if /sbin/init exists,
    # else return an empty string
    def mock_run_command(*args, **kwargs):
        if os.path.exists('/sbin/init'):
            return 0, os.readlink('/sbin/init'), ''
        else:
            return 0, '', ''
    module.run_command = mock_run_command

    # not systemd
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(module)

   

# Generated at 2022-06-11 05:19:18.388445
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class AnsibleModuleTest():
        def __init__(self):
            self.params = {}
            self.run_command_expect_failure = False
            self.run_command_rc = 0
            self.run_command_err = ''
            self.run_command_response = ''
            self.run_command_path = ''
            self.get_bin_path_response = ''
            self.get_bin_path_path = ''
            self.readlink_response = ''
            self.readlink_link = ''
            self.isdir_path = ''
            self.isdir_response = ''
            self.isfile_path = ''
            self.isfile_response = ''

        def get_bin_path(self, path):
            self.get_bin_path_path = path

# Generated at 2022-06-11 05:19:26.694280
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Run these test on all platforms, since the unit test cannot
    # detect which OS it is running on.

    # test systemd managed
    # setup data
    module = MockModule()

# Generated at 2022-06-11 05:19:27.879078
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed('mock') == True


# Generated at 2022-06-11 05:19:35.046922
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule(object):
        def __init__(self, params, facts=None):
            self.params = params
            self.facts = facts
            self.fail_json = lambda **kwargs: params.pop()
            self.exit_json = lambda **kwargs: params.pop()
        def get_bin_path(exe):
            if exe in MockModule.exes:
                return exe
            raise Exception
        def run_command(cmd):
            return tuple(MockModule.commands.pop(0))
    class MockFacts(object):
        def get(fact):
            return MockFacts.facts.get(fact)
    MockModule.exes = ['systemctl', 'unknown-command']

# Generated at 2022-06-11 05:19:41.420990
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collectors.service_mgr
    class MockModule(object):
        def get_bin_path(self, path):
            return path
    m = MockModule()
    assert ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector.is_systemd_managed_offline(m) == False
    try:
        os.symlink('/bin/systemd', '/sbin/init')
        assert ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector.is_systemd_managed_offline(m) == True
    finally:
        os.remove('/sbin/init')

# Generated at 2022-06-11 05:19:49.261554
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.six.moves.mock import patch


# Generated at 2022-06-11 05:19:57.382913
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector()
    # create a fake dict of module to pass to is_systemd_managed_offline
    module = {'get_bin_path': lambda path: '/bin/systemctl'}
    assert collector.is_systemd_managed_offline(module)
    good_path = '/usr/bin/systemctl'
    bad_path = '/usr/bin/systemctrl'
    module['get_bin_path'] = lambda path: good_path
    assert collector.is_systemd_managed_offline(module)
    os.remove(good_path)
    assert not collector.is_systemd_managed_offline(module)
    module['get_bin_path'] = lambda path: bad_path
    assert not collector.is_systemd_managed_offline(module)