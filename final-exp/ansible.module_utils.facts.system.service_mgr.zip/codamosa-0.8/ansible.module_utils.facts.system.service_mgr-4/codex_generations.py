

# Generated at 2022-06-11 05:10:34.517129
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector.collect()

# Generated at 2022-06-11 05:10:42.296925
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import sys
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector

    tmpdir = tempfile.mkdtemp()
    tmpfile = tempfile.mkstemp(dir=tmpdir, suffix='.py')
    filepath = tmpfile[1]
    with open(filepath, 'w') as f:
        f.write("#!/usr/bin/python\n")
    os.chmod(filepath, 0o755)
    sys.path.insert(0, tmpdir)
    class AnsibleModuleProxy(AnsibleModule):
        @staticmethod
        def get_bin_path(module_name):
            return filepath
    module = AnsibleModuleProxy(argument_spec=dict())
    collector = Service

# Generated at 2022-06-11 05:10:53.373359
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import FactCollector

    # Create a fake Ansible module
    module = AnsibleModule()

    # Create a fake service manager fact collector.
    fact_collector = FactCollector()
    fact_collector.add_collector(ServiceMgrFactCollector())

    # Collect all facts provided by the fake service manager fact collector.
    module.run_command = lambda x, **kwargs: (0, 'systemd', None)
    facts_dict = fact_collector.get_facts(module=module)
    print(facts_dict)
    assert facts_dict['service_mgr'] == 'systemd'

    # Collect all facts provided by the fake service manager fact collector.

# Generated at 2022-06-11 05:10:58.346921
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.basic
    import ansible.module_utils.facts.collector

    class TestModule(object):
        def get_bin_path(self, bin_name):
            if bin_name == 'systemctl':
                return '/bin/true'

    class TestAnsibleModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self):
            self.params = dict()
            self.check_mode = False

    def run_command(self, args, use_unsafe_shell):
        return (0, "", "")

    if platform.system() != 'SunOS':
        from ansible.module_utils.compat.six import PY3


# Generated at 2022-06-11 05:11:03.380960
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.basic
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors

    class MockModule(ansible.module_utils.basic.AnsibleModule):
        def get_bin_path(self, executable):
            return ''

    x = ServiceMgrFactCollector()
    assert not x.is_systemd_managed(MockModule())


# Generated at 2022-06-11 05:11:12.017891
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector

    class MockModule(object):
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/usr/bin/systemctl'
            else:
                return None

    class MockFile(object):
        def exists(self, path):
            if path == '/run/systemd/system/':
                return True
            else:
                return False

    class MockOs(object):
        path = MockFile()

    module = MockModule()
    os = MockOs()

    assert ServiceMgrFactCollector().is_systemd_managed(module, os) == True


# Generated at 2022-06-11 05:11:17.820757
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Test 'systemd' in the case of /sbin/init -> systemd symlink
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False
    import os
    os.symlink("/usr/lib/systemd/systemd", "/sbin/init")
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == True
    os.remove("/sbin/init")
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False


# Generated at 2022-06-11 05:11:25.627545
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network import NetworkCollector

    m = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    ifc = ServiceMgrFactCollector()
    facts = ifc.collect(m)

    assert 'service_mgr' in facts
    assert facts['service_mgr'] == 'systemd'


# Generated at 2022-06-11 05:11:31.301758
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Unit test: ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed_offline
    """
    class MockModule():
        def get_bin_path(self, name):
            return name

    s = ServiceMgrFactCollector()
    assert s.is_systemd_managed_offline(module=MockModule()) is False

# Generated at 2022-06-11 05:11:41.437053
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import mock
    import os.path
    import posixpath
    SMFC = ServiceMgrFactCollector()

    # Case 1: systemctl exists at a path, but not the init symlink
    with mock.patch('os.path.isfile', return_value=True):
        assert False == SMFC.is_systemd_managed_offline(mock)

    # Case 2: systemctl exists at a path, and the init symlink is not to systemd
    with mock.patch('os.path.isfile', return_value=True):
        mocked = mock.MagicMock()
        mocked.readlink.return_value = 'not-systemd'

# Generated at 2022-06-11 05:12:04.799862
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    class MockModule(object):

        def get_bin_path(self, path):
            return os.path.join("/bin", path)

    class MockSystem(object):

        @staticmethod
        def uname():
            return ('Linux', 'localhost.localdomain', '2.6.32-131.0.15.el6.x86_64', '#1 SMP Wed May 25 10:07:59 EDT 2011', 'x86_64')

    import sys
    sys.modules['ansible.module_utils.facts'] = MockSystem
    sys.modules['ansible.module_utils.basic'] = MockSystem

    module = MockModule()
    # Emulate /dev/.run/systemd/
    import tempfile
    tempfile.mkdtemp(prefix="/dev/.run/systemd/")

# Generated at 2022-06-11 05:12:12.041995
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector as facts_collector

    # Arrange
    # (pylint thinks this is a module not a class, so disable reporting that warning)
    svc_mgr_fact_collector_impl = facts_collector.ServiceMgrFactCollector()  # pylint: disable=no-member
    svc_mgr_fact_collector_impl.name = 'service_mgr'
    module = None
    expected = False

    # Act
    actual = svc_mgr_fact_collector_impl.is_systemd_managed(module)

    # Assert
    assert actual == expected

# Generated at 2022-06-11 05:12:21.741696
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.facts.collector import BaseFactCollector
    class DummyModule(BaseFactCollector):
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return 'bin/systemctl'
            else:
                return None

    dummyModule = DummyModule()

    # mocking is_systemd_managed_offline method
    # which depends on os.path and os.readlink
    real_path_islink = os.path.islink
    real_os_readlink = os.readlink

    # mock os.path.islink
    def mock_path_islink(path):
        if path == "/sbin/init":
            return True
        else:
            return real_path_islink

# Generated at 2022-06-11 05:12:31.798676
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockAnsibleModule()
    module.run_command.return_value = (1, '', '')
    module.get_bin_path.return_value = '/bin/systemctl'
    module.stat.return_value = 1
    os.path.islink.return_value = False
    os.readlink.return_value = "systemd"

    # Test when systemctl is installed and /sbin/init is a symlink to systemd
    result = ServiceMgrFactCollector.is_systemd_managed_offline(module)
    assert result == True

    # Test when systemctl is installed and /sbin/init is not a symlink
    os.path.islink.return_value = True
    result = ServiceMgrFactCollector.is_systemd_managed_offline(module)
   

# Generated at 2022-06-11 05:12:33.313530
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False


# Generated at 2022-06-11 05:12:38.432038
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import shutil

    def link_sbin_init(module, systemd_dir):
        if os.path.exists('/sbin/init'):
            shutil.move('/sbin/init', os.path.join(systemd_dir, 'init'))

        os.symlink(os.path.join(systemd_dir, 'systemd'), '/sbin/init')

    def recover_sbin_init(module, systemd_dir):
        if os.path.islink('/sbin/init'):
            os.remove('/sbin/init')
        if os.path.exists(os.path.join(systemd_dir, 'init')):
            shutil.move(os.path.join(systemd_dir, 'init'), '/sbin/init')


# Generated at 2022-06-11 05:12:46.382281
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import FactsParams
    params = FactsParams()
    params.get_all_facts = True
    smfc = get_collector_instance(ServiceMgrFactCollector, params)
    # testing the method collect of class ServiceMgrFactCollector
    assert smfc.collect() == {'service_mgr': 'service'}

# Generated at 2022-06-11 05:12:50.200093
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    m = MockModule()
    s = ServiceMgrFactCollector()
    assert not s.is_systemd_managed_offline(m)

    m.file_exists_isdir = True
    assert s.is_systemd_managed_offline(m)


# Generated at 2022-06-11 05:12:55.624561
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from mock import Mock

    def mock_get_bin_path(bin_path):
        return bin_path == "systemctl"

    module = Mock()
    module.get_bin_path = mock_get_bin_path

    # TODO: assert that is_systemd_managed() calls module.get_bin_path with input "systemctl"

    # TODO: assert that is_systemd_managed() returns True when /run/systemd/system/ exists
    # TODO: assert that is_systemd_managed() returns True when /dev/.run/systemd/ exists
    # TODO: assert that is_systemd_managed() returns True when /dev/.systemd/ exists


# Generated at 2022-06-11 05:13:06.241298
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """Test for method collect of class ServiceMgrFactCollector"""
    import platform
    import collections

    from ansible.module_utils.facts.collector import BaseFactCollector

    from test.support import EnvironmentVarGuard

    from ansible.module_utils.facts.utils import get_file_content

    class System_calls_stub:
        def __init__(self):
            self.retvals = {}

        def register_retval(self, method, retval):
            self.retvals[method] = retval

        def __getattr__(self, name):
            return lambda *args, **kwargs: self.retvals[name]

    def get_bin_path_stub(self, binname):
        return self.retvals[binname]


# Generated at 2022-06-11 05:13:48.220846
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from mock import Mock
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(
        argument_spec={
        },
        supports_check_mode=True,
    )

    # init a ServiceMgrFactCollector
    smfc = ServiceMgrFactCollector()
    smfc.collect(module=module)

    # mock module.get_bin_path
    old_get_bin_path = module.get_bin_path
    module.get_bin_path = Mock(return_value='foo')

    # create a mock os.path.exists
    old_path_exists = os.path.exists
    os.path.exists = Mock(return_value=True)

    # create a mock os.readlink
    old

# Generated at 2022-06-11 05:13:57.560532
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    import ansible.module_utils.facts.collector.service_mgr
    import modules.systemd_offline
    import modules.systemd_run

    class FakeBinPathModule:
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/usr/bin/systemctl'
            else:
                return None

    class FakeFileContentModule:
        def __init__(self, file_content):
            self.file_content = file_content

        def get_file_content(self, file_path):
            return self.file_content

    class FakeRunCommandModule:
        def run_command(self, command):
            return (0, 'test-runit-init', '')


# Generated at 2022-06-11 05:14:07.255450
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    test_object = ServiceMgrFactCollector
    module = basic.AnsibleModule(argument_spec={})
    facts_collector = collector.FactsCollector()

    # Add the test method to the object
    setattr(test_object, "is_systemd_managed_offline", test_object.is_systemd_managed_offline)

    # Add the test object to the facts collector in order to be able to call the method
    setattr(facts_collector, "service_mgr", test_object)

    # Return True when /sbin/init is symlinked to systemd
    result_true = test_object.is_systemd_managed_offline(module=module)
    assert result_true is True

# Generated at 2022-06-11 05:14:17.113456
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    test_module = TestModule()
    service_mgr_fact = ServiceMgrFactCollector(test_module)

    test_module.run_command = lambda *args, **kwargs: (0, '', '')
    assert service_mgr_fact.is_systemd_managed(test_module) is False

    test_module.run_command = lambda *args, **kwargs: (1, '', '')
    assert service_mgr_fact.is_systemd_managed(test_module) is False

    test_module.run_command = lambda *args, **kwargs: (0, '1\ndeadbeef', '')


# Generated at 2022-06-11 05:14:27.093989
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    if platform.system() != 'Linux':
        return

    from ansible.module_utils.facts.utils import TestModule

    def is_systemd_managed(module):
        return True

    def is_systemd_managed_offline(module):
        return False

    TestModule.get_bin_path = lambda self, name: '/bin'

    ansible_module = TestModule({'ansible_distribution': 'Linux', 'ansible_system': 'Linux'}, test_platform='linux')

    # Test case 1: Only is_systemd_managed() returns true
    ansible_module.is_systemd_managed = is_systemd_managed
    ansible_module.is_systemd_managed_offline = lambda module: False
    svc_mgr = ServiceMgrFactCollector()
    facts = svc_

# Generated at 2022-06-11 05:14:36.089340
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import ModuleStub

    module = ModuleStub()
    collector = ServiceMgrFactCollector()

    module.run_command.return_value = (0, 'unit file')
    assert collector.is_systemd_managed(module)

    module.run_command.return_value = (1, 'fail')
    assert not collector.is_systemd_managed(module)

    module.run_command.return_value = (0, '')
    assert not collector.is_systemd_managed(module)

    module.run_command.return_value = (0, None)
    assert not collector.is_systemd_managed(module)

# Generated at 2022-06-11 05:14:45.755759
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    import copy
    import mock

    MockedModule = mock.Mock()
    MockedModule.run_command.return_value = (0, 'COMMAND\n', '')

    fact_collector = FactCollector(MockedModule)
    facts_dict = fact_collector.collect(collected_facts={'ansible_system': 'Linux', 'ansible_distribution': 'OpenWrt'})
    assert 'service_mgr' in facts_dict
    assert facts_dict['service_mgr'] == 'openwrt_init'
    facts_dict = fact_collector.collect(collected_facts={'ansible_system': 'Linux', 'ansible_distribution': 'OpenWrt'})
    assert 'service_mgr'

# Generated at 2022-06-11 05:14:56.453433
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils import basic
    import tempfile

    systemctl_found = False
    for path in os.environ['PATH'].split(os.pathsep):
        if os.path.exists(os.path.join(path, 'systemctl')):
            systemctl_found = True
            break
    if not systemctl_found:
        raise Exception("skipping test, systemctl not found in PATH")

    # Temporarily create systemd canaries and directory to contain them
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create canary directories
        for canary in ("/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"):
            os.makedirs(os.path.join(tmpdir, canary[1:]))

        # Create module

# Generated at 2022-06-11 05:14:59.642763
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class Module():
        def get_bin_path(self, string):
            return "systemctl"

    module = Module()
    assert ServiceMgrFactCollector.is_systemd_managed(module) == True


# Generated at 2022-06-11 05:15:08.854464
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class ModuleStub:
        def get_bin_path(self, cmd):
            return None

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            self.module = ModuleStub()

    # test without systemd
    test1 = TestServiceMgrFactCollector()
    assert False == test1.is_systemd_managed_offline()

    # test with systemd
    test2 = TestServiceMgrFactCollector()
    test2.module.get_bin_path = lambda cmd: "/usr/bin/systemctl"
    test2.is_systemd_managed = lambda: False
    assert False == test2.is_systemd_managed_offline()

    # test with systemd and /sbin/init pointing to systemd
    test3 = TestServiceMgrFactCollect

# Generated at 2022-06-11 05:16:30.230400
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    from ansible.module_utils.facts.collector import DictCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    collected_facts = {
        'platform': 'Linux',
        'distribution': 'Ubuntu',
        'ansible_system': 'Linux',
    }

    test_obj = ServiceMgrFactCollector()
    res = test_obj.collect(collected_facts=collected_facts)
    assert res['service_mgr'] == 'service'



# Generated at 2022-06-11 05:16:33.459128
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # construct module object
    module = AnsibleModule(
        argument_spec=dict()
    )

    # test collection function
    factCollector = ServiceMgrFactCollector(module=module)

    # check return value
    assert 'service_mgr' in factCollector.collect()

# Generated at 2022-06-11 05:16:39.799681
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, cmd_name, opts=None, required=False):
            return "/bin/systemctl"
    mock_module = MockModule()
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module)
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(mock_module)

# Generated at 2022-06-11 05:16:49.288989
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = FakeAnsibleModule()
    collector = ServiceMgrFactCollector()

    # Nothing installed
    is_systemd_managed_offline = collector.is_systemd_managed_offline(module=module)
    if is_systemd_managed_offline:
        raise Exception('If nothing is installed, then systemctl is not available')

    # Systemd installed, but not running
    module.command_results = ((0, '/sbin/init', ''),)
    is_systemd_managed_offline = collector.is_systemd_managed_offline(module=module)
    if is_systemd_managed_offline:
        raise Exception('If systemd is not running, then systemd is not manager')

    # Systemd installed and running

# Generated at 2022-06-11 05:16:58.635116
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import sys
    import tempfile
    import shutil

    # prepare temporary directory
    test_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(test_dir, 'run'))
    os.mkdir(os.path.join(test_dir, 'dev'))
    os.mkdir(os.path.join(test_dir, 'dev', '.run'))
    os.mkdir(os.path.join(test_dir, 'run', 'systemd'))
    os.mkdir(os.path.join(test_dir, 'dev', '.run', 'systemd'))
    os.mkdir(os.path.join(test_dir, 'dev', '.systemd'))

    # mock module
    class MockModule():
        def __init__(self):
            self

# Generated at 2022-06-11 05:17:08.194577
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import collector

    test_module = AnsibleModuleMock()

    # test fail without systemd tools
    test_module.fail_json = lambda **ignore: None
    collector.get_file_content = lambda filename: None
    assert ServiceMgrFactCollector.is_systemd_managed(test_module) is False

    # test success with systemd tools and systemd boot canary files
    test_module.fail_json = lambda **ignore: None
    collector.get_file_content = lambda filename: filename
    assert ServiceMgrFactCollector.is_systemd_managed(test_module) is True

    # test fail without systemd tools
    test_module.fail_json = lambda **ignore: None
    del collector.get_file_content
    assert ServiceMgrFactCollector.is_systemd_managed

# Generated at 2022-06-11 05:17:17.039465
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    smfc=ServiceMgrFactCollector()
    assert not smfc.is_systemd_managed_offline(None)
    smfc.module=MyModule()
    smfc.module.get_bin_path=lambda _: '/bin/systemctl'
    assert not smfc.is_systemd_managed_offline(None)
    smfc.module.get_bin_path=lambda _: '/usr/bin/systemctl'
    assert not smfc.is_systemd_managed_offline(None)
    os.symlink('/usr/bin/systemd','/sbin/init')
    assert smfc.is_systemd_managed_offline(None)
    os.remove('/sbin/init')



# Generated at 2022-06-11 05:17:20.783830
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # on some systems /sbin/init is not a symlink to systemd, on those systems it is not possible to detect
    # that systemd is used as the init system from inside the init system, so we have to test the online detection
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=None) is False


# Generated at 2022-06-11 05:17:29.629830
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    MockModule = basic.AnsibleModule

    # create mock module
    test_module = MockModule()

    test_module.params = {}
    test_module.run_command = lambda *cmd, **kwargs: (0, '', '')

    # Create a mock Collector object
    test_collection_object = Collector(module=test_module)

    # Create a ServiceMgrFactCollector object
    test_ServiceMgrFactCollector_object = ServiceMgrFactCollector()

    # Make sure we return service_mgr

# Generated at 2022-06-11 05:17:37.148242
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import subprocess
    import tempfile
    # class under test
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # module under test
    class TestModule():
        def run_command(self, command, use_unsafe_shell=True):
            return 0, '\n', ''

        def get_bin_path(self, command):
            return command

    service_mgr_fact_collector.is_systemd_managed_offline(TestModule())
    NO_SYSTEMD = '/usr/lib/xenomai/boot/no-systemd'