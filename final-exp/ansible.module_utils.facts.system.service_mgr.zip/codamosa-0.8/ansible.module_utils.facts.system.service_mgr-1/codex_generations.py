

# Generated at 2022-06-11 05:10:41.083895
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module_mock = AnsibleModuleMock()
    get_file_content_mock = GetFileContentMock()
    is_systemd_managed_mock = IsSystemdManagedMock()
    is_systemd_managed_offline_mock = IsSystemdManagedOfflineMock()

    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Method should return a dictionary with the key 'service_mgr'
    assert service_mgr_fact_collector.collect(module_mock) == {
        'service_mgr': 'systemd'
    }

    # With parameter AnsibleModuleMock() method collect should return:
    # 1. a dictionary with the key 'service_mgr' and the value 'systemd'
    # 2. if file /proc/1/comm exists

# Generated at 2022-06-11 05:10:50.445956
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Mock
    class MockModule(object):
        @staticmethod
        def get_bin_path(name, opts=None, required=True):
            if name == 'systemctl':
                return '/bin/systemctl'

        @staticmethod
        def run_command(cmd, use_unsafe_shell=False, check_rc=False):
            return False, "", ""


    module = MockModule()
    service_mgr_name = ServiceMgrFactCollector.is_systemd_managed(module)
    assert not service_mgr_name

# Generated at 2022-06-11 05:10:59.882291
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # create a mocked module to pass to is_systemd_managed_offline method
    class TestModule:
        def __init__(self, found_bin_path):
            self.found_bin_path = found_bin_path
        def get_bin_path(self, name):
            return self.found_bin_path[name]

    # Create a mocked os module
    class TestOs:
        def __init__(self, is_link):
            self.is_link = is_link
        def islink(self, name):
            return self.is_link
        def readlink(self, name):
            return self.is_link
    # Create a mocked os module
    class TestOsModule:
        def __init__(self, is_link):
            self.is_link = is_link
            self.path

# Generated at 2022-06-11 05:11:03.333689
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collectors.service_mgr
    module = ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector()
    assert module.is_systemd_managed_offline(module) == False

# Generated at 2022-06-11 05:11:13.289039
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import ModuleBase
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.platform.linux import Linux

    # Setup module and facts
    module = ModuleBase()
    facts = Facts(module)
    ServiceMgrFactCollector.__module__ = Facts.__module__

    # Execute test cases
    # Test 1
    # Test case 1: Validate systemctl is_systemd_managed() fails with empty sys.executable
    module.run_command = lambda *args, **kwargs: (7, '')
    module.get_bin_path = lambda *args, **kwargs: None
    facts_collector = ServiceMgrFactCollector(module=module)

# Generated at 2022-06-11 05:11:22.407743
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import ServiceMgrFactCollector

    # Create a fake module for Mock AnsibleModule
    module = BaseFactCollector.get_module()

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    program = os.path.join(temp_dir, 'program')
    systemctl = os.path.join(temp_dir, 'systemctl')
    os.mkdir(os.path.join(temp_dir, 'system'))
    os.mkdir(os.path.join(temp_dir, 'run'))
    os.mkdir(os.path.join(temp_dir, 'run', 'systemd'))

# Generated at 2022-06-11 05:11:25.727212
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Run is_systemd_managed
    output = ServiceMgrFactCollector.is_systemd_managed()
    assert(output == False)


# Generated at 2022-06-11 05:11:36.192882
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module_mock = MockAnsibleModule()
    module_mock.params = {}

    collector = ServiceMgrFactCollector(module=module_mock)
    assert not collector.is_systemd_managed_offline(None)

    module_mock.params = {
        'ansible_facts': {
            'ansible_system': "Linux",
        },
    }

    # Test with an empty systemctl command
    module_mock.get_bin_path.return_value = ""
    assert not collector.is_systemd_managed_offline(module_mock)

    # Test for systemd but without /sbin/init symlink
    module_mock.get_bin_path.return_value = "/usr/bin/systemctl"
    assert not collector.is_systemd_managed_offline

# Generated at 2022-06-11 05:11:44.987276
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """Test is_systemd_managed method of class ServiceMgrFactCollector."""
    # Define test classes
    class ModuleMock(object):
        def __init__(self, is_linux, is_systemd_managed, is_systemd_managed_offline):
            self.is_linux = is_linux
            self.is_systemd_managed = is_systemd_managed
            self.is_systemd_managed_offline = is_systemd_managed_offline

        def get_bin_path(self, _):
            if self.is_linux:
                return '/bin/systemctl'
            return None
    class AnsiColorsMock(object):
        def __init__(self, color_stdout):
            self.color_stdout = color_stdout


# Generated at 2022-06-11 05:11:53.885018
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # test set up
    fake_module = type('module', (object,), {
        'get_bin_path.return_value': 'systemctl',
        'run_command.return_value': None,
        'run_command.return_value.rc': 0,
        'run_command.return_value.stdout': 'systemd',
        'run_command.return_value.stderr': '',
        'exit_json.side_effect': None
    })

    # test systemctl is a symlink to systemd
    os.symlink('/bin/systemctl', '/sbin/init')

    # test systemctl is a symlink to systemd but have not symlink in /sbin

# Generated at 2022-06-11 05:12:13.287844
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Create a mock module object
    mock_module = MagicMock()

    # Create a mock Facts object
    mock_facts = {
        'platform': 'SunOS',
        'distribution': 'SunOS',
        'ansible_system': 'SunOS'
    }

    # Initialize instance of ServiceMgrFactCollector
    smfc = ServiceMgrFactCollector()

    # Run the method collect
    result = smfc.collect(mock_module, mock_facts)

    # Assert result
    assert result == {'service_mgr': 'smf'}

# Generated at 2022-06-11 05:12:23.007583
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import fact_collector

    module = basic.AnsibleModule(
        argument_spec = dict(),
    )

    fact_collector.setup(module)
    service_mgr = ServiceMgrFactCollector()

    # Test with invalid parameters
    assert not service_mgr.is_systemd_managed_offline(None)
    assert not service_mgr.is_systemd_managed_offline(module)

    # Reset the module
    module = basic.AnsibleModule(
        argument_spec = dict(),
    )

    # Set module.get_bin_path() to return None (no systemctl command available).

# Generated at 2022-06-11 05:12:25.962439
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class Module(object):
        def get_bin_path(self, arg):
            return True
    assert ServiceMgrFactCollector.is_systemd_managed_offline(Module()) == True

# Generated at 2022-06-11 05:12:34.587507
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # test data
    fake_module_ansible_facts = {
        'ansible_distribution': 'Linux',
        'ansible_system': 'Linux'
    }

    fake_module = FakeAnsibleModule(
        fake_ansible_module_facts=fake_module_ansible_facts
    )
    # end of test data

    ServiceMgrFactCollector = ServiceMgrFactCollector()
    ServiceMgrFactCollector.collect(
        module=fake_module,
        collected_facts=None
    )

    service_mgr = fake_module.params.get('ansible_facts', {}).get('service_mgr')
    assert service_mgr == 'sysvinit'


# Generated at 2022-06-11 05:12:45.186001
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    def get_bin_path(program):
        return "/usr/bin/systemctl"
    class Module(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, program):
            return get_bin_path(program)
    module = Module()
    collector = ServiceMgrFactCollector()
    # Test that the method returns True when /sbin/init is a symlink to systemd.
    open('/sbin/init', 'w').close()
    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    assert collector.is_systemd_managed_offline(module)
    # Test that the method returns False when /sbin/init is not a symlink to systemd.

# Generated at 2022-06-11 05:12:54.579282
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create object of class ServiceMgrFactCollector
    x = ServiceMgrFactCollector()

    # Create object of class MockedModule
    class MockedModule(object):
        def __init__(self, name):
            self.name = name

        def get_bin_path(self, binary, required=False):
            # Mocking functionality for method get_bin_path of class MockedModule
            if (binary == 'systemctl'):
                return binary
            return None

        def run_command(self, cmd, use_unsafe_shell=False):
            # Mocking functionality for method run_command of class MockedModule
            if (cmd == "ps -p 1 -o comm|tail -n 1"):
                return 0, 'COMMAND\n', ''
            return 0, None, ''

    # Create object of class

# Generated at 2022-06-11 05:13:03.999551
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    sut = ServiceMgrFactCollector()

    # when init is symlink to systemd and tools exists
    module = MockModule()
    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    module.run_command_side_effect = [
        # module.get_bin_path('systemctl')
        (1, '', ''),
        (0, '/bin/systemctl', ''),
        # module.run_command("ps -p 1 -o comm|tail -n 1", use_unsafe_shell=True)
        (0, 'systemd', '')
    ]

    assert sut.is_systemd_managed_offline(module) is True

# Generated at 2022-06-11 05:13:09.363809
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    # Fake module class
    class FakeModule(object):
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/usr/bin/systemctl'
            return None

    module = FakeModule()
    service_mgr_collector = ServiceMgrFactCollector()

    result = service_mgr_collector.is_systemd_managed_offline(module)

    assert result is False

# Generated at 2022-06-11 05:13:18.124153
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import sys
    import tempfile
    import shutil

    class TestModule:
        def __init__(self, results, return_val=0, run_exit=True):
            self.results = results.copy()
            self.return_val = return_val
            self.run_exit = run_exit

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/usr/bin/systemctl'
            return False

        def run_command(self, args, use_unsafe_shell=False):
            if 'ps -p 1 -o comm|tail -n 1' in args:
                return (self.results['rc'], self.results['out'], self.results['err'])

# Generated at 2022-06-11 05:13:18.999016
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector()

# Generated at 2022-06-11 05:13:57.726210
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import sys
    import os

    # Set up a mock get_bin_path function which returns the path
    # specified as the argument. This allows testing without
    # actually having any of the required binaries installed.
    def mock_get_bin_path(name, required=False):
        return name


# Generated at 2022-06-11 05:14:00.327598
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    svc_mgr_obj = ServiceMgrFactCollector()
    result = svc_mgr_obj.collect()
    assert result == {'service_mgr': 'service'}

# Generated at 2022-06-11 05:14:03.834413
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class TestModule():
        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, "", ""
    tc = ServiceMgrFactCollector()
    assert False == tc.is_systemd_managed_offline(TestModule())


# Generated at 2022-06-11 05:14:13.933585
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Arrange
    import mock
    module = mock.Mock()
    module.get_bin_path.return_value = '/bin/systemctl'
    init_system_mock = mock.Mock()
    init_system_mock.readline.return_value = '/bin/systemd'
    init_system_mock.__enter__ = lambda s: init_system_mock
    init_system_mock.__exit__ = lambda s, *a: None
    with mock.patch('__builtin__.open', create=True) as mock_open:
        mock_open.return_value = init_system_mock
        # Act
        result = ServiceMgrFactCollector.is_systemd_managed(module)
    # Assert
    assert result == True


# Generated at 2022-06-11 05:14:23.480546
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil

    class DummyModule:
        def get_bin_path(self, name):
            return "systemctl"

    def is_systemd_managed_offline(module):
        return ServiceMgrFactCollector.is_systemd_managed_offline(module)

    def is_systemd_boot(booted_path, result):
        tmpdir = tempfile.mkdtemp(prefix="ansible_unittest.")
        os.symlink("systemd", booted_path)
        rc = is_systemd_managed_offline(DummyModule())
        assert rc == result, "{0} not {1}".format(booted_path, result)
        shutil.rmtree(tmpdir)

    is_systemd_boot("/sbin/init", True)
   

# Generated at 2022-06-11 05:14:33.692233
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import get_file_content

    # create mock module
    class MockModule(object):
        def __init__(self, params=None):
            self.params = params
            self.tmpdir = ''
            self.tmpfile = '/tmp'

        def fail_json(self, msg=None, **kwargs):
            self.msg = msg
            self.kwargs = kwargs
            raise AssertionError('fail_json called')

        def get_bin_path(self, path):
            return path

        def run_command(self, cmd, use_unsafe_shell=False):
            return (0, '', '')


# Generated at 2022-06-11 05:14:44.290115
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    '''
    Test collect method of class ServiceMgrFactCollector.
    The method is supposed to return dict with service_mgr key
    whose value should be the service manager
    '''
    from ansible.module_utils.facts import ModuleTestCase
    from ansible.module_utils.facts import FactCollector

    class Module:
        def get_bin_path(self, app, *args, **kwargs):
            dist = platform.dist()[0]

            if dist.startswith('debian') and app == '/usr/bin/initctl':
                return '/usr/bin/initctl'
            elif app == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    ServiceMgrFactCollector.required_facts = set(['platform', 'distribution'])
    facts_collect

# Generated at 2022-06-11 05:14:55.395512
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import shutil
    import tempfile

    module = MagicMock()
    module.get_bin_path.return_value = '/bin/systemctl'
    smfc = ServiceMgrFactCollector()

    # if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
    systemd = os.path.join(tempfile.gettempdir(), 'systemd')
    os.symlink(systemd, '/sbin/init')
    assert smfc.is_systemd_managed_offline(module)

    os.remove('/sbin/init')
    assert not smfc.is_systemd_managed_offline(module)

    # if we fail to remove for whatever reason, check that it doesn't

# Generated at 2022-06-11 05:15:04.680415
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = FakeModule()
    collector = ServiceMgrFactCollector()

    # check if is_systemd_managed() detects systemd
    module.files = {
        "/run/systemd/system/": True,
        "/dev/.run/systemd/": True,
        "/dev/.systemd/": True
    }
    assert(collector.is_systemd_managed(module))

    # check if is_systemd_managed() returns False, if tools are not installed
    module.files = {}
    module.bin_path = {}
    assert(not collector.is_systemd_managed(module))

    # check if is_systemd_managed() returns False, if systemd canaries are not present
    module.bin_path = {
        "systemctl": "systemctl"
    }

# Generated at 2022-06-11 05:15:13.598440
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Collector

    class MockModule(object):
        def __init__(self, params={}):
            self.params = params

        def get_bin_path(self, path):
            if path == 'systemctl':
                return '/bin/systemctl'

    class MockFacts(dict):
        _module = MockModule()

        def __init__(self, facts):
            super(MockFacts, self).__init__(facts)

        def __getattr__(self, attr):
            return self[attr]

        def __setattr__(self, attr, val):
            self[attr] = val


# Generated at 2022-06-11 05:16:05.687879
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    module = MockModule()

    # returns True if systemctl binary exists in module.command_finder.get_bin_path
    platform = MockModule(system='Linux')
    module.command_finder = MockCommandFinder(bin_path=True, platform=platform.system)
    assert ServiceMgrFactCollector.is_systemd_managed(module)

    # returns False if systemctl binary not found in module.command_finder.get_bin_path
    module.command_finder = MockCommandFinder(bin_path=False, platform=platform.system)
    assert ServiceMgrFactCollector.is_systemd_managed(module) is False

    # returns False if platform is not Linux

# Generated at 2022-06-11 05:16:13.817688
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """ Test the is_systemd_managed_offline() method of ServiceMgrFactCollector.
    """

    # noinspection PyUnresolvedReferences
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    from ansible_collections.ansible.community.plugins.module_utils import basic
    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes

    class Collect(object):

        def get_bin_path(self, path, required=False, opt_dirs=[]):
            if path == 'systemctl':
                return True
            else:
                return None


# Generated at 2022-06-11 05:16:21.568197
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import mock

    module = mock.Mock()
    module.get_bin_path.return_value = '/bin/systemctl'

    with mock.patch('os.path.islink', return_value=True) as mock_islink:
        with mock.patch('os.readlink', return_value='/sbin/init'):
            with mock.patch('os.path.basename', return_value='systemd'):
                assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == True

    with mock.patch('os.path.islink', return_value=False):
        assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False


# Generated at 2022-06-11 05:16:30.311319
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    A test to check whether the method is_systemd_managed_offline of class ServiceMgrFactCollector returns
    the expected value.

    Return Value
    ------------
    True if the method is_systemd_managed_offline of class ServiceMgrFactCollector returns the expected value.
    False otherwise.
    """
    # Create a dummy module
    module = DummyModule()

    # Create an instance of class ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Create a dummy /sbin/init symlink
    os.symlink('systemd', '/sbin/init')

    # Test the is_systemd_managed_offline method of class ServiceMgrFactCollector

# Generated at 2022-06-11 05:16:40.616658
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ModuleFactCollector
    import os, shutil

    systemd_unit_dir = '/run/systemd/system'
    systemd_dev_dir = '/dev/.run/systemd/'
    systemd_dev_dir2 = '/dev/.systemd/'
    systemd_sbin_init = '/sbin/init'
    tmp_dir = '/tmp/test_ServiceMgrFactCollector_is_systemd_managed'
    tmp_systemd_unit_dir = '%s%s' % (tmp_dir, systemd_unit_dir)
    tmp_systemd_dev_dir = '%s%s' % (tmp_dir, systemd_dev_dir)
    tmp_systemd_dev_

# Generated at 2022-06-11 05:16:49.477619
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.hardware.service_mgr

    class FakeModule(object):
        def __init__(self):
            self.module = FakeModule
            self.tmpdir = FakeModule
            self.facts = FakeModule

        def get_bin_path(self, cmd, opt_dirs=None, required=False):
            if cmd == "systemctl":
                return True
            else:
                return False

    fake_module = FakeModule()
    service_mgr_fact_collector = ansible.module_utils.facts.collectors.hardware.service_mgr.ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(fake_module) is True

# Generated at 2022-06-11 05:16:58.774140
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a module mock
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Create a ServiceMgrFactCollector object
    service_mgr_fact_collector_obj = ServiceMgrFactCollector(module=module)

    # Run code to be tested
    result = service_mgr_fact_collector_obj.collect(module=module)

    assert type(result) == dict
    assert 'service_mgr' in result
    assert isinstance(result['service_mgr'], text_type)

    # Cleanup test files
    BaseFactCollector._

# Generated at 2022-06-11 05:17:05.517758
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    pass_args = {
        'get_file_content': (os.path.exists('/sbin/init') and os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd'),
        'get_bin_path': ('/bin/true'),
    }
    test_case = ServiceMgrFactCollector()
    assert test_case.is_systemd_managed_offline(pass_args) == False


# Generated at 2022-06-11 05:17:14.554743
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class MockModule:
        def __init__(self, command_results=''):
            self.command_results = command_results
        def get_bin_path(self, program):
            return True
        def run_command(self, command, use_unsafe_shell=True):
            if command == "ps -p 1 -o comm|tail -n 1":
                return 0, self.command_results, ''
            elif command == "systemctl":
                return 0, '', ''
            else:
                raise Exception("unexpected command %s" % command)

    # Create a facts collector instance to test
    obj = ServiceMgrFactCollector()

    # Initial test case
    module = MockModule()
    assert obj.collect(module) == {'service_mgr': 'service'}

    # Test case where we get an

# Generated at 2022-06-11 05:17:22.857857
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.basic import AnsibleModule

    fact_collector = ServiceMgrFactCollector()

    # if run via ansible-inventory, then AnsibleModule is None
    if AnsibleModule is not None:
        module = AnsibleModule(
            argument_spec={},
            supports_check_mode=True
        )
    else:
        class FakeModule:
            def __init__(self):
                self.run_command_called = 0

            def get_bin_path(self, app, required=False, opt_dirs=None):
                # return None so is_systemd_managed returns False

                if app not in ['systemctl']:
                    return '/bin/' + app

                return None

            def run_command(self, command, use_unsafe_shell=False):
                self.run

# Generated at 2022-06-11 05:19:06.275691
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class Module(object):
        def get_bin_path(self, path, opt_dirs=[]):
            if path == 'systemctl':
                return path
            else:
                return None

    # systemd system
    module = Module()
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.is_systemd_managed(module=module)

    # systemd system without systemctl installed
    module = Module()
    fact_collector = ServiceMgrFactCollector()
    assert not fact_collector.is_systemd_managed(module=Module())

# Generated at 2022-06-11 05:19:13.718433
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule, MockCollectedFact
    from ansible.module_utils.facts.collector.service.mgr import (
        ServiceMgrFactCollector
    )

    module = MockModule()
    facts_dict = dict()
    collected_facts = MockCollectedFact(
        ansible_facts=dict(facts_dict),
        ansible_module=module
    )

    expected = {
        'ansible_facts': {
            'service_mgr': 'systemd'
        },
        'warnings': []
    }

    collector = ServiceMgrFactCollector(module=module)
    result = collector.collect(module=module, collected_facts=collected_facts)

    assert result == expected

# Generated at 2022-06-11 05:19:22.285334
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import hash_args
    from ansible.module_utils.facts.utils import get_file_content

    class CollectedFacts:
        pass

    collected_facts = CollectedFacts()

    def mock_run_command(self, *args, **kwargs):
        if args[0].endswith("ls -1 /proc/1/exe"):
            return 0, "/sbin/init", ""
        else:
            return 0, "", ""

    FakeModule = type('FakeModule', (object,), {})
    fake_module = FakeModule()
    fake_module.run_command = mock_run_command

# Generated at 2022-06-11 05:19:29.242974
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic

    collector = ServiceMgrFactCollector()
    assert collector.collect() == {'service_mgr': 'service'}

    def get_bin_path(name):
        if name == 'initctl':
            return '/sbin/initctl'
        return None

    class LinuxModule:
        def __init__(self):
            self.run_command = lambda _: (0, '', '')
        def get_bin_path(self, name):
            return get_bin_path(name)

    class FreeBSDModule:
        def __init__(self):
            self.run_command = lambda _: (0, '', '')

    class OpenWrtModule:
        def __init__(self):
            self.run_command = lambda _: (0, '', '')

# Generated at 2022-06-11 05:19:36.310674
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic


# Generated at 2022-06-11 05:19:41.022257
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.facts.collector import ModuleStub

    module = ModuleStub()
    collector = ServiceMgrFactCollector()

    os.symlink('/bin/systemd', '/sbin/init')
    assert collector.is_systemd_managed_offline(module=module)

    os.remove('/sbin/init')
    assert not collector.is_systemd_managed_offline(module=module)

# Generated at 2022-06-11 05:19:48.530337
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Note:
    #   (1) class ServiceMgrFactCollector is tested in the integration tests
    #       (see test/integration/targets/plugin/facts/test_service_mgr_facts.py)
    #   (2) on other platforms, methods is_systemd_managed and is_systemd_managed_offline
    #       are also tested in the integration tests
    if platform.system() == 'Linux':
        # Make sure that there is no service_mgr fact present
        facts = {}
        pc = ServiceMgrFactCollector()
        result = pc.collect(collected_facts=facts)
        assert('service_mgr' not in result)

        # /proc/1/comm is empty (maybe read failed)
        # Init is not systemd
        # Invoke 'ps -p 1 -o comm

# Generated at 2022-06-11 05:19:55.597323
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Return False if /sbin/init is not a symlink to systemd
    assert service_mgr_fact_collector.is_systemd_managed_offline(None) == False

    # Return True if /sbin/init is a symlink to systemd
    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    assert service_mgr_fact_collector.is_systemd_managed_offline(None) == True

    # Cleanup
    os.remove('/sbin/init')


# Generated at 2022-06-11 05:19:57.182868
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_manager = ServiceMgrFactCollector()
    assert service_manager.is_systemd_managed_offline({}) == False

# Generated at 2022-06-11 05:20:04.670051
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """
    Unit test for method is_systemd_managed of class ServiceMgrFactCollector
    """

    from ansible.module_utils.facts.collector import BaseFactCollector
    # Arrange
    fake_module = {'get_bin_path': lambda x: '/usr/bin/systemctl'}
    fake_os = {'path': {}, 'exists': lambda x: x in ['/run/systemd/system/', '/dev/.run/systemd/', '/dev/.systemd/']}
    facts_collector = ServiceMgrFactCollector()
    facts_collector.os = fake_os
    # Act
    result = facts_collector.is_systemd_managed(module=fake_module)
    # Assert
    assert result

