

# Generated at 2022-06-11 05:10:47.019949
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    ServiceMgrFactCollectorMock = ServiceMgrFactCollector()
    mock_module = type('module', (object,), {})()

    assert not ServiceMgrFactCollectorMock.is_systemd_managed_offline(mock_module)

    mock_module.get_bin_path = lambda x: '/usr/bin/systemctl'
    assert not ServiceMgrFactCollectorMock.is_systemd_managed_offline(mock_module)

    mock_module.get_bin_path = lambda x: '/usr/bin/systemctl'
    os.symlink('/bin/bash', '/sbin/init')
    assert not ServiceMgrFactCollectorMock.is_systemd_managed_offline(mock_module)


# Generated at 2022-06-11 05:10:57.338029
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile
    import shutil
    import subprocess
    import unittest

    class FakeModule(object):
        def __init__(self):
            self._bin_path = {}

        def get_bin_path(self, name):
            return self._bin_path.get(name)

        def run_command(self, cmd, use_unsafe_shell):
            # TODO: implement me
            return (0, "", "")

    class ServiceMgrFactCollectorTest(unittest.TestCase):
        def setUp(self):
            self._temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self._temp_dir, ignore_errors=True)


# Generated at 2022-06-11 05:11:02.751609
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collector

    import tempfile

    # Create a temporary file for testing.
    (fd, tmp_file) = tempfile.mkstemp()

    class TestModule:
        def get_bin_path(self, program):
            return '/bin/false'

    class TestCollector(Collector):
        def collect(self, module=None, collected_facts=None):
            return {}

    collector.collectors.append(ServiceMgrFactCollector())

    # Test with a modern systemd version.
    os.write(fd, b'/run/systemd/system/\n')
    os.close(fd)
    facts = Collector.collect(TestModule(), TestCollector())

# Generated at 2022-06-11 05:11:08.146939
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class Module():
        def __init__(self, param):
            self.params = param
            return

        def get_bin_path(self, tool, required=False):
            return tool

    s = ServiceMgrFactCollector()
    m = Module({})
    assert s.is_systemd_managed_offline(m) == False

# Generated at 2022-06-11 05:11:16.631356
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """Unit test for method get_init of class ServiceMgrFactCollector"""

    class MockedModule():
        def __init__(self):
            self.params = {}
            self.run = None

        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            elif name == 'initctl':
                return '/sbin/initctl'
            return None

    class MockedCollector():
        def __init__(self):
            self.facts_dict = {'platform': 'Linux', 'ansible_distribution': 'OpenWrt'}

    class MockedCollector_NoInit():
        def __init__(self):
            self.facts_dict = {'platform': 'Linux', 'ansible_distribution': 'OpenWrt'}


# Generated at 2022-06-11 05:11:27.325045
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create mocks
    real_get_file_content = get_file_content
    real_os_path_islink = os.path.islink
    real_os_readlink = os.readlink

# Generated at 2022-06-11 05:11:34.834922
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Create the class to test.
    module = type('', (object,), {})
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    # Create the class under test.
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Get the facts.
    facts_dict = service_mgr_fact_collector.collect(module=module)

    # Make sure the values were set properly.
    assert facts_dict['service_mgr'] == 'systemd'


# Generated at 2022-06-11 05:11:44.160071
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ''' Unit test for method collect of class ServiceMgrFactCollector '''

    class MockModule:

        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None
            self.run_command_calls = 0

        def run_command(self, cmd):
            if self.run_command_calls == 0:
                self.run_command_calls +=1
                return (0, 'init', None)
            elif self.run_command_calls == 1:
                self.run_command_calls +=1
                return (0, 'COMMAND', None)
            elif self.run_command_calls == 1:
                self.run_command_calls +=1
                raise OSError("File not found.")




# Generated at 2022-06-11 05:11:53.007838
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    import ansible.module_utils.facts.utils

    class TestModule(object):
        def __init__(self):
            self.exit_json = None
            self.fail_json = None

        def get_bin_path(self, arg):
            return '/usr/bin/systemctl'

        def run_command(self, arg, check_rc=False, use_unsafe_shell=True):
            return 0, '', ''

    class TestAnsibleModule(object):
        def __init__(self):
            self.ansible_facts = {}
            self.check_mode = None
            self.diff = None

        def exit_json(self, **kwargs):
            self.exit_json = kwargs

        def fail_json(self, **kwargs):
            self.fail_json = kwargs

# Generated at 2022-06-11 05:11:56.622055
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """
    Test for method is_systemd_managed of class ServiceMgrFactCollector
    :return:
    """
    # TODO: Write unit test for method is_systemd_managed of class ServiceMgrFactCollector
    assert False, 'Test is not implemented'


# Generated at 2022-06-11 05:12:22.135906
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    '''Unit test for method collect of class ServiceMgrFactCollector'''

    # Initialize test environment
    test_obj = ServiceMgrFactCollector()

    # Create mock module
    class MockModule:
        def get_bin_path(self, arg, *args, **kwargs):
            if arg == 'systemctl':
                return 'systemctl'
            return None

        def run_command(self, arg, *args, **kwargs):
            return 0, 'COMMAND\n', ''

    mock_module = MockModule()

    # Create mock collected facts
    mock_collected_facts = {
        'ansible_system': 'Linux',
        'ansible_distribution': 'OpenWrt',
    }

    # Return values of the mock module

# Generated at 2022-06-11 05:12:32.083525
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Unit test for method collect of class ServiceMgrFactCollector
    """
    import platform
    import os


    class AnsibleModuleMocked(object):
        def __init__(self):
            self.facts = {}

        def get_bin_path(self, bin_name):
            return "/usr/bin/%s" % bin_name

        def run_command(self, cmd, use_unsafe_shell=False):
            if bin_name == 'initctl':
                return (0, "/usr/bin/initctl", "")
            return (0, "", "")

        def set_fact(self, fact_name, fact_value):
            self.facts[fact_name] = fact_value


# Generated at 2022-06-11 05:12:37.535577
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ModuleArgsParser
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collected_facts
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.library.distribution import Distribution
    from ansible.module_utils.facts.library.distribution import DistributionCollector
    from ansible.module_utils.facts.library.platform import Platform
    from ansible.module_utils.facts.library.platform import PlatformCollector

    # Define test collect method
    def collect(self, module=None, collected_facts=None):
        collected_facts = collected_facts or {}

# Generated at 2022-06-11 05:12:48.252429
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import unittest
    import mock
    from ansible.module_utils.facts.utils import get_distribution

    class TestServiceMgrFactCollector(unittest.TestCase):
        def test_is_systemd_managed(self):

            # Test systemctl exists
            with mock.patch.object(os, 'path') as mock_path:
                mock_path.exists.return_value = False
                mock_path.isfile.return_value = True
                mock_path.islink.return_value = False
                self.assertFalse(ServiceMgrFactCollector.is_systemd_managed(None))

            # Test /run/systemd/system exists

# Generated at 2022-06-11 05:12:53.774061
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import MockModule
    module = MockModule()
    module._debug = False
    module._ansible_api_version = 2
    module.run_command = Mock(return_value=('/usr/bin/systemd', ''))
    module.get_bin_path = Mock(return_value='/usr/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(module)


# Generated at 2022-06-11 05:13:04.193070
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # create mocked module
    module = FakeAnsibleModule()
    module.run_command.return_value = (0, '', '')

    # create instance of ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # verify result if init is a symlink to systemd
    module.exists.return_value = True
    module.readlink.return_value = '/lib/systemd/systemd'
    assert service_mgr_fact_collector.is_systemd_managed_offline(module) == True

    # verify result if init is not a symlink to systemd
    module.exists.return_value = True
    module.readlink.return_value = '/sbin/init.bkp'

# Generated at 2022-06-11 05:13:13.587352
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import platform
    import pytest

    class MockModule(object):
        def __init__(self, platform, readlink=""):
            self.platform = platform
            self.readlink = readlink

        def get_bin_path(self, path):
            paths = {
                "systemctl": "/bin/systemctl"
            }
            return paths.get(path, "")

        def run_command(self, path):
            if 'ps' in path:
                if self.platform != "Linux":
                    return (0, "init\n", "")
                if self.readlink == "tini":
                    return (0, "tini\n", "")
                if self.readlink == "systemd":
                    return (0, "systemd\n", "")
                return (0, "init\n", "")

# Generated at 2022-06-11 05:13:15.723357
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # We are not going to test this, because it's system dependent,
    # but if we do not provide the method, python will show us a warning.
    pass


# Generated at 2022-06-11 05:13:21.401316
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    '''
    Unit test for method is_systemd_managed() of class ServiceMgrFactCollector.
    :return:
    '''
    class TestModule(object):
        def get_bin_path(self, executable_name):
            return '/bin/' + executable_name

    test_module = TestModule()

    # System has systemd
    ServiceMgrFactCollector._file_exists = lambda path: True
    assert ServiceMgrFactCollector.is_systemd_managed(module=test_module) is True



# Generated at 2022-06-11 05:13:29.528152
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import os
    import shutil
    import inspect
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary directories and files
    canary1 = os.path.join(tmp_dir, 'run/systemd/system/')
    os.makedirs(canary1)
    canary2 = os.path.join(tmp_dir, 'dev/.run/systemd/')
    os.makedirs(canary2)
    canary3 = os.path.join(tmp_dir, 'dev/.systemd/')
    os.makedirs(canary3)

    # Create a temporary module

# Generated at 2022-06-11 05:14:11.933515
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import collect_subset
    from ansible.module_utils.facts.collector import TestModule

    test_module = TestModule()
    test_collector = collect_subset(ServiceMgrFactCollector, test_module)

    assert test_collector.service_mgr.is_systemd_managed(test_module) == True


# Generated at 2022-06-11 05:14:21.635544
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    collected_facts = {}
    mock_module = AnsibleMock(collected_facts=collected_facts)
    mock_module.get_bin_path.return_value = True
    mock_module.run_command.return_value = 0, '', ''

    test_collector = ServiceMgrFactCollector()
    test_collector.name = 'service_mgr'
    results = test_collector.collect(mock_module)
    assert results['service_mgr'] == 'service'

    collected_facts = {'platform': 'Linux', 'distribution': 'Debian'}
    mock_module = AnsibleMock(collected_facts=collected_facts)
    mock_module.get_bin_path.return_value = False

# Generated at 2022-06-11 05:14:31.705773
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    fixture = {}
    fact_module = fixture
    fact_module.get_bin_path = lambda x: '/bin/' + x
    fact_module.run_command = lambda x: (0, '', '')
    fact_module.get_file_content = lambda x: ''
    fact_module.os_path_exists = lambda x: False
    fact_module.os_path_islink = lambda x: False

    # Do not test against real types, the output changes between platform,
    # to_native, python version etc.
    fixture['ansible_distribution'] = 'MacOSX'
    collector = ServiceMgrFactCollector(fact_module=fact_module,
                                        collected_facts=fixture)
    assert collector.collect() == {'service_mgr': 'launchd'}


# Generated at 2022-06-11 05:14:42.541530
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collector = ServiceMgrFactCollector()

    # mock module object
    class AnsibleModuleFake:
        def get_bin_path(self, binary_name):
            '''Fake implementation of AnsibleModule.get_bin_path'''
            return binary_name

    ansible_module = AnsibleModuleFake()

    # mock os module object
    class OsModuleFake:
        def islink(self, path):
            '''Fake implementation of os.islink'''
            if path == '/sbin/init':
                return True
            else:
                return False

        def readlink(self, path):
            '''Fake implementation of os.readlink'''
            if path == '/sbin/init':
                return 'systemd'
            else:
                return path

    os_module = OsModuleFake()

    # is_

# Generated at 2022-06-11 05:14:53.374243
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Mock the get_file_content method of the utils module to control the output of the ServiceMgrFactCollector.collect method
    def mock_get_file_content(file_name, as_bytes=False, encoding=None):
        if file_name == '/proc/1/comm':
            return "systemd\n"
        elif file_name == '/sbin/init':
            return "/lib/systemd/systemd"
        else:
            return None

    mocked_get_

# Generated at 2022-06-11 05:15:03.073503
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Initialize the module object
    module = AnsibleModule(
        argument_spec=dict(),
    )

    # Set up the module_utils/facts/collector.py module_utils paths
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.get_bin_path = get_bin_path
    module.run_command = run_command

    # Initialize our ServiceMgrFactCollector object
    smfc = ServiceMgrFactCollector(module=module)

    # Check that if /sbin/init does not exist, return False
    os.path.exists = MagicMock(return_value=False)
    assert (smfc.is_systemd_managed_offline() is False)

    # Check that if /sbin/init exists but is not a symlink,

# Generated at 2022-06-11 05:15:12.151347
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # We need to use a magicmock for the module parametre because
    # we cannot use the real module and we cannot use AnsibleModule
    # because it is not yet possible to build a module with the
    # facts_module.
    MockedModule = collections.namedtuple('MockedModule', ['get_bin_path', 'run_command'])

    def mocked_get_bin_path(path):
        if path == 'systemctl' and system == 'systemd':
            return '/bin/systemctl'
        if path == 'systemctl' and system == 'systemd_offline':
            return '/bin/systemctl'
        if path == 'systemctl' and system == 'openwrt':
            return None
        if path == 'systemctl' and system == 'upstart':
            return None

# Generated at 2022-06-11 05:15:20.118256
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import ModuleFacts
    import os.path

    def mock_os_path_islink(path):
        return True
    #mock_os_path_islink.return_value = True

    def mock_os_readlink(path):
        return "systemd"
    #mock_os_readlink.return_value = "systemd"

    ServiceMgrFactCollector.is_systemd_managed_offline.__globals__['os.path.islink'] = mock_os_path_islink
    ServiceMgrFactCollector.is_systemd_managed_offline.__globals__['os.readlink'] = mock_os_readlink
    module = ModuleFacts()
    s = ServiceMgrFactCollector()

# Generated at 2022-06-11 05:15:26.727539
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collectors.service_mgr
    class FakeModule(object):
        def __init__(self, a=None, b=None):
            self.a = a
            self.b = b
        def get_bin_path(self, *args, **kwargs):
            return os.path.join(self.a, *args)
        def run_command(self, *args, **kwargs):
            return self.b
    instance = ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector()
    assert isinstance(instance, BaseFactCollector)
    facts_dict = dict(ansible_distribution='MacOSX', ansible_system='Darwin')

# Generated at 2022-06-11 05:15:29.763900
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    def mocked_get_bin_path(path):
        return os.path.exists(path)

    module = type('FakeModule', (), dict())
    module.get_bin_path = mocked_get_bin_path
    module.run_command = None
    mgr = ServiceMgrFactCollector()
    mgr.is_systemd_managed(module)

# Generated at 2022-06-11 05:16:56.672664
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector

    class TestModule:
        def get_bin_path(self, executable):
            return '/bin/{0}'.format(executable)

    # Setup: create a fake /sbin/init symlink to systemd
    import tempfile
    import shutil
    tempdir = tempfile.mkdtemp()
    old_cwd = os.getcwd()
    os.chdir(tempdir)
    os.symlink('/bin/systemctl', '/sbin/init')

    # Run test
    test_module = TestModule()
    collector = Collector()
    facts = FactCollector(base_collectors=[ServiceMgrFactCollector()], module=test_module)
    facts.collect

# Generated at 2022-06-11 05:17:01.795849
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # a basic MacOSX system with LaunchD as service manager
    macosx_facts = {
        'platform': 'Darwin',
        'platform_family': 'Darwin',
        'distribution_major_version': '14',
        'distribution': 'MacOSX',
        'distribution_release': '14.3.0',
        'distribution_version': '14.3.0',
        'ansible_distribution': 'MacOSX',
        'ansible_distribution_release': '14.3.0',
        'ansible_distribution_version': '14.3.0',
        'ansible_system': 'Darwin',
        'os_family': 'Darwin'
    }

    # a basic FreeBSD system with BSDInit as service manager

# Generated at 2022-06-11 05:17:04.661934
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    facts_dict = ServiceMgrFactCollector().collect()
    assert 'service_mgr' in facts_dict

# Generated at 2022-06-11 05:17:12.482827
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts import Collector

    module = AnsibleModuleMock()
    module.run_command = AnsibleRunCommandMock(0, "")

    collector = Collector(module=module)

    service_mgr = ServiceMgrFactCollector()

    os.path.exists = PathExistsMock(False)
    service_mgr.is_systemd_managed(module)

    os.path.exists = PathExistsMock(True)
    service_mgr.is_systemd_managed(module)

    module.get_bin_path = AnsibleGetBinPathMock("")
    service_mgr.is_systemd_managed(module)



# Generated at 2022-06-11 05:17:14.339528
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    ServiceMgrFactCollector.is_systemd_managed(distribution=DistributionFactCollector)


# Generated at 2022-06-11 05:17:15.502451
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    ServiceMgrFactCollector.is_systemd_managed_offline()


# Generated at 2022-06-11 05:17:18.275559
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collector as collector

    module = AnsibleModuleMock(dict())
    smfc = collector.ServiceMgrFactCollector()
    assert not smfc.is_systemd_managed(module)


# Generated at 2022-06-11 05:17:27.002482
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    def run_test(test, test_result):
        module = MockModule()
        module.run_command = MagicMock(return_value=test_result)
        module.get_bin_path = MagicMock(return_value=True)
        svc_mgr = ServiceMgrFactCollector(module)
        test_result = (0, "systemd\n", "")
        if test['proc_1_map']:
            proc_1_map = dict(test['proc_1_map'].split(':'))
        else:
            proc_1_map = {}
        expected_result = test['result']
        result = svc_mgr.collect(module, {})
        assert result['service_mgr'] == expected_result
        return True

    module = MockModule()
    module.run_

# Generated at 2022-06-11 05:17:31.576870
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # pylint: disable=protected-access

    service_mgr = ServiceMgrFactCollector()
    module = MockModule()
    module.get_bin_path = MockGetBinPath(True)
    os.path.islink = MockIsLink(True)
    os.readlink = MockReadLink('init')

    assert service_mgr.is_systemd_managed_offline(module) == True


# Generated at 2022-06-11 05:17:39.130153
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    '''
    Test the function ServiceMgrFactCollector.is_systemd_managed_offline()
    '''
    # Test 1
    facts = {
        'ansible_system': 'Linux',
        'ansible_distribution': 'Fedora'
    }
    test_obj = ServiceMgrFactCollector(module=None)
    result = test_obj.is_systemd_managed_offline(facts)
    assert result is True

    # Test 2
    facts = {
        'ansible_system': 'SunOS',
        'ansible_distribution': 'Solaris'
    }
    test_obj = ServiceMgrFactCollector(module=None)
    result = test_obj.is_systemd_managed_offline(facts)
    assert result is False
