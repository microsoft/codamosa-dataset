

# Generated at 2022-06-11 05:10:41.351446
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    path = '/tmp/test_ServiceMgrFactCollector_is_systemd_managed'

# Generated at 2022-06-11 05:10:52.262162
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    class MockModule(object):
        @staticmethod
        def get_bin_path(binary):
            return binary

    class MockSystemdMgr(ServiceMgrFactCollector):
        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            collected_facts['ansible_distribution'] = 'os123'
            return super(MockSystemdMgr, self).collect(module=module, collected_facts=collected_facts)

    # Preserve existing module_utils
    original_module_utils = basic._ANSIBLE_ARGS
    original_collector = collector.FactsCollector

    # We are going to replace the module_utils with our mock.
    # The test

# Generated at 2022-06-11 05:11:01.513256
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    # Mock the module
    module = type('module', (object,), {})
    # Mock the function get_file_content
    module.get_file_content = lambda name: ''
    # Mock the function get_bin_path
    module.get_bin_path = lambda name: '/usr/bin/systemctl'
    # Test if the function is_systemd_managed returns True when a system is systemd managed
    # Create a directory run/systemd/system
    os.makedirs('/run/systemd/system')
    assert ServiceMgrFactCollector.is_systemd_managed(module)
    # Remove the directory run/systemd/system created above
    os.removedirs('/run/systemd/system')

# Generated at 2022-06-11 05:11:11.683108
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import LazyFactsCollector

    class MockModule:
        def __init__(self):
            self.path = {}

        def get_bin_path(self, command):
            paths = {
                'systemctl': '/bin/systemctl',
                'init': '/bin/init',
            }
            return paths.get(command)

        def run_command(self, command):
            if self.path['systemctl'] and 'status' in command and 'systemd-logind.service' in command:
                return 0, 'active', ''

        def exists(self, path):
            return True

        def isfile(self, path):
            return True

        def islink(self, path):
            return True



# Generated at 2022-06-11 05:11:19.754347
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import shutil

    class DummyModule():
        def __init__(self):
            self.tmp_dir = tempfile.mkdtemp()

        def get_bin_path(self, command):
            return os.path.join(self.tmp_dir, command)

    init_path = os.path.join('/sbin', 'init')

    class DummyTest():
        def __init__(self, symlink_target, test_result):
            self.symlink_target = symlink_target
            self.test_result = test_result

    test_data = [
        DummyTest('systemd', True),
        DummyTest('dummy', False),
    ]


# Generated at 2022-06-11 05:11:31.011613
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import ModuleCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class ModuleDummy:
        def __init__(self):
            self.params = ()
            self.args = ()
            self.exit_json = lambda **kwargs: kwargs
            self.fail_json = lambda **kwargs: kwargs
            self.run_command = lambda command, **kwargs: (0, '', '')
            self.get_bin_path = lambda command: '/usr/bin/systemctl' if command == 'systemctl' else None

        @staticmethod
        def is_executable(filename):
            return True


# Generated at 2022-06-11 05:11:34.720420
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    collector = ServiceMgrFactCollector(module=module)

    assert collector.is_systemd_managed_offline(module=module) is False


# Generated at 2022-06-11 05:11:39.315753
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    from ansible.module_utils.facts.collector import MockModule

    mock_module = MockModule()

    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    service_mgr = ServiceMgrFactCollector()

    assert service_mgr.is_systemd_managed(mock_module) == False
    mock_module.get_bin_path.return_value='systemctl'

    # empty directories
    mock_module.path_exists.return_value = False
    assert service_mgr.is_systemd_managed(mock_module) == False

    # /run/systemd/system exists
    mock_module.path_exists.return_value = True

# Generated at 2022-06-11 05:11:45.778193
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    from ansible.module_utils.facts.collector import MockModule

    def mock_module_get_bin_path(module, name):
        if name == 'uname' or name == 'systemctl':
            return '/bin/%s' % name
        if name == 'initctl':
            return '/sbin/%s' % name
        return None

    def mock_module_run_command(module, cmd, use_unsafe_shell):
        if cmd == 'systemctl':
            return 0, 'systemd', ''
        if cmd == 'systemctl is-active systemd-logind':
            return (0, 'active', '')
        if cmd == 'systemctl is-active upstart-logind':
            return (1, '', '')

# Generated at 2022-06-11 05:11:54.830146
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class Module(object):
        def __init__(self, results_dict):
            self._results_dict = results_dict
            self.run_command_results = {'is_systemd_managed': [0, '', '']}
            self.get_bin_path_results = {'systemctl': 'systemctl'}
            self.command_exists_results = {'systemctl': True}
            self.check_output_results = {'init': [0, '', ''], 'pidof': [0, '', ''], 'ps': [0, '', '']}
            self.stat_results = {'/sbin/init': 'sbin_init', '/usr/bin/systemctl': 'systemctl'}
            self.readlink_results = {'/sbin/init': 'init'}
            self.path_isf

# Generated at 2022-06-11 05:12:12.780585
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module = AnsibleModule({})
    fact_collector = ServiceMgrFactCollector()
    collected_facts = {'ansible_system':'Linux'}
    assert fact_collector.collect(module, collected_facts)['service_mgr'] == 'sysvinit'


# Generated at 2022-06-11 05:12:16.866048
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Create instance of class with args and call method under test
    distro = "distro"
    facts = {'distribution': distro}
    s = ServiceMgrFactCollector()
    res = s.collect(collected_facts=facts)
    assert res['service_mgr'] != None


# Generated at 2022-06-11 05:12:26.583333
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    """
    Test the method collect of class ServiceMgrFactCollector
    """
    class ModuleMock(object):
        def __init__(self, status=None, out="COMMAND\n", err='', bin_path='/bin/systemctl'):
            self.status = status
            self.out = out
            self.err = err
            self.bin_path = bin_path
            self.run_command_calls = []

        def get_bin_path(self, arg):
            return self.bin_path

        def run_command(self, command, use_unsafe_shell):
            self.run_command_calls.append(command)
            return self.status, self.out, self.err

    module = ModuleMock(status=0, out='systemd')
    base_facts = {}

# Generated at 2022-06-11 05:12:35.981839
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os, tempfile, shutil
    from ansible.module_utils.facts import ModuleFactCollector

    facts = {}

# Generated at 2022-06-11 05:12:46.678374
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    def test_service_mgr_name(service_mgr_name, expected_result):
        class ModuleMock:
            def get_bin_path(self, name, *args, **kwargs):
                if name == 'systemctl':
                    return name
                return None

            def run_command(self, command, use_unsafe_shell=True):
                return (0, '', '')

        class CollectedFactsMock:
            def __init__(self):
                self.dict = {
                    'ansible_distribution': service_mgr_name
                }

            def get(self, name, default=None):
                return self.dict.get(name, default)

        module_mock = ModuleMock()
        collected_facts = CollectedFactsMock()
        service_mgr_fact_

# Generated at 2022-06-11 05:12:55.814250
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.utils import get_file_content

    test_module = AnsibleModule(argument_spec={})
    test_module.params['name'] = 'unit.test'
    test_module.params['enabled'] = True

    class FakeModule(object):
        def __init__(self):
            self.run_command_patches = []
            self.run_command_calls = []
            self.run_command_results = []

        def run_command(self, cmd, check_rc=False, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(cmd)
            cmd_result

# Generated at 2022-06-11 05:13:06.100361
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    try:
        # Create mock module
        module = AnsibleModule(
            argument_spec = dict(),
            supports_check_mode = True
        )

        mock_collect = NonCallableMock(return_value = {
            'ansible_distribution': 'CentOS',
            'ansible_system': 'Linux',
        })
        with patch.object(BaseFactCollector, 'collect', mock_collect):
            # Create service_mgr fact collector
            collector = ServiceMgrFactCollector()

            # Collect service_mgr facts
            facts = collector.collect(module=module)

            # Assert that service_mgr facts were collected
            assert facts['service_mgr'] is not None
    except:
        raise

    return True


# Generated at 2022-06-11 05:13:15.245094
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    def _get_module():
        class _Module():
            def get_bin_path(self, *args, **kwargs):
                pass

        return _Module()

    # test_case_1: return True if /run/systemd/system/ is present
    def _test_case_1():
        with patch('os.path.exists', return_value=True):
            assert ServiceMgrFactCollector.is_systemd_managed(_get_module())

    # test_case_2: return True if /dev/.run/systemd/ is present
    def _test_case_2():
        with patch('os.path.exists', return_value=True):
            assert ServiceMgrFactCollector.is_

# Generated at 2022-06-11 05:13:23.384620
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule:
        def __init__(self):
            self.params = {}
            self.exit_params = None

    class MockCollector:
        def __init__(self):
            self.collected_facts = {}

    with open('/proc/1/comm', 'w') as f:
        f.write('systemd')
    with open('/proc/1/cmdline', 'w') as f:
        f.write('/sbin/init')
    class MockModule2:
        def __init__(self):
            self.params = {}
            self.exit_params = None

        def get_bin_path(self, command):
            return "/sbin/" + command

    class MockCollector2:
        def __init__(self):
            self.collected_facts = {}


# Generated at 2022-06-11 05:13:31.601627
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def get_bin_path(self, name):
            return name

    # Mocked environment, no 'systemd' canary files exist
    assert ServiceMgrFactCollector.is_systemd_managed(MockModule()) == False

    # Mock the return value of readlink for '/sbin/init'
    with mock.patch('os.path.islink') as mock_os_path_islink:
        mock_os_path_islink.return_value = True
        with mock.patch('os.readlink') as mock_os_readlink:
            mock_os_readlink.return_value = 'systemd'

            # Assert that systemd is detected
            assert ServiceMgrFactCollector.is_systemd_managed(MockModule()) == True



# Generated at 2022-06-11 05:14:07.552371
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils import facts

    class MockModule(object):
        def get_bin_path(self, executable):
            return None

        def run_command(self, executable, use_unsafe_shell=True):
            return (0, None, None)

    collector = ServiceMgrFactCollector()
    res_dict = collector.collect(module=MockModule(), collected_facts=dict(ansible_system='Linux'))
    assert res_dict['service_mgr'] == 'service'

# Generated at 2022-06-11 05:14:17.502037
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Instantiate a fake AnsibleModule object.
    # Pass its dict in collected_facts parameter to the method under test.
    # This instantly gives the method access to all Ansible facts 'ansible_distribution', 'ansible_system', etc.
    # We can use that to manipulate the return value of the method under test.
    # AnsibleModule only needs its run_command method to work.
    # emulate the return of run_command with a lambda function.
    module = lambda: 0  # noqa: E731
    module.run_command = lambda cmd, use_unsafe_shell: (
        0,  # rc
        b"",  # out
        b""  # err
    )
    module.get_bin_path = lambda cmd: True  # noqa: E731

# Generated at 2022-06-11 05:14:23.779971
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # define test data
    module_mock = None
    collected_facts_mock = {
        'ansible_system': 'Linux',
    }

    # initialize test class
    test_class = ServiceMgrFactCollector()

    # run method collect
    result = test_class.collect(module=module_mock, collected_facts=collected_facts_mock)
    assert test_class.required_facts == set(['platform', 'distribution'])
    assert result['service_mgr'] == 'service'

# Generated at 2022-06-11 05:14:31.661133
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class FakeModule(object):

        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return "systemctl"

    class FakeFacts(object):
        platform = "Linux"
        distribution = "CentOS"

    module = FakeModule()
    module.run_command = FakeModule.run_command
    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed_offline(module) == False


if __name__ == '__main__':
    import pytest

    pytest.main(['-v', __file__])

# Generated at 2022-06-11 05:14:42.496976
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockCommand

    import os
    import platform
    import shutil

    MockModule.run_command = MockCommand

    def side_effect_for_run_command(command, check_rc=True, close_fds=True, executable=None,
                                    data=None, binary_data=False, path_prefix=None, cwd=None,
                                    use_unsafe_shell=False, prompt_regex=None, environ_update=None,
                                    umask=None, encoding=None):
        if command in ['ps -p 1 -o comm|tail -n 1', 'systemctl', 'init --version']:
            return [0, '/usr/bin/systemd', '']

# Generated at 2022-06-11 05:14:42.991832
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector().collect()

# Generated at 2022-06-11 05:14:54.743572
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    from ansible.module_utils.facts import EpicFactModule
    from ansible.module_utils.facts.collector import FactCollector

    ansible_module_mock = EpicFactModule()

    # This does not test the actual collect method, just the is_systemd_managed methods
    facts_mock_dict = {
        'platform': 'Linux',
        'distribution': 'MacOSX'
    }

    for method in ['is_systemd_managed', 'is_systemd_managed_offline']:
        # Mock /sbin/init pointing to systemd
        def mock_isfile_init_systemd(_filename):
            return _filename == 'systemctl' and _filename == '/sbin/init'
        ansible_module_mock.isfile = mock_isfile_init_systemd
        ansible_module

# Generated at 2022-06-11 05:15:04.043534
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    collect_func = ServiceMgrFactCollector()

    class ModuleMock():
        def get_bin_path(self, path):
            return '/bin/' + path

        def run_command(self, command, use_unsafe_shell=False):
            return [0, 'COMMAND', None]

    class moduleMock():
        def __init__(self):
            self.params = {'gather_subset': [], 'filter': '*'}

        def get_bin_path(self, path):
            return '/bin/' + path

        def run_command(self, command, use_unsafe_shell=False):
            return [0, 'COMMAND', None]

    result = collect_func.collect(ModuleMock())
    assert result['service_mgr'] == 'service'

    result

# Generated at 2022-06-11 05:15:09.299842
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class MockModule():
        def __init__(self):
            self.facts={}
            self.params={}
        def get_bin_path(self,arg):
            return str('/usr/bin/systemctl')
    smfc = ServiceMgrFactCollector()
    smfc.required_facts = set()
    module = MockModule()
    assert smfc.is_systemd_managed_offline(module) == False

# Generated at 2022-06-11 05:15:11.693812
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(test_module(params={})), "Test case test_ServiceMgrFactCollector_is_systemd_managed_offline failed, returned False"

# Generated at 2022-06-11 05:15:44.253515
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import MockModule
    import os

    mock_module = MockModule()

    m = mock_module('/dev/.run/systemd/', 'exists')
    assert ServiceMgrFactCollector.check_is_systemd(mock_module)
    assert m.called
    assert m.call_args[0][0] == "/run/systemd/system/"

    m = mock_module('/dev/.run/systemd/', 'exists', False)
    assert not ServiceMgrFactCollector.check_is_systemd(mock_module)
    assert m.called
    assert m

# Generated at 2022-06-11 05:15:50.580701
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # create mock objects
    collected_facts = {}
    collected_facts['ansible_distribution'] = 'RedHat'
    collected_facts['ansible_system'] = 'Linux'

    class MockModule():
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, command):
            if self.params.get('bin_path'):
                return self.params.get('bin_path')
            else:
                return None

    # define return values of mocked methods
    return_value = "/usr/bin/systemctl"

    # create object
    service_mgr = ServiceMgrFactCollector()
    # create mock module
    module = MockModule(params={'bin_path': return_value})
    # run method collect of ServiceMgrFactCollector and test result


# Generated at 2022-06-11 05:15:58.326429
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system import PlatformFactCollector

    class FakeModule(object):
        def run_command(self, command):
            return (0, "/bin/systemd", "")

        def get_bin_path(self, name):
            return "/bin/systemctl"

    class FakeModule2(object):
        def run_command(self, command):
            return (0, "/sbin/init", "")

        def get_bin_path(self, name):
            return "/bin/systemctl"


# Generated at 2022-06-11 05:16:06.730692
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class Options(object):
        def __init__(self):
            self.connection = 'local'

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )

    module.params = {}

    # return function to mock run_command
    def run_command_mock(command, use_unsafe_shell=False, check_rc=True):
        if command == "ps -p 1 -o comm|tail -n 1":
            return 0, "/sbin/init", ""
        elif command == "systemctl show -p Type --value systemd | grep 'systemd'":
            return 0, "systemd", ""
        else:
            raise Exception("Unexpected command: %s" % command)


# Generated at 2022-06-11 05:16:11.834223
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils
    class MockModule(object):
        def get_bin_path(self, path):
            return '/bin/systemctl'

        def run_command(self):
            pass

    module = MockModule()
    ansible.module_utils.is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed
    assert ansible.module_utils.is_systemd_managed(module) == True


# Generated at 2022-06-11 05:16:12.654070
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector.collect()

# Generated at 2022-06-11 05:16:18.969731
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ''' Unit test for method collect of class ServiceMgrFactCollector '''
    def mock_get_file_content(path):
        ''' Mocking method get_file_content '''
        return 'COMMAND\n'

    def mock_get_bin_path(cmd):
        ''' Mocking method get_bin_path '''
        return True

    def mock_run_command(*cmd, **kwargs):
        ''' Mocking method run_command '''
        return 0, 'COMMAND', ''

    def mock_os_path_islink(path):
        ''' Mocking method os.path.islink '''
        return True

    def mock_os_readlink(path):
        ''' Mocking method os.readlink '''
        return 'COMMAND'


# Generated at 2022-06-11 05:16:27.655036
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create mock object for module
    class MockModule(object):
        def __init__(self):
            pass
        def get_bin_path(self, command):
            return "./" + command
    module = MockModule()
    # Create mock object for os
    class MockOs(object):
        def __init__(self):
            pass
        @staticmethod
        def path(path):
            return {
                "/run/systemd/system/": True,
                "/dev/.run/systemd/": True,
                "/dev/.systemd/": True
            }[path]
    os = MockOs()
    # Create mock object for os.path
    class MockOsPath(object):
        def __init__(self):
            pass

# Generated at 2022-06-11 05:16:37.955615
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import shutil
    import tempfile
    import ansible.module_utils.facts.collectors.system.service_mgr as SMFC

    temp_dir_path = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_dir_path, 'run', 'systemd', 'system'))
    os.mkdir(os.path.join(temp_dir_path, 'dev', '.run', 'systemd'))
    os.mkdir(os.path.join(temp_dir_path, 'dev', '.systemd'))

    # test canary directories should be detected
    os.environ['HOME'] = temp_dir_path
    os.environ['PATH'] = os.path.join(temp_dir_path, 'bin')

# Generated at 2022-06-11 05:16:42.840433
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector

    class MockModule(object):
        def get_bin_path(self, program):
            return 'systemctl'
    module = MockModule()

    systemd_managed_offline = ansible.module_utils.facts.collector.ServiceMgrFactCollector.is_systemd_managed_offline(module)
    assert systemd_managed_offline is False

# Generated at 2022-06-11 05:17:21.387211
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Facts


# Generated at 2022-06-11 05:17:23.921927
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    module = MockModule()
    ServiceMgrFactCollector.is_systemd_managed_offline(module)
    assert module.get_bin_path.called
    assert module.run_command.called


# Generated at 2022-06-11 05:17:31.784285
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class Module(object):
        def __init__(self):
            self.path = "/bin:/usr/bin"
        def get_bin_path(self, command, *args, **kwargs):
            if command == "systemctl":
                return "/usr/bin/systemctl"
            return None
    module = Module()
    s = ServiceMgrFactCollector()

    # Negative test
    result = s.is_systemd_managed_offline(module)
    assert result == False

    # Positive test
    os.symlink("../lib/systemd/systemd", "/sbin/init")
    result = s.is_systemd_managed_offline(module)
    os.remove("/sbin/init")
    assert result == True

# Generated at 2022-06-11 05:17:39.336390
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import shutil


# Generated at 2022-06-11 05:17:46.766498
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # create service mgr fact collector instance
    sm = ServiceMgrFactCollector()

    # Mock module
    class MockModule(object):
        def get_bin_path(self, arg):
            return "/bin/systemctl"

    # Mock module os
    class MockOs(object):
        def path_exists(self, arg):
            return True

    # Mock module os.path
    class MockOsPath(object):
        def exists(self, arg):
            return True

        def islink(self, arg):
            return True

        def basename(self, arg):
            return "systemd"

    module = MockModule()
    module.os = MockOs()
    module.os.path = MockOsPath()

    # Check if method is_systemd_managed returns True
    assert sm.is_systemd_managed

# Generated at 2022-06-11 05:17:54.159203
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock

    module_mock = mock.Mock()
    module_mock.get_bin_path = mock.Mock()
    module_mock.get_bin_path.return_value = '/bin/systemctl'

    assert ServiceMgrFactCollector.is_systemd_managed(module_mock) == False
    module_mock.get_bin_path.return_value = '/usr/bin/systemctl'

    assert ServiceMgrFactCollector.is_systemd_managed(module_mock) == False
    module_mock.run_command = mock.Mock()
    module_mock.run_command.return_value = (0, '', '')

    assert ServiceMgrFactCollector.is_systemd_managed(module_mock) == False
    module_mock.run

# Generated at 2022-06-11 05:18:01.088672
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import shutil
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collector

    class Module:
        def get_bin_path(self, path):
            if path == 'systemctl':
                return '/bin/systemctl'
            return None

    def test(trusted_path, expected_result):
        os.chmod(trusted_path, 0o755)
        os.symlink(trusted_path, os.path.join(temp_root, 'sbin', 'init'))
        test_object = ServiceMgrFactCollector()
        actual_result = test_object.is_systemd_managed_offline(module)
        assert actual_result == expected_result
        return True

    temp

# Generated at 2022-06-11 05:18:06.566285
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import os
    import shutil
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr import ServiceMgrFactCollector

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary systemd init symlink

# Generated at 2022-06-11 05:18:10.541560
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import AnsibleFactCollector

    module = AnsibleModule(argument_spec={})

    # create a fact collector and load the ServiceMgr fact collector
    fact_collector = AnsibleFactCollector()
    fact_collector.collectors = [ServiceMgrFactCollector()]

    # set system and distribution facts so the ServiceMgr fact collector can work
    fact_collector.collected_facts = {
        'ansible_system': 'Linux',
        'ansible_distribution': 'CentOS',
    }
    fact_collector.collect(module=module)
    facts = fact_collector.get_facts(module)

    assert facts['service_mgr'] == 'service'

# Generated at 2022-06-11 05:18:19.617354
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    def mock_get_file_content(path, default=None):
        return path

    def mock_get_bin_path(path, default=None):
        return path

    def mock_run_command(cmd, data=None, follow=False, check_rc=False, executable=None, use_unsafe_shell=False):
        return 0, "test_output", None

    def mock_platform_mac_ver(self, release=''):
        return ('10.13.4', ('', '', ''), 'x86_64')

    def mock_os_path_exists(path):
        return True

    def mock_os_path_islink(path):
        return True

    def mock_os_readlink(path):
        return path


# Generated at 2022-06-11 05:20:07.694798
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Module class to mock
    class AnsibleModuleMock:
        def get_bin_path(self, path):
            return '/sbin/init'

        def run_command(self, command):
            if command == 'ps -p 1 -o comm|tail -n 1':
                return 0, 'systemd', None
            return -1, '', None

    # Create a ServiceMgrFactCollector
    service_mgr_collector = ServiceMgrFactCollector()

    # Create a AnsibleModuleMock
    ansible_module_mock = AnsibleModuleMock()

    # Collect facts
    collected_facts = service_mgr_collector.collect(ansible_module_mock, {})

    # Assert that service_mgr is systemd

# Generated at 2022-06-11 05:20:14.953894
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import _get_collector_whitelist

    # fake module
    class FakeModule:
        def get_bin_path(self, cmd, required=False):
            return cmd

    module = FakeModule()

    # create a file /run/systemd/system/
    if not os.path.exists('/run/systemd/system/'):
        os.makedirs('/run/systemd/system/')

    assert ServiceMgrFactCollector.is_systemd_managed(module) is True

    # clean the file
    os.rmdir('/run/systemd/system/')

    assert ServiceMgrFactCollector.is_systemd_managed(module) is False
