

# Generated at 2022-06-11 05:10:42.201774
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    sm_mock_module = mock.Mock()
    sm_mock_module.get_bin_path.return_value = '/bin/systemctl'

    sm_collector = ServiceMgrFactCollector()
    assert sm_collector.is_systemd_managed(sm_mock_module) == False

    sm_mock_module.get_bin_path.return_value = ''
    assert sm_collector.is_systemd_managed(sm_mock_module) == False

    # Return value of mock_isfile_false should be ignored
    sm_mock_isfile = mock.Mock()
    sm_mock_isfile.return_value = False


# Generated at 2022-06-11 05:10:53.264194
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    platform_facts = {
        'platform': 'Linux',
        'distribution': 'RedHat',
    }
    tmp_module = MockModule(platform_facts=platform_facts)
    # get_file_content(path) returns None when path doesn't exist
    tmp_get_file_content = ServiceMgrFactCollector.get_file_content
    ServiceMgrFactCollector.get_file_content = Mock(side_effect=[None, 'init', 'systemd', 'svscan', 'procd'])
    # tmp_module.get_bin_path(path) returns None when path doesn't exist
    tmp_get_bin_path = tmp_module.get_bin_path
    tmp_module.get_bin_path = Mock(side_effect=[None, None, '/bin/systemctl', '/bin/systemctl'])

# Generated at 2022-06-11 05:10:55.512908
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector

# Generated at 2022-06-11 05:11:03.251071
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class FakeModule():
        def get_bin_path(self, arg):
            return '/etc/systemd/systemd'

    print('Test ServiceMgrFactCollector.is_systemd_managed method.')
    print('Create a fake instance of ServiceMgrFactCollector.')
    module = FakeModule()
    collector = ServiceMgrFactCollector()
    print(('Invoke collector.is_systemd_managed with module = %s' % module))
    expected = False
    actual = collector.is_systemd_managed(module=module)
    print(('Expected: %s' % expected))
    print(('Actual: %s' % actual))
    assert actual == expected


# Generated at 2022-06-11 05:11:13.248898
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector._fact_ids = set()
    ServiceMgrFactCollector.required_facts = set(['platform', 'distribution'])
    collected_facts = {'platform': 'linux', 'distribution': 'OpenWrt'}
    ServiceMgrFactCollector.collect(collected_facts=collected_facts)
    assert collected_facts['service_mgr'] == 'openwrt_init'
    collected_facts = {'platform': 'darwin', 'distribution': 'MacOSX'}
    ServiceMgrFactCollector.collect(collected_facts=collected_facts)
    assert collected_facts['service_mgr'] == 'launchd'
    collected_facts = {'platform': 'bsd', 'distribution': 'FreeBSD'}

# Generated at 2022-06-11 05:11:16.309779
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.system.service_mgr

    if platform.system() == 'Linux':
        assert ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

# Generated at 2022-06-11 05:11:26.509286
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def __init__(self, rc, stdout):
            self.rc = rc
            self.stdout = stdout

        def run_command(self, cmd, check_rc=False, use_unsafe_shell=True):
            return self.rc, self.stdout, ''

    # With systemd-vconsole-setup.service available
    module = MockModule(0, '/usr/lib/systemd/system/systemd-vconsole-setup.service\n')
    assert ServiceMgrFactCollector.is_systemd_managed(module)

    # With systemd-vconsole-setup.service unavailable
    module = MockModule(1, '')
    assert not ServiceMgrFactCollector.is_systemd_managed(module)

# Generated at 2022-06-11 05:11:36.925960
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFile

    mock_module = MockModule()
    mock_module.get_bin_path = lambda x: "/bin/systemctl"

    fake_file = MockFile()
    fake_file.content = None
    fake_file.exists = False

    m = mock_module('/run/systemd/system', fake_file)
    assert ServiceMgrFactCollector.is_systemd_managed(m)
    m = mock_module('/dev/.run/systemd/', fake_file)
    assert ServiceMgrFactCollector.is_systemd_managed(m)
    m = mock_module('/dev/.systemd/', fake_file)

# Generated at 2022-06-11 05:11:45.336586
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import subprocess

    class AnsibleModuleStub:
        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

        def run_command(self, cmd, use_unsafe_shell):
            if cmd == 'ps -p 1 -o comm|tail -n 1':
                return (0, to_bytes('init'), None)
            else:
                return (0, to_bytes('openrc\n'), None)

    class BasicStub:
        @staticmethod
        def log(x):
            return

    basicStub = BasicStub()
    ansibleModuleStub = AnsibleModuleStub()
    collector

# Generated at 2022-06-11 05:11:49.109224
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import MockModule
    c = ServiceMgrFactCollector()

    mm = MockModule({'run_command.return_value': (0, '/bin/systemctl', '')})
    assert c.is_systemd_managed(mm) is True



# Generated at 2022-06-11 05:12:09.870157
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    '''Unit test for method collect of class ServiceMgrFactCollector'''

    class ModuleStub:

        def get_bin_path(self, program):
            return True

        def run_command(self, cmd, use_unsafe_shell=True):

            return 0, cmd, ''

    module = ModuleStub()
    collected_facts = {}
    service_mgr_name = ServiceMgrFactCollector.collect(module, collected_facts)
    assert service_mgr_name.get('service_mgr') == 'service'


# Generated at 2022-06-11 05:12:19.720413
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class TestModule(object):
        def get_bin_path(self, cmd):
            return '/bin/systemctl'
    test_module = TestModule()

    # ensure true if /run/systemd/system/ exists
    os.makedirs('/run/systemd/system/')
    assert ServiceMgrFactCollector.is_systemd_managed(module=test_module)
    os.removedirs('/run/systemd/system/')

    # ensure true if /dev/.run/systemd/ exists
    os.makedirs('/dev/.run/systemd/')
    assert ServiceMgrFactCollector.is_systemd_managed(module=test_module)

# Generated at 2022-06-11 05:12:29.500815
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        def get_bin_path(self, binary_name):
            return binary_name
    module = MockModule()

    mock_init = MockModule()
    mock_init.path = '/sbin/init'
    mock_init.is_systemd = Mock(return_value=True)

# Generated at 2022-06-11 05:12:38.958093
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class MockModule:
        # The path of systemctl
        def get_bin_path(self, cmd):
            if cmd == 'systemctl':
                return cmd
            return None

    module = MockModule()

    # The test for this method on linux is covered in the file
    # test/units/modules/utility/linux/test_service.py, the test only cover
    # the path the function takes on the os_family 'Solaris'

    if platform.system() != 'SunOS':
        return

    # Set the required file to tell the function to return True
    open('/sbin/init', 'a').close()
    os.symlink('/systemd', '/sbin/init')

    # Create a object of the class ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFact

# Generated at 2022-06-11 05:12:47.682793
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    collector = ServiceMgrFactCollector()
    platform_system = platform.system()
    if platform_system == 'Darwin':
        facts = {'platform': 'Darwin',
                 'distribution': 'MacOSX'}
    elif platform_system == 'Linux':
        facts = {'platform': 'Linux',
                 'distribution': 'CentOS'}
    else:
        facts = {'platform': 'AIX',
                 'distribution': 'AIX'}

    result = collector.collect(collected_facts=facts)
    assert 'service_mgr' in result
    assert result['service_mgr'] == 'service'

# Generated at 2022-06-11 05:12:56.885185
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    class DummyModule(object):
        def __init__(self, params=None):
            self.params = params
            self.name = 'ansible_service_mgr'

        def __call__(self):
            return self.params

        def __getitem__(self, item):
            return self.params[item]

        # TODO: Avoid code duplication with platform.py
        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            '''
            Returns the path to an executable finding it in the PATH.
            Looks for executable in the following places:
            * os.environ['PATH']
            * platform-specific paths specified in opt_dirs
            * uses a default path based on the platform
            '''
            # allow injecting alternate paths, will be helpful for
            # oddballs

# Generated at 2022-06-11 05:13:07.540180
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts
    import ansible.module_utils
    import ansible.module_utils.common.process
    import ansible.module_utils.common
    import ansible.module_utils.basic
    import ansible.module_utils.parsing.convert_bool
    import ansible.module_utils.parsing.converter

    import copy
    import sys
    import tempfile


# Generated at 2022-06-11 05:13:09.735413
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts import Collector

    # run collect
    facts = Collector().collect(['service_mgr'])
    assert facts['service_mgr'] == 'service'

# Generated at 2022-06-11 05:13:18.492170
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import tempfile
    import shutil

    fake_module = FakeModule()

    # Add systemd binary to fake command
    fake_module.run_command_exe['systemctl'] = '/bin/true'

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-11 05:13:26.703593
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile

    class ModuleMock():
        def __init__(self):
            self.tmp_dir = tempfile.mkdtemp()

        def get_bin_path(self, cmd, opt_dirs=[]):
            return os.path.join(self.tmp_dir, cmd)

    module = ModuleMock()
    with open(module.get_bin_path('systemctl'), 'w'):
        pass

    collector = ServiceMgrFactCollector()

# Generated at 2022-06-11 05:13:48.690036
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    dummy_module = basic.AnsibleModule(argument_spec=dict())
    collector = ServiceMgrFactCollector()

    collector.is_systemd_managed_offline(dummy_module)


# Generated at 2022-06-11 05:13:52.245949
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.facts.collectors.service_mgr as service_mgr
    module = AnsibleModule()
    result = service_mgr.ServiceMgrFactCollector.is_systemd_managed(module)
    assert result is False


# Generated at 2022-06-11 05:14:01.757778
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class MockModule:
        def get_bin_path(self, arg):
            return "/bin/systemctl"

    service_mgr = ServiceMgrFactCollector()

    # create a mock object to simulate module object
    module = MockModule()
    module.run_command = MockModule()
    module.run_command.return_value = [0, '/usr/lib/systemd/systemd', '']
    assert service_mgr.is_systemd_managed_offline(module) is True

    module.run_command.return_value = [0, '/usr/lib/systemd/systemd-journald', '']
    assert service_mgr.is_systemd_managed_offline(module) is False

    module.run_command.return_value = [0, '', '']
    assert service_m

# Generated at 2022-06-11 05:14:11.687801
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    from . import AnsibleModuleMock
    fc = ServiceMgrFactCollector()

    m = AnsibleModuleMock()
    m.get_bin_path.side_effect = [ "/usr/bin/systemctl",
                                   "/usr/bin/systemctl",
                                   "/usr/bin/systemctl",
                                   "/usr/bin/systemctl",
                                   "/usr/bin/systemctl",
                                   "/usr/bin/systemctl",
                                   "/usr/bin/systemctl", None ]

    # This is the state of the system that we want to test, systemd is present but not active
    m.path_exists.side_effect = [ False, False, False ]

    assert fc.is_systemd_managed(module=m) == False

    # This is the state of the system that we want to test,

# Generated at 2022-06-11 05:14:21.417639
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import os
    import tempfile

    from ansible.module_utils.facts.collector import BaseFactCollector

    # create a fake systemctl
    tmpdir = tempfile.mkdtemp()
    systemctl = os.path.join(tmpdir, 'systemctl')
    open(systemctl, 'w').close()
    os.chmod(systemctl, 0o755)

    # create a fake systemctl --version
    version = os.path.join(tmpdir, 'version')
    open(version, 'w').write('systemd')
    os.chmod(version, 0o755)

    # create a fake /sbin/init
    init = tempfile.NamedTemporaryFile(prefix='init-', delete=False)
    # do not delete fake init
    init.close()

    # manipulate the path to include

# Generated at 2022-06-11 05:14:31.487223
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    sh_cmd = '/bin/sh'
    initctl_cmd = '/sbin/initctl'
    systemctl_cmd = '/bin/systemctl'


# Generated at 2022-06-11 05:14:42.319773
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    container_facts = dict(
        container='lxc',
        ansible_system='Linux',
        ansible_distribution='Alpine'
    )


# Generated at 2022-06-11 05:14:48.860245
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    test_module = AnsibleModule(argument_spec={})
    test_obj = ServiceMgrFactCollector()

    # Test cases:
    # - `systemctl` is not on $PATH:
    #   - `/sbin/init` is not a symlink: False
    #   - `/sbin/init` is a symlink pointing to anything other than 'systemd': False
    #     - `/sbin/init` is a symlink pointing to 'systemd': True
    # - `systemctl` is on $PATH:
    #   - `/sbin/init` is not a symlink: True
    #   - `/sbin/init` is a symlink pointing to anything other than 'systemd': True
    #   - `/sbin/init` is a symlink pointing to 'system

# Generated at 2022-06-11 05:14:59.316410
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import sys
    import mock

    # create a mock ansible module
    testmodule = mock.MagicMock()
    # and a mock of os.path for it as well
    testmodule.os.path = mock.MagicMock()

    def side_effect(name):
        if name == 'systemctl':
            return '/bin/true'
        elif name == '/run/systemd/system/':
            return True
        elif name == '/dev/.run/systemd/':
            return True
        elif name == '/dev/.systemd/':
            return True
        else:
            return False

    testmodule.os.path.exists = mock.MagicMock(side_effect=side_effect)

    # create an instance of ServiceMgrFactCollector

# Generated at 2022-06-11 05:15:02.204600
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    collector = ServiceMgrFactCollector()
    assert not collector.is_systemd_managed(None)

if __name__ == '__main__':
    test_ServiceMgrFactCollector_is_systemd_managed()

# Generated at 2022-06-11 05:15:52.353449
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import unittest.mock
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.service_mgr

    class ModuleMock(object):
        def get_bin_path(self, name):
            return name

    class CollectedFactsMock(object):
        def __init__(self):
            self.ansible_distribution = 'OpenWrt'
            self.ansible_system = 'Linux'
            self.platform = 'Linux'
            self.distribution = 'OpenWrt'
            self.distribution_version = '14.07'

    collected_facts_mock = CollectedFactsMock()

    # TODO: test for more service managers

# Generated at 2022-06-11 05:16:00.346283
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import ansible.module_utils.basic

    # mock the module to be used by is_systemd_managed
    class MockModule(object):
        def __init__(self, systemd_managed, systemctl_binary):
            self.systemd_managed = systemd_managed
            self.systemctl_binary = systemctl_binary

        def get_bin_path(self, path):
            if path == 'systemctl':
                return self.systemctl_binary
            else:
                return None

    module_dict = dict()
    module_dict['ServiceMgrFactCollector'] = ServiceMgrFactCollector

    test_cases = [
        [True, "/bin/systemctl", True],
        [False, "/bin/systemctl", False],
        [False, None, False],
        [True, None, False],
    ]



# Generated at 2022-06-11 05:16:08.893246
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    def get_bin_path(binary):
        if binary == 'systemctl':
            return '/bin/systemctl'
        else:
            return None

    class MockModule:
        def __init__(self, is_canary):
            self.is_canary = is_canary
        def get_bin_path(self, binary):
            return get_bin_path(binary)

    class MockFile:
        def __init__(self, is_canary, exists_return_value):
            self.is_canary = is_canary
            self.exists_return_value = exists_return_value
        def exists(self, canary):
            if canary == self.is_canary:
                return self.exists_return_value

    canary_true = '/run/systemd/system/'


# Generated at 2022-06-11 05:16:16.300141
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class Module:
        def get_bin_path(self, s):
            if s == 'systemctl':
                return 'systemctl'

    class Facts:
        platform = ""
        distribution = ""
        ansible_system = ""

    # case 01: /run/systemd/system/
    def os_path_exists(path):
        if path == '/run/systemd/system/':
            return True
        return False

    tc = ServiceMgrFactCollector()

    module = Module()
    facts = Facts()
    assert tc.is_systemd_managed(module) == True

    # case 02: /dev/.run/systemd/
    def os_path_exists(path):
        if path == '/dev/.run/systemd/':
            return True
        return False

    tc = ServiceMgrFact

# Generated at 2022-06-11 05:16:19.129736
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    test_obj = ServiceMgrFactCollector()
    test_obj1 = BaseFactCollector()
    assert test_obj.is_systemd_managed_offline(test_obj1) == False

# Generated at 2022-06-11 05:16:27.817835
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    m = module.ModuleStub()

    # ensure we return false if systemctl is not available
    assert ServiceMgrFactCollector.is_systemd_managed_offline(m) is False

    # add systemctl (this is the only required command)
    m.get_bin_path.return_value = 'foo'
    m.run_command.return_value = (0, '', '')

    # /sbin/init does not exist
    m.path_exists.return_value = False
    assert ServiceMgrFactCollector.is_systemd_managed_offline(m) is False

    # /sbin/init symlink does not point to systemd
    m.path_exists.return_value = True
    os.path.islink.return_value = True
    os.readlink.return_value

# Generated at 2022-06-11 05:16:38.119047
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MyModule:
        class RunCommand:
            def __init__(self, stdout='', stderr=''):
                self.stdout = stdout
                self.stderr = stderr
                self.rc = 0

        def run_command(self, *args, **kwargs):
            if args[0] == 'systemctl':
                return MyModule.RunCommand()
            return MyModule.RunCommand('', 'Command not found')


# Generated at 2022-06-11 05:16:39.076064
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector.collect_from(None)

# Generated at 2022-06-11 05:16:48.434252
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    # Create an object of class ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Create a stub module without systemctl executable
    module_obj = MockModule()
    module_obj.get_bin_path = Mock(return_value=None)

    assert not service_mgr_fact_collector.is_systemd_managed_offline(module_obj)

    # Create a stub module with systemctl executable
    module_obj = MockModule()
    module_obj.get_bin_path = Mock(return_value='/usr/bin/systemctl')

    # Remove /sbin/init file
    os.remove('/sbin/init')

    assert not service_mgr_fact_collector.is_systemd_managed_offline(module_obj)

    #

# Generated at 2022-06-11 05:16:57.988335
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    class TestModule(object):
        def __init__(self, executable='/bin/systemctl'):
            self.executable = executable

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return self.executable

    # Test when systemctl is not installed
    test_module = TestModule(executable=None)
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(test_module)

    # Test when systemctl is installed
    test_module = TestModule(executable='/bin/systemctl')
    assert not ServiceMgrFactCollector.is_systemd

# Generated at 2022-06-11 05:18:23.672505
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    c = ServiceMgrFactCollector()
    res = c.collect()
    assert 'service_mgr' in res
    assert res['service_mgr'] != 'unknown'

# Generated at 2022-06-11 05:18:29.528954
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test_class = ServiceMgrFactCollector()

    fake_module = FakeAnsibleModule()

    fake_module.get_bin_path_dict = { 'systemctl': None }
    assert(test_class.is_systemd_managed(module=fake_module) == False)

    fake_module.get_bin_path_dict = { 'systemctl': 'bin_path_systemctl' }
    # No canaries are are created
    assert(test_class.is_systemd_managed(module=fake_module) == False)

    fake_module.os_path_exists_dict = { '/run/systemd/system/': False, '/dev/.run/systemd/': False, '/dev/.systemd/': False }

# Generated at 2022-06-11 05:18:34.848903
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.facts import ModuleFacts
    from ansible.module_utils.facts import provider
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector

    # Initialize module information
    module = ModuleFacts()
    module.init_params(args=None)
    module.params['gather_subset'] = ['service_mgr']

    # Ensure that is_systemd_managed_offline() always returns false.
    provider.FACT_COLLECTION_PATHS.remove('service_mgr.py')

    ServiceMgrFactCollector.is_systemd_managed_offline(module)



# Generated at 2022-06-11 05:18:41.499994
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    collector = ServiceMgrFactCollector()
    module = FakeModule()
    module.run_command = run_command

    # No tools
    module.command_wrappers = {}
    assert collector.is_systemd_managed(module) == False

    # no canary
    module.command_wrappers = {"systemctl": "echo"}
    assert collector.is_systemd_managed(module) == False

    # no canary
    module.command_wrappers = {"systemctl": "echo"}
    os.path.exists = lambda path: False
    assert collector.is_systemd_managed(module) == False

    # 1st canary
    module.command_wrappers = {"systemctl": "echo"}
    os.path.exists = lambda path: path == "/run/systemd/system/"

# Generated at 2022-06-11 05:18:49.136362
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.system.service_mgr as service_mgr

    class FakeModule(object):
        def run_command(self, cmd, use_unsafe_shell=True):
            if cmd == 'systemctl --version':
                return 0, 'systemd 219', ''
            elif cmd == 'init --version':
                return 0, 'init (upstart 1.13.2)', ''
            else:
                pass

        def get_bin_path(self, command):
            return '/bin/{0}'.format(command)

    class MockOsIsLink(object):
        def __init__(self):
            self.is_systemd_managed_offline_called = False

        def __call__(self, path):
            if path == '/sbin/init':
                return True
           

# Generated at 2022-06-11 05:18:56.681003
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import platform
    import ansible.module_utils.facts.system.service_mgr

    class FakeModule(object):
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/usr/bin/systemctl'
            else:
                return None

    module = FakeModule()
    collector = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector()

    # check true case, with real example
    platform.system = lambda: 'Linux'
    os.path.exists = lambda path: path == '/run/systemd/system/'
    result = collector.is_systemd_managed(module)
    assert result is True

    # check false case
    platform.system = lambda: 'Linux'
    os.path.exists = lambda path: False

# Generated at 2022-06-11 05:19:02.834304
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # mock module for testing
    module = type('', (object,), {
        'get_bin_path': lambda self, x: '/bin/systemctl' if x == 'systemctl' else None,
        })()

    # test some cases
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False
    os.symlink('systemd', '/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == True
    os.unlink('/sbin/init')
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module) == False

# Generated at 2022-06-11 05:19:10.550133
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # We need to mock module object
    import ansible
    class MockModule(object):
        def __init__(self):
            self.fallback = ansible.module_utils.facts.collector

        def get_bin_path(self, path):
            return "/bin/{}".format(path)

    # Start the testing process
    s = ServiceMgrFactCollector()
    module = MockModule()
    result = False

    # First testing process: no symlink
    os.system("rm -f /sbin/init")
    result = s.is_systemd_managed_offline(module)
    assert result == False

    # Second testing process: /sbin/init symlink exist, but not target to systemd
    os.system("ln -s /bin/bash /sbin/init")

# Generated at 2022-06-11 05:19:18.180573
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    a = ServiceMgrFactCollector()

    # Mocking a module

    class SystemdCanary():
        def __init__(self, name, found):
            self.name = name
            self.found = found

    def exists(name):
        if name == 'run':
            return True
        canary = SystemdCanary(name, None)
        a.is_systemd_managed(canary)
        return canary.found

    class FakeModule():
        def __init__(self):
            self.EXEC_NATIVE_SUFFIX_LINE = ''

        def get_bin_path(self, command, required=False):
            if command == 'systemctl':
                return True

        def get_tmp_path(self):
            return None


# Generated at 2022-06-11 05:19:20.273923
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    factCollector = ServiceMgrFactCollector()
    factCollector.is_systemd_managed()
    assert factCollector