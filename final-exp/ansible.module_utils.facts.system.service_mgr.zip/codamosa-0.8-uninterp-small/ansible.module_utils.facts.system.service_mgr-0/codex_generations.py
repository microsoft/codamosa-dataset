

# Generated at 2022-06-25 00:34:16.680702
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    # If exists returns True, is_systemd_managed_offline returns True
    mock_exists_0 = MagicMock(side_effect=[True])
    mock_realpath_0 = MagicMock(return_value="")

    with patch.object(os.path, 'exists', mock_exists_0) as mock_exists_1:
        with patch.object(os, 'readlink', mock_realpath_0) as mock_realpath_1:
            bool_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(None)
            print(bool_0)
            assert bool_0
            # assert mock_exists_1.call_count > 2
            # assert mock

# Generated at 2022-06-25 00:34:24.736661
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    distribution_fact_collector = DistributionFactCollector()
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    platform_fact_collector = PlatformFactCollector()
    from ansible.module_utils.facts.virtual.virtualbox import VirtualBoxFactCollector
    virtualbox_fact_collector = VirtualBoxFactCollector()

# Generated at 2022-06-25 00:34:28.683469
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    # Create a module, this should fail without any arguments
    class Module:
        def get_bin_path(self, *arguments):
            return None
    module_0 = Module()
    bool_0 = service_mgr_fact_collector_0.is_systemd_managed(module=module_0)

# Generated at 2022-06-25 00:34:33.742022
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module_0 = None
    collected_facts_0 = None
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    return_value_0 = service_mgr_fact_collector_0.collect(module_0, collected_facts_0)
    assert return_value_0 == {'service_mgr': 'service'}


# Generated at 2022-06-25 00:34:37.668331
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    ansible_module_0 = AnsibleModule(argument_spec=dict())
    
    bool_result_0 = service_mgr_fact_collector_0.is_systemd_managed(ansible_module_0)

    assert(bool_result_0 == True)
    

# Generated at 2022-06-25 00:34:39.222905
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.collect()


# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 00:34:42.201707
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Mock module import
    class Mock(object):

        class module(object):
            def fail_json(self):
                pass

            def get_bin_path(self):
                return ''

            def run_command(self):
                return 0, '', ''

            def set_fact(self):
                pass


    mock = Mock()

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.collect(mock.module) == {}


# Generated at 2022-06-25 00:34:45.082190
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    bool_0 = True


# Generated at 2022-06-25 00:34:49.328343
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    """
    :return:
    """

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    bool_0 = service_mgr_fact_collector_0.is_systemd_managed()
    print(bool_0)
    print('Tests finished')



# Generated at 2022-06-25 00:34:52.969712
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    # Test with basic parameters
    module_obj = object
    result = service_mgr_fact_collector_0.is_systemd_managed_offline(module_obj)
    assert result == False


# Generated at 2022-06-25 00:35:12.017943
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test cases
    # Case0: Found /run/systemd/system
    # Case1: Found /dev/.run/systemd/
    # Case2: Found /dev/.systemd/
    # Case3: Not found
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    case0_module = MagicMock()
    case0_module.get_bin_path.return_value = 'test'
    case1_module = MagicMock()
    case1_module.get_bin_path.return_value = 'test'
    case2_module = MagicMock()
    case2_module.get_bin_path.return_value = 'test'
    case3_module = MagicMock()
    case3_module.get_bin_path.return_value = 'test'

# Generated at 2022-06-25 00:35:15.505622
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.collect(None, {'platform': 'Linux', 'distribution': 'OpenWrt'})

# Generated at 2022-06-25 00:35:16.930220
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    result = ServiceMgrFactCollector.is_systemd_managed_offline(None)
    assert result == False

# Generated at 2022-06-25 00:35:24.711527
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    class DummyModule:
        def get_bin_path(self, program):
            if program == 'systemctl':
                return True
            else:
                return False
    dummy_module = DummyModule()
    assert service_mgr_fact_collector.is_systemd_managed(module=dummy_module) == False


# Generated at 2022-06-25 00:35:30.596239
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module=None) == False


# Generated at 2022-06-25 00:35:32.473757
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # Execute the method we are testing
    result = ServiceMgrFactCollector.is_systemd_managed(None)

    assert result is False


# Generated at 2022-06-25 00:35:34.553194
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    smf = ServiceMgrFactCollector()
    assert smf.is_systemd_managed_offline({}, ) is False

# Generated at 2022-06-25 00:35:39.068140
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    ServiceMgrFactCollector_is_systemd_managed_offline = ServiceMgrFactCollector()
    assert ServiceMgrFactCollector_is_systemd_managed_offline.is_systemd_managed_offline() == False

# Generated at 2022-06-25 00:35:41.675626
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    tc0_args = {}

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.collect(**tc0_args)

# Generated at 2022-06-25 00:35:43.815058
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed() == False


# Generated at 2022-06-25 00:36:05.341193
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class  ModuleStub:
        def __init__(self):
            self.params = {'test_param': 'test_value'}

        def get_bin_path(self, arg):
            return "test_bin_path"

    class CollectedFacts:
        def __init__(self):
            self.ansible_facts = {'test_fact': 'test_fact_value'}

    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.collect(ModuleStub(), no_fetch="no_fetch") == {'service_mgr': 'service'}
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()

# Generated at 2022-06-25 00:36:07.097196
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    assert service_mgr_fact_collector.is_systemd_managed_offline(None) == False


# Generated at 2022-06-25 00:36:11.084029
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    ServiceMgrFactCollector().collect()

# Generated at 2022-06-25 00:36:15.555675
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    class ModuleMock(object):
        @staticmethod
        def get_bin_path(command):
            return '/bin/systemctl'

    assert service_mgr_fact_collector.is_systemd_managed(module=ModuleMock()) == True

# Generated at 2022-06-25 00:36:18.157832
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.collect()

# Generated at 2022-06-25 00:36:25.885036
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test
    try:
        from ansible.module_utils import basic
    except Exception as e:
        print("Module not found")
        return False

    module = basic.AnsibleModule(argument_spec={})
    Module_Func_Return_Value = ServiceMgrFactCollector.is_systemd_managed(module)

    if not Module_Func_Return_Value:
        print("System is not managed by systemd")
    else:
        print("System is managed by systemd")

    return Module_Func_Return_Value


# Generated at 2022-06-25 00:36:29.172923
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed_offline(module) == service_mgr_fact_collector.is_systemd_managed_offline(module)

# Generated at 2022-06-25 00:36:34.300666
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(module) == False


# Generated at 2022-06-25 00:36:43.186023
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    class Module:
        def __init__(self):
            self.bin_path = {}
            self.bin_path['systemctl'] = 'bin_path'
        def get_bin_path(self, command):
            return self.bin_path.get(command, None)
    module = Module()
    module.bin_path['systemctl'] = None
    assert service_mgr_fact_collector.is_systemd_managed(module) is False
    module.bin_path['systemctl'] = 'bin_path'
    assert service_mgr_fact_collector.is_systemd_managed(module) is False
    os.path.exists = lambda path: False
    assert service_mgr_fact_collector.is_system

# Generated at 2022-06-25 00:36:47.909838
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    test_dict_0 = {
        'ansible_system': 'SunOS',
        'ansible_distribution': 'OpenWrt'
    }
    service_mgr_fact_collector.collect(module=None, collected_facts=test_dict_0)

# Generated at 2022-06-25 00:37:11.576552
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    sm_fact_collector = ServiceMgrFactCollector()

    # Test that systemd is not managed if the runtime and boot systems do not match.
    os.symlink('systemd', '/sbin/init')
    assert not sm_fact_collector.is_systemd_managed_offline(None)
    os.remove('/sbin/init')

    # Test that systemd is not managed if the symlink does not exist.
    assert not sm_fact_collector.is_systemd_managed_offline(None)

    # Test that systemd is managed if the symlink exists and links to systemd.
    os.symlink('systemd', '/sbin/init')
    assert sm_fact_collector.is_systemd_managed_offline(None)


# Generated at 2022-06-25 00:37:18.905994
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    os.symlink("systemd", "/sbin/init")
    assert service_mgr_fact_collector.is_systemd_managed_offline == True
    os.remove("/sbin/init")

    assert service_mgr_fact_collector.is_systemd_managed_offline == False

# Generated at 2022-06-25 00:37:28.189453
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module = AnsibleModuleMock(
        dict(
            ansible_distribution='Ubuntu',
            ansible_system='Linux',
            platform='Ubuntu',
            distribution='Ubuntu'
        )
    )
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    # Testing with distro does not have /proc/1/comm
    service_mgr_name_1 = 'ubuntu_service'
    os.mknod('/proc/1/comm')
    facts_dict_1 = service_mgr_fact_collector_1.collect(module)
    assert facts_dict_1['service_mgr'] == service_mgr_name_1

    # Testing with distro does not have /proc/1/comm

# Generated at 2022-06-25 00:37:33.493329
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.collect() == {'service_mgr': 'service'}

# Generated at 2022-06-25 00:37:35.083876
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline() == None

# Generated at 2022-06-25 00:37:39.027929
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    # Test when systemd is the boot init system
    service_mgr_fact_collector_0.module = MagicMock()
    service_mgr_fact_collector_0.module.get_bin_path.return_value = '/usr/bin/systemctl'
    os.path.islink = MagicMock()
    os.path.islink.return_value = True
    os.readlink = MagicMock()
    os.readlink.return_value = 'systemd'
    assert service_mgr_fact_collector_0.is_systemd_managed_offline() == True

    # Test when systemd is not the boot init system
    os.readlink.return_value = 'upstart'
    assert service_mgr

# Generated at 2022-06-25 00:37:43.647097
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    is_systemd_managed_offline = service_mgr_fact_collector.is_systemd_managed_offline()
    return is_systemd_managed_offline

# Generated at 2022-06-25 00:37:52.699552
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from mock import patch, Mock

    # Create mocks
    module_0 = Mock()
    module_0.get_bin_path.return_value = False

    module_1 = Mock()
    module_1.get_bin_path.return_value = True

    mocked_os_path_islink = Mock()
    mocked_os_path_islink.return_value = False

    mocked_os_readlink = Mock()
    mocked_os_readlink.return_value = "systemd"

    # Test case 1 - bin_path returns False
    ServiceMgrFactCollector.is_systemd_managed_offline(module_0)
    assert module_0.get_bin_path.called is True
    assert module_0.get_bin_path.call_args_list[0] == ('systemctl', )



# Generated at 2022-06-25 00:37:54.316698
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(module=None) is False


# Generated at 2022-06-25 00:37:57.063682
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Test is_systemd_managed_offline with various arguments
    """
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    class_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(None)
    assert class_0 is None


# Generated at 2022-06-25 00:38:33.063808
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class ModuleDummy(object):
        def get_bin_path(arg):  # pylint: disable=no-self-use
            return "/bin/systemctl"

    # systemctl is available and /sbin/init is a symlink to systemd
    os.symlink("/bin/systemd", "/sbin/init")

    assert ServiceMgrFactCollector.is_systemd_managed_offline(ModuleDummy())

    # systemctl is available and /sbin/init is not a symlink to systemd
    os.unlink("/sbin/init")

    assert not ServiceMgrFactCollector.is_systemd_managed_offline(ModuleDummy())

    # systemctl is not available and /sbin/init is a symlink to systemd

# Generated at 2022-06-25 00:38:37.240429
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Input Params
    module = None
    collected_facts = None

    # Output Params
    results = {
        "service_mgr": "service_mgr_output"
    }

    # Mock Data
    ServiceMgrFactCollector.name = "name"
    ServiceMgrFactCollector._fact_ids = set()
    ServiceMgrFactCollector.required_facts = set(['platform', 'distribution'])

    # Perform the test
    service_mgr_fact_collector = ServiceMgrFactCollector()
    result = service_mgr_fact_collector.collect(module, collected_facts)

    # Verify the results
    assert(result == results)


# Generated at 2022-06-25 00:38:46.290191
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Check different methods for detecting systemd
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Systemd is marked due to /run/systemd/system/
    os.makedirs("/run/systemd/system/")
    assert service_mgr_fact_collector.is_systemd_managed(None) == True

    # Systemd is marked due to /dev/.run/systemd/
    os.rmdir("/run/systemd/system/")
    os.makedirs("/dev/.run/systemd/")
    assert service_mgr_fact_collector.is_systemd_managed(None) == True

    # Systemd is marked due to /dev/.systemd/
    os.rmdir("/dev/.run/systemd/")
    os.makedirs

# Generated at 2022-06-25 00:38:50.127840
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    class Module(object):
        def get_bin_path(self, arg):
            if arg == 'systemctl':
                return '/bin/systemctl'
            return None
    module = Module()
    assert service_mgr_fact_collector_0.is_systemd_managed(module) == False


# Generated at 2022-06-25 00:38:55.264608
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    setattr(service_mgr_fact_collector, 'module', None)
    assert service_mgr_fact_collector.is_systemd_managed()


# Generated at 2022-06-25 00:39:01.405274
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module = AnsibleModuleMock()
    collected_facts = None
    service_mgr_fact_collector_0.collect(module, collected_facts)


# Generated at 2022-06-25 00:39:02.646238
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

# Generated at 2022-06-25 00:39:04.469414
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector_0.is_systemd_managed_offline(module=None)

# Generated at 2022-06-25 00:39:07.663703
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class Module(object):
        def get_bin_path(self, path):
            return ''

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module_0 = Module()
    result_0 = service_mgr_fact_collector_0.is_systemd_managed(module_0)
    assert type(result_0) == bool


# Generated at 2022-06-25 00:39:09.819910
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module=None) == False


# Generated at 2022-06-25 00:40:04.308355
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    # Given
    m = AnsibleModule(argument_spec={})

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.module = m

    # When
    result = service_mgr_fact_collector_0.is_systemd_managed_offline(m)

    # Then
    assert result is None

# Generated at 2022-06-25 00:40:09.799350
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class MockModule():
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, path, opt_dirs=[]):
            if self.params['path'] == path:
                raise OSError
            else:
                return self.params['path']

    # Check that is_systemd_managed_offline returns True if bin path found.
    m = MockModule({'path':'test-systemd-bin-path'})
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=m) == True

    # Check that is_systemd_managed_offline returns False if bin path not found.
    m = MockModule({'path':'test-non-systemd-bin-path'})

# Generated at 2022-06-25 00:40:12.624521
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed() == False


# Generated at 2022-06-25 00:40:16.928436
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    is_systemd_managed = service_mgr_fact_collector.is_systemd_managed(module=None)
    assert is_systemd_managed == False

# Generated at 2022-06-25 00:40:19.276176
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    module = FakeAnsibleModule()
    assert service_mgr_fact_collector_1.is_systemd_managed_offline(module=module) is True


# Generated at 2022-06-25 00:40:22.432545
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # test is_systemd_managed() when procfs is available
    with mock.patch("os.path.exists") as mock_exists:
        mock_exists.return_value = True
        assert service_mgr_fact_collector.is_systemd_managed(mock.Mock()) == True


# Generated at 2022-06-25 00:40:24.099906
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    assert True == service_mgr_fact_collector_0.is_systemd_managed_offline('module')

# Generated at 2022-06-25 00:40:26.236821
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module='module_0') == False



# Generated at 2022-06-25 00:40:32.707705
# Unit test for method collect of class ServiceMgrFactCollector

# Generated at 2022-06-25 00:40:41.307658
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import FakeModule
    service_mgr_fact_collector_test = ServiceMgrFactCollector()
    if platform.system() == 'SunOS':
        fake_module = FakeModule()
        reply = service_mgr_fact_collector_test.is_systemd_managed(fake_module)
        assert reply == False
    elif platform.system() == 'Linux':
        fake_module = FakeModule()
        fake_module.run_command = lambda x, **kwargs: (0, '')
        fake_module.get_bin_path = lambda x: x
        reply = service_mgr_fact_collector_test.is_systemd_managed(fake_module)
        assert reply == False

# Generated at 2022-06-25 00:41:20.691019
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.collect() == {}


# Generated at 2022-06-25 00:41:24.980480
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Assert if the following attributes are correctly initialized. These attributes were
    # initially initialized in ServiceMgrFactCollector inferface.
    assert service_mgr_fact_collector.name == 'service_mgr'
    assert service_mgr_fact_collector._fact_ids == set()
    assert service_mgr_fact_collector.required_facts == set(['platform', 'distribution'])

    # Assert if the method is_systemd_managed has the expected output. This method
    # was initially created in ServiceMgrFactCollector inferface.
    test_value_1 = service_mgr_fact_collector.is_systemd_managed(None)
    assert test_value_1 == False

    # Assert if the method is

# Generated at 2022-06-25 00:41:29.397251
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    # Create the test object.
    test_object = object()

    assert service_mgr_fact_collector_1.is_systemd_managed_offline(test_object) == False


# Generated at 2022-06-25 00:41:33.824584
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.collect() == {}

# Generated at 2022-06-25 00:41:35.694970
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline() == False

# Generated at 2022-06-25 00:41:41.653311
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.collect() == {'service_mgr': 'service'}
    assert service_mgr_fact_collector_0.collect() == {'service_mgr': 'service'}
    assert service_mgr_fact_collector_0.collect() == {'service_mgr': 'service'}

# Generated at 2022-06-25 00:41:47.854010
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test with a module argument that is not None
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.is_systemd_managed(module=None) is False


# Generated at 2022-06-25 00:41:56.944532
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    fixture_0 = ServiceMgrFactCollector()
    result_0 = fixture_0.collect(module=None, collected_facts={u'ansible_distribution': u'MacOSX', u'ansible_system': u'Darwin'})
    assert isinstance(result_0, dict) is True
    assert result_0['service_mgr'] == 'launchd'

    fixture_1 = ServiceMgrFactCollector()
    result_1 = fixture_1.collect(module=None, collected_facts={u'ansible_distribution': u'OpenWrt', u'ansible_system': u'Linux'})
    assert isinstance(result_1, dict) is True
    assert result_1['service_mgr'] == 'openwrt_init'

    fixture_2 = ServiceMgrFactCollector()
    result

# Generated at 2022-06-25 00:42:00.751974
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1 is not None
    assert callable(getattr(service_mgr_fact_collector_1, 'is_systemd_managed', None))

    service_mgr_fact_collector_1.is_systemd_managed()


# Generated at 2022-06-25 00:42:07.403892
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    collected_facts = {'platform': 'Linux', 'ansible_facts': {}, 'distribution': 'Debian'}
    facts_dict = service_mgr_fact_collector.collect(None, collected_facts)
    assert isinstance(facts_dict, dict)
    assert 'service_mgr' in facts_dict
    assert facts_dict['service_mgr'] == 'sysvinit'

# Generated at 2022-06-25 00:43:41.475383
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_2.is_systemd_managed_offline(module = None) == False


# Generated at 2022-06-25 00:43:44.145573
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    systemd_canary = "/dev/.run/systemd/"
    this_module = FakeModule(systemd_canary)
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(this_module) is True


# Generated at 2022-06-25 00:43:47.071940
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = None
    service_mgr_fact_collector = ServiceMgrFactCollector()

    assert service_mgr_fact_collector.is_systemd_managed(module) == False
