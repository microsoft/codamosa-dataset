

# Generated at 2022-06-25 00:34:16.680888
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    collected_facts = {}
    collected_facts['ansible_distribution'] = 'MacOSX'
    collected_facts['platform'] = 'Darwin-16.7.0-x86_64-i386-64bit'
    collected_facts['ansible_system'] = 'Darwin-16.7.0-x86_64-i386-64bit'
    collected_facts['distribution'] = 'MacOSX'
    collected_facts['distribution_version'] = '16.7.0'
    collected_facts['distribution_release'] = 'darwin'
    collected_facts['distribution_major_version'] = '16.7.0'

# Generated at 2022-06-25 00:34:24.447104
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class DummyModule:
        def get_bin_path(self,cmd):
            return True

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    test_cases = [
        {
            'description': 'systemd_managed_offline_valid',
            'expected_result': True,
        },
    ]
    
    dummymodule = DummyModule()
    for test_case_dict in test_cases:
        actual_result = service_mgr_fact_collector_0.is_systemd_managed_offline(dummymodule)
        print(test_case_dict['description'] + ": " + str(actual_result))
        assert test_case_dict['expected_result'] == actual_result


# Generated at 2022-06-25 00:34:27.808204
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    try:
        ServiceMgrFactCollector()
        test_class = ServiceMgrFactCollector()
        test_class.collect()
        assert 1 == 1
    except Exception as Test_Exception:
        print("ERROR: Test_Exception: " + str(Test_Exception))
        assert 1 == 0


# Generated at 2022-06-25 00:34:31.689201
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed() == None


# Generated at 2022-06-25 00:34:38.186557
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    fc = ServiceMgrFactCollector()
    fc.module = FakeModule()
    fc.module.get_bin_path = lambda command: True

    fc.is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed
    fc.is_systemd_managed_offline = ServiceMgrFactCollector.is_systemd_managed_offline
    assert fc.is_systemd_managed_offline(fc.module) == True
    assert fc.is_systemd_managed(fc.module) == True
    assert fc.is_systemd_managed(fc.module) == True


# Generated at 2022-06-25 00:34:41.582451
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(None) == False


# Generated at 2022-06-25 00:34:46.101569
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module=None) == True


# Generated at 2022-06-25 00:34:52.751526
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    class TestModule(object):
        def get_bin_path(self, path):
            return "/bin/systemctl"
    test_module = TestModule()
    assert service_mgr_fact_collector.is_systemd_managed_offline(test_module) == True

# Generated at 2022-06-25 00:34:59.195286
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    service_mgr_fact_collector = ServiceMgrFactCollector()

    assert False == service_mgr_fact_collector.is_systemd_managed(module)

    module.get_bin_path = lambda x: '/bin/systemctl'
    assert False == service_mgr_fact_collector.is_systemd_managed(module)

    os.path.exists = lambda x: True
    assert True == service_mgr_fact_collector.is_systemd_managed(module)

# Generated at 2022-06-25 00:35:02.127798
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed_offline(None) == False

# Generated at 2022-06-25 00:35:33.904741
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.collect()


# Generated at 2022-06-25 00:35:42.567671
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile, shutil
    import ansible.module_utils.facts.system.service_mgr as service_mgr_facts

    temp_dir = tempfile.mkdtemp()
    try:
        os.symlink(os.path.join(temp_dir, 'systemd'), os.path.join(temp_dir, 'sbin', 'init'))
        os.makedirs(os.path.join(temp_dir, 'sbin'))
        assert service_mgr_facts.is_systemd_managed_offline(module=None) == True
    finally:
        shutil.rmtree(temp_dir)



# Generated at 2022-06-25 00:35:45.763159
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False

# Generated at 2022-06-25 00:35:56.446174
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # test case: test_case_0
    # test method: collect
    # test class: ServiceMgrFactCollector
    print("Testing test case: test_case_0")
    # none of the required facts are available
    collected_facts = {}
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    # collect facts
    fact_dict = service_mgr_fact_collector_0.collect(collected_facts=collected_facts)
    # assert "service_mgr" is present
    assert fact_dict and fact_dict.get("service_mgr")

    # test case: test_case_1
    # test method: collect
    # test class: ServiceMgrFactCollector
    print("Testing test case: test_case_1")
    # only "ansible_dist

# Generated at 2022-06-25 00:36:01.121022
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    collected_facts = {}
    fact_collector_instance = ServiceMgrFactCollector()
    fact_collector_instance.collect(collected_facts=collected_facts)
    assert 'service_mgr' in collected_facts


# Generated at 2022-06-25 00:36:06.961937
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import sys
    import tempfile

    temp_dir_name = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp_dir_name, 'run', 'systemd', 'system'))

    sys.modules['ansible.module_utils.facts.collector.ServiceMgrFactCollector'].__dict__['is_systemd_managed'].__dict__['_systemd_canaries'] = {}
    sys.modules['ansible.module_utils.facts.collector.ServiceMgrFactCollector'].__dict__['is_systemd_managed'].__dict__['_systemd_canaries']['_cache'] = {}

# Generated at 2022-06-25 00:36:16.310708
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import __builtin__
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    __builtin__.__dict__['_ansible_check_mode'] = False

    run_paths = ["/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"]
    for path in run_paths:
        # Create a dummy placeholder for the 'canary' we're looking for
        open(path, 'a').close()
        assert service_mgr_fact_collector_1.is_systemd_managed() == True
        os.remove(path)
    assert service_mgr_fact_collector_1.is_systemd_managed() == False


# Generated at 2022-06-25 00:36:21.759628
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    # TODO: define module_mock_args to test the is_systemd_managed method
    is_systemd_managed_expected_result = None
    is_systemd_managed_actual_result = service_mgr_fact_collector_1.is_systemd_managed(module=module_mock_args)
    assert is_systemd_managed_expected_result == is_systemd_managed_actual_result, 'Test failed because expected ' + str(
        is_systemd_managed_expected_result) + ' and got ' + str(is_systemd_managed_actual_result)



# Generated at 2022-06-25 00:36:23.599305
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.collect()

# Generated at 2022-06-25 00:36:31.594193
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts.collector import BaseFactCollector

    # This mocked-out module will allow us to test the is_systemd_managed_offline method
    class TestServiceMgrFactCollector(ServiceMgrFactCollector, BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(TestServiceMgrFactCollector, self).__init__(*args, **kwargs)
            self._module = TestModule()
        def get_file_content(self, filename):
            if filename == '/proc/1/comm':
                return None
            return super(TestServiceMgrFactCollector, self).get_file_content(filename)

    service_mgr_fact_collector_0 = TestService

# Generated at 2022-06-25 00:37:03.131250
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    os.symlink('/bin/systemd', '/sbin/init')

    assert service_mgr_fact_collector_0.is_systemd_managed_offline(None)
    os.remove('/sbin/init')


# Generated at 2022-06-25 00:37:09.713997
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.modules.utilities import set_module_args
    from ansible_collections.ansible.community.tests.unit.modules.utilities import AnsibleExitJson
    from ansible_collections.ansible.community.tests.unit.compat import mock
    import yaml
    import json

    mock_module = mock.MagicMock()
    mock_module.run_command = mock.Mock(return_value=(0, '', 0))
    mock_module.get_bin_path = mock.Mock(return_value=None)
    service_mgr_fact_collector = ServiceMgrFactCollector()
    result = service_mgr_fact_collector.collect(module=mock_module)

# Generated at 2022-06-25 00:37:12.677689
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Empty collect method for ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector() 
    result = service_mgr_fact_collector.collect()
    assert result == {}


# Generated at 2022-06-25 00:37:23.542791
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    try:
        import ansible.module_utils.facts.fact_collector
    except ImportError:
        import ansible.module_utils.facts.collector as fact_collector
    class Module(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, v1):
            return ''
    class ModuleMock(object):
        def __init__(self):
            self.module = Module()
        def run_command(self, v1):
            return 1, '', ''
    module = ModuleMock()
    service_mgr_fact_collector = fact_collector.get_collector('service_mgr')()
    service_mgr_fact_collector.is_systemd_managed_offline(module)

# Generated at 2022-06-25 00:37:25.019414
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.collect()

# Generated at 2022-06-25 00:37:26.507919
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed()


# Generated at 2022-06-25 00:37:29.174199
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.collect()

# Generated at 2022-06-25 00:37:30.793935
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:37:36.635615
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # No bin path for systemctl command if not installed.
    module = FakeModule({"systemctl": None})
    assert service_mgr_fact_collector.is_systemd_managed_offline(module) is False

    # systemctl is installed but no /sbin/init symlink.
    module = FakeModule({"systemctl": "/usr/bin/systemctl"})
    assert service_mgr_fact_collector.is_systemd_managed_offline(module) is False

    # systemctl is installed and /sbin/init is a symlink to systemd but it is not the init process.

# Generated at 2022-06-25 00:37:40.463850
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test data
    module = ''
    class TestModule:
       def get_bin_path(self, s):
           return ''
    result = ServiceMgrFactCollector.is_systemd_managed(TestModule())
    if result is not False:
        raise ValueError('unexpected output: %s' % result)


# Generated at 2022-06-25 00:38:20.137682
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    print("\nStart unit test for method is_systemd_managed of class ServiceMgrFactCollector")

    print("\tUnit test for is_systemd_managed(module=None)")
    is_systemd_managed = service_mgr_fact_collector.is_systemd_managed(None)
    print("\t\t" + str(is_systemd_managed))


# Generated at 2022-06-25 00:38:24.381211
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    collector = ServiceMgrFactCollector()
    assert collector.is_systemd_managed(module) == True

# Generated at 2022-06-25 00:38:33.063724
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    test_cwd = os.path.dirname(os.path.realpath(__file__))
    expected_results = {
        "test_no_systemd_sysvinit_sysvinit": False,
        "test_no_systemd_sysvinit_systemd": False,
        "test_no_systemd_systemd_sysvinit": False,
        "test_no_systemd_systemd_systemd": False,
        "test_systemd_sysvinit_sysvinit": False,
        "test_systemd_sysvinit_systemd": False,
        "test_systemd_systemd_sysvinit": False,
        "test_systemd_systemd_systemd_broken_init": False,
        "test_systemd_systemd_systemd": True,
    }



# Generated at 2022-06-25 00:38:34.877457
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed('MODULE_HERE') == False


# Generated at 2022-06-25 00:38:39.106272
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_facts_result = {
        'service_mgr': 'service'
    }
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.collect() == service_facts_result


# Generated at 2022-06-25 00:38:44.255825
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.required_facts = set(['ansible_distribution'])
    result = service_mgr_fact_collector_1.collect()

    assert result.get('service_mgr') == 'service'
    assert result.get('ansible_distribution') is None

# Generated at 2022-06-25 00:38:51.403303
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    service_mgr_fact_collector = ServiceMgrFactCollector()
    # Create test module object
    test_module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    # Call tested method
    result = service_mgr_fact_collector.is_systemd_managed_offline(test_module)

    assert result == False


# Generated at 2022-06-25 00:39:00.421860
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    class Mock_module_0():

        def get_bin_path(self, arg):
            return 'systemctl'

        def run_command(self, arg, arg2):
            rc_0 = 0
            output_0 = 'init\n'
            err_0 = ''
            return rc_0, output_0, err_0


        # a mock class for ansible module_utils
        class Mock_AnsibleModule_0(object):
            def __init__(self):
                self.params = dict()
                self.exit_json = lambda x: False
                self.fail_json = lambda x: False

    mock_module_0 = Mock_module_0()
    service_mgr_fact_collector_0.collect

# Generated at 2022-06-25 00:39:07.628658
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    class MockModule(object):
        def get_bin_path(self, arg):
            return "/bin/systemctl"
    module = MockModule()
    assert service_mgr_fact_collector_0.is_systemd_managed(module)
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module)


# Generated at 2022-06-25 00:39:10.163539
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    result = service_mgr_fact_collector.is_systemd_managed_offline('ansible')
    assert False == result

test_ServiceMgrFactCollector_is_systemd_managed_offline()

# Generated at 2022-06-25 00:40:47.872387
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Test case 1, check if init is a symlink to systemd
    svc_mgr_fact_col = ServiceMgrFactCollector()
    class ModuleMock:
        def __init__(self, get_bin_path_ret_val):
            self.get_bin_path_ret_val = get_bin_path_ret_val

        def get_bin_path(self, command):
            return self.get_bin_path_ret_val

    moduleMock = ModuleMock("/usr/bin/systemctl")
    assert svc_mgr_fact_col.is_systemd_managed_offline(moduleMock) == False


# Generated at 2022-06-25 00:40:56.628134
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    import ansible.module_utils
    from ansible.module_utils._text import to_native

    import os

    # instantiate a module, set module.run_command to my own defined function
    class TestModule:
        def __init__(self):
            self.params = dict()
            self.debug = False
            self.warnings = list()
            self.fail_json = dict()
            self.run_command = self.my_run_command

    # define faux run_command function

# Generated at 2022-06-25 00:40:58.472662
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    result = service_mgr_fact_collector_0.is_systemd_managed_offline()
    assert result == False

# Generated at 2022-06-25 00:41:05.206787
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    class MockModule(object):
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            return None

    class MockOs(object):
        def path(self, path):
            if path == '/run/systemd/system/':
                return True
            elif path == '/dev/.run/systemd/':
                return False
            elif path == '/dev/.systemd/':
                return False
            else:
                return None

    m = MockModule()
    o = MockOs()
    assert service_mgr_fact_collector.is_systemd_managed(m) == True


# Generated at 2022-06-25 00:41:06.716565
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector.is_systemd_managed_offline(module=None)

# Generated at 2022-06-25 00:41:12.712518
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(None) == False


# Generated at 2022-06-25 00:41:18.713012
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()


# Generated at 2022-06-25 00:41:24.411540
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class StubModule(BaseFactCollector):
        def get_bin_path(self, executable):
            return 'systemctl'

    class StubModuleFalse(BaseFactCollector):
        def get_bin_path(self, executable):
            return None

    class StubModuleLink(BaseFactCollector):
        def get_bin_path(self, executable):
            return 'systemctl'

        def islink(self, path):
            return True

        def readlink(self, path):
            return 'systemd'

    class StubModuleLinkFalse(StubModuleLink):
        def readlink(self, path):
            return 'other'

    assert ServiceMgrFactCollector.is_systemd_managed_offline(StubModule()) is True

# Generated at 2022-06-25 00:41:27.435573
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed(module = None)


# Generated at 2022-06-25 00:41:34.337204
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    os.environ['ANSIBLE_SERVICE_MGR_FACT_COLLECTED_FACTS'] = '{"ansible_distribution": "MacOSX"}'
    service_mgr_fact_collector.collect()
    os.environ['ANSIBLE_SERVICE_MGR_FACT_COLLECTED_FACTS'] = '{"ansible_system": "AIX"}'
    service_mgr_fact_collector.collect()
    os.environ['ANSIBLE_SERVICE_MGR_FACT_COLLECTED_FACTS'] = '{"ansible_system": "SunOS"}'
    service_mgr_fact_collector.collect()

# Generated at 2022-06-25 00:43:15.235136
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Assert that is_systemd_managed returns the correct value
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)

    assert var_0 == False

# Generated at 2022-06-25 00:43:17.298912
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:43:23.211296
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:43:27.241512
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)

# Generated at 2022-06-25 00:43:29.262404
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:43:32.776355
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)
    print(var_0)

# Generated at 2022-06-25 00:43:36.271232
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_manager_fact_collector = ServiceMgrFactCollector()
    var_0 = service_manager_fact_collector.is_systemd_managed_offline(service_manager_fact_collector)


# Generated at 2022-06-25 00:43:38.892392
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # Build necessary mock objects
    class MockModule:
        def get_bin_path(self, name):
            if name == 'systemctl':
                return name

    # Run test case
    test_case_0()


# Generated at 2022-06-25 00:43:42.086041
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)

# Generated at 2022-06-25 00:43:43.997439
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    result_1 = service_mgr_fact_collector_1.collect(service_mgr_fact_collector_1)
