

# Generated at 2022-06-25 00:34:15.912026
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    try:
        ServiceMgrFactCollector.is_systemd_managed_offline(None)
    except Exception as exception:
        assert False, "Failed to get service mgr name for platform on test case: " + str(exception)

# Generated at 2022-06-25 00:34:25.842220
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    def fake_get_bin_path(name):
        if name == 'systemctl':
            return True
        return None

    class FakeModule(object):

        def run_command(self, cmd, use_unsafe_shell):
            if cmd == "systemctl is-system-running":
                return 1, "", None
            elif cmd == "systemctl is-system-running|grep -i running":
                return 0, "running\n", None
            return None

        def get_bin_path(self, name):
            return fake_get_bin_path(name)

    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(FakeModule()) is True


# Generated at 2022-06-25 00:34:27.564965
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline() == False

# Generated at 2022-06-25 00:34:37.381898
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestModule(object):
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            return None

    class MockModule:
        def run_command(self, command, use_unsafe_shell=False):
            return (1, '/usr/lib/systemd/systemd', 'Systemd is present')

    expected_result = False
    test_module = TestModule()
    service_mgr_fact_collector = ServiceMgrFactCollector()
    result = service_mgr_fact_collector.is_systemd_managed_offline(test_module)
    assert result == expected_result



# Generated at 2022-06-25 00:34:42.710371
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    if platform.system() != 'SunOS':
        rc, systemd, err = service_mgr_fact_collector_0.is_systemd_managed()
        if LooseVersion(platform.dist()[1]) >= LooseVersion('7'):
            assert systemd == True
        else:
            assert systemd == False


# Generated at 2022-06-25 00:34:45.834530
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed() != ''


# Generated at 2022-06-25 00:34:52.490706
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Host is using systemd init system
    module = FakeModule({'path': '/bin:/usr/bin'}, 'systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(module)

    # Host is not using systemd init system
    module = FakeModule({'path': '/bin:/usr/bin'}, 'not-systemctl')
    assert not ServiceMgrFactCollector.is_systemd_managed(module)



# Generated at 2022-06-25 00:34:59.450610
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.module.get_bin_path = lambda bin: '/usr/bin/' + bin
    service_mgr_fact_collector.os.path.islink = lambda path: path == '/sbin/init'
    service_mgr_fact_collector.os.path.basename = lambda path: path[:-5]
    service_mgr_fact_collector.os.path.exists = lambda path: False

    assert not service_mgr_fact_collector.is_systemd_managed_offline(service_mgr_fact_collector.module)
    service_mgr_fact_collector.os.readlink = lambda path: 'systemd'
    assert service_mgr_fact_

# Generated at 2022-06-25 00:35:07.493250
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector

# Generated at 2022-06-25 00:35:11.699499
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed(module={'get_bin_path':lambda x:''}) == False
    assert ServiceMgrFactCollector.is_systemd_managed(module={'get_bin_path':lambda x:'systemctl'}) == False

# Generated at 2022-06-25 00:35:23.930394
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    return 'systemd'


# Generated at 2022-06-25 00:35:30.954566
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import platform
    import os

    # Construct a module_mock for testing purposes
    class ModuleMock(object):
        def __init__(self):
            self.platform_version = platform.version()
            self.system = platform.system()
            self.python_version = platform.python_version()
            self.bin_path = "/usr/bin"
            self.run_command_results = []
            self.run_command_results.append(["", "", 0])

        def get_bin_path(self, cmd):
            return "/usr/bin"

        def run_command(self, cmd, check_rc, use_unsafe_shell):
            return self.run_command_results.pop()

    module = ModuleMock()

    # Path is not set.  Should return False
    service_mgr_fact

# Generated at 2022-06-25 00:35:35.171192
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    assert service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0.module) == True


# Generated at 2022-06-25 00:35:37.082893
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.collect()


# Generated at 2022-06-25 00:35:38.124472
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass

# Generated at 2022-06-25 00:35:46.554398
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    class MockModule(object):
        def get_bin_path(self, path):
            return True

    class EmptyMockModule(object):
        def get_bin_path(self, path):
            return None

    class MockOSModule(object):
        def path(self, path):
            return True

    mock_module = MockModule()
    empty_mock_module = EmptyMockModule()
    mock_os = MockOSModule()
    assert service_mgr_fact_collector.is_systemd_managed(mock_module) == False
    assert service_mgr_fact_collector.is_systemd_managed(empty_mock_module) == False
    assert service_mgr_fact_collector.is_systemd_

# Generated at 2022-06-25 00:35:57.086481
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Case 1
    if platform.system() != 'SunOS':
        os.system("ln -s /sbin/init /sbin/systemd")
    assert service_mgr_fact_collector.is_systemd_managed_offline(None) == True
    
    # Case 2
    if platform.system() != 'SunOS':
        os.system("ln -s /sbin/sysvinit /sbin/init")
    assert service_mgr_fact_collector.is_systemd_managed_offline(None) == False

    # Case 3
    if platform.system() != 'SunOS':
        os.system("rm -rf /sbin/init")
    assert service_mgr_fact_collector.is_system

# Generated at 2022-06-25 00:36:00.063029
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    # ServiceMgrFactCollector is a subclass of BaseFactCollector
    # BaseFactCollector is a subclass of object
    instance = ServiceMgrFactCollector()

    assert instance.is_systemd_managed_offline(None) is False
    # TODO: add test for successfull case


# Generated at 2022-06-25 00:36:03.969293
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    class ModuleMock:
        distribution = ''
        ansible_distribution = ''
        ansible_system = ''
        def get_bin_path(self, bin_path):
            return None
        def run_command(self, bin_path, use_unsafe_shell=True):
            return None, None, None

    module = ModuleMock()
    # None
    facts_dict = ServiceMgrFactCollector.collect(module=module)
    assert facts_dict.get('service_mgr') is None

# Generated at 2022-06-25 00:36:07.324731
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    is_systemd_managed_offline = ServiceMgrFactCollector.is_systemd_managed_offline(None)
    assert is_systemd_managed_offline == False

# Generated at 2022-06-25 00:36:27.113904
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-25 00:36:32.923699
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
  assert callable(ServiceMgrFactCollector.is_systemd_managed)
  service_mgr_fact_collector_0 = ServiceMgrFactCollector()
  service_mgr_fact_collector_1 = ServiceMgrFactCollector()
  assert isinstance(service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_0), bool)

# Generated at 2022-06-25 00:36:35.524630
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    fixture = ServiceMgrFactCollector()
    expected = True
    actual = fixture.is_systemd_managed(fixture)
    assert actual == expected


# Generated at 2022-06-25 00:36:38.032407
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.collect() == {}


# Generated at 2022-06-25 00:36:41.854377
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_1)


# Generated at 2022-06-25 00:36:45.731956
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # From Ansible
    def is_systemd_managed(self, module):
        # tools must be installed
        if module.get_bin_path('systemctl'):

            # this should show if systemd is the boot init system, if checking init faild to mark as systemd
            # these mirror systemd's own sd_boot test http://www.freedesktop.org/software/systemd/man/sd_booted.html
            for canary in ["/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"]:
                if os.path.exists(canary):
                    return True
        return False

    service_mgr_fact_collector = ServiceMgrFactCollector()

# Generated at 2022-06-25 00:36:49.244317
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var = service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector)
    assert var is None


# Generated at 2022-06-25 00:36:53.540078
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Setup test environment
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.collect()
    assert service_mgr_fact_collector.collect() is None



# Generated at 2022-06-25 00:36:54.304018
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert True


# Generated at 2022-06-25 00:36:58.494743
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_0)


if __name__ == "__main__":
    test_case_0()
    test_ServiceMgrFactCollector_is_systemd_managed_offline()

# Generated at 2022-06-25 00:37:13.303920
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_1)
    assert var_0 == "service_mgr"


# Generated at 2022-06-25 00:37:18.627250
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    def mock_get_file_content_0(arg):
        # Mock of get_file_content method
        return '/init'

    def mock_get_file_content_1(arg):
        # Mock of get_file_content method
        return 'init'

    def mock_is_systemd_managed_0(arg):
        # Mock of is_systemd_managed method
        return True

    def mock_is_systemd_managed_1(arg):
        # Mock of is_systemd_managed method
        return False

    def mock_is_systemd_managed_offline_0(arg):
        # Mock of is_systemd_managed_offline method
        return 'False'


# Generated at 2022-06-25 00:37:20.743583
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    fact_collector = ServiceMgrFactCollector()
    assert fact_collector.is_systemd_managed_offline(fact_collector) == False


# Generated at 2022-06-25 00:37:25.831506
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Mock object
    module = mock.Mock()
    module.get_bin_path.return_value = "/bin/systemctl"
    module.os.path.exists.return_value = True
    module.os.path.islink.return_value = False

    assert not service_mgr_fact_collector.is_systemd_managed(module)


# Generated at 2022-06-25 00:37:30.690358
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect()


# Generated at 2022-06-25 00:37:33.502551
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    module_mock = Mock()
    assert ServiceMgrFactCollector.is_systemd_managed(module_mock) == service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector, module_mock)


# Generated at 2022-06-25 00:37:38.122306
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.collect()


# Generated at 2022-06-25 00:37:40.994476
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:37:45.152821
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector)



# Generated at 2022-06-25 00:37:47.984914
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.collect()

# Generated at 2022-06-25 00:38:02.721212
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    # print(service_mgr_fact_collector_1)


# Generated at 2022-06-25 00:38:05.430645
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.collect(service_mgr_fact_collector_1)
    assert service_mgr_fact_collector_1.collect(service_mgr_fact_collector_1) == {}


# Generated at 2022-06-25 00:38:09.934118
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:38:14.024750
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module = AnsibleModule()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(module)
    assert var_0 == False


# Generated at 2022-06-25 00:38:20.638956
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    rc, proc_1, err = service_mgr_fact_collector_0.run_command("ls -l /sbin/init", use_unsafe_shell=True)
    var_0 = True if proc_1.find("systemd") != -1 else False
    assert var_0 == service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:38:29.620984
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Test with a real module object
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.module = AnsibleModule(
        argument_spec={
            'systemctl': dict(required=False, type='str'),
        }
    )

    # Test when there is only /sbin/init symlinked to systemd
    service_mgr_fact_collector.module.run_command = MagicMock(return_value=(0, '/sbin/init -> ../lib/systemd/systemd', ''))
    service_mgr_fact_collector.module.get_bin_path = MagicMock(return_value='/bin/systemctl')

# Generated at 2022-06-25 00:38:33.806485
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = ServiceMgrFactCollector.is_systemd_managed_offline(service_mgr_fact_collector_0)

# Generated at 2022-06-25 00:38:39.028194
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert False == service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:38:44.768220
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # unit test for collect
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var = service_mgr_fact_collector.collect(service_mgr_fact_collector)
    assert service_mgr_fact_collector._fact_ids == set(['service_mgr'])
    assert service_mgr_fact_collector.required_facts == set(['platform', 'distribution'])
    assert var == {"service_mgr": "service"}

# Generated at 2022-06-25 00:38:48.446706
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Unit test to test method is_systemd_managed_offline of class ServiceMgrFactCollector
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    str_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:39:29.678144
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    fact_collector_0 = ServiceMgrFactCollector()
    fact_collector_0.collect(fact_collector_0)
    fact_collector_0.collect()

#

# Generated at 2022-06-25 00:39:34.814058
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(None)


# Generated at 2022-06-25 00:39:39.100492
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed()
    assert isinstance(var_0, bool)


# Generated at 2022-06-25 00:39:42.569195
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed()


# Generated at 2022-06-25 00:39:44.210624
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.is_systemd_managed_offline()

# Generated at 2022-06-25 00:39:48.598554
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    if False:
        var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 00:39:52.815300
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(test_ServiceMgrFactCollector_is_systemd_managed_offline), "test_ServiceMgrFactCollector_is_systemd_managed_offline returned False"


# Generated at 2022-06-25 00:39:54.576486
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector)

# Generated at 2022-06-25 00:39:56.412402
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:39:58.758674
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = module_0()
    var_2 = service_mgr_fact_collector_0.is_systemd_managed_offline(var_1)
    assert var_2 == False


# Generated at 2022-06-25 00:40:43.308197
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    serviceMgrFactCollector = ServiceMgrFactCollector()
    assert serviceMgrFactCollector.is_systemd_managed_offline() is None

if __name__ == "__main__":
    test_case_0()
    test_ServiceMgrFactCollector_is_systemd_managed_offline()

# Generated at 2022-06-25 00:40:48.126340
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var = service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector)


# Generated at 2022-06-25 00:40:50.186351
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    ServiceMgrFactCollector_instance_0 = ServiceMgrFactCollector()
    if (True):
        var_0 = ServiceMgrFactCollector_instance_0.is_systemd_managed(None)
    if (True):
        var_0 = ServiceMgrFactCollector_instance_0.is_systemd_managed(None)


# Generated at 2022-06-25 00:40:54.410948
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_1)


# Generated at 2022-06-25 00:41:00.029095
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module_0 = ""
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(module_0)


# Generated at 2022-06-25 00:41:05.481991
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os

    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
        assert service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1) == True
    else:
        assert service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1) == False

if __name__ == '__main__':
    test_case_0()
    test_ServiceMgrFactCollector_is_systemd_managed_offline()

# Generated at 2022-06-25 00:41:08.735663
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:41:12.096968
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    pass


# Generated at 2022-06-25 00:41:18.431295
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.is_systemd_managed_offline(None)


# Generated at 2022-06-25 00:41:21.297995
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # service_mgr_fact_collector_1 is ServiceMgrFactCollector
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    # var_1 is ServiceMgrFactCollector
    var_1 = service_mgr_fact_collector_1.collect()
    assert isinstance(var_1, dict)


# Generated at 2022-06-25 00:42:39.451340
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline() == None

# Generated at 2022-06-25 00:42:46.661079
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = os.path.exists("/run/systemd/system/")
    var_1 = os.path.exists("/dev/.run/systemd/")
    var_2 = os.path.exists("/dev/.systemd/")
    var_3 = os.path.exists("/run/initctl")
    var_4 = os.path.exists("/dev/initctl")
    var_5 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:42:49.295485
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:42:53.578298
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector is not None


# Generated at 2022-06-25 00:42:55.634160
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed(module=None)


# Generated at 2022-06-25 00:42:59.862113
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    var_1 = ServiceMgrFactCollector()
    var_2 = var_1.collect(var_1)
    var_1.required_facts = ServiceMgrFactCollector.required_facts
    var_1.name = ServiceMgrFactCollector.name
    var_3 = var_1.collect(var_1)
    assert var_3 == var_2


# Generated at 2022-06-25 00:43:03.934197
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:43:05.907866
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test with valid parameters
    try:
        ServiceMgrFactCollector.is_systemd_managed(
            (ServiceMgrFactCollector(),)
            )
    # Test with invalid parameters
    except TypeError as e:
        print('Caught exception: {}'.format(e))


# Generated at 2022-06-25 00:43:09.212215
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:43:14.049894
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)
