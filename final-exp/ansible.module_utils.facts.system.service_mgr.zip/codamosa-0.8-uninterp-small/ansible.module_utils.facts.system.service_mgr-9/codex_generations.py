

# Generated at 2022-06-25 00:34:12.206459
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    collected_facts = {
                         "ansible_distribution": "MacOSX",
                         "ansible_system": "Darwin",
                         "ansible_lsb": {
                                           "distcodename": "mountainlion",
                                           "distdescription": "Mac OS X 10.8.5",
                                           "distid": "MacOSX",
                                           "distrelease": "10.8.5",
                                           "distmajorrelease": "10",
                                           "majdistrelease": "10",
                                           "minordistrelease": "8"
                                         }
                     }

    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

# Generated at 2022-06-25 00:34:15.043619
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=object) == False

# Generated at 2022-06-25 00:34:19.032208
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    out_0 = service_mgr_fact_collector.is_systemd_managed()
    # print(out_0)


# Generated at 2022-06-25 00:34:23.388907
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Test with a mocked module
    module = MagicMock()
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    # Check the return value of method is_systemd_managed_offline
    # for the value of argument == 'module'
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module=module) == False



# Generated at 2022-06-25 00:34:27.029567
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    # var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline()
    # print(var_0)
    pass


# Generated at 2022-06-25 00:34:37.589746
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    # Setup state of test.
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module_0 = mock.Mock()
    service_mgr_fact_collector_0.module = module_0
    fake_dir_path_0 = tempfile.mkdtemp()
    os.symlink('/bin/systemd', fake_dir_path_0 + '/sbin/init')

    # Invoke the service_mgr_fact_collector_0.is_systemd_managed_offline with arguments.
    # This call should return a boolean value.
    is_systemd_managed_offline_retval = service_mgr_fact_collector_0.is_systemd_managed_offline(module=module_0)

    # Test assert
    assert is_systemd

# Generated at 2022-06-25 00:34:41.850844
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    class module3():
        def run_command(self, param1, param2):
            if param1 == 'ps -p 1 -o comm|tail -n 1':
                return 0, 'init', ''
            return 0, '', ''
        def get_bin_path(self, param1):
            if param1 == 'systemctl':
                return '/bin/systemctl'
            return ''

    var_0 = service_mgr_fact_collector_0.collect(module3())
    assert var_0 == {'service_mgr': 'init'}
    var_1 = service_mgr_fact_collector_0.collect(module3())
    assert var_1 == {'service_mgr': 'init'}



# Generated at 2022-06-25 00:34:45.387231
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    arg0 = ServiceMgrFactCollector()
    try:
        arg0.is_systemd_managed()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 00:34:48.530401
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-25 00:34:53.787341
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = object()
    assert service_mgr_fact_collector.is_systemd_managed(module) == False


# Generated at 2022-06-25 00:35:11.178992
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector) == 'systemd'


# Generated at 2022-06-25 00:35:13.314664
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline()


# Generated at 2022-06-25 00:35:15.248408
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(None) == False


# Generated at 2022-06-25 00:35:17.613843
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = ServiceMgrFactCollector.is_systemd_managed(service_mgr_fact_collector_0)
    assert var_0 == False


# Generated at 2022-06-25 00:35:22.489313
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.is_systemd_managed_offline(None)


# Generated at 2022-06-25 00:35:30.176046
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Setup mock module
    class Mock_module:
        @staticmethod
        def run_command(command, check_rc=False, use_unsafe_shell=False):
            return 0, "", ""
        @staticmethod
        def get_bin_path(program):
            return ""

    mock_module_0 = Mock_module()
    mock_module_1 = Mock_module()
    mock_module_2 = Mock_module()
    mock_module_3 = Mock_module()
    mock_module_4 = Mock_module()

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    var_1 = service_mgr_fact_collector_0.is_systemd_managed_offline(mock_module_0)
    assert var_1 == False

    service_mgr

# Generated at 2022-06-25 00:35:36.235233
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    input_0 = {'platform': 'Linux', 'ansible_distribution': 'CentOS'}
    expected_output_0 = {'service_mgr': 'sysvinit'}

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    output_0 = service_mgr_fact_collector_0.collect(input_0)
    assert output_0 == expected_output_0

# Generated at 2022-06-25 00:35:39.839545
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var = service_mgr_fact_collector.is_systemd_managed()


# Generated at 2022-06-25 00:35:42.080534
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.collect(service_mgr_fact_collector) == {}

# Generated at 2022-06-25 00:35:47.356410
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    mock_module = Mock()
    var_0 = ServiceMgrFactCollector.is_systemd_managed(mock_module)
    assert var_0 == True



# Generated at 2022-06-25 00:36:23.955090
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.is_systemd_managed() == None


# Generated at 2022-06-25 00:36:25.929626
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1)


# Generated at 2022-06-25 00:36:27.809726
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    module_0 = object()
    var_0 = service_mgr_fact_collector.is_systemd_managed(module_0)


# Generated at 2022-06-25 00:36:33.831382
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Mock the object
    from ansible.module_utils import basic
    module_mock = basic.AnsibleModule(
        argument_spec = dict()
    )
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    # Check whether is_systemd_managed() returns correct result for valid input
    service_mgr_fact_collector_0.is_systemd_managed(module_mock)


# Generated at 2022-06-25 00:36:38.032692
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    assert service_mgr_fact_collector.is_systemd_managed(module=module) == expected


# Generated at 2022-06-25 00:36:45.686528
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    systemd_managed_0 = ServiceMgrFactCollector.is_systemd_managed("module_0")
    systemd_managed_1 = ServiceMgrFactCollector.is_systemd_managed("module_1")
    if (systemd_managed_0 != systemd_managed_1):
        print("False")
        print("True")
    elif (systemd_managed_1 == systemd_managed_0):
        print("True")
        print("False")
    else:
        print("False")
        print("False")


# Generated at 2022-06-25 00:36:50.779291
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    try:
        import ansible.module_utils.facts.system.service_mgr.test_mock_ansible_module_is_systemd_managed as mockModule
    except ImportError:
        pass

    module = mockModule.MockAnsibleModule()
    service_mgr_fact_collector_0.is_systemd_managed(module)


# Generated at 2022-06-25 00:36:52.780671
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    method_var_0 = ServiceMgrFactCollector.is_systemd_managed()
    assert type(method_var_0) is bool


# Generated at 2022-06-25 00:36:56.448844
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    from ansible.module_utils.basic import AnsibleModule
    # FIXME: add tests
    module_0 = AnsibleModule(
        argument_spec = dict()
    )
    assert service_mgr_fact_collector_0.is_systemd_managed(module_0) == False


# Generated at 2022-06-25 00:36:57.173239
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:38:03.019133
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(None) is None


# Generated at 2022-06-25 00:38:09.625899
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)
    if 'service_mgr' in var_0:
        assert 1
    else:
        assert 0


# Generated at 2022-06-25 00:38:10.657220
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # TODO: test value of var_0
    assert True == True


# Generated at 2022-06-25 00:38:13.995631
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    bool_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)
    assert bool_0 == False


# Generated at 2022-06-25 00:38:18.305528
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.is_systemd_managed(None) == False

# Generated at 2022-06-25 00:38:22.110357
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module_0 = AnsibleCoreCI()
    service_mgr_fact_collector_0.is_systemd_managed_offline(module_0)

# Generated at 2022-06-25 00:38:23.759072
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:38:28.139164
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:38:30.913894
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed() == None


# Generated at 2022-06-25 00:38:32.992178
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    mock_module = MockModule()
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed_offline(mock_module)


# Generated at 2022-06-25 00:41:08.442459
# Unit test for method collect of class ServiceMgrFactCollector

# Generated at 2022-06-25 00:41:10.301358
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:41:15.523896
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    test_module_1 = None
    if service_mgr_fact_collector_1.is_systemd_managed_offline(test_module_1):
        print('ServiceMgrFactCollector.is_systemd_managed_offline: 1')
    else:
        print('ServiceMgrFactCollector.is_systemd_managed_offline: 0')


# Generated at 2022-06-25 00:41:18.220143
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert service_mgr_fact_collector.is_systemd_managed('any_value') == 'any_value'


# Generated at 2022-06-25 00:41:20.719171
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)
    # assert var_0 == (expected value)


# Generated at 2022-06-25 00:41:23.104570
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    collector_data_dict_0 = { 'ansible_distribution': 'MacOSX', 'ansible_system': 'Darwin' }

    var_0 = service_mgr_fact_collector_1.collect(module=collector_data_dict_0, collected_facts=None)


# Generated at 2022-06-25 00:41:32.263524
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    class MockModule(object):
        def __init__(self, return_value_0, return_value_1):
            self.return_value_0 = return_value_0
            self.return_value_1 = return_value_1

        def get_bin_path(self, args):
            if args == "systemctl":
                return self.return_value_0
            return self.return_value_1

    service_mgr_fact_collector_1.required_facts.add('module')

    # Create a mock_module
    var_0 = MockModule('/usr/bin/systemctl', None)
    var_1 = MockModule(None, None)

# Generated at 2022-06-25 00:41:32.949367
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    assert isinstance(collect(), dict)


# Generated at 2022-06-25 00:41:35.057351
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector) == True


# Generated at 2022-06-25 00:41:39.975524
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed(module=None) == False

