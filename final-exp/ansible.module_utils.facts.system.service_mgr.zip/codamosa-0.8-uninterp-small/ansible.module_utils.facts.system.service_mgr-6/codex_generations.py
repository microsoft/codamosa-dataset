

# Generated at 2022-06-25 00:34:06.549749
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

# Generated at 2022-06-25 00:34:11.675097
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    # test method with mock
    module = MockModule({'_ansible_version': '2.8.0dev0', '_ansible_sysv_module': True, '_ansible_sysv_module': False})

    service_mgr_fact_collector_0.is_systemd_managed_offline(module)

# Generated at 2022-06-25 00:34:14.875471
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    test_class_0 = ServiceMgrFactCollector()
    test_class_0.is_systemd_managed_offline(module=None)

# Generated at 2022-06-25 00:34:23.380615
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class Module(object):
        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return None

    class CollectedFacts(object):
        def __init__(self):
            self.ansible_os_family = 'Linux'

    collected_facts = CollectedFacts()

    def os_path_islink(path):
        return False

    def os_path_exists(path):
        return True

    def os_readlink(path):
        return 'systemd'

    class TestServiceMgrFactCollector(ServiceMgrFactCollector):
        def __init__(self):
            pass

    test_service_mgr_fact_collector = TestServiceMgrFactCollector()

# Generated at 2022-06-25 00:34:30.412473
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # genarating collector
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # genarating fake module
    class FakeModule:
        def get_bin_path(self,key):
            if key == 'systemctl':
                return os.path.exists('/bin/systemctl')
            else:
                return os.path.exists(key)
    fake_module = FakeModule()
    # creating files and folder for testing
    file_paths = [
        '/run/systemd/system/',
        '/dev/.run/systemd/',
        '/dev/.systemd/',
        '/bin/systemctl'
    ]

# Generated at 2022-06-25 00:34:39.606376
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule:
        def get_bin_path(self, param):
            if param == 'systemctl':
                return 'systemctl'

    def is_systemd_managed_offline(module):
        return ServiceMgrFactCollector.is_systemd_managed_offline(module)

    # Test 'is_systemd_managed_offline' when /sbin/init is a symlink to systemd
    module = FakeModule()
    assert is_systemd_managed_offline(module)

    # Test 'is_systemd_managed_offline' when /sbin/init is not a symlink to systemd
    try:
        os.unlink('/sbin/init')
    except:
        pass
    assert not is_

# Generated at 2022-06-25 00:34:41.260261
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    z = ServiceMgrFactCollector()

    if os.path.islink('/sbin/init'):
        assert z.is_systemd_managed_offline(None) == True


# Generated at 2022-06-25 00:34:47.511149
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    ansible_module_0 = AnsibleModule(
        argument_spec={})
    ansible_module_0.exit_json(**service_mgr_fact_collector_0.collect(module=ansible_module_0))


# Generated at 2022-06-25 00:34:50.961844
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    collected_facts = {'ansible_distribution': 'MacOSX'}

    service_mgr_fact_collector_0.collect(collected_facts)


# Generated at 2022-06-25 00:34:57.206008
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    class mocked_module(object):
        @staticmethod
        def get_bin_path(binary):
            return "/usr/bin/systemctl"

        @staticmethod
        def run_command(cmd, use_unsafe_shell):
            return (0, "test is_systemd_managed", "")

    mocked_module_obj = mocked_module()
    if not service_mgr_fact_collector.is_systemd_managed(mocked_module_obj):
        raise AssertionError()


# Generated at 2022-06-25 00:35:12.210370
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed(module) == is_systemd_managed(module)

# Generated at 2022-06-25 00:35:18.145605
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create class instance
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    # Test is_systemd_managed method
    assert service_mgr_fact_collector_1.is_systemd_managed(None) == False

# Generated at 2022-06-25 00:35:22.854712
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed_offline("") == False



# Generated at 2022-06-25 00:35:27.561631
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test case 0:
    # Test if systemd is the boot init system
    test_platform = 'Linux'
    test_distribution = 'Debian'
    mock_module = MockModule('Debian', 'Linux')
    mock_module.add_bin_path('systemctl', '/usr/bin/systemctl')
    assert ServiceMgrFactCollector.is_systemd_managed(mock_module)


# Generated at 2022-06-25 00:35:34.727200
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    test_case = {
        "run_command_data": {
            "/sbin/init": None,
        }
    }

    if os.path.exists('/sbin/init'):
        test_case["run_command_data"]["/sbin/init"] = os.readlink('/sbin/init')

    module = MockModule(run_command_return_values=test_case["run_command_data"])

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed_offline(module)


# Generated at 2022-06-25 00:35:38.209945
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.collect()

# Generated at 2022-06-25 00:35:41.221513
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    res = service_mgr_fact_collector_0.is_systemd_managed(module)
    assert(res == False)


# Generated at 2022-06-25 00:35:45.595738
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.set_module(AN_ANSIBLE_MODULE_MOCK)
    status = service_mgr_fact_collector_0.is_systemd_managed_offline(AN_ANSIBLE_MODULE_MOCK)
    assert status == False


# Generated at 2022-06-25 00:35:49.653519
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Test case 0
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    result_0 = service_mgr_fact_collector_0.collect()

    passed_0 = False
    if 'service_mgr' in result_0.keys():
        passed_0 = True
    passed_0 = True

    return [passed_0]

print(test_ServiceMgrFactCollector_collect())

# Generated at 2022-06-25 00:35:58.375016
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.system.service_mgr

    service_mgr_fact_collector_0 = ansible.module_utils.facts.system.service_mgr.ServiceMgrFactCollector()

    class AnsibleModuleMock(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, name):
            if name == "systemctl":
                return "/sbin/systemctl"
            elif name == "initctl":
                return "/sbin/initctl"

    class AnsibleModuleMockFailed(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, name):
            if name == "systemctl":
                return

# Generated at 2022-06-25 00:36:20.634791
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class MockModule(object):
        def __init__(self, l=None, i=None):
            self.lines = l
            self.indent = i
            self.executed_commands=[]

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return '/bin/%s' % name

        def run_command(self, name, args):
            return (0, self.lines, '')

#   Legal arguments for run_command

# Generated at 2022-06-25 00:36:23.779208
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0_collect = service_mgr_fact_collector_0.collect()
    print("service_mgr_fact_collector_0_collect = ", service_mgr_fact_collector_0_collect)



# Generated at 2022-06-25 00:36:31.322789
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Arrange
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        check_invalid_arguments=False,
        bypass_checks=True
    )

    module_get_bin_path_mock = lambda self, executable: '/bin/systemctl' if executable == 'systemctl' else None
    setattr(module, 'get_bin_path', module_get_bin_path_mock)

    # Act
    service_mgr_fact_collector.collect(module=module)


# Generated at 2022-06-25 00:36:36.707165
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    #  Initialisation
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    #  Test property is_systemd_managed
    assert isinstance(ServiceMgrFactCollector.is_systemd_managed(service_mgr_fact_collector_1), bool)


# Generated at 2022-06-25 00:36:41.143401
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr = ServiceMgrFactCollector()
    class dummy_module(object):

        @staticmethod
        def get_bin_path(command):
            command = "systemctl"
            return command

    fact_collector_result = service_mgr.is_systemd_managed_offline(dummy_module)
    assert fact_collector_result == True

# Generated at 2022-06-25 00:36:45.206396
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class ModuleStub:
        def get_bin_path (self, program):
            return '/usr/bin/systemctl'

    service_mgr_fact_collector = ServiceMgrFactCollector()
    module_stub = ModuleStub()

    assert service_mgr_fact_collector.is_systemd_managed_offline(module_stub) is True


# Generated at 2022-06-25 00:36:50.095403
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # When the service manager can be detected
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    class TestModule():
        def get_bin_path(self, command):
            return "/bin/systemctl"
    dummy_module = TestModule()
    assert service_mgr_fact_collector_0.is_systemd_managed(dummy_module) == True


# Generated at 2022-06-25 00:36:52.443368
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # true
    assert service_mgr_fact_collector.is_systemd_managed(module=None) == True


# Generated at 2022-06-25 00:36:55.912021
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    class ModuleStub:
        def get_bin_path(self, value):
            return '/bin/systemctl'
    module_stub = ModuleStub()

    assert service_mgr_fact_collector.is_systemd_managed_offline(module_stub)


# Generated at 2022-06-25 00:36:58.662794
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert(service_mgr_fact_collector_1.is_systemd_managed("systemctl") == True)


# Generated at 2022-06-25 00:37:17.287264
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    test_cases = [None]
    result = service_mgr_fact_collector.is_systemd_managed_offline(test_cases)
    assert  result == None


# Generated at 2022-06-25 00:37:21.646577
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)

test_case_0()

test_ServiceMgrFactCollector_is_systemd_managed_offline()

# Generated at 2022-06-25 00:37:23.428727
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    pass


# Generated at 2022-06-25 00:37:25.165349
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.collect() == {}


# Generated at 2022-06-25 00:37:28.808834
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.collect(service_mgr_fact_collector_1) == {'service_mgr': 'sysvinit'}


# Generated at 2022-06-25 00:37:33.986330
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = ansible.module_utils.basic.AnsibleModule()
    assert service_mgr_fact_collector.is_systemd_managed(module) == True


# Generated at 2022-06-25 00:37:38.457096
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed()


# Generated at 2022-06-25 00:37:40.520425
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = 1
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_1.is_systemd_managed(module)


# Generated at 2022-06-25 00:37:43.736059
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:37:47.877121
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline() == False


# Generated at 2022-06-25 00:38:19.517217
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    try:
        var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)
    except:
        var_0 = None
    assert var_0 is None


# Generated at 2022-06-25 00:38:23.197748
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    if ServiceMgrFactCollector.is_systemd_managed('module'):
        print("Success: test_ServiceMgrFactCollector_is_systemd_managed")
    else:
        print("Failure: test_ServiceMgrFactCollector_is_systemd_managed")


# Generated at 2022-06-25 00:38:28.829595
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """Function to test is_systemd_managed_offline function of class ServiceMgrFactCollector"""
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.is_systemd_managed_offline() == None, "Test case failed"


# Generated at 2022-06-25 00:38:32.894083
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    test_case_0()


# Generated at 2022-06-25 00:38:34.528642
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Start method call
    service_mgr_fact_collector.collect(service_mgr_fact_collector)

# Generated at 2022-06-25 00:38:39.396989
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.collect(service_mgr_fact_collector_1)
    assert var_1['service_mgr'] == 'systemd'


# Generated at 2022-06-25 00:38:43.294496
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:38:46.140562
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = False
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:38:47.838160
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    var_0 = ServiceMgrFactCollector()
    print(var_0.is_systemd_managed())


# Generated at 2022-06-25 00:38:49.676743
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(None)


# Generated at 2022-06-25 00:40:16.958796
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:40:22.827071
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    category_type_store_0 = ['__doc__', '__module__', 'name', 'collect', '_fact_ids', 'required_facts', '_fact_id_cache']
    __builtin__.__dict__.update(dict(
        zip(category_type_store_0, [None, None, None, None, None, None, None])
    ))

    import ansible.module_utils.facts.utils
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.functional import module_run_cli
    from ansible.module_utils.facts import collector

    class module_run_cli_0(object):
        def run_command(self, arg_0):
            return True, 'init', None


# Generated at 2022-06-25 00:40:25.124350
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    
    # Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    
    assert not service_mgr_fact_collector_0.is_systemd_managed_offline(None)
    


# Generated at 2022-06-25 00:40:26.774109
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed_offline(service_mgr_fact_collector) == False

# Generated at 2022-06-25 00:40:28.811617
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Initialize class
    testClass = ServiceMgrFactCollector()

    # Variable to store result of the method
    result = testClass.collect()

    # Check if the result is of the expected type
    assert not isinstance(result, str)


# Generated at 2022-06-25 00:40:34.736055
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.is_systemd_managed(None)


# Generated at 2022-06-25 00:40:37.253144
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var = service_mgr_fact_collector.is_systemd_managed_offline()


# Generated at 2022-06-25 00:40:42.675357
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline() == False


# Generated at 2022-06-25 00:40:50.991462
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    if platform.system() == 'Linux':
        # Set args
        from ansible.module_utils.facts import Module
        module = Module()
        var_0 = ServiceMgrFactCollector.is_systemd_managed(module)
        # Return type is <type 'bool'>
        assert var_0 is True or var_0 is False
    elif platform.system() == 'Darwin':
        # Set args
        from ansible.module_utils.facts import Module
        module = Module()
        var_0 = ServiceMgrFactCollector.is_systemd_managed(module)
        # Return type is <type 'bool'>
        assert var_0 is True or var_0 is False

# Generated at 2022-06-25 00:40:55.099072
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)

# Generated at 2022-06-25 00:43:44.821455
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # arange
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()
    service_mgr_fact_collector_3 = ServiceMgrFactCollector()
    service_mgr_fact_collector_4 = ServiceMgrFactCollector()
    service_mgr_fact_collector_5 = ServiceMgrFactCollector()
    service_mgr_fact_collector_6 = ServiceMgrFactCollector()
    service_mgr_fact_collector_7 = ServiceMgrFactCollector()
    service_mgr_fact_collector_8 = ServiceMgrFactCollector()
    service_mgr_fact

# Generated at 2022-06-25 00:43:46.638584
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    cfg = ServiceMgrFactCollector()
    val = cfg.is_systemd_managed()
    assert val


# Generated at 2022-06-25 00:43:49.079951
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline()

    assert var_0 in ('true', 'false')
