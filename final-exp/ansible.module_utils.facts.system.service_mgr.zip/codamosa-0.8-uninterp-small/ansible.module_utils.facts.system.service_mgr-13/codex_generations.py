

# Generated at 2022-06-25 00:34:10.855224
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    setattr(platform, 'system', lambda: 'Linux')
    setattr(os, 'path', os)
    setattr(os, 'readlink', lambda _: '/bin/systemd')
    setattr(os.path, 'exists', lambda _: True)
    setattr(os.path, 'islink', lambda _: True)
    f_module = ansible.module_utils.facts.module_facts.ModuleFacts()
    assert(ServiceMgrFactCollector.is_systemd_managed_offline(f_module))


# Generated at 2022-06-25 00:34:16.438340
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector_collect = service_mgr_fact_collector.collect()
    print(service_mgr_fact_collector_collect)

# Unit test 2 for method collect of class ServiceMgrFactCollector

# Generated at 2022-06-25 00:34:18.875156
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test_is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed
    assert test_is_systemd_managed is not None
    assert not test_is_systemd_managed

# Generated at 2022-06-25 00:34:22.777954
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    ansible_facts = {'distribution': 'OpenWrt', 'system': 'Linux'}
    result = service_mgr_fact_collector.collect(collected_facts=ansible_facts)
    assert result == {'service_mgr': 'openwrt_init'}, result

# Generated at 2022-06-25 00:34:30.104199
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    class MockModule(object):
        def __init__(self, use_unsafe_shell, bin_path):
            self.use_unsafe_shell = use_unsafe_shell
            self.bin_path = bin_path
        def get_bin_path(self, command):
            return self.bin_path
        def run_command(self, command, use_unsafe_shell):
            return self.use_unsafe_shell

    assert service_mgr_fact_collector_1.collect(MockModule(False, '')) == {'service_mgr': 'service'}

# Generated at 2022-06-25 00:34:35.093503
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # do not run the test on Solaris
    if platform.system() != 'SunOS':
        service_mgr_fact_collector = ServiceMgrFactCollector()
        # run the test
        res = service_mgr_fact_collector.is_systemd_managed(module=None)
        assert type(res) is bool


# Generated at 2022-06-25 00:34:43.291165
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test_cases = [
        {
            'systemd_canaries': [
                '/run/systemd/system/',
                '/dev/.run/systemd/',
                '/dev/.systemd/'
            ],
            'expected': True
        },
        {
            'systemd_canaries': [
                '/run/systemd/system/',
                '/dev/.run/systemd/'
            ],
            'expected': False
        },
        {
            'systemd_canaries': [],
            'expected': False
        }
    ]
    service_mgr_fact_collector = ServiceMgrFactCollector()
    for test_case in test_cases:
        canaries = test_case['systemd_canaries']
        expected = test_case['expected']

# Generated at 2022-06-25 00:34:53.292679
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    fake_module = Mock()
    fake_module.run_command.return_value = (0, 'procd', '')
    fake_module.get_bin_path.return_value = 'systemctl'
    fake_module.get_bin_path.return_value = ''
    fake_module.os.path.exists.return_value = True
    fake_facts = {
            'platform': 'Linux',
            'distribution': 'OpenWrt',
            'ansible_distribution': 'openwrt',
            'ansible_system': 'Linux',
            'ansible_pkg_mgr': 'opkg'
            }
    service_mgr_fact_collector = ServiceMgrFactCollector()

# Generated at 2022-06-25 00:35:01.761994
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    # Mocking module to return a custom command output
    class MockModule(object):
        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/sbin/systemctl'
            return None
        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, "systemd", ""
    module_0 = MockModule()
    res = service_mgr_fact_collector_0.is_systemd_managed(module_0)
    assert res is True


# Generated at 2022-06-25 00:35:10.230091
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    if platform.system() != 'SunOS':
        import sys
        import tempfile

        from ansible.module_utils.common.file import is_executable
        from ansible.module_utils.common.systemd import is_running, get_systemd_version

        systemctl_path = is_executable('/bin/systemctl') or is_executable('/usr/bin/systemctl')

# Generated at 2022-06-25 00:35:26.020591
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    class ModuleMock(object):
        def get_bin_path(self, path):
            return 'systemctl'
    module = ModuleMock()
    assert True == service_mgr_fact_collector.is_systemd_managed_offline(module)
    module = ModuleMock()
    assert False == service_mgr_fact_collector.is_systemd_managed_offline(module)

# Generated at 2022-06-25 00:35:31.017470
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    ServiceMgrFactCollector_is_systemd_managed_0 = ServiceMgrFactCollector()
    ServiceMgrFactCollector_is_systemd_managed_1 = ServiceMgrFactCollector()
    # TODO: Construct a mock ansible module


# Generated at 2022-06-25 00:35:34.593342
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.is_systemd_managed("") == False


# Generated at 2022-06-25 00:35:43.344740
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # Create an instance of class ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # In case of system is Linux
    if platform.system() == 'Linux':
        # Get the service_mgr details of the system
        result = service_mgr_fact_collector.collect()

        # Verify we get desired result
        assert (result["service_mgr"] == "systemd") or (result["service_mgr"] == "upstart") \
            or (result["service_mgr"] == "openrc") or (result["service_mgr"] == "sysvinit")

    # In case of the system is Windows
    elif platform.system() == 'Windows':
        # Get the service_mgr details of the system
        result = service_mgr_fact_collector

# Generated at 2022-06-25 00:35:48.330784
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    fact_collector = ServiceMgrFactCollector()
    facts_dict = fact_collector.collect()
    print("Facts ")
    print(facts_dict)


if __name__ == '__main__':
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-25 00:35:53.152013
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Set up
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Arrange
    def is_linked_to_systemd (path_to_file):
        os.symlink('/lib/systemd/systemd', path_to_file)

    # Assert
    # TODO: Add coverage for else branch, 'boot_id' branch and 'init_path' branch
    assert service_mgr_fact_collector.is_systemd_managed_offline(is_linked_to_systemd)

# Generated at 2022-06-25 00:36:00.568583
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    ServiceMgrFactCollector.is_systemd_managed(SystemModuleUtilsMock(cmd_rc=0, cmd_stdout='', cmd_stderr=''))
    ServiceMgrFactCollector.is_systemd_managed(SystemModuleUtilsMock(cmd_rc=0, cmd_stdout='abc', cmd_stderr=''))
    ServiceMgrFactCollector.is_systemd_managed(SystemModuleUtilsMock(cmd_rc=0, cmd_stdout='systemd', cmd_stderr=''))
    ServiceMgrFactCollector.is_systemd_managed(SystemModuleUtilsMock(cmd_rc=0, cmd_stdout='runit', cmd_stderr=''))

# Generated at 2022-06-25 00:36:06.236482
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test cases
    test_cases = [
        (None, False),
        ('/usr/bin/systemctl', False),
        ('/usr/bin/systemctl', True),
        ('/usr/bin/systemctl', True),
        ('/usr/bin/systemctl', False)
    ]

    for count in range(len(test_cases)):
        bin_path, systemd_present = test_cases[count]
        service_mgr_fact_collector = ServiceMgrFactCollector()
        from ansible.module_utils.common.collections import ImmutableDict

        facts = ImmutableDict({'ansible_system': 'Linux'})
        assert service_mgr_fact_collector.is_systemd_managed(
                module=MockModule(bin_path, facts)) == systemd_present



# Generated at 2022-06-25 00:36:16.856812
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    # Test with default parameters
    ServiceMgrFactCollector.is_systemd_managed_offline.__dict__['__globals__']['os'] = fake_os_0()
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector_0.is_systemd_managed_offline({'get_bin_path': lambda x: 'fake_bin_path', 'run_command': lambda x, y: 'fake_command'})
    assert not service_mgr_fact_collector_0.is_systemd_managed_offline({'get_bin_path': lambda x: None, 'run_command': lambda x, y: 'fake_command'})
    assert service_mgr_fact_collector_0.is_systemd

# Generated at 2022-06-25 00:36:23.402857
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    temp_facts_dict = {}
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.required_facts = set(['ansible_distribution'])
    temp_facts_dict['ansible_distribution'] = 'OpenWrt'
    result_1 = service_mgr_fact_collector_1.collect(collected_facts=temp_facts_dict)
    assert 'service_mgr' in result_1
    assert isinstance(result_1['service_mgr'], str)
    assert 'openwrt_init' == result_1['service_mgr']
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()
    service_mgr_fact_collector_2.required_facts = set

# Generated at 2022-06-25 00:36:52.940310
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    '''
    test_collect
    :return:
    '''
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.collect()

if __name__ == '__main__':
    test_case_0()
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-25 00:36:54.785758
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector.is_systemd_managed_offline(None)

# Generated at 2022-06-25 00:36:56.709292
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_collector = ServiceMgrFactCollector()
    result = service_mgr_collector.is_systemd_managed_offline(None)
    assert result == False

# Generated at 2022-06-25 00:36:57.386142
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:36:59.029715
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed() == False


# Generated at 2022-06-25 00:37:03.248128
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    circleci_systemd_managed = ServiceMgrFactCollector()
    circleci_systemd_managed_result = circleci_systemd_managed.is_systemd_managed(None)
    assert circleci_systemd_managed_result == True

if __name__ == '__main__':
    test_case_0()
    test_ServiceMgrFactCollector_is_systemd_managed()

# Generated at 2022-06-25 00:37:05.310445
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    print('\nMethod collect:')
    print(service_mgr_fact_collector_1.collect())


# Generated at 2022-06-25 00:37:07.238091
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed() == False


# Generated at 2022-06-25 00:37:15.359509
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import os

    class MockModule(object):
        def __init__(self):
            self.paths = []
            self.paths.append("/System/Library/CoreServices/SystemVersion.plist")
            self.paths.append("/usr/sbin/systemctl")
            self.paths.append("/sbin/init")
            self.paths.append("/etc/debian_version")

        def get_bin_path(self, cmd):
            if cmd == 'systemctl' and os.path.exists(self.paths[1]):
                return self.paths[1]
            else:
                return None

    module = MockModule()
    # If the systemd-sysvinit package is not installed on SUSE, the file /sbin/init will not be present
    # Run the test with

# Generated at 2022-06-25 00:37:18.180065
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    result = service_mgr_fact_collector_1.is_systemd_managed({})
    assert result is None


# Generated at 2022-06-25 00:37:59.351310
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    mock_module_0 = mock.MagicMock()
    mock_module_0.get_bin_path.return_value = '/usr/bin/systemctl'
    mock_module_0.run_command.return_value = (0, '', '')

    var_0 = service_mgr_fact_collector_0.is_systemd_managed(mock_module_0)
    assert var_0 == True

# Generated at 2022-06-25 00:38:04.329635
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # python2 and python3 output differ,
    # python2: /usr/sbin/systemctl
    # python3: /usr/sbin/systemctl\n
    # so the var_1 will be set to '/usr/sbin/systemctl\n' if python3 is used,
    # which will make the test failed.
    rc, var_1, err = module.run_command('which systemctl')
    var_1 = var_1.strip()
    var_2 = '/bin'
    var_3 = os.path.join(var_2, 'systemd')
    var_4 = os.path.exists(var_3)
    var_5 = ServiceMgrFactCollector.is_systemd_managed(ServiceMgrFactCollector, var_1, var_4)
    module.exit_json

# Generated at 2022-06-25 00:38:13.314516
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    raise SkipTest('Not supported on Windows')
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = {'platform': 'Linux'}
    service_mgr_fact_collector_1.platform = var_1
    var_2 = {'ansible_system': 'Linux'}
    service_mgr_fact_collector_1.collected_facts = var_2
    class DummyModule:
        def get_bin_path(self, path):
            self.path = path
            if path == 'systemctl':
                return path
            else:
                raise Exception()
        def run_command(self, cmd, use_unsafe_shell=True):
            return (0, 'a\n', None)
    module = DummyModule()

# Generated at 2022-06-25 00:38:18.155107
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0 = MockModule()
    service_mgr_fact_collector_1 = service_mgr_fact_collector_2.is_systemd_managed(service_mgr_fact_collector_0)
    assert service_mgr_fact_collector_1 == True


# Generated at 2022-06-25 00:38:29.267572
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Make sure to use 'run' instead of 'check_output' here, check_output
    # swallows exceptions
    which_output = run("which systemctl")
    if not which_output:
        raise Exception("systemctl not found! Please install systemd.")
    else:
        os.symlink("/usr/bin/ls", "/sbin/init")
        service_mgr_fact_collector_1 = ServiceMgrFactCollector()
        assert_equal(False, service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1))
        os.unlink("/sbin/init")
        os.symlink("/usr/bin/ls", "/sbin/init")

# Generated at 2022-06-25 00:38:33.129155
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.collect()


# Generated at 2022-06-25 00:38:34.903596
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)

# Generated at 2022-06-25 00:38:37.984401
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    # FIXME: arrange
    # FIXME: act
    # FIXME: assert


# Generated at 2022-06-25 00:38:45.995045
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_1)
    var_1 = service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_1)
    var_2 = service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_1)

# Generated at 2022-06-25 00:38:47.434745
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed() == None


# Generated at 2022-06-25 00:40:22.179450
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()
    # result = service_mgr_fact_collector_2.is_systemd_managed(service_mgr_fact_collector_2)


# Generated at 2022-06-25 00:40:25.810288
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)



# Generated at 2022-06-25 00:40:30.317175
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    possible_return_values = [True, False]
    actual_return_value = service_mgr_fact_collector.is_systemd_managed()
    assert actual_return_value in possible_return_values


# Generated at 2022-06-25 00:40:33.261308
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed(module) == False


# Generated at 2022-06-25 00:40:35.672151
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.is_systemd_managed()


# Generated at 2022-06-25 00:40:43.038699
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Testing using mock
    from ansible.module_utils.facts import mocks

    # TODO: It seems this test might be broken in the future. Currently /etc/redhat-release returns result that is used.
    # In the future this file might be moved away and testing this case might become impossible.
    mocks.mock_ansible_module.get_file_content.return_value = 'Red Hat Enterprise Linux Server release 6.4 (Santiago)'
    mocks.mock_ansible_module.get_bin_path.return_value = True
    mocks.mock_ansible_module.run_command.return_value = [
        0,
        'init',
    ]
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_

# Generated at 2022-06-25 00:40:44.799057
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_1)


# Generated at 2022-06-25 00:40:48.963734
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0) == False



# Generated at 2022-06-25 00:40:55.416003
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # test_case_0
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(module=None)


# Generated at 2022-06-25 00:40:57.499617
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(service_mgr_fact_collector) == False
