

# Generated at 2022-06-25 00:34:13.589960
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.utils import get_file_content

    class TestModule:
        def __init__(self):
            self.bin_path_value = "/bin"

        def get_bin_path(self, *args, **kwargs):
            return self.bin_path_value

    test_service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test case where systemd is not installed
    test_module = TestModule()
    test_module.bin_path_value = None
    assert test_service_mgr_fact_collector.is_systemd_managed_offline(module=test_module) is False

    # Test case where /sbin/init is not a symlink
    test_module = TestModule()

# Generated at 2022-06-25 00:34:21.258337
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    testing_dict_0 = dict()
    testing_dict_0["ansible_system"] = "Linux"
    assert service_mgr_fact_collector_1.is_systemd_managed_offline(module=testing_dict_0) == False


# Generated at 2022-06-25 00:34:24.497022
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test case for when files that systemd uses can be found
    assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == True


# Generated at 2022-06-25 00:34:26.180635
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector_result = service_mgr_fact_collector.collect()
    print(service_mgr_fact_collector_result)


# Generated at 2022-06-25 00:34:31.529852
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # change working directory to test directory so that we can import module utils
    working_dir = os.getcwd()
    os.chdir(os.path.dirname(os.path.realpath(__file__)))

    from ansible.module_utils.facts.system.service_mgr import (
        ServiceMgrFactCollector,
        mock_module_implementation
    )

    service_mgr_fact_collector = ServiceMgrFactCollector()

    # mock module to return the path to `systemctl` and return it
    module = mock_module_implementation(
        bin_path_systemctl=os.path.realpath('systemctl')
    )

    # create fake systemd environment by creating used runtime and system directories
    os.makedirs("/run/systemd/system")
    os.makedirs

# Generated at 2022-06-25 00:34:38.463390
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed_offline(None) == False

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:34:46.508500
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import mock
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts import utils
    class MockModule(object):
        def __init__(self, params=None):
            self.params = {}
        def get_bin_path(self, path, opts=None):
            if path == 'systemctl':
                return True
            else:
                return False
        def fail_json(self, *args, **kwargs):
            raise Exception('fail_json')

# Generated at 2022-06-25 00:34:53.572059
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    class TestModule(object):
        pass
    test_module = TestModule()
    test_module.run_command = lambda x: (None, None, None)
    test_module.get_bin_path = lambda x: '/some/path'
    assert service_mgr_fact_collector.is_systemd_managed(test_module) == False

# Generated at 2022-06-25 00:34:57.170844
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.is_systemd_managed_offline() == False

# Generated at 2022-06-25 00:34:59.104918
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector.is_systemd_managed_offline('')


# Generated at 2022-06-25 00:35:13.649901
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)

# Generated at 2022-06-25 00:35:14.359887
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:35:19.447971
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed('ansible_systemd')


# Generated at 2022-06-25 00:35:25.662535
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    required_facts = set(['platform', 'distribution'])
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.required_facts = required_facts
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(module=service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:35:30.359563
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed_offline()


# Generated at 2022-06-25 00:35:33.183174
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1)



# Generated at 2022-06-25 00:35:34.790421
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector) == True


# Generated at 2022-06-25 00:35:37.916550
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(None) is True


# Generated at 2022-06-25 00:35:43.012651
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """Check the functioning of method is_systemd_managed"""
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    magic_mock_1 = MagicMock(name='get_bin_path')
    magic_mock_1.return_value = (1)
    service_mgr_fact_collector_1.get_bin_path = magic_mock_1
    var_2 = os.path.exists((1))
    var_3 = service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_1)
    assert (var_2 == var_3).__bool__()



# Generated at 2022-06-25 00:35:48.391247
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    test_case_0()
    assert service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0) == True



# Generated at 2022-06-25 00:36:17.391109
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_fixture_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_fixture_0.collect(service_mgr_fact_collector_fixture_0)
    assert var_1['service_mgr'] == 'service'


# Generated at 2022-06-25 00:36:24.374872
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)
    print("var_0: " + str(var_0))

# Generated at 2022-06-25 00:36:25.358619
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline() == None


# Generated at 2022-06-25 00:36:27.657256
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:36:32.031149
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline()


# Generated at 2022-06-25 00:36:41.929667
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # First test case
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    dict_0 = dict()
    dict_0['ansible_service_mgr'] = 'sysvinit'
    dict_0['ansible_system'] = 'Linux'

    # Second test case
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    dict_0 = dict()
    dict_0['ansible_service_mgr'] = 'systemd'
    dict_0['ansible_system'] = 'Linux'

    # Third test case
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()
    dict_0 = dict()
    dict_0['ansible_service_mgr'] = 'upstart'

# Generated at 2022-06-25 00:36:45.477029
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0) == False


# Generated at 2022-06-25 00:36:53.681536
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    previous_val_of_property_1 = ServiceMgrFactCollector.is_systemd_managed_offline
    previous_val_of_property_2 = ServiceMgrFactCollector.required_facts
    previous_val_of_property_3 = ServiceMgrFactCollector.is_systemd_managed
    # set new value for property is_systemd_managed_offline of class ServiceMgrFactCollector
    ServiceMgrFactCollector.is_systemd_managed_offline = None
    # set new value for property required_facts of class ServiceMgrFactCollector
    ServiceMgrFactCollector.required_facts = set()
    # set new value for property is_systemd_managed of class ServiceMgrFactCollector
    ServiceMgrFactCollector.is_systemd_managed = set()
    test_case_

# Generated at 2022-06-25 00:36:54.442512
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:36:59.178946
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Define a mock module
    class MockModule:
        def get_bin_path(self, arg):
            return '/bin/systemctl'
    mock_module = MockModule()

    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    result = service_mgr_fact_collector_1.is_systemd_managed(mock_module)
    assert result == True


# Generated at 2022-06-25 00:38:03.083161
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import tempfile
    import os
    import shutil

    # Setup temporary directory
    tmpdir = tempfile.mkdtemp()
    os.symlink(os.path.join(tmpdir, 'systemd'), os.path.join(tmpdir, 'init'))
    var_1 = ServiceMgrFactCollector()
    var_2 = var_1.is_systemd_managed_offline(var_1)
    assert var_2

    # Teardown temporary directory
    shutil.rmtree(tmpdir)


# Generated at 2022-06-25 00:38:13.195351
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    myServiceMgrFactCollector = ServiceMgrFactCollector()

    service_mgr_fact_collector_0 = myServiceMgrFactCollector.is_systemd_managed_offline(service_mgr_fact_collector_0)
    assert service_mgr_fact_collector_0.service_mgr == 'systemd'
    service_mgr_fact_collector_1 = myServiceMgrFactCollector.is_systemd_managed_offline(service_mgr_fact_collector_1)
    assert service_mgr_fact_collector_1.service_mgr == 'sysvinit'
    service_mgr_fact_collector_2 = myServiceMgrFactCollector.is_systemd_managed_offline(service_mgr_fact_collector_2)
   

# Generated at 2022-06-25 00:38:19.438458
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.collect(service_mgr_fact_collector_1)


if __name__ == '__main__':
    test_case_0()
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-25 00:38:29.157749
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.module = AnsibleModuleStub()
    service_mgr_fact_collector_0.module.params = {}
    service_mgr_fact_collector_0.module.run_command.return_value = (0, '', '')
    service_mgr_fact_collector_0.module.get_bin_path.return_value = '/usr/bin/systemctl'
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0.module)
    assert var_0 == False


# Generated at 2022-06-25 00:38:32.921195
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(ServiceMgrFactCollector())


# Generated at 2022-06-25 00:38:35.045068
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:38:44.441298
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # TODO: move to module_utils/facts/service_mgr.py
    # 
    # The distutils module is not shipped with SUNWPython on Solaris.
    # It's in the SUNWPython-devel package which also contains development files
    # that don't belong on production boxes.  Since our Solaris code doesn't
    # depend on LooseVersion, do not import it on Solaris.
    if platform.system() == 'SunOS':
        return None
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_2.is_systemd_managed_offline(service_mgr_fact_collector_2) == False 


# Generated at 2022-06-25 00:38:49.830433
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect()
    assert var_0 is None

# Generated at 2022-06-25 00:38:55.056846
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var = service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector)
    print(var)


# Generated at 2022-06-25 00:39:04.024684
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    init_managers = ['systemd', 'upstart', 'openrc', 'sysvinit']
    for manager in init_managers:
        # set default value
        ansible_system = 'Linux'
        ansible_distribution = None
        ansible_distribution_version = None
        is_systemd_managed = None

        # set the appropriate value for each manager.
        if manager == 'systemd':
            ansible_system = 'Linux'
            ansible_distribution = None
            ansible_distribution_version = None
            is_systemd_managed = True
        elif manager == 'upstart':
            ansible_system = 'Linux'
            ansible_distribution = None
            ansible_distribution_version = None


# Generated at 2022-06-25 00:41:34.071494
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:41:36.117799
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0) == None

# Generated at 2022-06-25 00:41:41.853265
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)
    var_1 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)
    assert(var_0 == var_1)

# Generated at 2022-06-25 00:41:48.251762
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    # test case 0

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)

    assert var_0 == {
        "service_mgr": "systemd"
    }

# Generated at 2022-06-25 00:41:54.575356
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed('/path/to/systemctl') == False


# Generated at 2022-06-25 00:41:59.756014
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # Call method
    result = service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector)
    assert result == False


# Generated at 2022-06-25 00:42:05.427483
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    expected_value = True
    obtained_value = service_mgr_fact_collector.is_systemd_managed(None)
    assert(expected_value == obtained_value)

# Generated at 2022-06-25 00:42:12.456980
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    yaml_0 = {'sys_binary_path': '/usr/local/bin'}

    expected = 'systemd'
    actual = service_mgr_fact_collector_0.is_systemd_managed_offline(yaml_0)

    assert expected == actual

test_case_0()

# Generated at 2022-06-25 00:42:14.111826
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector)


# Generated at 2022-06-25 00:42:16.815327
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    collected_facts = {'ansible_distribution': 'OpenWrt'}
    var_0 = service_mgr_fact_collector_0.collect(collected_facts=collected_facts)
    assert var_0 == {'service_mgr': 'openwrt_init'}

