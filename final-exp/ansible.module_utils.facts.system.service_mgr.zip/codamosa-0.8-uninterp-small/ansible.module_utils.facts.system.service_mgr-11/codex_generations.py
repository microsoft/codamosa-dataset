

# Generated at 2022-06-25 00:34:07.244007
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Run collect
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.collect()



# Generated at 2022-06-25 00:34:12.024184
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    bool_0 = False
    service_mgr_fact_collector_0 = ServiceMgrFactCollector(bool_0)
    method_result_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(module=None)
    assert method_result_0 is False


# Generated at 2022-06-25 00:34:17.156270
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # set up test
    service_mgr_collector = ServiceMgrFactCollector()
    service_mgr_collector.is_systemd_managed = ServiceMgrFactCollector.is_systemd_managed

    # test
    assert service_mgr_collector.collect() == {"service_mgr": "service"}

# Generated at 2022-06-25 00:34:20.273839
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Get instance of ServiceMgrFactCollector class
    service_mgr_fact_collector_0 = ServiceMgrFactCollector(None)

    # Test init function
    service_mgr_fact_collector_0.is_systemd_managed(None)


# Generated at 2022-06-25 00:34:29.669947
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    bool_0 = False
    service_mgr_fact_collector_0 = ServiceMgrFactCollector(bool_0)
    os_0 = None
    os_1 = None
    os_2 = None
    bool_1 = False
    bool_2 = False
    if test_case_0():
        os_0 = os
    if test_case_0():
        os_1 = os
    if test_case_0():
        os_2 = os

    if test_case_0():
        bool_0 = os_0.path.islink('/sbin/init')
    service_mgr_fact_collector_0.is_systemd_managed_offline(bool_0, bool_1, bool_2)


# Generated at 2022-06-25 00:34:33.633364
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    bool_0 = False
    service_mgr_fact_collector_0 = ServiceMgrFactCollector(bool_0)
    bool_1 = service_mgr_fact_collector_0.is_systemd_managed_offline()


# Generated at 2022-06-25 00:34:40.729116
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    bool_0 = False
    service_mgr_fact_collector_0 = ServiceMgrFactCollector(bool_0)
    module_0_0 = None
    collected_facts_0_0 = None

    # Call method collect of class ServiceMgrFactCollector with arguments module_0_0, collected_facts_0_0
    service_mgr_fact_collector_0.collect(module_0_0, collected_facts_0_0)

    # Call method collect of class ServiceMgrFactCollector with arguments module_0_0, collected_facts_0_0
    service_mgr_fact_collector_0.collect(module_0_0, collected_facts_0_0)

# Generated at 2022-06-25 00:34:41.448686
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Replace 'pass' with your actual test.
    assert True is True

# Generated at 2022-06-25 00:34:44.952551
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    bool_0 = False
    service_mgr_fact_collector_0 = ServiceMgrFactCollector(bool_0)


# Generated at 2022-06-25 00:34:50.190019
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    bool_0 = False
    service_mgr_fact_collector_0 = ServiceMgrFactCollector(bool_0)
    bool_0 = True
    service_mgr_fact_collector_0 = ServiceMgrFactCollector(bool_0)


# Generated at 2022-06-25 00:35:11.497263
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test with a class object
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:35:15.252621
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:35:17.328432
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1)


# Generated at 2022-06-25 00:35:28.255342
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    service_mgr_fact_collector = ServiceMgrFactCollector()

    # case when /run/systemd/ is present
    os.path.exists = lambda path: path == "/run/systemd/"
    assert ServiceMgrFactCollector.is_systemd_managed("module") == True

    # case when /dev/.run/systemd/ is present
    os.path.exists = lambda path: path == "/dev/.run/systemd/"
    assert ServiceMgrFactCollector.is_systemd_managed("module") == True

    # case when /dev/.systemd/ is present
    os.path.exists = lambda path: path == "/dev/.systemd/"
    assert ServiceMgrFactCollector.is_systemd_managed("module") == True

    # case when none of the above are present

# Generated at 2022-06-25 00:35:31.320212
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.is_systemd_managed_offline('/sbin/init')


# Generated at 2022-06-25 00:35:34.794323
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0) == ServiceMgrFactCollector.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:35:38.896479
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)
    assert var_0['service_mgr'] == 'service', "mismatched expected value"



# Generated at 2022-06-25 00:35:40.852242
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed(ServiceMgrFactCollector()) == False

if __name__ == '__main__':
    test_case_0()
    test_ServiceMgrFactCollector_is_systemd_managed()

# Generated at 2022-06-25 00:35:42.112622
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    ServiceMgrFactCollector.is_systemd_managed_offline()


# Generated at 2022-06-25 00:35:47.159907
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # TODO: assert on mocked module return values
    ServiceMgrFactCollector.is_systemd_managed(module=None)


# Generated at 2022-06-25 00:36:25.162526
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module_0 = ServiceMgrFactCollector()
    module_0.get_bin_path("systemctl")
    service_mgr_fact_collector_0.is_systemd_managed(module_0)


# Generated at 2022-06-25 00:36:32.190940
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.service_mgr.ServiceMgrFactCollector import ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert isinstance(service_mgr_fact_collector, BaseFactCollector)
    assert 'service_mgr' not in service_mgr_fact_collector.collect()


# Generated at 2022-06-25 00:36:35.000907
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    service_mgr_fact_collector = ServiceMgrFactCollector()

    service_mgr_fact_collector.module = type('module_0', (object,), {
        'run_command': test_case_0
    })

    # Testing if the return value is None when exception occurs
    assert service_mgr_fact_collector.is_systemd_managed_offline(service_mgr_fact_collector) is None

# Generated at 2022-06-25 00:36:38.715561
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:36:46.125084
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # We will construct a dictionary with data for a fake Linux system
    test_data = {}
    test_data['ansible_distribution'] = 'Linux'
    test_data['ansible_system'] = 'Linux'
    # Now we will call collect() method of the collector with this fake data
    service_mgr_fact_collector = ServiceMgrFactCollector()
    result = service_mgr_fact_collector.collect(service_mgr_fact_collector, test_data)
    sysvinit_result = {'service_mgr': 'sysvinit'}
    openwrt_result = {'service_mgr': 'openwrt_init'}
    openrc_result = {'service_mgr': 'openrc'}
    systemd_result = {'service_mgr': 'systemd'}

# Generated at 2022-06-25 00:36:50.721003
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1)


# Generated at 2022-06-25 00:36:52.269904
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    test = ServiceMgrFactCollector()
    # expected =
    # received = test.is_systemd_managed(test)
    # assert expected == received
    pass


# Generated at 2022-06-25 00:36:54.855553
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module_1 = AnsibleModule([])
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(module_1)


# Generated at 2022-06-25 00:36:56.188391
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

# Generated at 2022-06-25 00:36:59.254252
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)

# Generated at 2022-06-25 00:38:12.220637
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    assert callable(getattr(ServiceMgrFactCollector, 'collect', None))
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)

# Generated at 2022-06-25 00:38:19.054882
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    #case 1
    if isinstance(service_mgr_fact_collector_1.collect(service_mgr_fact_collector_1), dict):
        pass

    assert(True)

# Generated at 2022-06-25 00:38:23.349986
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    print('Test function is_systemd_managed of class ServiceMgrFactCollector')
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0) == None


# Generated at 2022-06-25 00:38:27.117519
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.is_systemd_managed_offline()


# Generated at 2022-06-25 00:38:31.071504
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.module = ''
    expected = ''
    actual = service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector.module)
    assert actual == expected


# Generated at 2022-06-25 00:38:33.856443
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1)
    print("a = " + var_1.__str__())


# Generated at 2022-06-25 00:38:39.027775
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # FIXME: mock module
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    # FIXME: mock module
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline()


# Generated at 2022-06-25 00:38:42.648763
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_case_0()



# Generated at 2022-06-25 00:38:46.402181
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)

    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.collect()

# Generated at 2022-06-25 00:38:48.924120
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed()
    assert (var_1 == False)


# Generated at 2022-06-25 00:41:53.829088
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed()


# Generated at 2022-06-25 00:41:54.550425
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:42:03.173482
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    file_path = os.path.realpath(__file__)
    assert file_path.endswith('.py'), "File path should end with .py"
    file_path = file_path[:-3]
    file_path = file_path + "_data/systemd/is_systemd_managed_offline_1"
    assert os.path.exists(file_path), "File path %s is not correct" % file_path
    assert os.path.isfile(file_path), "File path %s is not a file" % file_path
    assert os.path.isdir(file_path), "File path %s is not a directory" % file_path
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

# Generated at 2022-06-25 00:42:07.663549
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:42:11.801332
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert False == service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:42:15.760224
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    try:
        service_mgr_fact_collector_1.is_systemd_managed()
    except NameError as info:
        print('NameError:', info)
    except AttributeError as info:
        print('AttributeError:', info)


# Generated at 2022-06-25 00:42:19.207284
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector.is_systemd_managed_offline(service_mgr_fact_collector)


# Generated at 2022-06-25 00:42:21.850650
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector) == False
    assert service_mgr_fact_collector.is_systemd_managed_offline(service_mgr_fact_collector) == False


# Generated at 2022-06-25 00:42:28.377093
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
        assert service_mgr_fact_collector.is_systemd_managed(None)
    else:
        assert not service_mgr_fact_collector.is_systemd_managed(None)


# Generated at 2022-06-25 00:42:32.944975
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    module = MagicMock()
    module.run_command.return_value = (0, 'systemd', '')
    collected_facts = {
        'ansible_distribution': 'MacOSX',
        'ansible_system': 'Linux'
    }
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.is_systemd_managed = MagicMock(return_value=False)
    service_mgr_fact_collector.is_systemd_managed_offline = MagicMock(return_value=False)
    service_mgr_fact_collector.collect(module, collected_facts)