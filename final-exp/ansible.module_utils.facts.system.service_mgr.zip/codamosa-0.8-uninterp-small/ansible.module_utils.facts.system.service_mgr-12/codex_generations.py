

# Generated at 2022-06-25 00:34:15.510555
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module=None) == False


# Generated at 2022-06-25 00:34:26.025131
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    """
    Unit test for ServiceMgrFactCollector.is_systemd_managed()
    """

    class MockModule(object):
        """
        Mock class
        """
        def __init__(self):
            self.run_command = MockModule.run_command
            self.get_bin_path = MockModule.get_bin_path

        @staticmethod
        def run_command(*args, **kwargs):
            """
            Mock run_command
            """
            return 0, '', ''

        @staticmethod
        def get_bin_path(*args, **kwargs):
            """
            Mock get_bin_path
            """
            return '/usr/bin/systemctl'

    ServiceMgrFactCollector.is_systemd_managed(MockModule())
    return True


# Generated at 2022-06-25 00:34:33.157333
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    ret = service_mgr_fact_collector.is_systemd_managed_offline(None)

    # If systemd is installed but is not the boot init system, os.path.exists(canary) returns False.
    assert not ret



# Generated at 2022-06-25 00:34:42.840830
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    class MockModule:
        def get_bin_path(self, path):
            if path == 'systemctl':
                return '/usr/bin/systemctl'
            return None

# Generated at 2022-06-25 00:34:46.322479
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    assert service_mgr_fact_collector_0.is_systemd_managed_offline() == None


# Generated at 2022-06-25 00:34:54.816189
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_collector_os_path_islink = os.path.islink
    service_mgr_collector_os_readlink = os.readlink
    os.path.islink = lambda x: True
    os.readlink = lambda x: '/usr/bin/systemd'

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline({'get_bin_path':lambda x: '/path/to/systemctl'}) == True

    os.path.islink = service_mgr_collector_os_path_islink
    os.readlink = service_mgr_collector_os_readlink

# Generated at 2022-06-25 00:35:03.458816
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """Test case for systemd_managed_offline"""

    from ansible.module_utils.facts.collector import ServiceMgrFactCollector
    import os
    import tempfile
    import shutil
    import errno

    test_dir = tempfile.mkdtemp()

    # Set up a fake /sbin/init symlink to systemd
    symlink_dir = os.path.join(test_dir, 'sbin')

# Generated at 2022-06-25 00:35:10.356881
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule:
        def get_bin_path(self, option):
            return True

    class MockBaseFactCollector(BaseFactCollector):

        def collect(self, module=None, collected_facts=None):
            pass

    mock_module = MockModule()
    mock_baseFactCollector = MockBaseFactCollector()

    # Try to detect systemctl managed via is_systemd_managed_offline
    os.symlink("/bin/systemctl", "/sbin/init")
    assert mock_baseFactCollector.is_systemd_managed_offline(module=mock_module) == True
    os.unlink("/sbin/init")

# Generated at 2022-06-25 00:35:17.110585
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    def mock_run_command(self, cmd, in_data=None, run_as_root=True, executable=None, use_unsafe_shell=False):
        return (0, '/sbin/init\n')

    ServiceMgrFactCollector.get_file_content = mock_run_command
    service_mgr_fact_collector_0.is_systemd_managed()

    def mock_run_command(self, cmd, in_data=None, run_as_root=True, executable=None, use_unsafe_shell=False):
        return (0, '/run/systemd/system/\n')

    ServiceMgrFactCollector.get_file_content = mock_run_command
    service_mgr_

# Generated at 2022-06-25 00:35:22.422926
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = MockModule()
    assert service_mgr_fact_collector.is_systemd_managed_offline(module=module) == False



# Generated at 2022-06-25 00:36:02.303883
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils.facts.facts import AnsibleFactCollector
    ansible_module = AnsibleModule({})

    # The command applies to linux only.
    ansible_module.params['ansible_system'] = 'Linux'

    ansible_fact_collector = AnsibleFactCollector(ansible_module=ansible_module,
                                                  collected_facts=dict(),
                                                  cached_facts=dict())
    facts_dict = {}
    service_mgr_fact_collector = ServiceMgrFactCollector(ansible_fact_collector)

    # For this test, the unit test framework will be expected to set up the following:
    # - /run/systemd/system

# Generated at 2022-06-25 00:36:06.970913
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.collect() is None


# Generated at 2022-06-25 00:36:14.652580
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # test_case_0
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module=None) is False
    # test_case_1
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.is_systemd_managed_offline(module=None) is False

# Generated at 2022-06-25 00:36:20.401675
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module = AnsibleModuleStub()

    has_bin = os.path.isfile('/sbin/init')
    module.run_command.return_value = (0, '', '')

    service_mgr_fact_collector_0.collect(module=module)

# Generated at 2022-06-25 00:36:29.169217
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # test case:
    # 1st: item exist
    # 2nd: item doesn't exist
    for item_exist in (True, False):

        ################################################################################################################
        # Case 1: /run/systemd/system exists
        # Expected: system is systemd managed
        ################################################################################################################
        if item_exist:
            os.makedirs('/run/systemd/system')

        assert ServiceMgrFactCollector.is_systemd_managed(None) == item_exist

        if item_exist:
            os.rmdir('/run/systemd/system')

        ################################################################################################################
        # Case 2: /dev/.run/systemd exists
        # Expected: system is systemd managed
        ################################################################################################################

# Generated at 2022-06-25 00:36:40.729221
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    test_module = None

    # test systemd
    os.environ['PATH'] = '/bin:/usr/bin'
    os.environ['HOME'] = '.'
    os.environ['USER'] = 'root'
    os.environ['LOGNAME'] = 'root'

    rc, output, err = test_module.run_command('which systemctl')
    assert rc == 0
    rc, output, err = test_module.run_command('touch /run/systemd/system')
    assert rc == 0
    assert service_mgr_fact_collector.is_systemd_managed(test_module) is True

    rc, output, err = test_module.run_command('rm -f /run/systemd/system')

# Generated at 2022-06-25 00:36:44.089573
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.collect() == {}

if __name__ == '__main__':
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-25 00:36:46.647012
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Calls the is_systemd_managed_offline function with a module argument
    assert service_mgr_fact_collector.is_systemd_managed_offline(module=None)

# Generated at 2022-06-25 00:36:51.297905
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    smfc = ServiceMgrFactCollector()
    test_facts = {
        'distribution': 'MacOSX',
        'platform': 'Linux',
        'system': 'BSD'
    }
    results = smfc.collect(collected_facts=test_facts)

    assert results['service_mgr'] == 'bsdinit'

# Generated at 2022-06-25 00:36:53.851414
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class ModuleMock(object):
        def get_bin_path(self, path):
            return path

    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = ModuleMock()

    m = service_mgr_fact_collector.is_systemd_managed(module)
    assert m == False

# Generated at 2022-06-25 00:37:29.555537
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(None) == 'systemd'


# Generated at 2022-06-25 00:37:36.813592
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    d_0 = {'ansible_distribution':'RedHat','ansible_system':'Linux'}
    c_0 = ServiceMgrFactCollector()
    t_0 = c_0.is_systemd_managed(d_0)
    assert t_0 == False

    d_1 = {'ansible_distribution':'CentOS','ansible_system':'Linux'}
    c_1 = ServiceMgrFactCollector()
    t_1 = c_1.is_systemd_managed(d_1)
    assert t_1 == False

    d_2 = {'ansible_distribution':'Ubuntu','ansible_system':'Linux'}
    c_2 = ServiceMgrFactCollector()
    t_2 = c_2.is_systemd_managed(d_2)


# Generated at 2022-06-25 00:37:41.986303
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_is_systemd_managed = ServiceMgrFactCollector()

    class MockModule:

        @staticmethod
        def get_bin_path(self, command):
            return True

    module = None
    assert service_mgr_fact_collector_is_systemd_managed.is_systemd_managed(module) == False

    module = MockModule()
    assert service_mgr_fact_collector_is_systemd_managed.is_systemd_managed(module) == True


# Generated at 2022-06-25 00:37:46.135399
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    result = service_mgr_fact_collector.is_systemd_managed(module=None)
    assert result == False


# Generated at 2022-06-25 00:37:49.058130
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed_offline()


# Generated at 2022-06-25 00:37:50.546735
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(module=None) is False


# Generated at 2022-06-25 00:37:52.118611
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(None)

# Generated at 2022-06-25 00:37:54.613511
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr = ServiceMgrFactCollector()
    assert service_mgr.is_systemd_managed("/run/systemd/system/") is True
    assert service_mgr.is_systemd_managed("/dev/.run/systemd/") is True
    assert service_mgr.is_systemd_managed("/dev/.systemd/") is True


# Generated at 2022-06-25 00:38:02.061884
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    import subprocess
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import Collector
    from ansible.module_utils._text import to_bytes

    def test_collect_method(self, module=None, collected_facts=None):
        fact_dict = {'ansible_system': 'Linux'}
        # Mocking get_file_content
        def mock_get_file_content(file_path):
            if 'ansible_system' in file_path:
                return b'Linux'
            if 'comm' in file_path:
                return b'init'
            return None
        get_file_content_old = Collector.get_file_content
        Collector.get_file_content = mock_get_file_content


# Generated at 2022-06-25 00:38:06.542931
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create required variables
    module = 'module'
    # Execute the method
    result = ServiceMgrFactCollector.is_systemd_managed(module)
    # Check the result
    assert result is not None


# Generated at 2022-06-25 00:38:39.104137
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    result = service_mgr_fact_collector_0.is_systemd_managed("")
    assert result == False


# Generated at 2022-06-25 00:38:43.641185
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    print("Test 1: Testing service_mgr_fact_collector_0.collect() without arguments")
    result = service_mgr_fact_collector_0.collect()
    print(result)

# Unit tests for class ServiceMgrFactCollector

# Generated at 2022-06-25 00:38:45.598396
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector.is_systemd_managed_offline({})

# Generated at 2022-06-25 00:38:48.445949
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    is_systemd_managed_offline = service_mgr_fact_collector.is_systemd_managed_offline(None)
    assert is_systemd_managed_offline == False

# Generated at 2022-06-25 00:38:55.147009
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_data = {
            'ansible_distribution': 'MacOSX',
            'ansible_system': 'Darwin'
            }

    # Method is_systemd_managed of class ServiceMgrFactCollector
    def mock_method_is_systemd_managed(module):
        return False

    # Method get_bin_path of class AnsibleModule
    def mock_method_get_bin_path(path):
        return path
    
    # Method is_systemd_managed_offline of class ServiceMgrFactCollector
    def mock_method_is_systemd_managed_offline(module):
        return False

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed = mock_method_is

# Generated at 2022-06-25 00:38:57.089229
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline() == False

# Generated at 2022-06-25 00:38:59.642307
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Create an instance of the ServiceMgrFactCollector class
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    assert service_mgr_fact_collector_1.is_systemd_managed_offline(module = 'Module') == False

# Generated at 2022-06-25 00:39:02.062221
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module = AnsibleModuleMock()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module) == False


# Generated at 2022-06-25 00:39:05.342300
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    # Test with commad not throwing exception
    try:
        service_mgr_fact_collector_1.collect()
    except:
        pass
    # Test with commad throwing exception
    try:
        service_mgr_fact_collector_1.collect()
    except:
        pass



# Generated at 2022-06-25 00:39:07.916255
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import FakeModule
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.collect(module=FakeModule())

# Generated at 2022-06-25 00:40:42.387366
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # this should return True
    assert service_mgr_fact_collector.is_systemd_managed_offline(module=None) == True



# Generated at 2022-06-25 00:40:43.840541
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector.is_systemd_managed(None)


# Generated at 2022-06-25 00:40:45.830766
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector_collect = service_mgr_fact_collector.collect()
    return service_mgr_fact_collector_collect == {'service_mgr': 'service'}


# Generated at 2022-06-25 00:40:49.742305
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    class MockModule:
        def get_bin_path(self, arg):
            return "/bin/"+arg

    assert True is service_mgr_fact_collector.is_systemd_managed_offline(MockModule())

# Generated at 2022-06-25 00:40:53.468692
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    assert service_mgr_fact_collector_0.is_systemd_managed() is None

# Generated at 2022-06-25 00:40:57.492704
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    res = service_mgr_fact_collector_0.is_systemd_managed_offline()
    assert res is False


# Generated at 2022-06-25 00:41:01.284905
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed()


# Generated at 2022-06-25 00:41:09.152056
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    module_0 = BaseFactCollector()
    get_file_content_0 = get_file_content("/sbin/init")
    assert ('systemd' == ServiceMgrFactCollector.is_systemd_managed_offline(module_0))

# Generated at 2022-06-25 00:41:12.647895
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.collect()
    return True

# Generated at 2022-06-25 00:41:22.282483
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Get the ServiceMgrFactCollector if name is service_mgr
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.name == 'service_mgr'

    # Get the ServiceMgrFactCollector if fact_ids is set()
    assert service_mgr_fact_collector_1._fact_ids == ServiceMgrFactCollector._fact_ids

    # Get the ServiceMgrFactCollector if required_facts is set(['platform', 'distribution'])
    assert service_mgr_fact_collector_1.required_facts == ServiceMgrFactCollector.required_facts

    # Get the ServiceMgrFactCollector if is_systemd_managed(module=None)
    service_mgr_fact_collector_1