

# Generated at 2022-06-25 00:34:06.675144
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    pass


# Generated at 2022-06-25 00:34:08.855588
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
  list_0 = {}
  service_mgr_fact_collector_0 = ServiceMgrFactCollector()
  service_mgr_fact_collector_0.collect()

# Unit tests for functions

# Generated at 2022-06-25 00:34:14.800864
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    list_0 = None
    dict_0 = None
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(list_0, dict_0)
    assert not var_0



# Generated at 2022-06-25 00:34:17.651435
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    list_0 = None
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.is_systemd_managed(list_0)


# Generated at 2022-06-25 00:34:18.825464
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    assert ServiceMgrFactCollector.is_systemd_managed_offline(list_0) == False


# Generated at 2022-06-25 00:34:22.172779
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    list_0 = None
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(list_0)




# test_case_0()
test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-25 00:34:24.886733
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    list_0 = []
    assert service_mgr_fact_collector_0.is_systemd_managed(list_0) == False


# Generated at 2022-06-25 00:34:28.822603
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    list_0 = []
    function_0 = service_mgr_fact_collector_0.is_systemd_managed(list_0)
    assert function_0 == None, f"Expected: None, instead got: {function_0}"


# Generated at 2022-06-25 00:34:35.059800
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    list_0 = None
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(list_0)
    var_1 = service_mgr_fact_collector_0.collect(list_0, None)
    assert var_0 == False and var_1 == {}


# Generated at 2022-06-25 00:34:36.464609
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # FIXME: test me
    assert False


# Generated at 2022-06-25 00:34:55.887992
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Tests if the given path is a valid binary, and marks the success of the test in the test_was_successful variable
    test_was_successful = True

# Generated at 2022-06-25 00:34:59.482811
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Case 0
    print("Testing Case 0")
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    try:
        service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)
    except Exception as ex:
        print(ex)
    print("Done with Case 0")



# Generated at 2022-06-25 00:35:02.124423
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert 'systemd' == service_mgr_fact_collector.is_systemd_managed()

# Generated at 2022-06-25 00:35:05.631029
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.collect() == 'service'

# Generated at 2022-06-25 00:35:15.698048
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Test cases for valid arguments
    assert ServiceMgrFactCollector().is_systemd_managed_offline() == true
    assert ServiceMgrFactCollector().is_systemd_managed_offline() == true
    assert ServiceMgrFactCollector().is_systemd_managed_offline() == true
    assert ServiceMgrFactCollector().is_systemd_managed_offline() == true
    # Test cases for invalid arguments
    with pytest.raises(TypeError) as excinfo:
        ServiceMgrFactCollector().is_systemd_managed_offline(7)
    assert excinfo.value.args[0] == 'module is not an instance of AnsibleModule'
    with pytest.raises(TypeError) as excinfo:
        ServiceMgrFactCollector().is_systemd_managed_offline()

# Generated at 2022-06-25 00:35:21.415994
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    bool_expected = True
    bool_actual = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)
    assert bool_expected == bool_actual


# Generated at 2022-06-25 00:35:25.479332
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_ = ServiceMgrFactCollector()
    # Return value of method is_systemd_managed of class ServiceMgrFactCollector
    return_value_ = service_mgr_fact_collector_.is_systemd_managed()
    assert return_value_ is None


# Generated at 2022-06-25 00:35:35.614507
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed_offline(None) == False

###############################################################################################
# FIXME: how to fake out module for above
# TODO: also check for openrc init
# TODO: also check for systemd init
# TODO: also check for sysvinit init
# TODO: also check for bsdinit init
# TODO: also check for launchd init
# TODO: also check for upstart init
# TODO: also check for smf init
# TODO: also check for s6 init
# TODO: also check for launchd init
# TODO: also check for src init
# TODO: also check for openwrt_init init

# http://superuser.com/

# Generated at 2022-06-25 00:35:41.432352
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_1)
    assert var_1 in ('systemd', 'service', 'bsdinit', None)


# Generated at 2022-06-25 00:35:44.224096
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    x = ServiceMgrFactCollector()
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var = service_mgr_fact_collector.is_systemd_managed_offline(x)

# Generated at 2022-06-25 00:36:16.856657
# Unit test for method collect of class ServiceMgrFactCollector

# Generated at 2022-06-25 00:36:20.373494
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.collect(service_mgr_fact_collector_1)
    assert var_1 is None


# Generated at 2022-06-25 00:36:21.951968
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:36:24.795248
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:36:28.706664
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    var_0 = ServiceMgrFactCollector()
    var_1 = ServiceMgrFactCollector()
    var_2 = ServiceMgrFactCollector.collect(var_1)


# Generated at 2022-06-25 00:36:30.392136
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    pass


# Generated at 2022-06-25 00:36:38.673921
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # save the state of the current facts being collected
    from ansible.module_utils.facts import collector
    facts_dict = collector._COLLECTED_FACTS

    service_mgr_fact_collector__0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector__0.collect(service_mgr_fact_collector__0)

    # restore the state of the facts to what it was
    collector._COLLECTED_FACTS = facts_dict

# Generated at 2022-06-25 00:36:42.350733
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed()


# Generated at 2022-06-25 00:36:44.695081
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    assert ('service_mgr' in var_0)
    assert (var_0['service_mgr'] == 'service')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:36:46.920501
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_test_0 = ServiceMgrFactCollector()
    var_test_0 = service_mgr_fact_collector_test_0.is_systemd_managed_offline()


# Generated at 2022-06-25 00:37:42.140220
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    x = service_mgr_fact_collector.is_systemd_managed_offline() # No module specified

# Generated at 2022-06-25 00:37:44.814148
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.collect(service_mgr_fact_collector_1)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 00:37:50.260590
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)
    # assert service_mgr_fact_collector_0
    # assert var_0 == 'systemd'



# Generated at 2022-06-25 00:37:52.466113
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)
    assert var_0


# Generated at 2022-06-25 00:37:57.632134
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    ret_1 = service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1)

# Generated at 2022-06-25 00:38:06.715685
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector._module = MockAnsibleModule(platform_system='Linux', distribution_name='Ubuntu')
    service_mgr_fact_collector._module.get_bin_path = Mock()
    service_mgr_fact_collector._module.get_bin_path.return_value = '/usr/bin/systemctl'
    service_mgr_fact_collector._module.run_command = Mock()
    service_mgr_fact_collector._module.run_command.return_value = 0, '', ''
    assert service_mgr_fact_collector.is_systemd_managed(service_mgr_fact_collector._module) == True


# Generated at 2022-06-25 00:38:10.996299
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-25 00:38:12.865341
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # No unit test is currently available, please write one and contribute
    assert True


# Generated at 2022-06-25 00:38:15.142405
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    # TODO: test all cases
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:38:19.866756
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # FIXME: it should be possible to test this without mocking all facts
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.collect()


if __name__ == '__main__':
    test_case_0()
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-25 00:40:32.517073
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:40:34.524411
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    is_systemd_managed_offline()
    """
    collection = ServiceMgrFactCollector()
    collection.collect()

# Generated at 2022-06-25 00:40:40.559312
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    parameter_1 = os.path.islink('/sbin/init')
    parameter_2 = os.path.basename(os.readlink('/sbin/init'))
    parameter_3 = "systemd"
    var = (parameter_1 == parameter_2 == parameter_3)
    expected = var == True
    actual = service_mgr_fact_collector.is_systemd_managed_offline(None)
    assert actual == expected


# Generated at 2022-06-25 00:40:42.565841
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Test variables and expected output
    service_mgr_fact_collector_test = ServiceMgrFactCollector()

    # Check default return value
    assert service_mgr_fact_collector_test.is_systemd_managed_offline(service_mgr_fact_collector_test) == False

# Generated at 2022-06-25 00:40:51.368910
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Fixture
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.module.run_command = lambda cmd, use_unsafe_shell=False: ("", "")
    service_mgr_fact_collector_1.module.get_bin_path = lambda cmd: "/bin/systemctl"
    # Initializing the variable to use in the test
    os.path.exists = lambda path: True

    # Test
    var_1 = service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_1.module)

    # Assertion - verify that assertion holds
    assert var_1 == True


# Generated at 2022-06-25 00:41:00.746702
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    fixture_platform = platform.system
    fixture_os_readlink = os.readlink
    fixture_os_path_islink = os.path.islink
    fixture_get_bin_path = ServiceMgrFactCollector.get_bin_path


# Generated at 2022-06-25 00:41:02.222039
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()
    service_mgr_fact_collector_2.is_systemd_managed()


# Generated at 2022-06-25 00:41:08.162953
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = ServiceMgrFactCollector.is_systemd_managed_offline(service_mgr_fact_collector_1)


# Generated at 2022-06-25 00:41:10.762157
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    pass


# Generated at 2022-06-25 00:41:16.968096
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    print("test_ServiceMgrFactCollector_is_systemd_managed")
    sm_module = 'module_name'
    expected_result = True


    # Read's module_name is default as '<module_name>'
    sm_module = '<module_name>'
    # Call method is_systemd_managed of class ServiceMgrFactCollector by passing a module name as argument
    actual_result = ServiceMgrFactCollector.is_systemd_managed(sm_module)
    # Assert that the actual_result is equel to the expected_result
    assert (expected_result == actual_result)
