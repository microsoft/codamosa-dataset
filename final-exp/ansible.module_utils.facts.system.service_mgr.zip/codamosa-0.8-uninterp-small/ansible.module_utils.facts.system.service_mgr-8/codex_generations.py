

# Generated at 2022-06-25 00:34:07.408879
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module=None) is None

# Generated at 2022-06-25 00:34:15.511836
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    '''
    Unit test for method collect of class ServiceMgrFactCollector.
    '''
    # From module ping.py
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # From module ping.py
    set_module_args(dict(output='text'))

    # Unit test case
    result = ServiceMgrFactCollector.collect(module=module, collected_facts={'ansible_distribution': 'AIX'})

    assert result == dict(service_mgr='src')



# Generated at 2022-06-25 00:34:18.593835
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.is_systemd_managed() == False
    assert service_mgr_fact_collector_1.is_systemd_managed() == False

# Generated at 2022-06-25 00:34:21.358693
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_ = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_.collect().get('service_mgr') == None


# meta: timeout=30

# Generated at 2022-06-25 00:34:25.754226
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_is_systemd_managed_offline = ServiceMgrFactCollector()
    distutils = module_distutils()
    is_systemd_managed_offline_0 = service_mgr_fact_collector_is_systemd_managed_offline.is_systemd_managed_offline(distutils)
    assert is_systemd_managed_offline_0 == False



# Generated at 2022-06-25 00:34:37.504655
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Testing when canary files exist
    mocked_canary = {
        "/run/systemd/system/" : True,
        "/dev/.run/systemd/" : True,
        "/dev/.systemd/" : True
        }
    def mock_os_path_exists(canary_file):
        return mocked_canary[canary_file]

    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = Mock()
    module.get_bin_path.return_value = '/usr/bin/systemctl'
    service_mgr_fact_collector.os.path.exists = mock_os_path_exists
    assert_equals(service_mgr_fact_collector.is_systemd_managed(module), True)

    # Testing when canary files missing
    mocked

# Generated at 2022-06-25 00:34:41.184552
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_collect = ServiceMgrFactCollector()
    result = service_mgr_fact_collector_collect.collect()
    #assert len(result) == 2
    #assert type(result) is dict
    assert result is not None
    assert type(result['ansible_service_mgr']) is str
    assert result['ansible_service_mgr'] is not None


# Generated at 2022-06-25 00:34:52.449837
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-25 00:34:56.249358
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed_offline()

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 00:35:01.378304
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    class ModuleMock(object):

        def __init__(self):
            self.bin_path = []

        def get_bin_path(self, executable):
            if executable == 'systemctl':
                return '/bin/systemctl'
            else:
                return None

    assert not service_mgr_fact_collector.is_systemd_managed_offline(ModuleMock())

# Generated at 2022-06-25 00:35:30.654473
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    print("ServiceMgrFactCollector_is_systemd_managed:")
    # setup
    import ansible.module_utils.facts.system.service_mgr as service_mgr
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    # Test for Linux *systemd* managed
    # mock module
    class Module0(object):
        def get_bin_path(self, cmd):
            return "/bin/systemctl"

    module0 = Module0()
    if ServiceMgrFactCollector.is_systemd_managed(module0):
        print("Linux *systemd* managed")
    else:
        print("Linux *systemd* not managed")

    # Test for Linux *systemd* managed
    # mock module

# Generated at 2022-06-25 00:35:40.101734
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    '''
    Create class ServiceMgrFactCollector and test cases for method is_systemd_managed_offline.
    :return:
    '''
    service_mgr_fact_collector = ServiceMgrFactCollector()
    collection = dict(ansible_system='Linux')
    class fake_module(object):
        '''
        Fake module class
        '''
        def __init__(self, collection):
            self.collection = collection

        def get_bin_path(self, command):
            '''
            Fake method for get_bin_path()
            :param command:
            :return:
            '''
            if command == 'systemctl':
                return '/usr/bin/systemctl'
            return None

    module_0 = fake_module(collection)
    assert service_mgr_fact_collect

# Generated at 2022-06-25 00:35:45.122745
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = AnsibleModule()
    os.symlink("/bin/sh", "/sbin/init")
    assert not service_mgr_fact_collector.is_systemd_managed_offline(module)
    os.unlink("/sbin/init")
    os.symlink("/bin/systemd", "/sbin/init")
    assert service_mgr_fact_collector.is_systemd_managed_offline(module)
    os.unlink("/sbin/init")
    os.symlink("/usr/lib/systemd/systemd", "/sbin/init")
    assert service_mgr_fact_collector.is_systemd_managed_offline(module)

# Generated at 2022-06-25 00:35:51.058126
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.module = FakeModule()
    service_mgr_fact_collector_0.module.get_bin_path = FakeGetBinPath()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline()

# Class FakeModule

# Generated at 2022-06-25 00:35:58.711155
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system import service_mgr
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import PY3
    import os
    import sys
    import tempfile

    if PY3:
        from unittest.mock import MagicMock, patch
    else:
        from mock import MagicMock, patch

    # Instantiate a FactsCollector object
    facts_collector = FactsCollector()

    # Instantiate a ServiceMgrFactCollector object
    service_mgr_fact_collector = ServiceMgrFactCollector()

    #

# Generated at 2022-06-25 00:36:00.486509
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_case_1()

if __name__ == '__main__':
    test_case_0()
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-25 00:36:06.172922
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    platform_system = platform.system()
    service_mgr_fact_collector_obj = ServiceMgrFactCollector()

    # Mock module class
    class Module(object):
        def get_bin_path(self, tool):
            if tool == 'systemctl':
                return True
            else:
                return False

    if platform_system == "Linux":
        obj_module = Module()
        result = service_mgr_fact_collector_obj.is_systemd_managed_offline(obj_module)
        assert result == False
    elif platform_system == "FreeBSD":
        obj_module = Module()
        result = service_mgr_fact_collector_obj.is_systemd_managed_offline(obj_module)
        assert result == False

# Generated at 2022-06-25 00:36:16.823677
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    params = {}
    # Current directory should contain tests/units/module_utils/facts/test_ServiceMgrFactCollector.py
    params['ansible_system'] = 'Linux'
    params['ansible_system_vendor'] = 'Linux'

    # create module which will be passed as argument
    class AnsibleModuleFake:
        def run_command(self, command, use_unsafe_shell):
            return 0, '/sbin/init', ""

        def get_bin_path(self, command):
            return '/bin'

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    test_module = AnsibleModuleFake()

    rc = service_mgr_fact_collector_0.is_systemd_managed_offline(test_module)

    assert rc == True

#

# Generated at 2022-06-25 00:36:21.472756
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    # Testing 'is_systemd_managed' method of class ServiceMgrFactCollector
    # Testing with a predefined class
    # Return value of 'is_systemd_managed' method of class ServiceMgrFactCollector
    assert ServiceMgrFactCollector.is_systemd_managed(service_mgr_fact_collector_0.module) is None


# Generated at 2022-06-25 00:36:26.847780
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    # Test default case where /sbin/init doesn't exist.
    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = None
    result = service_mgr_fact_collector.is_systemd_managed_offline(module)
    assert result == False

    # Test when /sbin/init is a symbolic link to systemd
    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = None
    result = service_mgr_fact_collector.is_systemd_managed_offline(module)
    assert result == False

    # When symbolic link /sbin/init points to a non-systemd executable
    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = None
    result = service_mgr_fact_collector

# Generated at 2022-06-25 00:37:25.265001
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Test happy path when the required bin is present
    class FakeModule:
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, command):
            if command == 'systemctl':
                return self.bin_path
            return None

    class FakeOs(object):
        @staticmethod
        def path_exists(file):
            return False

    fake_module_0 = FakeModule('/bin/systemctl')
    assert not ServiceMgrFactCollector.is_systemd_managed_offline(fake_module_0)
    assert not ServiceMgrFactCollector.is_systemd_managed(fake_module_0)

    # Test if the required bin is not present but the required file exists
    fake_module_1 = FakeModule(None)

# Generated at 2022-06-25 00:37:29.030946
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    module = MockModule()
    assert service_mgr_fact_collector_1.is_systemd_managed(module) == True


# Generated at 2022-06-25 00:37:34.188132
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    setattr(service_mgr_fact_collector, '_get_proc_1', lambda: 'test')
    assert service_mgr_fact_collector.collect() == {'service_mgr': 'test'}

# Generated at 2022-06-25 00:37:41.545488
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    expected_map = [
        ("Fedora",         "systemd",      True),
        ("Fedora",         "upstart",      False),
        ("AbstractLinux",  "systemd",      False),
        ("AbstractLinux",  "upstart",      False),
    ]
    for distribution, system, expected_result in expected_map:
        module = {
            "ansible_system": system,
            "ansible_distribution": distribution,
        }
        result = ServiceMgrFactCollector.is_systemd_managed(module=module)
        assert(result == expected_result)


# Generated at 2022-06-25 00:37:48.079349
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    expected = True
    service_mgr_fact_collector = ServiceMgrFactCollector()
    class fakeModuleClass:
        def __init__(self):
            self.run_command = None
        def get_bin_path(self, command):
            return "/usr/bin/" + command
        def run_command(self, command, use_unsafe_shell):
            return (0, os.readlink("/sbin/init"), "")

    fakeModule = fakeModuleClass()
    actual = service_mgr_fact_collector.is_systemd_managed_offline(fakeModule)
    assert actual == expected

# Generated at 2022-06-25 00:37:51.002301
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    testing_module_1 = None
    assert service_mgr_fact_collector_1.is_systemd_managed_offline(testing_module_1) is False

# Generated at 2022-06-25 00:37:52.797930
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    ServiceMgrFactCollector_is_systemd_managed_0 = ServiceMgrFactCollector()
    assert ServiceMgrFactCollector_is_systemd_managed_0.is_systemd_managed() == False


# Generated at 2022-06-25 00:37:54.166438
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector_1.is_systemd_managed()

# Generated at 2022-06-25 00:37:59.298111
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # test options
    # run test with no options
    if platform.system() != 'SunOS':
        from ansible.module_utils.facts.collectors import ServiceMgrFactCollector
        expected_result = True
        service_mgr_fact_collector = ServiceMgrFactCollector()
        actual_result = service_mgr_fact_collector.is_systemd_managed_offline(module=None)
        assert actual_result == expected_result

# Generated at 2022-06-25 00:38:06.803377
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    systemd_paths = [
        "/run/systemd/system/",
        "/dev/.run/systemd/",
        "/dev/.systemd/"
    ]

    # fake the existence of systemd paths
    for path in systemd_paths:
        path_orig = "/orig" + path

        os.renames(path, path_orig)

        module = Mock(name='ansible_module')
        module.get_bin_path.return_value = True

        # call is_systemd_managed
        assert service_mgr_fact_collector.is_systemd_managed(module=module)

        # put back original path
        os.renames(path_orig, path)


if __name__ == '__main__':
    test

# Generated at 2022-06-25 00:40:23.518469
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Mock module
    class MockModule(object):
        def get_bin_path(self, _):
            return True

    # If /sbin/init is a symlink to systemd, it should return True
    with open('/sbin/init', 'w') as f:
        f.write('systemd')
    module = MockModule()
    assert service_mgr_fact_collector.is_systemd_managed_offline(module) == True

    # If /sbin/init is not a symlink, it should return False
    with open('/sbin/init', 'w') as f:
        f.write('init')
    assert service_mgr_fact_collector.is_systemd_managed_offline(module)

# Generated at 2022-06-25 00:40:25.069973
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # Test no paramater - collected_facts is None
    assert service_mgr_fact_collector.collect() == {}

# Generated at 2022-06-25 00:40:28.667635
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # Test0
    sample_module = {}
    service_mgr_fact_collector.is_systemd_managed_offline(sample_module)
    # Test1
    sample_module = {
        'get_bin_path': lambda p:
        "/usr/bin/systemctl"
    }
    service_mgr_fact_collector.is_systemd_managed_offline(sample_module)

# Generated at 2022-06-25 00:40:37.993078
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    service_mgr_fact_collector = ServiceMgrFactCollector()
    base_fact_collector = BaseFactCollector()

    assert isinstance(base_fact_collector, BaseFactCollector)
    assert isinstance(ServiceMgrFactCollector, BaseFactCollector)

    assert service_mgr_fact_collector.is_systemd_managed(base_fact_collector), \
           'is_systemd_managed failed to return a boolean.'


# Generated at 2022-06-25 00:40:46.089148
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test with os.path.trylink
    def mock_is_systemd_managed_os_path_islink(path):
        if path == "/sbin/init":
            return True
        return False
    service_mgr_fact_collector.is_systemd_managed_os_path_islink = mock_is_systemd_managed_os_path_islink

    # Test with os.readlink
    def mock_is_systemd_managed_os_readlink(path):
        if path == "/sbin/init":
            return "systemd"
        return False
    service_mgr_fact_collector.is_systemd_managed_os_readlink = mock_is_systemd_managed_os_readlink

   

# Generated at 2022-06-25 00:40:55.496400
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create instance of class with only static methods
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # Create class
    test_class = DummyAnsibleModule()
    # Set the get_bin_path return value to a known state
    test_class.get_bin_path_retval = "/usr/bin/systemctl"
    # Set up a canary that is marked by systemd
    test_class.os_path_exists_retvals = {'/run/systemd/system/': True}
    assert service_mgr_fact_collector.is_systemd_managed(test_class)
    # Reset return values
    test_class.get_bin_path_retval = None
    test_class.os_path_exists_retvals = {}
    # Reset the class variable
   

# Generated at 2022-06-25 00:40:58.034376
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # HACK: Cannot unit test this
    try:
        result = service_mgr_fact_collector.collect()
    except NotImplementedError as exception:
        assert type(exception) == NotImplementedError


# Generated at 2022-06-25 00:41:04.816436
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module='/sbin/init') is False
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module='/usr/bin/init') is False
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module='systemd') is False
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module='/usr/lib/systemd/systemd') is True


# Generated at 2022-06-25 00:41:10.548836
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    serviceMgrFactCollector = ServiceMgrFactCollector()
    mockModule = Mock()
    mockModule.run_command = Mock()
    setattr(mockModule, 'get_bin_path', Mock())
    collectedFacts = {'ansible_distribution': None, 'ansible_system': None}

    # test case with ansible_system = 'Linux' | ansible_distribution = 'Fedora' | service_mgr = 'systemd'
    collectedFacts['ansible_system'] = 'Linux'
    collectedFacts['ansible_distribution'] = 'Fedora'
    serviceMgrFactCollector.is_systemd_managed = Mock(return_value=True)
    assert serviceMgrFactCollector.collect(mockModule, collectedFacts) == {'service_mgr': 'systemd'}

# Generated at 2022-06-25 00:41:17.768166
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    import os
    import tempfile

    # this object will be used as a module like object in the test
    class Module:
        def fail_json(self, msg=None):
            raise ValueError(msg)

        def get_bin_path(self, name):
            return os.path.join(tempdir, name)

        def run_command(self, cmd, check_rc=False, use_unsafe_shell=None):
            return 0, cmd, None

    # create temporary directory to simulate commands
    tempdir = tempfile.mkdtemp()

    # create temporary bin_path in order to test path
    bin_path_1 = os.path.join(tempdir, "systemctl")
    open(bin_path_1, 'a').close()

    # create temporary bin_path in order to test path
    bin_path