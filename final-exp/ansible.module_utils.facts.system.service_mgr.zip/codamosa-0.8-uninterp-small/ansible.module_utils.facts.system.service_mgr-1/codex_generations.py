

# Generated at 2022-06-25 00:34:08.472423
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    # Case with default parameters
    facts_dict = service_mgr_fact_collector_1.collect()
    assert facts_dict['service_mgr'] is not None

# Generated at 2022-06-25 00:34:19.203408
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-25 00:34:21.970546
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module = None
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module) is False


# Generated at 2022-06-25 00:34:29.966848
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import ansible.module_utils.facts.collector
    import platform

    # Get Ansible module
    mock_AnsibleModule = ansible.module_utils.facts.collector.AnsibleModule
    mock_module = mock_AnsibleModule()

    # Create an instance of class ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()

    # Test on platform Linux
    if platform.system() != 'Linux':
        print("SKIP test_ServiceMgrFactCollector_is_systemd_managed_offline on non Linux platform")
        return

    # /sbin/init is not a symlink to systemd
    os.system('mkdir /tmp/test_ServiceMgrFactCollector_is_systemd_managed_offline')

# Generated at 2022-06-25 00:34:35.273698
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    my_ansible_module_0 = AnsibleModuleStub()
    service_mgr_fact_collector_0.collect(module=my_ansible_module_0)

# Unit test base class for module facts.fact_collector.ServiceMgrFactCollector

# Generated at 2022-06-25 00:34:38.568069
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.collect()

# Generated at 2022-06-25 00:34:41.126423
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    module = AnsibleModule(argument_spec=dict(
                ))
    assert service_mgr_fact_collector_1.is_systemd_managed(module=module) == False


# Generated at 2022-06-25 00:34:49.928610
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.processor import Processor

    facts_1 = Processor(Collector()).collect()

    service_mgr_fact_collector_2 = ServiceMgrFactCollector()

    assert service_mgr_fact_collector_2.collect(collected_facts=facts_1) == {'service_mgr': 'systemd'}


# Generated at 2022-06-25 00:34:51.855245
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.collect()

# Generated at 2022-06-25 00:34:53.994479
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.collect() == {}


# Generated at 2022-06-25 00:35:11.846130
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    assert service_mgr_fact_collector.is_systemd_managed_offline(module) == False

# Generated at 2022-06-25 00:35:15.071966
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.collect() == {'service_mgr': 'service'}


# Generated at 2022-06-25 00:35:20.081158
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    result = service_mgr_fact_collector_1.is_systemd_managed_offline('/bin/systemctl')
    assert result == False


# Generated at 2022-06-25 00:35:24.907170
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    fake_module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    assert service_mgr_fact_collector.is_systemd_managed(module=fake_module) == False


# Generated at 2022-06-25 00:35:35.558792
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    module_0 = AnsibleModule(
        argument_spec = dict(
            group_prefix = dict(type='str', required=False)
        ),
        supports_check_mode = False
    )

    ansible_facts_0 = dict(
        ansible_distribution='Debian'
    )

    service_mgr_fact_collector_1.collect(module=module_0, collected_facts=ansible_facts_0)

    ansible_facts_1 = dict(
        ansible_distribution='OpenWrt'
    )

    service_mgr_fact_collector_1.collect(module=module_0, collected_facts=ansible_facts_1)

    ansible_facts_2 = dict()

   

# Generated at 2022-06-25 00:35:45.867354
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """Test to assert that the method is_systemd_managed_offline
    returns true if /sbin/init is a symlink to systemd"""
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    # When /sbin/init is a symlink to systemd
    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(None) is True

    os.remove('/sbin/init')

    # When /sbin/init is a symlink to any other
    os.symlink('/usr/lib/systemd/systemd', '/sbin/init')
    assert service_mgr_fact_collector_0.is_systemd

# Generated at 2022-06-25 00:35:55.791520
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.utils import MockModule
    mock_module = MockModule()
    smfc = ServiceMgrFactCollector()
    smfc.m = mock_module
    mock_module.get_bin_path.return_value = None
    assert not smfc.is_systemd_managed(mock_module)

    mock_module.get_bin_path.return_value = '/usr/bin/systemctl'
    assert not smfc.is_systemd_managed(mock_module)

    mock_module.get_bin_path.return_value = '/usr/bin/systemctl'
    assert not smfc.is_systemd_managed(mock_module)



# Generated at 2022-06-25 00:36:00.256409
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class TestModule(object):
        def get_bin_path(self, arg):
            return '/bin/true'
    fake_module = TestModule()

    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.is_systemd_managed_offline(fake_module) is True


# Generated at 2022-06-25 00:36:06.181403
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Set up mock objects
    is_systemd_managed_mock_ansible_facts = {'ansible_distribution': 'MacOSX'}
    is_systemd_managed_mock_ansible_module_get_bin_path_systemctl = 'F:/systemctl/'

    is_systemd_managed_mock_ansible_module = mock.MagicMock(name='is_systemd_managed_mock_ansible_module')
    type(is_systemd_managed_mock_ansible_module).ansible_facts = mock.PropertyMock(return_value=is_systemd_managed_mock_ansible_facts)

# Generated at 2022-06-25 00:36:08.287541
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    print ((service_mgr_fact_collector_1.collect()))

# Unit test is missing, we need to write the unit test for the class ServiceMgrFactCollector

# Generated at 2022-06-25 00:36:36.012766
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_o = ServiceMgrFactCollector()
    service_mgr_dict = service_mgr_fact_collector_o.collect()
    assert isinstance(service_mgr_dict, dict)

# Generated at 2022-06-25 00:36:39.261724
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector.is_systemd_managed(module=None)


# Generated at 2022-06-25 00:36:46.539844
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.params['bin_path'] = "/usr/bin/"

        def get_bin_path(self, command):
            self.params['command'] = command
            return command in self.params['bin_path']

    test_module_0 = TestModule()

    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    # Run test on test_module_0 with service_mgr_fact_collector_1
    assert service_mgr_fact_collector_1.is_systemd_managed_offline(test_module_0)

    class TestModule(object):
        def __init__(self):
            self.params = {}

# Generated at 2022-06-25 00:36:51.783185
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    def mock_get_bin_path(name):
        return "/bin/systemctl"

    module = type('', (), {})()
    module.get_bin_path = mock_get_bin_path

    os.path.exists = lambda name: True

    assert(service_mgr_fact_collector.is_systemd_managed(module))


# Generated at 2022-06-25 00:36:53.235444
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    assert ServiceMgrFactCollector.collect(
        module=None,
        collected_facts=None
    ) == {}

# Generated at 2022-06-25 00:36:55.949278
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    if platform.system() != 'SunOS':
        assert service_mgr_fact_collector.is_systemd_managed_offline(module=None) == False


# Generated at 2022-06-25 00:36:59.864237
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
	# TODO: For cases when 'systemctl' is not found or any other failure
	assert ServiceMgrFactCollector.is_systemd_managed(None) == False
	assert ServiceMgrFactCollector.is_systemd_managed_offline(None) == False
	# TODO: Need to generate file structure simulating a running systemd system in here

# Generated at 2022-06-25 00:37:02.985410
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    is_systemd_managed_result = service_mgr_fact_collector.is_systemd_managed(module=None)
    assert is_systemd_managed_result == False


# Generated at 2022-06-25 00:37:05.492707
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()


# Generated at 2022-06-25 00:37:11.811614
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    import os
    import platform
    import pytest

    class MockModule(object):
        def __init__(self, return_value=None):
            self.params = {}
            self.return_value = return_value

        def get_bin_path(self, executable, required=True):
            # FIXME: this is a bit hacky, but there is no "required" attribute on ModuleFinder
            return '/bin/systemctl'


# Generated at 2022-06-25 00:37:46.434289
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_1)


# Generated at 2022-06-25 00:37:52.097702
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1)

# Generated at 2022-06-25 00:37:57.601037
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)



# Generated at 2022-06-25 00:38:03.081132
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1)

# Generated at 2022-06-25 00:38:05.326579
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:38:07.115223
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    is_systemd_managed_offline_0 = ServiceMgrFactCollector.is_systemd_managed_offline(ServiceMgrFactCollector())


# Generated at 2022-06-25 00:38:12.784196
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1)
    print("test_ServiceMgrFactCollector_is_systemd_managed_offline")
    print(var_1)


# Generated at 2022-06-25 00:38:18.971479
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module_0 = object()

    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(module_0)



# Generated at 2022-06-25 00:38:21.782556
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    collect_service_mgr = ServiceMgrFactCollector()
    collect_service_mgr.is_systemd_managed_offline(collect_service_mgr)


# Generated at 2022-06-25 00:38:26.412472
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)  # test function



# Generated at 2022-06-25 00:39:31.317200
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)
    assert isinstance(var_0, bool)
    assert var_0 == False


# Generated at 2022-06-25 00:39:36.008270
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    obj_service_mgr_fact_collector = ServiceMgrFactCollector()
    obj_service_mgr_fact_collector.is_systemd_managed(obj_service_mgr_fact_collector)


# Generated at 2022-06-25 00:39:39.097033
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    var_1 = ServiceMgrFactCollector()
    var_2 = {}
    var_3 = var_1.collect(var_2)
    assert var_3 == {}



# Generated at 2022-06-25 00:39:43.551742
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    param_0 = ServiceMgrFactCollector()

    # unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
    assert param_0.is_systemd_managed_offline() == ServiceMgrFactCollector.is_systemd_managed_offline(param_0)

# Generated at 2022-06-25 00:39:48.204934
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:39:52.610959
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector import FactsCollector
    facts_collector = FactsCollector()
    facts = facts_collector.collect()
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(facts)


# Generated at 2022-06-25 00:39:54.614360
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:39:56.630170
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    # FIXME: need to fake module so we can test
    module = None
    var_1 = service_mgr_fact_collector_0.is_systemd_managed_offline(module)

# Generated at 2022-06-25 00:39:58.759194
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():

    # Test case for callable is_systemd_managed of class ServiceMgrFactCollector
    # Test case for return value None
    assert ServiceMgrFactCollector.is_systemd_managed(None) == None


# Generated at 2022-06-25 00:40:06.516237
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_get_bin_path = service_mgr_fact_collector_0.module.get_bin_path.func_globals.get('__module__')
    if var_get_bin_path == 'ansible.module_utils.facts.system.distribution':
        service_mgr_fact_collector_0.module.get_bin_path = lambda *args: '/usr/bin/systemctl'

    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)

    pass


# Generated at 2022-06-25 00:42:12.379967
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_obj = ServiceMgrFactCollector()
    service_mgr_fact_collector_obj.collect()


# Generated at 2022-06-25 00:42:15.582270
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # Create an instance of a module
    _module = AnsibleModule(
        argument_spec = dict()
    )

    # Create a class instance and run the method
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector.is_systemd_managed(_module)


# Generated at 2022-06-25 00:42:20.182319
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:42:28.266300
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    class service_mgrModule():
        def __init__(self):
            self.run_command = ServiceMgrFactCollector.collect
    service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgrModule())


# Generated at 2022-06-25 00:42:31.870553
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)

# Generated at 2022-06-25 00:42:35.135820
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    if not service_mgr_fact_collector_0.is_systemd_managed():
        return False
    return True


# Generated at 2022-06-25 00:42:39.899404
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    print('')

    ############################################
    # Unit test for:
    #   collect()
    ############################################
    test_case_0()


################################################
# Unit test execution
################################################

if __name__ == '__main__':
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-25 00:42:44.663985
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector0 = ServiceMgrFactCollector()
    var0 = service_mgr_fact_collector0.collect(None)
    assert var0 is not None
    assert var0 == {'service_mgr': 'service'}

# Generated at 2022-06-25 00:42:47.879622
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(None) is True


# Generated at 2022-06-25 00:42:54.377802
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector.is_systemd_managed_offline('')
