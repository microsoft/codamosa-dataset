

# Generated at 2022-06-25 00:34:09.974722
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    print('Test test_ServiceMgrFactCollector_collect')
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-25 00:34:13.256598
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    # TODO: Remove this test after support for lesser versions of Python are dropped.
    pass


# Generated at 2022-06-25 00:34:16.721899
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect()
    assert var_0['service_mgr'] == 'service'


# Generated at 2022-06-25 00:34:19.203603
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert True == service_mgr_fact_collector_0.is_systemd_managed_offline()

# Generated at 2022-06-25 00:34:28.827353
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-25 00:34:35.343880
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import platform
    import os

    if platform.system() != 'SunOS':
        return
    if not os.path.islink('/sbin/init') or os.readlink('/sbin/init') != 'systemd':
        return

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(module)
    print(var_0)

# Generated at 2022-06-25 00:34:38.904588
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert True == service_mgr_fact_collector_0.is_systemd_managed(module)


# Generated at 2022-06-25 00:34:41.184240
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    param_0 = False
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed_offline(param_0)


# Generated at 2022-06-25 00:34:45.301840
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    output = service_mgr_fact_collector.is_systemd_managed()


# Generated at 2022-06-25 00:34:52.323251
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    required_facts = set(['platform', 'distribution'])

    # The *_0 cases are named for the case that is being tested
    # The *_1 cases are named for the values that are being set in the setUp
    # The *_2 cases are named for the values that are expected to be returned
    # by the function being tested

    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.required_facts = required_facts
    service_mgr_fact_collector_0.collect()

# Generated at 2022-06-25 00:35:11.582704
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var_1 = ServiceMgrFactCollector.is_systemd_managed_offline(service_mgr_fact_collector)
    print(var_1)


# Generated at 2022-06-25 00:35:21.828676
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # For the following test case, the is_systemd_managed_offline method should return True
    # This test case is just to test the output of the test case
    svc_mgr_fact_collector_true = ServiceMgrFactCollector()
    var_true = svc_mgr_fact_collector_true.is_systemd_managed_offline(svc_mgr_fact_collector_true)
    assert var_true == True
    # For the following test case, the is_systemd_managed_offline method should return False
    # This test case is just to test the output of the test case
    svc_mgr_fact_collector_false = ServiceMgrFactCollector()
    var_false = svc_mgr_fact_collector_false.is_systemd_managed_offline

# Generated at 2022-06-25 00:35:27.905265
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_1, None)
    assert var_0 == {u'service_mgr': u'service'}

if __name__ == '__main__':
    test_case_0()
    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-25 00:35:30.120597
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    with pytest.raises(TypeError):
        ServiceMgrFactCollector.is_systemd_managed_offline()


# Generated at 2022-06-25 00:35:32.604757
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    pass

# Generated at 2022-06-25 00:35:35.589994
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # TODO - Add test cases here
    #assert service_mgr_fact_collector.is_systemd_managed() == 'expected_value'


# Generated at 2022-06-25 00:35:40.751378
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)
    print(var_0)

# Generated at 2022-06-25 00:35:46.104205
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-25 00:35:49.762125
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_1.is_systemd_managed()


# Generated at 2022-06-25 00:35:55.370695
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    print("\n**** Unit testcase: test_ServiceMgrFactCollector_is_systemd_managed ****")
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert(service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0) is not None)


# Generated at 2022-06-25 00:36:33.389420
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'junk\n', 'junk')
    module.get_bin_path.return_value = True

    service_mgr_fact_collector = ServiceMgrFactCollector()
    var = service_mgr_fact_collector.collect(module)
    assert var['service_mgr'] == 'service', 'Service manager not set'


# Generated at 2022-06-25 00:36:35.121103
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()


# Generated at 2022-06-25 00:36:44.857016
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()
    return_1 = service_mgr_fact_collector_2.is_systemd_managed_offline(service_mgr_fact_collector_2)
    return_2 = service_mgr_fact_collector_2.is_systemd_managed_offline(service_mgr_fact_collector_2)
    return_3 = service_mgr_fact_collector_2.is_systemd_managed_offline(service_mgr_fact_collector_2)
    return_4 = service_mgr_fact_collector_2.is_systemd_managed_offline(service_mgr_fact_collector_2)

# Generated at 2022-06-25 00:36:48.825281
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed_offline(module = None) == False

if __name__ == '__main__':
    test_case_0()
    test_ServiceMgrFactCollector_is_systemd_managed_offline()

# Generated at 2022-06-25 00:36:50.053134
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    assert callable(ServiceMgrFactCollector.collect)


# Generated at 2022-06-25 00:36:57.201967
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    tmp_module_0 = service_mgr_fact_collector_0.module
    # Unit test for is_systemd_managed_offline, base on service_mgr_fact_collector_0
    tmp_result_0 = tmp_module_0.run_command("ps -p 1 -o comm|tail -n 1", use_unsafe_shell=True)
    # Unit test for method is_systemd_managed of class ServiceMgrFactCollector
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    tmp_module_1 = service_mgr_fact_collector_0.module
    # Unit test for is_systemd_managed, base on service_mgr_fact_collector_0

# Generated at 2022-06-25 00:37:00.296006
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.is_systemd_managed_offline(module=None) == False

test_case_0()

# Generated at 2022-06-25 00:37:02.862957
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed_offline()


# Generated at 2022-06-25 00:37:11.759265
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    import os
    import tempfile

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    tm_file = tempfile.NamedTemporaryFile(dir=tmp_dir)

    # Create a symlink from /sbin/init to tm_file
    os.symlink(tm_file.name, "/sbin/init")

    # Create a ServiceMgrFactCollector object
    smfc = ServiceMgrFactCollector()

    # Assert that is_systemd_managed_offline returns False
    assert not smfc.is_systemd_managed_offline(smfc)

    # Write systemd to tm_file
    with open(tm_file.name, "w") as f:
        f.write("systemd")

    # Assert that

# Generated at 2022-06-25 00:37:16.949155
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed_offline('module')


# Generated at 2022-06-25 00:38:21.501632
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.collect(service_mgr_fact_collector)


# Generated at 2022-06-25 00:38:28.101481
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    module_1 = MagicMock()
    # mock the command
    module_1.get_bin_path.return_value = True
    # mock the command
    os.path.islink.return_value = True
    os.readlink.return_value = 'systemd'
    assert service_mgr_fact_collector_1.is_systemd_managed_offline(module_1)

# Generated at 2022-06-25 00:38:29.854272
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    obj = ServiceMgrFactCollector()
    obj.is_systemd_managed(obj)


# Generated at 2022-06-25 00:38:33.407182
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed()


# Generated at 2022-06-25 00:38:33.813760
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    pass


# Generated at 2022-06-25 00:38:39.028053
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:38:42.946562
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.collect(service_mgr_fact_collector_1)
    assert not var_1


# Generated at 2022-06-25 00:38:49.744624
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    collector = ServiceMgrFactCollector()

    # Test with a mocked module
    class ModuleMock(object):
        def __init__(self, module_name):
            self.module_name = module_name
            self.run_command = ModuleMock.run_command
            self.get_bin_path = ModuleMock.get_bin_path

        @staticmethod
        def run_command(cmd, **kwargs):
            return None, '', ''

        @staticmethod
        def get_bin_path(cmd, **kwargs):
            return None

    module_mock = ModuleMock('test_case_0')
    assert collector.is_systemd_managed(module_mock) is False


# Generated at 2022-06-25 00:38:55.583744
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # arrange
    service_mgr_fact_collector = ServiceMgrFactCollector()
    param = service_mgr_fact_collector
    # act
    var = service_mgr_fact_collector.collect(param)
    # assert
    assert var == {'service_mgr': 'service'}


# Generated at 2022-06-25 00:38:57.857102
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_1)


# Generated at 2022-06-25 00:41:47.827327
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()
    check_var_0 = service_mgr_fact_collector_2.is_systemd_managed_offline(service_mgr_fact_collector_2)


# Generated at 2022-06-25 00:41:54.219958
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.is_systemd_managed


# Generated at 2022-06-25 00:41:58.932654
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.is_systemd_managed_offline()



# Generated at 2022-06-25 00:42:01.370086
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    print(test_case_0.__doc__)
    test_case_0()

# Generated at 2022-06-25 00:42:04.785508
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    var_0 = ServiceMgrFactCollector()
    var_1 = LinuxModule()
    var_0.is_systemd_managed_offline(var_1)

# Generated at 2022-06-25 00:42:10.637172
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    
    # NOTE: this will not work unless you are running Ansible locally as root.
    #       This is just a quick and easy test.  If someone could think of a
    #       better way to test this, please go ahead!
    
    # /run/systemd/system/ exists, so this should return True
    assert service_mgr_fact_collector.is_systemd_managed(module=None)


# Generated at 2022-06-25 00:42:19.898941
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    fact_dict_0 = {}
    fact_dict_1 = {}
    fact_dict_1['ansible_distribution'] = 'MacOSX'
    fact_dict_2 = {}
    fact_dict_2['ansible_system'] = 'AIX'
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()

# Generated at 2022-06-25 00:42:27.508008
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    # Test case where the value of /sbin/init is not 'systemd'
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline('/sbin/init')


# Generated at 2022-06-25 00:42:34.004853
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    print("test_ServiceMgrFactCollector_is_systemd_managed()")
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    print("var_0: " + str(service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)))
    var_1 =  service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)
    assert var_1 == False


# Generated at 2022-06-25 00:42:38.852556
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():

    stub_platform = {
        'mac_ver': (
            '10.12',
            ('', '', ''),
            'x86_64',
            'i386'
        ),
        'system': '',
        'uname': (
            'Darwin',
            '',
            '16.3.0',
            '',
            'Darwin Kernel Version 16.3.0: Thu Nov 17 20:23:58 PST 2016; root:xnu-3789.31.2~1/RELEASE_X86_64',
            '',
            ''
        )
    }

    facts = {
        'platform': 'MacOSX',
        'distribution': 'MacOSX'
    }

    module = type('', (), {})()
    def get_bin_path_mock(bin):
        return