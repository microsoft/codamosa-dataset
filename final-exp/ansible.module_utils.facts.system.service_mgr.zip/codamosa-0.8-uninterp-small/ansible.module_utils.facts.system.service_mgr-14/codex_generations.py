

# Generated at 2022-06-25 00:34:18.544875
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(module=None) == False

# Generated at 2022-06-25 00:34:26.278649
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts import CallableFactCollector

    class ModuleMock:
        def __init__(self, run_command_status, run_command_stdout, run_command_stderr, get_bin_path_return_val):
            self.run_command_status = run_command_status
            self.run_command_stdout = run_command_stdout
            self.run_command_stderr = run_command_stderr
            self.get_bin_path_return_val = get_bin_path_return_val

        def run_command(self, command, check_rc=True, use_unsafe_shell=False):
            return (self.run_command_status, self.run_command_stdout, self.run_command_stderr)


# Generated at 2022-06-25 00:34:37.534940
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-25 00:34:39.969827
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.is_systemd_managed_offline("module") == "False"


# Generated at 2022-06-25 00:34:45.478299
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Initialization
    service_mgr_fact_collector = ServiceMgrFactCollector()
    from ansible.module_utils.facts.collector import get_module_obj
    module = get_module_obj()
    module.get_bin_path = lambda cmd: '/bin/foo'

    # Test is_systemd_managed_offline
    assert service_mgr_fact_collector.is_systemd_managed_offline(module) == False
    os.symlink('systemd', '/sbin/init')
    assert service_mgr_fact_collector.is_systemd_managed_offline(module) == True
    os.unlink('/sbin/init')
    assert service_mgr_fact_collector.is_systemd_managed_offline(module) == False

# Generated at 2022-06-25 00:34:49.371339
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = AnsibleModule(argument_spec=dict())
    assert not service_mgr_fact_collector.is_systemd_managed_offline(module)


# Generated at 2022-06-25 00:34:50.996475
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()


# Generated at 2022-06-25 00:34:56.949651
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    test_case_0()
    smf = ServiceMgrFactCollector()

    class ModuleTest(object):
        @staticmethod
        def get_bin_path(command):
            return '/bin/systemctl'

    assert smf.is_systemd_managed_offline(ModuleTest) is False

    os.symlink('/bin/systemctl', '/sbin/init')
    assert smf.is_systemd_managed_offline(ModuleTest) is True


if __name__ == '__main__':
    test_ServiceMgrFactCollector_is_systemd_managed_offline()

# Generated at 2022-06-25 00:34:58.863608
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    value = service_mgr_fact_collector.is_systemd_managed_offline("")
    assert value == False

# Generated at 2022-06-25 00:35:01.795752
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed() == None


# Generated at 2022-06-25 00:35:19.857415
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    float_0 = 60.0
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(float_0)


# Generated at 2022-06-25 00:35:23.936371
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    float_0 = 89.0
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(float_0)
    print(var_0)

# Generated at 2022-06-25 00:35:25.507115
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:35:30.979419
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    float_0 = 60.0
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(float_0)
    assert var_0 == 0


# Generated at 2022-06-25 00:35:35.171236
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    float_1 = 60.0
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed(float_1)


# Generated at 2022-06-25 00:35:42.569726
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    """
    Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
    """
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # Must return False if '/sbin/init' is not a symlink.
    if os.path.islink('/sbin/init') and os.path.basename(os.readlink('/sbin/init')) == 'systemd':
        return True
    else:
        return False



# Generated at 2022-06-25 00:35:47.891277
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    float_0 = 60.0
    var_1 = service_mgr_fact_collector_0.is_systemd_managed(float_0)


# Generated at 2022-06-25 00:35:51.768093
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Setup arguments for the test function
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()

    # Test is_systemd_managed_offline
    assert not service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_1)
    assert service_mgr_fact_collector_2.is_systemd_managed_offline(service_mgr_fact_collector_1)


# Generated at 2022-06-25 00:35:54.107639
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    collected_facts = {}
    module = None
    service_mgr_fact_collector.collect(module, collected_facts)



# Generated at 2022-06-25 00:35:57.091081
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    float_0 = 60.0
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = ServiceMgrFactCollector.is_systemd_managed(service_mgr_fact_collector_0, float_0)


# Generated at 2022-06-25 00:36:18.902262
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)
    assert var_0 == False


# Generated at 2022-06-25 00:36:24.014843
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)

# Generated at 2022-06-25 00:36:29.107317
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module_0 = AnsibleModule(argument_spec={})
    assert not service_mgr_fact_collector_0.is_systemd_managed_offline(module_0)


# Generated at 2022-06-25 00:36:38.761139
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    # As Mocking is not present for Python 2.7, the following code is only for testing purpose
    # Here, the first argument is self, which is not considered
    var_1 = ServiceMgrFactCollector.is_systemd_managed_offline(service_mgr_fact_collector_1)
    if var_1==False:
        print("The method is_systemd_managed_offline works fine")
    else:
        print("The method is_systemd_managed_offline does not work fine")

# Generated at 2022-06-25 00:36:44.436633
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = platform.system() == 'Linux'
    if var_1:
        pass
    else:
        var_1 = platform.system() == 'SunOS'
    if var_1:
        pass
    else:
        var_1 = service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_1)
    var_2 = not var_1
    return var_2


# Generated at 2022-06-25 00:36:45.751172
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert service_mgr_fact_collector.is_systemd_managed(module) == True


# Generated at 2022-06-25 00:36:50.205583
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var = service_mgr_fact_collector.collect(service_mgr_fact_collector)
    print(var)

if __name__ == "__main__":
    test_ServiceMgrFactCollector_collect()
    #test_case_0()

# Generated at 2022-06-25 00:36:52.571020
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:36:57.017679
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Test with required parameters
    var_0 = ServiceMgrFactCollector()
    var_1 = ServiceMgrFactCollector()
    var_0.service_mgr = var_1
    var_1.name = 'name'
    var_1.required_facts = set()
    var_1.platform = 'platform'
    var_1.distribution = 'distribution'
    var_2 = var_0.collect(var_1)
    assert isinstance(var_2, dict)


# Generated at 2022-06-25 00:36:58.961556
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    var = ServiceMgrFactCollector()
    var_0 = var.collect()
    assert var_0 == {}


# Generated at 2022-06-25 00:37:21.705698
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed(None)


# Generated at 2022-06-25 00:37:26.389585
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    expected_dict_1 = {'service_mgr': 'service'}
    actual_dict_1 = service_mgr_fact_collector_1.collect({'ansible_distribution': 'MacOSX', 'ansible_system': 'Darwin'})
    assert expected_dict_1 == actual_dict_1


# Generated at 2022-06-25 00:37:28.556803
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    assert True



# Generated at 2022-06-25 00:37:30.730509
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # TODO: mock modules for testing
    pass

# Generated at 2022-06-25 00:37:32.648182
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed()


# Generated at 2022-06-25 00:37:41.647851
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()
    collected_facts = {'ansible_facts': {'service_mgr': 'systemd'}}
    assert service_mgr_fact_collector.is_systemd_managed_offline(module=None) == True
    collected_facts = {'ansible_facts': {'service_mgr': 'sysvinit'}}
    assert service_mgr_fact_collector.is_systemd_managed_offline(module=None) == False


# Generated at 2022-06-25 00:37:46.674451
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var = service_mgr_fact_collector.collect()
    service_mgr_name = var['service_mgr']
    print(service_mgr_name)
    assert service_mgr_name == 'systemd'


# Generated at 2022-06-25 00:37:53.181440
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.collect()

# all tests passed
if __name__ == '__main__':
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.collect()
    print(str(service_mgr_fact_collector))

# Generated at 2022-06-25 00:38:01.795679
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    # Create new instance of ServiceMgrFactCollector
    var_0 = ServiceMgrFactCollector()

    # Mock module object
    class MockModule:
        def get_bin_path(arg_0):
            if isinstance(arg_0, str):
                return to_native("/bin/systemctl")

    # Create new instance of AnsibleModule
    module_0 = MockModule()

    # Call method
    var_1 = var_0.is_systemd_managed_offline(var_0, module_0)
    assert var_1 == True

    # Mock module object
    class MockModule:
        def get_bin_path(arg_0):
            if isinstance(arg_0, str):
                return to_native("/bin/foobar_baz_sysctl")

    # Create new instance of Ans

# Generated at 2022-06-25 00:38:07.058389
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)
    assert (var_0 is None)


# Generated at 2022-06-25 00:38:44.660313
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # Test with no module object
    var = service_mgr_fact_collector.collect()
    assert var == {}
    # Test with no collected_facts object
    collected_facts = {}
    var = service_mgr_fact_collector.collect(collected_facts=collected_facts)
    assert var == {}
    # Test with no module and collected_facts objects
    var = service_mgr_fact_collector.collect(collected_facts=collected_facts)
    assert var == {}


# Generated at 2022-06-25 00:38:46.583797
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed()


# Generated at 2022-06-25 00:38:48.554698
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed('')


# Generated at 2022-06-25 00:38:50.827308
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:38:54.329026
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    assert ServiceMgrFactCollector.is_systemd_managed('module_0')


# Generated at 2022-06-25 00:38:57.239343
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    # Test with invalid arguments
    with pytest.raises(TypeError):
        service_mgr_fact_collector_0.is_systemd_managed_offline(module=None,
                                                                 collected_facts=None)


# Generated at 2022-06-25 00:39:00.642569
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    print("Testing is_systemd_managed of class ServiceMgrFactCollector")
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed("sbin/init")

test_case_0()
test_ServiceMgrFactCollector_is_systemd_managed()


# Generated at 2022-06-25 00:39:02.837163
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    import module_utils.facts.system.service_mgr as service_mgr_fact_collector
    method = service_mgr_fact_collector.ServiceMgrFactCollector.is_systemd_managed
    assert callable(method)

# Generated at 2022-06-25 00:39:04.671830
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    assert service_mgr_fact_collector.is_systemd_managed_offline(None) == False


# Generated at 2022-06-25 00:39:07.188599
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # Initialize testcase object.
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    # Invoke the test!
    service_mgr_fact_collector_0.is_systemd_managed_offline(None)

test_case_0()

# Generated at 2022-06-25 00:40:54.031286
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    serviceMgrFactCollector = ServiceMgrFactCollector()
    serviceMgrFactCollector.collect(collected_facts = {'ansible_distribution': 'MacOSX', 'ansible_system': 'Darwin'})
    serviceMgrFactCollector.collect(collected_facts = {'ansible_system': 'FreeBSD'})
    serviceMgrFactCollector.collect(collected_facts = {'ansible_distribution': 'OpenWrt', 'ansible_system': 'Linux'})
    serviceMgrFactCollector.collect(collected_facts = {'ansible_system': 'Linux'})

# Generated at 2022-06-25 00:40:59.992907
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)
    assert var_1 == True


# Generated at 2022-06-25 00:41:00.416085
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:41:02.533339
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0) == False


# Generated at 2022-06-25 00:41:08.190550
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    var = ServiceMgrFactCollector()
    var.collect(var)

# main function for testing this module
if __name__ == '__main__':
    test_ServiceMgrFactCollector_collect()
    test_case_0()

# Generated at 2022-06-25 00:41:13.930441
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    var = service_mgr_fact_collector.collect(service_mgr_fact_collector)



if __name__ == '__main__':
    print ("test_case_0")
    test_case_0()

    test_ServiceMgrFactCollector_collect()

# Generated at 2022-06-25 00:41:18.814899
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed_offline()
    assert var_1 == False


# Generated at 2022-06-25 00:41:20.499206
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_0.is_systemd_managed()


# Generated at 2022-06-25 00:41:23.525557
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)
    assert var_0 == False, 'expected False, got {}'.format(var_0)

# Generated at 2022-06-25 00:41:30.009603
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)
    if var_0:
        print('line: 34, result: %s' % (var_0))
    else:
        print('line: 34, result: %s' % (var_0))
