

# Generated at 2022-06-25 00:34:10.644855
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector_0.is_systemd_managed_offline()

# Generated at 2022-06-25 00:34:18.166032
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    with open('/proc/self/exe', 'r') as f:
        exe = f.read()
    service_mgr_fact_collector_is_systemd_managed = ServiceMgrFactCollector()
    if exe == '/lib/systemd/systemd':
        assert service_mgr_fact_collector_is_systemd_managed.is_systemd_managed() is True
    else:
        assert service_mgr_fact_collector_is_systemd_managed.is_systemd_managed() is False

# Generated at 2022-06-25 00:34:18.997903
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:34:21.435794
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(service_mgr_fact_collector) == False

# Generated at 2022-06-25 00:34:29.268898
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    class TestModule(object):
        def get_bin_path(self, cmd, opt_dirs=[]):
            if cmd == 'systemctl':
                return '/usr/bin/systemctl'

    service_mgr_fact_collector = ServiceMgrFactCollector()
    module = TestModule()

    os.makedirs(os.path.join('/run/systemd/system'))
    assert service_mgr_fact_collector.is_systemd_managed(module) is True
    os.removedirs(os.path.join('/run/systemd/system'))

    os.makedirs(os.path.join('/dev', '.run', 'systemd'))
    assert service_mgr_fact_collector.is_systemd_managed(module) is True
    os.removedirs

# Generated at 2022-06-25 00:34:31.731491
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert False

# Generated at 2022-06-25 00:34:40.001045
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    class MockModule():
        def get_bin_path(self, tool):
            return "/bin/systemctl"
    class MockOS():
        def islink(self, path):
            return path == "/sbin/init"
        def readlink(self, path):
            return "systemd"
        def exists(self, path):
            return path == "/run/systemd/system/" or path == "/dev/.run/systemd/" or path == "/dev/.systemd/" or path == "/sbin/init"
    class MockFile():
        content = "systemd\n"
        def get_file_content(self, path):
            return self.content
    mock_module = MockModule()
    mock_os = MockOS()
    test_dict

# Generated at 2022-06-25 00:34:45.497855
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class _module(object):
        def __init__(self):
            self.check_mode = False
        def run_command(self, cmd, use_unsafe_shell=False):
            # called by is_systemd_managed_offline
            if cmd != "readlink /sbin/init":
                raise Exception("Unexpected command: %s" % cmd)
            return 0, "systemd", None
        def get_bin_path(self, cmd):
            if cmd != "systemctl":
                raise Exception("Unexpected command: %s" % cmd)
            return cmd

    facts = {}
    service_mgr_fact_collector_0 = ServiceMgrFactCollector(module=_module())

# Generated at 2022-06-25 00:34:50.051755
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    assert service_mgr_fact_collector_0.is_systemd_managed_offline(module) == False

# Generated at 2022-06-25 00:34:57.696168
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector

# Generated at 2022-06-25 00:35:12.498982
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_1.collect() == {}

# Generated at 2022-06-25 00:35:19.012095
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # Test case 0 - empty module
    module = None
    assert not service_mgr_fact_collector.is_systemd_managed_offline(module)


# Generated at 2022-06-25 00:35:24.945603
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    module_1 = {}
    os.symlink('systemd', '/sbin/init')
    assert service_mgr_fact_collector_1.is_systemd_managed_offline(module_1) == True
    os.unlink('/sbin/init')


# Generated at 2022-06-25 00:35:30.594867
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # Test 0:
    # When default arguments are provided
    # Running collect should return a dictionary
    assert(isinstance(service_mgr_fact_collector.collect(), dict))

# Generated at 2022-06-25 00:35:35.735052
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()

    class TestModule(object):
        def get_bin_path(self, name):
            return '/bin/' + name

    test_module = TestModule()
    assert service_mgr_fact_collector.is_systemd_managed_offline(test_module)

# Generated at 2022-06-25 00:35:38.451018
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    service_mgr_fact_collector_0.is_systemd_managed()


# Generated at 2022-06-25 00:35:40.752145
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed({}) == False


# Generated at 2022-06-25 00:35:44.215083
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Init ServiceMgrFactCollector
    service_mgr_fact_collector = ServiceMgrFactCollector()
    # Try to collect
    result = service_mgr_fact_collector.collect()

    # Check if returned dict is empty
    assert len(result) == 0


# Generated at 2022-06-25 00:35:46.329130
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    assert ServiceMgrFactCollector.is_systemd_managed_offline(object)

# Generated at 2022-06-25 00:35:48.183892
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector.is_systemd_managed_offline(None)

# Generated at 2022-06-25 00:36:25.283412
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()

    # Unit test for method is_systemd_managed_offline
    # Check the return value for case 1
    os.symlink("/bin/systemd", "/sbin/init")
    assert service_mgr_fact_collector_1.is_systemd_managed_offline(None) == True

# Generated at 2022-06-25 00:36:28.944518
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector_facts = service_mgr_fact_collector.collect()
    assert service_mgr_fact_collector_facts is not None

# Generated at 2022-06-25 00:36:34.948891
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    test_result = service_mgr_fact_collector.collect()
    if 'service_mgr' in test_result:
        assert True
    else:
        assert False


# Generated at 2022-06-25 00:36:39.608212
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    ansible_facts = {
        'ansible_distribution': '',
        'ansible_system': 'Linux'
    }
    results = service_mgr_fact_collector_0.collect(None, ansible_facts)
    assert results['service_mgr'] == 'service'

# Generated at 2022-06-25 00:36:41.827681
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed(None)

# Generated at 2022-06-25 00:36:47.391771
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    '''
    Test systemd_managed() method of class ServiceMgrfactCollector
    '''
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert not service_mgr_fact_collector.is_systemd_managed({})
    assert service_mgr_fact_collector.is_systemd_managed({'get_bin_path': lambda _: '/bin/systemctl'})
    assert not service_mgr_fact_collector.is_systemd_managed({'get_bin_path': lambda _: None})



# Generated at 2022-06-25 00:36:53.456937
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    class MockModule(object):
        def __init__(self, test_file_exists_result=None, test_is_link_result=None):
            self.module_params = dict()
            self.cmd_results = dict()
            self.test_file_exists_result = test_file_exists_result
            self.test_is_link_result = test_is_link_result

        def get_bin_path(self, cmd):
            return self.cmd_results.get(cmd)

        def file_exists(self, path):
            return self.test_file_exists_result

        def is_link(self, path):
            return self.test_is_link_result

        def readlink(self, path):
            return "/sbin/init"

    # Expected result of method is

# Generated at 2022-06-25 00:37:01.499490
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Test case for when /proc/1/comm doesn't exist
    module = ActionModule(argument_spec={})
    os.environ['PATH'] = os.pathsep.join(['/bin', '/usr/bin', '/sbin', '/usr/sbin'])
    os.environ['LANG'] = 'C'
    os.environ['LC_ALL'] = 'C'
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    service_mgr_fact_collector_1.collect(module=module, collected_facts={'ansible_system': 'Linux', 'ansible_distribution': 'CentOS'})
    # Test case for when /proc/1/comm exists, is readable and is a readable file
    module = ActionModule(argument_spec={})
    os.en

# Generated at 2022-06-25 00:37:05.172550
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module = None
    collected_facts = {'ansible_distribution': 'OpenWrt', 'ansible_system': 'Linux'}
    response = service_mgr_fact_collector_0.collect(module, collected_facts)
    assert response == {'service_mgr': 'openwrt_init'}


# Generated at 2022-06-25 00:37:11.537874
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    module = MagicMock()
    module.get_bin_path.return_value = True
    for canary_path in ["/run/systemd/system/", "/dev/.run/systemd/", "/dev/.systemd/"]:
        with patch("os.path.exists", return_value=True) as exists:
            assert ServiceMgrFactCollector.is_systemd_managed(module)
            exists.assert_called_once_with(canary_path)
        exists.reset_mock()

    with patch("os.path.exists", return_value=False) as exists:
        assert not ServiceMgrFactCollector.is_systemd_managed(module)
        exists.assert_called_once_with("/run/systemd/system/")
        exists.reset_mock()
        exists.return_

# Generated at 2022-06-25 00:37:49.064459
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector

    obj = ServiceMgrFactCollector()
    obj.collect(BaseFactCollector())
    obj.collect(Collector())

# Generated at 2022-06-25 00:37:51.653553
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    facts_dict = {}
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.collect(service_mgr_fact_collector,facts_dict)

# Generated at 2022-06-25 00:37:57.327451
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    module = None
    service_mgr_fact_collector_0.is_systemd_managed_offline(module)

# Generated at 2022-06-25 00:38:02.476268
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.is_systemd_managed_offline()


# Generated at 2022-06-25 00:38:04.806875
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
   service_mgr_fact_collector_0 = ServiceMgrFactCollector()
   assert service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0) == False


# Generated at 2022-06-25 00:38:10.381669
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    # FIXME: this test needs to call the real module to get the bin path
    class TestModule:
        def get_bin_path(self, path):
            return True

    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert service_mgr_fact_collector.is_systemd_managed_offline(TestModule) == True



# Generated at 2022-06-25 00:38:13.066192
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_2 = ServiceMgrFactCollector()
    var_2 = service_mgr_fact_collector_2.is_systemd_managed()


# Generated at 2022-06-25 00:38:19.223284
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1)
    assert var_1 is False


# Generated at 2022-06-25 00:38:26.126155
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)
    assert(var_0 == False)


# Generated at 2022-06-25 00:38:31.031882
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    path_0 = {
        'PATH': ':/usr/share/something/bin:/usr/local/something/bin'
    }
    var_0 = service_mgr_fact_collector_0.get_bin_path('systemctl', False, '/sbin', False, path_0)
    assert var_0 == '/sbin/systemctl'



# Generated at 2022-06-25 00:39:53.973224
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:39:54.919745
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    # TODO
    pass

# Generated at 2022-06-25 00:39:59.248234
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    service_mgr_fact_collector = ServiceMgrFactCollector()

    rc, out, err = module.run_command("mv /sbin/init /sbin/init.backup")
    rc, out, err = module.run_command("ln -s /bin/true /sbin/init")
    assert service_mgr_fact_collector.is_systemd_managed_offline(module)

    rc, out, err = module.run_command("rm /sbin/init")
    rc, out, err = module.run_command("mv /sbin/init.backup /sbin/init")
    assert not service_mgr_fact_collector.is_systemd_managed_offline(module)

# Generated at 2022-06-25 00:40:04.643411
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect(service_mgr_fact_collector_0)
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:40:06.516625
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    assert isinstance(service_mgr_fact_collector.collect(service_mgr_fact_collector), dict)


# Generated at 2022-06-25 00:40:12.706552
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed_offline(service_mgr_fact_collector_1)


# Generated at 2022-06-25 00:40:14.699789
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:40:16.794187
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_1 = ServiceMgrFactCollector()
    var_1 = service_mgr_fact_collector_1.is_systemd_managed(service_mgr_fact_collector_1)



# Generated at 2022-06-25 00:40:19.103915
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()

    param_0 = None

    method_0 = service_mgr_fact_collector_0.is_systemd_managed_offline(param_0)


# Generated at 2022-06-25 00:40:23.685502
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.is_systemd_managed()


# Generated at 2022-06-25 00:41:47.607487
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert service_mgr_fact_collector_0.is_systemd_managed_offline(service_mgr_fact_collector_0)


# Generated at 2022-06-25 00:41:51.995098
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    # Example of imported file
    path = '/etc/ansible/facts.d/fake_service_mgr_collector.fact'
    fake_collected_facts = {"ansible_distribution": "MacOSX", "ansible_system": "Darwin"}
    # Example of Command
    var_1 = get_file_content('/etc/ansible/facts.d/fake_service_mgr_collector.fact')
    # Example of Output
    var_2 = {'service_mgr': 'launchd'}

    # Example of Command
    var_3 = get_file_content('/etc/ansible/facts.d/fake_service_mgr_collector.fact')
    # Example of Output
    var_4 = {'service_mgr': 'launchd'}

    # Example of Command
   

# Generated at 2022-06-25 00:41:54.425446
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():
    service_mgr_fact_collector = ServiceMgrFactCollector()
    service_mgr_fact_collector.is_systemd_managed_offline()



# Generated at 2022-06-25 00:41:59.122292
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    assert(service_mgr_fact_collector_0.is_systemd_managed(None) == False)


# Generated at 2022-06-25 00:42:02.747532
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    var_0 = ServiceMgrFactCollector()
    var_0.required_facts={'platform', 'distribution'}
    var_0.name='service_mgr'
    var_0._fact_ids={}
    var_0.collect()


# Generated at 2022-06-25 00:42:08.686648
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    class ModuleStub:
        def get_bin_path(self, *args, **kwargs):
            directory = '/usr/bin'
            executable = '/bin/systemctl'
            return os.path.join(directory, executable)


    module_stub = ModuleStub()

    service_mgr_fact_collector = ServiceMgrFactCollector()

    if os.path.islink('/sbin/init'):
        os.unlink('/sbin/init')

    assert service_mgr_fact_collector.is_systemd_managed_offline(module_stub) == False

    os.symlink('/bin/systemctl', '/sbin/init')

    assert service_mgr_fact_collector.is_systemd_managed_offline(module_stub) == True

# Generated at 2022-06-25 00:42:09.551381
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
  #TODO: add test cases
  pass


# Generated at 2022-06-25 00:42:14.712367
# Unit test for method collect of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_collect():
    service_mgr_fact_collector_0 = ServiceMgrFactCollector()
    var_0 = service_mgr_fact_collector_0.collect()
    var_1 = service_mgr_fact_collector_0.collect()

# Generated at 2022-06-25 00:42:17.453886
# Unit test for method is_systemd_managed of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed():
    c = ServiceMgrFactCollector()
    import ansible.module_utils.facts.test_module_config
    c.module = ansible.module_utils.facts.test_module_config.Mock()
    c.module.get_bin_path = c.module.get_bin_path
    assert c.is_systemd_managed(c.module) == True


# Generated at 2022-06-25 00:42:19.650861
# Unit test for method is_systemd_managed_offline of class ServiceMgrFactCollector
def test_ServiceMgrFactCollector_is_systemd_managed_offline():

    # The first case
    assert ServiceMgrFactCollector.is_systemd_managed_offline(module=None) == False
