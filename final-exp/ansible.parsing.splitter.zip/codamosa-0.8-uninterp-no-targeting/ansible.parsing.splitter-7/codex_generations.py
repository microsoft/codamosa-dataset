

# Generated at 2022-06-20 23:20:12.705071
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c = 3 d = 4") == {u"_raw_params": "a=1 b=2 c = 3 d = 4", u'b': u'2', u'a': u'1', u'c': u'3', u'd': u'4'}
    assert parse_kv("a = 1 b=2 c = 3 d = 4") == {u"_raw_params": "a = 1 b=2 c = 3 d = 4", u'b': u'2', u'a': u'1', u'c': u'3', u'd': u'4'}

# Generated at 2022-06-20 23:20:23.343689
# Unit test for function split_args

# Generated at 2022-06-20 23:20:33.236903
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['a']) == 'a'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', '\nb']) == 'a \nb'
    assert join_args(['a\n', 'b']) == 'a\n b'
    assert join_args(['a\n', 'b', 'c']) == 'a\n b c'
    assert join_args(['a\n', 'b\n', 'c']) == 'a\n b\n c'
    assert join_args(['a\n', 'b\n', 'c', '\nd']) == 'a\n b\n c \nd'

# Generated at 2022-06-20 23:20:43.806493
# Unit test for function parse_kv
def test_parse_kv():
    assert {} == parse_kv(None)
    assert {} == parse_kv('')
    assert {'a': '1', 'b': '2'} == parse_kv('a=1 b=2')
    assert {'a': 'c', 'b': '1', 'c': '2'} == parse_kv('a="c" b=1 c=2')
    assert {'a': '1 2 3', 'b': '2', 'c': '3'} == parse_kv('a="1 2 3" b=2 c=3')
    assert {'a': '1 2 3', 'b': '2', 'c': '3'} == parse_kv("a='1 2 3' b=2 c=3")

# Generated at 2022-06-20 23:20:48.416604
# Unit test for function split_args
def test_split_args():
    # test that bash token delimiters are parsed correctly
    assert split_args('''foo='bar baz'; echo $foo''') == ["foo='bar baz'", "echo", "$foo"]
    assert split_args('''a="b c"; echo $a''') == ["a=\"b c\"", "echo", "$a"]
    assert split_args('''a='b c'; echo $a''') == ["a='b c'", "echo", "$a"]
    assert split_args('''a=b\ c; echo $a''') == ["a=b\\ c", "echo", "$a"]
    assert split_args('''a="b c"; echo \$a''') == ["a=\"b c\"", "echo", "\\$a"]

# Generated at 2022-06-20 23:20:53.041191
# Unit test for function split_args
def test_split_args():
    '''
    test cases for the split_args function
    '''

    def _get_params(args):
        '''
        this function returns exactly what split_args returns
        so that we can test the list of params parsed properly
        '''
        return parse_kv(args)['_raw_params']

    import pytest

    # test basic functionality
    assert _get_params(u'foo') == ['foo']
    assert _get_params(u'foo bar') == ['foo', 'bar']
    assert _get_params(u'') == []

    # test blocks and quotes
    assert _get_params(u"'foo'") == ['\'foo\'']
    assert _get_params(u"foo 'bar'") == ['foo', "'bar'"]

# Generated at 2022-06-20 23:20:57.558726
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a='b c' d=e") == ["a='b c'", 'd=e']
    assert split_args("a='b c' d='e f'") == ["a='b c'", "d='e f'"]
    assert split_args("a=b c='d e' f='g h'") == ['a=b', "c='d e'", "f='g h'"]
    assert split_args("a={{b}} c=d") == ['a={{b}}', 'c=d']
    assert split_args("a='b c' d={{e f}}") == ["a='b c'", 'd={{e f}}']

# Generated at 2022-06-20 23:21:02.694634
# Unit test for function split_args
def test_split_args():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-20 23:21:09.271906
# Unit test for function split_args

# Generated at 2022-06-20 23:21:15.088313
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo']) == 'foo'
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo', '\n', 'bar']) == 'foo\nbar'
    assert join_args(['foo', '\n', 'bar', '\n', 'baz']) == 'foo\nbar\nbaz'



# Generated at 2022-06-20 23:21:31.765074
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing parse_kv")
    values = parse_kv('test=~test2 test3_2=5 test3_1=5 test3_0=5 test3_3=5')
    assert values['test'] == '~test2'
    assert values['test3_2'] == '5'
    assert values['test3_1'] == '5'
    assert values['test3_0'] == '5'
    assert values['test3_3'] == '5'
    assert '_raw_params' not in values

    values = parse_kv('test2="~test2" test3_2=5 test3_1=5 test3_0=5 test3_3=5')
    assert values['test2'] == '~test2'
    assert values['test3_2'] == '5'
   

# Generated at 2022-06-20 23:21:34.616841
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'bar']) == 'echo bar'
    assert join_args(['echo \n', 'bar']) == 'echo \n bar'



# Generated at 2022-06-20 23:21:44.806204
# Unit test for function split_args
def test_split_args():
    '''
    Test function split_args with variety of inputs.
    '''

# Generated at 2022-06-20 23:21:50.981310
# Unit test for function join_args
def test_join_args():
    x = join_args(['foo', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur dictum dignissim justo, quis mattis leo. Integer nec ligula massa', 'bar'])
    assert x == 'foo\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur dictum dignissim justo, quis mattis leo. Integer nec ligula massa bar'
    x = join_args(['foo', 'bar'])
    assert x == 'foo bar'



# Generated at 2022-06-20 23:22:01.277759
# Unit test for function split_args
def test_split_args():
    import pytest


# Generated at 2022-06-20 23:22:07.653528
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo']) == 'foo'
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo\nbar']) == 'foo\nbar'
    assert join_args(['foo bar']) == 'foo bar'
    assert join_args(['foo\nbar', 'foobar']) == 'foo\nbar foobar'



# Generated at 2022-06-20 23:22:11.595038
# Unit test for function join_args
def test_join_args():
    s = ['echo', '1', '2', '3', '\n', 'echo', '4', '5', '6', '\n', 'echo', '7', '8', '9']
    result = join_args(s)
    assert(result == 'echo 1 2 3\necho 4 5 6\necho 7 8 9')



# Generated at 2022-06-20 23:22:17.252915
# Unit test for function split_args
def test_split_args():
    # Test 1: No quotes, no jinja, no nested jinja
    test_string = "a=b c=d e=f"
    result = split_args(test_string)
    assert result == ['a=b', 'c=d', 'e=f']

    # Test 2: No quotes, simple jinja, no nested jinja
    test_string = "a={{b}} c={{d}} e={{f}}"
    result = split_args(test_string)
    assert result == ['a={{b}}', 'c={{d}}', 'e={{f}}']

    # Test 3: No quotes, simple jinja, nested jinja
    test_string = "a={{b}} c={{d}} e={{f {{g}} h}}"
    result = split_args

# Generated at 2022-06-20 23:22:27.234965
# Unit test for function join_args
def test_join_args():
    assert join_args(['a b']) == 'a b'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a ', ' b', '\tc']) == 'a  b \tc'
    assert join_args(['a b\n', ' c']) == 'a b\n c'
    assert join_args(['a', ' ', 'b']) == 'a   b'
    assert join_args(['a b ', '\n c']) == 'a b \n c'
    assert join_args(['a b', '', ' c']) == 'a b  c'

# Generated at 2022-06-20 23:22:36.698321
# Unit test for function split_args
def test_split_args():

    # Test single-quoted strings
    assert(split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"])

    # Test double-quoted strings
    assert(split_args("a=b c='foo bar' d=\"foo bar\"") == ['a=b', "c='foo bar'", "d=\"foo bar\""])

    # Test simple string
    assert(split_args("a=b c=d") == ['a=b', 'c=d'])

    # Test single-quoted string within double quotes
    assert(split_args("a=b c=\"foo 'bar'\"") == ['a=b', "c=\"foo 'bar'\""])

    # Test double-quoted string within single quotes

# Generated at 2022-06-20 23:23:01.537285
# Unit test for function split_args

# Generated at 2022-06-20 23:23:03.311046
# Unit test for function parse_kv
def test_parse_kv():
    print(parse_kv('''name="value1" name2="value2" name3="value3"'''))


# Generated at 2022-06-20 23:23:13.889913
# Unit test for function join_args
def test_join_args():

    cmd = "sed -i 's/^#Port 22/Port 22/g' /etc/ssh/sshd_config"
    assert join_args(split_args(cmd)) == cmd

    cmd = '''sed -i 's/^#Port 22/Port 22/g' /etc/ssh/sshd_config'''
    assert join_args(split_args(cmd)) == cmd

    cmd = '''sed -i "s/^#Port 22/Port 22/g" /etc/ssh/sshd_config'''
    assert join_args(split_args(cmd)) == cmd

    cmd = '''sed -i "s/^#Port 22/Port 22/g" /etc/ssh/sshd_config'''
    assert join_args(split_args(cmd)) == cmd


# Generated at 2022-06-20 23:23:20.456947
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv('k=v') == {'k': 'v'}
    assert parse_kv('k1=v1 k2=v2') == {'k1': 'v1', 'k2': 'v2'}
    assert parse_kv('k1=v1 k2=v2 k3=v3') == {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}
    assert parse_kv('k1=v1 k2=v2 k3=v3', check_raw=True) == {'k1': 'v1', 'k2': 'v2', 'k3': 'v3', '_raw_params': ''}

# Generated at 2022-06-20 23:23:26.918218
# Unit test for function join_args
def test_join_args():
    # test input:
    # line 1
    # line 2
    # line 3
    inp_args = ['\n', 'line', ' ', '1\n', 'line', ' ', '2\n', 'line', ' ', '3']
    # test output:
    # line 1
    # line 2
    # line 3
    expected = '\nline 1\nline 2\nline 3'
    assert expected == join_args(inp_args)



# Generated at 2022-06-20 23:23:34.400402
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\n', 'b\n', 'c']) == 'a\n b\n c'
    assert join_args(['a\n', ' b\n', ' c']) == 'a\n b\n c'
    assert join_args(['a\n', 'b\n', ' c']) == 'a\n b\n c'
    assert join_args(['a', 'b', 'c\n']) == 'a b c\n'



# Generated at 2022-06-20 23:23:39.778965
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['test']) == 'test'
    assert join_args(['test', 'test', 'test']) == 'test test test'
    assert join_args(['test', '\n', 'test']) == 'test\ntest'
    assert join_args(['\n', 'test', '\n']) == '\ntest\n'



# Generated at 2022-06-20 23:23:46.991395
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['arg1']) == 'arg1'
    assert join_args(['arg1', 'arg2', 'arg3']) == 'arg1 arg2 arg3'
    assert join_args(['arg1', 'arg2', '\n', 'arg3']) == 'arg1 arg2\narg3'
    assert join_args(['arg1', 'arg2', '\n', 'arg3', 'arg4']) == 'arg1 arg2\narg3 arg4'
    assert join_args(['arg1', 'arg2', '\n', 'arg3', '\n', 'arg4']) == 'arg1 arg2\narg3\narg4'


# Generated at 2022-06-20 23:23:57.462495
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("this=that") == {"this": "that"}
    assert parse_kv("this='that' and=theother") == {"this": "'that'", "and": "theother"}
    assert parse_kv("this=\"that\" and=theother") == {"this": "\"that\"", "and": "theother"}
    assert parse_kv("this=\"that\" and=theother this=somethingelse") == {"this": "somethingelse", "and": "theother"}
    assert parse_kv("this=\"that and theother\"") == {"this": "\"that and theother\""}
    assert parse_kv("this='that and theother'") == {"this": "'that and theother'"}

# Generated at 2022-06-20 23:24:06.348841
# Unit test for function split_args
def test_split_args():
    args = '\'foo bar\' "hello \'world\'"'
    assert split_args(args) == ['foo bar', 'hello \'world\''], 'failed, simple example'

    args = '\'{{foo_bar}}\''
    assert split_args(args) == ['{{foo_bar}}'], 'failed, simple jinja2 parameter'

    args = '\'{{foo_bar}}\' "hello \'world\'"'
    assert split_args(args) == ['{{foo_bar}}', 'hello \'world\''], 'failed, simple jinja2 parameter and string'

    args = '\'{{foo_bar}}\' "hello \'world\'" \'{{baz}} "qux"\' \'{{quux}}\''

# Generated at 2022-06-20 23:24:15.948952
# Unit test for function join_args
def test_join_args():
    assert join_args(['arg1','arg2','\n']) == 'arg1 arg2\n'



# Generated at 2022-06-20 23:24:23.281131
# Unit test for function join_args
def test_join_args():
    assert join_args(split_args("a b c")) == "a b c"
    assert join_args(split_args("a\n b\nc")) == "a\n b\nc"
    assert join_args(split_args("a 'b c'")) == "a 'b c'"
    assert join_args(split_args('a "b c"')) == 'a "b c"'
    assert join_args(split_args("a '''b c'''")) == "a '''b c'''"
    assert join_args(split_args('a """b c"""')) == 'a """b c"""'


# Generated at 2022-06-20 23:24:25.526864
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', 'b', '\n', 'c', 'd']) == 'a b\nc d'



# Generated at 2022-06-20 23:24:30.301729
# Unit test for function split_args
def test_split_args():
    # Normal case
    test_string = 'a=b c="foo bar"'
    result = split_args(test_string)
    assert result == ['a=b', 'c="foo bar"']

    # Ignore new line continuation
    test_string = 'a=b \\\nc="foo bar"'
    result = split_args(test_string)
    assert result == ['a=b', '\nc="foo bar"']

    # Ignore line continuation in quotes
    test_string = 'a=b \\\\\n c="foo bar"'
    result = split_args(test_string)
    assert result == ['a=b', 'c="foo\\\\\n foo bar"']

    # Ignore two line continuation and with spaces
    test_string = 'a=b \\\n \\\n c="foo bar"'
    result = split_args

# Generated at 2022-06-20 23:24:37.144598
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {'foo': 'bar'}
    assert parse_kv("foo=bar baz=faz") == {'foo': 'bar', 'baz': 'faz'}
    assert parse_kv("foo='bar baz'") == {'foo': 'bar baz'}
    assert parse_kv("foo='bar\\ baz'") == {'foo': 'bar\\ baz'}
    assert parse_kv("foo=\"bar\\ baz\"") == {'foo': 'bar\\ baz'}
    assert parse_kv("foo=bar key=val k2='foo bar'") == {'foo': 'bar', 'key': 'val', 'k2': 'foo bar'}

# Generated at 2022-06-20 23:24:41.467093
# Unit test for function split_args
def test_split_args():
    def assert_list(text, expected):
        result = split_args(text)
        assert result == expected, "split_args(%s) returned: %s. Expected: %s" % (repr(text), result, expected)

    assert_list(u'a=b c="foo bar"', [u'a=b', u'c="foo bar"'])
    assert_list(u'a=b c="foo bar"\nd=e f="foo bar"', [u'a=b', u'c="foo bar"\nd=e', u'f="foo bar"'])
    assert_list(u'a=b c="foo bar"\nd=e f="foo bar"\n', [u'a=b', u'c="foo bar"\nd=e', u'f="foo bar"'])
   

# Generated at 2022-06-20 23:24:48.158347
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo', '', 'bar']) == 'foo  bar'
    assert join_args(['foo', ' ', 'bar']) == 'foo   bar'
    assert join_args(['foo', '\n', 'bar']) == 'foo\nbar'
    assert join_args(['foo', '\nbar']) == 'foo\nbar'



# Generated at 2022-06-20 23:24:58.063319
# Unit test for function split_args

# Generated at 2022-06-20 23:25:08.188520
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('this=that') == {u'this': u'that'}
    assert parse_kv('this="that thing"') == {u'this': u'that thing'}
    assert parse_kv('this=that thing') == {u'this': u'that', u'thing': u''}
    assert parse_kv('this="that thing" thing') == {u'this': u'that thing', u'thing': u''}
    assert parse_kv('this=that other_thing=something-else') == {u'this': u'that', u'other_thing': u'something-else'}
    assert parse_kv('this=that, other_thing="something else"') == {u'this': u'that', u'other_thing': u'something else'}
    assert parse

# Generated at 2022-06-20 23:25:14.820402
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a b ', '\nc']) == 'a b \nc'
    assert join_args(['a', 'b', 'c', '\n']) == 'a b c \n'
    assert join_args(['a', 'b', 'c\n']) == 'a b c\n'



# Generated at 2022-06-20 23:25:28.827867
# Unit test for function parse_kv
def test_parse_kv():
    kv_string = "test=testval test2=testval2"
    assert parse_kv(kv_string) == {'test': 'testval', 'test2': 'testval2'}
    assert parse_kv(kv_string, check_raw=True) == {'test': 'testval', 'test2': 'testval2'}
    assert parse_kv("test=testval _raw_params=test2=testval2") == {'test': 'testval', '_raw_params': 'test2=testval2'}



# Generated at 2022-06-20 23:25:35.442352
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'this=true that=false') == {u'this': u'true', u'that': u'false'}
    assert parse_kv(u'this=true that=false', True) == {u'this': u'true', u'that': u'false'}
    assert parse_kv(u'this=true that=false another') == {u'this': u'true', u'that': u'false'}
    assert parse_kv(u'this=true that=false another', True) == {u'this': u'true', u'that': u'false', u'_raw_params': u'another'}

# Generated at 2022-06-20 23:25:46.556318
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv(u'a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv(u'foo=bar baz=') == {'foo': 'bar', 'baz': ''}
    assert parse_kv(u'foo=bar baz=spam=eggs') == {'foo': 'bar', 'baz': u'spam=eggs'}
    assert parse_kv(u'foo=bar baz="spam=eggs"') == {'foo': 'bar', 'baz': u'spam=eggs'}

# Generated at 2022-06-20 23:25:49.109965
# Unit test for function join_args
def test_join_args():
    s = ['echo', '"\nHello\nWorld\n"']
    assert join_args(s) == 'echo "\nHello\nWorld\n"'



# Generated at 2022-06-20 23:25:56.838161
# Unit test for function join_args
def test_join_args():
    '''
    Unit test for function join_args, it checks some input and output.
    '''
    assert join_args(['a','b','c']) == 'a b c'
    assert join_args(['a b c']) == 'a b c'
    assert join_args(['a \n b \n c']) == 'a \n b \n c'
    assert join_args(['a \n b c']) == 'a \n b c'
    assert join_args(['a \n b \n c']) == 'a \n b \n c'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', 'b', 'c']) == 'a b c'

# Generated at 2022-06-20 23:26:07.846306
# Unit test for function split_args

# Generated at 2022-06-20 23:26:17.097613
# Unit test for function split_args
def test_split_args():
    '''
    test split_args
    '''

# Generated at 2022-06-20 23:26:25.472903
# Unit test for function join_args
def test_join_args():
    assert 'this is a test' == join_args(['this', 'is', 'a', 'test'])
    assert 'this is a test with a newline \nto add' == join_args(['this', 'is', 'a', 'test', 'with', 'a', 'newline \nto', 'add'])
    assert 'this is a test with a newline \n\n\n\n\n to add' == join_args(['this', 'is', 'a', 'test', 'with', 'a', 'newline \n\n\n\n\n', 'to', 'add'])
    assert 'this is a test with a newline \nto add' == join_args(['this', 'is', 'a', 'test', 'with', 'a', 'newline \nto', 'add'])
   

# Generated at 2022-06-20 23:26:34.332196
# Unit test for function join_args
def test_join_args():
    assert join_args(['git clone', '-b 123', '--single-branch',
            'https://github.com/username/repo.git']) == 'git clone -b 123 --single-branch https://github.com/username/repo.git'
    assert join_args(['pip install', '-r requirements.txt',
        '--user', '--upgrade', '"Some project <foo@bar.com>"']) == 'pip install -r requirements.txt --user --upgrade "Some project <foo@bar.com>"'



# Generated at 2022-06-20 23:26:42.595813
# Unit test for function parse_kv

# Generated at 2022-06-20 23:26:58.641435
# Unit test for function split_args
def test_split_args():
    # Test single arg with spaces
    assert split_args("foo bar") == ["foo", "bar"]
    # Test multiple args
    assert split_args("foo bar baz") == ["foo", "bar", "baz"]
    # Test with quotes
    assert split_args("foo bar \"baz bat\"") == ["foo", "bar", "\"baz bat\""]
    # Test with quotes and escaped quotes
    assert split_args("foo bar \"baz \\\"bat\\\"\"") == ["foo", "bar", "\"baz \\\"bat\\\"\""]
    # Test with escaped quotes and no quotes
    assert split_args("foo bar \\\"baz bat\\\"") == ["foo", "bar", "\\\"baz", "bat\\\""]
    # Test with escaped quote at end of string
    assert split_args

# Generated at 2022-06-20 23:27:07.021691
# Unit test for function parse_kv

# Generated at 2022-06-20 23:27:17.703395
# Unit test for function join_args
def test_join_args():
    assert(join_args(['a', '\nb']) == 'a \nb')
    assert(join_args(['a ', '\nb']) == 'a  \nb')
    assert(join_args(['a', '\nb']) == 'a \nb')
    assert(join_args(['a', '\n', 'b']) == 'a \n b')

# For each of the following tests, we must verify that the split_args()
# properly capture both the arguments and the delimiters.
# For example the string "a='b c' d=e" is translated into:
# ['a=', "'b c'", ' d=e']
# Read the test cases from bottom to top.
#
# Test case 3:
# Verify that the open string delimiter for each argument is preserved
#    "a=

# Generated at 2022-06-20 23:27:26.737673
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c', 'd']) == 'a b c d'
    assert join_args(['a=1', 'b=2', 'c=3', 'd=4']) == 'a=1 b=2 c=3 d=4'
    assert join_args(['a="b c d"', 'b=2', 'c=3', 'd=4']) == 'a="b c d" b=2 c=3 d=4'
    assert join_args(['a=1', 'b=2', 'c=3', 'd=4\ne=5']) == 'a=1 b=2 c=3 d=4\ne=5'

# Generated at 2022-06-20 23:27:37.969173
# Unit test for function split_args
def test_split_args():
    assert split_args(None) == [None]
    assert split_args(u'foo bar') == [u'foo', u'bar']
    assert split_args(u'foo    bar') == [u'foo', u'bar']
    assert split_args(u'foo    bar    ') == [u'foo', u'bar']
    assert split_args(u'foo    bar    \n') == [u'foo', u'bar']
    assert split_args(u'foo    bar    \n   foo') == [u'foo', u'bar', '   ', u'foo']
    assert split_args(u'foo    bar    \n   foo   ') == [u'foo', u'bar', '   ', u'foo']

# Generated at 2022-06-20 23:27:47.014603
# Unit test for function split_args
def test_split_args():
    # Lists of tuples for the unit test
    # Tuple is ( input, expected_output )
    wrong_input = [
        ( None, AnsibleParserError ),
        ( 'a=b c="foo bar' , AnsibleParserError ),
    ]


# Generated at 2022-06-20 23:27:53.068226
# Unit test for function split_args
def test_split_args():
    assert split_args('foo=bar') == ['foo=bar']
    assert split_args('foo="bar baz"') == ['foo=bar baz']
    assert split_args('foo="bar \\"baz\\""') == ['foo=bar "baz"']
    assert split_args('foo="bar \'baz\'"') == ['foo=bar \'baz\'']
    assert split_args('foo="bar \'baz\' \\"blurf\\""') == ['foo=bar \'baz\' "blurf"']
    assert split_args('foo=bar \'baz blurf\'') == ['foo=bar', 'baz blurf']
    assert split_args('foo=bar "baz blurf"') == ['foo=bar', 'baz blurf']

# Generated at 2022-06-20 23:28:02.731749
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('creates=/tmp/foo removes=/tmp/bar') == dict(creates='/tmp/foo', removes='/tmp/bar')
    assert parse_kv('''creates=/tmp/foo removes=/tmp/bar 'baz=bang'="'wee'"''') == dict(creates='/tmp/foo', removes='/tmp/bar', baz='bang', wee='')

# For testing parse_kv, initialize an array variable to append each test case
# to as a tuple of args and the expected output of parse_kv
test_parse_kv.arg_lists = []

# Add a test case tuple to the test_parse_kv.arg_lists array

# Generated at 2022-06-20 23:28:10.758890
# Unit test for function join_args
def test_join_args():
    assert join_args(['one']) == 'one'
    assert join_args(['one', 'two']) == 'one two'
    assert join_args(['one\ntwo']) == 'one\ntwo'
    assert join_args(['one\ntwo', 'three']) == 'one\ntwo three'
    assert join_args(['one two', 'three']) == 'one two three'
    assert join_args(['one  two', 'three']) == 'one  two three'
    assert join_args(['one \ntwo', 'three']) == 'one \ntwo three'
    assert join_args(['\none', 'two\n']) == '\none two\n'



# Generated at 2022-06-20 23:28:17.076472
# Unit test for function split_args
def test_split_args():
    """
    Split args cases
    """
    assert split_args('') == ['']
    assert split_args('foo') == ['foo']
    assert split_args('foo\n') == ['foo\n']
    assert split_args('"foo"') == ['"foo"']
    assert split_args('"foo"\n') == ['"foo"\n']
    assert split_args('"foo\n\nbar"\n') == ['"foo\n\nbar"\n']
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b\n') == ['a=b\n']
    assert split_args('a=b c') == ['a=b', 'c']

# Generated at 2022-06-20 23:28:33.623087
# Unit test for function split_args
def test_split_args():
    '''
    Unit tests for function split_args
    '''
    # Basic test
    assert split_args("a=b c=d") == [u"a=b", u"c=d"]
    # Test quotes
    assert split_args("a=b c=\"d e\"") == [u"a=b", u"c=\"d e\""]
    # Test quote stack
    assert split_args("a=b c=\"d 'e'\"") == [u"a=b", u"c=\"d 'e'\""]
    # Test escaping quote stack
    assert split_args("a=b c=\"d \'e\'\"") == [u"a=b", u"c=\"d \'e\'\""]
    # Test escaping quotes in the middle of a string

# Generated at 2022-06-20 23:28:41.781984
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a b', 'c']) == 'a b c'
    assert join_args(['a b', 'c', 'd']) == 'a b c d'
    assert join_args(['a', 'b', 'c d e', 'f']) == 'a b c d e f'
    assert join_args(['a', 'b', ' c ', 'd', 'e', ' f']) == 'a b  c  d e  f'
    assert join_args(['a', 'b', 'c', ' d ', 'e', ' f']) == 'a b c  d  e f'

# Generated at 2022-06-20 23:28:51.643296
# Unit test for function split_args
def test_split_args():
    assert split_args("echo hello world") == ["echo", "hello", "world"]
    assert split_args("a=b c=\"foo bar\"") == ["a=b", "c=\"foo bar\""]
    assert split_args("a=b c=\"foo bar\" d") == ["a=b", "c=\"foo bar\"", "d"]
    assert split_args("command '{\"a\": 1, \"b\": 2}'") == ["command", "'{\"a\": 1, \"b\": 2}'"]
    assert split_args("command \"{\\\"a\\\": 1, \\\"b\\\": 2}\"") == ["command", "\"{\\\"a\\\": 1, \\\"b\\\": 2}\""]
    assert split_args("echo 'hello world'") == ["echo", "'hello world'"]
    assert split

# Generated at 2022-06-20 23:29:01.187808
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar\'s baz"') == ['foo', '"bar\'s baz"']
    assert split_args('foo "bar\\"s baz"') == ['foo', '"bar\\"s baz"']
    assert split_args('foo "bar\\\'s baz"') == ['foo', '"bar\\\'s baz"']
    assert split_args('foo ""') == ['foo', '""']
    assert split_args('foo "\\""') == ['foo', '"\\""']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split

# Generated at 2022-06-20 23:29:11.275053
# Unit test for function split_args
def test_split_args():
    """Test the split_args function"""
    import pprint
    # test that we correctly split on spaces, but not when inside quotes
    assert split_args("a=b c='d e'") == ['a=b', "c='d e'"]

    assert split_args("a=b c={{ d e }}") == ['a=b', "c={{ d e }}"]

    # test that we correctly reassemble blocks and quoted strings
    # that were split on newlines
    assert split_args("a=b\nc={{d\ne}}\nf='g\nh'") == ['a=b', "c={{d\ne}}", "f='g\nh'"]

    # test that we correctly reassemble jinja2 blocks and quoted strings
    # that were split on newlines, but strip out things that look

# Generated at 2022-06-20 23:29:20.510307
# Unit test for function parse_kv

# Generated at 2022-06-20 23:29:33.000437
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=foo') == {'foo': 'bar', 'baz': 'foo'}
    assert parse_kv('foo=bar baz=foo', True) == {u'foo': 'bar', u'baz': 'foo'}
    assert parse_kv('foo=bar baz=foo check_raw=False') == {u'foo': 'bar', u'baz': 'foo', u'check_raw': 'False'}
    assert parse_kv('foo=bar baz=foo check_raw=False', True) == {u'foo': 'bar', u'baz': 'foo', u'check_raw': 'False'}