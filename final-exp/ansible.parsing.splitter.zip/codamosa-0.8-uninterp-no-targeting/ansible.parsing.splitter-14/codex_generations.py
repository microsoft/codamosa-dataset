

# Generated at 2022-06-20 23:20:09.272494
# Unit test for function join_args
def test_join_args():
    assert join_args(split_args('one\n"two"\nthree')) == 'one\n"two"\nthree'
    assert join_args(split_args('"one two"')) == '"one two"'



# Generated at 2022-06-20 23:20:17.103996
# Unit test for function join_args
def test_join_args():
    s = ["echo", "foo", "bar", "baz", "qux", "quux", "corge",
         "grault", "garply", "waldo", "fred", "plugh", "xyzzy",
         "thud", "hello, world", "goodbye", "cruel", "world",
         "!!!"]

    result = join_args(s)

    assert result == ("echo foo bar baz qux quux corge grault garply waldo fred plugh xyzzy thud hello, world goodbye cruel world !!!")



# Generated at 2022-06-20 23:20:25.260138
# Unit test for function parse_kv
def test_parse_kv():

    # All returned dictionaries should look this way:
    assert_dict = dict([
        ('a', '1'),
        ('b', '2'),
        ('c', '3'),
        ('d', '4'),
        ('e', '5'),
        ('f', '6'),
        ('g', '7'),
        ('h', '8'),
        ('i', '9'),
        ('j', '10'),
        ('_raw_params', u'a=b c=d \\e=f "g=h" \'i=j\''),
    ])

    # Test basic parsing
    assert parse_kv('a=b c=d \\e=f "g=h" \'i=j\'') == assert_dict

    # Test parsing with a list/tuple as input

# Generated at 2022-06-20 23:20:35.336930
# Unit test for function parse_kv
def test_parse_kv():
    # Test handling of equals signs in values, and values containing spaces.
    assert parse_kv(u"a=b c='d e' f=\"g=h\" i=\"j k\" l=m n=o p=q\"rs\" t=u v='w x' y=\"z a\"") == {
        u'a': u'b', u'c': u'd e', u'f': u'g=h', u'i': u'j k', u'l': u'm', u'n': u'o',
        u'p': u'q"rs"', u't': u'u', u'v': u'w x', u'y': u'z a',
    }

    # Test that raw params are correctly exctracted

# Generated at 2022-06-20 23:20:45.290195
# Unit test for function split_args

# Generated at 2022-06-20 23:20:47.279018
# Unit test for function join_args
def test_join_args():
    t = ['echo -n hello', 'echo world']
    assert(join_args(t) == 'echo -n hello\necho world')



# Generated at 2022-06-20 23:20:52.190504
# Unit test for function split_args

# Generated at 2022-06-20 23:21:02.470728
# Unit test for function parse_kv
def test_parse_kv():
    # test basic parsing
    args = u'k1=v1 k2="v2" k3=v3 k4="v4 with spaces"'
    options = parse_kv(args)
    assert type(options) is dict
    assert len(options) == 4
    assert options['k1'] == u'v1'
    assert options['k2'] == u'v2'
    assert options['k3'] == u'v3'
    assert options['k4'] == u'v4 with spaces'

    # test raw parameter detection
    args = u'k1=v1 k2="v2" k3=v3 k4="v4 with spaces" creates="/tmp/test" /usr/bin/whoami'
    options = parse_kv(args, check_raw=True)
    assert type(options) is dict

# Generated at 2022-06-20 23:21:09.270478
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b") == {'a': 'b'}
    assert parse_kv("a=b c=d") == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=''") == {'a': ''}
    assert parse_kv("a='' b=''") == {'a': '', 'b': ''}
    assert parse_kv("a='' b=d") == {'a': '', 'b': 'd'}
    assert parse_kv("a='aaa' b='bbb'") == {'a': 'aaa', 'b': 'bbb'}

# Generated at 2022-06-20 23:21:20.292765
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b "c d"') == ['a=b', '"c d"']
    assert split_args('a=b \'c d\'') == ['a=b', '\'c d\'']
    assert split_args('a=b "c\nd"') == ['a=b', '"c\nd"']
    assert split_args('a=b "c \nd"') == ['a=b', '"c \nd"']
    assert split_args('a=b "c \\nd"') == ['a=b', '"c \\nd"']

    assert split_args("a\\=c") == ['a\\=c']
    assert split_args("a=\\\"c\\\"") == ['a=\\"c\\"']


# Generated at 2022-06-20 23:21:45.406917
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("one=foo") == {'one': 'foo'}
    assert parse_kv("one=foo two=bar") == {'one': 'foo', 'two': 'bar'}
    assert parse_kv("one='foo bar' two=bar three='four=five'") == {'one': 'foo bar', 'two': 'bar', 'three': 'four=five'}
    assert parse_kv("one='foo bar' two=bar three='four=five' four='six'") == {'one': 'foo bar', 'two': 'bar', 'three': 'four=five', 'four': 'six'}

# Generated at 2022-06-20 23:21:50.383112
# Unit test for function join_args
def test_join_args():
    print(join_args(["one", "two", "three"]))
    print(join_args(["one=two", "three=four", "five=six"]))
    print(join_args(["one=two", "three=four", "five=six", "seven", "eight=nine"]))
    print(join_args(["one\n=two", "three=four\n", "five=six\n", "seven", "eight=nine"]))



# Generated at 2022-06-20 23:22:00.053061
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Unit test for function parse_kv
    '''
    print("")
    print("Running unit test on function parse_kv")

    import sys
    sys.argv.append("")
    sys.argv.append("--extra-vars")

    import ansible.module_utils.basic
    execute_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={
        },
        supports_check_mode=True
    ).exit_json


# Generated at 2022-06-20 23:22:11.109092
# Unit test for function parse_kv
def test_parse_kv():
    print("Running test_parse_kv")
    
    assert parse_kv("test_key=test_value", True) == {'test_key': 'test_value'}
    assert parse_kv("test_key='test value'", True) == {'test_key': 'test value'}
    assert parse_kv("test_key=test_value test_key2=test_value2", True) == {'test_key': 'test_value', 'test_key2': 'test_value2'}
    assert parse_kv(None, True) == {}
    assert parse_kv("", True) == {}
    assert parse_kv("test_key = test_value", True) == {'test_key': 'test_value'}

# Generated at 2022-06-20 23:22:16.960146
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("=") == dict()

    assert parse_kv("foo=bar") == dict(foo=u'bar')
    assert parse_kv("foo=bar=baz=glarch") == dict(foo=u'bar=baz=glarch')
    assert parse_kv("foo=bar b=glarch") == dict(foo=u'bar', b=u'glarch')
    assert parse_kv("foo='bar baz'") == dict(foo=u'bar baz')
    assert parse_kv("foo=\"bar baz\"") == dict(foo=u'bar baz')
    assert parse_kv("foo=\"bar \\\"baz\\\" glarch\"") == dict(foo=u'bar "baz" glarch')

# Generated at 2022-06-20 23:22:24.225004
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo\nbar']) == 'foo\nbar'
    assert join_args(['foo', 'bar\n', 'foo', 'bar']) == 'foo bar\nfoo bar'
    assert join_args(['foo\n', 'bar\n', 'foo', 'bar']) == 'foo\nbar\nfoo bar'
    assert join_args(['foo\n', 'bar', 'bar\n', 'foo']) == 'foo\nbar bar\nfoo'



# Generated at 2022-06-20 23:22:34.400692
# Unit test for function join_args
def test_join_args():
    result1 = join_args(['a', 'b', 'c'])
    assert result1 == 'a b c'
    result2 = join_args(['a', 'b', '\n'])
    assert result2 == 'a b '
    result3 = join_args(['a', 'b', '\n\n'])
    assert result3 == 'a b '
    result4 = join_args(['a', 'b', '\n\n\n'])
    assert result4 == 'a b '
    result5 = join_args(['a', 'b', '\n\n', '\n\n'])
    assert result5 == 'a b '
    result6 = join_args(['a', 'b', '\n\n', '\n\n', '\n\n'])
   

# Generated at 2022-06-20 23:22:45.975305
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ e }}') == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}']
    assert split_args('a=b c="foo bar" d={{ e }} f="g {{ h }}"') == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}', 'f="g {{ h }}"']
    assert split_args('a=b c="foo bar" d={{ e }} f="g\n{{ h }}"') == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}', 'f="g', '{{ h }}"']

# Generated at 2022-06-20 23:22:55.742953
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['a']) == 'a'
    assert join_args(['a', 'b c', 'd']) == 'a b c d'
    assert join_args(['a b', 'c', 'd']) == 'a b c d'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', 'b c', 'd', 'e']) == 'a b c d e'
    assert join_args(['a', 'b c', 'd', 'e', 'f f']) == 'a b c d e f f'

# Generated at 2022-06-20 23:22:57.970071
# Unit test for function join_args
def test_join_args():
    s = 'a b c\nd e f'
    result = join_args(split_args(s))
    if result != s:
        raise AssertionError("Split/join does not retain original string")



# Generated at 2022-06-20 23:23:10.812815
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test parse_kv function
    '''
    # FIXME
    pass

# Generated at 2022-06-20 23:23:19.134748
# Unit test for function parse_kv
def test_parse_kv():
    test1 = u"key=value key2=value2 key3=value3"
    test2 = u"key='value' key2=\"value2\" key3=value3"
    assert parse_kv(test1) == {u'key3': u'value3', u'key': u'value', u'key2': u'value2'}
    assert parse_kv(test2) == {u'key3': u'value3', u'key': u'value', u'key2': u'value2'}

    test3 = u"key1=value1 key2='va\"lue2' key3=\"va'lue3\" key4=nested\\ key\\=nested\\ value"

# Generated at 2022-06-20 23:23:29.860312
# Unit test for function parse_kv
def test_parse_kv():
    args = parse_kv('yum -q -y update; /usr/bin/uptime', check_raw=True)
    assert args['_raw_params'] == 'yum -q -y update; /usr/bin/uptime'
    args = parse_kv('-e something', check_raw=True)
    assert args['_raw_params'] == ''
    args = parse_kv('-e key=value', check_raw=True)
    assert args['key'] == 'value'
    args = parse_kv('-e key="value"', check_raw=True)
    assert args['key'] == 'value'
    args = parse_kv('-e key="value with spaces"', check_raw=True)
    assert args['key'] == 'value with spaces'
    args = parse_kv

# Generated at 2022-06-20 23:23:40.031380
# Unit test for function split_args

# Generated at 2022-06-20 23:23:47.551989
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', '\nb', 'c']) == 'a\nb c'
    assert join_args(['a', '\n', 'b', 'c']) == 'a\n b c'
    assert join_args(['a', '\n', 'b', 'c', '\n']) == 'a\n b c\n'
    assert join_args(['a', '\n', 'b', 'c', '\n', 'd', '\n', 'e']) == \
        'a\n b c\n d\n e'

# Generated at 2022-06-20 23:23:57.803866
# Unit test for function parse_kv
def test_parse_kv():
    print("*************** parsing kv")
    print(parse_kv("foo=bar"))
    print("")
    print(parse_kv("foo=bar ralph=fred"))
    print("")
    print(parse_kv("foo=bar ralph=fred  "))
    print("")
    print(parse_kv("foo=''"))
    print("")
    print(parse_kv("foo="""))
    print("")
    print(parse_kv("foo='a''b'  "))
    print("")
    print(parse_kv("foo=\"a\"\"b\"  "))
    print("")
    print(parse_kv("foo=\"a\"\"b\"  bar='a''b'"))
    print("")

# Generated at 2022-06-20 23:24:06.609901
# Unit test for function join_args
def test_join_args():
    # the following examples are from the original implementation of join_args()
    assert join_args(['foo', 'bar baz', '"one two three"', '"facebook \"the social network\""']) == 'foo bar baz "one two three" "facebook \"the social network\""'
    assert join_args(['foo', 'bar baz', '"one two three"', 'one\ntwo three']) == 'foo bar baz "one two three" one\ntwo three'
    assert join_args(['foo', 'bar baz', '"one two three"', 'one\n two three']) == 'foo bar baz "one two three" one\n two three'

# Generated at 2022-06-20 23:24:15.813602
# Unit test for function parse_kv
def test_parse_kv():
    r = parse_kv("foo='bar baz' fizzy=true ver=1.0.0 number=123")

    assert r == dict(foo=u"bar baz", fizzy=u"true", ver=u"1.0.0", number=u"123")

    r = parse_kv("foo='bar baz' name=fizzy number=123")

    assert r == dict(foo=u"bar baz", name=u"fizzy", number=u"123")

    r = parse_kv("user=\"$(whoami)\"")

    assert r == dict(user="$(whoami)")

    r = parse_kv("user=\"$(whoami)\" creates=\"/tmp/foo\"")

    assert r == dict(user="$(whoami)", creates="/tmp/foo")

    r

# Generated at 2022-06-20 23:24:24.698628
# Unit test for function join_args
def test_join_args():
    # Test1
    test1 = ['ls', '-l', '-a']
    assert(join_args(test1) == 'ls -l -a')
    # Test2
    test2 = ['echo', 'a=b', 'c=d', 'e=f']
    assert(join_args(test2) == 'echo a=b c=d e=f')
    # Test3
    test3 = ['ls', '-l', '-a', '-F']
    assert(join_args(test3) == 'ls -l -a -F')
    # Test4
    test4 = ['ls', '-l', '-a\n', '-F']
    assert(join_args(test4) == 'ls -l -a\n-F')
    # Test5

# Generated at 2022-06-20 23:24:32.057881
# Unit test for function parse_kv

# Generated at 2022-06-20 23:24:43.699228
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args(u'bar') == ['bar']
    assert split_args('a=b') == ['a=b']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a=b c="d e"') == ['a=b', 'c="d e"']
    assert split_args('a="b c" d=e') == ['a="b c"', 'd=e']
    assert split_args('a="b c" d="e f"') == ['a="b c"', 'd="e f"']
    assert split_args('a="b c" d=e f="g h"') == ['a="b c"', 'd=e', 'f="g h"']
   

# Generated at 2022-06-20 23:24:54.659265
# Unit test for function split_args
def test_split_args():
    '''
    Tests the split_args() function with a variety of arguments and input strings.
    '''

# Generated at 2022-06-20 23:25:05.638731
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b") == {'a': 'b'}
    assert parse_kv("a=1 b='2' c=\"foo bar\"") == {'a': '1', 'b': '2', 'c': 'foo bar'}
    assert parse_kv("a='foo''bar' c=\"foo\"\"bar\"") == {'a': "foo'bar", 'c': 'foobar'}
    assert parse_kv("creates=foo a=1") == {'creates': 'foo', 'a': '1'}
    assert parse_kv("a=b,c=d") == {'a': 'b,c=d'}

# Generated at 2022-06-20 23:25:11.996278
# Unit test for function join_args

# Generated at 2022-06-20 23:25:22.762469
# Unit test for function parse_kv

# Generated at 2022-06-20 23:25:31.616049
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\n', 'b']) == 'a\n b'
    assert join_args(['a\n', 'b', '\nc']) == 'a\n b \nc'
    assert join_args(['a']) == 'a'
    assert join_args(['a\n']) == 'a\n'
    assert join_args(['a', '\n', 'b']) == 'a \n b'
    assert join_args(['a b', '\nc']) == 'a b \nc'
    assert join_args(['a\n', 'b', 'c']) == 'a\n b c'

# Generated at 2022-06-20 23:25:37.383999
# Unit test for function split_args
def test_split_args():
    """This unit test uses the Python unittest module.

    To run the test, run this module as a script. The test output
    will be printed to stdout.
    """
    import unittest
    class TestParseKV(unittest.TestCase):
        ''' Unit tests for parse_kv function '''

# Generated at 2022-06-20 23:25:46.636956
# Unit test for function join_args
def test_join_args():
    cases = [
        (
            ['a', 'b', 'c'],
            'a b c'
        ),
        (
            ['a', 'b', ' ', 'c'],
            'a b   c'
        ),
        (
            ['a', 'b', '\n', 'c'],
            'a b\n c'
        ),
        (
            ['a', 'b', '\n', 'c', ' '],
            'a b\n c '
        )
    ]
    for test_case in cases:
        result = join_args(test_case[0])
        assert result == test_case[1]



# Generated at 2022-06-20 23:25:53.600090
# Unit test for function join_args
def test_join_args():
    # Empty list
    assert join_args([]) == ''

    # List with one element
    assert join_args(['cmd']) == 'cmd'

    # Simple list
    assert join_args(['foo', 'bar']) == 'foo bar'

    # List with newline
    assert join_args(['foo', 'bar\n', 'baz']) == 'foo bar\n baz'

    # List with leading newline
    assert join_args(['\nfoo', 'bar\n', 'baz']) == '\nfoo bar\n baz'



# Generated at 2022-06-20 23:26:03.550939
# Unit test for function parse_kv
def test_parse_kv():
    test_dict = {'test1a': 'foo', 'test2a': 'bar', 'test5a': 'baz', '_raw_params': 'test1b=foo test2b=bar test3b test4b=spam="with teapot" test5b=baz'}
    assert parse_kv("test1a=foo test2a=bar test1b=foo test2b=bar test3b test4b=spam=\"with teapot\" test5a=baz test5b=baz", True) == test_dict
    test_dict = {'hello': 'world', '_raw_params': 'foo="bar baz"', 'foobar': 'foo'}
    assert parse_kv("hello=world foobar=foo foo=\"bar baz\"", True) == test_dict
    test

# Generated at 2022-06-20 23:26:14.461167
# Unit test for function split_args
def test_split_args():
    tests = ['foo', 'foo "bar baz"', 'foo="bar baz"', 'foo="bar baz\\"bad"']
    for arg in tests:
        assert split_args(arg) == arg.split(" ")

# Generated at 2022-06-20 23:26:16.502871
# Unit test for function join_args
def test_join_args():
    inp = split_args(r'''
a b \
c d
''')
    assert join_args(inp) == r'''
a b c d
'''



# Generated at 2022-06-20 23:26:24.896726
# Unit test for function parse_kv
def test_parse_kv():
    # Test that parse_kv works properly with var=val args
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u' a=1 b=2 c=3 ') == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv(u'a=1\\=2=3') == {u'a': u'1=2=3'}

    # Test that parse_kv works properly with mixed args
    assert parse_kv(u'a=1 b=2 c') == {u'a': u'1', u'b': u'2', u'_raw_params': u'c'}

# Generated at 2022-06-20 23:26:36.317934
# Unit test for function split_args

# Generated at 2022-06-20 23:26:44.016938
# Unit test for function join_args
def test_join_args():
    assert join_args(['a b']) == 'a b'
    assert join_args(['a b', 'c d']) == 'a b c d'
    assert join_args(['a b', '', 'c d']) == 'a b\n\nc d'
    assert join_args(['a b', '', 'c d', 'e f']) == 'a b\n\nc d e f'
    assert join_args(['a b', '', '', 'e f']) == 'a b\n\n\ne f'
    assert join_args(['a b', '', '', 'e f', 'g h']) == 'a b\n\n\ne f g h'
    assert join_args(['a b', '\n', '\n', 'e f', 'g h'])

# Generated at 2022-06-20 23:26:46.924314
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\nb']) == 'a\nb'


# Generated at 2022-06-20 23:26:56.577147
# Unit test for function join_args
def test_join_args():
    assert join_args(['first', 'second', 'third']) == 'first second third'
    assert join_args(['first', '\nsecond', 'third']) == 'first\nsecond third'
    assert join_args(['first\n', 'second', 'third']) == 'first\nsecond third'
    assert join_args(['first\n', ' second', 'third']) == 'first\n second third'
    assert join_args(['first\n', ' \nsecond', 'third']) == 'first\n \nsecond third'
    assert join_args(['first\n', '\nsecond', 'third']) == 'first\n\nsecond third'
    assert join_args(['first', 'second', '\nthird']) == 'first second\nthird'



# Generated at 2022-06-20 23:27:05.510981
# Unit test for function split_args

# Generated at 2022-06-20 23:27:07.108329
# Unit test for function join_args
def test_join_args():
    assert join_args(['1', '2', '\n3', '4']) == '1 2\n3 4'


# Generated at 2022-06-20 23:27:17.748875
# Unit test for function split_args

# Generated at 2022-06-20 23:27:56.042158
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("arg1=1 arg2=2 arg3=3") == {"arg1": "1", "arg2": "2", "arg3": "3"}
    assert parse_kv("a=b c=d e=f") == {"a": "b", "c": "d", "e": "f"}
    assert parse_kv("a=b c=d e=f") == {"a": "b", "c": "d", "e": "f"}
    assert parse_kv("a=b") == {"a": "b"}
    assert parse_kv("arg1=1 arg2='2' arg3=3") == {"arg1": "1", "arg2": "2", "arg3": "3"}

# Generated at 2022-06-20 23:28:01.845646
# Unit test for function split_args
def test_split_args():
    # Define test cases
    testing_set = [
        ("a='foo bar' b={{ result }}", ['a=\'foo bar\'', 'b={{ result }}'])
    ]


    for test_case in testing_set:
        args = test_case[0]
        result = test_case[1]
        assert split_args(args) == result


# Generated at 2022-06-20 23:28:03.007070
# Unit test for function split_args
def test_split_args():
    # no tests
    pass

# Generated at 2022-06-20 23:28:11.570214
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar baz=quux") == {u'baz': u'quux', u'foo': u'bar'}
    assert parse_kv("foo=bar baz") == {u'_raw_params': u'baz', u'foo': u'bar'}
    assert parse_kv("foo") == {u'_raw_params': u'foo'}
    assert parse_kv(None) == {}
    assert parse_kv(u"foo='bar'", check_raw=True) == {u'foo': u'bar'}

# Generated at 2022-06-20 23:28:13.511031
# Unit test for function join_args
def test_join_args():
    assert join_args(['-m', 'shell', '-a', '"/sbin/reboot"']) == '-m shell -a "/sbin/reboot"'



# Generated at 2022-06-20 23:28:25.064412
# Unit test for function parse_kv
def test_parse_kv():
    # Test parsing of normal parameters
    data = parse_kv('ansible_port=22')
    assert len(data) == 1
    assert data['ansible_port'] == '22'

    # Test parsing of multiple parameters
    data = parse_kv('ansible_port=22 other_var=foo')
    assert len(data) == 2
    assert data['ansible_port'] == '22'
    assert data['other_var'] == 'foo'

    # Test parsing of multiple parameters with a raw parameter
    data = parse_kv('ansible_port=22 other_var=foo echo "this should be a raw_param"')
    assert len(data) == 3
    assert data['ansible_port'] == '22'
    assert data['other_var'] == 'foo'

# Generated at 2022-06-20 23:28:34.060616
# Unit test for function join_args
def test_join_args():
    assert 'woot' == join_args(['woot'])
    assert 'woot\n' == join_args(['woot', '\n'])
    assert '/tmp/foo.txt' == join_args(['/tmp/foo.txt'])
    assert 'woot\n/tmp/foo.txt' == join_args(['woot', '\n', '/tmp/foo.txt'])
    assert 'woot /tmp/foo.txt' == join_args(['woot', ' ', '/tmp/foo.txt'])
    assert '"woot /tmp/foo.txt"' == join_args(['"woot', ' ', '/tmp/foo.txt"'])

# Generated at 2022-06-20 23:28:39.331080
# Unit test for function join_args
def test_join_args():
    assert join_args(['ansible', '-m', 'ping', 'test']) == 'ansible -m ping test'
    assert join_args(['ansible', '-m', 'ping', 'test', 'arg1']) == 'ansible -m ping test arg1'
    assert join_args(['ansible', '-m', 'ping', 'test', 'arg1', 'arg2']) == 'ansible -m ping test arg1 arg2'



# Generated at 2022-06-20 23:28:48.588317
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {"a": "1", "b": "2"}
    assert parse_kv('a=1 b="2 with spaces"') == {"a": "1", "b": "2 with spaces"}
    assert parse_kv('a=1 b="2=with=equals"') == {"a": "1", "b": "2=with=equals"}
    assert parse_kv('a=1 b="2=with=equals" c=3') == {"a": "1", "b": "2=with=equals", "c": "3"}
    assert parse_kv('a=1 b="2=with=equals" c="3 4"') == {"a": "1", "b": "2=with=equals", "c": "3 4"}


# Generated at 2022-06-20 23:28:58.680749
# Unit test for function split_args
def test_split_args():
    def split_and_join(input):
        return join_args(split_args(input))

    # Actual unit tests below
    assert split_and_join("a b") == "a b"
    assert split_and_join("a=b c=d") == "a=b c=d"
    assert split_and_join("a=b c=d\ne=f") == "a=b c=d\ne=f"
    assert split_and_join("a=b c=d\ne=f\n") == "a=b c=d\ne=f\n"
    assert split_and_join("a=b c=d\ne=f\n ") == "a=b c=d\ne=f\n "