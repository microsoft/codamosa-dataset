

# Generated at 2022-06-20 23:20:13.439795
# Unit test for function join_args
def test_join_args():
    '''
    test the join_args() function
    '''
    req_str = ('/bin/mkdir dir1\n'
               '\n'
               ' /bin/mkdir dir2\n'
               '/bin/mkdir dir3\n'
               '\n'
               '/bin/mkdir dir4\n'
               '$HOME/bin/mkdir dir5\n'
               '\n'
               '$HOME/bin/mkdir dir6\n')
    # split the req_str string into pieces
    pieces = req_str.split()
    # reassemble the pieces with join_args()
    t_str = join_args(pieces)
    assert req_str == t_str, "join_args() failed to reassemble the string after it was split"
test_join_args()

# Generated at 2022-06-20 23:20:22.809445
# Unit test for function parse_kv

# Generated at 2022-06-20 23:20:33.072865
# Unit test for function parse_kv
def test_parse_kv():
    x = '''k1=v1 k2=v2 "k3 = v3" "k4= v4" k5=v5 "k6=v6" k7=v7 "k8 = v8" "k9= v9"'''

# Generated at 2022-06-20 23:20:43.614610
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c=3") == {"a": "1", "b": "2", "c": "3"}
    assert parse_kv("a=hello world b=2 c=3") == {"a": "hello world", "b": "2", "c": "3"}
    assert parse_kv("a=hello\\=world b=2 c=3") == {"a": "hello\\=world", "b": "2", "c": "3"}
    assert parse_kv("a=hello=world b=2 c=3") == {"a": "hello=world", "b": "2", "c": "3"}

# Generated at 2022-06-20 23:20:54.332659
# Unit test for function join_args
def test_join_args():
    assert join_args(['arg1', 'arg2', 'arg3']) == 'arg1 arg2 arg3'
    assert join_args(['arg1', 'arg2', 'arg3', '\n']) == 'arg1 arg2 arg3\n'
    assert join_args(['arg1', 'arg2', 'arg3', '\n', '\n']) == 'arg1 arg2 arg3\n\n'
    assert join_args(['arg1', 'arg2', 'arg3', '\n', '\n', 'arg4']) == 'arg1 arg2 arg3\n\narg4'

# Generated at 2022-06-20 23:20:58.131036
# Unit test for function join_args
def test_join_args():
    test_str = 'a\n b\n  c\n   d'
    expected = 'a\n b\n  c\n   d'
    assert join_args(split_args(test_str)) == to_text(expected, errors='surrogate_or_strict')



# Generated at 2022-06-20 23:21:06.776217
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d e=f') == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert parse_kv('a=b "c=d" e=f') == {'a': 'b', 'c=d': None,
                                         'e': 'f'}
    assert parse_kv('a=b c="d" e=f') == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert parse_kv('a=b c=d e="f"') == {'a': 'b', 'c': 'd', 'e': 'f'}

# Generated at 2022-06-20 23:21:16.359223
# Unit test for function split_args
def test_split_args():
    """Check parsed args from shell module"""
    from ansible.module_utils.six import assertCountEqual
    import ansible.module_utils.basic
    import ansible.module_utils.six as six

    # split_args, if not passed as unicode, should fail without warnings
    def _fails_on_non_unicode():
        """Check that split_args() on bytes fails"""
        try:
            ansible.module_utils.basic.split_args(six.b('foo bar'))
        except (AnsibleParserError, TypeError):
            return True
        return False

    assert(_fails_on_non_unicode())
    assert(not _fails_on_non_unicode())

    # Check invalid combinations in case we need to fix and test

# Generated at 2022-06-20 23:21:24.850691
# Unit test for function join_args
def test_join_args():
    assert join_args(['one', 'two']) == "one two"
    assert join_args(['one\ntwo']) == "one\ntwo"
    assert join_args(['one', '\n', 'two']) == "one\ntwo"
    assert join_args(['one\ntwo', 'three']) == "one\ntwo three"
    assert join_args(['one=two', 'three']) == "one=two three"
    assert join_args(['one', 'two=three']) == "one two=three"



# Generated at 2022-06-20 23:21:31.366391
# Unit test for function parse_kv
def test_parse_kv():
    d = parse_kv('creates=/tmp/foo removes=/tmp/bar')
    assert d[u'creates'] == '/tmp/foo'
    assert d[u'removes'] == '/tmp/bar'
    assert '_raw_params' not in d

    d = parse_kv('creates=/tmp/foo removes=/tmp/bar arg1 arg2')
    assert d[u'creates'] == '/tmp/foo'
    assert d[u'removes'] == '/tmp/bar'
    assert d[u'_raw_params'] == 'arg1 arg2'

    d = parse_kv('creates=/tmp/foo removes=/tmp/bar arg1 arg2', check_raw=False)
    assert d[u'creates'] == '/tmp/foo'

# Generated at 2022-06-20 23:21:48.753165
# Unit test for function split_args
def test_split_args():
    args = '''a b="c d"
e=f
g "h i"'''

    # Tests from the docstring
    assert split_args('a b="c d"\ne=f') == ['a', 'b="c d"', 'e=f']
    assert split_args('g "h i"') == ['g', '"h i"']

    assert split_args('a="b" c="d"') == ['a="b"', 'c="d"']

    # Escaping quotes
    assert split_args('a="b\"c\"" d="e\\"f"') == ['a="b"c""', 'd="e"f"']

    # Simple quotes inside quotes
    assert split_args('a="b c"') == ['a="b c"']

    # Escaping blocks

# Generated at 2022-06-20 23:21:51.155820
# Unit test for function join_args
def test_join_args():
    s = ['foo', 'bar', 'baz']
    assert join_args(s) == 'foo bar baz'

    s = ['foo', '\n', 'bar', 'baz']
    assert join_args(s) == 'foo\nbar baz'



# Generated at 2022-06-20 23:22:01.713530
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("d e='foo bar' f=5") == ['d', "e='foo bar'", 'f=5']
    assert split_args("d e='foo bar' f=5\n") == ['d', "e='foo bar'", 'f=5']
    assert split_args("g 'h i' j=k") == ['g', "'h i'", 'j=k']
    assert split_args("l 'h i'\n") == ['l', "'h i'"]
    assert split_args("{{ ds }}") == ['{{ ds }}']

# Generated at 2022-06-20 23:22:11.791248
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\nb', 'c\nd']) == 'a\nb c\nd'
    assert join_args(['\n', 'a\n']) == '\na\n'
    assert join_args(['\n', 'a\nb']) == '\na\nb'
    assert join_args(['\n', 'a\nb\n']) == '\na\nb\n'
    assert join_args(['a\n', 'b\n']) == 'a\nb\n'
    assert join_args(['a\n', 'b\n', 'c']) == 'a\nb\nc'
    assert join_args(['a\n', 'b\n', 'c\n'])

# Generated at 2022-06-20 23:22:23.500599
# Unit test for function split_args
def test_split_args():
    def _check(input_data, expected_output):
        assert expected_output == split_args(input_data)

    _check('--extra-vars "a=b"', ['--extra-vars', '"a=b"'])
    _check('--extra-vars "a={{b}}"', ['--extra-vars', '"a={{b}}"'])
    _check('--extra-vars "a={{b}} c=d"', ['--extra-vars', '"a={{b}} c=d"'])
    _check('--extra-vars "a=\"b\""', ['--extra-vars', '"a=\"b\""'])

# Generated at 2022-06-20 23:22:33.453674
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=3 b=4") == {'a':'3', 'b':'4'}
    assert parse_kv("a=3 b=4") == {'a':'3', 'b':'4'}
    assert parse_kv("a=3= b=4") == {'a':'3=', 'b':'4'}
    assert parse_kv("a=\"3= b\"=4") == {'a':'3= b', '"=4':None}
    # This should really throw an error
    assert parse_kv("a=3 b=4 c='5 d'") == {'a':'3', 'b':'4', 'c':'5 d'}

# Generated at 2022-06-20 23:22:38.406525
# Unit test for function join_args
def test_join_args():
    assert join_args(['asdf', 'fdsa']) == 'asdf fdsa'
    assert join_args(['a\nsdf', 'fdsa']) == 'a\nsdf fdsa'
    assert join_args(['asdf', '\nfd\nsa']) == 'asdf \nfd\nsa'
    assert join_args(['asdf', 'f\n\nda']) == 'asdf f\n\nda'



# Generated at 2022-06-20 23:22:49.295753
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.compat.tests import unittest
    from ansible.module_utils._text import to_bytes

    class TestParseKV(unittest.TestCase):
        def setUp(self):
            # Set up basic inputs and outputs
            self.simple_input = u'a=1 b="two three" c=@/etc/hosts d=w\\ x\ny\tz'
            self.simple_output = {u'a': u'1', u'b': u'two three', u'c': u'@/etc/hosts', u'd': u'w x\ny\tz'}
            self.multi_input = u'a=b=c=d'
            self.multi_output = {u'a': u'b=c=d'}
            self.spaces_input = u

# Generated at 2022-06-20 23:22:57.703936
# Unit test for function split_args
def test_split_args():
    file_object = open("testfiles/split_args_testfile.txt", 'r')
    for line in file_object:
        stripped_line = line.strip()
        # Proceed only if line is not empty or starts with #
        if (len(stripped_line) == 0 or stripped_line[0] == '#'):
            continue
        (input_value, processed_values) = stripped_line.split("|")
        expected_values = processed_values.split(" ")
        # remove leading and trailing space in input value
        input_value = input_value.strip()
        output_value = split_args(input_value)
        assert(output_value == expected_values)
    file_object.close()



# Generated at 2022-06-20 23:23:07.233128
# Unit test for function split_args

# Generated at 2022-06-20 23:23:28.546555
# Unit test for function parse_kv
def test_parse_kv():
    def compare(str, d):
        parsed = parse_kv(str)
        if parsed != d:
            print("ERROR: parsing %s should have returned %s, but got %s" % (str, d, parsed))
            raise Exception('test failure')
    compare(u'spam=eggs', {u'spam': u'eggs'})
    compare(u'spam="scrambled eggs"', {u'spam': u'scrambled eggs'})
    compare(u'spam="scrambled eggs" ham=green', {u'spam': u'scrambled eggs', u'ham': u'green'})
    compare(u'spam=\'bare eggs\' ham=green', {u'spam': u'bare eggs', u'ham': u'green'})

# Generated at 2022-06-20 23:23:33.122537
# Unit test for function join_args
def test_join_args():
    s = ['foo\n', 'bar\n', 'baz', ' qux']
    assert join_args(s) == 'foo\nbar\nbaz qux'
    s = ['foo', 'bar', 'baz', 'qux']
    assert join_args(s) == 'foo bar baz qux'



# Generated at 2022-06-20 23:23:42.787735
# Unit test for function split_args
def test_split_args():
    assert(split_args("a=b c=d e={{f={{g=h i=j}}}}") == ['a=b', 'c=d', 'e={{f={{g=h', 'i=j}}}}'])
    assert(split_args("a=b c=d e={{f=\"{{g=h i=j}}\"}}") == ['a=b', 'c=d', 'e={{f="{{g=h', 'i=j}}"}}'])

# Generated at 2022-06-20 23:23:51.811312
# Unit test for function split_args
def test_split_args():
    def wrap(s):
        return (s, split_args(s))


# Generated at 2022-06-20 23:23:55.297887
# Unit test for function join_args
def test_join_args():
    assert join_args(split_args('1 \n2 3 "4 5"')) == '1 \n2 3 "4 5"'
    assert join_args(split_args('1 \n2 "3 "4" 5"')) == '1 \n2 "3 "4" 5"'



# Generated at 2022-06-20 23:24:00.539828
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\n', 'b', 'c']) == 'a\nb c'
    assert join_args(['a\n', 'b\n', 'c']) == 'a\nb\nc'



# Generated at 2022-06-20 23:24:08.084973
# Unit test for function split_args

# Generated at 2022-06-20 23:24:16.760527
# Unit test for function parse_kv
def test_parse_kv():
    # Note: function split_args() is tested in test_split_args()
    # Note: function parse_kv() is not tested directly.
    # Note: function join_args() is tested in test_join_args()
    # This is a somewhat indirect test, but it seems to work, using the 'shell' or 'command' module.
    from ansible.modules.shell_plugins import Command # module used to be named 'shell'
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-20 23:24:25.593273
# Unit test for function join_args
def test_join_args():
    '''
    Test that the original list can be reconstructed.
    '''
    s = ['"a b', 'c"', 'd', 'e']
    assert join_args(s) == '"a b c" d e'
    s = ['{{a', 'b', 'c}}', 'd', 'e']
    assert join_args(s) == '{{a b c}} d e'
    s = ['{{a', 'b', 'c}}', 'd', '{{e', 'f', 'g}}']
    assert join_args(s) == '{{a b c}} d {{e f g}}'
    s = ['a', 'b', '"c\n', 'd"', 'e', 'f']
    assert join_args(s) == 'a b "c\n d" e f'



# Generated at 2022-06-20 23:24:32.809098
# Unit test for function parse_kv
def test_parse_kv():
    """
    For coverage and to try to figure out how to test it.
    :return:
    """
    # Some unit tests
    # http://docs.pytest.org/en/latest/assert.html
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import pytest

    def assert_decode(encoded, expected):
        assert _decode_escapes(encoded) == expected

    assert_decode(u"Hello, world!", u"Hello, world!")
    assert_decode(u'I say "hi."', u'I say "hi."')
    assert_decode(u'I say "hi."\n', u'I say "hi."\n')
    assert_decode(u'I say "hi."\\n', u'I say "hi."\\n')


# Generated at 2022-06-20 23:24:50.378636
# Unit test for function parse_kv

# Generated at 2022-06-20 23:25:00.135859
# Unit test for function join_args
def test_join_args():
    '''Test function join_args'''
    mycommand = u'foo \nbar'
    assert join_args(['foo ', 'bar']) == mycommand
    mycommand = u'foo -a "foo bar" bar'
    assert join_args(['foo ', '-a ', 'foo bar', ' bar']) == mycommand
    mycommand = u'foo -a "foo bar" bar'
    assert join_args(['foo ', '-a ', 'foo bar ', ' bar']) == mycommand
    mycommand = u'foo \nbar \\n "foo bar"'
    assert join_args(['foo ', '\n', 'bar \\n ', 'foo bar']) == mycommand



# Generated at 2022-06-20 23:25:09.321985
# Unit test for function split_args
def test_split_args():
    # Test a simple case
    assert split_args("foo bar") == ["foo", "bar"]
    # Test with a quoted argument
    assert split_args('foo "bar baz"') == ["foo", '"bar baz"']
    # Test with a quoted argument containing spaces and single quotes
    assert split_args("foo 'bar' 'baz qux'") == ["foo", "'bar'", "'baz qux'"]
    # Test with a single quoted argument containing spaces and double quotes
    assert split_args("foo 'bar baz'") == ["foo", "'bar baz'"]
    # Test with a single quoted argument containing spaces and double quotes
    assert split_args("foo 'bar \"baz\"'") == ["foo", "'bar \"baz\"'"]
    # Test with an escaped argument

# Generated at 2022-06-20 23:25:20.026904
# Unit test for function parse_kv
def test_parse_kv():
    # basic sanity
    assert parse_kv('a=b') == {u'a': u'b'}
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}

    # unicode
    assert parse_kv(u'ab=cd') == {u'ab': u'cd'}
    assert parse_kv(u'ab=cd ef=gh') == {u'ab': u'cd', u'ef': u'gh'}
    assert parse_kv(u'ab=c\u1234d ef=gh') == {u'ab': u'c\u1234d', u'ef': u'gh'}

    # escapes

# Generated at 2022-06-20 23:25:29.644021
# Unit test for function split_args
def test_split_args():
    args = """a=b c=\"foo bar\" d="foo\"bar" e='foo\'bar' f=\\'bar g='foo\\\"bar\\' h=\\'foo bar i="foo\\\"bar\\\\"""
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"', 'd="foo\\"bar"', "e='foo\\'bar'", "f=\\'bar", "g='foo\\\"bar\\'", "h=\\'foo bar", 'i="foo\\\"bar\\\\']
    params = split_args("\"a b\" c=\"d e\"")
    assert params == ['"a b"', 'c="d e"']
    params = split_args("\"a\\\"b\\\"c\" d=\"e f\"")

# Generated at 2022-06-20 23:25:41.599259
# Unit test for function join_args
def test_join_args():
    assert(join_args(['   ']) == '   ')
    assert(join_args(['\n']) == '\n')
    assert(join_args(['\n', '\n']) == '\n\n')
    assert(join_args(['a']) == 'a')
    assert(join_args(['a', 'b']) == 'a b')
    assert(join_args(['a', ' b']) == 'a  b')
    assert(join_args(['a', ' ', 'b']) == 'a   b')
    assert(join_args(['a', '\n', 'b']) == 'a\nb')
    assert(join_args(['a', '   ', 'b']) == 'a   b')


# Generated at 2022-06-20 23:25:51.756362
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing parse_kv()")

# Generated at 2022-06-20 23:25:58.152518
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b') == {'a': 'b'}
    assert parse_kv('a=b\nc=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c = d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c = d  e =   f') == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert parse_kv('a=b\nc=d e = f') == {'a': 'b', 'e': 'f', 'c': 'd'}
    assert parse_kv

# Generated at 2022-06-20 23:26:08.972689
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar spam=eggs') == {'foo': 'bar', 'spam': 'eggs'}
    assert parse_kv('foo="bar baz" spam=eggs') == {'foo': 'bar baz', 'spam': 'eggs'}
    assert parse_kv('foo=bar spam="eggs bacon"') == {'foo': 'bar', 'spam': 'eggs bacon'}
    assert parse_kv('foo=bar spam=eggs bacon') == {'foo': 'bar', 'spam': 'eggs', '_raw_params': 'bacon'}
    assert parse_kv('foo=bar spam=eggs bacon=ham') == {'foo': 'bar', 'spam': 'eggs', '_raw_params': 'bacon=ham'}


# Generated at 2022-06-20 23:26:17.718388
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {
        "a": "b",
        "c": "d",
    }
    assert parse_kv("a='b c' d=e") == {
        "a": "b c",
        "d": "e",
    }
    assert parse_kv("a='b c' d=e f g") == {
        "a": "b c",
        "d": "e",
        "_raw_params": "f g",
    }
    assert parse_kv("a=/bin/echo -n x=y") == {
        "a": "/bin/echo -n x=y",
    }

# Generated at 2022-06-20 23:26:35.199358
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo="bar baz"') == {u'foo': u'bar baz'}
    assert parse_kv('one=1 two=2 three=3 four=4') == {u'four': u'4', u'three': u'3', u'one': u'1', u'two': u'2'}
    assert parse_kv('one=1 two=2,three=3,four=4') == {u'four': u'4', u'three': u'3', u'one': u'1', u'two': u'2'}

# Generated at 2022-06-20 23:26:43.183497
# Unit test for function join_args
def test_join_args():
    '''
    Ensure the join_args() fn works as expected.
    This will catch any unintended side-effects of split_args().
    '''

# Generated at 2022-06-20 23:26:53.102819
# Unit test for function join_args
def test_join_args():
    """
    Test join_args()
    """
    assert join_args(["foo", "bar"]) == "foo bar"
    assert join_args(["foo bar"]) == "foo bar"
    assert join_args(["foo", "bar "]) == "foo bar "
    assert join_args(["foo", "bar ", "baz"]) == "foo bar  baz"
    assert join_args(["foo", "\nbar ", "baz"]) == "foo \nbar  baz"
    assert join_args(["foo", " bar ", "baz"]) == "foo  bar  baz"


# Quoting adapted from http://stackoverflow.com/questions/296536/how-to-get-a-list-of-command-line-arguments-in-python

# Generated at 2022-06-20 23:27:02.561597
# Unit test for function join_args
def test_join_args():
    assert join_args(['a b']) == 'a b'
    assert join_args(['a b', 'c d']) == 'a b c d'
    assert join_args(['a b', '', 'c d']) == 'a b\nc d'
    assert join_args(['a b', '\n', 'c d']) == 'a b\n\nc d'
    assert join_args(['a b', '\n   ', 'c d']) == 'a b\n   c d'
    assert join_args(['a b', '\n\n', 'c d']) == 'a b\n\n\nc d'
    assert join_args(['a b', '\n\n\n', 'c d']) == 'a b\n\n\n\nc d'


# Generated at 2022-06-20 23:27:05.324129
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo']) == 'echo'
    assert join_args(['echo','hello world']) == 'echo hello world'
    assert join_args(['echo hello','world']) == 'echo hello\nworld'
    assert join_args(['echo', 'hello', 'world']) == 'echo hello\nworld'


# Generated at 2022-06-20 23:27:10.553892
# Unit test for function split_args

# Generated at 2022-06-20 23:27:21.028788
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz') == {u'foo': u'bar', u'_raw_params': u'baz'}
    assert parse_kv("foo='bar bar' baz") == {u'foo': u'bar bar', u'_raw_params': u'baz'}
    assert parse_kv("foo='bar=baz' baz") == {u'foo': u'bar=baz', u'_raw_params': u'baz'}
    assert parse_kv("foo=\'bar=baz\' baz") == {u'foo': u'bar=baz', u'_raw_params': u'baz'}
    assert parse_kv("foo=bar='bar baz'") == {u'foo': u'bar=bar baz'}
   

# Generated at 2022-06-20 23:27:28.688044
# Unit test for function join_args

# Generated at 2022-06-20 23:27:40.672882
# Unit test for function join_args
def test_join_args():
    from ansible.module_utils._text import to_text
    result = join_args(["a", "b", "c"])
    assert result == "a b c"
    result = join_args(["a", "\nb", "c"])
    assert result == "a\nb c"
    result = join_args(["a", "\n\nb", "c"])
    assert result == "a\n\nb c"
    result = join_args(["a", "\n\n\nb", "c"])
    assert result == "a\n\n\nb c"
    result = join_args(["a", "b", "c", "\nd", "\ne"])
    assert result == "a b c\nd\ne"

# Generated at 2022-06-20 23:27:48.730460
# Unit test for function split_args
def test_split_args():

    def do_test(args, expected):
        actual = join_args(split_args(args))
        assert actual == expected

    do_test(u"a=b c=d", u"a=b c=d")
    do_test(u"a=b 'c=d e f'", u"a=b 'c=d e f'")
    do_test(u"a=b 'c=d \"e f\"'", u"a=b 'c=d \"e f\"'")
    do_test(u"a=b c='d e f'", u"a=b c='d e f'")
    do_test(u"a=b c='\"d e f\"'", u"a=b c='\"d e f\"'")

# Generated at 2022-06-20 23:28:05.295936
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b') == {u'a': u'b'}
    assert parse_kv(' "a"=b') == {u'a': u'b'}
    assert parse_kv(" 'a'=b") == {u'a': u'b'}
    assert parse_kv(" a='b'") == {u'a': u'b'}
    assert parse_kv(" a=\"b\"") == {u'a': u'b'}
    assert parse_kv(" a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv(" a=\"b c\"") == {u'a': u'b c'}

# Generated at 2022-06-20 23:28:13.606619
# Unit test for function split_args
def test_split_args():
    '''
    Test ansible.playbook.play_context.split_args
    '''
    import ansible.playbook.play_context

# Generated at 2022-06-20 23:28:17.363414
# Unit test for function join_args
def test_join_args():
    assert join_args(['cmd0\n', 'cmd1\n', 'cmd2']) == 'cmd0\n cmd1\n cmd2'



# Generated at 2022-06-20 23:28:27.189688
# Unit test for function split_args
def test_split_args():
    print()
    print('Testing split_args with the following data')
    print()

# Generated at 2022-06-20 23:28:29.186881
# Unit test for function join_args
def test_join_args():
    inp = ['foo', 'bar']
    outp = join_args(inp)
    assert outp == 'foo bar'


# Generated at 2022-06-20 23:28:37.948348
# Unit test for function split_args
def test_split_args():
    sample_args1 = '''a=b c="foo bar"'''
    result1 = ['a=b', 'c="foo bar"']
    assert split_args(sample_args1) == result1

    sample_args2 = '''a=b c="foo bar"'''
    result2 = ['a=b', 'c="foo bar"']
    assert split_args(sample_args2) == result2

    sample_args3 = '''a=b c="foo bar\\ "'''
    result3 = ['a=b', 'c="foo bar\\ "']
    assert split_args(sample_args3) == result3

    sample_args4 = '''a=b c="foo bar\\ ""'''
    result4 = ['a=b', 'c="foo bar\\ "']

# Generated at 2022-06-20 23:28:39.725836
# Unit test for function join_args
def test_join_args():
    assert join_args(['arg1', 'arg2', 'arg3']) == 'arg1 arg2 arg3'



# Generated at 2022-06-20 23:28:48.230224
# Unit test for function parse_kv
def test_parse_kv():
    parse_kv('a=b')
    parse_kv('a')
    parse_kv('a="b b"')
    parse_kv('a="b\\tb"')
    parse_kv('a="b\\nb"')
    parse_kv('a=b\'b"b')
    parse_kv('a="b\'b"b"')
    parse_kv('a="b\'b"b"')
    parse_kv('a=b\'b"b c=d e=\'f"g h\'i j"k l="m n"o p')
    parse_kv('a=b c=d e=\'f"g h\'i j"k l="m n"o p')



# Generated at 2022-06-20 23:28:57.850194
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('A=B C="D" E="F G" H="I J" K=L') == dict(A='B', C='D', E='F G', H='I J', K='L')
    assert parse_kv("A=B'C D' E='F G' H=\"I J\" K=L") == dict(A="B'C D'", E="'F G'", H='I J', K='L')
    assert parse_kv("A=B'C D' E=\"F G\" H='I J' K=L") == dict(A="B'C D'", E='F G', H="'I J'", K='L')

# Generated at 2022-06-20 23:29:01.985223
# Unit test for function join_args
def test_join_args():
    s = ['echo', 'a b', 'c d', 'e\nf g', 'h\ni\n', 'j', '\nk\n']
    result = join_args(s)
    assert result == u"echo a b c d e\nf g h\ni\nj\nk\n"


# Generated at 2022-06-20 23:29:17.987730
# Unit test for function join_args
def test_join_args():
    p = ['echo one', '', '\necho two']
    assert join_args(p) == 'echo one\necho two'
    assert join_args(['\n']) == '\n'
    assert join_args(['\necho "one two three"']) == '\necho "one two three"'


# Generated at 2022-06-20 23:29:27.221138
# Unit test for function parse_kv
def test_parse_kv():
    # test for parse_kv function
    assert parse_kv("key=value") == {"key": "value"}
    assert parse_kv("key=value with spaces") == {"key": "value with spaces"}
    assert parse_kv("key = value") == {"key": "value"}
    assert parse_kv("key    =    value") == {"key": "value"}
    assert parse_kv("key=value with spaces=another_value") == {"key": "value with spaces=another_value"}

