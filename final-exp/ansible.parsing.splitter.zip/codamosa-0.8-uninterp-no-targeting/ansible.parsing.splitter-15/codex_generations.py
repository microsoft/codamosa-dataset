

# Generated at 2022-06-20 23:20:59.933794
# Unit test for function join_args
def test_join_args():
    assert join_args(['a b c', 'd e f']) == 'a b c d e f'
    assert join_args(['a b c\n', 'd e f']) == 'a b c\nd e f'
    assert join_args(['a b c\n', '"d e f']) == 'a b c\n"d e f'
    assert join_args(['a b c\n', '"d e f\n']) == 'a b c\n"d e f\n'



# Generated at 2022-06-20 23:21:05.176932
# Unit test for function split_args
def test_split_args():
    import json

# Generated at 2022-06-20 23:21:10.448397
# Unit test for function join_args
def test_join_args():
    test_param = ['-v', '-i', 'myhosts', '-m', 'command', '-a', 'uptime']
    assert(join_args(test_param) == '-v -i myhosts -m command -a uptime')
    test_param = ['-v', '-i', 'myhosts', '-m', 'command', '-a', 'uptime', '\n']
    assert(join_args(test_param) == '-v -i myhosts -m command -a uptime\n')
    test_param = ['-v', '-i', 'myhosts', '\n', '-m', 'command', '-a', 'uptime', '\n']

# Generated at 2022-06-20 23:21:16.762938
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', '\n', 'b']) == 'a \nb'
    assert join_args(['a', '\n', 'b', '\n', '   c']) == 'a \nb \n   c'
    assert join_args(['a', 'b', '\n', 'c']) == 'a b \nc'
    assert join_args([]) == ''



# Generated at 2022-06-20 23:21:27.000761
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('key1=val1') == {u'key1': u'val1'}
    assert parse_kv('key1=val1 key2=val2') == {u'key1': u'val1', u'key2': u'val2'}
    assert parse_kv('key1=val1 key2=val2 key2=val2') == {u'key1': u'val1', u'key2': u'val2'}
    assert parse_kv('key1=val1 key2=val2 key2=val2 key3') == {u'key1': u'val1', u'key2': u'val2', u'_raw_params': u'key3'}

# Generated at 2022-06-20 23:21:32.350141
# Unit test for function parse_kv
def test_parse_kv():
  assert parse_kv("k1=v1 k2=v2") == {"k1": "v1", "k2": "v2"}
  assert parse_kv("k1=v1 k2=v2") == {"k1": "v1", "k2": "v2"}
  assert parse_kv("k1='a=b' k2=v2") == {"k1": "a=b", "k2": "v2"}
  assert parse_kv("k1='a=b' k2='c=d'") == {"k1": "a=b", "k2": "c=d"}

# Generated at 2022-06-20 23:21:42.778376
# Unit test for function parse_kv
def test_parse_kv():
    import json
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=bat') == {u'foo': u'bar', u'baz': u'bat'}
    assert parse_kv('foo=bar "baz = bat"') == {u'foo': u'bar', u'baz = bat': u''}
    assert parse_kv('foo=bar "baz = bat" fizzle=wizzle') == {u'foo': u'bar', u'baz = bat': u'', u'fizzle': u'wizzle'}
    assert parse_kv('foo baz=bat fizzle') == {u'_raw_params': u'foo baz=bat fizzle'}

# Generated at 2022-06-20 23:21:47.198622
# Unit test for function join_args
def test_join_args():
    # Test join_args with an argument - a newline in string.
    assert join_args(['a', 'b', '\n', 'c']) == "a b \nc"
    # Test join_args with an argument - no newline in string.
    assert join_args(['a', 'b', 'c']) == "a b c"



# Generated at 2022-06-20 23:21:54.790033
# Unit test for function parse_kv
def test_parse_kv():
    # Setup a tests dict
    tests = dict()

    # Test 1: basic test
    tests['-m ping -f'] = dict(
        args='-m ping -f',
        kwargs=dict(
            check_raw=False
        ),
        expected=dict(
            m='ping',
            f=''
        )
    )

    # Test 2: check_raw test
    tests['-m ping -f'] = dict(
        args='-m ping -f',
        kwargs=dict(
            check_raw=True
        ),
        expected=dict(
            m='ping',
            f='',
            _raw_params='-m ping -f'
        )
    )

    # Test 3: basic test with quotes

# Generated at 2022-06-20 23:22:06.342718
# Unit test for function parse_kv
def test_parse_kv():
    def test(in_val, out_val):
        assert parse_kv(in_val) == out_val

    test('a=b', {'a': 'b'})
    test('"a=b"', {'a=b': ''})
    test('a="b c"', {'a': 'b c'})
    test('"a"="b c"', {'a': 'b c'})
    test('a=b c=d "a=b b=c"', {'a': 'b', 'c': 'd', '_raw_params': '"a=b b=c"'})

# Generated at 2022-06-20 23:22:33.453192
# Unit test for function split_args
def test_split_args():
    def _test_eq(test_data):
        for _test_data in test_data:
            if len(_test_data) == 2:
                _input, _result = _test_data
                _input = ' '.join(_input)
                _result = ' '.join(_result)
            else:
                _input, _result, _error = _test_data
            try:
                _output = ' '.join(split_args(_input))
                assert _output == _result
            except Exception as e:
                if _error is None:
                    raise
                assert str(e) == _error, '%r != %r' % (str(e), _error)


# Generated at 2022-06-20 23:22:40.605059
# Unit test for function parse_kv
def test_parse_kv():
    test_data = {
             'usebackq': '''a=b c=d''',
             'backslash': '''a=b\\ c=d''',
             'equal': '''a= b= c=''',
             'comma': '''a=b,c=d''',
             'slash': '''a=b\\c=d''',
             'quote': '''a="b c d" e='f g h' i="j 'k' l"''',
             'quote_equal': '''a="b c=d e"''',
             'empty': 'a=""',
    }


# Generated at 2022-06-20 23:22:46.402960
# Unit test for function join_args
def test_join_args():
    assert(join_args(["First", "sentence"]) == "First sentence")
    assert(join_args(["First \n", "sentence"]) == "First \nsentence")
    assert(join_args(["First", "\n", "sentence"]) == "First\nsentence")
    assert(join_args(["First", "\nsentence"]) == "First\nsentence")



# Generated at 2022-06-20 23:22:56.109964
# Unit test for function split_args
def test_split_args():
    # empty string should work
    assert split_args('') == []

    # verify basic whitespace splits
    assert split_args('a b') == ['a', 'b']

    # newlines should work
    assert split_args('a b\n c') == ['a', 'b\n', 'c']

    # basic quoting should work to prevent whitespace split
    assert split_args('a "b c"') == ['a', '"b c"']

    # basic jinja2 should work to prevent whitespace split
    assert split_args('a {{ b }}') == ['a', '{{', 'b', '}}']

    # jinja2 mixed with quotes should work
    assert split_args('a {{ "b c" }}') == ['a', '{{', '"b c"', '}}']

    # quotes mixed with j

# Generated at 2022-06-20 23:23:01.908763
# Unit test for function split_args
def test_split_args():
    '''
    Unit test function designed to verify the functionality of split_args().
    '''
    def _compare(s):
        '''
        Compares output from split_args() to the original string,
        but in list format instead of a string
        '''
        l = split_args(s)
        s2 = join_args(l)
        assert s2 == s, "split_args() -> %s\njoin_args(split_args()) -> %s\n" % (l, s2)
        print("split_args('%s') -> %s" % (s, l))

    _compare('')
    _compare('one')
    _compare('"one two"')
    _compare("'one two'")
    _compare('one "two three"')
    _comp

# Generated at 2022-06-20 23:23:12.074602
# Unit test for function split_args
def test_split_args():
    # Basic test
    input_string = r"a=b " \
        r"c='d' " \
        r"e=\"f\" " \
        r"g=h " \
        "i='j \" k \"' " \
        "l=\"m ' n '\" " \
        r"o=p " \
        "q=r"
    expected_result = [u'a=b', u"c='d'", u'e="f"', u'g=h', u"i='j \" k \"'", u'l="m \' n \'"', u'o=p', u'q=r']
    assert split_args(input_string) == expected_result

    # Test that we can split over quoted new lines

# Generated at 2022-06-20 23:23:19.713118
# Unit test for function split_args
def test_split_args():
    # Test each item passed in, return True if all tests pass, False if any fail
    # Return True on failure to stop testing
    def test_items(items):
        # Array of [input, output, exception]
        for test in items:
            args = test[0]
            expected_result = test[1]
            expected_exception = test[2]

            try:
                result = split_args(args)
            except Exception as ex:
                if not expected_exception or (expected_exception and not ex.startswith(expected_exception)):
                    # unexpected exception
                    print('unexpected exception: ' + str(ex))
                    return False
                continue

            if expected_exception:
                # expected exception but none thrown
                print('expected exception but none thrown')
                return False


# Generated at 2022-06-20 23:23:23.354685
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', 'b', 'c', '', 'd', '\n', 'e']) == 'a b c\n d\n e'



# Generated at 2022-06-20 23:23:34.189950
# Unit test for function split_args
def test_split_args():
    assert split_args("echo hello world") == ['echo', 'hello', 'world']
    assert split_args("echo hello world ") == ['echo', 'hello', 'world', '']
    assert split_args("echo 'hello world'") == ['echo', "'hello world'"]
    assert split_args("echo 'hello world' ") == ['echo', "'hello world'", '']
    assert split_args("echo 'hello 'world''") == ['echo', "'hello 'world''"]
    assert split_args("echo 'hello '''world'") == ['echo', "'hello '''world'"]
    assert split_args("echo 'hello \nworld'") == ['echo', "'hello \nworld'"]
    assert split_args("echo 'hello \nworld' ") == ['echo', "'hello \nworld'", '']

# Generated at 2022-06-20 23:23:43.727301
# Unit test for function join_args
def test_join_args():
    assert join_args(['first_param']) == 'first_param'
    assert join_args(['first_param', 'second_param']) == 'first_param second_param'
    assert join_args(['first_param', 'second_param\nthird_param']) == 'first_param second_param\nthird_param'
    assert join_args(['first_param', 'second_param\nthird_param', 'fourth_param']) == 'first_param second_param\nthird_param fourth_param'
    assert join_args(['first_param\n', 'second_param']) == 'first_param\n second_param'
    assert join_args(['first_param\n', 'second_param\n']) == 'first_param\n second_param\n'
    assert join_args

# Generated at 2022-06-20 23:24:04.842512
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv("") == {}

    # Single equals sign
    assert parse_kv("a=b") == {u'a': u'b'}
    assert parse_kv("a= b") == {u'a': u'b'}
    assert parse_kv("a =b") == {u'a': u'b'}
    assert parse_kv("a = b") == {u'a': u'b'}

    # Space between key and equals sign
    assert parse_kv("a =b") == {u'a': u'b'}
    assert parse_kv("a = b") == {u'a': u'b'}
    assert parse_kv("a  =b") == {u'a': u'b'}

# Generated at 2022-06-20 23:24:14.539905
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test function parse_kv()
    '''
    # pylint: disable=missing-docstring
    def check_kv(options, expected):
        print('options: ' + str(options))
        ret = parse_kv(options)
        print('result:  ' + str(ret))
        print('expected:' + str(expected))
        assert ret == expected

    check_kv(u'', {})
    check_kv(u'a=1', {u'a': u'1'})
    check_kv(u'a=1 b=2', {u'a': u'1', u'b': u'2'})

# Generated at 2022-06-20 23:24:19.316103
# Unit test for function split_args
def test_split_args():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert split_args('') == []
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=foo\\ bar') == ['a=b', 'c=foo\\ bar']
    assert split_args('a=b c={{foo}}') == ['a=b', 'c={{foo}}']

# Generated at 2022-06-20 23:24:25.821275
# Unit test for function split_args
def test_split_args():

    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c='foo bar' d='foobar'") == ['a=b', "c='foo bar'", "d='foobar'"]
    assert split_args("a=b c='foo bar' d='foo bar'") == ['a=b', "c='foo bar'", "d='foo bar'"]
    assert split_args("a=b c='foo \n bar'") == ['a=b', "c='foo \n bar'"]
    assert split_args("a=b c='foo \\n bar'") == ['a=b', "c='foo \\n bar'"]

# Generated at 2022-06-20 23:24:30.530088
# Unit test for function split_args

# Generated at 2022-06-20 23:24:37.587634
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("key=value") == {u'key': u'value'}
    assert parse_kv("key1=value1 key2=value2") == {u'key1': u'value1', u'key2': u'value2'}
    assert parse_kv("key1=value1 key2=value2 key3=value3") == {u'key1': u'value1', u'key2': u'value2', u'key3': u'value3'}
    assert parse_kv("here is a string") == {u'_raw_params': u'here is a string'}
    assert parse_kv("here is a string 'with spaces'") == {u'_raw_params': u"here is a string 'with spaces'"}

# Generated at 2022-06-20 23:24:44.249348
# Unit test for function join_args
def test_join_args():
    assert join_args(["A", "B", "C"]) == "A B C"
    assert join_args(["A", "B", "\nC"]) == "A B\nC"
    assert join_args(["A", "\nB", "\nC"]) == "A\nB\nC"
    assert join_args(["", "\n"]) == "\n"
    assert join_args(["A\nB", "C", "\nD"]) == "A\nB C\nD"



# Generated at 2022-06-20 23:24:54.659562
# Unit test for function split_args

# Generated at 2022-06-20 23:25:05.639194
# Unit test for function parse_kv
def test_parse_kv():
    """This function tests the parse_kv function."""
    from ansible.module_utils.common.text import parse_kv
    pair = (
        # The input k/v string of key/value items.
        'one=1 two="two = 1 = 2" three=3 four="4"',
        # The corresponding dictionary.
        {"one": "1", "two": "two = 1 = 2", "three": "3", "four": "4"},
    )
    options = parse_kv(pair[0])
    assert options == pair[1], "{0} != {1}".format(options, pair)

# Generated at 2022-06-20 23:25:12.015274
# Unit test for function join_args
def test_join_args():
    def _test(in_args, expected):
        result = join_args(in_args)
        if result != expected:
            raise AssertionError("Result: %s\nExpected: %s" % (result, expected))
    _test([], '')
    _test(['test'], 'test')
    _test(['test', 'test2'], 'test test2')
    _test(['test', '\ntest2'], 'test\ntest2')
    _test(['test', '\n', 'test2'], 'test\ntest2')
    _test(['test', '\n', '\n', '\n', 'test2'], 'test\n\n\ntest2')

# Generated at 2022-06-20 23:25:28.866671
# Unit test for function split_args
def test_split_args():
    # Test that whitespace is preserved.
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"\n') == ['a=b', 'c="foo bar"\n']
    assert split_args('a=b \n c="foo bar"') == ['a=b', '\n', 'c="foo bar"']
    assert split_args('a=b \n c="foo bar"\n') == ['a=b', '\n', 'c="foo bar"\n']

    # Test that quotes are preserved.
    assert split_args('a="b c"') == ['a="b c"']

# Generated at 2022-06-20 23:25:34.862498
# Unit test for function join_args
def test_join_args():
    assert join_args(["a", "b", "c", "d"]) == 'a b c d'
    assert join_args(["a", "\nb", "c", "d"]) == 'a\n b c d'
    assert join_args(["a", "\nb", "c,\n", "d"]) == 'a\n b c,\n d'
    assert join_args(["a", "\nb", "c,\n", "d,"]) == 'a\n b c,\n d,'
    assert join_args(["a", "\nb", "c,\n", "d,", "e"]) == 'a\n b c,\n d, e'



# Generated at 2022-06-20 23:25:46.106765
# Unit test for function join_args

# Generated at 2022-06-20 23:25:54.968604
# Unit test for function split_args
def test_split_args():
    assert split_args(u'''{{foo}} {{'bar'}} "{{baz}}"''') == [u"{{foo}}", u"{{'bar'}}", u'"{{baz}}"']
    assert split_args(u'''{{foo}} {{'bar'}} "{{baz}}\\"''') == [u"{{foo}}", u"{{'bar'}}", u'"{{baz}}"']
    assert split_args(u"{{ foo }}") == [u"{{ foo }}"]
    assert split_args(u"{{foo}}=five") == [u"{{foo}}=five"]
    assert split_args(u"{{foo}} =five") == [u"{{foo}}", u"=five"]

# Generated at 2022-06-20 23:26:05.117817
# Unit test for function join_args
def test_join_args():
    assert join_args(['a\n']) == 'a\n'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', 'b', 'c d\n']) == 'a b c d\n'
    assert join_args(['a', '', 'b', '\n']) == 'a  b \n'
    assert join_args(['a', '\\\\b', 'c', 'd\n']) == 'a \\\\\\\\b c d\n'
    assert join_args(['a', '\\\\', 'b', 'c\n']) == 'a \\\\\\\\ b c\n'

# Generated at 2022-06-20 23:26:15.943731
# Unit test for function split_args
def test_split_args():
    cmd = 'ls -l "{{ foo }}" {\'foo\'} {% if foo %}'
    assert split_args(cmd) == ['ls', '-l', '"{{ foo }}"', "{'foo'}", '{% if foo %}']

    cmd2 = 'ls -l "{{ foo }}" {% if foo %}'
    assert split_args(cmd2) == ['ls', '-l', '"{{ foo }}"', '{% if foo %}']

    cmd3 = 'ls -l "{{ foo }}"'
    assert split_args(cmd3) == ['ls', '-l', '"{{ foo }}"']

    cmd4 = 'ls -l "{{ foo }}"\n'
    assert split_args(cmd4) == ['ls', '-l', '"{{ foo }}"']

   

# Generated at 2022-06-20 23:26:24.404670
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('single') == dict(single='')
    assert parse_kv('k1=v1') == dict(k1='v1')
    assert parse_kv('k1=v1 k2=v2') == dict(k1='v1', k2='v2')
    assert parse_kv('k1=v1   k2=v2') == dict(k1='v1', k2='v2')
    assert parse_kv('k1="v1" k2="v2"') == dict(k1='v1', k2='v2')
    assert parse_kv('k1=v1 k2="v2"') == dict(k1='v1', k2='v2')
    assert parse_kv('k1="v1" k2=v2')

# Generated at 2022-06-20 23:26:31.944316
# Unit test for function join_args
def test_join_args():
    s = ['add', '-p=4', '{{', 'foo', '}}', '--bar=baz']
    assert join_args(s) == 'add -p=4 {{ foo }} --bar=baz'
    s = ['foo', '-p=-1', '{{', 'bar', '}}', '--baz=blah', '\n', '-p=3']
    assert join_args(s) == 'foo -p=-1 {{ bar }} --baz=blah \n -p=3'



# Generated at 2022-06-20 23:26:37.431557
# Unit test for function join_args
def test_join_args():
    assert join_args(["a", "-b", "--c"]) == "a -b --c"
    assert join_args(["a", "-b", "\n--c"]) == "a -b \n--c"
    assert join_args(["a", "\n-b", "--c"]) == "a \n-b --c"



# Generated at 2022-06-20 23:26:46.486062
# Unit test for function parse_kv
def test_parse_kv():
    # the below are all testing against a shell command we use in test/runner/specific/test_cron.py:
    # command: /bin/echo "{{item}}" > /etc/cron.d/.ansible_placeholder
    assert parse_kv(u'/bin/echo "{{item}}" > /etc/cron.d/.ansible_placeholder') == {u'_raw_params': u'/bin/echo "{{item}}" > /etc/cron.d/.ansible_placeholder'}
    assert parse_kv(u'/bin/echo "{{item}}" > /etc/cron.d/.ansible_placeholder', check_raw=True) == {u'_raw_params': u'/bin/echo "{{item}}" > /etc/cron.d/.ansible_placeholder'}
   

# Generated at 2022-06-20 23:26:59.713923
# Unit test for function join_args
def test_join_args():
    assert join_args(['one', 'two']) == 'one two'
    assert join_args(['one two']) == 'one two'
    assert join_args(['one\ntwo']) == 'one\ntwo'
    assert join_args(['one', 'two\nthree']) == 'one two\nthree'
    assert join_args(['one\n', 'two']) == 'one\n two'
    assert join_args(['one', 'two\n', 'three']) == 'one two\n three'



# Generated at 2022-06-20 23:27:07.622037
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    data = DataLoader()


# Generated at 2022-06-20 23:27:18.682293
# Unit test for function split_args

# Generated at 2022-06-20 23:27:27.124037
# Unit test for function parse_kv
def test_parse_kv():
    args = "foo=bar biz=baz"
    result = parse_kv(args)
    assert result == {u'foo': u'bar', u'biz': u'baz'}

    # Test special characters
    args = "foo='bar biz' baz=\"bam boo\""
    result = parse_kv(args)
    assert result == {u'foo': u'bar biz', u'baz': u'bam boo'}

    # Test spaces and escaped quotes
    args = "foo=bar\\ baz='\"biz bam\"'"
    result = parse_kv(args)
    assert result == {u'foo': u'bar baz', u'"biz bam"': u''}

    # Test escaping of = sign
    args = r"foo\=bar=baz"
   

# Generated at 2022-06-20 23:27:38.133411
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv('var1=value1') == {'var1': 'value1'})
    assert(parse_kv('var2=value2 var3=value3') == {'var2': 'value2', 'var3': 'value3'})
    assert(parse_kv('var4=value4 var5=value5 var6=value6') == {'var4': 'value4', 'var5': 'value5', 'var6': 'value6'})
    assert(parse_kv('var7=value7 var8=value8 var9=value9 var10=value10') == {'var7': 'value7', 'var8': 'value8', 'var9': 'value9', 'var10': 'value10'})


# Generated at 2022-06-20 23:27:47.158876
# Unit test for function parse_kv
def test_parse_kv():
    """
    Test to verify that the parse_kv function correctly parses a string
    of key values into a hash.
    """
    def assert_kv(args, expected):
        actual = parse_kv(args)
        assert actual == expected

    assert_kv(None, {})
    assert_kv('', {})
    assert_kv('a=1', {'a': '1'})
    assert_kv('a=1 b=2', {'a': '1', 'b': '2'})
    assert_kv('a=1\nb=2', {'a': '1', 'b': '2'})
    assert_kv('a=1\\\nb=2', {'a': '1\\', 'b': '2'})

# Generated at 2022-06-20 23:27:53.714679
# Unit test for function parse_kv
def test_parse_kv():
    res=parse_kv('a=1 b=2')
    assert res['a'] == '1'
    assert res['b'] == '2'
    res=parse_kv('a=1 "b=2"')
    assert res['a'] == '1'
    assert res['b'] == '2'
    res=parse_kv('a=1 "b=2')
    assert res['a'] == '1'
    assert res['b'] == '2'
    res=parse_kv('a=1 "b=2')
    assert res['a'] == '1'
    assert res['b'] == '2'
    res=parse_kv('a=1 "b=2" c')
    assert res['a'] == '1'
    assert res['b'] == '2'

# Generated at 2022-06-20 23:28:04.054317
# Unit test for function parse_kv
def test_parse_kv():

    def test(kv_string, expected):
        assert(parse_kv(kv_string) == expected)

    # can use a string with spaces and something like: foo=bar arg1 arg2 arg3
    test('''
               foo=bar arg1 arg2 arg3
    ''', {'foo': 'bar', '_raw_params': 'arg1 arg2 arg3'})

    # can use a string with spaces and something like: foo=bar arg1=arg2 arg3
    test('''
               foo=bar arg1=arg2 arg3
    ''', {'foo': 'bar', 'arg1': 'arg2', '_raw_params': 'arg3'})

    # can use a string with spaces and something like: foo=bar arg1 arg2=arg3

# Generated at 2022-06-20 23:28:12.569774
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c='foo bar'") == [u'a=b', u"c='foo bar'"]
    assert split_args(u"a=b c=\"foo bar\"") == [u'a=b', u'c="foo bar"']
    assert split_args(u"a=b c=foo\\\\'bar d=1") == [u'a=b', u"c=foo\\\\'bar", u'd=1']
    assert split_args(u'a=b c="foo bar \\\\"') == [u'a=b', u'c="foo bar \\\\\\"']
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo')

# Generated at 2022-06-20 23:28:24.686919
# Unit test for function join_args
def test_join_args():
    assert join_args(split_args('')) == ''
    assert join_args(split_args('foo')) == 'foo'
    assert join_args(split_args('foo bar')) == 'foo bar'
    assert join_args(split_args('foo bar\nbaz')) == 'foo bar\nbaz'
    assert join_args(split_args('foo bar\nbaz\n')) == 'foo bar\nbaz\n'
    assert join_args(split_args('foo "bar baz"')) == 'foo "bar baz"'
    assert join_args(split_args('foo "bar baz"\nbam')) == 'foo "bar baz"\nbam'

# Generated at 2022-06-20 23:28:38.795848
# Unit test for function split_args
def test_split_args():
    # Basics
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Escaped quotation marks
    assert split_args(u"a=b c=\\\"foo bar\\\"") == [u'a=b', u'c=\\"foo bar\\"']

    # Escaped newline
    assert split_args('a=b\\\nc=d') == ['a=b', u'c=d']

    # Escaped space
    assert split_args('a=b\\ c=d') == ['a=b', u'c=d']

    # Jinja2 blocks
    assert split_args('a={% b %} c') == ['a={% b %}', 'c']

    # Jinja2 blocks spanning multiple lines

# Generated at 2022-06-20 23:28:47.899377
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': u'b', 'c': u'd'}
    assert parse_kv('a=b "c=d e" f="g h"') == {'a': u'b', 'c': u'd e', 'f': u'g h'}
    assert parse_kv('"a=b c=d"') == {'a': u'b c', 'd': u''}
    assert parse_kv('"a=b c=d e=f"') == {'a': u'b c', 'd e': u'f'}
    assert parse_kv('a=b c="d e" f="g h"') == {'a': u'b', 'c': u'd e', 'f': u'g h'}
   

# Generated at 2022-06-20 23:28:57.547678
# Unit test for function parse_kv
def test_parse_kv():
    # Test a simple command line
    cmd = 'ssh localhost -o StrictHostKeyChecking=no'
    result = parse_kv(cmd, check_raw=True)
    assert result == {'_raw_params': 'ssh localhost -o StrictHostKeyChecking=no'}

    # Test a simple key value pair
    cmd = 'ssh localhost -o StrictHostKeyChecking=no'
    result = parse_kv(cmd, check_raw=False)
    assert result == {u'o': u'StrictHostKeyChecking=no'}

    # Test a simple key value pair with a quoted value
    cmd = 'ssh localhost -o "StrictHostKeyChecking=no"'
    result = parse_kv(cmd, check_raw=False)

# Generated at 2022-06-20 23:29:01.558206
# Unit test for function join_args
def test_join_args():
    orig = split_args('''
      cmd1 'arg1 "arg1" arg1' arg1=val1
      cmd2 arg2=val2 \\\\
      cmd3 arg3=val3
      cmd4
      ''')
    assert ' '.join(orig) == join_args(orig)



# Generated at 2022-06-20 23:29:12.204359
# Unit test for function split_args
def test_split_args():
    # Unit test for function split_args. See:
    # https://docs.python.org/3/library/unittest.html
    # https://docs.python.org/3/library/unittest.html#test-discovery
    import unittest

    # TestCase is used to create test cases by subclassing unittest.TestCase.
    class test_split_args(unittest.TestCase):
        # test fixture
        # setUpClass is called with the class as the only argument and must be decorated
        # as a classmethod():
        @classmethod
        def setUpClass(cls):
            # setUpClass is called before tests in an individual class run
            # cls.split_args = split_args
            pass

        # tearDownClass is called with the class as the only argument and must be decorated
       

# Generated at 2022-06-20 23:29:20.730284
# Unit test for function split_args
def test_split_args():

    raw_args = """a=b c="foo bar" d='foo bar' e="don't" f=\'don\\'t\' g=\\"don't\\" h=\\\\"don't\\\\" i = foo\\\\'bar=baz\\\\'qux j='foo \\' bar' k="foo \\" bar" l=foo\\\\ bar=baz\\\\ qux"""

    # valid jinja2, but not python
    raw_args += " m='foo bar \\ x=y \\'"

    # invalid jinja2
    raw_args += " n='foo bar \\x=y\\'"


# Generated at 2022-06-20 23:29:27.561933
# Unit test for function parse_kv
def test_parse_kv():
    options = {}
    args = 'key="value" creates=/tmp/foo'
    options = parse_kv(args)
    if not options['creates'] == '/tmp/foo':
        raise AssertionError('parse_kv failure')

if __name__ == '__main__':
    test_parse_kv()

__all__ = ['parse_kv']