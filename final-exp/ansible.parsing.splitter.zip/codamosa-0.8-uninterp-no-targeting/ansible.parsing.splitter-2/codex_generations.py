

# Generated at 2022-06-20 23:20:12.346035
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b') == {'a': 'b'}
    assert parse_kv(u'a="b"') == {'a': 'b'}
    assert parse_kv(u"a=b'c'") == {'a': "b'c'"}
    assert parse_kv(u"a=b'c' d=e") == {'a': "b'c'", 'd': 'e'}
    assert parse_kv(u'a="b\'c"') == {'a': "b\'c"}
    assert parse_kv(u'a="b\"c"') == {'a': 'b"c'}
    assert parse_kv(u'a=b"c"') == {'a': 'b"c'}
    assert parse

# Generated at 2022-06-20 23:20:22.012872
# Unit test for function split_args
def test_split_args():
    # Test 1: Test simple args, no jinja2
    result = split_args("git clone --branch stable-2.3 https://github.com/ansible/ansible.git")
    assert result == ['git', 'clone', '--branch', 'stable-2.3', 'https://github.com/ansible/ansible.git']

    # Test 2: Test args split on jinja2
    result = split_args("bash -c '{{ foo }} {{ bar }}'")
    assert result == ["bash", "-c", "{{ foo }} {{ bar }}"]

    # Test 3: Test args split on quotes
    result = split_args("bash -c '{{ foo }}'")
    assert result == ["bash", "-c", "{{ foo }}"]

    # Test 4: Test args with line continuation
    result = split_args

# Generated at 2022-06-20 23:20:25.230662
# Unit test for function join_args
def test_join_args():
    from nose.plugins.skip import SkipTest
    raise SkipTest
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\n', 'b']) == 'a\nb'
    assert join_args(['a', 'b\n']) == 'a\nb\n'



# Generated at 2022-06-20 23:20:35.298868
# Unit test for function split_args

# Generated at 2022-06-20 23:20:39.373122
# Unit test for function join_args
def test_join_args():
    s = ['a', 'b', 'c', 'd', '\ne', 'f\ng', '\nh']
    assert join_args(s) == "a b c d\ne f\ng\nh"



# Generated at 2022-06-20 23:20:47.333529
# Unit test for function join_args

# Generated at 2022-06-20 23:20:58.053885
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\n', 'b']) == 'a\nb'
    assert join_args(['a', 'b\n']) == 'a b\n'
    assert join_args(['a\n', 'b\n']) == 'a\n\n\nb'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\n', 'b', 'c']) == 'a\nb c'
    assert join_args(['a', 'b\n', 'c']) == 'a b\nc'
    assert join_args(['a', 'b', 'c\n']) == 'a b c\n'
    assert join_args

# Generated at 2022-06-20 23:21:06.742095
# Unit test for function parse_kv
def test_parse_kv():
    def test(args, result, check_raw=False):
        assert parse_kv(args, check_raw) == result

    test("foo=bar baz=quux", {'foo': 'bar', 'baz': 'quux'})
    test("foo='bar baz'", {'foo': 'bar baz'})
    test("foo=bar baz='quux'", {'foo': 'bar', 'baz': 'quux'})
    test("foo='bar baz' quux='moo cow'", {'foo': 'bar baz', 'quux': 'moo cow'})

# Generated at 2022-06-20 23:21:16.359307
# Unit test for function split_args

# Generated at 2022-06-20 23:21:26.588563
# Unit test for function parse_kv
def test_parse_kv():
    """
    Test parse_kv function
    """
    assert parse_kv("test=test=test=test") == {"test": "test=test=test"}
    assert parse_kv("test=test=test=test", check_raw=True) == {"test": "test=test=test", "_raw_params": "test=test=test=test"}
    assert parse_kv("test=test=test=test") == {"test": "test=test=test"}
    assert parse_kv("test='test=test'") == {"test": "test=test"}
    assert parse_kv("test='test=test", check_raw=True) == {"_raw_params": "test='test=test"}

# Generated at 2022-06-20 23:21:49.066360
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'''a=b 
c="foo bar"''') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo \\"bar\\""') == [u'a=b', u'c="foo \\"bar\\""']
    assert split_args(u'a=b c="foo \\\\"bar\\\\""') == [u'a=b', u'c="foo \\\\"bar\\\\""']
    assert split_args(u'a=b c="foo \\\\"bar\\\\""') == [u'a=b', u'c="foo \\\\"bar\\\\""']
    assert split

# Generated at 2022-06-20 23:21:57.795226
# Unit test for function parse_kv
def test_parse_kv():
    # parsing a normal key value pair should yield expected result
    assert parse_kv("key=value") == {"key": "value" }
    assert parse_kv("key = value") == {"key": "value" }
    assert parse_kv("key =  value") == {"key": "value" }
    assert parse_kv("key = value ") == {"key": "value" }
    assert parse_kv(" key = value ") == {"key": "value" }
    # parsing a escaped key value pair should yield expected result
    assert parse_kv("key\\=value") == {"key=value": None }
    assert parse_kv("key\\= value") == {"key=value": None }
    assert parse_kv("key\\=value ") == {"key=value": None }
    assert parse_kv

# Generated at 2022-06-20 23:22:09.421371
# Unit test for function join_args
def test_join_args():
    s = ['foo', 'bar', 'baz']
    assert join_args(s) == 'foo bar baz'
    s = ['foo', 'bar', 'baz\n']
    assert join_args(s) == 'foo bar baz\n'
    s = ['foo', 'bar', '\nbaz\n']
    assert join_args(s) == 'foo bar \nbaz\n'
    s = ['foo', 'bar', '\n\nbaz\n']
    assert join_args(s) == 'foo bar \n\nbaz\n'
    s = ['foo bar\\', 'baz']
    assert join_args(s) == 'foo bar\\ baz'
    s = ['foo bar baz\\', 'bling']

# Generated at 2022-06-20 23:22:13.457622
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("users=root action=create") == dict(users="root", action="create")
    assert parse_kv("users=root action=create foo") == dict(users="root", action="create", _raw_params="foo")
    assert parse_kv("users=root\\ action=create foo") == dict(users="root action=create", _raw_params="foo")


# Generated at 2022-06-20 23:22:24.107565
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {'foo': 'bar'}
    assert parse_kv("foo=bar", check_raw=True) == {'foo': 'bar', '_raw_params': 'foo=bar'}
    assert parse_kv("foo=bar baz=zoo") == {'foo': 'bar', 'baz': 'zoo'}
    assert parse_kv("foo=bar baz=zoo", check_raw=True) == {'foo': 'bar', 'baz': 'zoo', '_raw_params': 'foo=bar baz=zoo'}
    assert parse_kv("foo=\"bar baz\"") == {'foo': 'bar baz'}

# Generated at 2022-06-20 23:22:33.416528
# Unit test for function parse_kv
def test_parse_kv():
    in_value_with_escaped_equals='foo=bar\=baz'
    in_value_without_escaped_equals='foo=bar'
    parsed_result_should_be_value='bar'
    parsed_result_should_be_escaped_equals='bar=baz'
    res=parse_kv(in_value_with_escaped_equals)
    assert(res['foo'] == parsed_result_should_be_escaped_equals)
    res=parse_kv(in_value_without_escaped_equals)
    assert(res['foo'] == parsed_result_should_be_value)
    # no crash please
    parse_kv(None)


# Generated at 2022-06-20 23:22:40.604343
# Unit test for function split_args
def test_split_args():
    res = split_args("a=b c={{ foo }}")
    assert res == ['a=b', 'c={{ foo }}']

    res = split_args("echo 123 {{ foo }} 'foo bar'")
    assert res == ['echo 123 {{ foo }} \'foo bar\'']

    res = split_args('echo 123 {{ foo }} "foo bar"')
    assert res == ['echo 123 {{ foo }} "foo bar"']

    res = split_args("echo 123 {{ foo }}\necho 456\nbar")
    assert res == ['echo 123 {{ foo }}', 'echo 456', 'bar']

    res = split_args('a=b c="foo bar"')
    assert res == ['a=b', 'c="foo bar"']

    res = split_args("a=b c='foo bar'")
    assert res

# Generated at 2022-06-20 23:22:51.382340
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    assert split_args(args) == ['a=b', 'c="foo bar"']

    args = "a=b c='foo bar'"
    assert split_args(args) == ['a=b', "c='foo bar'"]

    args = "a=\"foo bar\""
    assert split_args(args) == ['a="foo bar"']

    args = "a='foo bar'"
    assert split_args(args) == ["a='foo bar'"]

    args = "a={{ foo }}"
    assert split_args(args) == ['a={{ foo }}']

    args = "a={{ foo }}\nc='here is some more'"
    assert split_args(args) == ['a={{ foo }}', "c='here is some more'"]

    args

# Generated at 2022-06-20 23:22:59.279505
# Unit test for function parse_kv
def test_parse_kv():
    def test(s, expected):
        actual = parse_kv(s)
        if actual != expected:
            raise AssertionError("Expected %s\n  but got %s" % (expected, actual))

    test('foo=1 bar=2', dict(foo='1', bar='2'))
    test('foo=1 bar=2 baz=', dict(foo='1', bar='2', baz=''))
    test('foo=1 bar=2 baz=', dict(foo='1', bar='2', baz=''))
    test('foo=1 bar=2 baz=', dict(foo='1', bar='2', baz=''))
    test('foo=1=2', dict(foo='1=2'))

# Generated at 2022-06-20 23:23:02.329958
# Unit test for function join_args
def test_join_args():
    original = 'test \\\n a=b \\\n c=d'
    split_result = ['test', '\\', 'a=b', '\\', 'c=d']
    assert join_args(split_result) == original



# Generated at 2022-06-20 23:23:18.939836
# Unit test for function split_args

# Generated at 2022-06-20 23:23:29.664300
# Unit test for function split_args
def test_split_args():

    def _test_case(description, expected_result, arg_string):
        actual_result = split_args(arg_string)
        if repr(actual_result) != repr(expected_result):
            raise AssertionError(u"{2}: given '{0}', expected '{1}' but got '{3}'".format(arg_string, expected_result, description, actual_result))
        expected_result_after_join = join_args(expected_result)
        if expected_result_after_join != arg_string:
            raise AssertionError(u"{2}: given '{0}', expected '{1}' but got '{3}'".format(arg_string, expected_result, description, expected_result_after_join))


# Generated at 2022-06-20 23:23:35.060828
# Unit test for function join_args
def test_join_args():
    assert join_args(["hello", "world"]) == r"hello world"
    assert join_args(["hello", "world\n"]) == r"hello world\n"
    assert join_args(["\nhello", "world"]) == r"\nhello world"
    assert join_args(["\n", "\n# example"]) == r"\n\n# example"



# Generated at 2022-06-20 23:23:36.772434
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '"one\ntwo"']) == 'echo "one\ntwo"'



# Generated at 2022-06-20 23:23:45.731584
# Unit test for function split_args
def test_split_args():
    assert ['a=b', 'c="foo bar"'] == split_args('a=b c="foo bar"')
    assert ['a=b', 'c="foo bar"'] == split_args('a=b\nc="foo bar"')
    assert ['a=b', 'c="foo bar"'] == split_args('a=b \nc="foo bar"')
    assert ['a=b', 'c="foo bar"'] == split_args('a=b\n c="foo bar"')
    assert ['a=b', 'c="foo bar"'] == split_args('a=b\n c="foo bar"')
    assert ['a=b', 'c="foo', 'bar"'] == split_args('a=b\nc="foo\nbar"')

# Generated at 2022-06-20 23:23:56.419871
# Unit test for function join_args
def test_join_args():
    '''
    This method is a unit test for the join_args() function.
    '''
    s = ['foo', 'bar', 'baz']
    result = join_args(s)
    assert result == 'foo bar baz', "Error in join_args()"
    s = ['foo', 'bar', 'baz', '\nxyz']
    result = join_args(s)
    assert result == 'foo bar baz \nxyz', "Error in join_args()"
    s = ['foo', '\nbar', 'baz']
    result = join_args(s)
    assert result == 'foo \nbar baz', "Error in join_args()"
    s = ['foo', 'bar', 'baz \nxyz']
    result = join_args(s)

# Generated at 2022-06-20 23:24:01.933889
# Unit test for function join_args
def test_join_args():
    assert 'ls -l' == join_args(['ls', '-l'])
    assert 'ls -l\ncd' == join_args(['ls', '-l', '\n', 'cd'])
    assert 'ls -l\ncd' == join_args(['ls', '-l\n', 'cd'])
    assert 'ls -l\ncd' == join_args(['ls -l\n', 'cd'])


# Generated at 2022-06-20 23:24:07.561935
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '$HOME']) == 'echo $HOME'
    assert join_args(['echo', '$HOME', '# A comment']) == 'echo $HOME # A comment'
    assert join_args([r'echo "\\"']) == r'echo "\\"'
    assert join_args(['echo', '"\\""']) == r'''echo "\"\""'''
    assert join_args(['echo', '"\\""']) == r'''echo "\"\""'''



# Generated at 2022-06-20 23:24:10.360189
# Unit test for function join_args
def test_join_args():
    s = split_args("a b c\n d e\nf")
    assert join_args(s) == "a b c\n d e\nf"



# Generated at 2022-06-20 23:24:14.702333
# Unit test for function split_args

# Generated at 2022-06-20 23:24:28.213850
# Unit test for function split_args

# Generated at 2022-06-20 23:24:33.230657
# Unit test for function split_args

# Generated at 2022-06-20 23:24:41.097553
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo="bar baz" ignoreme=\'this=v1 this=v2\'') == {'foo': 'bar baz', '_raw_params': ' ignoreme=\'this=v1 this=v2\''}
    assert parse_kv("foo=bar") == {'foo': 'bar'}
    assert parse_kv("foo='bar'") == {'foo': 'bar'}
    assert parse_kv("foo='bar baz'") == {'foo': 'bar baz'}
    assert parse_kv("foo='bar\tbaz'") == {'foo': 'bar\tbaz'}
    assert parse_kv("foo=\"bar\tbaz\"") == {'foo': 'bar\tbaz'}

# Generated at 2022-06-20 23:24:51.997051
# Unit test for function split_args

# Generated at 2022-06-20 23:25:02.826152
# Unit test for function join_args
def test_join_args():
    assert join_args(['arg1', 'arg2']) == 'arg1 arg2'
    assert join_args(['arg1 ', 'arg2']) == 'arg1  arg2'
    assert join_args(['arg1\n', 'arg2']) == 'arg1\narg2'
    assert join_args(['arg1\n', 'arg2\n']) == 'arg1\narg2\n'
    assert join_args(['arg1', '\narg2\n']) == 'arg1 \narg2\n'
    assert join_args([]) == ''
    assert join_args(['arg1\n', 'arg2', 'arg3', 'arg4\n']) == 'arg1\narg2 arg3 arg4\n'



# Generated at 2022-06-20 23:25:10.607079
# Unit test for function split_args
def test_split_args():
    assert ['echo', 'foo', 'bar'] == split_args('echo foo bar')
    assert ['echo', 'foo bar'] == split_args('echo "foo bar"')
    assert ['echo', u'foobar\xe9'] == split_args(u'echo "foobar\\xe9"')
    assert ['echo', 'quoth the raven', 'nevermore'] == split_args('echo "quoth the raven" nevermore')
    assert ['echo', '{{ foo }}'] == split_args('echo "{{ foo }}"')
    assert ['echo', '"{{ foo }}"'] == split_args('echo "\\"{{ foo }}\\""')
    assert ['echo', '{{ foo }}', 'bar', '{{ bam }}'] == split_args('echo "{{ foo }}" bar "{{ bam }}"')

# Generated at 2022-06-20 23:25:21.448956
# Unit test for function split_args
def test_split_args():
    assert split_args(u"this is a test") == [u"this", u"is", u"a", u"test"]
    assert split_args(u"this is a\\\n test") == [u"this", u"is", u"a\n", u"test"]
    assert split_args(u"this is 'a test'") == [u'this', u'is', u"'a test'"]
    assert split_args(u"this is 'a\\' test'") == [u"this", u"is", u"\'a\' test\'"]
    assert split_args(u"this is 'a\\' test' more") == [u"this", u"is", u"\'a\' test\'", u"more"]

# Generated at 2022-06-20 23:25:30.581263
# Unit test for function split_args
def test_split_args():
    '''
    Execute the split_args function unit tests.
    '''
    # Test splitting on spaces with quoting
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', 'd=\'foo bar\'']
    assert split_args('a=b c="foo bar\' d=\'foo bar"') == ['a=b', 'c="foo bar\' d=\'foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']

# Generated at 2022-06-20 23:25:35.278819
# Unit test for function parse_kv
def test_parse_kv():
    fd = open('/Users/huangjianyang/Desktop/parse_kv.txt','r')
    for x in fd.readlines():
        x = x.rstrip('\n')

# Generated at 2022-06-20 23:25:46.433474
# Unit test for function split_args

# Generated at 2022-06-20 23:26:13.146162
# Unit test for function split_args
def test_split_args():
    def _test(s, expected):
        params = split_args(s)
        assert params == expected, _err(s, params, expected)

    def _err(s, params, expected):
        return (u"split_args(%s) produced %s but expected %s" % (repr(s), repr(params), repr(expected))).encode('utf-8')

    # Invalid cases
    try:
        split_args("a=b 'foo bar")
        assert False, "Should have raised an exception"
    except AnsibleParserError:
        pass

    try:
        split_args("a=b \"foo bar")
        assert False, "Should have raised an exception"
    except AnsibleParserError:
        pass


# Generated at 2022-06-20 23:26:15.340041
# Unit test for function join_args
def test_join_args():
    assert join_args(('one', 'two', 'three\nfour')) == 'one two three\nfour'
    assert join_args(()) == ''



# Generated at 2022-06-20 23:26:24.685804
# Unit test for function parse_kv
def test_parse_kv():
    args = " foo=aaa  bar='bbb'  ccc=\"ddd eee \" "
    answers = { 'foo': 'aaa', 'bar': 'bbb', 'ccc': 'ddd eee'}
    assert parse_kv(args) == answers

    args = " foo \\\"aaa \\\\\"  bar='bb\\\\b' "
    answers = { 'foo': '\"aaa \\\"', 'bar': 'bb\\b' }
    assert parse_kv(args) == answers

    args = ' foo=aaa bar= bbb=ccc=ddd'
    answers = {'foo': 'aaa', 'bbb': 'ccc=ddd'}
    assert parse_kv(args) == answers

    args = ' foo= aaa = bbb'

# Generated at 2022-06-20 23:26:36.069971
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.compat.tests.mock import patch
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test basic parsing with no raw params
    options = parse_kv("option1=value1 option2=value2 option3=value3")
    assert 'option1' in options and options['option1'] == 'value1'
    assert 'option2' in options and options['option2'] == 'value2'
    assert 'option3' in options and options['option3'] == 'value3'

    # Test basic parsing with a single raw param
    options = parse_kv("option1=value1 'option2 something=value2' option3=value3", check_raw=True)
    assert 'option1' in options and options['option1'] == 'value1'

# Generated at 2022-06-20 23:26:43.839601
# Unit test for function parse_kv
def test_parse_kv():
    # Test basic parsing of key=value pairs
    assert parse_kv('foo=bar a=b') == {u'foo': u'bar', u'a': u'b'}
    # Test parsing with values that contain an '=' character
    assert parse_kv('foo=a=b c=d=e') == {u'foo': u'a=b', u'c': u'd=e'}

    # Test escaping of special characters
    assert parse_kv(r'foo=bar\=baz') == {u'foo': u'bar=baz'}
    assert parse_kv(r"foo=bar\\baz") == {u'foo': r'bar\baz'}

# Generated at 2022-06-20 23:26:46.764888
# Unit test for function join_args
def test_join_args():
    """
    Unit test for function join_args
    """
    assert join_args(['echo', 'hi,', '\\', 'there!']) == 'echo hi, \\ there!'


# Generated at 2022-06-20 23:26:52.368326
# Unit test for function join_args
def test_join_args():
    '''
    test support function join_args()
    '''
    assert join_args(['echo', 'hello']) == 'echo hello'
    assert join_args(['echo', 'hello there']) == 'echo hello there'
    assert join_args(['echo', 'hello', 'there']) == 'echo hello there'
    assert join_args(['echo', 'hello', '\n', 'there']) == 'echo hello \n there'


# Generated at 2022-06-20 23:26:56.626275
# Unit test for function join_args
def test_join_args():
    s = '''- a_key=a_value abc\
    - b_key=b_value\
        - c_key=c_value\
        - d_key=d_value\
      '''
    assert join_args(split_args(s)) == s



# Generated at 2022-06-20 23:27:04.361948
# Unit test for function split_args
def test_split_args():
    # Get the test data
    import os
    test_dir = os.path.dirname(__file__)
    test_file = os.path.join(test_dir, 'test_split_args.yml')
    test_data = open(test_file).read()
    test_data = yaml.load(test_data)
    # Test each line
    for line in test_data:
        if line[0]:
            params = line[0]
        else:
            params = ''
        expected = line[1]
        observed = split_args(params)
        assert expected == observed, "Failed parsing argument string '{0}'".format(params)

# Generated at 2022-06-20 23:27:10.057988
# Unit test for function join_args
def test_join_args():
    assert join_args(['this', 'is', 'a', 'test']) == 'this is a test'
    assert join_args(['this', 'is', 'a\n test']) == 'this is a\n test'
    assert join_args(['this', 'is', 'a', 'test\n']) == 'this is a test\n'
    assert join_args(['this', 'is', 'a', '\ntest']) == 'this is a \ntest'
    assert join_args(['this\n', 'is', 'a', '\ntest']) == 'this\n is a \ntest'
    assert join_args(['this\n', 'is', 'a', '\ntest\n']) == 'this\n is a \ntest\n'



# Generated at 2022-06-20 23:28:40.497904
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['arg1']) == 'arg1'
    assert join_args(['arg1', 'arg2']) == 'arg1 arg2'
    assert join_args(['arg1', 'arg2', 'arg3']) == 'arg1 arg2 arg3'
    assert join_args(['arg1', 'arg2', 'arg3', 'arg4']) == 'arg1 arg2 arg3 arg4'
    assert join_args(['arg1', 'arg2', 'arg3', 'arg4', 'arg5']) == 'arg1 arg2 arg3 arg4 arg5'
    assert join_args(['arg1\n', 'arg2\n', 'arg3\n']) == 'arg1\narg2\narg3\n'
    assert join

# Generated at 2022-06-20 23:28:49.754074
# Unit test for function split_args
def test_split_args():
    def split_and_stringify(text):
        return join_args(split_args(text))

    print(split_and_stringify('a=b c="foo bar"\nd=e f="foo bar"'))
    print(split_and_stringify('a=b c="foo bar"\nd=e f=\'foo bar\''))
    print(split_and_stringify('a=b c="foo bar"\nd=e f=\'foo bar\'\\'))
    print(split_and_stringify('a=b c="foo bar"\nd=e f=\'foo bar\'\\'))
    print(split_and_stringify('a=b c="foo bar"\nd=e f=\'foo bar\'\\\n'))


# Generated at 2022-06-20 23:28:59.866587
# Unit test for function split_args

# Generated at 2022-06-20 23:29:09.589293
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['a']) == 'a'
    assert join_args(['a','b','c']) == 'a b c'
    assert join_args(['a b','c']) == 'a b c'
    assert join_args(['a', 'b c']) == 'a b c'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\n', 'b', 'c']) == 'a\nb c'
    assert join_args(['a\n', 'b', 'c']) == 'a\nb c'
    assert join_args(['"a"', 'b', 'c']) == '"a" b c'

# Generated at 2022-06-20 23:29:19.611400
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv('foo=bar key=val')
    assert options == {u'foo': u'bar', u'key': u'val'}
    options = parse_kv('foo=bar key="weird name"')
    assert options == {u'foo': u'bar', u'key': u'weird name'}
    options = parse_kv('foo="" bar="" key=""')
    assert options == {u'foo': u'', u'bar': u'', u'key': u''}
    options = parse_kv('foo=bar key=val _raw_params=weird name')
    assert options == {u'foo': u'bar', u'key': u'val'}

# Generated at 2022-06-20 23:29:32.549671
# Unit test for function join_args
def test_join_args():
    assert join_args(["a", "b"]) == "a b"
    assert join_args(["a b"]) == "a b"
    assert join_args(["a \n", "b"]) == "a \n b"
    assert join_args(["a", "\n b"]) == "a \n b"
    assert join_args(["a b"]) == "a b"
    assert join_args(["a", "\n", "b"]) == "a \n b"
    assert join_args(["a", " b"]) == "a  b"
    assert join_args(["a ", "b"]) == "a  b"
    assert join_args(["a ", "\n", " b"]) == "a \n  b"