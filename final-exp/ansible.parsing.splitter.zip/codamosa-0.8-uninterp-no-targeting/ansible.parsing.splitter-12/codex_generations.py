

# Generated at 2022-06-20 23:19:56.030757
# Unit test for function split_args
def test_split_args():

    def _compare_args(input, expected_output):
        output = split_args(input)
        message = u"\ninput: {0}\nexpected output: {1}\nactual output: {2}\n".format(input, expected_output, output)
        assert expected_output == output, message

    # Possible todo: test with non-ascii characters
    _compare_args("-a -b -c", ["-a", "-b", "-c"])
    _compare_args("a=b c=d", ["a=b", "c=d"])
    _compare_args("a=b 'c d' e=f", ["a=b", "'c d'", "e=f"])

# Generated at 2022-06-20 23:20:01.977771
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b="2 3" c=4') == {'a': '1', 'c': '4', 'b': '2 3'}
    assert parse_kv('a=1 b="2 3" c=4', check_raw=True) == {'a': '1', 'c': '4', 'b': '2 3', '_raw_params': 'a=1 b="2 3" c=4'}
    assert parse_kv('a=1 b="2 3" c=4', check_raw=True) == {'a': '1', 'c': '4', 'b': '2 3', '_raw_params': 'a=1 b="2 3" c=4'}

# Generated at 2022-06-20 23:20:13.048292
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])

# Generated at 2022-06-20 23:20:16.850448
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\n', 'b']) == 'a\nb'
    assert join_args(['a\n', '\nb']) == 'a\n\nb'



# Generated at 2022-06-20 23:20:22.404332
# Unit test for function join_args
def test_join_args():
    assert join_args(['abc\n', 'def\n', 'ghi']) == 'abc\ndef\nghi'
    assert join_args(['abc\\\n', 'def\n', 'ghi']) == 'abc\\\ndef\nghi'
    assert join_args(['abc', 'def', 'ghi']) == 'abc def ghi'
    assert join_args(['abc', '\ndef']) == 'abc\ndef'



# Generated at 2022-06-20 23:20:24.802363
# Unit test for function join_args
def test_join_args():
    assert ('a b c' == join_args(['a', 'b', 'c']))
    assert ('a b\nc d' == join_args(['a', 'b', 'c', 'd']))


# Generated at 2022-06-20 23:20:34.908961
# Unit test for function parse_kv
def test_parse_kv():
    """
    Test parse_kv on a variety of use cases
    """
    tests = [
        (u'a=b', {u'a': u'b'}),
        (u"'a=c'", {u'a': u'c'}),
        (u"a=b 'a=c' 'a=d'", {u'a': u'b a=c a=d'}),
        (u'a=b a=c', {u'a': u'b a=c'}),
        (u'a=b a="c d" a=c', {u'a': u'b c d a=c'}),
        (u'a= b="c d" a=c', {u'a': u' b c d a=c'}),
    ]

# Generated at 2022-06-20 23:20:44.872377
# Unit test for function parse_kv
def test_parse_kv():
    results = parse_kv('foo=bar')
    assert results == {'foo': 'bar'}
    results = parse_kv('foo=bar baz=bear')
    assert results == {'foo': 'bar', 'baz': 'bear'}
    results = parse_kv(u'foo=bar "baz=bear"')
    assert results == {'foo': 'bar', 'baz=bear': None}
    results = parse_kv(u'foo=bar "a=c d=e"')
    assert results == {'foo': 'bar', 'a=c d=e': None}
    results = parse_kv(u'foo=bar "a=c d=e" f=g "b = e"')

# Generated at 2022-06-20 23:20:49.405659
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(u"a=b 'c=\"foo bar\"'") == [u'a=b', 'c="foo bar"']
    assert split_args(u"a=b c={% foo %}") == [u'a=b', u'c={% foo %}']
    assert split_args(u"a=b c={{ foo }}") == [u'a=b', u'c={{ foo }}']
    assert split_args(u"a=b c={{ foo }} d={{ bar }} e='foo bar'") == [u'a=b', u'c={{ foo }}', u'd={{ bar }}', u"e='foo bar'"]
    assert split_args

# Generated at 2022-06-20 23:21:00.408570
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {u'foo': u'bar'}
    assert parse_kv("foo=bar baz=blip") == {u'foo': u'bar', u'baz': u'blip'}
    assert parse_kv("foo='bar blip' baz=blip") == {u'foo': u'bar blip', u'baz': u'blip'}
    assert parse_kv("foo='bar\x20blip' baz=blip") == {u'foo': u'bar blip', u'baz': u'blip'}
    assert parse_kv("foo=bar baz='blip blop'") == {u'foo': u'bar', u'baz': u'blip blop'}
    assert parse_kv

# Generated at 2022-06-20 23:21:21.822074
# Unit test for function parse_kv
def test_parse_kv():
    text = 'creates=/tmp/foo executable=/bin/sh removes=/tmp/bar'
    assert parse_kv(text, check_raw=True) == {'creates': '/tmp/foo', 'executable': '/bin/sh', 'removes':'/tmp/bar'}
    text = 'creates=/tmp/foo removes=/tmp/bar /usr/bin/show full=True'
    assert parse_kv(text, check_raw=True) == {'creates': '/tmp/foo', 'removes': '/tmp/bar', '_raw_params': '/usr/bin/show full=True'}
    text = 'creates=/tmp/foo removes=/tmp/bar "/usr/bin/show this is a test"'

# Generated at 2022-06-20 23:21:29.888682
# Unit test for function split_args

# Generated at 2022-06-20 23:21:40.804885
# Unit test for function split_args
def test_split_args():
    import random
    from G_utils import compare_output
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-20 23:21:48.322716
# Unit test for function split_args
def test_split_args():
    results = split_args(
        "foo=bar b={{myvar}} c=\\{{myvar}} d={% if 1==1 %}{% endif %} e={{foo={{bar}} print(bar)}}")
    print(results)
    assert results == ["foo=bar", 'b={{myvar}}', 'c=\\{{myvar}}', 'd={{foo={{bar}} print(bar)}}']


results = split_args(
        "foo=bar b={{myvar}} c=\\{{myvar}} d={% if 1==1 %}{% endif %} e={{foo={{bar}} print(bar)}}")
print(results)

# Generated at 2022-06-20 23:21:54.514941
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('abc') == {'abc': True}
    assert parse_kv('a=a') == {'a': 'a'}
    assert parse_kv('a="1"') == {'a': '1'}
    assert parse_kv('a="1 2"') == {'a': '1 2'}
    assert parse_kv('abc=abc') == {'abc': 'abc'}
    assert parse_kv("a='1'") == {'a': '1'}
    assert parse_kv("a='1 2'") == {'a': '1 2'}
    assert parse_kv("a='1 2' b='3'") == {'a': '1 2', 'b': '3'}

# Generated at 2022-06-20 23:21:56.981658
# Unit test for function parse_kv
def test_parse_kv():
    args = 'a=1 b="hello world" c="a=b c=d"'
    res = parse_kv(args)
    print(res)


# Generated at 2022-06-20 23:22:02.237641
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'hello']) == 'echo hello'
    assert join_args(['echo', 'hello', 'world']) == 'echo hello world'
    assert join_args(['echo', 'hello\n', 'world']) == 'echo hello\nworld'



# Generated at 2022-06-20 23:22:11.975801
# Unit test for function join_args
def test_join_args():
    # pylint: disable=too-many-branches,too-many-locals
    '''
    Test function join_args to see if it can join the args back
    to its original form.
    '''
    # the following list of raw commands are known to have problems
    # parsing. If you add a new command to this list, you need to
    # update the updated_raw_cmd.
    raw_cmd = []
    raw_cmd.append("/bin/bash '-c' 'echo hiera(\"variable_name\")' ';'")
    raw_cmd.append("/bin/bash '-c' 'echo ''\"$variable_name\"'''")
    raw_cmd.append("/bin/bash '-c' 'echo ''\"${variable_name}\"'''")

# Generated at 2022-06-20 23:22:13.025594
# Unit test for function split_args
def test_split_args():
    split_args("-y -s --one-two='foo bar'")

# Generated at 2022-06-20 23:22:23.657141
# Unit test for function split_args
def test_split_args():
    def compare_arguments(args):
        # Test that join_args(split_args(args)) == args
        split = split_args(args)
        joined = join_args(split)
        assert args == joined


# Generated at 2022-06-20 23:22:40.502853
# Unit test for function split_args

# Generated at 2022-06-20 23:22:51.335429
# Unit test for function split_args
def test_split_args():
    import ansible.constants as C

    for line in [u"foo bar baz",
                  u"foo bar baz",
                  u"foo bar baz",
                  u"foo bar baz",
                  u"foo bar baz",
                  u"foo bar baz",
                  u"foo bar baz",
                  u"foo bar baz",
                  u"foo bar baz",
                  u"foo bar baz",
                  u"foo bar baz",
                  u"foo bar baz",
                  u"foo bar baz"]:
        out = split_args(line)
        assert ['foo', 'bar', 'baz'] == out

    out = split_args(u"'foo bar baz'")
    assert ['\'foo bar baz\''] == out


# Generated at 2022-06-20 23:22:59.248685
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'k1=v1 k2="v 2"') == {u'k1': u'v1', u'k2': u'v 2'}
    assert parse_kv(u'k1="   v 1" k2=v2 ') == {u'k1': u'v 1', u'k2': u'v2'}
    assert parse_kv(u'k 1=v1 k2=v2') == {u'k 1': u'v1', u'k2': u'v2'}
    assert parse_kv(u'k1="v 1" k2=v2') == {u'k1': u'v 1', u'k2': u'v2'}

# Generated at 2022-06-20 23:23:08.748082
# Unit test for function join_args

# Generated at 2022-06-20 23:23:18.085711
# Unit test for function join_args
def test_join_args():

    assert join_args(['a', '\\', 'b', '"', 'c']) == 'a \\ "b" "c"'
    assert join_args(['a', '\\', 'b', '"c\'', 'd', '"', 'e']) == 'a \\ "b"c\'d" "e"'
    assert join_args(['a', '\\', 'b', '"c\'', '\\"d', '"', 'e']) == 'a \\ "b"c\'\\"d" "e"'
    assert join_args(['a', '"', 'b', 'c\'', '\\"d', '"', 'e']) == 'a "b"c\'\\"d" "e"'

# Generated at 2022-06-20 23:23:20.901533
# Unit test for function join_args
def test_join_args():
    s = ['"first argument"', "'second argument'"]
    assert join_args(s) == '"first argument" \'second argument\''


# Generated at 2022-06-20 23:23:23.354416
# Unit test for function join_args
def test_join_args():
    test_str = 'foo\nbar\nbaz\n'
    assert join_args(split_args(test_str)) == test_str



# Generated at 2022-06-20 23:23:26.918703
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '$VAR',
                      '\n', 'echo', '$VAR']) == "echo $VAR\necho $VAR"



# Generated at 2022-06-20 23:23:36.728155
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'key1=value1 key2=value2') == {
        u'key1': u'value1',
        u'key2': u'value2',
    }
    assert parse_kv(u'key1="value1 key2=value2"') == {
        u'key1': u'value1 key2=value2',
    }
    assert parse_kv(u'key1="key1 goes here" key2="key2 goes here"') == {
        u'key1': u'key1 goes here',
        u'key2': u'key2 goes here',
    }
    assert parse_kv(u"key1='value1 key2=value2'") == {
        u'key1': u'value1 key2=value2',
    }
   

# Generated at 2022-06-20 23:23:39.167137
# Unit test for function split_args
def test_split_args():
    # Add tests here
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-20 23:23:50.170770
# Unit test for function split_args
def test_split_args():

    assert split_args(u'foo') == ['foo']
    assert split_args(u'foo bar') == ['foo', 'bar']
    assert split_args(u"'foo bar'") == ["'foo bar'"]
    assert split_args(u"'foo bar") == ["'foo bar"]
    assert split_args(u'foo bar' + u"'") == ['foo', "bar'"]
    assert split_args(u'foo bar\\') == ['foo', 'bar']
    assert split_args(u'foo "bar\\') == ['foo', '"bar']
    assert split_args(u'foo bar\\\nbaz') == ['foo', 'bar', 'baz']
    assert split_args(u'foo \\\nbar baz') == ['foo', 'bar', 'baz']

# Generated at 2022-06-20 23:24:00.539844
# Unit test for function parse_kv
def test_parse_kv():
    # Test parsing a simple string
    assert parse_kv('foo=bar') == {u'foo': u'bar'}

    # Test parsing a string containing an escaped equals sign
    assert parse_kv('foo\\=bar=baz') == {u'foo=bar': u'baz'}

    # Test parsing a string containing an escaped equals sign and other
    # escaped characters
    assert parse_kv(u'foo\\=bar=baz\\=blah') == {u'foo=bar': u'baz=blah'}

    # Test parsing a string containing a quoted value
    assert parse_kv('foo="bar baz"') == {u'foo': u'bar baz'}

    # Test parsing a string containing a quoted value with escaped quotes

# Generated at 2022-06-20 23:24:08.084722
# Unit test for function join_args
def test_join_args():
    from ansible.compat.tests import unittest

    def _test_join_args(expected_output, split_input):
        output = join_args(split_input)
        assert output == expected_output

    _test_join_args("", [""])
    _test_join_args("foo", ["foo"])
    _test_join_args("foo bar", ["foo", "bar"])
    _test_join_args("foo bar", ["foo", " ", "bar"])
    _test_join_args("foo\nbar", ["foo", "\n", "bar"])
    _test_join_args("foo\n bar", ["foo\n", " ", "bar"])
    _test_join_args("foo\n\nbar", ["foo\n", "\n", "bar"])
    _

# Generated at 2022-06-20 23:24:16.761409
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.six import PY3
    import sys
    import unittest

    if PY3:
        from unittest import mock
    else:
        import mock

    from ansible.module_utils._text import to_native, to_text

    stderr_message_enough_quotes = "A parameter is being split on whitespace but an equals sign is present. Did you forget to quote a parameter value?\n"
    stderr_message_not_enough_quotes = "A parameter is being split on whitespace but no equals sign is present. Did you forget to quote a parameter name?\n"
    stderr_message_no_closing_quote = "error parsing argument string, try quoting the entire line.\n"


# Generated at 2022-06-20 23:24:21.760744
# Unit test for function split_args
def test_split_args():
    # test basic logic
    assert split_args("foo=bar baz=\"{{this}} should be a single token\" {{foo_bar}}") == ['foo=bar', 'baz="{{this}} should be a single token"', '{{foo_bar}}']
    assert split_args("foo=bar baz=\"{{this}} should be a single token\"") == ['foo=bar', 'baz="{{this}} should be a single token"']
    assert split_args("foo=bar baz=\"{{this}} should be a single token\"\nfoo=bar") == ['foo=bar', 'baz="{{this}} should be a single token"\nfoo=bar']
    # test whitespace before and after args
    assert split_args("   foo=bar    ") == ['foo=bar']

# Generated at 2022-06-20 23:24:25.107467
# Unit test for function split_args

# Generated at 2022-06-20 23:24:29.903531
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("a=b") == ['a=b']
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a='b c=d'") == ["a='b c=d'"]
    assert split_args("a='b c=d' e=f") == ["a='b c=d'", 'e=f']
    assert split_args("a=\"b c=d\" e=f") == ['a="b c=d"', 'e=f']
    assert split_args("a='b c d' e=f") == ['a=\'b c d\'', 'e=f']

# Generated at 2022-06-20 23:24:36.859970
# Unit test for function parse_kv
def test_parse_kv():
    assert {'a': 'b', 'c': 'd'} == parse_kv('a=b c=d')
    assert {'a': 'b c', '_raw_params': 'd=e'} == parse_kv('a=b\\ c d=e')
    assert {'a': 'b', '_raw_params': 'c=d e=f'} == parse_kv('a=b c=d\\ e=f')
    assert {'a': 'b', '_raw_params': 'c=d\\ e=f'} == parse_kv('a=b c=d\\ e=f', check_raw=True)

# Generated at 2022-06-20 23:24:46.842910
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("a=b c=d e=f")
    assert options['a'] == 'b', options['a']
    assert options['c'] == 'd', options['c']
    assert options['e'] == 'f', options['e']

    options = parse_kv("a.b=c d.e=f g.h=i")
    assert options['a.b'] == 'c', options['a.b']
    assert options['d.e'] == 'f', options['d.e']
    assert options['g.h'] == 'i', options['g.h']

    options = parse_kv("a=b'c' d=e'f' g=h'i'")
    assert options['a'] == "bc", options['a']

# Generated at 2022-06-20 23:24:50.498134
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', 'b c', 'd']) == 'a b c d'
    assert join_args(['a\nb', 'c', 'd']) == 'a\nb c d'



# Generated at 2022-06-20 23:25:07.068414
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a="1 2" b=2 c=3') == {'a': '1 2', 'b': '2', 'c': '3'}
    assert parse_kv('a="1 $2" b=2 c=3') == {'a': '1 $2', 'b': '2', 'c': '3'}
    assert parse_kv('a="1\\"2" b=2 c=3') == {'a': '1"2', 'b': '2', 'c': '3'}

# Generated at 2022-06-20 23:25:17.929141
# Unit test for function split_args
def test_split_args():
    '''
    split_args() is used by modules and the ansible cli
    to split command line arguments for modules into a
    list of arguments

    This is a unit test for the above function
    '''


# Generated at 2022-06-20 23:25:28.077093
# Unit test for function join_args
def test_join_args():
    '''
    Unit test for function join_args.
    '''
    #
    # join two arguments.
    assert(join_args(['1', '2']) == '1 2')
    assert(join_args(['1 ', '2']) == '1  2')
    assert(join_args(['1', ' 2']) == '1  2')
    assert(join_args(['1 ', ' 2']) == '1   2')
    #
    # join with a line feed.
    assert(join_args(['1', '\n', '2']) == '1\n2')
    assert(join_args(['1\n', '2']) == '1\n2')
    assert(join_args(['1', '\n2']) == '1\n2')

# Generated at 2022-06-20 23:25:31.907462
# Unit test for function join_args
def test_join_args():
    print("Unit test for function join_args")
    assert join_args(['\n', 'a', ' ', 'b']) == '\na b'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a b']) == 'a b'
    print("Unit test for function join_args passed")


# Generated at 2022-06-20 23:25:37.556909
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c=\"foo bar\"") == [u"a=b", u"c=\"foo bar\""]
    assert split_args(u"a=b") == [u"a=b"]
    assert split_args(u"a=b c=\"foo bar\" d={{ e=f }} g={{ h=i }} j={{ k={{ l=m }} n=o }} p=q") == [u"a=b", u"c=\"foo bar\"", u"d={{ e=f }}", u"g={{ h=i }}", u"j={{ k={{ l=m }} n=o }}", u"p=q"]

# Generated at 2022-06-20 23:25:43.238324
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=zab') == {'foo': 'bar', 'baz': 'zab'}
    assert parse_kv('foo="with a quote"') == {'foo': 'with a quote'}
    assert parse_kv("foo='with a quote'") == {'foo': "with a quote"}

# Generated at 2022-06-20 23:25:51.627059
# Unit test for function join_args
def test_join_args():
    assert join_args(['one', 'two', 'three']) == 'one two three'
    assert join_args(['one\ntwo', 'three']) == 'one\ntwo three'
    assert join_args(['one', 'two\nthree']) == 'one two\nthree'
    assert join_args(['one\ntwo', 'three\nfour']) == 'one\ntwo three\nfour'
    assert join_args(['one\ntwo three', 'four\nfive six seven']) == 'one\ntwo three four\nfive six seven'
    assert join_args(['one', '"two three"']) == 'one "two three"'



# Generated at 2022-06-20 23:25:58.086390
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo= bar baz') == {'foo': 'bar baz'}
    assert parse_kv('foo="bar baz"') == {'foo': 'bar baz'}
    assert parse_kv('foo="bar baz" spam=eggs') == {'foo': 'bar baz', 'spam': 'eggs'}
    assert parse_kv('foo="bar baz" spam=eggs asdf') == {'foo': 'bar baz', 'spam': 'eggs asdf'}

# Generated at 2022-06-20 23:26:09.268024
# Unit test for function split_args
def test_split_args():
    assert split_args('--private-key=~/foo/bar') == ['--private-key=~/foo/bar']
    assert split_args('--private-key=~/foo/bar --vpc-subnet-id=subnet-1234abcd') == ['--private-key=~/foo/bar', '--vpc-subnet-id=subnet-1234abcd']
    assert split_args('--private-key=~/foo/bar --vpc-subnet-id=subnet-1234abcd --group-ids=sg-1234abcd') == ['--private-key=~/foo/bar', '--vpc-subnet-id=subnet-1234abcd', '--group-ids=sg-1234abcd']

# Generated at 2022-06-20 23:26:17.812205
# Unit test for function split_args

# Generated at 2022-06-20 23:26:39.214300
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(b"foo=bar") == {u'foo': u'bar'}
    assert parse_kv(b"foo='bar baz'") == {u'foo': u'bar baz'}
    assert parse_kv(b"foo='bar baz' spam='ham eggs'") == {u'spam': u'ham eggs', u'foo': u'bar baz'}
    assert parse_kv(b"foo='bar baz' spam='ham eggs'", check_raw=True) == {u'_raw_params': u'foo=\'bar baz\' spam=\'ham eggs\'', u'spam': u'ham eggs', u'foo': u'bar baz'}

# Generated at 2022-06-20 23:26:48.650098
# Unit test for function parse_kv
def test_parse_kv():
    kv = parse_kv('a=1 b=2 c=3 d="4 5" e="6 7" f="8=9" g="10=11" h="I \'m a lumberjack and I \'m okay" i="I don\'t want to go to sleep" j="I wanna stay up \'til for-ever!" k="\"I\'m a lumberjack and I\'m okay\"" l="this is a \\"test\\" of escaped quotes" m="this is an \\\\\\"unescaped\\\\" quote" n=\\\\o="this is an unescaped quote with a backslash at the end: \\\\\\\\"p=\\\\\\"this is an escaped quote with a backslash at the end: \\\\\""')

# Generated at 2022-06-20 23:26:58.517612
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar") == {u"foo": u"bar"};
    assert parse_kv(u"foo=bar baz=bang") == {u"foo": u"bar", u"baz": u"bang"};
    assert parse_kv(u"foo='bar' baz=bang") == {u"foo": u"bar", u"baz": u"bang"};
    assert parse_kv(u"foo=\"bar\" baz=bang") == {u"foo": u"bar", u"baz": u"bang"};
    assert parse_kv(u"foo=bar baz='bang'") == {u"foo": u"bar", u"baz": u"bang"};

# Generated at 2022-06-20 23:27:06.890167
# Unit test for function parse_kv
def test_parse_kv():
    x = 'wibble=a=b c=d e= f g h i="j k"'
    result = parse_kv(x, False)
    assert result == {'wibble': 'a=b', 'c': 'd', 'e': '', 'f': 'g', 'h': 'i=j k'}

    x = 'wibble=a=b c="d e" f="g h" i="j\"k"'
    result = parse_kv(x, False)
    assert result == {'wibble': 'a=b', 'c': 'd e', 'f': 'g h', 'i': 'j"k'}

    x = 'wibble=a=b c="d e" f=g h i="j k'
    result = parse_kv(x, False)

# Generated at 2022-06-20 23:27:17.661188
# Unit test for function join_args
def test_join_args():
    '''
    Unit test for function join_args
    '''
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', 'b', 'c', '\nd e f']) == 'a b c\nd e f'
    assert join_args(['a\nb', 'c', 'd e f']) == 'a\nb c d e f'
    assert join_args(['a\nb\nc', 'd\ne\nf', 'g h i']) == 'a\nb\nc d\ne\nf g h i'
    assert join_args(['\na', '\nb\nc', 'd\ne\nf', 'g h i']) == '\na \nb\nc d\ne\nf g h i'
   

# Generated at 2022-06-20 23:27:26.666285
# Unit test for function parse_kv
def test_parse_kv():
    assert {} == parse_kv(None)
    assert {u'foo': u'bar'} == parse_kv(u'foo=bar')
    assert {u'foo': u'bar baz'} == parse_kv(u'foo=bar baz')
    assert {u'foo': u'bar baz'} == parse_kv(u'foo="bar baz"')
    assert {u'foo': u'bar baz'} == parse_kv(u"foo='bar baz'")
    assert {u'foo': u'bar'} == parse_kv(u'foo=\'bar\'')
    assert {u'foo': u'bar'} == parse_kv(u'foo="bar"')

# Generated at 2022-06-20 23:27:38.276818
# Unit test for function join_args
def test_join_args():
    assert join_args(['a','b','c'])       == 'a b c'
    assert join_args(['a  b  c'])         == 'a  b  c'
    assert join_args(['a\nb\nc'])         == 'a\nb\nc'
    assert join_args(['a', 'b\nc'])       == 'a b\nc'
    assert join_args(['a\n', 'b c'])      == 'a\n b c'
    assert join_args(['a\n', 'b\nc'])     == 'a\n b\nc'
    assert join_args(['a\nb', 'c'])       == 'a\nb c'
    assert join_args(['a\r\nb', 'c'])     == 'a\r\nb c'

# Generated at 2022-06-20 23:27:43.006961
# Unit test for function split_args
def test_split_args():
    # Basic tests
    assert split_args("foo") == ["foo"]
    assert split_args("foo bar") == ["foo", "bar"]
    assert split_args("foo bar baz") == ["foo", "bar", "baz"]
    assert split_args("foo bar\nbaz") == ["foo", "bar\n", "baz"]
    assert split_args("foo bar baz\nqux") == ["foo", "bar", "baz\n", "qux"]
    assert split_args("foo\nbar baz") == ["foo\n", "bar", "baz"]
    assert split_args("foo\nbar baz\nqux") == ["foo\n", "bar", "baz\n", "qux"]

# Generated at 2022-06-20 23:27:49.678042
# Unit test for function join_args
def test_join_args():
    assert join_args(['/bin/bash']) == '/bin/bash'
    assert join_args(['/bin/bash', '-c', 'exit 1']) == '/bin/bash -c exit 1'
    assert join_args(['/bin/bash', '-c', '''\
            echo "Hello, World!"
            exit 1''']) == '''/bin/bash -c \
            echo "Hello, World!"
            exit 1'''
    assert join_args(['/bin/bash', '-c', '''\
            echo "Hello, World!"
            exit 1''']) =='''/bin/bash -c \
            echo "Hello, World!"
            exit 1'''



# Generated at 2022-06-20 23:28:00.290358
# Unit test for function split_args
def test_split_args():
    '''
    tests for split_args
    '''
    params = ['a=b', 'c', 'd="foo bar"', 'e="foo', 'bar"' '"f', 'g"', 'h', '"i', 'j"', 'k', 'l="m', 'n"', 'o', '"pqrs"']
    params2 = ['a=b', 'c', 'd="foo bar"', 'e="foo bar"', '"f g"', 'h', '"i j"', 'k', 'l="m n"', 'o', '"pqrs"']

# Generated at 2022-06-20 23:28:16.788286
# Unit test for function split_args
def test_split_args():
    assert split_args("foo bar biz") == ["foo", "bar", "biz"]
    assert split_args("'''") == ["'''"]
    assert split_args("'foo bar biz'") == ["'foo bar biz'"]
    assert split_args("\"foo bar biz\"") == ["\"foo bar biz\""]
    assert split_args("foo bar \"foo bar biz\"") == ["foo", "bar", "\"foo bar biz\""]
    assert split_args("foo bar biz\\") == ["foo", "bar", "biz"]
    assert split_args("foo bar\\") == ["foo", "bar"]
    assert split_args("foo bar \\ biz") == ["foo", "bar", "biz"]

# Generated at 2022-06-20 23:28:25.710769
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['a']) == 'a'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', '\nb']) == 'a \nb'
    assert join_args(['a\n', 'b']) == 'a\n b'
    assert join_args(['a\n', 'b\n']) == 'a\n b\n'
    assert join_args(['a\n', '\nb']) == 'a\n \nb'
    assert join_args(['a\n', '\nb\n']) == 'a\n \nb\n'



# Generated at 2022-06-20 23:28:29.376781
# Unit test for function join_args
def test_join_args():
    assert join_args(['hello', 'world']) == 'hello world'
    assert join_args(['hello\tworld']) == 'hello\tworld'
    assert join_args(['hello', 'world', 'foo\nbar']) == 'hello world foo\nbar'



# Generated at 2022-06-20 23:28:38.091369
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\n', 'b']) == 'a\nb'
    assert join_args(['a', '\nb']) == 'a \nb'
    assert join_args(['a\n', '\nb']) == 'a\n \nb'
    assert join_args(['a\n', '\nb\nc']) == 'a\n \nb\nc'
    assert join_args(['a\n', '\nb\nc', 'd']) == 'a\n \nb\nc d'
    assert join_args(['a\n', '\nb\nc\n', 'd']) == 'a\n \nb\nc\n d'

# Generated at 2022-06-20 23:28:47.230890
# Unit test for function parse_kv
def test_parse_kv():
    # test 1
    result = parse_kv('test_key=test_value')
    assert result['test_key'] == 'test_value'

    # test 2
    result = parse_kv('test_key=test_value other_test_key = other_test_value')
    assert result['test_key'] == 'test_value'
    assert result['other_test_key'] == 'other_test_value'

    # test 3
    result = parse_kv('test_key="test_value" other_test_key = "other_test_value"')
    assert result['test_key'] == 'test_value'
    assert result['other_test_key'] == 'other_test_value'

    # test 4

# Generated at 2022-06-20 23:28:56.671297
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d e f') == {'a': 'b', 'c': 'd', '_raw_params': 'e f'}
    assert parse_kv('a=b c="d e"') == {'a': 'b', 'c': 'd e'}
    assert parse_kv('') == {}
    assert parse_kv('a="bar=baz"') == {'a': 'bar=baz'}
    assert parse_kv('a="bar=baz" c=d') == {'a': 'bar=baz', 'c': 'd'}
    assert parse_kv('abc def') == {'_raw_params': 'abc def'}

# Generated at 2022-06-20 23:29:06.171873
# Unit test for function parse_kv
def test_parse_kv():
    def assert_parse(in_, out):
        assert parse_kv(in_) == out

    assert_parse(u'test_key="test_value"',
            {u'test_key': u'test_value'})
    assert_parse(u'foo=["bar1","bar2"]',
            {u'foo': u'["bar1","bar2"]'})
    assert_parse(u'foo=b\\"ar', {u'foo': u'b\\"ar'})
    assert_parse(u'foo="b\\"ar"', {u'foo': u'b"ar'})
    assert_parse(u'foo="bar1","bar2"', {u'foo': u'bar1,"bar2"'})

# Generated at 2022-06-20 23:29:16.048342
# Unit test for function parse_kv
def test_parse_kv():
    params = "param1=value1 param2='value2' param3=\"value3\" param4='value4'\"value5\"' param5='value6\"value7\"' param6=value8\\=value9"
    result = parse_kv(params)

    assert result['param1'] == 'value1'
    assert result['param2'] == 'value2'
    assert result['param3'] == 'value3'
    assert result['param4'] == 'value4"value5"'
    assert result['param5'] == 'value6"value7"'
    assert result['param6'] == 'value8=value9'



# Generated at 2022-06-20 23:29:29.736364
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv("a=b c=d")
    assert result == {'a': 'b', '_raw_params': ' c=d', 'c': 'd'}

    result = parse_kv("a=b 'c=d e'")
    assert result == {'a': 'b', 'c=d e': ''}

    result = parse_kv("a=b 'c=d e' f=g")
    assert result == {'a': 'b', '_raw_params': " 'c=d e' f=g", 'c=d e': '', 'f': 'g'}

    result = parse_kv("a=b 'c=d\"e' f=g")