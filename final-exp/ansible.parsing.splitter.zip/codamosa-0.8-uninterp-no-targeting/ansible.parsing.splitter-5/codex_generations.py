

# Generated at 2022-06-20 23:21:29.429305
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('test=test', check_raw=True) == {u'test': u'test', u'_raw_params': u'test=test'}
    assert parse_kv('test=test') == {u'test': u'test'}
    assert parse_kv('test=test string') == {u'test': u'test string'}
    assert parse_kv('test=test string=stringy') == {u'test': u'test string=stringy'}
    assert parse_kv('test="test string="stringy"') == {u'test': u'test string="stringy'}
    assert parse_kv('test="test string=""stringy"') == {u'test': u'test string=""stringy'}

# Generated at 2022-06-20 23:21:40.150287
# Unit test for function split_args
def test_split_args():
    _split_args = split_args
    try:
        from ansible.cli import CLI
        import ansible.constants as C
        C.DEFAULT_LOCAL_TMP = '/tmp'
        cli = CLI(args=[])
        cli._load_plugins()
        cli._parser.load_plugins()
        split_args = cli._get_action_args(split_args)[0]
    except:
        pass

    # Test when split on a space inside the quotes
    assert _split_args(u"a=b c='foo bar'") == ['a=b', 'c=foo bar']

    # Test when split on a space outside the quotes
    assert _split_args(u"a=b c=foo bar") == ['a=b', 'c=foo bar']

    # Test when split on a

# Generated at 2022-06-20 23:21:48.958738
# Unit test for function parse_kv

# Generated at 2022-06-20 23:21:57.428887
# Unit test for function split_args
def test_split_args():
    args = "{% for i in foo %}{{ foo }}{% endfor %}"
    params = split_args(args)
    assert params == ['{%', 'for', 'i', 'in', 'foo', '%}', '{{', 'foo', '}}', '{%', 'endfor', '%}']

    args = "{# foo #}use_backslashes=no {{ foo }}{# foo #}"
    params = split_args(args)
    assert params == ['{#', 'foo', '#}', 'use_backslashes=no', '{{', 'foo', '}}', '{#', 'foo', '#}']

    args = "{# foo #}use_backslashes=no {# broken #} {{ foo }}{# foo #}"
    params = split_args(args)

# Generated at 2022-06-20 23:22:04.705128
# Unit test for function join_args
def test_join_args():
    for input, output in [
            (['hello'], 'hello'),
            (['hello,', 'world'], 'hello, world'),
            (['hello,\n', 'world'], 'hello,\nworld'),
            (['hello,\n', 'world', '\n', '!'], 'hello,\nworld\n!')]:
        assert join_args(input) == output



# Generated at 2022-06-20 23:22:13.267153
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'one=1 two="2" three=3') == {"one": "1", "_raw_params": "one=1 two=\"2\" three=3"}
    assert parse_kv(u'one=1 two="2" three=3', check_raw=True) == {"one": "1", "two": "2", "three": "3", "_raw_params": "one=1 two=\"2\" three=3"}
    assert parse_kv(u'one=1 two="2" three=3') == {"one": "1", "_raw_params": "one=1 two=\"2\" three=3"}

# Generated at 2022-06-20 23:22:25.658531
# Unit test for function split_args

# Generated at 2022-06-20 23:22:35.635901
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar baz=qux") == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv("foo=bar baz=qux", check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv("foo='bar baz' qux=quxx") == {u'foo': u'bar baz', u'qux': u'quxx'}

# Generated at 2022-06-20 23:22:40.740502
# Unit test for function join_args
def test_join_args():
    assert join_args(split_args('[[\n  1 -eq 1 ]] && echo yay')) == '[[\n  1 -eq 1 ]] && echo yay'
    assert join_args(split_args('foo &&\n bar')) == 'foo &&\n bar'



# Generated at 2022-06-20 23:22:45.094381
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['a', '-b', 'c']) == 'a -b c'
    assert join_args(['a\n', '-b', ' c']) == 'a\n-b c'



# Generated at 2022-06-20 23:25:10.997836
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common._collections_compat import Mapping

    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar "baz qux"') == ['foo', 'bar', '"baz qux"']
    assert split_args('foo bar "baz qux" "a=" b=c') == ['foo', 'bar', '"baz qux"', '"a="', 'b=c']
    assert split_args('foo bar \'baz qux\'') == ['foo', 'bar', '\'baz qux\'']
    assert split_args('foo bar \'a=b b=c\'') == ['foo', 'bar', '\'a=b b=c\'']
   

# Generated at 2022-06-20 23:25:20.332577
# Unit test for function join_args
def test_join_args():
    # First, test a simple case
    test_list = ['a', 'b', 'c', 'd']
    assert join_args(test_list) == 'a b c d'
    # Second, test a case with embedded newlines
    test_list = ['a', 'b', 'c', 'd\ne', 'f']
    assert join_args(test_list) == 'a b c d\ne f'
    # Third, test a case with a path at the end
    test_list = ['a', 'b', 'c', 'd', 'e', '/tmp/mytask']
    assert join_args(test_list) == 'a b c d e /tmp/mytask'


# Generated at 2022-06-20 23:25:24.809892
# Unit test for function parse_kv
def test_parse_kv():
    print ("======= test for parse_kv =======")
    args = 'test1=abc test2=abc test3=abc '
    print ('args:', args)
    options = parse_kv(args)
    print ('options:', options)

# splitter for use with shlex for splitting a string into
# options and arguments

# Generated at 2022-06-20 23:25:33.148610
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar' d='foo\nbar'") == ['a=b', "c='foo bar'", "d='foo\nbar'"]
    assert split_args("a=b 'c=foo bar' d='foo\nbar'") == ['a=b', "'c=foo bar'", "d='foo\nbar'"]
    assert split_args("a=b c='foo\nbar' d='foo\nbar'") == ['a=b', "c='foo\nbar'", "d='foo\nbar'"]
    assert split_args("a=b c='foo\nbar' d='foo  \nbar'") == ['a=b', "c='foo\nbar'", "d='foo  \nbar'"]

# Generated at 2022-06-20 23:25:44.785611
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '$HOME', '|', 'wc', '-l']) == 'echo $HOME | wc -l'
    assert join_args(['echo', '$HOME', '\n', '|', '\n', 'wc', '-l']) == 'echo $HOME \n | \n wc -l'
    # Test for comment
    assert join_args(['# echo $HOME', '|', 'wc', '-l']) == '# echo $HOME | wc -l'
    assert join_args(['echo', '# $HOME', '|', 'wc', '-l']) == 'echo # $HOME | wc -l'

# Generated at 2022-06-20 23:25:50.665995
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'foo', 'bar']) == 'a b foo bar'
    assert join_args(['a', 'b', 'foo \nbar']) == 'a b foo \nbar'
    assert join_args(['a', 'b', 'foo \nbar \n\n']) == 'a b foo \nbar \n\n'
    assert join_args(['a', 'b', 'foo bar \n', '\n']) == 'a b foo bar \n \n'
    assert join_args(['a', 'b', 'foo bar \n\n', '\n']) == 'a b foo bar \n\n \n'

# Generated at 2022-06-20 23:25:56.075858
# Unit test for function join_args
def test_join_args():
    assert join_args(['hello', 'world', r'c:\temp\ping.exe']) == 'hello world c:\\temp\\ping.exe'
    assert join_args(['hello\nworld']) == 'hello\nworld'
    assert join_args(['hello', '\n', 'world']) == 'hello \n world'
    assert join_args(['hello', '\nworld']) == 'hello \nworld'
    assert join_args(['hello\n', 'world']) == 'hello\n world'



# Generated at 2022-06-20 23:26:06.657229
# Unit test for function join_args
def test_join_args():
    assert join_args(['a','b','c']) == 'a b c'
    assert join_args(['a','\nb','c']) == 'a \nb c'
    assert join_args(['a','b','c\n']) == 'a b c\n'
    assert join_args(['a\n', 'b\n', 'c\n']) == 'a\n b\n c\n'
    assert join_args(['a', 'b', 'c\n']) == 'a b c\n'
    assert join_args(['a\n', 'b', 'c']) == 'a\n b c'
    assert join_args(['a\n', '\nb', 'c']) == 'a\n \nb c'

# Generated at 2022-06-20 23:26:13.145918
# Unit test for function join_args
def test_join_args():
    test_param_sets = [['hello', 'world', '\n', "it's good"],
                      ['hello world\n', "it's good"]]
    expected_outputs = ["hello world\nit's good",
                      'hello world\nit\'s good']
    for test_param, expected_output in zip(test_param_sets, expected_outputs):
        assert join_args(test_param) == expected_output



# Generated at 2022-06-20 23:26:19.647878
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}

    # simple
    assert parse_kv('foo=bar key="value"') == {'foo': 'bar', 'key': 'value'}

    # escaped quotes
    assert parse_kv('foo=bar key=\"value\"') == {'foo': 'bar', 'key': '"value"'}
    assert parse_kv('foo=bar key=\\"value\\"') == {'foo': 'bar', 'key': '"value"'}
    assert parse_kv('foo=bar key=\\"value\\"') == {'foo': 'bar', 'key': '"value"'}

    # escaped newlines

# Generated at 2022-06-20 23:26:44.205606
# Unit test for function split_args
def test_split_args():
    # split_args should leave simple args unchanged
    assert split_args("a=b c='d e' f=\"g h\"") == ['a=b', "c='d e'", 'f="g h"']

    # whitespace characters in a quoted string are retained
    assert split_args("c='d e'") == ["c='d e'"]

    # unbalanced quotes are not allowed
    from ansible.errors import AnsibleParserError
    try:
        split_args("c='")
        assert False
    except AnsibleParserError:
        pass

    # quoted strings with escaped quotes in them are preserved
    assert split_args("c='d\\'e'") == ["c='d\\'e'"]

    # leading/trailing whitespace is preserved

# Generated at 2022-06-20 23:26:54.396340
# Unit test for function split_args
def test_split_args():
    # A basic test
    basic_test = 'a=b foo="bar baz"'
    assert split_args(basic_test) == ['a=b', 'foo="bar baz"']

    # Tests for duplicate whitespace
    dupwhitespace = 'a=b foo="bar baz" more="foo bar"'
    assert split_args(dupwhitespace) == ['a=b', 'foo="bar baz"', 'more="foo bar"']

    # Tests for multi-line inputs
    multiline_test = 'a=b foo="bar\nbaz" more="foo bar"'
    assert split_args(multiline_test) == ['a=b', 'foo="bar\nbaz"', 'more="foo bar"']

    # Testing for backslash escaping that goes with quotes

# Generated at 2022-06-20 23:26:58.163921
# Unit test for function join_args
def test_join_args():
    assert join_args(['a','b','c']) == 'a b c'
    assert join_args(['a','\n','b','c']) == 'a\nb c'
    assert join_args(['\n','a','\n','b','c']) == '\na\nb c'



# Generated at 2022-06-20 23:27:06.671802
# Unit test for function parse_kv
def test_parse_kv():
    d = parse_kv('a=b c="d" e=\'f\' g="h h" i=\'j j\' k=l,v=w x="y z"')
    assert( d[u'a'] == u'b' )
    assert( d[u'c'] == u'd' )
    assert( d[u'e'] == u'f' )
    assert( d[u'g'] == u'h h' )
    assert( d[u'i'] == u'j j' )
    assert( d[u'k'] == u'l' )
    assert( d[u'v'] == u'w' )
    assert( d[u'x'] == u'y z' )

# Generated at 2022-06-20 23:27:17.530782
# Unit test for function split_args
def test_split_args():
    import json
    import pprint

# Generated at 2022-06-20 23:27:26.558220
# Unit test for function split_args
def test_split_args():
    assert [u'a=b', u'c=d', u'echo', u'{{', u'foo', u'}}', u'&&', u'bar', u'|', u'baz', u'>', u'/tmp/file.txt'] == split_args('a=b c=d echo "{{ foo }}" && bar | baz > /tmp/file.txt')
    assert [u'a=b', u'c=d', u'echo', u'{{', u'foo', u'}}', u'&&', u'bar', u'|', u'baz', u'>', u'/tmp/file.txt'] == split_args('a=b c=d echo "{{ foo }}" && bar | baz > /tmp/file.txt')
    assert [u'{{', u'foo', u'}}'] == split_args

# Generated at 2022-06-20 23:27:38.276621
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing: parse_kv')
    assert parse_kv('foo=bar bar=baz') == {'foo': 'bar', 'bar': 'baz'}
    assert parse_kv(u"foo=bar bar=baz") == {'foo': 'bar', 'bar': 'baz'}
    assert parse_kv(b"foo=bar bar=baz") == {'foo': 'bar', 'bar': 'baz'}
    assert parse_kv('foo=bar bar=baz', check_raw=True) == {'foo': 'bar', 'bar': 'baz'}
    assert parse_kv(u"foo=bar bar=baz", check_raw=True) == {'foo': 'bar', 'bar': 'baz'}

# Generated at 2022-06-20 23:27:47.230283
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.six import PY3
    raw_params = "rm -rf /home/myuser"
    assert parse_kv(raw_params, check_raw=True).get('_raw_params') == raw_params
    raw_params = "   rm -rf /home/myuser  "
    assert parse_kv(raw_params, check_raw=True).get('_raw_params') == raw_params
    raw_params = "rm -rf /home/myuser   --force"
    assert parse_kv(raw_params, check_raw=True).get('_raw_params') == raw_params
    raw_params = "   rm -rf /home/myuser   --force  "

# Generated at 2022-06-20 23:27:56.043637
# Unit test for function split_args
def test_split_args():
    # TODO: rewrite tests to not use fixed indexes and use a more test
    # unit framework.
    print('FIXME: rewrite tests to a more test friendly format')
    print('FIXME: catch exceptions raised and fail test')
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params[0] == 'a=b'
    assert params[1] == 'c="foo bar"'

    args = 'a="b c"'
    params = split_args(args)
    assert params[0] == 'a="b c"'

    args = 'a={{ b }}'
    params = split_args(args)
    assert params[0] == 'a={{ b }}'

    args = 'a="b {{ c }}"'
    params = split_args(args)
    assert params

# Generated at 2022-06-20 23:28:06.281460
# Unit test for function parse_kv
def test_parse_kv():
    '''
    parse_kv unit test
    '''

    assert parse_kv("") == {}
    assert parse_kv("a=1") == {u'a': u'1'}
    assert parse_kv("a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv("a=1 b=2 c=3") == {u'a': '1', u'b': '2', u'c': '3'}
    assert parse_kv("a=1 b='2 c'") == {u'a': '1', u'b': '2 c'}
    assert parse_kv("a=1 b=\"2 c\"") == {u'a': '1', u'b': '2 c'}
    assert parse

# Generated at 2022-06-20 23:28:25.091014
# Unit test for function split_args

# Generated at 2022-06-20 23:28:34.098473
# Unit test for function parse_kv
def test_parse_kv():
    our_dict = parse_kv('key="value" no_space_key=no_space_value')
    assert our_dict['key'] == u'value'
    assert our_dict['no_space_key'] == u'no_space_value'
    our_dict = parse_kv('test_key=test_value_1 with_space_key = "test value 2"')
    assert our_dict['test_key'] == u'test_value_1'
    assert our_dict['with_space_key'] == 'test value 2'
    our_dict = parse_kv('with_quote_key = "test\\"\\""')
    assert our_dict['with_quote_key'] == 'test""'

# Generated at 2022-06-20 23:28:39.108804
# Unit test for function join_args
def test_join_args():
    assert join_args(['ls', '-l']) == 'ls -l'
    assert join_args(['ls', '-l\n']) == 'ls -l\n'
    assert join_args(['ls', '-l\n', '-a']) == 'ls -l\n-a'
    assert join_args(['ls', '\n', '-l']) == 'ls \n-l'
    assert join_args(['ls\n', '\n', '-l', '-a']) == 'ls\n \n-l -a'
    assert join_args(['ls\n', '\n', '-l', '-a\n']) == 'ls\n \n-l -a\n'

# Generated at 2022-06-20 23:28:48.313205
# Unit test for function split_args
def test_split_args():
  # Use the function below to verify that args have been split correctly
  def arg_splits_are_identified(args, expect_split=False):
    # If Multiple args are passed in, then it is expected each one gets split into a list.
    # If only one arg is passed in, then it is expected that it does NOT get split into a list.
    if expect_split:
      list_length = len(args)
    else:
      list_length = 1

    params = split_args(args)
    assert len(params) == list_length, "failed to split args: %s" % params

  arg_splits_are_identified("a=b c=d", True)
  arg_splits_are_identified("a=b c='d e' f='g h'", True)
  arg_splits_are_identified

# Generated at 2022-06-20 23:28:58.004963
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {u'b': u'2', u'a': u'1'}
    assert parse_kv('a="a=1" b="b=2"') == {u'b': u'b=2', u'a': u'a=1'}
    assert parse_kv('a=1 b=2 c=3 d="d=4"') == {u'b': u'2', u'a': u'1', u'c': u'3', u'd': u'd=4'}
    assert parse_kv('a=1 b=bar="baz faz" d=4') == {u'a': u'1', u'b': u'bar="baz faz"', u'd': u'4'}
    assert parse_kv

# Generated at 2022-06-20 23:29:07.496246
# Unit test for function parse_kv
def test_parse_kv():
    #test 1
    args="ansible_ssh_user='james.cammarata' ansible_ssh_pass='password' ansible_python_interpreter='/usr/bin/python3'"
    x=parse_kv(args,True)

    #test 2 
    args="foo=bar"
    x=parse_kv(args,False)
    #assert x['foo'] == 'bar'

    #test 3
    args='foo="bar baz" hello="world"'
    x=parse_kv(args,True)
    #assert x['foo'] == 'bar baz' and x['hello'] == 'world'



# split_args adapted from https://github.com/ansible/ansible/blob/devel/lib/ansible/modules/core/async_wrapper.py#L

# Generated at 2022-06-20 23:29:18.387593
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', 'b\n', 'c']) == 'a\nb c'
    assert join_args(['a', 'b \n', 'c']) == 'a\nb c'
    assert join_args(['a', ' b\n', 'c']) == 'a\n b c'
    assert join_args(['a', 'b\n ', 'c']) == 'a\nb\n c'
    assert join_args(['a', 'b\n\n', 'c']) == 'a\nb\n\nc'
    assert join_args(['a\n', 'b\n', 'c']) == 'a\nb\nc'

# Generated at 2022-06-20 23:29:29.440813
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv('foo=bar baz=quux')
    assert result.get('foo') == 'bar'
    assert result.get('baz') == 'quux'
    assert result.get('_raw_params') is None

    result = parse_kv('foo=bar baz')
    assert result.get('foo') == 'bar'
    assert result.get('_raw_params') == 'baz'



# Split args adapted from Lib/shlex.py from the Python source code.
_find_unsafe = re.compile(r'[^\w@%+=:,./-]').search

