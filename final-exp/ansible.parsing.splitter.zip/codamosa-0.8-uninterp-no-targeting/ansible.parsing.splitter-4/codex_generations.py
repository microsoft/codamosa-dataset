

# Generated at 2022-06-20 23:20:33.161496
# Unit test for function split_args
def test_split_args():
    # This is a very simplified test
    # Opted not to port whole test cases from Ansible, and instead
    # choose to test a few cases which represent the common use cases
    # in networking modules
    assert split_args('show version') == ['show', 'version']

    assert split_args('logging level critical') == ['logging', 'level', 'critical']

    assert split_args('logging level critical \\') == ['logging', 'level', 'critical', '\\']

    assert split_args('logging level {{level}}') == ['logging', 'level', '{{level}}']

    assert split_args('logging level {{level}} \\') == ['logging', 'level', '{{level}}', '\\']


# Generated at 2022-06-20 23:20:42.044786
# Unit test for function join_args
def test_join_args():
    if join_args(['a', 'b', 'c']) != 'a b c':
        raise Exception("join_args('a', 'b', 'c') != 'a b c'")
    if join_args(['a\n', ' b', ' c']) != 'a\n b c':
        raise Exception("join_args('a', 'b', 'c') != 'a\n b c'")
    if join_args(['a', 'b \n', 'c']) != 'a b \n c':
        raise Exception("join_args('a', 'b', 'c') != 'a b \n c'")



# Generated at 2022-06-20 23:20:48.859406
# Unit test for function parse_kv
def test_parse_kv():
    import sys
    import json


# Generated at 2022-06-20 23:21:00.173738
# Unit test for function parse_kv
def test_parse_kv():

    def _test(args, expected):
        actual = parse_kv(args)
        assert actual == expected, \
            "KV parsing failed on arguments: %s" % args

    assert parse_kv(None) == {}
    _test("a=b c=d", {u'a': u'b', u'c': u'd'})
    _test("a=b=c c=d", {u'a': u'b=c', u'c': u'd'})
    _test("a='b c' c=d", {u'a': u'b c', u'c': u'd'})
    _test("a=\"b c\" c=d", {u'a': u'b c', u'c': u'd'})

# Generated at 2022-06-20 23:21:07.869918
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('key=value key2="value2"')                               == {'key': u'value', 'key2': u'value2'}
    assert parse_kv('key=value key2="value2 with spaces"')                   == {'key': u'value', 'key2': u'value2 with spaces'}
    assert parse_kv('key=value key2="value2_with_underscores"')              == {'key': u'value', 'key2': u'value2_with_underscores'}
    assert parse_kv('key=value key2="value2-with-hyphens"')                  == {'key': u'value', 'key2': u'value2-with-hyphens'}

# Generated at 2022-06-20 23:21:18.248011
# Unit test for function split_args
def test_split_args():
    import sys
    import os
    import json


# Generated at 2022-06-20 23:21:21.408451
# Unit test for function join_args
def test_join_args():
    test_string = '''- name: do something
  shell: /bin/foo
'''
    result = join_args(split_args(test_string))
    assert result == test_string



# Generated at 2022-06-20 23:21:29.623530
# Unit test for function join_args
def test_join_args():
    assert(join_args([]) == '')
    assert(join_args(['foo']) == 'foo')
    assert(join_args(['foo', 'bar']) == 'foo bar')
    assert(join_args(['foo', '\nbar']) == 'foo\nbar')
    assert(join_args(['foo', 'bar', '\n baz']) == 'foo bar\n baz')
    assert(join_args(['foo', 'bar', '\n', 'baz']) == 'foo bar\nbaz')
    assert(join_args(['foo', 'bar', '\'baz']) == "foo bar 'baz")
    assert(join_args(['foo', 'bar', '"baz\nqux']) == 'foo bar "baz\nqux')

# Generated at 2022-06-20 23:21:38.153025
# Unit test for function join_args
def test_join_args():
    s = split_args("""
        "hello
        world" 'foo bar'\\\\"""
    )
    assert join_args(s) == """
        hello world foo bar\\
    """
    s = split_args("""
        hello world \\\\\\
        foo bar"""
    )
    assert join_args(s) == """
        hello world \\
        foo bar
    """
    s = split_args("""
        hello
        world \\\\\\
        foo
        bar"""
    )
    assert join_args(s) == """
        hello world \\
        foo
        bar
    """



# Generated at 2022-06-20 23:21:47.356395
# Unit test for function split_args
def test_split_args():
    # Test expected split.
    s = 'a b c'
    assert split_args(s) == ['a', 'b', 'c']
    # Test whitespace inside quotes.
    s = 'a b "c d"'
    assert split_args(s) == ['a', 'b', '"c d"']
    # Test quotes inside quotes.
    s = 'a b "c \'d\'"'
    assert split_args(s) == ['a', 'b', '"c \'d\'"']
    # Test depth calculation.
    s = 'a b "c {{ d }} e"'
    assert split_args(s) == ['a', 'b', '"c {{ d }} e"']
    # Test depth calculation with quotes.
    s = 'a b "c {{ d }}" e'

# Generated at 2022-06-20 23:22:01.420151
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo', 'bar\nbaz']) == 'foo bar\nbaz'
    assert join_args(['foo', 'bar\n   baz']) == 'foo bar\n   baz'



# Generated at 2022-06-20 23:22:05.465638
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', "b\n", 'c']) == "a\nb\n c"



# Generated at 2022-06-20 23:22:13.809968
# Unit test for function split_args
def test_split_args():
    '''
    Unit tests for function split_args
    '''


# Generated at 2022-06-20 23:22:24.263870
# Unit test for function split_args
def test_split_args():
    params = split_args('key=value')
    assert params == ['key=value'], "key=value should be split into ['key=value']"

    params = split_args('key=value another=test')
    assert params == ['key=value', 'another=test'], "key=value another=test should be split into ['key=value', 'another=test']"

    params = split_args('key=value another=test \\')
    assert params == ['key=value', 'another=test'], "key=value another=test \\ should be split into ['key=value', 'another=test']"

    params = split_args('key=value another=test \\\\n')

# Generated at 2022-06-20 23:22:31.467064
# Unit test for function split_args
def test_split_args():
    import os
    import sys
    import pytest
    print("Running unit test for function split_args")
    my_dir = os.path.dirname(__file__)
    parent_dir = os.path.join(my_dir, '..')
    sys.path.insert(0, parent_dir)
    from testlib.playbook_runner import PlaybookRunner
    playbook = my_dir + '/test_split_args.yml'
    runner = PlaybookRunner(playbook)
    runner.run()


# Generated at 2022-06-20 23:22:39.445105
# Unit test for function split_args
def test_split_args():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert split_args('') == []
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo bar baz duh') == ['foo', 'bar', 'baz', 'duh']
    assert split_args('foo bar baz duh=hum') == ['foo', 'bar', 'baz', 'duh=hum']
    assert split_args('foo bar baz duh=hum fub') == ['foo', 'bar', 'baz', 'duh=hum', 'fub']


# Generated at 2022-06-20 23:22:50.732409
# Unit test for function parse_kv
def test_parse_kv():
    # Test with empty string
    args = parse_kv(None)
    assert args == {}

    # Test with simple key-value
    args = parse_kv('username=admin')
    assert args == {'username': 'admin'}
    args = parse_kv('username="admin"')
    assert args == {'username': '"admin"'}
    args = parse_kv('username="a\t=dmin"')
    assert args == {'username': 'a\t=dmin'}

    # Test with multiple key-values
    args = parse_kv('username=admin password=12345')
    assert args == {'username': 'admin', 'password': '12345'}
    args = parse_kv('username="admin" password="12345"')

# Generated at 2022-06-20 23:22:55.559626
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args(' ') == []
    assert split_args('   ') == []
    assert split_args('a') == ['a']
    assert split_args('  a') == ['a']
    assert split_args('  a  ') == ['a']
    assert split_args('a  ') == ['a']
    assert split_args('a  b') == ['a', 'b']
    assert split_args('a b') == ['a', 'b']
    assert split_args('a  b  c') == ['a', 'b', 'c']
    assert split_args('  a  b  c  ') == ['a', 'b', 'c']

# Generated at 2022-06-20 23:22:57.843069
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo', 'bar', '\nbaz']) == 'foo bar\nbaz'



# Generated at 2022-06-20 23:23:07.507418
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('one=1 two=2') == {u'one': u'1', u'two': u'2'}
    assert parse_kv(' one=1 two=2') == {u'one': u'1', u'two': u'2'}
    assert parse_kv(' one=1  two=2') == {u'one': u'1', u'two': u'2'}
    assert parse_kv('one=1 two=2 ') == {u'one': u'1', u'two': u'2'}
    assert parse_kv('one=1 two=2   ') == {u'one': u'1', u'two': u'2'}

# Generated at 2022-06-20 23:23:26.917652
# Unit test for function parse_kv

# Generated at 2022-06-20 23:23:36.728375
# Unit test for function split_args
def test_split_args():
    assert split_args('') == ['']
    assert split_args('a') == ['a']
    assert split_args('a b') == ['a', 'b']
    assert split_args('a "b c"') == ['a', '"b c"']
    assert split_args('a "b c\\"') == ['a', '"b c\\"']
    assert split_args('a "b c" d') == ['a', '"b c"', 'd']
    assert split_args('a "b c"\\') == ['a', '"b c"\\']
    assert split_args('a "b c"\\\nd') == ['a', '"b c"\\', 'd']

# Generated at 2022-06-20 23:23:45.699413
# Unit test for function split_args
def test_split_args():
    # Test basic quoted string
    assert split_args('''foo bar "longer quoted string"''') == ['foo', 'bar', '"longer quoted string"']

    # Test quotes inside quotes
    assert split_args('''foo bar "longer 'quoted string'"''') == ['foo', 'bar', '"longer \'quoted string\'"']
    assert split_args('''foo bar "longer "quoted" string"''') == ['foo', 'bar', '"longer "quoted" string"']
    assert split_args('''foo bar "longer 'quoted' string"''') == ['foo', 'bar', '"longer \'quoted\' string"']


# Generated at 2022-06-20 23:23:52.321791
# Unit test for function join_args
def test_join_args():
    assert join_args(['A', 'B']) == 'A B'
    assert join_args(['A\n', 'B']) == 'A\nB'
    assert join_args(['A', 'B\n']) == 'A B\n'
    assert join_args(['A\n', 'B\n']) == 'A\nB\n'
    assert join_args([]) == ''



# Generated at 2022-06-20 23:23:58.009752
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("test=test") == {'test': 'test'}
    assert parse_kv("test= test") == {'test': 'test'}
    assert parse_kv("test =test") == {'test': 'test'}
    assert parse_kv("test = test") == {'test': 'test'}
    assert parse_kv("test test") == {u'_raw_params': 'test test'}


# Generated at 2022-06-20 23:24:06.761849
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d e") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d e", check_raw=True) == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}

# Generated at 2022-06-20 23:24:15.917064
# Unit test for function parse_kv
def test_parse_kv():
    
    arg_list = ['cname=ajon', 'fname=jon', 'lname=jon', 'addr="15, gg"']
    arg_str = ' '.join(arg_list)
    #print(arg_str)
    
    res = parse_kv(arg_str, check_raw=False)
    #print(res)
    assert res['cname'] == 'ajon'
    assert res['fname'] == 'jon'
    assert res['lname'] == 'jon'
    assert res['addr'] == '15, gg'
    #assert res['addr_raw'] == '"15, gg"'


#from ansible.utils.unicode import to_unicode
#from ansible.utils.unicode import to_str

#from ansible.parsing.yaml.

# Generated at 2022-06-20 23:24:20.936227
# Unit test for function split_args

# Generated at 2022-06-20 23:24:24.758418
# Unit test for function join_args
def test_join_args():
    result = join_args([
        '1',
        '2 3',
        '''
        4 ''',
        '''
        5 "6" 7''',
        '8'])

    assert(result == '1\n2 3\n\n4\n\n5 "6" 7\n8')
test_join_args()



# Generated at 2022-06-20 23:24:32.084072
# Unit test for function parse_kv
def test_parse_kv():
    # encode escapes
    assert u'2\\="\\\\"' == _decode_escapes("2\\\\\\=\\\"\\\\\\\\\\\"")
    args = 'KEY1=VALUE1 KEY2=VALUE2 KEY3="VA=LUE3" KEY4="VALUE = 4"'
    args = '''"key 1 with spaces"=value1 "key 2 with spaces"="value 2 with spaces" key3="value 3" key4=value4 'key 5' "key 6""with doublequote" "key 7"=value7 \\"KEY8 with space\\"=\\"VALUE 8 with space\\" KEY9=VALUE9 KEY10='''

# Generated at 2022-06-20 23:24:48.707661
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args([b'a', b'b', b'c']) == 'a b c'
    assert join_args(['a', 'b', 'c\n']) == 'a b c\n'
    assert join_args(['a', 'b', 'c', 'd\n']) == 'a b c d\n'
    assert join_args(['a', 'b\n', 'c', 'd\n']) == 'a b\n c d\n'



# Generated at 2022-06-20 23:24:58.637172
# Unit test for function parse_kv

# Generated at 2022-06-20 23:25:09.321964
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    args = u"a=b c='hello world' d={{ foo }} e='this=that other=another'"
    options = parse_kv(args, check_raw=True)
    assert options[u'a'] == u'b'
    assert options[u'c'] == u'hello world'
    assert options[u'd'] == AnsibleUnsafeText(u'{{ foo }}')
    assert options[u'e'] == u'this=that other=another'
    # There should be one raw parameter, which is 'this=that other=another'
    assert len(options[u'_raw_params'].split(' ')) == 1
    # It should not be quoted
    assert options[u'_raw_params'].startswith("'")

# Generated at 2022-06-20 23:25:19.982864
# Unit test for function join_args
def test_join_args():
    assert join_args(["foo", "bar"]) == "foo bar"
    assert join_args(["foo", "bar", "baz"]) == "foo bar baz"
    assert join_args(["foo", "bar", "", "", "baz"]) == "foo bar  baz"
    assert join_args(["foo\nbar", "baz"]) == "foo\nbar baz"
    assert join_args(["foo\n", "bar\n", "baz\nbom"]) == "foo\nbar\nbaz\nbom"

# Generated at 2022-06-20 23:25:29.644347
# Unit test for function split_args
def test_split_args():
    # Single quotes
    assert ['a=1'], split_args('a=1')
    assert ['a=1'], split_args('\'a=1\'')
    assert ['a=1'], split_args('\'a=1')
    assert ['a=1'], split_args('a=1\'')
    assert ['a="1"', 'b=2'], split_args('a="1" b=2')
    assert ['a="1"', 'b=2'], split_args('a="1" b="2"')
    assert ['a="1"', 'b=2'], split_args('a="1" "b=2"')
    assert ['a="1"', 'b=2'], split_args('a="1" "b=2')

# Generated at 2022-06-20 23:25:37.137601
# Unit test for function join_args
def test_join_args():
    cmd = '''echo -n "hello " > escaper.txt
    echo -n world >> escaper.txt'''
    assert cmd == join_args(split_args(cmd))
    # Comment
    cmd = '''echo -n "hel\\"lo " > escaper.txt #comment
#comment
    echo -n world >> escaper.txt'''
    assert cmd == join_args(split_args(cmd))



# Generated at 2022-06-20 23:25:48.075175
# Unit test for function split_args
def test_split_args():
    '''
    basic tests for the split_args function
    '''
    assert split_args('a b c') == ['a', 'b', 'c']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a="b c" d="e f"') == ['a="b c"', 'd="e f"']
    assert split_args('a=b\nc=d') == ['a=b\nc=d']
    assert split_args('a=b\nc="d e"') == ['a=b\nc="d e"']
    assert split_args('a="b c" d=e\nf=g') == ['a="b c"', 'd=e\nf=g']

# Generated at 2022-06-20 23:25:56.165667
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("k=v") == {u'k': u'v'}
    assert parse_kv("k1=1 k2=2") == {u'k1': u'1', u'k2': u'2'}
    assert parse_kv("k=v another=one") == {u'k': u'v', u'another': u'one'}
    assert parse_kv("k='v with space'") == {u'k': u'v with space'}
    assert parse_kv("k=\"v with space\"") == {u'k': u'v with space'}
    assert parse_kv("k=v 'k2=v2'") == {u'k': u'v', u'_raw_params': u"'k2=v2'"}
    assert parse

# Generated at 2022-06-20 23:26:06.992469
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar one=two') == {u'foo': u'bar', u'one': u'two'}
    assert parse_kv('foo=bar x=one=y') == {u'foo': u'bar', u'x': u'one=y'}
    assert parse_kv('foo=bar one = two') == {u'foo': u'bar', u'one': u'two'}
    assert parse_kv('foo = bar = baz') == {u'foo': u'bar = baz'}


# Splits arguments on spaces and single quotes, while respecting quoted
# strings. This is not a full-blown shell parser, but can handle most
# simple examples.
# http://

# Generated at 2022-06-20 23:26:12.570410
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b c', 'd  e']) == 'a b c d  e'
    assert join_args(['a\n', 'b', 'c', 'd']) == 'a\nb c d'
    assert join_args(['a', '\nbc', 'd']) == 'a \nbc d'



# Generated at 2022-06-20 23:26:37.181877
# Unit test for function split_args
def test_split_args():
    # No quotes
    assert ['a', 'b', 'c', 'd'] == split_args('a b c d')
    assert ['a', 'b', 'c', 'd'] == split_args('a \n b \n c \n d')
    assert ['a', 'b', 'c', 'd'] == split_args('a \n b \n c \n d')
    assert ['a', 'b', 'c', 'd'] == split_args('a \n b \n c \n d')
    assert ['a', 'b', 'c', 'd'] == split_args('a \n b \n c \n d')
    assert ['a', 'b', 'c', 'd'] == split_args('a \\\n b \\\n c \\\n d')

# Generated at 2022-06-20 23:26:40.937929
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=4 b=5 c=6') == {u'a': u'4', u'b': u'5', u'c': u'6'}
    assert parse_kv(u'a=2,b=3') == {u'a': u'2', u'b': u'3'}


# Generated at 2022-06-20 23:26:50.328389
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('ansible_var=foo KEY=value', True) == {u'ansible_var': u'foo', u'KEY': u'value'}
    assert parse_kv('ansible_var=foo "KEY=value with spaces"', True) == {u'ansible_var': u'foo', u'KEY': u'value with spaces'}
    assert parse_kv('ansible_var=foo a=b c=d', True) == {u'ansible_var': u'foo', u'a': u'b', u'c': u'd'}
    assert parse_kv('ansible_var=foo a=b c=d', False) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-20 23:27:00.107521
# Unit test for function split_args
def test_split_args():
#
# This is the simplest conceivable test case
    assert(split_args("a=1") == ["a=1"])
#
# Multiple parameters
    assert(split_args("a=1 b=2") == ["a=1", "b=2"])
#
# Spaces in quoted string
    assert(split_args("a=1 b=\"2 3 4\"") == ["a=1", "b=\"2 3 4\""])
#
# Spaces in single quotes
    assert(split_args("a=1 b='2 3 4'") == ["a=1", "b='2 3 4'"])
#
# Escaped quotes in double quotes
    assert(split_args("a=\"x\\\"y\\\"z\"") == ["a=\"x\\\"y\\\"z\""])
#
# Escaped quotes in single quotes
   

# Generated at 2022-06-20 23:27:07.931586
# Unit test for function split_args

# Generated at 2022-06-20 23:27:19.030545
# Unit test for function parse_kv
def test_parse_kv():
    def compare(a, b):
        assert parse_kv(a) == b

    compare('a=b c=d', {'a': 'b', 'c': 'd'})
    compare('a="b c" d=e', {'a': 'b c', 'd': 'e'})
    compare('a=b" c"=d', {'a': 'b" c', '_raw_params': '"=d'})
    compare('a="b c" "d e"=f', {'a': 'b c', '_raw_params': '"d e"=f'})
    compare('a="b c" "d e"=f g=h', {'a': 'b c', '_raw_params': '"d e"=f g=h'})

# Generated at 2022-06-20 23:27:27.373489
# Unit test for function split_args

# Generated at 2022-06-20 23:27:39.071744
# Unit test for function join_args
def test_join_args():
    s = [u'VAR1=1', u'VAR2=2', u'VAR3=3', u'\n', u'VAR4=4', u'VAR5=5']
    assert join_args(s) == u'VAR1=1 VAR2=2 VAR3=3\nVAR4=4 VAR5=5'
    s = [u'VAR1=1', u'VAR2=2', u'VAR3=3']
    assert join_args(s) == u'VAR1=1 VAR2=2 VAR3=3'
    # TODO: Fix this test, the \n is still there

# Generated at 2022-06-20 23:27:47.610698
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo\nbar', 'baz']) == 'foo\nbar baz'
    assert join_args(['foo\n\nbar', 'baz']) == 'foo\n\nbar baz'
    assert join_args(['foo\n\nbar', '\nbaz']) == 'foo\n\nbar\nbaz'
    assert join_args(['foo\n\n\nbar', '\nbaz']) == 'foo\n\n\nbar\nbaz'

# Generated at 2022-06-20 23:27:56.726969
# Unit test for function split_args

# Generated at 2022-06-20 23:28:14.033424
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', '\nb']) == 'a\nb'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['\na', 'b']) == '\na b'
    assert join_args(['a', '\nb', 'c']) == 'a\nb c'
    assert join_args(['a', '\nb', '\nc']) == 'a\nb\nc'
    assert join_args(['a', '\nb\n', 'c']) == 'a\nb\n c'
    assert join_args(['a', '\nb\nc']) == 'a\nb\nc'



# Generated at 2022-06-20 23:28:18.944998
# Unit test for function split_args
def test_split_args():
    args = 'foo={{foo}}'
    assert split_args(args) == [u'foo={{foo}}']
    args = "ansible_ssh_host={{inventory_hostname}} ansible_ssh_port={{ssh_port}} ansible_ssh_user={{ssh_user}} ansible_ssh_pass={{ssh_pass}}"
    assert split_args(args) == [u'ansible_ssh_host={{inventory_hostname}}', u'ansible_ssh_port={{ssh_port}}', u'ansible_ssh_user={{ssh_user}}', u'ansible_ssh_pass={{ssh_pass}}']
    args = "ansible_ssh_host={{inventory_hostname}}\nansible_ssh_port={{ssh_port}}"

# Generated at 2022-06-20 23:28:23.976614
# Unit test for function join_args
def test_join_args():
    test_argv = ['echo', 'foo bar', 'baz', 'spam egg', 'bam\n', '-l', 'boom\n!']
    argv = join_args(test_argv)
    assert argv == 'echo foo bar baz spam egg bam\n -l boom\n!'



# Generated at 2022-06-20 23:28:32.898489
# Unit test for function split_args
def test_split_args():
    print("Test for split_args")
    def fmt(args):
        return repr(split_args(args))

    assert fmt("a=b c='d e' f=\"g h\" i") == "['a=b', 'c=\'d e\'', 'f=\"g h\"', 'i']"
    assert fmt("a=b c='d\"e' f=\"g'h\" i") == "['a=b', 'c=\'d\"e\'', 'f=\"g\'h\"', 'i']"
    assert fmt("a=b c='d'\"'\"'e' f=\"g'h\" i") == "['a=b', \"c='d'\"\"'\"'e'\", 'f=\"g\'h\"', 'i']"

# Generated at 2022-06-20 23:28:35.871803
# Unit test for function join_args
def test_join_args():
    s = ['a', '\nb', '  c', '\nd', '  e', '\n', 'f']
    assert join_args(s) == 'a\nb  c\nd  e\nf'



# Generated at 2022-06-20 23:28:42.782714
# Unit test for function join_args
def test_join_args():
    assert join_args(['"Test', 'test"']) == '"Test test"'
    assert join_args(['"Test', '', 'test"']) == '"Test  test"'
    assert join_args(['#test', '#test\n"test']) == '#test #test\n"test'
    assert join_args(['"Test\ntest"']) == '"Test\ntest"'
    assert join_args(['"Test\ntest"', '"Test', 'test"']) == '"Test\ntest" "Test test"'
    assert join_args(['#test', '"Test', '', 'test"']) == '#test "Test  test"'



# Generated at 2022-06-20 23:28:52.544315
# Unit test for function split_args
def test_split_args():
    import sys
    import getopt

# Generated at 2022-06-20 23:29:02.043351
# Unit test for function split_args

# Generated at 2022-06-20 23:29:13.538879
# Unit test for function split_args
def test_split_args():
    assert split_args(r'''a=b c="foo bar"''') == ['a=b', 'c="foo bar"']
    assert split_args(r'''a=b c="foo bar" d=''') == ['a=b', 'c="foo bar"', 'd=']
    assert split_args(r'''a=b c="foo bar" d=""''') == ['a=b', 'c="foo bar"', 'd=""']
    assert split_args(r'''a=b c="foo bar" d="\""''') == ['a=b', 'c="foo bar"', 'd="\\""']
    assert split_args(r'''a=b c="foo bar" d="\\""''') == ['a=b', 'c="foo bar"', 'd="\\\\""']

# Generated at 2022-06-20 23:29:21.200303
# Unit test for function join_args
def test_join_args():
    assert join_args(['a=1', 'b=2', 'c=3']) == 'a=1 b=2 c=3'
    assert join_args(['a=1', 'b=2', 'c=3\n']) == 'a=1 b=2\nc=3\n'
    assert join_args(['a=1', 'b=2\n', 'c=3\n']) == 'a=1\nb=2\nc=3\n'
    assert join_args(['a=1\n', 'b=2\n', 'c=3\n']) == 'a=1\nb=2\nc=3\n'
    assert join_args(['a=1\n', 'b=2\n']) == 'a=1\nb=2\n'