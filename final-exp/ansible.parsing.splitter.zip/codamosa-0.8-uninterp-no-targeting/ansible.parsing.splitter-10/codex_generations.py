

# Generated at 2022-06-20 23:20:40.516029
# Unit test for function join_args
def test_join_args():
    # test for single line
    s = ['ls', '-l', '-a']
    result = join_args(s)
    assert result == 'ls -l -a'

    # test for multi line
    s = ['ls', '-l', '\n', '-a']
    result = join_args(s)
    assert result == 'ls -l \n-a'

    # test for two blank line in between
    s = ['ls', '-l', '\n\n', '-a']
    result = join_args(s)
    assert result == 'ls -l \n\n-a'


# Generated at 2022-06-20 23:20:47.930066
# Unit test for function join_args
def test_join_args():
    s = ['a', 'b', 'c', 'd', 'e']
    assert s == split_args(join_args(s))

    s = ["a", "b", "c", "d", "e\n"]
    assert s == split_args(join_args(s))

    s = ["a", "b", "c", "d", "e\n", "f", "g", "h", "i", "j\n"]
    assert s == split_args(join_args(s))

    s = ['a', 'b', 'c', 'd', 'e']
    assert s == split_args(join_args(s))

    s = ['a', 'b', 'c', 'd', 'e\n']
    assert s == split_args(join_args(s))


# Generated at 2022-06-20 23:20:58.638139
# Unit test for function parse_kv
def test_parse_kv():

    # Test with a simple set of valid parameters
    x = parse_kv('a=b c=d')
    assert x == {'c': 'd', 'a': 'b'}

    # Test with no parameters
    x = parse_kv('')
    assert x == {}

    # Test with missing values
    x = parse_kv('a=b c=')
    assert x == {'c': '', 'a': 'b'}

    # Test with no input
    x = parse_kv(None)
    assert x == {}

    # Test with special characters

# Generated at 2022-06-20 23:21:08.216919
# Unit test for function join_args
def test_join_args():
    assert join_args(['ls']) == 'ls'
    assert join_args(['ls', '-a', '-l']) == 'ls -a -l'
    assert join_args(['ls', '\n', '-a', '-l']) == 'ls \n-a -l'
    assert join_args(['ls \n', '-a', '-l']) == 'ls \n-a -l'
    assert join_args(['ls', '-a', '-l\n']) == 'ls -a -l\n'
    assert join_args(['echo', '\n']) == 'echo \n'
    assert join_args(['echo', '\n\n']) == 'echo \n\n'

# Generated at 2022-06-20 23:21:19.153137
# Unit test for function split_args
def test_split_args():

    def validate(args, expected):
        result = split_args(args)
        if result != expected:
            print(u"result', '%s'\nexpected', '%s'" % (result, expected))
            raise AssertionError(u"Invalid args split for '%s'. Expected %s. Got %s" % (args, expected, result))

    # some basic tests

# Generated at 2022-06-20 23:21:28.217768
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\nb']) == 'a\nb'
    assert join_args(['a b']) == 'a b'
    assert join_args(['a\nb']) == 'a\nb'
    assert join_args(['a\n', 'b']) == 'a\n b'
    assert join_args(['a\n\n', 'b']) == 'a\n\n b'
    assert join_args(['a\n', 'b\n']) == 'a\n b\n'
    assert join_args(['a\n', 'b\n', 'c']) == 'a\n b\n c'

# Generated at 2022-06-20 23:21:38.909439
# Unit test for function split_args

# Generated at 2022-06-20 23:21:48.016063
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c='foo bar' d='{% if foo %}blah{% endif %}'") == ['a=b', "c='foo bar'", "d='{% if foo %}blah{% endif %}'"]
    assert split_args("a=b c='foo bar' d='{{ foo }}'") == ['a=b', "c='foo bar'", "d='{{ foo }}'"]

# Generated at 2022-06-20 23:21:54.777996
# Unit test for function split_args
def test_split_args():
    # tests demonstrating that quote boundaries are maintained
    assert split_args(u'a=b') == [u'a=b']
    assert split_args(u'a=b "c=d e=f"') == [u'a=b', u'"c=d e=f"']
    assert split_args(u"'a=b c=d' e=f") == [u"'a=b c=d'", u'e=f']

    # tests demonstrating that newline boundaries are maintained
    assert split_args(u'a=b\nc=d') == [u'a=b', u'c=d']
    assert split_args(u'a=b\nc="d e" f=g') == [u'a=b', u'c="d e"', u'f=g']
    assert split_args

# Generated at 2022-06-20 23:22:06.342661
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', 'b c']) == 'a b c'
    assert join_args(['a', '"b c"']) == 'a "b c"'
    assert join_args(['a', '\n"b c"']) == 'a\n"b c"'
    assert join_args(['a', '"\nb c"']) == 'a "\nb c"'
    assert join_args(['a', '\n"\nb c"']) == 'a\n"\nb c"'
    assert join_args(['a', '\t"\nb c"']) == 'a\t"\nb c"'

# Generated at 2022-06-20 23:22:20.840164
# Unit test for function join_args
def test_join_args():
    assert join_args(['A', 'B', 'C']) == 'A B C'
    assert join_args(['A', '\nB', 'C']) == 'A\nB C'
    assert join_args(['A', 'B\n', 'C']) == 'A B\nC'
    assert join_args(['A', '\nB\n', 'C']) == 'A\nB\nC'



# Generated at 2022-06-20 23:22:31.233440
# Unit test for function split_args
def test_split_args():
    import unittest
    class TestSplitArgs(unittest.TestCase):
        def test_simple(self):
            arg_string = 'foo="bar baz"'
            expected_result = [u'foo="bar baz"']
            self.assertEqual(split_args(arg_string), expected_result)
            arg_string = 'foo=bar baz'
            expected_result = [u'foo=bar', u'baz']
            self.assertEqual(split_args(arg_string), expected_result)
            arg_string = 'foo=bar baz=foobar'
            expected_result = [u'foo=bar baz=foobar']
            self.assertEqual(split_args(arg_string), expected_result)

# Generated at 2022-06-20 23:22:39.670143
# Unit test for function split_args

# Generated at 2022-06-20 23:22:50.813008
# Unit test for function join_args
def test_join_args():
    assert join_args(["argument"]) == "argument"
    assert join_args(["arg1", "arg2"]) == "arg1 arg2"
    assert join_args(["arg1", "arg2", "arg3"]) == "arg1 arg2 arg3"
    assert join_args(["arg1", "arg2", "arg3\narg4"]) == "arg1 arg2 arg3\narg4"
    assert join_args(["arg1", "arg2", "\narg3\narg4"]) == "arg1 arg2 \narg3\narg4"
    assert join_args(["arg1", "arg2", "\narg3\narg4\n"]) == "arg1 arg2 \narg3\narg4\n"
    return True



# Generated at 2022-06-20 23:22:58.932943
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c', 'd']) == 'a b c d'
    assert join_args(['a\n', 'b\n', 'c\n', 'd']) == 'a\nb\nc\nd'
    assert join_args(['a\n', 'b', 'c', 'd']) == 'a\n b c d'
    assert join_args(['a\n', 'b', '\nc', 'd']) == 'a\n b \nc d'
    assert join_args(['a\n', 'b', '\nc', 'd\n']) == 'a\n b \nc d\n'

# Generated at 2022-06-20 23:23:08.459332
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv('') == {}
    assert parse_kv('foo=bar') == {"foo": "bar"}
    assert parse_kv('foo=bar ') == {"foo": "bar"}
    assert parse_kv(' foo=bar') == {"foo": "bar"}
    assert parse_kv(' foo=bar ') == {"foo": "bar"}

    assert parse_kv('foo=bar baz=qux') == {"foo": "bar", "baz": "qux"}
    assert parse_kv('foo=bar baz=qux ') == {"foo": "bar", "baz": "qux"}
    assert parse_kv(' foo=bar baz=qux') == {"foo": "bar", "baz": "qux"}

# Generated at 2022-06-20 23:23:16.313164
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("a=b d='ef'   g='' foo=bar")
    assert options == {u'a': u'b', u'd': u'ef', u'g': u'', u'foo': u'bar'}
    # Test that escapes are decoded
    options = parse_kv("a=\\n\\tb")
    assert options == {u'a': "\n\tb"}
    # Test that backslashes before equals are preserved
    options = parse_kv("a=\\=b")
    assert options == {u'a': "=b"}



# Generated at 2022-06-20 23:23:26.966463
# Unit test for function split_args
def test_split_args():
    for args, result in TEST_CASES.items():
        assert split_args(args) == result


# Generated at 2022-06-20 23:23:29.739329
# Unit test for function join_args
def test_join_args():
    assert 'foo "bar baz"' == join_args(["foo", '"bar baz"'])
    assert 'foo "bar\nbaz"' == join_args(["foo", '"bar\nbaz"'])



# Generated at 2022-06-20 23:23:39.908114
# Unit test for function split_args
def test_split_args():
    from ansible import errors as ae
    from ansible.module_utils import basic

    testcases = {}
    # Edge case of empty string
    testcases[''] = []
    # Simple string
    testcases['foo bar'] = ['foo', 'bar']
    # Simple string with two spaces
    testcases['foo  bar'] = ['foo', '', 'bar']
    # Simple string with a linefeed
    testcases['foo\nbar'] = ['foo', 'bar']
    # Simple string with two linefeeds
    testcases['foo\n\nbar'] = ['foo', '', 'bar']
    # Simple string with a linefeed and a space
    testcases['foo\n bar'] = ['foo', ' bar']
    # Simple string with two spaces and a linefeed

# Generated at 2022-06-20 23:23:55.514263
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\nb', 'c', 'd']) == 'a\nbc d'
    assert join_args(['a', 'b', 'c\n']) == 'a b\nc'
    assert join_args(['a\n', 'b', 'c\n']) == 'a\nbc\n'
    assert join_args(['a\n', '', 'c\n']) == 'a\n c\n'



# Generated at 2022-06-20 23:23:58.853480
# Unit test for function join_args
def test_join_args():
    res = join_args(['{{test}}', 'test2'])
    assert (res == '{{test}} test2')
    res = join_args(['test1', 'test2'])
    assert (res == 'test1 test2')


# Generated at 2022-06-20 23:24:07.178382
# Unit test for function split_args
def test_split_args():
    assert split_args(u"git clone https://github.com/ansible/ansible.git") == ['git', 'clone', 'https://github.com/ansible/ansible.git']
    assert split_args(u"curl -sSL https://get.rvm.io | bash -s stable --autolibs=3 --ruby") == ['curl', '-sSL', 'https://get.rvm.io', '|', 'bash', '-s', 'stable', '--autolibs=3', '--ruby']
    assert split_args(u'gem install bundler --no-rdoc --no-ri') == ['gem', 'install', 'bundler', '--no-rdoc', '--no-ri']
    assert split_args(u'bundle install') == ['bundle', 'install']


# Generated at 2022-06-20 23:24:16.244115
# Unit test for function join_args
def test_join_args():
    assert join_args(['1', '2', '3']) == '1 2 3'
    assert join_args(['1', '2 ', '3']) == '1 2 3'
    assert join_args(['1 ', '2', ' 3']) == '1 2 3'
    assert join_args(['1', '\n2', '\n3']) == '1\n2\n3'
    assert join_args(['1', '\n2\n', '\n3']) == '1\n2\n3'
    assert join_args(['1', '\n 2\n', '3']) == '1\n 2\n3'
    assert join_args(['1', '\n2\n 3']) == '1\n2\n 3'

# Generated at 2022-06-20 23:24:25.119000
# Unit test for function join_args
def test_join_args():
    assert join_args(["test1","test2"]) == "test1 test2"
    assert join_args(["test1\n","test2"]) == "test1\ntest2"
    assert join_args(["test1","\ntest2"]) == "test1\ntest2"
    assert join_args(["test1", "\ntest2"]) == "test1\ntest2"
    assert join_args(["test1", "\ntest2", "test3"]) == "test1\ntest2 test3"
    assert join_args(["test1", "\ntest2", "\ntest3"]) == "test1\ntest2\ntest3"



# Generated at 2022-06-20 23:24:31.531217
# Unit test for function parse_kv
def test_parse_kv():
    # Test parsing and decoding hex escapes
    assert parse_kv("a=1 b=\\x0a c=\\x0A d=\\u1234 e=\\U00006789 f=\\N{CYRILLIC CAPITAL LETTER A} g=\\' h=\\\" i=\\\\ j=\\a") == dict(
        a='1',
        b=u'\n',
        c=u'\n',
        d=u'\u1234',
        e=u'\u6789',
        f=u'\u0410',
        g="'",
        h='"',
        i='\\',
        j='a')



# Generated at 2022-06-20 23:24:36.267707
# Unit test for function split_args
def test_split_args():
    import pytest

    def test_split_args_helper(args, expected):
        actual = split_args(args)
        assert actual == expected, \
            "Expected output: \n{0}\nGot:\n{1}\nFor args:\n{2}".format(expected, actual, args)

    # Test cases taken from shell module test suite
    test_split_args_helper(
        "hi there", [
            "hi", "there",
        ]
    )
    test_split_args_helper(
        "{{ foo }}\n{{ bar }}", [
            "{{ foo }}", "{{ bar }}",
        ]
    )
    test_split_args_helper(
        "{{ foo }} {{ bar }}", [
            "{{ foo }}", "{{ bar }}",
        ]
    )

# Generated at 2022-06-20 23:24:39.826208
# Unit test for function parse_kv
def test_parse_kv():
    args = 'foo=one "bar=two three" \'baz = four\''
    assert parse_kv(args) == {u'foo': u'one', u'baz': u'four', u_raw_params: u'bar=two three', u'bar': u'two three'}



# Generated at 2022-06-20 23:24:43.514825
# Unit test for function join_args
def test_join_args():
    teststr = 'hello\nworld "foo\nbar" \nwhatsup'
    print(join_args(split_args(teststr)))
    assert join_args(split_args(teststr)) == teststr



# Generated at 2022-06-20 23:24:53.199635
# Unit test for function parse_kv
def test_parse_kv():
    def _test_parse_kv(args, options):
        assert parse_kv(args) == options

    _test_parse_kv('"1=2"', {u'1': u'2'})
    _test_parse_kv('1=2', {u'1': u'2'})
    _test_parse_kv('1="2"', {u'1': u'2'})
    _test_parse_kv('a=1 "b = 2"', {u'a': u'1', u'b': u'2'})
    _test_parse_kv('a=1 "b = 2" c="3"', {u'a': u'1', u'b': u'2', u'c': u'3'})

# Generated at 2022-06-20 23:25:11.198968
# Unit test for function split_args
def test_split_args():
    '''
    Usage:
    $ python split_args.py
    '''
    # These tests should return a list of params that we can reassemble back into the original string
    assert [u'a=b'] == split_args('a=b')
    assert [u'a=b'] == split_args(u'a=b')
    # The parse module already makes sure that args aren't comma separated by the time we get here,
    # so we don't need to test for that anymore, but we do want to make sure we're handling spaces correctly
    assert [u'a=b cd'] == split_args(u'a=b cd')
    assert [u'a=b cd'] == split_args(u'a=b cd')
    # These tests should check quotes and jinja2 blocks

# Generated at 2022-06-20 23:25:16.023686
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b\nc']) == 'a b\nc'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', ' b ', 'c']) == 'a  b  c'



# Generated at 2022-06-20 23:25:22.275988
# Unit test for function join_args
def test_join_args():
    assert join_args(["echo", "hello world"]) == "echo hello world"
    assert join_args(["echo", "hello", "world"]) == "echo hello world"
    assert join_args(["echo", "hello", "\n", "world"]) == "echo hello\n world"
    assert join_args("echo hello world".split()) == "echo hello world"
    assert join_args("echo hello\n world".split()) == "echo hello\n world"



# Generated at 2022-06-20 23:25:25.178165
# Unit test for function join_args
def test_join_args():
    s = ['echo', '"Hello world', 'with some "quotes" in the middle"']
    result = join_args(s)
    assert result == 'echo "Hello world with some "quotes" in the middle"'



# Generated at 2022-06-20 23:25:33.387099
# Unit test for function split_args
def test_split_args():
    assert split_args('echo "hello world"') == ['echo', '"hello world"']
    assert split_args('echo "hello world" | grep world') == ['echo', '"hello world"', '|', 'grep', 'world']
    assert split_args('echo "hello world"|grep world') == ['echo', '"hello world"|grep', 'world']
    assert split_args('echo "hello world"|grep "hello world"') == ['echo', '"hello world"|grep', '"hello world"']
    assert split_args('echo "a\\"b"') == ['echo', '"a"b"']
    assert split_args('echo "a\\\\\\b"') == ['echo', '"a\\\\b"']

# Generated at 2022-06-20 23:25:44.785642
# Unit test for function split_args
def test_split_args():
    print("=== BEGIN GROUP 1 ===")

# Generated at 2022-06-20 23:25:49.793460
# Unit test for function parse_kv
def test_parse_kv():
    results = parse_kv("arg1=foobar arg2=foobaz")
    assert results == {'arg1': 'foobar', 'arg2': 'foobaz'}
    results = parse_kv("arg1='foo bar' arg2=\"foo baz\"")
    assert results == {'arg1': 'foo bar', 'arg2': 'foo baz'}
    results = parse_kv("arg1='foo bar' arg2=\"foo baz\" arg3=foo\\=bar")
    assert results == {'arg1': 'foo bar', 'arg2': 'foo baz', 'arg3': 'foo=bar'}


# Generated at 2022-06-20 23:25:57.287105
# Unit test for function split_args

# Generated at 2022-06-20 23:26:08.214430
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=\"b c\"") == ['a="b c"']
    assert split_args("a=\"b c\" d='e f'") == ['a="b c"', "d='e f'"]
    assert split_args("a=\"b c\" d=\"e f\"") == ['a="b c"', 'd="e f"']
    assert split_args("foo bar baz") == ['foo', 'bar', 'baz']
    assert split_args("foo=bar baz=quux") == ['foo=bar', 'baz=quux']
    assert split_args("foo=\"bar baz\"") == ['foo="bar baz"']

# Generated at 2022-06-20 23:26:17.281061
# Unit test for function join_args
def test_join_args():
    from ansible.compat.tests.mock import patch
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader, cache_loader
    from ansible.utils.display import Display
    from ansible.utils.path import plugin_paths
    import ansible.constants as C
    import os

    class TestModule(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.params = kwargs



# Generated at 2022-06-20 23:26:37.526540
# Unit test for function parse_kv
def test_parse_kv():
    expected = {u'key1': u'"I am value 1"', u'key2': u'"I am value 2"',
                u'key3': u'"I am value 3"', u'key4': u'"I am value 4"',
                u'key6': u'6', u'key7': u'7'}
    result = parse_kv(u'key1="I am value 1" key2="I am value 2"  key3="I am value 3"   key4="I am value 4" key5 key6=6 key7=7')
    assert result == expected


# Generated at 2022-06-20 23:26:46.605889
# Unit test for function parse_kv
def test_parse_kv():
    'Test parse_kv with various inputs'
    def test(args, check_raw, expected):
        actual = parse_kv(args, check_raw)
        if actual != expected:
            m = '\nparse_kv("%s", %d) expected %s\n got %s'
            print (m % (args, check_raw, expected, actual))
    test('', 0, {})
    test('foo=bar', 0, {'foo': 'bar'})
    test('foo=bar bar=baz', 0, {'foo': 'bar', 'bar': 'baz'})
    test('foo=bar bar=baz', 1, {'foo': 'bar', 'bar': 'baz', '_raw_params': 'foo=bar bar=baz'})

# Generated at 2022-06-20 23:26:56.237937
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', 'baz']) == u'foo bar baz'
    assert join_args(['foo bar', 'baz']) == u'foo bar baz'
    assert join_args(['foo', '\nbar', 'baz']) == u'foo\nbar baz'
    assert join_args(['foo', 'bar', '\nbaz']) == u'foo bar\nbaz'
    assert join_args(['foo', 'bar', '\n', 'baz']) == u'foo bar\n baz'
    assert join_args(['foo', 'bar ', '\n', 'baz']) == u'foo bar \n baz'

# Generated at 2022-06-20 23:27:03.016051
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '"foo bar"']) == 'echo "foo bar"'
    assert join_args(['echo', '-n', '"foo', 'bar"']) == 'echo -n "foo bar"'
    assert join_args(['echo', '"foo\\nbar"']) == 'echo "foo\\nbar"'
    assert join_args(['echo', 'foo\\nbar']) == 'echo foo\\nbar'
    assert join_args(['echo', '"foo', '-n', 'bar"']) == 'echo "foo -n bar"'



# Generated at 2022-06-20 23:27:09.741535
# Unit test for function join_args
def test_join_args():
    assert join_args(['hello world']) == 'hello world'
    assert join_args(['hello world', 'the cake is a lie\n', '  I want to believe']) == 'hello world the cake is a lie\n  I want to believe'
    assert join_args(['hello world', 'the cake is a lie\n', '  I want to beleive']) == 'hello world the cake is a lie\n  I want to beleive'
    assert join_args(['hello world', 'the cake is a lie\n', '  I want to beleive\n', 'but you are wrong']) == 'hello world the cake is a lie\n  I want to beleive\nbut you are wrong'



# Generated at 2022-06-20 23:27:20.361081
# Unit test for function join_args
def test_join_args():
    '''
    Verify that split_args() and join_args() are inverses of each other.
    '''
    def test(args):
        assert join_args(split_args(args)) == args
    test("foo bar")
    test("foo bar baz")
    test("foo\nbar")
    test("'foo bar'")
    test("'foo bar' baz")
    test("'foo\nbar' baz")
    test("'foo\nbar'\nbaz")
    test("'foo\nbar'\\\n  baz")
    test("``dog``")
    test("``dog`` cat")
    test("``dog\ncat``")
    test("``dog\ncat`` fish")
    test("``dog\ncat``\\\nfish")

# Generated at 2022-06-20 23:27:28.243375
# Unit test for function split_args
def test_split_args():
    '''
    Basic test function for function split_args
    '''

# Generated at 2022-06-20 23:27:40.217164
# Unit test for function split_args

# Generated at 2022-06-20 23:27:48.364338
# Unit test for function join_args
def test_join_args():
    s = ['foo=bar', 'baz=quux', 'one', 'two', 'three']
    assert join_args(s) == "foo=bar baz=quux one two three"

    s = ['foo=bar', 'baz=quux', 'one', 'two', 'three\n']
    assert join_args(s) == "foo=bar baz=quux one two three\n"

    s = ['foo=bar', 'baz=quux', 'one\n', 'two', 'three\n']
    assert join_args(s) == "foo=bar baz=quux one\n two three\n"

    s = ['foo=bar', 'baz=quux\n', 'one\n', 'two', 'three\n']

# Generated at 2022-06-20 23:27:58.075048
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo']) == 'echo'
    assert join_args(['echo', 'hello']) == 'echo hello'
    assert join_args(['echo', 'hello', 'world']) == 'echo hello world'
    assert join_args(['echo', 'hello', 'world\n']) == 'echo hello world\n'
    assert join_args(['echo', 'hello', 'world', '\n']) == 'echo hello world \n'
    assert join_args(['echo', 'hello', 'world\n', '!']) == 'echo hello world\n!'
    assert join_args(['echo', 'hello', 'world\n', '!']) == 'echo hello world\n!'
    assert join_args(['echo', 'hello', 'world\n']) == 'echo hello world\n'




# Generated at 2022-06-20 23:28:13.382040
# Unit test for function join_args
def test_join_args():
    input = ['echo', '1', '', '\n', 'echo 2']
    assert 'echo 1 \n echo 2' == join_args(input)
    input = []
    assert '' == join_args(input)
    input = ['foo']
    assert 'foo' == join_args(input)
    input = ['foo', 'bar']
    assert 'foo bar' == join_args(input)
    input = ['foo', 'bar', '']
    assert 'foo bar ' == join_args(input)
    input = ['foo', '', 'bar', '', 'baz']
    assert 'foo  bar  baz' == join_args(input)
    input = ['foo', '', 'bar', '', 'baz', '']
    assert 'foo  bar  baz ' == join_args(input)
   

# Generated at 2022-06-20 23:28:25.057366
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {u'a': u'1', u'b': u'2'}
    assert parse_kv('a=1 b=2 c=') == {u'a': u'1', u'b': u'2', u'c': u''}
    assert parse_kv('a=1 b=2 c') == {u'a': u'1', u'b': u'2', u'_raw_params': u'c'}
    assert parse_kv('a=1 b=2 c d=3') == {u'a': u'1', u'b': u'2', u'_raw_params': u'c d=3'}

# Generated at 2022-06-20 23:28:27.969500
# Unit test for function join_args
def test_join_args():
    wanted = 'cd /tmp && ls -lh /tmp'
    got = join_args(split_args(wanted))
    assert wanted == got, 'join_args() failed. got %s wanted %s' % (got, wanted)



# Generated at 2022-06-20 23:28:36.835604
# Unit test for function join_args
def test_join_args():
    got = join_args(['abcdefg', 'hijkl\nm'])
    assert got == 'abcdefg hijkl\nm', got
    got = join_args(['abcdefg', '\thijkl\nm'])
    assert got == 'abcdefg \thijkl\nm', got
    got = join_args(['abcdefg', 'hijkl\nm', 'no\nnewline'])
    assert got == 'abcdefg hijkl\nm no\nnewline', got
    got = join_args(['abcdefg', '\thijkl\nm', 'no\nnewline'])
    assert got == 'abcdefg \thijkl\nm no\nnewline', got
    # Check that comments are preserved
    g = 'ansible-doc -l | less'

# Generated at 2022-06-20 23:28:40.881481
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a="b c"') == {'a': 'b c'}
    assert parse_kv('a="b=c d"') == {'a': 'b=c d'}
    assert parse_kv('a="b=c d e"') == {'a': 'b=c d e'}
    assert parse_kv('a=b=c') == {'a': 'b=c'}
    assert parse_kv('a=b c') == {'_raw_params': 'a=b c'}
    assert parse_kv("a='b c'") == {'a': 'b c'}

# Generated at 2022-06-20 23:28:50.161716
# Unit test for function split_args
def test_split_args():
  import sys
  if sys.version_info[0] >= 3:
    unicode = str

  # Simple single word
  input = 'a'
  output = split_args(input)
  assert len(output) == 1
  assert output[0] == 'a'

  # Single word with extra space
  input = 'a '
  output = split_args(input)
  assert len(output) == 1
  assert output[0] == 'a'

  # Two words separated by space
  input = 'a b'
  output = split_args(input)
  assert len(output) == 2
  assert output[0] == 'a'
  assert output[1] == 'b'

  # Two words separated by extra space
  input = 'a  b'
  output = split_args(input)

# Generated at 2022-06-20 23:29:00.267477
# Unit test for function split_args
def test_split_args():
    '''
    test that split args and join args function correctly together
    '''

# Generated at 2022-06-20 23:29:02.564661
# Unit test for function join_args
def test_join_args():
    s = ['a', ' b', '&\nc', 'd ', '\nf']
    assert join_args(s) == "a b\n&\nc d \nf"



# Generated at 2022-06-20 23:29:14.046139
# Unit test for function split_args
def test_split_args():
    import unittest.mock as mock
    # This module is weird in that its used by the local executor that ships with Ansible, but it is
    # also used in some of the modules. This test needs to assume the local executor is not present
    # and create its own version of the parse error that is normally in the local executor.
    with mock.patch.dict(globals(), {'AnsibleParserError': AnsibleParserError}):
        assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
        assert split_args("a='b c'") == ["a='b c'"]
        assert split_args("a='b c'") == ["a='b c'"]

# Generated at 2022-06-20 23:29:21.475351
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '-n', 'hello']) == 'echo -n hello'
    assert join_args(['echo', '-n', 'hello', 'world']) == 'echo -n hello world'
    assert join_args(['echo', '-n', 'hello\nworld']) == 'echo -n hello\nworld'
    assert join_args(['echo', '-n', 'hello\n', 'world']) == 'echo -n hello\nworld'
    assert join_args(['echo', '-n', 'hello', '\nworld']) == 'echo -n hello\nworld'
    assert join_args(['echo', '-n', 'hello', '\n', 'world']) == 'echo -n hello\nworld'