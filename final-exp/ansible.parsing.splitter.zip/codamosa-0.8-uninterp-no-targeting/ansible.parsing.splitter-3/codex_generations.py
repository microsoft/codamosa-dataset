

# Generated at 2022-06-20 23:20:08.897071
# Unit test for function join_args
def test_join_args():
    assert join_args(['1', '2', '3', '4']) == '1 2 3 4'
    assert join_args(['1 2 3 4']) == '1 2 3 4'
    assert join_args(['1\n2\n3\n4']) == '1\n2\n3\n4'
    assert join_args(['1\n2\n3\n4', '5', '6', '7']) == '1\n2\n3\n4 5 6 7'



# Generated at 2022-06-20 23:20:14.651543
# Unit test for function join_args
def test_join_args():
    assert join_args(["foo", "bar"]) == "foo bar"
    assert join_args(["foo", "bar", "baz"]) == "foo bar baz"
    assert join_args(["foo", "bar\n"]) == "foo bar\n"
    assert join_args(["foo", "bar", "baz\n"]) == "foo bar baz\n"



# Generated at 2022-06-20 23:20:22.808504
# Unit test for function join_args
def test_join_args():
    s = ['Hello', ' World!']
    assert join_args(s) == 'Hello World!'
    s = ['Hello\n', ' World!']
    assert join_args(s) == 'Hello\n World!'
    s = ['Hello\n', 'World!']
    assert join_args(s) == 'Hello\nWorld!'
    s = ['Hello\nWorld!']
    assert join_args(s) == 'Hello\nWorld!'
    s = ['Hello', '\nWorld!']
    assert join_args(s) == 'Hello\nWorld!'
    s = ['Hello', '\n', 'World!']
    assert join_args(s) == 'Hello\n World!'


# Generated at 2022-06-20 23:20:33.112648
# Unit test for function join_args
def test_join_args():
    assert join_args(['a','b','c','d','e\nf','g','h','i','j\nk']) == 'a b c d e\nf g h i j\nk'
    assert join_args(['"a b" "c"\'d e\' f\n']) == '"a b" "c"\'d e\' f\n'
    assert join_args(['"a b" "c"\'d e\' f\n', '"g h" "i"\'j k\' "l\nm" \'n o\' p\nq']) == '"a b" "c"\'d e\' f\n "g h" "i"\'j k\' "l\nm" \'n o\' p\nq'

# Generated at 2022-06-20 23:20:43.653435
# Unit test for function join_args
def test_join_args():
    # Trivial case (one arg)
    assert join_args(["foo"]) == "foo"

    # Trivial case (multiple args)
    assert join_args(["foo", "bar"]) == "foo bar"

    # Simple case
    assert join_args(["foo bar"]) == "foo bar"

    # Check newline preservation
    assert join_args(["foo\nbar"]) == "foo\nbar"
    assert join_args(["foo", "bar"]) == "foo bar"
    assert join_args(["foo", "\nbar"]) == "foo \nbar"

    # Check whitespace preservation
    assert join_args(["foo bar"]) == "foo bar"
    assert join_args(["foo", "bar"]) == "foo bar"

# Generated at 2022-06-20 23:20:48.228984
# Unit test for function split_args
def test_split_args():

    # Test with no args
    assert split_args('') == []

    # Test with simple args
    assert split_args('a b c d') == ['a', 'b', 'c', 'd']

    # Test with quoted args
    assert split_args('a "b c"') == ['a', '"b c"']

    # Test with jinja2 blocks
    assert split_args('{{ foo }}\n{{ bar }}') == ['{{ foo }}', '{{ bar }}']

    # Test with quoted args that are broken across lines
    assert split_args('a "b\nc"') == ['a', '"b\nc"']

    # Test with jinja2 blocks that are broken across lines
    assert split_args('{{ foo }}\n{{ bar }}') == ['{{ foo }}', '{{ bar }}']

    # Test

# Generated at 2022-06-20 23:20:59.376253
# Unit test for function parse_kv
def test_parse_kv():
    def assert_args(args, expected):
        """
        Asserts that parse_kv(args) == expected.
        :param args: a string with the command line arguments to pass to parse_kv
        :param expected: a dict with the expected result of parse_kv(args).
        """
        assert expected == parse_kv(args, check_raw=True), args

    assert_args('a=1 b=2', {'a': '1', 'b': '2'})
    assert_args('a="1" b="2"', {'a': '1', 'b': '2'})
    assert_args('a=1" b=2', {'a': '1"', 'b': '2'})

# Generated at 2022-06-20 23:21:07.361094
# Unit test for function join_args
def test_join_args():
    assert(join_args(['This', 'is', 'a', 'test.']) == 'This is a test.')
    assert(join_args(['This', '\nis', '\n', 'a', '\n', 'test.']) == 'This\nis\n\na\n\ntest.')
    assert(join_args(['This', '\\', '\n', '\n', 'is', '\n', 'a', '\n', 'test.']) == 'This \\ \n\n is \n a \n test.')

# Generated at 2022-06-20 23:21:16.882527
# Unit test for function join_args
def test_join_args():
    def cmp_join_args(s, expected):
        actual = join_args(split_args(s))
        assert actual == expected, "actual: %r expected: %r" % (actual, expected)
        actual = s.replace('\n', '&#10;')
        assert actual == expected, "actual: %r expected: %r" % (actual, expected)
    cmp_join_args('a b', 'a b')
    cmp_join_args('a\nb', 'a\nb')
    cmp_join_args('a b\nc', 'a b\nc')
    cmp_join_args('a b\n c', 'a b\n c')
    cmp_join_args('a b \n c', 'a b \n c')

# Generated at 2022-06-20 23:21:27.112894
# Unit test for function join_args
def test_join_args():
    '''
    join_args() should return a string equivalent to its input
    when split_args() is used as the inverse.
    '''
    def join_split_test(s):
        '''
        Return the result of joining the list of tokens from split_args().
        '''
        return join_args(split_args(s))

    assert join_split_test('a b c') == 'a b c'
    assert join_split_test('a"b"c') == 'a"b"c'
    assert join_split_test("a'b'c") == "a'b'c"
    assert join_split_test("a'b c'") == "a'b c'"
    assert join_split_test("a\"b c\"") == "a\"b c\""
    assert join_split_

# Generated at 2022-06-20 23:21:47.278643
# Unit test for function split_args
def test_split_args():
    import ansible.module_utils.common.utils as util
    import ansible.module_utils.basic as basic
    util.get_module_path = lambda x: './'
    util.HAS_PYXML = False
    util.HAS_LXML = False
    util.HAS_DATEUTIL = False
    basic.__ansible_module__ = None
    basic.ANSIBLE_MODULE_ARGS = {}


    assert split_args("foo bar biz 'biz bang' \"boom pow\"") == ['foo', 'bar', 'biz', "biz bang", "boom pow"]
    assert split_args("foo bar=foo bar=foo") == ['foo', 'bar=foo', 'bar=foo']

# Generated at 2022-06-20 23:21:53.939457
# Unit test for function split_args

# Generated at 2022-06-20 23:22:05.821045
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('this=that that=this') == {u'this': u'that', u'that': u'this'}
    assert parse_kv('this=this\=that that=this\=that') == {u'this': u'this=that', u'that': u'this=that'}
    assert parse_kv('this=that that=this', check_raw=True) == {u'this': u'that', u'that': u'this', u'_raw_params': u'this=that that=this'}

# Generated at 2022-06-20 23:22:14.002864
# Unit test for function parse_kv

# Generated at 2022-06-20 23:22:22.252723
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'a b c\nd e', 'f g\nh i']) == 'echo a b c\nd e f g\nh i'
    assert join_args(['echo', 'a b c\n d e', 'f g\nh i']) == 'echo a b c\n d e f g\nh i'
    assert join_args(['echo', 'a b c\n d e', 'f g\nh i', 'j k l']) == 'echo a b c\n d e f g\nh i j k l'



# Generated at 2022-06-20 23:22:32.155574
# Unit test for function split_args
def test_split_args():

    try:
        split_args('')
    except AnsibleParserError:
        pass
    else:
        assert False

    try:
        split_args('foo')
    except AnsibleParserError:
        assert False
    else:
        assert True

    try:
        split_args("foo='bar baz'")
    except AnsibleParserError:
        assert False
    else:
        assert True

    try:
        split_args("'foo bar' baz='foo bar'")
    except AnsibleParserError:
        assert False
    else:
        assert True

    try:
        split_args("foo bar")
    except AnsibleParserError:
        assert False
    else:
        assert True

    try:
        split_args("foo bar=")
    except AnsibleParserError:
        assert False

# Generated at 2022-06-20 23:22:36.547821
# Unit test for function parse_kv

# Generated at 2022-06-20 23:22:41.207239
# Unit test for function join_args
def test_join_args():
    # multiple newlines
    assert(join_args(['a', '', 'b']) == 'a\n\nb')
    # trailing newlines
    assert(join_args(['a', '', 'b', '\n']) == 'a\n\nb\n')



# Generated at 2022-06-20 23:22:51.816855
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a='b c'") == ["a=b c"]
    assert split_args(u"a='b c' d=e") == ["a=b c", "d=e"]
    assert split_args(u"a='b c'\ne='f g'") == ["a=b c\n", "e=f g"]
    assert split_args(u"a='b c'\ne='f g'\nh='i j'") == ["a=b c\n", "e=f g\n", "h=i j"]
    assert split_args(u"a='b c' \n e='f g'\nh='i j'") == ["a=b c", "e=f g\n", "h=i j"]

# Generated at 2022-06-20 23:22:59.537195
# Unit test for function split_args

# Generated at 2022-06-20 23:23:19.132329
# Unit test for function parse_kv
def test_parse_kv():

    # test one key/value pair
    test_data = [u'''path=/usr/bin''', u'''path=/usr/bin/''', u'''path=/usr/bin/ ''']
    results = [u'path=/usr/bin', u'path=/usr/bin/', u'path=/usr/bin/ ']
    for i in range(len(test_data)):
        assert parse_kv(test_data[i])[u'path'] == results[i]

    # test multiple key/value pairs
    test_data = [u'''path=/usr/bin state=directory''',
                 u'''path=/usr/bin state=directory''',
                 u'''path=/usr/bin state=directory ''']

# Generated at 2022-06-20 23:23:23.674535
# Unit test for function join_args
def test_join_args():
    s = ['a', 'b', 'c']
    actual_result = join_args(s)
    assert actual_result == 'a b c'
    s = ['a\nb', 'c', 'd']
    actual_result = join_args(s)
    assert actual_result == 'a\nb c d'



# Generated at 2022-06-20 23:23:34.504354
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo="bar"') == {'foo': 'bar'}
    assert parse_kv('foo="bar baz"') == {'foo': 'bar baz'}
    assert parse_kv('foo="bar baz" space="a b"') == {'foo': 'bar baz', 'space': 'a b'}
    assert parse_kv('creates=/tmp/foo') == {'creates': '/tmp/foo'}
    assert parse_kv('creates = /tmp/foo') == {'creates': '/tmp/foo'}

# Generated at 2022-06-20 23:23:43.917445
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar bam=boo') == {'foo': 'bar', 'bam': 'boo'}
    assert parse_kv('foo="bar bam=boo"') == {'foo': 'bar bam=boo'}
    assert parse_kv('foo="bar bam=boo" spam=ham') == {'foo': 'bar bam=boo', 'spam': 'ham'}
    assert parse_kv('foo="bar bam=\\"boo\\"" spam=ham') == {'foo': 'bar bam="boo"', 'spam': 'ham'}

# Generated at 2022-06-20 23:23:46.138337
# Unit test for function join_args
def test_join_args():
    assert join_args(['ls', '-l']) == 'ls -l'
    assert join_args(['echo', '"hello"', '"world"']) == 'echo "hello" "world"'



# Generated at 2022-06-20 23:23:48.965639
# Unit test for function join_args
def test_join_args():
    assert(join_args(['a','b','c']) == 'a b c')
    assert(join_args(['a','b','\nc']) == 'a b\nc')



# Generated at 2022-06-20 23:23:59.587463
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("creates=/tmp/foo removes=/tmp/bar other=baz another=bang") == dict(creates="/tmp/foo", removes="/tmp/bar", other="baz", another="bang")
    assert parse_kv("creates=/tmp/foo other=baz another=bang") == dict(creates="/tmp/foo", other="baz", another="bang")
    assert parse_kv("creates=/tmp/foo") == dict(creates="/tmp/foo")
    assert parse_kv("other=baz") == dict(other="baz")
    assert parse_kv("other=baz other=bang") == dict(other="baz", other="bang")

# Generated at 2022-06-20 23:24:07.593276
# Unit test for function split_args

# Generated at 2022-06-20 23:24:14.925266
# Unit test for function join_args
def test_join_args():
    test1 = [u'arg1', u'arg2']
    assert join_args(test1) == 'arg1 arg2'
    test2 = [u'arg1', u'arg2', u'\\n', u'arg3']
    assert join_args(test2) == 'arg1 arg2 \n arg3'
    test3 = [u'arg1', u'arg2', u'\\n', u'arg3', u'\\n', u'arg4']
    assert join_args(test3) == 'arg1 arg2 \n arg3 \n arg4'



# Generated at 2022-06-20 23:24:23.656131
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == dict(a='b', c='d')
    assert parse_kv('a=b c=d', check_raw=True) == dict(a='b', c='d')
    assert parse_kv('a=b c=d e') == dict(a='b', c='d')
    assert parse_kv('a=b c=d e', check_raw=True) == dict(a='b', c='d', _raw_params='e')
    assert parse_kv('a=b c="d e" f=\'g h\'') == dict(a='b', c='d e', f='g h')

# Generated at 2022-06-20 23:24:34.283287
# Unit test for function split_args
def test_split_args():
    assert split_args("foo") == ['foo']
    assert split_args("foo bar baz") == ['foo', 'bar', 'baz']
    assert split_args("foo='bar baz'") == ['foo=\'bar baz\'']
    assert split_args("foo=\"bar 'baz'\"") == ['foo="bar \'baz\'"']
    assert split_args("foo='bar \"baz\"'") == ['foo=\'bar "baz"\'']
    assert split_args("'bar baz'") == ['\'bar baz\'']
    assert split_args("\"bar 'baz'\"") == ['\"bar \'baz\'\"']
    assert split_args("'bar \"baz\"'") == ['\'bar "baz"\'']

# Generated at 2022-06-20 23:24:43.313867
# Unit test for function parse_kv
def test_parse_kv():
    def do_test(value, expected_result):
        result = parse_kv(value)
        assert result == expected_result


# Generated at 2022-06-20 23:24:53.020769
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'set_hostname=foo') == {'set_hostname': 'foo'}
    assert parse_kv(u'set_hostname=foo ') == {'set_hostname': 'foo'}
    assert parse_kv(u'set_hostname=foo bar') == {'set_hostname': 'foo bar'}
    assert parse_kv(u'set_hostname=foo bar=baz') == {'set_hostname': 'foo bar=baz'}
    assert parse_kv(u'set_hostname="foo bar"') == {'set_hostname': '"foo bar"'}
    assert parse_kv(u'ab foo') == {'_raw_params': u'ab foo'}

# Generated at 2022-06-20 23:25:04.122996
# Unit test for function split_args
def test_split_args():
    args_plain = u"one two three four"
    out_plain = [u'one', u'two', u'three', u'four']
    assert split_args(args_plain) == out_plain

    args_newlines = u"one two \\\\\nthree four"
    out_newlines = [u'one two \\', u'three', u'four']
    assert split_args(args_newlines) == out_newlines


# Generated at 2022-06-20 23:25:09.842162
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('"foo=bar baz"') == {'foo': 'bar baz'}
    assert parse_kv("'foo=bar baz'") == {'foo': 'bar baz'}
    # TODO: Add tests for quoted keys.  Does parse_kv() escape quotes?
    assert parse_kv('foo=bar baz') == {'foo': 'bar', u'_raw_params': 'baz'}
    assert parse_kv('foo=b"ar') == {'foo': 'b"ar'}



# Generated at 2022-06-20 23:25:20.420225
# Unit test for function join_args
def test_join_args():
    assert join_args(['a=b', 'c=d']) == 'a=b c=d'
    assert join_args(['a=b', 'c=d', '\n', 'e=f']) == 'a=b c=d\ne=f'
    assert join_args(['\\', 'a=b', 'c=d', '\n', 'e=f']) == '\\ a=b c=d\ne=f'
    assert join_args(['\n', 'a=b', 'c=d']) == '\na=b c=d'
    assert join_args(['a=b', '\\', 'c=d', '\n', 'e=f']) == 'a=b \\ c=d\ne=f'

# Generated at 2022-06-20 23:25:29.947193
# Unit test for function parse_kv

# Generated at 2022-06-20 23:25:41.747184
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv("one=two three=four")
    assert result["one"] == "two"
    assert result["three"] == "four"
    assert len(result) == 2
    result = parse_kv("one=two=three", check_raw=False)
    assert len(result) == 1
    assert result["one"] == "two=three"
    result = parse_kv("one=two=three", check_raw=True)
    assert len(result) == 1
    assert "=" in result["_raw_params"]
    result = parse_kv("one=two three=four", check_raw=True)
    assert result["one"] == "two"
    assert result["three"] == "four"
    assert "_raw_params" not in result

# Generated at 2022-06-20 23:25:53.600131
# Unit test for function split_args
def test_split_args():
    # Test empty args
    assert split_args(u'') == []

    # Test a=1 b=2
    assert split_args(u'a=1 b=2') == [u'a=1', u'b=2']

    # Test a="b c"
    assert split_args(u'a="b c"') == [u'a="b c"']

    # Test a="b c" d e
    assert split_args(u'a="b c" d e') == [u'a="b c"', u'd', u'e']

    # Test a={{ b }} c={{ d }}
    assert split_args(u'a={{ b }} c={{ d }}') == [u'a={{ b }}', u'c={{ d }}']

    # Test a={{ b }} c=

# Generated at 2022-06-20 23:26:03.240833
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('key=value') == {u'key': u'value'}
    assert parse_kv('key1=value1,key2=\\"value2\\\\pi\\\\\\"\\"') == {u'key1': u'value1', u'key2': u'"value2\\pi\\""'}
    assert parse_kv('key1=value1,key2=\\"value2\\\\pi\\\\\\"\\"', check_raw=True) == {u'key1': u'value1', u'key2': u'"value2\\pi\\"', u'_raw_params': u'key1=value1,key2=\\"value2\\\\pi\\\\\\"\\"'}


# Generated at 2022-06-20 23:26:17.606955
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c='d e' f=g h 'i''j' k") == [u'a=b', u"c='d e'", u'f=g', u'h', u"i'j", u'k']
    assert split_args(u'a=b "c d" e=f') == [u'a=b', u'"c d"', u'e=f']
    assert split_args(u'a=b "c d') == [u'a=b', u'"c', u'd']
    assert split_args(u'a=b """c d') == [u'a=b', u'"""c', u'd']
    assert split_args(u'a=b """c d') == [u'a=b', u'"""c', u'd']


# Generated at 2022-06-20 23:26:26.516186
# Unit test for function split_args
def test_split_args():

    # Simple test:
    # Input:
    #    a=b c="foo bar"
    # Expected output:
    #    ['a=b', 'c="foo bar"']
    my_args = u'a=b c="foo bar"'
    my_result = split_args(my_args)
    assert(len(my_result) == 2)
    assert(my_result[0] == u"a=b")
    assert(my_result[1] == u'c="foo bar"')

    # Test double quotes:
    # Input:
    #    a="b c d"
    # Expected output:
    #    ['a="b c d"']
    my_args = u'a="b c d"'
    my_result = split_args(my_args)

# Generated at 2022-06-20 23:26:29.554856
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', '\n', 'bar']) == 'foo\nbar'
    assert join_args(['foo', 'bar']) == 'foo bar'



# Generated at 2022-06-20 23:26:39.743578
# Unit test for function parse_kv
def test_parse_kv():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument

    # simple key/value pairs
    results = parse_kv('foo=bar baz=foobar')
    assert results == {'foo': 'bar', 'baz': 'foobar'}

    # quoted values
    results = parse_kv('foo="with space" bar="with \"quote\""')
    assert results == {'foo': 'with space', 'bar': 'with "quote"'}

    # quoted unbalanced quotes
    results = parse_kv('foo="with space"')
    assert results == {'foo': 'with space'}

    # quoted balanced quotes
    results = parse_kv("foo='with space'")
    assert results == {'foo': 'with space'}

    # escaped quotes
   

# Generated at 2022-06-20 23:26:41.494513
# Unit test for function join_args
def test_join_args():
    s = ['foo','bar','baz']
    print(join_args(s))
#test_join_args()


# Generated at 2022-06-20 23:26:50.981187
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("c=\"foo bar\" a=b") == ['c="foo bar"', 'a=b']
    assert split_args("a=b") == ['a=b']
    assert split_args("a=\"b c\"") == ['a="b c"']
    assert split_args("a=\"b c\" d=\"e f\"") == ['a="b c"', 'd="e f"']
    assert split_args("a=\"b c\" d=\"e f\" g='h i'") == ['a="b c"', 'd="e f"', "g='h i'"]

# Generated at 2022-06-20 23:27:00.817738
# Unit test for function split_args
def test_split_args():
    assert ['foo'] == split_args('foo')
    assert ['foo', 'foo bar'] == split_args('foo "foo bar"')
    assert ['foo', 'bar baz'] == split_args('foo "bar baz"')
    assert ['foo', 'bar baz'] == split_args("foo 'bar baz'")
    assert ['foo', 'bar', 'baz'] == split_args("foo bar baz")
    assert ['foo', 'bar', 'baz'] == split_args("foo bar baz")
    assert ['foo', 'bar baz'] == split_args("foo bar\\ baz")
    assert ['foo', 'bar', 'baz'] == split_args("foo 'bar' baz")
    assert ['foo', 'bar', 'baz'] == split_args('foo "bar" baz')
   

# Generated at 2022-06-20 23:27:05.884612
# Unit test for function split_args
def test_split_args():
    '''
    This function unit tests the split_args function.
    '''
    args_data = dict(
        dict(param='a=b c="foo bar"', expected=['a=b', 'c="foo bar"'])
    )
    for args, expected in args_data.items():
        split_args(args) == expected

    for args, expected in args_data.items():
        split_args(args) == expected
test_split_args()

# Generated at 2022-06-20 23:27:16.384975
# Unit test for function split_args
def test_split_args():
    args = '''a="{{" b="{{ foo }}" c="foo" d="{{ foo }}bar" e="{{ foo }}\\
        bar" f="}}"\\
        g="foo {{" h="foo {{ bar }}" i="foo {{ bar }} baz" j="foo {{ bar }}\\
        baz" k="foo }} bar" l="foo }} bar" m={{" bar }} n={{" bar }}" o="}}\\
        foo" p="}} foo" q="foo }} bar" r="foo }} bar" s="foo }} bar baz" t="foo \\
        }} bar baz" u="foo {{ bar }} baz" v="foo {{ bar }} baz" w="foo {{ bar }}\\
        baz" x="foo {{ bar }} baz" y="foo}}" z="foo}}"'''

    result = split

# Generated at 2022-06-20 23:27:25.688617
# Unit test for function split_args
def test_split_args():
    def test_helper(value, expected):
        result = split_args(value)
        err_msg = "Expected %s, got %s" % (repr(expected), repr(result))
        assert result == expected, err_msg

    # Empty string should return an empty array
    test_helper("", [])
    # Whitespace only
    test_helper("   ", [])
    # Basic token
    test_helper("simple", ['simple'])
    # Basic single quoted token
    test_helper("'simple'", ["'simple'"])
    # Basic double quoted token
    test_helper('"simple"', ['"simple"'])
    # Basic double quoted token with multiple spaces
    test_helper('"simple   example"', ['"simple   example"'])
    # Basic double quoted token with multiple

# Generated at 2022-06-20 23:27:41.872346
# Unit test for function split_args

# Generated at 2022-06-20 23:27:49.647143
# Unit test for function split_args
def test_split_args():
    assert split_args('foo={{bar}}') == ['foo={{bar}}']
    assert split_args('foo={{bar}} baz={{blah}}') == ['foo={{bar}}', 'baz={{blah}}']
    assert split_args('foo={{bar baz={{blah}}}}') == ['foo={{bar baz={{blah}}}}']
    assert split_args('foo={{bar {{blah}}') == ['foo={{bar {{blah}}']
    assert split_args('foo=bar{{blah}}') == ['foo=bar{{blah}}']
    assert split_args('foo= "bar baz {{blah"' ) == ['foo=', '"bar baz {{blah"']

# Generated at 2022-06-20 23:28:00.205232
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv('a=1') == {u'a': u'1'}
    assert parse_kv('a=1 b=2') == {u'a': u'1', u'b': u'2'}
    assert parse_kv(' a=1 b=2 ') == {u'a': u'1', u'b': u'2'}
    assert parse_kv('a=1\tb=2') == {u'a': u'1', u'b': u'2'}
    assert parse_kv('a="1 2 3"') == {u'a': u'1 2 3'}
    assert parse_kv('a="1 2 3" b="4 5 6"') == {u'a': u'1 2 3', u'b': u'4 5 6'}

# Generated at 2022-06-20 23:28:09.410214
# Unit test for function parse_kv

# Generated at 2022-06-20 23:28:16.164313
# Unit test for function split_args
def test_split_args():
    def compare_parsed_args(ok, args, func=split_args):
        """
        Returns True if args was parsed correctly, otherwise raises an error
        with a helpful message that describes the problem.
        """
        try:
            result = func(args)
        except Exception as e:
            print("ERROR: failed to parse arguments: {0}".format(args))
            print("Exception: {0}".format(e))
            return False

        if ok != result:
            print("")
            print("ERROR: failed to parse arguments: {0}".format(args))

# Generated at 2022-06-20 23:28:26.247790
# Unit test for function split_args

# Generated at 2022-06-20 23:28:35.347849
# Unit test for function split_args
def test_split_args():
    "check that all these args are treated the same in split_args function"

# Generated at 2022-06-20 23:28:43.788742
# Unit test for function split_args
def test_split_args():
    assert ['foo=bar', 'stuff="create', 'test1.txt"', 'other="baz"'] == split_args('foo=bar stuff="create\\ntest1.txt" other="baz"')
    assert ['foo=bar', 'stuff="create', 'test1.txt"', 'other="baz"'] == split_args('foo=bar stuff="create\\r\\ntest1.txt" other="baz"')
    assert ['foo=bar', 'stuff="create', 'test1.txt"', 'other="baz"'] == split_args('foo=bar stuff="create\\rtest1.txt" other="baz"')

# Generated at 2022-06-20 23:28:53.466553
# Unit test for function split_args

# Generated at 2022-06-20 23:29:00.498408
# Unit test for function join_args
def test_join_args():
    s = ['foo', 'bar', "I'm not done yet", 'newline\nis done']
    assert join_args(s) == 'foo bar "I\'m not done yet" newline\nis done'

    s = ['foo', 'bar', '"I\'m done now"']
    assert join_args(s) == 'foo bar "I\'m done now"'

    s = ['foo', 'bar', '\n"I\'m done now"']
    assert join_args(s) == 'foo bar\n"I\'m done now"'



# Generated at 2022-06-20 23:29:16.659243
# Unit test for function parse_kv
def test_parse_kv():

    class FakeModule(object):
        def __init__(self, fail_json):
            self.fail_json = fail_json

    my_module = FakeModule(fail_json=True)

    # single item
    assert parse_kv('port=3000') == {u'port': u'3000'}

    # multiple items
    assert parse_kv('port=3000 user=apache group=apache') == {u'port': u'3000', u'user': u'apache', u'group': u'apache'}

    # equals in and out of values
    assert parse_kv('port=3=0=0 user=apache group=apache') == {u'port': u'3=0=0', u'user': u'apache', u'group': u'apache'}

    # escaped equals

# Generated at 2022-06-20 23:29:22.336941
# Unit test for function parse_kv
def test_parse_kv():
    # Trivial
    assert parse_kv(u"") == {}
    assert parse_kv(u" \n\n    \t") == {}
    assert parse_kv(u"a=b") == {u'a': u'b'}
    assert parse_kv(u"   a=b") == {u'a': u'b'}
    assert parse_kv(u"a=b   ") == {u'a': u'b'}
    assert parse_kv(u"   a=b   ") == {u'a': u'b'}
    assert parse_kv(u"a=b c=d") == {u'a': u'b', u'c': u'd'}