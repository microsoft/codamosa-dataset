

# Generated at 2022-06-20 23:19:50.002185
# Unit test for function join_args
def test_join_args():
    assert join_args(['a','\nb','\nc','\n','\nd','\n','e','\n','f','\n','\ng','\n','h']) == 'a\nb\nc\n\nd\n\ne\n\nf\n\ng\n\nh'



# Generated at 2022-06-20 23:19:59.000764
# Unit test for function split_args
def test_split_args():
    print(split_args('a=b c="foo bar"'))
    print(split_args('a=b c="{{ foo }}"'))
    print(split_args('a=b c="foo {{bar}} baz"'))
    print(split_args('a=b c="foo {{bar}} {{ baz }}"'))
    print(split_args('a=b c="foo {%bar%} baz"'))
    print(split_args('a=b c="foo {%bar%} {% baz %}"'))
    print(split_args('a=b c="foo {#bar#} baz"'))
    print(split_args('a=b c="foo {#bar#} {# baz #}"'))
test_split_args()


# Generated at 2022-06-20 23:20:10.977940
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b', join_args(['a', 'b'])
    assert join_args(['"a', 'b"', 'c']) == '"a b" c', join_args(['"a', 'b"', 'c'])
    assert join_args(['"a', 'b"', "c=1", 'd']) == '"a b" c=1 d', join_args(['"a', 'b"', "c=1", 'd'])
    assert join_args(['a=1', 'b="', 'c', 'd"']) == 'a=1 b=" c d"', join_args(['a=1', 'b="', 'c', 'd"'])

# Generated at 2022-06-20 23:20:20.960824
# Unit test for function split_args
def test_split_args():
    print("Testing function split_args")
    line_to_args_map = {}
    line_to_args_map[u'a=b c="foo bar"'] = [u'a=b', u'c="foo bar"']
    line_to_args_map[u'a=b c="foo bar\\"'] = [u'a=b', u'c="foo bar\\"']
    line_to_args_map[u"a=b c='foo bar\\'"] = [u'a=b', u"c='foo bar\\'"]
    line_to_args_map[u"a=b c='foo bar\\''"] = [u'a=b', u"c='foo bar\\''"]

# Generated at 2022-06-20 23:20:32.097651
# Unit test for function split_args

# Generated at 2022-06-20 23:20:42.734489
# Unit test for function split_args
def test_split_args():
    '''
    Test suite for the split_args function.
    Need to test the following:
    - multiple sections
    - jinja2 block nesting
    - quotes and escapes
    - whitespace and line breaks

    '''
    import unittest
    import pprint

    class TestParseKv(unittest.TestCase):

        def setUp(self):
            self.single_arg = "a=b"
            self.multi_arg = "a=b c=d"
            self.quoted_arg = "a=b c=\"foo bar\""
            self.quoted_and_escaped_arg = "a=b c=\"foo bar\\\""
            self.multi_line = 'a=b\nc=d'

# Generated at 2022-06-20 23:20:49.217275
# Unit test for function split_args
def test_split_args():
    # Test strings have to be unicode strings, or else we get encoding problems
    s = u"a=b c=\"foo bar\""
    result = split_args(s)
    assert result == ['a=b', 'c="foo bar"']

    s = u"foo bar baz"
    result = split_args(s)
    assert result == ['foo', 'bar', 'baz']

    s = u"foo\\\nbar\\\nbaz"
    result = split_args(s)
    assert result == ['foo', 'bar', 'baz']

    s = u"foo\\\nbar' baz'\\\nbash"
    result = split_args(s)
    assert result == ["foo", "bar' baz'", "bash"]


# Generated at 2022-06-20 23:20:53.728324
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args('a=b c={   \n    "foo" : "bar" }') == ['a=b', 'c={   \n    "foo" : "bar" }']
    assert split_args('a=b c={{ [1,2,3]|json_query("foo") }}') == ['a=b', 'c={{ [1,2,3]|json_query("foo") }}']
    assert split_args("a=b c={{ [1,2,3]|json_query(\"foo\") }}") == ['a=b', 'c={{ [1,2,3]|json_query("foo") }}']

# Generated at 2022-06-20 23:20:58.305045
# Unit test for function split_args

# Generated at 2022-06-20 23:21:03.436700
# Unit test for function split_args
def test_split_args():
    '''
    Test function split_args
    '''
    assert split_args('file=/etc/test') == ['file=/etc/test']
    assert split_args('{{var1}} file=/etc/test') == ['{{var1}}', 'file=/etc/test']
    assert split_args('{{ var1 }}{% raw %}{% endif %} file=/etc/test') == ['{{ var1 }}{% raw %}{% endif %}', 'file=/etc/test']
    assert split_args('{# comment #} file=/etc/test') == ['{# comment #}', 'file=/etc/test']

# Generated at 2022-06-20 23:21:27.592682
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("abc=123 def='456'") == {'abc': '123', 'def': '456'}
    assert parse_kv("abc=123 def='456'") == {'abc': '123', 'def': '456'}
    assert parse_kv("abc=123 def='456'") == {'abc': '123', 'def': '456'}
    assert parse_kv("abc=123 def='456'") == {'abc': '123', 'def': '456'}
    assert parse_kv("abc=123 def='456'") == {'abc': '123', 'def': '456'}
    assert parse_kv("abc=123 def='456'") == {'abc': '123', 'def': '456'}

# Generated at 2022-06-20 23:21:38.160207
# Unit test for function split_args
def test_split_args():
    '''
    Test function split_args
    '''


# Generated at 2022-06-20 23:21:47.356311
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=b") == {u'a': u'b'}
    assert parse_kv(u"a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u"a='foo bar' b=2") == {u'a': u'foo bar', u'b': u'2'}
    assert parse_kv(u"a='foo bar' b=2 c=3") == {u'a': u'foo bar', u'b': u'2', u'c': u'3'}
    assert parse_kv(u'a=b c=d=3') == {u'a': u'b', u'c': u'd=3'}

# Generated at 2022-06-20 23:21:53.659427
# Unit test for function split_args

# Generated at 2022-06-20 23:22:05.579170
# Unit test for function split_args
def test_split_args():
    import sys
    if sys.version_info[:2] < (2, 7):
        from ansible.compat.unittest import TestCase
    else:
        from unittest import TestCase


# Generated at 2022-06-20 23:22:13.867833
# Unit test for function parse_kv
def test_parse_kv():
    kv = parse_kv('k1=v1 k2="v2 v3" k3=v4')
    assert kv == dict(k1=u'v1', k2=u'v2 v3', k3=u'v4'), kv

    kv = parse_kv(u'k1=v1 k2=\\"v2\\" k3=v4')
    assert kv == dict(k1=u'v1', k2=u'"v2"', k3=u'v4'), kv

    kv = parse_kv('k1=v1 k2=\\"v2 k3=v4')
    assert kv == dict(k1=u'v1', k2=u'"v2', k3=u'v4'), kv

    kv = parse

# Generated at 2022-06-20 23:22:24.263272
# Unit test for function parse_kv
def test_parse_kv():
    # test empty input
    assert parse_kv("") == {}
    # a=b
    assert parse_kv("a=b") == {"a":"b"}
    # a=b c=d
    assert parse_kv("a=b c=d") == {"a":"b", "c":"d"}
    # a=b c = d
    assert parse_kv("a=b c = d") == {"a":"b", "c":"d"}
    # a=b c = "d"
    assert parse_kv("a=b c = \"d\"") == {"a":"b", "c":"d"}
    # a=b c = "d" e = f
    assert parse_kv("a=b c = \"d\" e = f") == {"a":"b", "c":"d", "e":"f"}

# Generated at 2022-06-20 23:22:34.438610
# Unit test for function split_args

# Generated at 2022-06-20 23:22:46.056938
# Unit test for function split_args
def test_split_args():
    '''
    run test on function split_args
    '''

    # case 1
    args = """
    foo bar
    baz % bar
    """
    params = split_args(args)
    assert params == ['foo', 'bar\nbaz', '%', 'bar']

    # case 2
    args = '''
    foo bar
    baz % bar
    '''
    params = split_args(args)
    assert params == ['foo', 'bar\nbaz', '%', 'bar']

    # case 3
    args = """
    foo bar
    'baz' bar
    """
    params = split_args(args)
    assert params == ['foo', 'bar\nbaz bar']

    # case 4
    args = """
    foo bar
    'baz bar
    '
    """

# Generated at 2022-06-20 23:22:55.818749
# Unit test for function split_args
def test_split_args():
    import unittest
    import ansible.module_utils.basic

    class MyTests(unittest.TestCase):
        def test_split_args(self):
            def compare_args(args, expected):
                try:
                    result = split_args(args)
                    self.assertEqual(result, expected)
                except AnsibleParserError as e:
                    self.fail("Exception raising while parsing {0}. Exception raised was {1}".format(args, e))


# Generated at 2022-06-20 23:23:13.729182
# Unit test for function split_args
def test_split_args():
    '''
    Test for split_args
    '''
    assert split_args("hello world") == ["hello", "world"]
    assert join_args(split_args("hello world")) == "hello world"

    assert split_args("hello 'world'") == ["hello", "'world'"]
    assert join_args(split_args("hello 'world'")) == "hello 'world'"

    assert split_args("hello \"world\"") == ["hello", "\"world\""]
    assert join_args(split_args("hello \"world\"")) == "hello \"world\""

    assert split_args("hello {{foo}}") == ["hello", "{{foo}}"]
    assert join_args(split_args("hello {{foo}}")) == "hello {{foo}}"


# Generated at 2022-06-20 23:23:20.375248
# Unit test for function join_args
def test_join_args():
    assert 'foo\nbar' == join_args(['foo\n', 'bar'])
    assert 'foo bar' == join_args(['foo', 'bar'])
    assert 'foo\nbar' == join_args(['foo\n', 'bar'])
    assert 'foo\nbar baz' == join_args(['foo\n', 'bar', 'baz'])
    assert 'foo "bar baz"' == join_args(['foo', '"bar baz"'])
    assert 'foo "bar baz"' == join_args(['foo', '"bar', 'baz"'])
    assert 'foo "bar\nbaz"' == join_args(['foo', '"bar\nbaz"'])

# Generated at 2022-06-20 23:23:30.506430
# Unit test for function split_args
def test_split_args():
    assert split_args(args='foo') == ['foo']
    assert split_args(args='foo bar') == ['foo', 'bar']
    assert split_args(args='foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args(args='foo "bar baz" \\') == ['foo', '"bar baz"', '\\']
    assert split_args(args='foo "bar baz" \\  \\') == ['foo', '"bar baz"', '\\  \\']
    assert split_args(args='foo "bar baz" \\ "bar baz"') == ['foo', '"bar baz" \\ "bar baz"']


# Generated at 2022-06-20 23:23:40.587550
# Unit test for function split_args
def test_split_args():
    # FIXME: add more tests
    assert split_args("--foo bar --baz") == ['--foo', 'bar', '--baz']
    assert split_args("--foo bar --baz='blah blah'") == ['--foo', 'bar', "--baz='blah blah'"]
    assert split_args("--foo bar --baz='{{ hello }}'") == ['--foo', 'bar', "--baz='{{ hello }}'"]
    assert split_args("--foo bar --baz='{{ hello }} blah blah'") == ['--foo', 'bar', "--baz='{{ hello }} blah blah'"]
    assert split_args("--foo bar --baz='foo \\'bar\\' baz'") == ['--foo', 'bar', "--baz='foo \\'bar\\' baz'"]
   

# Generated at 2022-06-20 23:23:47.832759
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b") == {"a": "b"}
    assert parse_kv("a = b") == {"a": "b"}
    assert parse_kv("a= b") == {"a": "b"}
    assert parse_kv("  a   =   b  ") == {"a": "b"}
    assert parse_kv("a=b c=d") == {"a": "b", "c": "d"}
    assert parse_kv("a=b c=d e=f") == {"a": "b", "c": "d", "e": "f"}
    assert parse_kv("a='b c' d='e f'") == {"a": "b c", "d": "e f"}

# Generated at 2022-06-20 23:23:58.129483
# Unit test for function parse_kv
def test_parse_kv():
    # Test simple k=v
    options = parse_kv(u'mykey=foo')
    assert options == {u'mykey': u'foo'}

    # Test that spaces around the equals are optional
    options = parse_kv(u'mykey = foo')
    assert options == {u'mykey': u'foo'}

    # Test that quotes are handled
    options = parse_kv(u'mykey="foo"')
    assert options == {u'mykey': u'foo'}
    options = parse_kv(u'mykey="foo bar"')
    assert options == {u'mykey': u'foo bar'}
    options = parse_kv(u'mykey="foo=bar"')
    assert options == {u'mykey': u'foo=bar'}

# Generated at 2022-06-20 23:24:06.822166
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo="bar baz"') == {'foo': 'bar baz'}
    assert parse_kv('foo="bar baz" spam=eggs') == {'foo': 'bar baz', 'spam': 'eggs'}
    assert parse_kv('foo="bar baz" spam=eggs eggs="spam and"') == {'foo': 'bar baz', 'spam': 'eggs', 'eggs': 'spam and'}

# Generated at 2022-06-20 23:24:12.706626
# Unit test for function join_args
def test_join_args():
    '''
    Test function join_args
    '''
    # list of test cases
    # input, expected output
    test_cases = [
        (['a', 'b'], 'a b'),
        (['a', '\nb'], 'a\nb'),
        (['a', '\nb', 'c'], 'a\nb c'),
    ]
    for test in test_cases:
        # test the output against expectations
        assert join_args(test[0]) == test[1]



# Generated at 2022-06-20 23:24:21.756658
# Unit test for function parse_kv
def test_parse_kv():
    option = parse_kv('a=b c=d e="f g" h=\'i j\'')
    assert option['a'] == 'b'
    assert option['c'] == 'd'
    assert option['e'] == 'f g'
    assert option['h'] == 'i j'
    assert len(option) == 5

    option = parse_kv('a="b c"d e=\'f g\'h')
    assert option['a'] == 'b cd'
    assert option['e'] == 'f gh'
    assert len(option) == 2

    option = parse_kv('a="b c"d e=\'f g\'h', check_raw=True)
    assert len(option) == 4
    assert option['a'] == 'b cd'

# Generated at 2022-06-20 23:24:29.399076
# Unit test for function parse_kv
def test_parse_kv():
    print(parse_kv('name="Test\\"Test"',check_raw=True))
    print(parse_kv('name="Test\\"Test"',check_raw=False))
    print(parse_kv('name="Test\\"Test\\""',check_raw=True))
    print(parse_kv('name="Test\\"Test\\"", name2="Test"',check_raw=True))
    print(parse_kv('name="Test\\"Test\\"" name2="Test"',check_raw=True))
    print(parse_kv('name="Test\\"Test" name2="Test"',check_raw=True))
    print(parse_kv('name="Test"Test" name2="Test"',check_raw=True))

# Generated at 2022-06-20 23:24:45.937359
# Unit test for function join_args
def test_join_args():
    assert "echo arg1 arg2" == join_args(['echo', 'arg1', 'arg2'])
    assert "echo arg1 arg2 arg3 arg4\n" == join_args(['echo', 'arg1', 'arg2 arg3 arg4'])
    assert "echo \"arg1 arg2 arg3 arg4\"\n" == join_args(['echo', '"arg1 arg2 arg3 arg4"'])
    assert "echo \"arg1 arg2 arg3 arg4\"\n" == join_args(['echo', '"arg1', 'arg2 arg3 arg4"'])
    assert "echo \"arg1 arg2 arg3 arg4\"\n" == join_args(['echo', '"arg1 arg2 arg3 arg4'])

# Generated at 2022-06-20 23:24:55.524938
# Unit test for function split_args
def test_split_args():
    # Test with one item
    test = "1"
    result = split_args(test)
    assert result == ["1"]

    # Test with multiple items
    test = "1 2 3"
    result = split_args(test)
    assert result == ["1", "2", "3"]

    # Test with spaces in item
    test = '1 a="2 3" 4'
    result = split_args(test)
    assert result == ['1', 'a="2 3"', '4']

    # Test with spaces in item and no quotes
    test = '1 a=2 3 4'
    result = split_args(test)
    assert result == ['1', 'a=2', '3', '4']

    # Test with spaces in item and no quotes, with dashes

# Generated at 2022-06-20 23:25:04.409378
# Unit test for function join_args
def test_join_args():
    assert join_args(['one', 'two']) == 'one two'
    assert join_args(['one', 'two', 'three']) == 'one two three'
    assert join_args(['one', '\ntwo']) == 'one\ntwo'
    assert join_args(['one', '\ntwo', 'three']) == 'one\ntwo three'
    assert join_args(['\none', '\ntwo', 'three']) == '\none\ntwo three'
    assert join_args(['one', '\ntwo', '\nthree']) == 'one\ntwo\nthree'


# Generated at 2022-06-20 23:25:09.079963
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'a', 'b', 'c']) == 'echo a b c'
    assert join_args(['a\nb', 'c', 'd', 'e\nf']) == 'a\nb c d e\nf'
    assert join_args(['a\n', 'b', 'c d', '\ne f', '\ng']) == 'a\n b c d \ne f \ng'


# Generated at 2022-06-20 23:25:19.792261
# Unit test for function split_args
def test_split_args():
    import unittest

    class SplitArgsTestCase(unittest.TestCase):
        def test_no_args(self):
            self.assertEqual(split_args(''), [])

        def test_split_space(self):
            self.assertEqual(split_args('a b'), ['a', 'b'])

        def test_split_space_with_comments(self):
            self.assertEqual(split_args('a b #k=v'), ['a', 'b'])

        def test_split_quote(self):
            self.assertEqual(split_args('"a" "b"'), ['a', 'b'])


# Generated at 2022-06-20 23:25:29.449873
# Unit test for function split_args
def test_split_args():
    # Test cases borrowed from
    # https://github.com/ansible/ansible/blob/devel/test/units/modules/utilities/test_common.py
    result = split_args('')
    assert result == []

    result = split_args('a=b')
    assert result == ['a=b']

    result = split_args('a=b c=d')
    assert result == ['a=b', 'c=d']

    result = split_args('a=b "c=d"')
    assert result == ['a=b', '"c=d"']

    result = split_args('a=b "c=d e=f"')
    assert result == ['a=b', '"c=d e=f"']


# Generated at 2022-06-20 23:25:35.824471
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv('''foo=bar param=foobar creates=/tmp/somefile executable=/bin/bash''')
    assert options[u'foo'] == u'bar'
    assert options[u'param'] == u'foobar'
    assert options[u'creates'] == u'/tmp/somefile'
    assert options[u'executable'] == u'/bin/bash'

    options = parse_kv('''foo=bar param=foobar creates=/tmp/somefile _raw_params=executable=/bin/bash''')
    assert options[u'foo'] == u'bar'
    assert options[u'param'] == u'foobar'
    assert options[u'creates'] == u'/tmp/somefile'

# Generated at 2022-06-20 23:25:46.907486
# Unit test for function parse_kv
def test_parse_kv():
    def _test_case(s, expected):
        test_output = parse_kv(s)
        assert test_output == expected, "Failed to parse key value argument '%s' correctly. Expected: %s, Actual: %s" % (s, expected, test_output)
    _test_case("one=two three=four", {"one": "two", "three": "four"})
    _test_case("one='two three' four=five", {"one": "two three", "four": "five"})
    _test_case("one=\"two three\" four=five", {"one": "two three", "four": "five"})
    _test_case("one=two three=four five", {"one": "two", "three": "four", "_raw_params": "five"})

# Generated at 2022-06-20 23:25:55.527851
# Unit test for function split_args
def test_split_args():
    # Test basic functionality, e.g. commands with arguments
    assert split_args("echo hello") == ['echo', 'hello']
    assert split_args("echo 'hello world'") == ["echo", "'hello world'"]
    assert split_args("echo 'hello world' > /path/to/file") == ["echo", "'hello world'", ">", "/path/to/file"]

    # Test array syntax, quoted or not
    assert split_args("foo=(bar baz)") == ['foo=(bar', 'baz)']
    assert split_args('foo=("bar baz")') == ["foo=('bar baz')"]

    # Test line continuations
    assert split_args("this is\\\na test") == ['this', 'is', 'a test']
    assert split_args("this is\\\n       a test")

# Generated at 2022-06-20 23:26:05.500129
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d="foo\\" bar" e=\'foo "bar\' f=\\"foo "bar\\"') == [u'a=b', u'c="foo bar"', u'd="foo\\" bar"', u'e=\'foo "bar\'', u'f=\\"foo "bar\\"']
    assert split_args(u'a=b c=\'foo "bar\' d="foo\\" bar"') == [u'a=b', u'c=\'foo "bar\'', u'd="foo\\" bar"']

# Generated at 2022-06-20 23:26:18.131253
# Unit test for function join_args
def test_join_args():
    cmd = '''
    a=1
    b=2\nc=3'''

    assert join_args(split_args(cmd)) == cmd
    assert join_args(split_args(cmd.strip())) == cmd



# Generated at 2022-06-20 23:26:27.653057
# Unit test for function split_args
def test_split_args():
    args = 'ssh -o proxycommand="ssh -W %h:%p -q bastionuser@bastion.net" -o StrictHostKeyChecking=no -i ~/.ssh/vurt/vurt-key -l user_a host_a.vurt.net'
    params = split_args(args)
    assert len(params) == 2
    assert params[0] == 'ssh -o proxycommand="ssh -W %h:%p -q bastionuser@bastion.net" -o StrictHostKeyChecking=no -i ~/.ssh/vurt/vurt-key -l user_a'
    assert params[1] == 'host_a.vurt.net'
    params = split_args('foo bar baz')
    assert len(params) == 3
    assert params[0] == 'foo'

# Generated at 2022-06-20 23:26:38.393302
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar')               == dict(foo="bar")
    assert parse_kv('foo="bar"')             == dict(foo="bar")
    assert parse_kv('foo=b ar')              == dict(foo="b ar")
    assert parse_kv('foo="a b c"')           == dict(foo="a b c")
    assert parse_kv('foo=bar baz=foobar')    == dict(foo="bar", baz="foobar")
    assert parse_kv('foo="bar baz" baz=foobar') == dict(foo="bar baz", baz="foobar")
    assert parse_kv('foo=bar baz="foobar baz"') == dict(foo="bar", baz="foobar baz")

# Generated at 2022-06-20 23:26:43.566223
# Unit test for function join_args
def test_join_args():
    assert join_args(['1', '2', '3']) == '1 2 3'
    assert join_args([]) == ''
    assert join_args(['a', 'b', 'c\n', 'd', 'e', 'f']) == 'a b c\nd e f'
    assert join_args(['a\n', 'b', 'c', 'd', 'e\n', 'f']) == 'a\nb c d e\nf'



# Generated at 2022-06-20 23:26:50.451258
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', '\nb', 'c']) == 'a\n b c'
    assert join_args(['a', 'b', '\nc']) == 'a b\nc'
    assert join_args(['a', 'b', '\n', 'c']) == 'a b\n c'
    assert join_args(['a', 'b', '\n\nc']) == 'a b\n\nc'



# Generated at 2022-06-20 23:27:00.237065
# Unit test for function parse_kv
def test_parse_kv():
    passed = True
    def test(i, o, check_raw=False):
        global passed
        if parse_kv(i, check_raw=check_raw) == o:
            return
        else:
            print("parse_kv(" + i + ") should have been " + str(o) + " but was " + str(parse_kv(i, check_raw=check_raw)))
            passed = False

    test("", {})
    test("a=foo", {u'a': u'foo'})
    test("a=foo bar=baz", {u'a': u'foo', u'bar': u'baz'})
    test("a=foo bar=baz ", {u'a': u'foo', u'bar': u'baz'})

# Generated at 2022-06-20 23:27:07.933096
# Unit test for function split_args
def test_split_args():
    def _check_split(expected, arg):
        assert split_args(arg) == expected
    _check_split(["foo"], "foo")
    # double quoting is not supported
    _check_split(["\"foo\""], "\"foo\"")
    _check_split(["\"foo"], "\"foo")
    _check_split(["'foo"], "'foo")
    # single quoting is supported
    _check_split(["'foo'"], "'foo'")
    _check_split(["'foo", "'foo"], "'foo")
    _check_split(['"foo', '"foo'], '"foo')
    _check_split(["foo"], "foo")
    _check_split(["foo", "bar"], "foo bar")
    _check_split(["foo bar"], "'foo bar'")
    _check

# Generated at 2022-06-20 23:27:19.030051
# Unit test for function split_args
def test_split_args():
    import pytest
    def assert_split(input, expect):
        output = split_args(input)
        assert output == expect, 'expect {0}, got {1}'.format(
                expect, output)

    assert_split('foo bar baz', ['foo', 'bar', 'baz'])
    assert_split('foo    bar', ['foo', '   ', 'bar'])
    assert_split('foo    bar baz', ['foo', '   ', 'bar', 'baz'])
    assert_split('foo bar \\\n baz', ['foo', 'bar', '\n', 'baz'])

    assert_split('foo "bar baz"', ['foo', '"bar baz"'])
    assert_split("foo 'bar baz'", ["foo", "'bar baz'"])
    assert_split

# Generated at 2022-06-20 23:27:19.815447
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', '\nb', 'c d']) == 'a\nb c d'



# Generated at 2022-06-20 23:27:20.364703
# Unit test for function parse_kv
def test_parse_kv():
    pass


# Generated at 2022-06-20 23:27:38.172639
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing parse_kv")

# Generated at 2022-06-20 23:27:47.214244
# Unit test for function parse_kv
def test_parse_kv():
    data = """one='1' two='2' three='3' four=''"""
    assert parse_kv(data) == {u'one': u'1', u'three': u'3', u'four': u'', u'two': u'2'}

    data = """one='1' two=two three=3='3' four=''"""
    assert parse_kv(data) == {u"three": "3='3'", u"two": u"two", u'one': u'1', u'_raw_params': "one='1' two=two three=3='3' four=''"}


# Generated at 2022-06-20 23:27:53.717071
# Unit test for function parse_kv
def test_parse_kv():
    # Tests a simple key/value pair with no whitespace
    result = parse_kv("foo=bar")
    if result['foo'] != u"bar":
        raise AssertionError("Simple key/value pair with no whitespace is not parsed correctly")

    # Tests a key/value pair with lots of whitespace
    result = parse_kv("       foo       =       bar         ")
    if result['foo'] != u"bar":
        raise AssertionError("Key/value pair with lots of whitespace is not parsed correctly")

    # Tests a string with multiple assignment operators
    result = parse_kv("foo=bar=baz")
    if result[u'_raw_params'] != u"foo=bar=baz":
        raise AssertionError("String with multiple assignment operators is not parsed correctly")

    # Tests a string with

# Generated at 2022-06-20 23:28:04.054109
# Unit test for function parse_kv
def test_parse_kv():

    # Test that arguments are correctly parsed - double quote
    args = 'arg1="bar1" arg2="bar2" arg3="bar3"'
    expected = dict(arg1='bar1', arg2='bar2', arg3='bar3')
    assert parse_kv(args) == expected

    # Test that arguments are correctly parsed - single quote
    args = "arg1='bar1' arg2='bar2' arg3='bar3'"
    expected = dict(arg1='bar1', arg2='bar2', arg3='bar3')
    assert parse_kv(args) == expected

    # Test that arguments are correctly parsed - no quote
    args = 'arg1=bar1 arg2=bar2 arg3=bar3'
    expected = dict(arg1='bar1', arg2='bar2', arg3='bar3')


# Generated at 2022-06-20 23:28:12.534061
# Unit test for function join_args
def test_join_args():
    assert join_args(['a','b','c']) == 'a b c'
    assert join_args(['a','\nb','c']) == 'a\n b c'
    assert join_args(['a','\nb\n','c']) == 'a\n b\n c'
    import itertools
    for a in itertools.permutations(['a','b','c'], 3):
        assert join_args(a) == 'a b c'
    for a in itertools.permutations(['a','\nb','c'], 3):
        assert join_args(a) == 'a\n b c'
    for a in itertools.permutations(['a','\nb\n','c'], 3):
        assert join_args(a) == 'a\n b\n c'

# Generated at 2022-06-20 23:28:24.686623
# Unit test for function parse_kv

# Generated at 2022-06-20 23:28:29.601907
# Unit test for function join_args
def test_join_args():
    s = split_args('a b " c "')
    assert s == ['a', 'b', ' c ']
    result = join_args(s)
    assert result == 'a b  c '
    s = split_args('a b\n" c "')
    assert s == ['a', 'b\n', ' c ']
    result = join_args(s)
    assert result == 'a b\n c '



# Generated at 2022-06-20 23:28:39.331011
# Unit test for function parse_kv
def test_parse_kv():
    # Test 1
    result1 = parse_kv("aa=bb")
    assert(result1 == {"aa":"bb"})
    # Test 2
    result2 = parse_kv("aa=\"bb bb\"")
    assert(result2 == {"aa":"bb bb"})
    # Test 3
    result3 = parse_kv("aa=\"bb bb\" cc=dd")
    assert(result3 == {"aa":"bb bb", "cc":"dd"})
    # Test 4
    result4 = parse_kv("aa=\"bb=bb\"")
    assert(result4 == {"aa":"bb=bb"})
    # Test 5
    result5 = parse_kv("aa=''")
    assert(result5 == {"aa":""})


# split args adapted from commands.sh

# Generated at 2022-06-20 23:28:48.588129
# Unit test for function split_args
def test_split_args():
    assert split_args("foo bar baz") == ["foo", "bar", "baz"]
    assert split_args("foo bar baz one two three") == ["foo", "bar", "baz", "one", "two", "three"]
    assert split_args("foo bar baz \"one two three\" four five six") == ["foo", "bar", "baz", "\"one two three\"", "four", "five", "six"]
    assert split_args("foo bar baz \"one two three\\\" four\\\" five six") == ["foo", "bar", "baz", "\"one two three\\\" four\\\" five six"]
    assert split_args(" foo bar \\n baz one two three ") == ["foo", "bar", "baz", "one", "two", "three"]

# Generated at 2022-06-20 23:28:58.701527
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar baz=qux") == {"foo": "bar", "baz": "qux"}
    assert parse_kv(u"foo='bar baz' qux=quux") == {"foo": "bar baz", "qux": "quux"}
    assert parse_kv(u"foo='bar baz' qux=quux fred=\"tom\\'s joe\"") == {"foo": "bar baz", "qux": "quux", "fred": "tom's joe"}
    assert parse_kv(u"'bar baz' qux=quux fred=\"tom\\'s joe\"") == {"_raw_params": u"'bar baz' qux=quux fred=\"tom\\'s joe\""}



# Generated at 2022-06-20 23:29:18.663623
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"key1=value1 key2=value2") == {u"key1":u"value1", u"key2":u"value2"}
    assert parse_kv(u"key1=value1  key2=value2") == {u"key1":u"value1", u"key2":u"value2"}
    assert parse_kv(u"key1=value1\tkey2=value2") == {u"key1":u"value1", u"key2":u"value2"}
    assert parse_kv(u"key1=value1 key2= value2") == {u"key1":u"value1", u"key2":u"value2"}

# Generated at 2022-06-20 23:29:31.740463
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b') == {u'a': u'b'}
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b "c d"=e') == {u'a': u'b', u'c d': u'e'}
    assert parse_kv('a=b "c = d"=e') == {u'a': u'b', u'c = d': u'e'}
    assert parse_kv('a=b x\\=y=c') == {u'a': u'b', u'x\\=y': u'c'}