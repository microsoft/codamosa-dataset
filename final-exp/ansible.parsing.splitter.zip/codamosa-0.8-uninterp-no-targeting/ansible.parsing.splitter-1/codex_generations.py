

# Generated at 2022-06-20 23:20:23.343766
# Unit test for function parse_kv
def test_parse_kv():
    o = parse_kv('a=b key="val" c=d e="f g=h" i=j k=l m\=n o="p=q" r s')

    # check the key/value items
    assert(o['a'] == 'b')
    assert(o['key'] == 'val')
    assert(o['c'] == 'd')
    assert(o['e'] == 'f g=h')
    assert(o['i'] == 'j')
    assert(o['k'] == 'l')
    assert(o['m=n'] == '')
    assert(o['o'] == 'p=q')

    # check the remainder
    assert(o['_raw_params'] == 'r s')


# Generated at 2022-06-20 23:20:33.236554
# Unit test for function split_args
def test_split_args():
    def assert_split_args(args, expected_params):
        params = split_args(args)
        assert params == expected_params, "split_args(%r)!=%r, actual=%r" % (args, expected_params, params)

    assert_split_args("", [])
    assert_split_args("a=b c=\"foo bar\"", ['a=b', 'c="foo bar"'])
    assert_split_args("a=\"foo bar\" c=b", ['a="foo bar"', 'c=b'])
    assert_split_args("a=b c=d e=\"foo bar\"", ['a=b', 'c=d', 'e="foo bar"'])
    assert_split_args("a=\"foo bar", ['a="foo bar'])

# Generated at 2022-06-20 23:20:43.773898
# Unit test for function split_args
def test_split_args():
    def _test(args):
        assert split_args(args) == shlex.split(args)

    _test('a=b c="foo" d=\'bar\'')
    _test('''a="foo bar" b='foo bar' c='"foo bar"' d="'foo bar'"''')
    _test('''a=b "c d" 'e f' g''')
    _test('''a=b "c d" "e 'f'" g''')
    _test('''a=b "c 'd'" 'e "f"' g''')
    _test('a=b "c \'d\'" "e \'f\'" g')
    _test('a=b "c \'d\'" "e \'f\' g')

# Generated at 2022-06-20 23:20:54.414649
# Unit test for function parse_kv
def test_parse_kv():
    def test_assert_true(x):
        assert(x == True)
    def test_assert_equal(x, y):
        assert(x == y)

    options = parse_kv('key=val otherval')
    test_assert_true('key' in options)
    test_assert_equal(options['key'], 'val')
    test_assert_true('_raw_params' in options)
    test_assert_equal(options['_raw_params'], 'otherval')

    options = parse_kv(u'ke\u00e9=val otherval')
    test_assert_true(u'ke\u00e9' in options)
    test_assert_equal(options[u'ke\u00e9'], u'val')

# Generated at 2022-06-20 23:20:59.024389
# Unit test for function split_args
def test_split_args():
    # Test with trivial case
    test_string = "key=value"
    expected_result = ['key=value']
    actual_result = split_args(test_string)
    assert expected_result == actual_result

    # Test with no equals sign
    test_string = "key value"
    expected_result = ['key', 'value']
    actual_result = split_args(test_string)
    assert expected_result == actual_result

    # Test with multiline
    test_string = "key=value\nkey2=value2"
    expected_result = ['key=value', 'key2=value2']
    actual_result = split_args(test_string)
    assert expected_result == actual_result

    # Test with multiline, multicharacter equals

# Generated at 2022-06-20 23:21:08.217220
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'stderr=True') == {u'stderr': u'True'}
    assert parse_kv(u'creates=/tmp/myfile') == {u'creates': u'/tmp/myfile'}
    assert parse_kv(u'stdin=hello') == {u'stdin': u'hello'}
    assert parse_kv(u'{"one":1, "two":2}') == {u'one': u'1', u'two': u'2'}
    assert parse_kv(u'name=wendy age=12') == {u'name': u'wendy', u'age': u'12'}

# Generated at 2022-06-20 23:21:19.152989
# Unit test for function split_args
def test_split_args():
    assert split_args('{{foo}}') == ['{{foo}}']
    assert split_args('foo{{bar}}') == ['foo{{bar}}']
    assert split_args('foo {{bar}}') == ['foo', '{{bar}}']
    assert split_args('foo "{{bar}}"') == ['foo', '"{{bar}}"']
    assert split_args('foo "{{bar}}" baz') == ['foo', '"{{bar}}"', 'baz']
    assert split_args('foo "{{bar}}" baz {{bat}}') == ['foo', '"{{bar}}"', 'baz', '{{bat}}']
    assert split_args('foo {{bar}}{{bat}}') == ['foo', '{{bar}}{{bat}}']

# Generated at 2022-06-20 23:21:28.217336
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar") == {u'foo': u'bar'}
    assert parse_kv(u"foo='bar baz'") == {u'foo': u'bar baz'}
    assert parse_kv(u"foo=\"bar baz\"") == {u'foo': u'bar baz'}
    assert parse_kv(u"foo='bar=baz'") == {u'foo': u'bar=baz'}
    assert parse_kv(u"foo=\"bar=baz\"") == {u'foo': u'bar=baz'}
    assert parse_kv(u"foo='bar=\"baz\"'") == {u'foo': u'bar="baz"'}

# Generated at 2022-06-20 23:21:39.337625
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a={{foo}}') == [u'a={{foo}}']
    assert split_args(u'a={{foo}} b={{bar}}') == [u'a={{foo}}', u'b={{bar}}']
    assert split_args(u'a={{foo}} b="{{ bar }}"') == [u'a={{foo}}', u'b="{{ bar }}"']

# Generated at 2022-06-20 23:21:48.400507
# Unit test for function split_args

# Generated at 2022-06-20 23:22:06.302892
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\n', 'b']) == 'a\nb'
    assert join_args(['a\n']) == 'a\n'
    assert join_args(['a']) == 'a'
    assert join_args(['a', 'b\n', 'c']) == 'a\nb\nc'



# Generated at 2022-06-20 23:22:14.315714
# Unit test for function split_args
def test_split_args():
    # No jinja2 stuff, just quotes
    test_string = u'a=1 b="quoted args" c="use \\" quotes" d=\'single quotes\''
    assert split_args(test_string) == ["a=1", "b=\"quoted args\"", "c=\"use \\\" quotes\"", "d='single quotes'"]

    # Single jinja2 {{ }}
    test_string = u'a={{ foo }} b={{ bar }}'
    assert split_args(test_string) == ["a={{ foo }}", "b={{ bar }}"]

    # Single jinja2 {% %}
    test_string = u'a={% foo %} b={% bar %}'

# Generated at 2022-06-20 23:22:24.600383
# Unit test for function parse_kv
def test_parse_kv():
    # Test function parse_kv with valid input
    assert parse_kv("") == {}
    assert parse_kv("foo=bar")[u'foo'] == u'bar'
    assert parse_kv("foo=bar")[u'_raw_params'] == u''

    assert parse_kv("foo=bar baz=qux")[u'foo'] == u'bar'
    assert parse_kv("foo=bar baz=qux")[u'baz'] == u'qux'
    assert parse_kv("foo=bar baz=qux")[u'_raw_params'] == u''

    assert parse_kv("foo=bar baz='qux'")[u'foo'] == u'bar'

# Generated at 2022-06-20 23:22:34.865184
# Unit test for function split_args

# Generated at 2022-06-20 23:22:46.580902
# Unit test for function split_args
def test_split_args():
    import unittest

    class TestSplitArgs(unittest.TestCase):
        def _test_args(self, orig_args, expected_output, exception_expected=False):
            with self.subTest(args=orig_args):
                if exception_expected:
                    with self.assertRaises(AnsibleParserError):
                        split_args(orig_args)
                else:
                    self.assertListEqual(split_args(orig_args), expected_output)

        def test_basic_parsing(self):
            self._test_args('a=b c="foo bar"', ['a=b', 'c="foo bar"'])

        def test_empty_args(self):
            self._test_args('', [])


# Generated at 2022-06-20 23:22:48.087708
# Unit test for function join_args
def test_join_args():
    assert join_args(['ls', '\n', '-l']) == 'ls \n -l'



# Generated at 2022-06-20 23:22:51.291134
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c\nd', 'e\nf']) == 'a b c\nd e\nf'



# Generated at 2022-06-20 23:22:59.220421
# Unit test for function split_args

# Generated at 2022-06-20 23:23:08.658944
# Unit test for function split_args

# Generated at 2022-06-20 23:23:17.996083
# Unit test for function parse_kv
def test_parse_kv():
    from inspect import getargspec
    func_args = getargspec(parse_kv).args
    assert func_args == ['args', 'check_raw'], 'parse_kv expects 2 arguments: {0}'.format(', '.join(func_args))

    assert parse_kv(None) == {}
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo="bar"') == {u'foo': u'"bar"'}
    assert parse_kv(u'foo="bar" baz=hoge') == {u'foo': u'"bar"', u'baz': u'hoge'}

# Generated at 2022-06-20 23:23:40.997090
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a b', 'c']) == 'a b c'
    assert join_args(['a', 'b c']) == 'a b c'
    assert join_args(['a', 'b\nc']) == 'a\nb\nc'     # ansible-playbook compatible
    assert join_args(['a', 'b\nc', 'd']) == 'a\nb\nc d'
    assert join_args(['a\nb', 'c']) == 'a\nb c'
    assert join_args(['a\nb', 'c\nd']) == 'a\nb\nc\nd'

# Generated at 2022-06-20 23:23:48.054163
# Unit test for function split_args

# Generated at 2022-06-20 23:23:58.538615
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar bar=baz') == {u'bar': u'baz', u'foo': u'bar'}
    assert parse_kv('foo="bar baz"') == {u'foo': u'bar baz'}
    assert parse_kv('foo="bar baz') == {u'foo': u'"bar baz'}
    assert parse_kv('foo="bar \\" baz"') == {u'foo': u'bar " baz'}
    assert parse_kv("foo='bar \\'baz'") == {u'foo': u'bar \'baz'}

# Generated at 2022-06-20 23:24:06.965151
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("") == {}
    assert parse_kv("a=") == {u'a': u''}
    assert parse_kv("a=") == {u'a': u''}
    assert parse_kv("a =") == {u'a': u''}
    assert parse_kv("a = '1'") == {u'a': u'1'}
    assert parse_kv("a='1'") == {u'a': u'1'}
    assert parse_kv("a= '1'") == {u'a': u'1'}
    assert parse_kv("a = 1") == {u'a': u'1'}
    assert parse_kv("a=1") == {u'a': u'1'}

# Generated at 2022-06-20 23:24:16.117676
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {'foo': 'bar'}
    assert parse_kv("foo='bar'") == {'foo': 'bar'}
    assert parse_kv("foo=\"bar\"") == {'foo': 'bar'}
    assert parse_kv("foo=bar baz=quux") == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv("foo=bar baz=\"a b c\"") == {'foo': 'bar', 'baz': 'a b c'}
    assert parse_kv("foo=bar baz=\"a=b c\"") == {'foo': 'bar', 'baz': 'a=b c'}

# Generated at 2022-06-20 23:24:18.753463
# Unit test for function join_args
def test_join_args():
    s = ['foo', 'bar', 'baz=test\nanother']
    assert join_args(s) == 'foo bar baz=test\nanother'



# Generated at 2022-06-20 23:24:25.309338
# Unit test for function split_args
def test_split_args():

    # test basic string-only split
    test_args = "one two three"
    result = split_args(test_args)
    assert result == ["one", "two", "three"]

    # test that quotes on the outside of a string group tokens together
    test_args = 'one "two three"'
    result = split_args(test_args)
    assert result == ["one", '"two three"']

    # test that quotes on the inside of a string do not group tokens
    test_args = "one 'two three'"
    result = split_args(test_args)
    assert result == ["one", "'two", "three'"]

    # test that quotes on the inside of a string do not group tokens,
    # even if there is no space between tokens
    test_args = "one'two'three"

# Generated at 2022-06-20 23:24:26.453076
# Unit test for function split_args
def test_split_args():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-20 23:24:33.567090
# Unit test for function join_args
def test_join_args():
    assert join_args(['one', 'two', 'three']) == 'one two three'
    assert join_args(['one', 'two', 'three', 'four']) == 'one two three four'
    assert join_args(['\none', 'two', 'three']) == '\none two three'
    assert join_args(['\none', 'two', 'three', 'four']) == '\none two three four'
    assert join_args(['one', '\ntwo', 'three']) == 'one \ntwo three'
    assert join_args(['one', '\ntwo', 'three', 'four']) == 'one \ntwo three four'
    assert join_args(['one', 'two\n', 'three']) == 'one two\n three'

# Generated at 2022-06-20 23:24:42.244380
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a b', 'c']) == '"a b" c'
    assert join_args(['a', 'b c']) == 'a "b c"'
    assert join_args(['a b\n', 'c']) == '"a b"\nc'
    assert join_args(['a', 'b\n', 'c\n', 'd']) == 'a\nb\nc\nd'
    assert join_args(['a', 'b\n', 'c\\\n', 'd']) == 'a\nb\nc\\\nd'

# Generated at 2022-06-20 23:25:11.382758
# Unit test for function join_args
def test_join_args():
    s = ['asd', 'asd\nasd']
    assert join_args(s) == 'asd asd\nasd'
    s = ['a', 'b\na']
    assert join_args(s) == 'a b\na'
    s = ['a', 'b', 'a']
    assert join_args(s) == 'a b a'



# Generated at 2022-06-20 23:25:23.463235
# Unit test for function split_args
def test_split_args():
    '''
    Unit tests for function split_args
    '''

# Generated at 2022-06-20 23:25:26.612786
# Unit test for function parse_kv
def test_parse_kv():
    option = parse_kv(u'param1=value1 param2=value2')

    assert option[u'param1'] == u"value1"
    assert option[u'param2'] == u"value2"


# Generated at 2022-06-20 23:25:34.225689
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv('') == {}
    assert parse_kv(u'') == {}
    assert parse_kv(u'  ') == {}
    assert parse_kv(b'') == {}
    assert parse_kv(b'  ') == {}

    assert parse_kv('this=that') == {u'this': u'that'}
    assert parse_kv(u'this=that') == {u'this': u'that'}
    assert parse_kv(b'this=that') == {u'this': u'that'}

    assert parse_kv('this=this\=that') == {u'this': u'this=that'}

# Generated at 2022-06-20 23:25:40.725417
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', '\nb', 'c']) == 'a\nb c'
    assert join_args(['\na', 'b', 'c']) == '\na b c'
    assert join_args(['a', '\n', '\nb', 'c']) == 'a\n\nb c'



# Generated at 2022-06-20 23:25:46.269389
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', 'b c']) == 'a b c'
    assert join_args(['a\nb', 'c']) == 'a\nb c'
    assert join_args(['a\n', '\nb']) == 'a\n \nb'



# Generated at 2022-06-20 23:25:55.104636
# Unit test for function join_args
def test_join_args():
    assert join_args(['one', 'two']) == 'one two'
    assert join_args(['one two']) == 'one two'
    assert join_args(['one\ntwo']) == 'one\ntwo'
    assert join_args(['one', 'two\n', 'three']) == 'one two\n three'
    assert join_args(['one\ntwo\n', 'three']) == 'one\ntwo\n three'
    assert join_args(['one\ntwo\n', 'three\n']) == 'one\ntwo\n three\n'


# FIXME: make a unit test for this, as well as for the entire file

# Generated at 2022-06-20 23:26:05.269252
# Unit test for function split_args

# Generated at 2022-06-20 23:26:16.049978
# Unit test for function parse_kv

# Generated at 2022-06-20 23:26:24.509411
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b") == {u'a': u'b'}
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=\"b c\" d=\"e f\"") == {u'a': u'b c', u'd': u'e f'}
    assert parse_kv("a=\"b c\" d='e f'") == {u'a': u'b c', u'd': u'e f'}
    assert parse_kv("a=\"b c\" d='e f' e=g") == {u'a': u'b c', u'd': u'e f', u'e': u'g'}

# Generated at 2022-06-20 23:26:53.465508
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(args=None) == {}
    assert parse_kv(args='') == {}
    assert parse_kv(args='a=b') == {u'a': u'b'}
    assert parse_kv(args='a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv(args='a=b=c d=e') == {u'a': u'b=c', u'd': u'e'}
    # assert parse_kv(args='a="b c"') == {u'a': u'"b c"'}
    # assert parse_kv(args='a=b c= "b c"') == {u'a': u'b', u'c': u'"b c"'}
    #

# Generated at 2022-06-20 23:27:02.811162
# Unit test for function split_args
def test_split_args():
    assert split_args(u'''{{ foo }}''') == [u'{{ foo }}']
    assert split_args(u'''{{ foo }} > /tmp/something''') == [u'{{ foo }}', u'>', u'/tmp/something']
    assert split_args(u'''{{ foo }} {{ bar }}''') == [u'{{ foo }}', u'{{ bar }}']
    assert split_args(u'''{{ foo }} {{ bar }}''') == [u'{{ foo }}', u'{{ bar }}']
    assert split_args(u'''{{ foo }}
{{ bar }}''') == [u'{{ foo }}\n{{ bar }}']
    assert split_args(u'''{{ foo }}\\
{{ bar }}''') == [u'{{ foo }}\n{{ bar }}']

# Generated at 2022-06-20 23:27:10.500922
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ""

    assert join_args(["a"]) == "a"
    assert join_args(["a ", "b"]) == "a b"
    assert join_args(["a\n", "b"]) == "a\nb"

    assert join_args(["a", "b"]) == "a b"
    assert join_args(["a b"]) == "a b"
    assert join_args(["a\nb"]) == "a\nb"

    assert join_args(["a", "\n", "b"]) == "a\nb"
    assert join_args(["a", "", "\n", "b"]) == "a\nb"
    assert join_args(["a", " ", "\n", "b"]) == "a\nb"
    assert join_args

# Generated at 2022-06-20 23:27:20.989371
# Unit test for function split_args

# Generated at 2022-06-20 23:27:28.662551
# Unit test for function split_args

# Generated at 2022-06-20 23:27:40.633216
# Unit test for function parse_kv
def test_parse_kv():
    import sys
    if sys.version_info[0] == 2:
        assert parse_kv('foo=bar baz=bam foo2=bar2') == {u'foo': 'bar', u'baz': 'bam', u'foo2': 'bar2'}
        assert parse_kv('foo=bar baz=bam foo2="bar2=bar2 bar2" spaces="should work"') == {u'foo': 'bar', u'baz': 'bam', u'foo2': 'bar2=bar2 bar2', u'spaces': u'should work'}

# Generated at 2022-06-20 23:27:44.235030
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo\n', 'bar\n']) == 'foo\nbar\n'
    assert join_args(['foo', 'bar', '\n']) == 'foo bar \n'



# Generated at 2022-06-20 23:27:51.263904
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b") == {u'a': u'b'}
    assert parse_kv("a='b c'") == {u'a': u'b c'}
    assert parse_kv("a=\"b c\"") == {u'a': u'b c'}
    assert parse_kv("a=b c") == {u'a': u'b', u'_raw_params': u'c'}
    assert parse_kv("a=b\" c\"") == {u'a': u'b" c"'}
    assert parse_kv("a=\"b' c\"") == {u'a': u"b' c"}

# Generated at 2022-06-20 23:28:01.977158
# Unit test for function split_args

# Generated at 2022-06-20 23:28:10.828430
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c=\'foo bar\'') == [u'a=b', u"c='foo bar'"]
    assert split_args(u'a=b c="foo bar') == [u'a=b', u'c="foo bar']
    assert split_args(u'a=b c="foo') == [u'a=b', u'c="foo']
    assert split_args(u'a=b c=\\"foo\\"') == [u'a=b', u'c=\\"foo\\"']

# Generated at 2022-06-20 23:28:47.485450
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo\nbar', 'baz']) == 'foo\nbar baz'
    assert join_args(['foo\nbar\nbaz']) == 'foo\nbar\nbaz'



# Generated at 2022-06-20 23:28:55.043269
# Unit test for function join_args
def test_join_args():
    assert 'a b' == join_args(['a', 'b'])
    assert 'a b c' == join_args(['a', 'b', 'c'])
    assert 'a\nb' == join_args(['a\n', 'b'])
    assert 'a\nb\nc' == join_args(['a\n', 'b\n', 'c'])
    assert 'a\nb c' == join_args(['a\n', 'b', 'c'])
    assert 'a b\nc' == join_args(['a', 'b\n', 'c'])


# Generated at 2022-06-20 23:29:04.119403
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\nb', 'c']) == 'a\nb c'
    assert join_args(['a', 'b\nc']) == 'a  b\nc'
    assert join_args(['a\n\nb', 'c']) == 'a\n\nb c'
    assert join_args(['a', '\nb\nc']) == 'a  \nb\nc'
    assert join_args(['a', 'b\n\nc']) == 'a  b\n\nc'
    assert join_args(['a\n\n', 'b\n\nc']) == 'a\n\n b\n\nc'

# Generated at 2022-06-20 23:29:15.761873
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('k1=v1 k2=v2') == {u'k1': u'v1', u'k2': u'v2'}
    assert parse_kv('k1=v1 k2=') == {u'k1': u'v1', u'k2': u''}
    assert parse_kv('k1="v1"') == {u'k1': u'v1'}
    assert parse_kv('k1=v1,k2=v2') == {u'k1': u'v1', u'k2': u'v2'}
    assert parse_kv(' k1=v1,k2=v2') == {u'k1': u'v1', u'k2': u'v2'}
    assert parse_kv

# Generated at 2022-06-20 23:29:29.478920
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c='d e' d='f g h'") == {u'a': u'1', u'b': u'2', u'c': u'd e', u'd': u'f g h', u'_raw_params': u"a=1 b=2 c='d e' d='f g h'"}
    assert parse_kv("a=1 b=2 c='d e' d='f g h'", check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'd e', u'd': u'f g h'}
    assert parse_kv("a='b\"c'") == {u'a': u'b"c', u'_raw_params': u"a='b\"c'"}
