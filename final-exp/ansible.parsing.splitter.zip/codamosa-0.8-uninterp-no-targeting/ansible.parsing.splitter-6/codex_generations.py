

# Generated at 2022-06-20 23:20:09.197411
# Unit test for function join_args
def test_join_args():

    test = 'foo'
    expected = 'foo'
    result = join_args(test.split())
    assert expected == result

    test = 'foo bar'
    expected = 'foo bar'
    result = join_args(test.split())
    assert expected == result

    test = 'foo "bar"'
    expected = 'foo "bar"'
    result = join_args(test.split())
    assert expected == result

    test = 'foo bar "baz bang"'
    expected = 'foo bar "baz bang"'
    result = join_args(test.split())
    assert expected == result

    test = 'foo bar\n"baz bang"'
    expected = 'foo bar\n"baz bang"'
    result = join_args(test.split())
    assert expected == result


# Generated at 2022-06-20 23:20:19.680498
# Unit test for function parse_kv
def test_parse_kv():
    ret = parse_kv('foo=bar key="with spaces" num=5')
    assert ret == {
        'num': '5',
        'key': 'with spaces',
        'foo': 'bar',

    }

    ret = parse_kv('user=bob param1=foo param2="with spaces"')
    assert ret == {
        'param2': 'with spaces',
        'param1': 'foo',
        'user': 'bob',

    }
    # test raw params
    ret = parse_kv('user=bob param1=foo param2="with spaces" "whats this?" extra=foo', check_raw=True)

# Generated at 2022-06-20 23:20:26.768122
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common.text_utils import split_args

    def check(inp, outp):
        result = split_args(inp)
        if outp != result:
            raise Exception("Expected: {0}, got {1}".format(outp, result))

    check('foo=bar', ['foo=bar'])
    check('foo=bar baz="fizz buzz"', ['foo=bar', 'baz="fizz buzz"'])
    check('foo=bar baz="fizz buzz" qux', ['foo=bar', 'baz="fizz buzz"', 'qux'])

# Generated at 2022-06-20 23:20:37.481242
# Unit test for function parse_kv
def test_parse_kv():

    # Test split_args
    assert split_args(u'foo bar baz') == [u'foo', u'bar', u'baz']
    assert split_args(u'foo "bar" baz') == [u'foo', u'"bar"', u'baz']
    assert split_args(u'foo "bar bar baz" baz') == [u'foo', u'"bar bar baz"', u'baz']
    assert split_args(u'foo "bar bar \'baz\'" baz') == [u'foo', u'"bar bar \'baz\'"', u'baz']
    assert split_args(u'foo "bar bar \"baz\"" baz') == [u'foo', u'"bar bar \"baz\""', u'baz']

# Generated at 2022-06-20 23:20:46.335200
# Unit test for function split_args

# Generated at 2022-06-20 23:20:48.546257
# Unit test for function split_args
def test_split_args():
    # Iterate over testcases which is a list of tuples where the first element
    # is the input and second is expected output.
    for input_data, result in TEST_CASES:
        actual = split_args(input_data)
        assert actual == result


# Generated at 2022-06-20 23:20:59.810528
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('creates=/tmp/foo executable=/usr/bin/python') == dict(
        creates='/tmp/foo',
        executable='/usr/bin/python',
    )

    assert parse_kv('creates=/tmp/foo creates=/tmp/bar') == dict(
        creates='/tmp/bar',
    )

    assert parse_kv('creates=/tmp/foo creates=/tmp/bar', check_raw=True) == dict(
        creates='/tmp/bar',
        _raw_params='creates=/tmp/foo',
    )


# Generated at 2022-06-20 23:21:07.635093
# Unit test for function parse_kv
def test_parse_kv():
    args1 = u'a=1 b=2 c=3'
    args2 = u'a=1 b=2 c=3 d=4'
    args3 = u'a=1 b=2 c=3 d=4 e="hello world"'
    args4 = u'a=1 b=2 c="hello=world" d=4 e="hello world"'
    args5 = u'a=1 b=2 c="hello\\=world" d=4 e="hello world"'
    args6 = u'a=1 b=2 c="hello\\world" d=4 e="hello world"'
    args7 = u'a=1 b=2 c="hello\\\\world" d=4 e="hello world"'
    args8 = u'a=1 b=2 c=hello\\=world d=4 e=hello world'

    res

# Generated at 2022-06-20 23:21:16.318780
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing parse_kv function")
    print(parse_kv('creates=/tmp/foo removes=/tmp/bar'))
    print(parse_kv('creates=/tmp/foo executable=/bin/bash'))
    print(parse_kv('/usr/bin/python -c "from time import time; print(time())"'))
    print(parse_kv('date +"%Y-%m-%d"'))
    print(parse_kv('date +"%Y-%m-%d" creates=/tmp/foo'))
    print(parse_kv('date +"%Y-%m-%d" creates=/tmp/foo removes=/tmp/bar'))


# Generated at 2022-06-20 23:21:18.457003
# Unit test for function split_args
def test_split_args():
    args = 'foo  bar  baz'
    print(split_args(args))


# Generated at 2022-06-20 23:21:45.406461
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('key1="quoted" key2=another="value1 value2"') == {'key2': 'another="value1 value2"', 'key1': 'quoted'}
    assert parse_kv('key1=value1 anotherexample="value1 value2"') == {'anotherexample': 'value1 value2', 'key1': 'value1'}
    assert parse_kv('key1=value1 anotherexample="value1 value2"') == {'anotherexample': 'value1 value2', 'key1': 'value1'}
    assert parse_kv('key1=value1 anotherexample=value1 value2') == {'_raw_params': 'anotherexample=value1 value2', 'key1': 'value1'}

# Generated at 2022-06-20 23:21:47.371146
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv('d= a=1 b=2 c=3') == {u'a': u'1', u'b': u'2', u'c': u'3', u'd': u''}


# Generated at 2022-06-20 23:21:53.373990
# Unit test for function parse_kv
def test_parse_kv():
    args = 'key1=value1   key2=value2            key3=value3=value3a key4=~/key4'
    results = parse_kv(args)
    expected = {u'key1': u'value1', u'key2': u'value2', u'key3': u'value3=value3a', u'key4': u'~/key4'}
    assert results == expected

    args = "a=1 b=2 b='3 3' d='value=4'"
    results = parse_kv(args)
    expected = {'a': '1', 'b': '2', 'd': 'value=4'}
    assert results == expected



# Generated at 2022-06-20 23:22:05.353146
# Unit test for function split_args

# Generated at 2022-06-20 23:22:09.155020
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo\nA\n B']) == 'echo\nA\n B'
    assert join_args(['echo', 'A', 'B']) == 'echo A B'
    assert join_args(['echo\nA B']) == 'echo\nA B'



# Generated at 2022-06-20 23:22:17.147541
# Unit test for function split_args
def test_split_args():
    assert split_args(u'value1 value2 value3') == [u'value1', u'value2', u'value3']
    assert split_args(u'value1=value2 value3') == [u'value1=value2', u'value3']
    assert split_args(u'value1="value2 value3"') == [u'value1="value2 value3"']
    assert split_args(u'value1="value2=value3 value4"') == [u'value1="value2=value3 value4"']
    assert split_args(u"value1='value2=value3 value4'") == [u"value1='value2=value3 value4'"]

# Generated at 2022-06-20 23:22:26.816699
# Unit test for function split_args

# Generated at 2022-06-20 23:22:36.466580
# Unit test for function parse_kv

# Generated at 2022-06-20 23:22:47.736625
# Unit test for function split_args
def test_split_args():
    """
    Tests for the code that parses args.
    """
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-20 23:22:57.276257
# Unit test for function split_args
def test_split_args():

    def _verify_split_args(input, expected):
        actual = split_args(input)
        if actual != expected:
            msg = (u'Expected %s, but got %s' % (expected, actual))
            raise AssertionError(msg)

    _verify_split_args('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _verify_split_args("a=b c='foo bar'", ['a=b', 'c=\'foo bar\''])
    _verify_split_args("a=b c=\\'foo bar\\'", ['a=b', "c=\\'foo bar\\'"])
    _verify_split_args("a=b c=foo\\ bar", ['a=b', "c=foo\\ bar"])


# Generated at 2022-06-20 23:23:15.701761
# Unit test for function split_args
def test_split_args():
    def do_test(args, expect):
        result = split_args(args)
        assert result == expect, "expected {0} but got {1}".format(expect, result)

    do_test("a=b", ['a=b'])
    do_test("a=b c='d e'", ['a=b', "c='d e'"])
    do_test("a=b c='d e' f={{ g }}", ['a=b', "c='d e'", 'f={{ g }}'])
    do_test("a=b c='d e '\\''f g'", ['a=b', """c='d e '\\''f g'"""])

# Generated at 2022-06-20 23:23:21.253515
# Unit test for function parse_kv

# Generated at 2022-06-20 23:23:31.704174
# Unit test for function parse_kv
def test_parse_kv():
    test1 = 'string1=test1 string2=test2'
    test2 = 'string1="with spaces" string2=\'space in string\''
    test3 = 'string1="space at end " string2=\'space at end \''
    test4 = 'string1="spaces at end  " string2=\'spaces at end  \''
    test5 = 'string1="with \\"quotes\\"" string2=\'with \\\'quotes\\\'\''
    test6 = 'string1=\\"with quotes\\" string2=\'with quotes\''
    test7 = 'string1=\\"with \\\' quotes\\" string2=\'with quotes\''
    test8 = 'string1=with space at end\\'
    test9 = 'string1=with escaped quote \\\\\\"'
    test10

# Generated at 2022-06-20 23:23:41.605795
# Unit test for function split_args
def test_split_args():
    '''
    Unit test for function split_args
    '''

# Generated at 2022-06-20 23:23:46.323091
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a b c']) == 'a b c'
    assert join_args(['a\nb c', 'd\nf']) == 'a\nb c d\nf'
    assert join_args(['a\n', '\nb c', 'd\nf']) == 'a\n\n\nb c d\nf'



# Generated at 2022-06-20 23:23:56.723801
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a="1" b=2 "c=3" d="4 5"') == {u'a': u'1', u'b': u'2', u'c=3': u'd="4 5"'}
    assert parse_kv('a="1" b=2 "c=3" d="4 5" _raw_params=wow') == {u'a': u'1', u'b': u'2', u'c=3': u'd="4 5"', u'_raw_params': u'wow'}

# Generated at 2022-06-20 23:24:05.495995
# Unit test for function join_args
def test_join_args():
    '''
    Test the functionality of join_args().
    '''
    # test case 1
    assert join_args(['a', 'b', 'c']) == 'a b c'
    # test case 2
    assert join_args(['', 'a', 'b', 'c']) == ' a b c'
    # test case 3
    assert join_args(['a', 'b', 'c', '']) == 'a b c '
    # test case 4
    assert join_args(['', '', 'a', 'b', 'c', '']) == '  a b c '
    # test case 5
    assert join_args(['', 'a', '\n', 'b', 'c', '']) == ' a \n b c '



# Generated at 2022-06-20 23:24:10.343966
# Unit test for function split_args
def test_split_args():
    from ansible.tests.unit.utils import TestCase
    from ansible.module_utils.common.validation import check_type_list

    class TestSplitArgs(TestCase):

        def test_split_args(self):
            args = """
                test arg1='{{ foo }} arg2' arg3='{{ bar }}' arg4={{ baz }} arg5={{ zip }}
            """
            self.assertEqual(
                split_args(args),
                [
                    "test", 
                    "arg1='{{ foo }} arg2'", 
                    "arg3='{{ bar }}'", 
                    "arg4={{ baz }}", 
                    "arg5={{ zip }}",
                ]
            )


# Generated at 2022-06-20 23:24:14.664003
# Unit test for function split_args
def test_split_args():
    assert split_args("-i /path/to/foo.pem -C /usr/bin/foo") == ['-i', '/path/to/foo.pem', '-C', '/usr/bin/foo']
    assert split_args('{{ foo }}') == ['{{', 'foo', '}}']
    assert split_args('{% foo %}') == ['{%', 'foo', '%}']
    assert split_args('{# foo #}') == ['{#', 'foo', '#}']
    assert split_args('{{ foo }}{% bar %}') == ['{{', 'foo', '}}{%', 'bar', '%}']
    assert split_args('"foo bar"') == ['"foo bar"']

# Generated at 2022-06-20 23:24:19.512192
# Unit test for function split_args

# Generated at 2022-06-20 23:24:27.483807
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("a=b c=d")
    assert isinstance(options, dict)
    assert len(options.keys()) == 2
    assert options["a"] == "b"
    assert options["c"] == "d"



# Generated at 2022-06-20 23:24:30.417880
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '-n', '"foo"', 'bar\n']) == "echo -n '\"foo\"' bar\n"
    assert join_args(['echo', '"a b"']) == "echo '\"a b\"'"



# Generated at 2022-06-20 23:24:35.411958
# Unit test for function split_args

# Generated at 2022-06-20 23:24:45.217301
# Unit test for function parse_kv
def test_parse_kv():
    # Test single character escapes
    result = parse_kv('"\\f\\o\\o=bar"\\b\\a\\z')
    assert result == { u'foo':u'barbaz' }

    # Test single character escapes
    result = parse_kv('"foo=bar\\"baz"')
    assert result == { u'foo':u'bar"baz' }

    # Test output includes raw params
    result = parse_kv('"foo=bar\\"baz" "baz=qux"', check_raw=True)
    assert result == {u'foo': u'bar"baz', u'_raw_params': u'"baz=qux"', u'baz': u'qux'}

    # Test single character escapes

# Generated at 2022-06-20 23:24:54.566907
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('x=1\ny=2') == {u'y': u'2', u'x': u'1'}
    assert parse_kv('x=1%20y=2') == {u'x': u'1 y=2'}
    assert parse_kv('x=1\ny=2', True) == {u'_raw_params': u'x=1\ny=2', u'x': u'1', u'y': u'2'}
    assert parse_kv('x=1%20y=2 arg=3', True) == {u'arg': u'3', u'_raw_params': u'x=1%20y=2 arg=3', u'x': u'1 y=2'}

# Generated at 2022-06-20 23:24:59.911545
# Unit test for function join_args
def test_join_args():
    assert join_args(['testing', 'this', 'out', '\n']) == 'testing this out \n'
    assert join_args(['testing', 'this', 'out']) == 'testing this out'
    assert join_args(['\ntesting', 'this', 'out']) == '\ntesting this out'



# Generated at 2022-06-20 23:25:09.322039
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test for function parse_kv
    '''

    string = 'a=b'
    assert parse_kv(string) == {'a': 'b'}

    string = 'a=b c=d'
    assert parse_kv(string) == {'a': 'b', 'c': 'd'}

    string = 'a=b c=d e=f'
    assert parse_kv(string) == {'a': 'b', 'c': 'd', 'e': 'f'}

    string = 'a=b "c=d e=f"'
    assert parse_kv(string) == {'a': 'b', 'c=d e=f': ''}

    string = 'a=b "c=d e=f"'

# Generated at 2022-06-20 23:25:19.982752
# Unit test for function parse_kv

# Generated at 2022-06-20 23:25:23.751970
# Unit test for function parse_kv
def test_parse_kv():
  expected = {u'foo': u'bar'}
  # Single string
  output = parse_kv("foo=bar")
  assert output == expected
  # List
  output = parse_kv(["foo=bar"])
  assert output == expected


# Generated at 2022-06-20 23:25:32.423663
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar spam=eggs') == {'foo': 'bar', 'spam': 'eggs'}
    assert parse_kv('foo=bar spam=eggs=green') == {'foo': 'bar', 'spam': 'eggs=green'}
    assert parse_kv('foo=bar \\\tspam=eggs') == {'foo': 'bar', 'spam': 'eggs'}
    assert parse_kv('foo=bar spam=eggs \\\nmore=spam') == {'foo': 'bar', 'spam': 'eggs', 'more': 'spam'}
    assert parse_kv('foo bar') == {'foo': 'bar'}
    assert parse_

# Generated at 2022-06-20 23:25:47.710584
# Unit test for function split_args

# Generated at 2022-06-20 23:25:56.046239
# Unit test for function parse_kv

# Generated at 2022-06-20 23:25:59.492558
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', '\nbar']) == 'foo\nbar'
    assert join_args(['foo', '    ', '\n', 'bar']) == 'foo\nbar'



# Generated at 2022-06-20 23:26:10.622467
# Unit test for function parse_kv

# Generated at 2022-06-20 23:26:18.392291
# Unit test for function join_args
def test_join_args():
    assert join_args(['test', 'string']) == 'test string'
    assert join_args(['test', 'string\n']) == 'test string\n'
    assert join_args(['test\n', 'string']) == 'test\nstring'
    assert join_args(['test', ' string']) == 'test  string'
    assert join_args(['test\n', 'string\n']) == 'test\nstring\n'
    assert join_args(['test', '\nstring']) == 'test \nstring'
    assert join_args(['test\n', '\nstring']) == 'test\n\nstring'
    assert join_args(['test string']) == 'test string'
    assert join_args(['test\nstring']) == 'test\nstring'

# Generated at 2022-06-20 23:26:28.108325
# Unit test for function join_args
def test_join_args():
    assert join_args(["a", "b", "c"])=="a b c"
    assert join_args(["a b c"])=="a b c"
    assert join_args(["a \\\n", "b \\\n", "c"])=="a \\\n b \\\n c"
    assert join_args(["a \\\n", "b \\\n c"])=="a \\\n b \\\n c"
    assert join_args(["a \\\nb c"])=="a \\\nb c"
    assert join_args(["a \\\n b c"])=="a \\\n b c"
    assert join_args(["a \\\n", "b", "c"])=="a \\\n b c"

# Generated at 2022-06-20 23:26:38.707604
# Unit test for function join_args
def test_join_args():
    list1 = ['a b c', 'd', '', 'e f g']
    assert join_args(list1) == 'a b c d \n e f g'
    list2 = []
    assert join_args(list2) == ''
    list3 = ['abcd efg']
    assert join_args(list3) == 'abcd efg'
    list4 = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
    assert join_args(list4) == 'a b c d e f g'
    list5 = ['a', 'b', 'c', 'd', 'e', 'f', 'g', '\n']
    assert join_args(list5) == 'a b c d e f g \n'

# Generated at 2022-06-20 23:26:48.030273
# Unit test for function join_args
def test_join_args():
    assert join_args(split_args("/path/to/foo \"bar baz\" cow")) == "/path/to/foo \"bar baz\" cow"
    assert join_args(split_args("\"bar baz\" cow")) == "\"bar baz\" cow"
    assert join_args(split_args("cow")) == "cow"
    assert join_args(split_args("")) == ""
    assert join_args(split_args(" ")) == " "
    assert join_args(split_args("\n")) == "\n"
    assert join_args(split_args(" /path/to/foo \"bar baz\" cow")) == " /path/to/foo \"bar baz\" cow"
    assert join_args(split_args("\\foo\\bar \"baz\"")) == "\\foo\\bar \"baz\""

# Generated at 2022-06-20 23:26:57.615128
# Unit test for function parse_kv
def test_parse_kv():
    # FIXME: Write a unit test which will check that the parser is able to handle
    #        commented lines correctly
    assert parse_kv('var1=value1 var2=value2') == {'var1': 'value1', 'var2': 'value2'}
    assert parse_kv('var1=value1 "var2=value2 with whitespace"') == {'var1': 'value1', 'var2': 'value2 with whitespace'}
    assert parse_kv('"var1=value1" "var2=value2 with whitespace"') == {'var1': 'value1', 'var2': 'value2 with whitespace'}

# Generated at 2022-06-20 23:27:06.435078
# Unit test for function parse_kv
def test_parse_kv():
    # Basic conversion
    result = parse_kv('foo=bar x=1')
    assert result == {u'foo': u'bar', u'x': u'1'}

    # Double quotes are stripped from values
    result = parse_kv('foo="bar" x="1"')
    assert result == {u'foo': u'bar', u'x': u'1'}

    # Escaped quotes are preserved within double quotes
    result = parse_kv(u'foo="bar\\"baz" x="1"')
    assert result == {u'foo': u'bar"baz', u'x': u'1'}

    # Quotes in unquoted values are not parsed
    result = parse_kv(u'foo=bar"baz x="1"')

# Generated at 2022-06-20 23:27:25.290738
# Unit test for function join_args
def test_join_args():
    test_data = [
        (['echo', '1'], 'echo 1'),
        (['echo', '1\n', '2'], 'echo 1\n2'),
        (['echo', 'a', 'b'], 'echo a b'),
        (['echo', 'a', 'b\n', 'echo', 'c', 'd'], 'echo a b\necho c d'),
        (['echo', 'a', 'b\n\n', 'echo', 'c', 'd'], 'echo a b\n\necho c d'),
    ]
    for i in test_data:
        if i[1] != join_args(i[0]):
            print('join_args Failed for test data:')
            print(i)
            print('Result:')

# Generated at 2022-06-20 23:27:30.715482
# Unit test for function join_args
def test_join_args():
    '''
    Unit test for function join_args
    '''
    test_cmd_1 = "    test_cmd \\\n   --arg1=1\n  --arg2=2  "
    test_cmd_2 = "test_cmd -a 'command: with: in: it'"
    test_cmd_3 = '''test_cmd \
    -a 'command: with: in: it' \
    -b 'command:
      - with:
      - in:
      - it'
    '''
    test_cmd_4 = '''test_cmd \
    -a 'command: with: in: it' \\\n
    -b 'command:
      - with:
      - in:
      - it'
    '''

# Generated at 2022-06-20 23:27:41.913266
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=simple b="with space" c="this=that" d=\'a="b"\'') == dict(a=u'simple', b=u'with space', c=u'this=that', d=u'a="b"')
    assert parse_kv(u'a=simple b="with space" c="this=that" d=\'a="b"\' e=') == dict(a=u'simple', b=u'with space', c=u'this=that', d=u'a="b"', e=u'')

# Generated at 2022-06-20 23:27:49.677831
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c='foo bar' d={{foo}}") == [u'a=b', u"c='foo bar'", u'd={{foo}}']
    assert split_args(u'a=b c="foo bar" d={{foo}}') == [u'a=b', u'c="foo bar"', u'd={{foo}}']
    assert split_args(u"a=b c='foo bar' d={{foo}} e={{foo}} f='foo bar'") == [u'a=b', u"c='foo bar'", u'd={{foo}}', u'e={{foo}}', u"f='foo bar'"]

# Generated at 2022-06-20 23:28:00.242360
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b") == {"a": "b"}
    assert parse_kv("a=b c=d") == {"a": "b", "c": "d"}
    assert parse_kv("a=b c") == {"a": "b", "_raw_params": "c"}
    assert parse_kv("a=b c= d=e") == {"a": "b", "c": "", "d": "e"}
    assert parse_kv("a='b c' d=e") == {"a": "b c", "d": "e"}
    assert parse_kv("a=b \\= c=d") == {"a": "b \\", "c": "d"}

# Generated at 2022-06-20 23:28:09.460468
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv({}) == {}
    assert parse_kv('') == {}
    assert parse_kv(None) == {}
    assert parse_kv('flag') == {'_raw_params': 'flag'}
    assert parse_kv('flag1 flag2') == {'_raw_params': 'flag1 flag2'}
    assert parse_kv('key1=value1') == {'key1': 'value1'}
    assert parse_kv('key1=value1 key2=value2') == {'key1': 'value1', 'key2': 'value2'}
    assert parse_kv('key1=value1 key2=value2 flag1') == {'key1': 'value1', 'key2': 'value2', '_raw_params': 'flag1'}
   

# Generated at 2022-06-20 23:28:11.251292
# Unit test for function join_args
def test_join_args():
    assert "foo bar baz" == join_args(["foo", "bar", "baz"])
    assert "foo  \n foo" == join_args(["foo", " ", "\n", " ", "foo"])
    assert "a\\ b" == join_args(["a\\", "b"])



# Generated at 2022-06-20 23:28:17.372789
# Unit test for function join_args
def test_join_args():
    '''
    Test that join_args(split_args(x)) == x
    '''
    # almost there, except I don't know how to correctly escape characters
    # in python or how to properly parse the command line properly
    terminators = ['\n', ' ']
    import tests.units.modules.utils.params as p
    test_cases = [
        ('foo bar baz', 'foo bar baz'),
        ('foo\nbar\nbaz', 'foo\nbar\nbaz'),
        ('foo\\ ', 'foo\\ '),
        ('"foo \\\\" bar" baz', '"foo \\\\" bar" baz'),
        ('"foo \\\\" bar"baz', '"foo \\\\" bar"baz'),
    ]
    for args, expected in test_cases:
        actual = join_

# Generated at 2022-06-20 23:28:27.190218
# Unit test for function split_args
def test_split_args():
    import pytest

# Generated at 2022-06-20 23:28:36.170732
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c=d e f') == {u'a': u'b', u'c': u'd', u'_raw_params': u'e f'}
    assert parse_kv(u'b="c d"') == {u'b': u'c d'}
    assert parse_kv(u'c="d e" f') == {u'c': u'd e', u'_raw_params': u'f'}
    assert parse_kv(u'a=b c="d e" f') == {u'a': u'b', u'c': u'd e', u'_raw_params': u'f'}

# Generated at 2022-06-20 23:28:50.119192
# Unit test for function split_args
def test_split_args():
    failed = False

# Generated at 2022-06-20 23:28:58.898814
# Unit test for function join_args
def test_join_args():
    assert join_args(['a']) == 'a'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', '\nb']) == 'a\nb'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', '\nb', 'c']) == 'a\nb c'
    assert join_args(['a', 'b', 'c', 'd']) == 'a b c d'
    assert join_args(['a', '\nb', 'c', 'd']) == 'a\nb c d'



# Generated at 2022-06-20 23:29:02.238613
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("creates=/tmp/foo executable=/bin/bash") == \
        {"creates":"/tmp/foo", "executable":"/bin/bash"}

# See comments in split_args() above.
_SPLIT_QUOTED_RE = re.compile(r'''
    ("(?:\\.|[^"\\])*"        # Match double quoted string
    | '(?:\\.|[^'\\])*'       # Match single quoted string
    | [^'" ]+                # Match anything else without quotes
    )''', re.VERBOSE)


# Generated at 2022-06-20 23:29:13.670415
# Unit test for function split_args
def test_split_args():
    # Simple tests
    assert split_args('simple') == ['simple']
    assert split_args('one two three') == ['one', 'two', 'three']
    assert split_args('one two three\nfour five six') == ['one', 'two', 'three\nfour', 'five', 'six']

    # Test splitted arg lists
    assert split_args('"a b c" "d e f"') == ['"a b c"', '"d e f"']
    assert split_args("'a b c' 'd e f'") == ["'a b c'", "'d e f'"]
    assert split_args('a b "c d e" f g') == ['a', 'b', '"c d e"', 'f', 'g']

# Generated at 2022-06-20 23:29:21.276052
# Unit test for function join_args
def test_join_args():
    assert join_args([""]) == ''
    assert join_args(["-m", "shell", "-a", "echo $PATH; echo 'a b c'"]) == "-m shell -a echo $PATH; echo 'a b c'"
    assert join_args(["-m", "shell", "-a", "echo $PATH;\n   echo 'a b c'"]) == "-m shell -a echo $PATH;\n   echo 'a b c'"
    assert join_args(["-m", "shell", "-a", "echo $PATH;\n   echo 'a b c'", "-x"]) == "-m shell -a echo $PATH;\n   echo 'a b c' -x"

# Generated at 2022-06-20 23:29:33.093059
# Unit test for function join_args
def test_join_args():
    assert join_args(['first_param', 'second_param']) == 'first_param second_param'
    assert join_args(['first_param', 'second\nparam']) == 'first_param\nsecond\nparam'
    assert join_args(['first_param', 'second\tparam']) == 'first_param\tsecond\tparam'
    assert join_args(['first_param', 'second    param']) == 'first_param    second    param'
    assert join_args(['first_param    ', 'second_param']) == 'first_param        second_param'
    assert join_args(['first_param\n', 'second_param']) == 'first_param\nsecond_param'