

# Generated at 2022-06-20 23:19:59.798272
# Unit test for function parse_kv
def test_parse_kv():
    # test simple values
    assert parse_kv(u'foo=bar spam=eggs') == dict(foo=u'bar', spam=u'eggs')

    # test with empty values
    assert parse_kv(u'foo= bar=') == dict(foo=u'', bar=u'')
    assert parse_kv(u'foo=bar spam=') == dict(foo=u'bar', spam=u'')
    assert parse_kv(u'foo= bar=eggs') == dict(foo=u'', bar=u'eggs')

    # test with quotes
    #  " - escaped
    assert parse_kv(u'foo="bar" spam="eggs"') == dict(foo=u'bar', spam=u'eggs')

# Generated at 2022-06-20 23:20:11.654038
# Unit test for function join_args
def test_join_args():
    assert join_args(["a", "b", "c"]) == "a b c"
    assert join_args(["a b c"]) == "a b c"
    assert join_args(["a\nb c"]) == "a\nb c"
    assert join_args(["a\n", "b c"]) == "a\nb c"
    assert join_args(["a\n", "b c"]) == "a\nb c"
    assert join_args(["a\n", "\n", "b c"]) == "a\n\nb c"
    assert join_args(["a\n", "\n", "b c"]) == "a\n\nb c"

# Generated at 2022-06-20 23:20:14.290133
# Unit test for function parse_kv
def test_parse_kv():
    tests = [
        ('creates=foo', {"creates": "foo"}),
        ('creates=foo removes=bar', {"creates": "foo", "removes": "bar"}),
        ("creates=foo bar", {'creates': 'foo', '_raw_params': 'bar'}),
        ("creates='foo bar'", {'creates': 'foo bar'}),
    ]
    for args, expected in tests:
        assert parse_kv(args) == expected
        assert parse_kv(args, check_raw=True) == expected


# Generated at 2022-06-20 23:20:23.421274
# Unit test for function parse_kv
def test_parse_kv():
    # Test normal data
    results = parse_kv('foo=bar\nfoo2=bar2')
    assert results == {u'foo': u'bar', u'foo2': u'bar2'}, results

    results = parse_kv('foo=bar\nfoo2=bar2\nfoo2=overwrite=me')
    assert results == {u'foo': u'bar', u'foo2': u'overwrite=me'}, results

    # Test empty data
    results = parse_kv('')
    assert results == {}, results

    # Test None data
    results = parse_kv(None)
    assert results == {}, results

    # Test quoted data
    results = parse_kv('foo=bar\nfoo2="bar2"')

# Generated at 2022-06-20 23:20:27.690579
# Unit test for function parse_kv
def test_parse_kv():
    assert (parse_kv('foo=bar bar=baz baz=foobar') == {'foo': 'bar', 'baz': 'foobar', 'bar': 'baz'})
    assert (parse_kv('foo=bar bar="baz baz baz" baz=foobar') == {'foo': 'bar', 'bar': 'baz baz baz', 'baz': 'foobar'})
    assert (parse_kv('foo=bar bar="baz\' baz baz" baz=foobar') == {'foo': 'bar', 'bar': "baz\' baz baz", 'baz': 'foobar'})

# Generated at 2022-06-20 23:20:36.030388
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv("") == {})
    assert(parse_kv("foo=bar") == {u'foo': u'bar'})
    assert(parse_kv("foo=bar foo=baz") == {u'foo': u'baz'})
    assert(parse_kv("foo=\"bar baz\"") == {u'foo': u'bar baz'})
    assert(parse_kv("foo='bar baz'") == {u'foo': u'bar baz'})
    assert(parse_kv("foo=bar baz") == {u'foo': u'bar', u'baz': None})



# Generated at 2022-06-20 23:20:42.343747
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo', 'bar baz']) == 'foo \'bar baz\''
    assert join_args(['foo', 'bar baz', 'boo']) == 'foo \'bar baz\' boo'
    assert join_args(['foo', '', 'bar baz', 'boo']) == 'foo \'\' \'bar baz\' boo'



# Generated at 2022-06-20 23:20:49.007170
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing parse_kv")
    assert(parse_kv("foo=bar") == {'foo':u'bar'})
    assert(parse_kv("foo=bar", check_raw=True) == {'foo':u'bar'})
    assert(parse_kv("foo=bar cat='meow dog'") == {'foo':u'bar', 'cat':u'meow dog'})
    assert(parse_kv("foo=bar cat='meow dog'", check_raw=True) == {'foo':u'bar', 'cat':u'meow dog'})
    assert(parse_kv("foo=bar cat='meow dog' bar=baz") == {'foo':u'bar', 'bar':u'baz', 'cat':u'meow dog'})

# Generated at 2022-06-20 23:21:00.292516
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['hi']) == 'hi'
    assert join_args(['hello']) == 'hello'
    assert join_args(['hello', 'world']) == 'hello world'
    assert join_args(['hello\nworld']) == 'hello\nworld'
    assert join_args(['hello', 'world']) == 'hello world'
    assert join_args(['hello world\n']) == 'hello world\n'
    assert join_args(['hello world\n\n']) == 'hello world\n\n'
    assert join_args(['hello', 'world\n']) == 'hello world\n'
    assert join_args(['hello\n', 'world\n']) == 'hello\nworld\n'
    assert join_

# Generated at 2022-06-20 23:21:07.948005
# Unit test for function parse_kv

# Generated at 2022-06-20 23:21:29.704937
# Unit test for function split_args

# Generated at 2022-06-20 23:21:40.546002
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', 'b\n', 'c']) == 'a\nb\n c'
    assert join_args(['a', 'b\n', 'c\n', 'd']) == 'a\nb\nc\n d'
    assert join_args(['a\n', 'b\n', 'c\n', 'd']) == 'a\nb\nc\nd'
    assert join_args(['a', 'b', '\n', 'c']) == 'a b \nc'
    assert join_args(['a', 'b', ' ', 'c']) == 'a b  c'

# Generated at 2022-06-20 23:21:49.287582
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo \"bar\"'") == ['a=b', 'c=\'foo "bar"\'']
    assert split_args("a=b c=\"foo 'bar'\"") == ['a=b', 'c="foo \'bar\'"']
    assert split_args("a=b c=foo\\ bar") == ['a=b', 'c=foo bar']
    assert split_args("a=b c='foo \\\"bar\\\"'") == ['a=b', 'c=\'foo \\"bar"\'']
    assert split_args("a=b c=\"foo \\\"bar\\\"\"") == ['a=b', 'c="foo \\"bar\\""']

# Generated at 2022-06-20 23:21:58.124405
# Unit test for function parse_kv
def test_parse_kv():
    module = AnsibleModule(
        argument_spec = dict(
            foo=dict(default=True, type='bool'),
            bar=dict(required=True, type='bool'),
        ),
    )

    assert parse_kv('foo=True bar=True') == dict(foo=True, bar=True)
    assert parse_kv(u'''foo=True bar=true 'foo="bar baz" boo=\'bar baz\''i x=y  z=a\=b''') == dict(foo=u'True', bar=u'true', foo="bar baz", boo="bar baz", i=u'x', x=u'y', z=u'a=b', _raw_params=u'''x=y  z=a\=b''')

# Generated at 2022-06-20 23:22:05.315792
# Unit test for function join_args
def test_join_args():
    s = ['this', 'is', 'a', 'string', '\n', '\n', 'another\tline', '\n', '\n',
         'line\t3', '\n', '\n', '\tline4']
    assert join_args(s) == 'this is a string\n\nanother\tline\n\nline\t3\n\n\tline4'



# Generated at 2022-06-20 23:22:13.456657
# Unit test for function parse_kv
def test_parse_kv():
    test_data = ['foo=bar', 'foo', '=bar', 'foo=', 'foo=bar=baz', 'hello=world=goodbye']
    tests = []
    for x in test_data:
        tests.append(parse_kv(x))
    assert tests[0] == {u'foo': u'bar'}
    assert tests[1] == {u'_raw_params': u'foo'}
    assert tests[2] == {u'_raw_params': u'=bar'}
    assert tests[3] == {u'foo': u''}
    assert tests[4] == {u'foo': u'bar=baz'}
    assert tests[5] == {u'hello': u'world=goodbye'}


# Generated at 2022-06-20 23:22:25.658560
# Unit test for function parse_kv
def test_parse_kv():
    cmd = u"foo=bar 'foo bar' biz=123 '{foo}'"
    o = parse_kv(cmd, check_raw=True)
    assert o == {'foo': u'bar', 'biz': u'123', '_raw_params': u"'foo bar' '{foo}'"}
    assert parse_kv(u"foo=bar 'foo bar' biz=123 '{foo}'", check_raw=False) == {'foo': u'bar', 'biz': u'123'}
    assert parse_kv(u'foo=bar') == {'foo': u'bar'}
    assert parse_kv(u'foo="bar"') == {'foo': u'bar'}

# Generated at 2022-06-20 23:22:35.636492
# Unit test for function parse_kv
def test_parse_kv():

    raw_params = {}
    raw_params['creates'] = "/home/michael/foo"
    raw_params['removes'] = "/home/michael/foo"
    raw_params['chdir'] = "/tmp"
    raw_params['executable'] = "/bin/bash"
    raw_params['warn'] = "yes"
    raw_params['stdin'] = "/tmp/input"
    raw_params['stdin_add_newline'] = "yes"
    raw_params['strip_empty_ends'] = "yes"

    raw_params_args = []
    for k, v in raw_params.iteritems():
        raw_params_args.append(k+'='+v)


# Generated at 2022-06-20 23:22:41.661579
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['"a b"', 'c']) == '"a b" c'
    assert join_args([u'a b', 'c']) == u'a b c'
    assert join_args([u'a\nb', 'c']) == u'a\nb c'
    assert join_args(['a', '\nb', 'c']) == 'a \nb c'
    assert join_args(['a', 'b', '\nc']) == 'a b \nc'
    assert join_args([u'\u00ae']) == u'\u00ae'
    assert join_args([u'a\u00ae']) == u'a\u00ae'
    assert join_args

# Generated at 2022-06-20 23:22:51.981593
# Unit test for function parse_kv

# Generated at 2022-06-20 23:23:09.514655
# Unit test for function join_args
def test_join_args():
    '''
    Test function that confirms that join_args can rejoin a string
    split by split_args.
    '''
    string = 'cmd1\n  cmd2 \n\t \ncmd3   \n\n'
    assert join_args(split_args(string)) == string



# Generated at 2022-06-20 23:23:18.533401
# Unit test for function split_args
def test_split_args():
    # Validate whether the testcase fails or passes
    def assertEqual(testcase, msg, e, r):
        if e != r:
            print(msg)
            print("  expected: %s" % (e))
            print("    result: %s" % (r))
        testcase.assertEqual(e, r)
    # Check for regular string
    def test_regular(testcase):
        e = ['foo="bar baz"', 'bla="baz bar"', 'frotz="bla bla"']
        r = split_args(b'foo="bar baz" bla="baz bar" frotz="bla bla"')
        assertEqual(testcase, "failed on regular arg", e, r)
    # Check for escaped string

# Generated at 2022-06-20 23:23:23.354578
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b\nc']) == 'a b\nc'
    assert join_args(['a', 'b', 'c']) == 'a b c'



# Generated at 2022-06-20 23:23:29.169811
# Unit test for function join_args
def test_join_args():
    result = join_args(['a', '\nb'])
    assert(result == 'a\nb')
    result = join_args(['a', ' \nb'])
    assert(result == 'a \\nb')
    result = join_args(['a', '\nb', '\n c'])
    assert(result == 'a\nb\n c')



# Generated at 2022-06-20 23:23:39.299990
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {u'_raw_params': u'a=1 b=2 c=3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {u'_raw_params': u'a=1 b=2 c=3'}

# Test for quoted string in the middle
    assert parse_kv('a=foo b="foo 2" c=3') == {u'a': u'foo', u'b': u'foo 2', u'c': u'3'}

    # as above

# Generated at 2022-06-20 23:23:47.122557
# Unit test for function parse_kv
def test_parse_kv():
    # simple test
    assert parse_kv('key1=val1') == {'key1': 'val1'}

    # test with different whitespace
    assert parse_kv('key1 = val1') == {'key1': 'val1'}
    assert parse_kv('key1= val1') == {'key1': 'val1'}
    assert parse_kv('key1 =val1') == {'key1': 'val1'}
    assert parse_kv('key1=val1 ') == {'key1': 'val1'}
    assert parse_kv(' key1=val1') == {'key1': 'val1'}
    assert parse_kv('key1=val1 ') == {'key1': 'val1'}

    # test with escaped equals

# Generated at 2022-06-20 23:23:57.548305
# Unit test for function split_args

# Generated at 2022-06-20 23:24:06.452847
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo']) == 'echo'
    assert join_args(['echo', 'foo']) == 'echo foo'
    assert join_args(['echo\nfoo']) == 'echo\nfoo'
    assert join_args(['echo', '\n', '-n', 'foo\n']) == 'echo\n-n foo\n'
    assert join_args(['echo', '\n', '"foo"\n']) == 'echo\n"foo"\n'
    assert join_args(['echo', '"foo\nbar"\n']) == 'echo "foo\nbar"\n'
    assert join_args(['echo', '\n', '"foo"', 'bar', 'baz\n']) == 'echo\n"foo" bar baz\n'


# Generated at 2022-06-20 23:24:15.676480
# Unit test for function join_args
def test_join_args():
    s = ('foo', 'bar', 'baz')
    assert join_args(s) == 'foo bar baz'
    s = ('foo\n', 'bar\n', 'baz')
    assert join_args(s) == 'foo\nbar\nbaz'
    s = ('foo', '\nbar\n', 'baz')
    assert join_args(s) == 'foo\nbar\nbaz'
    s = ('foo\n', '\nbar\n', 'baz')
    assert join_args(s) == 'foo\n\nbar\nbaz'
    s = ('foo', '', 'bar', 'baz')
    assert join_args(s) == 'foo\nbar baz'
    s = ('foo', '\n\n', 'bar', 'baz')


# Generated at 2022-06-20 23:24:20.701221
# Unit test for function split_args

# Generated at 2022-06-20 23:24:42.691258
# Unit test for function split_args

# Generated at 2022-06-20 23:24:45.721716
# Unit test for function join_args
def test_join_args():
    results = ('foo', 'foo bar', 'foo bar baz')
    for r in results:
        assert r == join_args(split_args(r))


# Generated at 2022-06-20 23:24:54.659132
# Unit test for function join_args
def test_join_args():
    test1 = ['echo', '"hello', 'world"']
    assert join_args(test1) == 'echo "hello world"'
    # ensure that new lines are retained
    test2 = ['echo', '"hello\n', 'world"']
    assert join_args(test2) == 'echo "hello\nworld"'
    # ensure that spaces are not stripped
    test3 = ['ansible-playbook', '--private-key', '~/.ssh/files/private_key.pem', '-i', 'hosts.ini', 'site.yml']
    assert join_args(test3) == 'ansible-playbook --private-key ~/.ssh/files/private_key.pem -i hosts.ini site.yml'



# Generated at 2022-06-20 23:25:02.000733
# Unit test for function join_args
def test_join_args():
    # Normal case
    s = ['a', 'b c d', 'e\nf', 'g', '"h\ni"', 'j\nk', "'l\nm'"]
    expected = 'a b c d\ne\nf g "h\ni" j\nk \'l\nm\''
    assert join_args(s) == expected

    # Src quote is empty
    s = []
    assert join_args(s) == ''



# Generated at 2022-06-20 23:25:10.108025
# Unit test for function split_args
def test_split_args():
    """
    This is a basic unit test for the function split_args. It tests for the
    base cases of correct functionality. Please increase the coverage
    of the unit test as the functionality of the function is increased.

    :return:
    """
    def test_split(args, expected, msg):
        """
        This function will test the function split_args with the specified
        arguments. The results of the function split_args will be compared to
        the expected results.

        :param args:     The string that is to be passed to split_args.
        :param expected: The list of expected results.
        :param msg:      The message that is to be displayed on a failure.
        :return:
        """
        result = split_args(args)
        assert result == expected, msg

    # Test the function with one of each type of character.
   

# Generated at 2022-06-20 23:25:20.665225
# Unit test for function join_args

# Generated at 2022-06-20 23:25:28.633268
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', '\nc', 'd']) == 'a b\nc d'
    assert join_args(['a', ' b', '\n c', 'd']) == 'a  b\n  c d'
    assert join_args(['a=1', 'b=2', '\nc=3', 'd=4']) == 'a=1 b=2\nc=3 d=4'
    assert join_args(['a=1', ' b=2', '\n c=3', 'd=4']) == 'a=1  b=2\n  c=3 d=4'



# Generated at 2022-06-20 23:25:34.917371
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['foo']) == 'foo'
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo\nbar']) == 'foo\nbar'
    assert join_args(['foo', '\nbar']) == 'foo \nbar'
    assert join_args(['foo', '\nbar', 'baz']) == 'foo \nbar baz'
    assert join_args(['foo', '"bar"', '\nbaz']) == 'foo "bar" \nbaz'
    assert join_args(['foo', '"bar', 'taz"']) == 'foo "bar taz"'



# Generated at 2022-06-20 23:25:46.148556
# Unit test for function split_args
def test_split_args():
    def assert_split(arg_str, expected):
        result = join_args(split_args(arg_str))
        assert result == expected
    assert_split(u"foo={{bar", u"foo={{bar")
    assert_split(u"foo={{bar}}", u"foo={{bar}}")
    assert_split(u"foo={{bar}}\n", u"foo={{bar}}\n")
    assert_split(u"foo={{bar}} \n", u"foo={{bar}} \n")
    assert_split(u"foo={{bar}} \\ \n", u"foo={{bar}} \\ \n")
    assert_split(u"foo={{bar}} \\ baz=quux\n", u"foo={{bar}} \\ baz=quux\n")
    assert_split

# Generated at 2022-06-20 23:25:54.999638
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv('') == {}
    assert parse_kv('one=1') == {u'one': u'1'}
    assert parse_kv('one=1 two=2') == {u'one': u'1', u'two': u'2'}
    assert parse_kv('one=\\x31 two=\\u0032 three=\\N{GREEK CAPITAL LETTER OMEGA}') == {u'one': u'1', u'two': u'2', u'three': u'\u03a9'}
    assert parse_kv('one=1 two=2 "three words"') == {u'one': u'1', u'two': u'2', u'_raw_params': u'three words'}


# Generated at 2022-06-20 23:26:15.873232
# Unit test for function split_args
def test_split_args():
    '''
    test some of the more complicated corner cases with split_args()
    This is done as a unit test since we don't want to have to write
    test modules for everything.
    '''

    # for each tuple in the list, the first item is the input, the second item
    # is the expected list result

# Generated at 2022-06-20 23:26:24.336004
# Unit test for function split_args
def test_split_args():
    '''
    returns True if all tests passed
    returns False if any tests fail
    '''

    from ansible.errors import AnsibleError

    # basic tests
    t1 = ['a=b', 'c="foo bar"', 'd="foo\nbar"']
    assert split_args("a=b c='foo bar' d='foo\nbar'") == t1
    # make sure the quotes are stripped, but the escaped
    # double quotes are preserved
    t2 = ['a=b', 'c="foo', 'bar"', 'd=a\nb', 'e=a\rb', 'f=a\fb']
    assert split_args("a=b c=\"foo\nbar\" d=a\\nb e=a\\rb f=a\\fb") == t2
    # test quotes inside jinja2 blocks


# Generated at 2022-06-20 23:26:35.658729
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common.collections import Mapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.errors import AnsibleParserError


# Generated at 2022-06-20 23:26:43.566317
# Unit test for function split_args

# Generated at 2022-06-20 23:26:53.179196
# Unit test for function join_args
def test_join_args():
    assert join_args([u'sed -i', u'$ a test']) == 'sed -i $ a test'
    assert join_args([u'sed -i', u'$ a test', u'two']) == 'sed -i $ a test two'
    assert join_args([u'sed -i', u'$ a test\n', u'two']) == 'sed -i $ a test\n two'
    assert join_args([u'sed -i', u'\'$ a test\n\'', u'two']) == 'sed -i \'$ a test\n\' two'
    assert join_args([u'sed -i', u'\'$ a test\n', u'two\'']) == 'sed -i \'$ a test\n two\''



# Generated at 2022-06-20 23:27:02.559562
# Unit test for function split_args
def test_split_args():
    # NOTE - this function's unit test is not exhaustive and relies on the
    # behavior of the Jinja2 templating language to cover some edge cases.
    def assert_split_args(args, expected_result):
        result = split_args(args)

        if result != expected_result:
            raise AssertionError("'%s' did not split correctly. Expected result: '%s' Got: '%s'" % (args, expected_result, result))

    assert_split_args('a b c', ['a', 'b', 'c'])
    assert_split_args('a b=c d', ['a', 'b=c', 'd'])
    assert_split_args('a=b c d', ['a=b', 'c', 'd'])

# Generated at 2022-06-20 23:27:10.024182
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {"foo":"bar"}
    assert parse_kv("foo='bar baz'") == {"foo":"bar baz"}
    assert parse_kv("foo='bar \"baz\"'") == {"foo":"bar \"baz\""}
    assert parse_kv("foo=bar baz=quux") == {"foo":"bar", "baz":"quux"}
    assert parse_kv("foo='bar \"baz\"' norf=thud") == {"foo":"bar \"baz\"", "norf":"thud"}
    assert parse_kv("foo=bar baz='quux thud' norf=frotz") == {"foo":"bar", "baz":"quux thud", "norf":"frotz"}

# Generated at 2022-06-20 23:27:20.612419
# Unit test for function split_args

# Generated at 2022-06-20 23:27:26.444133
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo bar baz']) == 'foo bar baz'
    assert join_args(['foo\nbar', 'baz']) == 'foo\nbar baz'
    assert join_args(['foo\nbar\nbaz']) == 'foo\nbar\nbaz'
    assert join_args(['foo', 'bar\nbaz']) == 'foo bar\nbaz'



# Generated at 2022-06-20 23:27:37.240797
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv('') == {}
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('fiz faz') == {u'_raw_params': u'fiz faz'}
    assert parse_kv('fiz=faz') == {u'fiz': u'faz'}
    assert parse_kv('foo=bar fiz=faz') == {u'foo': u'bar', u'fiz': u'faz'}
    assert parse_kv('fiz foo=bar') == {u'_raw_params': u'fiz', u'foo': u'bar'}

# Generated at 2022-06-20 23:27:58.433459
# Unit test for function join_args
def test_join_args():
    '''
    This is the unit test for join_args function.
    '''
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo', 'bar', 'baz', '\n']) == 'foo bar baz\n'
    assert join_args(['foo', 'bar', 'baz\n']) == 'foo bar baz\n'
    assert 'foo bar baz\n' == join_args(['foo', 'bar', 'baz\n'])
    assert join_args(['foo', 'bar', 'baz\n', '\n']) == 'foo bar baz\n\n'

# Generated at 2022-06-20 23:28:09.290883
# Unit test for function split_args
def test_split_args():
    args = u"""
    a=b c="foo bar"
    x=y z=zoo
    """
    params = split_args(args)
    assert params == [u'a=b', u'c="foo bar"', u'x=y', u'z=zoo'], "Failed to split arguments."
    params = split_args(args.strip())
    assert params == [u'a=b', u'c="foo bar"', u'x=y', u'z=zoo'], "Failed to split arguments."
    args = u"""
    a=b c="foo bar"
    a=b c="foo bar"
    """
    params = split_args(args)

# Generated at 2022-06-20 23:28:16.086447
# Unit test for function parse_kv
def test_parse_kv():
    # Test basic key/value assignment
    data = parse_kv('foo=bar')
    assert data[u'foo'] == u'bar'

    # Test key/value assignment with surrounding whitespace
    data = parse_kv('  foo= bar  ')
    assert data[u'foo'] == u'bar'

    # Test that assignments without any equals sign are discarded
    data = parse_kv('free form text')
    assert u'free' not in data.keys()

    # Test advanced escaping for equals sign
    data = parse_kv(r'foo\===bar')
    assert data[u'foo='] == u'=bar'

    # Test advanced escaping for equals sign but no match
    data = parse_kv(r'foo\=')
    assert u'foo=' not in data.keys()

    #

# Generated at 2022-06-20 23:28:26.168256
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_bytes
    fail_unquoted_args = [
        u'foo bar=baz',
        u'foo bar=baz cat',
        u'foo=bar baz',
        u'foo="bar baz"',
        u'foo="bar baz',
        u'foo=bar baz"',
        u'foo="bar baz""',
        u'foo="bar baz\'',
        u'foo=bar baz\'"',
        u'foo=\'bar baz"',
        u'foo="bar baz\''
    ]

# Generated at 2022-06-20 23:28:35.270719
# Unit test for function join_args

# Generated at 2022-06-20 23:28:43.427045
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar baz=quux") == {u"foo":u"bar", u"baz":u"quux"}
    assert parse_kv(u"foo=bar baz='quux quux'") == {u"foo":u"bar", u"baz":u"quux quux"}
    assert parse_kv(u"foo=bar baz=\"quux quux\"") == {u"foo":u"bar", u"baz":u"quux quux"}
    assert parse_kv(u"foo=bar baz=\"quux quux\"") == {u"foo":u"bar", u"baz":u"quux quux"}

# Generated at 2022-06-20 23:28:53.233211
# Unit test for function split_args

# Generated at 2022-06-20 23:29:02.473098
# Unit test for function parse_kv
def test_parse_kv():
    """
    Unit test for function parse_kv
    """

    assert parse_kv("foo=bar baz=foobar") == {"foo": "bar", "baz": "foobar"}
    assert parse_kv("foo='bar baz'") == {"foo": "bar baz"}
    assert parse_kv("foo=bar baz") == {"foo": "bar", "_raw_params": "baz"}
    assert parse_kv("foo=bar\nbaz=foobar") == {"foo": "bar\nbaz", "baz": "foobar"}
    assert parse_kv("foo=bar\nbaz=foobar", check_raw=True) == {"foo": "bar\nbaz", "baz": "foobar", "_raw_params": "foo=bar\nbaz"}


# Generated at 2022-06-20 23:29:14.006831
# Unit test for function split_args
def test_split_args():
    import os
    import tempfile
    with tempfile.NamedTemporaryFile() as test_file:
        script = (
            '#!/bin/bash -e\n'
            '\n'
            'export MYVAR="My Value"\n'
            'echo "echo exit status is $?"\n'
            'echo "MYVAR is $MYVAR"\n'
        )
        test_file.write(script.encode('utf-8'))
        test_file.flush()
        os.fchmod(test_file.fileno(), 0o775)
        actual = split_args(u'executable={0} stdin="{{stdin}}"'.format(test_file.name))

# Generated at 2022-06-20 23:29:17.211451
# Unit test for function join_args
def test_join_args():
    orig = ('''\
A=1 \\\n
    B=2 \\\n
    C=3''')
    assert join_args(split_args(orig)) == orig



# Generated at 2022-06-20 23:29:34.780167
# Unit test for function join_args
def test_join_args():
    assert(join_args(['echo', 'Hello\nWorld']) == 'echo Hello\nWorld')
    assert(join_args(['echo', 'hello world']) == 'echo hello world')
    assert(join_args(['echo', 'hello\nworld']) == 'echo hello\nworld')
    assert(join_args(['echo', 'hello world\n']) == 'echo hello world\n')
    assert(join_args(['echo', '"hello world"']) == 'echo "hello world"')
    assert(join_args(['echo', '\'hello world\'']) == 'echo \'hello world\'')
    assert(join_args(['echo', '"hello world\nHow are you?"']) == 'echo "hello world\nHow are you?"')