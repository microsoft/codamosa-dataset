

# Generated at 2022-06-17 06:13:26.572008
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:13:40.699550
# Unit test for function split_args
def test_split_args():
    # Test for issue #24094
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d=') == [u'a=b', u'c="foo bar"', u'd=']
    assert split_args(u'a=b c="foo bar" d=\\') == [u'a=b', u'c="foo bar"', u'd=\\']
    assert split_args(u'a=b c="foo bar" d=\\\n') == [u'a=b', u'c="foo bar"', u'd=\\\n']

# Generated at 2022-06-17 06:13:48.995728
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f="g h"') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f="g h" i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f="g h" i j') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j'}

# Generated at 2022-06-17 06:14:02.838578
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:11.919360
# Unit test for function split_args
def test_split_args():
    # Test 1: simple test
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test 2: test with newlines
    assert split_args('a=b\nc="foo bar"') == ['a=b', 'c="foo bar"']

    # Test 3: test with newlines and line continuation
    assert split_args('a=b\nc="foo bar"\\\nd=e') == ['a=b', 'c="foo bar"d=e']

    # Test 4: test with jinja2 blocks
    assert split_args('a=b c="{{ foo }}"') == ['a=b', 'c="{{ foo }}"']

    # Test 5: test with jinja2 blocks and newlines

# Generated at 2022-06-17 06:14:22.329914
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:32.299916
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:14:41.336996
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''
    a=b c="foo bar"
    '''
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Test case 2
    args = '''
    a=b c="foo bar"
    '''
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Test case 3
    args = '''
    a=b c="foo bar"
    '''
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Test case 4
    args = '''
    a=b c="foo bar"
    '''
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Test case 5
   

# Generated at 2022-06-17 06:14:55.183216
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:15:03.304921
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = 'a=b c="foo bar"'
    result = ['a=b', 'c="foo bar"']
    assert split_args(args) == result

    # Test case 2
    args = 'a=b c="foo bar" d=\'foo bar\''
    result = ['a=b', 'c="foo bar"', 'd=\'foo bar\'']
    assert split_args(args) == result

    # Test case 3
    args = 'a=b c="foo bar" d=\'foo bar\' e="foo bar"'
    result = ['a=b', 'c="foo bar"', 'd=\'foo bar\'', 'e="foo bar"']
    assert split_args(args) == result

    # Test case 4

# Generated at 2022-06-17 06:15:30.564674
# Unit test for function split_args
def test_split_args():
    # Test 1: simple case
    args = "a=b c='foo bar'"
    expected = ['a=b', "c='foo bar'"]
    result = split_args(args)
    assert result == expected

    # Test 2: simple case with newlines
    args = "a=b\nc='foo bar'"
    expected = ['a=b', "c='foo bar'"]
    result = split_args(args)
    assert result == expected

    # Test 3: simple case with newlines and spaces
    args = "a=b\n c='foo bar'"
    expected = ['a=b', "c='foo bar'"]
    result = split_args(args)
    assert result == expected

    # Test 4: simple case with newlines and spaces
    args = "a=b\n c='foo bar'"
   

# Generated at 2022-06-17 06:15:38.983843
# Unit test for function split_args

# Generated at 2022-06-17 06:15:48.469719
# Unit test for function split_args
def test_split_args():
    # Test simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test case with newlines
    assert split_args('a=b\nc="foo bar"') == ['a=b', 'c="foo bar"']

    # Test case with escaped quotes
    assert split_args('a=b c="foo \\"bar\\""') == ['a=b', 'c="foo \\"bar\\""']

    # Test case with escaped newlines
    assert split_args('a=b c="foo\\\nbar"') == ['a=b', 'c="foo\\\nbar"']

    # Test case with escaped newlines and escaped quotes

# Generated at 2022-06-17 06:15:58.203601
# Unit test for function split_args
def test_split_args():
    # Test 1: simple args
    args = 'a=b c="foo bar"'
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 2: args with newlines
    args = 'a=b\nc="foo bar"'
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 3: args with newlines and spaces
    args = 'a=b\n c="foo bar"'
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 4: args with newlines and spaces
    args = 'a=b\n c="foo bar"'
    result = split_args(args)

# Generated at 2022-06-17 06:16:03.046402
# Unit test for function split_args
def test_split_args():
    def _test_split_args(args, expected):
        actual = split_args(args)
        assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)

    _test_split_args('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _test_split_args('a=b c="foo bar" d="foo bar"', ['a=b', 'c="foo bar"', 'd="foo bar"'])
    _test_split_args('a=b c="foo bar" d="foo bar" e=f', ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f'])

# Generated at 2022-06-17 06:16:13.045956
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:16:28.033797
# Unit test for function split_args

# Generated at 2022-06-17 06:16:37.492723
# Unit test for function split_args
def test_split_args():
    # Test with a simple string
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test with a string containing a space in a jinja2 block
    assert split_args('a=b c="foo {{ bar }}"') == ['a=b', 'c="foo {{ bar }}"']

    # Test with a string containing a space in a jinja2 block with quotes
    assert split_args('a=b c="foo {{ bar }}" d="{{ foo }} bar"') == ['a=b', 'c="foo {{ bar }}"', 'd="{{ foo }} bar"']

    # Test with a string containing a space in a jinja2 block with quotes

# Generated at 2022-06-17 06:16:47.442388
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:16:57.689729
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']

# Generated at 2022-06-17 06:17:26.479043
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e=\"{{ bar }}\"") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e=\"{{ bar }}\" f='{{ baz }}'") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"', "f='{{ baz }}'"]
    assert split

# Generated at 2022-06-17 06:17:32.844218
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''a=b c="foo bar"'''
    expected = ['a=b', 'c="foo bar"']
    actual = split_args(args)
    assert actual == expected

    # Test case 2
    args = '''a=b c="foo bar" d={{ e }}'''
    expected = ['a=b', 'c="foo bar"', 'd={{', 'e', '}}']
    actual = split_args(args)
    assert actual == expected

    # Test case 3
    args = '''a=b c="foo bar" d={{ e }} f={{ g }} h={{ i }}'''

# Generated at 2022-06-17 06:17:47.195405
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_k

# Generated at 2022-06-17 06:17:53.568224
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:18:06.841760
# Unit test for function parse_kv
def test_parse_kv():
    # Test case 1
    args = "a=1 b=2 c=3"
    expected = {u'a': u'1', u'b': u'2', u'c': u'3'}
    result = parse_kv(args)
    assert result == expected

    # Test case 2
    args = "a=1 b=2 c=3 d"
    expected = {u'a': u'1', u'b': u'2', u'c': u'3', u'_raw_params': u'd'}
    result = parse_kv(args, check_raw=True)
    assert result == expected

    # Test case 3
    args = "a=1 b=2 c=3 d"

# Generated at 2022-06-17 06:18:21.205683
# Unit test for function split_args
def test_split_args():
    # Test 1: simple case
    assert split_args("a=b c=d") == ['a=b', 'c=d']

    # Test 2: simple case with spaces
    assert split_args("a=b c=d e=f") == ['a=b', 'c=d', 'e=f']

    # Test 3: simple case with newlines
    assert split_args("a=b\nc=d") == ['a=b', 'c=d']

    # Test 4: simple case with newlines and spaces
    assert split_args("a=b\nc=d e=f") == ['a=b', 'c=d', 'e=f']

    # Test 5: simple case with quotes
    assert split_args("a=b c='d e'") == ['a=b', "c='d e'"]



# Generated at 2022-06-17 06:18:29.402294
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:18:35.056309
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': ''}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:18:42.513334
# Unit test for function split_args

# Generated at 2022-06-17 06:18:52.445957
# Unit test for function split_args
def test_split_args():
    # Test 1: Simple test
    args = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected

    # Test 2: Test with newlines
    args = 'a=b c="foo bar"\nd=e f="foo bar"'
    expected = ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"']
    result = split_args(args)
    assert result == expected

    # Test 3: Test with newlines and line continuation
    args = 'a=b c="foo bar"\nd=e f="foo bar" \\'
    expected = ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"']
    result = split_

# Generated at 2022-06-17 06:19:26.728086
# Unit test for function split_args

# Generated at 2022-06-17 06:19:37.858932
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=\'g h\'') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i j=k') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j=k'}

# Generated at 2022-06-17 06:19:50.764575
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv("a=1 b=2 c") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c'}
    assert parse_kv("a=1 b=2 c d=3") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c d=3'}
    assert parse_kv("a=1 b=2 c d=3 e") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c d=3 e'}

# Generated at 2022-06-17 06:20:00.088200
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f={{ foo }}']

# Generated at 2022-06-17 06:20:09.165784
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}


# Generated at 2022-06-17 06:20:22.836977
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ foo }} f={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ foo }}', 'f={{ foo }}']

# Generated at 2022-06-17 06:20:28.178944
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:20:40.672772
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=quux') == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv('foo=bar baz=quux spam=eggs') == {'foo': 'bar', 'baz': 'quux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=quux spam=eggs') == {'foo': 'bar', 'baz': 'quux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=quux spam=eggs') == {'foo': 'bar', 'baz': 'quux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:20:47.689646
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:20:59.927298
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e=') == {'a': 'b', 'c': 'd', 'e': ''}
    assert parse_kv('a=b c=d e= f=g') == {'a': 'b', 'c': 'd', 'e': '', 'f': 'g'}

# Generated at 2022-06-17 06:21:20.235056
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:21:34.618294
# Unit test for function split_args
def test_split_args():
    # Test simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test case with newlines
    assert split_args('a=b\nc="foo bar"') == ['a=b\n', 'c="foo bar"']

    # Test case with line continuation
    assert split_args('a=b\\\nc="foo bar"') == ['a=b\\\n', 'c="foo bar"']

    # Test case with line continuation and newlines
    assert split_args('a=b\\\n\nc="foo bar"') == ['a=b\\\n\n', 'c="foo bar"']

    # Test case with line continuation and newlines

# Generated at 2022-06-17 06:21:46.027971
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}

# Generated at 2022-06-17 06:21:54.108050
# Unit test for function split_args

# Generated at 2022-06-17 06:22:01.053838
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:22:11.582649
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:22:23.466359
# Unit test for function split_args
def test_split_args():
    # Test 1: Simple test
    test_string = "a=b c=d"
    result = split_args(test_string)
    assert result == ['a=b', 'c=d']

    # Test 2: Test with quotes
    test_string = "a=b c='d e'"
    result = split_args(test_string)
    assert result == ['a=b', "c='d e'"]

    # Test 3: Test with double quotes
    test_string = 'a=b c="d e"'
    result = split_args(test_string)
    assert result == ['a=b', 'c="d e"']

    # Test 4: Test with escaped quotes
    test_string = "a=b c='d\\' e'"
    result = split_args(test_string)

# Generated at 2022-06-17 06:22:33.957485
# Unit test for function split_args