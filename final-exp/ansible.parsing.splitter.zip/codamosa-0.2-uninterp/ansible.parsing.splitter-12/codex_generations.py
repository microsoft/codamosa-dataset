

# Generated at 2022-06-17 06:13:07.035091
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:13:21.740285
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}

# Generated at 2022-06-17 06:13:27.944845
# Unit test for function split_args
def test_split_args():
    # Test for issue #17074
    assert split_args(u"{{ 'foo' }}") == [u"{{ 'foo' }}"]
    assert split_args(u"{{ 'foo' }} {{ 'bar' }}") == [u"{{ 'foo' }}", u"{{ 'bar' }}"]
    assert split_args(u"{{ 'foo' }} {{ 'bar' }} {{ 'baz' }}") == [u"{{ 'foo' }}", u"{{ 'bar' }}", u"{{ 'baz' }}"]
    assert split_args(u"{{ 'foo' }} {{ 'bar' }} {{ 'baz' }} {{ 'qux' }}") == [u"{{ 'foo' }}", u"{{ 'bar' }}", u"{{ 'baz' }}", u"{{ 'qux' }}"]
    assert split_args

# Generated at 2022-06-17 06:13:42.978126
# Unit test for function split_args

# Generated at 2022-06-17 06:13:49.421985
# Unit test for function split_args

# Generated at 2022-06-17 06:14:03.234732
# Unit test for function split_args
def test_split_args():
    # Test with a simple string
    assert split_args("a=b c=d") == ["a=b", "c=d"]

    # Test with a string with quotes
    assert split_args("a=b c=\"foo bar\"") == ["a=b", "c=\"foo bar\""]

    # Test with a string with quotes and spaces
    assert split_args("a=b c=\"foo bar\" d=\"foo bar\"") == ["a=b", "c=\"foo bar\"", "d=\"foo bar\""]

    # Test with a string with quotes and spaces and newlines
    assert split_args("a=b\nc=\"foo bar\"\nd=\"foo bar\"") == ["a=b", "c=\"foo bar\"", "d=\"foo bar\""]

    # Test with a string with quotes and spaces and newlines and line continuation

# Generated at 2022-06-17 06:14:13.944967
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:22.372587
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:28.822869
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:14:39.681346
# Unit test for function split_args

# Generated at 2022-06-17 06:15:27.177806
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:15:34.814139
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e=') == {'a': 'b', 'c': 'd', 'e': ''}
    assert parse_kv('a=b c=d e= f=g') == {'a': 'b', 'c': 'd', 'e': '', 'f': 'g'}

# Generated at 2022-06-17 06:15:45.238099
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c=3") == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-17 06:15:55.978093
# Unit test for function parse_kv
def test_parse_kv():
    # Test with empty string
    assert parse_kv('') == {}
    # Test with single key-value pair
    assert parse_kv('key=value') == {'key': 'value'}
    # Test with multiple key-value pairs
    assert parse_kv('key1=value1 key2=value2') == {'key1': 'value1', 'key2': 'value2'}
    # Test with multiple key-value pairs and spaces
    assert parse_kv('key1=value1 key2=value2 ') == {'key1': 'value1', 'key2': 'value2'}
    # Test with multiple key-value pairs and spaces
    assert parse_kv(' key1=value1 key2=value2') == {'key1': 'value1', 'key2': 'value2'}


# Generated at 2022-06-17 06:16:10.243854
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=1 b=2 c=3') == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv(u'a=1 b=2 c=3', check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv(u'a=1 b=2 c=3', check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'3'}

# Generated at 2022-06-17 06:16:26.126884
# Unit test for function split_args
def test_split_args():
    # Test that we can split and rejoin args that have no jinja2 blocks or quotes
    args = 'foo bar baz'
    assert join_args(split_args(args)) == args

    # Test that we can split and rejoin args that have quotes
    args = 'foo "bar baz" qux'
    assert join_args(split_args(args)) == args

    # Test that we can split and rejoin args that have quotes and jinja2 blocks
    args = 'foo "bar {{ baz }} qux" quux'
    assert join_args(split_args(args)) == args

    # Test that we can split and rejoin args that have quotes and jinja2 blocks
    args = 'foo "bar {{ baz }} qux" quux'
    assert join_args(split_args(args)) == args



# Generated at 2022-06-17 06:16:36.218865
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:16:47.404495
# Unit test for function split_args

# Generated at 2022-06-17 06:16:54.050392
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d e=f", check_raw=True) == {u'a': u'b', u'c': u'd', u'e': u'f'}

# Generated at 2022-06-17 06:17:09.020399
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:17:52.686693
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:17:56.977058
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:18:09.580450
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}" f="{{ foo }} bar"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"', 'f="{{ foo }} bar"']
    assert split

# Generated at 2022-06-17 06:18:19.636139
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo \\" bar"') == ['a=b', 'c="foo bar"', 'd="foo \\" bar"']
    assert split_args('a=b c="foo bar" d="foo \\" bar" e=\\"foo bar\\"') == ['a=b', 'c="foo bar"', 'd="foo \\" bar"', 'e=\\"foo bar\\"']

# Generated at 2022-06-17 06:18:27.885826
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:18:40.844193
# Unit test for function split_args
def test_split_args():
    # Test 1
    args = "a=b c=\"foo bar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 2
    args = "a=b c=\"foo bar\"\nd=e f=\"foo bar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"']

    # Test 3
    args = "a=b c=\"foo bar\"\nd=e f=\"foo bar\"\n"
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"']

    # Test 4

# Generated at 2022-06-17 06:18:51.994411
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f="g h"') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f="g h" i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f="g h" i j') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j'}

# Generated at 2022-06-17 06:19:02.960605
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv(u"a=1 b=2 c=3") == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv(u"a=1 b=2 c=3 d=4") == {u'a': u'1', u'b': u'2', u'c': u'3', u'd': u'4'}

# Generated at 2022-06-17 06:19:15.162304
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar') == [u'a=b', u'c="foo bar']
    assert split_args(u'a=b c="foo bar\\') == [u'a=b', u'c="foo bar\\']
    assert split_args(u'a=b c="foo bar\\"') == [u'a=b', u'c="foo bar\\"']
    assert split_args(u'a=b c="foo bar\\\\"') == [u'a=b', u'c="foo bar\\\\"']

# Generated at 2022-06-17 06:19:26.785329
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''a=b c="foo bar"'''
    expected = ['a=b', 'c="foo bar"']
    actual = split_args(args)
    assert actual == expected, "Expected: %s, Actual: %s" % (expected, actual)

    # Test case 2
    args = '''a=b c="foo bar" d={{ foo }}'''
    expected = ['a=b', 'c="foo bar"', 'd={{ foo }}']
    actual = split_args(args)
    assert actual == expected, "Expected: %s, Actual: %s" % (expected, actual)

    # Test case 3
    args = '''a=b c="foo bar" d={{ foo }} e={{ bar }}'''

# Generated at 2022-06-17 06:19:51.599274
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ e }}") == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}']
    assert split_args("a=b c=\"foo bar\" d={{ e }} f={{ g }}") == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}', 'f={{', 'g', '}}']

# Generated at 2022-06-17 06:20:00.133481
# Unit test for function split_args
def test_split_args():
    # Test that split_args works as expected
    #
    # This test is not exhaustive, but it does cover the
    # basic cases that we expect to see in practice.
    #
    # If you make changes to split_args, you should
    # add additional tests here to ensure that it
    # continues to work as expected.

    # Test that split_args works on a simple string
    assert split_args("foo bar") == ["foo", "bar"]

    # Test that split_args works on a string with quotes
    assert split_args("foo 'bar baz'") == ["foo", "'bar baz'"]

    # Test that split_args works on a string with double quotes
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']

    # Test that split_args works on a string with escaped

# Generated at 2022-06-17 06:20:09.166376
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f="{{ foo }} bar"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f="{{ foo }} bar"']
    assert split

# Generated at 2022-06-17 06:20:22.837393
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e=f') == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert parse_kv('a=b c=d e=f g') == {'a': 'b', 'c': 'd', 'e': 'f', '_raw_params': 'g'}
    assert parse_kv('a=b c=d e=f g h') == {'a': 'b', 'c': 'd', 'e': 'f', '_raw_params': 'g h'}

# Generated at 2022-06-17 06:20:30.850890
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:20:42.410331
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']

# Generated at 2022-06-17 06:20:51.435333
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c=3") == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'3'}
   

# Generated at 2022-06-17 06:21:00.217455
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar") == {u"foo": u"bar"}
    assert parse_kv(u"foo=bar baz=qux") == {u"foo": u"bar", u"baz": u"qux"}
    assert parse_kv(u"foo=bar baz=qux quux") == {u"foo": u"bar", u"baz": u"qux", u"_raw_params": u"quux"}
    assert parse_kv(u"foo=bar baz=qux quux=corge") == {u"foo": u"bar", u"baz": u"qux", u"quux": u"corge"}

# Generated at 2022-06-17 06:21:14.494370
# Unit test for function split_args

# Generated at 2022-06-17 06:21:25.001311
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_k

# Generated at 2022-06-17 06:22:11.615682
# Unit test for function split_args

# Generated at 2022-06-17 06:22:21.899584
# Unit test for function split_args

# Generated at 2022-06-17 06:22:32.340655
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u"a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u"a=b c=d", check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u"a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u"a=b c=d", check_raw=False) == {u'a': u'b', u'c': u'd'}
