

# Generated at 2022-06-17 06:13:44.777411
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]

# Generated at 2022-06-17 06:13:55.106972
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e f') == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:06.757041
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:14:14.586764
# Unit test for function split_args
def test_split_args():
    # Test 1: Test basic functionality
    args = "a=b c='foo bar'"
    result = split_args(args)
    assert result == ['a=b', "c='foo bar'"]

    # Test 2: Test with a jinja2 block
    args = "a=b c='foo bar' d='{{ foo }}'"
    result = split_args(args)
    assert result == ['a=b', "c='foo bar'", "d='{{ foo }}'"]

    # Test 3: Test with a jinja2 block with spaces
    args = "a=b c='foo bar' d='{{ foo }} bar'"
    result = split_args(args)
    assert result == ['a=b', "c='foo bar'", "d='{{ foo }} bar'"]

    # Test 4: Test with a jin

# Generated at 2022-06-17 06:14:24.105073
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected

    # Test case 2
    args = 'a=b c="foo bar" d="foo bar"'
    expected = ['a=b', 'c="foo bar"', 'd="foo bar"']
    result = split_args(args)
    assert result == expected

    # Test case 3
    args = 'a=b c="foo bar" d="foo bar" e="foo bar"'
    expected = ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"']
    result = split_args(args)
    assert result == expected

    # Test case 4

# Generated at 2022-06-17 06:14:34.012075
# Unit test for function split_args

# Generated at 2022-06-17 06:14:41.567362
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3 d', check_raw=True) == {'a': '1', 'b': '2', 'c': '3', '_raw_params': 'd'}
    assert parse_kv('a=1 b=2 c=3 d e', check_raw=True) == {'a': '1', 'b': '2', 'c': '3', '_raw_params': 'd e'}
    assert parse

# Generated at 2022-06-17 06:14:55.440893
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:15:03.639933
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']

# Generated at 2022-06-17 06:15:17.148044
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar") == {u"foo": u"bar"}
    assert parse_kv(u"foo='bar'") == {u"foo": u"bar"}
    assert parse_kv(u"foo=\"bar\"") == {u"foo": u"bar"}
    assert parse_kv(u"foo='bar baz'") == {u"foo": u"bar baz"}
    assert parse_kv(u"foo=\"bar baz\"") == {u"foo": u"bar baz"}
    assert parse_kv(u"foo='bar baz' bar=foo") == {u"foo": u"bar baz", u"bar": u"foo"}

# Generated at 2022-06-17 06:15:52.970396
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux', '_raw_params': 'foo=bar baz=qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux', '_raw_params': 'foo=bar baz=qux'}

# Generated at 2022-06-17 06:16:07.922988
# Unit test for function split_args
def test_split_args():
    # Test 1: Simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test 2: Simple case with newlines
    assert split_args('a=b\nc="foo bar"') == ['a=b', 'c="foo bar"']

    # Test 3: Simple case with newlines and line continuation
    assert split_args('a=b\nc="foo bar"\\\nd=e') == ['a=b', 'c="foo bar"', 'd=e']

    # Test 4: Simple case with newlines and line continuation and spaces
    assert split_args('a=b\nc="foo bar"\\\nd=e f=g') == ['a=b', 'c="foo bar"', 'd=e f=g']

    # Test 5:

# Generated at 2022-06-17 06:16:15.136747
# Unit test for function split_args

# Generated at 2022-06-17 06:16:25.602150
# Unit test for function split_args

# Generated at 2022-06-17 06:16:36.008017
# Unit test for function split_args

# Generated at 2022-06-17 06:16:48.947199
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f="{{ foo }} bar"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f="{{ foo }} bar"']
    assert split

# Generated at 2022-06-17 06:17:03.406128
# Unit test for function split_args
def test_split_args():
    def _test(args, expected):
        actual = split_args(args)
        assert actual == expected, "Expected: %s, Actual: %s" % (expected, actual)

    _test('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _test('a=b c="foo bar" d={{ foo }}', ['a=b', 'c="foo bar"', 'd={{ foo }}'])
    _test('a=b c="foo bar" d={{ foo }} e="{{ foo }}"', ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"'])

# Generated at 2022-06-17 06:17:09.620662
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:17:15.465905
# Unit test for function split_args
def test_split_args():
    # Test with no quotes or jinja2 blocks
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b c=d\ne=f') == ['a=b', 'c=d\ne=f']
    assert split_args('a=b c=d\ne=f\n') == ['a=b', 'c=d\ne=f\n']

    # Test with quotes
    assert split_args('a=b c="d e"') == ['a=b', 'c="d e"']
    assert split_args('a=b c="d e"\ne=f') == ['a=b', 'c="d e"\ne=f']

# Generated at 2022-06-17 06:17:28.937512
# Unit test for function split_args
def test_split_args():
    # Test 1
    args = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    assert split_args(args) == expected

    # Test 2
    args = 'a=b c="foo bar" d="foo bar"'
    expected = ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args(args) == expected

    # Test 3
    args = 'a=b c="foo bar" d="foo bar" e="foo bar"'
    expected = ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"']
    assert split_args(args) == expected

    # Test 4

# Generated at 2022-06-17 06:17:52.896065
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux=quux') == {'foo': 'bar', 'baz': 'qux=quux'}
    assert parse_kv('foo=bar baz=qux=quux fred=wilma') == {'foo': 'bar', 'baz': 'qux=quux', 'fred': 'wilma'}

# Generated at 2022-06-17 06:18:00.551698
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:18:11.169445
# Unit test for function split_args
def test_split_args():
    assert split_args('foo=bar') == ['foo=bar']
    assert split_args('foo=bar baz=qux') == ['foo=bar', 'baz=qux']
    assert split_args('foo=bar\nbaz=qux') == ['foo=bar\n', 'baz=qux']
    assert split_args('foo=bar\n baz=qux') == ['foo=bar\n', 'baz=qux']
    assert split_args('foo=bar\n\nbaz=qux') == ['foo=bar\n', '\n', 'baz=qux']
    assert split_args('foo=bar\n\n baz=qux') == ['foo=bar\n', '\n', 'baz=qux']

# Generated at 2022-06-17 06:18:24.462390
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:18:33.947768
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=quux') == {u'foo': u'bar', u'baz': u'quux'}
    assert parse_kv(u'foo=bar baz=quux spam=eggs') == {u'foo': u'bar', u'baz': u'quux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=quux spam=eggs') == {u'foo': u'bar', u'baz': u'quux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:18:43.961040
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:18:53.085669
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:19:03.058435
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo\'s bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo\'s bar"']

# Generated at 2022-06-17 06:19:15.209185
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d=') == [u'a=b', u'c="foo bar"', u'd=']
    assert split_args(u'a=b c="foo bar" d=\\') == [u'a=b', u'c="foo bar"', u'd=\\']
    assert split_args(u'a=b c="foo bar" d=\\\n') == [u'a=b', u'c="foo bar"', u'd=\\\n']

# Generated at 2022-06-17 06:19:26.809774
# Unit test for function split_args

# Generated at 2022-06-17 06:19:55.416635
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c=\"foo bar\"") == [u'a=b', u'c="foo bar"']
    assert split_args(u"a=b c=\"foo bar\" d={{ foo }}") == [u'a=b', u'c="foo bar"', u'd={{ foo }}']
    assert split_args(u"a=b c=\"foo bar\" d={{ foo }} e={{ bar }}") == [u'a=b', u'c="foo bar"', u'd={{ foo }}', u'e={{ bar }}']

# Generated at 2022-06-17 06:20:08.393725
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:20:13.586500
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:20:25.536666
# Unit test for function split_args

# Generated at 2022-06-17 06:20:32.320324
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e f') == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:20:39.928336
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv(u'foo=bar baz=qux=quux') == {u'foo': u'bar', u'baz': u'qux=quux'}

# Generated at 2022-06-17 06:20:46.773026
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:20:59.641025
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=\'g h\'') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i', check_raw=False) == {u'a': u'b', u'c': u'd e', u'f': u'g h'}

# Generated at 2022-06-17 06:21:08.414212
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:21:17.373844
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=\'g h\'') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i j=k') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j=k'}

# Generated at 2022-06-17 06:21:44.347434
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:21:53.767250
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\\"') == ['a=b', 'c="foo bar\\"']
    assert split_args('a=b c="foo bar" d="foo bar\\"') == ['a=b', 'c="foo bar"', 'd="foo bar\\"']
    assert split_args('a=b c="foo bar" d="foo bar\\" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar\\"', 'e=f']

# Generated at 2022-06-17 06:22:04.335557
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=False) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:22:11.981608
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test that we can handle newlines
    assert split_args('a=b\nc="foo bar"') == ['a=b', 'c="foo bar"']

    # Test that we can handle line continuations
    assert split_args('a=b\\\nc="foo bar"') == ['a=b\\', 'c="foo bar"']

    # Test that we can handle line continuations inside quotes
    assert split_args('a=b\\\nc="foo\\\nbar"') == ['a=b\\', 'c="foo\\\nbar"']

    # Test that we can handle line continuations inside jinja2 blocks

# Generated at 2022-06-17 06:22:22.300284
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c='foo bar'") == [u'a=b', u"c='foo bar'"]
    assert split_args(u"a=b c=\"foo bar\"") == [u'a=b', u'c="foo bar"']
    assert split_args(u"a=b c=\"foo bar\" d='foo bar'") == [u'a=b', u'c="foo bar"', u"d='foo bar'"]
    assert split_args(u"a=b c=\"foo bar\" d='foo bar' e=\"foo bar\"") == [u'a=b', u'c="foo bar"', u"d='foo bar'", u'e="foo bar"']

# Generated at 2022-06-17 06:22:31.241270
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': ''}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': ''}