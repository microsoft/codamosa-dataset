

# Generated at 2022-06-17 06:13:06.314649
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']
    assert split_args('a=b c="foo bar" d=\\') == ['a=b', 'c="foo bar"', 'd=\\']
    assert split_args('a=b c="foo bar" d=\\\n') == ['a=b', 'c="foo bar"', 'd=\\\n']

# Generated at 2022-06-17 06:13:21.215267
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:13:30.317757
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'3', u'_raw_params': u'a=1 b=2 c=3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=False) == {u'a': u'1', u'b': u'2', u'c': u'3'}

# Generated at 2022-06-17 06:13:44.423559
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo \\"bar\\""') == ['a=b', 'c="foo bar"', 'd="foo \\"bar\\""']
    assert split_args('a=b c="foo bar" d="foo \\"bar\\"" e=f') == ['a=b', 'c="foo bar"', 'd="foo \\"bar\\""', 'e=f']

# Generated at 2022-06-17 06:13:50.229273
# Unit test for function split_args
def test_split_args():
    # Test for a simple case
    test_args = "a=b c=\"foo bar\""
    assert split_args(test_args) == ['a=b', 'c="foo bar"']

    # Test for a case with a newline
    test_args = "a=b\nc=\"foo bar\""
    assert split_args(test_args) == ['a=b', 'c="foo bar"']

    # Test for a case with a newline and a space
    test_args = "a=b\n c=\"foo bar\""
    assert split_args(test_args) == ['a=b', 'c="foo bar"']

    # Test for a case with a newline and a space and a backslash
    test_args = "a=b\n c=\"foo bar\"\\"
    assert split_args

# Generated at 2022-06-17 06:14:03.733272
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e="foo bar" f="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"', 'f="foo bar"']

# Generated at 2022-06-17 06:14:17.860577
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=1 b=2 c=3") == {u'a': u'1', u'c': u'3', u'b': u'2'}
    assert parse_kv(u"a=1 b=2 c=3", check_raw=True) == {u'a': u'1', u'c': u'3', u'b': u'2', u'_raw_params': u'a=1 b=2 c=3'}
    assert parse_kv(u"a=1 b=2 c=3", check_raw=False) == {u'a': u'1', u'c': u'3', u'b': u'2'}

# Generated at 2022-06-17 06:14:27.311797
# Unit test for function parse_kv
def test_parse_kv():
    # Test with no args
    assert parse_kv('') == {}

    # Test with a single arg
    assert parse_kv('foo=bar') == {'foo': 'bar'}

    # Test with multiple args
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}

    # Test with multiple args and spaces
    assert parse_kv('foo=bar baz=qux ') == {'foo': 'bar', 'baz': 'qux'}

    # Test with multiple args and spaces
    assert parse_kv(' foo=bar baz=qux ') == {'foo': 'bar', 'baz': 'qux'}

    # Test with multiple args and spaces

# Generated at 2022-06-17 06:14:35.998420
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:14:42.279092
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'e'}

# Generated at 2022-06-17 06:15:18.493800
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}

# Generated at 2022-06-17 06:15:24.852666
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:15:34.647169
# Unit test for function split_args
def test_split_args():
    # Test for issue #14053
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=foo\\ bar") == ['a=b', 'c=foo bar']
    assert split_args("a=b c=foo\\\nbar") == ['a=b', 'c=foobar']
    assert split_args("a=b c=foo\\\n\nbar") == ['a=b', 'c=foo', 'bar']
    assert split_args("a=b c=foo\\\n\nbar\n") == ['a=b', 'c=foo', 'bar']
    assert split

# Generated at 2022-06-17 06:15:47.857054
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=\'g h\'') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i j=k') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j=k'}

# Generated at 2022-06-17 06:15:57.538108
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ foo }} f={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ foo }}', 'f={{ foo }}']

# Generated at 2022-06-17 06:16:11.107822
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c=3") == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=False) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-17 06:16:16.455272
# Unit test for function split_args

# Generated at 2022-06-17 06:16:26.030998
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }} f=\"{{ foo }}\"") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ foo }}"']

# Generated at 2022-06-17 06:16:36.180587
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\\') == ['a=b', 'c="foo bar\\']
    assert split_args('a=b c="foo bar\\"') == ['a=b', 'c="foo bar\\"']
    assert split_args('a=b c="foo bar\\""') == ['a=b', 'c="foo bar\\""']
    assert split_args('a=b c="foo bar\\"" d=e') == ['a=b', 'c="foo bar\\""', 'd=e']

# Generated at 2022-06-17 06:16:47.406722
# Unit test for function split_args

# Generated at 2022-06-17 06:17:09.210564
# Unit test for function split_args

# Generated at 2022-06-17 06:17:22.987687
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:32.112687
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d={{ foo }}') == [u'a=b', u'c="foo bar"', u'd={{ foo }}']
    assert split_args(u'a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == [u'a=b', u'c="foo bar"', u'd={{ foo }}', u'e="{{ foo }}"']

# Generated at 2022-06-17 06:17:46.453925
# Unit test for function split_args

# Generated at 2022-06-17 06:17:53.037722
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f={{ foo }}']

# Generated at 2022-06-17 06:18:00.614140
# Unit test for function split_args

# Generated at 2022-06-17 06:18:10.442115
# Unit test for function split_args

# Generated at 2022-06-17 06:18:23.607207
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e f') == {'a': 'b', 'c': 'd', '_raw_params': 'e f'}
    assert parse_k

# Generated at 2022-06-17 06:18:30.311072
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {u'foo': u'bar'}
    assert parse_kv("foo='bar'") == {u'foo': u'bar'}
    assert parse_kv("foo='bar baz'") == {u'foo': u'bar baz'}
    assert parse_kv("foo='bar baz' foo2=bar2") == {u'foo': u'bar baz', u'foo2': u'bar2'}
    assert parse_kv("foo='bar baz' foo2=bar2 foo3='bar3'") == {u'foo': u'bar baz', u'foo2': u'bar2', u'foo3': u'bar3'}

# Generated at 2022-06-17 06:18:38.087170
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}


# Generated at 2022-06-17 06:19:02.374423
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:19:14.534331
# Unit test for function split_args

# Generated at 2022-06-17 06:19:26.533414
# Unit test for function split_args

# Generated at 2022-06-17 06:19:37.753838
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b') == {'a': 'b'}
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e f') == {'a': 'b', 'c': 'd', '_raw_params': 'e f'}
    assert parse_kv('a=b c=d e f g=h') == {'a': 'b', 'c': 'd', '_raw_params': 'e f', 'g': 'h'}

# Generated at 2022-06-17 06:19:50.708286
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-17 06:20:00.223192
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:20:10.264133
# Unit test for function split_args

# Generated at 2022-06-17 06:20:24.161847
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:20:35.102342
# Unit test for function split_args

# Generated at 2022-06-17 06:20:44.502194
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e=') == {'a': 'b', 'c': 'd', 'e': ''}
    assert parse_kv('a=b c=d e= f=g') == {'a': 'b', 'c': 'd', 'e': '', 'f': 'g'}

# Generated at 2022-06-17 06:21:03.151597
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv(u'foo=bar baz=qux=quux') == {u'foo': u'bar', u'baz': u'qux=quux'}

# Generated at 2022-06-17 06:21:07.050788
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:21:19.862721
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:21:34.560312
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar']

# Generated at 2022-06-17 06:21:45.996323
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar') == [u'a=b', u'c="foo bar']
    assert split_args(u'a=b c="foo bar\\') == [u'a=b', u'c="foo bar\\']
    assert split_args(u'a=b c="foo bar\\"') == [u'a=b', u'c="foo bar\\"']
    assert split_args(u'a=b c="foo bar"\\') == [u'a=b', u'c="foo bar"\\']

# Generated at 2022-06-17 06:21:54.190260
# Unit test for function split_args
def test_split_args():
    # Test for simple args
    assert split_args("a=b c=d") == ["a=b", "c=d"]

    # Test for args with quotes
    assert split_args("a=b c='foo bar'") == ["a=b", "c='foo bar'"]

    # Test for args with double quotes
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test for args with escaped quotes
    assert split_args('a=b c="foo \"bar\""') == ['a=b', 'c="foo \"bar\""']

    # Test for args with escaped double quotes
    assert split_args("a=b c='foo \"bar\"'") == ["a=b", "c='foo \"bar\"'"]

    # Test for args with escaped

# Generated at 2022-06-17 06:22:01.142047
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs', u'_raw_params': u'foo=bar baz=qux spam=eggs'}

# Generated at 2022-06-17 06:22:11.582852
# Unit test for function split_args
def test_split_args():
    # Test for a simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test for a case with a jinja2 block
    assert split_args('a=b c="foo {{ bar }}"') == ['a=b', 'c="foo {{ bar }}"']

    # Test for a case with a jinja2 block and a newline
    assert split_args('a=b c="foo {{ bar }}"\nd=e') == ['a=b', 'c="foo {{ bar }}"', 'd=e']

    # Test for a case with a jinja2 block and a newline and a line continuation

# Generated at 2022-06-17 06:22:21.843102
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c=\"foo bar\"") == [u'a=b', u'c="foo bar"']
    assert split_args(u"a=b c=\"foo bar\" d={{ foo }}") == [u'a=b', u'c="foo bar"', u'd={{ foo }}']
    assert split_args(u"a=b c=\"foo bar\" d={{ foo }} e=\"{{ bar }}\"") == [u'a=b', u'c="foo bar"', u'd={{ foo }}', u'e="{{ bar }}"']

# Generated at 2022-06-17 06:22:31.207436
# Unit test for function split_args
def test_split_args():
    def _test_split_args(args, expected):
        result = split_args(args)
        assert result == expected, "Expected '%s', got '%s'" % (expected, result)

    _test_split_args("a=b c='foo bar'", ['a=b', "c='foo bar'"])
    _test_split_args("a=b c=\"foo bar\"", ['a=b', 'c="foo bar"'])
    _test_split_args("a=b c=\"foo bar\" d='foo bar'", ['a=b', 'c="foo bar"', "d='foo bar'"])