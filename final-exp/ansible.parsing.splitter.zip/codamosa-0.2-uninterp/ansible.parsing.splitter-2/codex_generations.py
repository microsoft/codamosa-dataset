

# Generated at 2022-06-17 06:13:01.909109
# Unit test for function split_args

# Generated at 2022-06-17 06:13:08.596762
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:13:13.950713
# Unit test for function split_args
def test_split_args():
    # Test simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test simple case with newlines
    assert split_args('a=b\nc="foo bar"') == ['a=b', 'c="foo bar"']

    # Test simple case with newlines and escaped newlines
    assert split_args('a=b\nc="foo\\\nbar"') == ['a=b', 'c="foo\\\nbar"']

    # Test simple case with newlines and escaped newlines
    assert split_args('a=b\nc="foo\\\nbar"') == ['a=b', 'c="foo\\\nbar"']

    # Test simple case with newlines and escaped newlines

# Generated at 2022-06-17 06:13:24.820369
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g=h') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g=h']

# Generated at 2022-06-17 06:13:39.463407
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:13:48.572817
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:14:02.428988
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:14:10.435497
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:14:20.407831
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd="{{ foo }}"']
    assert split_args('a=b c="foo bar" d="{{ foo }}" e="{% foo %}"') == ['a=b', 'c="foo bar"', 'd="{{ foo }}"', 'e="{% foo %}"']

# Generated at 2022-06-17 06:14:30.684937
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar bar=baz') == {u'foo': u'bar', u'bar': u'baz'}
    assert parse_kv('foo=bar bar=baz baz=') == {u'foo': u'bar', u'bar': u'baz', u'baz': u''}
    assert parse_kv('foo=bar bar=baz baz= ') == {u'foo': u'bar', u'bar': u'baz', u'baz': u''}
    assert parse_kv('foo=bar bar=baz baz=  ') == {u'foo': u'bar', u'bar': u'baz', u'baz': u''}

# Generated at 2022-06-17 06:14:51.570181
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:59.440146
# Unit test for function split_args

# Generated at 2022-06-17 06:15:04.718980
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:15:17.398100
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:15:24.052599
# Unit test for function split_args

# Generated at 2022-06-17 06:15:36.760069
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:15:49.984050
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\\"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar\\" d=e') == ['a=b', 'c="foo bar"', 'd=e']
    assert split_args('a=b c="foo bar\\" d=e\\') == ['a=b', 'c="foo bar"', 'd=e\\']

# Generated at 2022-06-17 06:15:58.851559
# Unit test for function split_args
def test_split_args():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    # Test cases

# Generated at 2022-06-17 06:16:11.196410
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar baz=quux") == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv("foo=bar baz=quux", check_raw=True) == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv("foo=bar baz=quux", check_raw=True) == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv("foo=bar baz=quux", check_raw=True) == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv("foo=bar baz=quux", check_raw=True) == {'foo': 'bar', 'baz': 'quux'}
    assert parse_k

# Generated at 2022-06-17 06:16:20.801502
# Unit test for function split_args

# Generated at 2022-06-17 06:16:48.927174
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:03.406469
# Unit test for function split_args
def test_split_args():
    # Test a simple case
    assert split_args("a=b c=d") == ["a=b", "c=d"]

    # Test a case with a quoted string
    assert split_args("a=b c='d e'") == ["a=b", "c='d e'"]

    # Test a case with a quoted string with spaces
    assert split_args("a=b c='d e f'") == ["a=b", "c='d e f'"]

    # Test a case with a quoted string with spaces and a newline
    assert split_args("a=b c='d e f'\n") == ["a=b", "c='d e f'\n"]

    # Test a case with a quoted string with spaces and a newline and a space

# Generated at 2022-06-17 06:17:09.648041
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:17:15.424407
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''a=b c="foo bar"'''
    expected = ['a=b', 'c="foo bar"']
    assert split_args(args) == expected

    # Test case 2
    args = '''a=b c="foo bar" d="{{ foo }}"'''
    expected = ['a=b', 'c="foo bar"', 'd="{{ foo }}"']
    assert split_args(args) == expected

    # Test case 3
    args = '''a=b c="foo bar" d="{{ foo }}" e="{% if foo %}bar{% endif %}"'''
    expected = ['a=b', 'c="foo bar"', 'd="{{ foo }}"', 'e="{% if foo %}bar{% endif %}"']
    assert split_args

# Generated at 2022-06-17 06:17:27.190599
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:33.919573
# Unit test for function split_args
def test_split_args():
    # Test that split_args() returns the same list as shlex.split()
    # when given a string that does not contain any jinja2 blocks
    # or quotes.
    import shlex
    test_string = "a=b c='foo bar' d=\"foo bar\" e={{ foo }} f={{ foo }} g={{ foo }} h={{ foo }} i={{ foo }} j={{ foo }} k={{ foo }} l={{ foo }} m={{ foo }} n={{ foo }} o={{ foo }} p={{ foo }} q={{ foo }} r={{ foo }} s={{ foo }} t={{ foo }} u={{ foo }} v={{ foo }} w={{ foo }} x={{ foo }} y={{ foo }} z={{ foo }}"
    assert split_args(test_string) == shlex.split(test_string)



# Generated at 2022-06-17 06:17:47.862929
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:17:58.652623
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f={{ foo }}']

# Generated at 2022-06-17 06:18:04.267272
# Unit test for function split_args
def test_split_args():
    '''
    Test the split_args function.
    '''
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    # Test cases are a tuple of (input, expected output)

# Generated at 2022-06-17 06:18:12.498194
# Unit test for function parse_kv
def test_parse_kv():
    # Test basic functionality
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=False) == {'foo': 'bar', 'baz': 'qux'}

    # Test that escaped equals are treated as part of the value
    assert parse_kv('foo=bar\\=baz') == {'foo': 'bar=baz'}
    assert parse_kv('foo=bar\\=baz', check_raw=True) == {'foo': 'bar=baz'}
    assert parse

# Generated at 2022-06-17 06:18:29.689889
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:18:37.520394
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}


# Generated at 2022-06-17 06:18:42.847821
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=g') == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv(u'a=b c="d e" f=g', check_raw=True) == {u'a': u'b', u'c': u'd e', u'f': u'g', u'_raw_params': u'a=b c="d e" f=g'}

# Generated at 2022-06-17 06:18:52.552491
# Unit test for function split_args

# Generated at 2022-06-17 06:19:02.991311
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:19:11.306320
# Unit test for function split_args

# Generated at 2022-06-17 06:19:19.151387
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ foo }} f=\"{{ foo }}\"") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ foo }}', 'f="{{ foo }}"']

# Generated at 2022-06-17 06:19:27.876911
# Unit test for function split_args
def test_split_args():
    assert split_args(u'foo bar') == [u'foo', u'bar']
    assert split_args(u'foo bar baz') == [u'foo', u'bar', u'baz']
    assert split_args(u'foo "bar baz"') == [u'foo', u'"bar baz"']
    assert split_args(u'foo "bar baz" qux') == [u'foo', u'"bar baz"', u'qux']
    assert split_args(u'foo "bar baz" qux "quux"') == [u'foo', u'"bar baz"', u'qux', u'"quux"']

# Generated at 2022-06-17 06:19:37.034979
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ foo }} f={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ foo }}', 'f={{ foo }}']

# Generated at 2022-06-17 06:19:50.244982
# Unit test for function split_args
def test_split_args():
    # Test a simple case
    args = "a=b c='foo bar'"
    assert split_args(args) == ['a=b', "c='foo bar'"]

    # Test a case with a jinja2 block
    args = "a=b c='foo {{ bar }}'"
    assert split_args(args) == ['a=b', "c='foo {{ bar }}'"]

    # Test a case with a jinja2 block and a newline
    args = "a=b c='foo {{ bar }}\n'"
    assert split_args(args) == ['a=b', "c='foo {{ bar }}\n'"]

    # Test a case with a jinja2 block and a newline and a line continuation
    args = "a=b c='foo {{ bar }}\n\\'"

# Generated at 2022-06-17 06:20:09.102629
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3 d') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3 d', check_raw=True) == {'a': '1', 'b': '2', 'c': '3', '_raw_params': 'd'}

# Generated at 2022-06-17 06:20:22.779696
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:20:30.823935
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:20:42.354120
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a=1 b=2 c') == {'a': '1', 'b': '2', '_raw_params': 'c'}
    assert parse_kv('a=1 b=2 c d') == {'a': '1', 'b': '2', '_raw_params': 'c d'}
    assert parse_kv('a=1 b=2 c d e=3') == {'a': '1', 'b': '2', '_raw_params': 'c d e=3'}

# Generated at 2022-06-17 06:20:51.435437
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e=f g=h', check_raw=True) == {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}

# Generated at 2022-06-17 06:21:00.217442
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:21:14.494759
# Unit test for function split_args
def test_split_args():
    def assert_split_args(args, expected):
        actual = split_args(args)
        assert actual == expected, "Expected: %s, Actual: %s" % (expected, actual)

    assert_split_args("a=b c=\"foo bar\"", ['a=b', 'c="foo bar"'])
    assert_split_args("a=b c=\"foo bar\"\nd=e f=\"g h\"", ['a=b', 'c="foo bar"', 'd=e', 'f="g h"'])
    assert_split_args("a=b c=\"foo bar\"\nd=e f=\"g h\"\n", ['a=b', 'c="foo bar"', 'd=e', 'f="g h"', ''])

# Generated at 2022-06-17 06:21:25.031134
# Unit test for function split_args
def test_split_args():
    # Test for a simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test for a case with a jinja2 block
    assert split_args('a=b c="foo {{ bar }}"') == ['a=b', 'c="foo {{ bar }}"']

    # Test for a case with a jinja2 block and quotes
    assert split_args('a=b c="foo {{ bar }}" d="{{ foo }} bar"') == ['a=b', 'c="foo {{ bar }}"', 'd="{{ foo }} bar"']

    # Test for a case with a jinja2 block and quotes and a newline

# Generated at 2022-06-17 06:21:37.581703
# Unit test for function split_args

# Generated at 2022-06-17 06:21:47.366777
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:22:02.699796
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:22:11.703736
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=\'g h\'') == {'a': 'b', 'c': 'd e', 'f': 'g h'}
    assert parse_kv('a=b c="d e" f=\'g h\' i') == {'a': 'b', 'c': 'd e', 'f': 'g h', '_raw_params': 'i'}
    assert parse_kv('a=b c="d e" f=\'g h\' i j=k') == {'a': 'b', 'c': 'd e', 'f': 'g h', '_raw_params': 'i j=k'}

# Generated at 2022-06-17 06:22:21.985167
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv("a=1 b=2 c") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c'}
    assert parse_kv("a=1 b=2 c d") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c d'}
    assert parse_kv("a=1 b=2 c='d e'") == {u'a': u'1', u'b': u'2', u'c': u'd e', u'_raw_params': u"c='d e'"}

# Generated at 2022-06-17 06:22:27.166768
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f="g=h"') == {u'a': u'b', u'c': u'd e', u'f': u'g=h'}
    assert parse_kv(u'a=b c="d e" f="g=h"', check_raw=True) == {u'a': u'b', u'c': u'd e', u'f': u'g=h', u'_raw_params': u'a=b c="d e" f="g=h"'}