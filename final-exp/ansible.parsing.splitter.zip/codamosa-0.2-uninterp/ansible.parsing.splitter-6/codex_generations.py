

# Generated at 2022-06-17 06:14:04.583604
# Unit test for function split_args

# Generated at 2022-06-17 06:14:18.764663
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e f=g') == {'a': 'b', 'c': 'd', '_raw_params': 'e f=g'}
    assert parse_kv('a=b c=d e f=g', check_raw=True) == {'a': 'b', 'c': 'd', 'f': 'g', '_raw_params': 'e'}

# Generated at 2022-06-17 06:14:27.391050
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:14:31.975639
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {'foo': 'bar'}
    assert parse_kv("foo=bar baz=qux") == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv("foo=bar baz=qux xyzzy=plugh") == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv("foo='bar baz'") == {'foo': 'bar baz'}
    assert parse_kv("foo='bar baz' xyzzy=plugh") == {'foo': 'bar baz', 'xyzzy': 'plugh'}

# Generated at 2022-06-17 06:14:39.777569
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:53.916968
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}


# Generated at 2022-06-17 06:15:01.541783
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{foo}}") == ['a=b', 'c="foo bar"', 'd={{foo}}']
    assert split_args("a=b c=\"foo bar\" d={{foo}} e=\"{{bar}}\"") == ['a=b', 'c="foo bar"', 'd={{foo}}', 'e="{{bar}}"']
    assert split_args("a=b c=\"foo bar\" d={{foo}} e=\"{{bar}}\" f={{baz}}") == ['a=b', 'c="foo bar"', 'd={{foo}}', 'e="{{bar}}"', 'f={{baz}}']
    assert split_args

# Generated at 2022-06-17 06:15:08.227748
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:15:16.296194
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''
    a=b c="foo bar"
    '''
    expected = ['a=b', 'c="foo bar"']
    assert split_args(args) == expected

    # Test case 2
    args = '''
    a=b c="foo bar"
    d=e f="foo bar"
    '''
    expected = ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"']
    assert split_args(args) == expected

    # Test case 3
    args = '''
    a=b c="foo bar"
    d=e f="foo bar"
    g=h i="foo bar"
    '''

# Generated at 2022-06-17 06:15:26.788423
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f="g h"') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f="g h" i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f="g h" i j') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j'}

# Generated at 2022-06-17 06:15:50.274960
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=quux') == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv('foo=bar baz=quux spam=eggs') == {'foo': 'bar', 'baz': 'quux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=quux spam=eggs') == {'foo': 'bar', 'baz': 'quux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=quux spam=eggs') == {'foo': 'bar', 'baz': 'quux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:15:58.906621
# Unit test for function split_args

# Generated at 2022-06-17 06:16:03.172996
# Unit test for function parse_kv
def test_parse_kv():
    # Test with no args
    assert parse_kv(None) == {}
    # Test with empty args
    assert parse_kv('') == {}
    # Test with single arg
    assert parse_kv('foo') == {'_raw_params': 'foo'}
    # Test with multiple args
    assert parse_kv('foo bar') == {'_raw_params': 'foo bar'}
    # Test with single kv pair
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    # Test with multiple kv pairs
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    # Test with multiple kv pairs and args

# Generated at 2022-06-17 06:16:13.107838
# Unit test for function split_args
def test_split_args():
    # Test for a simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test for a case with a newline
    assert split_args('a=b\nc="foo bar"') == ['a=b', 'c="foo bar"']

    # Test for a case with a newline and a space
    assert split_args('a=b\n c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test for a case with a newline and a space and a backslash
    assert split_args('a=b\n c="foo bar"\\') == ['a=b', 'c="foo bar"\\']

    # Test for a case with a newline and a space and a backslash and a newline
   

# Generated at 2022-06-17 06:16:23.760507
# Unit test for function split_args

# Generated at 2022-06-17 06:16:35.107979
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:16:48.740046
# Unit test for function split_args

# Generated at 2022-06-17 06:17:03.297652
# Unit test for function split_args
def test_split_args():
    # Test for unbalanced quotes
    try:
        split_args('foo "bar')
        assert False
    except AnsibleParserError:
        pass

    # Test for unbalanced jinja2 blocks
    try:
        split_args('foo {{ bar')
        assert False
    except AnsibleParserError:
        pass

    # Test for unbalanced jinja2 blocks
    try:
        split_args('foo {% bar')
        assert False
    except AnsibleParserError:
        pass

    # Test for unbalanced jinja2 blocks
    try:
        split_args('foo {# bar')
        assert False
    except AnsibleParserError:
        pass

    # Test for unbalanced jinja2 blocks

# Generated at 2022-06-17 06:17:12.942577
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=g') == {'a': 'b', 'c': 'd e', 'f': 'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {'a': 'b', 'c': 'd e', 'f': 'g', '_raw_params': 'a=b c="d e" f=g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=False) == {'a': 'b', 'c': 'd e', 'f': 'g'}

# Generated at 2022-06-17 06:17:27.694576
# Unit test for function split_args

# Generated at 2022-06-17 06:17:46.799743
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:51.116396
# Unit test for function split_args

# Generated at 2022-06-17 06:18:06.143620
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c=\"foo bar\"") == [u"a=b", u"c=\"foo bar\""]
    assert split_args(u"a=b c=\"foo bar\" d=\"{{ foo }}\"") == [u"a=b", u"c=\"foo bar\"", u"d=\"{{ foo }}\""]
    assert split_args(u"a=b c=\"foo bar\" d=\"{{ foo }}\" e=\"{{ bar }}\"") == [u"a=b", u"c=\"foo bar\"", u"d=\"{{ foo }}\"", u"e=\"{{ bar }}\""]

# Generated at 2022-06-17 06:18:20.413247
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.splitter import parse_kv

    # Test cases

# Generated at 2022-06-17 06:18:26.982424
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a=1 b=2 c') == {'a': '1', 'b': '2', '_raw_params': 'c'}
    assert parse_kv('a=1 b=2 c d') == {'a': '1', 'b': '2', '_raw_params': 'c d'}
    assert parse_kv('a=1 b=2 c d e=3') == {'a': '1', 'b': '2', '_raw_params': 'c d e=3'}

# Generated at 2022-06-17 06:18:40.451465
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'3'}
   

# Generated at 2022-06-17 06:18:51.965292
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux=quux') == {u'foo': u'bar', u'baz': u'qux=quux'}
    assert parse_kv('foo=bar baz=qux=quux=corge') == {u'foo': u'bar', u'baz': u'qux=quux=corge'}

# Generated at 2022-06-17 06:19:02.566739
# Unit test for function parse_kv
def test_parse_kv():
    # Test for empty string
    assert parse_kv('') == {}

    # Test for empty string with check_raw
    assert parse_kv('', check_raw=True) == {}

    # Test for simple key value pair
    assert parse_kv('key=value') == {'key': 'value'}

    # Test for simple key value pair with check_raw
    assert parse_kv('key=value', check_raw=True) == {'key': 'value'}

    # Test for simple key value pair with spaces
    assert parse_kv('key = value') == {'key': 'value'}

    # Test for simple key value pair with spaces with check_raw
    assert parse_kv('key = value', check_raw=True) == {'key': 'value'}

    # Test for simple key value pair

# Generated at 2022-06-17 06:19:14.702784
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:19:26.590391
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f="g h"') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f="g h" i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f="g h" i', check_raw=False) == {u'a': u'b', u'c': u'd e', u'f': u'g h'}

# Generated at 2022-06-17 06:19:43.841495
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e=f', check_raw=True) == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert parse_kv('a=b c=d e=f', check_raw=False) == {'a': 'b', 'c': 'd', 'e': 'f'}

# Generated at 2022-06-17 06:19:53.686944
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {u'foo': u'bar'}
    assert parse_kv("foo=bar baz=qux") == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv("foo=bar baz=qux baz=quux") == {u'foo': u'bar', u'baz': u'quux'}
    assert parse_kv("foo=bar baz=qux baz=quux baz=quuz") == {u'foo': u'bar', u'baz': u'quuz'}

# Generated at 2022-06-17 06:20:07.489644
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=\'g h\'') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i j=k') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j=k'}

# Generated at 2022-06-17 06:20:13.461855
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:20:25.985326
# Unit test for function split_args
def test_split_args():
    # Test 1: Simple test
    test_args = "a=b c='foo bar'"
    expected_result = ['a=b', "c='foo bar'"]
    assert split_args(test_args) == expected_result

    # Test 2: Test with newlines
    test_args = "a=b c='foo bar'\nd=e f='foo bar'"
    expected_result = ['a=b', "c='foo bar'", 'd=e', "f='foo bar'"]
    assert split_args(test_args) == expected_result

    # Test 3: Test with jinja2 blocks
    test_args = "a=b c='foo bar'\nd=e f='foo bar'\n{{ g=h i='foo bar' }}"

# Generated at 2022-06-17 06:20:35.221789
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test that we can handle newlines
    assert split_args('a=b \\\nc="foo bar"') == ['a=b', 'c="foo bar"']

    # Test that we can handle newlines in quotes
    assert split_args('a=b \\\nc="foo\\\nbar"') == ['a=b', 'c="foo\\\nbar"']

    # Test that we can handle newlines in jinja2 blocks
    assert split_args('a=b \\\nc="foo{{\\\nbar}}"') == ['a=b', 'c="foo{{\\\nbar}}"']

    # Test that we can handle newlines in jinja2 blocks in quotes

# Generated at 2022-06-17 06:20:43.127773
# Unit test for function split_args

# Generated at 2022-06-17 06:20:56.883093
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux', '_raw_params': 'foo=bar baz=qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=False) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux', '_raw_params': 'foo=bar baz=qux'}

# Generated at 2022-06-17 06:21:08.137738
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar" d="foo bar') == ['a=b', 'c="foo bar"', 'd="foo bar']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']

# Generated at 2022-06-17 06:21:20.329580
# Unit test for function split_args
def test_split_args():
    def _test_split_args(args, expected):
        actual = split_args(args)
        assert actual == expected, 'Expected: %s, got: %s' % (expected, actual)

    _test_split_args('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _test_split_args('a=b c="foo bar" d={{ foo }}', ['a=b', 'c="foo bar"', 'd={{ foo }}'])
    _test_split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}"', ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"'])

# Generated at 2022-06-17 06:21:37.977131
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar baz=qux") == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv("foo='bar baz'") == {u'foo': u'bar baz'}
    assert parse_kv("foo=\"bar baz\"") == {u'foo': u'bar baz'}
    assert parse_kv("foo=bar baz='qux quux'") == {u'foo': u'bar', u'baz': u'qux quux'}
    assert parse_kv("foo=bar baz=\"qux quux\"") == {u'foo': u'bar', u'baz': u'qux quux'}

# Generated at 2022-06-17 06:21:47.393429
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:21:54.869858
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:22:04.416410
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-17 06:22:13.875564
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:22:24.875372
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:22:34.524595
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv