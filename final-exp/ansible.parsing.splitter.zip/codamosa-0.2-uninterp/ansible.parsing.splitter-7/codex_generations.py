

# Generated at 2022-06-17 06:13:21.351615
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:13:30.377912
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=1 b=2 c=3") == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv(u"a=1 b=2 c=3", check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv(u"a=1 b=2 c=3", check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'3'}

# Generated at 2022-06-17 06:13:38.868501
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:13:48.313010
# Unit test for function split_args

# Generated at 2022-06-17 06:14:02.171703
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:10.210507
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:14.980671
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f={{ foo }}']

# Generated at 2022-06-17 06:14:23.394383
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c='foo bar' d=\"foo bar\"") == ['a=b', "c='foo bar'", 'd="foo bar"']
    assert split_args("a=b c='foo bar' d=\"foo bar\" e='foo bar'") == ['a=b', "c='foo bar'", 'd="foo bar"', "e='foo bar'"]
    assert split_args("a=b c='foo bar' d=\"foo bar\" e='foo bar' f=\"foo bar\"") == ['a=b', "c='foo bar'", 'd="foo bar"', "e='foo bar'", 'f="foo bar"']

# Generated at 2022-06-17 06:14:33.306924
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e f') == {'a': 'b', 'c': 'd', '_raw_params': 'e f'}
    assert parse_k

# Generated at 2022-06-17 06:14:40.669195
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:15:05.475035
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-17 06:15:17.800342
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:15:24.438737
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo="bar"') == {u'foo': u'bar'}
    assert parse_kv(u'foo="bar baz"') == {u'foo': u'bar baz'}
    assert parse_kv(u'foo="bar baz" spam=eggs') == {u'foo': u'bar baz', u'spam': u'eggs'}
    assert parse_kv(u'foo="bar baz" spam=eggs') == {u'foo': u'bar baz', u'spam': u'eggs'}

# Generated at 2022-06-17 06:15:37.141880
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}" f="{{ foo }} bar"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"', 'f="{{ foo }} bar"']
    assert split

# Generated at 2022-06-17 06:15:50.388314
# Unit test for function split_args
def test_split_args():
    # Test 1
    args = 'a=b c="foo bar"'
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Test 2
    args = 'a=b c="foo bar" d=\'foo bar\''
    assert split_args(args) == ['a=b', 'c="foo bar"', 'd=\'foo bar\'']

    # Test 3
    args = 'a=b c="foo bar" d=\'foo bar\' e="foo bar"'
    assert split_args(args) == ['a=b', 'c="foo bar"', 'd=\'foo bar\'', 'e="foo bar"']

    # Test 4
    args = 'a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\''
   

# Generated at 2022-06-17 06:15:58.957268
# Unit test for function split_args

# Generated at 2022-06-17 06:16:08.649798
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test that we can split on newlines
    assert split_args('a=b\nc="foo bar"') == ['a=b\n', 'c="foo bar"']

    # Test that we can split on escaped newlines
    assert split_args('a=b\\\nc="foo bar"') == ['a=b\\\n', 'c="foo bar"']

    # Test that we can split on escaped newlines
    assert split_args('a=b\\\nc="foo bar"') == ['a=b\\\n', 'c="foo bar"']

    # Test that we can split on escaped newlines
    assert split_args('a=b\\\nc="foo bar"')

# Generated at 2022-06-17 06:16:14.520021
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:16:22.517066
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:16:34.053235
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f="g h"') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f="g h" i=j') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'i': u'j'}
    assert parse_kv(u'a=b c="d e" f="g h" i=j k=l') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'i': u'j', u'k': u'l'}

# Generated at 2022-06-17 06:16:52.431595
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar baz=qux") == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv("foo=bar baz=qux", check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv("foo=bar baz=qux", check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv("foo=bar baz=qux _raw_params=blah") == {'foo': 'bar', 'baz': 'qux', '_raw_params': 'blah'}

# Generated at 2022-06-17 06:17:02.511954
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:17:12.883046
# Unit test for function split_args

# Generated at 2022-06-17 06:17:26.540734
# Unit test for function split_args

# Generated at 2022-06-17 06:17:33.376247
# Unit test for function split_args

# Generated at 2022-06-17 06:17:43.114474
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:52.896086
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:57.093000
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv("a=1 b=2 c=3") == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv("a=1 b=2 c=3 d=4") == {u'a': u'1', u'b': u'2', u'c': u'3', u'd': u'4'}
    assert parse_kv("a=1 b=2 c=3 d=4 e=5") == {u'a': u'1', u'b': u'2', u'c': u'3', u'd': u'4', u'e': u'5'}

# Generated at 2022-06-17 06:18:09.642237
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:18:19.636452
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:18:40.452422
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    assert split_args(args) == expected

    # Test case 2
    args = 'a=b c="foo bar" d="{{ foo }}"'
    expected = ['a=b', 'c="foo bar"', 'd="{{ foo }}"']
    assert split_args(args) == expected

    # Test case 3
    args = 'a=b c="foo bar" d="{{ foo }}" e="{{ foo }} bar"'
    expected = ['a=b', 'c="foo bar"', 'd="{{ foo }}"', 'e="{{ foo }} bar"']
    assert split_args(args) == expected

    # Test case 4

# Generated at 2022-06-17 06:18:51.968194
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test line continuation
    assert split_args('a=b \\\nc="foo bar"') == ['a=b', 'c="foo bar"']

    # Test jinja2 blocks
    assert split_args('a=b c="foo {{ bar }}"') == ['a=b', 'c="foo {{ bar }}"']
    assert split_args('a=b c="foo {{ bar }}" d="{{ foo }} bar"') == ['a=b', 'c="foo {{ bar }}"', 'd="{{ foo }} bar"']

# Generated at 2022-06-17 06:19:02.961171
# Unit test for function split_args

# Generated at 2022-06-17 06:19:11.276199
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:19:19.128409
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e=f', check_raw=True) == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert parse_kv('a=b c=d e=f', check_raw=False) == {'a': 'b', 'c': 'd', 'e': 'f'}

# Generated at 2022-06-17 06:19:31.845435
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:19:43.204993
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:19:53.451979
# Unit test for function split_args

# Generated at 2022-06-17 06:20:07.434068
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux', '_raw_params': 'foo=bar baz=qux'}
    assert parse_kv('foo=bar baz=qux=quux') == {'foo': 'bar', 'baz': 'qux=quux'}
    assert parse_kv('foo=bar baz=qux=quux', check_raw=True) == {'foo': 'bar', 'baz': 'qux=quux', '_raw_params': 'foo=bar baz=qux=quux'}
    assert parse_

# Generated at 2022-06-17 06:20:12.761433
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e="foo bar" f="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"', 'f="foo bar"']

# Generated at 2022-06-17 06:20:35.193796
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=g') == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {u'a': u'b', u'c': u'd e', u'f': u'g', u'_raw_params': u'a=b c="d e" f=g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=False) == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True)

# Generated at 2022-06-17 06:20:44.543844
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=g') == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv(u'a=b c="d e" f=g', check_raw=True) == {u'a': u'b', u'c': u'd e', u'f': u'g', u'_raw_params': u'a=b c="d e" f=g'}
    assert parse_kv(u'a=b c="d e" f=g', check_raw=False) == {u'a': u'b', u'c': u'd e', u'f': u'g'}

# Generated at 2022-06-17 06:20:58.323967
# Unit test for function split_args

# Generated at 2022-06-17 06:21:08.254144
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f="{{ foo }} bar"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f="{{ foo }} bar"']
    assert split

# Generated at 2022-06-17 06:21:15.769588
# Unit test for function split_args

# Generated at 2022-06-17 06:21:26.305424
# Unit test for function split_args
def test_split_args():
    # Test 1
    args = '''
    a=b c="foo bar"
    '''
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2
    args = '''
    a=b c="foo bar"
    d=e f="foo bar"
    '''
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"']

    # Test 3
    args = '''
    a=b c="foo bar"
    d=e f="foo bar"
    '''
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"']

# Generated at 2022-06-17 06:21:38.137092
# Unit test for function split_args

# Generated at 2022-06-17 06:21:47.418775
# Unit test for function split_args

# Generated at 2022-06-17 06:21:57.885263
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:22:03.700448
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = "a=b c=\"foo bar\""
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test case 2
    args = "a=b c=\"foo bar\"\nd=e f=\"foo bar\""
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"']

    # Test case 3
    args = "a=b c=\"foo bar\"\nd=e f=\"foo bar\"\ng=h i=\"foo bar\""
    params = split_args(args)

# Generated at 2022-06-17 06:22:31.207450
# Unit test for function split_args