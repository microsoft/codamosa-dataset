

# Generated at 2022-06-17 06:13:26.388384
# Unit test for function split_args
def test_split_args():
    # Test 1: Simple case
    args = "a=b c=\"foo bar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 2: Simple case with newlines
    args = "a=b\nc=\"foo bar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 3: Simple case with newlines and spaces
    args = "a=b\n c=\"foo bar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 4: Simple case with newlines and spaces
    args = "a=b\n c=\"foo bar\""
    result = split_args(args)

# Generated at 2022-06-17 06:13:40.506866
# Unit test for function split_args

# Generated at 2022-06-17 06:13:49.197537
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:03.006905
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:08.824338
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:19.381686
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected

    # Test case 2
    args = 'a=b c="foo bar" d=\'foo bar\''
    expected = ['a=b', 'c="foo bar"', 'd=\'foo bar\'']
    result = split_args(args)
    assert result == expected

    # Test case 3
    args = 'a=b c="foo bar" d=\'foo bar\' e="foo bar'
    expected = ['a=b', 'c="foo bar"', 'd=\'foo bar\'', 'e="foo bar']
    result = split_args(args)
    assert result == expected

    # Test case 4

# Generated at 2022-06-17 06:14:26.714866
# Unit test for function split_args

# Generated at 2022-06-17 06:14:35.448308
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:14:42.729501
# Unit test for function split_args

# Generated at 2022-06-17 06:14:56.580488
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:15:18.095129
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:15:27.555553
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:15:34.830849
# Unit test for function split_args

# Generated at 2022-06-17 06:15:47.976788
# Unit test for function split_args

# Generated at 2022-06-17 06:15:57.664138
# Unit test for function split_args

# Generated at 2022-06-17 06:16:02.450282
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo="bar"') == {u'foo': u'bar'}
    assert parse_kv('foo="bar baz"') == {u'foo': u'bar baz'}
    assert parse_kv('foo="bar baz" spam=eggs') == {u'foo': u'bar baz', u'spam': u'eggs'}
    assert parse_kv('foo="bar baz" spam=eggs') == {u'foo': u'bar baz', u'spam': u'eggs'}

# Generated at 2022-06-17 06:16:13.263499
# Unit test for function split_args

# Generated at 2022-06-17 06:16:17.275241
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']
    assert split_args('a=b c="foo bar" d=\\') == ['a=b', 'c="foo bar"', 'd=\\']
    assert split_args('a=b c="foo bar" d=\\\n') == ['a=b', 'c="foo bar"', 'd=\\\n']
    assert split_args('a=b c="foo bar" d=\\\ne=f') == ['a=b', 'c="foo bar"', 'd=\\\n', 'e=f']

# Generated at 2022-06-17 06:16:30.017937
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv(u"a=1 b=2 c=3") == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv(u"a=1 b=2 c=3 d=4") == {u'a': u'1', u'b': u'2', u'c': u'3', u'd': u'4'}

# Generated at 2022-06-17 06:16:44.531489
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:17:06.694146
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:17:13.733383
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:26.597739
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=False) == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux=quux') == {u'foo': u'bar', u'baz': u'qux=quux'}
    assert parse

# Generated at 2022-06-17 06:17:33.428511
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:17:47.668811
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e=\"{{ bar }}\"") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e=\"{{ bar }}\" f=\"{{ foo }} {{ bar }}\"") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"', 'f="{{ foo }} {{ bar }}"']

# Generated at 2022-06-17 06:17:58.551377
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'e'}

# Generated at 2022-06-17 06:18:10.339366
# Unit test for function split_args
def test_split_args():
    # Test that the function can split args on whitespace
    assert split_args("a=b c=d") == ['a=b', 'c=d']

    # Test that the function can split args on newlines
    assert split_args("a=b\nc=d") == ['a=b', 'c=d']

    # Test that the function can split args on newlines and whitespace
    assert split_args("a=b\nc=d e=f") == ['a=b', 'c=d', 'e=f']

    # Test that the function can split args on newlines and whitespace
    assert split_args("a=b\nc=d e=f\ng=h") == ['a=b', 'c=d', 'e=f', 'g=h']

    # Test that the function can split args on newlines and

# Generated at 2022-06-17 06:18:23.487037
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-17 06:18:33.922106
# Unit test for function split_args
def test_split_args():
    # Test for a simple case
    args = "a=b c='foo bar'"
    result = split_args(args)
    assert result == ['a=b', "c='foo bar'"]

    # Test for a simple case with spaces
    args = "a=b c='foo bar' d='foo bar'"
    result = split_args(args)
    assert result == ['a=b', "c='foo bar'", "d='foo bar'"]

    # Test for a simple case with spaces and newlines
    args = "a=b c='foo bar'\nd='foo bar'"
    result = split_args(args)
    assert result == ['a=b', "c='foo bar'\n", "d='foo bar'"]

    # Test for a simple case with spaces and newlines

# Generated at 2022-06-17 06:18:41.400810
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:18:55.374092
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:19:04.288679
# Unit test for function split_args
def test_split_args():
    # Test for unbalanced jinja2 blocks
    try:
        split_args("{{ foo }} {% bar %}")
        assert False
    except AnsibleParserError:
        pass

    # Test for unbalanced quotes
    try:
        split_args("'foo bar")
        assert False
    except AnsibleParserError:
        pass

    # Test for unbalanced quotes
    try:
        split_args("'foo bar' \"baz quux\"")
        assert False
    except AnsibleParserError:
        pass

    # Test for unbalanced quotes
    try:
        split_args("'foo bar' \"baz quux")
        assert False
    except AnsibleParserError:
        pass

    # Test for unbalanced quotes

# Generated at 2022-06-17 06:19:12.265986
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args("a=b c=\"foo bar\" d='foo bar' e=\"foo bar\"") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']

# Generated at 2022-06-17 06:19:25.683440
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:19:37.168961
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-17 06:19:50.360566
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f="{{ foo }} bar"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f="{{ foo }} bar"']
    assert split

# Generated at 2022-06-17 06:19:56.681566
# Unit test for function split_args
def test_split_args():
    # Test 1: simple test
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2: test with newlines
    args = 'a=b\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar"']

    # Test 3: test with newlines and line continuation
    args = 'a=b\nc="foo bar" \\\nd=e'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar" \\\n', 'd=e']

    # Test 4: test with newlines and line continuation

# Generated at 2022-06-17 06:20:03.084569
# Unit test for function split_args

# Generated at 2022-06-17 06:20:09.890897
# Unit test for function split_args

# Generated at 2022-06-17 06:20:23.622548
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:20:41.565304
# Unit test for function split_args

# Generated at 2022-06-17 06:20:48.436317
# Unit test for function split_args

# Generated at 2022-06-17 06:21:00.249206
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-17 06:21:14.549772
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e"') == {u'a': u'b', u'c': u'd e'}
    assert parse_kv(u"a='b c'") == {u'a': u'b c'}
    assert parse_kv(u"a='b c' d='e f'") == {u'a': u'b c', u'd': u'e f'}
    assert parse_kv(u"a='b c' d='e f' g") == {u'a': u'b c', u'd': u'e f', u'_raw_params': u'g'}

# Generated at 2022-06-17 06:21:25.021430
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d _raw_params=e=f") == {'a': 'b', 'c': 'd', '_raw_params': 'e=f'}

# Generated at 2022-06-17 06:21:37.581119
# Unit test for function split_args

# Generated at 2022-06-17 06:21:47.365343
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:21:54.848438
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:22:01.685555
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:22:11.646081
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=quux') == {u'foo': u'bar', u'baz': u'quux'}
    assert parse_kv(u'foo=bar baz=quux spam=eggs') == {u'foo': u'bar', u'baz': u'quux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=quux spam=eggs') == {u'foo': u'bar', u'baz': u'quux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:22:34.845396
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}