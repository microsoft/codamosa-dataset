

# Generated at 2022-06-17 06:13:25.472210
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e=f', check_raw=True) == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert parse_kv('a=b c=d e=f', check_raw=False) == {'a': 'b', 'c': 'd', 'e': 'f'}

# Generated at 2022-06-17 06:13:39.719633
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ e }}') == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}']
    assert split_args('a=b c="foo bar" d={{ e }} f="g {{ h }} i"') == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}', 'f="g {{ h }} i"']

# Generated at 2022-06-17 06:13:48.624497
# Unit test for function split_args

# Generated at 2022-06-17 06:14:02.430753
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-17 06:14:11.670946
# Unit test for function split_args

# Generated at 2022-06-17 06:14:20.547700
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''a=b c="foo bar"'''
    expected_result = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected_result

    # Test case 2
    args = '''a=b c="foo bar" d="{{ foo }}" e="{% foo %}" f="{# foo #}"'''
    expected_result = ['a=b', 'c="foo bar"', 'd="{{ foo }}"', 'e="{% foo %}"', 'f="{# foo #}"']
    result = split_args(args)
    assert result == expected_result

    # Test case 3

# Generated at 2022-06-17 06:14:30.768965
# Unit test for function split_args

# Generated at 2022-06-17 06:14:38.933206
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d e") == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}
    assert parse_kv("a=b c=d e", check_raw=True) == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}

# Generated at 2022-06-17 06:14:50.250255
# Unit test for function split_args

# Generated at 2022-06-17 06:15:00.046305
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:15:16.146613
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''a=b c="foo bar"'''
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Test case 2
    args = '''a=b c="foo bar" d="{{ foo }}"'''
    assert split_args(args) == ['a=b', 'c="foo bar"', 'd="{{ foo }}"']

    # Test case 3
    args = '''a=b c="foo bar" d="{{ foo }}" e="{{ foo }}" f="{{ foo }}"'''
    assert split_args(args) == ['a=b', 'c="foo bar"', 'd="{{ foo }}"', 'e="{{ foo }}"', 'f="{{ foo }}"']

    # Test case 4

# Generated at 2022-06-17 06:15:30.621207
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d e") == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}
    assert parse_kv("a=b c=d e=f g") == {u'a': u'b', u'c': u'd', u'e': u'f', u'_raw_params': u'g'}
    assert parse_kv("a=b c=d e=f g h=i") == {u'a': u'b', u'c': u'd', u'e': u'f', u'g': u'h=i'}

# Generated at 2022-06-17 06:15:38.983851
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-17 06:15:51.061864
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:15:59.098944
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar baz=quux") == {u'foo': u'bar', u'baz': u'quux'}
    assert parse_kv(u"foo=bar baz=quux", check_raw=True) == {u'foo': u'bar', u'baz': u'quux'}
    assert parse_kv(u"foo=bar baz=quux", check_raw=False) == {u'foo': u'bar', u'baz': u'quux'}
    assert parse_kv(u"foo=bar baz=quux", check_raw=True) == {u'foo': u'bar', u'baz': u'quux'}

# Generated at 2022-06-17 06:16:08.817350
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux=quux') == {u'foo': u'bar', u'baz': u'qux=quux'}
    assert parse_kv(u'foo=bar baz="qux=quux"') == {u'foo': u'bar', u'baz': u'qux=quux'}

# Generated at 2022-06-17 06:16:14.706862
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar') == [u'a=b', u'c="foo bar']
    assert split_args(u'a=b c="foo bar\\') == [u'a=b', u'c="foo bar\\']
    assert split_args(u'a=b c="foo bar\\"') == [u'a=b', u'c="foo bar\\"']
    assert split_args(u'a=b c="foo bar"\\') == [u'a=b', u'c="foo bar"\\']

# Generated at 2022-06-17 06:16:25.255953
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}" f={{ "{{ bar }}" }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"', 'f={{ "{{ bar }}" }}']

# Generated at 2022-06-17 06:16:36.008591
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:16:47.404528
# Unit test for function split_args

# Generated at 2022-06-17 06:17:10.231002
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {u'foo': u'bar'}
    assert parse_kv("foo=bar baz=qux") == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv("foo=bar baz=qux xyzzy=plugh") == {u'foo': u'bar', u'baz': u'qux', u'xyzzy': u'plugh'}
    assert parse_kv("foo=bar baz=qux xyzzy=plugh thud=grunt") == {u'foo': u'bar', u'baz': u'qux', u'xyzzy': u'plugh', u'thud': u'grunt'}

# Generated at 2022-06-17 06:17:24.800984
# Unit test for function split_args

# Generated at 2022-06-17 06:17:32.761532
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=g') == {'a': 'b', 'c': 'd e', 'f': 'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {'a': 'b', 'c': 'd e', 'f': 'g', '_raw_params': 'a=b c="d e" f=g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=False) == {'a': 'b', 'c': 'd e', 'f': 'g'}

# Generated at 2022-06-17 06:17:47.072233
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:17:53.320101
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f="{{ foo }} bar"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f="{{ foo }} bar"']
    assert split

# Generated at 2022-06-17 06:18:06.704033
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:18:21.143114
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:18:27.188252
# Unit test for function split_args
def test_split_args():
    # Test for single argument
    assert split_args("foo") == ["foo"]
    # Test for multiple arguments
    assert split_args("foo bar") == ["foo", "bar"]
    # Test for multiple arguments with quotes
    assert split_args("foo 'bar baz'") == ["foo", "'bar baz'"]
    # Test for multiple arguments with quotes and spaces
    assert split_args("foo 'bar baz' qux") == ["foo", "'bar baz'", "qux"]
    # Test for multiple arguments with quotes and spaces and newlines
    assert split_args("foo 'bar baz'\nqux") == ["foo", "'bar baz'\nqux"]
    # Test for multiple arguments with quotes and spaces and newlines and line continuation
    assert split_args("foo 'bar baz'\\\nqux")

# Generated at 2022-06-17 06:18:40.509362
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:18:51.966700
# Unit test for function split_args

# Generated at 2022-06-17 06:19:05.508042
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=False) == {u'foo': u'bar', u'baz': u'qux'}

# Generated at 2022-06-17 06:19:16.840224
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:19:31.005350
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:19:37.169830
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = 'a=b c="foo bar"'
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Test case 2
    args = 'a=b c="foo bar" d={{ foo }}'
    assert split_args(args) == ['a=b', 'c="foo bar"', 'd={{ foo }}']

    # Test case 3
    args = 'a=b c="foo bar" d={{ foo }} e={{ bar }}'
    assert split_args(args) == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']

    # Test case 4
    args = 'a=b c="foo bar" d={{ foo }} e={{ bar }} f={{ foo }}'
    assert split

# Generated at 2022-06-17 06:19:50.359134
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': ''}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:19:56.716970
# Unit test for function split_args
def test_split_args():
    # Test simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test with newlines
    assert split_args('a=b\nc="foo bar"') == ['a=b', 'c="foo bar"']

    # Test with line continuation
    assert split_args('a=b\\\nc="foo bar"') == ['a=b\\', 'c="foo bar"']

    # Test with line continuation and newline
    assert split_args('a=b\\\n\nc="foo bar"') == ['a=b\\', 'c="foo bar"']

    # Test with line continuation and newline
    assert split_args('a=b\\\n\nc="foo bar"') == ['a=b\\', 'c="foo bar"']



# Generated at 2022-06-17 06:20:03.118011
# Unit test for function split_args

# Generated at 2022-06-17 06:20:09.911278
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:20:23.678850
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}


# Generated at 2022-06-17 06:20:31.177492
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {'foo': 'bar'}
    assert parse_kv("foo='bar'") == {'foo': 'bar'}
    assert parse_kv("foo=bar baz=quux") == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv("foo=bar baz=quux xyzzy=plugh") == {'foo': 'bar', 'baz': 'quux', 'xyzzy': 'plugh'}
    assert parse_kv("foo=bar baz=quux xyzzy=plugh 'a b c'") == {'foo': 'bar', 'baz': 'quux', 'xyzzy': 'plugh', '_raw_params': "'a b c'"}

# Generated at 2022-06-17 06:20:47.108167
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:20:59.861056
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar") == {u'foo': u'bar'}
    assert parse_kv(u"foo='bar'") == {u'foo': u'bar'}
    assert parse_kv(u"foo='bar baz'") == {u'foo': u'bar baz'}
    assert parse_kv(u"foo='bar baz' bar=foo") == {u'foo': u'bar baz', u'bar': u'foo'}
    assert parse_kv(u"foo='bar baz' bar=foo baz=qux") == {u'foo': u'bar baz', u'bar': u'foo', u'baz': u'qux'}

# Generated at 2022-06-17 06:21:08.544666
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_k

# Generated at 2022-06-17 06:21:17.583189
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d="foo\\"bar"') == [u'a=b', u'c="foo bar"', u'd="foo\\"bar"']
    assert split_args(u'a=b c="foo bar" d="foo\\"bar" e=\\"foo\\"') == [u'a=b', u'c="foo bar"', u'd="foo\\"bar"', u'e=\\"foo\\"']

# Generated at 2022-06-17 06:21:26.149205
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c='foo bar'") == [u'a=b', u"c='foo bar'"]
    assert split_args(u"a=b c='foo bar' d='foo bar'") == [u'a=b', u"c='foo bar'", u"d='foo bar'"]
    assert split_args(u"a=b c='foo bar' d='foo bar' e='foo bar'") == [u'a=b', u"c='foo bar'", u"d='foo bar'", u"e='foo bar'"]

# Generated at 2022-06-17 06:21:38.085136
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'a=b c=d'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}

# Generated at 2022-06-17 06:21:47.394369
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:21:54.867461
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:22:01.686469
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:22:11.646505
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f="{{ foo }} bar"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f="{{ foo }} bar"']
    assert split

# Generated at 2022-06-17 06:22:31.066451
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }} f={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f={{ foo }}']