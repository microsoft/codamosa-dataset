

# Generated at 2022-06-17 06:14:27.599432
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:14:32.126362
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:14:39.906926
# Unit test for function split_args

# Generated at 2022-06-17 06:14:53.917375
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:15:02.743711
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test that we can handle newlines
    assert split_args('a=b\nc="foo bar"') == ['a=b', 'c="foo bar"']

    # Test that we can handle escaped newlines
    assert split_args('a=b\\\nc="foo bar"') == ['a=b\\', 'c="foo bar"']

    # Test that we can handle escaped quotes
    assert split_args('a=b c="foo \\"bar\\""') == ['a=b', 'c="foo \\"bar\\""']

    # Test that we can handle escaped newlines inside quotes

# Generated at 2022-06-17 06:15:10.757198
# Unit test for function split_args

# Generated at 2022-06-17 06:15:25.171894
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''a=b c="foo bar"'''
    expected = ['a=b', 'c="foo bar"']
    actual = split_args(args)
    assert actual == expected

    # Test case 2
    args = '''a=b c="foo bar" d={{ foo }}'''
    expected = ['a=b', 'c="foo bar"', 'd={{ foo }}']
    actual = split_args(args)
    assert actual == expected

    # Test case 3
    args = '''a=b c="foo bar" d={{ foo }} e={{ foo }} f="{{ foo }}"'''
    expected = ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ foo }}', 'f="{{ foo }}"']

# Generated at 2022-06-17 06:15:34.675483
# Unit test for function split_args

# Generated at 2022-06-17 06:15:47.917143
# Unit test for function split_args

# Generated at 2022-06-17 06:15:55.415010
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e f') == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:16:13.269055
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''a=b c="foo bar"'''
    expected_result = ['a=b', 'c="foo bar"']
    assert split_args(args) == expected_result

    # Test case 2
    args = '''a=b c="foo bar" d="{{ foo }}"'''
    expected_result = ['a=b', 'c="foo bar"', 'd="{{ foo }}"']
    assert split_args(args) == expected_result

    # Test case 3
    args = '''a=b c="foo bar" d="{{ foo }}" e="{{ foo }} bar"'''
    expected_result = ['a=b', 'c="foo bar"', 'd="{{ foo }}"', 'e="{{ foo }} bar"']

# Generated at 2022-06-17 06:16:23.942908
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f="{{ foo }} bar"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f="{{ foo }} bar"']
    assert split

# Generated at 2022-06-17 06:16:35.311086
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:16:48.838749
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux=quux') == {'foo': 'bar', 'baz': 'qux=quux'}
    assert parse_kv('foo=bar baz=qux=quux fred=wilma') == {'foo': 'bar', 'baz': 'qux=quux', 'fred': 'wilma'}

# Generated at 2022-06-17 06:17:03.297715
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3 d=4') == {'a': '1', 'b': '2', 'c': '3', 'd': '4'}
    assert parse_kv('a=1 b=2 c=3 d=4 e=5') == {'a': '1', 'b': '2', 'c': '3', 'd': '4', 'e': '5'}

# Generated at 2022-06-17 06:17:12.943360
# Unit test for function split_args
def test_split_args():
    def _test(args, expected):
        result = split_args(args)
        assert result == expected, "split_args('%s') returned %s, expected %s" % (args, result, expected)

    _test('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _test('a=b c="foo bar"\nd=e', ['a=b', 'c="foo bar"', 'd=e'])
    _test('a=b c="foo bar"\nd=e f=g', ['a=b', 'c="foo bar"', 'd=e', 'f=g'])

# Generated at 2022-06-17 06:17:26.540412
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:33.376780
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:47.633773
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:17:58.551435
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:18:24.938241
# Unit test for function split_args
def test_split_args():
    '''
    This is a unit test for the function split_args.
    '''
    # Test 1: Test for a simple string
    args = 'a=b c="foo bar"'
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 2: Test for a string with a newline
    args = 'a=b c="foo bar"\nd=e'
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"', 'd=e']

    # Test 3: Test for a string with a newline and a space
    args = 'a=b c="foo bar"\n d=e'
    result = split_args(args)

# Generated at 2022-06-17 06:18:34.636646
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']
    assert split_args('a=b c="foo bar" d=\\') == ['a=b', 'c="foo bar"', 'd=\\']
    assert split_args('a=b c="foo bar" d=\\\n') == ['a=b', 'c="foo bar"', 'd=\\\n']
    assert split_args('a=b c="foo bar" d=\\\ne=f') == ['a=b', 'c="foo bar"', 'd=\\\n', 'e=f']

# Generated at 2022-06-17 06:18:44.188313
# Unit test for function split_args

# Generated at 2022-06-17 06:18:53.260848
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:19:00.256703
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:19:12.939470
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''
    a=b
    c="foo bar"
    '''
    expected_result = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected_result

    # Test case 2
    args = '''
    a=b
    c="foo bar"
    d="{{ foo }}"
    '''
    expected_result = ['a=b', 'c="foo bar"', 'd="{{ foo }}"']
    result = split_args(args)
    assert result == expected_result

    # Test case 3
    args = '''
    a=b
    c="foo bar"
    d="{{ foo }}"
    e="{{ foo }} bar"
    '''

# Generated at 2022-06-17 06:19:19.658580
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_k

# Generated at 2022-06-17 06:19:32.027733
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:19:43.269733
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:19:53.475118
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:20:26.565659
# Unit test for function split_args

# Generated at 2022-06-17 06:20:40.099128
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=g') == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {u'a': u'b', u'c': u'd e', u'f': u'g', u'_raw_params': u'a=b c="d e" f=g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=False) == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True)

# Generated at 2022-06-17 06:20:46.955550
# Unit test for function split_args

# Generated at 2022-06-17 06:20:59.792595
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:21:08.517487
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo="bar baz"') == {u'foo': u'bar baz'}
    assert parse_kv(u'foo="bar baz" qux=quux') == {u'foo': u'bar baz', u'qux': u'quux'}
    assert parse_kv(u'foo="bar baz" qux=quux') == {u'foo': u'bar baz', u'qux': u'quux'}

# Generated at 2022-06-17 06:21:17.516177
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo bar baz\n') == ['foo', 'bar', 'baz\n']
    assert split_args('foo bar baz\nqux') == ['foo', 'bar', 'baz\n', 'qux']
    assert split_args('foo bar baz\nqux quux') == ['foo', 'bar', 'baz\n', 'qux', 'quux']
    assert split_args('foo bar baz\nqux quux quuz') == ['foo', 'bar', 'baz\n', 'qux', 'quux', 'quuz']

# Generated at 2022-06-17 06:21:27.007005
# Unit test for function split_args

# Generated at 2022-06-17 06:21:39.159853
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test that newlines are preserved
    assert split_args('a=b\nc="foo bar"') == ['a=b\n', 'c="foo bar"']

    # Test that newlines are preserved and that whitespace is preserved
    assert split_args('a=b\n c="foo bar"') == ['a=b\n', 'c="foo bar"']

    # Test that newlines are preserved and that whitespace is preserved
    assert split_args('a=b\n c="foo bar"') == ['a=b\n', 'c="foo bar"']

    # Test that newlines are preserved and that whitespace is preserved

# Generated at 2022-06-17 06:21:47.463675
# Unit test for function parse_kv
def test_parse_kv():
    # Test with a string of key/value items
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    # Test with a string of key/value items and free-form params
    assert parse_kv('foo=bar baz=qux quux') == {'foo': 'bar', 'baz': 'qux', '_raw_params': 'quux'}
    # Test with a string of key/value items and free-form params
    assert parse_kv('foo=bar baz=qux quux', check_raw=False) == {'foo': 'bar', 'baz': 'qux'}
    # Test with a string of key/value items and free-form params

# Generated at 2022-06-17 06:21:57.916230
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u'a=b "c=d"') == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u'a=b "c=d" e=f') == {u'a': u'b', u'c': u'd', u'e': u'f'}
    assert parse_kv(u'a=b "c=d" e=f g="h i"') == {u'a': u'b', u'c': u'd', u'e': u'f', u'g': u'h i'}

# Generated at 2022-06-17 06:22:26.157455
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }} f={{ baz }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f={{ baz }}']