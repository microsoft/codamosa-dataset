

# Generated at 2022-06-17 06:13:28.999668
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=g') == {'a': 'b', 'c': 'd e', 'f': 'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {'a': 'b', 'c': 'd e', 'f': 'g', '_raw_params': 'a=b c="d e" f=g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {'a': 'b', 'c': 'd e', 'f': 'g', '_raw_params': 'a=b c="d e" f=g'}

# Generated at 2022-06-17 06:13:34.731617
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo="bar baz"') == {'foo': 'bar baz'}
    assert parse_kv('foo="bar baz" spam=eggs') == {'foo': 'bar baz', 'spam': 'eggs'}
    assert parse_kv('foo="bar baz" spam=eggs') == {'foo': 'bar baz', 'spam': 'eggs'}
    assert parse_kv('foo="bar baz" spam=eggs') == {'foo': 'bar baz', 'spam': 'eggs'}
    assert parse_kv('foo="bar baz" spam=eggs') == {'foo': 'bar baz', 'spam': 'eggs'}


# Generated at 2022-06-17 06:13:39.430796
# Unit test for function split_args
def test_split_args():
    # Test 1
    args = '''a=b c="foo bar"'''
    expected = ['a=b', 'c="foo bar"']
    assert split_args(args) == expected

    # Test 2
    args = '''a=b c="foo bar" d={{ foo }}'''
    expected = ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args(args) == expected

    # Test 3
    args = '''a=b c="foo bar" d={{ foo }} e="{{ bar }}"'''
    expected = ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"']
    assert split_args(args) == expected

    # Test 4

# Generated at 2022-06-17 06:13:48.541200
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test that a space inside quotes is not split
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']

    # Test that a space inside a jinja2 block is not split
    assert split_args('a=b c="foo bar" d="foo bar" e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="{{ foo }}"']

    # Test that a space inside a jinja2 block is not split

# Generated at 2022-06-17 06:14:02.432013
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args("a=b c=\"foo bar\" d='foo bar' e={{ foo }}") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d='foo bar' e={{ foo }} f={% foo %}") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e={{ foo }}', 'f={% foo %}']

# Generated at 2022-06-17 06:14:13.893453
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:14:22.372919
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-17 06:14:32.341486
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar") == {u'foo': u'bar'}
    assert parse_kv(u"foo='bar'") == {u'foo': u'bar'}
    assert parse_kv(u"foo=\"bar\"") == {u'foo': u'bar'}
    assert parse_kv(u"foo=bar baz=qux") == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u"foo=bar baz=qux quux=corge") == {u'foo': u'bar', u'baz': u'qux', u'quux': u'corge'}

# Generated at 2022-06-17 06:14:41.005698
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:14:54.924221
# Unit test for function split_args

# Generated at 2022-06-17 06:15:18.686585
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=g') == {'a': 'b', 'c': 'd e', 'f': 'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {'a': 'b', 'c': 'd e', 'f': 'g', '_raw_params': 'a=b c="d e" f=g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {'a': 'b', 'c': 'd e', 'f': 'g', '_raw_params': 'a=b c="d e" f=g'}

# Generated at 2022-06-17 06:15:31.087690
# Unit test for function split_args

# Generated at 2022-06-17 06:15:39.024842
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=quux') == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv('foo=bar baz=quux spam=eggs') == {'foo': 'bar', 'baz': 'quux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=quux spam=eggs') == {'foo': 'bar', 'baz': 'quux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=quux spam=eggs') == {'foo': 'bar', 'baz': 'quux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:15:51.086237
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:16:05.111986
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:16:11.024305
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e=f', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'e=f'}
    assert parse_kv('a=b c=d e=f', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:16:16.371824
# Unit test for function split_args
def test_split_args():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict

    # test data

# Generated at 2022-06-17 06:16:25.964739
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']
    assert split_args('a=b c="foo bar" d=\\') == ['a=b', 'c="foo bar"', 'd=\\']
    assert split_args('a=b c="foo bar" d=\\\n e=f') == ['a=b', 'c="foo bar"', 'd=\\', 'e=f']

# Generated at 2022-06-17 06:16:36.086689
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f="{{ foo }} bar"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f="{{ foo }} bar"']
    assert split

# Generated at 2022-06-17 06:16:47.404963
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:17:09.179088
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=\'g h\'') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i', check_raw=False) == {u'a': u'b', u'c': u'd e', u'f': u'g h'}

# Generated at 2022-06-17 06:17:15.054725
# Unit test for function split_args

# Generated at 2022-06-17 06:17:27.042618
# Unit test for function split_args

# Generated at 2022-06-17 06:17:33.782318
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d="foo bar"') == [u'a=b', u'c="foo bar"', u'd="foo bar"']
    assert split_args(u'a=b c="foo bar" d="foo bar" e=f') == [u'a=b', u'c="foo bar"', u'd="foo bar"', u'e=f']

# Generated at 2022-06-17 06:17:47.801526
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:17:58.603058
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:18:04.265896
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'a=b c=d'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:18:12.498240
# Unit test for function parse_kv
def test_parse_kv():
    # Test with a simple string
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}

    # Test with a string that contains escaped quotes
    assert parse_kv('a="b c" d="e f"') == {u'a': u'b c', u'd': u'e f'}

    # Test with a string that contains escaped quotes and escaped equals
    assert parse_kv('a="b c" d="e f" g=h\\=i') == {u'a': u'b c', u'd': u'e f', u'g': u'h=i'}

    # Test with a string that contains escaped quotes and escaped equals

# Generated at 2022-06-17 06:18:24.900692
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux xyzzy=plugh') == {u'foo': u'bar', u'baz': u'qux', u'xyzzy': u'plugh'}
    assert parse_kv(u'foo=bar baz=qux xyzzy=plugh') == {u'foo': u'bar', u'baz': u'qux', u'xyzzy': u'plugh'}

# Generated at 2022-06-17 06:18:34.638012
# Unit test for function split_args

# Generated at 2022-06-17 06:18:55.322569
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo bar baz\n') == ['foo', 'bar', 'baz\n']
    assert split_args('foo bar baz\nqux') == ['foo', 'bar', 'baz\nqux']
    assert split_args('foo bar baz\nqux quux') == ['foo', 'bar', 'baz\nqux', 'quux']
    assert split_args('foo bar baz\nqux quux\n') == ['foo', 'bar', 'baz\nqux', 'quux\n']

# Generated at 2022-06-17 06:19:04.287923
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:19:16.268440
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:19:27.136512
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=g') == {'a': 'b', 'c': 'd e', 'f': 'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {'a': 'b', 'c': 'd e', 'f': 'g', '_raw_params': 'a=b c="d e" f=g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {'a': 'b', 'c': 'd e', 'f': 'g', '_raw_params': 'a=b c="d e" f=g'}

# Generated at 2022-06-17 06:19:37.029446
# Unit test for function split_args

# Generated at 2022-06-17 06:19:50.244297
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=g') == {'a': 'b', 'c': 'd e', 'f': 'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {'a': 'b', 'c': 'd e', 'f': 'g', '_raw_params': 'a=b c="d e" f=g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=False) == {'a': 'b', 'c': 'd e', 'f': 'g'}

# Generated at 2022-06-17 06:19:56.578341
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:20:00.586172
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:20:09.196757
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c=3") == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv("a=1 b='2' c=\"3\"") == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv("a=1 b='2' c=\"3\" d=4 e=5 f=6") == {u'a': u'1', u'b': u'2', u'c': u'3', u'd': u'4', u'e': u'5', u'f': u'6'}

# Generated at 2022-06-17 06:20:22.893363
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    assert split_args(args) == expected

    # Test case 2
    args = 'a=b c="foo bar" d="foo bar"'
    expected = ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args(args) == expected

    # Test case 3
    args = 'a=b c="foo bar" d="foo bar" e="foo bar"'
    expected = ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"']
    assert split_args(args) == expected

    # Test case 4

# Generated at 2022-06-17 06:20:45.929712
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:20:58.902677
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:21:08.281007
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo="bar baz"') == {u'foo': u'bar baz'}
    assert parse_kv('foo="bar baz" bar=foo') == {u'foo': u'bar baz', u'bar': u'foo'}
    assert parse_kv('foo="bar baz" bar=foo baz=') == {u'foo': u'bar baz', u'bar': u'foo', u'baz': u''}

# Generated at 2022-06-17 06:21:17.389515
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:21:26.975760
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    actual = split_args(args)
    assert actual == expected

    # Test case 2
    args = 'a=b c="foo bar" d="foo bar"'
    expected = ['a=b', 'c="foo bar"', 'd="foo bar"']
    actual = split_args(args)
    assert actual == expected

    # Test case 3
    args = 'a=b c="foo bar" d="foo bar" e="foo bar"'
    expected = ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"']
    actual = split_args(args)
    assert actual == expected

    # Test case 4

# Generated at 2022-06-17 06:21:38.775617
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:21:47.442648
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:21:57.915684
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv(u"a=1 b=2 c") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c'}
    assert parse_kv(u"a=1 b=2 c d=3") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c d=3'}
    assert parse_kv(u"a=1 b=2 c d=3 e f") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c d=3 e f'}
    assert parse

# Generated at 2022-06-17 06:22:03.719098
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:22:11.790019
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv