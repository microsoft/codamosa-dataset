

# Generated at 2022-06-17 06:13:01.290531
# Unit test for function split_args

# Generated at 2022-06-17 06:13:08.229158
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=g') == {'a': 'b', 'c': 'd e', 'f': 'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {'a': 'b', 'c': 'd e', 'f': 'g', '_raw_params': 'a=b c="d e" f=g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {'a': 'b', 'c': 'd e', 'f': 'g', '_raw_params': 'a=b c="d e" f=g'}

# Generated at 2022-06-17 06:13:20.353867
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=False) == {u'foo': u'bar', u'baz': u'qux'}


# Generated at 2022-06-17 06:13:26.506033
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']

# Generated at 2022-06-17 06:13:40.638205
# Unit test for function split_args
def test_split_args():
    # Test simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test case with jinja2 blocks
    assert split_args('a=b c="foo {{ bar }}"') == ['a=b', 'c="foo {{ bar }}"']

    # Test case with jinja2 blocks and quotes
    assert split_args('a=b c="foo {{ bar }}" d="{{ foo }} bar"') == ['a=b', 'c="foo {{ bar }}"', 'd="{{ foo }} bar"']

    # Test case with jinja2 blocks and quotes and newlines

# Generated at 2022-06-17 06:13:48.959872
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']

# Generated at 2022-06-17 06:14:02.777537
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux quux') == {'foo': 'bar', 'baz': 'qux', '_raw_params': 'quux'}
    assert parse_kv('foo=bar baz=qux quux=corge') == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}

# Generated at 2022-06-17 06:14:13.920063
# Unit test for function split_args

# Generated at 2022-06-17 06:14:22.373842
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv(u'foo=bar baz=qux=quux') == {u'foo': u'bar', u'baz': u'qux=quux'}

# Generated at 2022-06-17 06:14:32.382406
# Unit test for function split_args

# Generated at 2022-06-17 06:14:58.374601
# Unit test for function split_args
def test_split_args():
    # Test 1: Simple args
    # Input: a=b c="foo bar"
    # Expected Output: ['a=b', 'c="foo bar"']
    args = 'a=b c="foo bar"'
    expected_result = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected_result

    # Test 2: Simple args with newlines
    # Input: a=b \
    #        c="foo bar"
    # Expected Output: ['a=b', 'c="foo bar"']
    args = 'a=b \\\n        c="foo bar"'
    expected_result = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected_result

    # Test 3: Simple args with escaped

# Generated at 2022-06-17 06:15:05.683433
# Unit test for function split_args

# Generated at 2022-06-17 06:15:17.830410
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:15:30.843820
# Unit test for function split_args

# Generated at 2022-06-17 06:15:39.006776
# Unit test for function split_args
def test_split_args():
    # Test 1
    args = "a=b c=\"foo bar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 2
    args = "a=b c=\"foo bar\" d='foo bar'"
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"', "d='foo bar'"]

    # Test 3
    args = "a=b c=\"foo bar\" d='foo bar' e={{ foo }}"
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"', "d='foo bar'", 'e={{ foo }}']

    # Test 4

# Generated at 2022-06-17 06:15:48.468342
# Unit test for function split_args

# Generated at 2022-06-17 06:15:58.204431
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c='foo bar'") == [u'a=b', u"c='foo bar'"]
    assert split_args(u"a=b c=\"foo bar\"") == [u'a=b', u'c="foo bar"']
    assert split_args(u"a=b c=\"foo bar") == [u'a=b', u'c="foo bar']
    assert split_args(u"a=b c='foo bar") == [u'a=b', u"c='foo bar"]
    assert split_args(u"a=b c=\"foo bar\\\"") == [u'a=b', u'c="foo bar"']

# Generated at 2022-06-17 06:16:02.580813
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:16:13.359972
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:16:28.088436
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f="{{ foo }} bar"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f="{{ foo }} bar"']
    assert split

# Generated at 2022-06-17 06:16:53.088222
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:08.604173
# Unit test for function split_args

# Generated at 2022-06-17 06:17:13.581444
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}" f={{ baz }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"', 'f={{ baz }}']
    assert split_args

# Generated at 2022-06-17 06:17:27.806818
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:17:34.363561
# Unit test for function split_args

# Generated at 2022-06-17 06:17:48.075942
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2") == {'a': '1', 'b': '2'}
    assert parse_kv("a=1 b=2 c") == {'a': '1', 'b': '2', '_raw_params': 'c'}
    assert parse_kv("a=1 b=2 c d") == {'a': '1', 'b': '2', '_raw_params': 'c d'}
    assert parse_kv("a=1 b=2 c='d e'") == {'a': '1', 'b': '2', '_raw_params': "c='d e'"}

# Generated at 2022-06-17 06:18:02.209976
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c='foo bar' d=\"foo bar\"") == ['a=b', "c='foo bar'", 'd="foo bar"']
    assert split_args("a=b c='foo bar' d=\"foo bar\" e='foo bar'") == ['a=b', "c='foo bar'", 'd="foo bar"', "e='foo bar'"]

# Generated at 2022-06-17 06:18:10.884664
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:18:24.035385
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:18:33.947566
# Unit test for function split_args

# Generated at 2022-06-17 06:18:49.111857
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f="g=h"') == {u'a': u'b', u'c': u'd e', u'f': u'g=h'}
    assert parse_kv(u'a=b c="d e" f="g=h" i') == {u'a': u'b', u'c': u'd e', u'f': u'g=h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f="g=h" i', check_raw=False) == {u'a': u'b', u'c': u'd e', u'f': u'g=h'}

# Generated at 2022-06-17 06:19:00.784492
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv(u"a=1 b=2 c") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c'}
    assert parse_kv(u"a=1 b=2 c d") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c d'}
    assert parse_kv(u"a=1 b=2 c d e=3") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c d', u'e': u'3'}
    assert parse_

# Generated at 2022-06-17 06:19:13.113621
# Unit test for function split_args
def test_split_args():
    # Test for issue #18094
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo bar baz ') == ['foo', 'bar', 'baz']
    assert split_args('foo bar baz  ') == ['foo', 'bar', 'baz']
    assert split_args('foo bar baz   ') == ['foo', 'bar', 'baz']
    assert split_args('foo bar baz    ') == ['foo', 'bar', 'baz']
    assert split_args('foo bar baz     ') == ['foo', 'bar', 'baz']
    assert split_args('foo bar baz      ') == ['foo', 'bar', 'baz']


# Generated at 2022-06-17 06:19:17.935075
# Unit test for function split_args

# Generated at 2022-06-17 06:19:31.677089
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}" f="{{ foo }} bar"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"', 'f="{{ foo }} bar"']
    assert split

# Generated at 2022-06-17 06:19:43.134454
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:19:53.431247
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo="bar baz"') == {u'foo': u'bar baz'}
    assert parse_kv('foo="bar baz" baz=qux') == {u'foo': u'bar baz', u'baz': u'qux'}
    assert parse_kv('foo="bar baz" baz=qux quux=quuz') == {u'foo': u'bar baz', u'baz': u'qux', u'quux': u'quuz'}

# Generated at 2022-06-17 06:20:07.436796
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar" d="foo bar') == ['a=b', 'c="foo bar"', 'd="foo bar']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']

# Generated at 2022-06-17 06:20:13.470460
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d e=f", check_raw=True) == {u'a': u'b', u'c': u'd', u'e': u'f'}

# Generated at 2022-06-17 06:20:25.485245
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }} f={{ baz }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f={{ baz }}']

# Generated at 2022-06-17 06:20:44.828428
# Unit test for function split_args

# Generated at 2022-06-17 06:20:58.382419
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:21:04.246651
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=g') == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv(u'a=b c="d e" f=g', check_raw=True) == {u'a': u'b', u'c': u'd e', u'f': u'g', u'_raw_params': u'a=b c="d e" f=g'}

# Generated at 2022-06-17 06:21:18.354841
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:21:26.391007
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-17 06:21:38.185529
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:21:44.327355
# Unit test for function split_args
def test_split_args():
    # Test the basic functionality
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:21:53.738275
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:22:00.722939
# Unit test for function split_args
def test_split_args():
    # Test 1: Test basic functionality
    args = "a=b c=\"foo bar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 2: Test with a jinja2 block
    args = "a=b c=\"foo bar\" d={{ foo }}"
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"', 'd={{ foo }}']

    # Test 3: Test with a jinja2 block and a newline
    args = "a=b c=\"foo bar\"\nd={{ foo }}"
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"\n', 'd={{ foo }}']

    # Test 4: Test with a

# Generated at 2022-06-17 06:22:11.410137
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv(u'foo=bar baz=qux=quux') == {u'foo': u'bar', u'baz': u'qux=quux'}