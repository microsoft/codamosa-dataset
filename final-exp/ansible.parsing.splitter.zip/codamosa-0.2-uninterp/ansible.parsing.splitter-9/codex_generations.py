

# Generated at 2022-06-17 06:13:08.572780
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:13:22.921605
# Unit test for function split_args
def test_split_args():
    assert split_args(u"foo bar") == [u"foo", u"bar"]
    assert split_args(u"foo bar baz") == [u"foo", u"bar", u"baz"]
    assert split_args(u"foo bar baz\nqux") == [u"foo", u"bar", u"baz\nqux"]
    assert split_args(u"foo bar baz\nqux\nquux") == [u"foo", u"bar", u"baz\nqux\nquux"]
    assert split_args(u"foo bar baz\nqux\nquux\nquuz") == [u"foo", u"bar", u"baz\nqux\nquux\nquuz"]

# Generated at 2022-06-17 06:13:28.848486
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]

# Generated at 2022-06-17 06:13:43.558339
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d=') == [u'a=b', u'c="foo bar"', u'd=']
    assert split_args(u'a=b c="foo bar" d=\\') == [u'a=b', u'c="foo bar"', u'd=\\']
    assert split_args(u'a=b c="foo bar" d=\\\n') == [u'a=b', u'c="foo bar"', u'd=\\\n']

# Generated at 2022-06-17 06:13:52.476278
# Unit test for function split_args
def test_split_args():
    # Test for issue #18074
    assert split_args('{{ foo }}') == ['{{ foo }}']
    assert split_args('{{ foo }}\n{{ bar }}') == ['{{ foo }}', '{{ bar }}']
    assert split_args('{{ foo }} {{ bar }}') == ['{{ foo }} {{ bar }}']
    assert split_args('{{ foo }}\n{{ bar }}\n{{ baz }}') == ['{{ foo }}', '{{ bar }}', '{{ baz }}']
    assert split_args('{{ foo }} {{ bar }}\n{{ baz }}') == ['{{ foo }} {{ bar }}', '{{ baz }}']
    assert split_args('{{ foo }} {{ bar }}\n{{ baz }}\n{{ qux }}') == ['{{ foo }} {{ bar }}', '{{ baz }}', '{{ qux }}']
   

# Generated at 2022-06-17 06:14:03.602629
# Unit test for function split_args
def test_split_args():
    '''
    Unit test for function split_args
    '''
    # Test cases

# Generated at 2022-06-17 06:14:17.735034
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:14:27.311302
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f={{ foo }}']

# Generated at 2022-06-17 06:14:31.920948
# Unit test for function parse_kv
def test_parse_kv():
    # Test 1
    args = 'a=b c=d'
    options = parse_kv(args)
    assert options['a'] == 'b'
    assert options['c'] == 'd'

    # Test 2
    args = 'a=b c=d e'
    options = parse_kv(args)
    assert options['a'] == 'b'
    assert options['c'] == 'd'
    assert options['_raw_params'] == 'e'

    # Test 3
    args = 'a=b c=d e f="g h"'
    options = parse_kv(args)
    assert options['a'] == 'b'
    assert options['c'] == 'd'
    assert options['_raw_params'] == 'e f="g h"'

    # Test 4

# Generated at 2022-06-17 06:14:39.745042
# Unit test for function split_args
def test_split_args():
    # Test 1: Simple string
    args = "a=b c=\"foo bar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 2: String with newlines
    args = "a=b c=\"foo\nbar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo\nbar"']

    # Test 3: String with escaped quotes
    args = "a=b c=\"foo\\\"bar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo\\"bar"']

    # Test 4: String with escaped quotes and newlines
    args = "a=b c=\"foo\\\"bar\nbar\""

# Generated at 2022-06-17 06:15:24.319610
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }} f={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f={{ foo }}']

# Generated at 2022-06-17 06:15:37.033285
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:15:50.272908
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''
    a=b c="foo bar"
    '''
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Test case 2
    args = '''
    a=b c="foo bar"
    d=e f="foo bar"
    '''
    assert split_args(args) == ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"']

    # Test case 3
    args = '''
    a=b c="foo bar"
    d=e f="foo bar"
    '''
    assert split_args(args) == ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"']

    # Test case 4

# Generated at 2022-06-17 06:15:58.906981
# Unit test for function split_args
def test_split_args():
    # Test the basic functionality of split_args
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test that split_args can handle a line continuation
    assert split_args('a=b c="foo bar" \\') == ['a=b', 'c="foo bar"']

    # Test that split_args can handle a line continuation with a newline
    assert split_args('a=b c="foo bar" \\ \n') == ['a=b', 'c="foo bar"']

    # Test that split_args can handle a line continuation with a newline and a space
    assert split_args('a=b c="foo bar" \\ \n ') == ['a=b', 'c="foo bar"']

    # Test that split_args can handle a line continuation with a

# Generated at 2022-06-17 06:16:03.494810
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=g') == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {u'a': u'b', u'c': u'd e', u'f': u'g', u'_raw_params': u'a=b c="d e" f=g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=False) == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True)

# Generated at 2022-06-17 06:16:13.212716
# Unit test for function split_args
def test_split_args():
    # Test 1: Simple test
    args = 'a=b c="foo bar"'
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 2: Test with newlines
    args = 'a=b\nc="foo bar"'
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 3: Test with escaped quotes
    args = 'a=b c="foo \\"bar\\""'
    result = split_args(args)
    assert result == ['a=b', 'c="foo \\"bar\\""']

    # Test 4: Test with escaped quotes and newlines
    args = 'a=b\nc="foo \\"bar\\""'
    result = split_args(args)

# Generated at 2022-06-17 06:16:22.444745
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:16:35.351533
# Unit test for function split_args
def test_split_args():
    # Test for issue #15961
    assert split_args(u"a='b c'") == [u"a='b c'"]
    assert split_args(u"a='b c' d='e f'") == [u"a='b c'", u"d='e f'"]
    assert split_args(u"a='b c' d='e f' g='h i'") == [u"a='b c'", u"d='e f'", u"g='h i'"]
    assert split_args(u"a='b c' d='e f' g='h i' j='k l'") == [u"a='b c'", u"d='e f'", u"g='h i'", u"j='k l'"]

# Generated at 2022-06-17 06:16:48.860952
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:03.299168
# Unit test for function split_args

# Generated at 2022-06-17 06:17:14.435380
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:17:26.853736
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:17:33.630666
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ e }}') == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}']
    assert split_args('a=b c="foo bar" d={{ e }} f="{{ g }}"') == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}', 'f="{{', 'g', '}}"']

# Generated at 2022-06-17 06:17:47.768529
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u"a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u"a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u"a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u"a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}


# Generated at 2022-06-17 06:17:58.627879
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args("a=b c=\"foo bar\" d='foo bar' e=foo\\ bar") == ['a=b', 'c="foo bar"', "d='foo bar'", "e=foo bar"]
    assert split_args("a=b c=\"foo bar\" d='foo bar' e=foo\\\nbar") == ['a=b', 'c="foo bar"', "d='foo bar'", "e=foobar"]

# Generated at 2022-06-17 06:18:10.368218
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-17 06:18:23.545907
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:18:32.364969
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:18:38.422639
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ e }}") == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}']
    assert split_args("a=b c=\"foo bar\" d={{ e }} f={{ g }}") == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}', 'f={{', 'g', '}}']

# Generated at 2022-06-17 06:18:42.713204
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv("a=1 b=2 c") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c'}
    assert parse_kv("a=1 b=2 c d") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c d'}
    assert parse_kv("a=1 b=2 c d e=3") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c d e=3'}

# Generated at 2022-06-17 06:19:03.490794
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == dict(foo='bar')
    assert parse_kv("foo=bar baz=quux") == dict(foo='bar', baz='quux')
    assert parse_kv("foo=bar baz=quux biz=boz") == dict(foo='bar', baz='quux', biz='boz')
    assert parse_kv("foo='bar baz'") == dict(foo='bar baz')
    assert parse_kv("foo=\"bar baz\"") == dict(foo='bar baz')
    assert parse_kv("foo='bar baz' biz=\"boz quux\"") == dict(foo='bar baz', biz='boz quux')

# Generated at 2022-06-17 06:19:15.700863
# Unit test for function split_args

# Generated at 2022-06-17 06:19:26.982316
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a=1 b=2 c') == {'a': '1', 'b': '2', '_raw_params': 'c'}
    assert parse_kv('a=1 b=2 c d=3') == {'a': '1', 'b': '2', '_raw_params': 'c d=3'}
    assert parse_kv('a=1 b=2 c d=3 e') == {'a': '1', 'b': '2', '_raw_params': 'c d=3 e'}

# Generated at 2022-06-17 06:19:31.544709
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"\nd=e f="foo bar"') == ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"']
    assert split_args('a=b c="foo bar"\nd=e f="foo bar"\n') == ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"', '']
    assert split_args('a=b c="foo bar"\nd=e f="foo bar"\n\n') == ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"', '', '']

# Generated at 2022-06-17 06:19:37.250480
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ e }}') == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}']
    assert split_args('a=b c="foo bar" d={{ e }} f="{{ g }}"') == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}', 'f="{{', 'g', '}}"']

# Generated at 2022-06-17 06:19:50.418934
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar') == [u'a=b', u'c="foo bar']
    assert split_args(u'a=b c="foo bar" d=') == [u'a=b', u'c="foo bar"', u'd=']
    assert split_args(u'a=b c="foo bar" d=\\') == [u'a=b', u'c="foo bar"', u'd=\\']

# Generated at 2022-06-17 06:19:57.554889
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar baz=qux") == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u"foo=bar baz=qux", check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv(u"foo=bar baz=qux", check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}

# Generated at 2022-06-17 06:20:09.241871
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }} f={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f={{ foo }}']

# Generated at 2022-06-17 06:20:22.948681
# Unit test for function split_args
def test_split_args():
    # Test for issue #27077
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo bar baz\n') == ['foo', 'bar', 'baz\n']
    assert split_args('foo bar baz\n') == ['foo', 'bar', 'baz\n']
    assert split_args('foo bar baz\nqux') == ['foo', 'bar', 'baz\nqux']
    assert split_args('foo bar baz\nqux quux') == ['foo', 'bar', 'baz\nqux', 'quux']

# Generated at 2022-06-17 06:20:30.898331
# Unit test for function split_args

# Generated at 2022-06-17 06:21:02.906226
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:21:17.811411
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:21:26.357632
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e=\"{{ foo }}\"") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e=\"{{ foo }}\" f={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f={{ foo }}']

# Generated at 2022-06-17 06:21:38.161448
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g=h') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g=h']

# Generated at 2022-06-17 06:21:47.418930
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:21:57.885094
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux fred=wilma') == {'foo': 'bar', 'baz': 'qux', 'fred': 'wilma'}
    assert parse_kv('foo=bar baz=qux fred=wilma barney=betty') == {'foo': 'bar', 'baz': 'qux', 'fred': 'wilma', 'barney': 'betty'}
    assert parse_kv('foo=bar baz=qux fred=wilma barney=betty bammbamm=pebbles')

# Generated at 2022-06-17 06:22:07.073595
# Unit test for function split_args
def test_split_args():
    # Test simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test case with newlines
    assert split_args('a=b\nc="foo bar"') == ['a=b', 'c="foo bar"']

    # Test case with newlines and line continuation
    assert split_args('a=b\nc="foo bar"\\\nd=e') == ['a=b', 'c="foo bar"', 'd=e']

    # Test case with newlines and line continuation and spaces
    assert split_args('a=b\nc="foo bar"\\\nd=e f=g') == ['a=b', 'c="foo bar"', 'd=e f=g']

    # Test case with newlines and line continuation and spaces and quotes
   

# Generated at 2022-06-17 06:22:13.539843
# Unit test for function split_args
def test_split_args():
    # Test 1
    args = "a=b c=\"foo bar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test 2
    args = "a=b c=\"foo bar\" d=\"foo bar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"', 'd="foo bar"']

    # Test 3
    args = "a=b c=\"foo bar\" d=\"foo bar\" e=f"
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']

    # Test 4

# Generated at 2022-06-17 06:22:23.063190
# Unit test for function split_args

# Generated at 2022-06-17 06:22:33.466099
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {u'foo': u'bar', u'baz': u'qux', u'xyzzy': u'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {u'foo': u'bar', u'baz': u'qux', u'xyzzy': u'plugh'}