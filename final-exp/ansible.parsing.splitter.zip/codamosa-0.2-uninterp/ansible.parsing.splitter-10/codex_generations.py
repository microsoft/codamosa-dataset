

# Generated at 2022-06-17 06:13:09.945597
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-17 06:13:23.229190
# Unit test for function split_args
def test_split_args():
    # Test that the function can handle a simple string
    assert split_args('foo bar') == ['foo', 'bar']

    # Test that the function can handle a simple string with quotes
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']

    # Test that the function can handle a simple string with quotes and spaces
    assert split_args('foo "bar baz" qux') == ['foo', '"bar baz"', 'qux']

    # Test that the function can handle a simple string with quotes and spaces
    assert split_args('foo "bar baz" qux') == ['foo', '"bar baz"', 'qux']

    # Test that the function can handle a simple string with quotes and spaces

# Generated at 2022-06-17 06:13:38.615429
# Unit test for function split_args
def test_split_args():
    # Test that split_args() can handle a simple string
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test that split_args() can handle a string with escaped quotes
    assert split_args(r'a=b c="foo \"bar\""') == ['a=b', r'c="foo \"bar\""']

    # Test that split_args() can handle a string with escaped newlines
    assert split_args(r'a=b c="foo \n bar"') == ['a=b', r'c="foo \n bar"']

    # Test that split_args() can handle a string with escaped backslashes
    assert split_args(r'a=b c="foo \\ bar"') == ['a=b', r'c="foo \\ bar"']

# Generated at 2022-06-17 06:13:48.708063
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=\'g h\'') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f=\'g h\'') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f=\'g h\'') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}

# Generated at 2022-06-17 06:14:02.540853
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f="g h"') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv('a=b c="d e" f="g h" i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv('a=b c="d e" f="g h" i j') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j'}

# Generated at 2022-06-17 06:14:11.743125
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:14:22.267792
# Unit test for function split_args
def test_split_args():
    # Test 1
    args = '''
    - name: test
      shell: echo "{{ foo }}"
    '''
    params = split_args(args)
    assert params == ['-', 'name:', 'test', 'shell:', 'echo', '"{{', 'foo', '}}"']

    # Test 2
    args = '''
    - name: test
      shell: echo "{{ foo }}"
      args:
        creates: /tmp/foo
    '''
    params = split_args(args)
    assert params == ['-', 'name:', 'test', 'shell:', 'echo', '"{{', 'foo', '}}"', 'args:', 'creates:', '/tmp/foo']

    # Test 3

# Generated at 2022-06-17 06:14:32.259771
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d={{ foo }}') == [u'a=b', u'c="foo bar"', u'd={{ foo }}']
    assert split_args(u'a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == [u'a=b', u'c="foo bar"', u'd={{ foo }}', u'e="{{ foo }}"']

# Generated at 2022-06-17 06:14:40.027186
# Unit test for function split_args

# Generated at 2022-06-17 06:14:54.047475
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs ham') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs', u'_raw_params': u'ham'}

# Generated at 2022-06-17 06:15:17.887376
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args("a=b c=\"foo bar\" d='foo bar' e=\"foo bar\"") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar' e=\"foo bar\" f='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]

# Generated at 2022-06-17 06:15:24.489349
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:15:37.198341
# Unit test for function split_args
def test_split_args():
    # Test case 1
    # Test case 1.1
    args = 'a=b c="foo bar"'
    expected_result = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected_result
    # Test case 1.2
    args = 'a=b c="foo bar"\nd=e f="foo bar"'
    expected_result = ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"']
    result = split_args(args)
    assert result == expected_result
    # Test case 1.3
    args = 'a=b c="foo bar"\nd=e f="foo bar"\ng=h i="foo bar"'

# Generated at 2022-06-17 06:15:50.441720
# Unit test for function split_args

# Generated at 2022-06-17 06:15:59.017681
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e=') == {'a': 'b', 'c': 'd', '_raw_params': 'e='}
    assert parse_kv

# Generated at 2022-06-17 06:16:08.724644
# Unit test for function split_args

# Generated at 2022-06-17 06:16:14.599890
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d=\"foo bar\"") == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args("a=b c=\"foo bar\" d=\"foo bar\" e=\"foo bar\"") == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"']
    assert split_args("a=b c=\"foo bar\" d=\"foo bar\" e=\"foo bar\" f=\"foo bar\"") == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"', 'f="foo bar"']

# Generated at 2022-06-17 06:16:25.254570
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u'a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u'a=b c=d e') == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}
    assert parse_kv(u'a=b c=d e', check_raw=True) == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}

# Generated at 2022-06-17 06:16:36.008177
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''
    a=b c="foo bar"
    '''
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test case 2
    args = '''
    a=b c="foo bar"
    d="{{ foo }}"
    '''
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"', 'd="{{ foo }}"']

    # Test case 3
    args = '''
    a=b c="foo bar"
    d="{{ foo }}"
    e="{{ foo }} bar"
    '''
    params = split_args(args)

# Generated at 2022-06-17 06:16:47.405972
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e="foo bar" f="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"', 'f="foo bar"']

# Generated at 2022-06-17 06:17:05.754681
# Unit test for function split_args

# Generated at 2022-06-17 06:17:13.316009
# Unit test for function split_args

# Generated at 2022-06-17 06:17:26.569964
# Unit test for function split_args
def test_split_args():
    # Test case 1:
    # Test case:
    #   Input:
    #       args = "a=b c=\"foo bar\""
    #   Output:
    #       ['a=b', 'c="foo bar"']
    args = "a=b c=\"foo bar\""
    expected_result = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected_result

    # Test case 2:
    # Test case:
    #   Input:
    #       args = "a=b c=\"foo bar\""
    #   Output:
    #       ['a=b', 'c="foo bar"']
    args = "a=b c=\"foo bar\""
    expected_result = ['a=b', 'c="foo bar"']

# Generated at 2022-06-17 06:17:33.403815
# Unit test for function split_args

# Generated at 2022-06-17 06:17:43.102927
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz=qux'}
    assert parse_kv(u'foo=bar baz=qux=quux') == {u'foo': u'bar', u'baz': u'qux=quux'}

# Generated at 2022-06-17 06:17:52.896321
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''
    a=b c="foo bar"
    '''
    expected = ['a=b', 'c="foo bar"']
    assert split_args(args) == expected

    # Test case 2
    args = '''
    a=b c="foo bar" d="{{ foo }}"
    '''
    expected = ['a=b', 'c="foo bar"', 'd="{{ foo }}"']
    assert split_args(args) == expected

    # Test case 3
    args = '''
    a=b c="foo bar" d="{{ foo }}" e="{% if foo %} {% endif %}"
    '''

# Generated at 2022-06-17 06:18:06.563922
# Unit test for function split_args

# Generated at 2022-06-17 06:18:21.141995
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux', '_raw_params': 'foo=bar baz=qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=False) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux', '_raw_params': 'foo=bar baz=qux'}

# Generated at 2022-06-17 06:18:27.970262
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d="foo bar"') == [u'a=b', u'c="foo bar"', u'd="foo bar"']
    assert split_args(u'a=b c="foo bar" d="foo bar" e=f') == [u'a=b', u'c="foo bar"', u'd="foo bar"', u'e=f']

# Generated at 2022-06-17 06:18:36.880129
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=g') == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv(u'a=b c="d e" f=g', check_raw=True) == {u'a': u'b', u'c': u'd e', u'f': u'g', u'_raw_params': u'a=b c="d e" f=g'}
    assert parse_kv(u'a=b c="d e" f=g', check_raw=False) == {u'a': u'b', u'c': u'd e', u'f': u'g'}

# Generated at 2022-06-17 06:18:54.889450
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c=\"foo bar\"") == [u"a=b", u"c=\"foo bar\""]
    assert split_args(u"a=b c=\"foo bar\" d='foo bar'") == [u"a=b", u"c=\"foo bar\"", u"d='foo bar'"]
    assert split_args(u"a=b c=\"foo bar\" d='foo bar' e=\"foo bar\"") == [u"a=b", u"c=\"foo bar\"", u"d='foo bar'", u"e=\"foo bar\""]

# Generated at 2022-06-17 06:19:03.946387
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d={{ foo }}') == [u'a=b', u'c="foo bar"', u'd={{ foo }}']
    assert split_args(u'a=b c="foo bar" d={{ foo }} e={{ bar }}') == [u'a=b', u'c="foo bar"', u'd={{ foo }}', u'e={{ bar }}']

# Generated at 2022-06-17 06:19:16.150072
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux quux=corge') == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}
    assert parse_kv('foo=bar baz=qux quux=corge') == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}
    assert parse_kv('foo=bar baz=qux quux=corge') == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}
    assert parse

# Generated at 2022-06-17 06:19:27.116961
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u'a=b c=d e') == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}
    assert parse_kv(u'a=b c=d e=') == {u'a': u'b', u'c': u'd', u'_raw_params': u'e='}
    assert parse_kv(u'a=b c=d e=f g') == {u'a': u'b', u'c': u'd', u'e': u'f', u'_raw_params': u'g'}

# Generated at 2022-06-17 06:19:37.004803
# Unit test for function split_args
def test_split_args():
    # Test 1: simple case
    args = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected

    # Test 2: simple case with newlines
    args = 'a=b\nc="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected

    # Test 3: simple case with newlines and spaces
    args = 'a=b\n c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected

    # Test 4: simple case with newlines and spaces
    args = 'a=b\n c="foo bar"'
   

# Generated at 2022-06-17 06:19:50.184894
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': ''}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:19:56.523669
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:20:03.046384
# Unit test for function split_args

# Generated at 2022-06-17 06:20:11.297739
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f={{ foo }}']

# Generated at 2022-06-17 06:20:24.941126
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:20:51.390099
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=b c=d") == {u"a": u"b", u"c": u"d"}
    assert parse_kv(u"a=b c=d e") == {u"a": u"b", u"c": u"d", u"_raw_params": u"e"}
    assert parse_kv(u"a=b c=d e", check_raw=False) == {u"a": u"b", u"c": u"d"}
    assert parse_kv(u"a=b c=d e", check_raw=True) == {u"a": u"b", u"c": u"d", u"_raw_params": u"e"}

# Generated at 2022-06-17 06:21:01.646897
# Unit test for function split_args

# Generated at 2022-06-17 06:21:09.847960
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:21:20.922206
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u'a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u'a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u'a=b c=d e') == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}

# Generated at 2022-06-17 06:21:34.678631
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e=\"{{ foo }}\"") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e=\"{{ foo }}\" f={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f={{ foo }}']

# Generated at 2022-06-17 06:21:46.289688
# Unit test for function split_args

# Generated at 2022-06-17 06:21:54.320935
# Unit test for function split_args

# Generated at 2022-06-17 06:22:04.390527
# Unit test for function split_args
def test_split_args():
    assert split_args(u"foo bar") == [u"foo", u"bar"]
    assert split_args(u"foo bar baz") == [u"foo", u"bar", u"baz"]
    assert split_args(u"foo bar baz\nfoo bar baz") == [u"foo", u"bar", u"baz\nfoo", u"bar", u"baz"]
    assert split_args(u"foo bar baz\nfoo bar baz\nfoo bar baz") == [u"foo", u"bar", u"baz\nfoo", u"bar", u"baz\nfoo", u"bar", u"baz"]

# Generated at 2022-06-17 06:22:12.034401
# Unit test for function split_args

# Generated at 2022-06-17 06:22:22.352515
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=g') == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv(u'a=b c="d e" f=g', check_raw=True) == {u'a': u'b', u'c': u'd e', u'f': u'g', u'_raw_params': u'a=b c="d e" f=g'}
    assert parse_kv(u'a=b c="d e" f=g', check_raw=False) == {u'a': u'b', u'c': u'd e', u'f': u'g'}