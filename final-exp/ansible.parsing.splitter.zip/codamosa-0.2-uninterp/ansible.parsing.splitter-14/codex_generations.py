

# Generated at 2022-06-17 06:13:07.628574
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:13:22.237904
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=\'g h\'') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i j=k') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j=k'}

# Generated at 2022-06-17 06:13:30.936345
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'a=b c=d'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:13:36.290754
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:13:47.207030
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo="bar baz"') == {u'foo': u'bar baz'}
    assert parse_kv(u'foo="bar baz" spam=eggs') == {u'foo': u'bar baz', u'spam': u'eggs'}
    assert parse_kv(u'foo="bar baz" spam=eggs') == {u'foo': u'bar baz', u'spam': u'eggs'}
    assert parse_kv(u'foo="bar baz" spam=eggs') == {u'foo': u'bar baz', u'spam': u'eggs'}

# Generated at 2022-06-17 06:13:57.272155
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:14:08.529988
# Unit test for function split_args

# Generated at 2022-06-17 06:14:20.805027
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f={{ foo }}']

# Generated at 2022-06-17 06:14:30.893586
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-17 06:14:39.036046
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=1 b=2 c=3") == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv(u"a=1 b=2 c=3", check_raw=True) == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv(u"a=1 b=2 c=3", check_raw=False) == {u'a': u'1', u'b': u'2', u'c': u'3'}

# Generated at 2022-06-17 06:15:04.150736
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f="g h"') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f="g h" i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f="g h" i j') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j'}

# Generated at 2022-06-17 06:15:17.211260
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {u'a': u'b', u'c': u'd', u'_raw_params': u''}
    assert parse_kv("a=b c=d e") == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}
    assert parse_kv("a=b c=d e", check_raw=True) == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}

# Generated at 2022-06-17 06:15:30.734904
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=1 b=2 c=3') == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv(u'a=1 b="2 c" d=3') == {u'a': u'1', u'b': u'2 c', u'd': u'3'}
    assert parse_kv(u'a=1 b="2 c" d=3', check_raw=True) == {u'a': u'1', u'b': u'2 c', u'd': u'3', u'_raw_params': u'a=1 b="2 c" d=3'}
    assert parse_kv(u'a=1 b="2 c" d=3', check_raw=True)

# Generated at 2022-06-17 06:15:44.395321
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:15:57.431283
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"']

# Generated at 2022-06-17 06:16:10.942250
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:16:26.547224
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:16:36.557122
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:16:47.405116
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:16:54.029390
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:17:11.972102
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv("a=1 b=2 c") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c'}
    assert parse_kv("a=1 b=2 c d") == {u'a': u'1', u'b': u'2', u'_raw_params': u'c d'}
    assert parse_kv("a=1 b=2 c= d") == {u'a': u'1', u'b': u'2', u'c': u'', u'_raw_params': u'd'}

# Generated at 2022-06-17 06:17:26.448467
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:17:32.825144
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:47.135932
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:17:53.556332
# Unit test for function parse_kv
def test_parse_kv():
    # Test basic functionality
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d e') == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}
    assert parse_kv('a=b c=d e=') == {u'a': u'b', u'c': u'd', u'e': u''}
    assert parse_kv('a=b c=d e= f') == {u'a': u'b', u'c': u'd', u'e': u'', u'_raw_params': u'f'}

# Generated at 2022-06-17 06:18:06.807041
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d={{ foo }}') == [u'a=b', u'c="foo bar"', u'd={{ foo }}']
    assert split_args(u'a=b c="foo bar" d={{ foo }} e={{ bar }}') == [u'a=b', u'c="foo bar"', u'd={{ foo }}', u'e={{ bar }}']

# Generated at 2022-06-17 06:18:21.143265
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar baz=quux") == {u"foo": u"bar", u"baz": u"quux"}
    assert parse_kv(u"foo=bar baz=quux", check_raw=True) == {u"foo": u"bar", u"baz": u"quux"}
    assert parse_kv(u"foo=bar baz=quux", check_raw=False) == {u"foo": u"bar", u"baz": u"quux"}
    assert parse_kv(u"foo=bar baz=quux", check_raw=True) == {u"foo": u"bar", u"baz": u"quux"}

# Generated at 2022-06-17 06:18:29.333819
# Unit test for function split_args

# Generated at 2022-06-17 06:18:34.985824
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:18:44.318379
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:18:56.711753
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:19:05.929053
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''a=b c="foo bar"'''
    expected_result = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected_result

    # Test case 2
    args = '''a=b c="foo bar" d="{{ foo }}"'''
    expected_result = ['a=b', 'c="foo bar"', 'd="{{ foo }}"']
    result = split_args(args)
    assert result == expected_result

    # Test case 3
    args = '''a=b c="foo bar" d="{{ foo }}" e="{{ foo }} bar"'''
    expected_result = ['a=b', 'c="foo bar"', 'd="{{ foo }}"', 'e="{{ foo }} bar"']

# Generated at 2022-06-17 06:19:17.010713
# Unit test for function split_args
def test_split_args():
    # Test with no quotes or jinja2 blocks
    assert split_args('a=b c=d') == ['a=b', 'c=d']

    # Test with quotes
    assert split_args('a=b c="d e"') == ['a=b', 'c="d e"']
    assert split_args('a=b c=\'d e\'') == ['a=b', 'c=\'d e\'']

    # Test with jinja2 blocks
    assert split_args('a=b c={{ d }}') == ['a=b', 'c={{ d }}']
    assert split_args('a=b c={{ d }} e=f') == ['a=b', 'c={{ d }}', 'e=f']

# Generated at 2022-06-17 06:19:31.171521
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:19:42.919012
# Unit test for function split_args
def test_split_args():
    # Test 1
    args = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    actual = split_args(args)
    assert actual == expected

    # Test 2
    args = 'a=b c="foo bar" d="{{ foo }}"'
    expected = ['a=b', 'c="foo bar"', 'd="{{ foo }}"']
    actual = split_args(args)
    assert actual == expected

    # Test 3
    args = 'a=b c="foo bar" d="{{ foo }}" e="{{ foo }} bar"'
    expected = ['a=b', 'c="foo bar"', 'd="{{ foo }}"', 'e="{{ foo }} bar"']
    actual = split_args(args)
    assert actual == expected

    # Test 4


# Generated at 2022-06-17 06:19:51.801276
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:20:05.724462
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo="bar"') == {'foo': 'bar'}
    assert parse_kv('foo="bar" baz=quux') == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv('foo="bar baz"') == {'foo': 'bar baz'}
    assert parse_kv('foo="bar baz" baz=quux') == {'foo': 'bar baz', 'baz': 'quux'}
    assert parse_kv('foo="bar baz" baz="quux quuux"') == {'foo': 'bar baz', 'baz': 'quux quuux'}

# Generated at 2022-06-17 06:20:13.232569
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:20:25.405416
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:20:35.162987
# Unit test for function split_args

# Generated at 2022-06-17 06:20:51.413007
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c=3") == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-17 06:21:00.217387
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:21:14.494573
# Unit test for function split_args

# Generated at 2022-06-17 06:21:22.423909
# Unit test for function split_args

# Generated at 2022-06-17 06:21:35.619758
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:21:46.864714
# Unit test for function parse_kv
def test_parse_kv():
    # Test with empty string
    assert parse_kv('') == {}

    # Test with a single key value pair
    assert parse_kv('foo=bar') == {'foo': 'bar'}

    # Test with multiple key value pairs
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}

    # Test with multiple key value pairs and freeform params
    assert parse_kv('foo=bar baz qux=quux') == {'foo': 'bar', 'qux': 'quux', '_raw_params': 'baz'}

    # Test with multiple key value pairs and freeform params

# Generated at 2022-06-17 06:21:54.546405
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo="bar baz"') == {'foo': 'bar baz'}
    assert parse_kv('foo="bar baz" baz=qux') == {'foo': 'bar baz', 'baz': 'qux'}
    assert parse_kv('foo="bar baz" baz=qux') == {'foo': 'bar baz', 'baz': 'qux'}
    assert parse_kv('foo="bar baz" baz=qux') == {'foo': 'bar baz', 'baz': 'qux'}
   

# Generated at 2022-06-17 06:22:04.389676
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:22:12.009611
# Unit test for function split_args
def test_split_args():
    # Test case 1:
    # Test case:
    #   - args: 'a=b c="foo bar"'
    #   - expected result: ['a=b', 'c="foo bar"']
    args = 'a=b c="foo bar"'
    expected_result = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected_result, "Test case 1: split_args() failed"

    # Test case 2:
    # Test case:
    #   - args: 'a=b c="foo bar" d="{{ foo }}"'
    #   - expected result: ['a=b', 'c="foo bar"', 'd="{{ foo }}"']
    args = 'a=b c="foo bar" d="{{ foo }}"'

# Generated at 2022-06-17 06:22:22.326815
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e=') == {'a': 'b', 'c': 'd', 'e': ''}
    assert parse_kv('a=b c=d e= f') == {'a': 'b', 'c': 'd', 'e': '', '_raw_params': 'f'}
    assert parse_kv('a=b c=d e= f=') == {'a': 'b', 'c': 'd', 'e': '', 'f': ''}
    assert parse