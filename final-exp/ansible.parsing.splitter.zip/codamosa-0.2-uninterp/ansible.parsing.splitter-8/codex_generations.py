

# Generated at 2022-06-17 06:13:09.172321
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:13:22.979598
# Unit test for function parse_kv
def test_parse_kv():
    # Test 1
    args = "a=1 b=2 c=3"
    options = parse_kv(args)
    assert options['a'] == '1'
    assert options['b'] == '2'
    assert options['c'] == '3'

    # Test 2
    args = "a=1 b=2 c=3 d"
    options = parse_kv(args)
    assert options['a'] == '1'
    assert options['b'] == '2'
    assert options['c'] == '3'
    assert options['_raw_params'] == 'd'

    # Test 3
    args = "a=1 b=2 c=3 d e"
    options = parse_kv(args)
    assert options['a'] == '1'
    assert options['b'] == '2'
   

# Generated at 2022-06-17 06:13:31.718418
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=\'g h\'') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i j=k') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j=k'}

# Generated at 2022-06-17 06:13:35.712329
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ e }}") == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}']
    assert split_args("a=b c=\"foo bar\" d={{ e }} f={{ g }}") == ['a=b', 'c="foo bar"', 'd={{', 'e', '}}', 'f={{', 'g', '}}']

# Generated at 2022-06-17 06:13:40.199746
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args("a=b c=\"foo bar\" d='foo bar' e={{ foo }}") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d='foo bar' e={{ foo }} f={% foo %}") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e={{ foo }}', 'f={% foo %}']

# Generated at 2022-06-17 06:13:48.780437
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ foo }}" f={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ foo }}"', 'f={{ foo }}']

# Generated at 2022-06-17 06:14:02.598740
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:14:08.673753
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d", check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d _raw_params=e f") == {'a': 'b', 'c': 'd', '_raw_params': 'e f'}

# Generated at 2022-06-17 06:14:20.843170
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv("a=1 b=2 c=3") == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv("a=1 b=2 c=3 d=4") == {u'a': u'1', u'b': u'2', u'c': u'3', u'd': u'4'}
    assert parse_kv("a=1 b=2 c=3 d=4 e=5") == {u'a': u'1', u'b': u'2', u'c': u'3', u'd': u'4', u'e': u'5'}

# Generated at 2022-06-17 06:14:30.933166
# Unit test for function split_args
def test_split_args():
    '''
    This is a unit test for the function split_args.
    '''
    # Test 1
    # Test the case where the string is empty
    test_string = ''
    expected_result = []
    actual_result = split_args(test_string)
    assert actual_result == expected_result

    # Test 2
    # Test the case where the string is a single word
    test_string = 'foo'
    expected_result = ['foo']
    actual_result = split_args(test_string)
    assert actual_result == expected_result

    # Test 3
    # Test the case where the string is a single word with a space
    test_string = 'foo '
    expected_result = ['foo']
    actual_result = split_args(test_string)
    assert actual_result == expected_result



# Generated at 2022-06-17 06:14:58.479521
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e={{ bar }} f="{{ baz }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f="{{ baz }}"']

# Generated at 2022-06-17 06:15:05.757532
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:15:17.830711
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:15:24.462616
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']
    assert split_args('a=b c="foo bar" d=\\') == ['a=b', 'c="foo bar"', 'd=\\']
    assert split_args('a=b c="foo bar" d=\\\n') == ['a=b', 'c="foo bar"', 'd=\\\n']
    assert split_args('a=b c="foo bar" d=\\\ne=f') == ['a=b', 'c="foo bar"', 'd=\\\n', 'e=f']

# Generated at 2022-06-17 06:15:37.268080
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=g') == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True) == {u'a': u'b', u'c': u'd e', u'f': u'g', u'_raw_params': u'a=b c="d e" f=g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=False) == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv('a=b c="d e" f=g', check_raw=True)

# Generated at 2022-06-17 06:15:50.495825
# Unit test for function split_args
def test_split_args():
    # Test for issue #16961
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"')

# Generated at 2022-06-17 06:15:59.054582
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}
    assert parse_kv('foo=bar baz=qux xyzzy=plugh') == {'foo': 'bar', 'baz': 'qux', 'xyzzy': 'plugh'}


# Generated at 2022-06-17 06:16:08.774493
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:16:14.652547
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:16:25.255440
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d="foo\nbar"') == [u'a=b', u'c="foo bar"', u'd="foo\nbar"']
    assert split_args(u'a=b c="foo bar" d="foo\nbar" e="foo\\"bar"') == [u'a=b', u'c="foo bar"', u'd="foo\nbar"', u'e="foo\\"bar"']

# Generated at 2022-06-17 06:16:47.231783
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=g') == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv(u'a=b c="d e" f=g', check_raw=True) == {u'a': u'b', u'c': u'd e', u'f': u'g', u'_raw_params': u'a=b c="d e" f=g'}
    assert parse_kv(u'a=b c="d e" f=g', check_raw=False) == {u'a': u'b', u'c': u'd e', u'f': u'g'}

# Generated at 2022-06-17 06:16:53.930358
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:17:03.585467
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:17:09.768733
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=True) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_k

# Generated at 2022-06-17 06:17:23.469061
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux=quux') == {'foo': 'bar', 'baz': 'qux=quux'}
    assert parse_kv('foo=bar baz=qux=quux=corge') == {'foo': 'bar', 'baz': 'qux=quux=corge'}
    assert parse_kv('foo=bar baz=qux=quux=corge=grault') == {'foo': 'bar', 'baz': 'qux=quux=corge=grault'}
    assert parse_kv

# Generated at 2022-06-17 06:17:29.665416
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-17 06:17:44.937821
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args("a=b c=\"foo bar\" d='foo bar' e={{ foo }}") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d='foo bar' e={{ foo }} f={% foo %}") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e={{ foo }}', 'f={% foo %}']

# Generated at 2022-06-17 06:17:52.341211
# Unit test for function parse_kv
def test_parse_kv():
    # Test with a string with no equal sign
    assert parse_kv("test") == {}

    # Test with a string with a single equal sign
    assert parse_kv("test=test") == {u'test': u'test'}

    # Test with a string with a single equal sign and a space
    assert parse_kv("test = test") == {u'test': u'test'}

    # Test with a string with a single equal sign and a space
    assert parse_kv("test = test") == {u'test': u'test'}

    # Test with a string with a single equal sign and a space
    assert parse_kv("test = test") == {u'test': u'test'}

    # Test with a string with a single equal sign and a space

# Generated at 2022-06-17 06:18:06.376965
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }} e={{ bar }} f={{ foo }}{{ bar }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ bar }}', 'f={{ foo }}{{ bar }}']
    assert split

# Generated at 2022-06-17 06:18:20.822499
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux', check_raw=True) == {u'foo': u'bar', u'baz': u'qux'}

# Generated at 2022-06-17 06:18:36.908126
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args("a=b c=\"foo bar\" d='foo bar' e='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'", "e='foo bar'"]
    assert split_args("a=b c=\"foo bar\" d='foo bar' e='foo bar' f=\"foo bar\"") == ['a=b', 'c="foo bar"', "d='foo bar'", "e='foo bar'", 'f="foo bar"']

# Generated at 2022-06-17 06:18:42.841164
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3 d=4') == {'a': '1', 'b': '2', 'c': '3', 'd': '4'}
    assert parse_kv('a=1 b=2 c=3 d=4 e=5') == {'a': '1', 'b': '2', 'c': '3', 'd': '4', 'e': '5'}

# Generated at 2022-06-17 06:18:52.526223
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e', check_raw=True) == {'a': 'b', 'c': 'd', '_raw_params': 'e'}

# Generated at 2022-06-17 06:19:02.991558
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:19:11.276811
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv

# Generated at 2022-06-17 06:19:24.354209
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 06:19:36.602418
# Unit test for function split_args

# Generated at 2022-06-17 06:19:49.817567
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 06:19:56.133606
# Unit test for function split_args
def test_split_args():
    # Test 1
    args = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    assert split_args(args) == expected

    # Test 2
    args = 'a=b c="foo bar" d=\'foo bar\''
    expected = ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args(args) == expected

    # Test 3
    args = 'a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\''
    expected = ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args(args) == expected

    # Test 4

# Generated at 2022-06-17 06:20:08.507170
# Unit test for function split_args
def test_split_args():
    # Test 1
    # Test case:
    #   Input:
    #       args = 'a=b c="foo bar"'
    #   Expected output:
    #       ['a=b', 'c="foo bar"']
    args = 'a=b c="foo bar"'
    expected_output = ['a=b', 'c="foo bar"']
    actual_output = split_args(args)
    assert actual_output == expected_output

    # Test 2
    # Test case:
    #   Input:
    #       args = 'a=b c="foo bar" d="foo bar"'
    #   Expected output:
    #       ['a=b', 'c="foo bar"', 'd="foo bar"']
    args = 'a=b c="foo bar" d="foo bar"'
    expected_output

# Generated at 2022-06-17 06:20:35.070611
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f="g h"') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f="g h" i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f="g h" i j') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j'}

# Generated at 2022-06-17 06:20:44.479175
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e" f=\'g h\'') == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i'}
    assert parse_kv(u'a=b c="d e" f=\'g h\' i j=k') == {u'a': u'b', u'c': u'd e', u'f': u'g h', u'_raw_params': u'i j=k'}

# Generated at 2022-06-17 06:20:58.324280
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c=3") == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv("a=1 b=2 c=3", check_raw=True) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-17 06:21:08.254031
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}
    assert parse_kv(u'foo=bar baz=qux spam=eggs') == {u'foo': u'bar', u'baz': u'qux', u'spam': u'eggs'}

# Generated at 2022-06-17 06:21:20.372833
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}"') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"']
    assert split_args('a=b c="foo bar" d={{ foo }} e="{{ bar }}" f={{ bar }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"', 'f={{ bar }}']

# Generated at 2022-06-17 06:21:34.678578
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-17 06:21:46.090406
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = '''a=b c="foo bar"'''
    expected = ['a=b', 'c="foo bar"']
    assert split_args(args) == expected

    # Test case 2
    args = '''a=b c="foo bar" d={{ foo }}'''
    expected = ['a=b', 'c="foo bar"', 'd={{ foo }}']
    assert split_args(args) == expected

    # Test case 3
    args = '''a=b c="foo bar" d={{ foo }} e="{{ bar }}"'''
    expected = ['a=b', 'c="foo bar"', 'd={{ foo }}', 'e="{{ bar }}"']
    assert split_args(args) == expected

    # Test case 4

# Generated at 2022-06-17 06:21:54.190487
# Unit test for function split_args
def test_split_args():
    # Test for simple case
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']

    # Test for simple case with newlines
    assert split_args("a=b\nc=\"foo bar\"") == ['a=b', 'c="foo bar"']

    # Test for simple case with newlines and spaces
    assert split_args("a=b\n c=\"foo bar\"") == ['a=b', 'c="foo bar"']

    # Test for simple case with newlines and spaces
    assert split_args("a=b\n c=\"foo bar\"") == ['a=b', 'c="foo bar"']

    # Test for simple case with newlines and spaces

# Generated at 2022-06-17 06:22:01.141910
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar"') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args('a=b c="foo bar" d=\'foo bar\' e="foo bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]
    assert split_args

# Generated at 2022-06-17 06:22:11.583144
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e=') == {'a': 'b', 'c': 'd', 'e': ''}
    assert parse_kv('a=b c=d e=\\') == {'a': 'b', 'c': 'd', 'e': '\\'}
    assert parse_kv('a=b c=d e=\\\\') == {'a': 'b', 'c': 'd', 'e': '\\\\'}

# Generated at 2022-06-17 06:22:38.547340
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv('foo=bar baz=qux spam=eggs') == {'foo': 'bar', 'baz': 'qux', 'spam': 'eggs'}
    assert parse_kv