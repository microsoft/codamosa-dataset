

# Generated at 2022-06-25 04:01:33.677101
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 04:01:37.827910
# Unit test for function parse_kv
def test_parse_kv():
    string_0 = '-rwxr-xr-x  1 root root  3.2K Dec 24  2018 /bin/ls'
    var_0 = parse_kv(string_0)
    string_1 = '-rwxr-xr-x  1 root root  3.2K Dec 24  2018 /bin/ls'
    var_1 = parse_kv(string_1)
    string_2 = '-rwxr-xr-x  1 root root  3.2K Dec 24  2018 /bin/ls'
    var_2 = parse_kv(string_2)
    string_3 = '-rwxr-xr-x  1 root root  3.2K Dec 24  2018 /bin/ls'
    var_3 = parse_kv(string_3)
    string_

# Generated at 2022-06-25 04:01:49.045114
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv(args=u'create table if not exists tab (id int);')
    assert(options[u'_raw_params'] == u'create table if not exists tab (id int);')

    options = parse_kv(args=u'create table if not exists tab (id int);')
    assert(options[u'_raw_params'] == u'create table if not exists tab (id int);')

    try:
        options = parse_kv(args=u'\x00\x01\x02')
    except Exception:
        print(u'Failed')
        pass
    else:
        print('Error')
        assert False

#
# Code copied from /lib/python2.7/shlex.py because its not available
# in Ansible 2.4


# Generated at 2022-06-25 04:01:57.173759
# Unit test for function split_args
def test_split_args():

    # Test 0
    print("Testing case 0")
    bytes_0 = b'\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B'
    result_0 = split_args(bytes_0)
    expected_0 = ['\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B']

    if result_0 == expected_0:
        print("Test case passed")
    else:
        print("Test case failed, expected output: " + str(expected_0) + ", got: " + str(result_0))

# Generated at 2022-06-25 04:02:04.715387
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B'
    var_0 = parse_kv(bytes_0)

    assert var_0 == {}, var_0
    bytes_1 = b'\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B'
    var_1 = parse_kv(bytes_1)

    assert var_1 == {}, var_1

# Generated at 2022-06-25 04:02:07.174298
# Unit test for function parse_kv
def test_parse_kv():
    # FIXME: Test the test_case_0
    pass



# Generated at 2022-06-25 04:02:17.483539
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv(b'\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B') == {})

# Generated at 2022-06-25 04:02:23.065737
# Unit test for function parse_kv
def test_parse_kv():
    # Test with a working good example
    assert parse_kv(b'key1=val1 key2="quoted val2" key3=\'quoted val3\' key4=val4') == {'key1': 'val1', 'key3': '\'quoted val3\'', 'key2': '"quoted val2"', 'key4': 'val4'}
    # Test with an unsupported unicode escaped string
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 04:02:31.570565
# Unit test for function split_args

# Generated at 2022-06-25 04:02:42.563988
# Unit test for function split_args
def test_split_args():
    test_cases=[]
    with open('./python-debugger/parser_test_cases.txt') as f:
        for line in f:
            test_cases.append(line.strip())
            print(line)

    for i in range(len(test_cases)):
        test_case = test_cases[i]
        bytes_0 = test_case.encode()
        print(bytes_0)
        print(type(bytes_0))
        var_0 = split_args(bytes_0)
        print(var_0)
        print('\n')


# Generated at 2022-06-25 04:03:11.808740
# Unit test for function split_args
def test_split_args():
    '''
    Test case for function split_args
    '''
    # Inputs
    # Return value tests
    # Function tests
    assert split_args('abc=def ghi=jkl') == ['abc=def', 'ghi=jkl']
    assert split_args('mno pqr=stu') == ['mno', 'pqr=stu']
    assert split_args('vwx=yz{}') == ['vwx=yz{}']
    assert split_args('a="123 456"') == ['a="123 456"']
    assert split_args('{{foo}}') == ['{{foo}}']
    assert split_args('{{foo}} bar="{{biz}}"') == ['{{foo}}', 'bar="{{biz}}"']

# Generated at 2022-06-25 04:03:12.802661
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

# Generated at 2022-06-25 04:03:18.715917
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing function parse_kv')
    # Debug: parse_kv(vargs)
    # Debug: _decode_escapes(orig_x)
    # Debug: _ESCAPE_SEQUENCE_RE.sub(decode_match, s)
    test_case_0()


# Generated at 2022-06-25 04:03:24.513326
# Unit test for function parse_kv
def test_parse_kv():
    n = 'test_case_0'
    v = globals()[n]
    print(v)


# https://docs.python.org/3/library/shlex.html

# Generated at 2022-06-25 04:03:31.701249
# Unit test for function split_args
def test_split_args():
    args1 = "git clone https://github.com/lingxiankong/vulnspy.git /home/lingxiankong/vulnspy"
    params1 = split_args(args1)

    for param in params1:
        print(param)

    args2 = "{{ 'https://github.com/lingxiankong/vulnspy.git' }}"
    params2 = split_args(args2)

    for param in params2:
        print(param)


# Generated at 2022-06-25 04:03:36.642842
# Unit test for function split_args

# Generated at 2022-06-25 04:03:48.216199
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('"foo"') == ['"foo"']
    assert split_args('{% foo %}') == ['{% foo %}']
    assert split_args('{{ foo }}') == ['{{ foo }}']
    assert split_args('{{ foo }} {% bar %}') == ['{{ foo }}', '{% bar %}']
    assert split_args('foo bar=baz') == ['foo', 'bar=baz']
    assert split_args('foo bar=baz qux=quux') == ['foo', 'bar=baz', 'qux=quux']

# Generated at 2022-06-25 04:03:58.421528
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'c\x82\x9e\x06\xdd\x03\xe0\xdc\xc2\x8d\x1a\x1c\x05\xad8\x0c'
    str_1 = 'b\x07\xd1\x0f\x9e\x07\x02\x0b\x85\xdc[\xe1\xbe\x9b\xfa\x1b'
    str_2 = 'a'
    str_3 = 'd'

# Generated at 2022-06-25 04:04:07.168264
# Unit test for function split_args
def test_split_args():
    test_case_0()


if __name__ == "__main__":
    test_split_args()



#     args = to_text(args, nonstring='passthru')
#
#     options = {}
#     if args:
#         for x in args.split():
#             if "=" in x:
#                 (k, v) = x.split("=", 1)
#                 options[k.strip()] = to_text(unquote(v.strip()))
#             else:
#                 options[x] = True
#
#     return options

# Generated at 2022-06-25 04:04:14.847684
# Unit test for function split_args
def test_split_args():
    a = "ax -b yz -c xyz"
    b = a.split()
    c = split_args(a)
    if b == c:
        print('equal')
    else:
        print('not equal')


# Generated at 2022-06-25 04:04:38.450936
# Unit test for function parse_kv
def test_parse_kv():
    #test case 0
    bytes_0 = b'\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B'
    var_0 = parse_kv(bytes_0)

    #test case 1
    bytes_1 = b'\xaeT\x11R\xee\x11\x02\x8b\x87\xbc\xa9'
    var_1 = parse_kv(bytes_1)

    #test case 2

# Generated at 2022-06-25 04:04:46.593918
# Unit test for function split_args
def test_split_args():
    input_str = "--start-date='2017-01-01' --end-date=\"2017-08-27\" --ttl=2017-12-31 --page-size=100 --page-num=1 --format=json"
    result = split_args(input_str)
    assert len(result) == 6
    assert result[0] == "--start-date='2017-01-01'"
    assert result[1] == "--end-date=\"2017-08-27\""
    assert result[2] == "--ttl=2017-12-31"
    assert result[3] == "--page-size=100"
    assert result[4] == "--page-num=1"
    assert result[5] == "--format=json"


# Generated at 2022-06-25 04:04:54.662666
# Unit test for function split_args
def test_split_args():
    # test case 0
    bytes_0 = b'\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B'
    var_0 = split_args(bytes_0)
    # make sure the answer is correct, should be ['\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B']

# Generated at 2022-06-25 04:05:00.784878
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(b'a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv(b'a="b c d"') == {u'a': u'b c d'}
    #assert parse_kv(b"a='b c d'") == {u'a': u'b c d'}
    assert parse_kv(b'a=b c="d e" f=g') == {u'a': u'b', u'c': u'd e', u'f': u'g'}


# ---------- parsing.utils.to_text functions ----------


# Generated at 2022-06-25 04:05:07.247108
# Unit test for function split_args
def test_split_args():
    # Test case data
    bytes_0 = b'a=b c="foo bar"'
    bytes_1 = b'a=b c="foo bar" d="""multi \n line \n quotes"""'
    bytes_2 = b'a=b c="foo bar" d=\'single quotes\''
    bytes_3 = b'a=b c="foo bar" d=\\'
    bytes_4 = b'-x -arg1 -arg2 -arg3 --foo bar'
    bytes_5 = b'-x -arg1 -arg2 -arg3 --foo bar -'
    bytes_6 = b'-x -arg1 -arg2 -arg3 --foo bar - '
    bytes_7 = b'-x -arg1 -arg2 -arg3 -'

# Generated at 2022-06-25 04:05:09.829021
# Unit test for function split_args
def test_split_args():
    expected = ['a=b', 'c="foo bar"']
    result = split_args(b'a=b c="foo bar"')
    assert result == expected


# Generated at 2022-06-25 04:05:12.340591
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'abcd efg hijkl'
    var_0 = parse_kv(bytes_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:05:12.998411
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()



# Generated at 2022-06-25 04:05:17.017375
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B'
    var_0 = parse_kv(bytes_0)
    print('Test case 0:')
    print('Input', bytes_0)
    print('Output', var_0)
    print('')


# Generated at 2022-06-25 04:05:27.431767
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv(b'\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B')
    # split_args(None)
    if (var_0):
        var_0 += 1
    else:
        var_0 = 0
    # same function
    if (var_0):
        var_0 += 1
    else:
        var_0 = 0
    # Not applicable
    if (var_0):
        var_0 += 1
    else:
        var_0 = 0
    # call to join_args
    if (var_0):
        var_0 += 1
    else:
        var_0 = 0
    # call

# Generated at 2022-06-25 04:05:44.439853
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-25 04:05:46.161361
# Unit test for function split_args
def test_split_args():
    test_case = """
        {{ lookup('file', '/path/to/file') }}
    """
    print(split_args(test_case))


# Generated at 2022-06-25 04:05:50.897922
# Unit test for function parse_kv
def test_parse_kv():
    res = parse_kv('host=1.1.1.1 port=1111 group=c\\=a\\,b user=foo')
    assert res['host'] == '1.1.1.1'
    assert res['port'] == '1111'
    assert res['group'] == 'c=a,b'
    assert res['user'] == 'foo'



# unit test for function split_args

# Generated at 2022-06-25 04:05:54.423007
# Unit test for function parse_kv
def test_parse_kv():
    # Test top-level function call only
    #assert 1 == 2
    test_case_0()

# Main function for testing

# Generated at 2022-06-25 04:05:59.036180
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'-p 8080 -k True -k "False" -l \x00 -e "bad\x00escape\\\\\\" -e "bad\x0aescape\\\\\\" -e "good\\\\\\" -f bar -s True -i foo'
    var_0 = parse_kv(bytes_0)
    print(var_0)


# Generated at 2022-06-25 04:06:02.128716
# Unit test for function parse_kv
def test_parse_kv():
    assert isinstance(parse_kv, types.FunctionType)
    parse_kv('sp=sys_service_profile, name=None')


# Generated at 2022-06-25 04:06:09.316608
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b "c=foo bar"') == [u'a=b', u'"c=foo bar"']
    assert split_args(u'a=b "c=foo bar"') == [u'a=b', u'"c=foo bar"']
    assert split_args(u'a=b c=\\"foo bar\\"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c=\\"foo bar\\"') == [u'a=b', u'c="foo bar"']

# Generated at 2022-06-25 04:06:18.375260
# Unit test for function split_args
def test_split_args():
    args = "{{ foo }}"
    result = split_args(args)
    assert len(result) == 1, "Expecting len(result) to be 1, got %s" % len(result)
    assert result[0] == "{{ foo }}", "Expecting result[0] to be {{ foo }}, got %s" % result[0]
    args = "{{ foo }} {{ bar }}"
    result = split_args(args)
    assert len(result) == 3, "Expecting len(result) to be 3, got %s" % len(result)
    assert result[0] == "{{", "Expecting result[0] to be {{, got %s" % result[0]
    assert result[1] == "foo", "Expecting result[1] to be foo, got %s" % result[1]
   

# Generated at 2022-06-25 04:06:23.756583
# Unit test for function split_args
def test_split_args():
    """
    Test split_args function with a variable input
    """
    args = 'a=b c="foo bar"'
    output = split_args(args)
    assert output == ['a=b', 'c="foo bar"']


# Generated at 2022-06-25 04:06:34.153556
# Unit test for function parse_kv
def test_parse_kv():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.collections import is_sequence

    str_0 = u'HOME'
    str_1 = u'HOME=foo'
    str_2 = u"HOME='foo bar'"
    str_3 = u'HOME="/foo bar/"'
    str_4 = u'HOME=foo bar'
    str_5 = u'HOME=foo\ bar'
    str_6 = u'HOME=\\foo\\ bar'
    str_7 = u'HOME=foo\\ bar'
    str_8 = u'HOME=foo bar\\'
    str_9 = u'HOME=foo bar\\\nfubar'
    str_10 = u'HOME=\U0001f603\n'

    #Invalid string
    str_11

# Generated at 2022-06-25 04:06:46.306725
# Unit test for function parse_kv
def test_parse_kv():
    assert b'ansible' == b'ansible'
    assert b'ansible' != b'ansiblee'
    assert b'ansible'.upper() == 'ANSIBLE'
    assert b'ansible'.lower() == 'ansible'
    assert b'ansible'.capitalize() == 'Ansible'
    assert b'ansible'.title() == 'Ansible'
    assert b'ansible'.swapcase() == 'ANSIBLE'



# Generated at 2022-06-25 04:06:56.349614
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar'], \
        "foo bar did not split properly"
    assert split_args('foo\nbar') == ['foo\nbar'], \
        "foo\\nbar did not split properly"
    assert split_args('foo\nbar') == ['foo\nbar'], \
        "foo\\nbar did not split properly"
    assert split_args('''foo 'bar baz' "blah blah"''') == ['foo', 'bar baz', 'blah blah'], \
        "foo 'bar baz' \"blah blah\" did not split properly"
    assert split_args('foo="bar baz"') == ['foo=bar baz'], \
        "foo=\"bar baz\" did not split properly"

# Generated at 2022-06-25 04:07:03.861702
# Unit test for function split_args
def test_split_args():
    arg_str = 'a=b\n c="foo bar"\n d=\'foo bar\''
    arg_list = split_args(arg_str)
    assert(arg_list == ['a=b', 'c="foo bar"', "d='foo bar'"])

    arg_str = 'a=b\n c="foo bar"  d=\'foo bar\''
    arg_list = split_args(arg_str)
    assert(arg_list == ['a=b', 'c="foo bar"', "d='foo bar'"])

    arg_str = '''a=b
 c="foo bar"
 d='foo bar'
 e=\''
'''
    arg_list = split_args(arg_str)

# Generated at 2022-06-25 04:07:09.963471
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'src=/etc/ansible/hosts\x00'
    var_0 = parse_kv(bytes_0)

    return var_0


# Split args into a list of strings. Handles arguments that have spaces/quotes in them
# or arguments that are left empty.

# Generated at 2022-06-25 04:07:12.553685
# Unit test for function split_args
def test_split_args():
    args = '''a=b cd
    ef="gh  i" jk=\'lm \' no=pq " r "
    '''
    split_args(args)


# Generated at 2022-06-25 04:07:20.772332
# Unit test for function parse_kv
def test_parse_kv():
    # 0000000: 0f93 d518 e3a9 85c9 7e65 5bb2 f9d3 d0c1  .....~e[....
    # 0000010: 8d07 42                                  ..B

    bytes_0 = b'\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B'

    var_0 = parse_kv(bytes_0)
    assert var_0 == {}
    assert type(var_0) is dict


# Generated at 2022-06-25 04:07:28.299632
# Unit test for function parse_kv
def test_parse_kv():
    assert len(parse_kv("a=1 b=2")) == 2
    assert len(parse_kv("a=1 b=2 c=3")) == 3
    assert len(parse_kv("a=1 b=\"2 c=3\"")) == 2
    assert len(parse_kv("a=1 b=\"2=c=3\"")) == 2
    assert len(parse_kv("a=1 b=\"2=c=3\" c=4")) == 3
    assert len(parse_kv("a=1 b=2\" c=4 d=5")) == 3


# Generated at 2022-06-25 04:07:35.453715
# Unit test for function split_args
def test_split_args():
    # Args
    #   args: string of comma separated commands.
    # Returns
    #   A list of commands.

    # Tests
    args = '{{ foo }} bar baz'
    res = split_args(args)
    assert(res == ['{{ foo }}', 'bar', 'baz'])

    args = 'foo"bar baz"qux'
    res = split_args(args)
    assert(res == ['foo"bar baz"qux'])

    args = 'foo"bar" baz'
    res = split_args(args)
    assert(res == ['foo"bar"', 'baz'])

    args = 'foo\'bar\' baz'
    res = split_args(args)
    assert(res == ['foo\'bar\'', 'baz'])


# Generated at 2022-06-25 04:07:36.845351
# Unit test for function split_args
def test_split_args():
    #TODO: Add a unit test for split_args
    pass


# Generated at 2022-06-25 04:07:40.918165
# Unit test for function parse_kv
def test_parse_kv():
    for i in range(1000):
        test_case_0()

# Collect all tests in this file
test_list = [
    test_parse_kv,
]

# Run tests
for test in test_list:
    test()

print("Finish running test cases")

# Generated at 2022-06-25 04:08:00.447072
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = b'"a=b" c=d'
    var_1 = parse_kv(var_0)
    assert isinstance(var_1, dict)
    assert len(var_1) == 2
    assert var_1['c'] == 'd'
    assert isinstance(var_1['c'], str)
    assert isinstance(var_1['c'], str)
    var_2 = var_1['c']
    assert var_2 == 'd'
    assert var_1['a'] == 'b'
    assert isinstance(var_1['a'], str)
    assert isinstance(var_1['a'], str)
    var_3 = var_1['a']
    assert var_3 == 'b'


# Generated at 2022-06-25 04:08:04.047610
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B'
    var_0 = parse_kv(bytes_0)


# Generated at 2022-06-25 04:08:07.471171
# Unit test for function parse_kv
def test_parse_kv():
    fp = open('test_kv.txt')
    lines = fp.readlines()
    for line in lines:
        try:
            line2 = line.split('==')[1].strip()
            print(line2)
            print(parse_kv(line2))
            print()
        except:
            pass


# Generated at 2022-06-25 04:08:17.960900
# Unit test for function split_args
def test_split_args():
    args = "a=b c='foo bar' d=\"foo bar\\\"\" e='foo bar\\\"\"'"
    print("args = {}".format(args))
    split_list = split_args(args)
    print("split_list = {}".format(split_list))
    for arg in split_list:
        print("arg = {}".format(arg))

    args = "a=b c='foo bar' d=\"foo bar\\\"\" e='foo bar\\\"\"' f='\n'"
    print("args = {}".format(args))
    split_list = split_args(args)
    print("split_list = {}".format(split_list))
    for arg in split_list:
        print("arg = {}".format(arg))

    args = "a='\n'"

# Generated at 2022-06-25 04:08:28.186123
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing parse_kv()")

    params_str_1 = "echo 'hello world'"
    expected_1 = dict()
    expected_1['_raw_params'] = params_str_1
    actual_1 = parse_kv(params_str_1, True)
    assert expected_1 == actual_1

    params_str_2 = "key1=value1 key2=value2"
    expected_2 = dict()
    expected_2['key1'] = 'value1'
    expected_2['key2'] = 'value2'
    actual_2 = parse_kv(params_str_2)
    assert expected_2 == actual_2

    params_str_3 = "key1='value1 with spaces'"
    expected_3 = dict()

# Generated at 2022-06-25 04:08:33.456578
# Unit test for function parse_kv
def test_parse_kv():
    # Test one:
    # Test the statement:
    # Parse the key-value pair string in args and return the result as a dict.
    # If check_raw is set to True, the raw arguments will be assigned to a new
    # dict parameter called '_raw_params'.
    test_case_0()

# Generated at 2022-06-25 04:08:37.897671
# Unit test for function parse_kv
def test_parse_kv():
    assert_raises(AnsibleError, parse_kv, 'a=b=c')
    assert_raises(None, parse_kv, 'a=b')


# Generated at 2022-06-25 04:08:48.570877
# Unit test for function parse_kv
def test_parse_kv():
    assert decode_kv(b'\x94\xbe\x17\x19\xc36\x04\xc3\xee\x16\x9d\xef\x97\xd1\xcb\x8d\xa3\xfa\xa7\xab\x8d\x1b\xad\x99\xf4\xe5\x14`') == b'\xfc\x9c\xd5\x80\x07\xfe\x04\xf6\x82\xc1\x98\x82\x80\x9c\x81\x0c\x1f\xeb\xe6\xc1\x1f\xef\x82\x9e\x97\x0c\xac\x8d\x94\x0e'


# Generated at 2022-06-25 04:08:58.121281
# Unit test for function parse_kv
def test_parse_kv():
    case_0 = b'\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B'
    case_1 = b'\x10\x93\xd5\x19\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B'
    case_2 = b'\x11\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B'

# Generated at 2022-06-25 04:09:08.824559
# Unit test for function split_args
def test_split_args():

    # test_case_1
    # test_case_1:
    # arg_str = 'a=b c="foo bar"'
    test_case_1_arg_str = 'a=b c="foo bar"'
    # output_result = ['a=b', 'c="foo bar"']
    test_case_1_output_result = ['a=b', 'c="foo bar"']
    # run function split_args
    test_case_1_splited_str = split_args(test_case_1_arg_str)
    # compare if split_args result is correct
    if test_case_1_splited_str == test_case_1_output_result:
        print("Test Case 1 Passed")
    else:
        print("Test Case 1 Failed")

    # test_case_2
    #

# Generated at 2022-06-25 04:09:27.842691
# Unit test for function parse_kv
def test_parse_kv():
    print("test case 1: ")
    # Test case 1:
    # bytes_1 is a dict
    bytes_1 = b"a='b' c='d' e='f'"
    var_1 = parse_kv(bytes_1)
    # print var_1

    print("test case 2: ")
    # Test case 2:
    # bytes_2 is a dict with key and value in quotation marks
    bytes_2 = b"a=\"b\" c=\"d\" e=\"f\""
    var_2 = parse_kv(bytes_2)
    # print var_2

    print("test case 3: ")
    # Test case 3:
    # bytes_3 is a dict with key and value in single quotation marks
    bytes_3 = b"a='b' c='d' e='f'"
   

# Generated at 2022-06-25 04:09:30.017427
# Unit test for function split_args
def test_split_args():

    # Test case 0
    test_case_0()



# Generated at 2022-06-25 04:09:36.944225
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv('-k KEY -v "VALUE"')
    assert var_0 == {'k': 'KEY', 'v': 'VALUE'}

    var_1 = parse_kv('"FOO bar baz"')
    assert var_1 == {'_raw_params': 'FOO bar baz'}

    var_2 = parse_kv('\'FOO bar baz\'')
    assert var_2 == {'_raw_params': 'FOO bar baz'}

    var_3 = parse_kv('-k "FOO bar baz"')
    assert var_3 == {'k': 'FOO bar baz'}

    var_4 = parse_kv('-k "FOO b=ar baz"')

# Generated at 2022-06-25 04:09:38.558358
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing parse_kv")
    test_case_0()


# Generated at 2022-06-25 04:09:49.493292
# Unit test for function parse_kv
def test_parse_kv():
    print(parse_kv(b''))
    print(parse_kv(b'a=b'))
    print(parse_kv(b'a=b c=d'))
    print(parse_kv(b'a=b\nc=d'))
    print(parse_kv(b'a=b\nc=d\\=e f=g'))
    print(parse_kv(b"a=b\\=c\\\\=d"))
    print(parse_kv(b"a=b\\'c\\\\'=d"))
    print(parse_kv(b"a=b\\'c\\\\'=d\\'e\\''f=g"))
    print(parse_kv(b"a=b\\u1234\\u5678"))

# Generated at 2022-06-25 04:09:56.748271
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.common._collections_compat import Mapping
    assert callable(parse_kv)
    assert isinstance(parse_kv(u'', True), Mapping)
    assert isinstance(parse_kv(b'', True), Mapping)
    assert isinstance(parse_kv('', True), Mapping)
    assert parse_kv('', True) == {}
    test_case_0()

# Generated at 2022-06-25 04:10:01.703441
# Unit test for function parse_kv
def test_parse_kv():
    parameters = parse_kv(b"OPTARG='${OPTARG}'")
    assert(parameters == {'OPTARG': '${OPTARG}'})

    parameters = parse_kv(b"OPTARG='${OPTARG}' chdir=/abc")
    assert(parameters == {'OPTARG': '${OPTARG}', 'chdir': '/abc'})

# This tests the parsing of the raw options

# Generated at 2022-06-25 04:10:11.551542
# Unit test for function split_args
def test_split_args():
    args = """
    a=b c="foo \\\"bar\\\"" e={{overwrite_foo}} f=1 g=2 h=3 d={{overwrite_foo}}
    """
    params = split_args(args)
    assert len(params) == 8, params
    assert params[0] == 'a=b'
    assert params[1] == 'c="foo \\\\"bar\\\\""'
    assert params[2] == 'e={'
    assert params[3] == 'overwrite_foo'
    assert params[4] == '}'
    assert params[5] == 'f=1'
    assert params[6] == 'g=2'
    assert params[7] == 'h=3 d={'


# Generated at 2022-06-25 04:10:19.118906
# Unit test for function split_args
def test_split_args():
    args = b'{0}'
    b = args.format(b"a=b c='foo bar' d=\"bar doe\" e=f g='h \" i \" j' k='l \" m \" n \" x \" y \" z' l='o p=\" q \" r' s=t")
    c = args.format(u"a=b c='foo bar' d=\"bar doe\" e=f g='h \" i \" j' k='l \" m \" n \" x \" y \" z' l='o p=\" q \" r' s=t")
    a = args.format(u"a=b c=foo\\ bar d=\"bar doe\" e=f g=\"h \\\" i \\\" j k='l \" m \" n \" x \" y \" z' l='o p=\" q \" r' s=t")


# Generated at 2022-06-25 04:10:29.422165
# Unit test for function parse_kv
def test_parse_kv():
    # change here for specific function
    function_name = 'parse_kv'

    # list of values for function to test
    test_list = [
        '\x0f\x93\xd5\x18\xe3\xa9\x85\xc9~e[\xb2\xf9\xd3\xd0\xc1\x8d\x07B'
    ]

    # call the function and test its output
    for test in test_list:
        var = parse_kv(test)
        if hasattr(var, '__iter__'):
            print_res(var, function_name)
        else:
            print_res(str(var), function_name)

# test function for function parse_kv

# Generated at 2022-06-25 04:10:49.260599
# Unit test for function split_args
def test_split_args():
    # testcase 0 - simple case with no quotes or jinja2 blocks
    s_0 = u'a=b c="foo bar"'
    e_0 = [b'a=b', b'c="foo bar"']

    p_0 = split_args(s_0)
    assert p_0 == e_0

    # testcase 1 - quote does not close before next param
    s_1 = u'a=b c="foo bar d=e'
    e_1 = [b'a=b', b'c="foo bar d=e']

    p_1 = split_args(s_1)
    assert p_1 == e_1

    # testcase 2 - quote does not close before end of line
    s_2 = u'a=b c="foo bar'

# Generated at 2022-06-25 04:10:53.595144
# Unit test for function parse_kv
def test_parse_kv():
    test_results = [ {"input": 'a=b c=d "e = f"', "result": {'a': 'b', 'c': 'd', 'e = f': None}} ]

    expected_results = [ {"output": {'a': 'b', 'c': 'd', 'e = f': None}} ]

    test_count = 0
    for test_result in test_results:
        output = parse_kv(test_result['input'])
        expected = expected_results[test_count]

        assert output == expected['output']

        print(output)
        print(expected['output'])

        test_count += 1

# Generated at 2022-06-25 04:11:04.335615
# Unit test for function split_args
def test_split_args():
    """split_args() uses shlex to split on whitespace, but intelligently reassembles those that may have been split over a jinja2 block or quotes."""
    # These are the actual test cases