

# Generated at 2022-06-25 04:01:56.224642
# Unit test for function split_args
def test_split_args():
    params = []
    params = split_args(b'Hello world!')
    print(params)
    assert(params == ['Hello', 'world!'])


# Generated at 2022-06-25 04:01:57.800317
# Unit test for function parse_kv
def test_parse_kv():
    print("Parse Key Value")
    bytes_0 = b'test'
    var_0 = parse_kv(bytes_0)
    print(var_0)


# Generated at 2022-06-25 04:02:04.353304
# Unit test for function split_args

# Generated at 2022-06-25 04:02:12.956906
# Unit test for function parse_kv
def test_parse_kv():
    print("Test: parse_kv")
    # Test case #0
    var_0 = parse_kv('/usr/bin/ls -l')
    assert var_0[u'_raw_params'] == '/usr/bin/ls -l'

    # Test case #1
    var_1 = parse_kv('/usr/bin/ls -l --col=16')
    assert var_1[u'_raw_params'] == '/usr/bin/ls -l'
    assert var_1[u'--col'] == '16'

    # Test case #2
    var_2 = parse_kv('/usr/bin/ls -l --col=16 --color=never')
    assert var_2[u'_raw_params'] == '/usr/bin/ls -l'

# Generated at 2022-06-25 04:02:23.647009
# Unit test for function split_args
def test_split_args():
    args = 'foo=bar'
    result = split_args(args)
    assert [u'foo=bar'] == result
    args = 'foo=bar "baz qux"'
    result = split_args(args)
    assert [u'foo=bar', u'"baz qux"'] == result
    args = 'foo="bar baz"'
    result = split_args(args)
    assert [u'foo="bar baz"'] == result
    args = 'foo=bar "baz=qux"'
    result = split_args(args)
    assert [u'foo=bar', u'"baz=qux"'] == result
    args = 'foo=bar "baz=qux=foo"'
    result = split_args(args)

# Generated at 2022-06-25 04:02:24.371864
# Unit test for function parse_kv
def test_parse_kv():
    assert True


# Generated at 2022-06-25 04:02:33.168357
# Unit test for function split_args
def test_split_args():
    ##
    ## >>> split_args("example.yml")
    ## ['example.yml']
    ##
    expected_result = ['example.yml']
    parser_input = 'example.yml'
    actual_result = split_args(parser_input)
    assert actual_result == expected_result, \
            "{} != {} (actual != expected)".format(actual_result, expected_result)

    ##
    ## >>> split_args("'example.yml'")
    ## ['\'example.yml\'']
    ##
    expected_result = ["'example.yml'"]
    parser_input = "'example.yml'"
    actual_result = split_args(parser_input)

# Generated at 2022-06-25 04:02:41.458843
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv('foo=bar baz=quux')
    assert options['foo'] == u'bar'
    assert options['baz'] == u'quux'
    assert '_raw_params' not in options

    options = parse_kv('foo=bar baz=quux xyzzy')
    assert options['foo'] == u'bar'
    assert options['baz'] == u'quux'
    assert options['_raw_params'] == u'xyzzy'

    options = parse_kv('foo=bar baz=quux xyzzy', check_raw=True)
    assert options['foo'] == u'bar'
    assert options['baz'] == u'quux'
    assert options[u'_raw_params'] == u'xyzzy'


# Generated at 2022-06-25 04:02:44.501404
# Unit test for function split_args
def test_split_args():
    assert split_args(b'this is a test') == ['this', 'is', 'a', 'test']


# Generated at 2022-06-25 04:02:51.788322
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar foobar"') == ['foo', '"bar foobar"']
    assert split_args('foo "bar foobar') == ['foo', '"bar foobar']
    assert split_args('foo bar "bar foobar') == ['foo', 'bar', '"bar foobar']
    assert split_args('foo bar "bar foobar') == ['foo', 'bar', '"bar foobar']
    assert split_args('foo="bar foobar"') == ['foo="bar foobar"']
    assert split_args('foo="bar foobar') == ['foo="bar foobar']
    assert split_args('foo bar="bar foobar') == ['foo', 'bar="bar foobar']

# Generated at 2022-06-25 04:03:18.158773
# Unit test for function parse_kv
def test_parse_kv():
    print(parse_kv('a=4 b="some test"'))
    print(parse_kv(b'a=4 b="some test"', check_raw=True))
    print(parse_kv(u'a=4 b="some test"', check_raw=False))
    print(parse_kv(b'a=4 b="some test"', check_raw=False))

# Generated at 2022-06-25 04:03:22.070616
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

if __name__ == "__main__":
    # execute only if run as a script
    test_parse_kv()

# Generated at 2022-06-25 04:03:33.202634
# Unit test for function split_args
def test_split_args():
    # Input variables
    input_0 = 'this is a test'
    input_1 = '"another test"'
    input_2 = "'A third test'"
    input_3 = '" escaped quote test"'
    input_4 = "\"escaped quote test\""
    input_5 = "\"jinja2 block test {{ some_var }}\""
    input_6 = '"jinja2 {{ more_var }} block test" {{ more_var }}'
    input_7 = '"escaped {{ escaped_var }} quotes" \" inside {{ var }} quotes"'
    input_8 = '"escaped {{ escaped_var }} quotes" \" inside {{ var }} quotes" "escaped {{ escaped_var }} quotes" \" inside {{ var }} quotes"'

# Generated at 2022-06-25 04:03:41.378799
# Unit test for function split_args
def test_split_args():
    """
    Test that split_args works as expected.
    """
    assert split_args('\'test1\'') == ['\'test1\'']
    assert split_args('"test2"') == ['"test2"']
    assert split_args('test3') == ['test3']

    # simple unbalanced block
    assert split_args('test {{') == ['test', '{{']

    # simple balanced block
    assert split_args('test {{ test }}') == ['test', '{{ test }}']

    # nested blocks
    assert split_args('test {{ {{test }} }}') == ['test', '{{ {{test }} }}']

    # unbalanced block with quotes
    assert split_args('test "{{') == ['test', '"{{']

    # balanced block with quotes

# Generated at 2022-06-25 04:03:44.040806
# Unit test for function parse_kv
def test_parse_kv():
    arg1 = b'\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    arg2 = False
    result = parse_kv(arg1, arg2)
    print(result)
    print('PASSED: test_parse_kv')



# Generated at 2022-06-25 04:03:48.655037
# Unit test for function split_args
def test_split_args():
    '''Test split_args'''
    # Testcase 0
    bytes_0 = b'\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    var_0 = parse_kv(bytes_0)
    if var_0:
        print(var_0)

if __name__ == '__main__':
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 04:03:53.841590
# Unit test for function parse_kv
def test_parse_kv():

    assert callable(parse_kv)

    # Call function parse_kv
    try:
        test_case_0()
    except Exception as e:
        print(str(e))
        assert False

    print('All test cases passed for function parse_kv')


# Test case for function split_args

# Generated at 2022-06-25 04:04:02.459144
# Unit test for function split_args
def test_split_args():
   # split_args('foo')
    assert split_args(u'foo') == (u'foo',)
    assert split_args(u'foo bar') == (u'foo', u'bar')
    assert split_args(u'foo bar "baz zap"') == (u'foo', u'bar', u'baz zap')
    assert split_args(u'foo bar "baz zap') == (u'foo', u'bar', u'"baz', u'zap')
    assert split_args(u'foo bar "baz zap\\"') == (u'foo', u'bar', u'"baz', u'zap"')

# Generated at 2022-06-25 04:04:04.862374
# Unit test for function parse_kv
def test_parse_kv():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Command line interface

# Generated at 2022-06-25 04:04:10.197864
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a="b c" d=e') == ['a="b c"', 'd=e']
    assert split_args('a=b "c d"') == ['a=b', '"c d"']
    assert split_args('a=b "c d"') == ['a=b', '"c d"']
    assert split_args('a=b "c d" f="g h"') == ['a=b', '"c d"', 'f="g h"']

# Generated at 2022-06-25 04:04:26.543491
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    var_0 = parse_kv(bytes_0)
    # Parse a string of key/value items to a dict
    #
    # :arg args: key/value items in the form 'key=value', which
    #            can be passed as either a string or a list.
    #
    # :kwarg check_raw: If this option is set to True and free-form parameters
    #                   are included in the args string, they will be added as
    #                   a new key called '_raw_params' in the returned dict.
    #
    # :returns: dict of key/value items

# Generated at 2022-06-25 04:04:37.758462
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    vars_0 = split_args(bytes_0)
    assert vars_0 == ['K\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d']

# Generated at 2022-06-25 04:04:43.969722
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    var_0 = parse_kv(bytes_0)
    print(var_0)


if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-25 04:04:54.609417
# Unit test for function split_args
def test_split_args():

    # Split on space first
    tokens = split_args('foo bar')
    assert len(tokens) == 2

    # Split on tab
    tokens = split_args('\tfoo\tbar\t')
    assert len(tokens) == 2

    # Split on newline (defaults to space)
    tokens = split_args('\nfoo\nbar\n')
    assert len(tokens) == 2

    # Quote characters
    tokens = split_args('"foo bar"')
    assert len(tokens) == 1

    # Quote in the middle
    tokens = split_args('"foo bar')
    assert len(tokens) == 1
    assert tokens[0] == '"foo bar'

    # Quote in the middle, with newline

# Generated at 2022-06-25 04:05:00.086129
# Unit test for function parse_kv
def test_parse_kv():
    try:
        bytes_0 = b'\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    except:
        bytes_0 = '\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    var_0 = parse_kv(bytes_0)
    assert var_0['_raw_params'] == '\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'



# Generated at 2022-06-25 04:05:03.898987
# Unit test for function parse_kv
def test_parse_kv():
    here = sys.path[0]
    with open(os.path.join(here, 'parse_kv_data.json'), 'r') as data_file:
        data = json.load(data_file)
        for test in data['tests']:
            yield _run_parse_kv_test, test


# Generated at 2022-06-25 04:05:13.891072
# Unit test for function split_args
def test_split_args():
    assert split_args(b'') == []
    assert split_args(b'a=b') == [b'a=b']
    assert split_args(b'a="b c"') == [b'a="b c"']
    assert split_args(b'a=b c="d e"') == [b'a=b', b'c="d e"']
    assert split_args(b'''a=b c="d e"''') == [b'a=b', b'c="d e"']
    assert split_args(b'''a=b \
c="d e"''') == [b'a=b', b'c="d e"']

# Generated at 2022-06-25 04:05:25.964929
# Unit test for function parse_kv
def test_parse_kv():
    # Create test cases to unit test the function
    # test_case_0
    bytes_0 = b'\xc7\x1d\x0f\xcc\x8a\x04\xb4\x7f\x80\xc1\x02\x933\x9a\x96\x90'
    var_0 = parse_kv(bytes_0)
    assert var_0 == {}

    # test_case_1
    bytes_1 = b'\xc3\xbf\xc0\x0f\x9e\x05\x8f\xec\xbe\x98\xe3\x8a\xfc\x9c#\x8f'
    var_1 = parse_kv(bytes_1)
    assert var_1 == {}

    # test_case

# Generated at 2022-06-25 04:05:28.578064
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

if __name__ == "__main__":
    test_parse_kv()

# Generated at 2022-06-25 04:05:37.076915
# Unit test for function split_args
def test_split_args():
    assert split_args('var_a=\'foo bar\' var_b="foo bar" var_c=\\\'foo bar\\\' var_d=\\"foo bar\\" var_e=foo\\ bar') == ['var_a=\'foo bar\'', 'var_b="foo bar"', 'var_c=\\\'foo bar\\\'', 'var_d=\\"foo bar\\"', 'var_e=foo\\ bar']

    # Test support for backslash escaped quotes, see https://github.com/ansible/ansible/issues/14984
    assert split_args('"foo\\"\'bar"') == ['"foo\\"\'bar"']
    assert split_args('"foo\\"bar"') == ['"foo\\"bar"']

# Generated at 2022-06-25 04:05:53.225839
# Unit test for function split_args
def test_split_args():
    # Arguments
    #line = u'a=b c="foo bar"'
    #line = b'\xe1\xab\x8e\xb0m`\x07\xc8\xeb\xe9\x04\xe4\x89\x01\xab'
    #line = b'\xe1\xab\x8e\xb0m`\x07\xc8\xeb\xe9\x04\xe4\x89\x01\xab'
    line = 'a=b c="foo bar"'
    args = split_args(line)

    # Expected result
    #expected = [u'a=b', u'c="foo bar"']
    expected = ['a=b', 'c="foo bar"']
    assert args == expected


# Generated at 2022-06-25 04:06:02.399925
# Unit test for function parse_kv
def test_parse_kv():
    kv_string = "http://www.example.com:8000/path/to/page?p=q#fragment"
    parsed_kv = parse_kv(kv_string)
    assert parsed_kv == {u'_raw_params': kv_string}
    kv_string = '''
    alias ls="ls -l --color=auto"
    alias ll='ls'
    '''
    parsed_kv = parse_kv(kv_string)
    assert parsed_kv == {u'_raw_params': kv_string}
    kv_string = "$HOME/path/to/file.txt"
    parsed_kv = parse_kv(kv_string)
    assert parsed_kv == {u'_raw_params': kv_string}
    k

# Generated at 2022-06-25 04:06:04.535165
# Unit test for function parse_kv
def test_parse_kv():
    try:
        test_case_0()
        errors += 1
    except:
        pass


# Generated at 2022-06-25 04:06:05.981542
# Unit test for function parse_kv
def test_parse_kv():
    for test_case in [0]:
        locals()['test_case_%s' % test_case]()



# Generated at 2022-06-25 04:06:18.244094
# Unit test for function split_args
def test_split_args():
    assert split_args(b'a=b c="foo bar"') == [b'a=b', b'c="foo bar"']
    assert split_args('a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo \nbar"') == [u'a=b', u'c="foo \nbar"']
    assert split_args(u'a=b c="foo \nbar\n"') == [u'a=b', u'c="foo \nbar\n"']

# Generated at 2022-06-25 04:06:23.057006
# Unit test for function split_args
def test_split_args():
    args = '\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'

    ret = split_args(args)
    print("split_args() = %s" % repr(ret))


# Generated at 2022-06-25 04:06:28.032628
# Unit test for function parse_kv
def test_parse_kv():
    passed = 0
    failed = 0


# Generated at 2022-06-25 04:06:29.399895
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()


# Generated at 2022-06-25 04:06:35.956348
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    var_0 = split_args(bytes_0)


# Generated at 2022-06-25 04:06:37.374689
# Unit test for function parse_kv
def test_parse_kv():
    pass



# Generated at 2022-06-25 04:07:00.477831
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv('a=1')
    assert var_0.get('a') == '1'


# Generated at 2022-06-25 04:07:11.372559
# Unit test for function split_args
def test_split_args():
    assert split_args(b'a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(b'''{{foo bar}}''') == ['{{foo bar}}']
    assert split_args(b'''{%foo bar%}''') == ['{%foo bar%}']
    assert split_args(b'''{#foo bar#}''') == ['{#foo bar#}']
    assert split_args(b'''"{#foo bar#}"''') == ['"{#foo bar#}"']
    assert split_args(b'''{{foo bar}} {#foo bar#} {%foo bar%}''') == ['{{foo bar}}', '{#foo bar#}', '{%foo bar%}']

# Generated at 2022-06-25 04:07:21.951961
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv(b'')
    assert var_0 == {}
    var_1 = parse_kv(b'a=foo\x5c=b \x5c\x5c=c')
    assert var_1 == {'a':'foo=b\\=c'}
    var_2 = parse_kv(b'a=foo\x5c=b \x5c\x5c=c', check_raw=True)
    assert var_2 == {'a':'foo=b\\=c', '_raw_params': b'a=foo\x5c=b \x5c\x5c=c'}
    var_3 = parse_kv(b'a=foo\x5c=b \x5c\x5c=c && echo foo')
   

# Generated at 2022-06-25 04:07:28.391683
# Unit test for function split_args
def test_split_args():
    # "These unit tests should be run with the following flags:
    # --disable-cef-logging --no-color -c"
    bytes_0 = b'\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    var_0 = split_args(bytes_0)

# RUN TESTS
#test_split_args()

# Generated at 2022-06-25 04:07:35.633711
# Unit test for function parse_kv
def test_parse_kv():
    # Test with no arguments
    assert parse_kv(args = None) == {}

    # Test with key-value arguments
    assert parse_kv(args = 'name=some_name a=1 b="some string" c=\'another string\'') == {'name': 'some_name', 'a': '1', 'b': 'some string', 'c': 'another string'}
    assert parse_kv(args = 'a="b \'c\' d"') == {'a': "b 'c' d"}
    assert parse_kv(args = 'a=\'b "c" d\'') == {'a': 'b "c" d'}

    # Test with '_raw_params' argument

# Generated at 2022-06-25 04:07:37.625137
# Unit test for function parse_kv
def test_parse_kv():
    print(parse_kv(b'a=b c=d e=f g=h'))
    test_case_0()

# Generated at 2022-06-25 04:07:43.599300
# Unit test for function parse_kv
def test_parse_kv():
    # verify the initial values of Params
    assert parse_kv('') == {}, "Invalid value for parse_kv"
    # Setup test values for function parse_kv

    # Execute function parse_kv
    c = test_parse_kv()
    # Verify if the expected results are matching the actual results
    assert c == {}, "Invalid output for parse_kv"


#
# Unit tests for join_args
#


# Generated at 2022-06-25 04:07:44.971088
# Unit test for function parse_kv
def test_parse_kv():
    print('\nRunning unit test for function parse_kv:')
    print('-' * 78)




# Generated at 2022-06-25 04:07:49.321030
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    var_0 = parse_kv(bytes_0)
    assert var_0 is not None, "Failed to initialize"


# Generated at 2022-06-25 04:08:00.680668
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(b'a=b') == inspect.cleandoc('''
    {
        "a": "b"
    }''')
    assert parse_kv(b'a="b c"') == inspect.cleandoc('''
    {
        "a": "b c"
    }''')
    assert parse_kv(b'a="b\tc"') == inspect.cleandoc('''
    {
        "a": "b\tc"
    }''')
    assert parse_kv(b'a="b=c"') == inspect.cleandoc('''
    {
        "a": "b=c"
    }''')

# Generated at 2022-06-25 04:08:32.746341
# Unit test for function split_args
def test_split_args():
    print(">>> split_args <<<")
    # this function is used by many other functions that call parse_kv
    # so we want to manually test it here

# Generated at 2022-06-25 04:08:36.226752
# Unit test for function parse_kv
def test_parse_kv():
    assert callable(parse_kv)

# Generated at 2022-06-25 04:08:39.373715
# Unit test for function parse_kv
def test_parse_kv():
    try:
        test_case_0()
        print('Pass!')
    except:
        print('Failed!')

test_parse_kv()

# Generated at 2022-06-25 04:08:43.280380
# Unit test for function split_args
def test_split_args():
    args = '''
a=b
c=d
e=f
    '''
    result = split_args(args)
    print('result is : {}'.format(result))


# Generated at 2022-06-25 04:08:45.846891
# Unit test for function parse_kv
def test_parse_kv():
    # This test case is currently disabled
    #test_case_0()

    # These assertion checks should be enabled
    assert 2 + 2 == 4


# Generated at 2022-06-25 04:08:48.955851
# Unit test for function parse_kv
def test_parse_kv():

    # Execute function
    result = parse_kv(arg_0)

    # Verify the results
    correct_result = correct_result

    assert result == correct_result, 'Test Failed: In function "parse_kv", failed to parse string to dict.'



# Generated at 2022-06-25 04:08:55.058910
# Unit test for function split_args
def test_split_args():
    # Test cases
    assert split_args('cmd arg1 arg2 arg3') == ['cmd', 'arg1', 'arg2', 'arg3']
    # Test single-quotes
    assert split_args(r"cmd 'arg1 arg2' arg3") == ['cmd', "'arg1 arg2'", 'arg3']
    assert split_args(r"cmd 'arg1 arg2' 'arg3 arg4'") == ['cmd', "'arg1 arg2'", "'arg3 arg4'"]
    # Test double-quotes
    assert split_args(r'cmd "arg1 arg2" arg3') == ['cmd', '"arg1 arg2"', 'arg3']

# Generated at 2022-06-25 04:09:00.935479
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00'
    var_0 = parse_kv(bytes_0)
    bytes_1 = b'\xc3(\xd7\xdc3\xcf\xca]\x12\xe9\x81X\x86\xe1\x90\xa2\x89'
    var_1 = parse_kv(bytes_1)

# Generated at 2022-06-25 04:09:09.221890
# Unit test for function split_args

# Generated at 2022-06-25 04:09:11.474901
# Unit test for function parse_kv
def test_parse_kv():
    assert test_case_0() is None

# Generated at 2022-06-25 04:09:26.697798
# Unit test for function parse_kv
def test_parse_kv():
    assert(True)


# Generated at 2022-06-25 04:09:30.021433
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\xb8B\xdd\x9c\xfa,\xa5\xcd\xf5\xa0\xcb\xa0\x10\x9d}x\x1b'
    ansible_0 = parse_kv(bytes_0)


# Local Variables:
# python-indent-offset: 4
# indent-tabs-mode: nil
# End:
# vim: ai et ts=4 sts=4 sw=4

# Generated at 2022-06-25 04:09:31.626505
# Unit test for function parse_kv
def test_parse_kv():
    try:
        test_case_0()
    except:
        print('test_case_0() failed!')


# Generated at 2022-06-25 04:09:38.015107
# Unit test for function split_args
def test_split_args():
    test_input_1 = "foo=bar baz='hello world'"
    test_output_1 = ['foo=bar', 'baz=\'hello world\'']
    test_input_2 = "{{ test }}"
    test_output_2 = ['{{ test }}']
    test_input_3 = "{{ test }} 'hello world'"
    test_output_3 = ['{{ test }}', "'hello world'"]
    test_input_4 = "{{ test }} 'hello world' {{ test2 }}"
    test_output_4 = ['{{ test }}', "'hello world'", '{{ test2 }}']
    test_input_5 = "{{ test }} 'hello world' {{ test2 }} foo=bar"
    test_output_5 = ['{{ test }}', "'hello world'", '{{ test2 }}', 'foo=bar']


# Generated at 2022-06-25 04:09:49.455314
# Unit test for function split_args
def test_split_args():
    assert split_args('one') == ['one']
    assert split_args('one two') == ['one', 'two']
    assert split_args('one "two three"') == ['one', '"two three"']
    assert split_args('one two three') == ['one', 'two', 'three']
    assert split_args('one "two three" four') == ['one', '"two three"', 'four']
    assert split_args('one "two three" four five') == ['one', '"two three"', 'four', 'five']
    assert split_args('one "two three" "four five" six') == ['one', '"two three"', '"four five"', 'six']

# Generated at 2022-06-25 04:09:55.801515
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\xc6\xa4\x8f\xea\xb4\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    var_0 = parse_kv(bytes_0)


# Generated at 2022-06-25 04:10:03.504924
# Unit test for function parse_kv
def test_parse_kv():
    # Make sure that parsing an empty string results in an empty dictionary
    assert len(parse_kv('')) == 0

    # Make sure that parsing a string without equal signs results in a dictionary
    # with a single key and no value
    assert len(parse_kv('foo')) == 1
    assert parse_kv('foo')['foo'] is None

    # Make sure that parsing a string with a single key=value pair results in
    # a dictionary with a single item
    assert len(parse_kv('foo=bar')) == 1
    assert parse_kv('foo=bar')['foo'] == 'bar'

    # Make sure that parsing a string with a key=value pair that contains
    # a double-quote results in the value being correctly parsed
    assert len(parse_kv('foo="bar baz"')) == 1
   

# Generated at 2022-06-25 04:10:05.555129
# Unit test for function parse_kv
def test_parse_kv():
    # test case 0
    test_case_0()
    print('test done')

if __name__ == "__main__":
    test_parse_kv()

# Generated at 2022-06-25 04:10:16.950700
# Unit test for function parse_kv
def test_parse_kv():
    assert callable(parse_kv)


# Generated at 2022-06-25 04:10:25.044970
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    var_0 = parse_kv(bytes_0)
    #assert var_0 == "GNUGZP\xe8\x9a\x9f\x84\x93`\xed\x1f\xdd\xda\xd3\x11\xfd"
    assert var_0 == {'_raw_params': '\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'}

if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-25 04:10:54.848611
# Unit test for function split_args
def test_split_args():
    # Test case 0
    bytes_0 = b'\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d'
    var_1 = split_args(bytes_0)
    assert var_1 == [b'\xdc\xad\xfb\xb1\xbbx\x87\x0b\x02\xed\xb8\xd3Z.\x1d']

    # Test case 1
    # FIXME: Check edge cases for this one.

# Generated at 2022-06-25 04:10:59.804437
# Unit test for function parse_kv
def test_parse_kv():
    with open('parse_kv.dat', 'rb') as file_obj:
        for _ in range(100000):
            bytes_0 = file_obj.read(16)
            parse_kv(bytes_0)


# Generated at 2022-06-25 04:11:10.183157
# Unit test for function split_args
def test_split_args():
    test = 'a=b c="foo bar"'
    res = split_args(test)
    assert res == ['a=b', 'c="foo bar"']
    test = 'ansible_ssh_pass=test123 ansible_ssh_user=ubuntu ansible_become=yes'
    res = split_args(test)
    assert res == ['ansible_ssh_pass=test123', 'ansible_ssh_user=ubuntu', 'ansible_become=yes']
    test = 'ansible_ssh_pass=test123 ansible_ssh_user=root ansible_become=yes'
    res = split_args(test)
    assert res == ['ansible_ssh_pass=test123', 'ansible_ssh_user=root', 'ansible_become=yes']