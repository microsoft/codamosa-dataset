

# Generated at 2022-06-25 04:01:36.016109
# Unit test for function split_args
def test_split_args():
    # Test case with an input of str type.
    assert split_args("  -u \"user\" -k key -m ping") == ['-u', '"user"', '-k', 'key', '-m', 'ping']


# Generated at 2022-06-25 04:01:42.646545
# Unit test for function split_args
def test_split_args():
    assert split_args(302) == []
    assert split_args(305) == []
    assert split_args(-23) == []
    assert split_args(-9086) == []
    assert split_args(-26) == []
    assert split_args(-54) == []
    assert split_args(0) == []
    assert split_args(-3) == []
    assert split_args(-4) == []
    assert split_args(-7) == []
    assert split_args(-5) == []
    assert split_args(-6) == []
    assert split_args(-1) == []
    assert split_args(-2) == []
    assert split_args(-8) == []
    assert split_args(0) == []
    assert split_args(-3) == []
    assert split_args(-4) == []

# Generated at 2022-06-25 04:01:52.526877
# Unit test for function parse_kv
def test_parse_kv():
    parameters = {
        'param1': 'bar',
        'param2': '"bar"',
        'param3': "\"foo\''",
        'param4': 'b"z"',
        '_raw_params': '"foo bar" "bar" \'foo bar\'',
    }

    # Set parameters
    cli_args = "param1=bar param2=\"bar\" param3=\"\\\"foo\\\'\" param4=bz\\\" _raw_params=\"foo bar\" \"bar\" \'foo bar\' "
    args = parse_kv(cli_args)
    #assert args == parameters

    # Merge parameters
    cli_args = "param1=bar param3=\"\\\"foo\\\'\" param4=bz\\\""
    args = parse_kv(cli_args, parameters)
    #assert

# Generated at 2022-06-25 04:01:59.041774
# Unit test for function split_args
def test_split_args():
    assert split_args('"foo bar"') == ['foo bar']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar "foo bar"') == ['foo', 'bar', 'foo bar']
    assert split_args('foo bar \'foo bar\'') == ['foo', 'bar', 'foo bar']
    assert split_args('foo bar "foo bar" 123') == ['foo', 'bar', 'foo bar', '123']
    assert split_args('foo bar \'foo bar\' 123') == ['foo', 'bar', 'foo bar', '123']
    assert split_args('"foo" bar') == ['foo', 'bar']
    assert split_args('"foo bar') == ['foo bar']
    assert split_args('foo\nbar') == ['foo\nbar']

# Generated at 2022-06-25 04:01:59.695754
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 04:02:06.299740
# Unit test for function parse_kv

# Generated at 2022-06-25 04:02:11.877127
# Unit test for function split_args
def test_split_args():
    int_0 = 201
    var_0 = split_args(int_0)
    assert var_0 == ['201']


# Generated at 2022-06-25 04:02:20.065154
# Unit test for function split_args
def test_split_args():
    print("Testing split_args")
    int_0 = "-a -b \"hello\" -c 'Hello, world!'"
    var_0 = split_args(int_0)
    if var_0 != ["-a", "-b", "\"hello\"", "-c", "'Hello, world!'"]:
        raise AssertionError("expected: %s\nreceived: %s\n" % ("[-a, -b, \"hello\", -c, 'Hello, world!']", var_0))

# Generated at 2022-06-25 04:02:23.944744
# Unit test for function split_args
def test_split_args():
    # Test case 0
    test_case_0()
    print('split_args unit test passed 0/0')

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:02:30.502674
# Unit test for function parse_kv
def test_parse_kv():
    d0 = {"a":1, "b":2}
    assert(parse_kv(d0) == {"a":1, "b":2})
    d1 = {"a=1":2, "b=2":3}
    assert(parse_kv(d1) == {"a":1, "b":2})
    d2 = {"a=1==2":3, "b=2=3":4}
    assert(parse_kv(d2) == {"a":1, "b":2})
    d3 = {"a=":3, "b=":4}
    assert(parse_kv(d3) == {"a":"","b":""})


# Generated at 2022-06-25 04:02:51.101723
# Unit test for function split_args
def test_split_args():
    # Normal use case
    int_0 = "a=b c=\"foo bar\""
    var_0 = split_args(int_0)
    assert var_0 == ['a=b', 'c="foo bar"']
    # Normal use case
    int_0 = "\n"
    var_0 = split_args(int_0)
    assert var_0 == ['\n']
    # Normal use case
    int_0 = "\"\n\""
    var_0 = split_args(int_0)
    assert var_0 == ['"\n"']
    # Normal use case
    int_0 = "a=b    c=\"foo bar\""
    var_0 = split_args(int_0)
    assert var_0 == ['a=b', 'c="foo bar"']
    # Normal

# Generated at 2022-06-25 04:03:01.451000
# Unit test for function parse_kv
def test_parse_kv():
    # FIXME: should take a dict instead?
    str_0 = "key=value\n"
    dict_0 = parse_kv(str_0)



# this re is designed to split arguments, but NOT on commas
# unless they are inside quotes. It is a variation of the one here:
# http://stackoverflow.com/questions/4998629/python-split-string-with-multiple-delimiters
# Special thanks to tdelaney for the technique.
# the regex below uses positive lookahead assertions to find non-escaped
# quotes and then it uses a backreference to find the same character
# again later in the string.

# Generated at 2022-06-25 04:03:02.416586
# Unit test for function parse_kv
def test_parse_kv():
    int_0 = 302
    test_case_0()


# Split arguments

# Generated at 2022-06-25 04:03:08.333598
# Unit test for function split_args
def test_split_args():
    # Set up a dictionary of test cases and the expected results.
    # The format is test case => result
    test_cases = {}
    # FIXME: should we test full arg strings or individual arg tokens?

    # Adds an arg, the split args don't include the space
    test_cases['foo'] = ['foo']
    # Adds two args, the split args don't include the spaces
    test_cases['foo bar'] = ['foo', 'bar']
    # Adds an arg with an equals sign, the split args don't include the spaces
    test_cases['foo=bar'] = ['foo=bar']
    # Adds two args, the split args don't include the spaces
    test_cases['foo=bar baz=blam'] = ['foo=bar', 'baz=blam']
    # Adds an arg with an equals sign, then adds an arg

# Generated at 2022-06-25 04:03:09.884718
# Unit test for function split_args
def test_split_args():
    int_0 = 'echo "hello world"'
    var_0 = split_args(int_0)
    return var_0

# Generated at 2022-06-25 04:03:19.648309
# Unit test for function parse_kv
def test_parse_kv():
    # Set expectations
    expected_result = {u'_raw_params': u"BASE=''", u'INSTALL_PATH': u'/home', u'DB_HOST': u'localhost', u'DB_NAME': u'my_db', u'DB_USER': u'my_user'}
    # Try function call
    try:
        result = parse_kv(u"DB_NAME=my_db DB_HOST=localhost INSTALL_PATH=/home BASE='' DB_USER=my_user")
    except Exception as e:
        # Add error to list
        error.append(e)

    # Test for expected result
    assert result == expected_result, "Function parse_kv returned unexpected result."


# Generated at 2022-06-25 04:03:22.978220
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Generated at 2022-06-25 04:03:33.218972
# Unit test for function parse_kv
def test_parse_kv():
    key_0 = 0
    key_1 = 0
    key_2 = 0
    key_3 = 0
    key_5 = 0
    key_6 = 0
    key_8 = 0
    key_9 = 0
    key_10 = 0
    key_11 = 0
    key_12 = 0
    key_13 = 0
    key_14 = 0
    key_15 = 0
    key_16 = 0
    key_17 = 0
    key_18 = 0
    key_19 = 0
    key_20 = 0
    key_21 = 0
    key_22 = 0
    key_23 = 0
    key_24 = 0
    key_25 = 0
    key_26 = 0
    key_27 = 0
    key_28 = 0
    key_29 = 0
    key_

# Generated at 2022-06-25 04:03:35.111716
# Unit test for function split_args
def test_split_args():
    print("Testing function: split_args")
    test_case_0()

# Calling all test functions
test_split_args()

# Generated at 2022-06-25 04:03:45.113463
# Unit test for function split_args
def test_split_args():
    # Test with simple string
    var_0 = split_args("localhost")
    print(var_0)
    print()

    # Test with dictionary string
    var_0 = split_args("localhost:8080")
    print(var_0)
    print()

    # Test with simple list
    var_0 = split_args("localhost : 8080")
    print(var_0)
    print()

    # Test with a complex list
    var_0 = split_args("localhost : 8080 user=chad password=secret")
    print(var_0)
    print()

    var_0 = split_args("""localhost : 8080
    user=chad
    password=secret""")
    print(var_0)
    print()

    # Test with final example

# Generated at 2022-06-25 04:04:02.450467
# Unit test for function parse_kv
def test_parse_kv():
    int_0 = 302
    string_0 = '0=0\x00\x00'
    string_1 = '0=0\x00\x00'
    string_2 = '0=0\x00\x00'
    string_3 = '0=0\x00\x00'
    string_4 = '0=0\x00\x00'
    string_5 = '0=0\x00\x00'
    string_6 = '0=0\x00\x00'
    string_7 = '0=0\x00\x00'
    string_8 = '0=0\x00\x00'
    string_9 = '0=0\x00\x00'
    string_10 = '0=0\x00\x00'

# Generated at 2022-06-25 04:04:05.280389
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == "__main__":
    print("Running unit test for function split_args")
    test_split_args()

# Generated at 2022-06-25 04:04:09.084976
# Unit test for function split_args
def test_split_args():
    # example input: a=b c="foo bar"
    # example output: ['a=b', 'c="foo bar"']
    example_input = 'a=b c="foo bar"'
    out = split_args(example_input)
    assert out == ['a=b', 'c="foo bar"']



# Generated at 2022-06-25 04:04:17.533926
# Unit test for function parse_kv
def test_parse_kv():
    try:
        assert type(parse_kv('A=B')) is dict
        assert type(parse_kv('A=B',check_raw=True)) is dict
        assert int(parse_kv('A=B')['A']) is int_0
    except AssertionError as e:
        print("Error running test_parse_kv: " + str(e))
        return 1
    return 0


# Generated at 2022-06-25 04:04:26.579824
# Unit test for function parse_kv
def test_parse_kv():
    args = '''-a "foo=one" -b "bar=two three" 'quoted arg' -A -C'''
    assert parse_kv(args, check_raw=True) == {u'_raw_params': u'-A -C', u'a': u'foo=one', u'b': u'bar=two three', u'quoted arg': u''}

    args = '''arg1="foo=bar" arg2='foo=bar' arg3="foo=bar arg4='foo=bar' arg5=foo=bar'''

# Generated at 2022-06-25 04:04:37.759870
# Unit test for function parse_kv
def test_parse_kv():
    unittest.TestCase.assertEquals.__dict__.__setitem__('stypy_localization', localization)
    unittest.TestCase.assertEquals.__dict__.__setitem__('stypy_type_of_self', type_of_self)
    unittest.TestCase.assertEquals.__dict__.__setitem__('stypy_type_store', module_type_store)
    unittest.TestCase.assertEquals.__dict__.__setitem__('stypy_function_name', 'test_parse_kv')
    unittest.TestCase.assertEquals.__dict__.__setitem__('stypy_param_names_list', [])

# Generated at 2022-06-25 04:04:46.729947
# Unit test for function parse_kv
def test_parse_kv():
    try:
        parse_kv(1)
        assert True
    except AnsibleParserError as e:
        # TODO: fix type checker
        assert True

    try:
        parse_kv('"')
        assert False
    except AnsibleParserError as e:
        # TODO: fix type checker
        assert True

    try:
        parse_kv([1, 2])
        assert True
    except AnsibleParserError as e:
        # TODO: fix type checker
        assert True

    assert parse_kv(None) == {}
    assert parse_kv('') == {}
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-25 04:04:52.905046
# Unit test for function parse_kv
def test_parse_kv():
    int_0 = 302
    dict_0 = {u'_raw_params': u'', u'creates': u'', u'removes': u'', u'chdir': u'', u'executable': u'', u'strip_empty_ends': False, u'warn': False, u'stdin_add_newline': True, u'stdin': u''}
    dict_1 = parse_kv(int_0, False)
    assert dict_0 == dict_1


# Generated at 2022-06-25 04:05:03.810286
# Unit test for function parse_kv
def test_parse_kv():
    x = (parse_kv('foo=bar biz=boz'))
    assert 'foo' in x, "Failed to find foo in x"
    assert x['foo'] == u'bar', "Failed to parse x correctly"
    assert x['biz'] == u'boz', "Failed to parse y correctly"
    x = (parse_kv('foo=bar biz=boz', check_raw=True))
    assert x['_raw_params'] == u'foo=bar biz=boz', "Failed to parse with check_raw=True"
    x = (parse_kv('foo="bar bar" biz="boz boz"'))
    assert 'foo' in x, "Failed to find foo in x"

# Generated at 2022-06-25 04:05:06.212289
# Unit test for function split_args
def test_split_args():
  command = 'a=b c="foo bar"'
  args = split_args(command)
  print('args: ', args)


# Generated at 2022-06-25 04:05:17.240663
# Unit test for function parse_kv
def test_parse_kv():
    # Test for TypeError for parameter args
    args = [302]
    test_case_0(args)


# Generated at 2022-06-25 04:05:27.555124
# Unit test for function split_args
def test_split_args():
    # test case for function split_args with arguments : '{{foo}} -a "b c" \'d e\' bar'
    assert split_args(u'{{foo}} -a "b c" \'d e\' bar') == [u'{{foo}}', '-a', '"b c"', "'d e'", 'bar']
    # test case for function split_args with arguments : '{{foo}} -a "b c" \'d e\' bar'
    assert split_args(u'{{foo}} -a "b c" \'d e\' bar') == [u'{{foo}}', '-a', '"b c"', "'d e'", 'bar']
    # test case for function split_args with arguments : '-a "b c" \'d e\' bar'

# Generated at 2022-06-25 04:05:32.594670
# Unit test for function split_args
def test_split_args():
    args = "git config --global user.name \"Your Name\""
    params = split_args(args)
    print(params)
    params = [_decode_escapes(a) for a in params]
    print(params)

test_split_args()

test_case_0()

# Generated at 2022-06-25 04:05:44.281056
# Unit test for function parse_kv
def test_parse_kv():
    print("Test function parse_kv for module shell")
    assert(parse_kv('', False))

    assert(parse_kv('foo=bar', False))

    assert(parse_kv('foo=bar bar=baz', False))

    assert(parse_kv('foo=bar bar=baz baz=bam', False))

    assert(parse_kv('arg1 arg2 arg3', False))

    assert(parse_kv('arg1 arg2="foo bar"', False))

    assert(parse_kv('foo="bar=baz"', False))

    assert(parse_kv('foo="bar baz"', False))

    assert(parse_kv('foo="bar baz" arg2 arg3', False))


# Generated at 2022-06-25 04:05:50.419312
# Unit test for function split_args
def test_split_args():
    params = []
    params.append( '-a')
    params.append( '-b 1')
    params.append( '-a')
    params.append( '-b 2')
    args = join_args(params)
    print(args)
    args = split_args(args)
    print(args)
    # assert 1 == 2


# Generated at 2022-06-25 04:05:54.964613
# Unit test for function split_args
def test_split_args():
    s = "a=b c=d"
    params = split_args(s)
    if params != ['a=b', 'c=d']:
        print('FAIL1')


# Generated at 2022-06-25 04:06:01.692775
# Unit test for function split_args

# Generated at 2022-06-25 04:06:02.261069
# Unit test for function split_args
def test_split_args():
    assert True


# Generated at 2022-06-25 04:06:09.369087
# Unit test for function parse_kv
def test_parse_kv():
    int_0 = 42
    str_0 = 'ansible_playbook_python ver=2.7.5 path=None'
    dict_0 = parse_kv(str_0, True)
    str_1 = 'ansible_playbook_python'
    str_2 = '2.7.5'
    str_3 = 'None'
    str_4 = 'None'

    assert(dict_0['ansible_playbook_python'] == 'ver=2.7.5 path=None')
    assert(dict_0['ansible_playbook_python'] != 'ver=2.7.5 path=None')
    assert(dict_0[str_1] == 'ver=2.7.5 path=None')

# Generated at 2022-06-25 04:06:11.740934
# Unit test for function split_args
def test_split_args():
    args = '''a=b c="foo\nbar"'''
    assert split_args(args) == ['a=b', 'c="foo\nbar"']


# Generated at 2022-06-25 04:06:32.833196
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

# Parser for template lines of the form:
# key=value arg=value arg=value

# Generated at 2022-06-25 04:06:39.808553
# Unit test for function split_args
def test_split_args():
    str_1 = 'a=b c="foo bar"'
    var_1 = split_args(str_1)
    assert var_1 == [u'a=b', u'c="foo bar"']
    str_2 = '-e bash -c "env"'
    var_2 = split_args(str_2)
    assert var_2 == [u'-e', u'bash', u'-c', u'"env"']
    str_3 = 'echo "{{ foo }}"'
    var_3 = split_args(str_3)
    assert var_3 == [u'echo', u'"{{ foo }}"']
    str_4 = 'echo "{{ foo + bar }}"'
    var_4 = split_args(str_4)

# Generated at 2022-06-25 04:06:43.569348
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '>^KkMgD`xh<!_Q!I4:G'
    var_0 = parse_kv(str_0)

test_case_0()
test_parse_kv()

# Generated at 2022-06-25 04:06:47.123953
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()
    str_0 = 'abc=3 def=4'
    var_0 = parse_kv(str_0)
    str_1 = 'a=1 b=2 c=3'
    var_1 = parse_kv(str_1)

    if ((var_0['abc'] == '3') and (var_0['def'] == '4') and (var_1['a'] == '1') and (var_1['b'] == '2') and (var_1['c'] == '3')):
        return True

if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-25 04:06:55.733259
# Unit test for function parse_kv
def test_parse_kv():
    if '{{0}}' != '0':
        return

    str_0 = '{{0}}{{0}}{{0}}{{0}}{{0}}{{0}}{{0}}{{0}}{{0}}{{0}}{{0}}'
    var_0 = parse_kv(str_0)

    str_1 = '^5YkHj&9"6l7r%c^8W=P'
    var_1 = parse_kv(str_1)

    str_2 = 'z2Ov1D#U6w)M@Nx$OZo^'
    var_2 = parse_kv(str_2)

    str_3 = 'g+xD"L-ZJ*A-_)&$|>[9'
    var_3 = parse_kv(str_3)

# Generated at 2022-06-25 04:07:03.840159
# Unit test for function parse_kv
def test_parse_kv():
    print("Started testing 'parse_kv'...")
    print("test case 0: ")
    test_case_0()
    print("test case 1: ")
    test_case_1()
    print("test case 2: ")
    test_case_2()
    print("test case 3: ")
    test_case_3()
    print("test case 4: ")
    test_case_4()
    print("test case 5: ")
    test_case_5()
    print("test case 6: ")
    test_case_6()
    print("test case 7: ")
    test_case_7()
    print("test case 8: ")
    test_case_8()
    print("test case 9: ")
    test_case_9()

# Generated at 2022-06-25 04:07:15.353994
# Unit test for function split_args
def test_split_args():
    # Testcases
    str_0 = '>^KkMgD`xh<!_Q!I4:G'
    result_0 = split_args(str_0)
    assert len(result_0) == 1
    assert result_0[0] == str_0

    str_0 = '>^KkMgD`xh<!_Q!I4:G "foo bar" "\\b" "baz bang"'
    result_0 = split_args(str_0)
    assert len(result_0) == 4
    assert result_0[0] == '>^KkMgD`xh<!_Q!I4:G'
    assert result_0[1] == '"foo bar"'
    assert result_0[2] == '"\\b"'
    assert result_

# Generated at 2022-06-25 04:07:25.829738
# Unit test for function parse_kv

# Generated at 2022-06-25 04:07:30.134027
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()


# Generated at 2022-06-25 04:07:37.311813
# Unit test for function split_args
def test_split_args():
    # First test case
    args = '1=2 3=4'
    expected = ['1=2', '3=4']
    actual = split_args(args)
    assert actual == expected

    # Second test case: simple case
    args = 'a=b c=d'
    expected = ['a=b', 'c=d']
    actual = split_args(args)
    assert actual == expected

    # Third test case: new line, whitespace
    args = 'a=b \nc=d'
    expected = ['a=b', '\nc=d']
    actual = split_args(args)
    assert actual == expected

    # Fourth test case: k, v with spaces
    args = 'a="b b" c="d d"'
    expected = ['a="b b"', 'c="d d"']

# Generated at 2022-06-25 04:07:46.874159
# Unit test for function parse_kv
def test_parse_kv():
    assert True == True


# Generated at 2022-06-25 04:07:53.578272
# Unit test for function split_args
def test_split_args():
    args = "a=b c='d e' f='g h' i={{ j }} k=l"
    print(split_args(args))


# Generated at 2022-06-25 04:08:03.175806
# Unit test for function split_args
def test_split_args():
    str_1 = r'ls -l foo bar "baz with spaces"'
    assert split_args(str_1) == ['ls', '-l', 'foo', 'bar', '"baz', 'with', 'spaces"']
    str_2 = r'ls -l foo \\\\bar "baz with spaces"'
    assert split_args(str_2) == ['ls', '-l', 'foo', '\\\\bar', '"baz with spaces"']
    str_3 = r'ls -l {{PATH}}/foo {{bar}} baz'
    assert split_args(str_3) == ['ls', '-l', '{{PATH}}/foo', '{{bar}}', 'baz']
    str_4 = r'ls -l \\\\{{PATH}}/foo {{bar}} baz'
    assert split_

# Generated at 2022-06-25 04:08:07.961525
# Unit test for function parse_kv
def test_parse_kv():
    assert_equal(parse_kv('>^KkMgD`xh<!_Q!I4:G'), {'_raw_params': '>^KkMgD`xh<!_Q!I4:G'})


# Generated at 2022-06-25 04:08:20.780273
# Unit test for function split_args
def test_split_args():
    import string
    import random
    ids = 0
    cases = []
    cases.append("-a")
    cases.append("-a b")
    cases.append("-a=b")
    cases.append("-a=b c")
    cases.append("-a=b -c d")
    cases.append("-a=b -c='e f'")
    cases.append("-a=b -c=\'e f\'")
    cases.append("-a=b -c=\'e f' -d=\'g h")
    cases.append("-a=b -c=\'e f' -d=\'g h\" i")
    cases.append("-a=b -c=\'e f' -d=\"g h\" i")
    cases.append("a b=c")

# Generated at 2022-06-25 04:08:30.349331
# Unit test for function split_args
def test_split_args():
    str_14 = '''--url {{ test_url }}
--data {{ test_data }}
'''

    print(str_14)
    print(split_args(str_14))
    print()

    str_15 = '''--url {{ test_url }}
--data {{ test_data }}
--ignore-errors
'''

    print(str_15)
    print(split_args(str_15))
    print()

    str_16 = '''--url {{ test_url }}
--data '{
    "test_data": "{{ test_data }}"
}'
'''

    print(str_16)
    print(split_args(str_16))
    print()



# Generated at 2022-06-25 04:08:37.741484
# Unit test for function split_args
def test_split_args():

    # Test case 0
    str_0 = '>^KkMgD`xh<!_Q!I4:G'
    var_0 = split_args(str_0)
    out_0 = ['>^KkMgD`xh<', '_Q!I4:G']

    # Test case 1
    str_1 = '$/Y/X.00{@}[|xn-L>+R@1!w!t?Fn}(+Q1^#*X9o)&yl^<'
    var_1 = split_args(str_1)

# Generated at 2022-06-25 04:08:42.688517
# Unit test for function split_args
def test_split_args():
    str_0 = '-k hui  -p nin  -u ming --type=d2 --name=a --log=/app/log.log'
    var_0 = split_args(str_0)
    print(var_0)


# Generated at 2022-06-25 04:08:53.671025
# Unit test for function parse_kv
def test_parse_kv():
    dict_0 = dict()
    dict_0[u'_raw_params'] = u'echo >^KkMgD`xh<!_Q!I4:G'
    str_1 = 'echo >^KkMgD`xh<!_Q!I4:G'
    var_1 = parse_kv(str_1)
    assert var_1 == dict_0
    dict_1 = dict()
    dict_1[u'_raw_params'] = u'echo ">^KkMgD`xh<!_Q!I4:G"'
    str_2 = 'echo \">^KkMgD`xh<!_Q!I4:G\"'
    var_2 = parse_kv(str_2)
    assert var_2 == dict_1


# Generated at 2022-06-25 04:09:04.858416
# Unit test for function parse_kv
def test_parse_kv():
    assert to_text('\u1234') == '\u1234'
    assert to_text('\u1234', encoding='utf-8') == u'\u1234'.encode('utf-8')

    assert to_text(b'\xe4\xb8\x96\xe7\x95\x8c') == u'\u4e16\u754c'.encode('utf-8')
    assert to_text(b'\xe4\xb8\x96\xe7\x95\x8c', encoding='utf-8') == u'\u4e16\u754c'

    assert to_text(b'\xe4\xb8\x96\xe7\x95\x8c'.decode('utf-8')) == u'\u4e16\u754c'


# Generated at 2022-06-25 04:09:20.975636
# Unit test for function split_args
def test_split_args():
    print ("\n=== test split_args:")
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-25 04:09:22.791036
# Unit test for function split_args
def test_split_args():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 04:09:27.550879
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv('=')
    assert var_0 == {}

    var_1 = parse_kv('= =')
    assert var_1 == {}

    var_2 = parse_kv('a=')
    assert var_2 == {'a': ''}

    var_3 = parse_kv('a=b')
    assert var_3 == {'a': 'b'}

    var_4 = parse_kv('a')
    assert var_4 == {}


# Generated at 2022-06-25 04:09:37.122279
# Unit test for function split_args
def test_split_args():
    # The string and the expected output list
    input = 'NS_Path=/foo/bar ceph_cluster_network="{{ ceph_network }}" mds_data=/dev/sda1 ceph_fsid={{ ceph_fsid }} >/tmp/a b="c d e f" g="test,test,test"'
    expected = [u'NS_Path=/foo/bar', u'ceph_cluster_network="{{ ceph_network }}"', u'mds_data=/dev/sda1', u'ceph_fsid={{ ceph_fsid }}', u'', u'>/tmp/a', u'b="c d e f"', u'g="test,test,test"']
    # Run the unit test
    output = split_args(input)
    # Check the result with expected

# Generated at 2022-06-25 04:09:48.271246
# Unit test for function split_args
def test_split_args():

    str_0 = 'a=b c="foo bar" \\   d=\\"g\\" h="f f"'
    str_1 = 'a=b\\\n c="foo bar" \\\n  d=\\"g\\"\\\n h="f f"'
    str_2 = 'a=b\\\n c="foo bar" \\\n  d=\\"g\\"\\\n\n h="f f"'
    str_3 = 'a=b\\\n c="foo bar" \\\n  d=\\"g\\"\\\n\n'
    str_4 = 'a=b c="foo bar" \\'
    str_5 = 'a=b c="foo bar" \\'

# Generated at 2022-06-25 04:09:58.297964
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('"a e"') == ['a e']
    assert split_args('"a=b c"') == ['a=b c']
    assert split_args('"a=b c" d') == ['a=b c', 'd']
    assert split_args('"a=b c" d e') == ['a=b c', 'd', 'e']
    assert split_args('a=b c="foo bar"  d=e') == ['a=b', 'c="foo bar"', 'd=e']
    assert split_args('a=b c={{foo}} d="foo bar"  e=f') == ['a=b', 'c={{foo}}', 'd="foo bar"', 'e=f']

# Generated at 2022-06-25 04:10:03.444682
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '>^KkMgD`xh<!_Q!I4:G'
    assert parse_kv(str_0) == {}
    assert parse_kv(str_0) == {}
    assert parse_kv(str_0) == {}
    assert parse_kv(str_0) == {}
    assert parse_kv(str_0) == {}
    assert parse_kv(str_0) == {}
    assert parse_kv(str_0) == {}
    assert parse_kv(str_0) == {}
    assert parse_kv(str_0) == {}
    assert parse_kv(str_0) == {}
    assert parse_kv(str_0) == {}
    assert parse_kv(str_0) == {}
    assert parse_

# Generated at 2022-06-25 04:10:05.487744
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '>^KkMgD`xh<!_Q!I4:G'
    var_0 = parse_kv(str_0)

# Generated at 2022-06-25 04:10:16.927436
# Unit test for function split_args

# Generated at 2022-06-25 04:10:24.584417
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    assert split_args('a=b{{c=d}}e=f') == ['a=b', '{{c=d}}', 'e=f']
    assert split_args('a=b{% foo %}e=f') == ['a=b', '{% foo %}', 'e=f']
    assert split_args('a=b{# foo #}e=f') == ['a=b', '{# foo #}', 'e=f']

    assert split_args('a=b{{c=d}}e=f{{g=h}}') == ['a=b', '{{c=d}}', 'e=f', '{{g=h}}']

# Generated at 2022-06-25 04:10:45.213298
# Unit test for function parse_kv
def test_parse_kv():
    try:
        test_case_0()
    except Exception as err:
        print('test_case_0 failed: ' + str(err))
        return
    print('test_case_0 passed')

# Execute this code while this file is the main module.
# We do this to make sure the unit tests work.
if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-25 04:10:49.916755
# Unit test for function split_args
def test_split_args():
    # TODO: implement your test here
    str_0 = {"key_0": "value_0"}
    str_1 = {"key_1": "value_1"}
    try:
        assert(split_kwargs(str_0, str_1) == None)
    except AssertionError:
        print("Error: test_split_args failed!")


# Generated at 2022-06-25 04:10:54.429825
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing parse_kv')
    test_case_0()
    print('Finished test_parse_kv')


# Generated at 2022-06-25 04:10:57.221429
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()



# Generated at 2022-06-25 04:11:02.489895
# Unit test for function split_args
def test_split_args():
    try:
        with open('test_split_args.txt', 'r') as test_cases:
            for line in test_cases:
                split_args(line)
    except FileNotFoundError:
        print("First run \"python3 test_split_args.py\" to generate test_split_args.txt")
