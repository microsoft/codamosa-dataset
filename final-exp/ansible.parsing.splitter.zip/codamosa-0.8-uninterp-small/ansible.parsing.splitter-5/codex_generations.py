

# Generated at 2022-06-25 04:02:02.088795
# Unit test for function split_args
def test_split_args():
    # Test 0
    bytes_0 = None
    expected_0 = []
    var_0 = split_args(bytes_0)
    assert var_0 == expected_0, '0 Failed'
    # Test 1
    bytes_1 = b'a=b'
    expected_1 = [b'a=b']
    var_1 = split_args(bytes_1)
    assert var_1 == expected_1, '1 Failed'
    # Test 2
    bytes_2 = b'a=b\x00'
    expected_2 = [b'a=b\x00']
    var_2 = split_args(bytes_2)
    assert var_2 == expected_2, '2 Failed'
    # Test 3
    bytes_3 = b'a="b\x00"'

# Generated at 2022-06-25 04:02:09.507042
# Unit test for function parse_kv
def test_parse_kv():
    # TEST: 
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()



# Generated at 2022-06-25 04:02:18.897406
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'foo=bar baz="qux quux" "corge=grault"="garply waldo"'
    var_0 = parse_kv(bytes_0)
    assert 'foo' in var_0
    assert str(var_0['foo']) == 'bar'
    assert 'baz' in var_0
    assert str(var_0['baz']) == 'qux quux'
    assert 'corge=grault' in var_0
    assert str(var_0['corge=grault']) == 'garply waldo'
    assert '_raw_params' not in var_0

    bytes_1 = b'foo=bar baz=qux quux corge=grault="garply waldo"'

# Generated at 2022-06-25 04:02:22.395467
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = 'foo=bar'
    var_0 = parse_kv(bytes_0)
    assert var_0['foo'] == 'bar'


# Generated at 2022-06-25 04:02:30.409597
# Unit test for function split_args
def test_split_args():
    # Test case 0
    bytes_0 = b'a=b c="foo bar"\x00'
    var_0 = split_args(bytes_0)

    # Test case 1
    bytes_1 = None
    var_1 = split_args(bytes_1)

    # Test case 2
    bytes_2 = b'a=b c="foo bar"\x00'
    var_2 = split_args(bytes_2)

    # Test case 3
    bytes_3 = b'a=b c="foo bar"'
    var_3 = split_args(bytes_3)

    # Test case 4
    bytes_4 = b'a=b c="foo bar\nfoobar"'
    var_4 = split_args(bytes_4)

    # Test case 5

# Generated at 2022-06-25 04:02:43.690387
# Unit test for function split_args
def test_split_args():
    assert split_args('/bin/ls -l') == ['/bin/ls', '-l']
    assert split_args('-x /etc/passwd') == ['-x', '/etc/passwd']
    assert split_args('"foo bar baz" xyzzy') == ['"foo bar baz"', 'xyzzy']
    assert split_args("'foo bar baz' xyzzy") == ["'foo bar baz'", 'xyzzy']
    assert split_args('"foo bar') == ['"foo', 'bar']
    assert split_args("'foo bar") == ["'foo", 'bar']
    assert split_args('foo "bar baz') == ['foo', '"bar', 'baz']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']


# Generated at 2022-06-25 04:02:51.251933
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 04:02:57.475985
# Unit test for function split_args
def test_split_args():
    # TEST CASES

    # Test case 0
    result = split_args(None)
    assert result is None

    # Test case 1
    result = split_args("")
    assert result == []

    # Test case 2
    result = split_args("a=b c='foo bar'")
    assert result == [u"a=b", u"c='foo bar'"]

    # Test case 3
    result = split_args("\"quoted\"")
    assert result == [u"\"quoted\""]

    # Test case 4
    result = split_args("'quoted'")
    assert result == [u"'quoted'"]

    # Test case 5
    result = split_args("single=singletypedouble=\"doubletypedouble=doubletype\"")

# Generated at 2022-06-25 04:03:03.831076
# Unit test for function split_args

# Generated at 2022-06-25 04:03:09.665058
# Unit test for function split_args
def test_split_args():
    assert split_args(None) == []
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c=d e=f') == ['a=b', 'c=d', 'e=f']
    assert split_args('{\n') == ['{']
    assert split_args('{\n  foo: bar') == ['{', 'foo: bar']
    assert split_args('{\n  foo: bar\n') == ['{', 'foo: bar']


# Generated at 2022-06-25 04:03:33.124511
# Unit test for function parse_kv
def test_parse_kv():
    # Test all combinations of input args
    test_0 = join_args(None)
    assert test_0 == ""
    test_1 = join_args(None, True)
    assert test_1 == ""
    test_2 = join_args(None, False)
    assert test_2 == ""
    test_3 = join_args("")
    assert test_3 == ""
    test_4 = join_args("", True)
    assert test_4 == ""
    test_5 = join_args("", False)
    assert test_5 == ""
    test_6 = join_args(" ")
    assert test_6 == ""
    test_7 = join_args(" ", True)
    assert test_7 == ""
    test_8 = join_args(" ", False)
    assert test_8 == ""
    test_

# Generated at 2022-06-25 04:03:41.352354
# Unit test for function split_args
def test_split_args():
    bytes_0 = """a=b c="foo bar"\n"""
    b_0 = ['a=b', 'c="foo bar"']
    assert split_args(bytes_0) == b_0
    bytes_1 = """a=b c="foo bar"""
    b_1 = ['a=b', 'c="foo bar"']
    assert split_args(bytes_1) == b_1

# Generated at 2022-06-25 04:03:54.244496
# Unit test for function split_args
def test_split_args():
    #test_case_0
    bytes_0 = None
    var_0 = split_args(bytes_0)
    print(var_0)
    #test_case_1
    bytes_0 = '''a b c'''
    var_0 = split_args(bytes_0)
    assert var_0[0] == 'a'
    assert var_0[1] == 'b'
    assert var_0[2] == 'c'
    print(var_0)
    #test_case_2
    bytes_0 = '''a  b   c'''
    var_0 = split_args(bytes_0)
    assert var_0[0] == 'a'
    assert var_0[1] == 'b'
    assert var_0[2] == 'c'

# Generated at 2022-06-25 04:03:56.016459
# Unit test for function parse_kv
def test_parse_kv():
    arg_0 = "arg_0"
    arg_1 = True
    options = parse_kv(arg_0, arg_1)
    assert options is not None


# Generated at 2022-06-25 04:04:00.184740
# Unit test for function split_args
def test_split_args():
    # Testing with the following input:
    # args: "a=b c=\"foo bar\""
    args = "a=b c=\"foo bar\""

    # Testing with the following input:
    # args: "a=b c=\"foo bar\""
    var_0 = split_args(args)
    print('Var: {0}'.format(var_0))


# Generated at 2022-06-25 04:04:02.861400
# Unit test for function parse_kv
def test_parse_kv():
    input_str = '''"foo=bar" bar="baz qux"'''
    var_0 = parse_kv(input_str)
    assert var_0 == {'bar': 'baz qux', 'foo': 'bar', '_raw_params': '"foo=bar" bar="baz qux"'}


# Generated at 2022-06-25 04:04:05.489099
# Unit test for function split_args
def test_split_args():
    print('Testing split_args')
    print('test_case_0')
    test_case_0()


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:04:09.746551
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    assert module is not None

    # example input
    args = b'a=b c="foo bar"'
    # expected output
    expected_result = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected_result


# Generated at 2022-06-25 04:04:20.188036
# Unit test for function split_args
def test_split_args():
    # simple args
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']
    assert split_args('a="b\'c" d=e') == ['a="b\'c"', 'd=e']
    assert split_args('myvar={{ myvalue }}') == ['myvar={{', 'myvalue', '}}']

    # multiple lines
    assert split_args('a=b\nc=d') == ['a=b', '\n', 'c=d']

    # no equals
    assert split_args('asd qwe') == ['asd', 'qwe']

    # newline equals
    assert split

# Generated at 2022-06-25 04:04:26.164783
# Unit test for function split_args
def test_split_args():
    print("\nStart test split_args")
    with open("../yml/test_split_args.yml") as test_file:
        for test in yaml.load_all(test_file):
            # print(test)
            print("\ninput string: " + test["input"])
            print("\nExpected output: " + json.dumps(test["output"]))
            result = split_args(test["input"])
            print("\nResult: " + json.dumps(result))
            assert(result == test["output"])


# Generated at 2022-06-25 04:04:41.928015
# Unit test for function split_args
def test_split_args():
    # This is the test case for python3.
    bytes_0 = None
    var_0 = split_args(bytes_0)

    bytes_1 = ""
    var_1 = split_args(bytes_1)
    print(var_1)

    bytes_2 = "a=b c=\"foo bar\""
    var_2 = split_args(bytes_2)
    print(var_2)


if __name__ == "__main__":
    test_case_0()

    test_split_args()

# Generated at 2022-06-25 04:04:51.338163
# Unit test for function split_args
def test_split_args():
    # Test 0
    # The python interpreter crashes when split_args(None) is called
    # test_case = 0
    # test_split_args_helper(test_case)

    # Test 1
    test_case = 1
    test_split_args_helper(test_case)

    # Test 2
    test_case = 2
    test_split_args_helper(test_case)

# Helper function for unit test

# Generated at 2022-06-25 04:05:03.742273
# Unit test for function split_args
def test_split_args():
    # Test case 1
    # Test case with a single argument
    bytes_0 = None
    var_0 = split_args(bytes_0)
    assert var_0 == []

    # Test case 2
    # Test case with a single argument and a newline
    bytes_0 = u'\n'
    var_0 = split_args(bytes_0)
    assert var_0 == [u'\n']

    # Test case 3
    # Test case with two arguments separated by a newline
    bytes_0 = u'a\nb'
    var_0 = split_args(bytes_0)
    assert var_0 == [u'a', u'b']

    # Test case 4
    # Test case with an empty argument with whitespace
    bytes_0 = u'a b'
    var_0 = split_args

# Generated at 2022-06-25 04:05:13.756685
# Unit test for function parse_kv
def test_parse_kv():
    print(parse_kv(None))
    print(parse_kv('a=1'))
    print(parse_kv('a=1 b=2 c=3'))
    print(parse_kv('a="foo bar" b=\'baz qux\''))
    print(parse_kv('a=1 b="foo bar" c=3 d=\'baz qux\''))
    print(parse_kv('a="1 2 3" b=4 c=5'))
    print(parse_kv('a="1=2 3" b=4 c=5'))
    print(parse_kv('a=1 b="2=3" c=4'))
    print(parse_kv('a=1 b=2 c=\'3=4 5\''))

# Generated at 2022-06-25 04:05:19.315379
# Unit test for function parse_kv
def test_parse_kv():
    data_0 = None

# Generated at 2022-06-25 04:05:21.456080
# Unit test for function parse_kv
def test_parse_kv():
    raw_options = None
    checked_raw = None
    var_0 = parse_kv(raw_options, checked_raw)


# Generated at 2022-06-25 04:05:25.822880
# Unit test for function split_args

# Generated at 2022-06-25 04:05:30.402528
# Unit test for function split_args
def test_split_args():
    print(split_args('''a=b c="foo bar"'''))

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:05:37.837108
# Unit test for function split_args
def test_split_args():
    bytes_0 = 'a=b c="foo bar"'
    var_0 = split_args(bytes_0)
    assert var_0 == ['a=b', 'c="foo bar"']

    bytes_1 = 'a=b c="foo \n bar"'
    var_1 = split_args(bytes_1)
    assert var_1 == ['a=b', 'c="foo', 'bar"']

    bytes_2 = 'a=b c="foo \\\\n bar"'
    var_2 = split_args(bytes_2)
    assert var_2 == ['a=b', 'c="foo \\', 'bar"']

    bytes_3 = 'a=b c=\\'
    var_3 = split_args(bytes_3)
    assert var_3 == ['a=b', 'c=']



# Generated at 2022-06-25 04:05:48.007008
# Unit test for function split_args
def test_split_args():
    print("test case 0")
    r = 'a=b c="foo bar"'
    res = split_args(r)
    assert "a=b" == res[0]
    assert 'c="foo bar"' == res[1]
    print("test case 1")
    r = 'a=b c="foo bar" d=e f="g h i" j="k l=m n" o=p'
    res = split_args(r)
    assert "a=b" == res[0]
    assert 'c="foo bar"' == res[1]
    assert 'd=e' == res[2]
    assert 'f="g h i"' == res[3]
    assert 'j="k l=m n"' == res[4]
    assert 'o=p' == res[5]

# Generated at 2022-06-25 04:06:00.987081
# Unit test for function split_args
def test_split_args():
    args = '''
    {{  var_0 }}
    {{ var_1 }}
    {{ var_2  }}
    '''

    args_list = ['{{', 'var_0', '}}', '{{', 'var_1', '}}', '{{', 'var_2', '}}']
    split_args_list = split_args(args)

# Generated at 2022-06-25 04:06:08.922292
# Unit test for function split_args
def test_split_args():
    print("Testing function split_args")
    var_0 = "foo bar"
    var_1 = 'foo bar'
    var_2 = '"foo bar"'
    var_3 = "foo \"bar"
    var_4 = 'foo "bar'
    var_5 = 'foo \"bar'
    var_6 = "foo \"bar\""
    var_7 = 'foo "bar"'
    var_8 = 'a=b c=d e="foo bar"'
    var_9 = 'a=b\nc=d\ne="foo bar"'
    var_10 = 'a=b\nc=d\ne="foo bar\\n"'
    var_11 = '{{ foo }}'
    var_12 = '{{ foo }}\nbar'
    var_13 = '{{ foo\n}}'
    var_14

# Generated at 2022-06-25 04:06:12.351119
# Unit test for function split_args
def test_split_args():
    var_1 = None
    var_2 = parse_kv(var_1)
    assert var_2 == None


# Generated at 2022-06-25 04:06:16.728141
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = None
    assert parse_kv(var_0) == {}


# Generated at 2022-06-25 04:06:28.018622
# Unit test for function parse_kv
def test_parse_kv():
    args = None
    check_raw = False
    expected_result = {}
    result = parse_kv(args, check_raw)                    # Unit test for function parse_kv
    assert result == expected_result                      # Unit test for function parse_kv

    args = None
    check_raw = True
    expected_result = {}
    result = parse_kv(args, check_raw)                    # Unit test for function parse_kv
    assert result == expected_result                      # Unit test for function parse_kv

    args = ""
    check_raw = False
    expected_result = {}
    result = parse_kv(args, check_raw)                    # Unit test for function parse_kv
    assert result == expected_result                      # Unit test for function parse_kv

    args = ""
    check_raw = True
   

# Generated at 2022-06-25 04:06:35.148278
# Unit test for function split_args
def test_split_args():
    print("Test: split_args")
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=d e=f \"foo bar\"") == ['a=b', 'c=d', 'e=f', '"foo bar"']
    assert split_args("a=\"b c\"") == ['a="b c"']
    assert split_args("a=\"b c\" d=e") == ['a="b c"', 'd=e']
    assert split_args("a=\"b c\" \"d e\" f=g") == ['a="b c"', '"d e"', 'f=g']

# Generated at 2022-06-25 04:06:37.628384
# Unit test for function split_args
def test_split_args():
    test_case_0()
    test_case_join_args()


# Generated at 2022-06-25 04:06:40.460035
# Unit test for function split_args
def test_split_args():
    for var_0 in [None]:
        assert split_args(var_0) == [u'foo', u'bar']


# Generated at 2022-06-25 04:06:43.481791
# Unit test for function split_args
def test_split_args():
    var_0 = None
    var_1 = split_args(var_0)

# Generated at 2022-06-25 04:06:47.892338
# Unit test for function split_args
def test_split_args():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 04:07:16.445808
# Unit test for function split_args
def test_split_args():
    assert parse_kv("foo") == {u'foo': u''}
    assert parse_kv("foo=") == {u'foo': u''}
    assert parse_kv("foo=bar") == {u'foo': u'bar'}
    assert parse_kv("foo='bar'") == {u'foo': u'bar'}
    assert parse_kv("foo=\"bar\"") == {u'foo': u'bar'}
    assert parse_kv("foo=foo bar") == {u'foo': u'foo bar'}
    assert parse_kv("foo=foo bar", check_raw=True) == {u'foo': u'foo bar', u'_raw_params': u'foo bar'}

# Generated at 2022-06-25 04:07:27.007942
# Unit test for function split_args
def test_split_args():
    # if you want positive test cases, add them here
    var_10 = 'a=b c="foo bar"'
    var_11 = 'a=b c="foo bar"'
    var_12 = 'a=b c="foo bar'
    var_13 = 'a=b c="foo bar "d""'
    var_14 = 'a=b c="foo bar "d""'
    var_15 = 'a=b c="foo bar "d""'
    var_16 = 'a=b c="foo bar "d""'
    var_17 = "foo bar\nbar baz\ndoo bee"

    # if you want negative test cases, add them here
    var_20 = None

    result_10 = split_args(var_10)
    result_11 = split_args(var_11)
    result

# Generated at 2022-06-25 04:07:32.091352
# Unit test for function split_args
def test_split_args():
    var_0 = '/usr/bin/scl enable rh-python36 -- uwsgi --ini /etc/uwsgi/uwsgi.ini -d /var/log/uwsgi/uwsgi.log'
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None

    var_1 = split_args(var_0)
    var_2 = var_1
    var_3 = var_2
    var_4 = var_3
    var_5 = var_4
    var_6 = var_5
    print('var_5: ', var_1)

test_split_args()

# Generated at 2022-06-25 04:07:35.515877
# Unit test for function split_args
def test_split_args():
    var_0 = None
    assert split_args('" http_port=8080"') == ['http_port=8080']


# Generated at 2022-06-25 04:07:44.903805
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ e=f }}") == ['a=b', 'c="foo bar"', 'd={{', 'e=f', '}}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{', 'foo', '}}']
    assert split_args("a=b c=\"\"foo\" bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{', 'foo', '}}']

# Generated at 2022-06-25 04:07:54.764326
# Unit test for function split_args
def test_split_args():
    # var_0 = [u'a=b', u'c=\\"foo bar\\"']
    var_1 = [u'a=b', u'c="foo bar"']
    # var_2 = [u'a=b', u'c="foo bar"']
    args_0 = "a=b c='foo bar'"
    args_1 = "a=b c=\"foo bar\""
    args_2 = "a=b c='foo bar'"
    args_3 = "a=b c=\"foo bar\""
    args_4 = "a=b c='foo bar'"
    args_5 = "a=b c=\"foo bar\""
    args_6 = "a=b c='foo bar'"
    args_7 = "a=b c=\"foo bar\""
    assert var_1 == split

# Generated at 2022-06-25 04:08:03.820732
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('echo "foo bar" > /tmp/foo.txt') == ['echo', '"foo bar"', '>', '/tmp/foo.txt']
    assert split_args('echo "foo bar" {% if test %}> /tmp/foo.txt{% else %}> /tmp/bar.txt{% endif %}') == ['echo', '"foo bar"', '{% if test %}> /tmp/foo.txt{% else %}> /tmp/bar.txt{% endif %}']

# Generated at 2022-06-25 04:08:06.453515
# Unit test for function split_args
def test_split_args():
    # Test case for function split_args
    args = u"a=b c=\"foo bar\" d='foo bar'"
    expected = ['a=b', 'c="foo bar"', 'd=\'foo bar\'']
    actual = split_args(args)
    assert actual == expected

# Generated at 2022-06-25 04:08:12.266278
# Unit test for function split_args
def test_split_args():
    x = '"foo bar"'
    result = split_args(x)
    assert result == ['"foo bar"']

    x = "foo=bar"
    result = split_args(x)
    assert result == ["foo=bar"]

    x = "foo=bar\nfoo2=bar2"
    result = split_args(x)
    assert result == ["foo=bar", "foo2=bar2"]

    x = "foo=bar\nfoo2=bar2\n"
    result = split_args(x)
    assert result == ["foo=bar", "foo2=bar2", ""]

    x = "ansible_ssh_pass={{ vault_pass }}\nansible_become_pass={{ vault_pass }}"
    result = split_args(x)

# Generated at 2022-06-25 04:08:19.952391
# Unit test for function split_args

# Generated at 2022-06-25 04:08:46.620250
# Unit test for function parse_kv
def test_parse_kv():
    vars = var()
    var_0 = None
    var_1 = ''
    var_2 = 'a=1'
    var_3 = 'a=1 b=2'
    var_4 = 'a=1 b=2 c=3'
    var_5 = 'a="1=1" b="2=2" c="3=3"'
    var_6 = 'a="1=1" b="2=2" c=3'
    var_7 = 'a="1=1" b="2=2" c="3=3" d=4'
    var_8 = 'a=1\' b=2'
    var_9 = 'a=1" b=2'
    var_10 = "a=1' b=2 c=3"

# Generated at 2022-06-25 04:08:49.806132
# Unit test for function parse_kv
def test_parse_kv():
    args = 'creates=/tmp/foo executable=/bin/sh'
    exp = {u'creates': u'/tmp/foo', u'executable': u'/bin/sh'}

    res = parse_kv(args, check_raw=False)
    assert res == exp


# Generated at 2022-06-25 04:09:01.605044
# Unit test for function parse_kv
def test_parse_kv():

    # Inline testcase data
    test_data = [
        {
            'args': None, # [input]
            'check_raw': False, # [input]
            'expected_result': None, # [output]
        }
    ]

    # Loop over all test cases
    for test_case in test_data:

        # Setup test environment
        var_0 = test_case.get('args', None)
        var_1 = test_case.get('check_raw', False)

        # Run function under test
        result = parse_kv(var_0, var_1)

        # Do assert checks
        expected_result = test_case.get('expected_result', None)
        assert isinstance(result, type(expected_result))
        assert result == expected_result


# Generated at 2022-06-25 04:09:05.236690
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = None
    var_1 = None
    u'key=value'
    var_2 = False
    var_3 = parse_kv(var_0, var_1)
    assert var_3 == {u'key': u'value'}


# Generated at 2022-06-25 04:09:11.575833
# Unit test for function parse_kv
def test_parse_kv():
    print("testing parse_kv")
    var_0 = None
    var_1 = None
    try:
        var_0 = parse_kv(var_0)
    except:
        var_1 = 'exception'
    try:
        assert var_0 == None
    except AssertionError as e:
        print("AssertionError : ", e)
        print("unexpected result from parse_kv")
        var_1 = 'fail'

    print("test case 0 finished")
    print("test case 1")
    test_case_0()
    print("test case 1 finished")
    print("test case 2")
    test_case_0()
    print("test case 2 finished")
if __name__ == '__main__':
    test_parse_kv()
    print('All tests finished')

# Generated at 2022-06-25 04:09:21.976726
# Unit test for function parse_kv

# Generated at 2022-06-25 04:09:23.460713
# Unit test for function split_args
def test_split_args():
    var_0 = None
    assert split_args(var_0) == "Invalid input"


# Generated at 2022-06-25 04:09:36.921114
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = "a=1 b=2 c=3"
    var_1 = True
    expected_0 = {"a": "1", "b": "2", "c": "3"}
    expected_1 = "_raw_params"
    expected_2 = "a=1 b=2 c=3"
    expected_3 = "a=1 b=2 c=3"

    actual_0 = parse_kv(var_0, var_1)
    actual_1 = actual_0.keys()
    actual_2 = actual_0.get("a")
    actual_3 = actual_0.get("_raw_params")

    assert expected_0 == actual_0, "Failed parse_kv"
    assert expected_1 == actual_1, "Failed parse_kv"

# Generated at 2022-06-25 04:09:37.808029
# Unit test for function split_args
def test_split_args():
    assert( test_case_0() )

# Generated at 2022-06-25 04:09:43.746622
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = '"a=1 b=2" c=3'
    var_1 = {}
    var_2 = parse_kv(var_0, check_raw=True)
    assert var_1 == var_2


if __name__ == "__main__":
     pass

# ##############################################################################
# END OF FILE
# ##############################################################################

# Generated at 2022-06-25 04:10:00.384643
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 04:10:10.909408
# Unit test for function parse_kv
def test_parse_kv():
    var_1 = ""
    assert parse_kv(var_1) == {}
    var_2 = None
    assert parse_kv(var_2) == {}
    var_3 = "k=v\n"
    expected = {u'k': u'v'}
    assert parse_kv(var_3) == expected
    var_4 = "k=v\nk=v\n"
    expected = {u'k': u'v\nk=v'}
    assert parse_kv(var_4) == expected
    var_5 = "k=v\nk==v\n"
    expected = {u'k': u'v\nk=v'}
    assert parse_kv(var_5) == expected

# Generated at 2022-06-25 04:10:12.197510
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(var_0) is None


# Generated at 2022-06-25 04:10:20.996652
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = None
    x = parse_kv(var_0, False)
    if not isinstance(x, dict):
        raise AssertionError("", "parse_kv returned %s instead of %s" % (type(x), type(dict())))
    assert x == {}, "parse_kv returned %s instead of %s" % (x, dict())

    var_0 = ""
    x = parse_kv(var_0, False)
    if not isinstance(x, dict):
        raise AssertionError("", "parse_kv returned %s instead of %s" % (type(x), type(dict())))
    assert x == {}, "parse_kv returned %s instead of %s" % (x, dict())

    var_0 = "a"
    x = parse_k

# Generated at 2022-06-25 04:10:27.052498
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = None

    # Call function with args
    try:
        x = parse_kv(var_0)
    except Exception as e:
        #print(e)
        raise AssertionError("Error encountered during parsing")
        print("\n** test case 0 **\n")
        print(e)
        test_case_0()


# Generated at 2022-06-25 04:10:28.791276
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-25 04:10:31.209076
# Unit test for function parse_kv
def test_parse_kv():
    try:
        var_0 = None
        var_1 = True
        cls_0 = parse_kv(var_0, var_1)
        print(cls_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 04:10:34.455033
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = None
    var_1 = False
    var_2 = {}
    var_2 = parse_kv(var_0, var_1)
    assert var_2 is None

# Checking for function parse_kv with parameter 'args' set to 'None'

# Generated at 2022-06-25 04:10:36.143823
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv(None)
    assert "0" == "0"


# Generated at 2022-06-25 04:10:41.188967
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = None
    assert callable(parse_kv)

    # Test cases for function parse_kv
    var_0 = ""
    parse_kv(var_0)


if __name__ == '__main__':
    test_case_0()
    test_parse_kv()