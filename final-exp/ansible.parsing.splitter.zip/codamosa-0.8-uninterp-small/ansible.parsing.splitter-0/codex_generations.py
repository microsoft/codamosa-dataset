

# Generated at 2022-06-25 04:02:02.545175
# Unit test for function parse_kv
def test_parse_kv():
    from tests.unit import utils
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    module = AnsibleModule(argument_spec=dict())
    module.exit_json = utils.safe_exit_json
    module.params = {'arg1': 'key=value key=value'}
    result = parse_kv(module.params['arg1'])
    assert result == {u'key': u'value', u'key': u'value'}
    result = parse_kv(module.params['arg1'], True)
    assert result == {u'key': u'value', u'key': u'value'}


# Generated at 2022-06-25 04:02:04.399303
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv(None)



# Generated at 2022-06-25 04:02:12.945646
# Unit test for function split_args
def test_split_args():
    # FIXME: make these tests more realistic
    assert split_args('') == []
    assert split_args('one two three') == ['one', 'two', 'three']
    assert split_args('one \'two three\'') == ['one', '\'two three\'']
    assert split_args('one "two three"') == ['one', '"two three"']
    assert split_args('one "two three') == ['one', '"two three']
    assert split_args('one "two three\\') == ['one', '"two three\\']
    assert split_args('one "two three\\\\') == ['one', '"two three\\\\']
    assert split_args('one "two three\\\\\\') == ['one', '"two three\\\\\\\\']

# Generated at 2022-06-25 04:02:17.156199
# Unit test for function parse_kv
def test_parse_kv():
    var_bool_0 = False
    var_0 = parse_kv(var_bool_0)
    print(var_0)


# Generated at 2022-06-25 04:02:22.435602
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(False) == False


# Split args into a list of arguments, handling quotes,
# escaping, etc.
# This function is modified from shell_to_args() in
# lib/ansible/utils/shlex.py in Ansible

# Generated at 2022-06-25 04:02:30.434760
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'a=b c=d'
    str_1 = 'a="b c" d="e f"'
    str_2 = 'a="b" c="d e" f="g h"'
    str_3 = 'a="""b""" c=" d """ e'
    str_4 = 'c="d" e="f g"'
    str_5 = 'a="b""c" d="e f g"'
    str_6 = 'a="b""c" d="e f g"'
    str_7 = 'a="b""c" d="e f g"'
    str_8 = 'a="b""c" d="e f g"'
    str_9 = 'a="b""c" d="e f g"'
    str_10 = 'a="b""c" d="e f g"'

# Generated at 2022-06-25 04:02:35.390060
# Unit test for function split_args
def test_split_args():
    args = "'foo bar' baz=ba "
    vargs = split_args(args)
    
    # Should be 3 items
    assert vargs[0] == "'foo bar'"
    assert vargs[1] == "baz=ba"
    assert len(vargs) == 2
    
    
if __name__ == '__main__':
    test_case_0()
    test_split_args()
    pass

# Generated at 2022-06-25 04:02:38.748142
# Unit test for function parse_kv
def test_parse_kv():
    try:
        test_case_0()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-25 04:02:48.152129
# Unit test for function parse_kv
def test_parse_kv():
    test_cases = [
        # test case #0
        {
            'input': False,
            'expected': False,
        },
        # test case #1
        {
            'input': False,
            'expected': False,
        },
        # test case #2
        {
            'input': False,
            'expected': False,
        },
        # test case #3
        {
            'input': False,
            'expected': False,
        },
        # test case #4
        {
            'input': False,
            'expected': False,
        },
    ]

    for test_case in test_cases:
        assert test_case['expected'] == parse_kv(test_case['input'])



# Generated at 2022-06-25 04:02:50.104909
# Unit test for function parse_kv
def test_parse_kv():
    if not unittest.TextTestRunner().run(unittest.makeSuite(TestParseKv)).wasSuccessful():
        sys.exit(1)

# Generated at 2022-06-25 04:03:09.823281
# Unit test for function split_args
def test_split_args():
    arg_str = "a=b c={{foo}} d={{foo.bar}} e={{foo.bar.baz}} f=\"{{a.b.c.d}}\""
    split = split_args(arg_str)
    assert split == ["a=b", "c={{foo}}", "d={{foo.bar}}", "e={{foo.bar.baz}}", 'f="{{a.b.c.d}}"']
    

# Generated at 2022-06-25 04:03:17.526943
# Unit test for function parse_kv
def test_parse_kv():
    # Set arguments
    args = 'ansible-playbook demo.yml -e "server=localhost" -e "port=5000"'

    # Call function
    result = parse_kv(args)

    # AssertionError
    assert result == {'server': 'localhost', 'port': '5000'}
    assert result == {'server': 'localhost', 'port': '5000'}


# Generated at 2022-06-25 04:03:25.949821
# Unit test for function split_args
def test_split_args():
  assert split_args("foo") == ["foo"]
  # assert split_args("foo bar") == ["foo", "bar"]
  # assert split_args("foo bar baz") == ["foo", "bar", "baz"]
  # assert split_args("a=b c=d") == ["a=b", "c=d"]
  # assert split_args("foo=bar a=b") == ["foo=bar", "a=b"]
  # assert split_args("foo=bar we=do a=b") == ["foo=bar", "we=do", "a=b"]
  # assert split_args("foo bar\nwe do a=b") == ["foo", "bar", "we", "do", "a=b"]

  # assert split_args("foo\nbar\nwizbang") == ["foo", "bar

# Generated at 2022-06-25 04:03:27.244253
# Unit test for function split_args
def test_split_args():
    print("Test case 0: test_case_0")
    test_case_0()


# Generated at 2022-06-25 04:03:28.386784
# Unit test for function parse_kv
def test_parse_kv():
    assert 0 == 0

# Generated at 2022-06-25 04:03:31.138062
# Unit test for function split_args
def test_split_args():
	# Arrange
	args = 'a=b c="foo bar"'

	# Act
	result = split_args(args)

	# Assert
	assert(len(result) == 2)
	assert(result[0] == 'a=b')
	assert(result[1] == 'c="foo bar"')

# Generated at 2022-06-25 04:03:35.897357
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv('A=B C="D E"')
    assert(options == {u'A': u'B', u'C': u'D E'})



# Generated at 2022-06-25 04:03:41.989033
# Unit test for function parse_kv
def test_parse_kv():
    # User-defined parameters
    args = '''--name=test username=1 password=2 --name=test2'''

    # Expected Result
    exp_result = {'username': '1', '_raw_params': 'password=2', '--name': 'test2'}
    # Expected Result
    exp_result = [{'username': '1', '_raw_params': 'password=2', '--name': 'test2'}]

    # Call the function under test
    result = parse_kv(args)

    # Verify the result
    assert result == exp_result


# Generated at 2022-06-25 04:03:54.937709
# Unit test for function split_args
def test_split_args():
    
    # Test case 0
    args = "a=b c=\"foo bar\""
    result = ['a=b', 'c="foo bar"']
    assert split_args(args) == result
    
    # Test case 1
    args = "a=b c=\"foo\\\"bar\""
    result = ['a=b', 'c="foo\\"bar"']
    assert split_args(args) == result
    
    # Test case 2
    args = "a=b | c='foo bar'"
    result = ['a=b', "|", "c='foo bar'"]
    assert split_args(args) == result
    
    # Test case 3
    args = "a=b | c='foo bar' & d='wee woo'"

# Generated at 2022-06-25 04:03:59.794144
# Unit test for function parse_kv
def test_parse_kv():
    for t in test_case_0():
        #prepare parameters
        out = parse_kv(t["input"])

        #execute the code under test
        out = parse_kv(t["input"])
        
        #verify results
        print(str(t["out"]))
        print(str(out))
        assert t["out"] == out
test_parse_kv()

# Generated at 2022-06-25 04:04:19.229949
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'P\x9bL'
    var_0 = split_args(bytes_0)
    assert var_0 == ['P' + chr(0x9b) + 'L']

    bytes_0 = b'P\x9bL'
    var_0 = split_args(bytes_0)
    assert var_0 == ['P' + chr(0x9b) + 'L']

    bytes_0 = b'P\x9bL'
    var_0 = split_args(bytes_0)
    assert var_0 == ['P' + chr(0x9b) + 'L']

    bytes_0 = b'P\x9bL'
    var_0 = split_args(bytes_0)

# Generated at 2022-06-25 04:04:27.045542
# Unit test for function parse_kv
def test_parse_kv():
    for test_case_0 in range(0,20):
        test_case_0()
    for test_case_1 in range(0,20):
        test_case_1()
    for test_case_2 in range(0,20):
        test_case_2()
    for test_case_3 in range(0,20):
        test_case_3()
    for test_case_4 in range(0,20):
        test_case_4()
    for test_case_5 in range(0,20):
        test_case_5()
    for test_case_6 in range(0,20):
        test_case_6()
    for test_case_7 in range(0,20):
        test_case_7()

# Generated at 2022-06-25 04:04:37.867554
# Unit test for function split_args
def test_split_args():
    # Can we split a simple args string?
    args = 'one two three'
    params = split_args(args)
    assert params == ['one', 'two', 'three']
    
    # Can we split a simple args string with spaces?
    args = 'one "two three"'
    params = split_args(args)
    assert params == ['one', '"two three"']
    
    # Can we split a mixed args string that contains spaces?
    args = 'one "two three" four'
    params = split_args(args)
    assert params == ['one', '"two three"', 'four']
    
    # Can we split a mixed args string that contains spaces and is spread over two lines?
    args = 'one "two three" four\nfive six'
    params = split_args(args)
    assert params

# Generated at 2022-06-25 04:04:43.534870
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'P\x9bL\x9a\x92\xa2\x8a\xa2\x90\xa2\x92\xa2\x8a\xa0'
    var_0 = parse_kv(bytes_0)
    bytes_1 = b'P\x9bL\x9a\x98\xa0\x96\xa0\x90\xa0\x92\xa0\xa2\x98'
    var_1 = parse_kv(bytes_1)
    bytes_2 = b'P\x9bL\x9a\x90\xa2\x96\xa2\x90\xa2\x92\xa2\xa2\x90'
    var_2 = parse_kv(bytes_2)


# Generated at 2022-06-25 04:04:54.572488
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'{1}'
    result = split_args(bytes_0)
    assert result == ['{1}']
    assert result != None
    assert result != "abc"

    bytes_0 = b'{1'
    result = split_args(bytes_0)
    assert result == ['{1']
    assert result != None
    assert result != "abc"

    bytes_0 = b'ansible,action=sync,src='
    result = split_args(bytes_0)
    assert result == ['ansible,action=sync,src=']
    assert result != None
    assert result != "abc"

    bytes_0 = b'{1\n'
    result = split_args(bytes_0)
    assert result == ['{1\n']
    assert result != None

# Generated at 2022-06-25 04:04:57.764735
# Unit test for function split_args
def test_split_args():
    # Use test case 0
    bytes_0 = b'P\x9bL'
    params = split_args(bytes_0)
    if params != [b'P\x9bL']:
        print('Test case 0: Failed: expected [b\'P\x9bL\'] but got ' + str(params) + ' instead.')
    else:
        print('Test case 0: Passed')


# Generated at 2022-06-25 04:05:00.155106
# Unit test for function split_args
def test_split_args():
    # Test 0
    bytes_0 = b'P\x9bL'
    var_0 = split_args(bytes_0)



# Generated at 2022-06-25 04:05:06.881172
# Unit test for function split_args
def test_split_args():
    assert(split_args("a=b") == ['a=b'])
    assert(split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"])
    assert(split_args("foo='{{bar}}'") == ["foo='{{bar}}'"])
    assert(split_args("foo='{{bar}}") == ["foo='{{bar}}"])
    assert(split_args("foo='{{bar}}") == ["foo='{{bar}}"])
    assert(split_args("foo=\"{{bar}}\"") == ['foo="{{bar}}"'])
    assert(split_args("foo=\"{{bar}}") == ["foo=\"{{bar}}"])

# Generated at 2022-06-25 04:05:14.617111
# Unit test for function split_args
def test_split_args():
    # testcase0
    assert split_args('P\x9bL') == ['P\x9bL']
    # testcase1
    assert split_args('P\x9bL ') == ['P\x9bL']
    # testcase2
    assert split_args('P\x9bL=') == ['P\x9bL=']
    # testcase3
    assert split_args('P\x9bL\n') == ['P\x9bL']
    # testcase4
    assert split_args('P\x9bL \\') == ['P\x9bL']
    # testcase5
    assert split_args("P\x9bL \\\n") == ['P\x9bL']
    # testcase6

# Generated at 2022-06-25 04:05:26.024185
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("") == {}
    assert parse_kv("a=b") == {u'a': u'b'}
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv(" a=b   c =    d ") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a b c=d") == {u'c': u'd', u'_raw_params': u"a b"}
    assert parse_kv("a=b=c") == {u'a': u'b=c'}

# Generated at 2022-06-25 04:05:40.228524
# Unit test for function split_args
def test_split_args():
    assert split_args('a=1 b=2') == ['a=1', 'b=2']
    assert split_args('a="1 2"') == ['a="1 2"']
    assert split_args('a="1 \n 2"') == ['a="1', '2"']
    assert split_args('a=\\"1 2\\"') == ['a="1 2"']
    assert split_args('a="1 \\\\n 2"') == ['a="1 \\\\n 2"']
    assert split_args('a="1\n2"') == ['a="1\n2"']
    assert split_args('a="1\\n2"') == ['a="1\\n2"']
    assert split_args('a=\"1\n2\"') == ['a="1\n2"']


# Generated at 2022-06-25 04:05:44.389279
# Unit test for function parse_kv
def test_parse_kv():
    # bytes_0 = b'P\x9bL'
    # bytes_1 = b'P\x9bL'
    # var_0 = parse_kv(bytes_0)
    # assert var_0 == bytes_1
    print("Test passed.")


# Generated at 2022-06-25 04:05:44.972133
# Unit test for function parse_kv
def test_parse_kv():
    assert test_case_0() is None



# Generated at 2022-06-25 04:05:53.789264
# Unit test for function split_args
def test_split_args():
    # Test Case 0
    bytes_0 = b'P\x9bL'
    bytes_1 = b'P\x9bL'
    if bytes_0 != bytes_1:
        print('Failed to assert bytes_0 == bytes_1')
        print ('Got bytes_0 =', bytes_0)
        print ('Got bytes_1 =', bytes_1)
        return 1

    # Test Case 1
    bytes_0 = b'P\x9bL'
    bytes_1 = b'P\x9bL'
    if bytes_0 != bytes_1:
        print('Failed to assert bytes_0 == bytes_1')
        print ('Got bytes_0 =', bytes_0)
        print ('Got bytes_1 =', bytes_1)
        return 1

    # Test Case 2
    bytes_

# Generated at 2022-06-25 04:06:01.234868
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'P\x9bL'
    var_0 = parse_kv(bytes_0)
    assert (var_0 == {})
    bytes_1 = b'\x07'
    var_1 = parse_kv(bytes_1)
    assert (var_1 == {})
    str_2 = '4'
    var_2 = parse_kv(str_2)
    assert (var_2 == {})
    str_3 = '*'
    var_3 = parse_kv(str_3)
    assert (var_3 == {})
    str_4 = '%'
    var_4 = parse_kv(str_4)
    assert (var_4 == {})
    bytes_5 = b'\x0f'
    var_5 = parse_

# Generated at 2022-06-25 04:06:02.911402
# Unit test for function parse_kv
def test_parse_kv():
    ret_1 = parse_kv(b'P\x9bL')
    assert ret_1 == {}


# Generated at 2022-06-25 04:06:09.893637
# Unit test for function split_args

# Generated at 2022-06-25 04:06:12.704438
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'P\x9bL'
    # Test function parse_kv
    print(parse_kv(bytes_0))



# Generated at 2022-06-25 04:06:17.030742
# Unit test for function split_args
def test_split_args():
    assert split_args(b'a=b c="foo bar"') == ['a=b', 'c="foo bar"']


# Generated at 2022-06-25 04:06:28.019031
# Unit test for function parse_kv
def test_parse_kv():
    print("\n**[Test units] parse_kv**")
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23

# Generated at 2022-06-25 04:06:38.413092
# Unit test for function split_args
def test_split_args():
    item = 'P\x9bL'
    params = split_args(item)
    assert params == ['P\x9bL']


# Generated at 2022-06-25 04:06:43.333824
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'P\x9bL'
    var_0 = split_args(bytes_0)
    var_1 = "P\x9bL"
    if var_0 == var_1:
        print("Success")
    else:
        print("Fail")


# Generated at 2022-06-25 04:06:48.352859
# Unit test for function split_args
def test_split_args():
  print(split_args('whoami'))
  print(split_args('whoami-b'))   
  print(split_args('whoami -b'))
  print(split_args('whoami -b --b'))
  print(split_args('whoami -b --b='))
  print(split_args('whoami -b --b=a'))
  print(split_args('whoami -b --b=ab'))
  print(split_args('whoami -b --b=ab --b=ab --b=ab'))
  print(split_args('whoami -b --b=ab --b=ab --b=ab --b='))
  print(split_args('whoami -b --b=ab --b=ab --b=ab --b=a'))

# Generated at 2022-06-25 04:06:54.835930
# Unit test for function split_args
def test_split_args():
    assert split_args('a="b c"') == ['a=b c']
    assert split_args('a=b\\ c') == ['a=b c']
    assert split_args('a=b" "c') == ['a=b" "c']
    assert split_args('a="b c') == ['a=b c']
    assert split_args('a="b c\\') == ['a=b c\\']
    assert split_args('a="b c" d="e f"') == ['a=b c', 'd=e f']
    assert split_args('a="b c" d="e f') == ['a=b c', 'd=e f']
    assert split_args('a=b c d=e f') == ['a=b', 'c', 'd=e', 'f']

# Generated at 2022-06-25 04:06:58.459078
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Generated at 2022-06-25 04:07:04.222383
# Unit test for function split_args
def test_split_args():
    # Split arguments number one
    arg_1 = '-a create -f /tmp/ansible-tmp-1423063151.97-144077188020681/setup.py'
    answer_1 = ['-a', 'create', '-f', '/tmp/ansible-tmp-1423063151.97-144077188020681/setup.py']

# Generated at 2022-06-25 04:07:05.012780
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 04:07:16.365248
# Unit test for function split_args
def test_split_args():
    # Test 1
    # Test for known input
    # args to be tested
    test_args = "'a=b c=\"foo bar\"'"
    test_cases = split_args(test_args)
    # expected output
    expected_output = u"a=b c=\"foo bar\""
    # check for equality
    assert(test_cases == expected_output)

    # Test 2
    # Test for known input
    # args to be tested
    test_args = "a=b c=\"foo bar\""
    test_cases = split_args(test_args)
    # expected output
    expected_output = [u"a=b", u"c=\"foo bar\""]
    # check for equality
    assert(test_cases == expected_output)

    # Test 3
    # Test for known input
    # args to be

# Generated at 2022-06-25 04:07:19.165797
# Unit test for function split_args
def test_split_args():
	print('[+] test_split_args')
	bytes_0 = b'P\x9bL'
	var_0 = split_args(bytes_0)


# Generated at 2022-06-25 04:07:28.735804
# Unit test for function parse_kv
def test_parse_kv():
    vargs = ['a=b','c=d','e=f','g','h','i=j','k=l','m','n','o=p','q=r','s','t','u=v','w=x','y','z']
    args = join_args(vargs)
    # The k,m,n,s,t,y,z args should be processed as free-form params
    # and stored in the '_raw_params' key of the returned dict
    expected_result = {'a': 'b', 'c': 'd', 'e': 'f', 'i': 'j', 'k': 'l', 'o': 'p', 'q': 'r', 'u': 'v', 'w': 'x', '_raw_params': 'g h m n s t y z'}
    actual_result = parse_k

# Generated at 2022-06-25 04:07:40.041646
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv(b'P\x9bL')
    assert(result is None)


# Generated at 2022-06-25 04:07:42.924747
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv({b'P\x9bL'})
    var_1 = {b'P\x9bL': b'P\x9bL'}
    assert var_0 == var_1


# Generated at 2022-06-25 04:07:50.919685
# Unit test for function split_args
def test_split_args():
    args = "a=b c='foo bar'"
    params = split_args(args)
    assert(params == ['a=b', "c='foo bar'"])


# def test_case_1():
#     bytes_0 = '\x01\x00\x81\x11\x01\x00\x81\x12\x01\x00\x81\x13\x01\x00\x81\x14\x01\x00\x81\x15\x01\x00\x81\x16\x01\x00\x81\x17\x01\x00\x81\x18\x01\x00\x81\x19\x01\x00\x81\x1a\x01\x00\x81\x1b\x01\x00

# Generated at 2022-06-25 04:08:01.202803
# Unit test for function split_args
def test_split_args():
    # Test 0
    # bytes
    bytes_0 = b'P\x9bL'

    # expected result
    expected_result = ['P\x9bL']

    # test the function
    result = split_args(bytes_0)

    assert(result == expected_result)

    # Test 1
    # bytes
    bytes_1 = b'\xf1'

    # expected result
    expected_result = ['\xf1']

    # test the function
    result = split_args(bytes_1)

    assert(result == expected_result)

    # Test 2
    # bytes
    bytes_2 = b'\xf1\x81'

    # expected result
    expected_result = ['\xf1\x81']

    # test the function
    result = split_args(bytes_2)


# Generated at 2022-06-25 04:08:10.910633
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x1a'
    bytes_1 = b'\x16\x12\x03\x1c\x1c'
    bytes_2 = b'\x14\x1d\x16\x1e'
    bytes_3 = b'\x1b\x13\x10\x14'
    bytes_4 = b'\x16\x12\x1c'
    bytes_5 = b'\x13\x1b\x0b\x03\x01'
    bytes_6 = b'\x15\x1c'

# Generated at 2022-06-25 04:08:20.829982
# Unit test for function split_args
def test_split_args():
    result = split_args(b'a=b c="foo bar"')
    assert result == ['a=b', 'c="foo bar"']

    result = split_args(b'a=b c="foo')
    assert result == ['a=b', 'c="foo']

    result = split_args(b'a=b c="foo bar')
    assert result == ['a=b', 'c="foo bar']

    result = split_args(b'a=b c="foo bar"')
    assert result == ['a=b', 'c="foo bar"']

    result = split_args(b"a=b c='foo bar'")
    assert result == ["a=b", "c='foo bar'"]

    result = split_args(b'a=b c="foo bar')

# Generated at 2022-06-25 04:08:26.111595
# Unit test for function parse_kv
def test_parse_kv():
    """
    A test case definition for parse_kv.
    """
    # Case 0
    bytes_0 = b'P\x9bL'
    var_0 = parse_kv(bytes_0)
    assert var_0 == {'_raw_params': u'P\u009bL'}



# Generated at 2022-06-25 04:08:36.081048
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(u'a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args(u'a=b c="foo bar\\') == ['a=b', 'c="foo bar\\']
    assert split_args(u'a=b c="foo bar\\"') == ['a=b', 'c="foo bar\\"']
    assert split_args(u'a=b c="foo') == ['a=b', 'c="foo']
    assert split_args(u'a=b c="foo bar\\" x=y') == ['a=b', 'c="foo bar\\"', 'x=y']

# Generated at 2022-06-25 04:08:47.026155
# Unit test for function split_args
def test_split_args():
    print('test_split_args')
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\'') == ['a=b', 'c="foo bar\'']
    assert split_args('a=b c="foo bar"\'') == ['a=b', 'c="foo bar"\'']
    assert split_args('a=b c="foo bar"\n') == ['a=b', 'c="foo bar"\n']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 04:08:50.386840
# Unit test for function split_args
def test_split_args():
    try:
        test_case_0()
        print('Success: %s' % 'test_case_0')
    except Exception as e:
        print('Failed: %s\n%s' % ('test_case_0',str(e)))

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:09:02.213903
# Unit test for function parse_kv
def test_parse_kv():
    # Test with first valid input

    # Test with second valid input

    pass


# Generated at 2022-06-25 04:09:03.927744
# Unit test for function parse_kv
def test_parse_kv():
    print("test case 0")
    test_case_0()



# Generated at 2022-06-25 04:09:05.747725
# Unit test for function parse_kv
def test_parse_kv():
    print('function: parse_kv(bytes_0) -> dict')
    test_case_0()


# Generated at 2022-06-25 04:09:07.060553
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'P\x9bL'
    var_0 = parse_kv(bytes_0)

# Generated at 2022-06-25 04:09:17.355583
# Unit test for function split_args
def test_split_args():
    positional_args = 'P\x9bL'
    opt_key_value = 'a=b c="foo bar"'
    raw_params = '-c "foo bar" --bat=baz "-c bar'
    multi_lines = '''
        P\x9bL
        a=b c="foo bar"
        -c "foo bar" --bat=baz "-c bar"
    '''
    quoted_block_token_0 = "{% foo %}"
    quoted_block_token_1 = "{{ foo }}{% foo %}"
    quoted_block_token_2 = "{{ foo }}{% foo }}{# foo #}{{ foo }}"


# Generated at 2022-06-25 04:09:20.351107
# Unit test for function split_args
def test_split_args():
    # Dummy function to show test case skeleton
    test_case_0()



# Generated at 2022-06-25 04:09:30.194719
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'P\x9bL'
    var_0 = split_args(bytes_0)
    assert var_0[0] == 'P\\x9bL'

    bytes_1 = b'\\u043a\\u0456\\u0440\\u0456\\u043b\\u0456\\u0437\\u0430\\u0446\\u0456\\u0457 \\u043d\\u0430\\u0432\\u0435\\u0441\\u043d\\u0430\\u0446\\u0456\\u0457'
    var_1 = split_args(bytes_1)

# Generated at 2022-06-25 04:09:37.039674
# Unit test for function split_args
def test_split_args():
    assert parse_kv("foo=bar") == {'foo': 'bar'}
    assert parse_kv("foo=bar baz=foos") == {'foo': 'bar', 'baz': 'foos'}
    assert parse_kv("foo=bar baz=foos=bazs") == {'foo': 'bar', 'baz': 'foos=bazs'}
    # If more than one key with the same name, takes the last value
    assert parse_kv("foo=bar baz=foos baz=bazs") == {'foo': 'bar', 'baz': 'bazs'}
    # Quotes in values
    assert parse_kv("foo=\"bar\"") == {'foo': '"bar"'}

# Generated at 2022-06-25 04:09:48.186819
# Unit test for function parse_kv
def test_parse_kv():

    # bytes tests
    bytes_0 = b'P\x9bL'
    var_0 = parse_kv(bytes_0)
    assert var_0 == {'_raw_params': 'P\\x9bL'}

    bytes_1 = b"\xc8\n\xcc\xac"
    var_1 = parse_kv(bytes_1)
    assert var_1 == {'_raw_params': '\\xc8\\n\\xcc\\xac'}

    bytes_2 = b"\x13\x05\x98\x85\xca\x9a\xc6\x11\x9c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

# Generated at 2022-06-25 04:09:49.905334
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'/bin/grep --help'
    var_0 = split_args(bytes_0)
    assert var_0 == ['/bin/grep', '--help']



# Generated at 2022-06-25 04:10:04.053540
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'myvar=myvalue myvar2=myvalue2'
    var_0 = split_args(bytes_0)
    bytes_1 = b'myvar=my value myvar2=my value2'
    var_1 = split_args(bytes_1)
    bytes_2 = b'myvar=my value myvar2=\'my value2\''
    var_2 = split_args(bytes_2)
    bytes_3 = b'myvar=my value myvar2="my value2"'
    var_3 = split_args(bytes_3)
    assert type(var_0) is list
    assert len(var_0) == 2
    assert type(var_1) is list
    assert len(var_1) == 2
    assert type(var_2) is list

# Generated at 2022-06-25 04:10:13.965781
# Unit test for function split_args
def test_split_args():
    string = '"1 2 3 4 5" 6 7 8 9 10'
    assert split_args(string) == ['1 2 3 4 5', '6', '7', '8', '9', '10']

    string = 'a=b c="foo bar" d="a=b {{ foo }}"'
    assert split_args(string) == ['a=b', 'c="foo bar"', 'd="a=b {{ foo }}"']

    string = 'a=b c={{ foo_bar }}\n'
    assert split_args(string) == ['a=b', 'c={{ foo_bar }}\n']

    string = "a=b c='foo bar' d='a=b {{ foo }}'"

# Generated at 2022-06-25 04:10:19.774083
# Unit test for function split_args
def test_split_args():
    args = """
    - debug: var=hostvars[inventory_hostname]
    - name: Set facts from internal task
      set_fact:
        my_foo: "my_bar"
      run_once: true
      delegate_to: localhost
    """

    params = split_args(args)
    for p in params:
        print(p)

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:10:22.389210
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'P\x9bL'
    var_0 = split_args(bytes_0)


if __name__ == "__main__":
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 04:10:33.248615
# Unit test for function split_args
def test_split_args():
    print("test_split_args")
    # Test 0
    bytes_0 = b'P\x9bL'
    var_0 = list(split_args(bytes_0))
    assert len(var_0) == 1
    # Test 1
    bytes_1 = b'P\x9bL'
    var_1 = list(split_args(bytes_1))
    assert len(var_1) == 1
    # Test 2
    bytes_2 = b'P\x9bL'
    var_2 = list(split_args(bytes_2))
    assert len(var_2) == 1
    # Test 3
    bytes_3 = b'P\x9bL'
    var_3 = list(split_args(bytes_3))
    assert len(var_3) == 1
   

# Generated at 2022-06-25 04:10:43.879194
# Unit test for function split_args
def test_split_args():

    assert split_args(b"foo") == ['foo']

    assert split_args(b"foo bar") == ['foo', 'bar']

    assert split_args(b"foo bar\nbiz\nboom") == ['foo', 'bar', 'biz', 'boom']

    assert split_args(b"foo=\"bar biz\" boom") == ["foo='bar biz'", 'boom']

    assert split_args(b"foo='bar biz' boom") == ["foo='bar biz'", 'boom']

    assert split_args(b"foo=\"bar 'biz'\" boom") == ["foo='bar 'biz''", 'boom']

    assert split_args(b"foo=\"bar 'biz'\" \\\nboom") == ["foo='bar 'biz''", 'boom']


# Generated at 2022-06-25 04:10:54.273680
# Unit test for function parse_kv
def test_parse_kv():
    # Test with valid values
    data_0 = b'/c \xc0\x9bi'
    var_0 = parse_kv(data_0)
    # Should be {'_raw_params': '/c \xc0\x9bi'}
    print(var_0)

    data_1 = b'\xc0\x9b=\xc0'
    var_1 = parse_kv(data_1)
    # Should be {'\xc0\x9b': '\xc0'}
    print(var_1)

    data_2 = b'\xc0\x9b=\xc0\x9b'
    var_2 = parse_kv(data_2)
    # Should be {'\xc0\x9b': '\xc0\x9b'}
   

# Generated at 2022-06-25 04:11:00.742841
# Unit test for function parse_kv
def test_parse_kv():
    print("\nUnittest: test_parse_kv")
    bytes_0 = b'P\x9bL'
    var_0 = parse_kv(bytes_0)
    try:
       assert var_0 == {}
       print("passed")
    except:
       print("failed")


# Generated at 2022-06-25 04:11:10.251174
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'''""'''
    result = split_args(bytes_0)
    assert result == ['''""''']
    bytes_0 = b'''p\x9bL\x9b'''
    result = split_args(bytes_0)
    assert result == ['''p\x9bL\x9b''']
    bytes_0 = b'''\x9b'''
    result = split_args(bytes_0)
    assert result == ['''\x9b''']
    bytes_0 = b'''t\x9b'''
    result = split_args(bytes_0)
    assert result == ['''t\x9b''']
    bytes_0 = b'''X\x9b'''
    result = split_args(bytes_0)