

# Generated at 2022-06-25 04:01:55.184944
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('key1=val1 key2=val2') == {"key1":"val1", "key2":"val2"}
    assert parse_kv('key1=val1 key2=val2 --test') == {"key1":"val1", "key2":"val2", "_raw_params":"--test"}
    assert parse_kv('key1=val1 key2=val2 --test --test2') == {"key1":"val1", "key2":"val2", "_raw_params":"--test --test2"}
    assert parse_kv('key1=val1 key2=val2 key3+key4=val3') == {"key1":"val1", "key2":"val2", "key3+key4":"val3"}


# Generated at 2022-06-25 04:02:08.338859
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b") == ['a=b']
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a='b'") == ['a=\'b\'']
    assert split_args("a=\"b\"") == ['a="b"']
    assert split_args("a='b\"'") == ['a=\'b"\'']
    assert split_args("a='b\"' c=d") == ['a=\'b"\'', 'c=d']
    assert split_args("a='b\" c=d'") == ['a=\'b" c=d\'']

# Generated at 2022-06-25 04:02:18.267920
# Unit test for function split_args
def test_split_args():
    args_1 = b"a=b c='foo bar' d='foo bar biz baz' e='foo'\\''bar'"
    args_2 = b"a=b c='foo bar'"
    args_3 = b"a='\\'foo bar'"
    args_4 = b"a='\\'foo bar biz baz'"
    args_5 = b"a='foo'\\''bar'"
    args_6 = b"a='foo'\\''bar' b=c"
    args_7 = b"a=\"foo\" b=c"
    args_8 = b"a=\"foo bar baz\" b=c"
    args_9 = b"a='foo bar baz'"
    args_10 = b"a=b c=d e=f"

# Generated at 2022-06-25 04:02:19.852463
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 04:02:25.964361
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'

    var_0 = parse_kv(bytes_0)
    assert var_0.get(b'\x8d\x9c9\xdb\xa8v\xd9\xce\x96') == b'%}'


# Generated at 2022-06-25 04:02:36.672939
# Unit test for function split_args
def test_split_args():
    var_0 = split_args('ls')
    print(var_0)

    var_0 = split_args('-c ls')
    print(var_0)

    var_0 = split_args('ls -c')
    print(var_0)

    var_0 = split_args('ls "\' -c"')
    print(var_0)

    var_0 = split_args('ls "\' -c" \' -c \\\'" -c"')
    print(var_0)

    var_0 = split_args('ls "-c"')
    print(var_0)

    var_0 = split_args('ls "-c \\"" -c \\\\\'"\'"')
    print(var_0)


# Generated at 2022-06-25 04:02:42.195552
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args("a=b c=foo 'bar") == ['a=b', "c=foo 'bar"]
    assert split_args("a=b c=foo 'bar'") == ['a=b', "c=foo 'bar'"]
    assert split_args("a=b c=foo 'bar\\''") == ['a=b', "c=foo 'bar\\''"]
    assert split_args("c=foo 'bar\\''") == ['c=foo "bar\\\'"']

# Generated at 2022-06-25 04:02:49.639365
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b") == {u'a': u'b'}
    assert parse_kv("a=b a=b") == {u'a': u'b a=b'}
    assert parse_kv("a=b 'a=b'") == {u'a': u'b', u'_raw_params': u"'a=b'"}
    assert parse_kv("a=b 'a=b'", check_raw=True) == {u'a': u'b', u'_raw_params': u"'a=b'"}
    assert parse_kv("a=b 'a=b'", False) == {u'a': u'b', u'_raw_params': u"'a=b'"}

# Generated at 2022-06-25 04:02:53.820448
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()


# Generated at 2022-06-25 04:03:03.952772
# Unit test for function split_args
def test_split_args():
    try:
        result_0 = split_args(b'"')
        assert result_0 == [b'"']
    except Exception as e:
        print(e)
    try:
        result_1 = split_args(b"{'a': 'b'}")
        assert result_1 == [b"{'a': 'b'}"]
    except Exception as e:
        print(e)
    try:
        result_2 = split_args(b'RC1.5')
        assert result_2 == [b'RC1.5']
    except Exception as e:
        print(e)
    try:
        result_3 = split_args(b'$')
        assert result_3 == [b'$']
    except Exception as e:
        print(e)

# Generated at 2022-06-25 04:03:24.127151
# Unit test for function split_args
def test_split_args():
    assert split_args(b'o=/tmp/ansible-file-content-Content-Type-of-this-file-is-application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream') == ['o=/tmp/ansible-file-content-Content-Type-of-this-file-is-application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream/application/octet-stream']

# Generated at 2022-06-25 04:03:28.969062
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

# Run test
if __name__ == "__main__":
    test_parse_kv()

# Generated at 2022-06-25 04:03:31.691369
# Unit test for function split_args
def test_split_args():
    # Test using examples from the documentation of the split_args function.
    test_case_0()


# Generated at 2022-06-25 04:03:33.485606
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']



# Generated at 2022-06-25 04:03:41.453395
# Unit test for function split_args
def test_split_args():
    # Test 1: Zero argument list
    result = split_args('')
    print('Result:',result)
    assert result == [], "Failed argument processing test"

    # Test 2: Multiple arguments in quotes
    args = '-m ping -a "hello world"'
    result = split_args(args)
    print('Result:', result)
    assert result == ['-m', 'ping', '-a', 'hello world'], "Failed argument processing test"

    # Test 3: Multiple arguments in quotes with jinja2
    args = '-m ping -a "hello {{ world }}"'
    result = split_args(args)
    print('Result:', result)
    assert result == ['-m', 'ping', '-a', 'hello {{ world }}'], "Failed argument processing test"

    # Test 4: Multiple

# Generated at 2022-06-25 04:03:54.354423
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    var_0 = split_args(bytes_0)
    bytes_1 = '%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    var_1 = split_args(bytes_1)
    bytes_2 = '{"update_cache": true, "cache_valid_time": 86400}'
    var_2 = split_args(bytes_2)
    bytes_3 = b'\xd5\x7f\xd4\xdd\x8e\x05\x11\x92\x97\xf2\x88\x10'
    var_3 = split_args(bytes_3)
   

# Generated at 2022-06-25 04:03:59.547248
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'\xac\xf2\xdf\xdc\x9e\x9a\xb5}\x8f\x82\xc5\x11\xa6n\x1a\xf9\x88\x0c\x8b\x1e\xa3\xc3\xef'
    result_0 = split_args(bytes_0)
    print(result_0)


# Generated at 2022-06-25 04:04:00.536294
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()



# Generated at 2022-06-25 04:04:09.267694
# Unit test for function split_args
def test_split_args():
    print("STARTING SPLIT ARGS TEST")
    # Test case 1: Input: a=b c="foo bar"
    # Output: ['a=b', 'c="foo bar"']
    bytes_1 = b'a=b c="foo bar"'
    split_args(bytes_1)
    # TODO: Assert

    # Test case 2: Input: a=b c="foo bar"
    # Output: ['a=b', 'c="foo bar"']
    bytes_2 = b"a=b c='foo bar'"
    split_args(bytes_2)
    # TODO: Assert

    # Test case 3: Input: a=b c="foo bar"
    # Output: ['a=b', 'c="foo bar"']
    bytes_3 = b"a=b c=\"foo bar\""

# Generated at 2022-06-25 04:04:18.489321
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    var_0 = parse_kv(bytes_0)
    # Check that we get a string value from this function.
    assert_type_str(var_0)
    # Check that the string contains a '\x' escape sequence.
    if not re.match(r'\\x[a-fA-F0-9]{2}', var_0):
        raise AssertionError('failed to find \\x escape sequence')


# Generated at 2022-06-25 04:04:29.666827
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()


# Generated at 2022-06-25 04:04:32.990567
# Unit test for function split_args
def test_split_args():
    # Test case 0
    bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    result_0 = split_args(bytes_0)


# Generated at 2022-06-25 04:04:38.931202
# Unit test for function parse_kv
def test_parse_kv():
    try:
        bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
        var_0 = parse_kv(bytes_0)
    except:
        error_count += 1
        return error_count


if __name__ == '__main__':
    errors = 0
    errors += test_parse_kv()
    if errors == 0:
        print('Success! Tests passed.')
    else:
        print('Errors! Tests failed!')
    sys.exit(errors)

# Generated at 2022-06-25 04:04:41.462442
# Unit test for function split_args
def test_split_args():
    pass

# Represents an Ansible Error

# Generated at 2022-06-25 04:04:46.585591
# Unit test for function split_args
def test_split_args():
    arg = "{{ '{0}'"
    join_args(split_args(arg))



# Generated at 2022-06-25 04:04:51.695838
# Unit test for function parse_kv
def test_parse_kv():
    print('Test: parse_kv')

    # Test case 0
    print('Test 0')
    bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    var_0 = parse_kv(bytes_0)
    #assert(var_0 == )


# Generated at 2022-06-25 04:05:03.810926
# Unit test for function split_args
def test_split_args():
    # 'a=b', 'c="foo bar"'
    bytes_0 = b'a=b c="foo bar"'
    var_0 = split_args(bytes_0)
    assert var_0 == [u'a=b', u'c="foo bar"']
    # 'a=b', 'c="foo bar"'
    bytes_1 = b'a=b\n c="foo bar"'
    var_1 = split_args(bytes_1)
    assert var_1 == [u'a=b', u'c="foo bar"']
    # 'a=b', 'c="foo bar"'
    bytes_2 = b'a=b \n c="foo bar"'
    var_2 = split_args(bytes_2)

# Generated at 2022-06-25 04:05:07.926601
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'\xe7\x9f\x9f\x84\xa5', b'\xe7\x9f\x9f\x84\xa5'
    params_1 = split_args(bytes_0[0])
    assert params_1 == bytes_0[1]


# Generated at 2022-06-25 04:05:13.797119
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    var_0 = parse_kv(bytes_0)
    bytes_1 = b'\x1c\xb0\xbb\x88\x87\x96\x01\x1b\xbc\xc3\x81\xa1\xda\xb8@\xe2\x9c\x04'
    var_1 = parse_kv(bytes_1)

    print(var_0)
    print(var_1)


# Generated at 2022-06-25 04:05:25.970904
# Unit test for function split_args
def test_split_args():
    args = "KEY=VALUE"
    expected_response_0 = ['KEY=VALUE']
    assert (split_args(args) == expected_response_0)

    args = "KEY=VALUE VALUE_2=VALUE2"
    expected_response_1 = ['KEY=VALUE', 'VALUE_2=VALUE2']
    assert (split_args(args) == expected_response_1)

    args = "KEY=VALUE VALUE_2='VALUE2'"
    expected_response_2 = ['KEY=VALUE', 'VALUE_2=\'VALUE2\'']
    assert (split_args(args) == expected_response_2)

    args = "KEY=VALUE VALUE_2=\"VALUE2\""
    expected_response_3 = ['KEY=VALUE', 'VALUE_2="VALUE2"']

# Generated at 2022-06-25 04:05:39.456664
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    var_0 = parse_kv(bytes_0)
    assert var_0 == {}

# Generated at 2022-06-25 04:05:49.939032
# Unit test for function split_args
def test_split_args():
    result_0 = split_args(b'\xe2\x81\x87xb\x88\x9e\x9d\xfeJ\xd1\x80\x08\xf8\xad3')
    assert result_0 == []
    result_1 = split_args(b'\x86\xad\x93\x81\xda\x9c\x9d\xa3\x8b\x80\xfc\x87E')
    assert result_1 == []
    result_2 = split_args(b'\xae\x83\x98\x87\xd0\xa2\x9a\x9e\xd1\x7f\xf0')
    assert result_2 == []

# Generated at 2022-06-25 04:05:57.421010
# Unit test for function split_args
def test_split_args():
    # Input for test case 0
    bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    var_0 = split_args(bytes_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 04:06:07.961631
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing parse_kv')

    # Test case 0
    print('Test case 0')
    print('Test parsing shell-style arguments')
    bytes_0 = b'foo=bar key1="Bob\'s House" "key2"="Bob\'s House"'
    var_0 = parse_kv(bytes_0)
    assert var_0 == {u'foo': 'bar', u'key1': u"Bob's House", u'key2': u"Bob's House"}

    # Test case 1
    print('Test case 1')
    print('Test parsing quoted string with `=`')
    bytes_0 = b'foo="bar=bar" key1="Bob\'s House" "key2"="Bob\'s House"'
    var_0 = parse_kv(bytes_0)

# Generated at 2022-06-25 04:06:18.305679
# Unit test for function parse_kv
def test_parse_kv():
    assert '_raw_params' in parse_kv(b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'), "Failed to parse '%}\\x8d\\x9c9\\xdb\\xa8v\\xd9\\xce\\x96'"
    assert '_raw_params' in parse_kv(b'%}\\x8d\\x9c9\\xdb\\xa8v\\xd9\\xce\\x96'), "Failed to parse '%}\\x8d\\x9c9\\xdb\\xa8v\\xd9\\xce\\x96'"

# Generated at 2022-06-25 04:06:27.561193
# Unit test for function split_args
def test_split_args():
    res = split_args('a=b c="foo bar"')
    assert res == ['a=b', 'c="foo bar"']

    res = split_args('{{"foo bar}}')
    assert res == ['{{', 'foo bar}}']

    res = split_args('{{ "foo bar" }}')
    assert res == ['{{', '"foo bar"', '}}']

    res = split_args('{{ foo "bar baz" }}')
    assert res == ['{{', 'foo', '"bar baz"', '}}']

    res = split_args('{{"foo bar"}}')
    assert res == ['{{', '"foo bar"', '}}']

    res = split_args('{{"foo bar"}} {{ "baz foo" }}')

# Generated at 2022-06-25 04:06:34.897878
# Unit test for function split_args

# Generated at 2022-06-25 04:06:39.354754
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    # assert var_0 == 
    test_case_0()


# Generated at 2022-06-25 04:06:47.117156
# Unit test for function split_args
def test_split_args():
    arg = "{{foo}} 'bar'"
    assert split_args(arg) == ['{{foo}}', "'bar'"]
    assert join_args(['{{foo}}', "'bar'"]) == arg
    arg = '{{foo}} "bar"'
    assert split_args(arg) == ['{{foo}}', '"bar"']
    assert join_args(['{{foo}}', '"bar"']) == arg
    arg = "{{foo}} 'bar'\n{{bar}} 'foo'"
    split_args(arg) == ['{{foo}}', "'bar'", '{{bar}}', "'foo'"]
    assert join_args( ['{{foo}}', "'bar'", '{{bar}}', "'foo'"]) == arg
    arg = '{{foo}} \\ {{bar}}'

# Generated at 2022-06-25 04:06:55.731414
# Unit test for function split_args
def test_split_args():
    assert split_args(b"a b c") == ['a', 'b', 'c']
    assert split_args(b"a=b c=d") == ['a=b', 'c=d']
    assert split_args(b"a b='c d'") == ['a', 'b=\'c d\'']
    assert split_args(b"a b=\"c d\"") == ['a', 'b="c d"']
    assert split_args(b"a b=\"c \\\"d\\\"\"") == ['a', 'b="c \\"d\\""']
    assert split_args(b"a b=\"c 'd'\"") == ['a', 'b="c \'d\'"']

# Generated at 2022-06-25 04:07:12.618556
# Unit test for function parse_kv
def test_parse_kv():
    b_in_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    var_0 = parse_kv(b_in_0)


# Main function

# Generated at 2022-06-25 04:07:15.939962
# Unit test for function split_args
def test_split_args():
    arg_str = "{% if nb_test_0() %}{{ nb_test_0() }}{% endif %}"
    vargs = split_args(arg_str)
    assert len(vargs) == 3


# Generated at 2022-06-25 04:07:20.650387
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    assert parse_kv(bytes_0)[u'_raw_params'] == u'%}\\225\\234\\231\\215\\250v\\217\\206\\226'


# Generated at 2022-06-25 04:07:26.449814
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    var_0 = split_args(bytes_0)


# Generated at 2022-06-25 04:07:32.604713
# Unit test for function split_args
def test_split_args():
    # Both strings should be the same
    if not "{{ foo }}" in join_args(split_args("{{ foo }}")):
        print("Test failed")
        exit(0)

    string_0 = "{{ foo }} bar"
    if not "{{ foo }} bar" in join_args(split_args(string_0)):
        print("Test failed")
        exit(0)

    string_1 = "{{ foo }} \n \n \n {{ bar }}"
    if not "{{ foo }} \n \n \n {{ bar }}" in join_args(split_args(string_1)):
        print("Test failed")
        exit(0)

    string_2 = "{{ foo }} \n \n \n {{ bar }} "

# Generated at 2022-06-25 04:07:36.002791
# Unit test for function split_args
def test_split_args():
    try:
        test_case_0()
    except:
        print("Exception in test case 0")



# Generated at 2022-06-25 04:07:46.103936
# Unit test for function split_args
def test_split_args():
    # check that it handles escaped characters correctly
    assert split_args(r'\;') == [r'\;']
    assert split_args(r'\\;') == [r'\\;']
    assert split_args(r'\\\;') == [r'\\\;']
    assert split_args(r'\\\\\;') == [r'\\\\\;']
    # backslash followed by a newline should be ignored
    assert split_args(r'\\\n') == [r'\\']
    # backslash followed by a newline followed by an escaped newline
    # should be preserved
    assert split_args(r'\\\n\\\n') == [r'\\\n\\']
    # backslash followed by a newline followed by a non-escaped newline
    # should be replaced by a new

# Generated at 2022-06-25 04:08:00.631982
# Unit test for function split_args

# Generated at 2022-06-25 04:08:06.221784
# Unit test for function parse_kv
def test_parse_kv():
    print("[+] test_parse_kv")
    test_case_0()
    print("[-] test_parse_kv")

# -----------------------------------------------------------------------

# Generated at 2022-06-25 04:08:12.241515
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 04:08:32.612908
# Unit test for function parse_kv
def test_parse_kv():
    assert func_0 == 'test_value_0'
    assert func_1 == 'test_value_1'
    assert func_2 == 'test_value_2'
    assert func_3 == 'test_value_2'


# Generated at 2022-06-25 04:08:38.734803
# Unit test for function split_args
def test_split_args():
    print("Running test case 1")
    bytes_0 = b'cmd\n  test\n  echo "hello world"'
    params = split_args(bytes_0)
    print("Got params: %s" % params)
    assert len(params) == 6
    assert params[0] == 'cmd'
    assert params[1] == 'test'
    assert params[2] == 'echo'
    assert params[3] == '"hello'
    assert params[4] == 'world"'
    assert params[5] == ''
    print("Test case 1 passed")

    print("Running test case 2")
    # The value of args here is the contents of file sanity.txt

# Generated at 2022-06-25 04:08:46.416808
# Unit test for function split_args
def test_split_args():
    import random
    for _ in range(1):
        bytes_0 = b'\xe0\x1f\xc1\x8d\xf2Q\xf9\x0c\x12s\x1b\x00\x94\xf3\xaf\xa9\x9b\x9e\xcf\xdb\xc1\xd7\xeb\xba\t\xf1*\xbb\x9c\x84'
        var_0 = split_args(bytes_0)



# Generated at 2022-06-25 04:08:53.528820
# Unit test for function split_args

# Generated at 2022-06-25 04:09:04.787321
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv(b'foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv(' foo = bar ') == {'foo': 'bar'}
    assert parse_kv('foo = bar') == {'foo': 'bar'}
    assert parse_kv(' foo= bar') == {'foo': 'bar'}
    assert parse_kv('foo =bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar ') == {'foo': 'bar'}
    assert parse_kv('foo= bar') == {'foo': 'bar'}

# Generated at 2022-06-25 04:09:08.322516
# Unit test for function parse_kv
def test_parse_kv():
    with open("fixtures/test_parse_kv.txt") as infile:
        for line in infile:
            line = line.strip()
            parts = line.split(" => ")
            if len(parts) == 2:
                input_string, output_string = parts
                test_parse_kv_test(input_string, output_string)



# Generated at 2022-06-25 04:09:14.411053
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'a=b c="d e" f="g=h" i=j'
    var_0 = parse_kv(bytes_0)

    assert(var_0 == {'a':'b', 'c':'d e', 'f':'g=h', 'i':'j'})



# Generated at 2022-06-25 04:09:26.444957
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) is not None
    assert parse_kv(None) == {}
    assert parse_kv("") is not None
    assert parse_kv("") == {}
    assert parse_kv("foo=bar") is not None
    assert parse_kv("foo=bar") == {u'foo': u'bar'}
    assert parse_kv("foo=bar baz=frotz") is not None
    assert parse_kv("foo=bar baz=frotz") == {u'baz': u'frotz', u'foo': u'bar'}
    assert parse_kv("foo=bar baz=frotz", True) is not None

# Generated at 2022-06-25 04:09:34.632637
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x10\x7f'
    bytes_1 = b'\xdd\x97\x0c\x12\x14\x9b\x0b'
    var_0 = parse_kv(bytes_0)
    var_1 = parse_kv(bytes_1)

    # AssertionError: assert var_1 == var_0
    # assert var_1 != var_0


# Generated at 2022-06-25 04:09:44.171835
# Unit test for function split_args
def test_split_args():

    bytes_0 = b'\x883\x94\x94\xeb\x91\x7f\x95f\x97\x8c\xcc\xef\x1b\xbc\x8cJ\xbc\xe4\xab\xcc\x9e\xdb\x1e\x08?\xbf\xc0\x94\xc9\x91\x9c\x9er.\xa2\xed'
    var_0 = split_args(bytes_0)

# Generated at 2022-06-25 04:09:55.900160
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()



# Generated at 2022-06-25 04:10:02.112484
# Unit test for function split_args
def test_split_args():
    # Test 0: Test variable-length argument parsing
    input_0=b"a=b c='foo bar'\\\n    d={{ foo }}\\\n    e={{ 'foo' }}\\\n    f={{ 'foo bar' }}\\\n"
    expected_0=['a=b', 'c="foo bar"', 'd={{ foo }}', 'e={{ \'foo\' }}', 'f={{ \'foo bar\' }}']
    actual_0 = split_args(input_0)
    if actual_0 != expected_0:
        print("Expected: ", expected_0)
        print("Actual: ", actual_0)
    assert actual_0 == expected_0

    # Test 1: Test variable-length argument parsing with unbalanced quotes

# Generated at 2022-06-25 04:10:12.521967
# Unit test for function parse_kv

# Generated at 2022-06-25 04:10:18.500905
# Unit test for function parse_kv
def test_parse_kv():
    # First test case
    # Input arguments:
    #   args = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    #   check_raw=False
    bytes_0 = b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'
    var_0 = parse_kv(bytes_0)
    assert var_0 == {}


# Generated at 2022-06-25 04:10:29.164842
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing for parse_kv")

    var_0 = parse_kv(b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96')
    assert var_0 == {'_raw_params': b'%}\\x8d\\x9c9\\xdb\\xa8v\\xd9\\xce\\x96'}

    var_1 = parse_kv(b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96', True)
    assert var_1 == {'_raw_params': b'%}\\x8d\\x9c9\\xdb\\xa8v\\xd9\\xce\\x96'}


# Generated at 2022-06-25 04:10:39.223629
# Unit test for function split_args
def test_split_args():
    # Assertions
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c={{ foo }}') == ['a=b', 'c={{ foo }}']
    assert split_args('a=b c={{ foo }} d="{{ bar }}"') == ['a=b', 'c={{ foo }}', 'd="{{ bar }}"']
    assert split_args('a=b c={{ foo }} d="{{ bar }}" e=f') == ['a=b', 'c={{ foo }}', 'd="{{ bar }}"', 'e=f']
    assert split_args('a=b c={{ foo }}\nd={{ bar }}') == ['a=b', 'c={{ foo }}', 'd={{ bar }}']

# Generated at 2022-06-25 04:10:48.462624
# Unit test for function split_args
def test_split_args():
    test_string = "a=b c='foo' d='{{ foo }}' e='{% if foo %}{{ foo }}{% endif %}'"
    test_args = split_args(test_string)
    assert len(test_args) == 5, "split_args failed to split 5 parameters"
    assert test_args[0] == 'a=b', "split_args failed to split 1st argument"
    assert test_args[1] == "c='foo'", "split_args failed to split 2nd argument"
    assert test_args[2] == "d='{{ foo }}'", "split_args failed to split 3rd argument"
    assert test_args[3] == "e='{% if foo %}{{ foo }}{% endif %}'", "split_args failed to split 4th argument"

# Generated at 2022-06-25 04:10:50.753730
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv(b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96')


# Generated at 2022-06-25 04:10:59.203097
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(b'%}\x8d\x9c9\xdb\xa8v\xd9\xce\x96') == {}
    assert parse_kv(b"a='b c' d=e") == {b'd': b'e', b'a': b"b c"}
    assert parse_kv(b'a=b c d=e') == {b'd': b'e', b'a': b'b c'}


# Generated at 2022-06-25 04:11:10.153695
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv(bytes([0x7d, 0x8d, 0x9c, 0x39, 0xdb, 0xa8, 0x76, 0xd9, 0xce, 0x96]))
    assert var_0 == {u'_raw_params': b'}\x8d\x9c9\xdb\xa8v\xd9\xce\x96'}
    var_1 = parse_kv(bytes([0x7d, 0x8d, 0x9c, 0x39, 0xdb, 0xa8, 0x76, 0xd9, 0xce, 0x96]), True)