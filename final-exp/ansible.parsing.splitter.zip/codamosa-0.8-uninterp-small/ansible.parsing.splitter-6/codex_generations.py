

# Generated at 2022-06-25 04:02:12.840383
# Unit test for function split_args
def test_split_args():
    str_0 = '3w!-2VR:LhboB.<1wj.'
    var_0 = split_args(str_0)
    assert var_0 == ['3w!-2VR:LhboB.<1wj.']
    str_0 = 'AiN~-*@VL}y5rX0&0t`5'
    var_0 = split_args(str_0)
    assert var_0 == ['AiN~-*@VL}y5rX0&0t`5']
    str_0 = 'gOFyE$q3X~F6U|[!U+6F'
    var_0 = split_args(str_0)
    assert var_0 == ['gOFyE$q3X~F6U|[!U+6F']

# Generated at 2022-06-25 04:02:17.881600
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '3w!-2VR:LhboB.<1wj.'
    var_0 = split_args(str_0)
    var_1 = parse_kv(var_0)


# Generated at 2022-06-25 04:02:20.714957
# Unit test for function split_args
def test_split_args():
    try:
        print('test_case_0...')
        test_case_0()
        print('Success')
    except:
        print('Failure')

# Function: main

# Generated at 2022-06-25 04:02:29.924031
# Unit test for function parse_kv

# Generated at 2022-06-25 04:02:35.610982
# Unit test for function parse_kv
def test_parse_kv():

    # First make sure our helper decode_escapes() works as expected
    assert _decode_escapes('foo bar') == 'foo bar'
    assert _decode_escapes('foo\\ bar') == 'foo bar'
    assert _decode_escapes('foo\\tbar') == 'foo\tbar'
    assert _decode_escapes('foo\\nbar') == 'foo\nbar'
    assert _decode_escapes('foo\\"bar') == 'foo"bar'
    assert _decode_escapes('foo\\\'bar') == 'foo\'bar'
    assert _decode_escapes('foo\\\\bar') == 'foo\\bar'
    assert _decode_escapes('foo\\u0020bar') == 'foo bar'

# Generated at 2022-06-25 04:02:44.219069
# Unit test for function split_args
def test_split_args():
    #print('Test1: test for split_args')
    test_cases = {}
    test_cases[':'] = ['']
    test_cases['::'] = ['']
    test_cases[':::'] = ['']
    test_cases[':a'] = [':a']
    test_cases['a:'] = ['a:']
    test_cases[':a:'] = [':a:']
    test_cases['a::'] = ['a::']
    test_cases['a::b'] = ['a::b']
    test_cases['a:b:c'] = ['a:b:c']
    test_cases['a:b:c:d'] = ['a:b:c:d']
    test_cases['a::b::c'] = ['a::b::c']
    test_

# Generated at 2022-06-25 04:02:45.862166
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Test case for function split_args

# Generated at 2022-06-25 04:02:52.555914
# Unit test for function split_args
def test_split_args():
    assert split_args('3w!-2VR:LhboB.<1wj.') == ['3w!-2VR:LhboB.<1wj.']
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b c=d e=') == ['a=b', 'c=d', 'e=']
    assert split_args('a=b c=d e="f g"') == ['a=b', 'c=d', 'e="f g"']
    assert split_args('a=b c=d e="f g" h="i') == ['a=b', 'c=d', 'e="f g"', 'h="i']
   

# Generated at 2022-06-25 04:02:54.324351
# Unit test for function split_args
def test_split_args():
    print("[+] Testing 'split_args' function")
    test_case_0()
    print("[+] Done ... successfully")

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:02:58.389882
# Unit test for function split_args
def test_split_args():
    # str_0
    # print('str_0: testing split_args')
    test_case_0()



# Generated at 2022-06-25 04:03:24.668970
# Unit test for function split_args
def test_split_args():
    str_0 = "a=b c=\"foo bar\""
    var_0 = split_args(str_0)
    print(var_0)


# Generated at 2022-06-25 04:03:29.410972
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '3w!-2VR:LhboB.<1wj.'
    var_0 = parse_kv(str_0)


# Generated at 2022-06-25 04:03:38.509784
# Unit test for function parse_kv
def test_parse_kv():
    # Unit test for function parse_kv
    str_0 = '3w!-2VR:LhboB.<1wj.'
    var_0 = split_args(str_0)
    options = {}
    if str_0 is not None:
        try:
            vargs = var_0
        except IndexError as e:
            raise AnsibleParserError("Unable to parse argument string", orig_exc=e)
        except ValueError as ve:
            if 'no closing quotation' in str(ve).lower():
                raise AnsibleParserError("error parsing argument string, try quoting the entire line.", orig_exc=ve)
            else:
                raise

        raw_params = []
        for orig_x in vargs:
            x = _decode_escapes(orig_x)

# Generated at 2022-06-25 04:03:44.850458
# Unit test for function parse_kv
def test_parse_kv():
    with raises(AnsibleParserError):
        parse_kv("foo='this is a test")

    with raises(AnsibleParserError):
        parse_kv("foo2=this' is a test")

    with raises(AnsibleParserError):
        parse_kv("foo3=this is a test'")

    with raises(AnsibleParserError):
        parse_kv("foo4=this is a test'\"")

    with raises(AnsibleParserError):
        # test removing the special case for shell/command module options
        parse_kv("creates=test")

    assert parse_kv("foo=bar") == dict(foo='bar')

    assert parse_kv("foo=bar,baz=bas") == dict(foo='bar', baz='bas')


# Generated at 2022-06-25 04:03:55.326598
# Unit test for function split_args

# Generated at 2022-06-25 04:04:01.312730
# Unit test for function parse_kv
def test_parse_kv():
    # Testing with normal input
    str_0 = '-C/etc/ansible/hosts'
    str_1 = u'creates=/dev/null'
    test_case_0(str_0, str_1)

    # Testing with normal input
    str_0 = '-C/etc/ansible/hosts'
    str_1 = u'creates=/dev/null'
    test_case_0(str_0, str_1)


# Generated at 2022-06-25 04:04:10.244638
# Unit test for function split_args
def test_split_args():
    print('Testing function split_args')
    assert (split_args('foo') == ['foo'])
    assert (split_args('"foo bar"') == ['foo bar'])
    assert (split_args('foo bar') == ['foo', 'bar'])
    assert (split_args('foo "bar"') == ['foo', 'bar'])
    assert (split_args('foo bar \\ baz') == ['foo', 'bar', '\\', 'baz'])
    assert (split_args('foo "bar \\ baz"') == ['foo', 'bar \\ baz'])
    assert (split_args('foo "bar baz"') == ['foo', 'bar baz'])
    assert (split_args('foo "bar" baz') == ['foo', 'bar', 'baz'])

# Generated at 2022-06-25 04:04:13.780757
# Unit test for function split_args
def test_split_args():
    print('Testing split_args on str_0')
    test_case_0()

# Boilerplate to run test functions in a "main"
if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:04:26.343216
# Unit test for function split_args
def test_split_args():
    str_0 = '3w!-2VR:LhboB.<1wj.'
    str_1 = '\'3w!-2VR:LhboB.<1wj.\''
    str_2 = '\'3w!-2VR:LhboB.<1wj.'
    str_3 = '3w!-2VR:LhboB.<1wj.\''

# Generated at 2022-06-25 04:04:37.758815
# Unit test for function parse_kv
def test_parse_kv():
    def test_case_0():
        str_0 = '3w!-2VR:LhboB.<1wj.'
        str_1 = '-1wj.'
        var_0 = parse_kv(str_0)
        assert var_0 == {
            u'3w!-2VR:LhboB.<': u'',
            u'_raw_params': str_1
        }

    def test_case_1():
        str_2 = 'chdir=. lk=jhg 5222=2342.'
        var_1 = parse_kv(str_2)

# Generated at 2022-06-25 04:04:54.646210
# Unit test for function parse_kv
def test_parse_kv():
    # TEST CASE: test
    str_0 = 'N>FZL[-r|VTb<P?0=g|aC'
    res_0 = parse_kv(str_0)

    # TEST CASE: test_2
    str_1 = '%Qsb6+nM6g!qd*v]'
    res_1 = parse_kv(str_1)

    # TEST CASE: test_3
    str_2 = 'h'
    res_2 = parse_kv(str_2)

    # TEST CASE: test_4
    str_3 = 'o!*!0YE0R;-WN:'
    res_3 = parse_kv(str_3)

    # TEST CASE: test_5
    str_4 = '!q3y^'

# Generated at 2022-06-25 04:04:57.129656
# Unit test for function split_args
def test_split_args():
    # Test Case 0
    str_0 = '3w!-2VR:LhboB.<1wj.'
    var_0 = split_args(str_0)

if __name__ == "__main__":
    #test_split_args()
    test_case_0()

# Generated at 2022-06-25 04:04:59.044139
# Unit test for function parse_kv
def test_parse_kv():
    # Test case for parse_kv when kv_str is a string
    # Test case for parse_kv when kv_str is not a string
    pass


# Generated at 2022-06-25 04:05:06.160938
# Unit test for function split_args
def test_split_args():
    # --- testing case 0 ---
    str_0 = '3w!-2VR:LhboB.<1wj.'
    var_0 = split_args(str_0)
    assert var_0 == ['3w!-2VR:LhboB.<1wj.'], "failure test case 0"
    # --- testing case 1 ---
    str_0 = '--extra-vars "abc=def" --private-key=/root/a.pem'
    var_0 = split_args(str_0)
    assert var_0 == ['--extra-vars', '"abc=def"', '--private-key=/root/a.pem'], "failure test case 1"
    # --- testing case 2 ---
    str_0 = '{{ python -m json.tool }}'

# Generated at 2022-06-25 04:05:14.083291
# Unit test for function split_args
def test_split_args():

    # This example is taken from an ansible module source code.
    # The test case is slightly modified, but should produce the same result.
    str_test0 = '3w!-2VR:LhboB.<1wj.'
    var_test0 = split_args(str_test0)

    # This example is taken from an ansible module source code.
    # The test case is slightly modified, but should produce the same result.
    str_test1 = '3w!-2VR:LhboB.<1wj.'
    var_test1 = split_args(str_test1)

    # This example is taken from an ansible module source code.
    # The test case is slightly modified, but should produce the same result.
    str_test2 = '3w!-2VR:LhboB.<1wj.'

# Generated at 2022-06-25 04:05:16.838145
# Unit test for function split_args
def test_split_args():
    str_0 = '3w!-2VR:LhboB.<1wj.'
    var_0 = split_args(str_0)
    if str_0 == join_args(var_0):
        print("split_args succeed")
    else:
        print("split_args failed")


# Generated at 2022-06-25 04:05:27.290676
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'foo="bar"'
    ret_0 = parse_kv(str_0)
    assert 'bar' == ret_0['foo'], 'Expected return value of parse_kv to be bar, got %s' % ret_0['foo']

    str_1 = 'foo="bar"'
    ret_1 = parse_kv(str_1, True)
    assert 'bar' == ret_1['foo'], 'Expected return value of parse_kv to be bar, got %s' % ret_1['foo']

    str_2 = 'foo="bar"'
    ret_2 = parse_kv(str_2, False)
    assert 'bar' == ret_2['foo'], 'Expected return value of parse_kv to be bar, got %s' % ret_2['foo']



# Generated at 2022-06-25 04:05:36.493297
# Unit test for function parse_kv

# Generated at 2022-06-25 04:05:46.977411
# Unit test for function split_args

# Generated at 2022-06-25 04:05:47.907904
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 04:05:59.087966
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

# How to use the Coverage tool
if __name__ == '__main__':
    import coverage
    cov = coverage.coverage(source=['ansible'])
    cov.start()
    test_parse_kv()
    cov.stop()
    cov.save()
    cov.html_report()
    cov.report(show_missing=1)

# Generated at 2022-06-25 04:06:08.520370
# Unit test for function split_args
def test_split_args():
    str_0 = r'''a=b c="foo bar"'''
    str_1 = r'''a=b c="foo bar"'''
    str_2 = '''a=b c="foo {% bar %}"'''
    str_3 = '''a=b c="foo {{ bar }}"'''
    str_4 = '''a=b c="foo {# bar #}"'''
    str_5 = '''a=b c="{% if x %}foo {% bar %} {% endif %}"'''
    str_6 = '''a=b c="{% if x %}foo {{ bar }} {% endif %}"'''
    str_7 = '''a=b c="{% if x %}foo {# bar #} {% endif %}"'''

# Generated at 2022-06-25 04:06:13.089600
# Unit test for function parse_kv

# Generated at 2022-06-25 04:06:17.994807
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = 'B9AQJxnEoQo'
    var_1 = parse_kv(var_0)
    print('var_0: %s' % var_0)
    print('var_1: %s' % var_1)


# Generated at 2022-06-25 04:06:28.100926
# Unit test for function split_args
def test_split_args():
    print("Testing split_args")
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('"foo bar" c=a') == ['"foo bar"', 'c=a']
    assert split_args('a=b d=e f=g') == ['a=b', 'd=e', 'f=g']
    assert split_args('"a=b d=e" f=g') == ['"a=b d=e"', 'f=g']
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c') == ['a=b', 'c']
    assert split_args('a=b c=') == ['a=b', 'c=']
    assert split_args

# Generated at 2022-06-25 04:06:35.196599
# Unit test for function parse_kv
def test_parse_kv():
    fp_0 = 'PKnM'
    str_0 = 'L'
    str_1 = '1x'
    str_2 = 'X'
    str_3 = 'W'
    str_4 = '6'
    str_5 = '\/'
    str_6 = 'N'
    str_7 = 'j'
    str_8 = 'a'
    str_9 = '9'
    str_10 = '?'
    str_11 = 'T'
    str_12 = 'o'
    str_13 = '='
    str_14 = 'w'
    str_15 = '4'
    str_16 = 'J'
    str_17 = 'S'
    str_18 = 'm'
    str_19 = 'V'
    str_20 = '9'

# Generated at 2022-06-25 04:06:42.034120
# Unit test for function split_args
def test_split_args():
    args_0 = 'B9AQJxnEoQo'
    rtn_0 = split_args(args_0)
    expected_0 = [args_0]
    assert rtn_0 == expected_0, 'split_args: test case 0 failed'

    args_1 = 'B9AQJxnEoQo "{a} a\\n"'
    rtn_1 = split_args(args_1)
    expected_1 = [args_1]
    assert rtn_1 == expected_1, 'split_args: test case 1 failed'

    args_2 = 'B9AQJxnEoQo "{a} a\\nb"'
    rtn_2 = split_args(args_2)
    expected_2 = [args_2]
    assert rtn_2 == expected

# Generated at 2022-06-25 04:06:48.224250
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'B9AQJxnEoQo'
    var_0 = parse_kv(str_0)
    assert(var_0 == {})
    str_1 = '/var/www/html/index.html=B9AQJxnEoQo'
    var_1 = parse_kv(str_1)
    do_assert(var_1 == {u'/var/www/html/index.html': u'B9AQJxnEoQo'})
    str_2 = '/var/www/html/index.html=B9AQJxnEoQo\\=\\='
    var_2 = parse_kv(str_2)

# Generated at 2022-06-25 04:06:57.342926
# Unit test for function parse_kv
def test_parse_kv():
    # var_1 = parse_kv(str_0)
    str_0 = "A1=B1 A2=B2 A3=B3"
    assert parse_kv(str_0) == {u'A1': u'B1', u'A2': u'B2', u'A3': u'B3'}
    str_0 = "A1=B1 c=d e=f A2=B2 A3=B3"
    assert parse_kv(str_0) == {u'A1': u'B1', u'A2': u'B2', u'A3': u'B3', '_raw_params': u'c=d e=f'}
    str_0 = "A1=B1 c=d e=f"

# Generated at 2022-06-25 04:06:59.626454
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

# Generated at 2022-06-25 04:07:11.680622
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'B9AQJxnEoQo'
    var_0 = parse_kv(str_0)

    print(var_0)


# Parse complex args, which are a combination of key=value and simple args

# Generated at 2022-06-25 04:07:21.989423
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('B9AQJxnEoQo') == {}
    assert parse_kv('q=89QLtSBEIqi') == {'q': '89QLtSBEIqi'}
    assert parse_kv('a="asdwe"') == {'a': 'asdwe'}
    assert parse_kv('a="a    asdwe"') == {'a': 'a    asdwe'}
    assert parse_kv('a="a\\" asdwe"') == {'a': 'a\\" asdwe'}
    assert parse_kv('a="a\\" asdwe\\\\"') == {'a': 'a\\" asdwe\\\\'}

# Generated at 2022-06-25 04:07:30.639843
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = "a=b c=d"
    var_0 = parse_kv(str_0)
    assert var_0 == {'a': 'b', 'c': 'd'}

    str_0 = "a=b c=d"
    var_0 = parse_kv(str_0)
    assert var_0 == {'a': 'b', 'c': 'd'}

    str_0 = "a=b\nc=d"
    var_0 = parse_kv(str_0)
    assert var_0 == {'a': 'b', 'c': 'd'}

    str_0 = "a=b c=d e=f"
    var_0 = parse_kv(str_0)

# Generated at 2022-06-25 04:07:32.840060
# Unit test for function split_args
def test_split_args():
    tc = 'B9AQJxnEoQo'
    trans_tc = split_args(tc)
    print(trans_tc)



# Generated at 2022-06-25 04:07:40.376941
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'B9AQJxnEoQo'
    var_0 = parse_kv(str_0)
    expected = {u'_raw_params': u'B9AQJxnEoQo', u'B9AQJxnEoQo': u''}
    print(var_0)
    print(expected)
    assert var_0 == expected


# Generated at 2022-06-25 04:07:49.197618
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '_raw_params=/usr/bin/python -u -c "import pip; print(pip.pep425tags.get_supported())"'
    var_0 = parse_kv(str_0)
    str_1 = 'chdir=/root/ansible/v2.4.2.0/lib/ansible/modules/cloud/amazon/ec2_vpc_nacl'
    var_1 = parse_kv(str_1)
    str_2 = 'creates=/root/ansible/v2.4.2.0/lib/ansible/modules/cloud/amazon/ec2_vpc_nacl/clouddeployment'
    var_2 = parse_kv(str_2)
    str_3 = 'executable=/bin/sh'
    var_3

# Generated at 2022-06-25 04:07:52.879758
# Unit test for function parse_kv
def test_parse_kv():
    try:
        test_case_0()
    except:
        print("Error in evaluation.")


# Generated at 2022-06-25 04:08:03.126368
# Unit test for function parse_kv
def test_parse_kv():
    print("*"*10 + " test parse_kv " + "*"*10)
    str_0 = 'B9AQJxnEoQo'
    var_0 = parse_kv(str_0)
    print(var_0)
    str_1 = 'a=1 a2=2 "a3 = 3"'
    var_1 = parse_kv(str_1)
    print(var_1)
    str_2 = 'a=1 a2=2 a3 = 3'
    var_2 = parse_kv(str_2)
    print(var_2)
    str_3 = 'a=1 a2=2 "a3 = 3'
    var_3 = parse_kv(str_3)
    print(var_3)


# Generated at 2022-06-25 04:08:04.928094
# Unit test for function parse_kv
def test_parse_kv():
    assert func_0() == 'B9AQJxnEoQo'


# Generated at 2022-06-25 04:08:15.813892
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u"foo=bar 2's") == {u'foo': u"bar 2's"}
    assert parse_kv(u"foo='bar 2'") == {u'foo': u"bar 2"}
    assert parse_kv(u"foo=bar' 2") == {u'foo': u"bar' 2"}
    assert parse_kv(u"foo=bar\\ 2") == {u'foo': u"bar 2"}
    assert parse_kv(u"foo=bar\\\\2") == {u'foo': u"bar\\2"}
    assert parse_kv(u"foo='bar\\' 2'") == {u'foo': u"bar' 2"}
    assert parse_kv

# Generated at 2022-06-25 04:08:31.780292
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

    # Test cases for the kv string
    # 'a=1 b=2 c=3' -> {'a': '1', 'c': '3', 'b': '2'}
    # 'a=1,b=2,c=3' -> {'a': '1', 'c': '3', 'b': '2'}
    # 'a=1,b=abc,c=3' -> {'a': '1', 'c': '3', 'b': 'abc'}
    # 'a="1",b="2",c="3"' -> {'a': '"1"', 'c': '"3"', 'b': '"2"'}
    # 'a="1" b="2" c="3"' -> {'a': '"1"', 'c': '"

# Generated at 2022-06-25 04:08:39.310385
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'B9AQJxnEoQo'
    str_1 = join_args(['-c', 'echo', '-P', str_0])
    var_0 = parse_kv(str_1)
    print(var_0)

# Pre-processing to split a string into a list while 
# handling escaping quotation marks and brackets

# Generated at 2022-06-25 04:08:49.181737
# Unit test for function parse_kv
def test_parse_kv():
    # Input parameters
    str_0 = 'abc'
    str_1 = 'a=10'
    str_2 = 'a=10 b=20'

    # Additional input parameters
    str_3 = 'a=10 "b=20"'
    str_4 = 'a=10 "b=20 c=30"'
    str_5 = "a=10 'b=20'"
    str_6 = "a=10 'b=20 c=30'"
    str_7 = "a=10 'b=20' c=30"
    str_8 = 'a=10 b=20 c=\\"30\\"'
    str_9 = 'a=\\"10\\" b=20 c=30'

    # Output parameters
    dict_0 = {'a': '10'}

# Generated at 2022-06-25 04:09:01.546595
# Unit test for function split_args

# Generated at 2022-06-25 04:09:02.430032
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

# Generated at 2022-06-25 04:09:06.506777
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '--otp-secret=B9AQJxnEoQo'
    var_0 = parse_kv(str_0)
    assert var_0 == {u'otp-secret': u'B9AQJxnEoQo'}


## Unit tests for unsplit_args


# Generated at 2022-06-25 04:09:17.367771
# Unit test for function split_args
def test_split_args():
    print('Test split_args()')
    for i in range(5):
        str_0 = 'B9AQJxnEoQo'
        var_0 = split_args(str_0)
        var_1 = join_args(var_0)
        print(var_1)
    # Test cases
    # Test case 0.
    str_0 = 'B9AQJxnEoQo'
    var_0 = split_args(str_0)
    var_1 = join_args(var_0)
    if var_1 != str_0:
        print('test_split_args: failed: test case 0')
    else:
        print('test_split_args: passed: test case 0')
        print(var_1)
    # Test case 1.
    str_0

# Generated at 2022-06-25 04:09:19.411716
# Unit test for function parse_kv
def test_parse_kv():
    assert True == True


# Generated at 2022-06-25 04:09:30.156741
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = "a=b c='d' e=1,2,3 f=g=h 'i=j' k=['l','m'] n='o=p q=r s'"
    var_0 = parse_kv(str_0)
    print(var_0)
    assert var_0[0] == 'a'
    assert var_0[1] == 'b'
    assert var_0[2] == 'c'
    assert var_0[3] == 'd'
    assert var_0[4] == 'e'
    assert var_0[5] == '1,2,3'
    assert var_0[6] == 'f'
    assert var_0[7] == 'g=h'
    assert var_0[8] == 'i=j'
    assert var

# Generated at 2022-06-25 04:09:32.465823
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv('B9AQJxnEoQo')
    assert var_0[0] == '_raw_params'
    assert var_0[1] == 'B9AQJxnEoQo'

# Generated at 2022-06-25 04:09:40.189680
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()



# Generated at 2022-06-25 04:09:50.971253
# Unit test for function split_args
def test_split_args():
    '''
    Verify that split_args() returns the expected parsed list
    '''

# Generated at 2022-06-25 04:10:01.041165
# Unit test for function split_args
def test_split_args():
    print("===TESTING split_args===")
    print("testing str_0")
    str_0 = 'B9AQJxnEoQo'
    result = split_args(str_0)
    print(result)
    # Expecting: ['B9AQJxnEoQo']
    assert result == ['B9AQJxnEoQo']

    print("testing str_1")
    str_1 = 'bash -c "rm -f /root/solr/server/solr/search_shards.txt"'
    result = split_args(str_1)
    print(result)
    # Expecting: ['bash', '-c', '"rm -f /root/solr/server/solr/search_shards.txt"']

# Generated at 2022-06-25 04:10:10.977722
# Unit test for function parse_kv
def test_parse_kv():
    # 1. a=b
    str_1 = 'a=b'
    var_1 = parse_kv(str_1)
    assert var_1['a'] == 'b'

    # 2. a=b c=d
    str_2 = 'a=b c=d'
    var_2 = parse_kv(str_2)
    assert var_2['c'] == 'd'

    # 3. a="b c"
    str_3 = 'a="b c"'
    var_3 = parse_kv(str_3)
    assert var_3['a'] == 'b c'

    # 4. a=b c="d e"
    str_4 = 'a=b c="d e"'
    var_4 = parse_kv(str_4)
    assert var_4

# Generated at 2022-06-25 04:10:20.966194
# Unit test for function parse_kv
def test_parse_kv():
    # Input parameters
    str_0 = '--arg=a --arg="b" --arg="c c" --arg="d \" foo" --arg="\\" e"'
    str_1 = r'--arg=a --arg="b" --arg="c c" --arg="d \" foo" --arg="\e"'
    str_2 = r'some \x20 args \x20 \\ with \x20 \x27 some \x27 \x27 escapeds \x27 \x27'
    str_3 = r'some \x20 args \x20 \\ with \x20 \x27 some \x27 \x27 escapeds \x27 \x27'
    str_4 = 'x \x5C \x5C'
    str_5 = 'x \x5C \x5C'

# Generated at 2022-06-25 04:10:26.152038
# Unit test for function parse_kv
def test_parse_kv():
    # Test with all possible inputs
    str_0 = 'B9AQJxnEoQo'
    var_0 = parse_kv(str_0)
    print(var_0)


# Generated at 2022-06-25 04:10:27.607452
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'BEQIJxonEoQo'
    var_0 = parse_kv(str_0)
    assert str_0 == 'BEQIJxonEoQo'



# Generated at 2022-06-25 04:10:37.529749
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'B9AQJxnEoQo'
    str_1 = '-a "arg1" -A "arg 2" -b c'
    str_2 = 'arg1 arg2 arg3'
    str_3 = r'''arg1 \=  \= arg3
arg4 = arg5 'arg6'
'''

    # Assert that there are no raw params
    assert(len(parse_kv(str_0)) == 0)

    # Assert that we can parse a valid command string
    assert(parse_kv(str_1)['a'] == 'arg1')
    assert(parse_kv(str_1)['A'] == 'arg 2')
    assert(parse_kv(str_1)['b'] == 'c')

    # Assert that non-key

# Generated at 2022-06-25 04:10:40.304777
# Unit test for function parse_kv
def test_parse_kv():
    assert False, "Not implemented yet"


# Generated at 2022-06-25 04:10:51.247200
# Unit test for function split_args
def test_split_args():
    # test case 0
    str_0 = 'B9AQJxnEoQo'
    var_0 = split_args(str_0)
    assert var_0 == ['B9AQJxnEoQo']

    # test case 1
    str_1 = 'B9AQJxnEoQo=A3q6Hn9IViI'
    var_1 = split_args(str_1)
    assert var_1 == ['B9AQJxnEoQo=A3q6Hn9IViI']

    # test case 2
    str_2 = 'b9aqJxnEoQo=a3q6Hn9iviI'
    var_2 = split_args(str_2)

# Generated at 2022-06-25 04:11:06.552252
# Unit test for function parse_kv
def test_parse_kv():
    # Test cases for parse_kv, only test cases 4 and 5 will be used
    str_1 = '  key1=value1  key2=value2 \t\t'
    str_2 = 'key1="value1 with spaces" key2=value2'
    str_3 = "key1='value1 with spaces' key2=\"spaces in value \t\t\t and newlines\n\n\n\""
    str_4 = "key1='value1 with spaces' key2=\"spaces in value \t\t\t and newlines\n\n\n\"\\'\\\\''key3=\\'value3\\'''"