

# Generated at 2022-06-25 04:01:56.632166
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("k1=v1 k2=v2", True) == {u'k1': u'v1', u'k2': u'v2'}
    assert parse_kv("k1=v1 k2=v2", False) == {u'k1': u'v1', u'k2': u'v2'}

    # mix of key/value and positional args
    assert parse_kv("k1=v1 k2=v2 p1 p2", True) == {u'k1': u'v1', u'k2': u'v2', '_raw_params': u'p1 p2'}

# Generated at 2022-06-25 04:01:57.348039
# Unit test for function parse_kv
def test_parse_kv():
    assert True


# Generated at 2022-06-25 04:02:04.811237
# Unit test for function parse_kv
def test_parse_kv():
    list_0 = []

    var_0 = parse_kv(list_0)
    assert type(var_0) == dict

    list_1 = "test_1=test_2"
    var_1 = parse_kv(list_1)
    assert type(var_1) == dict
    assert len(var_1) == 1
    assert "test_1" in var_1
    assert var_1["test_1"] == "test_2"

    list_2 = "'test 2'=test 2"
    var_2 = parse_kv(list_2)
    assert type(var_2) == dict
    assert len(var_2) == 1
    assert "'test 2'" in var_2
    assert var_2["'test 2'"] == "test 2"



# Generated at 2022-06-25 04:02:12.979273
# Unit test for function split_args
def test_split_args():
    # Create function object and test array
    list_0 = """
    {%a
    {%b
    {%c
    {# d
    {# e
    {# f
    {% {#
    {% }#
    {# %}
    {% #}
    {#a%}
    """
    list_1 = """
    %}a
    %}b
    %}c
    #} d
    #} e
    #} f
    {% {#
    {# %}
    #}%}
    %} #}
    %}a#}
    """

# Generated at 2022-06-25 04:02:23.646931
# Unit test for function split_args
def test_split_args():
    # Testing for function split_args
    func_0 = "foo=bar"
    func_1 = "foo='bar'"
    func_2 = "foo=\"bar\""
    func_3 = "foo=\"bar baz\""
    func_4 = "foo="
    func_5 = 'foo="bar'
    func_6 = 'foo=bar'

    assert split_args(func_0) == ['foo=bar'], "test_split_args:0"
    assert split_args(func_1) == ['foo=bar'], "test_split_args:1"
    assert split_args(func_2) == ['foo=bar'], "test_split_args:2"
    assert split_args(func_3) == ['foo=bar baz'], "test_split_args:3"
   

# Generated at 2022-06-25 04:02:24.372640
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 04:02:33.695580
# Unit test for function split_args
def test_split_args():
    list_0 = u'"a=b c="foo bar"'
    list_1 = u'a=b c="foo bar"'
    list_2 = u'"a=b c="foo bar""'
    list_3 = u'a=b c="foo bar""'
    list_4 = u'"a=b c="foo bar"""'
    list_5 = u'a=b c="foo bar"""'
    list_6 = u"a=b c='foo bar'"
    list_7 = u'a=b c=\'foo bar\''
    list_8 = u"a=b c='foo bar'\na=b c='foo bar'"
    list_9 = u"a=b c='foo bar'\\\na=b c='foo bar'"

# Generated at 2022-06-25 04:02:43.772798
# Unit test for function parse_kv
def test_parse_kv():
    print(parse_kv(''))
    print(parse_kv('a=b'))
    print(parse_kv('a=b c=d'))
    print(parse_kv('a=b\n c=d'))
    print(parse_kv('a=b\n  c=d'))
    print(parse_kv('a=b\n   c=d'))
    #print parse_kv("a='b c'")
    print(parse_kv("a=b' c'"))
    print(parse_kv("a=b' c' d"))
    print(parse_kv("a=b' c' d e=f"))
    print(parse_kv("a=b' c' d \\'e\\'=f"))

# Generated at 2022-06-25 04:02:54.383392
# Unit test for function split_args
def test_split_args():
    # test_case_0()
    args = "dummy_arg -a dummy_arg dummy_arg dummy_arg dummy_arg -b dummy_arg dummy_arg dummy_arg dummy_arg -c dummy_arg dummy_arg dummy_arg dummy_arg -d \"dummy_arg dummy_arg dummy_arg dummy_arg\" -e 'dummy_arg dummy_arg dummy_arg dummy_arg' -f 'dummy_arg dummy_arg dummy_arg dummy_arg' -g 'dummy_arg dummy_arg dummy_arg dummy_arg'"

# Generated at 2022-06-25 04:02:56.421074
# Unit test for function split_args
def test_split_args():
    assert True


# Generated at 2022-06-25 04:03:10.412258
# Unit test for function parse_kv
def test_parse_kv():
    string_0 = 'root=1234'
    kwargs_0 = {'check_raw': False}
    result_0 = parse_kv(string_0, **kwargs_0)
    assert result_0['root'] == '1234'


# Generated at 2022-06-25 04:03:16.133297
# Unit test for function split_args
def test_split_args():
    str_0 = 'F~wT>%{#Ph[K6In~'
    var_0 = split_args(str_0)

    assert len(var_0) == 1
    assert var_0[0] == 'F~wT>%{#Ph[K6In~'

    str_1 = 'F~wT>%{#Ph[K6In~\n'
    var_1 = split_args(str_1)

    assert len(var_1) == 1
    assert var_1[0] == 'F~wT>%{#Ph[K6In~'

    str_2 = 'F~wT>%{#Ph[K6In~\n '
    var_2 = split_args(str_2)

    assert len(var_2) == 1

# Generated at 2022-06-25 04:03:25.072622
# Unit test for function split_args
def test_split_args():
    target = 'ansible'
    param_args = {
        '--list-hosts': '',
        '--syntax-check': '',
        '--inventory': 'inventories/dev',
        '--playbook-dir': 'playbooks',
        '--playbook': 'playbooks/deploy-services.yml',
        '-e': 'target=%s' % target
    }
    args = ' '.join(['%s="%s"' % (k, v) for k, v in param_args.items()])
    var_0 = split_args(args)
    print(var_0)


if __name__ == '__main__':
#    test_split_args()
    test_case_0()

# Generated at 2022-06-25 04:03:27.421847
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'F~wT>%{#Ph[K6In~'
    var_0 = parse_kv(str_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 04:03:31.463988
# Unit test for function split_args
def test_split_args():
    # Case 1
    str_1 = """async: "{{ ansible_date_time.epoch }} """
    var_1 = split_args(str_1)
    var_2 = [u'async:', u"{{", u'ansible_date_time.epoch', u'}}']
    if var_1 != var_2:
        print(u"CASE 1 ERROR")


# Generated at 2022-06-25 04:03:37.588581
# Unit test for function parse_kv
def test_parse_kv():
    s = 'ansible_ssh_pass=hunter1 private_key_file=/home/user/.ssh/id_rsa'
    result = parse_kv(s)
    print(result)



# Generated at 2022-06-25 04:03:48.265890
# Unit test for function split_args
def test_split_args():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    c = '''
    foo=bar1 baz={{{{ foo }}} zaz={{ bar }} bar=foo }}}
    {{ "{{ '{' }}}" }}
    {% {# {{ '{' }%}}}
    {{{{{{{ foo }}}
    "}}}}}}}}}}}}}}}}}}}}}}}}}}}}"
    '''

    # Test a list of strings, make sure they get parsed into the
    # correct list of params
    p = split_args(c)
    assert len(p) == 5
    assert p[0] == "foo=bar1 baz={{{{ foo }}} zaz={{ bar }} bar=foo }}}"
    assert isinstance(p[0], AnsibleUnsafeText)
    assert p

# Generated at 2022-06-25 04:03:58.460121
# Unit test for function parse_kv
def test_parse_kv():
    try:
        var_0 = split_args('')
        assert var_0 == [], 'Expected [], but got: ' + str(var_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 04:04:03.733010
# Unit test for function parse_kv
def test_parse_kv():
    assert "B=b" == join_args(split_args('B=b'))
    assert "B='b'" == join_args(split_args('B="b"'))
    assert "B=\"b\"" == join_args(split_args('B=\"b\"'))
    assert "B=\"b\" C=c" == join_args(split_args('B=\"b\" C=c'))
    assert "" == join_args(split_args(''))
    assert "B=b C=c" == join_args(split_args('B=b C=c'))
    assert "B=b C='c d'" == join_args(split_args('B=b C="c d"'))

# Generated at 2022-06-25 04:04:14.201785
# Unit test for function split_args
def test_split_args():
    str_0 = '-a "foo bar"'
    var_0 = split_args(str_0)
    assert var_0 == ['a=foo bar']

    str_1 = '-a "foo bar" -b "baz dib"'
    var_1 = split_args(str_1)
    assert var_1 == ['a=foo bar', 'b=baz dib']

    str_2 = '-a "foo bar" -b baz'
    var_2 = split_args(str_2)
    assert var_2 == ['a=foo bar', 'b=baz']

    str_3 = '-a foo bar -b baz'
    var_3 = split_args(str_3)
    assert var_3 == ['a=foo bar', 'b=baz']

    str_

# Generated at 2022-06-25 04:04:26.515874
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    var_0 = split_args(bytes_0)
    assert var_0 == [b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f']


# Generated at 2022-06-25 04:04:34.332321
# Unit test for function split_args
def test_split_args():
    # Arguments
    args = '--debug -r roles/ -e "foo=bar bam=baz" -t monitoring'

    # Expected result
    expected = ['--debug', '-r', 'roles/', '-e', 'foo=bar bam=baz', '-t', 'monitoring']

    # Call function
    result = split_args(args)

    # Verify if result and expectation match
    assert result == expected


# Generated at 2022-06-25 04:04:41.647325
# Unit test for function parse_kv
def test_parse_kv():
    assert len(parse_kv('user=jiemidashi')) == 1
    assert len(parse_kv('user=jiemidashi', True)) == 1

    assert len(parse_kv('user=jiemidashi message="Hello World"')) == 2
    assert len(parse_kv('user=jiemidashi message="Hello World"', True)) == 2

    assert len(parse_kv('user=jiemidashi "message=Hello World"')) == 1
    assert len(parse_kv('user=jiemidashi "message=Hello World"', True)) == 2

    assert len(parse_kv('user=jiemidashi "message=\"Hello World\""')) == 1
    assert len(parse_kv('user=jiemidashi "message=\"Hello World\""', True)) == 2

    result

# Generated at 2022-06-25 04:04:44.320956
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    var_0 = split_args(bytes_0)
    assert(var_0 == list(bytes_0))

# Generated at 2022-06-25 04:04:52.391121
# Unit test for function split_args
def test_split_args():
    # This is the string we want to split.
    # Note that because of the way this string is generated, we need to manually
    # fix it if changes in the core code cause new parts to be added to it.
    s = 'yum localinstall -y "rpm-1.noarch.rpm" "rpm-2.noarch.rpm"'
    assert(split_args(s) == ['yum', 'localinstall', '-y', 'rpm-1.noarch.rpm', 'rpm-2.noarch.rpm'])

# Generated at 2022-06-25 04:05:03.810844
# Unit test for function split_args
def test_split_args():
    assert split_args("hello world") == ['hello', 'world']
    assert split_args('''hello world "foo bar" baz''') == ['hello', 'world', '"foo bar"', 'baz']
    assert split_args('''foo "bar bizzle" foo''') == ['foo', '"bar bizzle"', 'foo']
    assert split_args('''foo "bar bizz{{le }}" foo''') == ['foo', '"bar bizz{{le }}"', 'foo']
    assert split_args('''foo "bar bizz{{le {{}} }}" foo''') == ['foo', '"bar bizz{{le {{}} }}"', 'foo']

# Generated at 2022-06-25 04:05:13.824667
# Unit test for function split_args
def test_split_args():
    assert split_args('ansible-galaxy install username.role_name') == ['ansible-galaxy', 'install', 'username.role_name']
    assert split_args('ansible-galaxy install "username.role_name"') == ['ansible-galaxy', 'install', '"username.role_name"']
    assert split_args('ansible-galaxy install \'username.role_name\'') == ['ansible-galaxy', 'install', '\'username.role_name\'']
    assert split_args('ansible-galaxy install "user\\"name.role_name"') == ['ansible-galaxy', 'install', '"user\\"name.role_name"']


# Generated at 2022-06-25 04:05:25.965676
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c') == ['a=b', 'c']
    assert split_args('a=b c') == ['a=b', 'c']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a="foo bar" c="foo bar"') == ['a="foo bar"', 'c="foo bar"']
    assert split_args('a="foo bar" \nc="foo bar"') == ['a="foo bar"', 'c="foo bar"']

# Generated at 2022-06-25 04:05:33.515058
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    var_0 = parse_kv(bytes_0, bytes_0)

# main function
if __name__ == '__main__':
    test_case_0()
    test_parse_kv()

# https://github.com/ansible/ansible-modules-core/blob/devel/system/ping.py

# Generated at 2022-06-25 04:05:39.842570
# Unit test for function split_args
def test_split_args():
    # Simple kv option
    args = 'a=b'
    assert split_args(args) == ['a=b']

    # Multiple options
    args = 'a=b c="foo bar"'
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Simple jinja2
    args = '{{ foo }}'
    assert split_args(args) == ['{{ foo }}']

    # jinja2 inside kv option
    args = 'a={{ foo }}'
    assert split_args(args) == ['a={{ foo }}']

    # kv option inside jinja2
    args = '{{ "a=b" }}'
    assert split_args(args) == ['{{ "a=b" }}']

    # kv inside jinja2 inside kv
   

# Generated at 2022-06-25 04:06:03.005676
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args('rm -rf /') == [u'rm', u'-rf', u'/']
    assert split_args('oneline') == [u'oneline']
    assert split_args('twoline\npara') == [u'twoline\npara']
    assert split_args('threeline\npara\nwith spaces') == [u'threeline\npara\nwith spaces']
    assert split_args("""fourline
para
with spaces,
and (parens)""") == [u'fourline\npara\nwith spaces,\nand (parens)']

# Generated at 2022-06-25 04:06:04.829507
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv()
    assert result == None


# Generated at 2022-06-25 04:06:14.268261
# Unit test for function split_args
def test_split_args():
    # The string to the function split_args
    bytes_0 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'

    # Invoke the function with the string
    var_0 = split_args(bytes_0)

    # There should be 6 params after splitting the string
    assert len(var_0) == 6

    # Each entry should be the correct parameter
    assert var_0[0] == '\x8c\xb0]'
    assert var_0[1] == '\xceO!'
    assert var_0[2] == '\xa5'
    assert var_0[3] == '\x84'
    assert var_0[4] == '\x1d'

# Generated at 2022-06-25 04:06:23.664514
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(u'"foo bar"\n"baz bat"') == [u'"foo bar"', u'"baz bat"']
    assert split_args(u'echo {{ item }}\'foo bar\'') == [u'echo', u'{{', u'item', u'}}', u'\'foo bar\'']
    assert split_args(u'{{ foo }} \'baz bat\'   "foo bar"') == [u'{{', u'foo', u'}}', u'\'baz bat\'', u'"foo bar"']

# Generated at 2022-06-25 04:06:30.633975
# Unit test for function split_args
def test_split_args():
    orig = '''
    this is a
    multi line
    test
    '''
    expected = ['this', 'is', 'a\nmulti', 'line\ntest']
    parsed = split_args(orig)
    assert parsed == expected, '%s does not match %s' % (parsed, expected)



# Generated at 2022-06-25 04:06:41.525213
# Unit test for function split_args
def test_split_args():
    # naive test
    test_args = "echo -n 'hello world'"
    result = split_args(test_args)
    if result != ['echo', "-n", "'hello world'"]:
        raise AssertionError("Test figure 1 failed")

    # quoted test
    test_args = "echo -n 'hello world' 'goodbye world'"
    result = split_args(test_args)
    if result != ['echo', "-n", "'hello world' 'goodbye world'"]:
        raise AssertionError("Test figure 2 failed")

    # double-quoted test
    test_args = 'echo -n "hello world"'
    result = split_args(test_args)
    if result != ['echo', "-n", '"hello world"']:
        raise AssertionError("Test figure 3 failed")

    # double-qu

# Generated at 2022-06-25 04:06:44.852105
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x93\x03\x8f\x0c\xf6}\xe4\xaa!\x8c\x9a\xdd\xd3p\x02\x1f\x1c'
    var_0 = parse_kv(bytes_0, bytes_0)

# Generated at 2022-06-25 04:06:53.438261
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    var_0 = parse_kv(bytes_0, bytes_0)
    assert var_0 == {u'_raw_params': u'key1=1 key2=2 key3="this is a string" key4=\'this is also a string\''}
    bytes_1 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    bytes_2 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'

# Generated at 2022-06-25 04:07:01.211245
# Unit test for function split_args
def test_split_args():
    # function test: returns the same result as original split_args function
    # normal cases
    assert split_args(r"a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args(r"a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args(r"a=b c=\"foo bar") == ['a=b', 'c="foo bar']
    assert split_args(r"a=b c=\'foo bar") == ['a=b', "c='foo bar"]
    assert split_args(r"a=b c='foo bar\"") == ['a=b', 'c=\'foo bar"\'']

# Generated at 2022-06-25 04:07:11.545701
# Unit test for function split_args
def test_split_args():
    # Test a simple case
    vargs = ['--foo', 'bar', 'baz']
    argline = '--foo bar baz'
    assert split_args(argline) == vargs

    # Test with a quoted parameter
    argline = '--foo "bar baz"'
    assert split_args(argline) == vargs

    # Test with a quoted parameter containing whitespace and newlines
    argline = '--foo "bar baz\nfoo\tbar"'
    assert split_args(argline) == vargs

    # Test with a quoted parameter containing whitespace, newlines and escaped quotes
    argline = '--foo "bar baz\\"\nfoo\\"\tbar"'
    assert split_args(argline) == vargs

    # Test with a quoted parameter containing whitespace, newlines and escaped whitespace and

# Generated at 2022-06-25 04:07:19.451257
# Unit test for function parse_kv
def test_parse_kv():
    """Test function: parse_kv"""
    test_case_0()


# Generated at 2022-06-25 04:07:24.731930
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    var_1 = b'\x1d\x1d=\x1d\x1d\x1d'
    var_2 = parse_kv(var_0, var_1)
    assert var_2 == {}


# Generated at 2022-06-25 04:07:28.132299
# Unit test for function split_args
def test_split_args():
    string_test_case = "a=b c=\"foo bar\""
    list_test_case = ['a=b', 'c="foo bar"']
    assert split_args(string_test_case) == list_test_case


# Generated at 2022-06-25 04:07:33.921723
# Unit test for function split_args
def test_split_args():
    # Test case: stdin=False
    try:
        print(split_args(False))
    except Exception as e:
        print(e)
    
    # Test case: stdin=True
    try:
        print(split_args(True))
    except Exception as e:
        print(e)


# Generated at 2022-06-25 04:07:35.769672
# Unit test for function parse_kv
def test_parse_kv():
    assert callable(parse_kv)


# Generated at 2022-06-25 04:07:45.102283
# Unit test for function parse_kv
def test_parse_kv():
    # test_case 0
    # expect 'x\x9cy\xbeO!\xa5\x84\x1d\x1d\x1f'
    var_0 = parse_kv(b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f', b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f')
    # test_case 1
    # expect 'x\x9cy\xbeO!\xa5\x84\x1d\x1d\x1f'

# Generated at 2022-06-25 04:07:50.481539
# Unit test for function split_args
def test_split_args():
    # Test arguments and expected results
    inputs = ['a=b c="foo bar"', 'a=b c="foo bar\"']
    expected = [['a=b', 'c="foo bar"'], ['a=b', 'c="foo bar\"']]
    # Loop through all inputs and check if they match the expected results
    for i in range(2):
        result = split_args(inputs[i])
        assert expected[i] == result
        print("PASSED: split_args")


# Generated at 2022-06-25 04:08:00.767863
# Unit test for function parse_kv
def test_parse_kv():

    bytes_3 = b'\xdd:\x13\xe5\x96\xa1\x0e\x89\x84a\x8a'
    bytes_4 = b'\x1f[\x8f\x03\x89\x9c\x8d\x8f\x00'
    str_4 = '\x05\x12\x00\x80'

    var_0 = parse_kv(b'', b'\x0f\x03\x96\xa2\x9aM\x00')

    var_1 = parse_kv(b'\x03\x00\x9d', b'\x91\xa5\x9d')

    var_2 = parse_kv(b'\xaa\x9b', b'\xdf')

# Generated at 2022-06-25 04:08:10.905356
# Unit test for function parse_kv
def test_parse_kv():
    arr_bytes = [
        b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f',
        b'\xb3\x93^\x00\xb6\x83?\xa9\x13\x1f\x1c',
        b'\x91\xb0]\xd7\xbc\x97\x9c?\x1e'
    ]

    # test 1
    bytes_value = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    var_result = None

    try:
        var_result = parse_kv(bytes_value, bytes_value)
    except Exception as error:
        pass


# Generated at 2022-06-25 04:08:14.935055
# Unit test for function split_args
def test_split_args():
    # Test 1
    bytes_0 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    var_0 = parse_kv(bytes_0, bytes_0)
    

# Generated at 2022-06-25 04:08:25.318427
# Unit test for function split_args
def test_split_args():
    # Test Case 0
    str_0 = '-a'
    expected_var_0 = ['-a']

    actual_var_0 = split_args(str_0)
    assert actual_var_0 == expected_var_0


# Generated at 2022-06-25 04:08:30.355866
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    assert parse_kv(bytes_0, bytes_0) == {}
    v_0 = b'\xea\x88\xcc'
    v_0 = bytes_0.replace(v_0, v_0)
    bytes_1 = b''
    assert parse_kv(bytes_1, bytes_1) == {}
    bytes_2 = b'L5\xa2\x91\xe1'
    assert parse_kv(bytes_2, bytes_2) is None

# Generated at 2022-06-25 04:08:41.586590
# Unit test for function split_args
def test_split_args():
    args = 'a b "{{foo}}" c={{bar}} d="\"{{baz}}\"" e="\\"{{blah}}\\"" "{{ foo}}"'
    params = split_args(args)
    assert params == [
        'a',
        'b',
        '"{{foo}}"',
        'c={{bar}}',
        'd="\"{{baz}}\""',
        'e="\\"{{blah}}\\""',
        '"{{ foo}}"',
    ]

    args = 'a b "{{foo}}" c={{bar}} d="\"{{baz}}\"" e="\\"{{blah}}\\""'
    params = split_args(args)

# Generated at 2022-06-25 04:08:50.177056
# Unit test for function parse_kv
def test_parse_kv():
    test_cases = list()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()

# Generated at 2022-06-25 04:08:52.161848
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 04:08:53.226362
# Unit test for function parse_kv
def test_parse_kv():
    assert True == True


# Generated at 2022-06-25 04:09:03.311839
# Unit test for function parse_kv

# Generated at 2022-06-25 04:09:10.264769
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(b'''A=1 B=2 C=" 3 "''') == {'A': '1', 'B': '2', 'C': ' 3 '}
    # FIXME: Chars are hexdecimal
    # assert parse_kv(b'''A=\\u1234\\u5678''') == {'A': '\u1234\u5678'}
    assert parse_kv(b'''A=\\u1234\\u5678''') == {'A': '\\u1234\\u5678'}
    assert parse_kv(b'B=/path/to/file') == {'B': '/path/to/file'}

# Generated at 2022-06-25 04:09:11.573035
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()


# Generated at 2022-06-25 04:09:16.773434
# Unit test for function parse_kv
def test_parse_kv():
    from test_utils import version_less_than, version_totuple
    if version_less_than(2, 7, 0):
        # Python 2.6
        from lib.asserts import assert_array_equal
    else:
        # Python 2.7, 3.3+
        from unittest.test.testmock.support import assert_array_equal

    bytes_0 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    var_0 = parse_kv(bytes_0, bytes_0)

# Generated at 2022-06-25 04:09:30.359091
# Unit test for function split_args
def test_split_args():
    """
    public : function split_args($args)
    """
    bytes_0 = b''
    var_0 = split_args(bytes_0)


# Generated at 2022-06-25 04:09:34.910496
# Unit test for function split_args
def test_split_args():
    # At the moment, testing is done by running this module as a script,
    # and manually inspecting the output.
    # TODO: Figure out how to easily and properly unit test this function.
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 04:09:41.411677
# Unit test for function split_args
def test_split_args():
    inputs = ['foo bar']
    outputs = [['foo', 'bar']]
    for index, input_value in enumerate(inputs):
        output_value = split_args(input_value)
        assert output_value == outputs[index]

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:09:52.656360
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    num_0 = -1457751681626678199
    num_1 = -1457751681626678199
    num_2 = -1457751681626678199
    num_3 = -1457751681626678199
    num_4 = -1457751681626678199
    num_5 = -1457751681626678199
    num_6 = -1457751681626678199
    num_7 = -1457751681626678199
    num_8 = -1457751681626678199
    num_9 = -1457751681626678199
    num_10 = -145775

# Generated at 2022-06-25 04:10:00.598183
# Unit test for function parse_kv
def test_parse_kv():
    assert '_raw_params' in parse_kv('a=2'), 'a=2'
    assert '_raw_params' in parse_kv('a=bad', check_raw=True), 'a=bad'
    assert 'a' in parse_kv('a=2'), 'a=2'
    assert 'a' in parse_kv('a=bad', check_raw=True), 'a=bad'
    assert 'a' in parse_kv('a=bad'), 'a=bad'
    assert parse_kv('a=2')["a"] == '2', 'a=2'
    assert parse_kv('a=2')["_raw_params"] == '2', 'a=2'
    assert parse_kv('a=bad')["a"] == 'bad', 'a=bad'
   

# Generated at 2022-06-25 04:10:05.486052
# Unit test for function parse_kv
def test_parse_kv():

    # Add test case url here
    test_case_0()

if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-25 04:10:16.927258
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    var_0 = parse_kv(bytes_0, bytes_0)
    assert var_0 == {}
    bytes_1 = b'D\xee\xf6\xcc\xa8\xfc\xb6\x1b\x1a\x10'
    var_1 = parse_kv(bytes_1, bytes_1)
    assert var_1 == {}
    bytes_2 = b'\xc7\x9e\xc8\xa0'
    var_2 = parse_kv(bytes_2, bytes_2)
    assert var_2 == {}

# Generated at 2022-06-25 04:10:18.049825
# Unit test for function parse_kv
def test_parse_kv():
    assert True == True


# Generated at 2022-06-25 04:10:28.507207
# Unit test for function parse_kv
def test_parse_kv():
    # Tests that the value returned by the parse_kv function is correct.
    v1 = u'a=b c=d'
    e1 = {u'a': u'b', u'c': u'd'}
    test_v = parse_kv(v1)
    assert e1 == test_v
    v2 = u"a='b c=d'"
    e2 = {u'a': u'b c=d'}
    test_v = parse_kv(v2)
    assert e2 == test_v
    v3 = u"a='b=c' d='e f'"
    e3 = {u'a': u'b=c', u'd': u'e f'}
    test_v = parse_kv(v3)
    assert e3 == test_v
   

# Generated at 2022-06-25 04:10:30.059764
# Unit test for function parse_kv
def test_parse_kv():
    assert test_case_0() is None
# End of test_parse_kv


# Generated at 2022-06-25 04:10:46.068671
# Unit test for function split_args
def test_split_args():
    result_1 = split_args("-i h\n-m ping\n-x localhost")
    assert result_1 == ['-i', 'h\n-m', 'ping\n-x', 'localhost']

    result_2 = split_args("-m raw -s -a 'hello'")
    assert result_2 == ['-m', 'raw', '-s', "-a", "'hello'"]

    result_3 = split_args("command1\ncommand1\ncommand1")
    assert result_3 == ['command1\ncommand1\ncommand1']

    result_4 = split_args("-m foo -a 'bar \n baz'")
    assert result_4 == ['-m', 'foo', '-a', '\'bar \n baz\'']


# Generated at 2022-06-25 04:10:51.654241
# Unit test for function parse_kv
def test_parse_kv():
    # bytes_0 = b'\x8c\xb0]\xceO!\xa5\x84\x1d\x1d\x1f'
    bytes_0 = b'this is a test'
    var_0 = parse_kv(bytes_0)
    print('TEST: parse_kv')
    print(f'{var_0}')
    print('-----')
    print(f'{bytes_0}')



# Take a string and split it into arguments, stripping out any empty values

# Generated at 2022-06-25 04:11:01.056898
# Unit test for function parse_kv

# Generated at 2022-06-25 04:11:07.834800
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=3 b=4') == {u'a': u'3', u'b': u'4'}
    assert parse_kv('a, b=4') == {u'a': u'', u'b': u'4'}
    assert parse_kv("a, b=4") == {u'a': u'', u'b': u'4'}
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('/') == {u'/': u''}
    assert parse_kv('/=') == {u'/': u''}
    assert parse_kv('/=a') == {u'/': u'a'}