

# Generated at 2022-06-25 04:01:48.928785
# Unit test for function parse_kv
def test_parse_kv():
    kv_str1 = "ansible_ssh_user=root state=present"
    kv_str2 = "url=http://localhost"

    res1 = parse_kv(kv_str1, check_raw=False)
    assert res1["state"] == "present"
    assert res1["ansible_ssh_user"] == "root"

    res2 = parse_kv(kv_str2, check_raw=False)
    assert res2["url"] == "http://localhost"

    print("Tests completed")



# Generated at 2022-06-25 04:01:49.788255
# Unit test for function split_args
def test_split_args():
    test_case_0()



# Generated at 2022-06-25 04:01:52.108068
# Unit test for function split_args
def test_split_args():
    test_case_0()
    # Add more test cases.

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:01:54.238133
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv('a=b c=d e=f')
    assert result == {'a': 'b', 'c': 'd', 'e': 'f'}


# Generated at 2022-06-25 04:01:56.576551
# Unit test for function split_args
def test_split_args():
    try:
        test_case_0()
        print("Test case <0> Pass")
    except Exception as e:
        print("An error occurred: {}".format(e))

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:02:04.189056
# Unit test for function parse_kv
def test_parse_kv():
    # FIXME
    #options = parse_kv('a=b c=d')
    #assert options['a'] == 'b'
    #assert options['c'] == 'd'
    #options = parse_kv('a="b c" d=e')
    #assert options['a'] == 'b c'
    #assert options['d'] == 'e'
    #options = parse_kv('a=b c="d e"')
    #assert options['a'] == 'b'
    #assert options['c'] == 'd e'
    #options = parse_kv('a=b c=d e=f')
    #assert options['a'] == 'b'
    #assert options['c'] == 'd'
    #assert options['e'] == 'f'
    return


# Generated at 2022-06-25 04:02:10.829725
# Unit test for function parse_kv
def test_parse_kv():
    print('start test')
    str_0 = 'hello=word'
    str_1 = 'hello=world abc=123 abc=xyz'
    str_2 = 'hello=world hello=word'
    str_3 = 'hello=world a=x=y b=m=n'
    str_4 = 'a=test b=test c=test'
    str_5 = 'a b c'
    str_6 = 'a b c d=e f=n=o'
    str_7 = 'a=b c=d e=f'
    str_8 = 'a=b c=d e=f g'
    str_9 = 'a=b c=d e=f g h'
    str_10 = 'a=b c=d e=f g h i'

# Generated at 2022-06-25 04:02:15.735397
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'a=b c=d'
    r = parse_kv(str_0)
    assert r == {'a':'b','c':'d'}
    str_0 = 'a=b c="d"'
    r = parse_kv(str_0)
    assert r == {'a':'b','c':'d'}
    str_0 = 'a=b "c=d"'
    r = parse_kv(str_0)
    assert r == {'a':'b','_raw_params':'"c=d"'}
    str_0 = 'a=b "c=d" "e=f"'
    r = parse_kv(str_0)

# Generated at 2022-06-25 04:02:26.190610
# Unit test for function split_args
def test_split_args():
    str_0 = 'J~:[<x'
    var_0 = split_args(str_0)
    assert 'J~:[<x' == var_0[0]
    assert len(var_0) == 1
    str_0 = '{{ }}'
    var_0 = split_args(str_0)
    assert '{{ }}' == var_0[0]
    assert len(var_0) == 1
    str_0 = '{% %}'
    var_0 = split_args(str_0)
    assert '{% %}' == var_0[0]
    assert len(var_0) == 1
    str_0 = '{# #}'
    var_0 = split_args(str_0)
    assert '{# #}' == var_0[0]


# Generated at 2022-06-25 04:02:30.538265
# Unit test for function split_args
def test_split_args():
    test_case_0()

test_split_args()

# Generated at 2022-06-25 04:03:01.474927
# Unit test for function parse_kv
def test_parse_kv():
    assert None == parse_kv('\x9b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00') == None

# Generated at 2022-06-25 04:03:03.492574
# Unit test for function parse_kv
def test_parse_kv():
    with open("parse_kv_0_data.txt", 'rb') as f:
        while True:
            v = f.readline().rstrip()
            if not v:
                break
            test_case_0()

# Entry point for running test cases

# Generated at 2022-06-25 04:03:10.628992
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    var_0 = parse_kv(bytes_0)
    var_1 = var_0.get(u'_raw_params', None)
    bytes_1 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c'
    bytes_1 += b'\xad\xa4df\x02\x0e'
    assert(var_1 != None)
    assert(var_1 == bytes_1)

# Generated at 2022-06-25 04:03:14.451596
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()
    #if __name__ == '__main__':
    #    test_parse_kv()

#-----------------------------------------------------------------
# join_args
#-----------------------------------------------------------------

# Generated at 2022-06-25 04:03:23.815169
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'a="b c d" e f'
    var_0 = parse_kv(bytes_0)
    assert var_0 == {'_raw_params': 'a="b c d" e f', 'a': 'b c d'}
    bytes_1 = b'foo bar bam'
    var_1 = parse_kv(bytes_1, True)
    assert var_1 == {'_raw_params': 'foo bar bam'}
    bytes_2 = b'foo="bar bam" arg2="c d" arg3="e f" g h i'
    var_2 = parse_kv(bytes_2)
    assert var_2 == {'arg2': 'c d', 'arg3': 'e f', 'foo': 'bar bam'}



# Generated at 2022-06-25 04:03:33.235418
# Unit test for function parse_kv
def test_parse_kv():
    correct_result_str = b'{\'_raw_params\': None, \'strip_empty_ends\': None, \'stdin\': None, \'removes\': None, \'stdin_add_newline\': None, \'executable\': None, \'chdir\': None, \'creates\': None, \'warn\': None}'
    correct_result = eval(correct_result_str)

    # example 1
    example_1 = b'/bin/false'
    result_1 = parse_kv(example_1)
    # print(result_1)
    # print(correct_result)
    assert (result_1 == correct_result)

    # example 2
    example_2 = b'/bin/false'
    result_2 = parse_kv(example_2, True)
    # print(result

# Generated at 2022-06-25 04:03:41.405228
# Unit test for function split_args
def test_split_args():
    assert split_args("user={{ user_name }} password={{ user_name }}") == ["user={{ user_name }}", "password={{ user_name }}"]
    assert split_args("/opt/application/deploy.sh status={{ status }} user_name={{ user_name }}") == ["/opt/application/deploy.sh", "status={{ status }}", "user_name={{ user_name }}"]
    assert split_args("/home/test -name test.txt") == ["/home/test", "-name test.txt"]
    assert split_args("permission=777 dest=/tmp/foo.txt") == ["permission=777", "dest=/tmp/foo.txt"]

# Generated at 2022-06-25 04:03:42.096215
# Unit test for function parse_kv
def test_parse_kv():
    assert(True)



# Generated at 2022-06-25 04:03:49.082438
# Unit test for function split_args
def test_split_args():
    # Test 1
    test_1 = b'a=b c="foo bar"'

    # Test 2
    test_2_1 = b'a=b c="foo bar'
    test_2_2 = b'"'
    test_2_3 = b'b c"'
    test_2_4 = b'foo bar'
    test_2_5 = b'baz'

    # Test 3
    test_3 = b'a=b c="foo bar'
    test_3_2 = b'"b c"'
    test_3_3 = b'foo bar'
    test_3_4 = b'baz'

    # Test 4
    test_4 = b'a=b c="foo bar" baz'

    # Test 5

# Generated at 2022-06-25 04:03:53.990859
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d" e="f g" h=\'i j\'') == {
        u'a': u'b',
        u'e': u'f g',
        u'h': u'i j',
        u'c': u'd',
    }

    assert parse_kv('a=b c="d" e="f g" h=\'i j\'', check_raw=True) == {
        u'_raw_params': u'a=b c="d" e="f g" h=\'i j\'',
    }

    assert parse_kv('a="\\\\"') == {
        u'a': u'\\',
    }

    assert parse_kv('a="\\""') == {
        u'a': u'"',
    }


# Generated at 2022-06-25 04:04:08.431006
# Unit test for function split_args
def test_split_args():
    # This is a simple test function that verifies that the function
    # is able to handle some basic cases. It is not exhaustive.
    # Print a status message
    print('Testing function split_args')

    # Remove any debug log files
    import glob
    import os
    files = glob.glob('split_args.log')
    for f in files:
        os.remove(f)

    # Create a logger (turn DEBUG on for verbosity)
    import logging
    log_format = '%(asctime)s %(levelname)s: %(message)s'
    date_format = '%Y-%m-%d %H:%M:%S'

# Generated at 2022-06-25 04:04:11.114657
# Unit test for function parse_kv
def test_parse_kv():
    assert func() == 0


if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-25 04:04:12.405825
# Unit test for function parse_kv
def test_parse_kv():
    assert 1
    assert 1

# Generated at 2022-06-25 04:04:21.108052
# Unit test for function parse_kv
def test_parse_kv():
    print(u"Unit test for function parse_kv")
    test_case_0()

# Run tests
test_parse_kv()


# Generated at 2022-06-25 04:04:25.579855
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    # var_0 =
    parse_kv(bytes_0)


# Generated at 2022-06-25 04:04:31.273855
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    var_0 = parse_kv(bytes_0)


# Generated at 2022-06-25 04:04:39.847931
# Unit test for function parse_kv
def test_parse_kv():
    print('Starting unit test for function parse_kv:')
    print('good bytes:')
    bytes_0 = b'foo=bar bar=baz'
    print('In:', bytes_0)
    try:
        parsed_0 = parse_kv(bytes_0)
        print('Out:', parsed_0)
    except AnsibleParserError as err:
        print('Error:', err)
    print('good unicode:')
    unicode_0 = u'foo=bar bar=baz'
    print('In:', unicode_0)
    try:
        parsed_0 = parse_kv(unicode_0)
        print('Out:', parsed_0)
    except AnsibleParserError as err:
        print('Error:', err)
    print('bad bytes:')
    bytes_0

# Generated at 2022-06-25 04:04:41.589655
# Unit test for function parse_kv

# Generated at 2022-06-25 04:04:48.480571
# Unit test for function split_args

# Generated at 2022-06-25 04:04:52.328093
# Unit test for function parse_kv
def test_parse_kv():
    import sys

    # Test 1:
    # args = 'a=b c="1 2" d=\'1 2\''
    # expected_output = {'a': 'b', 'c': '1 2', 'd': '1 2'}
    args = 'a=b c="1 2" d=\'1 2\''
    expected_output = {'a': b'b', 'c': b'1 2', 'd': b'1 2'}
    actual_output = parse_kv(args)
    assert actual_output == expected_output

    # Test 2:
    # args = 'a=b c="1 2" d=\'1 2\''
    # expected_output = {'a': 'b', 'c': '1 2', 'd': '1 2'}

# Generated at 2022-06-25 04:05:01.022214
# Unit test for function parse_kv
def test_parse_kv():
    element_0 = generate_bytes(4)
    assert_equal(parse_kv(element_0, true), unquote(element_0))

    element_1 = generate_bytes(random.randint(2, 3))
    var_7 = generate_bytes(random.randint(3, 4))
    var_8 = var_7 + element_1
    assert_equal(parse_kv(var_8, true), unquote(var_8))

    element_2 = generate_bytes(random.randint(3, 4))
    assert_equal(parse_kv(element_2), unquote(element_2))

    element_3 = generate_bytes(random.randint(2, 3))
    var_9 = generate_bytes(random.randint(2, 3))

# Generated at 2022-06-25 04:05:07.354117
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('key=value') == {'key': 'value'}
    assert parse_kv('key=value key=value') == {'key': 'value key=value'}
    assert parse_kv('key=value,key=value') == {'key': 'value,key=value'}
    assert parse_kv('key=value key=value') == {'key': 'value key=value'}
    assert parse_kv('key="value value"') == {'key': 'value value'}
    assert parse_kv('key=value value') == {'key': 'value', '_raw_params': 'value'}
    assert parse_kv('key=value,value') == {'key': 'value,value'}

# Generated at 2022-06-25 04:05:16.413115
# Unit test for function split_args
def test_split_args():
    print("in test_split_args")

    tokens_0 = ['"', 'a', '=', 'b', '"', '=', '1', ' ', '"', 'c', '=', 'd', '"', '=', '2']
    tokens_1 = ["'a", '=', 'b', "'", ' ', '=', '1', ' ', '\'c', '=', 'd\'', '=', '2']
    tokens_2 = ["'a", '=', 'b\'', ' ', '\'c', '=', 'd\'', '=', '2']

    for tokens in [tokens_0, tokens_1, tokens_2]:
        print('tokens: {}'.format(tokens))

# Generated at 2022-06-25 04:05:24.412885
# Unit test for function parse_kv
def test_parse_kv():
    '''
    String of key/value items to a dict. If any free-form params
    are found and the check_raw option is set to True, they will be added
    to a new parameter called '_raw_params'. If check_raw is not enabled,
    they will simply be ignored.
    '''
    var_0 = parse_kv(b'arg1=foo arg2="bar baz"')

    var_0[u'arg2'] == 'bar baz'
    var_0[u'arg1'] == 'foo'


# Generated at 2022-06-25 04:05:35.892593
# Unit test for function split_args

# Generated at 2022-06-25 04:05:46.292418
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    var_0 = parse_kv(bytes_0)
    assert (var_0 == {None: None})
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    var_1 = parse_kv(bytes_0)
    assert (var_1 == {None: None})

if (__name__ == '__main__'):
    test_parse_kv()
    test_case_0()

# Generated at 2022-06-25 04:05:47.189545
# Unit test for function parse_kv
def test_parse_kv():
    assert callable(parse_kv)


# Generated at 2022-06-25 04:05:51.119769
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('=') == {u'': u''}
    assert parse_kv('a=b') == {u'a': u'b'}
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=d f=') == {u'a': u'b', u'c': u'd', u'f': u''}
    assert parse_kv('a=b c=d f= ') == {u'a': u'b', u'c': u'd', u'f': u''}

# Generated at 2022-06-25 04:06:00.689932
# Unit test for function parse_kv
def test_parse_kv():
    # rsa
    rsa_p = 16747512243021002868195572857617351288238924007739200584660566150129851039688641
    rsa_q = 1426673097112658981455955036040404059003402753295375481360731515828687945103179
    rsa_e = 65537


# Generated at 2022-06-25 04:06:12.532995
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    var_0 = parse_kv(bytes_0)
    bytes_1 = b'\x08r;\x03\x01\x8e\x9c*_\x04\xb2\xf3'
    var_1 = parse_kv(bytes_1)
    bytes_2 = b'\x0f\x8e\x94\xcf\xda\x1a\xb2\xf7\x00\x0c\xa9\x9a\xb0\x8d\x10\x01w\xc6\x0c\x16\xf9'
    var_

# Generated at 2022-06-25 04:06:26.810456
# Unit test for function parse_kv
def test_parse_kv():
    case_0 = {'_raw_params' : '`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'}
    test(case_0, b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*', True)

# Module level test for function parse_kv
test_parse_kv()


# Generated at 2022-06-25 04:06:30.530153
# Unit test for function split_args
def test_split_args():
    array_0 = [b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*']
    array_1 = split_args(array_0)


# Generated at 2022-06-25 04:06:39.171958
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    assert_0 = parse_kv(bytes_0)
    #assert assert_0[u'_raw_params'] == b'foobar=\\'


# Generated at 2022-06-25 04:06:43.318463
# Unit test for function split_args
def test_split_args():
    """
    Test case for function split_args.
    """
    # Input
    args = "a=b c='foo bar'"

    # output
    result = split_args(args)
    assert result

if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 04:06:49.064264
# Unit test for function parse_kv
def test_parse_kv():
    # check that the parser is able to handle parsing a unicode string
    # with unicode escape sequences
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    var_0 = parse_kv(bytes_0)

    assert var_0.get(u"_raw_params") == u'`(\xdff'

    # check that the parser is able to handle parsing a unicode string
    # with unicode escape sequences
    bytes_1 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'

# Generated at 2022-06-25 04:06:53.270678
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x80'
    var_0 = parse_kv(bytes_0)



# Generated at 2022-06-25 04:07:03.791900
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('a') == ['a']
    assert split_args('a b') == ['a', 'b']
    assert split_args('a "b c"') == ['a', '"b c"']
    assert split_args('a "b c" d') == ['a', '"b c"', 'd']
    assert split_args('a "b c" d e') == ['a', '"b c"', 'd', 'e']
    assert split_args('a \"b c\" d e') == ['a', '"b c"', 'd', 'e']
    assert split_args('a \"b \dc\" d e') == ['a', '"b \dc"', 'd', 'e']

# Generated at 2022-06-25 04:07:15.289148
# Unit test for function parse_kv
def test_parse_kv():
    x = 'foo=bar key=val arg="with space" escaped="quote=foo"'
    assert parse_kv(x) == {u'foo': u'bar',
                           u'key': u'val',
                           u'arg': u'with space',
                           u'escaped': u'quote=foo',
                           u'_raw_params': u'foo=bar key=val arg="with space" escaped="quote=foo"'}

    x = 'foo=bar key=val arg="with space" escaped="quote=\\"foo\\""'

# Generated at 2022-06-25 04:07:25.829755
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    if sys.version_info[0] < 3 and not isinstance(bytes_0, str):
        bytes_0 = bytes_0.decode()
    assert '*d' == split_args(bytes_0)[0]
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 04:07:33.947168
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv(b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*')
    print(result)

# Boilerplate code
if __name__ == '__main__':
    test_case_0()
    test_parse_kv()

# Generated at 2022-06-25 04:07:47.806921
# Unit test for function split_args
def test_split_args():
    # Test option '--foo bar'
    # {'foo': 'bar'}
    cmd = b'--foo bar'
    print("cmd = '%s'" % (cmd,))

    print("split_args(cmd) => ")
    args = split_args(cmd)
    print(args)

    print("parse_kv(cmd)  => ")
    var = parse_kv(cmd)
    print(var)
    print("-" * 50)

    # Test option '--foo "bar baz"'
    # {'foo': 'bar baz'}
    cmd = b'--foo "bar baz"'
    print("cmd = '%s'" % (cmd,))

    print("split_args(cmd) => ")
    args = split_args(cmd)
    print(args)

   

# Generated at 2022-06-25 04:08:00.657307
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'item1=value1 item2=value2 item3=value3'

    var_0 = parse_kv(bytes_0)
    assert (len(var_0) == 3)
    assert (var_0['item1'] == 'value1')
    assert (var_0['item2'] == 'value2')
    assert (var_0['item3'] == 'value3')

    bytes_1 = b'item1=value1 item2="value2 is a long string" item3=value3 item4="item4 is a value with a single quote (\') and a double quote (\")"'
    var_1 = parse_kv(bytes_1)
    assert (len(var_1) == 4)
    assert (var_1['item1'] == 'value1')

# Generated at 2022-06-25 04:08:02.735863
# Unit test for function parse_kv
def test_parse_kv():
    assert 0



# Generated at 2022-06-25 04:08:14.451433
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=bar') == {u'foo': u'bar', u'baz': u'bar'}
    assert parse_kv('foo=bar baz=bar quux=foo') == {u'foo': u'bar', u'baz': u'bar', u'quux': u'foo'}
    assert parse_kv('foo=bar baz=bar quux=foo') == {u'foo': u'bar', u'baz': u'bar', u'quux': u'foo'}

# Generated at 2022-06-25 04:08:16.956857
# Unit test for function split_args
def test_split_args():
    result = split_args(u'a=b c="foo bar"')
    assert result == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 04:08:17.599925
# Unit test for function parse_kv
def test_parse_kv():
    assert True



# Generated at 2022-06-25 04:08:27.853593
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv('`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*') # TypeError: ord() expected string of length 1, but int found --> False Positive
    var_1 = parse_kv('`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*', '`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*') # TypeError: ord() expected string of length 1, but int found --> False Positive

# Generated at 2022-06-25 04:08:34.341971
# Unit test for function split_args
def test_split_args():
    try:
        # make sure that the arg string is eventually unquoted back to the original string
        # in this case, the module parameters are escaped properly and the shell/command
        # module will split them again when it executes the module
        test_case_0()
    except AnsibleParserError as e:
        if 'no closing quotation' not in str(e).lower():
            raise

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:08:45.397904
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv(b'_raw_params="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null" url=https://infra.example.com/pdb/apps/nginx/ansible/update-config.sh')
    assert 'url' in var_0
    assert var_0['url'] == 'https://infra.example.com/pdb/apps/nginx/ansible/update-config.sh'
    assert '_raw_params' in var_0
    assert var_0['_raw_params'] == '-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null'


# Generated at 2022-06-25 04:08:52.989779
# Unit test for function parse_kv
def test_parse_kv():
    import random
    import string
    
    # From: StackOverflow
    ex_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'

# Generated at 2022-06-25 04:09:05.863660
# Unit test for function split_args
def test_split_args():
    # Case 0
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    var_0 = split_args(bytes_0)
    assert var_0[0] == '`(d[Nd*'


# Generated at 2022-06-25 04:09:11.921580
# Unit test for function split_args
def test_split_args():
    test_str = 'a=b c="foo bar"'
    parsed_args = split_args(test_str)
    assert parsed_args == ['a=b', 'c="foo bar"']

    test_str = 'a=b "foo bar" c="baz quux"'
    parsed_args = split_args(test_str)
    assert parsed_args == ['a=b', '"foo bar"', 'c="baz quux"']

    test_str = 'a=b "foo bar" c="baz quux" \\ d=e \\'
    parsed_args = split_args(test_str)
    assert parsed_args == ['a=b', '"foo bar"', 'c="baz quux" d=e']


# Generated at 2022-06-25 04:09:15.472594
# Unit test for function parse_kv
def test_parse_kv():
    # print('type of var_0 : ' + str(type(var_0)))
    assert True == True


# Generated at 2022-06-25 04:09:22.523934
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    var_0 = parse_kv(bytes_0)
    test_case_0()

if __name__ == "__main__":
    test_parse_kv()

# Generated at 2022-06-25 04:09:23.653777
# Unit test for function parse_kv
def test_parse_kv():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 04:09:36.922289
# Unit test for function parse_kv

# Generated at 2022-06-25 04:09:48.056045
# Unit test for function split_args
def test_split_args():
    '''
    Tests for function split_args
    '''
    # no args
    assert split_args('') == []
    # simple args
    assert split_args('a=b') == ['a=b']
    # args with spaces
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    # args with newlines
    assert split_args('a=b\nc=d') == ['a=b', 'c=d']
    # args with spaces and newlines
    assert split_args('a=b c=d\ne=f') == ['a=b', 'c=d', 'e=f']
    # args with quotes
    assert split_args('a=b c="d e"') == ['a=b', 'c="d e"']
    # args

# Generated at 2022-06-25 04:09:53.527515
# Unit test for function parse_kv
def test_parse_kv():

    # str0 = 'cmd-bk-1.f"lks'
    # str0 = 'cmd-bk-1.f\nks'
    # str0 = 'cmd-bk-1.f\rks'
    str0 = 'cmd-bk-1.f\rks-'
    str0 = 'cmd-bk-1.f"f"ks'

    # var_0 = parse_kv(str0)
    var_0 = parse_kv(str0, False)

    # Unit test for function split_args
    def test_split_args():

        bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'

# Generated at 2022-06-25 04:10:02.874895
# Unit test for function parse_kv
def test_parse_kv():
    u_0_0 = b'\xea\x00\x01\x00'
    result = parse_kv(u_0_0)
    assert result == {u'_raw_params': b'\xea\x00\x01\x00'}

    u_1_0 = b'\xf6\xce\x99'
    result = parse_kv(u_1_0)
    assert result == {u'_raw_params': b'\xf6\xce\x99'}

    u_2_0 = b'\xea\x00\x01\x00'
    result = parse_kv(u_2_0)
    assert result == {u'_raw_params': b'\xea\x00\x01\x00'}

    u_3

# Generated at 2022-06-25 04:10:13.021041
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    var_0 = parse_kv(bytes_0)
    assert var_0 == {}

    bytes_1 = b'\xfa\x8f\x13\x87\xfc\xe1 \x8c\x19\xcc\xad\xdd%\xb8\xe9\x08\xc7\x1b\x1d\x8a\x15'
    var_1 = parse_kv(bytes_1)
    assert var_1 == {}


# Generated at 2022-06-25 04:10:22.361603
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'a=b c=d'
    bytes_1 = b'a=b c=d'
    vars_0 = parse_kv(bytes_0)
    assert vars_0 == {b'a': b'b', b'c': b'd'}
    vars_1 = parse_kv(bytes_1)
    assert vars_1 == {b'a': b'b', b'c': b'd'}

# Generated at 2022-06-25 04:10:31.497847
# Unit test for function split_args
def test_split_args():
    # Case 0
    test_split_args_case_0()
    # Case 1
    test_split_args_case_1()
    # Case 2
    test_split_args_case_2()
    # Case 3
    test_split_args_case_3()
    # Case 4
    test_split_args_case_4()
    # Case 5
    test_split_args_case_5()
    # Case 6
    test_split_args_case_6()


# Generated at 2022-06-25 04:10:40.830720
# Unit test for function split_args
def test_split_args():
    assert split_args(b"host={{host}} group={{group}}") == [b"host={{host}}", b"group={{group}}"]
    assert split_args(b"host={{host  }} group={{group}}") == [b"host={{host  }}", b"group={{group}}"]
    assert split_args(b"host={{  host  }} group={{group}}") == [b"host={{  host  }}", b"group={{group}}"]
    assert split_args(b"host={{  host  }} group={{  group  }}") == [b"host={{  host  }}", b"group={{  group  }}"]

# Generated at 2022-06-25 04:10:49.105282
# Unit test for function split_args
def test_split_args():
    args = """foo=bar creates=baz"""
    assert(split_args(args) == ['foo=bar', 'creates=baz'])
    args = "foo=bar creates=baz\nremoves=foo"
    assert(split_args(args) == ['foo=bar', 'creates=baz\nremoves=foo'])
    args = "foo=bar \"arg with spaces\" 1=2"
    assert(split_args(args) == ['foo=bar', '"arg with spaces" 1=2'])
    args = "foo=bar {{ ['foo', 'bar']|join('=') }} 1=2"
    assert(split_args(args) == ['foo=bar', "{{ ['foo', 'bar']|join('=') }}", '1=2'])

# Generated at 2022-06-25 04:10:57.359873
# Unit test for function split_args
def test_split_args():
    input_string1 = '''ansible_ssh_user=root ansible_become=true ansible_become_method=sudo ansible_become_user=root ansible_become_exe='/usr/bin/sudo' ansible_ssh_private_key_file=/var/lib/awx/.ssh/tower_rsa'''
    output_string1 = parse_kv(input_string1)
    print(output_string1)

    input_string2 = '''ansible_python_interpreter=/usr/bin/python3 ansible_ssh_host=192.168.1.233 ansible_ssh_pass=x ansible_ssh_port=22'''
    output_string2 = parse_kv(input_string2)
    print(output_string2)


# Generated at 2022-06-25 04:11:05.393233
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'`(\xdff\xb2\xb6\x03d[\x9b\xc9N\xaf\x9c\xad\xa4d\xf0*'
    expect_var = [b'`(\\xdff\\xb2', b'b6\\x03d[\\x9b', b'c9N\\xaf\\x9c', b'ad\\xa4d\\xf0*']
    result_var = split_args(bytes_0)
    print("split_args(", bytes_0, ")\n    ", expect_var, "-->", result_var, sep="")
