

# Generated at 2022-06-25 04:01:23.126807
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Generated at 2022-06-25 04:01:32.355802
# Unit test for function split_args
def test_split_args():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 04:01:38.108856
# Unit test for function split_args
def test_split_args():
    str_0 = 'a=b c="foo bar"'
    var_0 = split_args(str_0)
    assert var_0 == ['a=b', 'c="foo bar"']
    str_1 = '"foobar'
    var_1 = split_args(str_1)
    #assert var_1 == ['foobar']
    str_2 = "a=b c='foo bar' d='foo''bar' e=\"foo bar\" f=\"foo\"\"bar\""
    var_2 = split_args(str_2)
    assert var_2 == ['a=b', "c='foo bar'", "d='foo''bar'", 'e="foo bar"', 'f="foo""bar"']

# Generated at 2022-06-25 04:01:49.034208
# Unit test for function split_args
def test_split_args():
    var_1 = 'a=b c="foo bar"'
    var_0 = split_args(var_1)
    print(var_0)
    assert var_0 == ['a=b', 'c="foo bar"']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a="b c" d=e') == ['a="b c"', 'd=e']
    assert split_args('a="b"c" d=e') == ['a="b"c"', 'd=e']
    assert split_args('a=b"c d=e') == ['a=b"c', 'd=e']

# Generated at 2022-06-25 04:01:57.173023
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    expected_output = ['a=b', 'c="foo bar"']
    result = split_args(args)
    if result != expected_output:
        print("error, result is %s" % result)
    else:
        print("unit test passed")

    args = 'a=b c="foo bar" d="{{["foo"]}}"'
    expected_output = ['a=b', 'c="foo bar"', 'd="{{["foo"]}}"']
    result = split_args(args)

    if result != expected_output:
        print("error, result is %s" % result)
    else:
        print("unit test passed")

    args = 'a=b c="foo bar" d="{{["foo"]"}}"'

# Generated at 2022-06-25 04:02:04.705762
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 's3://elasticbeanstalk-us-west-2-016204785234/my_sample_application/148957785268/MySampleApplication-dev.zip?versionId=mT7g0TkOaV1QHlmlcpFVtgB3qg4c4y2t'
    var_0 = parse_kv(str_0)
    if '_raw_params' in var_0:
        assert False

    str_0 = 'foo=bar'
    var_0 = parse_kv(str_0)
    if var_0.get('foo') != u'bar':
        assert False

    str_0 = 'foo="bar"'
    var_0 = parse_kv(str_0)

# Generated at 2022-06-25 04:02:06.236377
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 04:02:17.453311
# Unit test for function split_args
def test_split_args():
    ## case 0
    str_0 = '>"kT#kmm8Qo5$K'
    var_0 = split_args(str_0)
    assert var_0 == ['"kT#kmm8Qo5$K']

    ## case 1
    str_1 = '>u(Q@"Vd;i=&'
    var_1 = split_args(str_1)
    assert var_1 == ['u(Q@"Vd;i=&']

    ## case 2
    str_2 = '>f_F?2'
    var_2 = split_args(str_2)
    assert var_2 == ['f_F?2']

    ## case 3
    str_3 = '>g4;%c'
    var_3 = split_args(str_3)


# Generated at 2022-06-25 04:02:28.183428
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ["a=b", "c=\"foo bar\""]
    assert split_args("a=b 'c=foo bar'") == ["a=b", "'c=foo bar'"]
    assert split_args("a=b c='foo bar'") == ["a=b", "c='foo bar'"]
    assert split_args("a=b 'c=foo bar") == ["a=b", "'c=foo bar"]
    assert split_args("a=b \"c=foo bar") == ["a=b", "\"c=foo bar"]
    assert split_args("a=b \"c=foo bar") == ["a=b", "\"c=foo bar"]

# Generated at 2022-06-25 04:02:38.236075
# Unit test for function split_args
def test_split_args():
    print("\nTest 0: \n")
    str_0 = ''
    str_1 = '>'
    str_2 = "\"kT#kmm8Qo5$K"
    str_3 = '"kT#kmm8Qo5$K"'
    str_4 = 'kT#kmm8Qo5$K>'
    str_5 = 'kT#kmm8Qo5$K\\'
    str_6 = 'kT#kmm8Qo5$K'
    str_7 = 'bT#bmm8Qo5$K>'
    str_8 = 'kT#kmm8Qo5$K"'
    str_9 = 'kT#kmm8Qo5$K'\
    '>'

# Generated at 2022-06-25 04:03:05.629098
# Unit test for function split_args
def test_split_args():
    try:
        str_0 = '>"kT#kmm8Qo5$K'
        var_0 = split_args(str_0)
        #assert(var_0 == False)
        print('test_split_args OK')
    except AssertionError as e:
        print('test_split_args NG')

    try:
        str_0 = 'F&Ov@x'
        var_0 = split_args(str_0)
        #assert(var_0 == True)
        print('test_split_args OK')
    except AssertionError as e:
        print('test_split_args NG')


# Generated at 2022-06-25 04:03:12.820956
# Unit test for function split_args
def test_split_args():
    # match official works
    example_1 = "a=b c='d'"
    assert split_args(example_1) == ['a=b', "c='d'"]

    # doc example
    example_2 = "a=b c='foo bar'"
    assert split_args(example_2) == ['a=b', "c='foo bar'"]

    # various works
    ex_3 = "a b=c"
    assert split_args(ex_3) == ["a", "b=c"]

    ex_4 = "a=b c"
    assert split_args(ex_4) == ["a=b", "c"]

    ex_5 = "a=b c=d"
    assert split_args(ex_5) == ["a=b", "c=d"]


# Generated at 2022-06-25 04:03:13.754088
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:03:24.041780
# Unit test for function split_args
def test_split_args():
    print("==========\nStarting test single quote")
    print("Test case 0")
    str_0 = "this is a split"
    var_0 = split_args(str_0)
    print(var_0)
    print("Finished testing case 0\n==========")

    print("Test case 1")
    str_1 = "this \\\nis a split"
    var_1 = split_args(str_1)
    print(var_1)
    print("Finished testing case 1\n==========")

    print("Test case 2")
    str_2 = "this is a \\\nsplit"
    var_2 = split_args(str_2)
    print(var_2)
    print("Finished testing case 2\n==========")

    print("Test case 3")
    str_3

# Generated at 2022-06-25 04:03:32.948586
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing parse_kv()')

    # Exception raised
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()

# Generated at 2022-06-25 04:03:33.526812
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Generated at 2022-06-25 04:03:34.974381
# Unit test for function split_args
def test_split_args():
    assert split_args(u'abc') == [u'abc']


# Test for function split_args with a comment

# Generated at 2022-06-25 04:03:43.923522
# Unit test for function split_args
def test_split_args():
    print('Testing split_args...', end='')
    assert(split_args('-p 8080 -x 127.0.0.1') == ['-p', '8080', '-x', '127.0.0.1'])
    assert(split_args('-p 8080 -x "127.0.0.1"') == ['-p', '8080', '-x', '"127.0.0.1"'])
    assert(split_args("-p 8080 -x '127.0.0.1'") == ['-p', '8080', '-x', "'127.0.0.1'"])
    assert(split_args("-p 8080 -x 'foo bar'") == ['-p', '8080', '-x', "'foo bar'"])

# Generated at 2022-06-25 04:03:55.300456
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'x=3 y="a b" z="a=b"'
    var_0 = parse_kv(str_0, True)
    str_1 = 'creates=/tmp/file'
    var_1 = parse_kv(str_1, False)
    str_2 = 'creates=/tmp/file'
    var_2 = parse_kv(str_2, True)
    str_3 = 'creates=/tmp/file rm'
    var_3 = parse_kv(str_3, True)
    str_4 = 'a="b c"'
    var_4 = parse_kv(str_4, True)
    str_5 = 'x=3 y="a b" z="a=b"'
    var_5 = parse_kv(str_5, False)


# Generated at 2022-06-25 04:03:56.181286
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 04:04:09.932728
# Unit test for function split_args
def test_split_args():
    try:
        assert split_args('"a=b c=d" e="f g"') == ['a=b c=d', 'e="f g"']
        assert split_args(u'a=b c=d e="f g"') == ['a=b', 'c=d', u'e="f g"']
        #test_case_0()
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 04:04:20.374065
# Unit test for function parse_kv
def test_parse_kv():
    print("Test for function parse_kv")
    str_0 = '>\"kT#kmm8Qo5$K'
    assert parse_kv(str_0, check_raw=True) == {'_raw_params': '>"kT#kmm8Qo5$K'}
    str_1 = '>#O\'xt=B;'
    assert parse_kv(str_1, check_raw=True) == {'_raw_params': '>#O\'xt=B;'}
    str_2 = '> Hf+J!'
    assert parse_kv(str_2, check_raw=True) == {'_raw_params': '> Hf+J!'}
    str_3 = '>b)#[w-z4]0'
    assert parse_kv

# Generated at 2022-06-25 04:04:31.385584
# Unit test for function split_args
def test_split_args():
    str_0 = "a=b"
    var_0 = split_args(str_0)
    assert(len(var_0) == 1)
    assert(var_0[0] == "a=b")

    str_1 = "a=b c=d"
    var_1 = split_args(str_1)
    assert(len(var_1) == 2)
    assert(var_1[0] == "a=b")
    assert(var_1[1] == "c=d")

    str_2 = "a=b c=d\ne=f"
    var_2 = split_args(str_2)
    assert(len(var_2) == 3)
    assert(var_2[0] == "a=b")

# Generated at 2022-06-25 04:04:34.807667
# Unit test for function parse_kv
def test_parse_kv():
    # As for now, test cases are not implemented.
    # If the function is simple and contains no complex branching,
    # a return value can be used as the test case.
    # For more complicated functions, a set of test cases can be
    # written.
    pass


# Generated at 2022-06-25 04:04:37.558832
# Unit test for function split_args
def test_split_args():
    print('Executing unit test for function split_args')
    test_case_0()

# Execute unit tests when this script runs
if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:04:43.346419
# Unit test for function parse_kv
def test_parse_kv():
    # Test var_0
    str_0 = '>"kT#kmm8Qo5$K'
    var_0 = split_args(str_0)
    print(len(var_0))
    print(var_0)
    str_1 = '-d "\"kT#kmm8Qo5$K\""'
    str_2 = '-d \'"kT#kmm8Qo5$K"\''
    var_1 = {u'_raw_params': str_1, u'd': u'"kT#kmm8Qo5$K"'}
    var_2 = {u'_raw_params': str_2, u'd': u'"kT#kmm8Qo5$K"'}

# Generated at 2022-06-25 04:04:46.173795
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 04:04:54.480995
# Unit test for function split_args
def test_split_args():
    var_1 = '> "kT#kmm8Qo5$K'
    var_2 = split_args(var_1)
    var_3 = '{{ playbook_dir }}'
    var_4 = '{{ foo }}'
    var_5 = '{{ playbook_dir }}/{{ foo }}'
    var_6 = split_args(var_5)
    print(var_6)
    var_7 = '"{{ playbook_dir }}/{{ foo }}"'
    var_8 = split_args(var_7)
    print(var_8)
    var_9 = '"{{ playbook_dir }}/{{ foo }}"'
    var_10 = '{{ item.name }}'
    var_11 = '"{{ playbook_dir }}/{{ foo }}" {{ item.name }}'
    var_12 = split

# Generated at 2022-06-25 04:05:00.462265
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '"[KEY]=[VALUE]"'
    dict_0 = dict(KEY='[VALUE]')
    assert parse_kv(str_0) == dict_0

    str_1 = '"[KEY_0]=[VALUE_0] [KEY_1]=[VALUE_1]"'
    dict_1 = dict(KEY_0 = '[VALUE_0]', KEY_1 = '[VALUE_1]')
    assert parse_kv(str_1) == dict_1

    str_2 = '"[KEY]=[VALUE1] [VALUE2]"'
    dict_2 = dict(KEY='[VALUE1] [VALUE2]')
    assert parse_kv(str_2) == dict_2

    str_3 = '"[KEY]=\"[VALUE1] [VALUE2]\""'

# Generated at 2022-06-25 04:05:07.047596
# Unit test for function parse_kv
def test_parse_kv():
    assert split_args('"a=1 b=2"') == ['a=1 b=2']
    assert split_args(r'"a=1 b=2\"') == ['a=1 b=2"']
    assert split_args(r'"a=1 b=2\" c=1"') == ['a=1 b=2"', 'c=1']

    # FIXME: this test case not pass
    #assert split_args(r'"a=1 b=2\" c=1') == ['a=1 b=2"', 'c=1']

    assert split_args(r'"a=1 b=2\" c=1" d=1') == ['a=1 b=2"', 'c=1', 'd=1']

# Generated at 2022-06-25 04:05:20.428525
# Unit test for function split_args
def test_split_args():
    str = '''a=b c="foo bar"'''
    ret = split_args(str)
    print(ret)


# Generated at 2022-06-25 04:05:26.171537
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\' d=\'{"hello other world",foo}') == ['a=b', 'c="foo bar\'', 'd=\'{"hello other world",foo}']


# Generated at 2022-06-25 04:05:27.732879
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ["a=b", "c=\"foo bar\""]



# Generated at 2022-06-25 04:05:30.997649
# Unit test for function split_args
def test_split_args():
    print("#### Testing split_args")
    print("#### Test case 0")
    test_case_0()

test_split_args()

# Generated at 2022-06-25 04:05:32.528752
# Unit test for function parse_kv
def test_parse_kv():
    try:
        test_case_0()
    except:
        pass


# Generated at 2022-06-25 04:05:44.281264
# Unit test for function split_args
def test_split_args():

    #str = 'a=b c="foo bar" d="x=\"hello\" y=\\"world\\"" e="\\"single quote\\""'
    str_0 = 'a=b c="foo bar" d="x=\"hello\" y=\\"world\\"" e="\\"single quote\\""'
    results_0 = ['a=b', 'c="foo bar"', 'd="x=\\"hello\\" y=\\\\\\"world\\\\\\""', 'e="\\\\"single quote\\\\""']

    str_1 = ""
    results_1 = []

    str_2 = " "
    results_2 = []

    str_3 = 'a="b b" d="c c" '
    results_3 = ['a="b b"', 'd="c c"']

    str_4 = '"\\""'


# Generated at 2022-06-25 04:05:53.728374
# Unit test for function split_args
def test_split_args():
    str_0 = r'ansible-playbook playbook.yml -i inventory -v'
    str_1 = r'ansible-playbook playbook.yml -i inventory -v -e "ansible_ssh_user=test"'
    str_2 = r'ansible-playbook playbook.yml -i inventory -v -e "ansible_ssh_user=test" --extra-var="ansible_ssh_private_key=~/.ssh/id_rsa"'
    str_3 = r'ansible-playbook playbook.yml -i inventory -v -e "ansible_ssh_user=test" --extra-var="ansible_ssh_private_key=~/.ssh/id_rsa" -e "ansible_python_interpreter=/opt/ansible-2.4.4.0/bin/python"'
   

# Generated at 2022-06-25 04:06:01.213664
# Unit test for function parse_kv
def test_parse_kv():
    # print("parse_kv('\\u00a4\\u00a4')", parse_kv('\\u00a4\\u00a4'))
    print("parse_kv('\\u00A3\\u00A3')", parse_kv('\\u00A3\\u00A3'))
    print("parse_kv('\\U0000A3\\U0000A3')", parse_kv('\\U0000A3\\U0000A3'))
    print("parse_kv('\\N{DOLLAR SIGN}\\N{DOLLAR SIGN}')", parse_kv('\\N{DOLLAR SIGN}\\N{DOLLAR SIGN}'))
    print("parse_kv('\\U00000000')", parse_kv('\\U00000000'))

# Generated at 2022-06-25 04:06:08.970095
# Unit test for function split_args
def test_split_args():
    str_0 = 'a=b c="foo bar"'
    var_0 = split_args(str_0)
    print(var_0)
    assert var_0 == ['a=b', 'c="foo bar"']

    str_1 = 'a="b c" d=e'
    var_1 = split_args(str_1)
    print(var_1)
    assert var_1 == ['a="b c"', 'd=e']

    str_2 = 'a="b c" d="e" f=g'
    var_2 = split_args(str_2)
    print(var_2)
    assert var_2 == ['a="b c"', 'd="e"', 'f=g']

    str_3 = 'a=b c=d "foo bar"'
    var

# Generated at 2022-06-25 04:06:15.385577
# Unit test for function split_args
def test_split_args():
    test_0 = 'ansible-playbook -D -i /etc/ansible/hosts /etc/ansible/playbooks/playbook.yml --vault-id /etc/ansible/vault_pass.txt'
    test_ans_0 = split_args(test_0)
    assert(test_ans_0 == ['ansible-playbook', '-D', '-i', '/etc/ansible/hosts', '/etc/ansible/playbooks/playbook.yml', '--vault-id', '/etc/ansible/vault_pass.txt'])


# Generated at 2022-06-25 04:06:23.496536
# Unit test for function parse_kv
def test_parse_kv():
    assert type(parse_kv('<[\\2w8{')) == dict


# Generated at 2022-06-25 04:06:29.622063
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing function: parse_kv')
    # Basic test
    print('Basic test')
    str_0 = '<[\\2w8{'
    var_0 = parse_kv(str_0)
    print(var_0)

    # Basic test
    print('Basic test')
    str_0 = '<[\\2w8{"'
    var_0 = parse_kv(str_0)
    print(var_0)

    # Basic test
    print('Basic test')
    str_0 = '<[\\2w8{"'
    var_0 = parse_kv(str_0)
    print(var_0)

    # Basic test
    print('Basic test')
    str_0 = '<[\\2w8{"'

# Generated at 2022-06-25 04:06:37.312103
# Unit test for function parse_kv
def test_parse_kv():
    # Test cases
    str_0 = ':!=!8wF '
    str_1 = 'A9{vO8fL '
    str_2 = '<q4v'
    str_3 = 'Yg=f ]L'
    var_0 = parse_kv(str_0)
    var_1 = parse_kv(str_1)
    var_2 = parse_kv(str_2)
    var_3 = parse_kv(str_3)



# Generated at 2022-06-25 04:06:40.429758
# Unit test for function split_args
def test_split_args():
    test_case_0()
    #test_case_1()
    #test_case_2()
    #test_case_3()



# Generated at 2022-06-25 04:06:43.138294
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'Hello World'
    var_0 = parse_kv(str_0)



# Generated at 2022-06-25 04:06:47.113442
# Unit test for function split_args
def test_split_args():
    # Case 0
    str_0 = '--check --verbose'
    expect_0 = ['--check', '--verbose']
    # print(split_args(str_0))
    assert split_args(str_0) == expect_0
    # Case 1
    str_1 = '--check -v'
    expect_1 = ['--check', '-v']
    # print(split_args(str_1))
    assert split_args(str_1) == expect_1



# Generated at 2022-06-25 04:06:51.751633
# Unit test for function split_args
def test_split_args():
    args = 'ansible_ssh_user=vagrant ansible_ssh_host=192.168.2.2 ansible_ssh_port=2222 ' \
           'ansible_ssh_pass=vagrant ansible_connection=ssh -m raw -a "yum install -y git"'
    result = [u'ansible_ssh_user=vagrant', u'ansible_ssh_host=192.168.2.2', u'ansible_ssh_port=2222', u'ansible_ssh_pass=vagrant', u'ansible_connection=ssh', u'-m', u'raw', u'-a', u'"yum install -y git"']
    assert list(split_args(args)) == result


# Generated at 2022-06-25 04:06:57.893472
# Unit test for function split_args
def test_split_args():
    str0 = '{{.\n.}}'
    str_0 = split_args(str0)
    assert str_0 == ['{{.', '.', '}}']

# Generated at 2022-06-25 04:07:01.187808
# Unit test for function split_args
def test_split_args():
    str_0 = 'ansible-test --version'
    var_0 = split_args(str_0)
    assert len(var_0) == 2
    assert var_0[0] == 'ansible-test'
    assert var_0[1] == '--version'


# Generated at 2022-06-25 04:07:11.426970
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ["a=b", "c=\"foo bar\""]
    assert split_args("a=b 'c=d'") == ['a=b', "'c=d'"]
    assert split_args("a=b 'c=d' 'e=f'") == ['a=b', "'c=d'", "'e=f'"]
    assert split_args("a='b c=d' 'e f'") == ["a='b c=d'", "'e f'"]
    assert split_args("a='b c=d' 'e=f'") == ["a='b c=d'", "'e=f'"]

# Generated at 2022-06-25 04:07:28.168732
# Unit test for function split_args
def test_split_args():
    args_0 = 'foo=bar'
    args_1 = 'foo="bar baz"'
    args_2 = 'foo="bar\\"baz"'
    args_3 = '''a=b c="foo bar"'''
    args_4 = '''a=b c="foo "bar" baz"'''
    args_5 = '''a=b c="foo"bar baz"'''
    args_6 = '''a=b c="foo\\
    bar baz"'''
    args_7 = '''a=b c="foo "bar
    baz"'''
    args_8 = '''a=b c="foo
    bar
    baz"'''
    args_9 = '''a=b c="foo 'bar'
    baz"'''

# Generated at 2022-06-25 04:07:29.556054
# Unit test for function split_args
def test_split_args():
    str_0 = '<[\\2w8{}]>'
    res_0 = split_args(str_0)


# Generated at 2022-06-25 04:07:37.036445
# Unit test for function split_args
def test_split_args():
    assert split_args('\.<[\\2w8{') == ['\.<[\\2w8{']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('"a=b" "c=d"') == ['"a=b"', '"c=d"']
    assert split_args('a=b "c=d"') == ['a=b', '"c=d"']
    assert split_args('"a=\\"b\\"" "c=d"') == ['"a=\\"b\\""', '"c=d"']
    assert split_args('"a=b" "c=d"') == ['"a=b"', '"c=d"']

# Generated at 2022-06-25 04:07:47.076354
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'chdir=dest=src creates=false removes=false'
    var_0 = parse_kv(str_0)
    assert 'chdir' in var_0 and var_0.get('chdir') is None, 'Failed to parse kv: %r' % var_0

    str_1 = u'a=b c=d'
    var_1 = parse_kv(str_1)
    assert 'a' in var_1 and 'c' in var_1, 'Failed to parse kv: %r' % var_1

    str_2 = u'a=b c="d"'
    var_2 = parse_kv(str_2)

# Generated at 2022-06-25 04:07:53.905250
# Unit test for function split_args
def test_split_args():
    str_0 = 'a=b c="foo bar"'
    list_0 = ['a=b', 'c="foo bar"']
    assert split_args(str_0) == list_0


# Generated at 2022-06-25 04:08:05.921482
# Unit test for function parse_kv
def test_parse_kv():
    input_0 = 'a=b\nc=d'
    output_0 = {u'a': u'b', u'c': u'd'}
    assert parse_kv(input_0) == output_0

    input_1 = 'a=b\nc'
    output_1 = {u'a': u'b', u'_raw_params': u'c'}
    assert parse_kv(input_1) == output_1

    input_2 = 'a="b = c"\nc=d'
    output_2 = {u'a': u'b = c', u'c': u'd'}
    assert parse_kv(input_2) == output_2

    input_3 = 'a="b=c \\" d"\nc=d'

# Generated at 2022-06-25 04:08:12.069842
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('A=1 a=2') == {'a': '2', 'A': '1'}
    assert parse_kv('A=1 a=2 C=3 c=4', True) == {'a': '2', 'A': '1', 'c': '4', 'C': '3'}
    assert parse_kv('A=1 a=2 C=3 c=4', False) == {'a': '2', 'A': '1', 'c': '4', 'C': '3'}
    assert parse_kv('A=1 "a=2 C=3" c=4', True) == {'_raw_params': '"a=2 C=3"', 'A': '1', 'c': '4'}

# Generated at 2022-06-25 04:08:19.789313
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'hL\\=)biw>1\\}"O\\}f9\\"4wi$\\'
    var_0 = parse_kv(str_0, False)
    assert var_0 == {u'_raw_params': u'hL\\=)biw>1\\}"O\\}f9\\"4wi$\\'}
    str_1 = 'vF_WVG\\{0!\\}\\\\\\'
    var_1 = parse_kv(str_1, False)
    assert var_1 == {u'_raw_params': u'vF_WVG\\{0!\\}\\\\\\'}
    str_2 = 'DK}S\\}G\\"`'
    var_2 = parse_kv(str_2, False)

# Generated at 2022-06-25 04:08:26.944952
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    test_string = u'{{ foo }}{{ bar }}'
    split_string = split_args(test_string)
    assert isinstance(split_string[0], AnsibleUnsafeText)
    assert isinstance(split_string[1], AnsibleUnsafeText)
    assert split_string == ["{{", "foo", "}}{{", "bar", "}}"]


# Generated at 2022-06-25 04:08:36.936046
# Unit test for function split_args
def test_split_args():
    # normal test case
    str_1 = 'a=b c="foo bar"'
    ret_1 = split_args(str_1)
    assert ret_1 == ['a=b', 'c="foo bar"']

    # test case with backslash
    str_2 = 'c="foo\\ bar"'
    ret_2 = split_args(str_2)
    assert ret_2 == ['c="foo\\ bar"']

    # test case with space inside quotes
    str_3 = 'c="foo bar"'
    ret_3 = split_args(str_3)
    assert ret_3 == ['c="foo bar"']

    # test case with json
    str_4 = 'c=\'{"foo": [{"bar", 1, 2, 3}]}\''

# Generated at 2022-06-25 04:08:45.723268
# Unit test for function split_args
def test_split_args():
    # Case 0
    test_case_0()


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:08:52.169404
# Unit test for function split_args
def test_split_args():
    print('========================Start test_split_args======================')
    str_0 = '"<[\\2w8{"'
    print(split_args(str_0))
    str_0 = '<[\\2w8{'
    print(split_args(str_0))
    str_0 = '<[\\2w8]'
    print(split_args(str_0))
    str_0 = '['
    print(split_args(str_0))
    str_0 = '<234{test}'
    print(split_args(str_0))
    print('========================END test_split_args========================')


# Generated at 2022-06-25 04:08:56.729054
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '\\new\\line'
    var_0 = parse_kv(str_0)
    str_1 = '.<[\\2w8{'
    var_1 = parse_kv(str_1)
    str_2 = '_\\U00f2U6\\'
    var_2 = parse_kv(str_2)
    str_3 = '\\U00f2U6\\'
    var_3 = parse_kv(str_3)
    str_4 = '\\f00,\\n'
    var_4 = parse_kv(str_4)
    str_5 = '\\U00f2U6'
    var_5 = parse_kv(str_5)
    str_6 = '\\U00f2U6'

# Generated at 2022-06-25 04:08:58.776376
# Unit test for function split_args
def test_split_args():
    print("Running split_args test case 0")
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:09:09.287369
# Unit test for function split_args
def test_split_args():
    case_0 = '.'
    param_0 = split_args(case_0)
    print("Result: %s" % (param_0))

    case_1 = '.[1]'
    param_1 = split_args(case_1)
    print("Result: %s" % (param_1))

    case_2 = '.[1,2]'
    param_2 = split_args(case_2)
    print("Result: %s" % (param_2))

    case_3 = '.[1, 2]'
    param_3 = split_args(case_3)
    print("Result: %s" % (param_3))

    case_4 = '.{1}'
    param_4 = split_args(case_4)
    print("Result: %s" % (param_4))

   

# Generated at 2022-06-25 04:09:17.448073
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('a=') == {'a': ''}
    assert parse_kv('a=1') == {'a': '1'}
    assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a="1 b=2"') == {'a': '"1 b=2"'}
    assert parse_kv('a=\'1 b=2\'') == {'a': "1 b=2"}
    assert parse_kv('a="1" b=2') == {'a': '"1"', 'b': '2'}

# Generated at 2022-06-25 04:09:19.143389
# Unit test for function split_args
def test_split_args():
    print('Test case 0: ')
    test_case_0()


# Generated at 2022-06-25 04:09:25.940721
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Perform unit tests if run as a script
if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 04:09:35.146196
# Unit test for function parse_kv
def test_parse_kv():
    inputs = ['no=params', 'single=param', 'first=param second_param', 'first=param second=param']
    outputs = [ {}, {'single': 'param'}, {'first': 'param', '_raw_params': 'second_param'}, {'first': 'param', 'second': 'param'} ]
    for i, input in enumerate(inputs):
        if parse_kv(input) != outputs[i]:
            raise Exception('Test case failed for input = ' + input)


# Generated at 2022-06-25 04:09:44.006637
# Unit test for function split_args
def test_split_args():
    str_0 = 'i=5'
    var_0 = split_args(str_0)
    print(var_0)
    str_1 = 'i = 5'
    var_1 = split_args(str_1)
    print(var_1)
    str_2 = '''i=5
               j=6
               l=7'''
    var_2 = split_args(str_2)
    print(var_2)
    str_3 = '''i=5
               j=6
               l=7
               '''
    var_3 = split_args(str_3)
    print(var_3)


if __name__ == '__main__':
    # test_case_0()
    test_split_args()

# Generated at 2022-06-25 04:10:00.916198
# Unit test for function split_args
def test_split_args():
    # check no error
    assert split_args('m0y=3Jjq=W41') == ['m0y=3Jjq=W41']
    assert split_args('\\') == ['\\']
    assert split_args('b') == ['b']
    assert split_args('xH') == ['xH']
    assert split_args('a') == ['a']
    assert split_args('.<[\\2w8{') == ['.<[\\2w8{']
    assert split_args('w<') == ['w<']
    assert split_args('3') == ['3']
    assert split_args('\\5') == ['\\5']
    assert split_args('.') == ['.']
    assert split_args('\\') == ['\\']

# Generated at 2022-06-25 04:10:10.977656
# Unit test for function split_args
def test_split_args():
    arg_string_1 = """
    \-a is the first argument
    \-f is the second argument
    \-x is the third argument
    """

    arg_string_2 = """
    '\'-a\' is the first argument'
    '\'-f\' is the second argument'
    '\'-x\' is the third argument'
    """

    arg_string_3 = """
    '\'-a\' is the first argument'
    '\'-f\' is the second argument'
    '\-x' is the third argument'
    """

    args = split_args(arg_string_1)
    if args[0] != '-a is the first argument':
        print('Test case 1 failed')
        exit(1)

# Generated at 2022-06-25 04:10:13.833870
# Unit test for function parse_kv
def test_parse_kv():
    print("Input string: {0}".format('<[\\2w8{'))
    print("Output dict: {0}".format(parse_kv('<[\\2w8{')))

    print("Input string: {0}".format("'"))
    print("Output dict: {0}".format(parse_kv("'")))



# Generated at 2022-06-25 04:10:22.805408
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'x-f0\n9'
    str_1 = ':\\B=:_S\\0\\M'
    str_2 = 'lN6Jn8gv'
    str_3 = '+Rr\\J}'
    str_4 = 'x-f0\n9'
    str_5 = ':\\B=:_S\\0\\M'
    str_6 = 'lN6Jn8gv'
    str_7 = '+Rr\\J}'
    var_0 = parse_kv(str_0)
    var_1 = parse_kv(str_1)
    var_2 = parse_kv(str_2)
    var_3 = parse_kv(str_3)

# Generated at 2022-06-25 04:10:31.081008
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar'), ['foo', 'bar']
    assert split_args('foo bar baz'), ['foo', 'bar', 'baz']
    assert split_args('foo="bar" baz'), ['foo=bar', 'baz']
    assert split_args('foo="bar" "baz'), ['foo=bar', '"baz']
    assert split_args('foo="bar" baz="foo bar"'), ['foo=bar', 'baz="foo bar"']
    assert split_args('foo="bar" baz="foo bar" blah'), ['foo=bar', 'baz="foo bar"', 'blah']
    assert split_args('foo="bar" baz="foo bar" blah="baz'), ['foo=bar', 'baz="foo bar"', 'blah="baz']
    assert split_

# Generated at 2022-06-25 04:10:42.949271
# Unit test for function split_args
def test_split_args():
    # Test a normal string
    args = 'openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout /etc/ssl/private/ansible.key -out /etc/ssl/certs/ansible.crt'
    result = split_args(args)
    assert len(result) == 10, 'Got %s instead of %s' % (len(result), 10)
    assert result[0] == 'openssl', 'Got %s instead of %s' % (result[0], 'openssl')
    assert result[1] == 'req', 'Got %s instead of %s' % (result[1], 'req')
    assert result[2] == '-x509', 'Got %s instead of %s' % (result[2], '-x509')

# Generated at 2022-06-25 04:10:54.236101
# Unit test for function parse_kv
def test_parse_kv():
    # Example:
    print(parse_kv('1=2 3="4" c="escaped \\"quote\\""'))
    # Example:
    print(parse_kv('creates=/tmp/file removes=/tmp/other_file', check_raw=True))


# The above examples assume that the code is executed from within the
# python-modules/files directory.  If you perform this test from any other
# directory, please replace the relative path with the absolute path.
if __name__ == '__main__':
    import sys
    import os
    sys.path.insert(1, os.path.join(sys.path[0], '../..'))
    import lib.ansible_test

# Generated at 2022-06-25 04:11:02.631433
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing function parse_kv')

    str_0 = '&6B|OF*'
    var_0 = parse_kv(str_0)

    # Testing if variable var_0 is equal to expected value '7d/:'
    var_0_expect = '7d/:'
    assert var_0 == var_0_expect, 'Expected {0}, got {1}'.format(var_0_expect, var_0)


# Generated at 2022-06-25 04:11:06.919232
# Unit test for function split_args
def test_split_args():
    a_str = ''''b=< c=&& "' d=\\\\' '''
    print(split_args(a_str))



if __name__ == '__main__':
    test_split_args()
    test_case_0()