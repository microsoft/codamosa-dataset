

# Generated at 2022-06-25 04:01:26.658344
# Unit test for function parse_kv

# Generated at 2022-06-25 04:01:32.820634
# Unit test for function parse_kv
def test_parse_kv():
    bytes_0 = b'\x87\x82A'
    var_0 = parse_kv(bytes_0)
    var_1 = parse_kv(None)
    bytes_1 = b'a=b'
    var_2 = parse_kv(bytes_1)
    bytes_2 = b'a="b"'
    var_3 = parse_kv(bytes_2)
    bytes_3 = b'a=b c=d'
    var_4 = parse_kv(bytes_3)
    bytes_4 = b'foo=bar'
    var_5 = parse_kv(bytes_4)


# Generated at 2022-06-25 04:01:37.030573
# Unit test for function parse_kv
def test_parse_kv():
    line = b'host=127.0.0.1 port=80'
    v = parse_kv(line)
    assert v[b'host'] == '127.0.0.1' and v[b'port'] == '80'

    line = b'host=127.0.0.1 port=80 user=dan'
    v = parse_kv(line)
    assert v[b'host'] == '127.0.0.1' and v[b'port'] == '80' and v[b'user'] == 'dan'

    line = b'host=127.0.0.1 port=80 user=dan   key="value with spaces"'
    v = parse_kv(line)

# Generated at 2022-06-25 04:01:48.929721
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv(u'a=1 b=2 c=3')
    assert(options[u'a'] == u'1')
    assert(options[u'b'] == u'2')
    assert(options[u'c'] == u'3')
    options = parse_kv(u'"foo bar"')
    assert(options[u'_raw_params'] == u'"foo bar"')
    options = parse_kv(u'foo bar')
    assert(options[u'_raw_params'] == u'foo bar')
    options = parse_kv(u'foo bar a=1 b=2 c=3')
    assert(options[u'_raw_params'] == u'foo bar')
    assert(options[u'a'] == u'1')

# Generated at 2022-06-25 04:01:54.332572
# Unit test for function split_args
def test_split_args():
    print("1")
    test_case_0()
    print("2")
    test_case_1()
    print("3")
    test_case_2()
    print("4")
    test_case_3()

# tests/helpers/module_utils/splitter.py:11: error: [Call to split_args]
#    test_case_0
#
#    [E901] SyntaxError parsing for ansible.module_utils.splitter: invalid syntax

# Generated at 2022-06-25 04:01:55.030206
# Unit test for function split_args
def test_split_args():
    test_case_0()



# Generated at 2022-06-25 04:02:02.245275
# Unit test for function parse_kv
def test_parse_kv():
    # Test case 0
    # TODO: Need to create a function call to test the output

    # Test case 1
    bytes_0 = b'\x87\x82A'
    test_case_0(bytes_0)



# Generated at 2022-06-25 04:02:06.439879
# Unit test for function parse_kv
def test_parse_kv():
    text = b"creates=/tmp/foo removes=/tmp/bar"
    output = parse_kv(text, check_raw=False)
    assert output[u'creates'] == u'/tmp/foo'
    assert output[u'removes'] == u'/tmp/bar'


# Generated at 2022-06-25 04:02:10.461343
# Unit test for function split_args
def test_split_args():
    test_case_0()

test_split_args()

# Generated at 2022-06-25 04:02:19.473804
# Unit test for function parse_kv
def test_parse_kv():

   # the function returns different values byt the type of
   # the parameter
    x = parse_kv(b'a=3 b=4')
    assert type(x) is dict

    y = parse_kv(u'a=3 b=4')
    assert type(y) is dict

    z = parse_kv('a=3 b=4')
    assert type(y) is dict

    # return a dictionary with the value of the token after
    # the first equals sign
    x = parse_kv(b'a=3 b=4')
    assert x['a'] == '3'
    assert x['b'] == '4'

    x = parse_kv(u'a=3 b=4')
    assert x['a'] == '3'
    assert x['b'] == '4'

    x

# Generated at 2022-06-25 04:02:36.753588
# Unit test for function parse_kv
def test_parse_kv():
    try:
        test_case_0()
    except AssertionError as ae:
        print(ae)

# Generated at 2022-06-25 04:02:42.232717
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'\x87\x82A'
    bytes_1 = b'\x9f\x8f\xa0\x93\xd2\x11\x8b\xb3\x00\x00\x00\x00'
    bytes_2 = b'\x98\x8a\xfe\x90\xb9\xd9\x06\xda\xad\x80\x01\x60\x4f\x4a\x7f'
    bytes_3 = b'\xbf\x7f\xfe\xfd\xfa'
    bytes_4 = b'\x9f\x8f\xa0D\x8f\x81'

# Generated at 2022-06-25 04:02:49.668107
# Unit test for function split_args
def test_split_args():
    # Example args
    # args = '''\x87\x82!\x82\x86\x90\x8A@\x83\x86\x89\x8A\x8B'''
    args = '\x87\x82!\x82\x86\x90\x8A@\x83\x86\x89\x8A\x8B'
    # Example expected result
    expected_result = ['!', '@']
    # Call split_args with args
    result = split_args(args)
    # Print result and expected result
    print('result = %s' % result)
    print('expected_result = %s' % expected_result)
    # Check if result is expected_result, if so then test passed
    assert result == expected_result

    # Example args
   

# Generated at 2022-06-25 04:02:56.527304
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args(' ') == []
    assert split_args('a') == ['a']
    assert split_args(' a') == ['a']
    assert split_args('a b') == ['a', 'b']
    assert split_args('a  b') == ['a', 'b']
    assert split_args('a b c') == ['a', 'b', 'c']
    assert split_args('a b c ') == ['a', 'b', 'c']
    assert split_args(' a b c ') == ['a', 'b', 'c']
    assert split_args(' a b c') == ['a', 'b', 'c']
    assert split_args(' a b c ') == ['a', 'b', 'c']

# Generated at 2022-06-25 04:03:03.336747
# Unit test for function split_args
def test_split_args():
    # $ grep -n 'command' ../../../testcases/**/*_playbook*.yml | awk -F : '{print $1}' | sort -u | xargs -I {} grep -n '\\n' {}
    if 0:
        assert split_args('''command git clone --branch=master \
--depth=1 --recurse-submodules -q git@git.foo.org:bar/baz.git dest={{ install_dir }}/baz''') == ['command', 'git', 'clone', '--branch=master', '--depth=1', '--recurse-submodules', '-q', 'git@git.foo.org:bar/baz.git', 'dest={{', 'install_dir', '}}/baz']


if __name__ == '__main__':
    test_

# Generated at 2022-06-25 04:03:09.132758
# Unit test for function parse_kv
def test_parse_kv():
    bytes_1 = b'\x87\x82A'
    bytes_2 = b'\x87\x82B'
    bytes_3 = b'{"a": "1"}'
    bytes_4 = b'{"b": "2"}'
    bytes_5 = b'{"a": "1", "b": "2"}'
    bytes_6 = b'{"a": "1", "b": "2", "c": "3"}'


    bytes_7 = b"a"
    bytes_8 = b"1"
    bytes_9 = b"b"
    bytes_10 = b"2"
    bytes_11 = b"3"
    assert True
    #if __name__ == '__main__':
    #    print("Result: " + repr(test_case_0()))

# Generated at 2022-06-25 04:03:13.712089
# Unit test for function split_args
def test_split_args():
    #assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    #assert split_args('a=b, c="foo bar"') == ['a=b,', 'c="foo bar"']
    #assert split_args('a=b\n c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(r'a=b\ c="foo bar"') == ['a=b c="foo bar"']
    #assert split_args(r'''a=b c="foo bar" 'd e f' "a'b'c"''') == ['a=b', 'c="foo bar"', '\'d e f\'', '"a\'b\'c"']
    #assert split_args('a=b c="foo

# Generated at 2022-06-25 04:03:17.297612
# Unit test for function parse_kv
def test_parse_kv():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 04:03:20.588938
# Unit test for function parse_kv
def test_parse_kv():
    # Try a good case
    assert parse_kv('foo=bar bar=baz') == {b'foo': b'bar', b'bar': b'baz'}
    # Try a bad case
    try:
        assert parse_kv('foo=ba=r bar=baz') == {b'foo': b'bar', b'bar': b'baz'}
    except:
        pass
    


# Generated at 2022-06-25 04:03:25.107509
# Unit test for function parse_kv
def test_parse_kv():
    #assert test_case_0(b'\x87\x82A') == '\x87\x82A'
    print("Test case 0")
    test_case_0()
    opt = parse_kv("k=v", check_raw=False)
    assert opt['k'] == 'v'


# Generated at 2022-06-25 04:03:35.265722
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()



# Generated at 2022-06-25 04:03:37.977523
# Unit test for function split_args
def test_split_args():
    try:
        split_args('foo bar a=1 b=2 c=3')        # Verify no exception is thrown
    except Exception as e:
        raise Exception('Split args test failed exception: {0}'.format(e))


# Generated at 2022-06-25 04:03:49.214220
# Unit test for function split_args
def test_split_args():

    # Test if two consecutive space chars are preserved
    assert split_args('a b') == ['a', 'b']
    assert split_args('a  b') == ['a', ' ', 'b']
    assert split_args('a   b') == ['a', '  ', 'b']
    assert split_args('a    b') == ['a', '    ', 'b']
    assert split_args('a     b') == ['a', '     ', 'b']

    # Test if newline char is preserved
    assert split_args('a\nb') == ['a', '\n', 'b']
    assert split_args('a\n b') == ['a', '\n b']
    assert split_args('a \nb') == ['a', ' \n', 'b']

# Generated at 2022-06-25 04:03:55.267876
# Unit test for function split_args
def test_split_args():
    split_args(None)
    # split_args('')
    # split_args('=')
    # split_args('= ')
    # split_args(' =')
    # split_args(' = ')
    # split_args("'= '")
    # split_args(" =' ")
    # split_args(" = '")
    # split_args("' = '")
    # split_args("'= \' ")
    # split_args("'= \" ")
    # split_args("'= \" ")
    # split_args("'= \" '")
    # split_args("\"= \' \"")
    # split_args("\"= \' \"'")
    # split_args("\"= \' \"'")
    # split_args("\"= \' \"' ")
   

# Generated at 2022-06-25 04:03:59.945046
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'fo&o bar a=1 b=2 c=3'
    var_0 = parse_kv(str_0)
    ans_0 = {'a':'1','b':'2','c':'3','_raw_params':'fo&o bar'}
    assert (var_0 == ans_0)


# Generated at 2022-06-25 04:04:08.978748
# Unit test for function split_args

# Generated at 2022-06-25 04:04:17.874760
# Unit test for function parse_kv
def test_parse_kv():
    my_dict = parse_kv('foo=bar key=val')
    assert my_dict['foo'] == 'bar'
    assert my_dict['key'] == 'val'
    assert '_raw_params' not in my_dict

    my_dict = parse_kv('foo=bar key=val', check_raw=True)
    assert my_dict['foo'] == 'bar'
    assert my_dict['key'] == 'val'
    assert '_raw_params' not in my_dict

# Generated at 2022-06-25 04:04:20.476651
# Unit test for function split_args
def test_split_args():
    print('Testing function split_args')
    test_case_0()

test_split_args()

# Generated at 2022-06-25 04:04:31.385555
# Unit test for function split_args
def test_split_args():
    test_str = 'a=b c="foo bar"'

    result = split_args(test_str)
    assert result[0] == 'a=b'
    assert result[1] == 'c="foo bar"'

    test_str = 'a=b c=foo\ bar'
    result = split_args(test_str)
    assert result[0] == 'a=b'
    assert result[1] == 'c=foo bar'

    test_str = 'a="b c" d=e'
    result = split_args(test_str)
    assert result[0] == 'a="b c"'
    assert result[1] == 'd=e'

    test_str = 'a="b c":d=e'
    result = split_args(test_str)

# Generated at 2022-06-25 04:04:39.901141
# Unit test for function split_args
def test_split_args():

    # test arg string with many params, a bunch with quotes
    arg_string = 'a=1 b=2 c="3 4" d="5 6" e="7 8" f="9 10" g="11 12" h="foo bar baz" i=13 j="14 15" k=16 l=17 m="18 19"'
    # expected results for above string
    expected_results = ['a=1', 'b=2', 'c="3 4"', 'd="5 6"', 'e="7 8"', 'f="9 10"', 'g="11 12"', 'h="foo bar baz"', 'i=13', 'j="14 15"', 'k=16', 'l=17', 'm="18 19"']
    results = split_args(arg_string)
    assert results == expected_results

    # test arg

# Generated at 2022-06-25 04:04:52.495829
# Unit test for function split_args
def test_split_args():
    arg_string = 'foo bar a=1 b=2 c=3'
    params = split_args(arg_string)
    assert len(params) == 3
    assert params[0] == 'foo'
    assert params[1] == 'bar'
    assert params[2] == 'a=1 b=2 c=3'



# Generated at 2022-06-25 04:04:59.570391
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'fo&o bar a=1 b=2 c=3'
    var_0 = parse_kv(str_0)
    assert var_0 == {
        'a': '1',
        'b': '2',
        'c': '3',
        '_raw_params': 'fo&o bar'
    }


# Generated at 2022-06-25 04:05:02.521062
# Unit test for function parse_kv
def test_parse_kv():
    result = True
    try:
        test_case_0()
    except Exception as e:
        print(e)
        result = False
    print(result)

if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-25 04:05:13.098659
# Unit test for function split_args
def test_split_args():
    # no quotes
    assert split_args("foo bar") == ["foo", "bar"]
    # " quotes
    assert split_args("foo bar") == ["foo", "bar"]
    # ' quotes
    assert split_args("foo bar") == ["foo", "bar"]
    # inner quotes
    assert split_args("fo\"o bar") == ["fo\"o", "bar"]
    # escaped quotes
    assert split_args("fo\\'o bar") == ["fo\\'o", "bar"]
    # quotes with spaces
    assert split_args("\"fo o\" bar") == ["\"fo o\"", "bar"]
    # empty quotes
    assert split_args("\"\"") == ["\"\""]
    # empty quotes with spaces
    assert split_args("\"\" bar") == ["\"\"", "bar"]
    # quotes containing

# Generated at 2022-06-25 04:05:18.944570
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

# python -m ansible.module_utils.common.parse_kv_test
if __name__ == '__main__':
    import sys
    import os
    import inspect
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    # print(os.getcwd())
    module_list = [u'parse_kv']
    for test_module_name in module_list:
        print('Unit test for module :%s' % test_module_name)
        module = __import__(test_module_name)
        if hasattr(module, 'test_' + test_module_name):
            print('Running unit test test_%s ...' % test_module_name)

# Generated at 2022-06-25 04:05:28.001240
# Unit test for function split_args
def test_split_args():

    # Test case 0
    str_0 = 'fo&o bar a=1 b=2 c=3'
    var_0 = split_args(str_0)
    assert var_0[0] == 'fo&o'
    assert var_0[1] == 'bar'
    assert var_0[2] == 'a=1'
    assert var_0[3] == 'b=2'
    assert var_0[4] == 'c=3'

    # Test case 1
    str_0 = 'a=1 b=b c= foo bar=1'
    var_0 = split_args(str_0)
    assert var_0[0] == 'a=1'
    assert var_0[1] == 'b=b'

# Generated at 2022-06-25 04:05:36.672780
# Unit test for function split_args
def test_split_args():
    str_1 = 'a=1 b=2 c=3'
    var_0 = split_args(str_1)
    assert var_0 == ['a=1', 'b=2', 'c=3']
    str_2 = 'a=1 b="2" c=3'
    var_1 = split_args(str_2)
    assert var_1 == ['a=1', 'b="2"', 'c=3']
    str_3 = 'a=1 b="2" c=3 d="4 5"'
    var_2 = split_args(str_3)
    assert var_2 == ['a=1', 'b="2"', 'c=3', 'd="4 5"']
    str_4 = 'a=1 b="2 5" c=3 d=4'
    var_

# Generated at 2022-06-25 04:05:47.145855
# Unit test for function split_args
def test_split_args():
    arg_str_0 = """a=1 b=2 b="1 2" d="1 2" c='1 2' e="a\\"b" f='a\\'b' g={h=1} h='{i=1}'"""
    arg_str_1 = """a=b c="foo bar" d="1 2" e='3 4'"""
    arg_str_2 = """a=b c="foo bar" d="1 2" e='3 4'"""
    arg_str_3 = """a=b c="foo bar" d="1 2" e='3 4'"""
    arg_str_4 = """a=b c="foo bar" d="1 2" e='3 4'"""
    arg_str_5 = """a=b c="foo bar" d="1 2" e='3 4'"""



# Generated at 2022-06-25 04:05:53.151539
# Unit test for function parse_kv
def test_parse_kv():
    assert 'fo&o' == parse_kv("fo&o")
    assert 'foo' == parse_kv("foo")
    assert 'bar' == parse_kv("bar")
    assert 'ba=r' == parse_kv("ba=r")
    assert 'ba=2' == parse_kv("ba=2")
    assert 'a=3 b=4' == parse_kv("a=3 b=4")
    assert 'a=4 b=4' == parse_kv("a=4 b=4")
    assert 'a=5 c=6' == parse_kv("a=5 c=6")



# Generated at 2022-06-25 04:05:57.978697
# Unit test for function parse_kv
def test_parse_kv():
    str_1 = 'fo&o bar a=1 b=2 c=3'
    str_2 = r'fo&o bar a=1 b="2" c=3'
    str_3 = r'fo&o bar a=1 b="2 c" d="3"'
    str_4 = r'fo&o bar a=1 b="2 c" d="3" e="a=4"'
    str_5 = r"fo&o bar a=1 b='2 c' d=3\ e='a=4'"
    str_6 = 'fo&o bar a=1 b1=2 c1=3 d1="a 1"'
    str_7 = r'fo&o bar a=1 b1=2 c1=3 d1="a 1" e1="b 2"'

# Generated at 2022-06-25 04:06:13.421629
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.common.text.utils import parse_kv
    import ansible.module_utils.common.text.common as common
    # Initial test case for function parse_kv
    # TODO: something is off here, fix it
    #assert common.parse_kv == test_case_0
    test_case_0()



# Generated at 2022-06-25 04:06:21.199296
# Unit test for function split_args

# Generated at 2022-06-25 04:06:28.705559
# Unit test for function split_args
def test_split_args():
    print('-'*10 + ' test_split_args ' + '-'*10)
    # str_0 = 'fo&o bar a=1 b=2 c=3'
    str_0 = 'fo&o bar a=1 b=2 c=3'
    var_0 = split_args(str_0)
    print(var_0)
    # str_1 = 'foo bar a=1 b=2 c=3'
    str_1 = 'foo bar a=1 b=2 c=3'
    var_1 = split_args(str_1)
    print(var_1)
    # str_2 = 'foo bar {% bar %} a=1 b=2 c=3'
    str_2 = 'foo bar {% bar %} a=1 b=2 c=3'
    var_

# Generated at 2022-06-25 04:06:35.899415
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'fo&o bar a=1 b=2 c=3'
    var_0 = parse_kv(str_0)
    assert var_0 == {'a': '1', 'b': '2', 'c': '3'}


# Generated at 2022-06-25 04:06:38.378352
# Unit test for function parse_kv
def test_parse_kv():
    assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:06:45.998036
# Unit test for function parse_kv
def test_parse_kv():
    assert u'fo&o' in parse_kv(u'fo&o bar a=1 b=2 c=3')
    assert u'1' in parse_kv(u'fo&o bar a=1 b=2 c=3')
    assert u'2' in parse_kv(u'fo&o bar a=1 b=2 c=3')
    assert u'3' in parse_kv(u'fo&o bar a=1 b=2 c=3')
    assert u'bar' in parse_kv(u'fo&o bar a=1 b=2 c=3')

# Test for parse_kv without any arguments set

# Generated at 2022-06-25 04:06:50.634658
# Unit test for function parse_kv
def test_parse_kv():
    ret_obj = {}
    ret_obj["expected"] = { u'a': u'1', u'c': u'3', u'b': u'2' }
    ret_obj["actual"] = parse_kv(u'fo&o bar a=1 b=2 c=3')
    assert ret_obj["expected"] == ret_obj["actual"]


# Generated at 2022-06-25 04:06:57.649843
# Unit test for function split_args
def test_split_args():
    # Case 0: Parse a regular string with no quotes or jinja2
    str_1 = 'echo hello world a=1 b=2 c=3'
    assert split_args(str_1) == ['echo', 'hello', 'world', 'a=1', 'b=2', 'c=3'], 'Error: Case 0'

    # Case 1: Parse a string with spaces inside quotes (double and single)
    str_2 = 'echo "hello world" \'a=1 b=2 c=3\''
    assert split_args(str_2) == ['echo', '"hello world"', '\'a=1 b=2 c=3\''], 'Error: Case 1'

    # Case 2: Parse a string with escaped quotes

# Generated at 2022-06-25 04:07:04.048737
# Unit test for function split_args
def test_split_args():
    test_cases = []

    # test case 0
    str_0 = 'fo&o bar a=1 b=2 c=3'
    var_0 = parse_kv(str_0)
    var_0_expect = {u'a': u'1', u'b': u'2', u'c': u'3', u'_raw_params': u'fo&o bar'}
    test_cases.append((str_0, var_0, var_0_expect))

    # test case 1
    str_1 = 'fo&o bar a=1 b=2 c=3'
    var_1 = parse_kv(str_1, False)
    var_1_expect = {u'a': u'1', u'b': u'2', u'c': u'3'}

# Generated at 2022-06-25 04:07:06.033429
# Unit test for function split_args
def test_split_args():
    str_0 = 'fo&o bar a=1 b=2 c=3'
    var_0 = split_args(str_0)
    print("0: " + str(var_0))


# Generated at 2022-06-25 04:07:26.579290
# Unit test for function parse_kv
def test_parse_kv():
    try:
        test_case_0()
    except AssertionError as e:
        print("AssertionError: %s" % e)



# Generated at 2022-06-25 04:07:32.645711
# Unit test for function parse_kv

# Generated at 2022-06-25 04:07:43.957157
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'fo&o bar a=1 b=2 c=3'
    var_0 = parse_kv(str_0)
    assert var_0['a'] == '1'
    assert var_0['b'] == '2'
    assert var_0['c'] == '3'
    assert var_0['_raw_params'] == 'fo&o bar'

    str_1 = 'fo&o bar a=1 b=2 c=3'
    var_1 = parse_kv(str_1, True)
    assert var_1['a'] == '1'
    assert var_1['b'] == '2'
    assert var_1['c'] == '3'

    str_2 = 'a=1 b=2 c="a=1" d=\'a=1\''
   

# Generated at 2022-06-25 04:07:51.619972
# Unit test for function split_args
def test_split_args():
    args = 'fo&o bar a=1 b=2 c=3'
    print(split_args(args))
    args = 'fo&o bar a=1 b=2 c="3 3 3"'
    print(split_args(args))
    args = 'fo&o bar a=1 b=2 c="3 3 3" d="4 4 4"'
    print(split_args(args))
    args = 'fo&o bar a=1 b=2 c="3 3 3" d="4 4\n 4"'
    print(split_args(args))
    args = 'fo&o bar a=1 b=2 c="3 3\n 3" d="4 4\n 4"'
    print(split_args(args))

# Generated at 2022-06-25 04:07:53.905013
# Unit test for function parse_kv
def test_parse_kv():
    # Test case for function parse_kv
    # Tests parse_kv with a simple string
    test_case_0()


# Generated at 2022-06-25 04:07:56.435203
# Unit test for function parse_kv
def test_parse_kv():
    # test 0
    try:
        assert (False) # test but don't care if it fails
    except:
        pass


# Generated at 2022-06-25 04:07:59.077493
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing function: parse_kv')
    test_case_0()


# Generated at 2022-06-25 04:08:01.440384
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'fo&o bar a=1 b=2 c=3'
    var_0 = parse_kv(str_0)
    assert var_0['a'] == 1


# Generated at 2022-06-25 04:08:10.932154
# Unit test for function split_args
def test_split_args():
    # test case 1
    args_1 = ''
    result_1 = split_args(args_1)
    assert result_1 == []

    # test case 2
    args_2 = ' '
    result_2 = split_args(args_2)
    assert result_2 == []

    # test case 3
    args_3 = 'x=1'
    result_3 = split_args(args_3)
    assert result_3 == ['x=1']

    # test case 4
    args_4 = 'x=1 y=2'
    result_4 = split_args(args_4)
    assert result_4 == ['x=1', 'y=2']

    # test case 5
    args_5 = 'x=1 y=2 z=3'

# Generated at 2022-06-25 04:08:13.212280
# Unit test for function parse_kv
def test_parse_kv():
    # FIXME: Implement test cases
    # assert(<TestCaseInstance>)
    test_case_0()


# Generated at 2022-06-25 04:08:36.878578
# Unit test for function split_args
def test_split_args():
    print('Enter function test_split_args')
    # test 0
    str_0 = 'foo bar a=1 b=2 c=3'
    var_0 = split_args(str_0)
    assert(len(var_0) == 5)
    assert(var_0[0] == 'foo')
    assert(var_0[1] == 'bar')
    assert(var_0[2] == 'a=1')
    assert(var_0[3] == 'b=2')
    assert(var_0[4] == 'c=3')
    # test 1
    str_1 = 'foo bar a=1 b="2 3" c=3'
    var_1 = split_args(str_1)
    assert(len(var_1) == 5)

# Generated at 2022-06-25 04:08:47.728691
# Unit test for function split_args
def test_split_args():
    args = "foo bar baz"

    # test without any quoting
    result = split_args(args)
    assert result == ["foo", "bar", "baz"]

    # test with quotes
    args = 'foo "bar baz" more'
    result = split_args(args)
    assert result == ["foo", '"bar baz"', "more"]

    # test with escaped quotes
    args = r'foo "bar\"baz" more'
    result = split_args(args)
    assert result == ["foo", r'"bar\"baz"', "more"]

    # test with escaped space
    args = r'foo bar\ baz more'
    result = split_args(args)
    assert result == ["foo", r'bar\ baz', "more"]

    # test with escaped space in quotes
    args

# Generated at 2022-06-25 04:08:53.890218
# Unit test for function parse_kv
def test_parse_kv():

    str_0 = 'foo bar a=1 b=2 c=3'
    var_0 = parse_kv(str_0)

    str_1 = 'foo bar a=1 b=2 c=3'
    var_1 = parse_kv(str_1, True)
    assert var_1 == {'a': '1', 'b': '2', 'c': '3', '_raw_params': 'foo bar'}

    str_2 = 'foo bar a=1 b=2 c=3'
    var_2 = parse_kv(str_2, False)
    assert var_2 == {'a': '1', 'b': '2', 'c': '3'}


# Module to split the args for the loop

# Generated at 2022-06-25 04:08:58.306049
# Unit test for function parse_kv
def test_parse_kv():
    # Initialize mock objects
    # Initialize class objects
    obj = parse_kv('foo bar a=1 b=2 c=3')
    # Run tests
    assert obj == {'a': '1', 'b': '2', 'c': '3', '_raw_params': 'foo bar'}
    # Return success
    return True


# Generated at 2022-06-25 04:09:06.421004
# Unit test for function parse_kv
def test_parse_kv():
    args = 'fo&o bar a=1 b=2 c=3'
    vargs = split_args(args)
    options = {}

    for x in vargs:
        print(x)
        if "=" in x:
            pos = x.index('=')
            k = x[:pos]
            v = x[pos + 1:]
            options[k.strip()] = v.strip()
        else:
            options[x.strip()] = x.strip()

    print(options)


# Generated at 2022-06-25 04:09:18.150708
# Unit test for function parse_kv
def test_parse_kv():
    assert str(parse_kv('foo bar a=1 b=2 c=3')) == str({'a': '1', 'b': '2', 'c': '3', '_raw_params': 'foo bar'})
    assert str(parse_kv('a=1 b=2 c=3')) == str({'a': '1', 'b': '2', 'c': '3'})
    assert str(parse_kv('a=1 b=2 c=3;')) == str({'a': '1', 'b': '2', 'c': '3', '_raw_params': ';'})

# Generated at 2022-06-25 04:09:30.155973
# Unit test for function split_args
def test_split_args():
    # case 0
    str_0 = 'fo&o bar a=1 b=2 c=3'
    var_0 = split_args(str_0)
    print(var_0)

    # case 1
    str_1 = 'cdp enable vlan all'
    var_1 = split_args(str_1)
    print(var_1)
    # assert var_1 == ['cdp', 'enable', 'vlan', 'all']

    # case 2
    str_2 = 'cdp enable vlan "all"'
    var_2 = split_args(str_2)
    print(var_2)
    # assert var_2 == ['cdp', 'enable', 'vlan', '"all"']

    # case 3
    str_3 = 'cdp enable "vlan all"'
    var

# Generated at 2022-06-25 04:09:37.017116
# Unit test for function split_args
def test_split_args():
    str_0 = '''
{{
    foo
    }}
    '''
    str_1 = '''
    foo bar\\
    a=1 b=2 c=3
    '''
    str_2 = "fo'o bar a=1 b=2 c=3"
    str_3 = '''
    {%
    foo
    %}
    '''

    str_4 = '''
    {#
    foo
    #}
    '''
    str_5 = '''
    {
    foo
    }
    '''
    str_6 = '''
    {
    foo
    }
    '''
    str_7 = '''
    {
    foo
    }
    '''

# Generated at 2022-06-25 04:09:48.144523
# Unit test for function split_args

# Generated at 2022-06-25 04:09:57.485495
# Unit test for function split_args
def test_split_args():
    str_0 = 'fo&o bar a=1 b=2 c=3'
    var_0 = split_args(str_0)
    str_1 = 'fo&o bar a=1 b=2 c=3'
    var_1 = split_args(str_1)
    str_2 = 'fo&o bar a=1 b=2 c=3'
    var_2 = split_args(str_2)
    str_3 = 'fo&o bar a=1 b=2 c=3'
    var_3 = split_args(str_3)
    str_4 = 'fo&o bar a=1 b=2 c=3'
    var_4 = split_args(str_4)
    str_5 = 'fo&o bar a=1 b=2 c=3'
    var_

# Generated at 2022-06-25 04:10:11.516669
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

# vim: set ts=4 sw=4 et

# Generated at 2022-06-25 04:10:19.101652
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'a=1 b=2 c=3'
    var_0 = parse_kv(str_0)

    assert var_0
    assert 'a' in var_0
    assert 'b' in var_0
    assert 'c' in var_0

    assert var_0['a'] == '1'
    assert var_0['b'] == '2'
    assert var_0['c'] == '3'

    str_1 = "a='quoted string' b=2 c=3"
    var_1 = parse_kv(str_1)

    assert var_1
    assert 'a' in var_1
    assert 'b' in var_1
    assert 'c' in var_1

    assert var_1['a'] == 'quoted string'

# Generated at 2022-06-25 04:10:29.330803
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'fo&o bar a=1 b=2 c=3'
    var_0 = parse_kv(str_0)
    str_1 = 'fo&o bar a: 1 b: 2 c: 3'
    var_1 = parse_kv(str_1)
    str_2 = 'fo&o bar a: 1 b: 2 c=3 \=4'
    var_2 = parse_kv(str_2)
    str_3 = 'fo&o bar a:1 b:2 c=3 \=4'
    var_3 = parse_kv(str_3)
    str_4 = 'fo&o bar a: 1 b: 2 b: 2 c=3 \=4'
    var_4 = parse_kv(str_4)

# Generated at 2022-06-25 04:10:39.273744
# Unit test for function parse_kv
def test_parse_kv():
    str = 'fo&o bar a=1 b=2 c=3'
    var = parse_kv(str)
    assert var.has_key('a')
    assert var.has_key('b')
    assert var.has_key('c')
    assert var.has_key('_raw_params')
    assert var['a'] == '1'
    assert var['b'] == '2'
    assert var['c'] == '3'
    assert var['_raw_params'] == 'fo&o bar'

    # test a single named param with a space
    str = 'a=foo bar'
    var = parse_kv(str)
    assert var.has_key('a')
    assert var['a'] == 'foo bar'

    # test a single named param with an equals

# Generated at 2022-06-25 04:10:49.314353
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = ' fo&o bar a=1 b=2 c=3'
    var_0 = parse_kv(str_0)
    assert len(var_0) == 4
    # assert var_0['a'] == 1
    # assert var_0['b'] == 2
    # assert var_0['c'] == 3
    # assert var_0['_raw_params'] == 'fo& bar'

    str_1 = 'fo&o bar a=1 b=2 c=3'
    var_1 = parse_kv(str_1)
    assert len(var_1) == 4
    # assert var_1['a'] == 1
    # assert var_1['b'] == 2
    # assert var_1['c'] == 3
    # assert var_1['_raw_params'] == '

# Generated at 2022-06-25 04:10:57.421973
# Unit test for function split_args
def test_split_args():
    # Test 1: Simple Quoted Args
    assert split_args("'foo bar' baz=qux") == ["'foo bar'", "baz=qux"]

    # Test 2: Complex Quoted Args
    assert split_args("quoted=\"'hello world'\" abc=foo") == ['quoted="\'hello world\'"', "abc=foo"]

    # Test 3: Args with newlines
    assert split_args('foo=bar\nabc="hello world"') == ['foo=bar\nabc="hello world"']
    assert split_args('foo\nfoo2=bar') == ['foo\nfoo2=bar']

    # Test 4: Args with unbalanced quotes
    # assert split_args('foo "bar') == ['foo "bar']

# Generated at 2022-06-25 04:11:02.029750
# Unit test for function parse_kv
def test_parse_kv():

    # Test cases for function parse_kv
    tests = [
        test_case_0
    ]

    # Run unit test for function parse_kv
    for test in tests:
        test()


# Split a string of arguments and unquote any quoted arguments