

# Generated at 2022-06-25 04:01:31.168424
# Unit test for function parse_kv
def test_parse_kv():
    float_0 = 1
    var_0 = parse_kv(float_0)



# Generated at 2022-06-25 04:01:40.412272
# Unit test for function split_args
def test_split_args():
    assert split_args('1.0') == 1.0
    assert split_args('2.0') == 2.0
    assert split_args('3.0') == 3.0
    assert split_args('4.0') == 4.0
    assert split_args('5.0') == 5.0
    assert split_args('6.0') == 6.0
    assert split_args('7.0') == 7.0
    assert split_args('8.0') == 8.0
    assert split_args('9.0') == 9.0
    assert split_args('10.0') == 10.0
    assert split_args('11.0') == 11.0
    assert split_args('12.0') == 12.0
    assert split_args('13.0') == 13.0
    assert split_

# Generated at 2022-06-25 04:01:50.515802
# Unit test for function split_args
def test_split_args():
    assert join_args(['ls', '-l', '-a', '-v']) == 'ls -l -a -v'
    assert join_args(['ls', '-l', '-a', '-v', '-h']) == 'ls -l -a -v -h'
    assert join_args(['ls', '-l', '-a']) == 'ls -l -a'
    assert join_args(['ls', '-l']) == 'ls -l'
    assert join_args(['ls', '-l', '-a', '-v', '-h', '-f']) == 'ls -l -a -v -h -f'
    assert join_args(['ls', '-l', '-a', '-v', '-h', '-f', '-g'])

# Generated at 2022-06-25 04:01:54.203869
# Unit test for function split_args
def test_split_args():
    str_0 = 'VAR0={{ VAR1 }} VAR2={{ VAR3 }}'
    result = split_args(str_0)
    print(result)

if __name__ == '__main__':
    test_case_0()
    #test_split_args()

# Generated at 2022-06-25 04:01:54.939761
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 04:02:00.531527
# Unit test for function parse_kv
def test_parse_kv():
    float_0 = 1.0
    var_0 = parse_kv(float_0)



# Generated at 2022-06-25 04:02:02.339340
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

if __name__ == "__main__":
    test_parse_kv()

# Generated at 2022-06-25 04:02:03.773440
# Unit test for function split_args
def test_split_args():
    print("test_split_args()")
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:02:10.714326
# Unit test for function split_args
def test_split_args():
    assert split_args("arg") == ['arg']
    assert split_args("arg1 arg2") == ['arg1', 'arg2']
    assert split_args("arg1 arg2\narg3 arg4") == ['arg1', 'arg2', 'arg3', 'arg4']
    assert split_args("arg1 'arg2 arg3'") == ["arg1", "arg2 arg3"]
    assert split_args("arg1 'arg2 arg3'\narg4 arg5") == ["arg1", "arg2 arg3", "arg4", "arg5"]
    assert split_args("arg1 \"arg2 arg3\"") == ["arg1", "arg2 arg3"]

# Generated at 2022-06-25 04:02:13.773185
# Unit test for function parse_kv
def test_parse_kv():
    ansible_conf = "key=value"
    ansible_conf_dict = parse_kv(ansible_conf)
    print(ansible_conf_dict)
    if ansible_conf_dict["key"] != "value":
        raise AssertionError("key not equal value")

if __name__ == '__main__':
    test_case_0()
    test_parse_kv()

# Generated at 2022-06-25 04:03:13.577834
# Unit test for function parse_kv
def test_parse_kv():
    args = "_test_raw_params=test"

    ret = parse_kv(args, True)
    assert(ret['_test_raw_params'] == 'test')

    args = "k1=v1 k2=v2 k3=v3"
    ret = parse_kv(args)
    assert(ret['k1'] == 'v1')
    assert(ret['k2'] == 'v2')
    assert(ret['k3'] == 'v3')

    args = 'k1=v1 k2="v2 with spaces" k3="v3 with spaces and \'quotes\'" k4=v4'
    ret = parse_kv(args)
    assert(ret['k1'] == 'v1')
    assert(ret['k2'] == 'v2 with spaces')

# Generated at 2022-06-25 04:03:23.688815
# Unit test for function parse_kv
def test_parse_kv():
    # Test cases
    print('Test case 0')
    float_0 = 1.0
    var_0 = split_args(float_0)

    print('Test case 1')
    str_0 = '1.0'
    var_0 = split_args(str_0)

    print('Test case 2')
    str_0 = '1.0'
    var_0 = split_args(str_0)

    print('Test case 3')
    list_0 = [float_0]
    var_0 = split_args(list_0)

    print('Test case 4')
    str_0 = '1.0'
    var_0 = split_args(str_0)

    print('Test case 5')
    list_0 = [str_0]

# Generated at 2022-06-25 04:03:30.701804
# Unit test for function split_args
def test_split_args():
    #print("Testing split_args")

    # We test this function using the examples from Ansible's source code
    # Example from ansible/module_utils/basic.py,
    # join_args function
    result = split_args("a=b c=\"foo bar\"")
    if (['a=b', 'c="foo bar"'] != result):
        print("ERROR: expected [\'a=b\', \'c=\"foo bar\"\'], got", result)

    # Example from Ansible's source code
    result = split_args("a=b c='foo bar'")
    if (['a=b', 'c=\'foo bar\''] != result):
        print("ERROR: expected [\'a=b\', \'c=\'foo bar\'\'], got", result)

    # Example from Ansible's source code

# Generated at 2022-06-25 04:03:39.113492
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('name=value') == {'name': 'value'}
    assert parse_kv('name = value') == {'name': 'value'}
    assert parse_kv('name= value') == {'name': 'value'}
    assert parse_kv('name =value') == {'name': 'value'}
    assert parse_kv('name=value ') == {'name': 'value'}
    assert parse_kv('name= value ') == {'name': 'value'}
    assert parse_kv('name =value ') == {'name': 'value'}

    assert parse_kv('name=value arg') == {'name': 'value', '_raw_params': 'arg'}

# Generated at 2022-06-25 04:03:43.930795
# Unit test for function parse_kv
def test_parse_kv():
    assert "out" in globals()
    assert "out_0" not in globals()
    float_0 = 1.0
    var_0 = parse_kv(float_0)


# Generated at 2022-06-25 04:03:45.292807
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()


# TODO: make this a public function in a utils file so we can use it elsewhere

# Generated at 2022-06-25 04:03:55.634901
# Unit test for function split_args
def test_split_args():
    args = "Hello my name is Arianna and I like penguins"
    split_args_result = split_args(args)
    assert split_args_result == args
    args = "this is a test of a string containing no whitespace to make sure that it returns correctly"
    split_args_result = split_args(args)
    assert split_args_result == args
    args = "this is a test of a string containing \nno whitespace to make sure that it returns correctly"
    split_args_result = split_args(args)
    assert split_args_result == args
    args = "a='b c' d=\"e f\""
    split_args_result = split_args(args)
    assert split_args_result == ['a=b c','d=e f']

# Generated at 2022-06-25 04:03:57.788688
# Unit test for function split_args
def test_split_args():
    float_0 = 1.0
    var_0 = split_args(float_0)


# Generated at 2022-06-25 04:04:00.615378
# Unit test for function split_args
def test_split_args():
    print('# Unit test for function split_args')
    print('# Test case 0: =========================')
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:04:02.153757
# Unit test for function parse_kv
def test_parse_kv():
    float_0 = 1.0
    var_0 = parse_kv(float_0)
    ok_(var_0 is not None)
    

# Generated at 2022-06-25 04:04:11.971907
# Unit test for function parse_kv
def test_parse_kv():
    try:
        assert 0
        test_case_0()
    except Exception as e:
        print(e)



# Generated at 2022-06-25 04:04:20.553980
# Unit test for function split_args
def test_split_args():
    # initialize test arguments
    split_args_arg_0 = "foo={{bar}} biz=baz"
    split_args_arg_1 = "foo={{bar}} biz=baz"

    # call the function under test
    result = split_args(split_args_arg_0, split_args_arg_1)

    # check the match against the expected result
    assert isinstance(result, (list, ))
    assert len(result) == 2
    assert result[0] == "foo={{bar}}"
    assert result[1] == "biz=baz"

if __name__ == '__main__':
    '''
    test_case_0()
    test_split_args()
    '''

# Generated at 2022-06-25 04:04:25.269282
# Unit test for function parse_kv
def test_parse_kv():
    string_0 = 'var1=value1 var2=value2'
    dict_0 = parse_kv(string_0)
    assert (dict_0 == {u'var1': u'value1', u'var2': u'value2'})



# Generated at 2022-06-25 04:04:33.517456
# Unit test for function parse_kv
def test_parse_kv():
    # Test 0
    float_0 = '''-a'''
    var_0 = parse_kv(float_0)
    # Test 1
    float_0 = '''-a -b -c'''
    var_0 = parse_kv(float_0)
    # Test 2
    float_0 = '''-a -b -c'''
    var_0 = parse_kv(float_0)
    # Test 3
    float_0 = '''-a=b -c=d'''
    var_0 = parse_kv(float_0)
    # Test 4
    float_0 = '''-a "d e" -c'''
    var_0 = parse_kv(float_0)
    # Test 5

# Generated at 2022-06-25 04:04:34.669064
# Unit test for function parse_kv
def test_parse_kv():
    func_arg_0 = parse_kv()
    assert type(func_arg_0) == dict

# test orig_arg on the function parse_kv

# Generated at 2022-06-25 04:04:37.364711
# Unit test for function parse_kv
def test_parse_kv():
    # Provided by user
    args = ''
    check_raw = False
    ans = parse_kv(args, check_raw)
    print(ans)
    assert ans == {}


# Generated at 2022-06-25 04:04:40.410162
# Unit test for function parse_kv
def test_parse_kv():
    try:
        test_case_0()
    except Exception as ex:
        print('Unit test failed.')
        print(f'Exception: {ex}')
    else:
        print('Unit test passed.')

if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-25 04:04:44.571702
# Unit test for function parse_kv
def test_parse_kv():
    try:
        var_0 = parse_kv()
        assert False
    except AnsibleParserError:
        pass
    except Exception:
        assert False
    else:
        pass
    try:
        var_0 = parse_kv("")
        assert False
    except AnsibleParserError:
        pass
    except Exception:
        assert False
    else:
        pass
# Testing function join_args

# Generated at 2022-06-25 04:04:50.960232
# Unit test for function parse_kv
def test_parse_kv():
    # Test for case 0
    float_0 = 1.0
    check_raw_0 = False
    var_0 = parse_kv(arg=float_0, check_raw=check_raw_0)
    print("var_0 = {}".format(var_0))
    print("repr(var_0) = {}".format(repr(var_0)))
    assert var_0 == {}


# Generated at 2022-06-25 04:04:55.419473
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 04:05:07.390817
# Unit test for function split_args
def test_split_args():
    cases = [
        ('a=b c="foo bar"', ['a=b', 'c="foo bar"']),
        ('a=b c="foo bar"', ['a=b', 'c="foo bar"']),
        ('a=b c="foo bar"', ['a=b', 'c="foo bar"']),
        ('a=b c="foo bar"', ['a=b', 'c="foo bar"']),
        ('a=b c="foo bar"', ['a=b', 'c="foo bar"']),
        ('a=b c="foo bar"', ['a=b', 'c="foo bar"']),
    ]

    for cases_0 in cases:
        func_arg_0 = cases_0[0]
        func_arg_1 = cases_0[1]
        assert split_

# Generated at 2022-06-25 04:05:14.865228
# Unit test for function parse_kv
def test_parse_kv():
    print("Start testing parse_kv")

    # Make sure the parsed dict looks like we want
    assert parse_kv("foo=bar") == dict(foo='bar'), "First test for parse_kv failed: "
    assert parse_kv("foo=bar baz=bar") == dict(foo='bar', baz='bar'), "Second test for parse_kv failed: "
    assert parse_kv("foo=bar baz=bar,bax=foo") == dict(foo='bar', baz='bar,bax=foo'), "Third test for parse_kv failed: "
    assert parse_kv("foo=bar baz='bar,bax=foo'") == dict(foo='bar', baz='bar,bax=foo'), "Fourth test for parse_kv failed: "

# Generated at 2022-06-25 04:05:26.054129
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.splitter import parse_kv

    var_0 = parse_kv(dir)
    var_0 = parse_kv(abs)
    var_0 = parse_kv(id)
    var_0 = parse_kv(ord)
    var_0 = parse_kv(chr)
    var_0 = parse_kv(isinstance)
    var_0 = parse_kv(issubclass)
    var_0 = parse_

# Generated at 2022-06-25 04:05:30.977924
# Unit test for function split_args
def test_split_args():
    assert split_args('hello') == ['hello']
    assert split_args('hello world') == ['hello', 'world']
    assert (split_args('hello world "a \\ b"') == ['hello', 'world', '"a \\ b"'])
    assert split_args('"hell"o "worl"d "a \\ b"') == ['"hell"o', '"worl"d', '"a \\ b"']
    assert split_args('"hell"o "worl"d "a \\ b"') != ['hello', 'world', 'a \\ b']


# Generated at 2022-06-25 04:05:34.753617
# Unit test for function parse_kv
def test_parse_kv():
    input_0 = b'name=value'
    result_0 = parse_kv(input_0)
    assert result_0 == {u'name': u'value'}

    input_1 = b'name=value'
    result_1 = parse_kv(input_1)
    assert result_1 == {u'name': u'value'}


# Generated at 2022-06-25 04:05:46.525891
# Unit test for function split_args
def test_split_args():
    assert(split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"'])
    assert(split_args('a=b c="foo bar" ') == ['a=b', 'c="foo bar"'])
    assert(split_args('a=b c="foo bar"\nd=e f="foo bar"') == ['a=b', 'c="foo bar"', 'd=e', 'f="foo bar"'])
    assert(split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"'])
    assert(split_args('a=b c="foo\\nbar"') == ['a=b', 'c="foo\\nbar"'])

# Generated at 2022-06-25 04:05:51.423257
# Unit test for function split_args
def test_split_args():
    float_0 = 1.0
    var_0 = split_args(float_0)
    print("split_args(%f) produced %s" % (float_0, var_0))
    float_1 = 2.0
    var_1 = split_args(float_1)
    print("split_args(%f) produced %s" % (float_1, var_1))

# Test for the function split_args

# Generated at 2022-06-25 04:05:57.310178
# Unit test for function parse_kv
def test_parse_kv():

    # add some more
    var_1 = 'string_0'
    var_2 = parse_kv(var_1)
    print (var_2)

    test_case_0()

if __name__ == "__main__":
    test_parse_kv()

# Generated at 2022-06-25 04:06:07.174589
# Unit test for function split_args
def test_split_args():
    test_case_0()

    test_cases = [
        {'name': 'case_0', 'input_args': 'a=b c="foo bar"', 'expected': ['a=b', 'c="foo bar"']},
        {'name': 'case_1', 'input_args': 'a=b c="foo bar"', 'expected': ['a=b', 'c="foo bar"']},
    ]

    for test_case in test_cases:
        result = split_args(test_case['input_args'])
        assert result == test_case['expected']


# Generated at 2022-06-25 04:06:12.273090
# Unit test for function split_args
def test_split_args():
    print("Testing split_args")
    float_0 = 1.0
    assert split_args(float_0) == []


# Generated at 2022-06-25 04:06:23.348422
# Unit test for function split_args
def test_split_args():

    ansible_1 = 'ansible'
    ansible_2 = ansible_1
    ansible_3 = 'ansible'
    ansible_4 = ansible_3

    assert(ansible_1 == ansible_2)
    assert(ansible_3 == ansible_4)


# Generated at 2022-06-25 04:06:24.825090
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = 1.0
    var_1 = parse_kv(var_0)
    print(var_1)


# Generated at 2022-06-25 04:06:31.887998
# Unit test for function split_args
def test_split_args():
    '''
    Test split_args function
    '''
    print("Testing function split_args")
    print("\tExpecting a List of Strings with 10 elements")
    result = split_args("-a 'ansible all -m ping' -o")
    if len(result) == 10:
        print("\tResult: PASS")
    else:
        print("\tResult: FAIL")
    print("\tResult: {0}".format(result))


# Generated at 2022-06-25 04:06:33.507303
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c=3") == { 'a': '1', 'b': '2', 'c': '3' }


# Generated at 2022-06-25 04:06:36.010584
# Unit test for function parse_kv
def test_parse_kv():
    try:
        float_0 = 1.0
        dict_0 = parse_kv(float_0)
    except Exception:
        print('An exception has occured')


# Generated at 2022-06-25 04:06:42.307742
# Unit test for function split_args
def test_split_args():
    assert split_args(float(1)) == []
    assert split_args(1) == []
    assert split_args(float(0)) == []
    assert split_args(0) == []
    assert split_args(str('')) == []
    assert split_args('') == []
    assert split_args(str(' ')) == [' ']
    assert split_args(' ') == [' ']
    assert split_args(str('  ')) == [' ', ' ']
    assert split_args('  ') == [' ', ' ']
    assert split_args(str(', ')) == [',']
    assert split_args(', ') == [',']
    assert split_args(str(',,')) == [',', ',']
    assert split_args(',,') == [',', ',']

# Generated at 2022-06-25 04:06:48.016181
# Unit test for function split_args
def test_split_args():
    # These lines of code are used as the input to the function.
    # Do not edit them! 
    test_case_input_0 = "a=b c=\"foo bar\""
    test_case_input_1 = "cd 'foo' ; pwd"

    # These lines of code are used as the expected output.
    # Do not edit them! 
    test_case_output_0 = ['a=b', 'c="foo bar"']
    test_case_output_1 = ['cd', 'foo', ';', 'pwd']

    assert split_args(test_case_input_0) == test_case_output_0
    assert split_args(test_case_input_1) == test_case_output_1


# Generated at 2022-06-25 04:06:57.403563
# Unit test for function split_args
def test_split_args():
    assert (split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"'])
    assert (split_args('{{a}} {{b}}') == ['{{a}}', '{{b}}'])
    assert (split_args('{%a%} {%b%}') == ['{%a%}', '{%b%}'])
    assert (split_args('{#a#} {#b#}') == ['{#a#}', '{#b#}'])
    assert (split_args('a=b "foo bar"') == ['a=b', '"foo bar"'])
    assert (split_args('a=b "foo bar') == ['a=b', '"foo bar'])

# Generated at 2022-06-25 04:07:00.834776
# Unit test for function parse_kv
def test_parse_kv():
    try:
        assert 2 + 2 == 5
    except AssertionError as e:
        print(e)


# Utility function to split a string into an array of arguments
# It will preserve quoted strings and escape sequences.

# Generated at 2022-06-25 04:07:05.624884
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = 'echo hi=true'
    result = parse_kv(var_0)
    assert result == {
        u'_raw_params': u'echo hi=true',
        u'hi': True
    }

test_parse_kv()
test_case_0()

# Generated at 2022-06-25 04:07:19.368345
# Unit test for function parse_kv
def test_parse_kv():
    str_1 = 'a=b c=d'
    var_1 = parse_kv(str_1)
    str_2 = 'a=b c=d e=f'
    var_2 = parse_kv(str_2)
    str_3 = 'a=b \'c=d\' e=f'
    var_3 = parse_kv(str_3)
    str_4 = 'a=b "c=d" e=f'
    var_4 = parse_kv(str_4)
    str_5 = 'a=b "c=d" e=f'
    var_5 = parse_kv(str_5)
    str_6 = 'a=b "c=d" e=f'
    var_6 = parse_kv(str_6)
    str

# Generated at 2022-06-25 04:07:20.770660
# Unit test for function split_args
def test_split_args():
    assert split_args('l*c') == ['l*c',]


# Generated at 2022-06-25 04:07:27.345085
# Unit test for function split_args
def test_split_args():
    str_0 = 'a=b c="foo bar" d=\'baz\''
    var_0 = split_args(str_0)
    if var_0 == ['a=b', 'c="foo bar"', 'd=\'baz\'']:
        print('PASSED')
    else:
        print('FAILED')


# Generated at 2022-06-25 04:07:32.577285
# Unit test for function split_args
def test_split_args():
    str_0 = '{{ foo }} {{ bar }}'
    var_0 = split_args(str_0)

    assert var_0[0] == '{{ foo }}'
    assert var_0[1] == '{{ bar }}'


# Generated at 2022-06-25 04:07:42.849781
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'l*c'
    var_0 = parse_kv(str_0)

    str_1 = ''
    var_1 = parse_kv(str_1)

    str_2 = 'l=c'
    var_2 = parse_kv(str_2)

    str_3 = 'l=l=l'
    var_3 = parse_kv(str_3)

    str_4 = 'l=l=l*l=l'
    var_4 = parse_kv(str_4)

    print("")

if __name__ == "__main__":
    test_case_0()
    test_parse_kv()

# Generated at 2022-06-25 04:07:50.847725
# Unit test for function parse_kv
def test_parse_kv():
    print("test_parse_kv")
    print("1. test case 1")
    str_0 = '''abcd efgh'''
    var_0 = parse_kv(str_0)
    print("Test case 1: " + "abcd efgh" + " gives " + str(var_0) + ": " + str(var_0 == {u'abcd': 'efgh'}))

    print("2. test case 2")
    str_0 = '''abcd=efgh'''
    var_0 = parse_kv(str_0)
    print("Test case 2: " + "abcd=efgh" + " gives " + str(var_0) + ": " + str(var_0 == {u'abcd': 'efgh'}))


# Generated at 2022-06-25 04:07:52.316972
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()


# Generated at 2022-06-25 04:08:03.097987
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = "a=1"
    var_0 = parse_kv(str_0)
    print(str(var_0))
    assert var_0 == {u'a': u'1'}
    str_0 = "a=1,b=2"
    var_0 = parse_kv(str_0)
    print(str(var_0))
    assert var_0 == {u'a': u'1', u'b': u'2'}
    str_0 = "a=1,=2"
    var_0 = parse_kv(str_0)
    print(str(var_0))
    assert var_0 == {u'a': u'1', u'_raw_params': u'=2'}
    str_0 = "a=1,=2"

# Generated at 2022-06-25 04:08:14.694690
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'l*c'
    var_0 = parse_kv(str_0)

    assert_equals(var_0, {u'_raw_params': u'l*c' })

    str_1 = 'l*c=xc'
    var_1 = parse_kv(str_1)

    assert_equals(var_1, {u'l*c': u'xc', u'_raw_params': u'l*c=xc' })

    str_2 = 'l*c="xc"'
    var_2 = parse_kv(str_2)

    assert_equals(var_2, {u'l*c': u'xc', u'_raw_params': u'l*c=xc' })


# Generated at 2022-06-25 04:08:18.867617
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing function parse_kv...", end="")

    test_case_0()

    print("passed all test cases!")

# Local Variables:
# compile-command: "cd ../..; python3 -m unittest -v test.test_utils.test_parse_kv"
# End:

# Generated at 2022-06-25 04:08:31.956141
# Unit test for function parse_kv
def test_parse_kv():
    # Test case variables
    str_0 = 'hosts=vms'
    str_1 = 'hosts=vms cmd> /tmp/cmd.log'
    str_2 = '2>&1'
    str_3 = '2>&1 && ls'
    str_4 = 'cmd 2>&1'
    str_5 = '&'
    str_6 = ' && ls'
    str_7 = 'ls 2>&1'
    str_8 = 'ls 2>&1 &&'
    str_9 = 'ls 2>&1 && test'
    str_10 = '/etc/hosts  > /tmp/hosts'
    str_11 = '/etc/hosts  > /tmp/hosts 2>&1'
    str_12 = 'cat > /tmp/hosts'
    str

# Generated at 2022-06-25 04:08:38.156719
# Unit test for function parse_kv
def test_parse_kv():
    # Input for function parse_kv
    str_0 = "a=b c=d"
    var_0 = parse_kv(str_0)
    return var_0



# Generated at 2022-06-25 04:08:48.819920
# Unit test for function split_args
def test_split_args():
    assert split_args('NAME="Linda Smith"') == ['NAME="Linda Smith"']
    assert split_args('\'NAME="Linda Smith"\'') == ['\'NAME="Linda Smith"\'']
    assert split_args('"NAME=\'Linda Smith\'"') == ['"NAME=\'Linda Smith\'"']
    assert split_args('"NAME=\'Linda Smith\'" AGE=22') == ['"NAME=\'Linda Smith\'"', 'AGE=22']
    assert split_args('"NAME=\'Linda Smith\'" AGE=22 DOB="2/3/80"') == ['"NAME=\'Linda Smith\'"', 'AGE=22', 'DOB="2/3/80"']

# Generated at 2022-06-25 04:08:49.867873
# Unit test for function parse_kv
def test_parse_kv():
    print(test_case_0())
    # assert test_case_0() == [1, 1]



# Generated at 2022-06-25 04:08:52.994916
# Unit test for function parse_kv
def test_parse_kv():
    str_1 = '* c'
    var_1 = parse_kv(str_1)


# Generated at 2022-06-25 04:09:02.660145
# Unit test for function parse_kv
def test_parse_kv():
    # Python 2
    if sys.version_info.major < 3:
        str_0 = 'we are friends\n.\n'
        var_0 = parse_kv(str_0)

        str_1 = 'we are friends\n.\n'
        var_1 = parse_kv(str_1)

        str_2 = 'we are friends\n.\n'
        var_2 = parse_kv(str_2)

        str_3 = 'we are friends\n.\n'
        var_3 = parse_kv(str_3)

        str_4 = 'we are friends\n.\n'
        var_4 = parse_kv(str_4)

        str_5 = 'we are friends\n.\n'

# Generated at 2022-06-25 04:09:06.023410
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 04:09:17.344374
# Unit test for function parse_kv
def test_parse_kv():
    assert (parse_kv('abd=${a}af') == {u'abd': u'${a}af', u'_raw_params': u'abd=${a}af'})
    assert (parse_kv('abd=${a}af') == {u'abd': u'${a}af', u'_raw_params': u'abd=${a}af'})
    assert (parse_kv('mu=$${y}fg') == {u'mu': u'$${y}fg', u'_raw_params': u'mu=$${y}fg'})
    assert (parse_kv('ac=${z}') == {u'ac': u'${z}', u'_raw_params': u'ac=${z}'})

# Generated at 2022-06-25 04:09:26.573306
# Unit test for function parse_kv
def test_parse_kv():

    # Test 0
    str_0 = 'l*c'
    var_0 = parse_kv(str_0)
    print(var_0)
    print(type(var_0))

    # Test 1
    str_1 = 'l*c '
    var_1 = parse_kv(str_1)
    print(var_1)
    print(type(var_1))

    # Test 2
    test_2 = 'l = v'
    var_2 = parse_kv(test_2)
    print(var_2)
    print(type(var_2))

    # Test 3
    test_3 = 'l=v'
    var_3 = parse_kv(test_3)
    print(var_3)
    print(type(var_3))

    # Test

# Generated at 2022-06-25 04:09:28.653874
# Unit test for function parse_kv
def test_parse_kv():
    # Unit: test_case_0
    str_0 = 'l*c'
    var_0 = parse_kv(str_0)
    assert var_0 == {'_raw_params': 'l*c'}



# Generated at 2022-06-25 04:09:47.677735
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 04:09:51.913802
# Unit test for function split_args
def test_split_args():
    str_1 = 'a=b c="foo bar"'

# Generated at 2022-06-25 04:10:00.411966
# Unit test for function parse_kv
def test_parse_kv():
    string_1 = 'l*c'

    # Testing if the string_1 was parsed by parse_kv properly
    test_1 = parse_kv(string_1)
    assert test_1 == {'_raw_params': 'l*c'}

    string_2 = 'l*c*'

    # Testing if the string_2 was parsed by parse_kv properly
    test_2 = parse_kv(string_2)
    assert test_2 == {'_raw_params': 'l*c*'}

    string_3 = '-query "select * from `test_sales`"'

    # Testing if the string_3 was parsed by parse_kv properly
    test_3 = parse_kv(string_3)

# Generated at 2022-06-25 04:10:05.437584
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'l*c'
    var_0 = parse_kv(str_0)
    print(var_0)


# Generated at 2022-06-25 04:10:10.588863
# Unit test for function split_args
def test_split_args():
    test_cases = [
        '"file=\'file1\'" \'a=b c=d\''
    ]
    for case in test_cases:
        print(case)
        print(split_args(case))


# Generated at 2022-06-25 04:10:20.947384
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '-a -b -c'
    str_1 = '-a -b=c'
    str_2 = 'foo=bar foo=oldbar foo=oldbar'
    str_3 = 'foo=bar foo=oldbar foo="oldbar with spaces"'
    str_4 = "extravar='this=test'"
    str_5 = '"test" \'test\''
    str_6 = "--extra-vars='{"
    str_7 = "foo='bar baz'"
    str_8 = "foo='bar baz'"
    str_9 = 'key7="a\=b\ c"'

    var_0 = parse_kv(str_0)
    var_1 = parse_kv(str_1)
    var_2 = parse_kv(str_2)


# Generated at 2022-06-25 04:10:31.036875
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = ''
    var_0 = parse_kv(str_0)
    assert var_0 == {}
    str_0 = 'a=b'
    var_0 = parse_kv(str_0)
    assert var_0 == {'a': 'b'}
    str_0 = "a=b c=d"
    var_0 = parse_kv(str_0)
    assert var_0 == {'a': 'b', 'c': 'd'}
    str_0 = "a=b c=d e=f 'a g'='b c'"
    var_0 = parse_kv(str_0)
    assert var_0 == {'a': 'b', 'c': 'd', 'e': 'f', 'a g': 'b c'}
    str_0

# Generated at 2022-06-25 04:10:40.559896
# Unit test for function split_args
def test_split_args():
    # Test case 1:
    # The function is being called with empty formatted string ("")
    #   The function should return a list of one string
    #   The string should be empty as well
    ans_1 = ['']
    try:
        ret_1 = split_args("")
        print("Test case 1 passed.\n")
    except Exception:
        print("Test case 1 failed.\n")

    # Test case 2:
    # The function is being called with a string containing only one character
    #   The function should return a list of one string
    #   The string should be the same as the input string
    ans_2 = ['a']

# Generated at 2022-06-25 04:10:45.040031
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'l*c'
    var_0 = parse_kv(str_0)

    #Test case 0
    #assert var_0 == {'_raw_params': "ls -l | grep 'c'"}


# Split the given args (a string) into a list.
# This is mostly shlex.split() except that it handles unicode
# and ansible's weird handling of quoted strings.

# Generated at 2022-06-25 04:10:50.789695
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'a=b c="d e" f="g h" i=\'j k l\''
    var_0 = parse_kv(str_0)
    assert var_0 == {'a': 'b', 'i': 'j k l', 'f': 'g h', 'c': 'd e'}


# Generated at 2022-06-25 04:11:05.917391
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '-m copy -a "src={{ src_file }} dest={{ dest_file }}" -s dest=/tmp '
    str_0 += '-e'
    var_0 = parse_kv(str_0)
    var_1 = {
        'a': 'src={{ src_file }} dest={{ dest_file }}',
        's': 'dest=/tmp',
        '_raw_params': '-e',
        'm': 'copy'
    }

    if var_0 == var_1:
        print("test_parse_kv: OK")
    else:
        print("test_parse_kv: NG")
        for key, value in var_0.items():
            print("key: ", key)
            print("value: ", value)


# This is a complete implementation