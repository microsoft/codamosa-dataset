

# Generated at 2022-06-25 04:02:29.600610
# Unit test for function split_args

# Generated at 2022-06-25 04:02:35.332142
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = 'OPTIONS=(--with-opt-dir=${OPT_DIR} --with-libraries=${LIB_DIR} --with-sysroot=${TARGET} --prefix=${PREFIX})'
    # var_0 = '--prefix=/home/dev/git/lmi'
    # var_0 = '--prefix=/home/dev/git/lmi --exec-prefix=PATH'
    # var_0 = '--exec-prefix=/usr/bin'
    # var_0 = '--exec-prefix=/usr/local/bin'
    var_1 = parse_kv(var_0)
    print(var_1)

if __name__ == '__main__':
    test_case_0()
    # test_parse_kv()

# Generated at 2022-06-25 04:02:38.803824
# Unit test for function parse_kv
def test_parse_kv():
    # result should be same as test_case_0
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()


# Generated at 2022-06-25 04:02:47.967468
# Unit test for function split_args
def test_split_args():
    # '  a="b c"  d  ' #
    args = 'a="b c" d'
    args_result = ['a="b c"', 'd']
    assert split_args(args) == args_result

    # 'a="b c" "d e" f=\\"g\\"' #
    args = 'a="b c" "d e" f=\\"g\\"'
    args_result = ['a="b c"', '"d e"', 'f=\\"g\\"']
    assert split_args(args) == args_result

    # 'a={{ b }} c={{ d }}' #
    args = 'a={{ b }} c={{ d }}'
    args_result = ['a={{ b }}', 'c={{ d }}']
    assert split_args(args)

# Generated at 2022-06-25 04:02:51.250129
# Unit test for function split_args
def test_split_args():
    print("testing split_args")
    var_0 = join_args([u'a=b', u'c="foo bar"'])
    var_1 = split_args(var_0)
    print("var_0 = " + str(var_0))
    print("var_1 = " + str(var_1))
    print("")


# Generated at 2022-06-25 04:03:01.450437
# Unit test for function split_args
def test_split_args():
    # No params
    params = split_args('')
    assert params == []

    # Split on newlines
    params = split_args('\n')
    assert params == ['\n']

    params = split_args('\n\n')
    assert params == ['\n', '\n']

    # Split on spaces, newlines
    params = split_args(' \n')
    assert params == [' ', '\n']

    params = split_args(' \n ')
    assert params == [' ', '\n', ' ']

    params = split_args(' \n \n ')
    assert params == [' ', '\n', ' ', '\n', ' ']

    # Basic parsing
    params = split_args('a')
    assert params == ['a']

    params = split_args('a b')


# Generated at 2022-06-25 04:03:03.974992
# Unit test for function split_args
def test_split_args():
    arg1 = "a=b c=\\'foo bar\\'"

# Generated at 2022-06-25 04:03:07.360808
# Unit test for function split_args
def test_split_args():
    # arg_string = "Ansible is (very) {awesome} [software]"
    arg_string = "Ansible is (very) {awesome}"
    parsed = split_args(arg_string)
    print(parsed)


# Generated at 2022-06-25 04:03:13.874436
# Unit test for function split_args
def test_split_args():
    test_cases = []

    # test case 0
    test_case_0_args = "arg1=val1 arg2=val2"
    test_case_0_expect = ['arg1=val1', 'arg2=val2']
    test_cases.append((test_case_0_args, test_case_0_expect))

    # test case 1
    test_case_1_args = "arg1=val1 arg2=val2 arg3='val3'"
    test_case_1_expect = ['arg1=val1', 'arg2=val2', "arg3='val3'"]
    test_cases.append((test_case_1_args, test_case_1_expect))

    # test case 2

# Generated at 2022-06-25 04:03:23.717398
# Unit test for function parse_kv
def test_parse_kv():
    bool_0 = False

# Generated at 2022-06-25 04:03:45.878076
# Unit test for function split_args
def test_split_args():
    options = parse_kv("name=test.conf a=b")
    print(options)
    options = parse_kv("name=test.conf\na=b")
    print(options)
    options = parse_kv("name=test.conf\na=b\nc=\"foo bar\"")
    print(options)
    options = parse_kv("name=test.conf\na=b\nc=\"foo bar\" d='foo bar'")
    print(options)
    options = parse_kv("a=\"{{ foo }}\" b=\"{{ foo }}\" c='{{ foo }}'")
    print(options)


    s = 'bash -c "python -c \'print(\"hello\")\'"'
    print(s)
    print(split_args(s))
    params = split_args(s)


# Generated at 2022-06-25 04:03:53.811598
# Unit test for function parse_kv
def test_parse_kv():
    # Initialization of args
    args = u"a=b c=d"

    # Initialization of check_raw
    check_raw = True

    # Call to the function
    dict_0 = parse_kv(args, check_raw)

    # Check if dict_0 == expected_dict_0
    expected_dict_0 = {"a": "b", "c": "d", "_raw_params": "a=b c=d"}
    assert dict_0 == expected_dict_0

# Generated at 2022-06-25 04:04:02.401731
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.parsing.dataloader import DataLoader

    data = u'arg1=foo arg2="foo bar" arg3=\'foo bar baz\''
    parsed = parse_kv(data, check_raw=False)
    assert parsed == dict(arg1=u'foo', arg2=u'foo bar', arg3=u'foo bar baz')

    data = u'arg1=foo arg2="foo bar\nblah" arg3=\'foo bar baz\''
    parsed = parse_kv(data, check_raw=False)
    assert parsed == dict(arg1=u'foo', arg2=u'foo bar\nblah', arg3=u'foo bar baz')


# Generated at 2022-06-25 04:04:09.238190
# Unit test for function parse_kv
def test_parse_kv():
    # Booleans are converted to actual bools from strings
    assert parse_kv(u"foo=True") == {u'foo': True}
    assert parse_kv(u"foo=False") == {u'foo': False}

    # Special Ansible variables are removed if they are found as keys
    assert parse_kv(u"ansible_foo=bar") == {u'foo': u'bar'}

    # Single-quoted strings are processed properly
    assert parse_kv(u"foo='bar baz'") == {u'foo': u'bar baz'}
    assert parse_kv(u"foo='bar baz' bar='foo bar'") == {u'foo': u'bar baz', u'bar': u'foo bar'}

    # Double-quoted strings are processed properly
    assert parse

# Generated at 2022-06-25 04:04:10.116568
# Unit test for function parse_kv
def test_parse_kv():
    assert True


# Generated at 2022-06-25 04:04:20.519115
# Unit test for function parse_kv
def test_parse_kv():
    # Test case for parse_kv
    bool_0 = False

# Generated at 2022-06-25 04:04:25.818903
# Unit test for function parse_kv
def test_parse_kv():
    arg_0 = ['creates=testfile', 'removes=testfile2', 'chdir=testdir', 'executable=testfile3', 'warn=yes']
    check_raw_0 = False
    ret_0 = parse_kv(arg_0, check_raw_0)
    test_case_0()



# Generated at 2022-06-25 04:04:36.856790
# Unit test for function parse_kv
def test_parse_kv():
    test_kv_0 = "key1=value1 key2=value2"
    test_kv_1 = ""
    test_kv_2 = "key1='value1' key2='value2'"
    test_kv_3 = "key1=\"value1\" key2=\"value2\""
    test_kv_4 = "key1='value1' key2=\"value2\""
    test_kv_5 = "key1=\"value1\" key2='value2'"
    test_kv_6 = "key1='value1' key2=value2"
    test_kv_7 = "key1=value1 key2='value2'"
    test_kv_8 = "key1='value1' key2=value2"

# Generated at 2022-06-25 04:04:38.909183
# Unit test for function split_args
def test_split_args():
    # Unit test for function split_args
	args = "ls -l -a /etc"
	params = split_args(args)
	print(params)


# Generated at 2022-06-25 04:04:44.205986
# Unit test for function parse_kv
def test_parse_kv():
    args = "key1=value1 key2=value2"
    check_raw = False
    actual_return = parse_kv(args, check_raw)
    expected_return = {u"key1": u"value1", u"key2": u"value2"}
    assert actual_return == expected_return

# Test for function parse_kv

# Generated at 2022-06-25 04:05:03.811002
# Unit test for function parse_kv
def test_parse_kv():
    assert to_text(parse_kv('abc=def xyz=123')) == {u'abc': u'def', u'xyz': u'123'}
    assert to_text(parse_kv('abc="def xyz" 123="w xyz"')) == {u'abc': u'def xyz', u'123': u'w xyz'}
    #assert to_text(parse_kv(u'abc="def xyz" 123="w xyz"')) == {u'abc': u'def xyz', u'123': u'w xyz'}
    assert to_text(parse_kv(u'abc="def xyz" 123="w xyz"')) == {u'abc': u'def xyz', u'123': u'w xyz'}

# Generated at 2022-06-25 04:05:06.212570
# Unit test for function parse_kv
def test_parse_kv():
    try:
        # Test for string input
        test_case_0()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 04:05:14.081526
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv("key0=val0 key1=val1")
    assert result['key0'] == 'val0'
    assert result['key1'] == 'val1'
    result = parse_kv("key0='val0' key1='val1'")
    assert result['key0'] == 'val0'
    assert result['key1'] == 'val1'
    result = parse_kv("key0=\"val0\" key1=\"val1\"")
    assert result['key0'] == 'val0'
    assert result['key1'] == 'val1'
    result = parse_kv("key0='val0 key1=val1'")
    assert result['key0'] == 'val0 key1=val1'

# Generated at 2022-06-25 04:05:19.562423
# Unit test for function split_args
def test_split_args():
    print('==test_split_args==')
    assert split_args('"cd test"; \\\"cd test\\\"; echo x') == ['cd test', '\\"cd test\\"', 'echo x']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('''a=b''') == ['a=b']

# Generated at 2022-06-25 04:05:21.319998
# Unit test for function split_args
def test_split_args():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 04:05:23.847666
# Unit test for function split_args
def test_split_args():
    print("Test 0: Test when split_args is called with no arguments.")
    assert split_args() == []


# Generated at 2022-06-25 04:05:31.668631
# Unit test for function split_args
def test_split_args():
    print('Test: test_1: Simple case split')
    try:
        params = split_args('a=b c="foo bar"')
        print(params)
        assert params[0] == 'a=b'
        assert params[1] == 'c="foo bar"'
    except:
        print('Expected no exception thrown')
        return False


# Generated at 2022-06-25 04:05:38.672834
# Unit test for function split_args
def test_split_args():
    print('Test case 0')
    bool_0 = True
    var_0 = parse_kv(bool_0)

    print('Test case 1')
    var_1 = split_args('')

    print('Test case 2')
    var_2 = split_args('abc')

    print('Test case 3')
    var_3 = split_args('{%')

    print('Test case 4')
    var_4 = split_args('{{')

    print('Test case 5')
    var_5 = split_args('{#')

    print('Test case 6')
    var_6 = split_args('a b c')

    print('Test case 7')
    var_7 = split_args('a\nb\nc')

    print('Test case 8')

# Generated at 2022-06-25 04:05:48.831952
# Unit test for function parse_kv
def test_parse_kv():
    bool_0 = True
    var_0 = parse_kv(bool_0)
    assert var_0 == True
    str_0 = "a == b"
    var_1 = parse_kv(str_0)
    assert var_1 == "a "
    str_1 = 'a == "b"'
    var_2 = parse_kv(str_1)
    assert var_2 == "a  ==  b"
    bool_1 = False
    var_3 = parse_kv(bool_1)
    assert var_3 == False
    str_2 = "a b c"
    var_4 = parse_kv(str_2)
    assert var_4 == "a  b  c"
    str_3 = 'a == "b" c == "d"'

# Generated at 2022-06-25 04:05:55.423973
# Unit test for function parse_kv
def test_parse_kv():
    print('[*] Test 0#: Function parse_kv')
    bool_0 = True
    var_0 = parse_kv(bool_0)
    if var_0 != {}:
        if bool_0:
            print('[-] TEST FAILED: Line 71')
            print('[*] Expected')
            print('{}')
            print('[*] Got:')
            print(var_0)
            quit(1)

    print('[*] Test 1#: Function parse_kv')
    bool_1 = True
    var_1 = parse_kv(bool_1)
    if var_1 != {}:
        if bool_1:
            print('[-] TEST FAILED: Line 77')
            print('[*] Expected')
            print('{}')
           

# Generated at 2022-06-25 04:06:08.978504
# Unit test for function parse_kv
def test_parse_kv():
    print("===START===\n")
    print("===MIDDLE===\n")
    print("===END===")

test_parse_kv()

# Generated at 2022-06-25 04:06:15.386014
# Unit test for function split_args

# Generated at 2022-06-25 04:06:20.979858
# Unit test for function parse_kv
def test_parse_kv():
    test_0 = ('a=1 b="2 3" c="4, 5"')
    res_0 = {'a': '1', 'b': '2 3', 'c': '4, 5', '_raw_params': ''}
    assert parse_kv(test_0) == res_0

    test_1 = ('a=b=c')
    res_1 = {'a': 'b=c', '_raw_params': ''}
    assert parse_kv(test_1) == res_1

    test_2 = ('a="b=c=d"')
    res_2 = {'a': 'b=c=d', '_raw_params': ''}
    assert parse_kv(test_2) == res_2


# Generated at 2022-06-25 04:06:23.144792
# Unit test for function split_args
def test_split_args():
    bool_0 = True
    var_0 = split_args(bool_0)



# Generated at 2022-06-25 04:06:26.600843
# Unit test for function parse_kv
def test_parse_kv():
    assert(test_case_0())


# Generated at 2022-06-25 04:06:34.415611
# Unit test for function split_args
def test_split_args():
    print('\n')
    result = split_args("a=b c=\"foo bar\"")
    print(result)
    print(split_args("a=b c=foo bar"))
    print(split_args("a=b c=foo bar {% if 1==1 %}"))
    print(split_args('a=b c=foo bar {% if 1==1 %}'))
    print(split_args('a=b c=foo bar {{ foo.bar }}'))

# Generated at 2022-06-25 04:06:45.308400
# Unit test for function split_args
def test_split_args():
    #Simple case
    var_0 = split_args("foo=bar")
    assert var_0 == ['foo=bar']
    var_1 = split_args("foo=bar baz=foo")
    assert var_1 == ['foo=bar', 'baz=foo']
    var_2 = split_args("foo=bar\\ baz=foo")
    assert var_2 == ['foo=bar baz=foo']
    var_3 = split_args("foo=bar\\\nbaz=foo")
    assert var_3 == ['foo=bar\nbaz=foo']
    var_4 = split_args("foo bar")
    assert var_4 == ['foo', 'bar']
    var_5 = split_args("foo 'bar baz'")
    assert var_5 == ['foo', '\'bar baz\'']

# Generated at 2022-06-25 04:06:49.468856
# Unit test for function split_args
def test_split_args():
    args = '''a=b c="foo bar"'''
    result = split_args(args)
    assert(result == ['a=b', 'c="foo bar"'])

test_split_args()

# Generated at 2022-06-25 04:06:57.581506
# Unit test for function split_args
def test_split_args():
    print("\n************************************\n")

    str_0 = " "
    str_0 = split_args(str_0)

    str_0 = " a=b c=\"foo bar\""
    str_0 = split_args(str_0)

    str_0 = "a={{b}} c=\"foo bar\""
    str_0 = split_args(str_0)

    str_0 = "{%if a == 'b'%} bar {% endif %}"
    str_0 = split_args(str_0)

    str_0 = "a=b\\ c=\"foo bar\"" #\
    str_0 = split_args(str_0)

    str_0 = '''a=b
c=d
e=f'''
    str_0 = split_args(str_0)


# Generated at 2022-06-25 04:07:00.555449
# Unit test for function parse_kv
def test_parse_kv():
    print('Function parse_kv passed all tests!')

if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-25 04:07:17.195350
# Unit test for function parse_kv
def test_parse_kv():
    bool_0 = True
    var_0 = parse_kv(bool_0)
    print(var_0)


# -------------------------
# Functions for splitting and joining arguments for shell execution
# (used by several modules)
#
# This is a stripped-down version of shlex.py, included because
# it avoids problems with unicode handling and other incompatibilities
# on Python 2.6.  In the future, we should consider switching to
# proper use of shlex.

WHITESPACE = ' \t\r\n'
QUOTES = '\'"'

# Posix allows single-quoted strings to have single-quote literals
# and double-quoted strings to have double-quote literals, but not
# the other way around.  This means single-quoted strings can have
# double-quote literals and

# Generated at 2022-06-25 04:07:19.451450
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']



# Generated at 2022-06-25 04:07:28.944251
# Unit test for function split_args
def test_split_args():
    assert split_args("ls") == ["ls"]
    assert split_args("echo {{ something }}") == ["echo", "{{ something }}"]
    assert split_args("echo {{ something }} > /path/to/foo") == ["echo", "{{ something }}", ">", "/path/to/foo"]
    assert split_args("/path/to/foo > echo {{ something }}") == ["/path/to/foo", ">", "echo", "{{ something }}"]
    assert split_args("uname") == ["uname"]
    assert split_args("uname -a") == ["uname", "-a"]
    assert split_args("useradd name={{ user }}") == ["useradd", "name={{ user }}"]

# Generated at 2022-06-25 04:07:36.991523
# Unit test for function split_args
def test_split_args():

    # Positive test 1
    line1 = 'a=b c="foo bar" \'foo bar\''
    expected_results1 = ['a=b', 'c="foo bar"', '\'foo bar\'']
    results1 = split_args(line1)
    if not (results1 == expected_results1):

        print("Error in %s: expected %s but got %s" % (line1, expected_results1 , results1))

    # Positive test 2
    line2 = 'grep -q fail=0 test.log'
    expected_results2 = ['grep', '-q', 'fail=0', 'test.log']
    results2 = split_args(line2)

# Generated at 2022-06-25 04:07:38.872731
# Unit test for function parse_kv
def test_parse_kv():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 04:07:48.174659
# Unit test for function split_args
def test_split_args():
    list_0 = list()
    list_0.append('arch=arm64')
    list_0.append('base=ubuntu/bionic64')
    list_0.append('memory=1024')
    list_0.append('cpus=2')
    list_0.append('extra_args="-no-reboot"')
    # usage:
    #    ansible-playbook main.yml -e vm_name=test-vm-1 -e annex_repo='https://github.com/brianmay/vagrant-annex.git' -e arch=arm64 -e base=ubuntu/bionic64 -e memory=1024 -e cpus=2 -e extra_args="-no-reboot"
    #    ansible-playbook main.yml -e vm_name=test-vm-1 -e annex

# Generated at 2022-06-25 04:07:52.427610
# Unit test for function parse_kv
def test_parse_kv():
    # Setup test case
    test_case_0()


# Generated at 2022-06-25 04:07:58.356141
# Unit test for function parse_kv
def test_parse_kv():
    # SUT setup
    bool_0 = "jrB+E/O"

    # Run unit under test
    var_0 = parse_kv(bool_0)

    assert True


# Generated at 2022-06-25 04:08:06.592516
# Unit test for function parse_kv
def test_parse_kv():
    print("Unit test for parse_kv")

    try:
        test_case_0()
    except Exception as e:
        print("Failed")
        return 1
    else:
        print("Succeed")
        return 0

###############################
# split_args and join_args adapted from Ansible utils.module_docs_fragments
# which is licensed under the GPLv3.
###############################


# Generated at 2022-06-25 04:08:12.391062
# Unit test for function split_args

# Generated at 2022-06-25 04:08:25.506561
# Unit test for function split_args
def test_split_args():
    var_0 = "a=b c=\"foo bar\""
    var_1 = split_args(var_0)
    # print(var_1)


# Generated at 2022-06-25 04:08:32.703860
# Unit test for function parse_kv
def test_parse_kv():
    print("[+] Testing parse_kv()")
    assert callable(parse_kv), "parse_kv() not callable"
    # Test #0
    try:
        print("\t[-] Testing call parse_kv() with 'True'")
        test_case_0()
        print("\t\t[+] No Exception raised")
    except Exception as e:
        print("\t\t[-] Exception raised: " + str(e))
    # Test #1
    try:
        print("\t[-] Testing call parse_kv() with 'False'")
        test_case_1()
        print("\t\t[+] No Exception raised")
    except Exception as e:
        print("\t\t[-] Exception raised: " + str(e))
    #

# Generated at 2022-06-25 04:08:38.877867
# Unit test for function parse_kv
def test_parse_kv():
    with open('./test/unit/parsing/parser/test_case_0.txt') as fh:
        data = fh.read()
        bool_0 = True
        var_0 = parse_kv(data)



# Generated at 2022-06-25 04:08:48.990295
# Unit test for function parse_kv
def test_parse_kv():
    bool_0 = u'b"\\'
    bool_1 = u"\\'"
    bool_2 = u"\\'"
    bool_3 = u'\\'
    bool_4 = u'\\'
    bool_5 = u'\\'
    bool_6 = u"'"
    bool_7 = u"'"
    bool_8 = u"'"
    bool_9 = u'"'
    bool_10 = u'"'
    bool_11 = u'"'
    bool_12 = u'\\'
    bool_13 = u'\\'
    bool_14 = u'\\'
    bool_15 = u'\\'
    bool_16 = u'\\'
    bool_17 = u'\\'
    bool_18 = u'\\'
    bool_19 = u'\\'
    bool_

# Generated at 2022-06-25 04:08:55.297104
# Unit test for function parse_kv
def test_parse_kv():
    # example_0
    bool_0 = True
    var_0 = parse_kv(bool_0)

    # example_1
    bool_1 = True
    var_1 = parse_kv(bool_1, bool_1)


# Utility functions for working with quoted strings

# Generated at 2022-06-25 04:09:07.096254
# Unit test for function split_args
def test_split_args():

    # function parameters
    str_0 = "A=1"
    str_1 = "B=1"
    str_2 = "C=1"
    bool_0 = True
    bool_1 = False
    bool_2 = True
    bool_3 = False
    bool_4 = True
    bool_5 = False
    bool_6 = False

    # Output tuples (expected)
    out_tuple_0 = ('A=1',)
    out_tuple_1 = ('B=1',)
    out_tuple_2 = ('C=1',)
    out_tuple_3 = ('A=1', 'B=1')
    out_tuple_4 = ('A=1', 'B=1', 'C=1')

# Generated at 2022-06-25 04:09:12.755070
# Unit test for function split_args
def test_split_args():
    args = ''' a="b" c="foo bar"'''
    params = split_args(args)
    assert isinstance(params, list) and params == ['a=b', 'c="foo bar"']

    args = '''a=b c="foo bar"'''
    params = split_args(args)
    assert isinstance(params, list) and params == ['a=b', 'c="foo bar"']

    args = '''a=b c="foo bar' '''
    params = split_args(args)
    assert isinstance(params, list) and params == ['a=b', 'c="foo bar']

    args = '''a=b c="foo bar' d=e '''
    params = split_args(args)

# Generated at 2022-06-25 04:09:22.060159
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c=d') == ['a=b', 'c=d'] 
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a b\nc d') == ['a', 'b\nc', 'd']
    assert split_args('a b\nc d\n') == ['a', 'b\nc', 'd\n']
    assert split_args('a b\\\nc d') == ['a', 'b\\\nc', 'd']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=\'foo bar\'')

# Generated at 2022-06-25 04:09:23.857017
# Unit test for function parse_kv
def test_parse_kv():
    bool_0 = False
    var_0 = parse_kv(bool_0)
    assert var_0 == dict()



# Generated at 2022-06-25 04:09:27.900912
# Unit test for function parse_kv
def test_parse_kv():
    bool_0 = True
    var_0 = parse_kv(bool_0)

# Test arguments.
args = [
    False,
    'true',
    'false',
    True,
    'True',
    'False',
]

# Positional arguments for the function template
kwargs = {
}


# Generated at 2022-06-25 04:09:34.511383
# Unit test for function parse_kv
def test_parse_kv():
    assert callable(parse_kv)



# Generated at 2022-06-25 04:09:40.518705
# Unit test for function split_args
def test_split_args():
    args_0 = "a=b c=\"foo bar\""
    result_0 = split_args(args_0)
    assert result_0 == ['a=b', 'c="foo bar"']


# Generated at 2022-06-25 04:09:51.969784
# Unit test for function parse_kv
def test_parse_kv():
    var_1 = 'var_1'
    var_2 = ',var_2'
    var_3 = '"var_3"'
    var_4 = 'var_4,'
    var_5 = '"var_5"'
    var_6 = ',var_6'
    var_7 = 'var_7,'
    var_8 = '"var_8"'
    var_9 = ',var_9'
    var_10 = 'var_10,'
    var_11 = '"var_11"'
    var_12 = ',var_12'
    var_13 = 'var_13,'
    var_14 = '"var_14"'
    var_15 = ',var_15'
    var_16 = 'var_16,'
    var_17 = '"var_17"'

# Generated at 2022-06-25 04:10:00.438592
# Unit test for function parse_kv
def test_parse_kv():
    print(parse_kv(None))
    print(parse_kv('-name=val -name2="with quotes" -name3="closing quote missing'))
    print(parse_kv('-name=val -name2="with quotes" -name3="closing quote missing'))
    print(parse_kv('-name=val -name2=with quotes -name3=closing quote missing'))
    print(parse_kv('-name=val -name2="with spaces"'))
    print(parse_kv('-name=\"val -name2="with spaces"'))
    print(parse_kv('-name="val -name2="with spaces"'))
    print(parse_kv('-name="val -name2=with spaces"'))

# Generated at 2022-06-25 04:10:09.146613
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.urls import open_url
    import os
    import datetime
    import dir_listing
    from ansible.module_utils.urls import open_url
    home_page_url = "http://www.sbs.com.au"
    d_listing = dir_listing.get_page_content(home_page_url)
    print (d_listing)

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:10:13.192059
# Unit test for function parse_kv
def test_parse_kv():
    print("\nRunning Tests for parse_kv function\n")
    print("Case 0: Boolean parameter True")
    test_case_0()


# Generated at 2022-06-25 04:10:22.276249
# Unit test for function split_args
def test_split_args():
    # Test the case where there are no quotes
    assert split_args('a=b c=d') == ['a=b', 'c=d']

    # Test the case where there are quotes
    assert split_args('a=\'b c\' d=f') == ['a=\'b c\'', 'd=f']

    # Test the case where there are double quotes
    assert split_args('a="b c" d=f') == ['a="b c"', 'd=f']

    # Test the case where there are escaped quotes
    assert split_args('a="b c" d=f g=h i=\\"j k"') == ['a="b c"', 'd=f', 'g=h', 'i=\\"j k"']

    # Test the case where there are escaped quotes and quotes within quotes
    assert split

# Generated at 2022-06-25 04:10:26.081012
# Unit test for function parse_kv
def test_parse_kv():
    bool_0 = True
    var_0 = parse_kv(bool_0)
    assert var_0 == {}


# Generated at 2022-06-25 04:10:36.228111
# Unit test for function split_args
def test_split_args():
    args = '''
    - name: test with_items
      shell: echo {{item}}
      with_items:
        - test 1
        - test 2
        - test 3
        - test 4
    register: test_1
    '''
    params = split_args(args)
    print(params)
    assert params == ['-', 'name:', 'test with_items', 'shell:', 'echo {{item}}', 'with_items:', '-', 'test 1', '-', 'test 2', '-', 'test 3', '-', 'test 4', 'register:', 'test_1']


# Generated at 2022-06-25 04:10:46.181830
# Unit test for function split_args
def test_split_args():
    # Regular string
    test_1 = "hello world this is a test string"
    # Regular string but with quotes
    test_2 = "\"hello world this is a test string\""
    # Jinja2 template with inline variables
    test_3 = "{{ foo }}"
    # Jinja2 template with inline variables and quotes
    test_4 = "\"{{ foo }}\""
    # Jinja2 template with a jinja2 block
    test_5 = """
        {{ foo }}

        {{ bar }}
        """
    # Jinja2 template with a jinja2 block with quotes
    test_6 = """
        \"{{ foo }}\"

        {{ bar }}
        """

    # Join the test cases together

# Generated at 2022-06-25 04:11:01.052585
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing function parse_kv")

    # kv_1 = 
    # kv_result_1 = 
    # kv_2 = 
    # kv_result_2 = 
    # kv_3 = 
    # kv_result_3 = 
    # kv_4 = 
    # kv_result_4 = 
    # kv_5 = 
    # kv_result_5 = 
    # kv_6 = 
    # kv_result_6 = 

    # Run the function
    # kv_result = parse_kv(kv_1)
    # assert kv_result == kv_result_1

    # Run the function
    # kv_result = parse_kv(kv_2)
    # assert kv