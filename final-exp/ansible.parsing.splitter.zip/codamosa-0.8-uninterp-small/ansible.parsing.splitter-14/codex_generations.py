

# Generated at 2022-06-25 04:01:40.131553
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:01:45.916338
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'SF^\tZy=/3qV'
    kwargs = {
        'check_raw': True,
    }
    var_0 = parse_kv(str_0, **kwargs)
    var_1 = parse_kv(str_0, **kwargs)
    assert var_0 == var_1


# Generated at 2022-06-25 04:01:50.306569
# Unit test for function parse_kv
def test_parse_kv():
    args = 'key1=value1 key2=value2'
    actual = parse_kv(args)
    expected = {
        u'key1': u'value1',
        u'key2': u'value2',
        u'_raw_params': u'key1=value1 key2=value2'
    }
    assert actual == expected



# Generated at 2022-06-25 04:01:58.102512
# Unit test for function split_args
def test_split_args():
    str_0 = '\n'
    var_0 = split_args(str_0)
    print(var_0)
    print(join_args(var_0))
    assert(join_args(var_0) == '\n')
    str_1 = 'a=b c="foo bar"'
    var_1 = split_args(str_1)
    print(var_1)
    print(join_args(var_1))
    assert(join_args(var_1) == 'a=b c="foo bar"')
    str_2 = 'a=b \"foo bar\"'
    var_2 = split_args(str_2)
    print(var_2)
    print(join_args(var_2))

# Generated at 2022-06-25 04:02:01.604317
# Unit test for function split_args
def test_split_args():
    try:
        assert(split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"'])
    except AssertionError as e:
        print('AssertionError:', e)
    else:
        print('Test pass.')


# Generated at 2022-06-25 04:02:09.926792
# Unit test for function split_args
def test_split_args():
    str_0 = '\'a=b c="foo bar"\''
    assert split_args(str_0) == [u"\'a=b", u"c=\"foo bar\"\'"], 'Failed (1)'
    str_1 = 'a=b c="foo bar"'
    assert split_args(str_1) == [u'a=b', u'c="foo bar"'], 'Failed (2)'
    str_2 = 'a=b c="foo bar'
    assert split_args(str_2) == [u'a=b', u'c="foo bar'], 'Failed (3)'
    str_3 = 'a=b c="foo bar\''
    assert split_args(str_3) == [u'a=b', u'c="foo bar\''], 'Failed (4)'

# Generated at 2022-06-25 04:02:12.795606
# Unit test for function split_args
def test_split_args():
    var_0 = split_args(';\t\'Tp\rXR,\r1c]')
    return var_0


# Generated at 2022-06-25 04:02:20.883801
# Unit test for function parse_kv
def test_parse_kv():
    print("Test case 1:\n")
    str_0 = 'SF^\tZy'
    var_0 = parse_kv(str_0)
    print(var_0)

    print("Test case 2:\n")
    str_1 = 'SF^\tZy'
    var_1 = parse_kv(str_1)
    print(var_1)


print("Test: split_args")
test_case_0()

# can be used to test the function

# Generated at 2022-06-25 04:02:29.922804
# Unit test for function parse_kv
def test_parse_kv():
    ans_0 = {'_raw_params': 'a=1'}
    var_0 = parse_kv('a=1')
    if not ans_0 == var_0:
        raise ValueError('Unexpected output for {}. Got {}, expected {}.'.format(str_0, var_0, ans_0))
    ans_1 = {'_raw_params': 'a="1 \\"b\\""'}
    var_1 = parse_kv('a="1 \\"b\\""')
    if not ans_1 == var_1:
        raise ValueError('Unexpected output for {}. Got {}, expected {}.'.format(str_0, var_0, ans_0))
    ans_2 = {'_raw_params': 'a=\'1 \\"b\\""'}
    var_2 = parse

# Generated at 2022-06-25 04:02:39.537042
# Unit test for function split_args
def test_split_args():
    input_0 = 'a cmd "some args" # this is a comment'
    expected_0 = ['a', 'cmd', '"some args"', '# this is a comment']
    assert split_args(input_0) == expected_0

    input_1 = "a cmd 'some args' # this is a comment"
    expected_1 = ['a', 'cmd', "'some args'", '# this is a comment']
    assert split_args(input_1) == expected_1

    input_2 = 'a cmd "\\"some args\\"" # this is a comment'
    expected_2 = ['a', 'cmd', '"\\"some args\\""', '# this is a comment']
    assert split_args(input_2) == expected_2


# Generated at 2022-06-25 04:02:49.630776
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'SF^\tZy'
    test_case_0()
    test_case_0()
    var_0 = parse_kv(str_0, True)


# Generated at 2022-06-25 04:03:01.345970
# Unit test for function split_args
def test_split_args():
    str = "2.0.0-SNAPSHOT:clean install -Dmaven.test.skip=true -Dmaven.javadoc.skip=true -s .m2/settings.xml"
    var = split_args(str)
    print(str)
    print(var)

    str_0 = 'SF^\tZy'
    var_0 = split_args(str_0)
    print(str_0)
    print(var_0)

    str_1 = 'wget -N "http://172.29.16.9/war/{{war_name}}/{{war_name}}.war" -O {{user_home}}/{{war_name}}.war'
    var_1 = split_args(str_1)
    print(str_1)

# Generated at 2022-06-25 04:03:02.810912
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'SF^\tZy'
    res = parse_kv(str_0, check_raw=False)


# Generated at 2022-06-25 04:03:03.515524
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 04:03:07.830974
# Unit test for function split_args
def test_split_args():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()

# Generated at 2022-06-25 04:03:12.370921
# Unit test for function split_args
def test_split_args():
    str_0 = "{{a.b}} string"
    var_0 = split_args(str_0)
    var_1 = join_args(var_0)
    print(var_0)
    print(var_1)
    str_1 = "john smith 'bob stone'"
    var_2 = split_args(str_1)
    var_3 = join_args(var_2)
    print(var_2)
    print(var_3)
    str_2 = "john smith 'bob stone' 'a=b c=d e=f'"
    var_4 = split_args(str_2)
    var_5 = join_args(var_4)
    print(var_4)
    print(var_5)

# Generated at 2022-06-25 04:03:17.736567
# Unit test for function split_args
def test_split_args():
    ##########################################################################
    # Test 1: check the returned value of split_args given a simple string
    ##########################################################################
    # Define input string
    str_1 = 'hello world'
    # Function call
    var_1 = split_args(str_1)
    # Expected result
    exp_1 = ['hello', 'world']
    # Test that the returned value equals to expected result
    assert var_1 == exp_1


    ##########################################################################
    # Test 2: check the returned value of split_args given a quoted string
    ##########################################################################
    # Define input string
    str_2 = 'hello \'word\' world'
    # Function call
    var_2 = split_args(str_2)
    # Expected result

# Generated at 2022-06-25 04:03:26.010244
# Unit test for function split_args
def test_split_args():
    str_0 = 'SF^\tZy'
    var_0 = split_args(str_0)
    if var_0 == ['SF', '^', 'Zy']:
        print('pass test_case_0')
    else:
        print('fail test_case_0')
    str_1 = 'SF^\tZyAC\rG'
    var_1 = split_args(str_1)
    if var_1 == ['SF', '^', 'Zy', 'AC', 'G']:
        print('pass test_case_1')
    else:
        print('fail test_case_1')
    str_2 = 'SF^\tZyAC\rGpr'
    var_2 = split_args(str_2)

# Generated at 2022-06-25 04:03:33.059901
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'SF^\tZy'
    var_0 = split_args(str_0)
    str_1 = 'x&\n\'|'
    var_1 = join_args(var_0)

    str_2 = 'SF^\tZy'
    var_2 = split_args(str_2)
    var_3 = parse_kv(var_2, False)
    str_3 = 'SF^\tZy'
    var_4 = parse_kv(str_3, False)
    str_4 = 'SF^\tZy'
    var_5 = split_args(str_4)
    var_6 = parse_kv(var_5, False)
    var_7 = parse_kv(var_6, False)

# Generated at 2022-06-25 04:03:41.298520
# Unit test for function split_args
def test_split_args():
    str_0 = 'SF^\tZy'
    var_0 = split_args(str_0)
    assert var_0 == ['SF^\tZy']

    str_1 = 'fX^\n^'
    var_1 = split_args(str_1)
    assert var_1 == ['fX^', '^']

    str_2 = 'fX^ '
    var_2 = split_args(str_2)
    assert var_2 == ['fX^']

    str_3 = 'a\tU6'
    var_3 = split_args(str_3)
    assert var_3 == ['a\tU6']

    str_4 = '^\tOo '
    var_4 = split_args(str_4)

# Generated at 2022-06-25 04:04:21.032712
# Unit test for function parse_kv
def test_parse_kv():
    arguments = "a=1 b=2 c=3"
    assert parse_kv(arguments) == {'a': '1', 'b': '2', 'c': '3'}

    arguments = "a=1 b=2 c='quoted'"
    assert parse_kv(arguments) == {'a': '1', 'b': '2', 'c': 'quoted'}

    arguments = "a=1 b='quoted' c='quotes \"inside quoted\"'"
    assert parse_kv(arguments) == {'a': '1', 'b': 'quoted', 'c': 'quotes \"inside quoted\"'}

    arguments = "a=1 b='quote\\'d'"
    assert parse_kv(arguments) == {'a': '1', 'b': "quote'd"}

    arguments

# Generated at 2022-06-25 04:04:22.532717
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()


# Generated at 2022-06-25 04:04:24.401222
# Unit test for function split_args
def test_split_args():
    #test_case_0()
    test_case_1()


# Generated at 2022-06-25 04:04:30.763903
# Unit test for function split_args
def test_split_args():
    print("==== Begin test_split_args ====")
    #test_case_0()
    test_split_args_1()
    print("==== End test_split_args ====")

# Generated at 2022-06-25 04:04:33.588807
# Unit test for function parse_kv
def test_parse_kv():
    test_string = "name=test"
    expected_value = {u'name': u'test'}
    actual_value = parse_kv(test_string)
    assert actual_value == expected_value


# Generated at 2022-06-25 04:04:38.352317
# Unit test for function split_args
def test_split_args():

    str_0 = 'SF^\tZy'
    str_1 = "a=b c=\"foo bar\""
    str_2 = u'a=b c="foo bar with spaces" d="foo=bar with equals"'
    str_3 = '"foo\nbar baz"\necho'
    str_4 = '"a \\"'
    str_5 = 'a b=c'
    str_6 = 'echo foo; echo bar'
    str_7 = 'echo a; echo "b c"'
    str_8 = u'a="b c"\nd="e f"'
    str_9 = "a=b\nc='foo bar'"
    str_10 = "echo 'foo\nbar baz'"
    str_11 = "a='foo\\'bar'"

# Generated at 2022-06-25 04:04:42.088915
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = "X'h\n"
    var_1 = parse_kv(var_0)
    print(var_1)

# Generated at 2022-06-25 04:04:46.120879
# Unit test for function parse_kv
def test_parse_kv():
    # Test when arguments are all key-value items
    str_0 = 'SF^\tZy'
    var_0 = parse_kv(str_0, True)
    assert(var_0['SF'] == '^\tZy')

    # Test when arguments are all free-form params
    str_1 = 'SF^\tZy'
    var_1 = parse_kv(str_1, False)
    assert(len(var_1) == 0)



# Generated at 2022-06-25 04:04:54.457461
# Unit test for function split_args
def test_split_args():
    # First case
    str_0 = 'a=b c="foo bar"'
    var_0 = split_args(str_0)
    assert len(var_0) == 2
    assert var_0[0] == 'a=b'
    assert var_0[1] == 'c="foo bar"'

    # Second case
    str_0 = '"a=b" c="foo bqar"'
    var_0 = split_args(str_0)
    assert len(var_0) == 2
    assert var_0[0] == '"a=b"'
    assert var_0[1] == 'c="foo bqar"'

    # Third case
    str_0 = '"a=b" c=\'foo bqar\''
    var_0 = split_args(str_0)


# Generated at 2022-06-25 04:04:56.579124
# Unit test for function split_args
def test_split_args():
    test_case_0()


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:05:25.965352
# Unit test for function split_args
def test_split_args():
    # Test case 1
    str_0 = 'invalid_user=1 op'
    var_0 = split_args(str_0)
    assert var_0 == ['invalid_user=1', 'op']
    # Test case 2
    str_0 = 'invalid_user = 1 op'
    var_0 = split_args(str_0)
    assert var_0 == ['invalid_user = 1', 'op']
    # Test case 3
    str_0 = 'invalid_user=1  op'
    var_0 = split_args(str_0)
    assert var_0 == ['invalid_user=1', 'op']
    # Test case 4
    str_0 = 'invalid_user=1 \t op'
    var_0 = split_args(str_0)

# Generated at 2022-06-25 04:05:32.155726
# Unit test for function split_args
def test_split_args():
    #1. no quoting
    str_0 = "SF^\tZy"
    str_1 = "SF^\tZy"
    var_1 = split_args(str_0)
    assert var_1 == str_1

    #2. 
    str_2 = 'SF^\tZy'



# Generated at 2022-06-25 04:05:37.241199
# Unit test for function split_args
def test_split_args():
    str1 = 'aaaaaaaaaaa'
    str2 = 'bbbbbbbbbbb'
    str3 = "ccccccccccc\n"
    str4 = "ddddddddddd\n"
    str5 = "eeeeeeeeeee\n"
    str6 = "fffffffffff\n"
    print(split_args(str1))
    print(split_args(str2))
    print(split_args(str3))
    print(split_args(str4))
    print(split_args(str5))
    print(split_args(str6))


# Generated at 2022-06-25 04:05:47.174593
# Unit test for function parse_kv
def test_parse_kv():
    # Test of case 0
    str_0 = 'SF^\tZy'
    var_0 = parse_kv(str_0)
    assert var_0 == {}
    # Test of case 1
    str_1 = '}F^QY\tW'
    var_1 = parse_kv(str_1)
    assert var_1 == {}
    # Test of case 2
    str_2 = '\t'
    var_2 = parse_kv(str_2)
    assert var_2 == {}
    # Test of case 3
    str_3 = '}F^QI\rE\t'
    var_3 = parse_kv(str_3)
    assert var_3 == {}
    # Test of case 4
    str_4 = 'O]UT1TP'
   

# Generated at 2022-06-25 04:05:54.583386
# Unit test for function split_args
def test_split_args():
    # Test if string 0 is properly split
    str_0 = 'SF^\tZy'
    var_0 = split_args(str_0)
    assert "SF" == var_0[0]
    assert "Zy" == var_0[1]

    # Test if string 1 is properly split
    str_1 = 'XNl\n`FdZ'
    var_1 = split_args(str_1)
    assert "XNl" == var_1[0]
    assert "`FdZ" == var_1[1]

    # Test if string 2 is properly split
    str_2 = 'n\nwv"b?\n8"_'
    var_2 = split_args(str_2)
    assert 'n' == var_2[0]

# Generated at 2022-06-25 04:05:58.279617
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'SF^\tZy'
    var_0 = parse_kv(str_0)
    assert var_0 == {'_raw_params': 'SF^\tZy'}


# Generated at 2022-06-25 04:06:08.470659
# Unit test for function parse_kv

# Generated at 2022-06-25 04:06:11.128400
# Unit test for function split_args
def test_split_args():

    test_case_0()


# Generated at 2022-06-25 04:06:19.740272
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing function parse_kv")
    assert parse_kv('key=value') == {'key': 'value'}, "Test 1 of parse_kv failed"
    assert parse_kv('key=value key=value') == {'key': 'value key=value'}, "Test 2 of parse_kv failed"
    assert parse_kv('key="some value"') == {'key': 'some value'}, "Test 3 of parse_kv failed"
    assert parse_kv('key=\'some value\'') == {'key': 'some value'}, "Test 4 of parse_kv failed"
    assert parse_kv('key="some value" key=\'some value\'') == {'key': 'some value key=\'some value\''}, "Test 5 of parse_kv failed"
    assert parse

# Generated at 2022-06-25 04:06:28.209679
# Unit test for function parse_kv
def test_parse_kv():
    # string with key/value
    str_0 = '"a=b c=d" e=f'
    str_1 = '"a=b c=d" e=f g="h i"'
    str_2 = '"a=b c=d" "e=f g=h"'

    # string without key/value
    str_3 = '"a b" "c d"'
    var_0 = parse_kv(str_3)
    str_4 = '"a b" c d'
    var_1 = parse_kv(str_4)
    str_5 = '"a b c d"'

    # string contains key/value and without key/value
    str_6 = 'a=b c="d e" "f g" h'

# Generated at 2022-06-25 04:06:51.843666
# Unit test for function split_args
def test_split_args():
    str_0 = 'python -c "import os"'
    var_0 = split_args(str_0)
    print(var_0)
    str_1 = 'python -c "import os" -H localhost'
    var_1 = split_args(str_1)
    print(var_1)
    str_2 = 'python -c "import os" -H \\\\localhost'
    var_2 = split_args(str_2)
    print(var_2)
    str_3 = 'python -c "import os" -H \\\\localhost -m "\\" -a \'abc\''
    var_3 = split_args(str_3)
    print(var_3)

# Generated at 2022-06-25 04:06:53.675219
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'A\x01#\x01?\x01\x001\x01'
    var_0 = parse_kv(str_0)
    #print(var_0)


# Generated at 2022-06-25 04:06:59.608927
# Unit test for function split_args
def test_split_args():
    # Test case 0
    test_case_0()

# Run unit tests
if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:07:05.044584
# Unit test for function parse_kv
def test_parse_kv():
    key = 'SF^\tZy'
    value = '1234'
    parsed = parse_kv('{0}={1}'.format(key, value))
    assert parsed[key] == value
    assert len(parsed) == 1

# Origin: http://stackoverflow.com/a/9323903/1493653

# Generated at 2022-06-25 04:07:16.364847
# Unit test for function parse_kv
def test_parse_kv():
    a = 'key0=val0 key1=val1  key2 = val2   key3 =val3    key4= val4'
    assert parse_kv(a,check_raw=False) == {'key0': 'val0', 'key1': 'val1', 'key2': 'val2', 'key3': 'val3', 'key4': 'val4'}
    assert parse_kv(a,check_raw=True) == {'key0': 'val0', 'key1': 'val1', 'key2': 'val2', 'key3': 'val3', 'key4': 'val4', '_raw_params': 'key0=val0 key1=val1  key2 = val2   key3 =val3    key4= val4'}

# Generated at 2022-06-25 04:07:26.930603
# Unit test for function split_args
def test_split_args():
    # Testing case 0
    str_0 = 'SF^\tZy'
    var_0 = split_args(str_0)
    assert var_0 == ['SF^\tZy']
    # Testing case 1
    str_0 = '1t*J}!W8)vj'
    var_0 = split_args(str_0)
    assert var_0 == ['1t*J}!W8)vj']
    # Testing case 2
    str_0 = 'p+{'
    var_0 = split_args(str_0)
    assert var_0 == ['p+{']
    # Testing case 3
    str_0 = 'f9'
    var_0 = split_args(str_0)
    assert var_0 == ['f9']
    # Testing case 4
   

# Generated at 2022-06-25 04:07:32.800024
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = "foo=bar baz=qux cow=dog"
    dict_0 = parse_kv(str_0)
    assert dict_0['foo'] == 'bar'
    assert dict_0['baz'] == 'qux'
    assert dict_0['cow'] == 'dog'
    #assert dict_0['_raw_params'] == ''

    str_1 = "foo='bar baz' qux='quux' xyzzy=splunge"
    dict_1 = parse_kv(str_1)
    assert dict_1['foo'] == '\'bar baz\''
    assert dict_1['qux'] == '\'quux\''
    assert dict_1['xyzzy'] == 'splunge'


# Generated at 2022-06-25 04:07:41.319437
# Unit test for function split_args
def test_split_args():
    str_0 = 'SF^\tZy'
    str_1 = '''-name "a b c"\n-mime_type "application/pdf"\n-size 3097'''
    var_0 = split_args(str_0)
    # assert that the first test case returns a list
    assert isinstance(var_0, list)

    var_1 = split_args(str_1)
    # assert that the second test case returns a list
    assert isinstance(var_1, list)


# Generated at 2022-06-25 04:07:48.621343
# Unit test for function parse_kv
def test_parse_kv():

    kv_str = "name='myvmid'cpus=1 memory=512 host='esxi01' " + \
        "datastore='NAS01' folder='my-vms' displayname='myvmid'"

    res = parse_kv(kv_str)

    assert res == {
        'name': 'myvmid',
        'cpus': '1',
        'memory': '512',
        'host': 'esxi01',
        'datastore': 'NAS01',
        'folder': 'my-vms',
        'displayname': 'myvmid'
    }



# Generated at 2022-06-25 04:08:00.680363
# Unit test for function split_args
def test_split_args():
    str_0 = 'SF^\tZy'
    var_0 = split_args(str_0)

    str_1 = '@'
    var_1 = split_args(str_1)

    str_2 = 'Xg e'
    var_2 = split_args(str_2)

    str_3 = '7@!a \x06X'
    var_3 = split_args(str_3)

    str_4 = '\x0b\x19\x1e\x1d\t\x00\x1a\tt\x1d\x06\x0f\x0f\x1dG'
    var_4 = split_args(str_4)


# Generated at 2022-06-25 04:08:32.376263
# Unit test for function split_args
def test_split_args():
    # Test with a parameter set
    str_0 = 'SF^\tZy '
    var_0 = split_args(str_0)
    print(var_0)


if __name__ == "__main__":
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 04:08:37.825681
# Unit test for function split_args
def test_split_args():
    print('Testing split_args')
    # Test cases for the split_args function
    test_case_0()

# Test Cases for the join_args function

# Generated at 2022-06-25 04:08:48.504817
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1') == {'a': '1'}
    assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a=1,b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a=1, b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a=1; b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a=1;b=2') == {'a': '1', 'b': '2'}

# Generated at 2022-06-25 04:08:50.705966
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'SF^\tZy'
    var_0 = split_args(str_0)

    assert var_0 == ["SF^\tZy"]
    assert parse_kv(var_0) == {}


# Generated at 2022-06-25 04:08:52.209537
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 04:08:53.693150
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

# Generated at 2022-06-25 04:08:55.936507
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:09:07.095172
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = ''
    var_0 = parse_kv(str_0)
    assert var_0 == {}
    str_0 = '\t'
    var_0 = parse_kv(str_0)
    assert var_0 == {}
    str_0 = '\t'
    var_0 = parse_kv(str_0, True)
    assert var_0 == {u'_raw_params': u'\t'}
    str_0 = '   \t \t  '
    var_0 = parse_kv(str_0, True)
    assert var_0 == {u'_raw_params': u'   \t \t  '}
    str_0 = 'hello'
    var_0 = parse_kv(str_0, True)

# Generated at 2022-06-25 04:09:18.174052
# Unit test for function parse_kv

# Generated at 2022-06-25 04:09:22.485947
# Unit test for function parse_kv
def test_parse_kv():    
    print("test")
    str_0 = 'SF^\tZy'
    var_0 = split_args(str_0)
    print(var_0)

if __name__ == "__main__":
    test_case_0()
    # test_parse_kv()

# Generated at 2022-06-25 04:09:40.299871
# Unit test for function split_args
def test_split_args():
    str_0 = 'SF^\tZy'
    var_0 = split_args(str_0)
    assert (var_0 == ['SF^\tZy'])


# Generated at 2022-06-25 04:09:51.781580
# Unit test for function split_args
def test_split_args():
    str_0 = 'abc="def" ghi="jkl" mno=pqr'
    str_ans = ['abc="def"', 'ghi="jkl"', 'mno=pqr']
    var_0 = split_args(str_0)
    assert var_0 == str_ans
    print ("test_split_args: 1 passed")

    str_0 = 'a=1 b=2 c=3 d'
    str_ans = ['a=1', 'b=2', 'c=3', 'd']
    var_0 = split_args(str_0)
    assert var_0 == str_ans
    print ("test_split_args: 2 passed")

    str_0 = 'a=1 b=2 c=3 d="\\"\\"\\"\\"\\""'
    str

# Generated at 2022-06-25 04:09:56.726891
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'SF^\tZy'
    var_0 = parse_kv(str_0)
    print(var_0)
    str_1 = 'SF^\tZy'
    var_1 = parse_kv(str_1, check_raw=True)
    print(var_1)


# Generated at 2022-06-25 04:10:03.947420
# Unit test for function parse_kv
def test_parse_kv():
    # split_args
    # case_0
    test_case_0()

    # check_raw 是否转换
    str_1 = 'a=1 b=2 c=3'
    var_0 = parse_kv(str_1, check_raw=False)
    print(var_0)
    var_0 = parse_kv(str_1, check_raw=True)
    print(var_0)
    # case_2
    str_2 = 'a=1 b=2 c=3 d="4 5 6"'
    var_0 = parse_kv(str_2, check_raw=False)
    print(var_0)
    # case_3

# Generated at 2022-06-25 04:10:12.833816
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = "abcd=efgh=ijk"
    var_0 = parse_kv(str_0)

    #Check if var_0 is a dict/hash
    assert( isinstance(var_0, dict) == True)

    #Check if var_0 has 1 key-value pair
    assert( len(var_0) == 1)

    #Check if key is 'abcd'
    assert('abcd' in var_0)

    #Check if value corresponding to key 'abcd' is equal to 'efgh=ijk'
    assert( var_0['abcd'] == 'efgh=ijk')


# Generated at 2022-06-25 04:10:21.962274
# Unit test for function parse_kv
def test_parse_kv():

    # Example 1
    str_0 = ''
    var_0 = parse_kv(str_0)
    assert var_0 == {}

    # Example 2
    str_0 = '-c5'
    var_0 = parse_kv(str_0)
    assert var_0 == {}

    # Example 3
    str_0 = 'test=test'
    var_0 = parse_kv(str_0)
    assert var_0 == {'test': 'test'}

    # Example 4
    str_0 = 'test=test -c 5'
    var_0 = parse_kv(str_0)
    assert var_0 == {'test': 'test', '_raw_params': [' -c 5']}

    # Example 5

# Generated at 2022-06-25 04:10:31.336541
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '<(A0@d|e\n'
    var_0 = parse_kv(str_0)
    str_1 = '6T\tXIk'
    var_1 = split_args(str_1)
    str_2 = 'e:I~\tK'
    var_2 = parse_kv(str_2)
    str_3 = 'M=g\tq'
    var_3 = parse_kv(str_3)
    str_4 = 'L[Y\t6'
    var_4 = split_args(str_4)
    str_5 = '}\\\t\n'
    var_5 = split_args(str_5)
    str_6 = 'C\tJ~'

# Generated at 2022-06-25 04:10:34.512632
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '/\t*Y\u0016\\]\x19\\u\\N\{GREEK SMALL LETTER ALPHA}\u001d\g)\x06'
    options = parse_kv(str_0, True)


# Generated at 2022-06-25 04:10:37.389700
# Unit test for function split_args
def test_split_args():
    print('Test case #0:')
    str_0 = 'SF^\tZy'
    var_0 = split_args(str_0)
    print(var_0)
    
test_split_args()

test_case_0()

# Generated at 2022-06-25 04:10:49.247523
# Unit test for function parse_kv
def test_parse_kv():
    assert(u'SF^\tZy' == join_args(split_args(u'SF^\tZy')))
    assert(u'SF\\^\\tZy' == join_args(split_args(u'SF\^\\tZy')))
    assert(u'SF\\^\\tZy' == join_args(split_args(u'SF^\\tZy')))
    assert(u'SF\\^\\tZy' == join_args(split_args(u'SF^\tZy')))
    assert(u'SF\\^\\tZy' == join_args(split_args(u'SF\\^\\tZy')))
    assert(u'SF\\^\\tZy' == join_args(split_args(u'SF\\^\tZy')))