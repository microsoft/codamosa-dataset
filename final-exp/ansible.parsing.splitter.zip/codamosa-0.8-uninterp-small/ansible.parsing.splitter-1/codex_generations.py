

# Generated at 2022-06-25 04:02:15.428422
# Unit test for function split_args
def test_split_args():
    # Test 0
    test_case_0()


# Generated at 2022-06-25 04:02:20.275526
# Unit test for function split_args
def test_split_args():
    str_0 = '''ls -l
    whoami
    pwd'''
    var_0 = split_args(str_0)
    assert var_0 == ['ls', '-l\n    whoami\n    pwd']



# Generated at 2022-06-25 04:02:29.862704
# Unit test for function parse_kv
def test_parse_kv():
    # test_case_0
    str_0 = 'f|Fv\\g_^Nli:K{OM'
    var_0 = split_args(str_0)
    # test_case_1
    str_1 = ' '
    var_1 = split_args(str_1)
    # test_case_2
    str_2 = 'A=h),,}'
    var_2 = split_args(str_2)
    # test_case_3
    str_3 = ';R|*_FAn -V'
    var_3 = split_args(str_3)
    # test_case_4
    str_4 = 'r[H{0b\\'
    var_4 = split_args(str_4)
    # test_case_5

# Generated at 2022-06-25 04:02:35.869601
# Unit test for function split_args
def test_split_args():
    str_0 = 'a=b c="d e"'
    str_1 = 'creates=/tmp/foo removes=/tmp/bar'
    str_2 = 'creates={{ /tmp/foo }} removes={{ /tmp/bar }}'
    var_0 = split_args(str_0)
    var_1 = split_args(str_1)
    var_2 = split_args(str_2)
    print(var_0)
    print(var_1)
    print(var_2)


# Generated at 2022-06-25 04:02:39.514983
# Unit test for function split_args
def test_split_args():
    print('Testing split_args')
    test_case_0()

    return

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:02:48.678040
# Unit test for function parse_kv
def test_parse_kv():
    var_0 = parse_kv('a=1 b=2 c="foo bar" d="this=that"')
    assert var_0.get('a') == '1', 'str.get() returned unexpected value'
    assert var_0.get('b') == '2', 'str.get() returned unexpected value'
    assert var_0.get('c') == 'foo bar', 'str.get() returned unexpected value'
    assert var_0.get('d') == 'this=that', 'str.get() returned unexpected value'
    # Test with check_raw option
    var_0 = parse_kv('a=1 b=2 c="foo bar" d="this=that"', True)
    assert var_0.get('a') == '1', 'str.get() returned unexpected value'
    assert var_0.get

# Generated at 2022-06-25 04:02:55.826990
# Unit test for function parse_kv
def test_parse_kv():
    # Test empty string
    assert {} == parse_kv("")
    # Test space between key-value pairs
    assert {'a': '1', 'b': '2'} == parse_kv("a=1 b=2")
    # Test key and value with quotes
    assert {'a': '1', 'b': '2'} == parse_kv("a='1' b=\"2\"")
    # Test key, value and space with quotes
    assert {'a': '1', 'b': '2 c'} == parse_kv("a='1' b='2 c'")
    # Test key, value, space and equal sign with quotes
    assert {'a': '1', 'b': '2 = c'} == parse_kv("a='1' b='2 = c'")
    # Test key, value

# Generated at 2022-06-25 04:03:00.412629
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'key="value with spaces" a=b \'c=d\' e="f=g" h=\'i=j\''
    var_0 = parse_kv(str_0)
    print(var_0)
    str_1 = None
    var_1 = parse_kv(str_1)
    print(var_1)


# Generated at 2022-06-25 04:03:01.552855
# Unit test for function split_args
def test_split_args():
    print('Test case 0')
    test_case_0()



# Generated at 2022-06-25 04:03:02.389630
# Unit test for function split_args
def test_split_args():
    # insert your code here
    test_case_0()


# Generated at 2022-06-25 04:03:16.603107
# Unit test for function split_args
def test_split_args():
    import os
    import re
    import io
    import sys
    import json

    os.chdir('/Users/jaime/Documents/GitHub/ansible/lib/ansible/module_utils/')
    test_dir = '/Users/jaime/Documents/GitHub/ansible/test/lib/ansible/module_utils/'
    sys.path.append(os.path.abspath('/Users/jaime/Documents/GitHub/ansible/lib/ansible/module_utils/'))

    py_file = open(os.path.join(test_dir, 'test_split_args.py'))
    py_str = ""
    for line in py_file:
        if re.match('^$', line) or re.match('^#', line):
            continue
        py_

# Generated at 2022-06-25 04:03:25.574958
# Unit test for function split_args
def test_split_args():
    # the string we're going to split
    # note that the first "group" of space separated items is
    # intentionally split with a \n, since that is what we'll
    # sometimes get in one of our parameters, and we need to be
    # able to handle that case.
    args = u"a=b \nc={{ foo }} d=bar e='foo bar' {{ f={{g}} 'h=i j' }}"
    # the expected result
    expected_result = ['a=b', 'c={{ foo }}', 'd=bar', u"e='foo bar'", "{{ f={{g}}", "'h=i j'", '}}']
    # split it
    result = split_args(args)
    # assert the result is what we expected
    assert result == expected_result



# Generated at 2022-06-25 04:03:27.468797
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 04:03:29.287389
# Unit test for function split_args
def test_split_args():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 04:03:32.289334
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'hO5Oe[5]:lS'
    test_0 = parse_kv(str_0)


# Generated at 2022-06-25 04:03:37.201206
# Unit test for function split_args
def test_split_args():
    arg_str = 'a=b c="foo bar" d=\'{"fizz": "buzz"}\' e=1 f=true g=false'

    params = split_args(arg_str)
    assert params == ['a=b', 'c="foo bar"', 'd=\'{\"fizz\": \"buzz\"}\'', 'e=1', 'f=true', 'g=false']

    arg_str = 'a=b c="foo bar" d=\'{"fizz": "buzz"}\' e=1 f=true g=false h={{ hello.world }} i={{ hello.world|foo("bar") }}'

    params = split_args(arg_str)

# Generated at 2022-06-25 04:03:48.240864
# Unit test for function split_args
def test_split_args():
    str_0 = 'ls -l'
    var_0 = split_args(str_0)
    print("str_0: %s" % str_0)
    print("var_0: %s" % var_0)
    assert( str_0 == 'ls -l' )
    assert( var_0 == ['ls', '-l'] )
    str_1 = 'ansible localhost -m ping -i /root/tmp/ansible/ansible_dir/hosts'
    var_1 = split_args(str_1)
    print("str_1: %s" % str_1)
    print("var_1: %s" % var_1)
    assert( str_1 == 'ansible localhost -m ping -i /root/tmp/ansible/ansible_dir/hosts' )

# Generated at 2022-06-25 04:03:53.327028
# Unit test for function split_args
def test_split_args():
    # test case 1
    str_0 = 'f|Fv\\g_^Nli:K{OM'
    var_0 = split_args(str_0)
    assert var_0 == ['f|Fv\\g_^Nli:K{OM']



# Generated at 2022-06-25 04:03:58.299902
# Unit test for function parse_kv
def test_parse_kv():
    # Testing for argument types
    assert parse_kv('foo="bar"') == {'foo': 'bar'}
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar=bar') == {'foo': 'bar=bar'}
    assert parse_kv('foo=bar="bar"') == {'foo': 'bar=bar'}
    assert parse_kv(u'foo="ba\u00e9"') == {'foo': u'ba\u00e9'}
    assert parse_kv(r'foo=ba\xc3\xa9') == {'foo': u'ba\u00e9'}
    assert parse_kv(r'foo=bar=bar') == {'foo': 'bar=bar'}
   

# Generated at 2022-06-25 04:04:03.338802
# Unit test for function parse_kv
def test_parse_kv():
    kv_0 = parse_kv(None)
    kv_1 = parse_kv(None)



# Generated at 2022-06-25 04:04:26.341964
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('x=1 y=2') == dict(x='1', y='2'), 'should return dict with keys x and y'
    assert parse_kv(['x=1', 'y=2']) == dict(x='1', y='2'), 'should return dict with keys x and y'
    assert parse_kv(dict(x='1', y='2')) == dict(x='1', y='2'), 'should return dict with keys x and y'
    assert parse_kv('ls -l /') == dict(_raw_params="ls -l /"), 'should return dict with key _raw_params'
    assert parse_kv('ls -l /', check_raw=False) == dict(), 'should return empty dict'

# Generated at 2022-06-25 04:04:37.757381
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'a=1'
    expected_0 = {u'a': u'1'}
    var_0 = parse_kv(str_0)
    assert var_0 == expected_0
    str_1 =  'a=a="b=1"'
    expected_1 = {u'a': u'a="b=1"'}
    var_1 = parse_kv(str_1)
    assert var_1 == expected_1
    str_2 =  'a=a=\\"b=1\\"'
    expected_2 = {u'a': u'a="b=1"'}
    var_2 = parse_kv(str_2)
    assert var_2 == expected_2
    str_3 =  'a=a=\\"b=1\\"'
    expected_

# Generated at 2022-06-25 04:04:46.729819
# Unit test for function parse_kv
def test_parse_kv():
    my_args = dict(foo='hello', bar='baz')

# Generated at 2022-06-25 04:04:54.703071
# Unit test for function split_args
def test_split_args():
    assert not split_args("a=b")
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b c=d 'e=f g=h' i=j") == ['a=b', 'c=d', 'e=f g=h', 'i=j']
    assert split_args("a=b c='d e' f=g") == ['a=b', 'c=d e', 'f=g']
    assert split_args("a=b 'c d' e='f g'") == ['a=b', 'c d', 'e=f g']
    assert split_args("a=b c=\"d e\" f=g") == ['a=b', 'c=d e', 'f=g']
    assert split_args

# Generated at 2022-06-25 04:05:03.985645
# Unit test for function parse_kv
def test_parse_kv():
    # None case
    try:
        # None case
        assert None == parse_kv(None)
    except AssertionError:
        print("args None")
    # Empty string case
    try:
        # Empty string case
        assert {} == parse_kv('')
    except AssertionError:
        print("args ''")
    # Single value case
    try:
        # Single value case
        assert {'state': 'latest'} == parse_kv('state=latest')
    except AssertionError:
        print("args 'state=latest'")
    # Multiple values case

# Generated at 2022-06-25 04:05:13.964819
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '^Dg@.N~A4QJ/&M+\'[Ex/I0jDos8Qv5j\\\t'
    var_0 = parse_kv(str_0, None)
    str_1 = '-v\x00\x00=HO7*\x00\x00\x00\x00QV*wR#\x00\x00\x00\x00pO_k\x00\x00\x00\x00V|wW\x00\x00\x00\x00o@P<\x00\x00\x00\x00$[wG\x00\x00\x00\x00jfB4\x00\x00\x00\x00'

# Generated at 2022-06-25 04:05:25.973994
# Unit test for function parse_kv
def test_parse_kv():
    import os
    # Test 1
    str_1 = 'cmd a=b c=d'
    var_1 = parse_kv(str_1, True)
    assert var_1[u'a'] == 'b'

    # Test 2
    str_2 = 'ls -l'
    var_2 = parse_kv(str_2, True)
    assert var_2[u'_raw_params'] == 'ls -l'

    # Test 3
    str_3 = 'cmd \\= a=b c=d'
    var_3 = parse_kv(str_3, True)
    assert var_3[u'_raw_params'] == 'cmd \\= a=b c=d'

    # Test 4
    str_4 = 'cmd a=b c=d \\='
    var_4

# Generated at 2022-06-25 04:05:28.468716
# Unit test for function split_args
def test_split_args():
    test_case_0()
    #
    # TODO: a lot of test cases
    #
    return



# Generated at 2022-06-25 04:05:30.700761
# Unit test for function split_args
def test_split_args():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 04:05:31.795687
# Unit test for function parse_kv
def test_parse_kv():
    print('Test Case 0')
    test_case_0()


# Generated at 2022-06-25 04:06:03.027050
# Unit test for function parse_kv
def test_parse_kv():
    arg1_list = [
        'a=b c=d e="f=g h" i=\'j=k l\' m=\'n="o" p\' q=\"r=s t\" u=v'
    ]
    check_raw_list = [
        True
    ]

    # Invoke method
    for arg1, check_raw in zip(arg1_list, check_raw_list):
        result = parse_kv(arg1, check_raw)
        assert True == result

    # #####################################
    # Test with invalid input
    # #####################################
    arg1_list = [
        None
    ]
    check_raw_list = None

    # Invoke method

# Generated at 2022-06-25 04:06:09.921934
# Unit test for function parse_kv
def test_parse_kv():
    assert 'foo=bar' == join_args(split_args('foo=bar'))
    assert '"quoted_arg" with_space' == join_args(split_args('"quoted_arg" with_space'))
    assert '"quoted_arg" with_space' == join_args(split_args('"quoted_arg" with_space'))
    assert 'quoted_arg with_space' == join_args(split_args('"quoted_arg with_space"'))
    assert '-u root' == join_args(split_args('-u root'))
    assert '-u root' == join_args(split_args('-u=root'))
    assert '-u root' == join_args(split_args('-u="root"'))
    assert '-u=root' == join

# Generated at 2022-06-25 04:06:15.743724
# Unit test for function split_args
def test_split_args():
    str_0 = 'f|Fv\\g_^Nli:K{OM'
    str_1 = 'f|Fv\\g_^Nli:K{OM'
    str_2 = 'w~q?@p}v-L:Tvy'
    str_3 = '"\\aa?\\"\\\\'
    str_4 = '-vse,1 -b'
    str_5 = '"\\v" "\\\\" "\\\\\\" '
    str_6 = 'foo\\ bar'
    str_7 = '{{ foo }}'
    str_8 = '{% foo %}'
    str_9 = '{# foo #}'
    str_10 = "foo\n bar"
    str_11 = "foo\\\n bar"

# Generated at 2022-06-25 04:06:21.150297
# Unit test for function split_args
def test_split_args():
    str_0 = 'f|Fv\\g_^Nli:K{OM'
    str_1 = ''
    str_2 = '$`*^>?_'
    str_3 = '=^]_{K4}pE\\>|Bq3{Z9X\\S'

    try:
        split_args(str_0)
    except Exception as exc:
        print('split_args(\'' + str_0 + '\')')
        raise Exception(exc) from exc

    try:
        split_args(str_1)
    except Exception as exc:
        print('split_args(\'' + str_1 + '\')')
        raise Exception(exc) from exc


# Generated at 2022-06-25 04:06:28.647833
# Unit test for function split_args
def test_split_args():
    # Test case where one of the lines is a comment
    str_0 = '''this is a single line of text\n#fdasfdas'''
    var_0 = split_args(str_0)
    if var_0[1] != '#fdasfdas':
        raise AnsibleParserError('comments')

    # Test case where one of the lines is a jinja2 block
    str_0 = '''this is a single line of text\n{{ fdasfdas }}'''
    var_0 = split_args(str_0)
    if var_0[1] != '{{ fdasfdas }}':
        raise AnsibleParserError('jinja2 block')

    # Test case where the entirety of the line is a jinja2 block

# Generated at 2022-06-25 04:06:32.355936
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 04:06:37.216077
# Unit test for function split_args
def test_split_args():
    # assert split_args('f|Fv\\g_^Nli:K{OM') == ['f|Fv\\\\g_^Nli:K{OM']
    assert split_args('f|Fv\\g_^Nli:K{OM') == ['f|Fvg_^Nli:K{OM']
    # assert split_args("f|Fv\\g_^Nli:K{OM") == ['f|Fv\\\\g_^Nli:K{OM']
    assert split_args("f|Fv\\g_^Nli:K{OM") == ["f|Fvg_^Nli:K{OM"]
    assert split_args("foo= Test \"bar baz\"") == ['foo=', 'Test', '"bar', 'baz"']

# Generated at 2022-06-25 04:06:44.612442
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

    # var_0 = parse_kv('f|Fv\\g_^Nli:K{OM')
    # var_1 = parse_kv(u'f|Fv\\g_^Nli:K{OM')
    # var_2 = parse_kv(b'f|Fv\\g_^Nli:K{OM')

if __name__ == "__main__":
    test_parse_kv()

# Generated at 2022-06-25 04:06:53.412449
# Unit test for function split_args
def test_split_args():
    print("Basic test for function split_args")
    # test case 1

# Generated at 2022-06-25 04:07:03.042165
# Unit test for function parse_kv

# Generated at 2022-06-25 04:07:17.381168
# Unit test for function parse_kv
def test_parse_kv():
    s = 'a=1 b="2 3" c={{ d }}'
    o = parse_kv(s)
    assert o.get('a') == '1'
    assert o.get('b') == '2 3'
    assert o.get('c') == '{{ d }}'

    # test that raw params are handled correctly
    o = parse_kv(s, check_raw=True)
    assert o.get('a') == '1'
    assert o.get('b') == '2 3'
    assert o.get('_raw_params') == 'c={{ d }}'
    assert 'c' not in o

    # test that raw params are parsed correctly
    s = 'a=1 b="2 3" c={{ d }}'

# Generated at 2022-06-25 04:07:21.159857
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = '--no-ff -m "revert: --no-edit=false" --no-commit --allow-empty'
    var_0 = parse_kv(str_0, True)
    assert id(var_0) != 0


# Generated at 2022-06-25 04:07:29.362674
# Unit test for function parse_kv
def test_parse_kv():
    assert 'test' == 'test'
    assert isinstance(parse_kv('f|Fv\\g_^Nli:K{OM'), dict)
    assert isinstance(parse_kv('Z0:\\:F\\=Mw\\?H6W8\\&g-_6[\\=v,\\+Y\\:9'), dict)
    assert isinstance(parse_kv('q3TmJ\\-Lmj\\:z{dZ\\,\\:n'), dict)
    assert isinstance(parse_kv('\\:t\\=\\=F_\\,{\\:3'), dict)


# Generated at 2022-06-25 04:07:35.620435
# Unit test for function parse_kv
def test_parse_kv():
    str_0 = 'f|Fv\\g_^Nli:K{OM'
    var_0 = split_args(str_0)

    input_0 = 'z=Fv\g^Nli:K{OM|f'
    input_1 = 'f|Fv\\g_^Nli:K{OM'

    output_0 = parse_kv(input_0)
    output_1 = parse_kv(input_1)

    assert output_0 == var_0
    assert output_1 == var_0


# Generated at 2022-06-25 04:07:45.005431
# Unit test for function split_args
def test_split_args():
    # Testing normal cases
    str_1 = 'taskname'
    res_1 = ['taskname']
    var_1 = split_args(str_1)
    assert var_1 == res_1
    str_2 = 'module: name=name age=age'
    res_2 = ['module:', 'name=name', 'age=age']
    var_2 = split_args(str_2)
    assert var_2 == res_2
    str_3 = 'a=b c=d e="f g" h="i\nj\nk"'
    res_3 = ['a=b', 'c=d', 'e="f g"', 'h="i\nj\nk"']
    var_3 = split_args(str_3)
    assert var_3 == res_3

    #

# Generated at 2022-06-25 04:07:47.116233
# Unit test for function split_args
def test_split_args():
    print ("test_split_args")
    test_case_0()



# Generated at 2022-06-25 04:07:52.755742
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 04:08:03.127604
# Unit test for function parse_kv
def test_parse_kv():
    # re-copy of unit test function parse_kv in module action_plugins/raw.py
    # with the addition of the following code,
    # to make it a standalone unit test.
    #
    #     import sys
    #     import os
    #     import inspect
    #     parentdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))))
    #     sys.path.insert(0,parentdir)
    #
    # from ansible.parsing.splitter import parse_kv
    # from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    #
    #
    # parse_kv = to_native(parse_kv)

    assert parse_k

# Generated at 2022-06-25 04:08:11.576763
# Unit test for function split_args

# Generated at 2022-06-25 04:08:19.337373
# Unit test for function split_args
def test_split_args():
    str_a = 'f|Fv\\g_^Nli:K{OM'
    list_a = split_args(str_a)
    str_b = 'f|Fv\\g_^Nli:K{OM\'?\\"&'
    list_b = split_args(str_b)
    str_c = 'f|Fv\\g_^Nli:K{OM\'?\\"&'
    list_c = split_args(str_c)
    str_d = 'f|Fv\\g_^Nli:K{OM\'?\\"&'
    list_d = split_args(str_d)
    str_e = 'f|Fv\\g_^Nli:K{OM\'?\\"&'
    list_e = split_args(str_e)

# Generated at 2022-06-25 04:08:36.030325
# Unit test for function split_args

# Generated at 2022-06-25 04:08:46.991022
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 04:08:57.885278
# Unit test for function split_args
def test_split_args():
    test_string_0 = '-a "foo bar" biz'
    test_aliases = {'a': 'foo', 'b': 'bar'}

    assert split_args(test_string_0, test_aliases) == ['-a', 'foo', 'bar', 'biz']
    assert split_args('foo', test_aliases) == ['foo']
    assert split_args('foo bar', test_aliases) == ['foo', 'bar']
    assert split_args('foo bar biz', test_aliases) == ['foo', 'bar', 'biz']
    assert split_args('foo bar biz \\', test_aliases) == ['foo', 'bar', 'biz', '\\']
    assert split_args('foo bar biz \\ ') == ['foo', 'bar', 'biz', '\\']
    assert split

# Generated at 2022-06-25 04:08:58.631756
# Unit test for function split_args
def test_split_args():
    pass



# Generated at 2022-06-25 04:09:04.787909
# Unit test for function split_args
def test_split_args():
    # Test case 0
    str_0 = '"Qu2+l8TI!]AI{uQH	A81"'
    var_0 = parse_kv(str_0)


if __name__ == '__main__':
    # test_split_args()
    test_case_0()

# Generated at 2022-06-25 04:09:11.265533
# Unit test for function split_args
def test_split_args():
    str_1 = 'One Two Three'
    var_1 = split_args(str_1)
    str_2 = "1 2 '3 4' 5 \"6 7\" 8"
    var_2 = split_args(str_2)
    str_3 = '''
    1 2 '3 4' 5
    "6 7" 8
    '''
    var_3 = split_args(str_3)
    str_4 = '''
    1 2 '3 4' 5
    "6 7" 8
    '''
    var_4 = split_args(str_4)
    str_5 = "1 2 '3 4' 5 \"6 7\" 8"
    var_5 = split_args(str_5)
    str_6 = '1 2 "3 4" 5 "6 7" 8'
    var

# Generated at 2022-06-25 04:09:15.584001
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing parse_kv...")

    test_case_0()

    print("Done.")

if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-25 04:09:21.006113
# Unit test for function split_args
def test_split_args():
    str_0 = 'Qu2+l8TI!]AI{uQH\tA81'
    var_0 = split_args(str_0)
    assert var_0[-1] == 'Qu2+l8TI!]AI{uQH\tA81'


# Generated at 2022-06-25 04:09:28.776720
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"\\n")[0] == "a=b"
    assert split_args("a=b c=\"foo bar\"\\n")[1] == "c=\"foo bar\""
    assert split_args("a=b c=\"foo bar\" \\d=e")[2] == "\\d=e"
    assert split_args("echo {{ foo }}")[0] == "echo"
    assert split_args("echo {{ foo }}")[1] == "{{ foo }}"
    assert split_args("echo {% foo %}")[0] == "echo"
    assert split_args("echo {% foo %}")[1] == "{% foo %}"
    assert split_args("echo {# foo #}")[0] == "echo"

# Generated at 2022-06-25 04:09:37.479843
# Unit test for function split_args
def test_split_args():
    # Test:
    str_0 = 'a=b c="foo bar"'
    var_0 = split_args(str_0)
    assert var_0 == ['a=b', 'c="foo bar"']
    # Test:
    str_1 = 'a="b \\"c\\""'
    var_1 = split_args(str_1)
    assert var_1 == ['a="b \\"c\\""']
    # Test:
    str_2 = 'a="b \'c\'"'
    var_2 = split_args(str_2)
    assert var_2 == ['a="b \'c\'"']
    # Test:
    str_3 = 'a=b c="foo bar"'
    var_3 = split_args(str_3)

# Generated at 2022-06-25 04:09:44.916670
# Unit test for function parse_kv
def test_parse_kv():
    assert callable(parse_kv)


# Generated at 2022-06-25 04:09:55.068831
# Unit test for function split_args
def test_split_args():
    assert unquote("hello") == "hello"
    assert unquote("hello world") == "hello world"
    assert unquote("'hello world'") == "hello world"
    assert unquote("\"hello world\"") == "hello world"
    assert unquote("hello \\'world\\'") == "hello 'world'"
    assert unquote("hello \\\"world\\\"") == "hello \"world\""
    assert unquote("hello \\\\\"world\\\\\"") == "hello \\\"world\\\""

# Generated at 2022-06-25 04:10:01.688213
# Unit test for function split_args
def test_split_args():
    # simple tests to make sure quotes/characters are being handled
    # properly on the split
    assert split_args("foo bar") == ['foo', 'bar']
    assert split_args("foo bar baz") == ['foo', 'bar', 'baz']
    assert split_args('"foo bar"') == ['foo bar']
    assert split_args("foo bar'baz'") == ['foo', 'barbaz']
    assert split_args("foo 'bar')") == ['foo', "bar)"]
    assert split_args("foo 'bar") == ['foo', "bar"]
    assert split_args("foo 'bar' baz") == ['foo', 'bar', 'baz']
    assert split_args("foo \"bar baz\"") == ['foo', 'bar baz']

# Generated at 2022-06-25 04:10:02.960047
# Unit test for function parse_kv
def test_parse_kv():
    test_case_0()

# Utility functions
# Parsing functions

# Generated at 2022-06-25 04:10:13.108650
# Unit test for function split_args
def test_split_args():
    '''
    Test if the function split_args() works.
    '''

    str_0 = '-a run -m shell -a -l -f'
    var_0 = split_args(str_0)
    if var_0[0] != '-a' or var_0[1] != 'run -m shell -a -l -f':
        raise Exception('Result of split_args() is incorrect!')

    str_1 = '-a run -m shell -a -l -f "single quote test"'
    var_1 = split_args(str_1)
    if var_1[0] != '-a' or var_1[1] != 'run -m shell -a -l -f "single quote test"':
        raise Exception('Result of split_args() is incorrect!')

    str_2

# Generated at 2022-06-25 04:10:22.216309
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c=') == ['a=b', 'c=']
    assert split_args('a=b c= ') == ['a=b', 'c=']
    assert split_args('a=b c= ""') == ['a=b', 'c=""']
    assert split_args('a=b c="" ') == ['a=b', 'c=""']
    assert split_args('a=b c= "foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 04:10:25.969296
# Unit test for function split_args
def test_split_args():
    str_0 = 'Qu2+l8TI!]AI{uQH\tA81'
    var_0 = split_args(str_0)


# Generated at 2022-06-25 04:10:29.098613
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('Qu2+l8TI!]AI{uQH\tA81') == {}

# Generated at 2022-06-25 04:10:39.182637
# Unit test for function parse_kv
def test_parse_kv():
    list_0 = ['Qu2+l8TI!]AI{uQH\tA81']
    dict_0 = {'_raw_params': 'Qu2+l8TI!]AI{uQH\tA81'}
    assert parse_kv('Qu2+l8TI!]AI{uQH\tA81') == dict_0

    list_1 = ['Qu2+l8TI!]AI{uQH\tA81']
    dict_1 = {'_raw_params': 'Qu2+l8TI!]AI{uQH\tA81'}
    assert parse_kv('Qu2+l8TI!]AI{uQH\tA81') == dict_1

    list_2 = ['Qu2+l8TI!]AI{uQH\tA81=']
    dict_2

# Generated at 2022-06-25 04:10:51.205433
# Unit test for function split_args
def test_split_args():
    str_0 = 'Qu2+l8TI!]AI{uQH\tA81'
    print(split_args(str_0))
    str_1 = 'foo=bar'
    print(split_args(str_1))
    str_2 = 'a=b c="foo bar"'
    print(split_args(str_2))
    str_3 = 'a=b c="foo bar" d="a=b c=d"'
    print(split_args(str_3))
    str_4 = 'a="b c=d"'
    print(split_args(str_4))

    print(split_args('''a="b c=d"'''))
    print(split_args('''a="b c=d"'''))

# Generated at 2022-06-25 04:11:06.129217
# Unit test for function parse_kv
def test_parse_kv():
    f_str = 'Qu2+l8TI!]AI{uQH\tA81' # secret decrypt: agvD1O7!u+{
    f_str = 'dsa5V5&+[6YGk7U4c%UJ4w{U5nL1F4ZS5zR    0V5&+[6YGk7U4c%UJ4w{U5nL1F4ZS5zR' # secret decrypt: mors example
    # f_str='AgvD1O7!u+{'
    # f_str='mors example'
    # f_str='"|>eIwPEr)@TI(D{9rqGH8^.xMg0#1"=M:MvH8R~w;Kc%="'