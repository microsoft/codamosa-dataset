

# Generated at 2022-06-23 05:00:55.592332
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo', '\nbar']) == 'foo\nbar'
    assert join_args(['foo', '\nbar']) == 'foo\nbar'
    assert join_args(['foo', 'bar', '\nbaz']) == 'foo bar\nbaz'
    assert join_args(['foo', '\\\nbar']) == 'foo \\\nbar'
    assert join_args(['foo', '"bar baz"', '\nfoo baz']) == 'foo "bar baz"\nfoo baz'
    assert join_args(['foo', '\'bar baz\'', '\nfoo baz']) == 'foo \'bar baz\'\nfoo baz'



# Generated at 2022-06-23 05:01:05.607194
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar\n') == ['foo', 'bar']
    assert split_args('foo bar\nprint(x)') == ['foo', 'bar\n', 'print(x)']
    assert split_args('foo bar\nprint(x, file=sys.stderr)') == ['foo', 'bar\n', 'print(x,', 'file=sys.stderr)']
    assert split_args('foo bar\nprint("x, y")') == ['foo', 'bar\n', 'print("x, y")']
    assert split_args("a = '{{ a }}'") == ["a = '{{", 'a', "}}'"]

# Generated at 2022-06-23 05:01:17.312101
# Unit test for function split_args
def test_split_args():
    '''
    This is a unit test for the split_args() function.
    This does not test any features that require the Jinja2 module, and
    therefore does not test for the parsing of Jinja2 blocks.
    '''

# Generated at 2022-06-23 05:01:24.977335
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo="bar baz"') == {'foo': 'bar baz'}
    assert parse_kv('foo="bar baz" bar=foo') == {'foo': 'bar baz', 'bar': 'foo'}
    assert parse_kv('foo=bar bar="foo baz"') == {'foo': 'bar', 'bar': 'foo baz'}
    assert parse_kv("foo='bar baz'") == {'foo': 'bar baz'}
    assert parse_kv("foo='bar baz' bar='foo'") == {'foo': 'bar baz', 'bar': 'foo'}

# Generated at 2022-06-23 05:01:33.572629
# Unit test for function join_args
def test_join_args():
    assert join_args(["", "", "", "foo", "bar"]) == "foo bar"
    assert join_args(["", "", "", "foo", "", "", "", "", "bar"]) == "foo bar"
    assert join_args(["", "", "", "foo", "bar", "baz"]) == "foo bar baz"
    assert join_args(["", "", "", "foo", "", "", "", "", "bar", "", "", "", "", "baz"]) == "foo bar baz"
    assert join_args(["", " ", "foo", "", "bar", " ", "baz"]) == "foo bar baz"

# Generated at 2022-06-23 05:01:42.080398
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', 'b c d']) == 'a b c d'
    assert join_args(['a\n', 'b c d']) == 'a\nb c d'
    assert join_args(['a\n', 'b\n', '\nc d\n', 'e']) == 'a\nb\n\nc d\ne'
    assert join_args(['a\n', 'b', 'c', 'd\n', 'e']) == 'a\nb c d\ne'


# Generated at 2022-06-23 05:01:50.721358
# Unit test for function split_args
def test_split_args():
    import random


# Generated at 2022-06-23 05:02:01.494150
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar\nbar=baz',check_raw=True) == {'foo': 'bar', 'bar': 'baz'}
    assert parse_kv(u'foo=bar\nbar=baz\n  ',check_raw=True) == {'foo': 'bar', 'bar': 'baz'}
    assert parse_kv(u'foo=bar\n\nbar=baz',check_raw=True) == {'foo': 'bar', 'bar': 'baz'}
    assert parse_kv(u'foo=bar\n  \nbar=baz',check_raw=True) == {'foo': 'bar', 'bar': 'baz'}

# Generated at 2022-06-23 05:02:03.408849
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo','bar','baz']) == 'foo bar baz'
    assert join_args(['foo','\n','bar','baz']) == 'foo\nbar baz'


# Generated at 2022-06-23 05:02:11.339301
# Unit test for function join_args
def test_join_args():
    assert join_args(['']) == ''
    assert join_args([]) == ''
    assert join_args(['-f']) == '-f'
    assert join_args(['\n']) == '\n'
    assert join_args(['\n\n']) == '\n\n'
    assert join_args(['\n', '\n']) == '\n\n'
    assert join_args(['\n-a']) == '\n-a'
    assert join_args(['-a', '\n']) == '-a\n'
    assert join_args(['\n', '-a']) == '\n-a'
    assert join_args(['-a', '\n', '-b']) == '-a\n-b'
    assert join_

# Generated at 2022-06-23 05:02:23.080463
# Unit test for function split_args

# Generated at 2022-06-23 05:02:29.221934
# Unit test for function join_args
def test_join_args():
    s0 = ['Hello', 'World']
    assert join_args(s0) == 'Hello World'
    s1 = ['Hello\n', 'World']
    assert join_args(s1) == 'Hello\nWorld'
    s2 = ['Hello', '\nWorld']
    assert join_args(s2) == 'Hello\nWorld'
    s3 = ['Hello\nWorld']
    assert join_args(s3) == 'Hello\nWorld'
    s4 = ['Hello', 'World\n']
    assert join_args(s4) == 'Hello World\n'



# Generated at 2022-06-23 05:02:39.701990
# Unit test for function split_args
def test_split_args():
    # test some trivial cases
    assert split_args(u'') == [u''], "failed on empty string"
    assert split_args(u'  ') == [u''], "failed on empty string with spaces"
    assert split_args(u'foo') == [u'foo'], "failed on simple string"
    assert split_args(u' foo ') == [u'foo'], "failed on simple string with spaces"
    assert split_args(u'"foo"') == [u'"foo"'], "failed on quoted string with spaces"
    assert split_args(u"foo bar") == [u'foo', u'bar'], "failed on simple split"
    assert split_args(u'foo "bar baz"') == [u'foo', u'"bar baz"'], "failed on quoted string"
    assert split_

# Generated at 2022-06-23 05:02:51.702512
# Unit test for function join_args
def test_join_args():
    """
    Test using a list of tupple
    :return:
    """
    assert join_args([
        '{{',
        'ansible_interfaces',
        '|',
        "map('regex_replace', '^eth[0-9]+', '')"
    ]) == '{{ ansible_interfaces | "map(\'regex_replace\', \'^eth[0-9]+\', \'\')"'
    assert join_args([
        "ansible_interfaces",
        "|",
        "map('regex_replace', '^eth[0-9]+', '')"
    ]) == "ansible_interfaces | map('regex_replace', '^eth[0-9]+', '')"

# Generated at 2022-06-23 05:02:59.835408
# Unit test for function parse_kv
def test_parse_kv():
    d = parse_kv("foo='foo bar' bar='bar bar'")
    assert d['foo'] == 'foo bar'
    assert d['bar'] == 'bar bar'
    assert len(d) == 2

    d = parse_kv("foo='foo bar' bar='bar bar' bam=bam baz=biz")
    assert d['foo'] == 'foo bar'
    assert d['bar'] == 'bar bar'
    assert d['bam'] == 'bam'
    assert d['baz'] == 'biz'
    assert len(d) == 4

    d = parse_kv("foo='foo bar' 'bar bar' bam=bam baz=biz")
    assert 'foo' not in d
    assert 'bar' not in d
    assert 'bam' not in d

# Generated at 2022-06-23 05:03:12.140204
# Unit test for function parse_kv

# Generated at 2022-06-23 05:03:22.500492
# Unit test for function split_args
def test_split_args():
    import os
    os.environ['ANSIBLE_CONFIG'] = 'tests/ansible.cfg'
    from ansible.config import CONFIG
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    vault_pass = os.environ['ANSIBLE_VAULT_PASSWORD_FILE'] = 'tests/test_vault_password.txt'
    loader = DataLoader()
    vault_secrets = VaultLib(vault_pass)


# Generated at 2022-06-23 05:03:32.606878
# Unit test for function split_args
def test_split_args():
    assert(split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"'])
    assert(split_args('a=b c="foo bar') == ['a=b', 'c="foo bar'])
    assert(split_args('a=b c="foo bar" d="foo\\"bar"') == ['a=b', 'c="foo bar"', 'd="foo\\"bar"'])
    assert(split_args('a=b c="foo bar" d="foo\\"bar') == ['a=b', 'c="foo bar"', 'd="foo\\"bar'])
    assert(split_args('a=b c="foo\nbar" d="foo bar"') == ['a=b', 'c="foo\nbar"', 'd="foo bar"'])

# Generated at 2022-06-23 05:03:43.378092
# Unit test for function parse_kv
def test_parse_kv():
    # Test for single argument
    assert parse_kv('arg=foo') == {'arg': 'foo'}
    assert parse_kv('arg="foo bar"') == {'arg': 'foo bar'}
    # Test for multiple arguments
    assert parse_kv('arg1=foo arg2=bar') == {'arg1': 'foo', 'arg2': 'bar'}
    assert parse_kv('arg1=foo arg2="bar baz"') == {'arg1': 'foo', 'arg2': 'bar baz'}
    # Test for empty argument
    assert parse_kv('') == {}
    # Test for empty value
    assert parse_kv('arg=') == {'arg': ''}
    assert parse_kv('arg=""') == {'arg': ''}
    # Test that trailing

# Generated at 2022-06-23 05:03:56.411385
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == dict({'foo': 'bar'})
    assert parse_kv('foo=bar baz=bar') == dict({'foo': 'bar', 'baz': 'bar'})
    assert parse_kv('foo=bar baz=bar qux') == dict({'foo': 'bar', 'baz': 'bar', '_raw_params': 'qux'})
    assert parse_kv('foo=bar baz=bar qux', check_raw=False) == dict({'foo': 'bar', 'baz': 'bar'})

# Generated at 2022-06-23 05:04:06.890357
# Unit test for function parse_kv
def test_parse_kv():
    expected = {
        'k1': '1',
        'k2': '2',
        'k3': '3',
        'k4': '4',
        'k5': '5',
        'k6': '6',
        'k7': '7',
        'k8': '8',
        'k9': '9',
        'k10': '10',
        'k11': '11',
        'k12': '12',
        'k13': '13'
    }

# Generated at 2022-06-23 05:04:16.333794
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b') == {u'a': u'b'}
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c="d e"') == {u'a': u'b', u'c': u'd e'}
    assert parse_kv(r'a=b c="d\"e"') == {u'a': u'b', u'c': u'd"e'}
    assert parse_kv(r'a=b c="d\ e"') == {u'a': u'b', u'c': u'd e'}

# Generated at 2022-06-23 05:04:19.451826
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo', 'bar\nbaz']) == 'foo\nbar\nbaz'



# Generated at 2022-06-23 05:04:29.865445
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("foo bar=baz")
    assert options == {u'foo': u'', u'bar': u'baz'}

    # quote key, value should be empty
    options = parse_kv("foo='bar baz'")
    assert options == {u'foo': u'bar baz'}

    # quote key, value should be empty
    options = parse_kv("foo=\"bar baz\"")
    assert options == {u'foo': u'bar baz'}

    # quote value, key should be "foo"
    options = parse_kv("'foo'=bar")
    assert options == {u'foo': u'bar'}

    # quote value, key should be "foo"
    options = parse_kv("\"foo\"=bar")

# Generated at 2022-06-23 05:04:40.442723
# Unit test for function split_args
def test_split_args():
    assert split_args('') == [u'']
    assert split_args(' ') == [u' ']
    assert split_args('"') == [u'"']
    assert split_args('""') == [u'""']
    assert split_args('"""') == [u'"""']
    assert split_args('"a') == [u'"a']  # this is ambiguous, but we assume the trailing " is missing
    assert split_args('"a\\"') == [u'"a\\"']

# Generated at 2022-06-23 05:04:51.722785
# Unit test for function join_args

# Generated at 2022-06-23 05:05:02.332875
# Unit test for function parse_kv
def test_parse_kv():
    args = "foo=bar baz=quux"
    actual = parse_kv(args)
    expected = {u'foo': u'bar', u'baz': u'quux'}
    assert actual == expected

    args = "foo='bar baz=quux'"
    actual = parse_kv(args)
    expected = {u'foo': u"bar baz=quux"}
    assert actual == expected

    args = "foo=bar baz='quux'"
    actual = parse_kv(args)
    expected = {u'foo': u'bar', u'baz': u'quux'}
    assert actual == expected

    args = "foo='bar baz' quux='bar baz'"
    actual = parse_kv(args)

# Generated at 2022-06-23 05:05:11.594259
# Unit test for function split_args
def test_split_args():
    assert split_args(u'arg1 arg2') == [u'arg1', u'arg2']
    assert split_args(u'arg1 "arg2 arg3"') == [u'arg1', u'"arg2 arg3"']
    assert split_args(u'arg1 arg2 arg3 "arg4 arg5"') == [u'arg1', u'arg2', u'arg3', u'"arg4 arg5"']
    assert split_args(u'arg1 "arg2 arg3" arg4') == [u'arg1', u'"arg2 arg3"', u'arg4']
    assert split_args(u'arg1 "arg2 \\"arg3\\"') == [u'arg1', u'"arg2 \\"arg3\\"']

# Generated at 2022-06-23 05:05:21.189763
# Unit test for function split_args
def test_split_args():
    # test case 1:
    args = "a=b c=d"
    result = split_args(args)
    assert len(result) == 2
    assert result[0] == "a=b"
    assert result[1] == "c=d"

    # test case 2:
    args = "a=b c= 'this is a quoted string with spaces' d=e"
    result = split_args(args)
    assert len(result) == 4
    assert result[0] == "a=b"
    assert result[1] == "c="
    assert result[2] == "'this is a quoted string with spaces'"
    assert result[3] == "d=e"

    # test case 3:
    args = "a=b c= \"this is a quoted string with spaces\" d=e"
    result

# Generated at 2022-06-23 05:05:31.556329
# Unit test for function parse_kv
def test_parse_kv():
    opts = parse_kv('foo=bar key=value another=option')
    assert opts['foo'] == 'bar'
    assert opts['key'] == 'value'
    assert opts['another'] == 'option'
    # assert len(opts) == 3

    try:
        parse_kv('foo=bar key=value another=')
        assert False, "Expected AnsibleParserError"
    except AnsibleParserError:
        assert True

    opts = parse_kv('foo=bar key=value another="a b c"')
    assert opts['foo'] == 'bar'
    assert opts['key'] == 'value'
    assert opts['another'] == 'a b c'
    # assert len(opts) == 3


# Generated at 2022-06-23 05:05:42.510791
# Unit test for function parse_kv
def test_parse_kv():
    test_kv1 = '''argument1=value1 argument2='value2' argument3=value3 argument4="value 4" argument5="value 5"'''
    test_kv2 = r'''argument1='Sometimes you don't expect a single quote until the end!' argument2='What "about" quoted things?'''
    test_kv3 = '''argument1=!@#$%^&*()_+~` argument2=[]\{}|;':",./<>?'''
    test_kv4 = '''argument1=http://www.example.com/this/is/a/test/?foo=bar&baz=boonk'''

# Generated at 2022-06-23 05:05:47.896121
# Unit test for function join_args
def test_join_args():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    cmd_list = [to_bytes('echo'), to_bytes('b'), to_bytes('\n'), to_bytes('c')]
    returned_string = join_args(cmd_list)
    assert isinstance(returned_string, Mapping)



# Generated at 2022-06-23 05:05:59.798391
# Unit test for function split_args
def test_split_args():
    import unittest
    from ansible.parsing.vault import VaultLib

    def get_split(s):
        vault = VaultLib([])
        return vault.unprotect_data(s)

    class TestSplitArgs(unittest.TestCase):
        def test_basic(self):
            s = 'foo=bar key={{ baz }}'
            self.assertEqual(get_split(s), ['foo=bar', 'key={{ baz }}'])

        def test_quotes(self):
            s = 'foo="bar baz"'
            self.assertEqual(get_split(s), ['foo="bar baz"'])

        def test_mix1(self):
            s = 'foo={{ baz }} "bar baz"'

# Generated at 2022-06-23 05:06:12.380746
# Unit test for function split_args
def test_split_args():
    assert split_args("a") == ["a"]
    assert split_args("a b") == ["a", "b"]
    assert split_args("a b  c") == ["a", "b  c"]
    assert split_args("a b c\nd") == ["a", "b", "c\nd"]
    assert split_args("a='b c'") == ["a='b c'"]
    assert split_args("a='b c'  d='e f'") == ["a='b c'", "d='e f'"]
    assert split_args("a\n  b") == ["a", "b"]
    assert split_args("a b 'c'") == ["a", "b", "'c'"]

# Generated at 2022-06-23 05:06:17.243185
# Unit test for function parse_kv
def test_parse_kv():
    try:
        print (parse_kv("blah=\"Hello world\"",True))
        print ('test_parse_kv [OK]')
    except AnsibleParserError as e:
        print ('test_parse_kv [Failed]: %s'%(e))
if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-23 05:06:20.487419
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', '\nb']) == 'a\nb'



# Generated at 2022-06-23 05:06:22.286263
# Unit test for function join_args
def test_join_args():
    assert join_args(["module:", "-a 'foo bar'"]) == "module: -a 'foo bar'"



# Generated at 2022-06-23 05:06:33.681020
# Unit test for function parse_kv
def test_parse_kv():
    # test_parse_kv_1
    args = """creates="/etc/yum.repos.d/foo.repo" name=epel -y"""
    options = parse_kv(args)
    assert options == {u'creates': u'/etc/yum.repos.d/foo.repo', u'name': u'epel'}

    # test_parse_kv_2
    args = """creates="/etc/yum.repos.d/foo.repo" name=epel"""
    options = parse_kv(args)
    assert options == {u'creates': u'/etc/yum.repos.d/foo.repo', u'name': u'epel'}

    # test_parse_kv_3

# Generated at 2022-06-23 05:06:45.810064
# Unit test for function split_args
def test_split_args():
    print("TESTING split_args()")

    # Expected results

# Generated at 2022-06-23 05:06:57.104158
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c=d') == ['a=b', 'c=d']
    assert split_args(u'a=b "c=d"') == ['a=b', '"c=d"']
    assert split_args(u'a=b "c=d" e="f g" h \'i=j\'') == ['a=b', '"c=d"', 'e="f g"', 'h', '\'i=j\'']
    assert split_args(u'a=b \'c=d\' e="f g" h \'i=j\'') == ['a=b', '\'c=d\'', 'e="f g"', 'h', '\'i=j\'']

# Generated at 2022-06-23 05:07:06.960200
# Unit test for function split_args

# Generated at 2022-06-23 05:07:16.252027
# Unit test for function split_args

# Generated at 2022-06-23 05:07:27.733573
# Unit test for function parse_kv
def test_parse_kv():
    '''Unit test for parse_kv'''
    # Tests for a dict of raw_params after parsing of environment variable string
    # Test 1: A string with only raw_params separated by space.
    string = 'some command --arg1 some_value --arg2 other_value'
    result = parse_kv(string)
    assert result == {'_raw_params':'some command --arg1 some_value --arg2 other_value'}
    # Test 2: A string with '=' with no value passed in.
    string = 'some command --arg1 some_value --arg2='
    result = parse_kv(string)
    assert result == {'_raw_params':'some command --arg1 some_value --arg2='}
    # Test 3: A string with '=' with value passed in.

# Generated at 2022-06-23 05:07:35.949718
# Unit test for function split_args
def test_split_args():
    import pprint
    # no quoting or jinja2
    params = split_args("a b 'c d'")
    assert params == ['a', 'b', '\'c', 'd\'']

    # quoted strings with whitespace
    params = split_args("a='b c'")
    assert params == ['a=\'b c\'']
    params = split_args("a='b'\"'\"'c'")
    assert params == ['a=\'b\'\'"\'\'c\'']
    params = split_args("a=\"b c\"")
    assert params == ['a="b c"']
    params = split_args("a=b\\ c")
    assert params == ['a=b c']

    # jinja2 blocks/filters with whitespace

# Generated at 2022-06-23 05:07:47.292849
# Unit test for function parse_kv
def test_parse_kv():
    def example_func(given, expected):
        try:
            result = parse_kv(given)
            if result != expected:
                print("Result does not match:")
                print(result)
            assert result == expected
        except Exception as e:
            print(e)
            assert False

    # Basic parsing
    example_func("", {})
    example_func("foo=bar", {u"foo": u"bar"})
    example_func("foo=bar baz=qux", {u"foo": u"bar", u"baz": u"qux"})

    # Handle escaped equal signs
    example_func(r"foo=bar\=baz=qux", {u"foo": u"bar=baz", u"baz": u"qux"})

# Generated at 2022-06-23 05:07:58.087564
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar', check_raw=True) == dict(foo=u'bar', _raw_params=u'foo=bar')
    assert parse_kv(u'key value', check_raw=True) == dict(_raw_params=u'key value')
    assert parse_kv(u'key value=more_value', check_raw=True) == dict(value=u'more_value', _raw_params=u'key value=more_value')
    assert parse_kv(u'key value="more_value value"', check_raw=True) == dict(value=u'more_value value', _raw_params=u'key value="more_value value"')

# Generated at 2022-06-23 05:08:00.235516
# Unit test for function join_args
def test_join_args():
    assert join_args(("first", "second")) == "first second"
    assert join_args(("first", "second third\n")) == "first second third\n"



# Generated at 2022-06-23 05:08:03.546135
# Unit test for function join_args
def test_join_args():
    s = "a b"
    assert join_args(split_args(s)) == s
    s = "a\nb"
    assert join_args(split_args(s)) == s
    s = """a \
        b\n\
        c"""
    assert join_args(split_args(s)) == s



# Generated at 2022-06-23 05:08:06.677054
# Unit test for function join_args
def test_join_args():
    assert(join_args(['echo', '1']) == 'echo 1')
    assert(join_args(['echo 1', '2', '3']) == 'echo 1\n2\n3')



# Generated at 2022-06-23 05:08:17.967622
# Unit test for function split_args

# Generated at 2022-06-23 05:08:28.736146
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b "c=foo bar"') == ['a=b', '"c=foo bar"']
    assert split_args('a=b "c=foo bar\\"') == ['a=b', '"c=foo bar"']
    assert split_args('python -c print "foo bar"') == ['python', '-c', 'print', '"foo bar"']
    assert split_args('python -c print "foo {{bar}}"') == ['python', '-c', 'print', '"foo {{bar}}"']
    assert split_args('python -c print "foo {{bar}}"', False) == ['python', '-c', 'print "foo {{bar}}"']


# Generated at 2022-06-23 05:08:40.414812
# Unit test for function split_args
def test_split_args():
    t0 = '''foo bar'''
    t1 = '''"foo bar"'''
    t2 = "'''foo bar'''"
    t3 = ''''foo bar'"'''
    t4 = '''foo {{foo}} bar'''
    t5 = '''foo "{{" bar'''
    t6 = '''foo '{%' bar'''
    t7 = ''''\\"{#' bar'''
    t8 = '''"foo bar\\"'''
    t9 = "'''foo bar'''"
    t10 = '''foo \
bar'''
    t11 = '''foo \
"bar"'''
    t12 = '''foo "bar\\"'''
    t13 = '''foo \
foo \
bar'''

# Generated at 2022-06-23 05:08:49.034448
# Unit test for function parse_kv
def test_parse_kv():
    # Should either pass foo=bar
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    # or pass foo="bar baz" (prefer double quotes)
    assert parse_kv('foo="bar baz"') == {u'foo': u'bar baz'}
    # or pass foo='bar baz' (single quotes)
    assert parse_kv('foo=\'bar baz\'') == {u'foo': u'bar baz'}

    # but not foo='bar' baz='qux' (to pass multiple options)
    try:
        parse_kv('foo=\'bar\' baz=\'qux\'')
    except AnsibleParserError:
        pass



# Generated at 2022-06-23 05:09:00.282916
# Unit test for function split_args
def test_split_args():

    assert ["a='foo'", "b='foo bar'"] == split_args("a='foo' b='foo bar'")
    assert ["a='foo bar'"] == split_args("a='foo bar'")
    assert ["a='foo", "bar='"] == split_args("a='foo\nbar='")
    assert ["a='foo", "bar='"] == split_args("a='foo bar='")
    assert ["a='foo\\'", "bar='"] == split_args("a='foo\\' bar='")
    assert ["a='foo", "bar='", "-x"] == split_args("a='foo bar=' -x")
    assert ["a='foo", "bar='", "c='foo", "bar='"] == split_args("a='foo bar=' c='foo bar='")

# Generated at 2022-06-23 05:09:11.600869
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("one=1 two=2 three=3") == dict(one='1', two='2', three='3')
    assert parse_kv("one=1 two=2 three=\"3 3 3\"") == dict(one='1', two='2', three='3 3 3')
    assert parse_kv("one=1 two=2 three=\"3\\\\3\\\\3\"") == dict(one='1', two='2', three='3\\3\\3')
    assert parse_kv("one=1 two=2 three=\"3\\\"3\\\\3\"") == dict(one='1', two='2', three='3"3\\3')


# Generated at 2022-06-23 05:09:21.726103
# Unit test for function split_args

# Generated at 2022-06-23 05:09:32.047696
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b c', 'd']) == 'a b c d'
    assert join_args(['a\n', 'b c', 'd']) == 'a\n b c d'
    assert join_args(['a\n', 'b c\n', 'd']) == 'a\n b c\n d'
    assert join_args(['a\n', 'b c\n', 'd\n']) == 'a\n b c\n d\n'
    assert join_args(['a', '\nb c', 'd']) == 'a \nb c d'
    assert join_args(['a', '\nb c', '\nd']) == 'a \nb c \nd'



# Generated at 2022-06-23 05:09:42.790727
# Unit test for function split_args

# Generated at 2022-06-23 05:09:52.913945
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.six import PY3

    def assertListEqual(a, b, msg=None):
        if a != b:
            raise AssertionError(msg)

    def testSplit(a, b, msg=None):
        assertListEqual(split_args(a), b, msg or "Split: {0} {1}".format(a, b))

    testSplit("hello world", ['hello', 'world'])
    testSplit("hello=world", ['hello=world'])
    testSplit("hello = world", ['hello', '=', 'world'])
    testSplit("hello='world'", ["hello='world'"])
    testSplit("hello='world", ["hello='world"])
    testSplit("hello=\\'world", ["hello=\\'world"])

# Generated at 2022-06-23 05:09:58.383149
# Unit test for function join_args
def test_join_args():
    s = [u'if [ -z "$1" ]', u'then', u'    echo "Parameter #1 is zero length."', u'else', u'    echo "First parameter: $1"', u'fi']
    assert join_args(s) == u'if [ -z "$1" ] then\n\techo "Parameter #1 is zero length."\nelse\n\techo "First parameter: $1"\nfi'



# Generated at 2022-06-23 05:10:08.473003
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="foo    bar" d="hello\tworld"') == {u'a': u'b', u'd': u'hello\tworld', u'c': u'foo    bar'}
    assert parse_kv(u"a='b c' 'd e'=f") == {u'a': u"b c", u'd e': u'f'}
    assert parse_kv(u"a='b c' 'd e'=f 'g h'='i j'") == {u'a': u"b c", u'd e': u'f', u'g h': u'i j'}

# Generated at 2022-06-23 05:10:12.547315
# Unit test for function join_args
def test_join_args():
    s = """    daemon  --user=root --pidfile=/var/run/docker.pid \\
          --exec-root=/var/run/docker
    """
    new_s = join_args(split_args(s))
    assert s == new_s


# Generated at 2022-06-23 05:10:21.455537
# Unit test for function parse_kv

# Generated at 2022-06-23 05:10:27.873031
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['a']) == 'a'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', '\nb']) == 'a\nb'
    assert join_args(['a', '\nb', '\nc']) == 'a\nb\nc'



# Generated at 2022-06-23 05:10:39.255625
# Unit test for function split_args
def test_split_args():
    # Use this function at call points or put in test suite
    import pprint
    # {u'chdir': u'~', u'creates': u'/dev/null', u'executable': None, u'stdin': None, u'stdin_add_newline': True, u'strip_empty_ends': True, u'warn': True}
    pprint.pprint(split_args("chdir=~ creates=/dev/null executable= stdin= stdin_add_newline=true warn=yes strip_empty_ends=True"))
    # {u'creates': u'/dev/null', u'executable': None, u'stdin': None, u'stdin_add_newline': True, u'strip_empty_ends': True, u'warn': True}

# Generated at 2022-06-23 05:10:46.609913
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar baz"') == split_args("foo 'bar baz'")
    assert split_args('foo "bar \\"baz\\""') == ['foo', '"bar \\"baz\\""']
    assert split_args('foo "bar \\"baz\\""') == split_args("foo 'bar \\\"baz\\\"'")
    assert split_args('foo "bar \\\\"baz\\\\""') == ['foo', '"bar \\\\"baz\\\\""']
    assert split_args('foo "bar \\\\"baz\\\\""') == split_

# Generated at 2022-06-23 05:10:57.155181
# Unit test for function parse_kv
def test_parse_kv():
    assert dict(parse_kv('A=B C=D')) == dict(A='B', C='D')
    assert dict(parse_kv('"NO_PKGS=DETECT"')) == dict(NO_PKGS="DETECT")
    assert dict(parse_kv('A="B=C"')) == dict(A='B=C')
    assert dict(parse_kv('"A=C B=D"')) == dict(A='C B=D')
    assert dict(parse_kv('A="B=C" D="E F"')) == dict(A='B=C', D='E F')
    assert dict(parse_kv('_raw_params="A=C B=D"')) == dict(_raw_params='A=C B=D')