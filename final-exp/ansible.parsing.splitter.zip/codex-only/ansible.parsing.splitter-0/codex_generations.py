

# Generated at 2022-06-23 05:00:53.898008
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar baz=quux creator=Tobin Harding") == {u'foo': u'bar', u'baz': u'quux', u'creator': u'Tobin Harding'}
    assert parse_kv(u"vars_prompt \"foo = bar\"") == {u'vars_prompt': u'"foo = bar"'}

# Generated at 2022-06-23 05:01:04.615602
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils import basic

    def test(value, expected, errored=False):
        try:
            result = parse_kv(value)
        except Exception as e:
            if not errored:
                raise AssertionError("unexpected exception: %s" % e)
            return
        else:
            if errored:
                raise AssertionError("expected exception")
        basic.json_dict_equality(result, expected)

    test("a=b c=d", {"a":"b", "c":"d"})
    test("a=b=c c=d", {"a":"b=c", "c":"d"})
    test("a=b=c c=d", {"a":"b=c", "c":"d"})

# Generated at 2022-06-23 05:01:15.853315
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("one=1 two=2") == dict(one = "1", two = "2")
    assert parse_kv("one=a two=2 three=3") == dict(one = "a", two = "2", three = "3")
    assert parse_kv("one=\\=x\\=y\\=z two=2") == dict(one = "=x=y=z", two = "2")
    assert parse_kv("one=\\=x=y=z two=2") == dict(one = "=x=y=z", two = "two=2")
    assert parse_kv("one=\\=x=y=z two=2") == dict(one = "=x=y=z", two = "two=2")

# Generated at 2022-06-23 05:01:24.820990
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'a\nb']) == 'echo a\nb'
    assert join_args(['echo', 'a\nb', '>', 'foo']) == 'echo a\nb > foo'
    assert join_args(['echo', 'a\nb', '|', 'foo', 'bar']) == 'echo a\nb | foo bar'
    assert join_args(['echo', 'a\nb', '|', 'foo', 'bar', '||', 'baz']) == 'echo a\nb | foo bar || baz'
    assert join_args(['echo', 'a\nb', '|', 'foo', 'bar', '&&', 'baz']) == 'echo a\nb | foo bar && baz'

# Generated at 2022-06-23 05:01:30.459359
# Unit test for function join_args
def test_join_args():
    assert join_args(['1']) == '1'
    assert join_args(['1', '2']) == '1 2'
    assert join_args(['1\n2']) == '1\n2'
    assert join_args(['1', '2\n', '3\n']) == '1 2\n3\n'
    assert join_args(['1\n', '2', '3\n4']) == '1\n2 3\n4'



# Generated at 2022-06-23 05:01:38.761200
# Unit test for function join_args
def test_join_args():
    assert join_args(['first', 'second', 'third', 'fourth']) == 'first second third fourth'
    assert join_args(['first \n second \n third \n fourth']) == 'first \n second \n third \n fourth'
    assert join_args(['first \\n second \\n third \\n fourth']) == 'first \\n second \\n third \\n fourth'
    assert join_args(['first second third fourth']) == 'first second third fourth'
    assert join_args(['first second', 'third', 'fourth']) == 'first second third fourth'
    assert join_args(['first\nsecond \n third \n fourth']) == 'first\nsecond \n third \n fourth'



# Generated at 2022-06-23 05:01:47.473289
# Unit test for function parse_kv
def test_parse_kv():
    # Realistically kv parsing will probably only happen in the context of
    # a module, so we only need to test that it returns the same thing as
    # the python version of the module (parse.py)
    try:
        from ansible.modules.system.ping import parse_kv as python_parse_kv
    except ImportError:
        # We're testing a vendored import and the src tree is not available,
        # so this test can't run. Skip it.
        return True


# Generated at 2022-06-23 05:01:57.139107
# Unit test for function parse_kv
def test_parse_kv():
    import pytest
    assert parse_kv('a=b c="d" e="f=g" h=\'i=j\' k="l=m,n=o" _raw_params="p=q r=s"') == {"a": "b", "c": "d", "e": "f=g", "h": "i=j", "k": "l=m,n=o", "_raw_params": "p=q r=s"}

# Generated at 2022-06-23 05:02:11.124059
# Unit test for function split_args
def test_split_args():
    """Just make sure that the split_args function doesn't
    break. This doesn't test the intelligent reassembly.
    """
    f = split_args  # short alias
    assert 'foo bar' == f('foo bar')
    assert 'foo bar' == f('foo \nbar')
    assert 'foo bar' == f('foo\nbar')
    assert 'foo "bar baz"' == f("foo 'bar baz'")
    assert 'foo "bar baz"' == f("foo \"bar baz\"")
    assert 'foo 1=2' == f("foo 1=2")
    assert 'foo' == f("foo ")
    assert 'foo\nbar' == f("foo\nbar")
    assert 'foo\nbar' == f("foo \nbar")

# Generated at 2022-06-23 05:02:16.583724
# Unit test for function join_args
def test_join_args():
    import random
    import subprocess
    for i in range(0, 1000):
        s = to_text(subprocess.check_output('shuf -n 1000 /usr/share/dict/words | tr "\\n" " " | head -c 1000', shell=True))
        assert join_args(split_args(s)) == s



# Generated at 2022-06-23 05:02:25.896033
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=foo c= bar') == {u'a': u'1', u'b': u'foo', u'c': u'bar'}
    assert parse_kv('a=1 b=foo c= bar') == {'a': u'1', u'b': u'foo', 'c': u'bar'}
    assert parse_kv('a=1 b=foo c= bar') == {'a': '1', 'b': u'foo', 'c': 'bar'}
    assert parse_kv('a=1 b=foo c= bar') == {'a': '1', 'b': 'foo', 'c': 'bar'}

# Generated at 2022-06-23 05:02:38.287665
# Unit test for function parse_kv
def test_parse_kv():
    # first test parsing with no free-form params
    parsed = parse_kv('foo=1 bar="2 baz"')
    assert parsed == {u'foo': u'1', u'bar': u'2 baz'}

    # check_raw testing, since it's a parameter that's normally used to enable this check
    parsed = parse_kv('foo=1 bar="2 baz"', check_raw=True)
    assert parsed == {u'foo': u'1', u'bar': u'2 baz', u'_raw_params': None}

    # now test parsing with some free-form params
    parsed = parse_kv('foo=1 baz=bar qux="abc def" /usr/bin/somecommand -x arg1 arg2 arg3')

# Generated at 2022-06-23 05:02:43.815086
# Unit test for function join_args
def test_join_args():
    test_str = ["newline at start",
                "\nnewline again",
                "now",
                "another\nnewline"]
    assert join_args(test_str) == "newline at start\nnewline again now\nanother\nnewline"


# Generated at 2022-06-23 05:02:52.116715
# Unit test for function join_args
def test_join_args():
    assert join_args(['arg1 arg2 arg3', 'arg4 arg5 arg6']) == 'arg1 arg2 arg3 arg4 arg5 arg6'
    assert join_args(['arg1', 'arg2', 'arg3']) == 'arg1 arg2 arg3'
    assert join_args(['arg1', 'arg2', 'arg3\narg4']) == 'arg1 arg2 arg3\narg4'
    assert join_args(['arg1 arg2 arg3', 'arg4\narg5 arg6']) == 'arg1 arg2 arg3 arg4\narg5 arg6'



# Generated at 2022-06-23 05:02:57.978931
# Unit test for function join_args
def test_join_args():
    '''
    Test function join_args().
    '''

# Generated at 2022-06-23 05:03:06.970046
# Unit test for function parse_kv
def test_parse_kv():
    # String with positional arguments
    test_string = "arg1 arg2=val2 arg3='test=test' arg4=\"test=test\""
    result = parse_kv(test_string)
    assert result['_raw_params'] == "arg1 arg2=val2 arg3='test=test' arg4=\"test=test\""

    # String with positional arguments and a single keyed argument
    test_string = "arg1 arg2=val2 arg3='test=test' arg4=\"test=test\" user=tst"
    result = parse_kv(test_string)
    assert result['user'] == 'tst'
    assert result['_raw_params'] == "arg1 arg2=val2 arg3='test=test' arg4=\"test=test\""

    # String with positional arguments and keyed arguments


# Generated at 2022-06-23 05:03:14.933744
# Unit test for function split_args
def test_split_args():
    assert split_args("foo=bar") == ["foo=bar"]
    assert split_args("foo=bar\nbaz=meh") == ["foo=bar", "baz=meh"]
    assert split_args("foo=bar\nbaz={{ meh }}") == ["foo=bar", "baz={{ meh }}"]
    assert split_args("foo=bar\nbaz={{ meh }}") == ["foo=bar", "baz={{ meh }}"]
    assert split_args("foo=bar\nbaz={{ meh }}\nfoo=bar") == ["foo=bar", "baz={{ meh }}", "foo=bar"]

# Generated at 2022-06-23 05:03:24.169678
# Unit test for function parse_kv

# Generated at 2022-06-23 05:03:33.701705
# Unit test for function join_args
def test_join_args():
    nums = [0, 1, 10]
    for n in nums:
        args = [str(i) for i in range(n)]
        assert join_args(args) == ' '.join(args)
    assert join_args([]) == ''
    assert join_args(['  hello', 'world  ']) == '  hello world  '
    assert join_args(['  hello\n', 'world  ']) == '  hello\n world  '
    assert join_args(['  hello\n', '\nworld  ']) == '  hello\n\n world  '
    assert join_args(['  hello\n\n', 'world  ']) == '  hello\n\n world  '

# Generated at 2022-06-23 05:03:44.155752
# Unit test for function join_args
def test_join_args():
    assert join_args(['p1']) == 'p1'
    assert join_args(['p1', 'p2']) == 'p1 p2'
    assert join_args(['p1', 'p2', 'p3']) == 'p1 p2 p3'
    assert join_args(['p1 p2 p3']) == 'p1 p2 p3'
    assert join_args(['p1\tp2\tp3']) == 'p1\tp2\tp3'
    assert join_args(['p1 p2\tp3']) == 'p1 p2\tp3'
    assert join_args(['p1\tp2 p3']) == 'p1\tp2 p3'

# Generated at 2022-06-23 05:03:47.795403
# Unit test for function join_args
def test_join_args():
    line = r"""
        echo "
        "
    """
    assert join_args(split_args(line)) == line
# end unit test



# Generated at 2022-06-23 05:03:57.200362
# Unit test for function split_args
def test_split_args():
    print("Testing split_args")
    assert(split_args("foo bar") == ["foo", "bar"])
    assert(split_args("foo\nbar") == ["foo\n", "bar"])
    assert(split_args("foo='bar wish'") == ["foo='bar wish'"])
    assert(split_args("foo='bar wish' baz") == ["foo='bar wish'", "baz"])
    assert(split_args("foo='bar wish'\nbaz") == ["foo='bar wish'\n", "baz"])
    assert(split_args("foo 'bar wish'") == ["foo", "'bar wish'"])
    assert(split_args("foo 'bar wish' baz") == ["foo", "'bar wish'", "baz"])

# Generated at 2022-06-23 05:04:07.617270
# Unit test for function split_args
def test_split_args():
    print("test_split_args()")
    # args = "command='/usr/bin/foo bar'"

# Generated at 2022-06-23 05:04:18.166633
# Unit test for function parse_kv
def test_parse_kv():
    # Test case 1:
    args='a=b c="d"'
    options = parse_kv(args, check_raw=False)
    assert options == {'a': "b", 'c': "d"}, 'test case 1 failed'

    # Test case 2:
    args = 'a=b c=d'
    options = parse_kv(args, check_raw=False)
    assert options == {'a': "b", 'c': "d"}, 'test case 2 failed'

    # Test case 3:
    args = 'a="b b" c=d'
    options = parse_kv(args, check_raw=False)
    assert options == {'a': "b b", 'c': "d"}, 'test case 3 failed'

    # Test case 4:

# Generated at 2022-06-23 05:04:27.991496
# Unit test for function join_args
def test_join_args():
    s = ['line1', 'line2']
    assert join_args(s) == 'line1 line2'
    s = ['line1', '\n', 'line2']
    assert join_args(s) == 'line1 \n line2'
    s = ['line1', '\nline2']
    assert join_args(s) == 'line1 \nline2'
    s = ['line1', '\n  line2']
    assert join_args(s) == 'line1 \n  line2'
    s = ['line1', '\n\tline2']
    assert join_args(s) == 'line1 \n\tline2'
    s = ['line1', '\n   line2']
    assert join_args(s) == 'line1 \n   line2'
   

# Generated at 2022-06-23 05:04:34.398425
# Unit test for function join_args
def test_join_args():
    testcases = [
        (['a', 'b', 'c'], 'a b c'),
        (['a', '\nb', '\nc'], 'a\nb\nc'),
        (['a', '\n', 'b'], 'a\n b'),
    ]
    for args, expected in testcases:
        result = join_args(args)
        if result != expected:
            raise AssertionError('join_args({0}) = "{1}" but we expected "{2}"'.format(args, result, expected))



# Generated at 2022-06-23 05:04:43.665266
# Unit test for function split_args
def test_split_args():
    f = split_args

    # Empty string returns empty list
    assert f('') == []

    # Basic with no blocks and quotes
    assert f('one two three') == ['one', 'two', 'three']

    # Simple quotes
    assert f('one "two three"') == ['one', '"two three"']
    assert f('one "two three') == ['one', '"two three']
    assert f('"one two three') == ['"one two three']
    assert f('"one two" three') == ['"one two"', 'three']
    assert f('"one two three') == ['"one two three']
    assert f('one "two three') == ['one', '"two three']
    assert f('one "two three"') == ['one', '"two three"']

# Generated at 2022-06-23 05:04:55.075052
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'status=present') == {u'status': u'present'}
    assert parse_kv(u'status=present,enabled=true') == {u'status': u'present', u'enabled': u'true'}
    assert parse_kv(u'name=ansible') == {u'name': u'ansible'}
    assert parse_kv(u"name='ansible'") == {u'name': u'ansible'}
    assert parse_kv(u'name=ansible,force=true') == {u'name': u'ansible', u'force': u'true'}
    assert parse_kv(u'name="ansible"') == {u'name': u'ansible'}

# Generated at 2022-06-23 05:04:59.039350
# Unit test for function join_args
def test_join_args():
    assert join_args(['apt-get', 'update', '&&']) == 'apt-get update &&'
    assert join_args(['apt-get', 'update', '\n', 'apt-get', 'upgrade']) == 'apt-get update\napt-get upgrade'



# Generated at 2022-06-23 05:05:06.475512
# Unit test for function join_args
def test_join_args():
    '''
    Test if join_args() works well with newlines.
    '''
    s0 = ['a', 'b', '\n', 'c', 'd']
    assert join_args(s0) == 'a b\nc d'

    s1 = ['\necho', '"a b c"']
    assert join_args(s1) == '\necho "a b c"'

    s2 = ['\nb=$(echo a) c=$(echo b)', 'd=$(echo c)']
    assert '\n' + join_args(s2) == '\nb=$(echo a) c=$(echo b) d=$(echo c)'



# Generated at 2022-06-23 05:05:17.263082
# Unit test for function split_args

# Generated at 2022-06-23 05:05:25.496241
# Unit test for function split_args
def test_split_args():
    def do_test(test):
        (in_, out_) = test
        got = split_args(in_)
        if got != out_:
            print(u"FAILED: expected {0}, got {1} for input {2}".format(out_, got, in_))


# Generated at 2022-06-23 05:05:36.283928
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=foo') == {u'baz': u'foo', u'foo': u'bar'}
    assert parse_kv("foo='bar spacey' blarg=baz") == {u'blarg': u'baz', u'foo': u'bar spacey'}
    assert parse_kv('foo=\'bar spacey\' blarg=baz') == {u'blarg': u'baz', u'foo': u'bar spacey'}
    assert parse_kv('foo="bar spacey" blarg=baz') == {u'blarg': u'baz', u'foo': u'bar spacey'}

# Generated at 2022-06-23 05:05:47.117597
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("creates=3 removes=4", check_raw=False) == {'creates': '3', 'removes': '4'}
    assert parse_kv("creates=3, removes=4", check_raw=False) == {'creates': '3,', 'removes': '4'}

# Generated at 2022-06-23 05:05:54.602282
# Unit test for function join_args
def test_join_args():
    assert join_args(['git', '-c diff.mnemonicprefix=false -c core.quotepath=false -c credential.helper=sourcetree',
                      'diff', '--no-index', '--src-prefix=a/', '--dst-prefix=b/', '--', 'foo', 'bar']
                     ) == 'git -c diff.mnemonicprefix=false -c core.quotepath=false -c credential.helper=sourcetree diff --no-index --src-prefix=a/ --dst-prefix=b/ -- foo bar'



# Generated at 2022-06-23 05:06:02.847149
# Unit test for function parse_kv
def test_parse_kv():
    # test values
    test_val = ['key1=value1', 'key2=value2', 'key3="value3"', 'key4="value4"', 'key5=value5 key6=value6', 'key7=value7 key8="value8"', 'key9=value9 key10="value10" key11=value11', 'key12=value12 key13="value13" key14=value14 key15="value15"']


    # test code
    for test in test_val:
        print(test + '#')
        print(parse_kv(test))

# TODO: later, think about possibly moving some utils functions here:

# Generated at 2022-06-23 05:06:08.452358
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args([' a ', '  b ', '\tc', '\n', '  d']) == ' a   b \tc\n  d'



# Generated at 2022-06-23 05:06:18.342706
# Unit test for function split_args
def test_split_args():
    assert(split_args('a=b') == ['a=b'])
    assert(split_args('a=b c=d') == ['a=b', 'c=d'])
    assert(split_args('a=b\nc=d') == ['a=b', 'c=d'])
    assert(split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"'])
    assert(split_args('a=b c="foo bar') == ['a=b', 'c="foo bar'])
    assert(split_args('a=b c="foo \nbar') == ['a=b', 'c="foo \nbar'])
    assert(split_args('a=b c="fo"o bar"') == ['a=b', 'c="fo"o bar"'])

# Generated at 2022-06-23 05:06:25.354711
# Unit test for function join_args
def test_join_args():
    input = [
        '"foo bar"',
        'baz',
        '""',
        '''fo"o''',
        '''ba"r''',
        '''b"a""z''',
        '''"foo" "bar" "baz"''',
    ]
    expected = """\
"foo bar" baz "" fo"o ba"r b"a""z "foo" "bar" "baz"
"""
    assert join_args(input) == expected



# Generated at 2022-06-23 05:06:35.712757
# Unit test for function join_args
def test_join_args():
    assert join_args(['one']) == 'one'
    assert join_args(['one', 'two']) == 'one two'
    assert join_args(['one', '\ntwo']) == 'one\ntwo'
    assert join_args([u'one', u'\u0422wo']) == u'one\u0422wo'
    assert join_args(['this', 'is', '"our', 'test"']) == 'this is "our test"'
    assert join_args(['one', '\'two three']) == 'one \'two three'
    assert join_args(['one', u'\\\u0422wo']) == u'one \\Тwo'
    assert join_args(['one', u'\\\\\u0422wo']) == u'one \\\\Тwo'


# Generated at 2022-06-23 05:06:46.899195
# Unit test for function split_args

# Generated at 2022-06-23 05:06:54.827242
# Unit test for function join_args
def test_join_args():
    assert join_args(split_args("""-a 'foo bar' baz""")) == """-a 'foo bar' baz"""
    assert join_args(split_args("""-a 'foo bar' \
                                baz""")) == """-a 'foo bar' baz"""
    assert join_args(split_args("""-a 'foo bar' \
                                baz=hello'world'""")) == """-a 'foo bar' baz=hello'world'"""
    assert join_args(split_args("""-a 'foo bar' \
                                baz=hello ' world'""")) == """-a 'foo bar' baz=hello ' world'"""

# Generated at 2022-06-23 05:07:03.365603
# Unit test for function parse_kv

# Generated at 2022-06-23 05:07:14.047255
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('a=b') == {u'a': u'b'}
    assert parse_kv('a="b"') == {u'a': u'"b"'}
    assert parse_kv('a=b\ c') == {u'a': u'b c'}
    assert parse_kv('a=b\ c\ d') == {u'a': u'b c d'}
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b\n c=d') == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-23 05:07:25.422095
# Unit test for function split_args
def test_split_args():
    # Single token
    assert ['fish'] == split_args('fish')
    # Two tokens
    assert ['fish', 'cake'] == split_args('fish cake')
    # Two tokens with quote
    assert ['fish', 'cake'] == split_args('fish "cake"')
    # Two tokens with double quote
    assert ['fish', 'cake'] == split_args('fish "cake"')
    # Three tokens
    assert ['fish', 'cake', 'flambe'] == split_args('fish cake flambe')
    # Three tokens with quote
    assert ['fish', 'cake', 'flambe'] == split_args('fish cake "flambe"')
    # Three tokens with double quote
    assert ['fish', 'cake', 'flambe'] == split_args('fish cake "flambe"')
    # Three tokens with single quote

# Generated at 2022-06-23 05:07:35.133770
# Unit test for function join_args

# Generated at 2022-06-23 05:07:46.479923
# Unit test for function parse_kv
def test_parse_kv():
    def is_equal(input, options):
        parsed_options = parse_kv(input)
        assert parsed_options == options

    is_equal('key1=value1 key2="value2 with spaces"', dict(key1='value1', key2='value2 with spaces'))
    is_equal('key1=value1" key2="value2"', dict(key1='value1', key2='value2'))
    is_equal('key1="value1"" key2="value2"', dict(key1='value1', key2='value2'))
    is_equal('key1="value1 key2="value2"', dict(key1='value1 key2="value2'))

# Generated at 2022-06-23 05:07:56.435132
# Unit test for function parse_kv
def test_parse_kv():
    in_str = "foo=bar biz=baz 'complex list'=['hello world', 'foo', 'bar', 'baz']"
    result_dict = {"foo": "bar", "biz": "baz", "complex list": "['hello world', 'foo', 'bar', 'baz']"}
    assert result_dict == parse_kv(in_str)
    in_str = 'ansible_ssh_user=foo ansible_ssh_pass=bar ' \
             'ansible_ssh_host=biz ansible_sudo_pass=baz'
    result_dict = {'ansible_ssh_user': 'foo', 'ansible_ssh_pass': 'bar',
                   'ansible_ssh_host': 'biz', 'ansible_sudo_pass': 'baz'}
    assert result_dict == parse_

# Generated at 2022-06-23 05:08:01.131618
# Unit test for function join_args
def test_join_args():
    for inp, out in (
            ('foo', 'foo'),
            ('foo bar', 'foo bar'),
            ('foo\nbar', 'foo\nbar'),
            ('foo \nbar', 'foo \nbar'),
            ('foo\n bar', 'foo\n bar'),
            ):
        assert join_args(split_args(inp)) == out
# end of unit test



# Generated at 2022-06-23 05:08:12.631253
# Unit test for function split_args
def test_split_args(): # (self):
    arg_string = """
'a=b' c={{foo}} d={{ foo }} e={{foo.bar}} f=foo
{% if a %}
g=bar
{% endif %}
"""
    expected = [
        'a=b',
        'c={{foo}}',
        'd={{ foo }}',
        'e={{foo.bar}}',
        'f=foo',
        '{% if a %}\ng=bar\n{% endif %}'
    ]

    actual = split_args(arg_string)
    for a, b in zip(actual, expected):
        assert a == b

    assert len(actual) == 6



# Generated at 2022-06-23 05:08:21.852600
# Unit test for function join_args
def test_join_args():
    # Test simple string
    assert join_args(split_args('foo')) == 'foo'
    # Test spaces
    assert join_args(split_args('foo bar baz')) == 'foo bar baz'
    # Test newlines
    assert join_args(split_args('foo bar\nbaz quux')) == 'foo bar\nbaz quux'
    # Test quotes
    assert join_args(split_args('foo "bar baz" quux')) == 'foo "bar baz" quux'
    # Test single quotes
    assert join_args(split_args("foo 'bar baz' quux")) == "foo 'bar baz' quux"
    # Test escaped quotes

# Generated at 2022-06-23 05:08:28.887794
# Unit test for function split_args
def test_split_args():
    '''
    Test function for split_args
    '''
    import random

    # generate a random list of arguments and join them
    params = []
    expected = []
    for item in range(10):
        params.append(' '.join(str(random.randint(0, 100)) for i in range(random.randint(1, 5))))

    expected = split_args(' '.join(params))
    actual = split_args(join_args(expected))

    assert params == actual
    assert expected == actual

# Generated at 2022-06-23 05:08:40.462738
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv(None) == {}
    assert parse_kv(' ') == {}
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv(' foo=bar ') == {'foo': 'bar'}
    assert parse_kv(' foo="bar" ') == {'foo': '"bar"'}
    assert parse_kv(' foo="bar" baz=bar') == {'foo': '"bar"', 'baz': 'bar'}
    assert parse_kv(' foo=bar baz="bar"') == {'foo': 'bar', 'baz': '"bar"'}

# Generated at 2022-06-23 05:08:49.697523
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'key') == {}
    assert parse_kv(u'key=') == {}
    assert parse_kv(u'key=value') == {u'key': u'value'}
    assert parse_kv(u'k1=v1 k2=v2') == {u'k1': u'v1', u'k2': u'v2'}
    assert parse_kv(u'k1= v1 k2=v2') == {u'k1': u'v1', u'k2': u'v2'}
    assert parse_kv(u'k1 = v1 k2 = v2') == {u'k1': u'v1', u'k2': u'v2'}

# Generated at 2022-06-23 05:09:00.916183
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv('a=1 b=2') == {u'a': u'1', u'b': u'2'})
    assert(parse_kv('a=1 b=2 "c" d=', check_raw=True) == {u'a': u'1', u'b': u'2', u'_raw_params': u'c d='})
    assert(parse_kv(qw('a=1 b=2 "c in quotes" d=')) == {u'a': u'1', u'b': u'2', u'_raw_params': u'c in quotes d='})

# Generated at 2022-06-23 05:09:09.381858
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv(u"name=John Doe") == {u'name': u'John Doe'}
    assert parse_kv(u"name='John Doe'") == {u'name': u'John Doe'}
    assert parse_kv(u"name=John\'s Doe") == {u'name': u"John's Doe"}
    assert parse_kv(u"name=John's Doe") == {u'name': u"John's Doe"}
    assert parse_kv(u"name=John's \"big\" Doe") == {u'name': u"John's \"big\" Doe"}
    assert parse_kv(u"Cmd='/bin/foo --opt=val'") == {u'Cmd': u'/bin/foo --opt=val'}

# Generated at 2022-06-23 05:09:20.914940
# Unit test for function parse_kv
def test_parse_kv():
    # basic tests
    assert parse_kv('a=1,b=2') == dict(a='1', b='2')
    assert parse_kv('a=1,b=2,c=3') == dict(a='1', b='2', c='3')

    # quoted values
    assert parse_kv('a="1",b="2",c="3"') == dict(a='1', b='2', c='3')
    assert parse_kv("a='1',b='2',c='3'") == dict(a='1', b='2', c='3')

    # quoted values with commas
    assert parse_kv(r'''a='1,2,3',b="4,5,6"''') == dict(a='1,2,3', b='4,5,6')

# Generated at 2022-06-23 05:09:32.047739
# Unit test for function join_args
def test_join_args():
    assert join_args(["arg", "arg"]) == "arg arg"
    assert join_args(["arg ", "arg"]) == "arg arg"
    assert join_args(["arg", " arg"]) == "arg arg"
    assert join_args(["arg", "arg "]) == "arg arg "
    assert join_args(["arg ", " arg"]) == "arg  arg"
    assert join_args(["arg", " arg "]) == "arg  arg "
    assert join_args(["arg ", " arg "]) == "arg  arg "
    assert join_args(["arg\\", "arg"]) == "arg\\ arg"
    assert join_args(["arg\\ ", "arg"]) == "arg\\ arg"
    assert join_args(["arg", " arg\\"]) == "arg arg\\"


# Generated at 2022-06-23 05:09:39.799920
# Unit test for function split_args
def test_split_args():
    # FIXME: add more unit tests here
    # TODO: add some tests of params passed in as k=v or k="v v v"
    #args = u"this is a test of the {{ var1 }} system"
    #args = "this is a test of the {{ var1 }} system {{ var3 }}"
    args = u"echo 'start {{ var1 }} finish {{ var3 }}'"
    split = split_args(args)
    print(split)
    joined = join_args(split)
    print(joined)
    assert joined == args
    # args = u"echo 'this is a test' 'start {{ var1 }} finish {{ var3 }}'"
    # split = split_args(args)
    # print(split)
    # joined = join_args(split)
    # print(joined)
    # assert joined

# Generated at 2022-06-23 05:09:50.834648
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('="foo"') == {u'_raw_params': u'"=foo"'}
    assert parse_kv('"foo"') == {u'_raw_params': u'"foo"'}
    assert parse_kv('') == {}
    assert parse_kv('foo bar') == {u'_raw_params': u'foo bar'}
    assert parse_kv('foo="bar baz"') == {u'foo': u'bar baz'}
    assert parse_kv('foo="bar=baz"') == {u'foo': u'bar=baz'}
    assert parse_kv('foo="bar\\\\=baz"') == {u'foo': u'bar\\=baz'}

# Generated at 2022-06-23 05:09:53.293901
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', '\nb', ' c', '\nd']) == 'a\nb c\nd'



# Generated at 2022-06-23 05:10:03.143995
# Unit test for function parse_kv
def test_parse_kv():
    # Test case: key = value
    assert parse_kv("key=value") == {'key': u'value'}
    # Test case: key = "value"
    assert parse_kv("key=\"value\"") == {'key': u'value'}
    # Test case: key = 'value'
    assert parse_kv("key='value'") == {'key': u'value'}
    # Test case: key='value'
    assert parse_kv("key='value'") == {'key': u'value'}
    # Test case: key="value"
    assert parse_kv("key=\"value\"") == {'key': u'value'}
    # Test case: key=value key2=value2

# Generated at 2022-06-23 05:10:11.578264
# Unit test for function parse_kv
def test_parse_kv():
    def _t(args, result, check_raw=False):
        assert parse_kv(args, check_raw=check_raw) == result

    _t("this='is a test'", {u'this': u"is a test"})
    _t("this=\"is a test\"", {u'this': u"is a test"})
    _t("this=\"is a test", {u'this': u"is a test"})
    _t("this=\"is a test'", {u'this': u"is a test"})
    _t("this='is a test\"", {u'this': u"is a test"})
    _t("this=is a test", {u'this': u"is a test"})

# Generated at 2022-06-23 05:10:23.149490
# Unit test for function parse_kv
def test_parse_kv():
    """
    The function parse_kv should convert a string of key/value items to a dict.
    The only way to test that is using a unit test against a set of test cases
    """
    # The test cases are a list of lists, each sublist containing two items:
    # - the first item is a string of key/value items to convert
    # - the second item is the expected dict

# Generated at 2022-06-23 05:10:30.704882
# Unit test for function parse_kv
def test_parse_kv():
    # Valid inputs
    assert parse_kv('created=ansible') == {'created': 'ansible'}
    assert parse_kv('created=ansible is awesome') == {'created': 'ansible is awesome'}
    assert parse_kv('created=ansible,tagged=yes') == {'created': 'ansible', 'tagged': 'yes'}
    assert parse_kv('created=ansible,tagged=yes,name=no') == {'created': 'ansible', 'tagged': 'yes', 'name': 'no'}
    assert parse_kv('created=ansible is awesome,tagged=yes,name=no') == {'created': 'ansible is awesome', 'tagged': 'yes', 'name': 'no'}

# Generated at 2022-06-23 05:10:41.531783
# Unit test for function split_args
def test_split_args():
    import pprint

# Generated at 2022-06-23 05:10:52.737743
# Unit test for function split_args
def test_split_args():
    assert split_args(u'one') == [u'one']
    assert split_args(u'two "three four"') == [u'two', u'three four']
    assert split_args(u'five "six seven" "eight nine"') == [u'five', u'six seven', u'eight nine']
    assert split_args(u'ten "eleven twelve"') == [u'ten', u'eleven twelve']
    assert split_args(u'ten "eleven \\"twelve\\""') == [u'ten', u'eleven "twelve"']
    assert split_args(u'ten "eleven "twelve" "') == [u'ten', u'eleven "twelve" ']