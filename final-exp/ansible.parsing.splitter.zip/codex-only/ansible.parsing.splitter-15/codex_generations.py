

# Generated at 2022-06-23 05:00:55.651345
# Unit test for function parse_kv
def test_parse_kv():
    def test_parse_kv_case(input_string, expect_dict, expect_raw_params):
        opts = parse_kv(input_string, check_raw=True)
        assert opts == expect_dict
        if expect_raw_params is not None:
            assert opts.get('_raw_params') == expect_raw_params

    # FIXME: add tests for one-shot quoting and backslashing

    # Test the case where there are no raw parameters
    test_parse_kv_case('a=a b=b', {'a': 'a', 'b': 'b'}, None)
    test_parse_kv_case('a=a\ b=b', {'a': 'a b', 'b': 'b'}, None)

# Generated at 2022-06-23 05:01:02.608059
# Unit test for function join_args
def test_join_args():
    s = ["rm", "-rf", "/", "&&", "ls"]
    result = join_args(s)
    assert result == "rm -rf / && ls"

    s = ["rm", "-rf", "\\", "&&", "ls"]
    result = join_args(s)
    assert result == "rm -rf \\ && ls"

    s = ["echo", "\\n\\nHello world"]
    result = join_args(s)
    assert result == "echo \\n\\nHello world"


# Generated at 2022-06-23 05:01:13.278347
# Unit test for function parse_kv
def test_parse_kv():
    import pprint

# Generated at 2022-06-23 05:01:20.389635
# Unit test for function join_args
def test_join_args():
    '''
    Unit test for function join_args()
    '''
    # Test case 1
    inp = ['echo \\\n', 'hello']
    out = join_args(inp)
    assert out == 'echo \\\n hello', 'join_args() failed'
    # Test case 2
    inp = ['echo \\\n', 'hello \\\n', 'world']
    out = join_args(inp)
    assert out == 'echo \\\n hello \\\n world', 'join_args() failed'
    return


# Generated at 2022-06-23 05:01:30.028962
# Unit test for function split_args

# Generated at 2022-06-23 05:01:39.240383
# Unit test for function split_args

# Generated at 2022-06-23 05:01:47.987462
# Unit test for function split_args
def test_split_args():
    """
    Ensure that the splitting code gives us back the original string
    """
    data = [
        '''a=b c="foo{{bar}}foo bar" \
        d={{foo}} e="foo\\"bar" f=\\'g g={{ "{{ x }}" }} h={{ x if x else y }}'''
    ]
    expected = [
        'a=b c="foo{{bar}}foo bar" d={{foo}} e="foo\\"bar" f=\\\'g g={{ "{{ x }}" }} h={{ x if x else y }}'
    ]

    for idx, datum in enumerate(data):
        result = split_args(datum)
        result = join_args(result)
        assert result == expected[idx], "split_args() returned %r instead of %r"

# Generated at 2022-06-23 05:01:56.426420
# Unit test for function parse_kv
def test_parse_kv():
    args = 'foo=bar one=1 "two=2=two" " three = 3 "'
    expected = {
        u'foo': u'bar',
        u'one': u'1',
        u'two=2=two': u'',
        u'three': u'3',
        u'_raw_params': u'" three = 3 "'
    }

    assert parse_kv(args, True) == expected

    args = "en_US.UTF-8"
    expected = {
        u'en_US.UTF-8': u'',
        u'_raw_params': u'en_US.UTF-8'
    }

    assert parse_kv(args, True) == expected

    args = "en_US.UTF-8"
    expected = {
    }

    assert parse_k

# Generated at 2022-06-23 05:02:10.529913
# Unit test for function split_args
def test_split_args():
    assert split_args("a=\"b c\"") == ["a=b c"]
    assert split_args("a=b c=\"foo bar\"") == ["a=b", "c=foo bar"]
    assert split_args("a=\"b {{ c }}\"") == ["a=b {{ c }}"]
    assert split_args("a=b {{ c }}") == ["a=b", "{{", "c", "}}"]
    assert split_args("a=b {{ c }} d={{ e }}") == ["a=b", "{{", "c", "}}", "d={{ e }}"]
    assert split_args("a=b {{ c }} d={{ e }} f=g") == ["a=b", "{{", "c", "}}", "d={{ e }}", "f=g"]

# Generated at 2022-06-23 05:02:23.160592
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("somekey=somevalue")
    assert options == {'somekey': 'somevalue'}
    options = parse_kv("somekey=somevalue somekey2='somevalue2'")
    assert options == {'somekey': 'somevalue', 'somekey2': 'somevalue2'}
    options = parse_kv("somekey=somevalue\nsomekey2='somevalue2'")
    assert options == {'somekey': 'somevalue', 'somekey2': 'somevalue2'}
    options = parse_kv("somekey=somevalue\nsomekey2='somevalue2' somekey3=somevalue3")
    assert options == {'somekey': 'somevalue', 'somekey2': 'somevalue2', 'somekey3': 'somevalue3'}
    options = parse

# Generated at 2022-06-23 05:02:28.507700
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c', 'd']) == 'a b c d'
    assert join_args(['a', 'b', 'c', 'd', '\ne', 'f']) == 'a b c d \ne f'
    assert join_args(['a', 'b', '\nc', 'd']) == 'a b \nc d'



# Generated at 2022-06-23 05:02:39.276239
# Unit test for function split_args
def test_split_args():
    def test(cmd, expected):
        result = split_args(cmd)
        if result == expected:
            return 0
        else:
            print("ERROR: {0} != {1}".format(result, expected))
            return 1

    test_result = 0
    test_result += test("echo 'hello world'", ['echo', "'hello world'"])
    test_result += test("echo \"hello world\"", ['echo', '"hello world"'])
    test_result += test("echo hello world", ['echo', 'hello', 'world'])
    test_result += test("echo 'hello'world'", ['echo', "'hello'world'"])
    test_result += test("echo 'hello\"world'", ['echo', "'hello\"world'"])

# Generated at 2022-06-23 05:02:51.659146
# Unit test for function split_args
def test_split_args():
    def _compare(s, p):
        s = join_args(s)
        p = join_args(p)
        print("Comparing: %s with: %s" % (s, p))
        assert split_args(s) == p

    # test case 1: unbalanced quote - should throw an exception
    # s = 'a=b c="foo bar d=e'
    # _compare(s, s)

    _compare(["a=b"], ["a=b"])
    _compare(["a=b c=d"], ["a=b", "c=d"])
    _compare(["a=b c='d e'"], ["a=b", "c='d e'"])

# Generated at 2022-06-23 05:02:59.787411
# Unit test for function split_args
def test_split_args():
    def _split(args, expected_result):
        test_result = split_args(args)
        assert test_result == expected_result, \
            u"\ntest data: %s\n  expected: %s\n    actual: %s" % (args, expected_result, test_result)

    _split('a=b c=d "foo bar"', ['a=b', 'c=d', '"foo bar"'])
    _split('a=b c=d "foo\nbar"', ['a=b', 'c=d', '"foo\nbar"'])
    _split('a=b c=d "foo\\\nbar"', ['a=b', 'c=d', '"foo\\\nbar"'])

# Generated at 2022-06-23 05:03:08.174348
# Unit test for function parse_kv
def test_parse_kv():
    import unittest

    class TestKVParams(unittest.TestCase):
        def runTest(self):
            args = 'a=b c="foo bar" d=\'{"a":1,"b":2}\' e= f=false g=True h=1 i=2.3 j=[]'
            parsed = parse_kv(args, check_raw=True)

            self.assertEqual(parsed['a'], 'b')
            self.assertEqual(parsed['c'], 'foo bar')
            self.assertEqual(parsed['d'], '{"a":1,"b":2}')
            self.assertEqual(parsed['e'], '')
            self.assertEqual(parsed['f'], 'false')

# Generated at 2022-06-23 05:03:15.461288
# Unit test for function parse_kv
def test_parse_kv():

    # we expect a string error from the below
    try:
        parse_kv(None)
        assert False, "invalid input did not raise exception"
    except TypeError:
        pass
    except Exception as e:
        assert False, "invalid arguments did not raise a TypeError (got a %s: %s) instead" % (e.__class__.__name__, to_text(e))


# Split args adapted from https://github.com/ansible/ansible/blob/2.0.0.2-1/lib/ansible/utils/shlex.py

# Strip out octothorpe comments.
_STRIPCOMMENTSRE = re.compile(r'(^|\s+)#.*')


# Generated at 2022-06-23 05:03:24.581314
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar=baz') == ['foo', 'bar=baz']
    assert split_args('foo bar=baz\nbar zzz=aaaa') == ['foo', 'bar=baz\n', 'bar', 'zzz=aaaa']
    assert split_args('foo bar="baz\nbar"') == ['foo', 'bar="baz\nbar"']
    assert split_args('foo bar="baz\nbar"\nbar zzz=aaaa') == ['foo', 'bar="baz\nbar"\n', 'bar', 'zzz=aaaa']
    assert split_args('foo bar="baz\nbar"') == ['foo', 'bar="baz\nbar"']

# Generated at 2022-06-23 05:03:34.070516
# Unit test for function split_args

# Generated at 2022-06-23 05:03:44.269065
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('foo=bar baz=bang') == {'foo':'bar', 'baz':'bang'}
    assert parse_kv('foo=bar') == {'foo':'bar'}
    assert parse_kv('arg1 arg2') == {u'_raw_params': 'arg1 arg2'}
    assert parse_kv('"foo"') == {}
    assert parse_kv('foo=bar creates=bang') == {'foo':'bar', 'creates': 'bang'}
    assert parse_kv('foo=bar arg1 arg2 arg3') == {'foo':'bar', '_raw_params': 'arg1 arg2 arg3'}

# Generated at 2022-06-23 05:03:57.049508
# Unit test for function split_args
def test_split_args():
    # set these to print out extra details if an error occurs
    verbose = True

    # This is a control list of all things that should be tested
    # We iterate over them and check to see if the results pass our expectations

# Generated at 2022-06-23 05:04:05.528643
# Unit test for function parse_kv

# Generated at 2022-06-23 05:04:08.621720
# Unit test for function join_args
def test_join_args():
    assert join_args(['hello\nworld']) == 'hello\nworld'
    assert join_args(['hello', 'world']) == 'hello world'


# Generated at 2022-06-23 05:04:17.648150
# Unit test for function split_args
def test_split_args():
    assert split_args('a') == ['a']
    assert split_args('a b') == ['a', 'b']
    assert split_args('a\nb') == ['a\n', 'b']
    assert split_args('a b\n') == ['a', 'b\n']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b c=\'d e\'') == ['a=b', "c='d e'"]
    assert split_args('a=b c="d e"') == ['a=b', 'c="d e"']
    assert split_args('a=b c="d e"') == ['a=b', 'c="d e"']

# Generated at 2022-06-23 05:04:26.367526
# Unit test for function join_args
def test_join_args():
    assert join_args(["hello","world"]) == "hello world"
    assert join_args(["hello", "world"]) == "hello world"
    assert join_args(["hello ", "world"]) == "hello  world"
    assert join_args(["hello\n", "world"]) == "hello\n world"
    assert join_args(["hello\n", "world "]) == "hello\n world "
    assert join_args(["hello\n","world\n"]) == "hello\nworld\n"
    assert join_args(["hello\n","world", "\nhello\n", "world"]) == "hello\nworld \nhello\n world"



# Generated at 2022-06-23 05:04:33.910604
# Unit test for function split_args
def test_split_args():
    '''
    Test the split args function
    '''
    # Basic no splitting required
    params = split_args("raw cmd")
    assert len(params) == 1 and params[0] == "raw cmd"

    # Split on spaces
    params = split_args("first cmd second cmd")
    assert len(params) == 2 and params[0] == "first" and params[1] == "cmd second cmd"

    # Split on newlines
    params = split_args("first cmd\nsecond cmd")
    assert len(params) == 2 and params[0] == "first cmd" and params[1] == "second cmd"

    # Split on spaces and newlines
    params = split_args("first cmd\nsecond cmd third cmd")

# Generated at 2022-06-23 05:04:38.457788
# Unit test for function split_args

# Generated at 2022-06-23 05:04:46.874185
# Unit test for function split_args
def test_split_args():
    # tests that have args that need to be balanced
    args = '"{{" "}}"'
    result = split_args(args)
    assert result == ['{', '}']
    args = '"{{" "}}" "{{ "'
    result = split_args(args)
    assert result == ['{', '}', '{ ']
    args = '"{{" "}}" "{{ '
    result = split_args(args)
    assert result == ['{', '{']
    args = '"{{" "}}" "\'"'
    result = split_args(args)
    assert result == ['{', '}', "\\'"]
    args = '"{{" "}}" \'\\\\\''
    result = split_args(args)
    assert result == ['{', '}', '\\\\\'']
   

# Generated at 2022-06-23 05:04:57.745995
# Unit test for function join_args
def test_join_args():
    assert join_args(['cmd', 'arg1', 'arg2']) == 'cmd arg1 arg2'
    assert join_args(['cmd arg1', 'arg2']) == 'cmd arg1 arg2'
    assert join_args(['cmd\narg1', 'arg2']) == 'cmd\narg1 arg2'
    assert join_args(['cmd\narg1', 'arg2']) == 'cmd\narg1 arg2'
    assert join_args(['cmd\narg1\n', 'arg2']) == 'cmd\narg1\narg2'
    assert join_args(['cmd', 'arg1', 'arg2\narg3']) == 'cmd arg1 arg2\narg3'
    # Test single-quoted command

# Generated at 2022-06-23 05:05:06.658374
# Unit test for function parse_kv
def test_parse_kv():

    # key=value
    test = parse_kv('key=value')
    assert test['key'] == 'value'

    # key= value=
    test = parse_kv('key= value=')
    assert test['key'] == ''
    assert test['value'] == ''

    # key="value"
    test = parse_kv('key="value"')
    assert test['key'] == 'value'

    # key=value key=value
    test = parse_kv('key=value key=value')
    assert test['key'] == 'value'

    # key=value key="value"
    test = parse_kv('key=value key="value"')
    assert test['key'] == 'value'

    # key="value" key=value

# Generated at 2022-06-23 05:05:17.821474
# Unit test for function parse_kv
def test_parse_kv():
    test1_string = "a=1 b=2 c=3"
    assert parse_kv(test1_string) == {'a': '1', 'b': '2', 'c': '3'}
    test2_string = "a=1 b=2 c='3 4'"
    assert parse_kv(test2_string) == {'a': '1', 'b': '2', 'c': '3 4'}
    test3_string = "a=1 b=2 c='3 4' d=5 e='6 7' 8 9"
    assert parse_kv(test3_string) == {'a': '1', 'b': '2', 'c': '3 4', 'd': '5', 'e': '6 7', '_raw_params': '8 9'}
    test4_string

# Generated at 2022-06-23 05:05:31.161801
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv(u'foo=1 bar=2')
    assert options[u'foo'] == u'1'
    assert options[u'bar'] == u'2'

    options = parse_kv(u"{'foo':1, 'bar':2}")
    assert options[u'foo'] == u'1'
    assert options[u'bar'] == u'2'

    options = parse_kv(u"{'foo':1, 'bar':2}", check_raw=True)
    assert options[u'foo'] == u'1'
    assert options[u'bar'] == u'2'
    assert options[u'_raw_params'] == u"{'foo':1, 'bar':2}"

    options = parse_kv(u'creates=foo')
    assert options

# Generated at 2022-06-23 05:05:38.359917
# Unit test for function join_args
def test_join_args():
    test_input = ['arg1=foo', '"arg2=bar"']
    test_input2 = 'arg1=foo"arg2=bar"'
    assert join_args(test_input) == test_input2

    test_input = ['arg1=foo', '\'arg2=bar\'']
    test_input2 = 'arg1=foo\'arg2=bar\''
    assert join_args(test_input) == test_input2


# Generated at 2022-06-23 05:05:47.925843
# Unit test for function parse_kv
def test_parse_kv():
    fname = (__file__.rsplit('/', 1)[-1:][0]).replace('.py', '')
    mod = __import__(fname)
    print (mod.parse_kv('\a=b \ c = d', check_raw=True))
    print (mod.parse_kv('\a=b \ c = d'))
    print (mod.parse_kv('\a=b \ c = d',))
    print (mod.parse_kv(None,))
    print (mod.parse_kv(None))
    print (mod.parse_kv(None, check_raw=True))

if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-23 05:05:56.259271
# Unit test for function join_args
def test_join_args():
    assert join_args(['hello', 'world']) == 'hello world'
    assert join_args(['hello world']) == 'hello world'
    assert join_args(['hello\nworld']) == 'hello\nworld'
    assert join_args(['hello\nworld', 'new\nlines']) == 'hello\nworld new\nlines'
    assert join_args(['hello', '\n', 'world']) == 'hello\nworld'



# Generated at 2022-06-23 05:06:07.239806
# Unit test for function parse_kv
def test_parse_kv():
    (b_options, options) = (dict(), dict())
    args = "a=b c=\"d e\" f='' g=''"

    def decode_match(match):
        return codecs.decode(match.group(0), 'unicode-escape')

    _ESCAPE_SEQUENCE_RE.sub(decode_match, args)

    b_options = parse_kv(args, check_raw=False)
    # We don't care about python version differences (py2 vs py3)
    # so we'll just convert the bytes to a string
    options['a'] = 'b'
    options['c'] = 'd e'
    options['f'] = ''
    options['g'] = ''
    options['_raw_params'] = "a=b c=\"d e\" f='' g=''"

# Generated at 2022-06-23 05:06:14.415460
# Unit test for function join_args
def test_join_args():
    cmd = """
    shell: /some/command arg1 arg2 arg3 arg4
    """
    s = split_args(cmd)
    cmd2 = join_args(s)
    assert(cmd == cmd2)
    cmd = """
    shell: /some/command arg1 arg2 arg3 arg4
    """
    s = split_args(cmd)
    cmd2 = join_args(s)
    assert(cmd == cmd2)
    assert(cmd == cmd2)



# Generated at 2022-06-23 05:06:22.238520
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.common._collections_compat import Mapping


# Generated at 2022-06-23 05:06:33.632570
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test that different formats of key-value pair strings gets parsed
    correctly to a dict.
    '''
    string = 'key=value key2=value2'
    res = parse_kv(string)
    assert res == {u'key': u'value', u'key2': u'value2'}

    string = '_raw_params=--verbose --recursive'
    res = parse_kv(string)
    assert res == {u'_raw_params': u'--verbose --recursive'}

    string = 'key="val ue" key2=value2'
    res = parse_kv(string)
    assert res == {u'key': u'val ue', u'key2': u'value2'}


# Generated at 2022-06-23 05:06:45.764063
# Unit test for function parse_kv
def test_parse_kv():
    # Empty input
    assert parse_kv('') == {}
    # Empty keyword
    assert parse_kv('foo=bar')['foo'] == 'bar'
    # Quoted keyword
    assert parse_kv('foo="bar"')['foo'] == 'bar'
    # Empty value
    assert parse_kv('foo=')['foo'] == ''
    # Quoted value
    assert parse_kv('foo="bar baz"')['foo'] == 'bar baz'
    # Escaped value
    assert parse_kv('foo=bar\\ baz')['foo'] == 'bar baz'
    # Quoted empty value
    assert parse_kv('foo=""')['foo'] == ''
    # Quoted empty value
    assert parse_kv('foo="\\"\\"')['foo'] == '""'

# Generated at 2022-06-23 05:06:57.053413
# Unit test for function parse_kv
def test_parse_kv():
    print("test_parse_kv")
    print("\tparse_kv('') = %r" % parse_kv(''))
    print("\tparse_kv('foo=bar') = %r" % parse_kv('foo=bar'))
    print("\tparse_kv('foo=') = %r" % parse_kv('foo='))
    print("\tparse_kv('foo= bar') = %r" % parse_kv('foo= bar'))
    print("\tparse_kv('foo=bar baz=quux') = %r" % parse_kv('foo=bar baz=quux'))

# Generated at 2022-06-23 05:07:06.872634
# Unit test for function join_args
def test_join_args():
    s = ['foo', 'arg']
    assert join_args(s) == 'foo arg'
    s = ['foo', 'arg', 'more']
    assert join_args(s) == 'foo arg more'
    s = ['foo', 'arg\nmore']
    assert join_args(s) == 'foo arg\nmore'
    s = ['foo', 'arg', '\nmore']
    assert join_args(s) == 'foo arg \nmore'
    s = ['foo', 'arg', '\nmore\n']
    assert join_args(s) == 'foo arg \nmore\n'
    s = ['foo', 'arg', '\nmore', '\n']
    assert join_args(s) == 'foo arg \nmore\n'

# Generated at 2022-06-23 05:07:16.227672
# Unit test for function join_args
def test_join_args():
    assert join_args(['a']) == 'a'
    assert join_args(['a b c']) == 'a b c'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\nb\nc']) == 'a\nb\nc'
    assert join_args(['a', 'b', 'c\nd']) == 'a b c\nd'
    assert join_args(['a\nb', 'c\nd']) == 'a\nb c\nd'
    assert join_args(['a\nb', 'c d']) == 'a\nb c d'
    assert join_args(['a\n', 'b\n', 'c\n']) == 'a\nb\nc\n'

# Generated at 2022-06-23 05:07:25.778346
# Unit test for function parse_kv
def test_parse_kv():
    
    assert parse_kv('a=b c="d e" f="g h i"') == {u'a': u'b',
    u'c': u'd e', u'f': u'g h i', u'_raw_params': u'a=b c="d e" f="g h i"'}
    assert parse_kv('a="b c"') == {u'a': u'b c', u'_raw_params': u'a="b c"'}
    assert parse_kv('a=b c=d e=f') == {u'a': u'b', u'c': u'd', u'e': u'f',
    u'_raw_params': u'a=b c=d e=f'}


# Generated at 2022-06-23 05:07:35.353048
# Unit test for function split_args

# Generated at 2022-06-23 05:07:44.709270
# Unit test for function join_args
def test_join_args():
    import re
    string = "this is a string with some\n"
    string += "whitespace\n"
    string += "and some newlines\n"
    string += "and\tthe odd tab"
    split1 = split_args(string)
    join1 = join_args(split1)
    split2 = split_args(join1)
    join2 = join_args(split2)

    match_string = re.sub(r'\s', '', string)
    match_join2 = re.sub(r'\s', '', join2)
    assert match_string == match_join2

test_join_args()



# Generated at 2022-06-23 05:07:55.324320
# Unit test for function split_args
def test_split_args():
    def check_split_args(result, expected, args):
        if result != expected:
            print("'%s' failed." % (args))
            print(result)
            print(expected)
            assert False

    check_split_args(split_args("a=b c=\"foo bar\""),
                     ['a=b', 'c="foo bar"'],
                     "a=b c=\"foo bar\"")
    check_split_args(split_args("{{ a }}"),
                     ['{{', 'a', '}}'],
                     "{{ a }}")
    check_split_args(split_args("{{ a }} 'b c'"),
                     ['{{', 'a', '}}', '\'b c\''],
                     "{{ a }} 'b c'")

# Generated at 2022-06-23 05:08:03.779044
# Unit test for function parse_kv
def test_parse_kv():

    import sys
    import inspect
    caller = inspect.stack()[1][3]

    print("Testing " + __file__ + "::" + caller)


# Generated at 2022-06-23 05:08:10.835734
# Unit test for function parse_kv
def test_parse_kv():
    # Dict returned by parse_kv
    result_dict = {}
    # String to test
    test_arg_string = "key1=value1 key2=value2 key3=value3"
    # Expected result
    result_dict = {"key1":"value1", "key2":"value2", "key3":"value3"}
    # Test parse_kv function
    assert parse_kv(test_arg_string) == result_dict

# Test case for function parse_kv

# Generated at 2022-06-23 05:08:21.590546
# Unit test for function split_args
def test_split_args():
    import os
    import sys
    import yaml

    def read_test_cases(f):
        tests = []
        with open(f, 'r') as stream:
            try:
                tests = yaml.safe_load(stream)
            except yaml.YAMLError as exc:
                print(exc)
        return tests

    test_cases = read_test_cases(os.path.join(sys.path[0], 'split_args.yml'))

    # This is the function we're testing
    test_function = split_args

    # Test each case
    print("Testing {} cases".format(len(test_cases)))
    failures = 0

# Generated at 2022-06-23 05:08:29.717308
# Unit test for function join_args
def test_join_args():
    s = [u"{{foo", u"bar}}"]
    assert join_args(s) == u"{{foo bar}}"
    s = [u"echo", u"{{foo", u"bar}}"]
    assert join_args(s) == u"echo {{foo bar}}"
    s = [u"{{foo", u"bar}}", u"echo"]
    assert join_args(s) == u"{{foo bar}} echo"
    s = [u"", u"{{foo", u"bar}}", u"", u"", u"", u""]
    assert join_args(s) == u"{{foo bar}}"



# Generated at 2022-06-23 05:08:40.844943
# Unit test for function split_args
def test_split_args():
    # Test basic splitting
    assert split_args(u'') == []
    assert split_args(u'a b c') == [u'a', u'b', u'c']
    assert split_args(u'\\a b c') == [u'a', u'b', u'c']
    assert split_args(u'a\\ b c') == [u'a b', u'c']
    assert split_args(u'a \\\n b \\\n c') == [u'a', u'b', u'c']
    assert split_args(u'a\\\n b \\\n c') == [u'a b', u'c']
    assert split_args(u'a b \\\n c') == [u'a', u'b', u'c']

# Generated at 2022-06-23 05:08:49.865358
# Unit test for function join_args
def test_join_args():
    # Should return the same thing
    assert join_args(split_args(join_args(split_args('foo bar "baz qux" "blah"')))) == 'foo bar "baz qux" "blah"'


# this is a literal string so that the test will not evaluate jinja2 variables
STR_IS_JINJA_REGEX = r'\{\{\s*.*\}\}'
JINJA_BLOCK_TOKENS = ('{{', '}}')


# Generated at 2022-06-23 05:09:01.055132
# Unit test for function join_args
def test_join_args():
    assert '-f1 -f2 -f3' == join_args(['-f1', '-f2', '-f3'])
    assert '-f1 -f2 -f3' == join_args([' -f1', '\n -f2', '\n -f3'])
    assert '-f1 -f2 -f3' == join_args(['-f1', '-f2 \n', '-f3'])
    assert '-f 1 -f 2 -f 3' == join_args(['-f 1', '-f 2 -f 3'])
    assert '-f 1 -f 2 -f 3' == join_args(['-f 1 -f 2', '-f 3 '])

# Generated at 2022-06-23 05:09:08.773839
# Unit test for function join_args

# Generated at 2022-06-23 05:09:20.285282
# Unit test for function parse_kv
def test_parse_kv():
    class FakeFile:
        def __init__(self, testfile):
            self.testfile = testfile
        def readline(self):
            return self.testfile.pop(0)
    def test_file(args, check_raw=False, quote_mode=False):
        tf = [args]
        return parse_kv(FakeFile(tf), check_raw=check_raw)
    assert test_file('foo=bar') == {u'foo': u'bar'}
    assert test_file('foo="bar"') == {u'foo': u'bar'}
    assert test_file('foo="bar baz"') == {u'foo': u'bar baz'}
    assert test_file('foo="bar baz') == {u'_raw_params':u'foo="bar baz'}


# Generated at 2022-06-23 05:09:31.466439
# Unit test for function split_args
def test_split_args():
    assert split_args(u"foo bar") == [u"foo", u"bar"]
    assert split_args(u"foo 'bar baz'") == [u"foo", u"'bar baz'"]
    assert split_args(u"foo '\"bar baz\"'") == [u"foo", u"'\"bar baz\"'"]
    assert split_args(u"foo \"'bar baz'\"") == [u"foo", u"\"'bar baz'\""]
    assert split_args(u"foo \"bar baz\"") == [u"foo", u"\"bar baz\""]
    assert split_args(u"foo 'bar" + "\\\n" + u"baz'") == [u"foo", u"'barbaz'"]

# Generated at 2022-06-23 05:09:41.459829
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.compat.tests import unittest
    from ansible.module_utils.six import StringIO

    class TestKV(unittest.TestCase):

        def test_parse_unquoted_value(self):
            input_str = 'foo=bar'
            expected = {'foo': 'bar'}
            self.assertEqual(expected, parse_kv(input_str))

        def test_parse_quoted_value(self):
            input_str = 'foo="bar"'
            expected = {'foo': 'bar'}
            self.assertEqual(expected, parse_kv(input_str))

        def test_parse_double_quoted_value(self):
            input_str = 'foo="bar baz"'
            expected = {'foo': 'bar baz'}
           

# Generated at 2022-06-23 05:09:46.194936
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo', '\n', 'bar']) == 'foo \n bar'
    assert join_args(['foo', '\n', 'bar', '\n', 'baz']) == 'foo \n bar \n baz'



# Generated at 2022-06-23 05:09:57.189170
# Unit test for function split_args
def test_split_args():
    # Very basic test
    test1 = ['a=b', 'c="foo bar"']
    result = split_args('a=b c="foo bar"')
    assert test1 == result, "test1 failed"

    # This is a test that should fail, because the open quotes here
    # will be closed by the split function
    test2 = ['a=b', 'c="foo bar"']
    result = split_args('a=b c="foo bar')
    assert test2 == result, "test2 failed"

    # The same as above, but using single quotes
    test3 = ['a=b', "c='foo bar'"]
    result = split_args('a=b c="foo bar')
    assert test3 == result, "test3 failed"

    # Verify that the function removes quotes

# Generated at 2022-06-23 05:09:59.146335
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'hi']) == 'echo hi'
    assert join_args(['echo', 'hi', 'there']) == 'echo hi there'
    assert join_args(['echo', 'hi\nthere']) == 'echo hi\nthere'
    assert join_args(['echo', 'hi', 'there\n']) == 'echo hi there\n'


# Generated at 2022-06-23 05:10:05.944116
# Unit test for function join_args
def test_join_args():
    test1 = ['a b', 'c', 'd e', '\nf g']
    expected1 = 'a b c d e\nf g'
    assert join_args(test1) == expected1
    test2 = ['a b', 'c', 'd e', '\nf g\nh\n', 'i']
    expected2 = 'a b c d e\nf g\nh\ni'
    assert join_args(test2) == expected2



# Generated at 2022-06-23 05:10:16.776509
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv(u'') == {}
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u"foo='bar baz'") == {u'foo': u'bar baz'}
    assert parse_kv(u"foo='bar baz' bax=blip") == {u'foo': u'bar baz', u'bax': u'blip'}
    assert parse_kv(u"foo='(bar baz)' bax=blip") == {u'foo': u'(bar baz)', u'bax': u'blip'}

# Generated at 2022-06-23 05:10:22.326362
# Unit test for function join_args
def test_join_args():
    assert join_args(["arg1", "arg2", "arg3"]) == "arg1 arg2 arg3"
    assert join_args(["arg1", "\narg2", "arg3"]) == "arg1\narg2 arg3"
    assert join_args(["arg1", "\"arg2"]) == "arg1 \"arg2"



# Generated at 2022-06-23 05:10:32.346530
# Unit test for function parse_kv
def test_parse_kv():

    def check(given, expected):
        returned = parse_kv(given)
        assert returned == expected, "parse_kv() returned incorrect results for input '{0}' parsed as: {1}".format(given, returned)

    check('foo=bar baz=qux', dict(foo='bar', baz='qux'))
    check('foo=bar=baz baz=qux', dict(foo='bar=baz', baz='qux'))
    check('foo="bar=baz" baz=qux', dict(foo='bar=baz', baz='qux'))
    check('foo="bar"baz" baz=qux', dict(foo='bar"baz', baz='qux'))

# Generated at 2022-06-23 05:10:42.460269
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b c=d e=f') == ['a=b', 'c=d', 'e=f']
    assert split_args('a=b\nc=d') == ['a=b\n', 'c=d']
    assert split_args('a=b\nc=d\ne=f') == ['a=b\n', 'c=d\n', 'e=f']
    assert split_args('a=b\nc=d e=f') == ['a=b\n', 'c=d', 'e=f']

# Generated at 2022-06-23 05:10:53.362648
# Unit test for function split_args
def test_split_args():
    '''
    Test that a few known input args return the expected results.
    '''

    # simple args, shouldn't change at all
    assert split_args('a b c') == ['a', 'b', 'c']

    # args with quotes, shouldn't change at all
    assert split_args('a "b c" d') == ['a', '"b c"', 'd']

    # args with backslash escapes
    assert split_args('a="b c" d=e') == ['a="b c"', 'd=e']

    # args with different types of quotes
    assert split_args('a="b c" d=\'"e f"\'') == ['a="b c"', 'd=\'"e f"\'']

    # args with spaces inside quotes