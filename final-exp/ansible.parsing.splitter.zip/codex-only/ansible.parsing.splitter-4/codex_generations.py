

# Generated at 2022-06-23 05:00:58.009217
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv("a=b") == { 'a': 'b' }
    assert parse_kv("a=b c=d") == { 'a': 'b', 'c': 'd' }
    assert parse_kv("a=b 'c=d e'=f") == { 'a': 'b', 'c=d e': 'f' }
    assert parse_kv("a=b 'c=d e'=f 'g' 'h=i'") == { 'a': 'b', 'c=d e': 'f', '_raw_params': 'g \'h=i\'' }

# Generated at 2022-06-23 05:01:10.741710
# Unit test for function parse_kv

# Generated at 2022-06-23 05:01:19.838806
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 "b"=2') == {u'a': u'1', u'b': u'2'}
    assert parse_kv('a=1 b=2', check_raw=True) == {u'a': u'1', u'b': u'2'}
    assert parse_kv('a=1 b:2', check_raw=True) == {u'a': u'1', u'b': u'2', u'_raw_params': u'b:2'}
    assert parse_kv('a=1 b="b2 b3"', check_raw=True) == {u'a': u'1', u'b': u'b2 b3'}

# Generated at 2022-06-23 05:01:27.689887
# Unit test for function split_args
def test_split_args():

    def assert_parses_args_to(source, expected_params):
        result = split_args(source)
        assert expected_params == result

    assert_parses_args_to(u"one two three", [u"one", u"two", u"three"])
    assert_parses_args_to(u"""one two three""", [u"one", u"two", u"three"])
    assert_parses_args_to(u"one\ntwo\nthree", [u"one\ntwo\nthree"])
    assert_parses_args_to(u"""one \n two \n three""", [u"one", u"\n", u"two", u"\n", u"three"])

# Generated at 2022-06-23 05:01:37.833490
# Unit test for function join_args
def test_join_args():
    assert join_args(['arg1', 'arg2', 'arg3']) == 'arg1 arg2 arg3'
    assert join_args(['arg1', 'arg2', '\n', 'arg3']) == 'arg1 arg2\narg3'

# Split args by spaces, but keep newlines intact
# Currently handles:
# * single-quoted strings with escaped single quotes and backslashes
# * double-quoted strings with escaped double quotes and backslashes
# * balanced jinja2 blocks
# * balanced bash blocks
# * single-line Python comments
# This is a work in progress. The goal is to eventually be able to
# handle anything that a shell would handle, without worrying about
# the details of the shell syntax.
# FIXME: expand this to handle the entire shell grammar
_split_args_pattern = re.comp

# Generated at 2022-06-23 05:01:43.265535
# Unit test for function join_args
def test_join_args():
    assert join_args(['a b', 'c', 'd']) == 'a b c d'
    assert join_args(['a b', '\nc']) == 'a b\nc'
    assert join_args(['a b\n', 'c']) == 'a b\n c'
    assert join_args(['a b\n', 'c\n']) == 'a b\n c\n'



# Generated at 2022-06-23 05:01:47.285567
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', "'b c'"]) == "a 'b c'"
    assert join_args(['a', '"b c"']) == 'a "b c"'


# Generated at 2022-06-23 05:01:56.796753
# Unit test for function split_args
def test_split_args():
    try:
        os.remove('test_args.txt')
    except:
        pass
    with open('test_args.txt', 'wb') as f:
        f.write('''{% if x|default(y)  in ['foo', 'bar'] %}
        'hello'
        {% else %}
        'howdy'
        {% endif %}
        {# this is a comment #}
        hello="world"
        foo="bar"
        cool="cats"
        abc=def
        {% if 'hello' in 'helloworld' -%}
        yes
        {% else -%}
        no
        {%- endif %}'''.encode('utf-8'))

# Generated at 2022-06-23 05:02:10.895764
# Unit test for function split_args
def test_split_args():

    # Very basic argument split test
    args = ["a=b c=d e=f g=h", "i=j k=l m=n o=p", "q=r s=t u=v w=x", "y=z"]
    test_input = '\n'.join(args)
    result = split_args(test_input)
    assert result == args

    # Basic argument split test, with a empty argument
    args = ["a=b c=d e=f g=h", "i=j k=l m=n o=p", "q=r s=t u=v w=x", "y=z", ""]
    test_input = '\n'.join(args)
    result = split_args(test_input)
    assert result == args

    # Test argument split with valid line continuation
   

# Generated at 2022-06-23 05:02:18.767970
# Unit test for function parse_kv
def test_parse_kv():
    string = 'foo=bar baz=qux one=two=three'
    print(parse_kv(string))
    string = "foo 'bar baz' qux"
    print(parse_kv(string))
    string = "foo is bar and baz is qux"
    print(parse_kv(string, check_raw=True))
    string = "foo=bar baz=qux \\=one=two=three"
    print(parse_kv(string))



# Generated at 2022-06-23 05:02:23.124956
# Unit test for function join_args
def test_join_args():
    assert 'foo' == join_args(['foo'])
    assert 'foo bar' == join_args(['foo', 'bar'])
    assert 'foo bar' == join_args(['foo', '', 'bar'])
    assert 'foo\nbar' == join_args(['foo', '\n', 'bar'])



# Generated at 2022-06-23 05:02:28.082257
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', '\nb', 'c']) == 'a\n b c'
    assert join_args(['', '\n', 'a']) == '\na'



# Generated at 2022-06-23 05:02:32.913136
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', '\n', 'bar']) == 'foo\nbar'
    assert join_args(['f', 'o', 'o']) == 'f o o'


# Note: this is intentionally not a method on _BaseAction, since it uses the
# quote-splitting method from _BaseAction but only operates on a single string

# Generated at 2022-06-23 05:02:42.116354
# Unit test for function join_args
def test_join_args():
    assert(join_args([]) == '')
    assert(join_args(['command']) == 'command')
    assert(join_args(['command1', 'command2']) == 'command1 command2')
    assert(join_args(['command1', '\ncommand2']) == 'command1 \ncommand2')
    assert(join_args(['command1', '\ncommand2', 'command3']) == 'command1 \ncommand2 command3')
    assert(join_args(['command1', 'command2', '\ncommand3']) == 'command1 command2 \ncommand3')
    assert(join_args(['command1', '', 'command2']) == 'command1  command2')


# Generated at 2022-06-23 05:02:52.897041
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test function parse_kv
    '''

    assert(parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'})
    assert(parse_kv('a=b c="d e" f=g') == {'a': 'b', 'c': 'd e', 'f': 'g'})
    assert(parse_kv('a=b "c=d e" f=g') == {'a': 'b', 'c=d e': '', 'f': 'g'})
    assert(parse_kv('a=b c="d=e" f=g') == {'a': 'b', 'c': 'd=e', 'f': 'g'})

# Generated at 2022-06-23 05:02:57.536489
# Unit test for function parse_kv
def test_parse_kv():
    args = "ssh -o ControlPath=/srv/test/.ansible/jump/%h-%p-%r -o ControlMaster=auto -o ControlPersist=30m"
    kv = parse_kv(args)
    assert len(kv) == 4
    assert kv['stdin_add_newline'] == u'True'
    assert kv['_raw_params'] == args



# Generated at 2022-06-23 05:03:06.591320
# Unit test for function split_args
def test_split_args():
    # If all of these test cases pass, we can be sure that the function
    # split_args() works as expected
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foobar"') == ['a=b', 'c="foobar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']

# Generated at 2022-06-23 05:03:14.941850
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'foo']) == 'echo foo'
    assert join_args(['echo', ' foo']) == 'echo  foo'
    assert join_args(['echo', '\nfoo']) == 'echo\nfoo'


# Generated at 2022-06-23 05:03:22.210430
# Unit test for function split_args
def test_split_args():
    import ansible
    import ansible.parsing.vault
    import ansible.parsing.splitter
    import tempfile
    import os
    import codecs
    import locale

    locale.setlocale(locale.LC_ALL, '')

    fil = tempfile.mkstemp()
    os.close(fil[0])
    fil = fil[1]

    def test(s, should_raise=False):
        with open(fil, 'wb') as f:
            if isinstance(s, str):
                f.write(s.encode())
            else:
                f.write(s)

        ex = None

# Generated at 2022-06-23 05:03:32.331582
# Unit test for function split_args
def test_split_args():
    test_input = []
    test_output = []
    test_input.append("foo = 'simple'")
    test_input.append("foo = 'with spaces'")
    test_input.append("foo = 'with spaces AND {{and jinja2'")
    test_input.append("foo = 'with spaces AND {{and jinja2' bar = 'with spaces AND }}}}and jinja2'")
    test_input.append("foo = '{{{with spaces AND }}}}and jinja2'")
    test_input.append("foo = 'with spaces AND }}and jinja2'")
    test_input.append("foo = 'with spaces AND {%and jinja2'")

# Generated at 2022-06-23 05:03:43.220954
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=a b=b c=c') == {u'a': u'a', u'b': u'b', u'c': u'c'}
    assert parse_kv('a="something with spaces"') == {u'a': u'something with spaces'}
    assert parse_kv('a=\\"something with spaces\\"') == {u'a': u'something with spaces'}
    assert parse_kv('a=something\ with\ spaces') == {u'a': u'something with spaces'}
    assert parse_kv('a=something$with$env$vars') == {u'a': u'something$with$env$vars'}

# Generated at 2022-06-23 05:03:56.369067
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a b', 'b', 'c']) == 'a b b c'
    assert join_args(['a', 'b', 'c d']) == 'a b c d'
    assert join_args(['a', 'b', 'c', 'd']) == 'a b c d'
    assert join_args(['a', 'b\nc', 'd']) == 'a b\nc d'
    assert join_args(['a', 'b\n c', 'd']) == 'a b\n c d'
    assert join_args(['a', 'b\n  c', 'd']) == 'a b\n  c d'

# Generated at 2022-06-23 05:04:04.561300
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo', 'bar baz']) == 'foo bar baz'
    assert join_args(['foo bar baz']) == 'foo bar baz'
    assert join_args(['foo bar\nbaz']) == 'foo bar\nbaz'
    assert join_args(['foo', 'bar\nbaz']) == 'foo bar\nbaz'
    assert join_args(['foo\nbar\nbaz']) == 'foo\nbar\nbaz'



# Generated at 2022-06-23 05:04:15.178868
# Unit test for function parse_kv
def test_parse_kv():
    parse_kv("a=b")
    parse_kv("a='b")
    parse_kv("a=b c=d")
    parse_kv("a=b\nc=d")
    parse_kv("a=b'c")
    parse_kv("a=b=c")
    parse_kv("a=b c")
    parse_kv("a=b c=d", check_raw=True)
    parse_kv("a=b c", check_raw=True)
    parse_kv("a=b'c", check_raw=True)
    parse_kv("a=b c=d e", check_raw=True)
    parse_kv("a=b c=d e=f", check_raw=True)

# Generated at 2022-06-23 05:04:25.609964
# Unit test for function parse_kv
def test_parse_kv():
    def assert_equal(in_str, out_dict):
        assert parse_kv(in_str) == out_dict

    assert_equal('a=b c=d', {u'a': u'b', u'c': u'd'})
    assert_equal('a="b=1 2=3" c=bar', {u'a': u'"b=1 2=3"', u'c': u'bar'})
    assert_equal('a=b c="d e"', {u'a': u'b', u'c': u'"d e"'})
    assert_equal('a=b\'c d\'', {u'a': u'b\'c d\''})

# Generated at 2022-06-23 05:04:35.160303
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("k=v")
    assert options['k'] == 'v'

    options = parse_kv("k = v")
    assert options['k'] == 'v'

    options = parse_kv("k=v ", check_raw=True)
    assert options['k'] == 'v'

    options = parse_kv("k = v ", check_raw=True)
    assert options['k'] == 'v'

    options = parse_kv("k=v with spaces ", check_raw=True)
    assert options['k'] == 'v with spaces'
    assert options['_raw_params'] == 'k=v with spaces'

    options = parse_kv("k = v with spaces ", check_raw=True)
    assert options['k'] == 'v with spaces'

# Generated at 2022-06-23 05:04:44.252440
# Unit test for function split_args
def test_split_args():
    teststr = "this string = has = some = equals = signs"
    ret = split_args(teststr)
    assert ret == ['this', 'string', '=', 'has', '=', 'some', '=', 'equals', '=', 'signs']

    teststr = '''["this string contains some whitespace"]'''
    ret = split_args(teststr)
    assert ret == ['["this string contains some whitespace"]']

    teststr = '''["this string contains some whitespace"] foo=bar'''
    ret = split_args(teststr)
    assert ret == ['["this string contains some whitespace"]', 'foo=bar']

    teststr = '''["this string = has = some = equals = signs"]'''
    ret = split_args(teststr)

# Generated at 2022-06-23 05:04:55.584902
# Unit test for function split_args
def test_split_args():
    '''
    A simple test of the split_args() function.
    '''
    # The input and expected output are a list of tuples, where the first
    # item is the input and the second is the expected output
    # (expecting an exception is indicated by an AnsibleParserException)

# Generated at 2022-06-23 05:05:07.183029
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c='foo bar'") == [u"a=b", u"c='foo bar'"]
    assert split_args(u"a=b c=\"\\'foo bar\\\" d=\"") == [u"a=b", u'c="\\\'foo bar\\"', u'd="']
    assert split_args(u"a=b c='foo bar") == [u"a=b", u"c='foo", u"bar"]
    assert split_args(u"a=b c=\"\\'foo bar\"") == [u'a=b', u'c="\\\'foo bar"']

# Generated at 2022-06-23 05:05:18.491401
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv("x=y z=a=b")
    debug_info(result)
    assert result  == {'x': 'y', 'z': 'a=b'}
    result = parse_kv("x= y z=a=b", check_raw=True)
    debug_info(result)
    assert result == {'x': 'y', 'z': 'a=b', '_raw_params': 'x= y z=a=b'}
    result = parse_kv("x='y' z=a=b", check_raw=True)
    debug_info(result)
    assert result == {'x': 'y', 'z': 'a=b', '_raw_params': "x='y' z=a=b"}

# Generated at 2022-06-23 05:05:26.496317
# Unit test for function join_args
def test_join_args():
    assert join_args(['ls', '-la', '/']) == 'ls -la /'
    assert join_args(['ls', '\n-la', '\n/']) == 'ls\n-la\n/'
    assert join_args(['ls', '-la', '\n/']) == 'ls -la \n/'
    assert join_args(['ls', '-la', '\n/\n']) == 'ls -la \n/\n'
    assert join_args(['ls', '-la', '\n/\n\n']) == 'ls -la \n/\n\n'
    assert join_args(['ls', '\n-la', '\n/\n']) == 'ls\n-la\n/\n'

# Generated at 2022-06-23 05:05:36.884723
# Unit test for function join_args
def test_join_args():
    success = True
    # Test 1
    s = ["foo bar", "baz"]
    r = join_args(s)
    if r != "foo bar baz":
        print("'{}' != '{}'".format(r, "foo bar baz"))
        success = False
    # Test 2
    s = ["foo", "\nbar", "baz"]
    r = join_args(s)
    if r != "foo\nbar baz":
        print("'{}' != '{}'".format(r, "foo\nbar baz"))
        success = False
    # Test 3
    s = ["foo", "\nbar", "baz", "boo\n", "else\nfoo"]
    r = join_args(s)

# Generated at 2022-06-23 05:05:47.964842
# Unit test for function split_args
def test_split_args():
    '''
    Test the split_args function, used by the command module
    '''
    # The list of tests is a list of tuples. The first element is a string with the
    # command line options to split. The second is the expected result.

# Generated at 2022-06-23 05:05:52.447177
# Unit test for function join_args
def test_join_args():
    s = ['a', '\n', 'b', ' c', '\n', 'd e']
    assert join_args(s) == 'a\nb c\nd e'



# Generated at 2022-06-23 05:05:56.997606
# Unit test for function join_args
def test_join_args():
    assert join_args(['cd', '"a b\"c\"d"']) == 'cd "a b\"c\"d"'
    assert join_args(['"a', 'b\\', '"c"', 'd"']) == "\"a b\\\"c\"d\""
    assert join_args(['cd', '"a b\\"c\\""d"']) == 'cd "a b\\"c\\""d"'



# Generated at 2022-06-23 05:06:07.702622
# Unit test for function join_args
def test_join_args():
    '''
    Test the join_args function
    '''
    assert join_args(['arg1=value1', 'arg2=value2']) == 'arg1=value1 arg2=value2'
    assert join_args(['arg1="value1', 'value2"', 'arg2="value3', 'value4']) == 'arg1="value1 value2" arg2="value3 value4'
    assert join_args(['arg1="value1', '\nvalue2"', 'arg2="value3', '\nvalue4']) == 'arg1="value1\nvalue2" arg2="value3\nvalue4'

# Generated at 2022-06-23 05:06:10.843830
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', '\nb', ' c ']) == 'a\n b c '


# Generated at 2022-06-23 05:06:14.942235
# Unit test for function join_args
def test_join_args():
    assert join_args(['ls', '-l']) == 'ls -l'
    assert join_args(['ls', '\n', '-l']) == 'ls \n-l'
    assert join_args(['echo', 'foo', '\n', '  ', '&&', '\n', 'bar']) == 'echo foo \n  && \nbar'



# Generated at 2022-06-23 05:06:25.499564
# Unit test for function join_args
def test_join_args():
    assert "ls -l" == join_args(["ls", "-l"])
    assert "nohup ls -l" == join_args(["nohup", "ls", "-l"])
    assert "nohup ls -l &" == join_args(["nohup", "ls", "-l", "&"])
    assert "nohup ls -l" == join_args(["nohup", "ls -l"])
    assert "nohup ls -l" == join_args(["nohup", "ls", " ", "-l"])
    assert "nohup ls\nl -l" == join_args(["nohup", "ls", "\nl", "-l"])

# Generated at 2022-06-23 05:06:31.889185
# Unit test for function join_args
def test_join_args():
    "Test cases for join_args"
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\n', 'b', 'c']) == 'a\nb c'
    assert join_args(['a\n', 'b\n', 'c']) == 'a\nb\nc'



# Generated at 2022-06-23 05:06:40.000636
# Unit test for function split_args
def test_split_args():
    '''Tests for split_args function'''
    import pytest
    # TODO: automate these tests
    #test_string = 'a=b c="foo bar"'

    #test_result = ['a=b', 'c="foo bar"']
    #assert split_args(test_string) == test_result

    #test_string = u'a=b c=\xe2\x21\x20d'
    #test_result = ['a=b', u'c=\xe2\x21\x20d']
    #assert split_args(test_string) == test_result

    #test_string = "a='b' 'c'"
    #test_result = ["a='b'", "'c'"]
    #assert split_args(test_string) == test_result

    #test_string

# Generated at 2022-06-23 05:06:49.590216
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.common.collections import is_sequence
    args = '''
    param=value
    param="value with spaces"
    param=value\ with\ quotes
    param="value with spaces and 'quotes'"
    param="value with spaces and \"quotes\""
    param=value with spaces and "quotes"
    '''
    data = parse_kv(to_text(args))
    assert data['param'] == "value with spaces and \"quotes\""
    assert data['_raw_params'] == 'param=value with spaces and "quotes"'

# Generated at 2022-06-23 05:06:57.357956
# Unit test for function join_args
def test_join_args():
    # The first one has only empty lines and whitespaces,
    # so the output should be empty.
    assert join_args(['  ']) == ''
    # The first line has a newline, so it should be preserved.
    assert join_args(['\n ']) == '\n '
    assert join_args(['a','b','c']) == 'a b c'
    assert join_args(['a','b','c','\n','d','e','f']) == 'a b c \n d e f'



# Generated at 2022-06-23 05:07:00.810256
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', '\nb', '\n\nc']) == 'a\nb\n\nc'



# Generated at 2022-06-23 05:07:12.065945
# Unit test for function split_args

# Generated at 2022-06-23 05:07:22.806023
# Unit test for function split_args
def test_split_args():
    import sys

# Generated at 2022-06-23 05:07:34.208616
# Unit test for function split_args
def test_split_args():
    func = split_args
    
    assert func('') == ['']
    assert func('hello') == ['hello']
    
    assert func('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert func('a=b c="foo bar"\nd=e f="fast and furious"') == ['a=b c="foo bar"', 'd=e f="fast and furious"']
    assert func('a=b f=g c="foo bar"\ne=f z=y') == ['a=b f=g c="foo bar"', 'e=f z=y']
    assert func('a=b f=g c="foo bar"\ne=f z=y') == ['a=b f=g c="foo bar"', 'e=f z=y']
   

# Generated at 2022-06-23 05:07:44.122369
# Unit test for function join_args
def test_join_args():
    assert join_args(['hello']) == 'hello'
    assert join_args(['hello', 'world']) == 'hello world'
    assert join_args(['hello', 'world\n']) == 'hello world\n'
    assert join_args(['hello', 'world\n', 'How are you?']) == 'hello world\n How are you?'
    assert join_args(['hello', 'world\n', 'How are you?\n']) == 'hello world\n How are you?\n'
    assert join_args(['hello', 'world\n', 'How are you?\n', 'I am fine.']) == 'hello world\n How are you?\n I am fine.'



# Generated at 2022-06-23 05:07:54.895877
# Unit test for function split_args
def test_split_args():
    '''Test for function split_args'''
    import AnsibleModuleExecutor
    import AnsibleExecutor
    executor = AnsibleModuleExecutor.AnsibleModuleExecutor()

# Generated at 2022-06-23 05:08:03.592623
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=1 b=2 c="foo bar"') == {u'a': u'1', u'c': u'foo bar', u'b': u'2'}
    assert parse_kv(u'a=1 b="foo bar" c=3') == {u'a': u'1', u'c': u'3', u'b': u'foo bar'}
    assert parse_kv(u'a=1 b=2 c=3') == {u'a': u'1', u'c': u'3', u'b': u'2'}
    assert parse_kv(u'a= b=') == {u'a': u'', u'b': u''}

# Generated at 2022-06-23 05:08:08.399952
# Unit test for function join_args
def test_join_args():
    # cmd = 'foo=bar echo hello world'
    # cmd_args = ['foo=bar', 'echo', 'hello world']
    # print "'{0}'".format(join_args(cmd_args))
    assert join_args(['foo=bar', 'echo', 'hello world']) == 'foo=bar echo hello world'


# Generated at 2022-06-23 05:08:19.181357
# Unit test for function split_args
def test_split_args():
    assert split_args(u'') == [u'']
    assert split_args(u'''foo bar''') == [u'foo', u'bar']
    assert split_args(u'''foo bar baz''') == [u'foo', u'bar', u'baz']
    assert split_args(u'''foo bar "baz"''') == [u'foo', u'bar', u'"baz"']
    assert split_args(u'''foo bar "baz" qux''') == [u'foo', u'bar', u'"baz"', u'qux']
    assert split_args(u'''foo "bar baz" qux''') == [u'foo', u'"bar baz"', u'qux']

# Generated at 2022-06-23 05:08:27.030211
# Unit test for function join_args
def test_join_args():
    string = split_args("""
    cmd1 -k1 v1 -k2 v2 -k3 v3 -k4 "v4 with spaces" -k5 'v5 with spaces' -k6 "v6 with \\"quotes\\"" -k7 "v7 with 'quotes'" -k8 'v8 with \\'quotes\\''
    cmd2 -k1 v1 -k2 v2 -k3 v3 -k4 "v4 with spaces"
    """)

# Generated at 2022-06-23 05:08:38.800599
# Unit test for function parse_kv
def test_parse_kv():
    # Unit test for function parse_kv
    # Testing option parser
    args = "creates=/tmp/foo removes=/tmp/bar chdir=executable=False warn=False stdin= ls -la"
    options = parse_kv(args, check_raw=True)
    assert options['creates'] == '/tmp/foo', "Failed to parse creates option"
    assert options['removes'] == '/tmp/bar', "Failed to parse removes option"
    assert options['chdir'] == '', "Failed to parse chdir option"
    assert options['executable'] == 'False', "Failed to parse executable option"
    assert options['warn'] == 'False', "Failed to parse warn option"
    assert options['stdin'] == '', "Failed to parse stdin option"
    assert options['_raw_params']

# Generated at 2022-06-23 05:08:48.217094
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv('foo=bar key="baz value" key2=\'boo value\'')
    assert options['foo'] == 'bar'
    assert options['key'] == 'baz value'
    assert options['key2'] == 'boo value'
    assert '_raw_params' not in options

    options = parse_kv('foo=bar key="baz value" key2=\'boo value\' another_key=')
    assert options['foo'] == 'bar'
    assert options['key'] == 'baz value'
    assert options['key2'] == 'boo value'
    assert options['another_key'] == ''
    assert '_raw_params' not in options


# Generated at 2022-06-23 05:08:54.853298
# Unit test for function join_args
def test_join_args():
    # test with empty string
    assert join_args([]) == '', "Empty case failed"
    # test with multiple partitions, without new line
    assert join_args(['cmd', '-f', '{{ foo }}']) == 'cmd -f {{ foo }}', "Simple case failed"
    # test with multiple partitions, with one new line
    assert join_args(['ls -l', '-f', '{{ foo }}']) == 'ls -l\n-f {{ foo }}', "Simple case failed"
    # test with multiple partitions, with two new lines
    assert join_args(['ls -l', '-f', '{{ foo }}', '\n', '-f', '{{ foo }}']) == 'ls -l\n-f {{ foo }}\n-f {{ foo }}', "Simple case failed"
    # test with multiple partitions,

# Generated at 2022-06-23 05:09:06.129415
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c='d e' f={{ z }} g='{{ x }}'") == dict(a='b', c='d e', f="{{ z }}", g="{{ x }}")
    assert parse_kv(u"a='b=c d=e'") == dict(a="b=c d=e")
    assert parse_kv(u"a='b=c d=e' f='g=h'") == dict(a="b=c d=e", f="g=h")
    assert parse_kv(u"a='b=c d=e' f='g=h'") == dict(a="b=c d=e", f="g=h")

# Generated at 2022-06-23 05:09:16.979253
# Unit test for function split_args

# Generated at 2022-06-23 05:09:26.855087
# Unit test for function split_args

# Generated at 2022-06-23 05:09:36.086088
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('valid_key=foo') == { u'valid_key': u'foo' }
    assert parse_kv('valid_key=foo valid_key2=foo2') == { u'valid_key': u'foo', u'valid_key2': u'foo2' }
    assert parse_kv('valid_key=foo valid_key2=foo2 valid_key3=foo3') == { u'valid_key': u'foo', u'valid_key2': u'foo2', u'valid_key3': u'foo3' }
    assert parse_kv('') == {}
    assert parse_kv(None) == {}
    assert parse_kv('invalid_key') == { u'_raw_params': u'invalid_key' }

# Generated at 2022-06-23 05:09:47.140267
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar baz quux") == {u'foo': u'bar', u'_raw_params': u'baz quux'}
    assert parse_kv(u"foo=bar baz quux", check_raw=True) == {u'foo': u'bar', u'_raw_params': u'baz quux'}
    assert parse_kv(u"foo=bar baz quux=something") == {u'foo': u'bar', u'quux': u'something'}
    assert parse_kv(u"foo=bar baz quux=something", check_raw=True) == {u'foo': u'bar', u'quux': u'something', u'_raw_params': u'baz'}

# Generated at 2022-06-23 05:09:53.068775
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['test']) == 'test'
    assert join_args(['test', 'test']) == 'test test'
    assert join_args(['test', '\ntest']) == 'test\ntest'
    assert join_args(['\ntest', '\ntest']) == '\ntest\ntest'


# Generated at 2022-06-23 05:10:01.545276
# Unit test for function parse_kv
def test_parse_kv():
    for test_string, parsed_dict in test_parse_kv.tests:
        assert parse_kv(test_string) == parsed_dict


# Generated at 2022-06-23 05:10:12.700905
# Unit test for function join_args
def test_join_args():
    '''
    Test the function join_args()
    This function is a simple concatenation of the input items.
    It is tested here to ensure that changes in split_args()
    do not break it.
    '''
    assert join_args(['a ', 'b']) == 'a b'
    assert join_args(['a\nb']) == 'a\nb'
    assert join_args(['a ', 'b', ' c']) == 'a b c'
    assert join_args(['a\nb', 'c']) == 'a\nb c'
    assert join_args(['a ', 'b', 'c\nd']) == 'a b c\nd'
    assert join_args(['a\nb', 'c\nd']) == 'a\nb c\nd'

# Generated at 2022-06-23 05:10:23.631057
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing parse_kv() with basic arguments")
    assert parse_kv("arg1=foo arg2=bar\n", True) == {u'arg1': u'foo', u'arg2': u'bar', u'_raw_params': u'arg1=foo arg2=bar'}

    print("Testing parse_kv() with unicode arguments")
    assert parse_kv(u"arg1=foo\u1041\u1042\u1043", True) == {u'arg1': u'foo\u1041\u1042\u1043', u'_raw_params': u'arg1=foo\u1041\u1042\u1043'}

    print("Testing parse_kv() with newline arguments")

# Generated at 2022-06-23 05:10:33.307192
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar' d='foo\"bar\"'") == ['a=b', "c='foo bar'", 'd=\'foo"bar"\'']
    assert split_args("a=b c='foo bar' d='foo\"bar\"'") == ['a=b', "c='foo bar'", 'd=\'foo"bar"\'']
    assert split_args("a=b c=\"foo bar\" d=\"foo\"bar\"\"") == ['a=b', "c=\"foo bar\"", 'd="foo"bar""']
    assert split_args("a=b c=\'foo bar\' d=\'foo\\\'bar\'") == ['a=b', "c='foo bar'", "d='foo\\'bar'"]

# Generated at 2022-06-23 05:10:43.017445
# Unit test for function parse_kv
def test_parse_kv():
    # Success cases
    assert parse_kv("a=b") == {"a":"b"}
    assert parse_kv("x=y=z") == {"x":"y=z"}
    assert parse_kv("a=b y=z") == {"a":"b", "y":"z"}
    assert parse_kv("a=b \\\ny=z") == {"a":"b", "y":"z"}
    assert parse_kv("a=\"b c\" y=z") == {"a":"b c", "y":"z"}
    assert parse_kv("a=b \"c d\" y=z") == {"a":"b", "y":"z", "_raw_params": "\"c d\""}
    assert parse_kv("\n") == {}
    assert parse_kv("\n\n") == {}

# Generated at 2022-06-23 05:10:53.633867
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c', 'd']) == 'a b c d'
    assert join_args(['a', '\nb', 'c', 'd']) == 'a\nb c d'
    assert join_args(['a', 'b c', 'd']) == 'a b c d'
    assert join_args(['a', 'b=c', 'd']) == 'a b=c d'
    assert join_args(['a', 'b = c', 'd']) == 'a b = c d'
    assert join_args(['a', '"b = c"', 'd']) == 'a "b = c" d'