

# Generated at 2022-06-23 05:00:53.935047
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar baz" qux') == ['foo', '"bar baz"', 'qux']
    assert split_args('foo "bar baz" qux quux') == ['foo', '"bar baz"', 'qux', 'quux']
    assert split_args('foo "bar \'baz\' qux" quux') == ['foo', '"bar \'baz\' qux"', 'quux']
    assert split_args("foo 'bar baz' qux") == ['foo', "'bar baz'", 'qux']

# Generated at 2022-06-23 05:01:02.859202
# Unit test for function join_args
def test_join_args():
    assert join_args(['ls', '-l']) == 'ls -l'
    assert join_args(['ls', '-l', '-a']) == 'ls -l -a'
    assert join_args(['ls', '-l', '\n', '-a']) == 'ls -l\n-a'
    assert join_args(['ls', '-l', '\n', '-a', '\n', '-b']) == 'ls -l\n-a\n-b'
    assert join_args(['echo', 'a b c d']) == 'echo a b c d'


# Generated at 2022-06-23 05:01:13.611476
# Unit test for function split_args
def test_split_args():
    # Single arg that should not require any special parsing
    args="-a"
    result = ["-a"]

    # Split on whitespace
    args="one two three"
    result = ["one", "two", "three"]

    # Split on whitespace, including newlines
    args="one\ntwo three\nfour\nfive\n"
    result = ["one", "two three", "four", "five"]

    # Basic jinja2-style {{}} block 1
    args="foo bar {{baz one two}}"
    result = ["foo", "bar", "{{baz one two}}"]

    # Basic jinja2-style {{}} block 1
    args="foo bar {{baz one two}}"
    result = ["foo", "bar", "{{baz one two}}"]

    # Basic jinja2-

# Generated at 2022-06-23 05:01:16.976018
# Unit test for function join_args
def test_join_args():
    assert join_args(["foo", "bar"]) == "foo bar"
    assert join_args(["foo\nbar\nbaz"]) == "foo\nbar\nbaz"



# Generated at 2022-06-23 05:01:25.672156
# Unit test for function split_args
def test_split_args():

    class args_test(object):

        def __init__(self, expect_result, test_string):
            self.expect_result = expect_result
            self.test_string = test_string

        def test_equal(self, split_result):
            # Result string elements are joined as a string and then compared.
            # This avoids issues with ordering of elements and whitespace.
            if len(split_result) != len(self.expect_result):
                raise AssertionError("Expected and actual result length differ: %d != %d" %
                                     (len(self.expect_result), len(split_result)))

# Generated at 2022-06-23 05:01:37.059434
# Unit test for function join_args
def test_join_args():
    cmd = 'test\n'
    assert (join_args(split_args(cmd)) == cmd), \
        "splitting and joining back failed"
    cmd = 'test \t  \n'
    assert(join_args(split_args(cmd)) == cmd), \
        "splitting and joining back failed"
    cmd = 'test \t  \n echo 1'
    assert(join_args(split_args(cmd)) == cmd), \
        "splitting and joining back failed"
    cmd = 'test \t  \n echo 1 ; echo 2'
    assert(join_args(split_args(cmd)) == cmd), \
        "splitting and joining back failed"
    cmd = 'test'
    assert(join_args(split_args(cmd)) == cmd), \
        "splitting and joining back failed"


# Generated at 2022-06-23 05:01:45.869143
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=2') == {'a': 'b','c': '2'}
    assert parse_kv('a=1=2') == {'a': '1=2'}
    assert parse_kv('a= this is a string') == {'a': 'this is a string'}
    assert parse_kv('a=what is the value of this?') == {'a': 'what is the value of this?'}
    assert parse_kv('a=b c=2', False) == {'a': 'b','c': '2'}
    assert parse_kv('a=1=2', False) == {'a': '1=2'}
    assert parse_kv('a= this is a string', False) == {'a': 'this is a string'}

# Generated at 2022-06-23 05:01:48.358091
# Unit test for function join_args
def test_join_args():
    assert join_args(['a b', 'c', 'd', '\ne f']) == 'a b c d \ne f'



# Generated at 2022-06-23 05:01:56.610956
# Unit test for function parse_kv
def test_parse_kv():
    # Tests based on examples in module documentation
    # A: Simple usage
    res = parse_kv("var=val var1=val1")
    assert res == {'var': 'val', 'var1': 'val1'}
    # B: multiple same key
    res = parse_kv("var=val var=val1")
    assert res == {'var': 'val1'}
    # C: check quotes handling
    res = parse_kv("var=\"val\"")
    assert res == {'var': 'val'}
    res = parse_kv("var='val'")
    assert res == {'var': 'val'}
    res = parse_kv("var='val' var2=\"val2\"")
    assert res == {'var': 'val', 'var2': 'val2'}
   

# Generated at 2022-06-23 05:02:04.141581
# Unit test for function join_args
def test_join_args():
    s = ['echo', "hi\nhi\nhi", '&&', 'echo', "bye\nbye\nbye"]
    answer = 'echo hi\nhi\nhi && echo bye\nbye\nbye'
    assert join_args(s) == answer



# Generated at 2022-06-23 05:02:13.649840
# Unit test for function join_args
def test_join_args():
    assert(join_args(["a","b","c\nd","e"]) == 'a b c\nd e')
    assert(join_args(["a","b","c\nd","e\nf"]) == 'a b c\nd e\nf')
    assert(join_args(["a","b","c\nd","e","\nf"]) == 'a b c\nd e \nf')
    assert(join_args(["a","b","c\nd","e","\nf\n"]) == 'a b c\nd e \nf\n')
    assert(join_args(["a","b","c\n","d","e","\nf\n"]) == 'a b c\n d e \nf\n')



# Generated at 2022-06-23 05:02:24.525935
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo", check_raw = False) == {}
    assert parse_kv("foo=bar baz=quux", check_raw = False) == dict(foo='bar', baz='quux')
    assert parse_kv("foo='bar baz' quux=blurp", check_raw = False) == dict(foo='bar baz', quux='blurp')
    assert parse_kv("foo=\"bar baz\" quux=blurp", check_raw = False) == dict(foo='bar baz', quux='blurp')
    assert parse_kv("""foo="bar \\"baz\\"" quux=blurp""", check_raw = False) == dict(foo='bar "baz"', quux='blurp')

# Generated at 2022-06-23 05:02:37.495881
# Unit test for function split_args
def test_split_args():
    assert(join_args(split_args('foo')) == 'foo')
    assert(join_args(split_args('foo bar bam')) == 'foo bar bam')
    assert(join_args(split_args('foo "bar" bam')) == 'foo "bar" bam')

    # if we add a newline we shouldn't lose it
    assert(join_args(split_args('foo\nbar')) == 'foo\nbar')

    # extra whitespace shouldn't matter
    assert(join_args(split_args('foo  bar')) == 'foo  bar')
    assert(join_args(split_args('foo\n\nbar')) == 'foo\n\nbar')

# Generated at 2022-06-23 05:02:41.461433
# Unit test for function join_args
def test_join_args():
    assert(join_args(['a', 'b', 'c']) == 'a b c')
    assert(join_args(['a', '\nb', 'c']) == 'a\nb c')
    assert(join_args(['a', '\n', 'b', 'c', '\n']) == 'a\n b c\n')



# Generated at 2022-06-23 05:02:43.142756
# Unit test for function join_args
def test_join_args():
    assert join_args(["asdf", "asdf\n", "asdf"]) == "asdf asdf\nasdf"



# Generated at 2022-06-23 05:02:47.490595
# Unit test for function parse_kv
def test_parse_kv():
    from nose.tools import assert_equals

    assert_equals({'foo': 'bar'}, parse_kv('foo=bar'))
    assert_equals({'foo': '\'bar\''}, parse_kv('foo=\'bar\''))



# Generated at 2022-06-23 05:02:51.692178
# Unit test for function join_args
def test_join_args():
    actual = join_args(['echo', '"a b c"', '', 'echo', '"a b c"'])
    expected = 'echo "a b c"\necho "a b c"'
    assert actual == expected



# Generated at 2022-06-23 05:02:55.647832
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['a']) == 'a'
    assert join_args(['  a b ']) == '  a b '
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\nb']) == 'a\nb'



# Generated at 2022-06-23 05:03:03.088531
# Unit test for function join_args
def test_join_args():
    def assert_join_args(input, expected):
        assert expected == join_args(input)

    assert_join_args(
        ['echo', '123'],
        'echo 123'
    )
    assert_join_args(
        ['1\\', '2\\', '3'],
        '1\\ 2\\ 3'
    )
    assert_join_args(
        ['1\\\n', '2\\\n', '3'],
        '1\\\n2\\\n3'
    )



# Generated at 2022-06-23 05:03:18.227827
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']

    assert split_args('foo bar "baz qux') == ['foo', 'bar', '"baz', 'qux']
    assert split_args('foo bar "baz qux"') == ['foo', 'bar', '"baz qux"']

    assert split_args('foo bar \'baz qux') == ['foo', 'bar', '\'baz', 'qux']
    assert split_args('foo bar \'baz qux\'') == ['foo', 'bar', '\'baz qux\'']

    assert split_args('foo bar "baz\'qux"') == ['foo', 'bar', '"baz\'qux"']

# Generated at 2022-06-23 05:03:29.353534
# Unit test for function parse_kv
def test_parse_kv():
    options1 = parse_kv('key1=value1')
    options2 = parse_kv('key1=value1 key2=value2 key3=value3')
    options3 = parse_kv('key1=value1;key2=value2;key3=value3', check_raw=True)
    options4 = parse_kv('key1=value1 key2=value2 key3=value3', check_raw=True)
    assert options4['_raw_params'] == 'key1=value1 key2=value2 key3=value3'
    assert isinstance(options1, dict)
    assert isinstance(options2, dict)
    assert isinstance(options3, dict)
    assert isinstance(options4, dict)
    assert options1 == {u'key1': u'value1'}


# Generated at 2022-06-23 05:03:36.531292
# Unit test for function join_args
def test_join_args():
    assert(join_args(['hello\n', 'world\n']) == 'hello\nworld\n')
    assert(join_args(['hello', 'world\n']) == 'hello world\n')
    assert(join_args(['hello world\n']) == 'hello world\n')
    assert(join_args(['hello\n', 'world']) == 'hello\nworld')



# Generated at 2022-06-23 05:03:47.752713
# Unit test for function parse_kv
def test_parse_kv():
    vargs = [
        "a=1,b=2,c=3",
        "a=1 b=2 c=3",
        "a=1, b=2, c=3",
        "a=1,b=2 b=3,c=4",
    ]
    for a in vargs:
        d = parse_kv(a)
        print("%s\n%s" % (a, d))

    # Free form param detection

# Generated at 2022-06-23 05:03:58.828838
# Unit test for function split_args
def test_split_args():
    '''
    assert that the split_args function properly splits args based on spaces,
    but does not split on spaces inside of jinja2 blocks or quotes
    '''

# Generated at 2022-06-23 05:04:03.006907
# Unit test for function join_args
def test_join_args():
    assert join_args(["a"]) == "a"
    # This next test is complicated and ugly, but is the closest we can
    # get to matching exactly how the shell tokenizes.
    assert join_args([u'echo', u'"\n', u'a', u'"\n']) == 'echo "\n a "\n'



# Generated at 2022-06-23 05:04:13.118760
# Unit test for function join_args
def test_join_args():
    '''Test for function join_args
    '''
    assert join_args(['foo']) == 'foo'
    assert join_args(['foo bar']) == 'foo bar'
    assert join_args(['foo\n']) == 'foo\n'
    assert join_args(['foo bar\n']) == 'foo bar\n'
    assert join_args(['"foo"', 'bar']) == '"foo" bar'
    assert join_args(['"foo\nbar"']) == '"foo\nbar"'
    assert join_args(['"foo\nbar"', 'baz']) == '"foo\nbar" baz'
    assert join_args(['foo', '"bar\nbaz"']) == 'foo "bar\nbaz"'

# Generated at 2022-06-23 05:04:18.618506
# Unit test for function split_args
def test_split_args():
    assert split_args("{{foo}} bar") == ['{{foo}}', 'bar']
    assert split_args("{%foo%} bar") == ['{%foo%}', 'bar']
    assert split_args("{#foo#} bar") == ['{#foo#}', 'bar']
    assert split_args("{{foo}}{{bar}}") == ['{{foo}}', '{{bar}}']
    assert split_args("{%foo%}{%bar%}") == ['{%foo%}', '{%bar%}']
    assert split_args("{#foo#}{#bar#}") == ['{#foo#}', '{#bar#}']
    assert split_args("{{foo}}\n{{bar}}") == ['{{foo}}', '{{bar}}']

# Generated at 2022-06-23 05:04:29.737838
# Unit test for function parse_kv

# Generated at 2022-06-23 05:04:40.326390
# Unit test for function split_args
def test_split_args():
    arguments = {
        "ls foo": ['ls', 'foo'],
        "ls {{ item }}": ['ls', '{{', 'item', '}}'],
        "{{ item }}": ['{{', 'item', '}}'],
        "{{ item }} {{ foo }}": ['{{', 'item', '}}', '{{', 'foo', '}}'],
        "{{ item }}\n{{ foo }}": ['{{', 'item', '}}', '{{', 'foo', '}}'],
        "{{ item }}\\ {{ foo }}": ['{{ item }} {{ foo }}'],
    }
    for input, expected in arguments.items():
        result = split_args(input)
        assert result == expected, "input '%s' expected '%s' but got '%s'" % (input, expected, result)


# Generated at 2022-06-23 05:04:45.645066
# Unit test for function parse_kv
def test_parse_kv():
    # Simple test to make sure we parse a line with an equal char
    assert parse_kv("foo=bar") == {
            "foo": "bar"
            }
    # Test a line with an escaped equal char
    assert parse_kv("foo\=bar") == {
            "foo\=bar": None
            }
    # Simple test to make sure we parse a line without an equal char
    assert parse_kv("foobar") == {
            "foobar": None
            }



# Generated at 2022-06-23 05:04:48.067133
# Unit test for function join_args
def test_join_args():
    if join_args(['a', 'b']) != 'a b':
        raise Exception('test_join_args failed')



# Generated at 2022-06-23 05:04:58.798289
# Unit test for function join_args
def test_join_args():
    # These are the strings used as input for split_args,
    # and the output of join_args should result in the
    # original input string.
    join_args_strings = [
        "", " ", "a", "a b", "a b c", "a 'b c'", "a \"b c\"",
        "a 'b\"c'", "a \"b'c\"", "a 'b\"'\"c'", "a \"b\"\"'c\"",
        "a b\nc\nd", "a b\n  c\nd",
    ]
    for s in join_args_strings:
        assert(s == join_args(split_args(s)))
    # These are different strings that should still
    # match the result of join_args(split_args(.)) since
    # the spaces inside the

# Generated at 2022-06-23 05:05:07.433141
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('a=1,b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a=1,b=2,c') == {'a': '1', 'b': '2', '_raw_params': 'c'}
    assert parse_kv('a=1,b=2 c') == {'a': '1', 'b': '2', '_raw_params': 'c'}
    assert parse_kv('a=1,b=2\nc') == {'a': '1', 'b': '2', '_raw_params': 'c'}

# Generated at 2022-06-23 05:05:12.383167
# Unit test for function join_args
def test_join_args():
    s = ['#!/usr/bin/python', 'print(1)', 'print(2)']
    result = join_args(s)
    print(result)
    assert(result == '#!/usr/bin/python\nprint(1)\nprint(2)')


# Generated at 2022-06-23 05:05:16.190653
# Unit test for function join_args
def test_join_args():
    inputs = ['a', '\nb', ' c', '\n d']
    assert join_args(inputs) == 'a\nb c\n d'
    inputs = ['a', 'b', 'c']
    assert join_args(inputs) == 'a b c'



# Generated at 2022-06-23 05:05:24.800714
# Unit test for function split_args

# Generated at 2022-06-23 05:05:31.758260
# Unit test for function split_args
def test_split_args():
    test = "a=b c=\"foo bar\""
    result = split_args(test)
    assert result == ['a=b', 'c="foo bar"']

    test = "a=b c=\"foo bar\""
    result = split_args(test)
    assert result == ['a=b', 'c="foo bar"']

    test = "a=b 'c=\"foo bar\"'"
    result = split_args(test)
    assert result == ['a=b', 'c="foo bar"']

    test = "a=b c=\"foo\\\"bar\""
    result = split_args(test)
    assert result == ['a=b', 'c="foo\\"bar"']

    test = "a=b c='foo\\'bar'"
    result = split_args(test)

# Generated at 2022-06-23 05:05:40.286657
# Unit test for function join_args
def test_join_args():
    assert join_args(['ls', '-l', '-a']) == 'ls -l -a'
    assert join_args(['ls', '-l', '-a', '\n']) == 'ls -l -a\n'
    assert join_args(['ls', '-l', '-a', '\n', '\n']) == 'ls -l -a\n\n'
    assert join_args(['ls', '-l', '-a', '\n', '\n', 'rm']) == 'ls -l -a\n\nrm'



# Generated at 2022-06-23 05:05:47.189180
# Unit test for function parse_kv
def test_parse_kv():
    test = "\"echo -e 'one\ntwo\nthree'\""
    actual = parse_kv("creates='/tmp/foobar'" + " " + test + " " + "warn=no")
    expected = {
        "creates": "/tmp/foobar",
        "_raw_params": "\"echo -e 'one\ntwo\nthree'\"",
        "warn": "no",
    }
    assert actual == expected



# Generated at 2022-06-23 05:05:59.273706
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d e="1 2"') == {'a': 'b', 'c': 'd', 'e': '1 2'}
    assert parse_kv('a=b c=d e="1 2"', check_raw=True) == {'a': 'b', 'c': 'd', 'e': '1 2'}

    assert parse_kv('/opt/foo/bar.tgz cwd=/tmp/x', check_raw=True) == {'cwd': '/tmp/x', '_raw_params': '/opt/foo/bar.tgz'}

# Generated at 2022-06-23 05:06:06.464685
# Unit test for function parse_kv

# Generated at 2022-06-23 05:06:14.524915
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo']) == 'echo'
    assert join_args(['echo "a b c d e f"']) == 'echo "a b c d e f"'
    assert join_args(['echo "a b','c d e f"']) == 'echo "a b c d e f"'
    assert join_args(['echo "a b"','c d e f']) == 'echo "a b" c d e f'
    assert join_args(['python -c "print "a b c""']) == 'python -c "print "a b c""'



# Generated at 2022-06-23 05:06:19.775395
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.compat.tests.mock import patch
    from ansible.module_utils import basic

    with patch.object(basic, '_ANSIBLE_ARGS') as mock_basic:
        mock_basic.ANSIBLE_MODULE_ARGS = dict(one=1, two=2)
        options = parse_kv('one=1 two=2')
        assert options == dict(one=1, two=2)

# Split args adapted from Python 3.5.1's shlex module

# Generated at 2022-06-23 05:06:30.941061
# Unit test for function split_args

# Generated at 2022-06-23 05:06:39.031969
# Unit test for function parse_kv
def test_parse_kv():
    """
    Unit-test parse_kv dictionary.
    """
    args = "creates=rpmbuild chdir=/opt/project/name stdin=a executable=true stdin_add_newline=True warn=False removes=/tmp/vde2-net.ctl strip_empty_ends=True"
    options = parse_kv(args, check_raw=True)
    assert options == {'creates': 'rpmbuild', 'chdir': '/opt/project/name', 'stdin': 'a', 'executable': 'true', 'stdin_add_newline': 'True', 'warn': 'False', 'removes': '/tmp/vde2-net.ctl', 'strip_empty_ends': 'True'}



# Generated at 2022-06-23 05:06:48.997956
# Unit test for function parse_kv
def test_parse_kv():
    def testsub(key, value, test_raw_params, args, **kwargs):
        options = parse_kv(args, check_raw=test_raw_params)
        assert key in options
        assert value == options[key]
        if test_raw_params:
            assert '_raw_params' in options
            assert '='.join([key, value]) == options['_raw_params']
        else:
            assert '_raw_params' not in options

    testsub('foo', 'bar', True, 'foo=bar')
    testsub('foo', '"bar"', True, 'foo="bar"')
    testsub('foo', '"bar"', True, 'foo = "bar"')
    testsub('foo', 'bar', True, 'foo = bar')

# Generated at 2022-06-23 05:07:00.024656
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a']) == 'a'
    assert join_args(['a ', ' b']) == 'a  b'
    assert join_args(['a\n', 'b']) == 'a\nb'
    assert join_args(['a ', '\nb']) == 'a \nb'
    assert join_args(['a\n', ' b']) == 'a\n b'
    assert join_args(['a\n', '\nb']) == 'a\n\nb'
    assert join_args(['a\n b']) == 'a\n b'
    assert join_args(['a\n\nb']) == 'a\n\nb'


# Generated at 2022-06-23 05:07:11.449871
# Unit test for function split_args

# Generated at 2022-06-23 05:07:16.728579
# Unit test for function join_args
def test_join_args():
    assert join_args(['one', 'two', 'three']) == 'one two three'
    assert join_args(['one', 'two', 'three\n']) == 'one two three\n'
    assert join_args(['one', 'two\n', 'three\n']) == 'one two\n three\n'



# Generated at 2022-06-23 05:07:28.151948
# Unit test for function split_args
def test_split_args():

    # first up, simple cases that should work
    test1 = split_args('a=b c="foo bar"')
    assert test1 == ['a=b', 'c="foo bar"'], "failed basic kv split"

    test2 = split_args(u'a=b c="foo bar" d="a\nb" d=\\\ne')
    assert test2 == [u'a=b', u'c="foo bar"', u'd="a\nb"', u'd=\\\ne'], "failed with newline/escape"

    test3 = split_args('''a=b c="foo
        bar"''')
    assert test3 == ['a=b', 'c="foo\n        bar"'], "failed with multi-line"

    test4 = split_args(u"echo 'foo bar'")
   

# Generated at 2022-06-23 05:07:36.312751
# Unit test for function split_args

# Generated at 2022-06-23 05:07:47.614597
# Unit test for function parse_kv

# Generated at 2022-06-23 05:07:58.215193
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing function parse_kv')
    # A basic test
    args_str = "foo=bar baz=qux"
    args_dict = parse_kv(args_str, True)
    assert args_dict == {"foo": "bar", "baz": "qux"}

    # Test that it's not throwing exceptions
    args_str = "a 'b=c' d='foo bar' e=\"foo bar\" f='a=b c=d'"
    try:
        args_dict = parse_kv(args_str, True)
    except:
        # If an exception happened
        print("Exception found when parsing the string {0}\n".format(args_str))
        assert False

    # Test param expansion

# Generated at 2022-06-23 05:08:01.669282
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'Hello', 'World']) == 'echo Hello World'
    assert join_args(['echo Hello World']) == 'echo Hello World'
    assert join_args(['echo \\\nHello \\\nWorld']) == 'echo \nHello \nWorld'



# Generated at 2022-06-23 05:08:13.199702
# Unit test for function parse_kv
def test_parse_kv():
    test_parse_kv = [
        (None, {}),
        ("", {}),
        ("foo=bar", {'foo': 'bar'}),
        ("foo=bar", {'foo': 'bar'}),
        ("foo=bar baz=faz", {'foo': 'bar', 'baz': 'faz'}),
        ("baz='foo bar'", {'baz': 'foo bar'}),
        ("baz='foo\\'bar'", {'baz': "foo'bar"}),
        ("baz=foo 'foo bar' baz='foo bar'", {'baz': 'foo', '_raw_params': "'foo bar' baz='foo bar'"}),
        ("baz=${foo}", {'baz': '${foo}'}),
    ]

# Generated at 2022-06-23 05:08:23.253816
# Unit test for function split_args
def test_split_args():
    """
    test function split_args
    :return:
    """
    # test for empty string
    assert split_args('') == []
    # test for string with one word
    assert split_args('foo') == ['foo']
    # test for string with space
    assert split_args('foo bar') == ['foo', 'bar']
    # test for space inside quoted string
    assert split_args('foo bar=baz') == ['foo', 'bar=baz']
    # test for space inside quoted string
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    # test for space inside quoted string
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    # test for space inside quoted string

# Generated at 2022-06-23 05:08:31.913148
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('key1=val1 key2=val2') == {u'key2': u'val2', u'key1': u'val1'}
    assert parse_kv("key1='val1' key2=val2") == {u'key2': u'val2', u'key1': u'val1'}
    assert parse_kv("key1='val1' key2='val2'") == {u'key2': u'val2', u'key1': u"val1"}
    assert parse_kv("key1=val1 key2='val2'") == {u'key2': u'val2', u'key1': u"val1"}

# Generated at 2022-06-23 05:08:42.340794
# Unit test for function parse_kv

# Generated at 2022-06-23 05:08:51.132848
# Unit test for function join_args
def test_join_args():
    def test(tc):
        input = tc[0]
        expect = tc[1]
        result = join_args(input)
        assert result == expect

    test([['a', 'b', 'c'], 'a b c'])
    test([['a\n', 'b', 'c'], 'a\n b c'])
    test([['a', 'b\n', 'c'], 'a b\n c'])
    test([['a\n', 'b\n', 'c'], 'a\n b\n c'])
    test([['a', 'b\n', 'c\n'], 'a b\n c\n'])
    test([['a\n', 'b', 'c\n'], 'a\n b c\n'])

# Generated at 2022-06-23 05:09:01.335017
# Unit test for function split_args
def test_split_args():
    assert split_args("{{foo}}") == [u'{{foo}}']
    assert split_args("{{foo}} 'bar'") == [u'{{foo}}', u"'bar'"]
    assert split_args("{{foo}} \\'bar\\'") == [u'{{foo}}', u"\\'bar\\'"]
    assert split_args("window={{foo}}") == [u'window={{foo}}']
    assert split_args("window={{foo}} bar") == [u'window={{foo}}', u'bar']
    assert split_args("window={{foo}} \\'bar\\'") == [u'window={{foo}}', u"\\'bar\\'"]

# Generated at 2022-06-23 05:09:09.028317
# Unit test for function split_args

# Generated at 2022-06-23 05:09:20.564191
# Unit test for function split_args
def test_split_args():
    args = '''{{ ('x', 'y', 'z')|sort|join(' ') }} -b a=b c=d'''
    assert split_args(args) == ["{{ ('x', 'y', 'z')|sort|join(' ') }}", '-b', 'a=b', 'c=d']
    args = '''{{ ('x', 'y', 'z')|join(' ') }} -b a=b c=d'''
    assert split_args(args) == ["{{ ('x', 'y', 'z')|join(' ') }}", '-b', 'a=b', 'c=d']
    args = '''{{"x y"}} -b a=b c=d'''

# Generated at 2022-06-23 05:09:31.625620
# Unit test for function split_args
def test_split_args():
    assert(split_args("foo bar baz=quux") == ['foo', 'bar', 'baz=quux'])
    assert(split_args("foo bar\nbaz=quux") == ['foo', 'bar\nbaz=quux'])
    assert(split_args("foo bar\n baz=quux") == ['foo', 'bar\n', 'baz=quux'])
    assert(split_args("foo bar\\\n baz=quux") == ['foo', 'bar\\', 'baz=quux'])
    assert(split_args("foo bar\\\n baz=quux\\\n") == ['foo', 'bar\\\n baz=quux\\'])


# Generated at 2022-06-23 05:09:41.604708
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv('foo=bar')
    assert options[u'foo'] == u'bar'
    options = parse_kv('foo=bar baz=foo')
    assert options[u'baz'] == u'foo'
    assert options[u'foo'] == u'bar'
    options = parse_kv('"foo"="bar baz"')
    assert options[u'foo'] == u'bar baz'
    options = parse_kv('"foo"=\'bar baz\'')
    assert options[u'foo'] == u'bar baz'
    options = parse_kv('foo=bar creates=/tmp/foo')
    assert options[u'foo'] == u'bar'
    assert options[u'creates'] == u'/tmp/foo'
    options = parse_kv

# Generated at 2022-06-23 05:09:52.049357
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("key=value") == { "key": "value" }
    assert parse_kv("key=value extra") == { "key": "value", "_raw_params": "extra"}
    assert parse_kv("key=value extra= foo bar") == { "key": "value", "extra": "foo bar" }
    assert parse_kv("key=value extra='foo bar'") == { "key": "value", "extra": "foo bar" }
    assert parse_kv("key=value extra=\"foo bar\"") == { "key": "value", "extra": "foo bar" }
    assert parse_kv("key=value extra='foo bar") == { "key": "value", "_raw_params": "extra='foo bar" }

# Generated at 2022-06-23 05:09:56.046101
# Unit test for function join_args
def test_join_args():
    test_list = ['echo', 'hello', 'world\nfoo\n', 'bar', 'baz']
    test_result = join_args(test_list)
    assert test_result == "echo hello world\nfoo\n bar baz"



# Generated at 2022-06-23 05:10:05.281524
# Unit test for function split_args
def test_split_args():
    assert u'a b' == join_args(split_args(u'a b'))
    assert u'a "b c"' == join_args(split_args(u'a "b c"'))
    assert u"a 'b c'" == join_args(split_args(u"a 'b c'"))
    assert u'a "b c"' == join_args(split_args(u'a \\"b c\\"'))
    assert u'a "b c"' == join_args(split_args(u'a "b c"'))
    assert u'a "b c"' == join_args(split_args(u'a \\"b c"'))
    assert u'a "b c"' == join_args(split_args(u'a "b c\\"'))

# Generated at 2022-06-23 05:10:16.141970
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a  b c'
    assert ''.join(['a', '"b"', 'c']) == 'a"b"c'
    assert join_args(['a', "\"b\"", 'c']) == 'a "b" c'
    assert join_args(['a', 'b', 'c']) == ' '.join(['a', 'b', 'c'])
    assert join_args(['a', '\nb', 'c']) == ''.join(['a', '\nb', 'c'])
    assert join_args(['a', ' b', 'c']) == ''.join(['a', ' b', 'c'])

# Generated at 2022-06-23 05:10:26.521022
# Unit test for function parse_kv
def test_parse_kv():
    invalid_list = [
        "=value",
        "key= ",
        "key = ",
        " key=value",
        "key=value ",
        " key = value ",
        " = ",
        " = ",
        "= ",
        "=",
        "key = value = value2",
        "key = value =value2",
        "key = value= value2",
        "key = value=value2",
        "key = value==value2",
        "key = value== value2",
        "key = value==value2",
        "key = value = value2=value3",
        "key = value=value2 = value3",
        "key = value==value2=value3",
        "key = value=value2==value3",
    ]

# Generated at 2022-06-23 05:10:38.570717
# Unit test for function parse_kv
def test_parse_kv():
    args = 'a=3 d="a long string" c'
    assert parse_kv(args) == {'a': '3', 'd': 'a long string', 'c': '', '_raw_params': 'c'}



# Generated at 2022-06-23 05:10:48.188590
# Unit test for function parse_kv
def test_parse_kv():

    # Test the function parse_kv
    ###########
    # type == 1:
    ###########
    # Expected test result:
    #   parameters['DEBUG'] = 'true'
    #   parameters['VERSION'] = '11.5.5'
    #   parameters['_raw_params'] = '-n 3 -x'
    parameters = parse_kv('''DEBUG=true VERSION=11.5.5 -n 3 -x''')
    assert parameters['DEBUG'] == 'true'
    assert parameters['VERSION'] == '11.5.5'
    assert parameters['_raw_params'] == '-n 3 -x'

    ###########
    # type == 2:
    ###########
    # Expected test result:
    #   parameters['_raw_params'] = '-n 3 -x -d