

# Generated at 2022-06-23 05:00:58.818949
# Unit test for function parse_kv
def test_parse_kv():
    # Test with some simple arguments
    s = "foo=bar foo2=bar2"
    p = parse_kv(s)
    assert p == {
        "foo": "bar",
        "foo2": "bar2"
    }

    # Test with quoted values

# Generated at 2022-06-23 05:01:08.021393
# Unit test for function parse_kv

# Generated at 2022-06-23 05:01:13.395971
# Unit test for function parse_kv
def test_parse_kv():
    test = '''
    foo = bar qux="a b" c=d qux='a b' e="a=b"
    '''
    parsed = parse_kv(test)
    assert parsed['foo'] == 'bar'
    assert parsed['qux'] == 'a b'
    assert parsed['c'] == 'd'
    assert parsed['e'] == 'a=b'
    assert parsed['_raw_params'] == ""



# Generated at 2022-06-23 05:01:23.033549
# Unit test for function split_args

# Generated at 2022-06-23 05:01:25.630868
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', '\nb']) == 'a\nb'



# Generated at 2022-06-23 05:01:37.005756
# Unit test for function split_args

# Generated at 2022-06-23 05:01:45.838122
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo bar baz']) == 'foo bar baz'
    assert join_args(['foo\nbar\nbaz']) == 'foo\nbar\nbaz'
    assert join_args(['foo\nbar', 'baz']) == 'foo\nbar baz'
    assert join_args(['foo', 'bar\nbaz']) == 'foo bar\nbaz'
    assert join_args(['foo', 'bar', 'baz', 'wibble']) == 'foo bar baz wibble'
    assert join_args(['foo', 'bar', 'baz', 'wibble\nwobble']) == 'foo bar baz wibble\nwobble'
    assert join_

# Generated at 2022-06-23 05:01:55.185921
# Unit test for function join_args
def test_join_args():
    '''test join_args'''
    assert join_args(['a']) == 'a'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\n', 'b']) == 'a\nb'
    assert join_args(['a', 'b\nc']) == 'a b\nc'
    assert join_args(['a', 'b\nc\n']) == 'a b\nc\n'
    assert join_args(['a b', 'b\nc\n']) == 'a b b\nc\n'
    # Verify spaces are stripped
    assert join_args(['a', 'b c']) == 'a b c'
    assert join_args(['a ', ' b']) == 'a  b'

# Generated at 2022-06-23 05:02:05.193728
# Unit test for function join_args
def test_join_args():
    assert join_args(['1','2','3','\n','4','5','6','\n']) == '1 2 3\n4 5 6\n'
    assert join_args(['1','2','3','\n','4','5','6']) == '1 2 3\n4 5 6'
    assert join_args(['1','2','3','4','5','6']) == '1 2 3 4 5 6'
# -- END unit test



# Generated at 2022-06-23 05:02:11.451024
# Unit test for function join_args
def test_join_args():
    # Simple test case
    s = ['echo', 'hello', 'world']
    assert join_args(s) == 'echo hello world'
    # Test case with \n
    s = ['echo', 'hello', 'world\n echo', 'hello', 'again']
    assert join_args(s) == 'echo hello world\n echo hello again'
    # Test case with ''
    s = ['']
    assert join_args(s) == ''



# Generated at 2022-06-23 05:02:23.120472
# Unit test for function parse_kv
def test_parse_kv():
    success = True

# Generated at 2022-06-23 05:02:32.562656
# Unit test for function join_args
def test_join_args():
    assert join_args(["first", "second", "third"]) == "first second third"
    assert join_args(["first", "second third", "fourth"]) == "first second third fourth"
    assert join_args(["first", "second", "third", "fourth line with spaces", "fifth"]) == "first second third fourth line with spaces fifth"
    assert join_args(["first", "second line with spaces", "third", "fourth line with spaces", "fifth"]) == "first second line with spaces third fourth line with spaces fifth"
    assert join_args(["first\nsecond line with spaces", "third", "fourth line with spaces", "fifth"]) == "first\nsecond line with spaces third fourth line with spaces fifth"

# Generated at 2022-06-23 05:02:42.677073
# Unit test for function parse_kv
def test_parse_kv():
  # Testing a single variable
  args = "single=variable"
  options = parse_kv(args)
  assert len(options) == 1
  assert options['single'] == 'variable'

  # Testing multiple variables
  args = "first=variable second=variable"
  options = parse_kv(args)
  assert len(options) == 2
  assert options['first'] == 'variable'
  assert options['second'] == 'variable'

  # Testing multiple variables
  args = "first=variable second=variable third=third is a special word"
  options = parse_kv(args)
  assert len(options) == 3
  assert options['first'] == 'variable'
  assert options['second'] == 'variable'
  assert options['third'] == 'third is a special word'

  # Testing multiple variables with spaces
  args

# Generated at 2022-06-23 05:02:53.337045
# Unit test for function join_args
def test_join_args():
    assert join_args(['a=b', 'c=d']) == 'a=b c=d'
    assert join_args(['a=b', 'c=d'], 0) == 'a=b c=d'
    assert join_args(['a=b', 'c=d'], 1) == 'a=b c=d'

    assert join_args(['a=b\n', 'c=d']) == 'a=b\n c=d'
    assert join_args(['a=b\n', 'c=d'], 0) == 'a=b\n c=d'
    assert join_args(['a=b\n', 'c=d'], 1) == 'a=b\n c=d'


# Generated at 2022-06-23 05:03:03.129010
# Unit test for function join_args
def test_join_args():
    sample = ['foo', 'bar ', '  baz', '\n', '\n', '\n', 'qux',
              'quux', '\n', 'quuz', 'norf', 'thud']
    assert 'foo bar   baz\n\n\nqux quux\nquuz norf thud' == join_args(sample)
    sample = ['foo', 'bar']
    assert 'foo bar' == join_args(sample)
    sample = ['foo\\', 'bar']
    assert 'foobar' == join_args(sample)


# Generated at 2022-06-23 05:03:18.275792
# Unit test for function split_args
def test_split_args():
    print("Testing split_args")

# Generated at 2022-06-23 05:03:29.400032
# Unit test for function split_args
def test_split_args():
    # Note: Basically, split_args should do inverse job of join_args.
    quote = '"'
    backslash = '\\'

    def assert_split(input, expected):
        # Note: We expect `input` be a string of bytes, not unicode string.
        result = split_args(input)
        print(u"result: {0}".format(result))
        assert result == expected, "Assertion failed: '{0}', expected: '{1}'".format(result, expected)

    assert_split('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    assert_split('a=b c="foo bar\\""', ['a=b', 'c="foo bar\\""'])

# Generated at 2022-06-23 05:03:33.824334
# Unit test for function join_args
def test_join_args():
    assert join_args(
        ['  # hello', 'world', '\n', '  # this is a test']) == \
        '  # hello\nworld\n\n  # this is a test'



# Generated at 2022-06-23 05:03:41.770495
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['foo']) == 'foo'
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo\n', 'bar']) == 'foo\nbar'
    assert join_args(['foo', 'bar\n']) == 'foo bar\n'
    assert join_args(['foo\n', 'bar\n']) == 'foo\nbar\n'



# Generated at 2022-06-23 05:03:47.954505
# Unit test for function join_args
def test_join_args():
    '''
    Join the original cmd based on manipulations by split_args().
    This retains the original newlines and whitespaces.
    '''
    assert join_args(['echo', '"hello world"']) == 'echo "hello world"'
    assert join_args(['echo', '"hello \n world"']) == 'echo "hello \n world"'
    assert join_args(['echo', '"hello \n world"', 'sleep 1']) == 'echo "hello \n world"\nsleep 1'



# Generated at 2022-06-23 05:03:57.401181
# Unit test for function split_args

# Generated at 2022-06-23 05:04:07.765146
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('foo=bar') == dict(foo=u'bar')
    assert parse_kv('foo="bar"') == dict(foo=u'bar')
    assert parse_kv('foo="bar baz"') == dict(foo=u'bar baz')
    assert parse_kv('foo="bar baz" spam=ham') == dict(foo=u'bar baz', spam=u'ham')
    assert parse_kv('foo="bar baz" spam=ham _raw_params=eggs') == dict(foo=u'bar baz', spam=u'ham', _raw_params=u'eggs')

# Generated at 2022-06-23 05:04:18.365661
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b=c') == {u'a': u'b=c'}
    assert parse_kv('a="b=c"') == {u'a': u'b=c'}
    assert parse_kv('a=b c="d e" f') == {u'a': u'b c', u'f': u'', u'c': u'd e'}
    assert parse_kv('a=b c="d e" f') == {u'a': u'b c', u'f': u'', u'c': u'd e'}

# Generated at 2022-06-23 05:04:29.737849
# Unit test for function parse_kv

# Generated at 2022-06-23 05:04:32.153583
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo foo', '\necho bar']) == 'echo foo\necho bar'



# Generated at 2022-06-23 05:04:41.892471
# Unit test for function parse_kv
def test_parse_kv():

    from test import test_runner

# Generated at 2022-06-23 05:04:44.882989
# Unit test for function join_args
def test_join_args():
    s = split_args("foo\n bar\n baz")
    assert(join_args(s) == "foo\n bar\n baz")



# Generated at 2022-06-23 05:04:56.120409
# Unit test for function split_args

# Generated at 2022-06-23 05:05:07.406164
# Unit test for function join_args

# Generated at 2022-06-23 05:05:13.594262
# Unit test for function join_args
def test_join_args():
    s = ['echo', '-n', '\n', 'Hello,',
         '\n', 'world!\n', 'I am your', '\n', '\n',
         '  friend.']
    result = join_args(s)
    assert result == 'echo -n\nHello,\nworld!\nI am your\n\n  friend.'



# Generated at 2022-06-23 05:05:22.740943
# Unit test for function split_args
def test_split_args():
    # Test various simple argument lists
    assert split_args("") == []
    assert split_args("foo") == ["foo"]
    assert split_args("foo bar") == ["foo", "bar"]
    assert split_args("foo bar baz") == ["foo", "bar", "baz"]

    # Test various lists with quotes
    assert split_args("foo 'bar'") == ["foo", "'bar'"]
    assert split_args("foo 'bar baz'") == ["foo", "'bar baz'"]
    assert split_args("foo \"bar\"") == ["foo", "\"bar\""]
    assert split_args("foo \"bar baz\"") == ["foo", "\"bar baz\""]
    assert split_args("foo 'bar\"") == ["foo", "'bar\""]

# Generated at 2022-06-23 05:05:32.021331
# Unit test for function parse_kv
def test_parse_kv():
    assert {'a': 'b'} == parse_kv('a=b')
    assert {'a': 'b', 'c': 'd'} == parse_kv('a=b c=d')
    assert {'a': 'b', 'c': 'd'} == parse_kv('a="b" c=d')
    assert {'a': 'b', 'c': 'd'} == parse_kv('a=b c="d"')
    assert {'a': 'b', 'c': 'd'} == parse_kv('a="b" c="d"')

    # Test that escaped quotes are stripped
    assert {'a': 'b'} == parse_kv('a="b"')

# Generated at 2022-06-23 05:05:43.013514
# Unit test for function parse_kv
def test_parse_kv():
    data = "foo=bar"
    assert parse_kv(data)['foo'] == "bar"

    data = "this=that  foo=bar"
    assert parse_kv(data)['foo'] == "bar"

    data = "foo='bar with spaces'"
    assert parse_kv(data)['foo'] == "bar with spaces"

    data = u"foo='bar with spaces' this='that with spaces'"
    assert parse_kv(data)['this'] == "that with spaces"

    # This should fail
    #data = "foo='bar with spaces"
    #assert parse_kv(data)['foo'] == "bar with spaces"

    # Test that non-ascii characters are preserved
    data = u"foo='bar with spaces' π='π'"

# Generated at 2022-06-23 05:05:52.987072
# Unit test for function join_args
def test_join_args():
    # test should pass
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a b c']) == 'a b c'
    assert join_args([]) == ''
    assert join_args(['a\n', 'b\n', 'c']) == 'a\n b\n c'
    assert join_args(['a\n', 'b c']) == 'a\n b c'
    assert join_args(['a', 'b\nc']) == 'a b\nc'
    # test should fail
    assert join_args(['a', 'b', 'c']) != 'a b  c'
    assert join_args(['a', 'b', 'c']) != 'a bc'

# Generated at 2022-06-23 05:06:02.815411
# Unit test for function split_args
def test_split_args():

    assert join_args(split_args("a=foo")) == "a=foo"
    assert join_args(split_args("a=foo b=bar c=baz")) == "a=foo b=bar c=baz"
    assert join_args(split_args("arg1 arg2 arg3")) == "arg1 arg2 arg3"
    assert join_args(split_args("arg1 arg2\narg3")) == "arg1 arg2\narg3"
    assert join_args(split_args("arg1 \narg2\narg3")) == "arg1 \narg2\narg3"
    assert join_args(split_args("arg1 arg2\n arg3")) == "arg1 arg2\n arg3"

# Generated at 2022-06-23 05:06:12.683416
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'hello', 'world']) == 'echo hello world'
    assert join_args(['echo', '\nhello', '\nworld']) == 'echo\nhello\nworld'
    assert join_args(['echo', '\nhello world']) == 'echo\nhello world'
    assert join_args(['echo', 'hello\nworld']) == 'echo hello\nworld'
    assert join_args(['echo', 'hello\nworld']) == 'echo hello\nworld'
    assert join_args(['echo', 'hello\nworld']) == 'echo hello\nworld'



# Generated at 2022-06-23 05:06:23.087842
# Unit test for function parse_kv
def test_parse_kv():
    test = 'foo=bar baz=quux "this=should be one arg" "this = should too"'
    print("PARSE_KV_TEST_1: \t" + str(parse_kv(test)))

    test = "foo='bar baz'"
    print("PARSE_KV_TEST_2: \t" + str(parse_kv(test)))

    test = "foo=\"bar 'baz' quux\""
    print("PARSE_KV_TEST_3: \t" + str(parse_kv(test)))

    test = "foo=\"bar 'baz' \\\"quux\\\"\""
    print("PARSE_KV_TEST_4: \t" + str(parse_kv(test)))


# Generated at 2022-06-23 05:06:27.216435
# Unit test for function parse_kv
def test_parse_kv():
    res = parse_kv('one=1 two=2 "three = 3"')

    print(res)
    assert(res == {"one" : "1" , "two" : "2" , "three = 3" : ""})


# Generated at 2022-06-23 05:06:37.141141
# Unit test for function split_args

# Generated at 2022-06-23 05:06:48.033600
# Unit test for function split_args
def test_split_args():
    #
    # Split args on whitespace, but intelligently reassembles
    # those that may have been split over a jinja2 block or quotes.
    #
    # Return True if tests pass
    # Return False if tests fail
    #
    test_string = '''
    one two
    three=four
    "five=six"
    seven="eight nine"
    '''
    test_result = ['one', 'two\n', 'three=four\n', '"five=six"\n', 'seven="eight nine"']
    if split_args(test_string) != test_result:
        return False

    test_string = '''
    eight="nine ten"
    eleven=\
    "twelve thirteen"
    '''


# Generated at 2022-06-23 05:06:59.233822
# Unit test for function split_args

# Generated at 2022-06-23 05:07:08.772812
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('"a"') == ['"a"']
    assert split_args('a b') == ['a', 'b']
    assert split_args('a "b c"') == ['a', '"b c"']
    assert split_args('"b c" d') == ['"b c"', 'd']
    assert split_args('"a" "b c"') == ['"a"', '"b c"']
    assert split_args('a "b c" d') == ['a', '"b c"', 'd']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-23 05:07:17.236336
# Unit test for function split_args
def test_split_args():
    # Split arguments excluding newlines
    args = 'a=b c="foo bar"'
    tokens = split_args(args)
    assert tokens == ['a=b', 'c="foo bar"']

    # Split arguments including newlines
    args = 'a=b\nc="foo bar"'
    tokens = split_args(args)
    assert tokens == ['a=b\n', 'c="foo bar"']

    # Split arguments with line continuation
    args = 'a=b\\\nc="foo bar"'
    tokens = split_args(args)
    assert tokens == ['a=b\\', 'c="foo bar"']

    # Split arguments including escaped newlines
    args = 'a=b\\n c="foo bar"'
    tokens = split_args(args)

# Generated at 2022-06-23 05:07:19.781887
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '1', '\n']) == 'echo 1\n'



# Generated at 2022-06-23 05:07:30.190540
# Unit test for function split_args
def test_split_args():
    '''
    test the split_args function with a variety of different behaviours
    '''

    assert split_args('1 2 3') == ['1', '2', '3']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b "c = d"') == ['a=b', '"c = d"']
    assert split_args('a=b "c=d"') == ['a=b', '"c=d"']
    assert split_args('a=b "foo bar"') == ['a=b', '"foo bar"']
    assert split_args('a=b "foo \"bar\""') == ['a=b', '"foo \"bar\""']

# Generated at 2022-06-23 05:07:31.898423
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == dict(a='b', c='d')



# Generated at 2022-06-23 05:07:36.360057
# Unit test for function join_args
def test_join_args():
    s = ['echo', '1', '2', '3\n', 'echo', '4', '5', '6']
    assert join_args(s) == 'echo 1 2 3\necho 4 5 6'
    s = ['echo', '1', '2', '3', '\n', 'echo', '4', '5', '6']
    assert join_args(s) == 'echo 1 2 3\necho 4 5 6'



# Generated at 2022-06-23 05:07:47.828829
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("a") == ["a"]
    assert split_args("foo 'a b' c") == ["foo", "'a b'", "c"]
    assert split_args("foo 'a b\\\\' c") == ["foo", "'a b\\\\'", "c"]
    assert split_args("foo 'a b'\\'' c") == ["foo", "'a b'\\''", "c"]
    assert split_args("foo='a b' c") == ["foo='a b'", "c"]
    assert split_args("foo='a b' 'c d'") == ["foo='a b'", "'c d'"]
    assert split_args("foo= b") == ['foo=', 'b']

# Generated at 2022-06-23 05:07:58.342181
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("one=1 two=2 \"three=3 four=4\"") == {"one": "1", "two": "2", "three=3 four=4": ""}
    assert parse_kv("one=1 two=2 \"three=3 four=4\"") == {"one": "1", "two": "2", "three=3 four=4": ""}
    assert parse_kv("one=1 two=2 \"three=3 four=4\"") == {"one": "1", "two": "2", "three=3 four=4": ""}
    assert parse_kv("one=1 two=2 \"three=3 four=4\"") == {"one": "1", "two": "2", "three=3 four=4": ""}

# Generated at 2022-06-23 05:08:08.763430
# Unit test for function split_args
def test_split_args():
    def _assert_split(unparsed, parsed):
        assert split_args(unparsed) == parsed

    # basic test
    _assert_split("foo bar baz", ['foo', 'bar', 'baz'])

    # comments
    _assert_split("foo {# comment #} bar baz", ['foo', 'bar', 'baz'])
    _assert_split("foo {# comment #} bar {# comment #} baz", ['foo', 'bar', 'baz'])
    _assert_split("foo {# comment #} bar {# comment #} baz {# comment #}", ['foo', 'bar', 'baz'])

    # empty args
    _assert_split("", [])

    # superfluous whitespace
    _assert_split("    ", [])

# Generated at 2022-06-23 05:08:14.621942
# Unit test for function join_args
def test_join_args():
    (s1, s2) = (['a', '"b', 'c"', 'd'], ['a', '"b', 'c"', 'd'])
    assert join_args(s1) == 'a "b c" d'
    assert join_args(s2) == 'a "b c" d'



# Generated at 2022-06-23 05:08:24.114404
# Unit test for function split_args
def test_split_args():
    '''
    This is the test case from the original description of the function.
    '''
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    # This is the same test case, but was removed from the original ticket.
    # It should be added back
    assert split_args('a=b c="foo bar" d=e') == ['a=b', 'c="foo bar"', 'd=e']
    '''
    This is the test case from ansible/ansible#25100.
    '''
    # https://github.com/ansible/ansible/issues/25100#issuecomment-265768796.

# Generated at 2022-06-23 05:08:32.197163
# Unit test for function join_args
def test_join_args():
    assert join_args(["ls", "-l", "-a", "-i", "-h", "-z", "-t", "--complex=arg", "--complex-2=\"complex arg\""]) == "ls -l -a -i -h -z -t --complex=arg --complex-2=\"complex arg\""
    assert join_args(["ls", "-l", "1", "-a", "\"quoted arg 1\"", "-i", "-h", "-z", "-t", "2", "--complex=arg", "--complex-2=\"complex arg\"", "3", "", "", "", ""]) == "ls -l 1 -a \"quoted arg 1\" -i -h -z -t 2 --complex=arg --complex-2=\"complex arg\" 3"

# Generated at 2022-06-23 05:08:43.184914
# Unit test for function parse_kv

# Generated at 2022-06-23 05:08:52.827101
# Unit test for function split_args
def test_split_args():
    assert split_args(u'') == [u'']
    assert split_args(u' ') == [u' ', u'']
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="foo') == [u'a=b', u'c="foo']
    assert split_args(u'a=b c="foo\nbar"') == [u'a=b', u'c="foo\nbar"']

# Generated at 2022-06-23 05:09:01.382301
# Unit test for function split_args

# Generated at 2022-06-23 05:09:09.027975
# Unit test for function join_args
def test_join_args():
    # When input is a list of strings, the result is a string containing
    # the original strings separated by spaces, with newlines preserved
    # and a space prepended to every line except the first
    assert join_args(['This is a string', 'It has', 'multiple lines']) \
        == 'This is a string It has multiple lines'
    assert join_args(['This is a string', 'It has', 'multiple lines', '\n']) \
        == 'This is a string It has multiple lines \n'
    assert join_args(['\n', 'This is a string', 'It has', 'multiple lines']) \
        == '\n This is a string It has multiple lines'

    # When input is a string, the result is identical

# Generated at 2022-06-23 05:09:13.992820
# Unit test for function join_args
def test_join_args():
    assert join_args(['a b', 'c d']) == 'a b c d'
    assert join_args(['a', 'b', '\nc', 'd']) == 'a b\nc d'



# Generated at 2022-06-23 05:09:24.756134
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('key=val') == {'key': 'val'}
    assert parse_kv('key="quoted val"') == {'key': '"quoted val"'}
    assert parse_kv('key="double"quotes"') == {'key': '"double"quotes"'}
    assert parse_kv('key="bar\'s"') == {'key': '"bar\'s"'}
    assert parse_kv('key=bar=baz') == {'key': 'bar=baz'}
    assert parse_kv('key=bar=baz=baxy') == {'key': 'bar=baz=baxy'}

# Generated at 2022-06-23 05:09:33.830641
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c\nd', 'e']) == 'a b c\nd e'
    assert join_args(['a', 'b', 'c d', 'e']) == 'a b c d e'
    assert join_args(['a', 'b', 'c  d', 'e']) == 'a b c  d e'
    assert join_args(['a', 'b', 'c', ' d', 'e']) == 'a b c  d e'
    assert join_args(['a', 'b', 'c', '\nd', 'e']) == 'a b c\nd e'


# Generated at 2022-06-23 05:09:43.464694
# Unit test for function parse_kv
def test_parse_kv():
    assert {} == parse_kv(None)
    assert {} == parse_kv('')
    assert {u'foo': u'bar'} == parse_kv('foo=bar')
    assert {u'foo': u'bar baz'} == parse_kv("foo='bar baz'")
    assert {u'foo': u"bar\\baz"} == parse_kv('foo=bar\\baz')
    assert {u'foo': u'bar'} == parse_kv(' foo = bar')
    assert {u'foo': u'bar'} == parse_kv('foo =bar')
    assert {u'foo': u'bar'} == parse_kv('foo= bar')

# Generated at 2022-06-23 05:09:52.199580
# Unit test for function join_args
def test_join_args():
    assert join_args(["foo"]) == "foo"
    assert join_args(["foo", "bar"]) == "foo bar"
    assert join_args(["foo", "bar", "baz"]) == "foo bar baz"
    assert join_args(["foo\nbar"]) == "foo\nbar"
    assert join_args(["foo", "\nbar"]) == "foo\nbar"
    assert join_args(["\nfoo"]) == "\nfoo"
    assert join_args(["\nfoo", "bar"]) == "\nfoo bar"
    assert join_args(["foo", "\nbar"]) == "foo\nbar"



# Generated at 2022-06-23 05:10:00.979272
# Unit test for function join_args
def test_join_args():
    assert join_args(['create', 'table', 'x', '(y int)']) == 'create table x (y int)'
    assert join_args(['create', 'table', 'x', '(y int)', ';', 'insert into x values (1);', 'select * from x;']) == \
        'create table x (y int) ; insert into x values (1); select * from x;'
    assert join_args(['create', 'table', 'x', '(y int)', ';', '\n', '--', 'insert into x values (1);']) == \
        "create table x (y int) ; \n -- insert into x values (1);"

# Generated at 2022-06-23 05:10:10.369251
# Unit test for function parse_kv

# Generated at 2022-06-23 05:10:22.225887
# Unit test for function parse_kv
def test_parse_kv():
    from sys_utils.ansible_utils import parse_kv
    from sys_utils.ansible_utils import join_args
    from sys_utils.ansible_utils import split_args
    import copy
    import json
    import collections


# Generated at 2022-06-23 05:10:32.219532
# Unit test for function split_args
def test_split_args():
    assert split_args("{{ansible_managed}}") == ["{{ansible_managed}}"]
    assert split_args("{% if ansible_managed %}...{% endif %}") == ["{%", "if", "ansible_managed", "%}...", "{%", "endif", "%}"]
    assert split_args("{# this is a comment #}") == ["{#", "this", "is", "a", "comment", "#}"]
    assert split_args("foo bar") == ["foo", "bar"]
    assert split_args("foo 'bar baz'") == ["foo", "'bar baz'"]
    assert split_args("foo \"bar baz\"") == ["foo", "\"bar baz\""]

# Generated at 2022-06-23 05:10:42.390426
# Unit test for function split_args

# Generated at 2022-06-23 05:10:53.327192
# Unit test for function split_args
def test_split_args():
    def _assert_split_args(myargs):
        myparams = split_args(myargs)
        new_myargs = join_args(myparams)
        assert myargs == new_myargs

    _assert_split_args("apt-get install -y apache2")
    _assert_split_args("apt-get install -y apache2 apache2-doc")
    _assert_split_args("apt-get install -y apache2 apache2-doc apache2-utils")
    _assert_split_args("apt-get install -y apache2\\")
    _assert_split_args("apt-get install -y apache2\\\napache2-doc")
    _assert_split_args("apt-get install -y apache2\\\napache2-doc\\\napache2-utils")