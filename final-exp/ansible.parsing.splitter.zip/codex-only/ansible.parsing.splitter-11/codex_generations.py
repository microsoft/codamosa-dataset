

# Generated at 2022-06-23 05:00:52.248229
# Unit test for function join_args
def test_join_args():
    assert join_args(['one', 'two']) == 'one two'
    assert join_args(['\n', 'one', '\n', 'two']) == '\none\n  two'
    assert join_args(['\n', 'one', '\n', '\n', 'two']) == '\none\n\n  two'



# Generated at 2022-06-23 05:01:03.245882
# Unit test for function split_args

# Generated at 2022-06-23 05:01:14.305911
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo="bar bar" baz=qux') == {u'foo': u'bar bar', u'baz': u'qux'}
    assert parse_kv('foo="bar\\"bar" baz=qux') == {u'foo': u'bar"bar', u'baz': u'qux'}
    assert parse_kv('foo="bar bar" baz="qux"') == {u'foo': u'bar bar', u'baz': u'qux'}

# Generated at 2022-06-23 05:01:23.753781
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv(u'foo="bar baz=qux"') == {'foo': 'bar baz=qux'}
    assert parse_kv(u"foo='bar baz=qux'") == {'foo': 'bar baz=qux'}
    assert parse_kv(u"foo='bar' baz='qux'") == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv(u"foo=bar baz='qux'") == {'foo': 'bar', 'baz': 'qux'}
   

# Generated at 2022-06-23 05:01:29.606315
# Unit test for function split_args
def test_split_args():
    split_args("foo") == ["foo"]
    split_args("'foo") == ["foo"]
    split_args("'foo'") == ["'foo'"]
    split_args("'foo bar'") == ["'foo bar'"]
    split_args("'foo bar' biz") == ["'foo bar'", "biz"]
    split_args("'foo bar' biz 'bang boom'") == ["'foo bar'", "biz", "'bang boom'"]
    split_args("'foo bar' biz 'bang boom'") == ["'foo bar'", "biz", "'bang boom'"]
    split_args("\"foo bar\" biz") == ["\"foo bar\"", "biz"]

# Generated at 2022-06-23 05:01:40.247741
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv('foo=bar key=value')
    assert options['foo'] == 'bar'
    assert options['key'] == 'value'

    options = parse_kv('foo="bar key"')
    assert options['foo'] == 'bar key'

    options = parse_kv('foo="bar key" key="value"')
    assert options['foo'] == 'bar key'
    assert options['key'] == 'value'

    options = parse_kv('''foo="bar key" key="value" ''')
    assert options['foo'] == 'bar key'
    assert options['key'] == 'value'

    options = parse_kv('foo="bar key" key="value" ')
    assert options['foo'] == 'bar key'
    assert options['key'] == 'value'

    # This

# Generated at 2022-06-23 05:01:42.637322
# Unit test for function join_args
def test_join_args():
    if join_args(['a', 'b', 'c']) != 'a b c':
        raise AssertionError('join_args(["a", "b", "c"]) != "a b c"')



# Generated at 2022-06-23 05:01:53.457185
# Unit test for function join_args
def test_join_args():
    assert join_args(['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o']) == 'a b c d e f g h i j k l m n o'
    assert join_args(['a b c\td', 'e\nf', 'g\nh\ni\n', 'j\tk l m n o']) == 'a b c\td e\nf g\nh\ni\n j\tk l m n o'
    assert join_args(['a b"c', 'd', 'e f g" h i j']) == 'a b"c d e f g" h i j'

# Generated at 2022-06-23 05:01:59.100736
# Unit test for function join_args
def test_join_args():
    assert join_args(['one']) == 'one'
    assert join_args(['one', 'two']) == 'one two'
    assert join_args(['one\n', 'two']) == 'one\ntwo'
    assert join_args(['one', 'two\n']) == 'one\ntwo\n'
    assert join_args(['one\n', 'two\n']) == 'one\ntwo\n'



# Generated at 2022-06-23 05:02:08.140356
# Unit test for function parse_kv

# Generated at 2022-06-23 05:02:20.688981
# Unit test for function split_args

# Generated at 2022-06-23 05:02:31.409373
# Unit test for function join_args
def test_join_args():
    result = join_args(['/sbin/iptables', '-A', 'INPUT', '-i', 'lo', '-j', 'ACCEPT'])
    assert result == '/sbin/iptables -A INPUT -i lo -j ACCEPT'

    result = join_args(['/bin/echo', '"\\[$(&)\\]"'])
    assert result == '/bin/echo "\\[$(&)\\]"'

    result = join_args(['/sbin/iptables', '-A INPUT -i lo -j ACCEPT'])
    assert result == '/sbin/iptables -A INPUT -i lo -j ACCEPT'

    result = join_args(['/bin/echo', '"\\$(&)"'])
    assert result == '/bin/echo "\\$(&)"'



# Generated at 2022-06-23 05:02:35.351050
# Unit test for function join_args
def test_join_args():
    assert join_args(("/bin/sh", "-c", "a=1\nb=2\nif [ $a -gt 0 ]; then echo yes; fi")) == "/bin/sh -c a=1\nb=2\nif [ $a -gt 0 ]; then echo yes; fi"


# Generated at 2022-06-23 05:02:40.370953
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'hi']) == 'echo hi'
    assert join_args(['echo hi']) == 'echo hi'
    assert join_args(['echo\nhi']) == 'echo\nhi'
    assert join_args(['echo', '\n', 'there']) == 'echo\nthere'
    assert join_args(['echo\n', 'there']) == 'echo\nthere'



# Generated at 2022-06-23 05:02:51.848402
# Unit test for function split_args
def test_split_args():
    assert split_args(u"foo bar baz") == [u"foo", u"bar", u"baz"]
    assert split_args(u"\nfoo\nbar\nbaz") == [u"foo", u"\n", u"bar", u"\n", u"baz"]
    assert split_args(u"\nfoo \n bar\nbaz") == [u"foo", u"\n", u"bar", u"\n", u"baz"]
    assert split_args(u"foo=bar baz=quux") == [u"foo=bar", u"baz=quux"]
    assert split_args(u"foo='bar' baz=quux") == [u"foo='bar'", u"baz=quux"]

# Generated at 2022-06-23 05:02:59.929791
# Unit test for function parse_kv
def test_parse_kv():
  assert parse_kv("foo=bar") == {"foo" : "bar"}
  assert parse_kv("foo='bar'") == {"foo" : "bar"}
  assert parse_kv("foo=\"bar\"") == {"foo" : "bar"}
  assert parse_kv("foo=\"bar\"\"baz\"") == {"foo" : "bar\"baz"}
  assert parse_kv("foo=\"bar\" biz=baz") == {"foo" : "bar", "biz" : "baz"}
  assert parse_kv("foo=bar biz=baz") == {"foo" : "bar", "biz" : "baz"}
  assert parse_kv("a=1 b=2") == {"a" : "1", "b" : "2"}

# Generated at 2022-06-23 05:03:06.398177
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo', 'bar baz', 'baz']) == 'foo bar baz baz'
    assert join_args(['foo', '\nbar\n', 'baz', '\n\nqux']) == 'foo\nbar\nbaz\n\nqux'
    assert join_args(['foo', 'bar\nbaz\n', 'baz', '\n\nqux']) == 'foo bar\nbaz\nbaz\n\nqux'



# Generated at 2022-06-23 05:03:12.309170
# Unit test for function split_args
def test_split_args():
    assert(split_args("first 'second third'") == ['first','\'second third\''])


# Generated at 2022-06-23 05:03:22.580850
# Unit test for function join_args
def test_join_args():
    s = ['arg1', 'arg2', 'arg3']
    assert join_args(s) == 'arg1 arg2 arg3'
    s = ['arg1', 'arg2', 'arg3\n', 'arg4']
    assert join_args(s) == 'arg1 arg2 arg3\narg4'
    s = ['arg1', 'arg2', 'arg3\n', 'arg4\n', 'arg5\n', 'arg6']
    assert join_args(s) == 'arg1 arg2 arg3\narg4\narg5\narg6'
    s = ['arg1', 'args2\n', 'arg3\n', 'arg4\n', 'arg5', 'arg6\n']

# Generated at 2022-06-23 05:03:32.684968
# Unit test for function parse_kv
def test_parse_kv():
    test_args = "one=1 two=2 three-3"

    # 1. Parse a string with no free-form args
    result = parse_kv(test_args)
    expected = dict(one='1', two='2', three='-3')
    assert result == expected

    # 2. Parse a string with free-form args
    result = parse_kv(test_args, check_raw=True)
    expected = dict(one='1', two='2', three='-3', _raw_params='three-3')
    assert result == expected

    # 3. Parse a string with escaped equals
    test_args = "v='one=1' v2='two=2'"
    result = parse_kv(test_args, check_raw=True)

# Generated at 2022-06-23 05:03:42.481952
# Unit test for function join_args
def test_join_args():
    s = ['a', 'b c', 'd\n', ' e', 'f', ' ', 'g']
    assert join_args(s) == 'a b c\n d\n  e f  g'
    s = ['a b c\n', 'd\n', ' e', 'f', ' ', 'g']
    assert join_args(s) == 'a b c\n d\n  e f  g'
    s = ['a b c\n', 'd\n', ' e', 'f', ' ', 'g\n', 'h']
    assert join_args(s) == 'a b c\n d\n  e f  g\n h'
test_join_args()



# Generated at 2022-06-23 05:03:49.824795
# Unit test for function join_args
def test_join_args():
    s=['foo', ' ', 'bar']
    assert join_args(s)=='foo bar'
    s=['foo', '\n', 'bar']
    assert join_args(s)=='foo\nbar'
test_join_args()


# Generated at 2022-06-23 05:03:55.699727
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', '\nb']) == 'a \nb'
    assert join_args(['a', 'b\n']) == 'a b\n'
    assert join_args(['a', '\nb\n']) == 'a \nb\n'
    assert join_args(['\n']) == '\n'
    assert join_args(['a b']) == 'a b'
    assert join_args(['a=b']) == 'a=b'
    assert join_args(['a=b', '\nc']) == 'a=b \nc'
    assert join_args(['a', 'b', 'c']) == 'a b c'

# Generated at 2022-06-23 05:04:06.199196
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('somekey=somevalue') == {u'somekey': u'somevalue'}
    assert parse_kv('somekey = somevalue') == {u'somekey': u'somevalue'}
    assert parse_kv(' somekey=somevalue') == {u'somekey': u'somevalue'}
    assert parse_kv('somekey=somevalue ') == {u'somekey': u'somevalue'}
    assert parse_kv('somekey = somevalue ') == {u'somekey': u'somevalue'}
    assert parse_kv(' somekey = somevalue ') == {u'somekey': u'somevalue'}
    assert parse_kv(' somekey=somevalue ') == {u'somekey': u'somevalue'}
    assert parse_kv

# Generated at 2022-06-23 05:04:17.001672
# Unit test for function split_args
def test_split_args():
    '''
   
    '''
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    original_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

# Generated at 2022-06-23 05:04:27.077294
# Unit test for function join_args
def test_join_args():
    assert join_args(split_args('foo "bar baz" doo')) == 'foo "bar baz" doo'
    assert join_args(split_args('foo "bar\\" baz" doo')) == 'foo "bar\\" baz" doo'
    assert join_args(split_args('foo "bar\\n baz" doo')) == 'foo "bar\\n baz" doo'
    assert join_args(split_args('foo "bar\\n\\nbaz" doo')) == 'foo "bar\\n\\nbaz" doo'
    assert join_args(split_args('foo "bar\\n\\nbaz"\ndoo')) == 'foo "bar\\n\\nbaz"\ndoo'

# Generated at 2022-06-23 05:04:36.142524
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d", True) == {u'a': u'b', u'c': u'd', u'_raw_params': u'a=b c=d'}
    assert parse_kv(r"a=b\\=c c=d", True) == {u'a': u'b=c', u'c': u'd', u'_raw_params': r'a=b\\=c c=d'}
    assert parse_kv(r"a='b=c' c=d", True) == {u'a': u'b=c', u'c': u'd', u'_raw_params': r"a='b=c' c=d"}

# Generated at 2022-06-23 05:04:45.796138
# Unit test for function split_args

# Generated at 2022-06-23 05:04:46.976471
# Unit test for function parse_kv
def test_parse_kv():
    pass


# Generated at 2022-06-23 05:04:57.836696
# Unit test for function split_args
def test_split_args():
    # Test 1: Should detect unbalanced "quotes"
    args = '''a=b c="stuff here" d="stuff with \"quotes\" in it"'''
    result = split_args(args)
    assert result == ['a=b', 'c="stuff here"', 'd="stuff with \\"quotes\\" in it"'], result

    # Test 2: Should detect unbalanced {{}}
    args = '''a=b c="stuff here" d="stuff with \\"quotes\\" in it" {{ foo }}'''
    result = split_args(args)
    assert result == ['a=b', 'c="stuff here"', 'd="stuff with \\"quotes\\" in it"', '{{', 'foo', '}}'], result

    # Test 3: Should detect unbalanced {{}}

# Generated at 2022-06-23 05:05:06.696603
# Unit test for function parse_kv
def test_parse_kv():

    def run_test(args, expected):
        result = parse_kv(args)
        assert expected == result, "Expected %s, got %s" % (expected, result)

    # no arguments
    run_test(None, {})
    run_test("", {})

    # simple arguments
    run_test("a=b", {'a': 'b'})
    run_test("a=1", {'a': '1'})

    # quoted arguments
    run_test("a='b c'", {'a': 'b c'})
    run_test("a='b c' d=2", {'a': 'b c', 'd': '2'})
    run_test("a=\"b c\"", {'a': 'b c'})

# Generated at 2022-06-23 05:05:10.287706
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b='c d' e=\"f g\"") == {'a': '1', 'b': "c d", 'e': "f g"}



# Generated at 2022-06-23 05:05:20.158647
# Unit test for function join_args
def test_join_args():
    assert join_args(['a','b','c']) == 'a b c'
    assert join_args(['a\n','b','c']) == 'a\nb c'
    assert join_args(['a','b','c\n']) == 'a b\nc\n'
    assert join_args(['a','b','\n','c']) == 'a b\n c'
    assert join_args(['a','b','\n','c\n']) == 'a b\n c\n'
    assert join_args(['a\n','b\n','\n','c']) == 'a\n b\n\n c'
    assert join_args(['a\n','b\n','\n','c\n']) == 'a\n b\n\n c\n'



# Generated at 2022-06-23 05:05:31.282249
# Unit test for function parse_kv
def test_parse_kv():
    def _kv_test(input, output):
        result = parse_kv(input)
        if isinstance(output, Exception):
            assert isinstance(result, type(output))
        else:
            assert result == output

    # I don't actually know how to split 'foo="a=b" bar=baz' in a way that will
    # make it parse correctly, so we don't bother trying...
    yield _kv_test, 'foo="a=b" bar=baz', ValueError
    yield _kv_test, 'foo="a=b" bar=baz', ValueError
    yield _kv_test, 'foo="a=b" bar=baz', ValueError
    yield _kv_test, 'foo="a=b" bar=baz', ValueError
    yield _kv_test,

# Generated at 2022-06-23 05:05:42.379602
# Unit test for function parse_kv
def test_parse_kv():
    import pytest

    ### Testing for single key value pair
    assert parse_kv('foo=42') == {u'foo': '42'}

    ### Testing for multiple key value pairs with space in between
    input_kv = 'foo="42" bar=baz'
    output_kv = {u'foo': '42', u'bar': 'baz'}
    assert parse_kv(input_kv) == output_kv

    ### Testing for multiple key value pairs without space in between
    input_kv = 'foo="42"bar=baz'
    assert parse_kv(input_kv) == output_kv

    ### Testing for multiple key value pairs without quotes
    input_kv = 'foo=42 bar=baz'
    assert parse_kv(input_kv) == output_k

# Generated at 2022-06-23 05:05:52.469879
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("foo=bar biz=baz")
    assert options['foo'] == 'bar'
    assert options['biz'] == 'baz'
    assert '_raw_params' not in options

    options = parse_kv("user=root password=foobar", check_raw=True)
    assert options['user'] == 'root'
    assert options['password'] == 'foobar'
    assert '_raw_params' not in options

    options = parse_kv("foo=bar biz=baz", check_raw=True)
    assert options['foo'] == 'bar'
    assert options['biz'] == 'baz'
    assert '_raw_params' not in options

    options = parse_kv("foo=bar biz=baz; echo 'hi'", check_raw=True)


# Generated at 2022-06-23 05:06:02.590625
# Unit test for function split_args
def test_split_args():
    assert split_args(args='foo=bar name={{name}}') == ['foo=bar', 'name={{name}}']
    assert split_args(args='foo=bar name={{name}}') != ['foo=bar', 'name={{name']
    assert split_args(args="foo='bar' name={{name}}") == ["foo='bar'", 'name={{name}}']
    assert split_args(args='''foo='bar' name={{name}}''') == ["foo='bar'", 'name={{name}}']
    assert split_args(args='''foo='bar' name={{ "name }}"}''') == ["foo='bar'", 'name={{ "name }}"}']

# Generated at 2022-06-23 05:06:15.161224
# Unit test for function parse_kv
def test_parse_kv():
    args = "creates=/tmp/foo removes=/tmp/bar chdir=/tmp/bam executable=/bin/bash warn=yes stdin=foobar.txt stdin_add_newline=yes strip_empty_ends=yes key=val key2='val two' key3=\"val three\" key4=true"
    options = parse_kv(args, check_raw=True)

# Generated at 2022-06-23 05:06:21.055696
# Unit test for function join_args
def test_join_args():
    s = ['hello', 'world\n', 'foo bar']
    assert join_args(s) == 'hello world\nfoo bar'
    s = ['hello', '"world\nfoo bar"', '\n', 'test']
    assert join_args(s) == 'hello "world\nfoo bar"\ntest'



# Generated at 2022-06-23 05:06:31.224626
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '"hello world"']) == 'echo "hello world"'
    assert join_args(['echo', 'hello world']) == 'echo hello world'
    assert join_args(['ps', '-ef', '-o pid,ppid,args']) == 'ps -ef -o pid,ppid,args'
    assert join_args(['cat "{{ file_name }}"']) == 'cat "{{ file_name }}"'
    assert join_args(['cat "{{', 'file_name', '}}"']) == 'cat "{{ file_name }}"'
    assert join_args(['-i', '"{{ inventory_path }}"']) == '-i "{{ inventory_path }}"'



# Generated at 2022-06-23 05:06:40.319594
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 05:06:49.821913
# Unit test for function join_args
def test_join_args():
    print('=== Testing join_args() ===')
    parsed = split_args('/bin/foo bar="baz"')
    assert (join_args(parsed) == '/bin/foo bar=baz')
    assert (join_args(split_args('/bin/foo "bar baz"')) ==
            '/bin/foo "bar baz"')
    assert (join_args(split_args('/bin/foo "bar \' baz"')) ==
            '/bin/foo "bar \' baz"')
    assert (join_args(split_args('/bin/foo "bar \' baz" a=1')) ==
            '/bin/foo "bar \' baz" a=1')

# Generated at 2022-06-23 05:07:00.762108
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c=d') == {u'a': u'b',
                                    u'c': u'd'}

    assert parse_kv(u'') == {}

    assert parse_kv(u'a=b  c=d') == {u'a': u'b',
                                     u'c': u'd'}

    assert parse_kv(u'a="b b" c=d') == {u'a': u'b b',
                                        u'c': u'd'}

    assert parse_kv(u'a="b b" c="d d"') == {u'a': u'b b',
                                            u'c': u'd d'}


# Generated at 2022-06-23 05:07:11.994858
# Unit test for function split_args

# Generated at 2022-06-23 05:07:22.760505
# Unit test for function split_args
def test_split_args():
    # Clean run
    assert split_args(u'foo=bar baz') == [u'foo=bar', u'baz']
    # Escaped single quote
    assert split_args(u'foo=bar baz="i\\\'m a very nice sentence"') == [u'foo=bar', u'baz="i\\\'m a very nice sentence"']
    # Jinja2 print block
    assert split_args(u'foo=bar baz="{{ my_var }}"') == [u'foo=bar', u'baz="{{ my_var }}"']
    # Jinja2 print block, with single quote string inside

# Generated at 2022-06-23 05:07:34.209794
# Unit test for function join_args

# Generated at 2022-06-23 05:07:45.369413
# Unit test for function split_args
def test_split_args():
    def check(input_string, expected_output):
        actual_output = split_args(input_string)
        assert actual_output == expected_output

    # Empty string
    check('', [])

    # No quotes
    check('a=b c=d', ['a=b', 'c=d'])
    check('--one --two', ['--one', '--two'])

    # Single quotes
    check("'foo bar'", ["'foo bar'"])
    check("'a=b bar'", ["'a=b bar'"])
    check("'a=b bar' 'c=d'", ["'a=b bar'", "'c=d'"])
    check("a='b bar' c='d'", ["a='b bar'", "c='d'"])

# Generated at 2022-06-23 05:07:48.797856
# Unit test for function split_args
def test_split_args():
    input_string = "true {{ foo }} bar"
    assert split_args(input_string) == ['true', '{{', 'foo', '}}', 'bar']


# Generated at 2022-06-23 05:07:59.037536
# Unit test for function split_args
def test_split_args():
    # test basic parsing and quotes
    assert split_args(u'foo=bar') == ['foo=bar']
    assert split_args(u'foo=bar "baz qux"') == ['foo=bar', '"baz qux"']
    assert split_args(u'foo=bar "baz qux" "quux corge"') == ['foo=bar', '"baz qux"', '"quux corge"']
    assert split_args(u"foo=bar 'baz qux'") == ['foo=bar', "'baz qux'"]
    assert split_args(u"foo=bar 'baz qux' 'quux corge'") == ['foo=bar', "'baz qux'", "'quux corge'"]
    # test args split over multiple lines

# Generated at 2022-06-23 05:08:09.343001
# Unit test for function join_args
def test_join_args():
    assert 'a' == join_args(['a'])
    assert 'a b' == join_args(['a', 'b'])
    assert 'a\n b' == join_args(['a\n', 'b'])
    assert 'a b\n c' == join_args(['a', 'b\n', 'c'])
    assert 'a b\n c d' == join_args(['a', 'b\n', 'c', 'd'])
    assert 'a\n b\n c\n d' == join_args(['a\n', 'b\n', 'c\n', 'd'])
    assert 'a b\n c d\n e f' == join_args(['a', 'b\n', 'c', 'd\n', 'e', 'f'])



# Generated at 2022-06-23 05:08:17.572807
# Unit test for function join_args
def test_join_args():
    res = join_args(['foo', 'bar', 'baz'])
    assert res == 'foo bar baz'
    res = join_args(['foo\n', 'bar\n', 'baz'])
    assert res == 'foo\nbar\n baz'
    res = join_args(['foo\n', 'bar', 'baz\n'])
    assert res == 'foo\nbar baz\n'
    res = join_args(['foo', 'bar\n', 'baz'])
    assert res == 'foo bar\n baz'



# Generated at 2022-06-23 05:08:25.833170
# Unit test for function split_args

# Generated at 2022-06-23 05:08:37.965121
# Unit test for function parse_kv
def test_parse_kv():
    tests = [
        ('foo=bar', {u'foo': u'bar'}),
        ('foo="bar baz"', {u'foo': u'bar baz'}),
        ('foo=bar baz=blam', {u'baz': u'blam', u'foo': u'bar'}),
        ('foo=bar baz=blam', {u'baz': u'blam', u'foo': u'bar'}),
        (u'foo=bar \u00E9=blam', {u'foo': u'bar', u'\u00E9': u'blam'}),
        (u'user=\u00E9ric', {u'user': u'\u00E9ric'})
    ]
    for arg, expected in tests:
        assert parse_k

# Generated at 2022-06-23 05:08:41.575115
# Unit test for function join_args
def test_join_args():
    assert 'a=1 b=2' == join_args(split_args('a=1 b=2'))
    assert 'a=1 b=2\nc=3' == join_args(split_args('a=1 b=2\nc=3'))



# Generated at 2022-06-23 05:08:52.792857
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=2 b=3') == {'a': '2', 'b': '3'}
    assert parse_kv('a=2 "b=3 hello"') == {'a': '2', 'b': '3 hello'}
    assert parse_kv('a=2 "b=3 hello" c=4 b="hello d"') == {'a': '2', 'b': 'hello d', 'c': '4'}

# Generated at 2022-06-23 05:09:03.737735
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("") == {}
    assert parse_kv("foo=bar") == {'foo': 'bar'}
    assert parse_kv("foo=bar bar=baz") == {'foo': 'bar', 'bar': 'baz'}
    assert parse_kv("foo=bar bar=baz bing=boom") == {'foo': 'bar', 'bar': 'baz', 'bing': 'boom'}
    assert parse_kv("foo=bar bar=baz bing='boom boom'") == {'foo': 'bar', 'bar': 'baz', 'bing': 'boom boom'}

# Generated at 2022-06-23 05:09:11.813519
# Unit test for function split_args
def test_split_args():
    print("*** Testing split_args ***")
    # test various nesting combinations

# Generated at 2022-06-23 05:09:21.759989
# Unit test for function parse_kv
def test_parse_kv():
    args = "a=b c=d e='i j' f='l=m'"
    options = parse_kv(args)
    assert options == dict(a='b', c='d', e='i j', f='l=m')

    args = "a=b c=d e='i j' f='l=\"m\"'"
    options = parse_kv(args)
    assert options == dict(a='b', c='d', e='i j', f=r'l="m"')

    args = 'test_arg=1 test_arg=\"\\\"\"'
    options = parse_kv(args)
    assert options == dict(test_arg='\"')

    args = 'test_arg=1 test_arg=\"\\\\\"'
    options = parse_kv(args)

# Generated at 2022-06-23 05:09:32.926147
# Unit test for function split_args

# Generated at 2022-06-23 05:09:40.498306
# Unit test for function split_args
def test_split_args():
    args = "{{ foo }}\n\n-a 'foo \\\nbar'\n{% bar %}\n -b 'foo \\\nbar' {# foo #}-c 'foo \\\nbar'\n -d 'foo \\\nbar'\n{{ baz }}"

    result = split_args(args)
    # there should be 5 elements, ordered as follows
    assert result[0] == "{{ foo }}\n"
    assert result[1] == "-a 'foo \\\nbar'"
    assert result[2] == "{% bar %}\n -b 'foo \\\nbar' {# foo #}-c 'foo \\\nbar'"
    assert result[3] == "-d 'foo \\\nbar'"
    assert result[4] == "{{ baz }}"


# Generated at 2022-06-23 05:09:51.284045
# Unit test for function split_args
def test_split_args():
    def assert_args(input_param, expected_output):
        if expected_output != split_args(input_param):
            print("Expected: %s" % expected_output)
            print("Got: %s" % split_args(input_param))
            raise AssertionError(input_param)

    # simple test
    assert_args("a=b c=d", ['a=b', 'c=d'])

    # quoting and jinja2
    assert_args("a=b c='foo bar' d=\"foo bar\" e='a \"b\" c'", ['a=b', 'c=\'foo bar\'', 'd="foo bar"', 'e=\'a "b" c\''])

    # test some edge cases

# Generated at 2022-06-23 05:10:01.593894
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a="1 2" b=c') == {'a': '"1 2"', 'b': 'c'}
    assert parse_kv("a='1 2' b=c") == {'a': "'1 2'", 'b': 'c'}
    assert parse_kv("a='1 2' b='c d'") == {'a': "'1 2'", 'b': "'c d'"}
    assert parse_kv("a='1 2' b='c=d e'") == {'a': "'1 2'", 'b': "'c=d e'"}

# Generated at 2022-06-23 05:10:12.701316
# Unit test for function join_args
def test_join_args():
    assert 'a b' == join_args(['a', 'b'])
    assert 'a b' == join_args(['a ', ' b'])
    assert 'a b' == join_args(['a\n', 'b'])
    assert 'a b' == join_args(['a\n', 'b\n'])
    assert 'a b' == join_args(['\na', ' b\n'])
    assert 'a b' == join_args(['\na', 'b\n'])
    assert 'a b\nc' == join_args(['a', 'b\nc'])
    assert 'a b\nc' == join_args(['a', 'b', 'c'])
    assert 'a b\nc' == join_args(['a\n', 'b', 'c'])


# Generated at 2022-06-23 05:10:23.674343
# Unit test for function split_args
def test_split_args():
    test_cases = []
    test_cases.append((
        '''a=b c="foo bar"''',
        ['a=b', 'c="foo bar"']
    ))
    test_cases.append((
        '''a=b c="foo bar"\n''',
        ['a=b', 'c="foo bar"']
    ))
    test_cases.append((
        '''a=b c="foo bar"\nd=e''',
        ['a=b', 'c="foo bar"\n', 'd=e']
    ))
    test_cases.append((
        '''a=b c="foo \nbar"''',
        ['a=b', 'c="foo \nbar"']
    ))

# Generated at 2022-06-23 05:10:33.346107
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a=b c=d']) == 'a=b c=d'
    assert join_args(['a', 'b c=d']) == 'a b c=d'
    assert join_args(['a', 'b', 'c=d']) == 'a b c=d'
    assert join_args(['a=b', 'c']) == 'a=b c'
    assert join_args(['a=b', 'c', 'd']) == 'a=b c d'
    assert join_args(['a=b', 'c=d', 'e']) == 'a=b c=d e'

# Generated at 2022-06-23 05:10:44.776369
# Unit test for function split_args

# Generated at 2022-06-23 05:10:54.571059
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"k=v") == {u"k": u"v"}
    assert parse_kv(u"k=\"v\"") == {u"k": u"v"}
    assert parse_kv(u"k='v'") == {u"k": u"v"}
    assert parse_kv(u"k=v g=1") == {u"k": u"v", u"g": u"1"}
    assert parse_kv(u"k='v g=1'") == {u"k": u"v g=1"}
    assert parse_kv(u"k='v g=1' g=1") == {u"k": u"v g=1", u"g": u"1"}