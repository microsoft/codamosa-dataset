

# Generated at 2022-06-23 05:00:54.006382
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo \"\"bar\"\"") == ['a=b', 'c="foo "bar""']
    assert split_args("a=b c=\\") == ['a=b', 'c=']
    assert split_args("a=b c='foo bar'") == ['a=b', 'c=\'foo bar\'']
    assert split_args("creates=\"/path/to/a/file\"") == ['creates="/path/to/a/file"']
    assert split_args("creates=\"/path/to/a/file\" d=\"foo") == ['creates="/path/to/a/file"', 'd="foo']

# Generated at 2022-06-23 05:00:57.708638
# Unit test for function split_args
def test_split_args():
    try:
        import tests

        tests.run_unittests(__file__)
    except ImportError:
        pass

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-23 05:01:07.065133
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.utils import unit
    assert parse_kv(u"foo=bar") == {u'foo': u'bar'}
    assert parse_kv(u"foo='bar'") == {u'foo': u'bar'}
    assert parse_kv(u"foo='bar' baz='quux'") == {u'foo': u'bar', u'baz': u'quux'}
    assert parse_kv(u"foo='a bar' baz='quux'") == {u'foo': u'a bar', u'baz': u'quux'}
    assert parse_kv(u"foo='a bar' baz='qu\"ux'") == {u'foo': u'a bar', u'baz': u'qu"ux'}

# Generated at 2022-06-23 05:01:16.449322
# Unit test for function parse_kv
def test_parse_kv():
    extra_vars = parse_kv("{ \"foo\" : \"bar\" }")
    assert extra_vars == {"foo" : "bar"}

    extra_vars = parse_kv("foo=bar")
    assert extra_vars == {"foo" : "bar"}

    extra_vars = parse_kv("foo=bar baz=bam")
    assert extra_vars == {"foo" : "bar", "baz" : "bam"}

    extra_vars = parse_kv("foo =  bar")
    assert extra_vars == {"foo" : "bar"}

    extra_vars = parse_kv("foo='bar'" , check_raw=True)
    assert extra_vars == {"foo" : "bar"}


# Generated at 2022-06-23 05:01:25.266147
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', 'b', '\nc']) == 'a b\nc'
    assert join_args(['a', 'b\n', 'c']) == 'a b\nc'
    assert join_args(['a', 'b\nc', 'd']) == 'a b\nc d'
    assert join_args(['\na', 'b\nc', 'd']) == '\na b\nc d'
    assert join_args(['\na\n', 'b\nc', 'd']) == '\na\n b\nc d'
    assert join_args(['\na\n', 'b\nc', '\nd']) == '\na\n b\nc\nd'
    assert join_args

# Generated at 2022-06-23 05:01:33.354112
# Unit test for function join_args
def test_join_args():
    s = [
        "command",
        " 1",
        " 2",
        "3 # test\n",
        "4",
        "5",
        "6",
        "7\n",
        "8",
        " # comment",
        "9",
        "10",
        "11\n",
        "12",
        "13",
        "14",
        "15",
    ]
    expected = "command 1 2 3 # test\n4 5 6 7\n8 # comment 9 10 11\n12 13 14 15"
    actual = join_args(s)
    assert actual == expected, "actual: %s\nexpected: %s" % (actual, expected)
# End unit test



# Generated at 2022-06-23 05:01:43.698207
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c=3") == {"a": "1", "b": "2", "c": "3"}
    assert (parse_kv("a=1 b=2 c=3", check_raw=True) ==
            {"a": "1", "b": "2", "c": "3", "_raw_params": "a=1 b=2 c=3"})
    assert parse_kv("a=1 b=2 _raw_params=c=3 _raw_params=d=4") == {"a": "1", "b": "2", "_raw_params": "c=3 d=4"}

# Generated at 2022-06-23 05:01:48.646879
# Unit test for function join_args
def test_join_args():
    s = ['echo', 'hello', 'world']
    assert join_args(s) == 'echo hello world'

    s = ['echo hello world', 'echo goodbye world']
    assert join_args(s) == 'echo hello world\necho goodbye world'


# Generated at 2022-06-23 05:01:56.806828
# Unit test for function join_args
def test_join_args():
    inp = '''a=1 b="2" c=3'''
    assert join_args(split_args(inp)) == inp

    inp = '''a=1 \\\n  b=2 \\\n  c=3'''
    assert join_args(split_args(inp)) == inp

    inp = '''a=1 \\\n  b=2 \\\n  c=3 \\\n'''
    assert join_args(split_args(inp)) == inp

    inp = '''a=1 \\\n  b=2 \\\n  c=3 \\\n  '''
    assert join_args(split_args(inp)) == inp


# Generated at 2022-06-23 05:02:05.193369
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar baz']) == 'foo bar baz'
    assert join_args(['foo bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo bar', 'baz\n', 'asdf', 'qwer']) == 'foo bar baz\nasdf qwer'



# Generated at 2022-06-23 05:02:19.512689
# Unit test for function join_args
def test_join_args():
    '''
    Test the join_args function
    '''
    assert '"' in join_args(['echo', 'string1 string2', '>', 'file.txt'])

    assert '"' not in join_args(['ls', '-thr'])

    assert '\\' not in join_args(['echo', '"a \\"b\\" c"', '>', 'file.txt'])

    assert "'''" in join_args(["echo", "string1 'string2' string3"])

    assert '\n' in join_args(['ls', '-thr', '\n', 'ls -thr'])

    assert '\\' not in join_args(['echo', '\\"string1\\"', '>', 'file.txt'])

    assert '\\\\' not in \
        join_

# Generated at 2022-06-23 05:02:30.756987
# Unit test for function split_args
def test_split_args():
    msg = "testing args: {0} -> {1}"

    def test_result(args, expected):
        result = split_args(args)
        assert result == expected, msg.format(args, result)

    test_result('a=b', ['a=b'])
    test_result('a=b c=d', ['a=b', 'c=d'])
    test_result('a=b\nc=d', ['a=b', 'c=d'])
    test_result('a=b\n    c=d', ['a=b', 'c=d'])
    test_result('a=b \\\nc=d', ['a=b c=d'])
    test_result('"a=b" c=d', ['a=b', 'c=d'])

# Generated at 2022-06-23 05:02:39.930191
# Unit test for function split_args
def test_split_args():
    '''Should return tuple of command / arguments'''

    test_count = 0

    def test_split_args_inner(args, expected):
        global test_count
        test_count += 1
        test_str = 'test_split_args_%d' % test_count
        result = split_args(args)
        assert result == expected, '%s failed. Expected: %s, Got: %s' % (test_str, expected, result)

    test_split_args_inner('a=b c="foo bar" d={{ foo.bar }}', ['a=b', 'c="foo bar"', 'd={{ foo.bar }}'])

# Generated at 2022-06-23 05:02:51.800650
# Unit test for function split_args
def test_split_args():
    import unittest

    class TestSplitArgs(unittest.TestCase):
        def test_split_args(self):
            # Tests the basic functionality of this function.
            # These tests should not be touching other areas of
            #   the code.
            test_string = "key1=val1 key2='val 2'"
            expected_results = ["key1=val1", "key2='val 2'"]
            results = split_args(test_string)
            self.assertEqual(results, expected_results)

            test_string = "key1=val1 key2=\"val 2\""
            expected_results = ["key1=val1", "key2=\"val 2\""]
            results = split_args(test_string)
            self.assertEqual(results, expected_results)


# Generated at 2022-06-23 05:03:00.296616
# Unit test for function join_args

# Generated at 2022-06-23 05:03:05.467914
# Unit test for function join_args
def test_join_args():
    assert join_args(['Hello', 'World', '\n', 'How', 'are', 'you?']) == 'Hello World\nHow are you?'



# Generated at 2022-06-23 05:03:20.559933
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar\\" baz"') == ['foo', '"bar\\" baz"']
    assert split_args('foo "bar\\" baz" spam') == ['foo', '"bar\\" baz"', 'spam']
    assert split_args('foo "bar baz" "spam eggs"') == ['foo', '"bar baz"', '"spam eggs"']
    assert split_args('foo "bar baz" "spam eggs" bar') == ['foo', '"bar baz"', '"spam eggs"', 'bar']
    assert split

# Generated at 2022-06-23 05:03:30.602687
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing parse_kv")
    assert parse_kv("foo=bar") == {"foo": "bar"}
    assert parse_kv("foo='bar baz'") == {"foo": "bar baz"}
    assert parse_kv("foo='bar baz' x=y") == {"foo": "bar baz", "x": "y"}
    assert parse_kv("foo='bar baz' x=y", check_raw=True) == {"foo": "bar baz", "x": "y", "_raw_params": "foo='bar baz' x=y"}
    assert parse_kv("foo='bar baz' x=y z") == {"foo": "bar baz", "x": "y"}
    assert parse_kv("foo='bar baz' x=y z", check_raw=True)

# Generated at 2022-06-23 05:03:37.920495
# Unit test for function parse_kv
def test_parse_kv():
    pairs = parse_kv('foo=bar=baz')
    assert pairs.get('foo') == 'bar=baz'
    assert pairs.get('_raw_params') is None
    pairs = parse_kv('foo="bar=baz bing"')
    assert pairs.get('foo') == 'bar=baz bing'
    assert pairs.get('_raw_params') is None
    pairs = parse_kv('foo="bar=baz bing"  bar="baz1"')
    assert pairs.get('foo') == 'bar=baz bing'
    assert pairs.get('bar') == 'baz1'
    assert pairs.get('_raw_params') is None
    pairs = parse_kv('bar="baz1"  foo="bar=baz bing"')
    assert pairs

# Generated at 2022-06-23 05:03:47.208179
# Unit test for function split_args

# Generated at 2022-06-23 05:03:58.634952
# Unit test for function split_args

# Generated at 2022-06-23 05:04:01.801671
# Unit test for function join_args
def test_join_args():
    test_list = ['a', 'b', 'c', '\nd', 'e f g']
    assert join_args(test_list) == 'a b c\n\nd e f g', 'join_args failed to reconstruct input'



# Generated at 2022-06-23 05:04:12.027071
# Unit test for function parse_kv

# Generated at 2022-06-23 05:04:19.953113
# Unit test for function parse_kv
def test_parse_kv():
    # Test that decode_escapes decodes valid escape sequences
    # Two-digit escapes
    assert _decode_escapes('\\x9a\\x9b') == '\x9a\x9b'
    # Four-digit escapes
    assert _decode_escapes('\\u9a9b\\u9a9c') == '\u9a9b\u9a9c'
    # Eight-digit escapes

# Generated at 2022-06-23 05:04:29.523048
# Unit test for function split_args
def test_split_args():
    assert split_args("{{hello}}") == ["{{hello}}"]
    assert split_args("{{hello}} {{world}}") == ["{{hello}}", "{{world}}"]
    assert split_args("{{hello}}\n{{world}}") == ["{{hello}}\n", "{{world}}"]

    assert split_args("foo 'a=b c=d' bar") == ["foo", "'a=b c=d'", "bar"]
    assert split_args("foo 'a=b c=d'\n bar") == ["foo", "'a=b c=d'\n", "bar"]

    assert split_args("foo \"a=b c=d\" bar") == ["foo", "\"a=b c=d\"", "bar"]

# Generated at 2022-06-23 05:04:37.381912
# Unit test for function join_args
def test_join_args():
    test_cases = [
        ('foo', 'foo'),
        ('foo=bar', 'foo=bar'),
        ('foo=bar baz=zoo', 'foo=bar baz=zoo'),
        ('foo=bar\nbaz=zoo', 'foo=bar\nbaz=zoo'),
        ('foo="bar\nbaz"', 'foo="bar\nbaz"'),
        ('foo="bar baz"', 'foo="bar baz"'),
    ]
    for input, output in test_cases:
        actual_output = join_args(split_args(input))
        assert actual_output == output, 'expected {0} but got {1} for test case: {2}'.format(output, actual_output, input)



# Generated at 2022-06-23 05:04:40.949537
# Unit test for function join_args
def test_join_args():
    assert join_args(['one', 'two']) == 'one two'
    assert join_args(['one\n', 'two']) == 'one\ntwo'
    assert join_args(['one\n', '\ntwo']) == 'one\n\ntwo'


# Generated at 2022-06-23 05:04:48.092581
# Unit test for function parse_kv
def test_parse_kv():

    ##########################################################################
    # Examples from command.py
    ##########################################################################

    # Basic use
    result = parse_kv("a=b c='d e' f=\"g h\" i=\\\"j\\\"")
    assert result['a'] == 'b'
    assert result['c'] == 'd e'
    assert result['f'] == 'g h'
    assert result['i'] == '"j"'
    assert '_raw_params' not in result

    # All parameters are key=value
    result = parse_kv("a=b c='d e' f=\"g h\" i=\\\"j\\\"")
    assert result['a'] == 'b'
    assert result['c'] == 'd e'
    assert result['f'] == 'g h'

# Generated at 2022-06-23 05:04:55.379827
# Unit test for function parse_kv

# Generated at 2022-06-23 05:05:06.983618
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '-n', 'foo\\\nbar']) == 'echo -n "foo\\\nbar"\n'
    assert join_args(['echo', '-n', 'foo\\\nbar', 'baz\\\nquux']) == 'echo -n "foo\\\nbar" "baz\\\nquux"\n'
    assert join_args(['echo', '-n', 'foo\\\nbar', 'baz\\\nquux', 'qux']) == 'echo -n "foo\\\nbar" "baz\\\nquux" qux\n'

# Generated at 2022-06-23 05:05:17.835251
# Unit test for function split_args

# Generated at 2022-06-23 05:05:19.884352
# Unit test for function split_args
def test_split_args():
    '''
    Note: This unittest uses doctest to actually test the functionality.
    '''
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 05:05:31.193327
# Unit test for function parse_kv

# Generated at 2022-06-23 05:05:39.808437
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c='hello world'") == {"a": "1", "b": "2", "c": "hello world"}
    assert parse_kv("a=1 b=2 c=hello\\ world", check_raw=True)['_raw_params'] == "a=1 b=2 c=hello\\ world"
    assert parse_kv("a=1 b=2 c=hello\\ world", check_raw=True)['c'] == "hello world"
    assert parse_kv("a=1 b=2 c=hello\\ world", check_raw=True)['a'] == "1"
    assert parse_kv("a=1 b=2 c=hello\\ world", check_raw=True)['b'] == "2"

# Generated at 2022-06-23 05:05:44.929370
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\nb']) == 'a\nb'
    assert join_args(['-m', 'foo "bar baz"']) == '-m foo "bar baz"'



# Generated at 2022-06-23 05:05:54.796092
# Unit test for function parse_kv
def test_parse_kv():
    print('##### parse_kv() test')
    tests = [
        'ansible_connection=local',
        'ansible_connection="local"',
        'ansible_connection=local ansible_user=root',
        'ansible_connection=local\nansible_user=root',
        'ansible_connection=local\nansible_user=ro\\ ot',
        'ansible_connection=local\nansible_user=ro\\\\ ot',
        'ansible_connection=local\nansible_user=ro\\\\=ot'
    ]

    for t in tests:
        print("Testing: %s" % t)
        parsed = parse_kv(t)
        print("Result is: %s" % parsed)

    print("\n")


#
# The following code is based on code originally

# Generated at 2022-06-23 05:06:04.006627
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar "baz zzz"') == ['foo', 'bar', '"baz zzz"']
    assert split_args('foo bar "baz zzz" ddk "pork"') == ['foo', 'bar', '"baz zzz"', 'ddk', '"pork"']
    assert split_args('foo bar "baz zzz') == ['foo', 'bar', '"baz', 'zzz']
    assert split_args('foo bar "baz zzz\nddk pork"\nddk dd"') == ['foo', 'bar', '"baz zzz\nddk pork"\n', 'ddk', 'dd"']

# Generated at 2022-06-23 05:06:14.861100
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("arg1=val1 arg2=val2") == {"arg1":"val1", "arg2":"val2"}
    #test the 'edges' of the regex used to find =
    assert parse_kv("arg1\\==val1 arg2=val2") == {"arg1\\=":"val1", "arg2":"val2"}
    assert parse_kv("arg1=val1\\==val1_1 arg2=val2") == {"arg1":"val1\\=", "arg2":"val2"}
    assert parse_kv("arg1=val1_x\\=val1_1 arg2=val2") == {"arg1":"val1_x\\=val1_1", "arg2":"val2"}
    assert parse_kv("arg1=val1 arg2=val\\=2")

# Generated at 2022-06-23 05:06:23.224204
# Unit test for function join_args
def test_join_args():
    s = ['a', ' ', 'b', '  ', 'c']
    assert join_args(s) == 'a b   c'
    s = ['a', '', 'b', '  ', 'c']
    assert join_args(s) == 'a b   c'
    s = ['a', '\n', 'b', '  ', 'c']
    assert join_args(s) == 'a\nb   c'
    s = ['a', '\n', 'b', '\n', 'c']
    assert join_args(s) == 'a\nb\nc'



# Generated at 2022-06-23 05:06:31.290144
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("one=two three=four") == {u'one': u'two', u'three': u'four'}
    assert parse_kv("one=two three=four", check_raw=True) == {u'one': u'two', u'three': u'four', u'_raw_params': u'three=four'}
    assert parse_kv("one='two three' four='five six'") == {u'one': u'two three', u'four': u'five six'}
    assert parse_kv("one='two three' four='five six'", check_raw=True) == {u'one': u'two three', u'four': u'five six', u'_raw_params': u'four=\'five six\''}

# Generated at 2022-06-23 05:06:40.399719
# Unit test for function split_args
def test_split_args():
    try:
        split_args("{{foo}}")
        assert False, "Should have thrown an error since {{foo}} is jinja2 blocks, but didn't"
    except AnsibleParserError:
        pass

    result = split_args("cmd \"{{foo}}\" bar")
    assert u'cmd "{{foo}}" bar' == join_args(result), "cmd \"{{foo}}\" bar did not rejoin correctly"

    result = split_args("cmd \"{{foo}} 'bar baz'\"")
    assert u"cmd \"{{foo}} 'bar baz'\"" == join_args(result), "cmd \"{{foo}} 'bar baz'\" did not rejoin correctly"

    result = split_args('''cmd "{{foo 'bar baz'}}"''')

# Generated at 2022-06-23 05:06:46.888743
# Unit test for function split_args
def test_split_args():
    import ansible.module_utils.basic as basic
    import ansible.module_utils.common.collections as collections

    class Options(collections.Mapping):
        def __getitem__(self, key):
            return '%s=%s' % (key, key.upper())

        def __iter__(self):
            return iter(('a', 'b', 'c'))

        def __len__(self):
            return 3

    options = Options()

    assert split_args('a={{foo}}') == ['a={{foo}}']
    assert split_args('a="{{foo}}"') == ['a="{{foo}}"']
    assert split_args('a={{foo}} b={{bar}}') == ['a={{foo}}', 'b={{bar}}']

# Generated at 2022-06-23 05:06:58.122066
# Unit test for function join_args

# Generated at 2022-06-23 05:07:00.375995
# Unit test for function split_args
def test_split_args():
   a = split_args('a=b c="foo bar"')
   assert a == ['a=b', 'c="foo bar"']



# Generated at 2022-06-23 05:07:11.894020
# Unit test for function split_args
def test_split_args():
  assert split_args(u"") == []
  assert split_args(u" ") == []
  assert split_args(u"  ") == []
  assert split_args(u"a") == [u"a"]
  assert split_args(u"a ") == [u"a"]
  assert split_args(u"a b") == [u"a", u"b"]
  assert split_args(u"a b c") == [u"a", u"b", u"c"]
  assert split_args(u"a=b c=d") == [u"a=b", u"c=d"]
  assert split_args(u"a=b c=d ") == [u"a=b", u"c=d"]

# Generated at 2022-06-23 05:07:20.035582
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', 'b c']) == 'a b c'
    assert join_args(['a b', 'c']) == 'a b c'
    assert join_args(['a\nb', 'c']) == 'a\nb c'
    assert join_args(['a\nb', '\nc']) == 'a\nb \nc'
    assert join_args(['a\nb', '\n c']) == 'a\nb \n c'



# Generated at 2022-06-23 05:07:30.350174
# Unit test for function split_args
def test_split_args():
    # Add unit test here
    print('Executing test_split_args()')
    # Test 1: Simple command
    my_args = "ls -alh"
    my_result = ['ls', '-alh']
    assert my_result == split_args(my_args)
    # Test 2: Simple command with quotes
    my_args = "ls -alh 'testfile1'"
    my_result = ['ls', '-alh', "'testfile1'"]
    assert my_result == split_args(my_args)
    # Test 3: More complex command
    my_args = "ls -alh 'testfile1' 'testfile2' 'testfile3'"
    my_result = ['ls', '-alh', "'testfile1'", "'testfile2'", "'testfile3'"]

# Generated at 2022-06-23 05:07:40.945927
# Unit test for function split_args
def test_split_args():
    '''
    This is a basic set of tests to see if the split_args utility method works as expected
    '''

    tests = {}

    # Basic test
    tests[u'a=b c="foo bar"'] = [u'a=b', u'c="foo bar"']

    # Test with newlines
    tests[u'a=b\nd=e'] = [u'a=b', u'd=e']

    # Test with jinja2 blocks
    tests[u'a=b j2={{ test }}'] = [u'a=b', u'j2={{ test }}']
    tests[u'a=b j2="{{ test }}"'] = [u'a=b', u'j2="{{ test }}"']

# Generated at 2022-06-23 05:07:52.516682
# Unit test for function split_args
def test_split_args():
    #from ansible.module_utils.common.validation import check_raw
    assert split_args('foo=bar key="val ue"') == ['foo=bar', 'key="val ue"']
    assert split_args('foo="bar1 bar2" key=value') == ['foo="bar1 bar2"', 'key=value']
    assert split_args('foo="bar1\\ bar2" key=value') == ['foo="bar1\\ bar2"', 'key=value']
    assert split_args('foo="bar1\\\\ bar2" key=value') == ['foo="bar1\\\\ bar2"', 'key=value']
    assert split_args('foo=bar key="val ue"') == ['foo=bar', 'key="val ue"']

# Generated at 2022-06-23 05:08:02.057400
# Unit test for function split_args
def test_split_args():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    assert split_args(u'') == []
    assert split_args(u'a b') == [u'a', u'b']
    assert split_args(u'a="b c"') == [u'a="b c"']
    assert split_args(u'a="b c" d="e f"') == [u'a="b c"', u'd="e f"']
    assert split_args(u'a="b c" \\\nd="e f"') == [u'a="b c"', u'd="e f"']

# Generated at 2022-06-23 05:08:13.610722
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv('') == {}
    assert parse_kv('potato') == {'_raw_params': 'potato'}
    assert parse_kv('potato=spud') == {'potato': 'spud'}
    assert parse_kv('potato=spud=mashed') == {'potato': 'spud=mashed'}
    assert parse_kv('potato="spud=mashed"') == {'potato': 'spud=mashed'}
    assert parse_kv('potato=spud=mashed fish=chips') == {'potato': 'spud=mashed', '_raw_params': 'fish=chips'}

# Generated at 2022-06-23 05:08:22.461343
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == { u'foo': u'bar' }
    assert parse_kv('foo=bar baz=biz') == { u'foo': u'bar', u'baz': u'biz' }
    assert parse_kv('foo=bar baz=biz boo=bam') == { u'foo': u'bar', u'baz': u'biz', u'boo': u'bam' }
    assert parse_kv('foo=bar baz=biz boo=bam ') == { u'foo': u'bar', u'baz': u'biz', u'boo': u'bam' }

# Generated at 2022-06-23 05:08:31.610113
# Unit test for function join_args
def test_join_args():
    def test(input, expected):
        if expected != join_args(input):
            raise ValueError('not matched: {}\n!=\n{}'.format(input, join_args(input)))
    test(['a', 'b', 'c'], 'a b c')
    test(['a=b', 'c'], "a='b' c")
    test(['a=b', 'cd'], "a='b' 'cd'")
    test(['a', '"b c"'], 'a "b c"')
    test(['a', '"b c"', 'd'], 'a "b c" d')
    test(['a', "b'c", 'd'], "a 'b'\\''c' d")

# Generated at 2022-06-23 05:08:38.033237
# Unit test for function join_args
def test_join_args():
    ''' test join_args '''
    x = 'foo bar "foo bar" baz'
    assert join_args(split_args(x)) == x
    x = 'foo\nbar "foo bar"\nbaz'
    assert join_args(split_args(x)) == x
    x = 'foo\nbar "foo bar"\nbaz\n'
    assert join_args(split_args(x)) == x



# Generated at 2022-06-23 05:08:47.582444
# Unit test for function join_args
def test_join_args():
    a1 = [
        "ansible localhost -m ping",
        "-a 'comm=ping arg=-c 5 arg=-s arg=127.0.0.1'"]
    assert join_args(a1) == "ansible localhost -m ping -a 'comm=ping arg=-c 5 arg=-s arg=127.0.0.1'"
    a2 = [
        "ansible localhost -m ping",
        "-a \"comm=ping arg=-c 5 arg=-s arg=127.0.0.1\""]
    assert join_args(a2) == "ansible localhost -m ping -a \"comm=ping arg=-c 5 arg=-s arg=127.0.0.1\""

# Generated at 2022-06-23 05:08:54.607497
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"""'foo=bar' 'bar=foo'""") == {u'foo': u'bar', u'bar': u'foo'}
    assert parse_kv(u"foo='bar baz'") == {u'foo': u'bar baz'}
    assert parse_kv(u"foo=\"bar baz\"") == {u'foo': u'bar baz'}
    assert parse_kv(u"foo=(bar baz)") == {u'foo': u'(bar baz)'}
    assert parse_kv(u"""foo='bar'\nbar='baz'""") == {u'foo': u'bar', u'bar': u'baz'}

# Generated at 2022-06-23 05:09:05.862965
# Unit test for function split_args
def test_split_args():
    input_str = '"{{" "foo" "}}" "bar"'
    params = split_args(input_str)
    assert len(params) == 1
    assert params[0] == input_str

    input_str = '"{{" "foo" "}} bar"'
    params = split_args(input_str)
    assert len(params) == 2
    assert params[0] == '"{{" "foo" "}}"'
    assert params[1] == 'bar'

    input_str = '"{{" "foo" "}} bar'
    params = split_args(input_str)
    assert len(params) == 2
    assert params[0] == '"{{" "foo" "}}'
    assert params[1] == 'bar'


# Generated at 2022-06-23 05:09:10.955485
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\n', 'b', 'c']) == 'a\n b c'
    assert join_args(['a\n', 'b\n', 'c']) == 'a\n b\n c'
    assert join_args(['a\n', 'b\n', 'c', 'd\n', 'e']) == 'a\n b\n c d\n e'



# Generated at 2022-06-23 05:09:21.365102
# Unit test for function split_args

# Generated at 2022-06-23 05:09:32.575447
# Unit test for function split_args

# Generated at 2022-06-23 05:09:39.479772
# Unit test for function split_args
def test_split_args():
    arg = u"one two three='four' five={{ six }} seven={{ hello }}eight={{nine}} {{ ten }} \"eleven twelve={{thirteen}}\""
    expected_result = [u"one", u"two", u"three='four'", u"five={{ six }}", u"seven={{ hello }}eight={{nine}} {{ ten }}", u"eleven twelve={{thirteen}}"]

    assert split_args(arg) == expected_result
if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-23 05:09:50.568293
# Unit test for function join_args

# Generated at 2022-06-23 05:09:53.400589
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo', '\nbar']) == 'foo\nbar'



# Generated at 2022-06-23 05:10:03.226284
# Unit test for function split_args
def test_split_args():
    import pytest

    # String with no quotes, no blocks - should work
    assert split_args("a b") == ['a', 'b']

    # String with no quotes, block - should work
    assert split_args("{% a %}") == ['{%', 'a', '%}']

    # String with quotes, no block - should work
    assert split_args("'a'") == ["'a'"]

    # String with quotes and block - should work
    assert split_args("{% 'a' %}") == ["{%", "'a'", "%}"]

    # String with unbalanced quotes - should fail
    pytest.raises(AnsibleParserError, split_args, '"a b')

    # String with unbalanced blocks - should fail

# Generated at 2022-06-23 05:10:14.660896
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv(u"key=value") == {u"key":u"value"})
    assert(parse_kv(u"key=\"value\"") == {u"key":u"value"})
    assert(parse_kv(u"key=value param=\"new value\"") == {u"key":u"value", u"param":u"new value"})
    assert(parse_kv(u"key1=value1 key2=value2") == {u"key1":u"value1", u"key2":u"value2"})
    assert(parse_kv(u"key1='value1' key2='value2'") == {u"key1":u"value1", u"key2":u"value2"})

# Generated at 2022-06-23 05:10:25.315605
# Unit test for function parse_kv
def test_parse_kv():
    args = """foo=bar
    before=be fore
    after=aft er
    space before=space after
    equals=foo\\= bar
    double_escape=\\\\
    escaped_quote=\\"quoted\\"
    newline='before\\nafter'
    newline2="before\\nafter"
    unicode=\\u3042\\U00003042
    named_unicode=\\N{HIRAGANA LETTER A}
    single_escape=\\'"
    """

    print("Args: {0}".format(args))
    print("Expected:")

# Generated at 2022-06-23 05:10:34.648782
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils import basic
    import sys

    def run_test(test_name, args, expected_result, comment_depth=0, block_depth=0, print_depth=0, quote_char=None, inside_quotes=False):
        result = split_args(args)
        if result == expected_result:
            print(test_name + ' - Success')
        else:
            print(test_name + ' - Failure')
        print('\tInput: {0}'.format(args))
        print('\tExpected Result: {0}'.format(expected_result))
        print('\tActual Result: {0}'.format(result))
        print()

    # run_test('SimpleString', 'a=b c=d', 'a=b c=d') - use for input
   

# Generated at 2022-06-23 05:10:45.926381
# Unit test for function split_args
def test_split_args():
    def do_test(args, result):
        assert split_args(args) == result.split(u' ')

    do_test(u'a=b', u'a=b')
    do_test(u'a  = b', u'a=b')
    do_test(u'a="b c"', u'a="b c"')
    do_test(u'a="b', u'a="b')
    do_test(u'a="b\\"', u'a="b\\"')
    do_test(u'a="b\\\\"', u'a="b\\\\"')
    do_test(u'a="b\\\\\\"', u'a="b\\\\\\"')
    do_test(u"a='b c'", u'a=\'b c\'')
   