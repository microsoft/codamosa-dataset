

# Generated at 2022-06-23 05:00:55.751630
# Unit test for function join_args

# Generated at 2022-06-23 05:01:00.153774
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo "foo bar"']) == 'echo "foo bar"'
    assert join_args(['echo', '"foo bar"']) == 'echo "foo bar"'
    # This is the used case:
    assert join_args(['echo', 'foo bar']) == 'echo foo bar'


# Generated at 2022-06-23 05:01:04.683595
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo']) == 'echo'
    assert join_args(['echo', 'hello', 'world']) == 'echo hello world'
    assert join_args(['echo hello world']) == 'echo hello world'



# Generated at 2022-06-23 05:01:15.893709
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Simple sanity check for parse_kv function
    '''
    import json
    import textwrap
    results = []

# Generated at 2022-06-23 05:01:24.859095
# Unit test for function parse_kv
def test_parse_kv():
    #Empty
    assert(parse_kv("", check_raw=True) == {})
    #No key=value format
    assert(parse_kv("echo hello world", check_raw=True) == {"_raw_params": "echo hello world"})
    #One key=value format
    assert(parse_kv("echo foo=bar baz", check_raw=True) == {"echo": "foo=bar baz", "_raw_params": "echo"})
    assert(parse_kv("echo foo", check_raw=True) == {"echo": "foo"})
    assert(parse_kv("foo=bar", check_raw=True) == {"foo": "bar"})
    #Multiple key=value formats

# Generated at 2022-06-23 05:01:28.709220
# Unit test for function join_args
def test_join_args():
    test_args = ['a', 'b', 'c', 'd\n', 'e\ne', 'f\n', 'g' , 'h\ni\n', ' j']
    assert join_args(test_args) == 'a b c d\ne\ne f\ng h\ni\n j'



# Generated at 2022-06-23 05:01:38.694212
# Unit test for function split_args
def test_split_args():
    '''
    This is a unit test for the split_args function.
    '''

# Generated at 2022-06-23 05:01:47.473582
# Unit test for function split_args

# Generated at 2022-06-23 05:01:57.138932
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test the parse_kv function with various inputs
    '''
    # Test a simple input
    result = parse_kv('foo=bar baz=qux')
    assert result == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': None}

    # Test a single leading/trailing space
    result = parse_kv(' foo=bar baz=qux')
    assert result == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': None}

    result = parse_kv('foo=bar baz=qux ')
    assert result == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': None}

    # Test a single word input

# Generated at 2022-06-23 05:02:11.078779
# Unit test for function parse_kv

# Generated at 2022-06-23 05:02:17.919458
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'hello']) == 'echo hello'
    assert join_args(['echo', 'hello\nworld']) == 'echo hello\nworld'
    assert join_args(['echo', 'hello world']) == 'echo hello world'



# Generated at 2022-06-23 05:02:26.852023
# Unit test for function join_args
def test_join_args():
    s = split_args("ls {{ directory }}")
    assert join_args(s) == "ls {{ directory }}"
    s = split_args("echo 'hello '\n'world'")
    assert join_args(s) == "echo 'hello '\n'world'"
    s = split_args("echo\n'hello '\n'world'")
    assert join_args(s) == "echo\n'hello '\n'world'"
    s = split_args("./my_script.sh param1 param2")
    assert join_args(s) == "./my_script.sh param1 param2"
    s = split_args('echo "{{ a }}" "{{ b }}"')
    assert join_args(s) == 'echo "{{ a }}" "{{ b }}"'
    s = split_args

# Generated at 2022-06-23 05:02:37.356985
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', ' \nb', 'c']) == 'a \nb c'
    assert join_args(['a', '\nb', 'c']) == 'a\nb c'
    assert join_args(['a', 'b', '\nc']) == 'a b\nc'
    assert join_args(['a', '\nb', 'c\n']) == 'a\nb c\n'
    assert join_args(['a', '\nb', 'c\n', '\n']) == 'a\nb c\n\n'


# Generated at 2022-06-23 05:02:43.693719
# Unit test for function split_args
def test_split_args():
    params = split_args('echo "{{ hello }} \\n {% if True %}world{% endif %}\\" \\"hello\\"\\n hello\\\\ world "')
    assert params[0] == 'echo', 'Params: %s' % params
    assert params[1] == '"{{ hello }} \\n {% if True %}world{% endif %}\\" \\"hello\\"\\n hello\\\\ world "'

    params = split_args('echo {{ hello }} {% if True %}world{% endif %}\\')
    assert params[0] == 'echo', 'Params: %s' % params
    assert params[1] == '{{ hello }} {% if True %}world{% endif %}\\'

# Generated at 2022-06-23 05:02:52.809111
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a b c', 'd', 'e', 'f']) == 'a b c d e f'
    assert join_args(['a\nb c', 'd', 'e', 'f']) == 'a\nb c d e f'
    assert join_args(['a=b', 'c=d', 'e=f']) == 'a=b c=d e=f'
    assert join_args(['a=b', 'c="d e"', 'f=g']) == 'a=b c="d e" f=g'



# Generated at 2022-06-23 05:03:00.629822
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c='foo bar'") == [u'a=b', u"c='foo bar'"]
    assert split_args(u"a=b c=\"foo bar\"") == [u'a=b', u'c="foo bar"']

# Generated at 2022-06-23 05:03:12.303100
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"1=2") == {u'1': u'2'}
    assert parse_kv(u"1=2 3=4") == {u'1': u'2', u'3': u'4'}
    assert parse_kv(u"1='2'") == {u'1': u'2'}
    assert parse_kv(u"1=2 3='4'") == {u'1': u'2', u'3': u'4'}
    assert parse_kv(u"1=2 a='b c'") == {u'1': u'2', u'a': u'b c'}

# Generated at 2022-06-23 05:03:18.037315
# Unit test for function join_args
def test_join_args():
    s = ['echo', '-n', 'abc\n', 'def']
    assert join_args(s) == 'echo -n abc\ndef'
    # Must retain the end newline from s[2]
    s = ['echo', '-n', 'abc\n', 'def\n']
    assert join_args(s) == 'echo -n abc\ndef\n'
    # Whitespace doesn't matter, but they should be preserved
    s = ['echo', '-n', 'abc\n', 'def']
    assert join_args(s) == 'echo -n abc\ndef'



# Generated at 2022-06-23 05:03:29.154001
# Unit test for function parse_kv
def test_parse_kv():
    cliargs = "creates=/tmp/foo removes=/tmp/bar chdir=/tmp warn=yes executable=/bin/bash"
    assert parse_kv(cliargs) == {u"creates": "/tmp/foo", u"chdir": "/tmp", u"warn": "yes", u"removes": "/tmp/bar", u"executable": "/bin/bash"}
    cliargs = "creates=/tmp/foo removes=/tmp/bar chdir=/tmp warn=yes executable=/bin/bash echo $HOME"

# Generated at 2022-06-23 05:03:41.727884
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo \\\nbar') == ['foo', 'bar']
    assert split_args('foo \\\n  bar') == ['foo', 'bar']
    assert split_args('foo \\ \\\n  bar') == ['foo', 'bar']
    assert split_args('foo \\ \\\n  bar \\') == ['foo', 'bar']
    assert split_args('foo \\ \\\n  bar \\\n') == ['foo', 'bar']
    assert split_args('foo \\ \\\n  bar \\\n  baz') == ['foo', 'bar', 'baz']
    assert split

# Generated at 2022-06-23 05:03:50.665903
# Unit test for function join_args
def test_join_args():
    value = ['echo', '"hello \\"world\\"!"']
    result = join_args(value)
    assert result == 'echo "hello \\"world\\"!"'

    value = ['echo', '"foo"', '"bar"']
    result = join_args(value)
    assert result == 'echo "foo" "bar"'

    value = ['echo', '"hello \\"world\\"!"', "foo", "bar", '"baz"']
    result = join_args(value)
    assert result == 'echo "hello \\"world\\"!" foo bar "baz"'

    value = ['echo', r'\t\n\r\b\f\a']
    result = join_args(value)
    assert result == r'echo \t\n\r\b\f\a'


# Generated at 2022-06-23 05:03:59.968378
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', '\nb', 'c']) == 'a\n b c'
    assert join_args(['a', 'b', '\nc']) == 'a b\n c'
    assert join_args(['a', '\nb', '\nc']) == 'a\n b\n c'
    assert join_args(['a', 'b', '\n\nc']) == 'a b\n\n c'
    assert join_args(['a', '\nb', '\n\nc']) == 'a\n b\n\n c'



# Generated at 2022-06-23 05:04:08.522832
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a b', 'c', 'd']) == 'a b c d'
    assert join_args(['a', 'b', 'c d']) == 'a b c d'
    assert join_args(['a', '', 'b', 'c d']) == 'a \nb c d'
    assert join_args(['a\nb', '', 'c d']) == 'a\nb \nc d'
    assert join_args(['a\nb', '\n', 'c d']) == 'a\nb \nc d'



# Generated at 2022-06-23 05:04:19.905573
# Unit test for function join_args
def test_join_args():
    '''
    Unit test for functions join_args and split_args
    '''
    # Test 1
    cmd = '''/bin/echo -e "a
b
c
"
'''
    tokens = split_args(cmd)
    cmd2 = join_args(tokens)
    assert cmd == cmd2, 'join_args(split_args("{}")) != "{}"'.format(cmd, cmd2)
    # Test 2: single quoted string
    cmd = "/bin/echo 'a\nb\nc'"
    tokens = split_args(cmd)
    cmd2 = join_args(tokens)
    assert cmd == cmd2, 'join_args(split_args("{}")) != "{}"'.format(cmd, cmd2)
    # Test 3: double quoted string

# Generated at 2022-06-23 05:04:30.022573
# Unit test for function parse_kv
def test_parse_kv():

    from ansible.module_utils import basic


# Generated at 2022-06-23 05:04:40.433316
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b="2" c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b="2 \'3\'" c=3') == {'a': '1', 'b': '2 \'3\'', 'c': '3'}

# Generated at 2022-06-23 05:04:47.830563
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv("additional=.dotfile")[u'additional'] == u'.dotfile'

    assert parse_kv("additional=.dotfile")[u'_raw_params'] is None

    assert parse_kv("additional=.dotfile", check_raw=True)[u'additional'] == u'.dotfile'

    assert parse_kv("additional=.dotfile", check_raw=True)[u'_raw_params'] == u'additional=.dotfile'

    assert parse_kv("a=1 b=2 c=3", check_raw=True)[u'_raw_params'] == u'a=1 b=2 c=3'

    assert parse_kv("a=1 b=2 c=3", check_raw=True)[u'c'] == u'3'



# Generated at 2022-06-23 05:04:55.352514
# Unit test for function parse_kv
def test_parse_kv():
    s = 'a=b c="d d" e="f=g"'
    d = parse_kv(s)

    assert(d == {'a':'b', 'c':'d d', 'e':'f=g'})

    s = 'a=b c="d d" e="f=g" g=\'h\' i="j j" k=\'l=m\''
    d = parse_kv(s)

    assert(d == {'a':'b', 'c':'d d', 'e':'f=g', 'g':'h', 'i':'j j', 'k':'l=m'})

    s = 'a=b c="d d" e="f=g" g=\'h\' i="j j" k=\'l=m\' h=n'
    d

# Generated at 2022-06-23 05:05:06.934686
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar baz" zorp') == ['foo', '"bar baz"', 'zorp']
    assert split_args('foo "bar\\\\ baz" zorp') == ['foo', '"bar\\\\ baz"', 'zorp']
    assert split_args('foo "bar\\\\" baz" zorp') == ['foo', '"bar\\\\" baz"', 'zorp']
    assert split_args('foo "bar\\\\"" zorp') == ['foo', '"bar\\\\""', 'zorp']
    assert split_args('foo "bar" baz') == ['foo', '"bar"', 'baz']
    assert split_args('foo "bar\" baz"')

# Generated at 2022-06-23 05:05:15.300545
# Unit test for function parse_kv
def test_parse_kv():
    '''
    assert based tests for parse_kv function
    '''
    assert parse_kv("foo=bar baz=qux") == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv("foo='bar baz'") == {u'foo': u'bar baz'}
    assert parse_kv("foo='bar baz' 'qux quux'") == {u'foo': u'bar baz', u'_raw_params': u"'qux quux'"}
    assert parse_kv("foo=bar 'a=b'") == {u'foo': u'bar', u'_raw_params': u"'a=b'"}

# Generated at 2022-06-23 05:05:24.105349
# Unit test for function join_args
def test_join_args():
    assert join_args(split_args('file=/path/to/bar state=directory')) == \
            'file=/path/to/bar state=directory'
    assert join_args(split_args('file=/path/to/bar\nstate=directory')) == \
            'file=/path/to/bar\nstate=directory'
    assert join_args(split_args('file=/path/to/bar state=directory\n  other=-mo')) == \
            'file=/path/to/bar state=directory\n  other=-mo'
    cmd = 'state=directory recurse=yes file=/path/to/bar mode=700'
    assert join_args(split_args(cmd)) == cmd
    cmd = 'state=directory recurse=yes\nfile=/path/to/bar mode=700'
    assert join

# Generated at 2022-06-23 05:05:27.709779
# Unit test for function join_args
def test_join_args():
    assert join_args(["1", "\n", "2", "\n3"]) == '1\n2\n3'
    assert join_args(["1", "\n2 3"]) == '1\n2 3'



# Generated at 2022-06-23 05:05:32.091378
# Unit test for function join_args
def test_join_args():
    s = ['echo', 'hello', 'world']
    result = join_args(s)
    assert result == 'echo hello world'
    s = ['echo', 'hello', '\n', 'world']
    result = join_args(s)
    assert result == 'echo hello\nworld'



# Generated at 2022-06-23 05:05:42.328792
# Unit test for function split_args
def test_split_args():
    import random
    import string
    random.seed(0)
    def random_string():
        return ''.join([random.choice(string.ascii_letters) for x in range(0, random.randint(0, 20))])
    for i in range(0, 1000):
        # Randomly generate a string to test
        arg_string = random_string()
        arg_list = []
        open_block_types = ['{', '{{', '{%', '{#']
        close_block_types = ['}', '}}', '%}', '#}']
        while len(arg_string) > 0:
            # Pick a random place to split the argument
            split_at = random.randint(0, len(arg_string))

# Generated at 2022-06-23 05:05:52.423861
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\nb', 'c']) == 'a\nb c'
    assert join_args(['a', 'b\nc']) == 'a b\nc'
    assert join_args(['a\nb\nc']) == 'a\nb\nc'
    assert join_args(['a', 'b', 'c', '\n']) == 'a b c \n'
    assert join_args(['a', '\n', 'b', 'c', '\n']) == 'a \n b c \n'
    # This behavior is not standard in shell, but it's what we need

# Generated at 2022-06-23 05:06:02.553530
# Unit test for function split_args
def test_split_args():
    import pytest

# Generated at 2022-06-23 05:06:12.506545
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\n', 'b', 'c']) == 'a\n b c'
    # Note: When using split_args and join_args, it is important
    # to check the result with a unit test. It is not sufficient
    # to check that split_args(join_args(s)) == s.
    assert join_args(['a ', 'b']) == 'a b'
    assert join_args(['foo\n', '"bar"', 'baz']) == 'foo\n "bar" baz'



# Generated at 2022-06-23 05:06:21.457928
# Unit test for function split_args

# Generated at 2022-06-23 05:06:27.101010
# Unit test for function join_args
def test_join_args():
    given_string = 'first\nsecond third\nfourth\nfifth "sixth sev enth" eighth'
    expected_string = 'first\nsecond third\nfourth\nfifth "sixth sev enth" eighth'

    assert(join_args(split_args(given_string)) == expected_string)


# Generated at 2022-06-23 05:06:37.343137
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('B=b2 C=c2 b=b1 c=c1', True) == {'B': 'b2', 'C': 'c2', 'b': 'b1', 'c': 'c1', '_raw_params': 'b=b2 c=c2 b=b1 c=c1'}
    assert parse_kv('B=b2 C="c3 b3" b=b1 c=c1', True) == {'B': 'b2', 'C': 'c3 b3', 'b': 'b1', 'c': 'c1', '_raw_params': 'B=b2 C="c3 b3" b=b1 c=c1'}

# Generated at 2022-06-23 05:06:45.536861
# Unit test for function join_args
def test_join_args():
    assert join_args(['arg1','arg2','arg3']) == 'arg1 arg2 arg3'
    assert join_args(['arg1','arg2','arg3\n']) == 'arg1 arg2 arg3\n'
    assert join_args(['arg1\n','arg2\n','arg3\n']) == 'arg1\narg2\narg3\n'
    assert join_args(['arg1\n','arg2\n','arg3\narg4']) == 'arg1\narg2\narg3\narg4'


# Generated at 2022-06-23 05:06:57.005177
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv(u"a=b") == {'a': 'b'})
    assert(parse_kv(u"foo=bar baz=qux") == {'foo': 'bar', 'baz': 'qux'})
    assert(parse_kv(u"foo=bar baz=qux 'a=b c=d'") == {'foo': 'bar', 'baz': 'qux', 'a=b c=d': ''})
    assert(parse_kv(u"foo=bar baz=qux 'a=b c=d'") == {'foo': 'bar', 'baz': 'qux', 'a=b c=d': ''})

# Generated at 2022-06-23 05:07:05.658435
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', 'b', 'c', 'd']) == 'a b c d'
    assert join_args(['a b', 'c']) == 'a b c'
    assert join_args(['a b', 'c d']) == 'a b c d'
    assert join_args(['a', 'b', 'c d']) == 'a b c d'
    assert join_args(['a\nb', 'c', 'd']) == 'a\nb c d'



# Generated at 2022-06-23 05:07:15.561875
# Unit test for function parse_kv
def test_parse_kv():
    # 1. Whitespace test
    # Test for mixed whitespace, ensure that consecutive whitespace characters are combined,
    # whitespace before and after quotes are removed, and final result is a flat string
    test_string = "  key1 =    value1    key2   =   \"value2\"    key3    =    \"value3\"   "
    expected_result = {
        u'key1': u'value1',
        u'key2': u'value2',
        u'key3': u'value3'
    }

    actual_result = parse_kv(test_string)
    assert actual_result == expected_result

    # 2. Non-key special characters
    # Ensure that all special characters can be used as values, including in strings

# Generated at 2022-06-23 05:07:25.380360
# Unit test for function join_args
def test_join_args():
    s = ['echo', 'foo']
    assert join_args(s) == 'echo foo'
    s = ['echo', 'foo', 'bar']
    assert join_args(s) == 'echo foo bar'
    s = ['echo', 'foo bar']
    assert join_args(s) == 'echo "foo bar"'
    s = ['echo foo', 'bar']
    assert join_args(s) == 'echo foo bar'
    s = ['echo foo', 'bar', 'baz']
    assert join_args(s) == 'echo foo bar baz'
    s = ['echo foo', 'bar baz']
    assert join_args(s) == 'echo "foo bar baz"'
    s = ['echo "foo', 'bar"', 'baz']

# Generated at 2022-06-23 05:07:31.082807
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo', '\n', 'bar', '\n', 'baz']) == 'foo\nbar\nbaz'
    assert join_args(['foo bar', 'bar baz', '\nbar']) == 'foo bar bar baz\nbar'


# Generated at 2022-06-23 05:07:35.547179
# Unit test for function parse_kv
def test_parse_kv():
    assert {} == parse_kv('')
    assert {u'foo': u'val'} == parse_kv('foo=val')
    assert {u'foo': u'val', u'foo2': u'val2'} == parse_kv('foo=val foo2=val2')
    assert {u'foo': u'val foo2=val2'} == parse_kv('foo=val foo2=val2', True)



# Generated at 2022-06-23 05:07:46.912419
# Unit test for function split_args
def test_split_args():
    # Test simple command
    assert split_args("cmd") == ['cmd']
    # Test simple command
    assert split_args("cmd arg1 arg2") == ['cmd', 'arg1', 'arg2']
    # Test simple command with quotes
    assert split_args('cmd arg1 arg2"') == ['cmd', 'arg1', 'arg2"']
    assert split_args("cmd arg1 arg2'") == ['cmd', 'arg1', 'arg2\'']
    # Test simple command with newline
    assert split_args("cmd \n arg1 \n arg2") == ['cmd', 'arg1', 'arg2']
    assert split_args("cmd \n arg1 'arg2'") == ['cmd', 'arg1', 'arg2']
    # Test simple command with newline and quotes

# Generated at 2022-06-23 05:07:56.810607
# Unit test for function split_args

# Generated at 2022-06-23 05:08:04.969480
# Unit test for function parse_kv

# Generated at 2022-06-23 05:08:16.377602
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv("one=1 two=2")
    print(result)
    assert result == {"one": "1", "two": "2"}
    result = parse_kv("one=1 two=2 three=3")
    print(result)
    assert result == {"one": "1", "two": "2", "three": "3"}
    result = parse_kv("one='1' two=2 three=3")
    print(result)
    assert result == {"one": "1", "two": "2", "three": "3"}
    result = parse_kv("one=1 two=2 three=three")
    print(result)
    assert result == {"one": "1", "two": "2", "three": "three"}

# Generated at 2022-06-23 05:08:27.519577
# Unit test for function split_args
def test_split_args():
    # basic split
    assert split_args("1 2 3") == ['1', '2', '3']

    # split on embedded newlines
    assert split_args("1\n2 3") == ['1\n2', '3']
    assert split_args("1\n2\n3\n") == ['1\n2\n3\n']

    # retain backslash escaping
    assert split_args("\\ 1 2 3") == ['\\ 1', '2', '3']

    # ignore backslash escapes inside quotes
    assert split_args("a='\\' 1 2 3'") == ["a='\\' 1 2 3'"]
    assert split_args('a="\\" 1 2 3"') == ['a="\\" 1 2 3"']

    # ignore backslash escapes inside jinja2 blocks
    assert split_

# Generated at 2022-06-23 05:08:39.109084
# Unit test for function parse_kv
def test_parse_kv():
    # test basic
    assert parse_kv("foo=bar") == dict(foo="bar")
    # test multi
    assert parse_kv("foo=bar bar2=baz") == dict(foo="bar", bar2="baz")
    # test with spaces
    assert parse_kv("foo=bar   baz=foo") == dict(foo="bar", baz="foo")
    # test multiple equal signs
    assert parse_kv("foo=bar=moo") == dict(foo="bar=moo")
    # test escaped equal signs
    assert parse_kv("foo=bar\\=moo") == dict(foo="bar=moo")
    # test escaped lots of things
    assert parse_kv("foo=bar\\=moo\\ bar") == dict(foo="bar=moo bar")
    # test

# Generated at 2022-06-23 05:08:48.498759
# Unit test for function parse_kv
def test_parse_kv():
    args = "arg1=simple arg2='key=value key2=value'"
    options = parse_kv(args)
    assert options['arg1'] == 'simple'
    assert options['arg2'] == "key=value key2=value"

    args = "arg1=simple arg2='key=value key2=value' arg3='key=value1=value2'"
    options = parse_kv(args)
    assert options['arg1'] == 'simple'
    assert options['arg2'] == "key=value key2=value"
    assert options['arg3'] == "key=value1=value2"


# Generated at 2022-06-23 05:08:59.261568
# Unit test for function split_args

# Generated at 2022-06-23 05:09:08.357143
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('"foo=baz" "bar baz"') == {u'foo': u'baz', u'_raw_params': u'"bar baz"'}
    assert parse_kv('"foo=baz" "bar baz"', check_raw=True) == {u'foo': u'baz', u'_raw_params': u'"bar baz"'}
    assert parse_kv('foo=baz "bar baz"') == {u'foo': u'baz', u'_raw_params': u'"bar baz"'}
    assert parse_kv('"foo=baz" bar baz') == {u'foo': u'baz', u'_raw_params': u'bar baz'}

# Generated at 2022-06-23 05:09:19.841549
# Unit test for function split_args
def test_split_args():
    """
    split_args() takes a string of command line arguments and returns a list of tokens, such
    that when they are joined with spaces they represent the original arguments.
    This function is different than shlex.split() in that it understands how to handle
    quotes and Jinja2 expressions.
    """
    test_cases = []
    test_cases.append(("a=b", ['a=b']))
    test_cases.append(("a=b c=d", ['a=b', 'c=d']))
    test_cases.append(("a=b c=d\n", ['a=b', 'c=d']))
    test_cases.append(("a=b\n c=d", ['a=b', 'c=d']))

# Generated at 2022-06-23 05:09:30.865118
# Unit test for function parse_kv

# Generated at 2022-06-23 05:09:34.437713
# Unit test for function join_args
def test_join_args():
    r = join_args(['echo "111\n222"', '\n', '', '-n', '\n', '333'])
    assert r == 'echo "111\n222"\n\n-n\n333'



# Generated at 2022-06-23 05:09:43.877752
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1") == {"a": "1"}
    assert parse_kv("a='1'") == {"a": "1"}
    assert parse_kv("a='1 2'") == {"a": "1 2"}
    assert parse_kv("a=1 b=2") == {"a": "1", "b": "2"}
    assert parse_kv("a='1 2' b='3 4'") == {"a": "1 2", "b": "3 4"}
    assert parse_kv("a='1=2'") == {"a":"1=2"}
    assert parse_kv("a='1\\'2'") == {"a": "1'2"}
    assert parse_kv("a='1=\\'2'") == {"a": "1='2"}

# Generated at 2022-06-23 05:09:47.228682
# Unit test for function parse_kv
def test_parse_kv():
    s = "a=1 b='c d' e='\\'f'"
    result = parse_kv(s)
    assert result == {"a": "1", "b": "c d", "e": "'f"}



# Generated at 2022-06-23 05:09:57.233314
# Unit test for function parse_kv
def test_parse_kv():
    parse_kv('a=1 b=2 c=3', True)
    parse_kv('a')
    parse_kv('a="b"')
    parse_kv('a="b" c="d')
    parse_kv('a="b" c="d"')
    parse_kv('a="b\"c\"" d="e\'f\'g"')
    parse_kv('a="b" c="d"', True)


# Include shlex.split which is a Python 3.8 function in Python 3.7
# https://github.com/python/cpython/commit/9e1e7a4ebba4d19529a4cdfa65055e4ae06059c8

# Generated at 2022-06-23 05:10:01.878269
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', '\nb']) == 'a \nb'
    assert join_args(['a', '\n', 'b']) == 'a \nb'
    assert join_args(['a', '\nb', 'c']) == 'a \nb c'
    assert join_args(['a', '\n-b', 'c']) == 'a \n-b c'


# Generated at 2022-06-23 05:10:10.854613
# Unit test for function split_args
def test_split_args():
    # Test simple
    args = '''a b c d'''
    expected_results = [u'a', u'b', u'c', u'd']
    results = split_args(args)
    assert results == expected_results
    # Test line continuation
    args = '''a b\
c d'''
    expected_results = [u'a', u'b c', u'd']
    results = split_args(args)
    assert results == expected_results
    # Test jinja2 variables
    args = '''a "{{foo}}" c "bar" d "{{ test }}" e'''
    expected_results = [u'a', u'"{{foo}}"', u'c', u'"bar"', u'd', u'"{{ test }}"', u'e']
    results = split_args(args)


# Generated at 2022-06-23 05:10:19.460750
# Unit test for function join_args
def test_join_args():
    assert join_args(["a", "b", "c", "d"]) == "a b c d"
    assert join_args(["a\nb", "c", "d"]) == "a\nb c d"
    assert join_args(["a\nb\n", "c", "d"]) == "a\nb\n c d"
    assert join_args(["a\nb\n", "c", "d", "e\n", "f\ng"]) == "a\nb\n c d e\n f\ng"



# Generated at 2022-06-23 05:10:22.973636
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo', 'bar', 'baz\n', 'qux']) == 'foo bar baz\nqux'



# Generated at 2022-06-23 05:10:27.064908
# Unit test for function join_args
def test_join_args():
    assert join_args(['line']) == 'line'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['line\n']) == 'line\n'
    assert join_args(['line', '\n']) == 'line \n'



# Generated at 2022-06-23 05:10:38.651885
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.parsing.splitter import split_args
    from ansible.parsing.splitter import join_args
    from ansible.parsing.quoting import unquote
    from ansible.module_utils._text import to_bytes

    def _encode(s):
        return to_bytes(s, encoding=u'utf-8', errors=u'surrogate_or_strict')

    def _test_parse_kv(args, check_raw, output, raw_params=None):
        args = split_args(args)
        output = split_args(output)
        options = [unquote(o) for o in output]
        if raw_params:
            raw_params = split_args(raw_params)

# Generated at 2022-06-23 05:10:43.751434
# Unit test for function join_args
def test_join_args():
    tests = (
        (["a", "\nb", "c"], "a\nb c"),
        (["a", "b", "\nc"], "a b\nc"),
    )
    for args, expected in tests:
        result = join_args(args)
        assert result == expected, "Failed: {} == {} != {}".format(args, expected, result)



# Generated at 2022-06-23 05:10:48.411379
# Unit test for function join_args
def test_join_args():
    _in = [
        'a',
        ' ',
        'b',
        '\n',
        '\t',
        'c'
    ]
    _out = join_args(_in)
    assert _out == 'a b\n\tc', _out

